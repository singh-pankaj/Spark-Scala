package processing

import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessPatientGuardian(spark: SparkSession) {

  import spark.implicits._

  def PatientGuardianObj(Patient: DataFrame, Individual: DataFrame, PatientGuardian: DataFrame, Address: DataFrame, MasterCity: DataFrame, MasterState: DataFrame, MasterPostalCode: DataFrame, MasterCountry: DataFrame, MasterPhoneType: DataFrame, phone: DataFrame, MasterRelationship: DataFrame) {

    val PatientGuardianPath = prop.getProperty("PatientGuardianPath")

    val PatientGuardianDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientGuardian.as("PG"), $"PG.PatientUid" === $"PT.PatientUid", "inner")
      .join(Address.as("A"), $"A.AddressUid" === $"PG.AddressUid", "left")
      .join(MasterCity.as("MC"), $"MC.CityUid" === $"A.CityUid", "left")
      .join(MasterState.as("MS"), $"MS.StateUid" === $"A.StateUid", "left")
      .join(MasterPostalCode.as("MPC"), $"MPC.PostalCodeUid" === $"A.PostalCodeUid", "left")
      .join(MasterCountry.as("MK"), $"MK.countryuid" === $"A.countryuid", "left")
      .join(phone.as("PH"), $"ph.phoneuid" === $"PG.Phoneuid", "left")
      .join(MasterPhoneType.as("MPH"), $"mph.PhoneTypeUid" === $"ph.PhoneTypeUid", "left")
      .join(MasterRelationship.as("MR"), $"MR.RelationshipUid" === $"PG.PatientRelationshipToGuardianUid", "left")
      .select($"PT.PatientID", $"PT.PatientUid", $"ID.PracticeUid", $"PG.GuardianLastName", $"PG.GuardianFirstName"
        , $"A.Line2".as("StreetLineAddress2"), $"A.Line3".as("StreetLineAddress3"), $"A.Line4".as("StreetLineAddress4")
        , $"MC.Name".as("City"), $"MS.Code".as("StateCode"), $"MS.Name".as("State"), $"MPC.Code".as("ZipCode"), $"MK.ShortDescription".as("CountryCode"), $"MK.Description".as("Country")
        , $"mph.description".as("TelecomTypeText"), $"ph.PhoneNo".as("TelecomValue"), $"MR.ExternalID".as("RelationshipToPatientCode"), $"MR.Description".as("RelationshipToPatientText"),
        $"MR.ExternalID".as("masterpatientracecode"), $"MR.Description".as("masterpatientracetext"))
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("PatientGuardianKey", lit(null).cast("string"))
      .limit(500)
    //.select(schema.head,schema.tail:_*)
    //.drop("columnName")
    //.withColumn("PatientUid", coalesce($"",$""))

    dfwritetohive(PatientGuardianDF, spark, PatientGuardianPath)


  }

}