package processing

import org.apache.spark.sql.functions.{coalesce, lit, split}
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessPatientResultObservation(spark: SparkSession) {

  import spark.implicits._

  def PatientResultObservationObj(Patient: DataFrame, Individual: DataFrame, PatientResultObservation: DataFrame, ServiceProvider: DataFrame, MasterCode: DataFrame, Master: DataFrame) {
    val PatientResultObservationPath = prop.getProperty("PatientResultObservationPath")

    val PatientResultObservationDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientResultObservation.as("PR"), $"PR.PatientUid" === $"ID.Individualuid", "inner")
      .join(ServiceProvider.as("SP"), $"SP.ServiceProviderUid" === $"PR.ServiceProviderUid", "left")
      .join(Individual.as("ID1"), $"SP.ServiceProviderUid" === $"ID1.Individualuid", "left")
      .join(Master.filter($"Type" === "ResultInterpretation").as("MPC"), $"MPC.MasterUid" === $"PR.MasterResultInterpretationUid", "left")
      .join(Master.filter($"Type" === "TargetSite").as("MPC1"), $"MPC1.MasterUid" === $"PR.MasterTargetSiteUid", "left")
      .join(Master.as("MPC2"), $"MPC2.MasterUid" === $"PR.MasterResultInterpretationUid", "left")
      .join(MasterCode.as("MC1"), $"MC1.CodeUid" === $"PR.ProcedureUid", "left")
      .join(MasterCode.as("MC2"), $"MC2.CodeUid" === $"PR.ObservationCodeUid", "left")
      .join(MasterCode.as("MC3"), $"MC2.CodeUid" === $"PR.MasterMethodCodeUid", "left")
      .select($"PT.PatientID", $"PR.CodeSystem".as("observationcategory"), $"PR.ResultDate".as("observationdate"), $"PR.PracticeCode", $"MC2.Code", $"PR.PracticeDescription", $"MC2.description"
        , $"PR.ResultValue".as("observationvalue"), $"MPC1.Code".as("targetsitecode"), $"MPC1.Name".as("targetsitetext")
        , $"SP.NPI".as("serviceprovidernpi"), $"ID1.Last".as("serviceproviderlastname"), $"ID1.First".as("serviceproviderfirstname")
        , $"PR.negationind", $"PR.resultobservationstatus", $"PR.resultorderdescription", $"PR.resultorderdate", $"PR.laboratoryid"
        , $"PR.laboratoryname", $"PR.resultordercode", $"PR.obssubid", $"PR.Unit".as("resultobsunit"), $"ID.Practiceuid", $"PT.PatientUid",$"PR.ReferenceObservationRange")
      .withColumn("observationcode", coalesce($"PR.PracticeCode", $"MC2.Code"))
      .withColumn("observationname", coalesce($"PR.PracticeDescription", $"MC2.description"))
      .withColumn("Range", split($"PR.ReferenceObservationRange", "-"))
      .select($"Range".getItem(0).as("referencelowerrange"), $"Range".getItem(1).as("referenceupperrange"))
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("methodcode", lit(null).cast("string"))
      .withColumn("methodcodetext", lit(null).cast("string"))
      .withColumn("procedurecode", lit(null).cast("string"))
      .withColumn("proceduretext", lit(null).cast("string"))
      //  .select(schema.head, schema.tail: _*)
      .drop("PR.PracticeCode", "MC2.Code", "PR.PracticeDescription", "MC2.description")
      //.withColumn("PatientUid", coalesce($"",$""))
      .limit(500)

    dfwritetohive(PatientResultObservationDF, spark, PatientResultObservationPath)
  }
}
