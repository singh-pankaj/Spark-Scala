package processing

import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessPatientDemographics(spark: SparkSession) {

  import spark.implicits._

  def PatientObj(Patient: DataFrame,
                 Address: DataFrame,
                 Individual: DataFrame,
                 IndividualIdentifier: DataFrame,
                 Mastercity: DataFrame,
                 MasterState: DataFrame,
                 MasterCountry: DataFrame,
                 MasterPostalCode: DataFrame,
                 Phone: DataFrame,
                 MasterPhoneType: DataFrame,
                 MasterGender: DataFrame,
                 MasterMaritalStatus: DataFrame,
                 Master: DataFrame,
                 ServiceProvider: DataFrame) {

    val PatientPath = prop.getProperty("PatientPath")


    val PatientDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(IndividualIdentifier.as("II"), $"II.Individualuid" === $"ID.Individualuid", "left")
      .join(Address.as("AD"), $"AD.AddressUid" === $"ID.Address1Uid", "left")
      .join(Address.as("AD1"), $"AD1.AddressUid" === $"ID.Address2Uid", "left")
      .join(Mastercity.as("MC"), $"MC.cityuid" === $"AD.cityuid", "left")
      .join(MasterState.as("MS"), $"AD.StateUid" === $"MS.StateUid", "left")
      .join(MasterCountry.as("MT"), $"AD.CountryUid" === $"MT.CountryUid", "left")
      .join(MasterPostalCode.as("MPC"), $"MPC.PostalCodeUid" === $"AD.PostalCodeUid", "left")
      .join(Phone.as("PH"), $"PH.PhoneUid" === $"ID.Phone1Uid", "left")
      .join(MasterPhoneType.as("MF"), $"MF.PhoneTypeUid" === $"PH.PhoneTypeUid", "left")
      .join(Phone.as("PH1"), $"PH1.PhoneUid" === $"ID.Phone2Uid", "left")
      .join(MasterPhoneType.as("MF1"), $"MF1.PhoneTypeUid" === $"PH1.PhoneTypeUid", "left")
      .join(MasterGender.as("MG"), $"MG.GenderUid" === $"ID.GenderUid", "left")
      .join(MasterMaritalStatus.as("MMT"), $"ID.MaritalStatusUid" === $"MMT.MaritalStatusUid", "left")
      .join(Master.as("M"), $"M.Masteruid" === $"PT.MasterReligiousAffiliationUid", "left")
      .join(Address.as("A1"), $"A1.AddressUid" === $"PT.BirthPlaceUid", "left")
      .join(MasterState.as("MS1"), $"A1.StateUid" === $"MS1.StateUid", "left")
      .join(MasterCountry.as("MC1"), $"A1.CountryUid" === $"MC1.CountryUid", "left")
      .join(MasterPostalCode.as("MPC1"), $"MPC1.PostalCodeUid" === $"A1.PostalCodeUid", "left")
      .join(ServiceProvider.as("SP"), $"SP.ServiceProviderUid" === $"PT.Provideruid", "left")
      .join(Individual.as("ID1"), $"SP.ServiceProviderUid" === $"ID1.Individualuid", "left")
      .select($"PT.PatientID",
        $"ID.Last".as("lastname"),
        $"ID.First".as("firstname"), $"ID.Middle".as("middlename"), $"AD.Line1".as("streetlineaddress1")
        , $"AD1.Line1".as("streetlineaddress2"), $"MC.Name".as("city"), $"MS.Code".as("statecode"), $"MS.Name".as("state"), $"MPC.Code".as("zipcode")
        , $"MT.ShortDescription".as("coutrycode"), $"MT.Description".as("country"), $"MF.Description".as("telecomtypetext1"), $"PH.PhoneNo".as("telecomvalue1")
        , $"MF1.Description".as("telecomtypetext2"), $"PH1.PhoneNo".as("telecomvalue2"),
        $"MG.Description".as("gender"), $"ID.birthdate".as("dob"), $"ID.DeathDate".as("deathdate"), $"MMT.ExternalID".as("maritalstatuscode"),
        $"MMT.Description".as("maritalstatustext"), $"M.Code".as("religiousaffiliationcode"), $"M.Name".as("religiousaffiliationtext"), $"MS1.Code".as("birthstatecode"),
        $"MS1.Name".as("birthstate"), $"MPC1.Code".as("birthzipcode"), $"MC1.ShortDescription".as("birthcountrycode"), $"MC1.Description".as("birthcountry"),
        $"Sp.NPI".as("serviceprovidernpi"), $"ID1.Last".as("serviceproviderlastname"), $"ID1.First".as("serviceproviderfirstname"), $"II.Identifier".as("ssn"),
        $"PT.deathreason", $"PT.isdeceased", $"PT.patient_emr_id", $"ID.EmailAddress".as("emailid"), $"PT.birthorder", $"PT.multiplebirthplaceindicator",
        $"PT.patientuid", $"PT.medicalrecordnumber", $"ID.practiceuid")
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("patientdemographicskey", lit(null).cast("string"))
      .withColumn("streetlineaddress3", lit(null).cast("string"))
      .withColumn("streetlineaddress4", lit(null).cast("string"))
      .withColumn("locationofdeath", lit(null).cast("string"))
      // .select(schema.head, schema.tail: _*)
      //.drop("columnName")
      //.withColumn("PatientUid", coalesce($"",$""))
      .limit(500)
    dfwritetohive(PatientDF, spark, PatientPath)


  }

}
