package processing

import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessPatientMedication(spark: SparkSession) {

  def PatientMedicationObj(Patient: DataFrame, Individual: DataFrame, ServiceProvider: DataFrame, MasterCode: DataFrame, Master: DataFrame, MasterMedicationRoute: DataFrame, PatientMedication: DataFrame) {


    import spark.implicits._
    val PatientMedicationPath = prop.getProperty("PatientMedicationPath")

    val PatientMedicationDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientMedication.as("PM"), $"PM.PatientUid" === $"PT.PatientUid", "inner")
      .join(ServiceProvider.as("SP"), $"SP.ServiceProviderUid" === $"PM.ServiceProviderUid", "left")
      .join(Individual.as("ID1"), $"ID1.IndividualUid" === $"SP.ServiceProviderUid", "left")
      .join(MasterCode.as("MC"), $"MC.CodeUid" === $"PM.ProcedureUid", "left")
      .join(MasterCode.as("MC1"), $"MC1.CodeUid" === $"PM.MedicationIndicationProblemCodeUid", "left")
      .join(MasterCode.as("MC2"), $"MC2.CodeUid" === $"PM.MedicationReactionProblemCodeUid", "left")
      .join(Master.filter($"Type" === "ProblemSeverity").as("MS"), $"MS.MasterUid" === $"PM.MasterMedicationReactionProblemServerityUid", "left")
      .join(Master.filter($"Type" === "MedicationStatus").as("MS1"), $"MS1.MasterUid" === $"PM.MasterMedicationStatusUid", "left")
      .join(Master.as("MS2"), $"MS2.MasterUid" === $"PM.MasterMedicationProductFormUid", "left")
      .join(MasterMedicationRoute.as("MMR"), $"MMR.MedicationRouteUid" === $"PM.MedicationReactionProblemCodeUid", "left")
      .select($"PT.PatientID", $"PM.medicationcode", $"PM.name".as("medicationname"), $"PM.medicationcode",
        $"PM.DrugSource".as("medicationcategory"), $"PM.StartDate".as("medstartdate"), $"PM.StopDate".as("medstopdate"), $"PM.administeredeffectivedate", $"PM.RefillQuantity".as("repeatnumber"),
        $"PM.medicationroutecode", $"PM.Route".as("medicationroutetext"), $"PM.dosequantity", $"PM.dosequantityunitcode", $"PM.dosequantityunittext", $"PM.medicationproductformcode",
        $"PM.productForm".as("medicationproductformtext"), $"MC.Code".as("procedurecode"), $"MC.Description".as("proceduretext"), $"MC.CodeSystem".as("procedurecategory"),
        $"PM.prescribeelectronically", $"PM.negationind", $"PM.medicationbrandname", $"PM.medicationgenericname", $"PM.maxdosequantity", $"SP.NPI".as("serviceprovidernpi"),
        $"ID1.Last".as("serviceproviderlastname"), $"ID1.First".as("serviceproviderfirstname"), $"PM.dispensingtimeofsupply", $"PM.DispensingDoseQuanity".as("dispensingdosequantity"),
        $"PM.supplyprescriberlastname", $"PM.supplyprescriberfirstname", $"PM.supplyperformerlastname", $"PM.supplyperformerfirstname", $"PM.servicelocationid",
        $"PM.servicelocationname", $"PM.medicationindicationcriteria", $"PM.medicationindicationproblemcode", $"MC1.Description".as("medicationindicationproblemtext"),
        $"MC1.CodeSystem".as("medicationindicationproblemcategory"), $"PM.medicationseriesnumber", $"PM.medicationreactionproblemcode", $"MC2.Description".as("medicationreactionproblemtext"),
        $"MC2.CodeSystem".as("medicationreactionproblemcategory"), $"PM.medicationreactionproblemseveritycode", $"MS.Name".as("medicationreactionproblemseveritytext"), $"MS2.Code".as("medicationstatuscode"),
        $"MS2.Name".as("medicationstatustext"), $"PM.medicinemanufacturer", $"PM.medicineid", $"PM.productinstancescopingentityid", $"PM.practicepatientmedicationkey", $"PM.documentationdate"
        , $"PT.PatientUid", $"I.Practiceuid")
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("masterprocedurecode", lit(null).cast("string"))
      .withColumn("masterproceduretext", lit(null).cast("string"))
      .withColumn("mastermedicationcode", lit(null).cast("string"))
      .withColumn("mastermedicationname", lit(null).cast("string"))
      .withColumn("mastermedicationproductformcode", lit(null).cast("string"))
      .withColumn("mastermedicationproductformtext", lit(null).cast("string"))
      .withColumn("mastermedicationindicationproblemcode", lit(null).cast("string"))
      .withColumn("mastermedicationindicationproblemtext", lit(null).cast("string"))
      .withColumn("mastermedicationreactionproblemcode", lit(null).cast("string"))
      .withColumn("mastermedicationreactionproblemtext", lit(null).cast("string"))
      .withColumn("mastermedicationreactionproblemseveritycode", lit(null).cast("string"))
      .withColumn("mastermedicationreactionproblemseveritytext", lit(null).cast("string"))
      .withColumn("mastermedicationstatuscode", lit(null).cast("string"))
      .withColumn("mastermedicationstatustext", lit(null).cast("string"))
      .withColumn("mastermedicationroutecode", lit(null).cast("string"))
      .withColumn("mastermedicationroutetext", lit(null).cast("string"))
      // .select(schema.head, schema.tail: _*)
      //.drop("columnName")
      //.withColumn("PatientUid", coalesce($"",$""))
      .limit(500)
    dfwritetohive(PatientMedicationDF, spark, PatientMedicationPath)


  }

}
