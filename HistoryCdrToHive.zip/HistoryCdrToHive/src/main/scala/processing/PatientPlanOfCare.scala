package processing

import org.apache.spark.sql.functions.{coalesce, lit}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class PatientPlanOfCare(spark: SparkSession) extends schemas {

  import spark.implicits._

  def PlanOfCareObj(Patient: DataFrame, Individual: DataFrame, PlanOfCare: DataFrame, Master: DataFrame) {

    val PlanOfCarePath = prop.getProperty("PatientPlanOfCarePath")

    val schema = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], PatientPlanofCareSchema).columns


    val PlanOfCareDF = Patient.as("PT").join(PlanOfCare.as("PP"),$"PT.PatientUid"===$"PP.PatientUid")
      .join(Individual.as("ID"), $"ID.IndividualUid" === $"PT.PatientUid", "inner")
      .join(Master.as("MS"), $"PP.MasterPlanOfCareStatusUid" === $"MS.MasterUid", "left")
      .join(Master.as("MP"), $"PP.MasterPlanOfCareUid" === $"MP.MasterUid")
      .select($"PT.patientid", $"PP.instructions", $"PP.practicecode", $"PP.practicedescription", $"PP.effectivedate", $"PP.planofcaregroup",
        $"MP.name".as("mpn")
        ,$"MS.Code".as("msc")
        ,$"MP.code".as("mpc")
        ,$"MS.name".as("msn"))
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("PatientPlanOfCareKey", lit(null).cast("string"))
      .withColumn("planofcarestatuscode", $"msc")
      .withColumn("planofcarestatustext", $"msn")
      .withColumn("practicecode", coalesce($"PP.practicecode", $"mpc"))
      .withColumn("practicedescription", coalesce($"PP.practicedescription", $"mpn"))
      .withColumn("masterplanofcarestatustext", lit(null).cast("string"))
      .drop("mpc", "mpn","msc","msn")
      .limit(500)
    // .select(schema.head, schema.tail: _*)

    PlanOfCareDF.printSchema()
    dfwritetohive(PlanOfCareDF, spark, PlanOfCarePath)
  }
}
