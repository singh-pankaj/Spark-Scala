package processing

import org.apache.spark.sql.functions.{coalesce, lit}
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessEthnicity(spark: SparkSession) {

  import spark.implicits._

  def EthnicityObj(Patient: DataFrame, Individual: DataFrame, IndividualEthnicity: DataFrame, MasterEthnicity: DataFrame) = {

    val ethnicityPath = prop.getProperty("PatientEthnicityPath")

    val EthnicityDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(IndividualEthnicity.as("IR"), $"IR.Individualuid" === $"ID.Individualuid", "inner")
      .join(MasterEthnicity.as("MR"), $"MR.EthnicityUid" === $"IR.EthnicityUid", "left")
      .select($"PT.PatientID", $"PT.PatientUid", $"ID.PracticeUid", $"MR.ExternalID".as("patientethnicitycode"), $"MR.Description", $"PracticeEthnicityText")
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("patientethnicitykey", lit(null).cast("string"))
      .withColumn("masterpatientethnicitycode", lit(null).cast("string"))
      .withColumn("masterpatientethnicitytext", lit(null).cast("string"))
      .withColumn("PatientEthnicityText", coalesce($"MR.Description", $"PracticeEthnicityText"))
      .drop("IR.PracticeEthnicityText", "MR.description")
      .limit(500)
    // .select(schema.head, schema.tail: _*)
    //.drop("columnName")

    dfwritetohive(EthnicityDF, spark, ethnicityPath)


  }

}

