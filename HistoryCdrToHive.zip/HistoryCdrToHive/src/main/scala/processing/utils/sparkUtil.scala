package processing.utils

import org.apache.spark.sql.SparkSession
import processing.commons.ApplicationConfig.prop

class sparkUtil {
  var num_executors: String = prop.getProperty("num_executors")
  var executor_cores: String = prop.getProperty("executor_cores")
  var executor_memory: String = prop.getProperty("executor_memory")
  var sparkMasterUrl: String = prop.getProperty("spark_master_url")
  var mode: String = prop.getProperty("mode")
  var awsAccessKeyId: String = prop.getProperty("awsAccessKeyId")
  var awsSecretAccessKey: String = prop.getProperty("awsSecretAccessKey")
  var hiveLocation: String = prop.getProperty("warehouse")

  def getSparkSession(): SparkSession = {

    val spark: SparkSession = SparkSession.builder.master(sparkMasterUrl).appName("HistoryToCDR")
      .config("spark.sql.crossJoin.enabled","true")
      .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .config("spark.speculation", "false")
      .config("spark.sql.warehouse.dir", hiveLocation)
      .config("executor-memory", executor_memory)
      .config("spark.submit.deployMode", mode)
      .config("executor-cores", executor_cores)
      .config("num-executors", num_executors)
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .config("fs.s3n.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem")
      //.config("hive.metastore.uris", "thrift://10.20.201.191:9083")
      .config("hive.metastore.uris", "thrift://10.20.201.80:9083")
      .config("fs.s3n.awsAccessKeyId", awsAccessKeyId)
      .config("fs.s3n.awsSecretAccessKey", awsSecretAccessKey)
      .config("spark.yarn.maxAppAttempts", "1")
      .enableHiveSupport()
      .getOrCreate()

    spark
  }

}
