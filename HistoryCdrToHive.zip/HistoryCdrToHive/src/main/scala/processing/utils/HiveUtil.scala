package processing.utils

import java.util.Calendar

import org.apache.spark.sql.{DataFrame, SparkSession}

object HiveUtil {

  def dfwritetohive(df: DataFrame, spark: SparkSession, s3Path: String): Unit = {


    println(s"start time for data write into path.. $s3Path.. " + Calendar.getInstance.getTime)

    df.coalesce(3).write.mode(saveMode = "overwrite").option("header", "true").parquet(s3Path)
    //.saveAsTable(TableName)
    println("End time for data write into s3Path.. " + Calendar.getInstance.getTime)


  }

}
