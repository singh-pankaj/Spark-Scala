package processing

import org.apache.spark.sql.functions.{coalesce, lit}
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessPatientAllergy(spark: SparkSession) {

  import spark.implicits._

  def PatientAllergyObj(Patient: DataFrame, Individual: DataFrame, PatientAllergy: DataFrame, MasterAllergy: DataFrame, Master: DataFrame) {

    val PatientAllergyPath = prop.getProperty("PatientAllergyPath")

    val PatientAllergyDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientAllergy.as("PA"), $"IR.Individualuid" === $"PT.PatientUid", "inner")
      .join(MasterAllergy.as("MA"), $"MA.AllergyUid" === $"PA.AllergyUid", "left")
      .join(Master.as("MS"), $"MS.MasterUid" === $"PA.MasterAllergyStatusUid", "left")
      .select($"PT.PatientID", $"PA.allergytypecode", $"PA.allergyeventtype", $"PA.allergyreaction", $"PT.PatientUid", $"ID.PracticeUid"
        , $"PA.DateFirstEncountered".as("effectivestartdate"), $"PA.DateOfResolution".as("effectiveenddate"), $"MS.Code".as("allergystatuscode")
        , $"MS.Name".as("allergystatustext"), $"PA.Description", $"MA.Description", $"PA.allergicto", $"MA.Code")
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("allergieskey", lit(null).cast("string"))
      .withColumn("masterallergictocode", lit(null).cast("string"))
      .withColumn("masterallergydescription", lit(null).cast("string"))
      .withColumn("masterallergystatuscode", lit(null).cast("string"))
      .withColumn("masterallergystatustext", lit(null).cast("string"))
      .withColumn("allergictocode", coalesce($"PA.allergicto", $"MA.Code"))
      .withColumn("allergictodescription", coalesce($"PA.Description", $"MA.Description"))
      // .select(schema.head, schema.tail: _*)
      .drop("PA.Description", "MA.Description")
      .drop("PA.allergicto", "MA.Code")
      .limit(500)
    //.withColumn("allergictocode", coalesce($"PA.allergicto",$"MA.Code"))

    dfwritetohive(PatientAllergyDF, spark, PatientAllergyPath)
  }
}
