package processing

import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessPatientLanguage(spark: SparkSession) {

  def PatientLanguageObj(Patient: DataFrame, Individual: DataFrame, PatientLanguage: DataFrame, Master: DataFrame) {

    import spark.implicits._
    val PatientLanguagePath = prop.getProperty("PatientLanguagePath")

    val PatientLanguageDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientLanguage.as("PL"), $"PL.PatientUid" === $"PT.PatientUid", "inner")
      .join(Master.filter($"TYPE" === "Language").as("M"), $"M.MasterUid" === $"PL.MasterLanguageUid", "left")
      .join(Master.as("M1"), $"M.MasterUid" === $"PL.MasterLangAbilityModeUid", "left")
      .join(Master.as("M2"), $"M.MasterUid" === $"PL.MasterLangProficiencyLevelUid", "left")
      .select($"PT.PatientID", $"M.Code".as("LanguageCode"), $"M.Name".as("LanguageText"), $"M1.Code".as("langaugeabilitymodecode"), $"M1.Name".as("langaugeabilitymodetext"),
        $"M2.Code".as("languageproficiencylevelcode"), $"M2.Name".as("languageproficiencyleveltext"), $"PL.preferenceind", $"PT.PatientUid", $"ID.PracticeUid")
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("patientlanguagekey", lit(null).cast("string"))
      //     .select(schema.head, schema.tail: _*)
      //.drop("columnName")
      //.withColumn("PatientUid", coalesce($"",$""))
      .limit(500)
    dfwritetohive(PatientLanguageDF, spark, PatientLanguagePath)

  }
}

/*
select PT.patientid,M.code  languagecode,M.Name languagetext,M1.Code as langaugeabilitymodecode,M1.Name as langaugeabilitymodetext,M2.Code as languageproficiencylevelcode,M2.Name as languageproficiencyleveltext,PL.preferenceind,
PL.patientlanguagekey,NULL as batchuid,PT.patientuid,ID.practiceuid
from PatientLanguage PL
inner join Patient PT  on PL.PatientUid=PT.PatientUid
inner join Individual ID  on ID.IndividualUid=PT.PatientUid
left join Master M on M.MasterUid=PL.MasterLanguageUid AND M.TYPE='Language'
left join Master M1 on M1.MasterUid=PL.MasterLangAbilityModeUid
left join master M2 on M2.MasterUid=PL.MasterLangProficiencyLevelUid
*/