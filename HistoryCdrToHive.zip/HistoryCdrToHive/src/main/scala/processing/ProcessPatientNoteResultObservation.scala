package processing

import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessPatientNoteResultObservation(spark: SparkSession) {

  import spark.implicits._

  def PatientNoteResultObservationObj(Patient: DataFrame, Individual: DataFrame, PatientNoteResultObservation: DataFrame, ServiceProvider: DataFrame, ServiceLocation: DataFrame, Institution: DataFrame, ClinicalInformationModelSection: DataFrame) {

    val PatientNoteResultObservationPath = prop.getProperty("PatientNoteResultObservationPath")

    val PatientNoteResultObservationDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientNoteResultObservation.as("PN"), $"PN.PatientUid" === $"PT.PatientUid", "inner")
      .join(ClinicalInformationModelSection.as("MPC"), $"MPC.ClinicalInformationModelSectionUid" === $"PN.ClinicalInformationModelSectionUid", "inner")
      .join(ServiceProvider.as("SP"), $"SP.ServiceProviderUid" === $"PN.ServiceProviderUid", "left")
      .join(Individual.as("ID1"), $"SP.ServiceProviderUid" === $"ID1.Individualuid", "left")
      .join(ServiceLocation.as("SL"), $"SL.ServiceLocationUid" === $"PN.ServiceLocationUid", "left")
      .join(Institution.as("IT"), $"IT.InstitutionUid" === $"PN.ServiceLocationUid", "left")
      .select($"PT.PatientID", $"PN.ReferenceDate", $"MPC.Name".as("sectionname"), $"PN.note", $"SP.NPI".as("serviceprovidernpi"), $"ID1.first".as("serviceproviderfirstname")
        , $"ID1.last".as("serviceproviderlastname"), $"SL.ExternalID".as("servicelocationid"), $"IT.Name".as("servicelocationname")
        , $"PN.group1", $"PN.group2", $"PN.group3", $"PN.group4", $"PN.practicepatientnotekey", $"Practiceuid", $"PatientUid")
      .withColumn("batchuid", lit(null).cast("string"))
      //.select(schema.head, schema.tail: _*)
      //.drop("columnName")
      //.withColumn("PatientUid", coalesce($"",$""))
      .limit(500)
    dfwritetohive(PatientNoteResultObservationDF, spark, PatientNoteResultObservationPath)


  }

}