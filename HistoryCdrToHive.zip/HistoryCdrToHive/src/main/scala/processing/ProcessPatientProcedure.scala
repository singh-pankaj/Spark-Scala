package processing

import org.apache.spark.sql.functions.{coalesce, lit}
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessPatientProcedure(spark: SparkSession) {

  def PatientProcedureObj(Patient: DataFrame, Individual: DataFrame, PatientProcedure: DataFrame, MasterCode: DataFrame, Master: DataFrame, ServiceProvider: DataFrame, ServiceLocation: DataFrame, Institution: DataFrame) {

    import spark.implicits._
    val PatientProcedurePath = prop.getProperty("PatientProcedurePath")


    val PatientProcedureDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientProcedure.as("PP"), $"PP.PatientUid" === $"PT.PatientUid", "inner")
      .join(ServiceProvider.as("SP"), $"SP.ServiceProviderUid" === $"PP.ServiceProviderUid", "left")
      .join(Individual.as("ID1"), $"ID1.IndividualUid" === $"SP.ServiceProviderUid", "left")
      .join(ServiceLocation.as("SL"), $"SL.ServiceLocationUid" === $"PP.ServiceLocationUid", "left")
      .join(Institution.as("IT"), $"IT.InstitutionUid" === $"Sl.ServiceLocationUid", "left")
      .join(Master.filter($"Type" === "TargetSite").as("MC"), $"MC.MasterUid" === $"PP.MasterTargetSiteUid", "left")
      .join(MasterCode.as("MS"), $"MS.CodeUid" === $"PP.ProcedureCodeUid", "left")
      .join(Master.filter($"Type" === "ProcedureStatus").as("MC1"), $"MC1.MasterUid" === $"PP.MasterProcedureStatusUid", "left")
      .select($"PT.PatientID", $"PP.negationind", $"PP.procedurecomment", $"PP.modifier1", $"PP.modifier2", $"PP.modifier3", $"PP.modifier4", $"PP.insurance",
        $"PT.PatientUid", $"ID.PracticeUid", $"PP.EffectiveDate".as("proceduredate"), $"MC.Code".as("targetsitecode"), $"MC.Name".as("targetsitetext")
        , $"SP.NPI".as("serviceprovidernpi"), $"ID1.Last".as("serviceproviderlastname"), $"ID1.First".as("serviceproviderfirstname"), $"SL.ExternalID".as("servicelocationid")
        , $"IT.Name".as("servicelocationname"), $"MC1.Code".as("procedurestatuscode"), $"MC1.Name".as("procedurestatustext"), $"PP.PracticeCode", $"MC.Code", $"PP.PracticeDescription", $"MC.Description"
        , $"PP.EffectiveDate".as("proceduredate"), $"MC.Code".as("targetsitecode"))
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("procedureskey", lit(null).cast("string"))
      .withColumn("masterprocedurecode", lit(null).cast("string"))
      .withColumn("masterproceduretext", lit(null).cast("string"))
      .withColumn("masterprocedurestatuscode", lit(null).cast("string"))
      .withColumn("masterprocedurestatustext", lit(null).cast("string"))
      .withColumn("mastertargetsitecode", lit(null).cast("string"))
      .withColumn("mastertargetsitetext", lit(null).cast("string"))
      .withColumn("procedurecode", coalesce($"PP.PracticeCode", $"MC.Code"))
      .withColumn("proceduretext", coalesce($"PP.PracticeDescription", $"MC.Description"))
      .drop("PracticeDescription", "Description", "PracticeCode", "Code")
      .limit(500)
    //  .select(schema.head, schema.tail: _*)


    //.withColumn("PatientUid", coalesce($"",$""))

    dfwritetohive(PatientProcedureDF, spark, PatientProcedurePath)


  }

}
