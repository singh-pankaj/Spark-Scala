package processing

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessPatientAdvanceDirectiveObservation(spark: SparkSession) {

  import spark.implicits._

  def PatientAdvanceDirectiveObservationObj(Patient: DataFrame, Individual: DataFrame, PatientAdvanceDirectiveObservation: DataFrame, Master: DataFrame) {

    val PatientAdvanceDirectiveObservationPath = prop.getProperty("PatientAdvanceDirectiveObservationPath")

    val PatientAdvanceDirectiveObservationDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientAdvanceDirectiveObservation.as("PA"), $"PA.PatientUid" === $"PT.PatientUid", "inner")
      .join(Master.as("MS"), $"PA.MasterAdvanceDirectiveTypeUid" === $"MS.MasterUid", "left")
      .join(Master.as("MS1"), $"PA.MasterAdvanceDirectiveStatusUid" === $"MS1.MasterUid", "left")
      .select($"PT.PatientID", $"MS.Code".as("advancedirectivetypecode"), $"PA.advancedirectivetypedetails",
        $"MS1.Code".as("advancedirectivestatuscode"), $"MS1.Name".as("advancedirectivestatustext"),
        $"PA.agentname", $"PA.groupname", $"PA.advancedirectivetypetext", $"PA.EffectiveDate".as("effectivestartdate")
        , $"PA.EffectiveDateTo".as("effectiveenddate"), $"Practiceuid", $"PT.PatientUid")
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("PatientAdvanceDirectiveObservationKey", lit(null).cast("string"))
      .withColumn("externaldocumentlink", lit(null).cast("string"))
      .withColumn("masteradvancedirectivetypecode", lit(null).cast("string"))
      .withColumn("masteradvancedirectivetypedetails", lit(null).cast("string"))
      .withColumn("masteradvancedirectivestatuscode", lit(null).cast("string"))
      .withColumn("masteradvancedirectivestatustext", lit(null).cast("string"))
      .limit(500)
    //    .select(schema.head, schema.tail: _*)
    //.drop("columnName")
    //.withColumn("PatientUid", coalesce($"",$""))

    dfwritetohive(PatientAdvanceDirectiveObservationDF, spark, PatientAdvanceDirectiveObservationPath)

  }

}
