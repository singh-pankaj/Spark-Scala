package processing

import org.apache.spark.sql.functions.{coalesce, lit}
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive


class ProcessPatientLabOrder(spark: SparkSession) {

  import spark.implicits._

  def PatientLabOrderObj(Patient: DataFrame, Individual: DataFrame, Master: DataFrame, ServiceProvider: DataFrame, PatientLabOrder: DataFrame, MasterCode: DataFrame) {

    val PatientLabOrderPath = prop.getProperty("PatientLabOrderPath")

    val PatientLabOrderDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientLabOrder.as("PF"), $"PF.PatientUid" === $"PT.PatientUid", "inner")
      .join(ServiceProvider.as("SP"), $"SP.ServiceProviderUid" === $"PF.ServiceProvider", "left")
      .join(Individual.as("ID1"), $"ID1.Individualuid" === $"SP.SP.serviceprovideruid", "left")
      .join(Master.as("MC"), $"MC.MasterUid" === $"PF.MasterTargetSiteUid", "left")
      .join(Master.filter($"Type" === "TargetSite").as("MS"), $"MS.MasterUid" === $"PF.MasterResultInterpretationUid", "left")
      .join(MasterCode.as("MPC"), $"mpc.CodeUid" === $"PF.OrderCodeUid", "left")
      .select($"PT.PatientID", $"PT.PatientUid", $"ID.PracticeUid", $"PF.OrderDate", $"PF.SpecimenID", $"PF.LaboratoryID", $"PF.Practicecode", $"mpc.code"
        , $"PF.Description".as("OrderName")
        , $"MPC.CodeSystem".as("OrderCategory")
        , $"MC.Code".as("TargetSiteCode")
        , $"MC.Name".as("TargetSiteText")
        , $"SP.NPI".as("OrderCategory")
        , $"ID1.Last".as("TargetSiteCode")
        , $"ID1.First".as("TargetSiteText")
        , $"PF.RangeFrom".as("ReferenceLowerRange")
        , $"PF.RangeTo".as("ReferenceHigherRange")
        , $"ms.code".as("MethodCode")
        , $"ms.Name".as("MethodText"))
      .withColumn("OrderCode", coalesce($"PF.Practicecode", $"mpc.code"))
      .withColumn("OrderStatus", lit(null).cast("string"))
      .withColumn("LaboratoryName", lit(null).cast("string"))
      .withColumn("PatientLabOrderKey", lit(null).cast("string"))
      .withColumn("batchuid", lit(null).cast("string"))
      .drop("Practicecode", "code")
      .limit(500)
    // .select(schema.head, schema.tail: _*)

    PatientLabOrderDF.show()

    dfwritetohive(PatientLabOrderDF, spark, PatientLabOrderPath)

  }

}
