package processing

import org.apache.spark.sql.functions.{coalesce, lit, split}
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessVitalSignObservation(spark: SparkSession) {

  import spark.implicits._

  def PatientVitalSignObservationObj(Patient: DataFrame, Individual: DataFrame, PatientVitalSignObservation: DataFrame, ServiceProvider: DataFrame, MasterCode: DataFrame, Master: DataFrame) {

    val PatientVitalSignObservationPath = prop.getProperty("PatientVitalSignObservationPath")

    val PatientVitalSignObservationDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientVitalSignObservation.as("PR"), $"PR.PatientUid" === $"PT.PatientUid", "inner")
      .join(Master.filter($"Type" === "ResultInterpretation").as("MPC"), $"MPC.MasterUid" === $"PR.MasterResultInterpretationUid", "left")
      .join(Master.filter($"Type" === "TargetSite").as("MPC1"), $"MPC1.MasterUid" === $"PR.MasterTargetSiteUid", "left")
      .join(Master.as("MPC2"), $"MPC2.MasterUid" === $"PR.MasterResultInterpretationUid", "left")
      .join(MasterCode.as("MC1"), $"MC1.CodeUid" === $"PR.ProcedureUid", "left")
      .join(MasterCode.as("MC2"), $"MC2.CodeUid" === $"PR.ObservationCodeUid", "left")
      .select($"PT.PatientID", $"PR.CodeSystem".as("observationcategory"), $"PR.ResultDate".as("observationdate")
        , $"PR.ResultValue".as("observationvalue"), $"MPC1.Code".as("targetsitecode"), $"MPC1.Name".as("targetsitetext")
        , $"PR.negationind", $"PP.PracticeCode", $"MC1.Code", $"MC1.Name", $"PP.Description"
        , $"PR.resultobservationstatus", $"PR.resultorderdescription", $"PR.resultorderdate", $"PR.laboratoryid", $"PR.laboratoryname", $"PR.resultordercode", $"PR.obssubid"
        , $"PR.Unit".as("resultobsunit"), $"ID.Practiceuid", $"PT.PatientUid"
      )
      .withColumn("observationcode", coalesce($"PP.PracticeCode", $"MC1.Code"))
      .withColumn("observationname", coalesce($"PP.Description", $"MC1.name"))
      .withColumn("Range", split($"ReferenceObservationRange", "-")).select($"Range".getItem(0).as("referencelowerrange"), $"Range".getItem(1).as("referenceupperrange"))
      .withColumn("obsinterpretationcode", lit(null).cast("string"))
      .withColumn("obsinterpretationtext", lit(null).cast("string"))
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("PatientVitalSignObservationKey", lit(null).cast("string"))
      .withColumn("methodcode", lit(null).cast("string"))
      .withColumn("methodcodetext", lit(null).cast("string"))
      .withColumn("procedurecode", lit(null).cast("string"))
      .withColumn("proceduretext", lit(null).cast("string"))
      .drop("PracticeCode", "Code", "Name", "Description")
      .limit(500)
    //.select(schema.head, schema.tail: _*)
    dfwritetohive(PatientVitalSignObservationDF, spark, PatientVitalSignObservationPath)

  }

}
