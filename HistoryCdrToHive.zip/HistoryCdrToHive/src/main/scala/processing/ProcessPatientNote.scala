package processing

import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessPatientNote(spark: SparkSession) {

  def PatientNoteObj(Patient: DataFrame, Individual: DataFrame, PatientNote: DataFrame, ServiceProvider: DataFrame, ServiceLocation: DataFrame, Institution: DataFrame, ClinicalInformationModelSection: DataFrame) {

    import spark.implicits._
    val PatientNotePath = prop.getProperty("PatientNotePath")


    val PatientNoteDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientNote.as("PN"), $"PN.PatientUid" === $"PT.PatientUid", "inner")
      .join(ClinicalInformationModelSection.as("MPC"), $"MPC.ClinicalInformationModelSectionUid" === $"PN.ClinicalInformationModelSectionUid", "inner")
      .join(ServiceProvider.as("SP"), $"SP.ServiceProviderUid" === $"PN.ServiceProviderUid", "left")
      .join(Individual.as("ID1"), $"SP.ServiceProviderUid" === $"ID1.Individualuid", "left")
      .join(ServiceLocation.as("SL"), $"SL.ServiceLocationUid" === $"PN.ServiceLocationUid", "left")
      .join(Institution.as("IT"), $"IT.InstitutionUid" === $"PN.ServiceLocationUid", "left")
      .select($"PT.PatientID", $"PN.ReferenceDate", $"MPC.Name".as("sectionname"), $"PN.note", $"SP.NPI".as("serviceprovidernpi"), $"ID1.first".as("serviceproviderfirstname")
        , $"ID1.last".as("serviceproviderlastname"), $"SL.ExternalID".as("servicelocationid"), $"IT.Name".as("servicelocationname")
        , $"PN.group1", $"PN.group2", $"PN.group3", $"PN.group4", $"PN.practicepatientnotekey", $"Practiceuid", $"PatientUid")
      .withColumn("batchuid", lit(null).cast("string"))
      // .select(schema.head, schema.tail: _*)
      //.drop("columnName")
      //.withColumn("PatientUid", coalesce($"",$""))
      .limit(500)
    dfwritetohive(PatientNoteDF, spark, PatientNotePath)

  }

}


/*
select distinct PT.patientid,PN.ReferenceDate as referenceddate,MPC.Name as sectionname,PN.note,SP.NPI as serviceprovidernpi,ID1.Last as serviceproviderlastname,ID1.First as serviceproviderfirstname,SL.ExternalID as servicelocationid,IT.Name as servicelocationname,
PN.group1,PN.group2,PN.group3,PN.group4,PN.practicepatientnotekey,NULL as batchuid,PT.patientuid,ID.practiceuid
from PatientNote PN with(nolock)
inner join Patient PT with(nolock) on PN.PatientUid=PT.PatientUid
inner join Individual ID with(nolock) on ID.IndividualUid=PT.PatientUid
left join ServiceProvider SP with(nolock) on SP.ServiceProviderUid=PN.ServiceProviderUid
left join Individual ID1 with(nolock) on ID1.IndividualUid=SP.ServiceProviderUid
left join ServiceLocation SL with(nolock) on SL.ServiceLocationUid=PN.ServiceLocationUid
left join Institution IT with(nolock) on IT.InstitutionUid=SL.ServiceLocationUid
inner join ClinicalInformationModelSection MPC with(nolock) on MPC.ClinicalInformationModelSectionUid=PN.ClinicalInformationModelSectionUid

 */