package processing.commons

import java.util.Properties

object ApplicationConfig {
  var prop = new Properties

  def setApplicationConfig(args: Array[String]): Unit = {

    prop.setProperty("awsAccessKeyId", "AKIALH6XLTJCI6I3N5RQ")
    prop.setProperty("awsSecretAccessKey", "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")
    prop.setProperty("postgresHostName", "10.20.201.36")
    prop.setProperty("warehouse", "/user/hive/warehouse")
    prop.setProperty("postgresHostPort", "5432")
    prop.setProperty("postgresManagementDatabaseName", "figmdhqimanagementaao")
    prop.setProperty("postgresHostUserName", "postgres")
    prop.setProperty("postgresUserPass", "Janus@123")
    prop.setProperty("num_executors", "10")
    prop.setProperty("executor_cores", "5")
    prop.setProperty("executor_memory", "7G")
    prop.setProperty("spark_master_url", "yarn")
    prop.setProperty("mode", "cluster")

    //set important properties

    prop.setProperty("DataLakeDB", "aao_main_temp")
    prop.setProperty("insertPath", "s3://bd-dev/hiveHistoryData/aaocdrhistorydata")
    prop.setProperty("hiveDBName", "aaocdrhistorydata")
    prop.setProperty("MasterTableDB", "figmdhqimanagement")

    //get important properties

    val DataLakeDB = prop.getProperty("DataLakeDB")
    val HiveDB = prop.getProperty("hiveDBName")
    val insertPath = prop.getProperty("insertPath")
    val MasterTableDB = prop.getProperty("MasterTableDB")

    //set usable properties


    //hive table Name
    prop.setProperty("PatientTable", s"$HiveDB.Patient")
    prop.setProperty("PatientEthnicityTable", s"$HiveDB.PatientEthnicity")
    prop.setProperty("PatientRaceTable", s"$HiveDB.PatientRace")
    prop.setProperty("VisitTable", s"$HiveDB.Visit")
    prop.setProperty("PatientProblemTable", s"$HiveDB.PatientProblem")
    prop.setProperty("PatientProceduresTable", s"$HiveDB.PatientProcedure")
    prop.setProperty("PatientAdvanceDirectiveTable", s"$HiveDB.PatientAdvanceDirective")
    prop.setProperty("PatientAllergiesTable", s"$HiveDB.PatientAllergies")
    prop.setProperty("PatientMedicationsTable", s"$HiveDB.PatientMedication")
    prop.setProperty("PatientPlanOfCareTable", s"$HiveDB.PatientPlanOfCare")
    prop.setProperty("PatientResultObservationTable", s"$HiveDB.PatientResultObservation")
    prop.setProperty("PatientSocialHistoryObservationTable", s"$HiveDB.PatientSocialHistoryObservation")
    prop.setProperty("PatientVitalSignsTable", s"$HiveDB.PatientVitalSigns")
    prop.setProperty("PatientFamilyHistoryTable", s"$HiveDB.PatientFamilyHistory")
    prop.setProperty("PatientLanguageTable", s"$HiveDB.PatientLanguage")
    prop.setProperty("PatientNoteTable", s"$HiveDB.PatientNote")
    prop.setProperty("PatientNoteResultObservationTable", s"$HiveDB.PatientNoteResultObservation")
    prop.setProperty("PatientNoteVitalObservationTable", s"$HiveDB.PatientNoteVitalObservation")
    prop.setProperty("PatientNoteProcedureTable", s"$HiveDB.PatientNoteProcedure")
    prop.setProperty("PatientNoteProblemTable", s"$HiveDB.PatientNoteProblem")
    prop.setProperty("PatientNoteMedicationTable", s"$HiveDB.PatientNoteMedication")
    prop.setProperty("PatientInsuranceTable", s"$HiveDB.PatientInsuranceInfo")

    //hive table Path
    prop.setProperty("PatientPath", s"$insertPath/Patient/")
    prop.setProperty("PatientEthnicityPath", s"$insertPath/PatientEthnicity/")
    prop.setProperty("PatientRacePath", s"$insertPath/PatientRace/")
    prop.setProperty("VisitPath", s"$insertPath/Visit/")
    prop.setProperty("PatientProblemPath", s"$insertPath/PatientProblem/")
    prop.setProperty("PatientProceduresPath", s"$insertPath/PatientProcedure/")
    prop.setProperty("PatientAdvanceDirectivePath", s"$insertPath/PatientAdvanceDirective/")
    prop.setProperty("PatientAllergiesPath", s"$insertPath/PatientAllergies/")
    prop.setProperty("PatientMedicationsPath", s"$insertPath/PatientMedication/")
    prop.setProperty("PatientPlanOfCarePath", s"$insertPath/PatientPlanOfCare/")
    prop.setProperty("PatientResultObservationPath", s"$insertPath/PatientResultObservation/")
    prop.setProperty("PatientSocialHistoryObservationPath", s"$insertPath/PatientSocialHistoryObservation/")
    prop.setProperty("PatientVitalSignsPath", s"$insertPath/PatientVitalSigns/")
    prop.setProperty("PatientFamilyHistoryPath", s"$insertPath/PatientFamilyHistory/")
    prop.setProperty("PatientLanguagePath", s"$insertPath/PatientLanguage/")
    prop.setProperty("PatientNotePath", s"$insertPath/PatientNote/")
    prop.setProperty("PatientNoteResultObservationPath", s"$insertPath/PatientNoteResultObservation/")
    prop.setProperty("PatientNoteVitalObservationPath", s"$insertPath/PatientNoteVitalObservation/")
    prop.setProperty("PatientNoteProcedurePath", s"$insertPath/PatientNoteProcedure/")
    prop.setProperty("PatientNoteProblemPath", s"$insertPath/PatientNoteProblem/")
    prop.setProperty("PatientNoteMedicationPath", s"$insertPath/PatientNoteMedication/")
    prop.setProperty("PatientInsurancePath", s"$insertPath/PatientInsuranceInfo/")

    //DataLake table name
    prop.setProperty("datalakeVisit", s"$DataLakeDB.Visit")
    prop.setProperty("datalakeVisitDiagnosis", s"$DataLakeDB.VisitDiagnosis")
    prop.setProperty("datalakeIndividual", s"$DataLakeDB.Individual")
    prop.setProperty("datalakeIndividualEthnicity", s"$DataLakeDB.IndividualEthnicity")
    prop.setProperty("datalakeIndividualIdentifier", s"$DataLakeDB.IndividualIdentifier")
    prop.setProperty("datalakeIndividualRace", s"$DataLakeDB.IndividualRace")
    prop.setProperty("datalakePatient", s"$DataLakeDB.Patient")
    prop.setProperty("datalakePatientImmunization", s"$DataLakeDB.PatientImmunization")
    prop.setProperty("datalakePatientAdvanceDirectiveObservation", s"$DataLakeDB.PatientAdvanceDirectiveObservation")
    prop.setProperty("datalakePatientAllergy", s"$DataLakeDB.PatientAllergy")
    prop.setProperty("datalakePatientFamilyHistory", s"$DataLakeDB.PatientFamilyHistory")
    prop.setProperty("datalakePatientInsuranceInfo", s"$DataLakeDB.PatientInsuranceInfo")
    prop.setProperty("datalakePatientLanguage", s"$DataLakeDB.PatientLanguage")
    prop.setProperty("datalakePatientNote", s"$DataLakeDB.PatientNote")
    prop.setProperty("datalakePatientPlanOfCare", s"$DataLakeDB.PatientPlanOfCare")
    prop.setProperty("datalakePatientPregnancyObservation", s"$DataLakeDB.PatientPregnancyObservation")
    prop.setProperty("datalakePatientProblem", s"$DataLakeDB.PatientProblem")
    prop.setProperty("datalakePatientProblemHistory", s"$DataLakeDB.PatientProblemHistory")
    prop.setProperty("datalakePatientProcedure", s"$DataLakeDB.PatientProcedure")
    prop.setProperty("datalakePatientVitalSignObservation", s"$DataLakeDB.PatientVitalSignObservation")
    prop.setProperty("datalakePatientNoteResultObservation", s"$DataLakeDB.PatientNoteResultObservation")
    prop.setProperty("datalakePatientNoteVitalObservation", s"$DataLakeDB.PatientNoteVitalObservation")
    prop.setProperty("datalakePatientNoteProcedure", s"$DataLakeDB.PatientNoteProcedure")
    prop.setProperty("datalakePatientNoteProblem", s"$DataLakeDB.PatientNoteProblem")
    prop.setProperty("datalakePatientNoteMedication", s"$DataLakeDB.PatientNoteMedication")
    prop.setProperty("datalakepatientresultobservation", s"$DataLakeDB.patientresultobservation")
    prop.setProperty("datalakePatientMedication", s"$DataLakeDB.PatientMedication")
    prop.setProperty("datalakePatientSocialHistoryObservation", s"$DataLakeDB.PatientSocialHistoryObservation")
    prop.setProperty("datalakePatientLabOrder", s"$DataLakeDB.PatientLabOrder")
    prop.setProperty("datalakePatientFamilyHistory", s"$DataLakeDB.PatientFamilyHistory")
    prop.setProperty("datalakePatientGuardian", s"$DataLakeDB.PatientGuardian")

    //Master table

    /*
        prop.setProperty("Allergy", "mappingpracticeallergy")
        prop.setProperty("Procedure", "mappingpracticeprocedure")
        prop.setProperty("PracticeCommonData", "mappingpracticecommondatamaster")
        prop.setProperty("Ethinicity", "mappingpracticecommondatamasterethnicity")
        prop.setProperty("Race", "mappingpracticecommondatamasterrace")
        prop.setProperty("Insurance", "mappingpracticeinsurancedata")
        prop.setProperty("Problem", "MappingPracticeProblem")
        prop.setProperty("Medication", "MappingPracticeMedication")
        prop.setProperty("Route", "MappingPracticeCommonDataMasterMedicationRoute")
        prop.setProperty("RelationShip", "MappingPracticeCommonDataMasterMedicationRoute")
    */
  }
}
