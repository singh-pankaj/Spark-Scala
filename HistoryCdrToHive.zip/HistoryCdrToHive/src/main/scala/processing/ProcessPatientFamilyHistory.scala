package processing

import org.apache.spark.sql.functions.{coalesce, lit}
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessPatientFamilyHistory(spark: SparkSession) {

  import spark.implicits._

  def PatientFamilyHistoryObj(Patient: DataFrame, Individual: DataFrame, PatientFamilyHistory: DataFrame, MasterRelationship: DataFrame, Master: DataFrame, MasterCode: DataFrame) {

    val PatientFamilyHistoryPath = prop.getProperty("PatientFamilyHistoryPath")

    val PatientFamilyHistoryDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientFamilyHistory.as("PA"), $"PA.PatientUid" === $"PT.PatientUid", "inner")
      .join(MasterRelationship.as("MR"), $"MR.RelationshipUid" === $"PA.PatientRelationshipToFamilyMemberUid", "left")
      .join(MasterCode.as("MS"), $"Ms.CodeUid" === $"PA.ProblemCodeUid", "left")
      .join(Master.as("M"), $"M.MasterUid" === $"PA.MasterProblemTypeUid", "left")
      .select($"PT.PatientID", $"PT.PatientUid", $"ID.PracticeUid", $"PA.ObservationDate".as("EffectiveDate")
        , $"M.Code".as("ProblemTypeCode"), $"M.Name".as("ProblemTypeText"), $"PA.FamilyMemberAge", $"PA.ProblemDescription", $"MS.Description", $"PA.Codesystem", $"PA.ProblemCode", $"MS.Code", $"MS.CodeSystem"
        , $"PA.IsAlive".as("IsFamilyMemberAlive"))
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("FamilyHistoryKey", lit(null).cast("string"))
      .withColumn("MasterRelationshipToPatientCode", lit(null).cast("string"))
      .withColumn("MasterRelationshipToPatientText", lit(null).cast("string"))
      .withColumn("MasterProblemTypeCode", lit(null).cast("string"))
      .withColumn("MasterProblemTypeText", lit(null).cast("string"))
      .withColumn("MasterProblemCode", lit(null).cast("string"))
      .withColumn("MasterProblemDescription", lit(null).cast("string"))
      .withColumn("ProblemCode", coalesce($"PA.ProblemCode", $"MS.Code"))
      .withColumn("ProblemDescription", coalesce($"PA.ProblemDescription", $"MS.Description"))
      .withColumn("ProblemCategory", coalesce($"PA.Codesystem", $"MS.CodeSystem"))
      //.select(schema.head, schema.tail: _*)
      .drop("ProblemDescription", "MS.Description", "PA.Codesystem", "MS.CodeSystem", "PA.ProblemCode", "MS.Code")
      //.withColumn("PatientUid", coalesce($"",$""))
      .limit(500)
    dfwritetohive(PatientFamilyHistoryDF, spark, PatientFamilyHistoryPath)
  }

}
