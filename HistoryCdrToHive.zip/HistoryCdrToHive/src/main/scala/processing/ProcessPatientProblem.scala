package processing

import org.apache.spark.sql.functions.{coalesce, lit}
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessPatientProblem(spark: SparkSession) {

  def PatientProblemObj(Patient: DataFrame, Individual: DataFrame, PatientProblem: DataFrame, PatientProblemHistory: DataFrame, MasterCode: DataFrame, Master: DataFrame) {

    import spark.implicits._
    val PatientProblemPath = prop.getProperty("PatientProblemPath")

    val PatientProblemDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientProblem.as("PP"), $"PP.PatientUid" === $"PT.PatientUid", "inner")
      .join(PatientProblemHistory.as("PPH"), $"PP.PatientProblemUid" === $"PPH.PatientProblemUid", "inner")
      .join(MasterCode.as("MC"), $"MC.CodeUid" === $"PP.CodeUid", "left")
      .join(Master.as("M1"), $"PPH.MasterProblemStatusUid" === $"M1.MasterUid", "left")
      .join(Master.as("M2"), $"PPH.MasterProblemHealthStatusUid" === $"M2.MasterUid", "left")
      .join(Master.as("M2"), $"PPH.MasterProblemTypeUid" === $"M3.MasterUid", "left")
      .select($"PT.PatientID", $"PPH.documentationdate", $"PT.PatientUid", $"ID.PracticeUid", $"pph.ResolutionDate".as("problemresolutiondate")
        , $"M3.Code".as("problemtypecode"), $"M3.Name".as("problemtypetext"), $"M1.Code".as("problemstatuscode"), $"M1.Name".as("problemstatustext")
        , $"M2.Code".as("problemhealthstatuscode"), $"M2.Name".as("problemhealthstatustext"), $"PP.Codesystem".as("problemcategory")
        , $"PP.negationind", $"PP.problemcomment", $"PPH.problemonsetdate", $" PPH.targetsitecode", $"PPH.targetsitetext")
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("problemkey", lit(null).cast("string"))
      .withColumn("masterproblemcode", lit(null).cast("string"))
      .withColumn("masterproblemtext", lit(null).cast("string"))
      .withColumn("masterproblemstatuscode", lit(null).cast("string"))
      .withColumn("masterproblemstatustext", lit(null).cast("string"))
      .withColumn("masterproblemhealthstatuscode", lit(null).cast("string"))
      .withColumn("masterproblemhealthstatustext", lit(null).cast("string"))
      .withColumn("mastertargetsitecode", lit(null).cast("string"))
      .withColumn("mastertargetsitetext", lit(null).cast("string"))
      .withColumn("problemcode", coalesce($"PP.PracticeCode", $"MC.Code"))
      .withColumn("problemtext", coalesce($"PP.PracticeDescription", $"MC.Description"))
      .limit(500)
    //.select(schema.head, schema.tail: _*)
    //.drop("columnName")


    dfwritetohive(PatientProblemDF, spark, PatientProblemPath)
    /*
    PatientProblem PP
    inner join PatientProblemHistory PPH on PP.PatientProblemUid=PPH.PatientProblemUid
    inner join Patient PT on PP.PatientUid=PT.PatientUid
    inner join Individual ID on ID.IndividualUid=PT.PatientUid
    left join MasterCode MC on MC.CodeUid=PP.CodeUid
    left join master M1 on PPH.MasterProblemStatusUid=M1.MasterUid
    left join master M2 on PPH.MasterProblemHealthStatusUid=M2.MasterUid
    left join master M3 on PPH.MasterProblemTypeUid=M3.MasterUid
     */

  }

}
