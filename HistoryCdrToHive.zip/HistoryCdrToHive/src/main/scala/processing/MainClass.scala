package processing

import org.apache.log4j.{Level, Logger}
import processing.commons.ApplicationConfig
import processing.utils.sparkUtil

//spar
object MainClass {

  def main(args: Array[String]): Unit = {


    ApplicationConfig.setApplicationConfig(args)


    val sparkUtility = new sparkUtil()
    val spark = sparkUtility.getSparkSession()
    val rt = new readTables(spark)

    Logger.getLogger("org").setLevel(Level.WARN)
    Logger.getLogger("akka").setLevel(Level.WARN)


/*
    val r = new ProcessRace(spark)
    r.raceObj(rt.PatientTable, rt.Individual, rt.IndividualRace, rt.MasterRace)

    // 1
    val planofcare = new PatientPlanOfCare(spark)
    planofcare.PlanOfCareObj(rt.PatientTable, rt.Individual, rt.PatientPlanOfCareTable, rt.Master)
    // 2
    val encounter = new ProcessEncounter(spark)
    encounter.EncounterObj(rt.Visit, rt.PatientTable, rt.ServiceProvider, rt.Individual, rt.ServiceLocation, rt.Institution, rt.Master, rt.Adderss, rt.MasterState, rt.MasterSpeciality)
    //3
    val ethnicity = new ProcessEthnicity(spark)
    ethnicity.EthnicityObj(rt.PatientTable, rt.Individual, rt.IndividualEthnicity, rt.MasterEthnicity)
    //4

    val insurance = new ProcessInsurance(spark)
    insurance.patientinsuranceObj(rt.PatientTable, rt.Individual, rt.PatientInsuranceInfoTable, rt.Master)
    //5
    val language = new ProcessPatientLanguage(spark)
    language.PatientLanguageObj(rt.PatientTable, rt.Individual, rt.PatientLanguageTable, rt.Master)
*/
    //6
    val resultobservation = new ProcessPatientResultObservation(spark)
    resultobservation.PatientResultObservationObj(rt.PatientTable, rt.Individual, rt.patientresultobservationTable, rt.ServiceProvider, rt.MasterCode, rt.Master)
    //7
    val vitalsignobservation = new ProcessVitalSignObservation(spark)
    vitalsignobservation.PatientVitalSignObservationObj(rt.PatientTable, rt.Individual, rt.PatientVitalSignObservationTable, rt.ServiceProvider, rt.MasterCode, rt.Master)
    //8
    val note = new ProcessPatientNote(spark)
    note.PatientNoteObj(rt.PatientTable, rt.Individual, rt.PatientNoteTable, rt.ServiceProvider, rt.ServiceLocation, rt.Institution, rt.ClinicalInformationModelSection)
    //9
    val problem = new ProcessPatientProblem(spark)
    problem.PatientProblemObj(rt.PatientTable, rt.Individual, rt.PatientProblemTable, rt.MasterCode, rt.Master, rt.PatientProblemHistoryTable)
    //10
    val procedure = new ProcessPatientProcedure(spark)
    procedure.PatientProcedureObj(rt.PatientTable, rt.Individual, rt.PatientProcedureTable, rt.MasterCode, rt.Master, rt.ServiceProvider, rt.ServiceLocation, rt.Institution)
    //11
    val socialhistoryobservation = new ProcessPatientSocialHistoryObservation(spark)
    socialhistoryobservation.PatientSocialHistoryObservationObj(rt.PatientTable, rt.Individual, rt.PatientSocialHistoryObservationTable, rt.Master)
    //12
    val advancedirectiveobservation = new ProcessPatientAdvanceDirectiveObservation(spark)
    advancedirectiveobservation.PatientAdvanceDirectiveObservationObj(rt.PatientTable, rt.Individual, rt.PatientAdvanceDirectiveObservationTable, rt.Master)
    //13
    val allergy = new ProcessPatientAllergy(spark)
    allergy.PatientAllergyObj(rt.PatientTable, rt.Individual, rt.PatientAllergyTable, rt.Master, rt.MasterAllergy)
    //14
    val familyhistory = new ProcessPatientFamilyHistory(spark)
    familyhistory.PatientFamilyHistoryObj(rt.PatientTable, rt.Individual, rt.PatientFamilyHistoryTable, rt.Master, rt.MasterRelationship, rt.MasterCode)
    //15
    val medication = new ProcessPatientMedication(spark)
    medication.PatientMedicationObj(rt.PatientTable, rt.Individual, rt.PatientMedicationTable, rt.Master, rt.MasterMedicationRoute, rt.MasterCode, rt.ServiceProvider)
    //16
    val demographics = new ProcessPatientDemographics(spark)
    demographics.PatientObj(rt.PatientTable, rt.Individual, rt.IndividualIdentifier, rt.Adderss, rt.MasterCity, rt.MasterState, rt.MasterCountry, rt.MasterPostalCode, rt.Phone, rt.MasterPhoneType, rt.MasterGender, rt.MasterMaritalStatus, rt.Master, rt.ServiceProvider)
    //17

    val guardian = new ProcessPatientGuardian(spark)
    guardian.PatientGuardianObj(rt.PatientTable, rt.Individual, rt.PatientGuardianTable, rt.Adderss, rt.MasterCity, rt.MasterState, rt.MasterCountry, rt.MasterPostalCode, rt.Phone, rt.MasterPhoneType, rt.MasterRelationship)
    //18
    val laborder = new ProcessPatientLabOrder(spark)
    laborder.PatientLabOrderObj(rt.PatientTable, rt.Individual, rt.PatientLabOrderTable, rt.ServiceProvider, rt.Master, rt.MasterCode)
    //19
    val notemedication = new ProcessPatientNoteMedication(spark)
    notemedication.PatientNoteMedicationObj(rt.PatientTable, rt.Individual, rt.PatientNoteMedicationTable, rt.ServiceProvider, rt.ServiceLocation, rt.Institution, rt.ClinicalInformationModelSection)
    //20
    val noteproblem = new ProcessPatientNoteProblem(spark)
    noteproblem.PatientNoteProblemObj(rt.PatientTable, rt.Individual, rt.PatientNoteProblemTable, rt.ServiceProvider, rt.ServiceLocation, rt.Institution, rt.ClinicalInformationModelSection)
    //21
    val noteProcedure = new ProcessPatientNoteProcedure(spark)
    noteProcedure.PatientNoteProcedureObj(rt.PatientTable, rt.Individual, rt.PatientNoteProcedureTable, rt.ServiceProvider, rt.ServiceLocation, rt.Institution, rt.ClinicalInformationModelSection)
    //22
    val noteResultObservation = new ProcessPatientNoteResultObservation(spark)
    noteResultObservation.PatientNoteResultObservationObj(rt.PatientTable, rt.Individual, rt.PatientNoteResultObservationTable, rt.ServiceProvider, rt.ServiceLocation, rt.Institution, rt.ClinicalInformationModelSection)
    //23
    val notevitalobservation = new ProcessPatientNoteVitalObservation(spark)
    notevitalobservation.PatientNoteVitalObservationObj(rt.PatientTable, rt.Individual, rt.PatientNoteVitalObservationTable, rt.ServiceProvider, rt.ServiceLocation, rt.Institution, rt.ClinicalInformationModelSection)


  }

}
