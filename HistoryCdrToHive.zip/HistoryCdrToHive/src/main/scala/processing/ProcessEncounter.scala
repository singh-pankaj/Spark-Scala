  package processing

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessEncounter(spark: SparkSession) {

  import spark.implicits._

  def EncounterObj(Visit: DataFrame, Patient: DataFrame, ServiceProvider: DataFrame, Individual: DataFrame, ServiceLocation: DataFrame, Institution: DataFrame, Master: DataFrame, Address: DataFrame, MasterState: DataFrame, MasterSpecialty: DataFrame) {

    val VisitPath = prop.getProperty("VisitPath")


    val VisitDF = Visit.as("VT")
      .join(Patient.as("PT"), $"PT.PatientUid" === $"VT.PatientUid", "inner")
      .join(ServiceProvider.as("SP"), $"SP.ServiceProviderUid" === $"VT.RenderringProviderUid", "left")
      .join(Individual.as("ID"), $"ID.IndividualUid" === $"SP.ServiceProviderUid", "left")
      .join(ServiceLocation.as("SL"), $"SL.ServiceLocationUid" === $"VT.ServiceLocationUid", "left")
      .join(Institution.as("IT"), $"IT.InstitutionUid" === $"SL.ServiceLocationUid", "left")
      .join(Master.filter($"Type" === "VisitType").as("M"), $"M.MasterUid" === $"VT.MasterVisitTypeUid", "left")
      .join(Address.as("A"), $"ID.IndividualUid" === $"SP.ServiceProviderUid", "left")
      .join(MasterState.as("MS"), $"ID.IndividualUid" === $"SP.ServiceProviderUid", "left")
      .join(MasterSpecialty.as("MSP"), $"ID.IndividualUid" === $"SP.ServiceProviderUid", "left")
      .select($"PT.PatientID", $"M.Code".as("encountertypecode"), $"M.Name".as("encountertypetext")
        , $"VT.StartDate".as("encounterstartdate"), $"VT.EndDate".as("encounterenddate"), $"SP.NPI".as("serviceprovidernpi")
        , $"ID.Last".as("serviceproviderlastname"), $"ID.First".as("serviceproviderfirstname")
        , $"MSP.Code".as("serviceproviderrolecode"), $"MSP.Description".as("serviceproviderroletext")
        , $"SL.ExternalID".as("servicelocationid"), $"IT.Name".as("servicelocationname")
        , $"VT.Note".as("reasonforvisit"), $"A.Line1".as("service_location_addressline")
        , $"A.City".as("service_location_city"), $"MS.Name".as("service_location_state")
        , $"A.PostalCode".as("service_location_postalcode")
        , $"VT.encounter_status", $"VT.encountertin", $"PT.patientuid", $"VT.visituid", $"VT.practiceuid")
      .withColumn("servicelocationroletypetext", lit(null).cast("string"))
      .withColumn("servicelocationroletypecode", lit(null).cast("string"))
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("encounterkey", lit(null).cast("string"))
      .limit(500)


    // .select(schema.head, schema.tail: _*)
    //.drop("columnName")
    //.withColumn("PatientUid", coalesce($"",$""))


    dfwritetohive(VisitDF, spark, VisitPath)
  }
}


