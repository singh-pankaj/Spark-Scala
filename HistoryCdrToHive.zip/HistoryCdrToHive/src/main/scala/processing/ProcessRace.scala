package processing

import org.apache.spark.sql.functions.{coalesce, lit}
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessRace(spark: SparkSession) {

  import spark.implicits._

  def raceObj(Patient: DataFrame, Individual: DataFrame, IndividualRace: DataFrame, MasterRace: DataFrame) {

    val racePath = prop.getProperty("PatientRacePath")

    val RaceDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(IndividualRace.as("IR"), $"IR.Individualuid" === $"ID.Individualuid", "inner")
      .join(MasterRace.as("MR"), $"MR.RaceUid" === $"IR.RaceUid", "left")

      .select($"PT.PatientID", $"IR.PracticeRaceText", $"MR.externalid".as("patientracecode"), $"PT.PatientUid", $"ID.PracticeUid", $"MR.description")
      .withColumn("PatientRaceText", coalesce($"IR.PracticeRaceText", $"MR.description"))
      .withColumn("masterpatientracetext", lit(null).cast("string"))
      .withColumn("masterpatientracecode", lit(null).cast("string"))
      .withColumn("PatientRaceKey", lit(null).cast("string"))
      .withColumn("batchuid", lit(null).cast("string"))
      .drop("IR.PracticeRaceText", "MR.description")
      // .select(schema.head, schema.tail: _*)
      .limit(500)


    dfwritetohive(RaceDF, spark, racePath)


  }

}
