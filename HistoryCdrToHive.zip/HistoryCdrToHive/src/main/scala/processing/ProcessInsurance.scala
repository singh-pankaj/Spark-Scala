package processing

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessInsurance(spark: SparkSession) {

  import spark.implicits._

  def patientinsuranceObj(Patient: DataFrame, Individual: DataFrame, PatientInsuranceInfo: DataFrame, Master: DataFrame) {

    val patientinsurancePath = prop.getProperty("PatientInsurancePath")

    val patientinsuranceDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientInsuranceInfo.as("PII"), $"PII.PatientUid" === $"PT.PatientUid", "inner")
      .join(Master.filter($"TYPE" === "CoverageRoleType").as("MPC"), $"MPC.MasterUid" === $"PII.InsuredRelationshipUid", "left")
      .select($"PT.PatientID", $"PII.PlanMemberID".as("insuredpersonid"), $"PII.insurancecompany", $"PII.insuranceplan", $"PII.insurancegroup",
        $"PII.ListOrder".as("insuranceorder"), $"PII.documentationdate", $"PII.ExpirationDate".as("enddateofinsurance"), $"PII.InsuredSameAsGuarantor".as("isinsuredsameasguarantor"),
        $"PII.payerid", $"PII.policyid", $"PII.PayerCity", $"PII.payerstate", $"PII.payerzip", $"PII.startdateofinsurance",
        $"PII.billinginsurance", $"ID.practiceuid", $"MPC.code".as("insuredrelationtopatientcode"), $"MPC.Name".as("insuredrelationtopatienttext"),$"PII.inactive")
      .withColumn("Inactiveinsurance", when($"PII.inactive" === 0, lit(1)).otherwise(lit(0)))
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("payerkey", lit(null).cast("string"))
      .withColumn("masterinsuredrelationtopatientcode", lit(null).cast("string"))
      .withColumn("masterinsuredrelationtopatienttext", lit(null).cast("string"))
      .drop("PII.inactive")
      .limit(500)
    // .select(schema.head, schema.tail: _*)
    //.drop("columnName")
    //.withColumn("PatientUid", coalesce($"",$""))

    dfwritetohive(patientinsuranceDF, spark, patientinsurancePath)

  }

}
