package processing

import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}
import processing.commons.ApplicationConfig.prop
import processing.utils.HiveUtil.dfwritetohive

class ProcessPatientSocialHistoryObservation(spark: SparkSession) {

  import spark.implicits._

  def PatientSocialHistoryObservationObj(Patient: DataFrame, Individual: DataFrame, PatientSocialHistoryObservation: DataFrame, Master: DataFrame) {

    val PatientSocialHistoryObservationPath = prop.getProperty("PatientSocialHistoryObservationPath")


    val PatientSocialHistoryObservationDF = Patient.as("PT")
      .join(Individual.as("ID"), $"PT.PatientUid" === $"ID.Individualuid", "inner")
      .join(PatientSocialHistoryObservation.as("PS"), $"PS.PatientUid" === $"PT.PatientUid", "inner")
      .join(Master.filter($"Type" === "SocialHistoryType").as("MS"), $"MS.MasterUid" === $"PS.MasterSocialHistoryTypeUid", "left")
      .join(Master.filter($"Type" === "SocialHistoryStatus").as("MS1"), $"MS.MasterUid" === $"PS.SocialHistoryStatusUid", "left")
      .select($"PT.PatientID", $"PS.socialhistoryobservedvalue", $"PS.effectivestartdate", $"PS.documentationdate", $"PT.PatientUid", $"ID.PracticeUid"
        , $"PS.yearssmoked", $"PS.quityear", $"PS.SocialHxGroup", $"PS.EffectiveEndDate".as("effectivestopdate"),
        $"MS1.Code".as("socialhistorystatuscode"), $"MS1.Name".as("socialhistorystatustext"))
      .withColumn("batchuid", lit(null).cast("string"))
      .withColumn("socialhistoryobservationkey", lit(null).cast("string"))
      .withColumn("mastersocialhistorytypecode", lit(null).cast("string"))
      .withColumn("mastersocialhistorytypetext", lit(null).cast("string"))
      .withColumn("mastersocialhistorystatuscode", lit(null).cast("string"))
      .withColumn("mastersocialhistorystatustext", lit(null).cast("string"))
      //  .select(schema.head, schema.tail: _*)
      //.drop("columnName")
      //.withColumn("PatientUid", coalesce($"",$""))
      .limit(500)
    dfwritetohive(PatientSocialHistoryObservationDF, spark, PatientSocialHistoryObservationPath)


  }

}
