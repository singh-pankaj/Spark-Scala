package com.figmd.kafka

import org.apache.spark.sql.SparkSession

object test {
  val spark = SparkSession.builder()
    .master("local[*]")
    .appName("KafkaSetup")
    .getOrCreate()

  def main(args: Array[String]): Unit = {

    import spark.implicits._

    case class FeaturesInfo(feat_id: String, feat_value_en: String,
                            feat_value_fr: String, feat_def_key: String,
                            feat_def_name_en: String, feat_def_name_fr: String, feat_def_sortPriority:
                            String, feat_group_id: String, feat_grp_name_en: String, feat_grp_name_fr:
                            String)

    val data: Map[Int, FeaturesInfo] = Map(0 -> FeaturesInfo("f2023", "Gold", "Or", "Colour", "Colour", "couleur",
      "null", "fg2004", "Hardware", "Appareil"),
      1 -> FeaturesInfo("f2052", "16GB", "16 Go", "DeviceMemory", "Internal", "Interne",
        "1", "fg2006", "Memory", "Mémoire"))

    //defined class FeaturesInfo
    //data: scala.collection.immutable.Map[Int,FeaturesInfo]


    case class jsonResult(key: Int, FEATURE_ID: String, VALUE_EN: String, VALUE_FR: String,
                          DEFN_KEY: String, DISPLAYq_NAME_EN: String, DISPLAY_NAME_FR: String,
                          SORT_PRIORITY: String, feat_group_id: String,
                          feat_grp_name_en: String, feat_grp_name_fr: String)
    val ds = data.map(x => jsonResult(x._1,
      x._2.feat_id, x._2.feat_value_en, x._2.feat_value_fr,
      x._2.feat_def_key, x._2.feat_def_name_en,
      x._2.feat_def_name_fr, x._2.feat_def_sortPriority,
      x._2.feat_group_id, x._2.feat_grp_name_en, x._2.feat_grp_name_fr))

    print(ds)

  }
}
