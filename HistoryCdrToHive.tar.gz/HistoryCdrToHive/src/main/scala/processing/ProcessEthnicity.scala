package processing

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.lit
import utils.HiveUtil.dfwritetohive
import commons.ApplicationConfig.prop

class ProcessEthnicity (spark:SparkSession){

  import spark.implicits._
  def raceObj(Patient:DataFrame,Individual:DataFrame,IndividualEthnicity:DataFrame,MasterEthnicity:DataFrame,EthnicityTable:DataFrame)={

    val schema = EthnicityTable.columns
    val ethnicityPath = prop.getProperty("PatientEthnicityPath")

    val EthnicityDF = Patient.as("PT")
      .join(Individual.as("ID"),$"PT.PatientUid"===$"ID.Individualuid","inner")
      .join(IndividualEthnicity.as("IR"),$"IR.Individualuid"===$"ID.Individualuid","inner")
      .join(MasterEthnicity.as("MR"),$"MR.EthnicityUid"===$"IR.EthnicityUid","left")
      .select($"PT.PatientID",$"IR.PatientEthnicityText",$"PT.PatientUid",$"ID.PracticeUid",$"MR.ExternalID".as("masterpatientethnicitycode"),$"MR.Description".as("masterpatientethnicitytext"))
      .withColumn("batchuid",lit(null))
      .withColumn("patientethnicitykey",lit(null))
      .withColumn("patientethnicitycode",lit(null))
      .select(schema.head,schema.tail:_*)
    //.drop("columnName")
    //.withColumn("PatientUid", coalesce($"",$""))


    dfwritetohive(EthnicityDF,spark,"patientRace",ethnicityPath)


  }

}

