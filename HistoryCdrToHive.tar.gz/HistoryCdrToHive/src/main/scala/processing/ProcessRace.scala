package processing

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import utils.HiveUtil.dfwritetohive
import commons.ApplicationConfig.prop

class ProcessRace (spark:SparkSession){

  import spark.implicits._
  def raceObj(Patient:DataFrame,Individual:DataFrame,IndividualRace:DataFrame,MasterRace:DataFrame,RaceTable:DataFrame){

    val racePath = prop.getProperty("PatientRacePath")

    val schema = RaceTable.columns

    val RaceDF = Patient.as("PT")
      .join(Individual.as("ID"),$"PT.PatientUid"===$"ID.Individualuid","inner")
      .join(IndividualRace.as("IR"),$"IR.Individualuid"===$"ID.Individualuid","inner")
      .join(MasterRace.as("MR"),$"MR.RaceUid"===$"IR.RaceUid","left")
      .select($"PT.PatientID",$"IR.PracticeRaceText",$"PT.PatientUid",$"ID.PracticeUid",$"MR.ExternalID".as("masterpatientracecode"),$"MR.Description".as("masterpatientracetext"))
      .withColumn("batchuid",lit(null))
      .withColumn("PatientRaceKey",lit(null))
      .withColumn("PatientRaceCode",lit(null))
      .select(schema.head,schema.tail:_*)
        //.drop("columnName")
        //.withColumn("PatientUid", coalesce($"",$""))


    dfwritetohive(RaceDF,spark,"patientRace",racePath)


  }

}
