package processing.utils

import java.util.Calendar

import org.apache.spark.sql.{DataFrame, SparkSession}

object HiveUtil {

  def dfwritetohive(df: DataFrame, spark: SparkSession, TableName: String, s3Path: String): Unit = {


    println(s"start time for data write into stageTable.. $TableName.. " + Calendar.getInstance.getTime)

    df.coalesce(3).write
      .partitionBy("PracticeUid")
      .mode("overwrite")
      .option("path", s3Path)
      .saveAsTable(TableName)
    println("End time for data write into stageTable.. " + Calendar.getInstance.getTime)


  }

}
