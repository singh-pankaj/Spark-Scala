package processing.commons

import java.util.Properties

object ApplicationConfig {
  var prop = new Properties

  def setApplicationConfig(args: Array[String]): Unit = {

    prop.setProperty("awsAccessKeyId", "AKIALH6XLTJCI6I3N5RQ")
    prop.setProperty("awsSecretAccessKey", "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")
    prop.setProperty("postgresHostName", "10.20.201.36")
    prop.setProperty("warehouse", "/user/hive/warehouse")
    prop.setProperty("postgresHostPort", "5432")
    prop.setProperty("postgresManagementDatabaseName", "figmdhqimanagementaao")
    prop.setProperty("postgresHostUserName", "postgres")
    prop.setProperty("postgresUserPass", "Janus@123")
    prop.setProperty("num_executors", "10")
    prop.setProperty("executor_cores", "5")
    prop.setProperty("executor_memory", "7G")
    prop.setProperty("spark_master_url", "yarn")
    prop.setProperty("mode", "cluster")
    prop.setProperty("insertPath","s3://bd-dev/migratedCDRdata/ACC")
    val rootPath = prop.getProperty("insertPath")

    prop.setProperty("PatientPath", s"$rootPath/Patient/")
    prop.setProperty("PatientEthnicityPath", s"$rootPath/A06375B5*")
    prop.setProperty("PatientRacePath", s"$rootPath/52DDF45C*")
    prop.setProperty("VisitPath", s"$rootPath/8FF9928E*")
    prop.setProperty("PatientProblemPath", s"$rootPath/C02A8880*")
    prop.setProperty("PatientProceduresPath", s"$rootPath/41318672*")
    prop.setProperty("PatientAdvanceDirectivePath", s"$rootPath/fa089e80*")
    prop.setProperty("PatientAllergiesPath", s"$rootPath/ED4EBA3A*")
    prop.setProperty("PatientMedicationsPath", s"$rootPath/E9746C91*")
    prop.setProperty("PatientPlanOfCarePath", s"$rootPath/4A188A2B*")
    prop.setProperty("PatientResultObservationPath",s"$rootPath/F967C591*")
    prop.setProperty("PatientSocialHistoryObservationPath", s"$rootPath/813EE7CA*")
    prop.setProperty("PatientVitalSignsPath", s"$rootPath/40EB7512*")
    prop.setProperty("PatientFamilyHistoryPath", s"$rootPath/7b5b1bad*")
    prop.setProperty("PatientLanguagePath", s"$rootPath/750B0376*")
    prop.setProperty("PatientNotePath", s"$rootPath/129E36F5*")
    prop.setProperty("PatientInsurancePath",s"$rootPath/A70ED65F*")

    /*
        prop.setProperty("Allergy", "mappingpracticeallergy")
        prop.setProperty("Procedure", "mappingpracticeprocedure")
        prop.setProperty("PracticeCommonData", "mappingpracticecommondatamaster")
        prop.setProperty("Ethinicity", "mappingpracticecommondatamasterethnicity")
        prop.setProperty("Race", "mappingpracticecommondatamasterrace")
        prop.setProperty("Insurance", "mappingpracticeinsurancedata")
        prop.setProperty("Problem", "MappingPracticeProblem")
        prop.setProperty("Medication", "MappingPracticeMedication")
        prop.setProperty("Route", "MappingPracticeCommonDataMasterMedicationRoute")
        prop.setProperty("RelationShip", "MappingPracticeCommonDataMasterMedicationRoute")
    */
  }
}
