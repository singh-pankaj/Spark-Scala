package processing

import org.apache.spark.sql.SparkSession

class readTables (spark:SparkSession){



  val patientTable = spark.table("2018_11_14_aao.patient")
  val RaceTable = spark.table("2018_11_14_aao.patientrace")



}
