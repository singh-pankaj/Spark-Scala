package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientFamilyHistory(FamilyHistoryPath : String) {

  def FamilyHistoryProcessing(sparkSess : SparkSession, mappingpractivecommondatamasterrelationship : DataFrame
                        , mappingpracticecommondatamaster : DataFrame, mappingpracticeproblem : DataFrame)
                         : Option[DataFrame] = {

    try {
      val file = CommonFunc.readFile(FamilyHistoryPath,sparkSess)

      val lookup1 = Map("_c0" -> "PatientId", "_c1" -> "FamilyMemberLastName", "_c2" -> "FamilyMemberFirstName",
        "_c3" -> "RelationshipToPatientCode", "_c4" -> "RelationshipToPatientText", "_c5" -> "FamilyMemberGender",
        "_c6" -> "FamilyMemberDOB", "_c7" -> "EffectiveDate", "_c8" -> "ProblemCode", "_c9" -> "ProblemText",
        "_c10" -> "ProblemCategory", "_c11" -> "ProblemTypeCode", "_c12" -> "ProblemTypeText", "_c13" -> "FamilyMemberAge",
        "_c14" -> "IsFamilyMemberAlive", "_c15" -> "FamilyHistoryKey", "_c16" -> "PracticeUid", "_c17" -> "BatchUid"
        , "_c18" -> "dummy1", "_c19" -> "dummy2")

      val cachePatientFamilyHistory = file.select(file.columns.map(c => col(c).as(lookup1.getOrElse(c, c))): _*)
        .drop("dummy1","dummy2")

      val tf = new CachePatientFamilyHistory(sparkSess, mappingpractivecommondatamasterrelationship, mappingpracticecommondatamaster, mappingpracticeproblem)

      val cacheFamilyHistory3 = cachePatientFamilyHistory
        .transform(tf.RelationshipToPatientCode)
        .transform(tf.RelationshipToPatientText)
        .transform(tf.ProblemTypeCode)
        .transform(tf.ProblemTypeText)
        .transform(tf.ProblemCode)
        .transform(tf.ProblemDescription)

      val cacheFamilyHistory4 = cacheFamilyHistory3.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("RelationshipToPatientCode", "MasterRelationshipToPatientCode"
          , "MasterRelationshipToPatientText"
          , "ProblemTypeCode", "ProblemTypeText", "MasterProblemTypeCode", "MasterProblemTypeText"
          , "ProblemCode", "ProblemText", "MasterProblemCode", "MasterProblemDescription"
          , "FamilyMemberAge", "FamilyMemberLastName", "FamilyMemberFirstName", "EffectiveDate"
          , "RelationshipToPatientText")).as("PatientFamilyHistory"))

      Some(cacheFamilyHistory4)
    }

    catch {
      case ex: FileNotFoundException => {
       ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }
}
