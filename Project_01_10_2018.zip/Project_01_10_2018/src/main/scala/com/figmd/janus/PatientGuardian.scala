package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

class PatientGuardian(GuardianPath : String) {


  def PatientGuardianProcessing(spark: SparkSession): Option[DataFrame] = {

    /*
  //Create map of file indices and column names
  val cachePatientGuardianMapDF: Dataset[Row] = rt.joinedDf
    .filter($"CacheTableViewName"==="ViewCachePatientGuardian")
  val lookup: collection.Map[String, String] = getLookupMap(cachePatientGuardianMapDF)
  */


    try {
      val lookup = Map("_c0" -> "PatientId", "_c1" -> "GuardianLastName", "_c2" -> "GuardianFirstName"
        , "_c3" -> "StreetLineAddress1", "_c4" -> "StreetLineAddress2", "_c5" -> "StreetLineAddress3"
        , "_c6" -> "StreetLineAddress4", "_c7" -> "City"
        , "_c8" -> "StateCode", "_c9" -> "State", "_c10" -> "ZipCode"
        , "_c11" -> "CountryCode", "_c12" -> "Country", "_c13" -> "TelecomTypeText"
        , "_c14" -> "TelecomValue", "_c15" -> "RelationshipToPatientCode", "_c16" -> "RelationshipToPatientText"
        , "_c17" -> "PatientGuardianKey", "_c18" -> "PracticeUid", "_c19" -> "BatchUid"
        ,"_c20" -> "dummy1", "_c21" -> "dummy2")


      //Read file for CachePatientGuardian
      val file: DataFrame = CommonFunc.readFile(GuardianPath,spark)

      //Apply lookup to generate file Header
      val CachePatientGuardianDF: DataFrame = file.select(file.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)

      val GuardianDF = CachePatientGuardianDF
        .groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("RelationshipToPatientCode", "RelationshipToPatientText",
          "City", "CountryCode", "Country", "StateCode",
          "State", "GuardianFirstName", "GuardianLastName", "StreetLineAddress1",
          "StreetLineAddress2", "StreetLineAddress3", "StreetLineAddress4", "TelecomTypeText",
          "TelecomValue", "ZipCode")).as("PatientGuardian"))
      Some(GuardianDF)
    }
    catch {
      case ex: FileNotFoundException => {
       ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }
}
