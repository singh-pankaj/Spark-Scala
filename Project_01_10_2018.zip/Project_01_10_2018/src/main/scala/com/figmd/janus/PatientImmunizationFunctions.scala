package com.figmd.janus
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.when

class CacheImmunizationFunctions(spaek : SparkSession,mappingpracticecommondatamaster:DataFrame,
                                   MappingPracticeCommonDataMasterMedicationRoute:DataFrame,MappingPracticeProcedure:DataFrame,
                                   MappingPracticeProblem:DataFrame,MappingPracticeCommonDataMaster:DataFrame)
{
  import spaek.implicits._

  def ImmunizationName(df:DataFrame): DataFrame={
    df.as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ImmunizationName" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterImmunizationCode")
        ,$"df2.CodeDescription".as("MasterImmunizationName"))
  }

  def ImmunizationCode(df:DataFrame): DataFrame={
    df.as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ImmunizationCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterImmunizationCode",when($"MappedValue1".isNull , $"MasterImmunizationCode").otherwise($"MappedValue1"))
      .withColumn("MasterImmunizationName",when($"MappedValue2".isNull , $"MasterImmunizationName").otherwise($"MappedValue2"))
  }

  def MedicationRouteText(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMasterMedicationRoute.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationRouteText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationRouteCode")
        ,$"df2.CodeDescription".as("MasterMedicationRouteText"))
  }

  def MedicationRouteCode(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMasterMedicationRoute.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationRouteCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationRouteCode",when($"MappedValue1".isNull , $"MasterMedicationRouteCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationRouteText",when($"MappedValue2".isNull , $"MasterMedicationRouteText").otherwise($"MappedValue2"))
  }

  def ProcedureText(df:DataFrame): DataFrame= {
    df.as("df1").join(MappingPracticeCommonDataMasterMedicationRoute.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureText" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MasterProcedureText"))
  }

  def ProcedureCode(df:DataFrame):DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMasterMedicationRoute.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.CodeDescription".as("MappedValue1"))
      .withColumn("MasterProcedureText",when($"MappedValue1".isNull , $"MasterProcedureText").otherwise($"MappedValue1"))
  }

  def MedicationIndicationProblemText(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeProblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationIndicationProblemCode")
        ,$"df2.CodeDescription".as("MasterMedicationIndicationProblemText"))
  }

  def MedicationIndicationProblemCode(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeProblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationIndicationProblemCode",when($"MappedValue1".isNull , $"MasterMedicationIndicationProblemCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationIndicationProblemText",when($"MappedValue2".isNull , $"MasterMedicationIndicationProblemText").otherwise($"MappedValue2"))
  }

  def MedicationReactionProblemText(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeProblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationReactionProblemText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationReactionProblemCode")
        ,$"df2.CodeDescription".as("MasterMedicationReactionProblemText"))
  }

  def MedicationReactionProblemCode(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeProblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationReactionProblemCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationReactionProblemCode",when($"MappedValue1".isNull , $"MasterMedicationReactionProblemCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationReactionProblemText",when($"MappedValue2".isNull , $"MasterMedicationReactionProblemText").otherwise($"MappedValue2"))
  }

  def MedicationReactionProblemSeverityText(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationReactionProblemSeverityText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationReactionProblemSeverityCode")
        ,$"df2.CodeDescription".as("MasterMedicationReactionProblemSeverityText"))
  }

  def MedicationReactionProblemSeverityCode(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationReactionProblemSeverityCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationReactionProblemSeverityCode",when($"MappedValue1".isNull , $"MasterMedicationReactionProblemSeverityCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationReactionProblemSeverityText",when($"MappedValue2".isNull , $"MasterMedicationReactionProblemSeverityText").otherwise($"MappedValue2"))
  }

  def MedicationStatusText(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationStatusText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationStatusCode")
        ,$"df2.CodeDescription".as("MasterMedicationStatusText"))
  }

  def MedicationStatusCode(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationStatusCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationStatusCode",when($"MappedValue1".isNull , $"MasterMedicationStatusCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationStatusText",when($"MappedValue2".isNull , $"MasterMedicationStatusText").otherwise($"MappedValue2"))
  }

}
