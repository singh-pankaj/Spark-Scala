package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.constant.ApplicationConfig.prop
import com.figmd.janus.util.{CommonFunc, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
class PatientresultObservation(ResultObsPath : String) {


  def cacheresultObsProcessing(sparkSess : SparkSession, mappingpracticecommondatamaster : DataFrame
                    ,mappingpracticeprocedure : DataFrame,conf : Config, DemoGraphicsDF : DataFrame): Unit = {

    import sparkSess.implicits._
    try {
      //Start CacheResultObservation
      var CacheResultObservation = CommonFunc.readFile(ResultObsPath,sparkSess)
      //CacheResultObservation.printSchema()

      val lookup10 = Map("_c0" -> "PatientId", "_c1" -> "ObservationCode", "_c2" -> "ObservationName"
        , "_c3" -> "ObservationCategory", "_c4" -> "ObservationDate", "_c5" -> "ObservationValue"
        , "_c6" -> "ObsInterpretationCode", "_c7" -> "ObsInterpretationText", "_c8" -> "TargetSiteCode"
        , "_c9" -> "TargetSiteText", "_c10" -> "ServiceProviderNPI", "_c11" -> "ServiceProviderLastName"
        , "_c12" -> "ServiceProviderFirstName", "_c13" -> "NegationInd", "_c14" -> "ReferenceLowerRange"
        , "_c15" -> "ReferenceUpperRange", "_c16" -> "MethodCode", "_c17" -> "MethodCodeText"
        , "_c18" -> "SpecimenId", "_c19" -> "ProcedureCode", "_c20" -> "ProcedureText"
        , "_c21" -> "ProcedureCategory", "_c22" -> "ResultObservationStatus", "_c23" -> "ResultOrderDescription"
        , "_c24" -> "ResultOrderDate", "_c25" -> "ResultOBSUnit", "_c26" -> "LaboratoryID"
        , "_c27" -> "LaboratoryName", "_c28" -> "ResultOrderCode", "_c29" -> "Obssubid"
        , "_c30" -> "ResultObservationKey", "_c31" -> "PracticeUid", "_c32" -> "BatchUid"
        , "_c33" -> "dummy1", "_c34" -> "dummy2")

      CacheResultObservation = CacheResultObservation.select(CacheResultObservation.columns.map(c => col(c).as(lookup10.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("ObservationDate", to_timestamp($"ObservationDate", "MM/dd/yyyy HH:mm:ss"))

      //CacheResultObservation.printSchema()

      val addPatientUid =  CacheResultObservation.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PracticeUid","PatientId"))
        .select($"df1.*",$"df2.PatientUid")

      //Some column is remaining
      val resultObsObj = new ResultObsFunction(sparkSess, mappingpracticecommondatamaster, mappingpracticeprocedure)

      val CacheResultObservation2 = addPatientUid
        .transform(resultObsObj.PracticeCode)
        .transform(resultObsObj.PracticeDescription)
        .transform(resultObsObj.TargetSiteCode)
        .transform(resultObsObj.TargetSiteText)
        .transform(resultObsObj.ObsInterpretationCode)
        .transform(resultObsObj.ObsInterpretationText)
        .transform(resultObsObj.ProcedureCode)
        .transform(resultObsObj.ProcedureText)
        .transform(resultObsObj.MethodCode)
        .transform(resultObsObj.MethodCodeText)


      /*val distinctYear = CacheResultObservation2.withColumn("Year",year($"ObservationDate")).select("Year").distinct()
      val distinctMonth = CacheResultObservation2.withColumn("Month",month($"ObservationDate")).select("Month").distinct()
      val distinctPUid = CacheResultObservation2.select("PracticeUid").distinct()

      val ListVal:Array[Any] = distinctYear.rdd.map(r => r(0)).collect()
      val PartitionYear = "(\"" + ListVal.mkString("\",\"") + "\")"

      val ListVal3:Array[Any] = distinctMonth.rdd.map(r => r(0)).collect()
      val PartitionMonth = "(\"" + ListVal3.mkString("\",\"") + "\")"

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val ResObsData = sparkSess.sql(s"select * from figmdaaocdr.patientresultobservation where" +
        s" practiceuid in $PartitionPUID and year in $PartitionYear and month in $PartitionMonth")
        .drop("year","month")

      val PreviousandNewData = CacheResultObservation2.as("df1").join(ResObsData.as("df2")
        ,Seq("PatientId","PatientUid","PracticeUid"),"left_outer")
        .select($"df1.*")

      val otherData = ResObsData.as("df1").join(CacheResultObservation2.as("df2")
        ,Seq("PatientId","PatientUid","PracticeUid"),"left_anti")
        .select($"df1.*")
/*
      val newData = CacheResultObservation2.as("df1").join(ResObsData.as("df2")
        ,Seq("PatientId","PatientUid","PracticeUid"),"left_anti")
        .select($"df1.*")*/

      val allResObsnData = PreviousandNewData.union(otherData)
      val tableName = conf.getString("db_tb_ResObs")
      val CombineData = allResObsnData.as("df1").withColumn("Year",year($"df1.ObservationDate"))
        .withColumn("Month",month($"df1.ObservationDate"))*/
      val tableName = conf.getString("db_tb_ResObs")
      val CombineData = CacheResultObservation2.as("df1").withColumn("Year",year($"df1.ObservationDate"))
      val tempTableName = prop.getProperty("HiveResultObsTableName")
      println("temp table of ResObs"+tempTableName)
      val s3path = prop.getProperty("s3LocationResObs")
      println("Data wrote to hive ResObs......")
      HiveUtility.dfwritrtohiveVisit(CombineData,tableName,sparkSess,tempTableName,s3path)

    }
    catch {
      case ex: FileNotFoundException => {
        println("File Not found"+ex)
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }
  }
}
