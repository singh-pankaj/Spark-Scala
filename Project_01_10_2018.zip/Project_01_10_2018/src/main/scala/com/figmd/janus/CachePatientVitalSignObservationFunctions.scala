package com.figmd.janus
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.when

class CachePatientVitalSignObservationFunctions(spark: SparkSession,mappingpracticecommondatamaster:DataFrame){
  import spark.implicits._

  def PracticeDescription(df:DataFrame): DataFrame={
    df.as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterObservationCode")
        ,$"df2.CodeDescription".as("MasterObservationName"))
  }

  def PracticeCode(df:DataFrame): DataFrame={
    df.as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterObservationCode",when($"MappedValue1".isNull
        , $"MasterObservationCode").otherwise($"MappedValue1"))
      .withColumn("MasterObservationName",when($"MappedValue2".isNull
        , $"MasterObservationName").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def TargetSiteText(df:DataFrame): DataFrame={
    df.as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterTargetSiteCode")
        ,$"df2.CodeDescription".as("MasterTargetSiteText"))
  }

  def TargetSiteCode(df:DataFrame): DataFrame={
    df.as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterTargetSiteCode",when($"MappedValue1".isNull
        , $"MasterTargetSiteCode").otherwise($"MappedValue1"))
      .withColumn("MasterTargetSiteText",when($"MappedValue2".isNull
        , $"MasterTargetSiteText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def ObsInterpretationText(df:DataFrame): DataFrame={
    df.as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterObsInterpretationCode")
        ,$"df2.CodeDescription".as("MasterObsInterpretationText"))
  }

  def ObsInterpretationCode(df:DataFrame): DataFrame={
    df.as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterObsInterpretationCode",when($"MappedValue1".isNull
        , $"MasterObsInterpretationCode").otherwise($"MappedValue1"))
      .withColumn("MasterObsInterpretationText",when($"MappedValue2".isNull
        , $"MasterObsInterpretationText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }



}
