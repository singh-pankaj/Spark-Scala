package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
class PatientRace(RacePath : String) {

  def cacheRaceProcessing(sparkSess : SparkSession, MasterRace : DataFrame) : Option[DataFrame] = {

  //import sparkSess.implicits._

    try {
      var CachePatientRaceTable = CommonFunc.readFile(RacePath,sparkSess)

      val lookup3 = Map("_c0" -> "PatientId", "_c1" -> "PatientRaceCode", "_c2" -> "PatientRaceText"
        , "_c3" -> "PatientRaceKey", "_c4" -> "PracticeUid"
        , "_c5" -> "BatchUid", "_c6" -> "dummy1", "_c7" -> "dummy2")

      CachePatientRaceTable = CachePatientRaceTable.select(CachePatientRaceTable.columns.map(c => col(c).as(lookup3.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")

      val CleanedData = CachePatientRaceTable.dropDuplicates("PatientId","PatientRaceText")
      val raceObj = new cacheRaceFunctions(sparkSess, MasterRace)

      val CachePatientRace = CleanedData
        .transform(raceObj.PatientRaceText)
        .transform(raceObj.PatientRaceCode)

      val CachePatientRace2 = CachePatientRace.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("PatientRaceCode", "PatientRaceText", "MasterPatientRaceCode"
          , "MasterPatientRaceText")).as("Race"))

      Some(CachePatientRace2)
    }
    catch {
      case ex: FileNotFoundException => {
       ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }

  }
}