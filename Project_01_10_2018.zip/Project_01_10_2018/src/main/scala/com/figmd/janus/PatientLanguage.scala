package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

class PatientLanguage(LanguagePath : String) {


  def cachepatientLangProcessing(sparkSess : SparkSession) : Option[DataFrame] = {


    //Start ImportPatientLanguageData

    try {
      var CachePatientLanguage = CommonFunc.readFile(LanguagePath,sparkSess).drop("dummy1", "dummy2")

      val lookup11 = Map("_c0" -> "PatientId", "_c1" -> "LanguageCode", "_c2" -> "LanguageText"
        , "_c3" -> "LangaugeAbilityModeCode", "_c4" -> "LangaugeAbilityModeText", "_c5" -> "LanguageProficiencyLevelCode"
        , "_c6" -> "LanguageProficiencyLevelText", "_c7" -> "PreferenceInd", "_c8" -> "PatientLanguageKey"
        , "_c9" -> "PracticeUid", "_c10" -> "BatchUid", "_c11" -> "dummy1"
        , "_c12" -> "dummy2")

      CachePatientLanguage = CachePatientLanguage.select(CachePatientLanguage.columns.map(c => col(c).as(lookup11.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")


      val CachePatientLanguage2 = CachePatientLanguage.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("LanguageCode", "LanguageText", "LangaugeAbilityModeCode"
          , "LangaugeAbilityModeText", "LanguageProficiencyLevelCode"
          , "LanguageProficiencyLevelText", "PreferenceInd")).as("Language"))

      Some(CachePatientLanguage2)
    }
    catch {
      case ex: FileNotFoundException => {
       ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }

}
