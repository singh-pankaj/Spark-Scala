package com.figmd.janus.constant
import java.util.{Properties}
import org.apache.log4j.{Level, Logger}
object ApplicationConfig {
    var prop = new Properties

    def setApplicationConfig(args: Array[String]): Unit =
    {
      /*

      prop.setProperty("warehouse", args(0))
      prop.setProperty("awsAccessKeyId",args(1))
      prop.setProperty("awsSecretAccessKey", args(2))
      prop.setProperty("postgresHostName", args(3))
      prop.setProperty("postgresHostPort", args(4))
      prop.setProperty("postgresManagementDatabaseName",args(5))
      prop.setProperty("postgresHostUserName",args(6))
      prop.setProperty("postgresUserPass", args(7))
      prop.setProperty("num_executors", args(8))
      prop.setProperty("executor_cores", args(9))
      prop.setProperty("executor_memory", args(10))
      prop.setProperty("spark_master_url", args(11))
      prop.setProperty("mode", args(12))
      prop.setProperty("Allergy", args(13))
      prop.setProperty("Procedure", args(14))
      prop.setProperty("PracticeCommonDta",args(15))
      prop.setProperty("Ethinicity", args(16))
      prop.setProperty("Race", args(17))
      prop.setProperty("Insurance", args(18))
      prop.setProperty("Problem",args(19))
      prop.setProperty("Medication", args(20))
      prop.setProperty("Route", args(21))
      prop.setProperty("RootPath", "s3://figmd-bigdata-emr-demo")

      val rootPath = prop.getProperty("RootPath")

      prop.setProperty("MedicationPath", s"$rootPath/CacheMedications/")
      prop.setProperty("NoteVitalSignPath", s"$rootPath/CachePatientNotesVitalObservation/")
      prop.setProperty("NotesProcedurePath", s"$rootPath/CachePatientNotesProcedure/")
      prop.setProperty("PatientNotesPath", s"$rootPath/CachePatientNotes/")
      prop.setProperty("EthinicityPath", s"$rootPath/CachePatientEthnicity/")
      prop.setProperty("DemoPath", s"$rootPath/CachePatientDemographics/")
      prop.setProperty("AllergiesPath", s"$rootPath/CacheAllergies/")
      prop.setProperty("NoteResultObservationPath", s"$rootPath/CachePatientNotesResultObservation/")
      prop.setProperty("LanguagePath",s"$rootPath/CachePatientLanguage/")
      prop.setProperty("ProcedurePath", s"$rootPath/CacheProcedures/")
      prop.setProperty("ImmunizationPath", s"$rootPath/CacheImmunization/")
      prop.setProperty("PlanOfCarePath", s"$rootPath/CachePlanOfCare/")
      prop.setProperty("FamilyHistoryPath", s"$rootPath/CacheFamilyHistory/")
      prop.setProperty("VitalSignPath", s"$rootPath/CacheVitalSigns/")
      prop.setProperty("PatientLabOrderPath",s"$rootPath/CachePatientLabOrder/")
      prop.setProperty("EncounterDiagnosisPath",s"$rootPath/CacheEncounterDiagnosis/")
      prop.setProperty("ResultObservationPath",s"$rootPath/CacheResultObservation/")
      prop.setProperty("PatientGuardianPath", s"$rootPath/CachePatientGuardian/")
      prop.setProperty("SocialHistoryObsPath", s"$rootPath/CacheSocialHistoryObservation/")
      prop.setProperty("EncounterPath", s"$rootPath/CacheEncounter/")
      prop.setProperty("PatientNotesProblemPath", s"$rootPath/CachePatientNotesProblem/")
      prop.setProperty("AdvanceDirectivePath", s"$rootPath/CacheAdvanceDirective/")
      prop.setProperty("RacePath", s"$rootPath/CachePatientRace/")
      prop.setProperty("PatientNotesMedicationPath", s"$rootPath/CachePatientNotesMedication/")
      prop.setProperty("InsurancePath", s"$rootPath/CachePayer/")
      prop.setProperty("ProblemPath", s"$rootPath/CacheProblem/")
    */

      //prop.setProperty("warehouse", "/user/hive/warehouse")
     // prop.setProperty("awsAccessKeyId", "AKIAL35LZ5DVCIC4JZRQ")
      //prop.setProperty("awsSecretAccessKey", "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")
      /*prop.setProperty("awsAccessKeyId", "AKIAIM2NKGABQ4C5A3JQ")
      prop.setProperty("awsSecretAccessKey", "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")*/
      //prop.setProperty("postgresHostName", "10.0.0.47")
      prop.setProperty("awsAccessKeyId", "AKIALH6XLTJCI6I3N5RQ")
      prop.setProperty("awsSecretAccessKey", "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")
      prop.setProperty("postgresHostName", "10.20.201.36")
      prop.setProperty("warehouse", "/user/hive/warehouse")
      prop.setProperty("postgresHostPort", "5432")
      prop.setProperty("postgresManagementDatabaseName", "figmdhqimanagementacr")             //postgress reg db name------------------------
      prop.setProperty("postgresHostUserName", "postgres")
      prop.setProperty("postgresUserPass", "Janus@123")
      prop.setProperty("num_executors", "7")
      prop.setProperty("executor_cores", "5")
      prop.setProperty("executor_memory", "8G")
      prop.setProperty("spark_master_url", "yarn")
      prop.setProperty("mode", "cluster")
      prop.setProperty("Allergy", "mappingpracticeallergy")
      prop.setProperty("Procedure", "mappingpracticeprocedure")
      prop.setProperty("PracticeCommonDta", "mappingpracticecommondatamaster")
      prop.setProperty("Ethinicity", "mappingpracticecommondatamasterethnicity")
      prop.setProperty("Race", "mappingpracticecommondatamasterrace")
      prop.setProperty("Insurance", "mappingpracticeinsurancedata")
      prop.setProperty("Problem", "MappingPracticeProblem")
      prop.setProperty("Medication", "MappingPracticeMedication")
      prop.setProperty("Route", "MappingPracticeCommonDataMasterMedicationRoute")
      prop.setProperty("RelationShip", "MappingPracticeCommonDataMasterMedicationRoute")

      //prop.setProperty("RootPath", "s3://bd-dev/REGDATA_AAO")
      //prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_AAOHNS")
      //prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_AAD")
      //prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_AAPMR")
      //prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_ABFM")
      //prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_APA")
      //prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_APTA")
      //prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_ASPS")
      //prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_AUA")
      //prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_AUGS")
      //prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_IC")
      //prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_POLARIS")
      //prop.setProperty("RootPath", "s3://bd-dev/REGDATA_AAO_PAR")
      prop.setProperty("RootPath", "s3://bd-dev/REGDATANEW1/ACR")                    //s3 path for per registry
      val rootPath = prop.getProperty("RootPath")
      prop.setProperty("DemoPath", s"$rootPath/PatientDemographics/")
      prop.setProperty("VitalSignPath", s"$rootPath/PatientVitalSigns/")
      prop.setProperty("SocialHistoryObsPath", s"$rootPath/PatientSocialHistoryObservation/")
      prop.setProperty("AdvanceDirectivePath", s"$rootPath/PatientAdvanceDirective/")
      prop.setProperty("AllergiesPath", s"$rootPath/PatientAllergies/")
      prop.setProperty("EncounterPath", s"$rootPath/PatientEncounter2/")
      prop.setProperty("EncounterDiagnosisPath",s"$rootPath/PatientEncounterDiagnosis/")
      prop.setProperty("EthinicityPath", s"$rootPath/PatientEthnicity/")
      prop.setProperty("FamilyHistoryPath", s"$rootPath/PatientFamilyHistory/")
      prop.setProperty("LanguagePath",s"$rootPath/PatientLanguage/")
      prop.setProperty("MedicationPath", s"$rootPath/PatientMedications/")
      prop.setProperty("PatientNotesPath", s"$rootPath/PatientNotes/")
      prop.setProperty("InsurancePath", s"$rootPath/PatientPayer/")
      prop.setProperty("PlanOfCarePath", s"$rootPath/PatientPlanOfCare/")  //PatientPlanOfCare
      prop.setProperty("ProblemPath", s"$rootPath/PatientProblem/")
      prop.setProperty("ProcedurePath", s"$rootPath/PatientProcedures/")
      prop.setProperty("RacePath", s"$rootPath/PatientRace/")
     // prop.setProperty("ResultObservationPath",s"$rootPath/PatientNotesResultObservation/")
      //change path
      prop.setProperty("ResultObservationPath",s"$rootPath/PatientResultObservation/")


      /*prop.setProperty("DemoPath", s"$rootPath/PatientDemographics/edea6658-b815-466d-aeea-17a9dd575dd1_[8af]*")
      prop.setProperty("VitalSignPath", s"$rootPath/PatientVitalSigns/40eb7512-26ea-4eec-b05f-966fb63e1aa4_[a]*")
      prop.setProperty("SocialHistoryObsPath", s"$rootPath/PatientSocialHistoryObservation/813ee7ca-89da-4a2a-9b78-bbc710595fcc_f*")
      prop.setProperty("AdvanceDirectivePath", s"$rootPath/PatientAdvanceDirective/fa089e80-9064-41aa-9052-dbe36a15cb66_[a]*")
      prop.setProperty("AllergiesPath", s"$rootPath/PatientAllergies/ed4eba3a-8fda-4cf8-a0a0-204c08258599_[a]*")
      prop.setProperty("EncounterPath", s"$rootPath/PatientEncounter/8ff9928e-7288-4491-8aa0-c7e0da5bbba8_[a]*")
      prop.setProperty("EncounterDiagnosisPath",s"$rootPath/PatientEncounterDiagnosis/608cdee4-97d1-42a2-849d-9d9a95bc5131_[a]*")
      prop.setProperty("EthinicityPath", s"$rootPath/PatientEthnicity/a06375b5-51cc-4028-88ea-1690c4e7b2e7_[a]*")
      prop.setProperty("FamilyHistoryPath", s"$rootPath/PatientFamilyHistory/7b5b1bad-4a4d-454e-a9a7-942340314884_[a]*")
      prop.setProperty("LanguagePath",s"$rootPath/PatientLanguage/750b0376-496d-4f3e-a061-5ea7f630b343_[a]*")
      prop.setProperty("MedicationPath", s"$rootPath/PatientMedications/e9746c91-6a44-4b65-b398-06706d075422_[a]*")
      prop.setProperty("PatientNotesPath", s"$rootPath/PatientNotes/129e36f5-51dd-412c-8a83-15f50cc6563e_[a]*")
      prop.setProperty("InsurancePath", s"$rootPath/PatientPayer/a70ed65f-6cca-4808-82b4-fb2bcc5e737a_[a]*")
      prop.setProperty("PlanOfCarePath", s"$rootPath/PatientPlanOfCare/4a188a2b-0e27-40d5-8a58-875e1113b4fa_[a]*")
      prop.setProperty("ProblemPath", s"$rootPath/PatientProblem/c02a8880-be91-4479-add2-02fe91f48db0_[a]*")
      prop.setProperty("ProcedurePath", s"$rootPath/PatientProcedures/41318672-877d-4c04-b2cb-61cd7db55864_[a]*")
      prop.setProperty("RacePath", s"$rootPath/PatientRace/52ddf45c-6d51-418f-be58-eb8ce57fa2a1_[a]*")
      prop.setProperty("ResultObservationPath",s"$rootPath/PatientResultObservation/f967c591-1460-4731-b6be-a620238630d2_8*")*/



      prop.setProperty("HivePatientTableName","acrcdrdb3.patient")                        //hive database and hive table name
      prop.setProperty("s3LocationPatient","s3://bd-dev/AAOData/AllReg/ACR/Patient/")           //s3 path from hive table

      prop.setProperty("HivEncounterTableName","acrcdrdb3.patientvisit")
      prop.setProperty("s3LocationEncounter","s3://bd-dev/AAOData/AllReg/ACR/PatientVisit/")

      prop.setProperty("HiveProblemTableName","acrcdrdb3.patientproblem")
      prop.setProperty("s3LocationProblem","s3://bd-dev/AAOData/AllReg/ACR/PatientProblem/")

      prop.setProperty("HiveProcedureTableName","acrcdrdb3.patientprocedure")
      prop.setProperty("s3LocationProcedure","s3://bd-dev/AAOData/AllReg/ACR/PatientProcedure/")

      prop.setProperty("HiveMedicationTableName","acrcdrdb3.patientmedication")
      prop.setProperty("s3LocationMedication","s3://bd-dev/AAOData/AllReg/ACR/PatientMedication/")

      prop.setProperty("HiveImmunizationTableName","")
      prop.setProperty("s3LocationImmunization","")

      prop.setProperty("HiveResultObsTableName","acrcdrdb3.patientresultobservation")
      prop.setProperty("s3LocationResObs","s3://bd-dev/AAOData/AllReg/ACR/PatientResultObservation/")

      prop.setProperty("HiveVitalSignTableName","acrcdrdb3.patientvitalsignobservation")
      prop.setProperty("s3LocationVitalsign","s3://bd-dev/AAOData/AllReg/ACR/Patientvitalsignobservation/")

      prop.setProperty("HivePatientNotesTableName","acrcdrdb3.patientnotes")
      prop.setProperty("s3LocationPatientNotes","s3://bd-dev/AAOData/AllReg/ACR/PatientNotes/")


      //prop.setProperty("RootPath", "s3://figmd-bigdata-emr-demo")
/*
      prop.setProperty("RootPath", "s3://bd-dev/AAOData/2018-09-30")
      val rootPath = prop.getProperty("RootPath")
      prop.setProperty("MedicationPath", s"$rootPath/PatientMedications/")
      prop.setProperty("PatientNotesPath", s"$rootPath/PatientNotes/")
      prop.setProperty("EthinicityPath", s"$rootPath/PatientEthnicity/")
     // prop.setProperty("DemoPath", s"$rootPath/PatientDemographics/")
      prop.setProperty("DemoPath", s"s3://bd-dev/REGDATA_AAO/PatientDemographics/edea6658-b815-466d-aeea-17a9dd575dd1_[abc]*")
      prop.setProperty("AllergiesPath", s"$rootPath/PatientAllergies/")
      prop.setProperty("NoteResultObservationPath", s"$rootPath/PatientNotesResultObservation/")
      prop.setProperty("LanguagePath",s"$rootPath/PatientLanguage/")
      prop.setProperty("ProcedurePath", s"$rootPath/PatientProcedures/")
      prop.setProperty("PlanOfCarePath", s"$rootPath/PatientPlanOfCare/")
      prop.setProperty("FamilyHistoryPath", s"$rootPath/PatientFamilyHistory/")
      prop.setProperty("VitalSignPath", s"$rootPath/PatientVitalSigns/")
      prop.setProperty("EncounterDiagnosisPath",s"$rootPath/PatientEncounterDiagnosis/")
      prop.setProperty("ResultObservationPath",s"$rootPath/PatientResultObservation/")
      prop.setProperty("SocialHistoryObsPath", s"$rootPath/PatientSocialHistoryObservation/")
      prop.setProperty("EncounterPath", s"$rootPath/PatientEncounter/")
      prop.setProperty("AdvanceDirectivePath", s"$rootPath/PatientAdvanceDirective/")
      prop.setProperty("RacePath", s"$rootPath/PatientRace/")
      prop.setProperty("PatientNotesMedicationPath", s"$rootPath/PatientNotesMedication/")
      prop.setProperty("InsurancePath", s"$rootPath/PatientInsurance/")
      prop.setProperty("ProblemPath", s"$rootPath/PatientProblem/")
      prop.setProperty("PatientNotesMedicationPath", s"$rootPath/CachePatientNotesMedication/")
      prop.setProperty("InsurancePath", s"$rootPath/CachePayer/")
      prop.setProperty("ProblemPath", s"$rootPath/CacheProblem/")*/

      //prop.setProperty("RootPath", "s3://figmd-bigdata-emr-demo/Allfiles/")
      //prop.setProperty("RootPath", " s3://janus/staging")

     // s3://janus/staging/CachePatientDemographics/
     // val rootPath = prop.getProperty("RootPath")

      /*prop.setProperty("MedicationPath", s"$rootPath/CacheMedications/")
      prop.setProperty("NoteVitalSignPath", s"$rootPath/CachePatientNotesVitalObservation/")
      prop.setProperty("NotesProcedurePath", s"$rootPath/CachePatientNotesProcedure/")
      prop.setProperty("PatientNotesPath", s"$rootPath/CachePatientNotes/")
      prop.setProperty("EthinicityPath", s"$rootPath/CachePatientEthnicity/")
      prop.setProperty("DemoPath", s"$rootPath/CachePatientDemographics/")
     // prop.setProperty("DemoPath", "s3://janus/staging/CachePatientDemographics/")
      prop.setProperty("AllergiesPath", s"$rootPath/CacheAllergies/")
      prop.setProperty("NoteResultObservationPath", s"$rootPath/CachePatientNotesResultObservation/")
      prop.setProperty("LanguagePath",s"$rootPath/CachePatientLanguage/")
      prop.setProperty("ProcedurePath", s"$rootPath/CacheProcedures/")
      prop.setProperty("ImmunizationPath", s"$rootPath/CacheImmunization/")
      prop.setProperty("PlanOfCarePath", s"$rootPath/CachePlanOfCare/")
      prop.setProperty("FamilyHistoryPath", s"$rootPath/CacheFamilyHistory/")
      prop.setProperty("VitalSignPath", s"$rootPath/CacheVitalSigns/")
      prop.setProperty("PatientLabOrderPath",s"$rootPath/CachePatientLabOrder/")
      prop.setProperty("EncounterDiagnosisPath",s"$rootPath/CacheEncounterDiagnosis/")
      prop.setProperty("ResultObservationPath",s"$rootPath/CacheResultObservation/")
      prop.setProperty("PatientGuardianPath", s"$rootPath/CachePatientGuardian/")
      prop.setProperty("SocialHistoryObsPath", s"$rootPath/CacheSocialHistoryObservation/")
      prop.setProperty("EncounterPath", s"$rootPath/CacheEncounter/")
      prop.setProperty("PatientNotesProblemPath", s"$rootPath/CachePatientNotesProblem/")
      prop.setProperty("AdvanceDirectivePath", s"$rootPath/CacheAdvanceDirective/")
      prop.setProperty("RacePath", s"$rootPath/CachePatientRace/")
      prop.setProperty("PatientNotesMedicationPath", s"$rootPath/CachePatientNotesMedication/")
      prop.setProperty("InsurancePath", s"$rootPath/CachePayer/")
      prop.setProperty("ProblemPath", s"$rootPath/CacheProblem/")*/




     /* prop.setProperty("MedicationPath",s"$rootPath/part_e9746c91-6a44-4b65-b398-06706d075422.txt")
      prop.setProperty("EthinicityPath", s"$rootPath/part_a06375b5-51cc-4028-88ea-1690c4e7b2e7.txt")
      prop.setProperty("DemoPath", s"$rootPath/part_edea6658-b815-466d-aeea-17a9dd575dd1.txt")
      prop.setProperty("LanguagePath",s"$rootPath/part_750b0376-496d-4f3e-a061-5ea7f630b343.txt")
      prop.setProperty("ProcedurePath", s"$rootPath/part_41318672-877d-4c04-b2cb-61cd7db55864.txt")
      prop.setProperty("PlanOfCarePath", s"$rootPath/part_4a188a2b-0e27-40d5-8a58-875e1113b4fa.txt")
      prop.setProperty("VitalSignPath", s"$rootPath/part_40eb7512-26ea-4eec-b05f-966fb63e1aa4.txt")
      prop.setProperty("ResultObservationPath",s"$rootPath/part_f967c591-1460-4731-b6be-a620238630d2.txt")
      prop.setProperty("SocialHistoryObsPath", s"$rootPath/part_813ee7ca-89da-4a2a-9b78-bbc710595fcc.txt")
      prop.setProperty("EncounterPath", s"$rootPath/part_8ff9928e-7288-4491-8aa0-c7e0da5bbba8.txt")
      prop.setProperty("InsurancePath",s"$rootPath/part_a70ed65f-6cca-4808-82b4-fb2bcc5e737a.txt")
      prop.setProperty("ProblemPath", s"$rootPath/part_c02a8880-be91-4479-add2-02fe91f48db0.txt")
      */


     /* prop.setProperty("MedicationPath",s"temp_test/AllFiles/part_e9746c91-6a44-4b65-b398-06706d075422.txt")
      prop.setProperty("EthinicityPath", s"temp_test/AllFiles/part_a06375b5-51cc-4028-88ea-1690c4e7b2e7.txt")
      prop.setProperty("DemoPath", s"temp_test/AllFiles/part_edea6658-b815-466d-aeea-17a9dd575dd1.txt")
      prop.setProperty("LanguagePath",s"temp_test/AllFiles/part_750b0376-496d-4f3e-a061-5ea7f630b343.txt")
      prop.setProperty("ProcedurePath", s"temp_test/AllFiles/part_41318672-877d-4c04-b2cb-61cd7db55864.txt")
      prop.setProperty("PlanOfCarePath", s"temp_test/AllFiles/part_4a188a2b-0e27-40d5-8a58-875e1113b4fa.txt")
      prop.setProperty("VitalSignPath", s"temp_test/AllFiles/part_40eb7512-26ea-4eec-b05f-966fb63e1aa4.txt")
      prop.setProperty("ResultObservationPath",s"temp_test/AllFiles/part_f967c591-1460-4731-b6be-a620238630d2.txt")
      prop.setProperty("SocialHistoryObsPath", s"temp_test/AllFiles/part_813ee7ca-89da-4a2a-9b78-bbc710595fcc.txt")
      prop.setProperty("EncounterPath", s"temp_test/AllFiles/part_8ff9928e-7288-4491-8aa0-c7e0da5bbba8.txt")
      prop.setProperty("InsurancePath",s"temp_test/AllFiles/part_a70ed65f-6cca-4808-82b4-fb2bcc5e737a.txt")
      prop.setProperty("ProblemPath", s"temp_test/AllFiles/part_c02a8880-be91-4479-add2-02fe91f48db0.txt")
      prop.setProperty("RacePath", s"temp_test/AllFiles/part_52ddf45c-6d51-418f-be58-eb8ce57fa2a1.txt")*/

      Logger.getLogger("org").setLevel(Level.OFF)
      Logger.getLogger("akka").setLevel(Level.OFF)
      Logger.getLogger("myLogger").setLevel(Level.OFF)


    }
  }


