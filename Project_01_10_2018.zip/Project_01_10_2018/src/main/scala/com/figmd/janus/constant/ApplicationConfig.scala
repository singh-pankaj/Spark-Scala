package com.figmd.janus.constant
import java.util.{Properties}
import org.apache.log4j.{Level, Logger}
object ApplicationConfig {
    var prop = new Properties

    def setApplicationConfig(args: Array[String]): Unit =
    {

      prop.setProperty("awsAccessKeyId", "AKIALH6XLTJCI6I3N5RQ")
      prop.setProperty("awsSecretAccessKey", "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")
      prop.setProperty("postgresHostName", "10.20.201.36")
      prop.setProperty("warehouse", "/user/hive/warehouse")
      prop.setProperty("postgresHostPort", "5432")
      prop.setProperty("postgresManagementDatabaseName", "figmdhqimanagementpolaris")             //postgress reg db name------------------------
      prop.setProperty("postgresHostUserName", "postgres")
      prop.setProperty("postgresUserPass", "Janus@123")
      prop.setProperty("num_executors", "7")
      prop.setProperty("executor_cores", "5")
      prop.setProperty("executor_memory", "8G")
      prop.setProperty("spark_master_url", "yarn")
      prop.setProperty("mode", "cluster")
      prop.setProperty("Allergy", "mappingpracticeallergy")
      prop.setProperty("Procedure", "mappingpracticeprocedure")
      prop.setProperty("PracticeCommonDta", "mappingpracticecommondatamaster")
      prop.setProperty("Ethinicity", "mappingpracticecommondatamasterethnicity")
      prop.setProperty("Race", "mappingpracticecommondatamasterrace")
      prop.setProperty("Insurance", "mappingpracticeinsurancedata")
      prop.setProperty("Problem", "MappingPracticeProblem")
      prop.setProperty("Medication", "MappingPracticeMedication")
      prop.setProperty("Route", "MappingPracticeCommonDataMasterMedicationRoute")
      prop.setProperty("RelationShip", "MappingPracticeCommonDataMasterMedicationRoute")


      prop.setProperty("RootPath", "s3://bd-dev/REGDATANEW1/POLARIS")                    //s3 path for per registry
      val rootPath = prop.getProperty("RootPath")
      prop.setProperty("DemoPath", s"$rootPath/PatientDemographics/")
      prop.setProperty("VitalSignPath", s"$rootPath/PatientVitalSigns/")
      prop.setProperty("SocialHistoryObsPath", s"$rootPath/PatientSocialHistoryObservation/")
      prop.setProperty("AdvanceDirectivePath", s"$rootPath/PatientAdvanceDirective/")
      prop.setProperty("AllergiesPath", s"$rootPath/PatientAllergies/")
      prop.setProperty("EncounterPath", s"$rootPath/PatientEncounter/")
      prop.setProperty("EncounterDiagnosisPath",s"$rootPath/PatientEncounterDiagnosis/")
      prop.setProperty("EthinicityPath", s"$rootPath/PatientEthnicity/")
      prop.setProperty("FamilyHistoryPath", s"$rootPath/PatientFamilyHistory/")
      prop.setProperty("LanguagePath",s"$rootPath/PatientLanguage/")
      prop.setProperty("MedicationPath", s"$rootPath/PatientMedications/")
      prop.setProperty("PatientNotesPath", s"$rootPath/PatientNotes/")
      prop.setProperty("InsurancePath", s"$rootPath/PatientInsurance/")
      prop.setProperty("PlanOfCarePath", s"$rootPath/PatientPlanOfCare/")  //PatientPlanOfCare
      prop.setProperty("ProblemPath", s"$rootPath/PatientProblem/")
      prop.setProperty("ProcedurePath", s"$rootPath/PatientProcedures/")
      prop.setProperty("RacePath", s"$rootPath/PatientRace/")
      //prop.setProperty("ResultObservationPath",s"$rootPath/PatientNotesResultObservation/")
      //change path
      prop.setProperty("ResultObservationPath",s"$rootPath/PatientResultObservation/")

      prop.setProperty("StageDB","11_11_2018_polarisdb")
      prop.setProperty("s3Path","s3://bd-dev/11_11_2018_11GB/AllReg/POLARIS")
      val s3Path = prop.getProperty("s3Path")
      val StageDB = prop.getProperty("StageDB")

      prop.setProperty("HivePatientTableName",s"$StageDB.patient")                        //hive database and hive table name
      prop.setProperty("s3LocationPatient",s"$s3Path/Patient/")           //s3 path from hive table

      prop.setProperty("HivEncounterTableName",s"$StageDB.patientvisit")
      prop.setProperty("s3LocationEncounter",s"$s3Path/PatientVisit/")

      prop.setProperty("HiveProblemTableName",s"$StageDB.patientproblem")
      prop.setProperty("s3LocationProblem",s"$s3Path/PatientProblem/")

      prop.setProperty("HiveProcedureTableName",s"$StageDB.patientprocedure")
      prop.setProperty("s3LocationProcedure",s"$s3Path/PatientProcedure/")

      prop.setProperty("HiveMedicationTableName",s"$StageDB.patientmedication")
      prop.setProperty("s3LocationMedication",s"$s3Path/PatientMedication/")

      prop.setProperty("HiveImmunizationTableName","")
      prop.setProperty("s3LocationImmunization","")

      prop.setProperty("HiveResultObsTableName",s"$StageDB.patientresultobservation")
      prop.setProperty("s3LocationResObs",s"$s3Path/PatientResultObservation/")

      prop.setProperty("HiveVitalSignTableName",s"$StageDB.patientvitalsignobservation")
      prop.setProperty("s3LocationVitalsign",s"$s3Path/Patientvitalsignobservation/")

      prop.setProperty("HivePatientNotesTableName",s"$StageDB.patientnotes")
      prop.setProperty("s3LocationPatientNotes",s"$s3Path/PatientNotes/")



      Logger.getLogger("org").setLevel(Level.OFF)
      Logger.getLogger("akka").setLevel(Level.OFF)
      Logger.getLogger("myLogger").setLevel(Level.OFF)


    }
  }


