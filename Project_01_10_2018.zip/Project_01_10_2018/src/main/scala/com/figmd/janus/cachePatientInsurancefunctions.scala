package com.figmd.janus

import org.apache.spark.sql.{DataFrame, SparkSession}

class cachePatientInsurancefunctions(sparkSess : SparkSession, MasterInsurance : DataFrame) {

  import sparkSess.implicits._


  //Master Insurance not contain Code and CodeDescription column
  def InsuredRelationToPatientCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(MasterInsurance.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.InsuredRelationToPatientCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.PayerId".as("MasterInsuredRelationToPatientCode")
        , $"df2.PayerId".as("MasterInsuredRelationToPatientText"))

  }
}
