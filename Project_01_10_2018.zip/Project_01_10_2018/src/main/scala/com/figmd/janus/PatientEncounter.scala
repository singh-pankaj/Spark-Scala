package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.constant.ApplicationConfig.prop
import com.figmd.janus.util.{CommonFunc, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.types._
import java.text.SimpleDateFormat
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
class PatientEncounter(EncounterPath : String) {


  def cachePatientEncounterProcessing(sparkSess : SparkSession, DemoGraphicsDF : DataFrame
                                      ,conf : Config) = {

    //Start Encounter

    //Its Required
    // val df2 =CacheEncounter.withColumn("_c3", to_timestamp($"_c3", "MM/dd/yyyy HH:mm:ss")).select("_c3")

    import sparkSess.implicits._
    try {
      var CacheEncounter = CommonFunc.readFile(EncounterPath,sparkSess)

      //CacheEncounter.printSchema()

      val lookup4 = Map("_c0" -> "PatientId", "_c1" -> "EncounterTypeCode", "_c2" -> "EncounterTypeText", "_c3" -> "EncounterStartDate"
        , "_c4" -> "EncounterEndDate", "_c5" -> "ServiceProviderNPI", "_c6" -> "ServiceProviderLastName", "_c7" -> "ServiceProviderFirstName"
        , "_c8" -> "ServiceProviderRoleCode", "_c9" -> "ServiceProviderRoleText", "_c10" -> "ServiceLocationId"
        , "_c11" -> "ServiceLocationName", "_c12" -> "ServiceLocationRoleTypeCode", "_c13" -> "ServiceLocationRoleTypeText"
        , "_c14" -> "ReasonForVisit", "_c15" -> "Service_Location_AddressLine", "_c16" -> "Service_Location_City"
        , "_c17" -> "Service_Location_State", "_c18" -> "Service_Location_PostalCode", "_c19" -> "Encounter_Status"
        , "_c20" -> "EncounterTIN", "_c21" -> "EncounterKey", "_c22" -> "PracticeUid", "_c23" -> "BatchUid", "_c24" -> "dummy1", "_c25" -> "dummy2")

      println("orginal data.......")
      CacheEncounter = CacheEncounter.select(CacheEncounter.columns.map(c => col(c).as(lookup4.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")

     // date_format(unix_timestamp(col, "yyyyMMdd").cast("timestamp"), "yyyy-MM-dd")

      //CacheEncounter.show(30,false)
      // val CacheEncounterDate = CacheEncounter
         //.withColumn("EncounterStartDate", to_date($"EncounterStartDate", "yyyy-MM-dd HH:mm:ss")).show(50,false)
        //.withColumn("EncounterStartDate",to_date(unix_timestamp(CacheEncounter.col("EncounterStartDate"), "yyyy-MM-dd HH:mm:ss").cast("timestamp"))).show(50,false)
        .withColumn("EncounterStartDate", date_format(col("EncounterStartDate"), "yyyy-MM-dd HH:mm:ss")) // "MM/dd/yyyy"

        //.withColumn("EncounterStartDate", unix_timestamp(col("EncounterStartDate"), "yyyy-MM-dd HH:mm:ss").cast(TimestampType))
        //.withColumn("EncounterStartDate", to_timestamp($"EncounterStartDate", "MM/dd/yyyy HH:mm:ss"))
    // val dateS =  CacheEncounter.withColumn("EncounterStartDate",unix_timestamp($"EncounterStartDate", "yyyy-MM-dd HH:mm:ss").cast("timestamp"))
      //CacheEncounter.printSchema()
      /*val simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      val firstTimestampFromDfFormatted = simpleDateFormat.format(CacheEncounter)
      CacheEncounter.show(50,false)*/

      //val startdata = CacheEncounter.withColumn("EncounterStartDate", date_format($"EncounterStartDate", "MM/dd/yyyy"))

      //startdata.show(10,false)

      //CacheEncounter.printSchema()

       val dropDuplicates = CacheEncounter.dropDuplicates("PatientId", "ServiceProviderNPI", "ServiceLocationName"
        , "EncounterStartDate")
      // println("coount....." + dropDuplicates.count())


       val addPatientUid =  dropDuplicates.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PracticeUid","PatientId")).select($"df1.*",$"df2.PatientUid")

      //println("count2......."+addPatientUid.count())

      //addPatientUid.show(50, false)

      val tempData = addPatientUid.select("PatientId", "ServiceProviderNPI", "ServiceLocationName"
        , "EncounterStartDate").distinct()
        .withColumn("visitUid",CommonFunc.getNewUid())

      val tempVisitUid = tempData.persist()

      //tempVisitUid.show(50)

      val CacheEncounter2 = addPatientUid.as("df1").join(tempVisitUid.as("df2"),$"df1.PatientId" === $"df2.PatientId"
        &&  $"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" && $"df1.ServiceLocationName" === $"df2.ServiceLocationName"
        && $"df1.EncounterStartDate" === $"df2.EncounterStartDate")
        .select($"df1.*",$"df2.VisitUid")
        .drop("dummy1","dummy2")
      CacheEncounter2.select("PatientId", "ServiceProviderNPI", "ServiceLocationName", "EncounterStartDate")
      //println("count2   CacheEncounter2......."+CacheEncounter2.count())

      CacheEncounter2.show(50)

/*
      val distinctYear = addPatientUid.withColumn("Year",year($"EncounterStartDate")).select("Year").distinct()
      val distinctMonth = addPatientUid.withColumn("Month",month($"EncounterStartDate")).select("Month").distinct()
      val distinctPUid = addPatientUid.select("PracticeUid").distinct()

      val ListVal:Array[Any] = distinctYear.rdd.map(r => r(0)).collect()
      val PartitionYear = "(\"" + ListVal.mkString("\",\"") + "\")"

      val ListVal3:Array[Any] = distinctMonth.rdd.map(r => r(0)).collect()
      val PartitionMonth = "(\"" + ListVal3.mkString("\",\"") + "\")"

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val VisitData = sparkSess.sql(s"select * from figmdaaocdr.visit where" +
        s" practiceuid in $PartitionPUID and year in $PartitionYear and month in $PartitionMonth")

      println("VisitData Count....... VisitData  .....  "+VisitData.count())

       val PreviousPatient = addPatientUid.as("df1").join(VisitData.as("df2"),
        Seq("PatientId","PracticeUid","PatientUid"),"inner").select($"df1.*",$"df2.VisitUid")
         .distinct()

      println("PreviousPatient Count....... PreviousPatient  .....  "+PreviousPatient.count())

      val newVisit = addPatientUid.as("df1").join(VisitData.as("df2"),
        Seq("PatientId","PracticeUid","PatientUid"),"left_anti").select($"df1.*")

      println("newVisit Count....... newVisit  .....  "+newVisit.count())

      val tempData = newVisit.select("PatientId", "ServiceProviderNPI", "ServiceLocationName"
        , "EncounterStartDate").distinct()
        .withColumn("visitUid",CommonFunc.getNewUid())

         val tempVisitUid = tempData.persist()

      val CacheEncounter2 = newVisit.as("df1").join(tempVisitUid.as("df2"),$"df1.PatientId" === $"df2.PatientId"
        &&  $"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" && $"df1.ServiceLocationName" === $"df2.ServiceLocationName"
        && $"df1.EncounterStartDate" === $"df2.EncounterStartDate")
        .select($"df1.*",$"df2.VisitUid")
        .drop("dummy1","dummy2")

      val otherData = VisitData.as("df1").join(addPatientUid.as("df2"),
        Seq("PatientId","PracticeUid","PatientUid"),"left_anti").select($"df1.*").drop("year","month")

     // println("otherData Count....... otherData  .....  "+otherData.count())

      val VisitAllRecords = PreviousPatient.union(CacheEncounter2).union(otherData)*/

     /* val CombineData = VisitAllRecords.withColumn("Year",year($"EncounterStartDate"))
        .withColumn("Month",month($"EncounterStartDate"))*/

      val CombineData = CacheEncounter2.withColumn("Year",year($"EncounterStartDate"))
      val tempTableName = prop.getProperty("HivEncounterTableName")   //HivEncounterTableName
      val TableName = conf.getString("db_tb_Visit")
      val s3path = prop.getProperty("s3LocationEncounter")
      //println("Encounter count ....."+CombineData.count)
      HiveUtility.dfwritrtohiveVisit(CombineData,TableName,sparkSess,tempTableName,s3path)
    }
    catch {
      case ex: FileNotFoundException => {
       ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }
  }
}
