package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientSocialHistoryObs(SocialHistoryPath : String) {


  def cacheSocialHistoryObsProcessing(sparkSess : SparkSession, mappingpracticecommondatamaster : DataFrame)
  : Option[DataFrame] = {


    try {
      val file = CommonFunc.readFile(SocialHistoryPath,sparkSess)

      val lookup1 = Map("_c0" -> "PatientId", "_c1" -> "SocialHistoryTypeCode", "_c2" -> "SocialHistoryTypeText", "_c3" -> "SocialHistoryObservedValue",
        "_c4" -> "DocumentationDate", "_c5" -> "EffectiveStopDate", "_c6" -> "SocialHistoryStatusCode",
        "_c7" -> "SocialHistoryStatusText", "_c8" -> "YearsSmoked", "_c9" -> "QuitYear", "_c10" -> "SocialHxGroup",
        "_c11" -> "EffectiveStartDate", "_c12" -> "SocialHistoryObservationKey", "_c13" -> "PracticeUid", "_c14" -> "BatchUid", "_c15" -> "dummy1", "_c16" -> "dummy2")

      val cachePatientSocialHistoryObs = file.select(file.columns.map(c => col(c).as(lookup1.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")

      val tf = new CachePatientSocialHistoryObs(sparkSess, mappingpracticecommondatamaster)

      val cacheSocialHistoryObs3 = cachePatientSocialHistoryObs
        .transform(tf.SocialHistoryTypeCode)
        .transform(tf.SocialHistoryTypeText)
        .transform(tf.SocialHistoryStatusCode)
        .transform(tf.SocialHistoryStatusText)

      val cacheSocialHistoryObs4 = cacheSocialHistoryObs3.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("SocialHistoryStatusCode", "SocialHistoryStatusText"
          , "SocialHistoryTypeText", "EffectiveStopDate", "MasterSocialHistoryTypeCode", "MasterSocialHistoryStatusCode"
          , "MasterSocialHistoryStatusText", "SocialHistoryTypeCode", "QuitYear", "EffectiveStartDate", "SocialHxGroup"
          , "DocumentationDate", "MasterSocialHistoryTypeText", "SocialHistoryObservationKey", "YearsSmoked", "PracticeUid"
          , "SocialHistoryObservedValue")).as("SocialHistoryObservation"))

      Some(cacheSocialHistoryObs4)
    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }

}
