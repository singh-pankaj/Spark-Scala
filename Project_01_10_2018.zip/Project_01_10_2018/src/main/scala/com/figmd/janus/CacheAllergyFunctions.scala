package com.figmd.janus

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

class CacheAllergyFunctions(sparkSess : SparkSession, masterAllergy : DataFrame
                            ,mappingpracticecommondatamaster : DataFrame) {
  import sparkSess.implicits._
  def AllergicToCode(df: DataFrame): DataFrame = {
    df
       .as("df1").join(masterAllergy.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AllergicToCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterAllergicToCode")
        ,$"df2.CodeDescription".as("MasterAllergyDescription"))
  }


  def AllergicToDescription(df: DataFrame): DataFrame = {
    df
      .as("df1").join(masterAllergy.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AllergicToDescription" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterAllergicToCode")
        ,$"df2.CodeDescription".as("MappedMasterAllergyDescription"))
      .withColumn("MasterAllergicToCode",when($"MappedMasterAllergicToCode".isNull,$"MasterAllergicToCode")
      .otherwise($"MappedMasterAllergicToCode"))
      .withColumn("MasterAllergyDescription",when($"MappedMasterAllergyDescription".isNull,$"MasterAllergyDescription")
        .otherwise($"MappedMasterAllergyDescription"))
      .drop("MappedMasterAllergicToCode","MappedMasterAllergyDescription")
  }


  def AllergyStatusCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AllergyStatusCode" === $"df2.PracticeValue"
        ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterAllergyStatusCode")
        ,$"df2.CodeDescription".as("MasterAllergyStatusText"))
  }

  def AllergyStatusText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AllergyStatusText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterAllergyStatusCode",when($"MappedValue1".isNull,$"MasterAllergyStatusCode")
        .otherwise($"MappedValue1"))
      .withColumn("MasterAllergyStatusText",when($"MappedValue2".isNull,$"MasterAllergyStatusText")
        .otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }


}



