package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.constant.ApplicationConfig.prop
import com.figmd.janus.util.{CommonFunc, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
class PatientNote(PatientNotePath : String) {


  def PatientNoteProcessing(sparkSess : SparkSession, conf : Config, DemoGraphicsDF : DataFrame) {


    try {
      import sparkSess.implicits._
      val CachePatientNotesFile = CommonFunc.readFile(PatientNotePath, sparkSess)

      val CachePatientNoteslookup = Map("_c0" -> "PatientId", "_c1" -> "EncounterDate", "_c2" -> "SectionName", "_c3" -> "Note",
        "_c4" -> "ServiceProviderNPI", "_c5" -> "ServiceProviderLastName", "_c6" -> "ServiceProviderFirstName",
        "_c7" -> "ServiceLocationId", "_c8" -> "ServiceLocationName", "_c9" -> "Group1", "_c10" -> "Group2", "_c11" -> "Group3",
        "_c12" -> "Group4", "_c13" -> "PracticePatientNoteKey", "_c14" -> "PracticeUid", "_c15" -> "BatchUid"
        , "_c16" -> "dummy1", "_c17" -> "dummy2")

      val CachePatientNotes = CachePatientNotesFile.select(CachePatientNotesFile.columns.map(c => col(c).as(CachePatientNoteslookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("EncounterDate", to_timestamp($"EncounterDate", "MM/dd/yyyy HH:mm:ss"))
      //CachePatientNotes.printSchema()

      val addPatientUid = CachePatientNotes.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PracticeUid","PatientId"))
        .select($"df1.*", $"df2.PatientUid")

/*
      val distinctYear = addPatientUid.withColumn("Year",year($"referencedDate")).select("Year").distinct()
      val distinctMonth = addPatientUid.withColumn("Month",month($"referencedDate")).select("Month").distinct()
      val distinctPUid = addPatientUid.select("PracticeUid").distinct()

      val ListVal:Array[Any] = distinctYear.rdd.map(r => r(0)).collect()
      val PartitionYear = "(\"" + ListVal.mkString("\",\"") + "\")"

      val ListVal3:Array[Any] = distinctMonth.rdd.map(r => r(0)).collect()
      val PartitionMonth = "(\"" + ListVal3.mkString("\",\"") + "\")"

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val PatientNoteData = sparkSess.sql(s"select * from figmdaaocdr.patientnotes where" +
        s" practiceuid in $PartitionPUID and year in $PartitionYear and month in $PartitionMonth")
        .drop("year","month").drop("dummy1","dummy2")

      val PreviousandNewData = addPatientUid.as("df1").join(PatientNoteData.as("df2")
        , Seq("PatientId","PatientUid", "PracticeUid"), "inner")
        .select($"df1.*")

      val otherData = PatientNoteData.as("df1").join(addPatientUid.as("df2")
        , Seq("PatientId","PatientUid", "PracticeUid"), "left_anti")
        .select($"df1.*")

      /*val newData = addPatientUid.as("df1").join(PatientNoteData.as("df2")
        , Seq("PatientId","PatientUid", "PracticeUid"), "left_anti")
        .select($"df1.*")*/

      val allPatientNoteData = PreviousandNewData.union(otherData)

      val tableName = conf.getString("db_tb_PatientNote")

      val CombineData = allPatientNoteData.withColumn("Year", year($"referencedDate"))
        .withColumn("Month", month($"referencedDate"))*/

      val tableName = conf.getString("db_tb_PatientNote")
      val CombineData = addPatientUid.withColumn("Year", year($"EncounterDate"))

      val tempTableName = prop.getProperty("HivePatientNotesTableName")
      val s3path = prop.getProperty("s3LocationPatientNotes")
      HiveUtility.dfwritrtohiveVisit(CombineData, tableName, sparkSess, tempTableName,s3path)
    }
    catch {
      case ex: FileNotFoundException => {
      ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        unknown.printStackTrace()
        None
      }
    }
  }
}
