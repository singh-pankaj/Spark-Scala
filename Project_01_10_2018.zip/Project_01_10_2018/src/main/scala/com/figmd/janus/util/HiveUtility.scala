package com.figmd.janus.util


import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.sql.functions.year
import org.apache.spark.sql.functions._

object HiveUtility {



  def dfwritrtohivePatient(df : DataFrame, tablename : String,spark : SparkSession, tempTableName : String,s3Path : String)
  : Unit = {

   // spark.sql(s"drop table if exists figmdcdr_temp.patient")
   // println("Patient Data Write to hive tables.........")

    //df.write.insertInto(tempTableName)
      df.write
      .partitionBy("PracticeUid")
      .mode("overwrite")
      .option("path",s3Path)
      .saveAsTable(tempTableName)
   // spark.sql(s"insert overwrite table $tablename partition(PracticeUid,year) select * from $tempTableName")

  }

  def dfwritrtohiveVisit(df : DataFrame, tablename : String,spark : SparkSession,tempTableName : String,s3path : String): Unit =
  {
   // println("Visit........")
    //println(s3path)
   // println(tempTableName)

    //df.write.insertInto(tempTableName)
     df
      .write
      .partitionBy("PracticeUid")
      .mode("overwrite")
      .option("path",s3path)
      .saveAsTable(tempTableName)

  }

  /*def commonHiveFunction(df : DataFrame,tableName : String, tempTableName : String
                         , PracticeUid : String, Year : Column, Month : Column): Unit = {

    sparkSess.sql(s"drop table if exists $tempTableName")
    println("temp table delete.......................")
    df.write.partitionBy(s"$PracticeUid",s"$Year",s"$Month").saveAsTable(tempTableName)
    println("data insert into temp table.......................")
    sparkSess.sql(s"insert overwrite table $tableName partition($PracticeUid,$Year,$Month) select  * from $tempTableName")
    println("end...............................................................")

  }*/


}
