package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

class PatientInsurance(InsurancePath : String) {

def cachePatientinsuranceprocessing(sparkSess : SparkSession, MasterInsurance : DataFrame) : Option[DataFrame] ={

  import sparkSess.implicits._

  //Start CachePayer

  try {
    var CachePayer = CommonFunc.readFile(InsurancePath,sparkSess)

    val lookup5 = Map("_c0" -> "PatientId", "_c1" -> "InsuredPersonId", "_c2" -> "InsuranceCompany", "_c3" -> "InsurancePlan"
      , "_c4" -> "InsuranceGroup", "_c5" -> "InsuranceOrder", "_c6" -> "InsuredRelationToPatientCode"
      , "_c7" -> "InsuredRelationToPatientText", "_c8" -> "DocumentationDate", "_c9" -> "EndDateOfInsurance"
      , "_c10" -> "IsInsuredSameAsGuarantor", "_c11" -> "PayerID", "_c12" -> "PolicyID", "_c13" -> "PayerCity"
      , "_c14" -> "PayerState", "_c15" -> "PayerZip", "_c16" -> "Insurance_Active"
      , "_c17" -> "StartDateOfInsurance", "_c18" -> "BillingInsurance", "_c19" -> "PayerKey"
      , "_c20" -> "PracticeUid", "_c21" -> "BatchUid", "_c22" -> "dummy1", "_c23" -> "dummy2")

    CachePayer = CachePayer.select(CachePayer.columns.map(c => col(c).as(lookup5.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    val InsuranceObj = new cachePatientInsurancefunctions(sparkSess, MasterInsurance)

    val CachePayer1 = CachePayer
      .transform(InsuranceObj.InsuredRelationToPatientCode)

    val CachePayer2 = CachePayer1.groupBy("PatientId","PracticeUid")
      .agg(collect_list(struct("PayerState", "Insurance_Active", "EndDateOfInsurance", "InsurancePlan"
        , "PayerID", "IsInsuredSameAsGuarantor", "BillingInsurance", "InsuredPersonId", "PatientId", "PayerCity"
        , "MasterInsuredRelationToPatientText", "InsuranceOrder", "StartDateOfInsurance", "MasterInsuredRelationToPatientCode"
        , "PayerZip", "InsuranceCompany", "DocumentationDate", "InsuredRelationToPatientCode", "InsuredRelationToPatientText"
        , "PracticeUid", "PayerKey", "PolicyID", "InsuranceGroup")).as("Insurance"))

    Some(CachePayer2)
  }
  catch {
    case ex: FileNotFoundException => {
      ex.printStackTrace()
      None
    }
    case unknown: Exception => {
      println(s"Unknown exception: $unknown")
      None
    }
  }
}
}
