package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.constant.ApplicationConfig.prop
import com.figmd.janus.util.{CommonFunc, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
class PatientVitalSignObservation(VitalSignPath : String) {

  def VitalSignObservationProcessing(spark: SparkSession, mappingpracticecommondatamaster : DataFrame
                                       ,conf : Config, DemoGraphicsDF : DataFrame) = {
    import spark.implicits._

    /*
  //Create map of file indices and column names
  val cachePatientVitalSignObservationMapDF: Dataset[Row] = rt.joinedDf
    .filter($"CacheTableViewName"==="ViewCachePatientVitalSignObservation")
  val lookup: collection.Map[String, String] = getLookupMap(cachePatientVitalSignObservationMapDF)
  */

    try {
      val lookup = Map("_c0" -> "PatientId", "_c1" -> "ObservationCode", "_c2" -> "ObservationName",
        "_c3" -> "ObservationCategory", "_c4" -> "ObservationDate", "_c5" -> "ObservationValue"
        , "_c6" -> "ObsInterpretationCode", "_c7" -> "ObsInterpretationText"
        , "_c8" -> "TargetSiteCode", "_c9" -> "TargetSiteText", "_c10" -> "NegationInd",
        "_c11" -> "ReferenceLowerRange", "_c12" -> "ReferenceUpperRange", "_c13" -> "MethodCode"
        , "_c14" -> "MethodCodeText", "_c15" -> "ResultOBSUnit", "_c16" -> "VitalSignsKey"
        , "_c17" -> "PracticeUid", "_c18" -> "BatchUid")

      println("start....")

      //Read file for CachePatientVitalSignObservation
      /*val CachePatientVitalSignObservationDF: DataFrame = CommonFunc.readFile(VitalSignPath,spark).drop("_c19", "_c20")
        .withColumn("ObservationDate", to_timestamp($"ObservationDate", "MM/dd/yyyy HH:mm:ss"))

      CachePatientVitalSignObservationDF.printSchema()*/
      val cachePatientVitalSignObservatio = CommonFunc.readFile(VitalSignPath,spark)
     // VitalSignPath

      //Apply lookup to generate file Header
      val CachePatientVitalSignObservationDF: DataFrame = cachePatientVitalSignObservatio.select(cachePatientVitalSignObservatio.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)
        .drop("_c19", "_c20")
        .withColumn("ObservationDate", to_timestamp($"ObservationDate", "MM/dd/yyyy HH:mm:ss"))

      //CachePatientVitalSignObservationDF.printSchema()

      val addPatientUid =  CachePatientVitalSignObservationDF.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PracticeUid","PatientId"))
        .select($"df1.*",$"df2.PatientUid")

      val patientVitalSignObservationDF = new CachePatientVitalSignObservationFunctions(spark, mappingpracticecommondatamaster)


      val transformPatientVitalSignObservationDF = addPatientUid
        .transform(patientVitalSignObservationDF.PracticeDescription)
        .transform(patientVitalSignObservationDF.PracticeCode)
        .transform(patientVitalSignObservationDF.TargetSiteText)
        .transform(patientVitalSignObservationDF.TargetSiteCode)
        .transform(patientVitalSignObservationDF.ObsInterpretationText)
        .transform(patientVitalSignObservationDF.ObsInterpretationCode)

      /*val distinctYear = transformPatientVitalSignObservationDF.withColumn("Year",year($"ObservationDate")).select("Year").distinct()
      val distinctMonth = transformPatientVitalSignObservationDF.withColumn("Month",month($"ObservationDate")).select("Month").distinct()
      val distinctPUid = transformPatientVitalSignObservationDF.select("PracticeUid").distinct()

      val ListVal:Array[Any] = distinctYear.rdd.map(r => r(0)).collect()
      val PartitionYear = "(\"" + ListVal.mkString("\",\"") + "\")"

      val ListVal3:Array[Any] = distinctMonth.rdd.map(r => r(0)).collect()
      val PartitionMonth = "(\"" + ListVal3.mkString("\",\"") + "\")"

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val VitalSignData = spark.sql(s"select * from figmdaaocdr.patientvitalsignobservation where" +
        s" practiceuid in $PartitionPUID and year in $PartitionYear and month in $PartitionMonth")
        .drop("year","month")

      val PreviousandNewData = transformPatientVitalSignObservationDF.as("df1").join(VitalSignData.as("df2")
        ,Seq("PatientId","PatientUid","PracticeUid"),"inner")
        .select($"df1.*")

      val otherData = VitalSignData.as("df1").join(transformPatientVitalSignObservationDF.as("df2")
        ,Seq("PatientId","PatientUid","PracticeUid"),"left_anti")
        .select($"df1.*")
/*
      val newData = transformPatientVitalSignObservationDF.as("df1").join(VitalSignData.as("df2")
        ,Seq("PatientId","PatientUid","PracticeUid"),"left_anti")
        .select($"df1.*")*/

      val allVitalSignData = PreviousandNewData.union(otherData)

      val tableName = conf.getString("db_tb_VitSign")
      val CombineData = allVitalSignData.as("df1").withColumn("Year",year($"df1.ObservationDate"))
        .withColumn("Month",month($"df1.ObservationDate"))*/

      val tableName = conf.getString("db_tb_VitSign")
      val CombineData = transformPatientVitalSignObservationDF.as("df1").withColumn("Year",year($"df1.ObservationDate"))

      val tempTableName = prop.getProperty("HiveVitalSignTableName")
      val s3path = prop.getProperty("s3LocationVitalsign")

      println("data write to hive......")
      HiveUtility.dfwritrtohiveVisit(CombineData,tableName,spark,tempTableName,s3path)
    }
    catch {
      case ex: FileNotFoundException => {
       ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }
}
