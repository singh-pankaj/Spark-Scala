package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

class PatientEthnicity(EthnicityPath : String) {


  def EthinicityProccessing(sparkSess : SparkSession,MasterEthnicity : DataFrame) : Option[DataFrame] = {

    //import sparkSess.implicits._
    try {
      /*var CacheEthnicityTable = sparkSess.read.option("delimiter", "\u0017").option("inferSchema", "true")
        .csv("temp_test/AllFiles/part_a06375b5-51cc-4028-88ea-1690c4e7b2e7.txt")*/

      var CacheEthnicityTable = CommonFunc.readFile(EthnicityPath,sparkSess)

      val lookup2 = Map("_c0" -> "PatientId", "_c1" -> "PatientEthnicityCode", "_c2" -> "PatientEthnicityText"
        , "_c3" -> "PatientEthnicityKey", "_c4" -> "PracticeUid"
        , "_c5" -> "BatchUid", "_c6" -> "dummy1", "_c7" -> "dummy2")

      CacheEthnicityTable = CacheEthnicityTable.select(CacheEthnicityTable.columns.map(c => col(c).as(lookup2.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")

      val CleanedData = CacheEthnicityTable.dropDuplicates("PatientId","PatientEthnicityText")
      val tf1 = new CacheEthnicityFunction(sparkSess, MasterEthnicity)

      val cacheAllergy3 = CleanedData
        .transform(tf1.PatientEthnicityText)
        .transform(tf1.PatientEthnicityCode)


      val CacheEthnicity = cacheAllergy3.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("PatientEthnicityText", "PatientEthnicityCode", "MasterPatientEthnicityText"
          , "MasterPatientEthnicityCode")).as("Ethnicity"))

      Some(CacheEthnicity)
    }
      catch {
        case ex: FileNotFoundException => {
          ex.printStackTrace()
          None
        }
        case unknown: Exception => {
          println(s"Unknown exception: $unknown")
          None
        }
      }

    }
}
