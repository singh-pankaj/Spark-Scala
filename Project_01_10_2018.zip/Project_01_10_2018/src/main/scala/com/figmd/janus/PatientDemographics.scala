package com.figmd.janus


import java.io.FileNotFoundException

import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import java.text.SimpleDateFormat
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientDemographics(DemoPath : String) {



  def demoProcessing(sparkSess : SparkSession) : Option[DataFrame] = {



    import sparkSess.implicits._

    try{

      val CachepatientDemo = CommonFunc.readFile(DemoPath,sparkSess)
      println("file path..." +DemoPath)

      val lookup = Map("_c0" -> "PatientId", "_c1" -> "LastName", "_c2" -> "FirstName", "_c3" -> "MiddleName", "_c4" -> "StreetLineAddress1"
        , "_c5" -> "StreetLineAddress2", "_c6" -> "StreetLineAddress3", "_c7" -> "StreetLineAddress4", "_c8" -> "City", "_c9" -> "StateCode"
        , "_c10" -> "State", "_c11" -> "ZipCode", "_c12" -> "CountryCode", "_c13" -> "Country", "_c14" -> "TelecomTypeText1"
        , "_c15" -> "TelecomValue1", "_c16" -> "TelecomTypeText2", "_c17" -> "TelecomValue2", "_c18" -> "Gender", "_c19" -> "DOB"
        , "_c20" -> "DeathDate", "_c21" -> "MaritalStatusCode", "_c22" -> "MaritalStatusText", "_c23" -> "ReligiousAffiliationCode"
        , "_c24" -> "ReligiousAffiliationText", "_c25" -> "BirthStateCode", "_c26" -> "BirthState", "_c27" -> "BirthZipCode"
        , "_c28" -> "BirthCountryCode", "_c29" -> "BirthCountry", "_c30" -> "ServiceProviderNPI", "_c31" -> "ServiceProviderLastName"
        , "_c32" -> "ServiceProviderFirstName", "_c33" -> "SSN", "_c34" -> "DeathReason", "_c35" -> "IsDeceased", "_c36" -> "Patient_EMR_ID"
        , "_c37" -> "EmailID", "_c38" -> "LocationOfDeath", "_c39" -> "BirthOrder", "_c40" -> "MultipleBirthPlaceIndicator"
        , "_c41" -> "PatientDemographicsKey", "_c42" -> "PracticeUid","_c43" -> "BatchUid")


      val CachepatientDemo1 = CachepatientDemo.select(CachepatientDemo.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)
        .drop("_c44","_c45")

      //CachepatientDemo1.show(50,false)

      val CachepatientDemo2 =  CachepatientDemo1.withColumn("DOB", to_timestamp(col("DOB"), "yyyy-MM-dd HH:mm:ss"))

//      val CachepatientDemo2 =  CachepatientDemo1.withColumn("DOB", unix_timestamp(col("DOB"), "yyyy-MM-dd").cast(TimestampType))

//      val CachepatientDemo2 =  CachepatientDemo1.withColumn("DOB", to_date(col("DOB"), "yyyy-MM-dd HH:mm:ss"))
        //.withColumn("EncounterStartDate", date_format(col("EncounterStartDate"), "yyyy-MM-dd HH:mm:ss"))

     // val CachepatientDemo2 =  CachepatientDemo1.withColumn("DOB", date_format(col("DOB"), "yyyy-MM-dd HH:mm:ss"))


      val CleanedRecords = CachepatientDemo2.dropDuplicates("PatientId","PracticeUid")

      val tempPatUid = CleanedRecords.select("PatientId", "PracticeUid").distinct()
        .withColumn("PatientUid",CommonFunc.getNewUid())

      //tempPatUid.coalesce(1).write.format("csv").save("s3://bd-dev/writetest/new1/")

      val PatUid = tempPatUid.persist()

      val CachepatientDemo3 = CleanedRecords.as("df1").join(PatUid.as("df2")
        ,   $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")

      //CachepatientDemo3.show(20,false)

      Some(CachepatientDemo3)
/*
      val distinctYear = CleanedRecords.withColumn("Year",year($"DOB")).select("Year").distinct()
      val distinctPUid = CleanedRecords.select("PracticeUid").distinct()

      val ListVal:Array[Any] = distinctYear.rdd.map(r => r(0)).collect()
      val PartitionYear = "(\"" + ListVal.mkString("\",\"") + "\")"

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"


      val RequiredData = sparkSess.sql(s"select * from figmdaaocdr.patient where" +
        s" practiceuid in $PartitionPUID and year in $PartitionYear")
        .drop("ethnicity","race","language","socialhistoryobservation"
          ,"insurance","advancedirectives","allergy","planofcare","patientfamilyhistory"
          ,"patientguardian","Year")
      println("RequiredData Demo Data.....  "+RequiredData.count())

       val PreviousPatient = CleanedRecords.as("df1").join(RequiredData.as("df2"),
        Seq("PatientId","PracticeUid"),"inner").select($"df1.*",$"df2.PatientUid")
        .drop("Year")

      println("PreviousPatient Demo Data.....  "+PreviousPatient.count())

      val newPatient =  CleanedRecords.as("df1").join(RequiredData.as("df2"),
        Seq("PatientId","PracticeUid"),"left_anti").select($"df1.*")

      println("newPatient Demo Data.....  "+newPatient.count())

      val tempPatUid = newPatient.select("PatientId", "PracticeUid").distinct()
        .withColumn("PatientUid",CommonFunc.getNewUid())

      val PatUid = tempPatUid.persist()

      val CachepatientDemo2 = newPatient.as("df1").join(PatUid.as("df2")
        , $"df1.PatientId" === $"df2.PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
        .select($"df1.*", $"df2.PatientUid")

      val OtherPatient =  RequiredData.as("df1").join(CleanedRecords.as("df2"),
        Seq("PatientId","PracticeUid"),"left_anti").select($"df1.*")
        .drop("Year")

      //println("OtherPatient Demo Data.....  "+OtherPatient.count())

      val allRecords = PreviousPatient.union(CachepatientDemo2).union(OtherPatient)*/
      //Some(allRecords)
    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }

  }
}
