package com.figmd.janus


import java.io.FileNotFoundException

import com.figmd.janus.constant.ApplicationConfig
import com.figmd.janus.util.{JoinDFUtil, ReadTables, SparkUtility}
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.functions._
import org.apache.log4j.{Level, Logger}
object CDRProcessor1 {


  def main(args: Array[String]): Unit = {

    try{

      ApplicationConfig.setApplicationConfig(args)

    Logger.getLogger("org").setLevel(Level.WARN)
    Logger.getLogger("akka").setLevel(Level.WARN)

    val conf = ConfigFactory.load("application.conf")

    val sparkUtility = new SparkUtility()
    val sparkSess = sparkUtility.getSparkSession()
    val ReadTBL = new ReadTables


    //println("Start programme............................")
    val masterAllergy = ReadTBL.getPostgresTable(sparkSess, ApplicationConfig.prop.getProperty("Allergy"))
    broadcast(masterAllergy)

    val mappingPracticeProcedure = ReadTBL.getPostgresTable(sparkSess, ApplicationConfig.prop.getProperty("Procedure"))
    broadcast(mappingPracticeProcedure)

    val mappingpracticecommondatamaster = ReadTBL.getPostgresTable(sparkSess, ApplicationConfig.prop.getProperty("Procedure"))
    broadcast(mappingpracticecommondatamaster)

    val mappingpracticecommondatamasterethnicity = ReadTBL.getPostgresTable(sparkSess, ApplicationConfig.prop.getProperty("Ethinicity"))
    broadcast(mappingpracticecommondatamasterethnicity)

    val mappingpracticecommondatamasterrace = ReadTBL.getPostgresTable(sparkSess, ApplicationConfig.prop.getProperty("Race"))
    broadcast(mappingpracticecommondatamasterrace)

    val mappingpracticeinsurancedata = ReadTBL.getPostgresTable(sparkSess, ApplicationConfig.prop.getProperty("Insurance"))
    broadcast(mappingpracticeinsurancedata)

    val MappingPracticeProblem = ReadTBL.getPostgresTable(sparkSess, ApplicationConfig.prop.getProperty("Problem"))
    broadcast(MappingPracticeProblem)

    val MappingPracticeMedication = ReadTBL.getPostgresTable(sparkSess, ApplicationConfig.prop.getProperty("Medication"))
    broadcast(MappingPracticeMedication)

    val MappingPracticeCommonDataMasterMedicationRoute = ReadTBL.getPostgresTable(sparkSess, ApplicationConfig.prop.getProperty("Route"))
    broadcast(MappingPracticeCommonDataMasterMedicationRoute)

    val mappingracticecommondatamasterrelationship = ReadTBL.getPostgresTable(sparkSess, ApplicationConfig.prop.getProperty("RelationShip"))
    broadcast(mappingracticecommondatamasterrelationship)

   // println("Start........PatientDemographics")
    val PatientDemoDF = new PatientDemographics(ApplicationConfig.prop.getProperty("DemoPath")).demoProcessing(sparkSess).toList

    val DemoGraphicsDF = PatientDemoDF.head.select("PatientId", "PracticeUid", "PatientUid")

    broadcast(DemoGraphicsDF)
   // println("Start........PatientEthnicity")
    val PatientEthnicityDF = new PatientEthnicity(ApplicationConfig.prop.getProperty("EthinicityPath"))
      .EthinicityProccessing(sparkSess,mappingpracticecommondatamasterethnicity).toList

    //println("Start........PatientRace")
    val PatientraceDF = new PatientRace(ApplicationConfig.prop.getProperty("RacePath"))
      .cacheRaceProcessing(sparkSess, mappingpracticecommondatamasterrace).toList

   // println("Start........PatientEncounter")

    val CacheEncounterDF = new PatientEncounter(ApplicationConfig.prop.getProperty("EncounterPath"))
      .cachePatientEncounterProcessing(sparkSess,DemoGraphicsDF, conf)

     val CachepatientInsuranceDF = new PatientInsurance(ApplicationConfig.prop.getProperty("InsurancePath"))
      .cachePatientinsuranceprocessing(sparkSess, mappingpracticeinsurancedata).toList
    //println("Start........PatientProblem")

    val PatientProblemDF = new PatientProblem(ApplicationConfig.prop.getProperty("ProblemPath"))
      .cachePatientProblemProcessing(sparkSess, MappingPracticeProblem, conf, DemoGraphicsDF)

   // println("Start........PatientProcedure")
    val PatientProcedureDF = new PatientProcedure(ApplicationConfig.prop.getProperty("ProcedurePath"))
      .cachePatientProcedureProceesing(sparkSess, mappingPracticeProcedure, mappingpracticecommondatamaster
        , conf, DemoGraphicsDF)

    val PatientAdvanceDirectiveDF = new PatientAdvanceDirectiveObservation(ApplicationConfig.prop.getProperty("AdvanceDirectivePath"))
      .cacheAdvObsProcessing(sparkSess, mappingpracticecommondatamaster).toList

    val PatientAllergyDF = new PatientAllergy(ApplicationConfig.prop.getProperty("AllergiesPath"))
      .cacheAllergyProcessing(sparkSess, masterAllergy, mappingpracticecommondatamaster).toList

   // println("Start........Medication")
    val PatientMedicationDF = new Medications(ApplicationConfig.prop.getProperty("MedicationPath"))
      .CacheMedicationsProcessing(sparkSess, mappingPracticeProcedure, MappingPracticeMedication, mappingpracticecommondatamaster
        , conf, DemoGraphicsDF)

    /*val PatientImmunizationDF = new PatientImmunization(ApplicationConfig.prop.getProperty("ImmunizationPath"))
      .ImmunizationProcessing(sparkSess, mappingpracticecommondatamaster,
        MappingPracticeCommonDataMasterMedicationRoute, mappingPracticeProcedure,
        MappingPracticeProblem, mappingpracticecommondatamaster, DemoGraphicsDF, conf)*/

    val PatientPlanOfCareDF = new PatientPlanOfCare(ApplicationConfig.prop.getProperty("PlanOfCarePath"))
      .PlanOfCareProcessing(sparkSess, mappingpracticecommondatamaster).toList

    //println("Start........ResultObservation")
    val PatientresultObservationbDF = new PatientresultObservation(ApplicationConfig.prop.getProperty("ResultObservationPath"))
      .cacheresultObsProcessing(sparkSess, mappingpracticecommondatamaster, mappingPracticeProcedure, conf,DemoGraphicsDF)

    val PatientSocialHistoryObsDF = new PatientSocialHistoryObs(ApplicationConfig.prop.getProperty("SocialHistoryObsPath"))
      .cacheSocialHistoryObsProcessing(sparkSess, mappingpracticecommondatamaster).toList
    //println("Start........Vitalsignobservation")

   val PatientVitalSignDF = new PatientVitalSignObservation(ApplicationConfig.prop.getProperty("VitalSignPath"))
      .VitalSignObservationProcessing(sparkSess, mappingpracticecommondatamaster, conf, DemoGraphicsDF)

    val PatientFamilyHistoryDF = new PatientFamilyHistory(ApplicationConfig.prop.getProperty("FamilyHistoryPath"))
      .FamilyHistoryProcessing(sparkSess, mappingracticecommondatamasterrelationship, mappingpracticecommondatamaster
        , MappingPracticeProblem)

    /*val PatientGuardianDF = new PatientGuardian(ApplicationConfig.prop.getProperty("PatientGuardianPath"))
      .PatientGuardianProcessing(sparkSess).toList*/

    val PatientLanguageDF = new PatientLanguage(ApplicationConfig.prop.getProperty("LanguagePath"))
      .cachepatientLangProcessing(sparkSess).toList

    println("Start........PatientNote")
    val PatientNotesDF = new PatientNote(ApplicationConfig.prop.getProperty("PatientNotesPath"))
      .PatientNoteProcessing(sparkSess,conf,DemoGraphicsDF)

   val dflist = PatientDemoDF ++ PatientEthnicityDF ++ PatientraceDF ++ PatientLanguageDF ++ PatientSocialHistoryObsDF ++ CachepatientInsuranceDF ++ PatientPlanOfCareDF ++ PatientAdvanceDirectiveDF ++ PatientAllergyDF ++ PatientFamilyHistoryDF //++ PatientGuardianDF

    val joinDF = new JoinDFUtil(sparkSess, conf)
    joinDF.sendPatientToHive(dflist)
      println("end ............................................")
  }
    catch {
      case ex: FileNotFoundException => {
       ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }

    //val PatientLabOrderDF = (new PatientLabOrder(ApplicationConfig.prop.getProperty("PatientLabOrderPath")))
    // .CachePatientLabOrder(sparkSess)

    //val EncounterDiagnosisDF = (new PatientEncounterDiagnosis(ApplicationConfig.prop.getProperty("EncounterDiagnosisPath")))
    // .CachePatientEncounterDiagnosis(sparkSess)
  }


}

