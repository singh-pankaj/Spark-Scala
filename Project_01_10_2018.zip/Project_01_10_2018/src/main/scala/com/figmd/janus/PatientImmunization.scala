package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.util.{CommonFunc, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

class PatientImmunization(ImmunizationPath : String) {

  def ImmunizationProcessing(spark: SparkSession, mappingpracticecommondatamaster: DataFrame,
                               MappingPracticeCommonDataMasterMedicationRoute: DataFrame, MappingPracticeProcedure: DataFrame,
                               MappingPracticeProblem: DataFrame, MappingPracticeCommonDataMaster: DataFrame
                               , DemoGraphicsDF : DataFrame,conf : Config)
                                 {
    import spark.implicits._

    //Read required tables for CachePatientImmunization

    /*
    //Create map of file indices and column names
    val cachePatientImmunizationMapDF: Dataset[Row] = rt.joinedDf
      .filter($"CacheTableViewName"==="ViewCachePatientImmunization")
    val lookup: collection.Map[String, String] = getLookupMap(cachePatientImmunizationMapDF)
  */

try {
  val lookup = Map("_c0" -> "PatientId", "_c1" -> "ImmunizationCode", "_c2" -> "ImmunizationName",
    "_c3" -> "ImmunizationCategory", "_c4" -> "ImmuStartDate", "_c5" -> "ImmuStopDate", "_c6" -> "AdministeredEffectiveDate",
    "_c7" -> "ServiceProviderNPI", "_c8" -> "ServiceProviderLastName", "_c9" -> "ServiceProviderFirstName",
    "_c10" -> "RepeatNumber", "_c11" -> "MedicationRouteCode", "_c12" -> "MedicationRouteText", "_c13" -> "DoseQuantity",
    "_c14" -> "DoseQuantityUnitCode", "_c15" -> "DoseQuantityUnitText", "_c16" -> "MedicationProductFormCode",
    "_c17" -> "MedicationProductFormText", "_c18" -> "ProcedureCode", "_c19" -> "ProcedureText", "_c20" -> "ProcedureCategory",
    "_c21" -> "NegationInd", "_c22" -> "MedicationBrandName", "_c23" -> "MedicationGenericName", "_c24" -> "MaxDoseQuantity",
    "_c25" -> "DispensingTimeOfSupply", "_c26" -> "DispensingDoseQuantity", "_c27" -> "SupplyPrescriberLastName",
    "_c28" -> "SupplyPrescriberFirstName", "_c29" -> "SupplyPerformerLastName", "_c30" -> "SupplyPerformerFirstName",
    "_c31" -> "ServiceLocationId", "_c32" -> "ServiceLocationName", "_c33" -> "MedicationIndicationCriteria",
    "_c34" -> "MedicationIndicationProblemCode", "_c35" -> "MedicationIndicationProblemText",
    "_c36" -> "MedicationIndicationProblemCategory", "_c37" -> "MedicationSeriesNumber",
    "_c38" -> "MedicationReactionProblemCode", "_c39" -> "MedicationReactionProblemText",
    "_c40" -> "MedicationReactionProblemCategory", "_c41" -> "MedicationReactionProblemSeverityCode",
    "_c42" -> "MedicationReactionProblemSeverityText", "_c43" -> "MedicationStatusCode", "_c44" -> "MedicationStatusText",
    "_c45" -> "MedicineManufacturer", "_c46" -> "MedicineId", "_c47" -> "ProductInstanceScopingEntityId",
    "_c48" -> "SubstanceLotNumber", "_c49" -> "SubstanceExpirationDate", "_c50" -> "ActionCode", "_c51" -> "AdministrationSite"
    , "_c52" -> "ImmunizationKey", "_c53" -> "PracticeUid", "_c54" -> "BatchUid", "_c55" -> "dummy1", "_c56" -> "dummy1")


  //Read file for CachePatientImmunization
  val file: DataFrame = CommonFunc.readFile(ImmunizationPath,spark)

  val CachePatientImmunization: DataFrame = file.select(file.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)
    .drop("dummy1", "dummy2")
    .withColumn("ImmuStartDate", to_timestamp($"ImmuStartDate", "MM/dd/yyyy HH:mm:ss"))

  val addPatientUid = CachePatientImmunization.as("df1").join(broadcast(DemoGraphicsDF).as("df2")
    , Seq("PatientId","PracticeUid"))
    .select($"df1.*", $"df2.PatientUid")
  //Get required functions for CachePatientImmunization
  val patientImmunization = new CacheImmunizationFunctions(spark, mappingpracticecommondatamaster, MappingPracticeCommonDataMasterMedicationRoute, MappingPracticeProcedure, MappingPracticeProblem, MappingPracticeCommonDataMaster)

  val transformImmunization = addPatientUid
    .transform(patientImmunization.ImmunizationName)
    .transform(patientImmunization.ImmunizationCode)
    .transform(patientImmunization.MedicationRouteText)
    .transform(patientImmunization.MedicationRouteCode)
    .transform(patientImmunization.ProcedureText)
    .transform(patientImmunization.ProcedureCode)
    .transform(patientImmunization.MedicationIndicationProblemText)
    .transform(patientImmunization.MedicationIndicationProblemCode)
    .transform(patientImmunization.MedicationReactionProblemText)
    .transform(patientImmunization.MedicationReactionProblemCode)
    .transform(patientImmunization.MedicationReactionProblemSeverityText)
    .transform(patientImmunization.MedicationReactionProblemSeverityCode)
    .transform(patientImmunization.MedicationStatusText)
    .transform(patientImmunization.MedicationStatusCode)

  /*val distinctYear = transformImmunization.withColumn("Year",year($"ImmuStartDate")).select("Year").distinct()
  val distinctMonth = transformImmunization.withColumn("Month",month($"ImmuStartDate")).select("Month").distinct()
  val distinctPUid = transformImmunization.select("PracticeUid").distinct()

  val ListVal:Array[Any] = distinctYear.rdd.map(r => r(0)).collect()
  val PartitionYear = "(\"" + ListVal.mkString("\",\"") + "\")"

  val ListVal3:Array[Any] = distinctMonth.rdd.map(r => r(0)).collect()
  val PartitionMonth = "(\"" + ListVal3.mkString("\",\"") + "\")"

  val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
  val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

  val ImmunizationData = spark.sql(s"select * from figmdaaocdr.immunization where" +
    s" practiceuid in $PartitionPUID and year in $PartitionYear and month in $PartitionMonth")
    .drop("year","month")

  val PreviousandNewData = transformImmunization.as("df1").join(ImmunizationData.as("df2")
    ,Seq("PatientId","PatientUid","PracticeUid"),"left_outer")
    .select($"df1.*")

  val otherData = ImmunizationData.as("df1").join(transformImmunization.as("df2")
    ,Seq("PatientId","PatientUid","PracticeUid"),"left_anti")
    .select($"df1.*")

  /*val newData = transformImmunization.as("df1").join(ImmunizationData.as("df2")
    ,Seq("PatientId","PatientUid","PracticeUid"),"left_anti")
    .select($"df1.*")*/

  val allImmunizationmData = PreviousandNewData.union(otherData)

  val tableName = conf.getString("db_tb_Immunization")
  val CombineData = allImmunizationmData.withColumn("Year",year($"ImmuStartDate"))
    .withColumn("Month",month($"ImmuStartDate"))*/

  val CombineData = transformImmunization.withColumn("Year",year($"ImmuStartDate"))

  println("Immunization........")
  val tableName = conf.getString("db_tb_Immunization")
  val tempTableName = "newfigmdcdr.immunization"
  val s3path = "s3://bd-dev/AAOData/NewRecords/PHI/PatientImmunization/"
  HiveUtility.dfwritrtohiveVisit(CombineData,tableName,spark,tempTableName,s3path)

}
catch {
  case ex: FileNotFoundException => {
    ex.printStackTrace()
  }
  case unknown: Exception => {
    println(s"Unknown exception: $unknown")
  }
}

  }
}

