package com.figmd.janus.util

import com.figmd.janus.constant.ApplicationConfig.prop
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{month, year,from_json,lit,when}
import org.apache.spark.sql.types._

class JoinDFUtil (sparkSess: SparkSession,conf : Config) {

  import sparkSess.implicits._


  val ethnicityschema = ArrayType(StructType(Array(
    StructField("PatientEthnicityText",StringType),
    StructField("PatientEthnicityCode",StringType),
    StructField("MasterPatientEthnicityText",StringType),
    StructField("MasterPatientEthnicityCode",StringType))))

  def arrayOfethnicityschema(schema: ArrayType) =
    from_json(lit("""[{"","","",""]"""), schema)

  val raceschema = ArrayType(StructType(Array(
    StructField("PatientRaceCode",StringType),
    StructField("PatientRaceText",StringType),
    StructField("MasterPatientRaceCode",StringType),
    StructField("MasterPatientRaceText",StringType))))

  def arrayOfraceschema(schema: ArrayType) =
    from_json(lit("""[{"","","",""}]"""), schema)


  val languageschema = ArrayType(StructType(Array(
    StructField("LanguageCode",StringType),
    StructField("LanguageText",StringType),
    StructField("LangaugeAbilityModeCode",StringType),
    StructField("LangaugeAbilityModeText",StringType),
    StructField("LanguageProficiencyLevelCode",StringType),
    StructField("LanguageProficiencyLevelText",StringType),
    StructField("PreferenceInd",StringType))))

  def arrayOflanguageschema(schema: ArrayType) =
    from_json(lit("""[{"","","","","","",""}]"""), schema)


  val socialhistoryobservationschema = ArrayType(StructType(Array(
    StructField("SocialHistoryStatusCode",IntegerType),
    StructField("SocialHistoryStatusText",StringType),
    StructField("SocialHistoryTypeText",StringType),
    StructField("EffectiveStopDate",StringType),
    StructField("MasterSocialHistoryTypeCode",StringType),
    StructField("MasterSocialHistoryStatusCode",StringType),
    StructField("MasterSocialHistoryStatusText",StringType),
    StructField("SocialHistoryTypeCode",IntegerType),
    StructField("QuitYear",StringType),
    StructField("EffectiveStartDate",StringType),
    StructField("SocialHxGroup",StringType),
    StructField("DocumentationDate",StringType),
    StructField("MasterSocialHistoryTypeText",StringType),
    StructField("SocialHistoryObservationKey",StringType),
    StructField("YearsSmoked",StringType),
    StructField("PracticeUid",StringType),
    StructField("SocialHistoryObservedValue",StringType))))


  def arrayOfsocialhistoryobservationschema(schema: ArrayType) =
    from_json(lit("""[{"","","","","","","","","","","","","","","","",""}]"""), schema)


  val insuranceschema = ArrayType(StructType(Array(
    StructField("PayerState",StringType),
    StructField("Insurance_Active",IntegerType),
    StructField("EndDateOfInsurance",StringType),
    StructField("InsurancePlan",StringType),
    StructField("PayerID",StringType),
    StructField("IsInsuredSameAsGuarantor",IntegerType),
    StructField("BillingInsurance",StringType),
    StructField("InsuredPersonId",StringType),
    StructField("PatientId",IntegerType),
    StructField("PayerCity",StringType),
    StructField("MasterInsuredRelationToPatientText",StringType),
    StructField("InsuranceOrder",StringType),
    StructField("StartDateOfInsurance",StringType),
    StructField("MasterInsuredRelationToPatientCode",StringType),
    StructField("PayerZip",StringType),
    StructField("InsuranceCompany",StringType),
    StructField("DocumentationDate",StringType),
    StructField("InsuredRelationToPatientCode",StringType),
    StructField("InsuredRelationToPatientText",StringType),
    StructField("PracticeUid",StringType),
    StructField("PayerKey",StringType),
    StructField("PolicyID",StringType),
    StructField("InsuranceGroup",StringType))))

  def arrayOfinsuranceschema(schema: ArrayType) =
    from_json(lit("""[{"","","","","","","","","","","","","","","","","","","","","","",""}]"""), schema)


  val Planofcareschema = ArrayType(StructType(Array(
    StructField("EffectiveDate",StringType),
    StructField("Instructions",StringType),
    StructField("PlanOfCareStatusCode",StringType),
    StructField("PlanOfCareStatusText",StringType),
    StructField("MasterPlanOfCareStatusCode",StringType),
    StructField("MasterPlanOfCareStatusText",StringType),
    StructField("PlanOfCareGroup",StringType),
    StructField("PracticeCode",StringType),
    StructField("PracticeDescription",StringType),
    StructField("MasterPlanOfCareCode",StringType),
    StructField("MasterPlanOfCareText",StringType))))

  def arrayOfPlanofCareSchema(schema: ArrayType) =
    from_json(lit("""[{"","","","","","","","","","",""}]"""), schema)


  val advancedirectivesschema = ArrayType(StructType(Array(
    StructField("AdvanceDirectiveTypeCode",IntegerType),
    StructField("AdvanceDirectiveTypeDetails",StringType),
    StructField("AdvanceDirectiveStatusCode",StringType),
    StructField("AdvanceDirectiveStatusText",StringType),
    StructField("EffectiveStartDate",DateType),
    StructField("EffectiveEndDate",DateType),
    StructField("AgentName",StringType),
    StructField("ExternalDocumentLink",StringType),
    StructField("GroupName",StringType),
    StructField("AdvanceDirectiveTypeText",StringType),
    StructField("MasterAdvanceDirectiveStatusCode",StringType),
    StructField("MasterAdvanceDirectiveStatusText",StringType),
    StructField("MasterAdvanceDirectiveTypeCode",StringType),
    StructField("MasterAdvanceDirectiveTypeDetails",StringType))))

  def arrayOfadvancedirectivesschema(schema: ArrayType) =
    from_json(lit("""[{"","","","","","","","","","","","","",""}]"""), schema)


  val allergyschema = ArrayType(StructType(Array(
    StructField("EffectiveStartDate",DateType),
    StructField("EffectiveEndDate",DateType),
    StructField("AllergyTypeCode",IntegerType),
    StructField("AllergyEventType",StringType),
    StructField("AllergicToCode",StringType),
    StructField("AllergicToDescription",StringType),
    StructField("AllergyStatusCode",StringType),
    StructField("AllergyStatusText",StringType),
    StructField("AllergyReaction",StringType),
    StructField("MasterAllergyStatusCode",StringType),
    StructField("MasterAllergyStatusText",StringType),
    StructField("MasterAllergicToCode",StringType),
    StructField("MasterAllergyDescription",StringType))))

  def arrayOfallergyschema(schema: ArrayType) =
    from_json(lit("""[{"","","","","","","","","","","","",""}]"""), schema)


  val patientfamilyhistoryschema = ArrayType(StructType(Array(
    StructField("RelationshipToPatientCode",StringType),
    StructField("MasterRelationshipToPatientCode",StringType),
    StructField("MasterRelationshipToPatientText",StringType),
    StructField("ProblemTypeCode",IntegerType),
    StructField("ProblemTypeText",StringType),
    StructField("MasterProblemTypeCode",StringType),
    StructField("MasterProblemTypeText",StringType),
    StructField("ProblemCode",IntegerType),
    StructField("ProblemText",StringType),
    StructField("MasterProblemCode",StringType),
    StructField("MasterProblemDescription",StringType),
    StructField("FamilyMemberAge",StringType),
    StructField("FamilyMemberLastName",StringType),
    StructField("FamilyMemberFirstName",StringType),
    StructField("EffectiveDate",StringType),
    StructField("RelationshipToPatientText",StringType))))

  def arrayOfpatientfamilyhistoryschema(schema: ArrayType) =
    from_json(lit("""[{"","","","","","","","","","","","","","","",""}]"""), schema)


  def sendPatientToHive(dfList : List[DataFrame]): Unit = {

    var PatientDF = dfList.tail.foldLeft(dfList.head)((accDF, newDF) => accDF.join(newDF
      , Seq("PracticeUid","PatientId"),"left_outer")).withColumn("Year",year($"DOB"))



    if(!PatientDF.columns.toSet.contains("ethnicity")){

      PatientDF = PatientDF.withColumn("ethnicity", arrayOfethnicityschema(ethnicityschema))

    }else{PatientDF}

    if(!PatientDF.columns.toSet.contains("race")){

      PatientDF = PatientDF.withColumn("race", arrayOfraceschema(raceschema))

    }else{PatientDF}

    if(!PatientDF.columns.toSet.contains("language")){

      PatientDF = PatientDF.withColumn("language", arrayOflanguageschema(languageschema))

    }else{PatientDF}

    if(!PatientDF.columns.toSet.contains("socialhistoryobservation")){

      PatientDF = PatientDF.withColumn("socialhistoryobservation", arrayOfsocialhistoryobservationschema(socialhistoryobservationschema))

    }else{PatientDF}

    if(!PatientDF.columns.toSet.contains("insurance")){

      PatientDF = PatientDF.withColumn("insurance", arrayOfinsuranceschema(insuranceschema))

    }else{PatientDF}

    if(!PatientDF.columns.toSet.contains("planofcare")){

      PatientDF = PatientDF.withColumn("planofcare", arrayOfPlanofCareSchema(Planofcareschema))

    }else{PatientDF}

    if(!PatientDF.columns.toSet.contains("advancedirectives")){

      PatientDF = PatientDF.withColumn("advancedirectives", arrayOfadvancedirectivesschema(advancedirectivesschema))

    }else{PatientDF}

    if(!PatientDF.columns.toSet.contains("allergy")){

      PatientDF = PatientDF.withColumn("allergy", arrayOfallergyschema(allergyschema))

    }else{PatientDF}

    if(!PatientDF.columns.toSet.contains("patientfamilyhistory")){

      PatientDF = PatientDF.withColumn("patientfamilyhistory", arrayOfpatientfamilyhistoryschema(patientfamilyhistoryschema))

    }
    else{PatientDF}


      println("Patient..................")
    //PatientDF.printSchema()
    val TableName = "figmdcdr_temp.patient"
    val tempTableName = prop.getProperty("HivePatientTableName")
    val s3Path = prop.getProperty("s3LocationPatient")
    HiveUtility.dfwritrtohivePatient(PatientDF,TableName,sparkSess,tempTableName,s3Path)
  }

  /*def sendVisitToHive(dflist : List[DataFrame]): Unit ={

    val df = dflist.tail.foldLeft(dflist.head)((accDF, newDF) => accDF.join(newDF, Seq("PatientId")))
      .withColumn("Year",year($"EncounterStartDate"))
      .withColumn("Month",month($"EncounterStartDate"))
    val tempTableName = "figmdcdr_temp.visit"
    val TableName = conf.getString("db_tb_Visit")
    HiveUtility.dfwritrtohiveVisit(df,TableName,sparkSess,tempTableName)
  }*/


}