package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.constant.ApplicationConfig.prop
import com.figmd.janus.util.{CommonFunc, HiveUtility}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.typesafe.config.Config

class PatientProblem(ProblemPath : String) {

  def cachePatientProblemProcessing(sparkSess : SparkSession, mappingpracticeproblem : DataFrame
                          ,conf : Config,DemoGraphicsDF : DataFrame) = {

    import sparkSess.implicits._

    try {
      var cachePatientProblem = CommonFunc.readFile(ProblemPath,sparkSess)

      val lookup1 = Map("_c0" -> "PatientId", "_c1" -> "ProblemCode", "_c2" -> "ProblemText", "_c3" -> "ProblemCategory"
        , "_c4" -> "ProblemTypeCode", "_c5" -> "ProblemTypeText", "_c6" -> "DocumentationDate",
        "_c7" -> "ProblemResolutionDate", "_c8" -> "ProblemStatusCode", "_c9" -> "ProblemStatusText"
        , "_c10" -> "ProblemHealthStatusCode", "_c11" -> "ProblemHealthStatusText", "_c12" -> "NegationInd",
        "_c13" -> "ProblemComment", "_c14" -> "ProblemOnsetDate", "_c15" -> "TargetSiteCode", "_c16" -> "TargetSiteText"
        , "_c17" -> "ProblemKey", "_c18" -> "PracticeUid", "_c19" -> "BatchUid",
        "_c20" -> "dummy1", "_c21" -> "dummy2")

      val cachePatientProblem1 = cachePatientProblem.select(cachePatientProblem.columns.map(c => col(c).as(lookup1.getOrElse(c, c))): _*)
        .drop("dummy1","dummy2")
        .withColumn("DocumentationDate", to_timestamp($"DocumentationDate", "MM/dd/yyyy HH:mm:ss"))

      //cachePatientProblem1.printSchema()

      val addPatientUid = cachePatientProblem1.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PracticeUid","PatientId"))
        .select($"df1.*",$"df2.PatientUid")

      val CleanedRecords = addPatientUid.dropDuplicates(Seq("PatientUid", "ProblemCode"
        , "DocumentationDate"))

      val CleanedRecords2 = CleanedRecords.dropDuplicates(Seq("PatientUid", "ProblemText"
        , "DocumentationDate"))

      val problemObj = new CachePatientProblemFunctions(sparkSess, mappingpracticeproblem)

      val cachePatientProblem3 = CleanedRecords2
        .transform(problemObj.ProblemCode)
        .transform(problemObj.ProblemText)
        .transform(problemObj.ProblemStatusCode)
        .transform(problemObj.ProblemStatusText)
        .transform(problemObj.ProblemHealthStatusCode)
        .transform(problemObj.ProblemHealthStatusText)
        .transform(problemObj.TargetSiteCode)
        .transform(problemObj.TargetSiteText)

      /*val distinctYear = cachePatientProblem3.withColumn("Year",year($"DocumentationDate")).select("Year").distinct()
      val distinctMonth = cachePatientProblem3.withColumn("Month",month($"DocumentationDate")).select("Month").distinct()
      val distinctPUid = cachePatientProblem3.select("PracticeUid").distinct()

      val ListVal:Array[Any] = distinctYear.rdd.map(r => r(0)).collect()
      val PartitionYear = "(\"" + ListVal.mkString("\",\"") + "\")"

      val ListVal3:Array[Any] = distinctMonth.rdd.map(r => r(0)).collect()
      val PartitionMonth = "(\"" + ListVal3.mkString("\",\"") + "\")"

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val ProblemData = sparkSess.sql(s"select * from figmdaaocdr.patientproblem where" +
        s" practiceuid in $PartitionPUID and year in $PartitionYear and month in $PartitionMonth")
        .drop("year","month")

      println("ProblemData Count....... ProblemData  .....  "+ProblemData.count())

      val PreviousDataandNew = cachePatientProblem3.as("df1").join(ProblemData.as("df2")
        ,Seq("PatientId","PatientUid","PracticeUid","ProblemCode"),"left_outer")
        .select($"df1.*")

      println("PreviousData Count....... PreviousData  .....  "+PreviousDataandNew.count())

      val otherData = ProblemData.as("df1").join(cachePatientProblem3.as("df2")
        ,Seq("PatientId","PatientUid","PracticeUid"),"left_anti")
        .select($"df1.*").drop("dummy1","dummy2")

      println("otherData Count....... otherData  .....  "+otherData.count())

     /* val newData = cachePatientProblem3.as("df1").join(ProblemData.as("df2")
        ,Seq("PatientId","PatientUid","PracticeUid"),"left_anti")
        .select($"df1.*")

      println("newData Count....... newData  .....  "+newData.count())*/

      val allProblemData = PreviousDataandNew.union(otherData)
      val CombineData = allProblemData.withColumn("Year",year($"DocumentationDate"))
        .withColumn("Month",month($"DocumentationDate"))*/

      val CombineData = cachePatientProblem3.withColumn("Year",year($"DocumentationDate"))
      val tableName = conf.getString("db_tb_Prob")
      val tempTableName = prop.getProperty("HiveProblemTableName")
      val s3path = prop.getProperty("s3LocationProblem")
      HiveUtility.dfwritrtohiveVisit(CombineData,tableName,sparkSess,tempTableName,s3path)
    }

    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
      }
    }
  }


}
