package com.figmd.janus

import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}

class cacheRaceFunctions (sparkSess : SparkSession ,MasterRace : DataFrame) {




  import sparkSess.implicits._
  def PatientRaceText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(MasterRace.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientRaceText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterPatientRaceCode")
        ,$"df2.CodeDescription".as("MasterPatientRaceText"))
  }

  def PatientRaceCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(MasterRace.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientRaceCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterPatientRaceCode",when($"MappedValue2".isNull,$"MasterPatientRaceCode")
        .otherwise($"MappedValue2"))
      .withColumn("MasterPatientRaceText",when($"MappedValue1".isNull,$"MasterPatientRaceText")
        .otherwise($"MappedValue1"))
      .drop("MappedValue1","MappedValue2")
  }
}
