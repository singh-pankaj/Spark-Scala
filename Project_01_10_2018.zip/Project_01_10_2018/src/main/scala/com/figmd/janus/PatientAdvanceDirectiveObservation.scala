package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientAdvanceDirectiveObservation(AdvanceDirPath : String) {

  def cacheAdvObsProcessing(sparkSess : SparkSession, mappingpracticecommondatamaster : DataFrame)
  : Option[DataFrame] = {

    import sparkSess.implicits._

    try {
      var cachePatientAdvDirObservation = CommonFunc.readFile(AdvanceDirPath,sparkSess)


      val lookup1 = Map("_c0" -> "PatientId", "_c1" -> "AdvanceDirectiveTypeCode", "_c2" -> "AdvanceDirectiveTypeDetails"
        , "_c3" -> "AdvanceDirectiveStatusCode", "_c4" -> "AdvanceDirectiveStatusText", "_c5" -> "EffectiveStartDate"
        , "_c6" -> "EffectiveEndDate", "_c7" -> "AgentName", "_c8" -> "ExternalDocumentLink", "_c9" -> "GroupName"
        , "_c10" -> "AdvanceDirectiveTypeText"
        , "_c11" -> "AdvanceDirectiveKey", "_c12" -> "PracticeUid", "_c13" -> "BatchUid"
        , "_c14" -> "dummy1", "_c15" -> "dummy2")

       cachePatientAdvDirObservation = cachePatientAdvDirObservation.select(cachePatientAdvDirObservation.columns.map(c => col(c).as(lookup1.getOrElse(c, c))): _*)
          .drop("dummy1","dummy2")
          .withColumn("EffectiveStartDate", to_timestamp($"EffectiveStartDate", "MM/dd/yyyy HH:mm:ss"))
          .withColumn("EffectiveEndDate", to_timestamp($"EffectiveEndDate", "MM/dd/yyyy HH:mm:ss"))

      val tf = new CachePatientAdvObservationFunctions(sparkSess, mappingpracticecommondatamaster)

      val cachePatientAdvObservation3 = cachePatientAdvDirObservation
        .transform(tf.DirectiveTypeCode)
        .transform(tf.DirectiveTypeDetails)
        .transform(tf.DirectiveStatusCode)
        .transform(tf.DirectiveStatusText)


      val cachePatientAdvObservation4 = cachePatientAdvObservation3.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("AdvanceDirectiveTypeCode", "AdvanceDirectiveTypeDetails", "AdvanceDirectiveStatusCode"
          , "AdvanceDirectiveStatusText", "EffectiveStartDate", "EffectiveEndDate", "AgentName"
          , "ExternalDocumentLink", "GroupName", "AdvanceDirectiveTypeText", "MasterAdvanceDirectiveStatusCode"
          , "MasterAdvanceDirectiveStatusText", "MasterAdvanceDirectiveTypeCode", "MasterAdvanceDirectiveTypeDetails"))
          .as("AdvanceDirectives"))

      Some(cachePatientAdvObservation4)
    }

    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }

}
