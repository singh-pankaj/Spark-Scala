package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

class PatientAllergy(AllergyPath : String) {


  def cacheAllergyProcessing(sparkSess : SparkSession, masterAllergy : DataFrame,mappingpracticecommondatamaster : DataFrame
                   ) : Option[DataFrame] = {


    try {
      import sparkSess.implicits._
      val file = CommonFunc.readFile(AllergyPath,sparkSess)

      val lookup1 = Map("_c0" -> "PatientId", "_c1" -> "EffectiveStartDate", "_c2" -> "EffectiveEndDate"
        , "_c3" -> "AllergyTypeCode", "_c4" -> "AllergyEventType", "_c5" -> "AllergicToCode"
        , "_c6" -> "AllergicToDescription", "_c7" -> "AllergyStatusCode"
        , "_c8" -> "AllergyStatusText", "_c9" -> "AllergyReaction", "_c10" -> "AllergiesKey"
        ,"_c11" -> "PracticeUid","_c12" -> "BatchUid","_c13" -> "dummy1","_c14" -> "dummy2")

      val cacheAllergy = file.select(file.columns.map(c => col(c).as(lookup1.getOrElse(c, c))): _*)
          .drop("dummy1","dummy2")
        .withColumn("EffectiveStartDate", to_timestamp($"EffectiveStartDate", "MM/dd/yyyy HH:mm:ss"))
        .withColumn("EffectiveEndDate", to_timestamp($"EffectiveEndDate", "MM/dd/yyyy HH:mm:ss"))

      val tf = new CacheAllergyFunctions(sparkSess, masterAllergy, mappingpracticecommondatamaster)
      val cacheAllergy3 = cacheAllergy
        .transform(tf.AllergicToCode)
        .transform(tf.AllergicToDescription)
        .transform(tf.AllergyStatusCode)
        .transform(tf.AllergyStatusText)

      val cacheAllergy4 = cacheAllergy3.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("EffectiveStartDate", "EffectiveEndDate", "AllergyTypeCode"
          , "AllergyEventType", "AllergicToCode", "AllergicToDescription", "AllergyStatusCode"
          , "AllergyStatusText", "AllergyReaction", "MasterAllergyStatusCode", "MasterAllergyStatusText"
          , "MasterAllergicToCode", "MasterAllergyDescription")).as("Allergy"))

      Some(cacheAllergy4)
    }


    catch {
      case ex: FileNotFoundException => {
       ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }

}
