
package com.figmd.janus
import java.io.FileNotFoundException

import com.figmd.janus.constant.ApplicationConfig.prop
import com.figmd.janus.util.{CommonFunc, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

class Medications(MedicationPath : String) {

  def CacheMedicationsProcessing(spark: SparkSession, MappingPracticeProcedure: DataFrame, MappingPracticeMedication: DataFrame,
                       MappingPracticeCommonDataMaster: DataFrame, conf : Config , DemoGraphicsDF : DataFrame
                       )  {
    import spark.implicits._

    /*
  //Create map of file indices and column names
  val cacheMedicationsMapDF: Dataset[Row] = rt.joinedDf
    .filter($"CacheTableViewName"==="ViewCacheMedications")
  val lookup: collection.Map[String, String] = getLookupMap(cacheMedicationsMapDF)
  */
    try {

      val lookup = Map("_c0" -> "PatientId", "_c1" -> "MedicationCode", "_c2" -> "MedicationName"
        , "_c3" -> "MedicationCategory", "_c4" -> "MedStartDate", "_c5" -> "MedStopDate"
        , "_c6" -> "AdministeredEffectiveDate", "_c7" -> "RepeatNumber", "_c8" -> "MedicationRouteCode"
        , "_c9" -> "MedicationRouteText", "_c10" -> "DoseQuantity", "_c11" -> "DoseQuantityUnitCode"
        , "_c12" -> "DoseQuantityUnitText", "_c13" -> "MedicationProductFormCode", "_c14" -> "MedicationProductFormText"
        , "_c15" -> "ProcedureCode", "_c16" -> "ProcedureText", "_c17" -> "ProcedureCategory"
        , "_c18" -> "PrescribeElectronically", "_c19" -> "NegationInd", "_c20" -> "MedicationBrandName"
        , "_c21" -> "MedicationGenericName", "_c22" -> "MaxDoseQuantity", "_c23" -> "ServiceProviderNPI"
        , "_c24" -> "ServiceProviderLastName", "_c25" -> "ServiceProviderFirstName", "_c26" -> "DispensingTimeOfSupply"
        , "_c27" -> "DispensingDoseQuantity", "_c28" -> "SupplyPrescriberLastName", "_c29" -> "SupplyPrescriberFirstName"
        , "_c30" -> "SupplyPerformerLastName", "_c31" -> "SupplyPerformerFirstName", "_c32" -> "ServiceLocationId"
        , "_c33" -> "ServiceLocationName", "_c34" -> "MedicationIndicationCriteria"
        , "_c35" -> "MedicationIndicationProblemCode", "_c36" -> "MedicationIndicationProblemText"
        , "_c37" -> "MedicationIndicationProblemCategory", "_c38" -> "MedicationSeriesNumber"
        , "_c39" -> "MedicationReactionProblemCode", "_c40" -> "MedicationReactionProblemText"
        , "_c41" -> "MedicationReactionProblemCategory", "_c42" -> "MedicationReactionProblemSeverityCode"
        , "_c43" -> "MedicationReactionProblemSeverityText", "_c44" -> "MedicationStatusCode"
        , "_c45" -> "MedicationStatusText", "_c46" -> "MedicineManufacturer", "_c47" -> "MedicineId"
        , "_c48" -> "ProductInstanceScopingEntityId", "_c49" -> "PracticePatientMedicationKey"
        , "_c50" -> "DocumentationDate", "_c51" -> "PracticeUid", "_c52" -> "BatchUid", "_c53" -> "dummy1"
        , "_c54" -> "dummy2")

      //Read file for CacheMedications
      val file: DataFrame = CommonFunc.readFile(MedicationPath,spark)

      //Apply lookup to generate file Header
      val CacheMedicationsDF: DataFrame = file.select(file.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("MedStartDate", to_timestamp($"MedStartDate", "MM/dd/yyyy HH:mm:ss"))

      //CacheMedicationsDF.printSchema()

      val addPatientUid =  CacheMedicationsDF.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PracticeUid","PatientId"))
        .select($"df1.*",$"df2.PatientUid")

      val CleanedData = addPatientUid.dropDuplicates(Seq("PatientUid", "PracticePatientMedicationKey"))

      //Get required functions for CacheMedications
      val medications = new CacheMedicationsFunctions(spark, MappingPracticeProcedure, MappingPracticeMedication, MappingPracticeCommonDataMaster)

      val transformMedicationsDF = CleanedData
        .transform(medications.ProcedureText)
        .transform(medications.ProcedureCode)
        .transform(medications.MedicationName)
        .transform(medications.MedicationCode)
        .transform(medications.MedicationProductFormText)
        .transform(medications.MedicationProductFormCode)
        .transform(medications.MedicationIndicationProblemText)
        .transform(medications.MedicationIndicationProblemCode)
        .transform(medications.MedicationReactionProblemText)
        .transform(medications.MedicationReactionProblemCode)
        .transform(medications.MedicationReactionProblemSeverityText)
        .transform(medications.MedicationReactionProblemSeverityCode)
        .transform(medications.MedicationStatusText)
        .transform(medications.MedicationStatusCode)
        .transform(medications.MedicationRouteText)
        .transform(medications.MedicationRouteCode)

      /*val distinctYear = transformMedicationsDF.withColumn("Year",year($"MedStartDate")).select("Year").distinct()
      val distinctMonth = transformMedicationsDF.withColumn("Month",month($"MedStartDate")).select("Month").distinct()
      val distinctPUid = transformMedicationsDF.select("PracticeUid").distinct()

      val ListVal:Array[Any] = distinctYear.rdd.map(r => r(0)).collect()
      val PartitionYear = "(\"" + ListVal.mkString("\",\"") + "\")"

      val ListVal3:Array[Any] = distinctMonth.rdd.map(r => r(0)).collect()
      val PartitionMonth = "(\"" + ListVal3.mkString("\",\"") + "\")"

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val MedicationData = spark.sql(s"select * from figmdaaocdr.patientmedication where" +
        s" practiceuid in $PartitionPUID and year in $PartitionYear and month in $PartitionMonth")
        .drop("year","month")

      println("Medication Count....... MedicationData  .....  "+MedicationData.count())

      val PreviousandNewData = transformMedicationsDF.as("df1").join(MedicationData.as("df2")
        ,Seq("PatientId","PracticeUid","PatientUid"),"left_outer")
        .select($"df1.*")

      println("Medication Count....... PreviousData  .....  "+PreviousandNewData.count())

      val otherData = MedicationData.as("df1").join(transformMedicationsDF.as("df2")
        ,Seq("PatientId","PracticeUid","PatientUid"),"left_anti")
        .select($"df1.*")
      println("Medication Count.......  otherData  .....  "+otherData.count())

    /*  val newData = transformMedicationsDF.as("df1").join(MedicationData.as("df2")
        ,Seq("PatientId","PracticeUid","PatientUid"),"left_anti")
        .select($"df1.*")

      ("Medication Count.......  newData  .....  "+newData.count())*/

      val allMedicationData = PreviousandNewData.union(otherData)

      val tableName = conf.getString("db_tb_Medication")
      val CombineData = allMedicationData.as("df1").withColumn("Year",year($"df1.MedStartDate"))
        .withColumn("Month",month($"df1.MedStartDate"))*/

      //println("start medication..........")
      val CombineData = transformMedicationsDF.as("df1").withColumn("Year",year($"df1.MedStartDate"))
      val tableName = conf.getString("db_tb_Medication")
      val tempTableName = prop.getProperty("HiveMedicationTableName")
      val s3path = prop.getProperty("s3LocationMedication")
      //println("Medication data write to  hive tables..........")
      HiveUtility.dfwritrtohiveVisit(CombineData,tableName,spark,tempTableName,s3path)
      //println("end medication..........")



    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
      }
    }
  }
}