package com.figmd.janus

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
class PatientLabOrder {

  def CachePatientLabOrder(spark: SparkSession): DataFrame = {
    import spark.implicits._

    /*
  //Create map of file indices and column names
  val cachePatientLabOrderMapDF: Dataset[Row] = rt.joinedDf
    .filter($"CacheTableViewName"==="ViewCachePatientLabOrder")
  val lookup: collection.Map[String, String] = getLookupMap(cachePatientLabOrderMapDF)
  */


    val lookup =Map("_c1"->"Patient_ID","_c2"->"Instructions","_c3"->"PracticeCode","_c4"->"PracticeDescription",
      "_c5"->"Effective_Date", "_c6"->"PlanOfCareStatusCode","_c7"->"PlanOfCareStatusText",
      "_c8"->"PlanOfCareGroup","_c9"->"PlanOfCare_Key" , "_c10" -> "dummy1", "_c11" -> "dummy2")


    //Read file for CachePatientLabOrder
    val file: DataFrame = spark.read.option("delimiter", "|").option("inferSchema", "true")
      .csv("file:///home/dev/Akshay/PatientLabOrder_testfile_bckup.csv")

    //File NOt Found

    //Apply lookup to generate file Header
    val CachePatientLabOrderDF: DataFrame = file.select(file.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)
      .drop("dummy1","dummy2")

    //@@// Start Transformation for CachePatientLabOrder



    CachePatientLabOrderDF
      .groupBy("PatientId")
      .agg(collect_list(struct("Description","OrderDate","RangeUnits","CustomName","RangeFrom",
        "RangeTo","ListOrder","Units","OrderGroupId","PracticeCode","ReferenceObservationRange","ResultValue",
        "ResultObservationStatus","SpecimenId","LaboratoryID","PatientLabOrderKey" )).as("allcols")).toJSON
      .select(get_json_object($"value", "$.PatientId").as("PatientId"),
        get_json_object($"value", "$.allcols").as("LabOrder"))

  }
}
