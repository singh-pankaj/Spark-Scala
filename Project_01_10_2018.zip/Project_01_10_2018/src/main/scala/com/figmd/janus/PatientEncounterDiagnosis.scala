package com.figmd.janus

import java.io.FileNotFoundException

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

class PatientEncounterDiagnosis {


  def CachePatientEncounterDiagnosis(spark:SparkSession): Option[DataFrame] = {
  import spark.implicits._

    try{

  val lookup = Map( "_c0" -> "PatientId", "_c1" -> "EncounterDate", "_c2" -> "ServiceProviderNPI",
  "_c3" -> "ServiceProviderLastName", "_c4" -> "ServiceProviderFirstName", "_c5" -> "ServiceLocationId",
  "_c6" -> "ServiceLocationName", "_c7" -> "EncounterDiagnosisCode", "_c8" -> "EncounterDiagnosisText",
  "_c9" -> "EncounterDiagnosisCategory", "_c10" -> "EncounterProblemTypeCode", "_c11" -> "EncounterProblemTypeText",
  "_c12" -> "DocumentationDate", "_c13" -> "ProblemResolutionDate", "_c14" -> "ProblemStatusCode",
  "_c15" -> "ProblemStatusText", "_c16" -> "ProblemHealthStatusCode", "_c17" -> "ProblemHealthStatusText",
  "_c18" -> "NegationInd", "_c19" -> "ProblemComment", "_c20" -> "ProblemOnsetDate", "_c21" -> "TargetSiteCode",
  "_c22" -> "TargetSiteText", "_c23" -> "ListOrder", "_c24" -> "EncounterDiagnosisKey", "_c25" -> "PracticeUid",
  "_c26" -> "BatchUid","_c27" -> "dummy1", "_c27" -> "dummy2")

  val file = spark.read.option("delimiter","\u0017").option("inferSchema","true")
    .csv("temp_test/AllFiles/608CDEE4_*")

  val CacheEncounterDiagnosis: DataFrame = file.select(file.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)
    .drop("dummy1","dummy2")


  val EncounterDiagnosis: DataFrame = CacheEncounterDiagnosis.groupBy("PatientId")
    .agg(collect_list(struct("EncounterDate","ServiceProviderNPI","ServiceProviderLastName",
      "ServiceProviderFirstName","ServiceLocationId","ServiceLocationName","EncounterDiagnosisCode","EncounterDiagnosisText",
      "EncounterDiagnosisCategory","EncounterProblemTypeCode","EncounterProblemTypeText","DocumentationDate",
      "ProblemResolutionDate","ProblemStatusCode","ProblemStatusText","ProblemHealthStatusCode","ProblemHealthStatusText",
      "NegationInd","ProblemComment","ProblemOnsetDate","TargetSiteCode","TargetSiteText","ListOrder","EncounterDiagnosisKey",
      "PracticeUid","BatchUid")).as("EncounterDiagnosis"))

      Some(EncounterDiagnosis)


}
catch {
  case ex: FileNotFoundException => {
  ex.printStackTrace()
    None
  }
  case unknown: Exception => {
    println(s"Unknown exception: $unknown")
    None
  }
}

  }
}
