package com.figmd.janus

import java.io.FileNotFoundException

import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
class PatientPlanOfCare (PlanOfCarePath : String){

  def PlanOfCareProcessing(spark: SparkSession ,mappingpracticecommondatamaster : DataFrame):
        Option[DataFrame] = {

    /*
  //Create map of file indices and column names
  val cachePatientPlanOfCareMapDF: Dataset[Row] = rt.joinedDf
    .filter($"CacheTableViewName"==="ViewCachePatientPlanOfCare")
  val lookup: collection.Map[String, String] = getLookupMap(cachePatientPlanOfCareMapDF)
  */

try {

  val lookup = Map("_c0" -> "PatientId", "_c1" -> "Instructions", "_c2" -> "PracticeCode",
    "_c3" -> "PracticeDescription","_c4" -> "EffectiveDate", "_c5" -> "PlanOfCareStatusCode", "_c6" -> "PlanOfCareStatusText",
    "_c7" -> "PlanOfCareGroup", "_c8" -> "PlanOfCareKey", "_c9" -> "PracticeUid", "_c10" -> "BatchUid"
    , "_c11" -> "dummy1", "_c12" -> "dummy2")

  //Read file for CachePatientPlanOfCare
  import spark.implicits._

  println("plant of care start...")
  val file: DataFrame = CommonFunc.readFile(PlanOfCarePath,spark)

  file.printSchema()

  //Apply lookup to generate file Header
  val CachePatientPlanOfCareDF: DataFrame = file.select(file.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)
    .drop("dummy1", "dummy2")

  CachePatientPlanOfCareDF.printSchema()

  //Get required functions for CachePatientPlanOfCare
  val patientPlanOfCare = new CachePlanOfCareFunctions(spark, mappingpracticecommondatamaster)

  val transformPatientPlanOfCareDF = CachePatientPlanOfCareDF
    .transform(patientPlanOfCare.PlanOfCareStatusText)
    .transform(patientPlanOfCare.PlanOfCareStatusCode)
    .transform(patientPlanOfCare.PracticeDescription)
    .transform(patientPlanOfCare.PracticeCode)

  val PanOfCareDf = transformPatientPlanOfCareDF
    .groupBy("PatientId","PracticeUid")
    .agg(collect_list(struct("EffectiveDate", "Instructions", "PlanOfCareStatusCode",
      "PlanOfCareStatusText", "MasterPlanOfCareStatusCode", "MasterPlanOfCareStatusText", "PlanOfCareGroup",
      "PracticeCode", "PracticeDescription", "MasterPlanOfCareCode", "MasterPlanOfCareText"))
      .as("PlanOfCare"))


  Some(PanOfCareDf)
}
catch {
  case ex: FileNotFoundException => {
    ex.printStackTrace()
    None
  }
  case unknown: Exception => {
    println(s"Unknown exception: $unknown")
    None
  }
}
  }
}
