package figmd.janus.exception

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

object wordCount {


    def main(args: Array[String])
    {

      Logger.getLogger("org").setLevel(Level.WARN)
      Logger.getLogger("akka").setLevel(Level.WARN)

      val spark = SparkSession.builder().master("local[*]").appName("wordCount")
        .config("spark.sql.warehouse.dir","/user/hive/warehouse")
        .config("spark.yarn.maxAppAttempts", "1")
        .config("hive.exec.dynamic.partition", "true")
        .config("hive.exec.dynamic.partition.mode", "nonstrict")
        .enableHiveSupport()
        .getOrCreate()


      val readFile = spark.read.option("header","true").option("inferSchema","true")
        .csv("temp_test/gajanan/abc3.txt")


      import spark.implicits._
      val partyear = readFile.select("year").distinct()
      val ListVal:Array[Any] = partyear.rdd.map(r => r(0)).collect()
      val PartitionYear = "(\"" + ListVal.mkString("\",\"") + "\")"

      val RequiredData = spark.sql(s"select * from testdb_update.student where year in $PartitionYear")


      val updaterecords = RequiredData.as("df1").join(readFile.as("df2"),Seq("id"),"left_outer")
        .select($"df1.*",$"df2.dept".as("newtab"))
        .withColumn("dept",$"newtab")
          .drop("newtab")

      val newData = readFile.as("df1").join(RequiredData.as("df2"),Seq("id"),"left_anti")

      val allRecords = updaterecords.union(newData)
      allRecords.show()
      //val pryear = allRecords.select("year").distinct()
      allRecords.write.mode("overwrite").partitionBy("Year").saveAsTable("testdb_update.patient")
      spark.sql("insert overwrite table testdb_update.student partition(Year) select id,name,dept,yoj,year from testdb_update.patient ")

      //spark.sql("insert overwrite table figmdcdr.patient partition(year) select  * from figmdcdr_temp.patient ")*/


      /*val ss = PatientDemoDF.head
      val dd =  ss.withColumn("Year",year($"DOB"))
      println("Partition column ...................................")
      dd.write.mode("overwrite").partitionBy("Year").saveAsTable("figmdcdr_temp.patient")
      sparkSess.sql("insert overwrite table figmdcdr.patient partition(year) select  * from figmdcdr_temp.patient ")*/


      /*  val dd = CachepatientDemo1.withColumn("Year",year($"DOB")).select("Year").distinct()

        val ListVal:Array[Any] = dd.rdd.map(r => r(0)).collect()
        val PartitionYear = "(\"" + ListVal.mkString("\",\"") + "\")"

        val RequiredData = sparkSess.sql(s"select * from figmdcdr.patient where year in $PartitionYear")*/
/*
      val updatenotupdatepatient = RequiredData.as("df1").join(CachepatientDemo1.as("df2"),
        Seq("PatientId","PracticeUid","PatientUid"),"left_outer").select($"df1.*",$"df2.Country"
        .as("MappedValue"))
        .withColumn("StreetLineAddress2",CommonFunc.updateWithJoin($"MappedValue",$"StreetLineAddress2"))
          .drop("MappedValue","Year")

      val newPatient =  CachepatientDemo1.as("df1").join(RequiredData.as("df2"),
        Seq("PatientId","PracticeUid"),"left_anti").select($"df1.*")*/


     /* val textfile = spark.sparkContext.textFile("/home/gajanan.doifode/AAO_DATA/abc2.txt")

      val word = textfile.filter(x => x.length >  0).map(_.split('|'))
      val keys = word.map(tuple => (tuple(0),tuple(5),(tuple(6)) ))
      val data = keys.map(x => x._1 + "," + x._2+ "," + x._3)
      val srch = data.filter(_.contains("PID"))
      srch.coalesce(1).saveAsTextFile("/home/gajanan.doifode/AAO_DATA/NewStructure/HL7")
      data.coalesce(1).saveAsTextFile("/home/gajanan.doifode/AAO_DATA/NewStructure/HL7/Data")*/
    }
  }


