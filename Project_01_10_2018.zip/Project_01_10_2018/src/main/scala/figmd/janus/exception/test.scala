package figmd.janus.exception

object test {




  import org.apache.log4j.{Level, Logger}
  import org.apache.spark.sql.SparkSession
  import org.apache.spark.sql.functions._
  object Test {

    def main(args: Array[String]): Unit = {

      Logger.getLogger("org").setLevel(Level.WARN)
      Logger.getLogger("akka").setLevel(Level.WARN)

      val warehouseLocation = "/user/hive/warehouse"

      //val sparkSess = SparkSession.builder().appName("Spark Hive Example").master("local[*]").getOrCreate()
      val sparkSess = SparkSession.builder()
        .appName("Spark Hive Example")
        .master("local[*]")
        .config("spark.sql.warehouse.dir", warehouseLocation)
        .enableHiveSupport()
        .getOrCreate()

      import sparkSess.implicits._

      val file = sparkSess.read.option("header","true").csv("file:///home/dev/gajanan/abc.txt")

      val df = file.groupBy("PatientId").agg(collect_list("startdate").as("EffectiveStartDate"))
        .withColumn("no_of_values", size($"EffectiveStartDate"))

      df.show(false)

      val dd = sparkSess.sql("select PatientId,EffectiveStartDate,AllergicToDescription from gaju.patientdemographics")
      //.withColumn("no_of_values", size($"EffectiveStartDate"))

      val cacheAllergy4 = dd.groupBy("patientId")
        .agg(collect_list(struct("EffectiveStartDate", "AllergicToDescription")).as("allcols")).toJSON
        .select(
          get_json_object($"value", "$.patientId").as("patientId"),
          get_json_object($"value", "$.allcols").as("AllCols")
        )

      cacheAllergy4.printSchema()
      cacheAllergy4.show(10,false)

      /*val joinData = dd.as("df1").join(df.as("df2"),Seq("PatientId"))
          .select($"df1.*",$"df2.EffectiveStartDate".as("newDate"),$"df2.no_of_values".as("count2"))
          .withColumn("EffectiveStartDate",when($"count2" > $"no_of_values",$"newDate")
          .otherwise($"EffectiveStartDate"))
          .withColumn("no_of_values",when($"count2" > $"no_of_values",$"count2")
          .otherwise($"no_of_values"))
          .drop("newDate","count2")*/




      // joinData.show(false)

      /* val dd = sparkSess.sql("select * from gaju.patientdemographics where Year = '1998'")
            .withColumn("Year", lit("1999"))
        println(dd.count())*/

      /* val dd = sparkSess.sql("select * from gaju.patientdemographics where Year = '1999'")
       println(dd.count())*/
      //dd.write.mode("overwrite").save("/user/hive/warehouse/gaju.db/patientdemographics/Year=1999")
      //dd.show(false)
      /* val dd = sparkSess.sql("select p.PatientId,f1.s1,f2.s2 from gaju.patientdemographics p " +
        "LATERAL VIEW EXPLODE(p.EffectiveStartDate) f1 as s1," +
        "LATERAL VIEW EXPLODE(p.AllergicToDescription) f2 as s2")*/
      /*
          val dd = sparkSess.sql("select t1.q1,t2.q2 from gaju.patientdemographics p " +
            "lateral view explode(p.EffectiveStartDate) t1 as q1" +
            " lateral view explode(p.AllergicToDescription) t2 as q2")

          println("Count is..  "+dd.count())
          dd.show(100,false)*/

      /* val filtercols = dd.select("PatientId","EffectiveStartDate","EffectiveEndDate","AllergicToDescription"
       ,"AllergyTypeCode","AllergyEventType","AllergicToCode","AllergyStatusCode","AllergyStatusText","AllergyReaction")
           .withColumn("EffectiveStartDate",explode_outer($"EffectiveStartDate"))
           .withColumn("AllergicToDescription",explode_outer($"AllergicToDescription"))
           .withColumn("EffectiveEndDate",explode_outer($"EffectiveEndDate"))
           .withColumn("AllergyTypeCode",explode_outer($"AllergyTypeCode"))
           .withColumn("AllergyEventType",explode_outer($"AllergyEventType"))
           .withColumn("AllergicToCode",explode_outer($"AllergicToCode"))
           .withColumn("AllergyStatusCode",explode_outer($"AllergyStatusCode"))
           .withColumn("AllergyStatusText",explode_outer($"AllergyStatusText"))
         .withColumn("AllergyReaction",explode_outer($"AllergyReaction")).distinct()

       println("Count is..  "+filtercols.count())*/
      //filtercols.show(100,false)


      /* ,collect_list("MasterAllergyStatusCode").as("MasterAllergyStatusCode")
       ,collect_list("MasterAllergyStatusText").as("MasterAllergyStatusText")
       ,collect_list("MasterAllergicToCode").as("MasterAllergicToCode")
       ,collect_list("MasterAllergyDescription").as("MasterAllergyDescription")*/




      /*//val file = sparkSess.read.option("delimiter","|").option("inferSchema","true").csv("/home/gajanan.doifode/AAO_DATA/NewStructure/PatientDemographics_testfile_bckup.csv")
      val file = sparkSess.read.option("delimiter", ",").option("inferSchema", "true").option("header", "true")
        .csv("/home/gajanan.doifode/AAO_DATA/patientData.txt")

      val file2 = sparkSess.read.option("delimiter", ",").option("inferSchema", "true").option("header", "true")
        .csv("/home/gajanan.doifode/AAO_DATA/MedicationData.txt")

      val df2 = file2.select("patientId","medication","startdate")
        .groupBy("patientId")
        .agg(collect_list("medication").as("Medication")
        ,collect_list("startdate").as("startdate"))

      val joinData = file.as("df1").join(df2.as("df2"), Seq("patientId"))

      joinData.printSchema()
      joinData.show(false)*/


    }
  }

}
