package figmd.janus.exception

import java.util.{Calendar, UUID}


import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object FileHandling {

  val getNewUid = udf[String](() => {
    UUID.randomUUID.toString
  })

  var list  = List
  def main(args: Array[String]): Unit = {


    println("Start Programme......................")
    Logger.getLogger("org").setLevel(Level.WARN)
    Logger.getLogger("akka").setLevel(Level.WARN)


      val  bdawsaccessKey = "AKIALH6XLTJCI6I3N5RQ"
       val  bdawssecretKey = "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"

    val sparkSess = SparkSession.builder().master("yarn").appName("FileHandling")
      .config("fs.s3n.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem")
      .config("fs.s3.awsAccessKeyId", bdawsaccessKey)
      .config("fs.s3.awsSecretAccessKey", bdawssecretKey)
      .config("spark.sql.warehouse.dir","/user/hive/warehouse")
      .enableHiveSupport()
      .getOrCreate()

/*
    val visit = sparkSess.read.option("header","true").parquet("s3://bd-dev/AAOData/alldata/gaju/visit/")

    val df1StartTime = Calendar.getInstance.getTime

    println("visit Start.......")
      visit.write
      .partitionBy("PracticeUid")
      .mode("overwrite")
      .option("path","s3://bd-dev/AAOData/NewRecords/PHI/PatientVisit/")
      .saveAsTable("newfigmdcdr.patientvisit")

    println("visit done.......")

    val procedure2 = sparkSess.read.option("header","true").parquet("s3://bd-dev/AAOData/alldata/gaju/patientprocedure/")

    println("procedure2 start.......")

    procedure2.write
      .partitionBy("PracticeUid")
      .mode("overwrite")
      .option("path","s3://bd-dev/AAOData/NewRecords/PHI/PatientProcedure/")
      .saveAsTable("newfigmdcdr.patientprocedure")

    println("procedure2 done.......")*/

   /* val file = sparkSess.sparkContext.textFile("s3://bd-dev/REGDATA_AAO/PatientNotes/")

    file.collect.foreach(println)*/

    val file2 = sparkSess.read.option("delimiter","\u0017").csv("s3://bd-dev/REGDATA_AAO/PatientNotes/129e36f5-51dd-412c-8a83-15f50cc6563e_004a80cd-bd57-4a55-aa4d-a7dde9ad036b_3bd0ba70-f095-4527-9830-841bbf78db6c_1770558595_09212018103044444.txt")

    val CachePatientNoteslookup = Map("_c0" -> "PatientId", "_c1" -> "referencedDate", "_c2" -> "SectionName", "_c3" -> "Note",
      "_c4" -> "ServiceProviderNPI", "_c5" -> "ServiceProviderLastName", "_c6" -> "ServiceProviderFirstName",
      "_c7" -> "ServiceLocationId", "_c8" -> "ServiceLocationName", "_c9" -> "Group1", "_c10" -> "Group2", "_c11" -> "Group3",
      "_c12" -> "Group4", "_c13" -> "PracticePatientNoteKey", "_c14" -> "PracticeUid", "_c15" -> "BatchUid"
      , "_c16" -> "dummy1", "_c17" -> "dummy2")



    val CachePatientNotes = file2.select(file2.columns.map(c => col(c).as(CachePatientNoteslookup.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    CachePatientNotes.show(false)


    val file3 = sparkSess.read.option("delimiter","\u0017").option("header","true")
      .option("multiline","true").csv("s3://bd-dev/REGDATA_AAO/PatientNotes/")

    val dd = file3.select(file3.columns.map(c => col(c).as(CachePatientNoteslookup.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    dd.show()
    /*val df1StartTime = Calendar.getInstance.getTime
    val vitalsign = sparkSess.read.option("header","true").parquet("s3://bd-dev/AAOData/alldata/gaju/patientvitalsignobservation/")
    println("vitalsign done.......")

     vitalsign.write
      .partitionBy("PracticeUid")
      .mode("overwrite")
      .option("path","s3://bd-dev/AAOData/NewRecords/PHI/Patientvitalsignobservation/")
      .saveAsTable("newfigmdcdr.patientvitalsignobservation")

    val df2EndTime = Calendar.getInstance.getTime


    println("Star time is  .... "+df1StartTime)
    println("end time is ....." +df2EndTime)
    println("vitalsign done.......")*/


   /* val file3 = "s3://bd-dev/AAOData/alldata/gaju/patientproblem/"
    val df2 = sparkSess.read.option("header","true").parquet(file3)
    println("Read file is done............")

    df2.write
      .partitionBy("PracticeUid")
      .mode("overwrite")
      .option("path","s3://bd-dev/AAOData/NewRecords/PHI/PatientProblem2/")
      .saveAsTable("newfigmdcdr.patientproblem2")
*/

      /*df2.write
      .partitionBy("PracticeUid")
      .mode("overwrite")
      .option("path","s3://bd-dev/AAOData/NewRecords/Clinical/PatientProblem/")
      .saveAsTable("figmdcdr_new.patientproblem")
*/

    println("DataWrite into Hive is done..............................")
   /* df2.printSchema()
    println(df2.count())
    df2.show()*/


      /*.partitionBy("PracticeUid")
      //.format("parquet")
      //.bucketBy(40, "Year")
      //.sortBy("PatientId")
      .mode("overwrite")
      .saveAsTable("figmdcdr_new.patientproblem")
    //.parquet("s3://bd-dev/AAOData/NewRecords/Clinical/PatientProblem/")*/

   /* val FileName1 = "/home/gajanan.doifode/AAO_DATA/student.txt"
    val FileName2 = "/home/gajanan.doifode/AAO_DATA/student.txt"
    //val file3 = "s3://bd-dev/samplenewdata/PatientDemographics/"


        val df2 = sparkSess.read.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/student.txt")
        val df3 = sparkSess.read.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/NewStudent.txt")
        val df4 = sparkSess.read.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/SparkData")

    val df1StartTime = Calendar.getInstance.getTime
   val joindf = df2.as("df1").join(df3,Seq("id")).select($"df1.*").show(1000000)
    val df1EndTime = Calendar.getInstance.getTime

    val df2StartTime = Calendar.getInstance.getTime
    val joindfCross = df2.as("df1").crossJoin(df3.as("df4")).where($"df1.id" === $"df4.id")
      .select($"df1.*").show(10000000)
    val df2EndTime = Calendar.getInstance.getTime



    println("df1 Start Time    : " + df1StartTime)
    println("df1 End Time    : " + df1EndTime)
    println("df2 Start Time    : " + df2StartTime)
    println("df2 End Time    : " + df2EndTime)*/

    //val df2 = sparkSess.read.option("delimiter","\u0017").csv(file3).cache()



   /* val value = conf.getString("db_table")*/
    //val value2 = conf.getString("table_Name")
   /* val value = ConfigFactory.load().getString("db_name")
    println(s"My secret value is $value")
    val value2 = ConfigFactory.load().getString("table_Name")
    println(s"My secret value is $value2")*/
  //val value3 = value + "." + value2
   /* /*println(s"My secret value is $value")*/
    val dd = (new FileFunctions(sparkSess)).FirstFileRead(FileName1,df2,df3).toList

    val df = (new FileFunctions(sparkSess)).SecondFileRead(FileName2).toList

    val ss = dd ++ df

    val pp =  ss.tail.foldLeft(ss.head)((accDF, newDF) => accDF.join(newDF, Seq("id")))
    pp.show(false)*/
/*
    def show(x: Option[DataFrame]) = x match {
      case Some(df) => if(!df.head(1).isEmpty){
      //makeList(df)
      }
      case None => "?"
    }
show(dd)*/

   /* def makeList(frame: sql.DataFrame): Unit ={
      var list : DataFrame = List[DataFrame]
      list += frame
    }*/
    println("End Programme......................")

  }

}
