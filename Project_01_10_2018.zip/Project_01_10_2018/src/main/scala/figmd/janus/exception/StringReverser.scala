package figmd.janus.exception

object StringReverser {


  def revers1(str : String): Unit = {
    val s = str.reverse
    println("Reverse String is = "+s )

  }

  def revers2(str : String): Unit = {

    val buf = new StringBuilder
    val len = str.length
    println("Length of String" +len)
    for(i <- 0 until len){
      buf.append(str.charAt(len - i - 1)).toString()
    }
    println("Reverse String is = "+buf )
  }


  def reverse3(str : String): String = {

    val len = str.length
    if (len == 1) {
      str
    } else {
      println("Substring "+ str.substring(1, len) +"  " + "charecter at " + str.charAt(0))
      reverse3(str.substring(1, len)) + str.charAt(0)
    }
  }

  def main(args: Array[String]): Unit = {

    //revers2("Gajanan")
    val ss = reverse3("Gajanan")
    println(ss)

  }
}

