package figmd.janus.exception

import java.io.FileNotFoundException

import org.apache.spark.sql.functions.{collect_list, struct}

import org.apache.spark.sql.{DataFrame, SparkSession}

class FileFunctions(sparkSess : SparkSession) {


  import sparkSess.implicits._
  def FirstFileRead(FileName : String , df : DataFrame,df3 : DataFrame): Option[DataFrame] = {

/*
    if(df.head(1).isEmpty) {
      throw new Exception("Sorry, you're ineligible yet")
    }*/
    try{
    val file1 = sparkSess.read.option("header","true").csv(FileName)

    println(".......................................................................")
    val allreadyPresent = file1.as("df1").join(df3.as("df2"),Seq("id")).select($"df1.id",$"df2.*")
    allreadyPresent.show(false)
    println(".......................................................................")
    val newData = df3.except(allreadyPresent).sort("id")
    newData.show(false)
    println(".......................................................................")
     val ss = file1.groupBy("id")
         .agg(collect_list(struct("name","add","date")).as("new_column"))
    ss.printSchema()
    ss.select("new_column.name").show(false)

    Some(file1)
    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File $FileName not found")
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }

  }



  def SecondFileRead(FileName : String): Option[DataFrame] = {

    try{
      val file2 = sparkSess.read.option("header","true").csv(FileName)
      println("file is Present" +FileName)
      Some(file2)

    }catch {
      case ex: FileNotFoundException => {
        println(s"File $FileName not found")
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }
  }

}
