package figmd.janus.exception

import org.apache.spark.sql.{DataFrame, SparkSession}

class JoinDataframes {

  def joindf(seq: Seq[DataFrame],spark : SparkSession): Unit =
  {
   /* val df1 = Seq(0)
    val df2 = Seq(1)
    val df3 = Seq(2)

    import spark.implicits._
    val joindf = df1.join(df2,Seq("id")).join(df3,Seq("id")).select($"df1.*")
    joindf.show(false)*/

  }
}
