package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.ProcedureTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}

import scala.collection.Map
class PatientProcedure(ProcedurePath : String,selectedIds : DataFrame) extends  Serializable {


  def cachePatientProcedureProceesing(spark : SparkSession, mappingPracticeProcedure : DataFrame
                                      , mappingpracticecommondatamaster : DataFrame)  {

    import spark.implicits._

    try {

      val mainTableName = ApplicationConfig.prop.getProperty("CDRProcedure")
      val stagetableName = ApplicationConfig.prop.getProperty("StageProcedure")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationProcedure")
      val validations = new ValidationCriteria(spark)

      val file = CommonFunc.readFile(ProcedurePath,spark).drop("dummy1", "dummy2")
        .withColumn("ProcedureDate", to_timestamp($"ProcedureDate", "MM/dd/yyyy HH:mm:ss"))

/*
      val lookup1 = Map("_c0" -> "PatientId", "_c1" -> "ProcedureCode", "_c2" -> "ProcedureText", "_c3" -> "ProcedureCategory",
        "_c4" -> "ProcedureDate", "_c5" -> "TargetSiteCode", "_c6" -> "TargetSiteText", "_c7" -> "ServiceProviderNPI", "_c8" -> "ServiceProviderLastName",
        "_c9" -> "ServiceProviderFirstName", "_c10" -> "ServiceLocationId", "_c11" -> "ServiceLocationName", "_c12" -> "ProcedureStatusCode", "_c13" -> "ProcedureStatusText",
        "_c14" -> "NegationInd", "_c15" -> "ProcedureComment", "_c16" -> "Modifier1", "_c17" -> "Modifier2", "_c18" -> "Modifier3", "_c19" -> "Modifier4",
        "_c20" -> "Insurance", "_c21" -> "ProceduresKey", "_c22" -> "PracticeUid", "_c23" -> "BatchUid", "_c24" -> "dummy1", "_c25" -> "dummy2")

      val cachePatientProcedure = file.select(file.columns.map(c => col(c).as(lookup1.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("ProcedureDate", to_timestamp($"ProcedureDate", "MM/dd/yyyy HH:mm:ss"))
*/

      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)
      val schema = file.schema.add(StructField("ErrorMessage",StringType))

      val cachePatientProcedureValidations = file
        .transform(validations.removeDuplicateRecords("PatientId","ProcedureCode","ProcedureDate"))
        .transform(validations.removeDuplicateRecords("PatientId","ProcedureText","ProcedureDate"))
        .transform(validations.removeDuplicateRecords("PatientId","ProcedureCode","ProcedureDate","ServiceProviderNPI"))
        .transform(validations.removeDuplicateRecords("PatientId","ProcedureText","ProcedureDate","ServiceProviderNPI"))


      val CleanedRecords = cachePatientProcedureValidations.filter(row => validations.checkNull(row,broadcastRows,"PatientId","ProcedureDate","ProcedureCode","ProcedureText"))

      val addPatientUid =  CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*",$"df2.PatientUid")

      val ProcedureObj = new ProcedureTransformFunctions(spark, mappingPracticeProcedure, mappingpracticecommondatamaster)

      val cachePatientProcedure3 = addPatientUid
        .transform(ProcedureObj.PracticeCode)
        .transform(ProcedureObj.PracticeDescription)
        .transform(ProcedureObj.ProcedureStatusCode)
        .transform(ProcedureObj.ProcedureStatusText)
        .transform(ProcedureObj.TargetSiteCode)
        .transform(ProcedureObj.TargetSiteText)

      HiveUtility.dfwritetohive(cachePatientProcedure3,mainTableName,spark,stagetableName,s3Path)
      val errList = validations.errorList += spark.createDataFrame(rows,schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.csv("temp_test/patientProcedure_error")
      broadcastRows.destroy()


      /*val distinctPUid = cachePatientProcedure3.select("PracticeUid").distinct()

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val ProcedureData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

     val FiletoJoin = cachePatientProcedure3.select("PracticeUid","PatientId","PatientUid").distinct()
     //broadcast(FiletoJoin)

      val otherData = ProcedureData.as("df1").join(FiletoJoin.as("df2")
        ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid","left_anti")
        .select($"df1.*")

     val newstructure = cachePatientProcedure3.select(otherData.columns.head,otherData.columns.tail:_*)

      val allProcedureData = newstructure.union(otherData)
     HiveUtility.dfwritetohive(allProcedureData,mainTableName,sparkSess,stagetableName,s3Path)*/


    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }
  }

}
