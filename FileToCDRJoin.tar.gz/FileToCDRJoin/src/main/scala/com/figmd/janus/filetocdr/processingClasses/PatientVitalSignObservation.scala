package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.VitalSignObsTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.Map

class PatientVitalSignObservation(VitalSignPath : String,selectedIds : DataFrame) extends  Serializable{

  def VitalSignObservationProcessing(spark: SparkSession, mappingpracticecommondatamaster : DataFrame
                                     ) = {
    import spark.implicits._

    /*
  //Create map of file indices and column names
  val cachePatientVitalSignObservationMapDF: Dataset[Row] = rt.joinedDf
    .filter($"CacheTableViewName"==="ViewCachePatientVitalSignObservation")
  val lookup: collection.Map[String, String] = getLookupMap(cachePatientVitalSignObservationMapDF)
  */

    try {

      println("Vital Sign start...........")
      val mainTableName = ApplicationConfig.prop.getProperty("CDRVitalSignObs")
      val stagetableName = ApplicationConfig.prop.getProperty("StageVitalSignObs")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationVitalSignObs")
      val validations = new ValidationCriteria(spark)


      val lookup = Map("_c0" -> "PatientId", "_c1" -> "ObservationCode", "_c2" -> "ObservationName",
        "_c3" -> "ObservationCategory", "_c4" -> "ObservationDate", "_c5" -> "ObservationValue"
        , "_c6" -> "ObsInterpretationCode", "_c7" -> "ObsInterpretationText"
        , "_c8" -> "TargetSiteCode", "_c9" -> "TargetSiteText", "_c10" -> "NegationInd",
        "_c11" -> "ReferenceLowerRange", "_c12" -> "ReferenceUpperRange", "_c13" -> "MethodCode"
        , "_c14" -> "MethodCodeText", "_c15" -> "ResultOBSUnit", "_c16" -> "VitalSignsKey"
        , "_c17" -> "PracticeUid", "_c18" -> "BatchUid","_c19" -> "dummy1", "_c20" -> "dummy2")

      //Read file for CachePatientVitalSignObservation
      val file: DataFrame = CommonFunc.readFile(VitalSignPath,spark)

      //Apply lookup to generate file Header
      val CachePatientVitalSignObservationDF: DataFrame = file.select(file.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("ObservationDate", to_timestamp($"ObservationDate", "MM/dd/yyyy HH:mm:ss"))

      val addPatientUid =  CachePatientVitalSignObservationDF.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*",$"df2.PatientUid")

      val patientVitalSignObservationDF = new VitalSignObsTransformFunctions(spark, mappingpracticecommondatamaster)

      println("Vital Sign goes to lookup...........")
      val transformPatientVitalSignObservationDF = addPatientUid
        .transform(patientVitalSignObservationDF.PracticeDescription)
        .transform(patientVitalSignObservationDF.PracticeCode)
        .transform(patientVitalSignObservationDF.TargetSiteText)
        .transform(patientVitalSignObservationDF.TargetSiteCode)
        .transform(patientVitalSignObservationDF.ObsInterpretationText)
        .transform(patientVitalSignObservationDF.ObsInterpretationCode)


      HiveUtility.dfwritetohive(transformPatientVitalSignObservationDF,mainTableName,spark,stagetableName,s3Path)
     /* println("Vital Sign goes to lookup end...........")
      val distinctPUid = transformPatientVitalSignObservationDF.select("PracticeUid").distinct()

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val vitalsignData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = transformPatientVitalSignObservationDF.select("PracticeUid","PatientId","PatientUid")
          .distinct()
      //broadcast(FiletoJoin)

      val otherData = vitalsignData.as("df1").join(FiletoJoin.as("df2")
        ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid","left_anti")
        .select($"df1.*")

      val newstructure = transformPatientVitalSignObservationDF.select(otherData.columns.head,otherData.columns.tail:_*)
      val AllVitalSignData = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllVitalSignData,mainTableName,spark,stagetableName,s3Path)

*/
    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }

}
