package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}

class SocialHistoryObsTransformFunc(sparkSess : SparkSession, mappingpracticecommondatamaster : DataFrame) {


  import sparkSess.implicits._

  def SocialHistoryTypeCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.SocialHistoryTypeCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterSocialHistoryTypeCode")
        ,$"df2.CodeDescription".as("MasterSocialHistoryTypeText"))
  }

  def SocialHistoryTypeText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.SocialHistoryTypeText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterSocialHistoryTypeCode")
        ,$"df2.CodeDescription".as("MappedMasterSocialHistoryTypeText"))
      .withColumn("MasterSocialHistoryTypeCode",when($"MappedMasterSocialHistoryTypeCode".isNull,$"MasterSocialHistoryTypeCode")
        .otherwise($"MappedMasterSocialHistoryTypeCode"))
      .withColumn("MasterSocialHistoryTypeText",when($"MappedMasterSocialHistoryTypeText".isNull,$"MasterSocialHistoryTypeText")
        .otherwise($"MappedMasterSocialHistoryTypeText"))
      .drop("MappedMasterSocialHistoryTypeCode","MappedMasterSocialHistoryTypeText")
  }

  def SocialHistoryStatusCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.SocialHistoryStatusCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterSocialHistoryStatusCode")
        ,$"df2.CodeDescription".as("MasterSocialHistoryStatusText"))
  }

  def SocialHistoryStatusText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.SocialHistoryStatusText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterSocialHistoryStatusCode")
        ,$"df2.CodeDescription".as("MappedMasterSocialHistoryStatusText"))
      .withColumn("MasterSocialHistoryStatusCode",when($"MappedMasterSocialHistoryStatusCode".isNull,$"MasterSocialHistoryStatusCode")
        .otherwise($"MappedMasterSocialHistoryStatusCode"))
      .withColumn("MasterSocialHistoryStatusText",when($"MappedMasterSocialHistoryStatusText".isNull,$"MasterSocialHistoryStatusText")
        .otherwise($"MappedMasterSocialHistoryStatusText"))
      .drop("MappedMasterSocialHistoryStatusCode","MappedMasterSocialHistoryStatusText")
  }


}
