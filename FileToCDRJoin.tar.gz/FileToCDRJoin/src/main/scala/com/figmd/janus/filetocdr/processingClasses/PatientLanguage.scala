package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.Map

class PatientLanguage(LanguagePath : String,selectedIds : DataFrame) extends  Serializable{


  def cachepatientLangProcessing(spark : SparkSession)  {


    //Start ImportPatientLanguageData

    try {

      import spark.implicits._
      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientLang")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientLang")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientLang")
      val validations = new ValidationCriteria(spark)

      var CachePatientLanguage = CommonFunc.readFile(LanguagePath,spark)

      val lookup11 = Map("_c0" -> "PatientId", "_c1" -> "LanguageCode", "_c2" -> "LanguageText"
        , "_c3" -> "LangaugeAbilityModeCode", "_c4" -> "LangaugeAbilityModeText", "_c5" -> "LanguageProficiencyLevelCode"
        , "_c6" -> "LanguageProficiencyLevelText", "_c7" -> "PreferenceInd", "_c8" -> "PatientLanguageKey"
        , "_c9" -> "PracticeUid", "_c10" -> "BatchUid", "_c11" -> "dummy1"
        , "_c12" -> "dummy2")

      CachePatientLanguage = CachePatientLanguage.select(CachePatientLanguage.columns.map(c => col(c).as(lookup11.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")

      val addPatientUid =  CachePatientLanguage.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*",$"df2.PatientUid")


      HiveUtility.dfwritetohive(addPatientUid,mainTableName,spark,stagetableName,s3Path)
     /* val distinctPUid = addPatientUid.select("PracticeUid").distinct()
      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val LanguageData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = addPatientUid.select("PracticeUid","PatientId","PatientUid").distinct()
      //broadcast(FiletoJoin)

      val otherData = LanguageData.as("df1").join(FiletoJoin.as("df2")
        ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid","left_anti")
        .select($"df1.*")


      val newstructure = addPatientUid.select(otherData.columns.head,otherData.columns.tail:_*)
      val AllLanguageData = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllLanguageData,mainTableName,sparkSess,stagetableName,s3Path)*/

    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }
}
