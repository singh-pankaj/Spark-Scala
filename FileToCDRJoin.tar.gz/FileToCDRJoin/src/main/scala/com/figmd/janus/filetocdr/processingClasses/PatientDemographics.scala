package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util
import java.util.Calendar

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions.{col, to_timestamp}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}

class PatientDemographics(DemoPath : String){



  def demoProcessing(spark : SparkSession):Option[DataFrame] = {

    import spark.implicits._


    try{
      val file = CommonFunc.readFile(DemoPath,spark)
        .drop("dummy1", "dummy2")

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatient")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatient")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatient")
      val validations = new ValidationCriteria(spark)

      println("file path..." +DemoPath)
//
//      val lookup = Map("_c0" -> "PatientId", "_c1" -> "LastName", "_c2" -> "FirstName", "_c3" -> "MiddleName", "_c4" -> "StreetLineAddress1"
//        , "_c5" -> "StreetLineAddress2", "_c6" -> "StreetLineAddress3", "_c7" -> "StreetLineAddress4", "_c8" -> "City", "_c9" -> "StateCode"
//        , "_c10" -> "State", "_c11" -> "ZipCode", "_c12" -> "CountryCode", "_c13" -> "Country", "_c14" -> "TelecomTypeText1"
//        , "_c15" -> "TelecomValue1", "_c16" -> "TelecomTypeText2", "_c17" -> "TelecomValue2", "_c18" -> "Gender", "_c19" -> "DOB"
//        , "_c20" -> "DeathDate", "_c21" -> "MaritalStatusCode", "_c22" -> "MaritalStatusText", "_c23" -> "ReligiousAffiliationCode"
//        , "_c24" -> "ReligiousAffiliationText", "_c25" -> "BirthStateCode", "_c26" -> "BirthState", "_c27" -> "BirthZipCode"
//        , "_c28" -> "BirthCountryCode", "_c29" -> "BirthCountry", "_c30" -> "ServiceProviderNPI", "_c31" -> "ServiceProviderLastName"
//        , "_c32" -> "ServiceProviderFirstName", "_c33" -> "SSN", "_c34" -> "DeathReason", "_c35" -> "IsDeceased", "_c36" -> "Patient_EMR_ID"
//        , "_c37" -> "EmailID", "_c38" -> "LocationOfDeath", "_c39" -> "BirthOrder", "_c40" -> "MultipleBirthPlaceIndicator"
//        , "_c41" -> "PatientDemographicsKey", "_c42" -> "PracticeUid","_c43" -> "BatchUid","_c44" -> "dummy1","_c45" -> "dummy2")
//
//
//      val CachepatientDemo = file.select(file.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)
//        .drop("dummy1","dummy2")
//
//      CachepatientDemo.show()
      val CachepatientDemo1 =  file.withColumn("DOB", to_timestamp($"DOB", "MM/dd/yyyy HH:mm:ss"))


      val schema = CachepatientDemo1.schema.add(StructField("ErrorMessage",StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)

      val cachePatientDemoValidations = CachepatientDemo1
        .transform(validations.removeDuplicateRecords("PatientId","PracticeUid"))

      val CleanedRecords = cachePatientDemoValidations.filter(row => validations.checkNull(row,broadcastRows,"PatientId","PracticeUid","FirstName","LastName","DOB","Gender"))


//      val CleanedRecords = CachepatientDemo1.dropDuplicates("PatientId","PracticeUid")

      val tempPatUid = CleanedRecords.select("PatientId", "PracticeUid").distinct()
        .withColumn("PatientUid",CommonFunc.getNewUid())

      val PatUid = tempPatUid.persist()
      //broadcast(PatUid)

      val CachepatientDemo2 = CleanedRecords.as("df1").join(PatUid.as("df2")
        ,  $"df1.PracticeUid" === $"df2.PracticeUid"  && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid").drop("dummy1","dummy2")

      HiveUtility.dfwritetohive(CachepatientDemo2,mainTableName,spark,stagetableName,s3Path)

      val errList = validations.errorList += spark.createDataFrame(rows,schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.csv("temp_test/patientDemo_error")
      broadcastRows.destroy()
      val send3uids  = CachepatientDemo2.select($"PracticeUid",$"PatientId",$"PatientUid")

      Some(send3uids)

      //val distinctPUid = CleanedRecords.select("PracticeUid").distinct()
      /*val fileJoinids = CleanedRecords.select("PracticeUid","PatientId")
     // broadcast(fileJoinids)

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"


      val RequiredData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      //println("RequiredData Demo Data.....  "+RequiredData.count())

      val UUIDs = RequiredData.select("PracticeUid","PatientId","PatientUid").distinct()
     // broadcast(UUIDs)

      val PreviousPatient = CleanedRecords.as("df1").join(UUIDs.as("df2"),
        Seq("PracticeUid","PatientId"),"inner").select($"df1.*",$"df2.PatientUid")
        .drop("dummy1","dummy2")

     // println("PreviousPatient Demo Data.....  "+PreviousPatient.count())

      val newPatient =  CleanedRecords.as("df1").join(UUIDs.as("df2"),
        Seq("PracticeUid","PatientId"),"left_anti").select($"df1.*")

     // println("newPatient Demo Data.....  "+newPatient.count())

      val tempPatUid = newPatient.select("PatientId", "PracticeUid").distinct()
        .withColumn("PatientUid",CommonFunc.getNewUid())

      val PatUid = tempPatUid.persist()
      //broadcast(PatUid)

      val CachepatientDemo2 = newPatient.as("df1").join(PatUid.as("df2")
        ,  $"df1.PracticeUid" === $"df2.PracticeUid"  && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid").drop("dummy1","dummy2")

      val OtherPatient =  RequiredData.as("df1").join(fileJoinids.as("df2"),
        Seq("PracticeUid","PatientId"),"left_anti").select($"df1.*")

     /* PreviousPatient.printSchema()
      CachepatientDemo2.printSchema()
      OtherPatient.printSchema()*/

      val allRecords = PreviousPatient.union(CachepatientDemo2).union(OtherPatient)

      //println("Processing End time for Demo.. "+Calendar.getInstance.getTime)
      HiveUtility.dfwritetohive(allRecords,mainTableName,sparkSess,stagetableName,s3Path)
      val send3uids  = allRecords.select("PracticeUid","PatientId","PatientUid")
      Some(send3uids)*/

    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
       None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }

  }


}
