package com.figmd.janus.filetocdr

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.processingClasses._
import com.figmd.janus.filetocdr.util.{Postgressutility, SparkUtility}
import org.apache.spark.sql.functions._
import org.apache.log4j.{Level, Logger}

import scala.collection.Map

//spark-submit --master yarn --deploy-mode cluster --executor-memory 5G --num-executors 5 --executor-cores 3 --class com.figmd.janus.filetocdr.CDRProcessing /home/dev/Akshay/filetocdrjoin_2.11-0.1.jar


object CDRProcessing {

  def main(args: Array[String]): Unit = {


    ApplicationConfig.setApplicationConfig(args)

    val sparkUtility = new SparkUtility()
    val sparkSess = sparkUtility.getSparkSession()
    val ReadTBL = new Postgressutility

    Logger.getLogger("org").setLevel(Level.WARN)
    Logger.getLogger("akka").setLevel(Level.WARN)


    import  sparkSess.implicits._

    println("Start programme............................")
    val tbl1 = ApplicationConfig.prop.getProperty("Allergy")
    val tbl2 = ApplicationConfig.prop.getProperty("Procedure")
    val tbl3 = ApplicationConfig.prop.getProperty("PracticeCommonData")
    val tbl4 = ApplicationConfig.prop.getProperty("Ethinicity")
    val tbl5 = ApplicationConfig.prop.getProperty("Race")
    val tbl6 = ApplicationConfig.prop.getProperty("Insurance")
    val tbl7 = ApplicationConfig.prop.getProperty("Problem")
    val tbl8 = ApplicationConfig.prop.getProperty("Medication")
    val tbl9 = ApplicationConfig.prop.getProperty("Route")
    val tbl10 = ApplicationConfig.prop.getProperty("RelationShip")

    val masterAllergy = ReadTBL.getPostgresTable(sparkSess,tbl1)
   // broadcast(masterAllergy)

    val mappingPracticeProcedure = ReadTBL.getPostgresTable(sparkSess,tbl2)
      .select("PracticeUid","PracticeValue","PracticeDescription","Code","CodeDescription")
    broadcast(mappingPracticeProcedure)

    val mappingpracticecommondatamaster = ReadTBL.getPostgresTable(sparkSess,tbl3)
      .select("PracticeUid","PracticeValue","PracticeDescription","Code","CodeDescription")
    broadcast(mappingpracticecommondatamaster)

    val mappingpracticecommondatamasterethnicity = ReadTBL.getPostgresTable(sparkSess,tbl4)
      .select("PracticeUid","PracticeValue","PracticeDescription","Code","CodeDescription")
    broadcast(mappingpracticecommondatamasterethnicity)

    val mappingpracticecommondatamasterrace = ReadTBL.getPostgresTable(sparkSess,tbl5)
      .select("PracticeUid","PracticeValue","PracticeDescription","Code","CodeDescription")
    broadcast(mappingpracticecommondatamasterrace)

    val mappingpracticeinsurancedata = ReadTBL.getPostgresTable(sparkSess,tbl6)
    broadcast(mappingpracticeinsurancedata)

   val MappingPracticeProblem = ReadTBL.getPostgresTable(sparkSess,tbl7)
     .select("PracticeUid","PracticeValue","PracticeDescription","Code","CodeDescription")
    broadcast(MappingPracticeProblem)

    val MappingPracticeMedication = ReadTBL.getPostgresTable(sparkSess,tbl8)
      .select("PracticeUid","PracticeValue","PracticeDescription","Code","CodeDescription")
    broadcast(MappingPracticeMedication)

    val MappingPracticeCommonDataMasterMedicationRoute = ReadTBL.getPostgresTable(sparkSess,tbl9)
      .select("PracticeUid","PracticeValue","PracticeDescription","Code","CodeDescription")
    broadcast(MappingPracticeCommonDataMasterMedicationRoute)

    val mappingracticecommondatamasterrelationship = ReadTBL.getPostgresTable(sparkSess,tbl10)
    broadcast(mappingracticecommondatamasterrelationship)

   val DemoPath = ApplicationConfig.prop.getProperty("DemoPath")
    val DemographicsDF = new PatientDemographics(DemoPath).demoProcessing(sparkSess)
    val selectedIds = DemographicsDF.head.select($"PracticeUid",$"PatientId",$"PatientUid")


    val EthinicityPath = ApplicationConfig.prop.getProperty("EthinicityPath")
    val PatientEthnicityDF = new PatientEthnicity(EthinicityPath,selectedIds)
      .EthinicityProccessing(sparkSess,mappingpracticecommondatamasterethnicity)

    val RacePath = ApplicationConfig.prop.getProperty("RacePath")
    val PatientraceDF = new PatientRace(RacePath,selectedIds)
      .cacheRaceProcessing(sparkSess, mappingpracticecommondatamasterrace)

    val EncounterPath = ApplicationConfig.prop.getProperty("EncounterPath")
    val CacheEncounterDF = new PatientEncounter(EncounterPath,selectedIds)
      .cachePatientEncounterProcessing(sparkSess)

    val ProblemPath = ApplicationConfig.prop.getProperty("ProblemPath")
    val PatientProblemDF = new PatientProblem(ProblemPath,selectedIds)
      .cachePatientProblemProcessing(sparkSess, MappingPracticeProblem)

    val ProcedurePath = ApplicationConfig.prop.getProperty("ProcedurePath")
    val PatientProcedureDF = new PatientProcedure(ProcedurePath,selectedIds)
      .cachePatientProcedureProceesing(sparkSess, mappingPracticeProcedure, mappingpracticecommondatamaster)

    val AdvanceDirectivePath = ApplicationConfig.prop.getProperty("AdvanceDirectivePath")
    val PatientAdvanceDirectiveDF = new PatientAdvanceDirectiveObservation(AdvanceDirectivePath,selectedIds)
      .cacheAdvObsProcessing(sparkSess, mappingpracticecommondatamaster)


    val AllergiesPath = ApplicationConfig.prop.getProperty("AllergiesPath")
    val PatientAllergyDF = new PatientAllergy(AllergiesPath,selectedIds)
      .cacheAllergyProcessing(sparkSess, masterAllergy, mappingpracticecommondatamaster)

    val MedicationPath = ApplicationConfig.prop.getProperty("MedicationPath")
    val PatientMedicationDF = new PatientMedications(MedicationPath,selectedIds)
      .CacheMedicationsProcessing(sparkSess, mappingPracticeProcedure, MappingPracticeMedication, mappingpracticecommondatamaster)


    val PlanOfCarePath = ApplicationConfig.prop.getProperty("PlanOfCarePath")
    val PatientPlanOfCareDF = new PatientPlanOfCare(PlanOfCarePath,selectedIds)
      .PlanOfCareProcessing(sparkSess, mappingpracticecommondatamaster)


    val ResultObservationPath = ApplicationConfig.prop.getProperty("ResultObservationPath")
    val PatientresultObservationbDF = new PatientresultObservation(ResultObservationPath,selectedIds)
      .cacheresultObsProcessing(sparkSess, mappingpracticecommondatamaster, mappingPracticeProcedure)


    val SocialHistoryObsPath = ApplicationConfig.prop.getProperty("SocialHistoryObsPath")
    val PatientSocialHistoryObsDF = new PatientSocialHistoryObs(SocialHistoryObsPath,selectedIds)
      .cacheSocialHistoryObsProcessing(sparkSess, mappingpracticecommondatamaster)


    val VitalSignPath = ApplicationConfig.prop.getProperty("VitalSignPath")
    val PatientVitalSignDF = new PatientVitalSignObservation(VitalSignPath,selectedIds)
      .VitalSignObservationProcessing(sparkSess, mappingpracticecommondatamaster)


    val FamilyHistoryPath = ApplicationConfig.prop.getProperty("FamilyHistoryPath")
    val PatientFamilyHistoryDF = new PatientFamilyHistory(FamilyHistoryPath,selectedIds)
      .FamilyHistoryProcessing(sparkSess, mappingracticecommondatamasterrelationship, mappingpracticecommondatamaster
           , MappingPracticeProblem)

   val LanguagePath = ApplicationConfig.prop.getProperty("LanguagePath")
   val PatientLanguageDF = new PatientLanguage(LanguagePath,selectedIds)
     .cachepatientLangProcessing(sparkSess)


   /* val PatientNotesPath = ApplicationConfig.prop.getProperty("PatientNotesPath")
    val PatientNotesDF = new PatientNote(PatientNotesPath,selectedIds)
      .PatientNoteProcessing(sparkSess)*/
    println("end..........................................")



  }

}
