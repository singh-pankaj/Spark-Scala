package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}

class ProblemTransformFunctions(sparkSess : SparkSession, mappingpracticeproblem : DataFrame) {

  import sparkSess.implicits._

  def ProblemCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterProblemCode")
        ,$"df2.CodeDescription".as("MasterProblemText"))
  }

  def ProblemText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterProblemCode")
        ,$"df2.CodeDescription".as("MappedMasterProblemText"))
      .withColumn("MasterProblemCode",when($"MappedMasterProblemCode".isNull,$"MasterProblemCode")
        .otherwise($"MappedMasterProblemCode"))
      .withColumn("MasterProblemText",when($"MappedMasterProblemText".isNull,$"MasterProblemText")
        .otherwise($"MappedMasterProblemText"))
      .drop("MappedMasterProblemCode","MappedMasterProblemText")
  }

  def ProblemStatusCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemStatusCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterProblemStatusCode")
        ,$"df2.CodeDescription".as("MasterProblemStatusText"))
  }

  def ProblemStatusText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemStatusText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterProblemStatusCode")
        ,$"df2.CodeDescription".as("MappedMasterProblemStatusText"))
      .withColumn("MasterProblemStatusCode",when($"MappedMasterProblemStatusCode".isNull,$"MasterProblemStatusCode")
        .otherwise($"MappedMasterProblemStatusCode"))
      .withColumn("MasterProblemStatusText",when($"MappedMasterProblemStatusText".isNull,$"MasterProblemStatusText")
        .otherwise($"MappedMasterProblemStatusText"))
      .drop("MappedMasterProblemStatusCode","MappedMasterProblemStatusText")
  }

  def ProblemHealthStatusCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemHealthStatusCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterProblemHealthStatusCode")
        ,$"df2.CodeDescription".as("MasterProblemHealthStatusText"))
  }

  def ProblemHealthStatusText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemHealthStatusText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedProblemHealthStatusCode")
        ,$"df2.CodeDescription".as("MappedMasterProblemHealthStatusText"))
      .withColumn("MasterProblemHealthStatusCode",when($"MappedProblemHealthStatusCode".isNull,$"MasterProblemHealthStatusCode")
        .otherwise($"MappedProblemHealthStatusCode"))
      .withColumn("MasterProblemHealthStatusText",when($"MappedMasterProblemHealthStatusText".isNull,$"MasterProblemHealthStatusText")
        .otherwise($"MappedMasterProblemHealthStatusText"))
      .drop("MappedProblemHealthStatusCode","MappedMasterProblemHealthStatusText")
  }

  def TargetSiteCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterTargetSiteCode")
        ,$"df2.CodeDescription".as("MasterTargetSiteText"))
  }

  def TargetSiteText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterTargetSiteCode")
        ,$"df2.CodeDescription".as("MappedMasterTargetSiteText"))
      .withColumn("MasterTargetSiteCode",when($"MappedMasterTargetSiteCode".isNull,$"MasterTargetSiteCode")
        .otherwise($"MappedMasterTargetSiteCode"))
      .withColumn("MasterTargetSiteText",when($"MappedMasterTargetSiteText".isNull,$"MasterTargetSiteText")
        .otherwise($"MappedMasterTargetSiteText"))
      .drop("MappedMasterTargetSiteCode","MappedMasterTargetSiteText")
  }


}
