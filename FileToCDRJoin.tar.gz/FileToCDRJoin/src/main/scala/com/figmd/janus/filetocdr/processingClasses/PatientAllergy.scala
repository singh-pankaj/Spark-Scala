package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.AllergyTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions.{collect_list, struct, to_timestamp}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}

import scala.collection.Map
class PatientAllergy(AllergiesPath : String,selectedIds : DataFrame) extends  Serializable {



  def cacheAllergyProcessing(spark : SparkSession, masterAllergy : DataFrame,mappingpracticecommondatamaster : DataFrame
                            ) {

    try {
      import spark.implicits._

      val validations = new ValidationCriteria(spark)

      val mainTableName = ApplicationConfig.prop.getProperty("CDRAllergy")
      val stagetableName = ApplicationConfig.prop.getProperty("StageAllergy")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationAllergy")
      val file = CommonFunc.readFile(AllergiesPath,spark)
        .drop("dummy1","dummy2")
        .withColumn("EffectiveStartDate", to_timestamp($"EffectiveStartDate", "MM/dd/yyyy HH:mm:ss"))
        .withColumn("EffectiveEndDate", to_timestamp($"EffectiveEndDate", "MM/dd/yyyy HH:mm:ss"))

/*
      val lookup1 = Map("_c0" -> "PatientId", "_c1" -> "EffectiveStartDate", "_c2" -> "EffectiveEndDate"
        , "_c3" -> "AllergyTypeCode", "_c4" -> "AllergyEventType", "_c5" -> "AllergicToCode"
        , "_c6" -> "AllergicToDescription", "_c7" -> "AllergyStatusCode"
        , "_c8" -> "AllergyStatusText", "_c9" -> "AllergyReaction", "_c10" -> "AllergiesKey"
        ,"_c11" -> "PracticeUid","_c12" -> "BatchUid","_c13" -> "dummy1","_c14" -> "dummy2")

      val cacheAllergy = file.select(file.columns.map(c => col(c).as(lookup1.getOrElse(c, c))): _*)
          .drop("dummy1","dummy2")
        .withColumn("EffectiveStartDate", to_timestamp($"EffectiveStartDate", "MM/dd/yyyy HH:mm:ss"))
        .withColumn("EffectiveEndDate", to_timestamp($"EffectiveEndDate", "MM/dd/yyyy HH:mm:ss"))

*/

      val schema = file.schema.add(StructField("ErrorMessage",StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)

      val cachePatientAllergyValidations = file
        .transform(validations.removeDuplicateRecords("PatientId"))
        .transform(validations.removeDuplicateRecords("PatientId","EffectiveStartDate"))
        .transform(validations.removeDuplicateRecords(" PatientId","EffectiveEndDate"))
        .transform(validations.removeDuplicateRecords("PatientId","AllergicToDescription"))
        .transform(validations.removeDuplicateRecords("PatientId","AllergicToDescription","EffectiveStartDate"))
        .transform(validations.removeDuplicateRecords("PatientId","AllergicToDescription","EffectiveEndDate"))


      val CleanedRecords = cachePatientAllergyValidations.filter(row => validations.checkNull(row,broadcastRows,"PatientId","AllergyStatusCode","AllergyStatusText"))

      val addPatientUid =  CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*",$"df2.PatientUid")

      val tf = new AllergyTransformFunctions(spark, masterAllergy, mappingpracticecommondatamaster)

      val cacheAllergy3 = addPatientUid
        .transform(tf.AllergicToCode)
        .transform(tf.AllergicToDescription)
        .transform(tf.AllergyStatusCode)
        .transform(tf.AllergyStatusText)

      HiveUtility.dfwritetohive(cacheAllergy3,mainTableName,spark,stagetableName,s3Path)
      val errList = validations.errorList += spark.createDataFrame(rows,schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.csv("temp_test/patientAllergies_error")
      broadcastRows.destroy()

      /*val distinctPUid = cacheAllergy3.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val AllergyData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cacheAllergy3.select("PracticeUid","PatientId","PatientUid").distinct()
      //broadcast(FiletoJoin)

      val otherData = AllergyData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

      val newstructure = cacheAllergy3.select(otherData.columns.head,otherData.columns.tail:_*)
      val AllAllergy = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllAllergy,mainTableName,sparkSess,stagetableName,s3Path)*/

    }


    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }

}
