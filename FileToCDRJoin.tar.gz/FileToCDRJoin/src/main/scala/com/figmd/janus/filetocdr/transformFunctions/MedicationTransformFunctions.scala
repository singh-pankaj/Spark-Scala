package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}

class MedicationTransformFunctions(spark : SparkSession, MappingPracticeProcedure : DataFrame
                                   , MappingPracticeMedication : DataFrame
                                   , MappingPracticeCommonDataMaster : DataFrame) {


  import spark.implicits._
  def ProcedureText(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterProcedureCode")
        ,$"df2.CodeDescription".as("MasterProcedureText"))
  }

  def ProcedureCode(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterProcedureCode",when($"MappedValue1".isNull , $"MasterProcedureCode")
        .otherwise($"MappedValue1"))
      .withColumn("MasterProcedureText",when($"MappedValue2".isNull , $"MasterProcedureText")
        .otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationName(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeMedication.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationName" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationCode")
        ,$"df2.CodeDescription".as("MasterMedicationName"))
  }

  def MedicationCode(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeMedication.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationCode",when($"MappedValue1".isNull , $"MasterMedicationCode")
        .otherwise($"MappedValue1"))
      .withColumn("MasterMedicationName",when($"MappedValue2".isNull , $"MasterMedicationName")
        .otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationProductFormText(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationProductFormText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationProductFormCode")
        ,$"df2.CodeDescription".as("MasterMedicationProductFormText"))
  }

  def MedicationProductFormCode(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationProductFormCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationProductFormCode",when($"MappedValue1".isNull
        , $"MasterMedicationProductFormCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationProductFormText",when($"MappedValue2".isNull
        , $"MasterMedicationProductFormText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationIndicationProblemText(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationIndicationProblemCode")
        ,$"df2.CodeDescription".as("MasterMedicationIndicationProblemText"))
  }

  def MedicationIndicationProblemCode(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationIndicationProblemCode",when($"MappedValue1".isNull
        , $"MasterMedicationIndicationProblemCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationIndicationProblemText",when($"MappedValue2".isNull
        , $"MasterMedicationIndicationProblemText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationReactionProblemText(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationReactionProblemText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationReactionProblemCode")
        ,$"df2.CodeDescription".as("MasterMedicationReactionProblemText"))
  }

  def MedicationReactionProblemCode(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationReactionProblemCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationReactionProblemCode",when($"MappedValue1".isNull
        , $"MasterMedicationReactionProblemCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationReactionProblemText",when($"MappedValue2".isNull
        , $"MasterMedicationReactionProblemText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationReactionProblemSeverityText(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationReactionProblemSeverityCode")
        ,$"df2.CodeDescription".as("MasterMedicationReactionProblemSeverityText"))
  }

  def MedicationReactionProblemSeverityCode(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationReactionProblemSeverityCode",when($"MappedValue1".isNull
        , $"MasterMedicationReactionProblemSeverityCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationReactionProblemSeverityText",when($"MappedValue2".isNull
        , $"MasterMedicationReactionProblemSeverityText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationStatusText(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationStatusCode")
        ,$"df2.CodeDescription".as("MasterMedicationStatusText"))
  }

  def MedicationStatusCode(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationStatusCode",when($"MappedValue1".isNull
        , $"MasterMedicationStatusCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationStatusText",when($"MappedValue2".isNull
        , $"MasterMedicationStatusText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationRouteText(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationRouteText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationRouteCode")
        ,$"df2.CodeDescription".as("MasterMedicationRouteText"))
  }

  def MedicationRouteCode(df:DataFrame): DataFrame={
    df.as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationRouteCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationRouteCode",when($"MappedValue1".isNull
        , $"MasterMedicationRouteCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationRouteText",when($"MappedValue2".isNull
        , $"MasterMedicationRouteText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

}
