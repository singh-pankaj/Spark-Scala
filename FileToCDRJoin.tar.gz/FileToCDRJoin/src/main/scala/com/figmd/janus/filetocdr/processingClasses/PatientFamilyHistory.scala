package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.FamilyHistoryTransformFunc
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.Map

class PatientFamilyHistory(FamilyHistoryPath : String,selectedIds : DataFrame) extends  Serializable{


  def FamilyHistoryProcessing(spark : SparkSession, mappingpractivecommondatamasterrelationship : DataFrame
                              , mappingpracticecommondatamaster : DataFrame, mappingpracticeproblem : DataFrame){

    try {

      println("start familyhistory.............................")

      val mainTableName = ApplicationConfig.prop.getProperty("CDRFamilyHistory")
      val stagetableName = ApplicationConfig.prop.getProperty("StageFamilyHistory")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationFamilyHistory")
      val validations = new ValidationCriteria(spark)

      import spark.implicits._
      val file = CommonFunc.readFile(FamilyHistoryPath,spark)

      val lookup1 = Map("_c0" -> "PatientId", "_c1" -> "FamilyMemberLastName", "_c2" -> "FamilyMemberFirstName",
        "_c3" -> "RelationshipToPatientCode", "_c4" -> "RelationshipToPatientText", "_c5" -> "FamilyMemberGender",
        "_c6" -> "FamilyMemberDOB", "_c7" -> "EffectiveDate", "_c8" -> "ProblemCode", "_c9" -> "ProblemText",
        "_c10" -> "ProblemCategory", "_c11" -> "ProblemTypeCode", "_c12" -> "ProblemTypeText", "_c13" -> "FamilyMemberAge",
        "_c14" -> "IsFamilyMemberAlive", "_c15" -> "FamilyHistoryKey", "_c16" -> "PracticeUid", "_c17" -> "BatchUid"
        , "_c18" -> "dummy1", "_c19" -> "dummy2")

      val cachePatientFamilyHistory = file.select(file.columns.map(c => col(c).as(lookup1.getOrElse(c, c))): _*)
        .drop("dummy1","dummy2")

      val addPatientUid =  cachePatientFamilyHistory.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*",$"df2.PatientUid")

      val tf = new FamilyHistoryTransformFunc(spark,mappingpractivecommondatamasterrelationship
        , mappingpracticecommondatamaster, mappingpracticeproblem)

      println("start familyhistory goes to lookup.............................")
      val cacheFamilyHistory3 = addPatientUid
        .transform(tf.RelationshipToPatientCode)
        .transform(tf.RelationshipToPatientText)
        .transform(tf.ProblemTypeCode)
        .transform(tf.ProblemTypeText)
        .transform(tf.ProblemCode)
        .transform(tf.ProblemDescription)


      HiveUtility.dfwritetohive(cacheFamilyHistory3,mainTableName,spark,stagetableName,s3Path)
      /*println("start familyhistory goes to lookup  end. ............................")
      val distinctPUid = cacheFamilyHistory3.select("PracticeUid").distinct()

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val FamilyHistoryData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cacheFamilyHistory3.select("PracticeUid","PatientId","PatientUid").distinct()
      //broadcast(FiletoJoin)

      val otherData = FamilyHistoryData.as("df1").join(FiletoJoin.as("df2")
        ,Seq("PatientId","PracticeUid","PatientUid"),"left_anti")
        .select($"df1.*")

      val newstructure = cacheFamilyHistory3.select(otherData.columns.head,otherData.columns.tail:_*)
      val AllFamilyHistoryData = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllFamilyHistoryData,mainTableName,sparkSess,stagetableName,s3Path)
*/
    }

    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }


}
