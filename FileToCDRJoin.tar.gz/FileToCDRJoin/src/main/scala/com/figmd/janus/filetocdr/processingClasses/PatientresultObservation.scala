package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.ResultObsTransformFunction
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.Map

class PatientresultObservation(ResultObservationPath : String,selectedIds : DataFrame) extends  Serializable{

  def cacheresultObsProcessing(spark : SparkSession, mappingpracticecommondatamaster : DataFrame
                               ,mappingpracticeprocedure : DataFrame): Unit = {

    import spark.implicits._
    try {


      val mainTableName = ApplicationConfig.prop.getProperty("CDRResultObs")
      val stagetableName = ApplicationConfig.prop.getProperty("StageResultObs")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationResultObs")
      //Start CacheResultObservation
      val validations = new ValidationCriteria(spark)
      var CacheResultObservation = CommonFunc.readFile(ResultObservationPath,spark)

      val lookup10 = Map("_c0" -> "PatientId", "_c1" -> "ObservationCode", "_c2" -> "ObservationName"
        , "_c3" -> "ObservationCategory", "_c4" -> "ObservationDate", "_c5" -> "ObservationValue"
        , "_c6" -> "ObsInterpretationCode", "_c7" -> "ObsInterpretationText", "_c8" -> "TargetSiteCode"
        , "_c9" -> "TargetSiteText", "_c10" -> "ServiceProviderNPI", "_c11" -> "ServiceProviderLastName"
        , "_c12" -> "ServiceProviderFirstName", "_c13" -> "NegationInd", "_c14" -> "ReferenceLowerRange"
        , "_c15" -> "ReferenceUpperRange", "_c16" -> "MethodCode", "_c17" -> "MethodCodeText"
        , "_c18" -> "SpecimenId", "_c19" -> "ProcedureCode", "_c20" -> "ProcedureText"
        , "_c21" -> "ProcedureCategory", "_c22" -> "ResultObservationStatus", "_c23" -> "ResultOrderDescription"
        , "_c24" -> "ResultOrderDate", "_c25" -> "ResultOBSUnit", "_c26" -> "LaboratoryID"
        , "_c27" -> "LaboratoryName", "_c28" -> "ResultOrderCode", "_c29" -> "Obssubid"
        , "_c30" -> "ResultObservationKey", "_c31" -> "PracticeUid", "_c32" -> "BatchUid"
        , "_c33" -> "dummy1", "_c34" -> "dummy2")

      CacheResultObservation = CacheResultObservation.select(CacheResultObservation.columns.map(c => col(c).as(lookup10.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("ObservationDate", to_timestamp($"ObservationDate", "MM/dd/yyyy HH:mm:ss"))

      val addPatientUid =  CacheResultObservation.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*",$"df2.PatientUid")

      //Some column is remaining
      val resultObsObj = new ResultObsTransformFunction(spark, mappingpracticecommondatamaster, mappingpracticeprocedure)

      val CacheResultObservation2 = addPatientUid
        .transform(resultObsObj.PracticeCode)
        .transform(resultObsObj.PracticeDescription)
        .transform(resultObsObj.TargetSiteCode)
        .transform(resultObsObj.TargetSiteText)
        .transform(resultObsObj.ObsInterpretationCode)
        .transform(resultObsObj.ObsInterpretationText)
        .transform(resultObsObj.ProcedureCode)
        .transform(resultObsObj.ProcedureText)
        .transform(resultObsObj.MethodCode)
        .transform(resultObsObj.MethodCodeText)

      HiveUtility.dfwritetohive(CacheResultObservation2,mainTableName,spark,stagetableName,s3Path)

     /* val distinctPUid = CacheResultObservation2.select("PracticeUid").distinct()

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val ResultObsData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = CacheResultObservation2.select("PracticeUid","PatientId","PatientUid").distinct()
     // broadcast(FiletoJoin)

      val otherData = ResultObsData.as("df1").join(FiletoJoin.as("df2")
        ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid","left_anti")
        .select($"df1.*")

      val newstructure = CacheResultObservation2.select(otherData.columns.head,otherData.columns.tail:_*)
      val AllResultObsData = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllResultObsData,mainTableName,sparkSess,stagetableName,s3Path)*/


    }
    catch {
      case ex: FileNotFoundException => {
        println("File Not found"+ex)
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }
  }
}
