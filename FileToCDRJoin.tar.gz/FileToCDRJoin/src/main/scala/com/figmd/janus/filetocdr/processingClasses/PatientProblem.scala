package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.ProblemTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

import scala.collection.Map

class PatientProblem(ProblemPath : String,selectedIds : DataFrame) extends  Serializable{

  def cachePatientProblemProcessing(spark: SparkSession, mappingpracticeproblem: DataFrame) = {

    val mainTableName = ApplicationConfig.prop.getProperty("CDRProblem")
    val stagetableName = ApplicationConfig.prop.getProperty("StageProblem")
    val s3Path = ApplicationConfig.prop.getProperty("s3LocationProblem")
    val validations = new ValidationCriteria(spark)

    import spark.implicits._

    try {
      val file = CommonFunc.readFile(ProblemPath, spark).drop("dummy1", "dummy2")
        .withColumn("DocumentationDate", to_timestamp($"DocumentationDate", "MM/dd/yyyy HH:mm:ss"))

/*
      val lookup1 = Map("_c0" -> "PatientId", "_c1" -> "ProblemCode", "_c2" -> "ProblemText", "_c3" -> "ProblemCategory"
        , "_c4" -> "ProblemTypeCode", "_c5" -> "ProblemTypeText", "_c6" -> "DocumentationDate",
        "_c7" -> "ProblemResolutionDate", "_c8" -> "ProblemStatusCode", "_c9" -> "ProblemStatusText"
        , "_c10" -> "ProblemHealthStatusCode", "_c11" -> "ProblemHealthStatusText", "_c12" -> "NegationInd",
        "_c13" -> "ProblemComment", "_c14" -> "ProblemOnsetDate", "_c15" -> "TargetSiteCode", "_c16" -> "TargetSiteText"
        , "_c17" -> "ProblemKey", "_c18" -> "PracticeUid", "_c19" -> "BatchUid",
        "_c20" -> "dummy1", "_c21" -> "dummy2")

      val cachePatientProblem = file.select(file.columns.map(c => col(c).as(lookup1.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("DocumentationDate", to_timestamp($"DocumentationDate", "MM/dd/yyyy HH:mm:ss"))

*/

      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)
      val schema = file.schema.add(StructField("ErrorMessage",StringType))

      val cachePatientProblemValidations = file
        .transform(validations.removeDuplicateRecords("PatientUid","ProblemCode","DocumentationDate"))
        .transform(validations.removeDuplicateRecords("PatientUid","problemtext","DocumentationDate"))

      val CleanedRecords = cachePatientProblemValidations.filter(row => validations.checkNull(row,broadcastRows,"PatientId","DocumentationDate","ProblemCode","ProblemText"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*",$"df2.PatientUid")

      val problemObj = new ProblemTransformFunctions(spark, mappingpracticeproblem)

      val cachePatientProblem3 = addPatientUid
        .transform(problemObj.ProblemCode)
        .transform(problemObj.ProblemText)
        .transform(problemObj.ProblemStatusCode)
        .transform(problemObj.ProblemStatusText)
        .transform(problemObj.ProblemHealthStatusCode)
        .transform(problemObj.ProblemHealthStatusText)
        .transform(problemObj.TargetSiteCode)
        .transform(problemObj.TargetSiteText)

      HiveUtility.dfwritetohive(cachePatientProblem3,mainTableName,spark,stagetableName,s3Path)

      val errList = validations.errorList += spark.createDataFrame(rows,schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.csv("temp_test/patientProblem_error")
      broadcastRows.destroy()

      /*val distinctPUid = cachePatientProblem3.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val ProblemData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cachePatientProblem3.select("PracticeUid","PatientId","PatientUid").distinct()
     //broadcast(FiletoJoin)

      val otherData = ProblemData.as("df1").join(FiletoJoin.as("df2")
        ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
        $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

      val newstructure = cachePatientProblem3.select(otherData.columns.head,otherData.columns.tail:_*)

      val AllProblemData = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllProblemData,mainTableName,sparkSess,stagetableName,s3Path)*/
    }

    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
      }
    }
  }

}
