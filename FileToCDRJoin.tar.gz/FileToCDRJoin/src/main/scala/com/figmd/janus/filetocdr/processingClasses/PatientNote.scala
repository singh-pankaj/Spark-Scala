package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{broadcast, col, to_timestamp, year}

class PatientNote(PatientNotesPath : String,selectedIds : DataFrame) {


  def PatientNoteProcessing(spark : SparkSession) {


    try {

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientNotes")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientNotes")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientNotes")
      val validations = new ValidationCriteria(spark)

      import spark.implicits._
      val CachePatientNotesFile = CommonFunc.readFile(PatientNotesPath, spark)

      val CachePatientNoteslookup = Map("_c0" -> "PatientId", "_c1" -> "referencedDate", "_c2" -> "SectionName", "_c3" -> "Note",
        "_c4" -> "ServiceProviderNPI", "_c5" -> "ServiceProviderLastName", "_c6" -> "ServiceProviderFirstName",
        "_c7" -> "ServiceLocationId", "_c8" -> "ServiceLocationName", "_c9" -> "Group1", "_c10" -> "Group2", "_c11" -> "Group3",
        "_c12" -> "Group4", "_c13" -> "PracticePatientNoteKey", "_c14" -> "PracticeUid", "_c15" -> "BatchUid"
        , "_c16" -> "dummy1", "_c17" -> "dummy2")

      val CachePatientNotes = CachePatientNotesFile.select(CachePatientNotesFile.columns.map(c => col(c).as(CachePatientNoteslookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
       // .withColumn("referencedDate", to_timestamp($"referencedDate", "MM/dd/yyyy HH:mm:ss"))


      val addPatientUid = CachePatientNotes.as("df1").join(selectedIds.as("df2")
        ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")

      HiveUtility.dfwritetohive(addPatientUid,mainTableName,spark,stagetableName,s3Path)

      /*val distinctPUid = addPatientUid.select("PracticeUid").distinct()

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val NotesData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = addPatientUid.select("PracticeUid","PatientId","PatientUid")
     // broadcast(FiletoJoin)

      val otherData = NotesData.as("df1").join(FiletoJoin.as("df2")
        ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid","left_anti")
        .select($"df1.*")

      val newstructure = addPatientUid.select(otherData.columns.head,otherData.columns.tail:_*)
      val AllNotesData = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllNotesData,mainTableName,sparkSess,stagetableName,s3Path)*/

    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        unknown.printStackTrace()

      }
    }
  }
}
