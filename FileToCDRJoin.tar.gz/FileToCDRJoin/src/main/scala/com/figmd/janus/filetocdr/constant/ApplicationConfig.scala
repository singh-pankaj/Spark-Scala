package com.figmd.janus.filetocdr.constant

import java.util.{Properties}
import org.apache.log4j.{Level, Logger}

object ApplicationConfig {

  var prop = new Properties

  def setApplicationConfig(args: Array[String]): Unit =
  {

    prop.setProperty("awsAccessKeyId", "AKIALH6XLTJCI6I3N5RQ")
    prop.setProperty("awsSecretAccessKey", "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")
    prop.setProperty("postgresHostName", "10.20.201.36")
    prop.setProperty("warehouse", "/user/hive/warehouse")
    prop.setProperty("postgresHostPort", "5432")
    prop.setProperty("postgresManagementDatabaseName", "figmdhqimanagementaao")
    prop.setProperty("postgresHostUserName", "postgres")
    prop.setProperty("postgresUserPass", "Janus@123")
    prop.setProperty("num_executors", "10")
    prop.setProperty("executor_cores", "5")
    prop.setProperty("executor_memory", "7G")
    prop.setProperty("spark_master_url", "yarn")
    prop.setProperty("mode", "cluster")
    prop.setProperty("Allergy", "mappingpracticeallergy")
    prop.setProperty("Procedure", "mappingpracticeprocedure")
    prop.setProperty("PracticeCommonData", "mappingpracticecommondatamaster")
    prop.setProperty("Ethinicity", "mappingpracticecommondatamasterethnicity")
    prop.setProperty("Race", "mappingpracticecommondatamasterrace")
    prop.setProperty("Insurance", "mappingpracticeinsurancedata")
    prop.setProperty("Problem", "MappingPracticeProblem")
    prop.setProperty("Medication", "MappingPracticeMedication")
    prop.setProperty("Route", "MappingPracticeCommonDataMasterMedicationRoute")
    prop.setProperty("RelationShip", "MappingPracticeCommonDataMasterMedicationRoute")



    //prop.setProperty("RootPath", "s3://bd-dev/REGDATA_AAO")
   // prop.setProperty("RootPath", "s3://bd-dev/REGDATA_AAO_PAR_PART")
   prop.setProperty("RootPath", "temp_test/sample_data")

    val rootPath = prop.getProperty("RootPath")
    prop.setProperty("DemoPath", s"$rootPath/PatientDemographics/")
    //prop.setProperty("DemoPath", s"s3://bd-dev/REGDATA_AAO_PAR/PatientDemographics/")
   // prop.setProperty("DemoPath", s"hdfs://ip-10-20-201-191.us-gov-west-1.compute.internal:8020/user/dev/aaoData/DemoGraphics/")
    prop.setProperty("VitalSignPath", s"$rootPath/PatientVitalSigns/")
    prop.setProperty("SocialHistoryObsPath", s"$rootPath/PatientSocialHistoryObservation/")
    prop.setProperty("AdvanceDirectivePath", s"$rootPath/PatientAdvanceDirective/")
    prop.setProperty("AllergiesPath", s"$rootPath/PatientAllergies/")
    prop.setProperty("EncounterPath", s"$rootPath/PatientEncounter/")
    prop.setProperty("EncounterDiagnosisPath",s"$rootPath/PatientEncounterDiagnosis/")
    prop.setProperty("EthinicityPath", s"$rootPath/PatientEthnicity/")
    prop.setProperty("FamilyHistoryPath", s"$rootPath/PatientFamilyHistory/")
    prop.setProperty("LanguagePath",s"$rootPath/PatientLanguage/")
    prop.setProperty("MedicationPath", s"$rootPath/PatientMedications/")
    prop.setProperty("PatientNotesPath", s"$rootPath/PatientNotes/")
    prop.setProperty("InsurancePath", s"$rootPath/PatientInsurance/")
    prop.setProperty("PlanOfCarePath", s"$rootPath/PatientPlanOfCare/")
    prop.setProperty("ProblemPath", s"$rootPath/PatientProblem/")
    prop.setProperty("ProcedurePath", s"$rootPath/PatientProcedures/")
    prop.setProperty("RacePath", s"$rootPath/PatientRace/")
    //change path of ResultObservationPath
    prop.setProperty("ResultObservationPath",s"$rootPath/PatientNotesResultObservation//")

    prop.setProperty("dbName","test_figmdcdr")
    val dbName = prop.getProperty("dbName")
    prop.setProperty("CDRPatient",s"$dbName.patient")
    prop.setProperty("CDREthinicity",s"$dbName.patientethnicity")
    prop.setProperty("CDRRace",s"$dbName.patientrace")
    prop.setProperty("CDRVisit",s"$dbName.visit")
    prop.setProperty("CDRProblem",s"$dbName.patientproblem")
    prop.setProperty("CDRProcedure",s"$dbName.patientprocedure")
    prop.setProperty("CDRAdvanceDirectives",s"$dbName.patientadvancedirective")
    prop.setProperty("CDRAllergy",s"$dbName.patientallergy")
    prop.setProperty("CDRMedication",s"$dbName.patientmedication")
    prop.setProperty("CDRPlanOfCare",s"$dbName.patientplanofcare")
    prop.setProperty("CDRResultObs",s"$dbName.patientresultobservation")
    prop.setProperty("CDRSocialHisObs",s"$dbName.patientsocialhistory")
    prop.setProperty("CDRVitalSignObs",s"$dbName.patientvitalsigns")
    prop.setProperty("CDRFamilyHistory",s"$dbName.patientfamilyhistory")
    prop.setProperty("CDRPatientLang",s"$dbName.patientlanguage")
    prop.setProperty("CDRPatientNotes",s"$dbName.patientnote")


    prop.setProperty("table_path","temp_test/validated_tables")
    val table_path = prop.getProperty("table_path")
    prop.setProperty("stageDB","test_figmdcdr_temp")
    val stageDB = prop.getProperty("stageDB")

    prop.setProperty("StagePatient",s"$stageDB.patient_stage")
    prop.setProperty("s3LocationPatient",s"$table_path/patient_stage/")
//
    prop.setProperty("StagePatient_error",s"$stageDB.patient_stage")
//
    prop.setProperty("StageEthinicity",s"$stageDB.Ethinicity_stage")
    prop.setProperty("s3LocationEthinicity",s"$table_path/Ethinicity_stage/")

    prop.setProperty("StageRace",s"$stageDB.Race_stage")
    prop.setProperty("s3LocationRace",s"$table_path/Race_stage/")

    prop.setProperty("StageVisit",s"$stageDB.Visit_stage")
    prop.setProperty("s3LocationVisit",s"$table_path/Visit_stage/")

    prop.setProperty("StageProblem",s"$stageDB.Problem_stage")
    prop.setProperty("s3LocationProblem",s"$table_path/Problem_stage/")

    prop.setProperty("StageProcedure",s"$stageDB.Procedure_stage")
    prop.setProperty("s3LocationProcedure",s"$table_path/Procedure_stage/")

    prop.setProperty("StageAdvanceDirectives",s"$stageDB.AdvanceDirectives_stage")
    prop.setProperty("s3LocationAdvanceDirectives",s"$table_path/AdvanceDirectives_stage/")

    prop.setProperty("StageAllergy",s"$stageDB.Allergy_stage")
    prop.setProperty("s3LocationAllergy",s"$table_path/Allergy_stage/")

    prop.setProperty("StageMedication",s"$stageDB.Medication_stage123")
    prop.setProperty("s3LocationMedication",s"$table_path/Medication_stage/")

    prop.setProperty("StagePlanOfCare",s"$stageDB.PlanOfCare_stage")
    prop.setProperty("s3LocationPlanOfCare",s"$table_path/PlanOfCare_stage/")

    prop.setProperty("StageResultObs",s"$stageDB.ResultObs_stage")
    prop.setProperty("s3LocationResultObs",s"$table_path/ResultObs_stage/")

    prop.setProperty("StageSocialHisObs",s"$stageDB.SocialHisObs_stage")
    prop.setProperty("s3LocationSocialHisObs",s"$table_path/SocialHisObs_stage/")

    prop.setProperty("StageVitalSignObs",s"$stageDB.VitalSignObs_stage")
    prop.setProperty("s3LocationVitalSignObs",s"$table_path/VitalSignObs_stage/")

    prop.setProperty("StageFamilyHistory",s"$stageDB.FamilyHistory_stage")
    prop.setProperty("s3LocationFamilyHistory",s"$table_path/FamilyHistory_stage/")

    prop.setProperty("StagePatientLang",s"$dbName.PatientLang_stage")
    prop.setProperty("s3LocationPatientLang",s"$table_path/PatientLang_stage/")

    prop.setProperty("StagePatientNotes",s"$stageDB.PatientNotes_stage")
    prop.setProperty("s3LocationPatientNotes",s"$table_path/PatientNotes_stage/")

    //prop.setProperty("s3LocationPatient","hdfs://ip-10-20-201-191.us-gov-west-1.compute.internal:8020/user/dev/aaoData/patient_stage12/")
    //prop.setProperty("s3LocationPatient","hdfs://ip-10-20-201-191.us-gov-west-1.compute.internal:8020/user/dev/aaoData/patient_stage12345/")



    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)
    Logger.getLogger("myLogger").setLevel(Level.OFF)


  }
}
