package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.SocialHistoryObsTransformFunc
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.Map

class PatientSocialHistoryObs(SocialHistoryObsPath : String,selectedIds : DataFrame) extends  Serializable{

  def cacheSocialHistoryObsProcessing(spark : SparkSession, mappingpracticecommondatamaster : DataFrame) {

    import spark.implicits._


    try {
      val mainTableName = ApplicationConfig.prop.getProperty("CDRSocialHisObs")
      val stagetableName = ApplicationConfig.prop.getProperty("StageSocialHisObs")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationSocialHisObs")
      val validations = new ValidationCriteria(spark)

      val file = CommonFunc.readFile(SocialHistoryObsPath,spark)

      val lookup1 = Map("_c0" -> "PatientId", "_c1" -> "SocialHistoryTypeCode", "_c2" -> "SocialHistoryTypeText", "_c3" -> "SocialHistoryObservedValue",
        "_c4" -> "DocumentationDate", "_c5" -> "EffectiveStopDate", "_c6" -> "SocialHistoryStatusCode",
        "_c7" -> "SocialHistoryStatusText", "_c8" -> "YearsSmoked", "_c9" -> "QuitYear", "_c10" -> "SocialHxGroup",
        "_c11" -> "EffectiveStartDate", "_c12" -> "SocialHistoryObservationKey", "_c13" -> "PracticeUid", "_c14" -> "BatchUid", "_c15" -> "dummy1", "_c16" -> "dummy2")

      val cachePatientSocialHistoryObs = file.select(file.columns.map(c => col(c).as(lookup1.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")

      val addPatientUid =  cachePatientSocialHistoryObs.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*",$"df2.PatientUid")

      val tf = new SocialHistoryObsTransformFunc(spark, mappingpracticecommondatamaster)

      val cacheSocialHistoryObs3 = addPatientUid
        .transform(tf.SocialHistoryTypeCode)
        .transform(tf.SocialHistoryTypeText)
        .transform(tf.SocialHistoryStatusCode)
        .transform(tf.SocialHistoryStatusText)

      HiveUtility.dfwritetohive(cacheSocialHistoryObs3,mainTableName,spark,stagetableName,s3Path)
      /*val distinctPUid = cacheSocialHistoryObs3.select("PracticeUid").distinct()

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val SocialHisObsData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cacheSocialHistoryObs3.select("PracticeUid","PatientId","PatientUid").distinct()
    //  broadcast(FiletoJoin)

      val otherData = SocialHisObsData.as("df1").join(FiletoJoin.as("df2")
        ,Seq("PatientId","PracticeUid","PatientUid"),"left_anti")
        .select($"df1.*")

      val newstructure = cacheSocialHistoryObs3.select(otherData.columns.head,otherData.columns.tail:_*)
      val AllSocialHistoryData = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllSocialHistoryData,mainTableName,sparkSess,stagetableName,s3Path)*/



    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }
}
