package com.figmd.janus.measureComputation.ecqm.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Ecqm68v7 extends MeasureUtilityUpdate with MeasureUpdate   {

  val MEASURE_NAME = "Ecqm68v7"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd)
    ippRDD.cache()

    val metRDD = getMet(ippRDD)
    metRDD.cache()

    // Filter Exceptions
    val intermediate = getinterRDD(ippRDD, metRDD)
    intermediate.cache()

    val exceptionRDD = getExceptionRDD(intermediate)
    exceptionRDD.cache()

    // Filter not Mate
    val notMetRDD = getinterRDD(intermediate, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, sparkSession.sparkContext.emptyRDD, sparkSession.sparkContext.emptyRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }

  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {
   val m = MeasureProperty(MEASURE_NAME, IPP)
    rdd.filter(visit => isPatientAdult(visit, m) && isEncounterPerformedOnEncounter(visit, m, ElementMaster.Medications_Encounter_Code_Set)
   )

  }


  def getMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,MET)
    ippRDD.filter(visit => isProcedurePerformedDuringEncounter(visit, m, ElementMaster.Current_Medications_Documented_Snmd)
    )
  }

  def getExceptionRDD(intermediateRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,EXCEPTION)
    intermediateRDD.filter(visit => isActionNotPerformedWithReasonDuringEncounter(visit, m, ElementMaster.Medical_Or_Other_Reason_Not_Done)
    )
  }


}

