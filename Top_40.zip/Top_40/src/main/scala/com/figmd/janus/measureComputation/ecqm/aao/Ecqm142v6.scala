package com.figmd.janus.measureComputation.ecqm.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Ecqm142v6 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm142v6"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {
    val patient_history_list = getPatientHistory(sparkSession, rdd,"dire").collect().toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(rdd,patientHistoryList)
    ippRDD.cache()
    // Eligible IPP
    val eligibleRdd = getEligibleIpp(ippRDD)
    // Filter Exclusions
    val notEligibleRDD =ippRDD.subtract(eligibleRdd)
    eligibleRdd.cache()

    // Filter Exclusions
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    /*// Filter Intermediate
    val intermediateA = getSubtractRDD(eligibleRdd, exclusionRDD)
    intermediateA.cache()*/

    // Filter Met
    val metRDD = getMet(eligibleRdd)
    metRDD.cache()

    // Filter Exceptions
    val intermediate =  getinterRDD(eligibleRdd,metRDD)
    intermediate.cache()

    val exceptionRDD =getexceptionRDD(intermediate)
    exceptionRDD.cache()

    // Filter not meate
    val notMetRDD =  getinterRDD(intermediate,exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }



  // Filter IPP
  def getIpp(rdd:RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP)

    rdd.filter(visit => isPatientAdult(visit, m)
      &&(isDiagnosedWithBeforeOrEqual(visit, m, ElementMaster.Diabetic_Retinopathy, ElementMaster.Encounter_Date, patientHistoryList)
      && isDiagnosedConcurrentwith (visit, m, ElementMaster.Diabetic_Retinopathy__Eye,ElementMaster.Diabetic_Retinopathy))

    )

  }


  def getEligibleIpp(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,ELIGIBLE)
    ippRDD.filter(visit =>  isDiagnosticStudyOnEncounter (visit,m,ElementMaster.Macular_Exam_result)
      &&isDiagnosticStudyConcurrentwith(visit,m,ElementMaster.Macular_Exam_Eye,ElementMaster.Macular_Exam)
    )
  }

  def getMet(eligibleRdd:RDD[CassandraRow]): RDD[CassandraRow] = {

    var m = MeasureProperty(MEASURE_NAME,MET)
    eligibleRdd.filter(visit =>
      (
      (
        isCommunicationFromProvidertoProviderOnEncounter(visit,m,ElementMaster.Proliferative_Diabetic_Retinopathy)
          ||isCommunicationFromProvidertoProviderOnEncounter(visit,m,ElementMaster.Severe_Non_Proliferative_Diabetic_Retinopathy)
          ||isCommunicationFromProvidertoProviderOnEncounter(visit,m,ElementMaster.Moderate_Diabetic_Retinopathy)
          ||isCommunicationFromProvidertoProviderOnEncounter(visit,m,ElementMaster.Mild_Non_Proliferative_Diabetic_Retinopathy)
          ||isCommunicationFromProvidertoProviderOnEncounter(visit,m,ElementMaster.Very_Severe_Non_Proliferative_Diabetic_Retinopathy)
        )
        &&
        (
          isCommunicationFromProvidertoProviderConcurrent(visit,m,ElementMaster.Level_Of_Severity_Of_Retinopathy_Findings_Eye,ElementMaster.Proliferative_Diabetic_Retinopathy)
            ||isCommunicationFromProvidertoProviderConcurrent(visit,m,ElementMaster.Level_Of_Severity_Of_Retinopathy_Findings_Eye,ElementMaster.Severe_Non_Proliferative_Diabetic_Retinopathy)
            ||isCommunicationFromProvidertoProviderConcurrent(visit,m,ElementMaster.Level_Of_Severity_Of_Retinopathy_Findings_Eye,ElementMaster.Moderate_Diabetic_Retinopathy)
            ||isCommunicationFromProvidertoProviderConcurrent(visit,m,ElementMaster.Level_Of_Severity_Of_Retinopathy_Findings_Eye,ElementMaster.Mild_Non_Proliferative_Diabetic_Retinopathy)
            ||isCommunicationFromProvidertoProviderConcurrent(visit,m,ElementMaster.Level_Of_Severity_Of_Retinopathy_Findings_Eye,ElementMaster.Very_Severe_Non_Proliferative_Diabetic_Retinopathy)

          )
      )
    &&
    (
      (
        isCommunicationFromProvidertoProviderOnEncounter(visit,m,ElementMaster.Macular_Edema_Findings_Present)
          ||isCommunicationFromProvidertoProviderOnEncounter(visit,m,ElementMaster.Macular_Edema_Findings_Absent)
        )
        &&
        (
          isCommunicationFromProvidertoProviderConcurrent(visit,m,ElementMaster.Macular_Edema_Findings__Eye,ElementMaster.Macular_Edema_Findings_Present)
            ||isCommunicationFromProvidertoProviderConcurrent(visit,m,ElementMaster.Macular_Edema_Findings__Eye,ElementMaster.Macular_Edema_Findings_Absent)
          )
      )
    )
  }

  def getexceptionRDD(intermediate: RDD[CassandraRow]): RDD[CassandraRow] = {

    var m = MeasureProperty(MEASURE_NAME,EXCEPTION)
    intermediate.filter(visit =>
    isActionNotPerformedWithReasonDuringEncounter(visit, m,ElementMaster.Medical_Reason)
    ||isActionNotPerformedWithReasonDuringEncounter(visit, m,ElementMaster.Patient_Reason)

    )
  }



}