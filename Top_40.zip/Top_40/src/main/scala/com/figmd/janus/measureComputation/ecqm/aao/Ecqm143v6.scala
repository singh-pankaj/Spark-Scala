package com.figmd.janus.measureComputation.ecqm.aao
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.measureComputation.qpp.aao.Qpp91.{getIpp, isVisitTypeIn}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


object Ecqm143v6 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm143v6"

  def refresh(sparkSession: SparkSession, rdd:RDD[CassandraRow]): Unit = {

    // Filter IPP

    var getPatientHistoryList = getPatientHistory(sparkSession,rdd,"propgl","propgl_date","opse","opse_date","caseinlorefa","caseinlorefa_date","nufavi","nufavi_date","ofvi_1","ofvi_1_date","ouco_1","ouco_1_date","fain","fain_date","poageye","poageye_date","cutodira","cutodira_date","cpdsert_eye","cpdsert_eye_date","opdiexfostab","opdiexfostab_date","odscexstrabn_eye","odscexstrabn_eye_date","mere_1","mere_1_date");

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList.collect().toList);

    val ippRDD = getIpp(rdd,patientHistoryList)
    ippRDD.cache()


    val notEligible= sparkSession.sparkContext.emptyRDD[CassandraRow]
    val exclusionRdd =sparkSession.sparkContext.emptyRDD[CassandraRow]
    val metRDD = getMet(ippRDD,patientHistoryList)
    metRDD.cache()

    // Filter Met

    val intermediateA = getSubtractRDD(ippRDD,metRDD)
    intermediateA.cache()

    val exceptionRDD = getExceptionRDD(intermediateA)
    exceptionRDD.cache()

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
    notMetRDD.cache()


    saveToWebDM(rdd, ippRDD, notEligible, exclusionRdd, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }


  def getIpp(rdd: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    var m = MeasureProperty(MEASURE_NAME,IPP)

    rdd.filter(visit =>
      isAgeAbove(visit,m,true,18)
        && (isDiagnosedWithOnEncounter(visit,m,ElementMaster.Primary_Open_Angle_Glaucoma)
        && isDiagnosedWithOnEncounter(visit,m,ElementMaster.Primary_Open_Angle_Glaucoma_Eye)
        )

    )
  }


  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    var m = MeasureProperty(MEASURE_NAME,MET)
    intermediateA.filter(visit =>
      (
        isDiagnosedWithOnEncounter(visit,m,ElementMaster.Cup_to_Disc_Ratio)
          && checkEyeElementsInRange(visit,ElementMaster.Cup_to_Disc_Ratio_Eye,ElementMaster.Primary_Open_Angle_Glaucoma)
          &&
          isDiagnosedWithOnEncounter(visit,m,ElementMaster.Optic_Disc_Exam_for_Structural_Abnormalities))
        && checkEyeElementsInRange(visit,ElementMaster.Optic_Disc_Exam_for_Structural_Abnormalities_Eye,ElementMaster.Primary_Open_Angle_Glaucoma)
    )
  }

  def getExceptionRDD(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    var m = MeasureProperty(MEASURE_NAME, EXCEPTION)

    intermediateA.filter(visit => (
      isDiagnosticPerformedNotDoneOnEncounter(visit, m,ElementMaster.Medical_Reason_CMS143v6)
        && isDiagnosticPerformedNotDoneOnEncounter(visit, m, ElementMaster.Medical_Reason_CMS143v6))
    )
  }
}
