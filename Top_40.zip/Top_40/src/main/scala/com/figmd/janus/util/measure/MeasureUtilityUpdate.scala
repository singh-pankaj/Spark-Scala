package com.figmd.janus.util.measure

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.WebDataMartCreator.global_measure_name

import com.figmd.janus.measureComputation.master.{ MeasureProperty}
import org.apache.spark.broadcast.Broadcast



class MeasureUtilityUpdate extends HistoryLookUpUtility {


  /**
    *
    * @param r get visit onEncounter for analysis assessmentPerformed
    * @param measureProperty m
    * @param elementArray get element list as input
    * @return true or false based on assessmentPerformed
    */

  def assessmentPerformed(r: CassandraRow, measureProperty: MeasureProperty, elementArray: Array[String]): Boolean = {
    procedurePerformed(r, measureProperty, elementArray: Array[String])
  }

  /**
    *
    * @param r get visit onEncounter for analysis getCHA2DS2_VASc
    * @param m m
    * @param hefa get element 1
    * @param hyper get element 2
    * @param dibtmelts get element 3
    * @param prirstrk get element 4
    * @param vsclr_disease get element 5
    * @param sex get element 6
    * @return true or false based on assessmentPerformed
    */

  def  getCHA2DS2_VASc(r: CassandraRow, m:MeasureProperty, hefa: String, hyper: String,dibtmelts: String,prirstrk: String,vsclr_disease: String,sex: String): Int= {
    var chadscore=0
    try {

      val dob = r.getDate("dob")
      val enounterdate = r.getString("encounterdate")

      if(isAgeAbove(r,m,true,75)){chadscore=chadscore+2}
      else if(!r.isNullAt(hefa) && r.getString(hefa).equals("1")){chadscore=chadscore+1}
      else if(isAgeAbove(r,m,true,64) && isAgeBelow(r,m,false,75)){chadscore=chadscore+1}
      else if(!r.isNullAt(hyper) && r.getString(hyper).equals("1")){chadscore=chadscore+1}
      else if(!r.isNullAt(dibtmelts) && r.getString(dibtmelts).equals("1")){chadscore=chadscore+1}
      else if(!r.isNullAt(prirstrk) && r.getString(prirstrk).equals("1")){chadscore=chadscore+2}
      else if(!r.isNullAt(vsclr_disease) && r.getString(vsclr_disease).equals("1")){chadscore=chadscore+1}
      else if(!r.isNullAt(sex) && r.getString(sex).equals("2")){chadscore=chadscore+1}

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:getCHA2DS2_VASc:" + e.printStackTrace(), "FAIL")

      }
    }
    chadscore
  }

  /**
    *
    * @param r get visit onEncounter for analysis isAssessmentLessThan
    * @param measureProperty m
    * @param checkValue get element value from cassendra
    * @param Value get input value
    * @return true or false based on isAssessmentLessThan
    */

  def isAssessmentLessThan(r: CassandraRow, measureProperty: MeasureProperty,checkValue:String, Value: Int): Boolean = {
    val isExist = !r.isNullAt(checkValue) && r.getInt(checkValue)<Value
    //val argsArray:Array[String]=Array(checkValue,Value.toString)
    //measureLogger(r, measureName, conditionType, "chkValueRangeLess", checkValue, isExist,argsArray)

    return isExist;
  }

  def encounterPerformed(r: CassandraRow, measureProperty: MeasureProperty, elementArray: Array[String]): Boolean = {
    procedurePerformed(r: CassandraRow, measureProperty, elementArray: Array[String])
  }

  def encounterPerformed(r:CassandraRow,measureProperty: MeasureProperty,element:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    isDiagnosedWithInHistory(r,measureProperty,element,patientHistoryList)
  }

  def procedurePerformed(r: CassandraRow, measureProperty: MeasureProperty, elementArray: Seq[String]): Boolean = {
    elementArray.exists(element=>checkElementPresent(r, measureProperty, element))
  }

  /*def unionOf(func: Array[Boolean]): Boolean = {
    func.forall(x => x == true)
  }*/

  /*

    def AND(functionArray: Array[Boolean]): Boolean = {
      var flag = true
      for (element <- functionArray) {
        if (!element) {
          false
        }
      }
      flag
    }


    def OR(functionArray: Array[Boolean]): Boolean = {
      var flag = true
      for (element <- functionArray) {
        if (element) {
          true
        }
      }
      flag
    }
  */




  def age_At_Encounter_GreaterThan_Or_EqualTo_2(r: CassandraRow, measureProperty: MeasureProperty): Boolean = {

    var isAgeGreterThan18 = false

    try {

      isAgeGreterThan18 = !r.isNullAt("dob") && !r.isNullAt("encounterdate") && dateUtility.getAge(r.getString("dob"), r.getString("encounterdate")) >= 2
      //  val argsArray: Array[String] = Array(sDate, eDate, compareYears.toString)
      //  measureLogger1(r, measureProperty, "ageGreaterThanOrEquals18", startDateDOB, isExist, argsArray)
      isAgeGreterThan18

    }
    catch {
      case ex: Throwable => println("*** Exception In ***" + ex.getMessage)
    }

    isAgeGreterThan18

  }

  def age_At_Encounter_GreaterThan_Or_EqualTo_65(r: CassandraRow, measureProperty: MeasureProperty): Boolean = {

    var isAgeGreterThan65 = false

    try {
      isAgeGreterThan65 = !r.isNullAt("dob") && !r.isNullAt("encounterdate") && dateUtility.getAge(r.getString("dob"), r.getString("encounterdate")) >= 65
      //  val argsArray: Array[String] = Array(sDate, eDate, compareYears.toString)
      //  measureLogger1(r, measureProperty, "ageGreaterThanOrEquals18", startDateDOB, isExist, argsArray)
    }
    catch {
      case ex: Throwable => println("*** Exception In ***" + ex.getMessage)
    }

    isAgeGreterThan65

  }

  def interventionNotPerformedDuringEncounter (r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }

  def assesment_Performed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }

  def intervention_Performed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    procedure_Performed(r: CassandraRow, measureProperty, element)
  }

  def procedure_Performed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }

  def intervention_Performed_Overlaps_Encounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    procedure_Performed(r: CassandraRow, measureProperty, element)
  }

  def diagnosis(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def medication_Active_On_Encounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def medication_Administered(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def medication_Order_Starts_After_Start_Of_Diagnosis(r: CassandraRow, measureProperty: MeasureProperty, medicationElement: String, dignosisElememnt: String, noOfDays: Int): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, medicationElement)
  }

  def medication_Active_Overlaps_MeasurementPeriod(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def laboratoryTest_Performed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def laboratoryTest_Not_Performed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def ageLessThan_76_OnEncounter(r: CassandraRow, measureProperty: MeasureProperty): Boolean = {

    var isAgeGreterThan18 = false

    try {

      isAgeGreterThan18 = !r.isNullAt("dob") && !r.isNullAt("encounterdate") && dateUtility.getAge(r.getString("dob"), r.getString("encounterdate")) < 76
      //  val argsArray: Array[String] = Array(sDate, eDate, compareYears.toString)
      //  measureLogger1(r, measureProperty, "ageGreaterThanOrEquals18", startDateDOB, isExist, argsArray)
      isAgeGreterThan18

    }
    catch {
      case ex: Throwable => println("*** Exception In ***" + ex.getMessage)
    }

    isAgeGreterThan18

  }

  def diagnosticStudy_Performed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)

  }


  def diagnosis_On_Encounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)

  }

  def diagnosis_Overlaps_Encounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)

  }

  def diagnosis_Overlaps_MeasurementPeriod(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)

  }

  def physical_Exam_Performed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)

  }


  def communication_From_Provider_To_Provider(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)

  }

  def communication_From_Provider_To_Provider_Not_Done(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    !dataType_On_Encounter(r: CassandraRow, measureProperty, element)

  }

  def telehealth(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    !dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def teleHealthModifier(visit: CassandraRow, m: MeasureProperty): Boolean = {
    (
      encounter_Performed(visit, m, "Home Healthcare Services_Telehealth Modifier")
        || encounter_Performed(visit, m, "Nursing Facility Visit_Telehealth Modifier")
        || encounter_Performed(visit, m, "Office Visit_Telehealth Modifier")
        || encounter_Performed(visit, m, "Emergency Department Visit_Telehealth Modifier")
        || encounter_Performed(visit, m, "Domiciliary or rest home visit_Telehealth Modifierr")

      )

  }

  def isVisitTypeIn(visit: CassandraRow, m: MeasureProperty, elementLists: String*): Boolean = {

    elementLists.exists(x=>encounter_Performed(visit, m, x))

  }

  def encounter_Performed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def intervention_Order(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }


  def medication_Order_During_Encounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def medication_Administered_During_Encounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def medication_Not_Administered_During_Encounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    !dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def dataType_On_Encounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {

    if (checkElementPresent(r, measureProperty, element) && isDateEqual(r, measureProperty, element + "_date", "encounterdate"))
      true
    else
      false
  }

  /*
  * Function returns whether Patient's Age is 18 year & older i.e. Adult
  * */
  def isPatientAdult(visit: CassandraRow, m: MeasureProperty): Boolean = {
    var flag=false
    try {
      flag =isAgeAbove(visit, m, true)
     }catch {
      case e: Exception => println(">>>>>>>"+e.getMessage)
    }
    flag
  }

  /*Function returns whether
 *Patient's Age is 65 year & older i.e. Elderly
 */
  def isPatientElderly(visit: CassandraRow, m: MeasureProperty): Boolean = {
    isAgeAbove(visit,m,true,65)
  }

  /**
    *
    * @param r cassendra row
    * @param measureProperty measure property
    * @param element element name to be checked
    * @return true or false based on isPOSEncounterNotPerformed
    */

  def isPOSEncounterNotPerformed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {

    if (!checkElementPresent(r, measureProperty, element))
      true
    else
      false

  }

  /**
    *
    * @param r cassendra row
    * @param measureProperty measure property
    * @param elementSequence element name to be checked
    * @return returns boolean
    */
  def isTelehealthEncounterNotPerformed(r: CassandraRow, measureProperty: MeasureProperty, elementSequence: String*): Boolean = {
    elementSequence.exists(x => checkElementPresent(r, measureProperty, x))

  }

  def isInterventionPerformedBefore(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList: Broadcast[ List[CassandraRow] ]): Boolean = {

    isAssessmentPerformedBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate, histroyElement: String, patientHistoryList )
  }

  /**
    *
    * @param visit cassendra row
    * @param m measure property
    * @param elementName get history element
    * @param patientHistoryList get history List
    * @return returns boolean
    */
  def isProcedurePerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)
  }

  /*
* --Function Name: isPneumococcalVaccineAdministered
* The function would check if a Pneumococcal Vaccine is administered and if it overlaps the measurement period
*/
  def isPneumococcalVaccineAdministered(visit: CassandraRow, measureProperty: MeasureProperty, Pneumococcal_Vaccine: String,  patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    checkElementPresent(visit, measureProperty, Pneumococcal_Vaccine) &&
      procedurePerformedStartsBeforeEndOfMeasurementPeriod(visit, measureProperty, Pneumococcal_Vaccine, patientHistoryList)
  }

  /*
* Function would check if intervention is ordered or performed and overlaps the measurement period
* */
  def wasInterventionPerformedOrOrderedInHistory(r: CassandraRow, measureProperty: MeasureProperty, elementName: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = checkElementPresent(r, measureProperty, elementName) && checkElementInHistory(r, measureProperty,elementName,patientHistoryList)
    isExist
  }

  def isInterventionOrdered(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)
  }

  def isElementPresentDuringMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[ List[CassandraRow]]): Boolean = {
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)
  }

  def isDiagnosticStudyPerformed(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList : Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentDuringMeasurementPeriod(visit, m,elementName, patientHistoryList)
  }

  def wasProcedurePerformedBefore(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    isAssessmentPerformedBeforeOrEqual(visit, m,elementDate,histroyElement, patientHistoryList)
  }
  def isLaboratoryTestPerformedBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeEncounterDate(visit,m,elementName,patientHistoryList)
  }

  def diagnosticStudy_Performed(r: CassandraRow, measureProperty: MeasureProperty, elements: String*): Boolean = {
    elements.exists(element=> dataType_On_Encounter(r: CassandraRow, measureProperty, element))
  }
 // need to be removed and new function name  isDiagnosedDuringEncounter
  def isDiagnosedWithOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, elements: String*): Boolean = {
    elements.exists(element=>dataType_On_Encounter(r, measureProperty, element))
  }

  def diagnostic_Study_Not_Done(r: CassandraRow, measureProperty: MeasureProperty, elements: String*): Boolean = {
    elements.exists(element=> dataType_On_Encounter(r: CassandraRow, measureProperty, element))
  }

  def isDiagnosedWithBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r, MeasureProperty, elementDate, histroyElement, patientHistoryList)
  }

  def isDiagnosedConcurrentwith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }

  def isDiagnosticStudyOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }
  def isDiagnosticStudyConcurrentwith(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }


  def isCommunicationFromProvidertoProviderOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }

  def isDiagnosisBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r, MeasureProperty, elementDate, histroyElement, patientHistoryList)
  }

  def  isProcedurePerformedAfterOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r, MeasureProperty, elementDate, histroyElement, patientHistoryList)
  }


 /* def isProcedurePerformed(visit: CassandraRow, m:MeasureProperty,  histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    isDiagnosedWithInHistory(visit, m,  histroyElement, patientHistoryList)
  }
*/



  def isActionNotPerformedWithReasonDuringEncounter(visit: CassandraRow, m:MeasureProperty, element:String ): Boolean ={
    dataType_On_Encounter(visit: CassandraRow, m, element)
  }

  def isProcedurePerformedDuringEncounter(visit: CassandraRow, m:MeasureProperty, element:String ): Boolean ={
    dataType_On_Encounter(visit: CassandraRow, m, element)
  }


  def isAssesmentPerformedDuringEncounter(visit: CassandraRow, m:MeasureProperty, element:String ): Boolean ={
    dataType_On_Encounter(visit: CassandraRow, m, element)
  }

  def isEncounterPerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)
  }

  def isImmunizationAdministered(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isEncounterPerformedInHistory(visit, m,elementName, patientHistoryList)
  }

  def isInterventionPerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)
  }

  def isInterventionBeforeEnd(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }


  def isMedicationPerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)

  }

  def wasMedicationPerformedInHistory(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementInHistory(visit, m,elementName, patientHistoryList)
  }

  def isInterventionBefore(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }

  def isLaboratoryTestPerformed(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)

  }

  def isPhysicalExamPerformed(r: CassandraRow, MeasureProperty:MeasureProperty, Value:Int, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentBeforeValue(r, MeasureProperty, Value, histroyElement, patientHistoryList)
  }

  def isPhysicalExamPerformed(r:CassandraRow,measureProperty:MeasureProperty,element:String,patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    isDiagnosedWithInHistory(r,measureProperty,element,patientHistoryList)
  }

  def isMedicationPerformedConcurrentwith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }
  def isMedicationActivePerformedConcurrentwith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }
  def isMedicationAdminisetredPerformedConcurrentwith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }
  def isDiagnosticStudy(r: CassandraRow, measureProperty: MeasureProperty,checkValue:String, Value: Int): Boolean = {
    isAssessmentLessThan(r, measureProperty,checkValue, Value)

  }
  def isEncounterPerformedConcurrentwith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }

  def isMedicationOrdernotdonePerformedConcurrentwith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }
  def isMedicationAdministeredNotDonePerformedConcurrentwith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }

  def isDiagnosticStudyLessThanValue(r: CassandraRow, measureProperty: MeasureProperty,checkValue:String, Value: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isAssessmentBeforeValue(r, measureProperty,Value,checkValue, patientHistoryList)

  }
  def isMedicationAdministeredPerformedInHistory(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)

  }


  def isInterventionOrderBeforeOrEqual(visit: CassandraRow, m: MeasureProperty, elementDate: String,histroyElement: String,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {

    isElementPresentBeforeOrEqual(visit, m, elementDate: String, histroyElement: String, patientHistoryList)

  }

  def PhysicalExamPerformedBeforeOrEqualInMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String,histroyElement: String,month: Int,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {

    isElementBeforeOrEqualInMonths(visit, m, elementDate, histroyElement, month,patientHistoryList)
  }

  def isInterventionOrderNotDoneBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    isElementBeforeOrEqualInMonths(visit, m, elementDate, histroyElement, month, patientHistoryList)

  }

  def isDiagnosedBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    isElementBeforeOrEqualInMonths(visit, m, elementDate, histroyElement, month, patientHistoryList)

  }

  def PhysicalExamPerformedMostRecentResultInBetweenBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, ValueStartRange: Double, ValueEndRange: Int, MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {

    ElementMostRecentResultInBetweenBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, month, ValueStartRange, ValueEndRange, MostRecentList)

  }

  def physicalExamPerformedMostRecentResultInBetweenBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {

    isElementBeforeOrEqualInMonths(visit, m, elementDate, mostRecentElement, month, MostRecentList)
  }

  def physicalExamPerformedMostRecentResultGreaterorEqualValueAndBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, ValueGreaterOrEqual: Double, MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {

    ElementMostRecentResultInBetweenBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, ValueGreaterOrEqual , month, MostRecentList)
  }

  def isPhysicalExamPerformedNotDone(visit: CassandraRow, m: MeasureProperty, element: String* ): Boolean = {
    !procedurePerformed(visit: CassandraRow, m: MeasureProperty, element)

  }

  def isDiagnosedBeforeOrEqual(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    isElementPresentBeforeOrEqual(visit, m, elementDate, histroyElement,  patientHistoryList)

  }


  def wasDiagnosticStudyPerformedPerformedBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeEncounterDate(visit, m, elementName, patientHistoryList)
  }

  def wasDiagnosticStudyPerformedInHistory(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    isDiagnosedWithInHistory(visit,m,elementName,patientHistoryList)
  }

  def interventionOrderWithinOneDayofEnc(r:CassandraRow,measureProperty:MeasureProperty,element1:String,element2:String,element3:String,days:Int): Boolean ={
    (!r.isNullAt(element1) && !r.isNullAt(element2) && !r.isNullAt(element3)) && checkElementPresent(r,measureProperty,element1) && checkElementPresent(r,measureProperty,element2) && isElementDateStartAfterStartOfWithInDays(r,measureProperty,element1,element3,days)
  }

  def isInterventionPerformedBeforeEnd(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }
  def isInterventionPerformedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }

  def isAssessmentValueBeforeOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, checkValue:String, Value: Int): Boolean = {
    val isExist = !r.isNullAt(checkValue) && r.getInt(checkValue)<Value
    //val argsArray:Array[String]=Array(checkValue,Value.toString)
    //measureLogger(r, measureName, conditionType, "chkValueRangeLess", checkValue, isExist,argsArray)
    return isExist;
  }

  def isMedicationPerformedBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r, MeasureProperty,elementDate,histroyElement, patientHistoryList)
  }

  def isInterventionPerformedBeforeOrEqualInMonthInHistory(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    wasElementAfterOrEqualEndDateInMonths(visit, m,  histroyElement, month, patientHistoryList)
  }

  def isAssesmentPerformedBeforeOrEqualInMonthInHistory(visit: CassandraRow, m: MeasureProperty,  histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    wasElementAfterOrEqualEndDateInMonths(visit, m,  histroyElement, month, patientHistoryList)
  }

  def isPatientTobaccoUser(visit: CassandraRow, m: MeasureProperty, elementName:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasDiagnosedWith(visit, m, elementName, patientHistoryList)

  }


  def isPhysicalExamPerformedBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r, MeasureProperty, elementDate, histroyElement, patientHistoryList)
  }

  def isPhysicalExamPerformedConcurrentWith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }
  def isMedicationWithBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r, MeasureProperty, elementDate, histroyElement, patientHistoryList)
  }

  def PhysicalExamPerformedMostRecentResulLessValueAndBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, ValueLess: Double, MostRecentList:List[CassandraRow]): Boolean = {

    ElementMostRecentResultLessBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, ValueLess , month, MostRecentList)

  }

  def isEncounterPerformedMeasurementPeriod(r: CassandraRow, m: MeasureProperty, element: String, elementdate: String): Boolean ={
    checkElementPresent(r, m,element)    &&    isDuringMeasurementPeriod(r, m, elementdate)
  }

  def isEncounterPerformedOnEncounter(r: CassandraRow, m: MeasureProperty, element: String): Boolean ={
    checkElementPresent(r, m,element)
  }


  def isProcedureNotPerformedWithReasonDuringEncounter(r: CassandraRow, m: MeasureProperty, element: String, elementDate: String, elementDate2: String): Boolean ={
    checkElementPresent(r, m, element) &&
      isDateEqual(r, m, elementDate,elementDate2)
  }

  def isDiagnosticStudyConcurrentwith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }

   def isCommunicationFromProvidertoProviderConcurrent (r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }

  def isAssessmentValueLessOrEqualDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, checkValue:String, Value: Int): Boolean = {
    val isExist = !r.isNullAt(checkValue) && r.getInt(checkValue)<=Value
    //val argsArray:Array[String]=Array(checkValue,Value.toString)
    //measureLogger(r, measureName, conditionType, "chkValueRangeLess", checkValue, isExist,argsArray)
    return isExist;
  }

  def isAssessmentPerformedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }

  def InterventionPerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosedWithInHistory(visit, m, elementName, patientHistoryList)

  }
  def isMedicationTherapyInDays(visit: CassandraRow, m: MeasureProperty,CurrentRowElement:String, element2:String, days:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    startAfterStartOfWithinDaysLessorEqual(visit, m: MeasureProperty,CurrentRowElement, element2,days,patientHistoryList)

  }

  def isDiagnosedWithStartAfterStart(visit: CassandraRow, m: MeasureProperty,CurrentRowElement:String, element2:String, days:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    startAfterStartOfEncounter(visit,m,CurrentRowElement,element2,patientHistoryList)
  }

  def isDiagnosedWithinDays(visit: CassandraRow, m: MeasureProperty,CurrentRowElement:String, element2:String, days:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    startAfterStartOfWithinDaysLessorEqual(visit, m: MeasureProperty,CurrentRowElement, element2,days,patientHistoryList)

  }
  def isMedicationAdministeredNotDoneOnEncounter(r: CassandraRow, m: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, m, element)
  }



  def isInterventionPerformedEqualBeforeEnd(r: CassandraRow, MeasureProperty: MeasureProperty, histroyElement: String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementInHistory(r, MeasureProperty, histroyElement,patientHistoryList)
  }

  def isLaboratoryTestPerformedDuringEncounter (r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }
  def isRecentLaboratoryTestResultInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosedWithInHistory(visit, m, elementName, patientHistoryList)

  }
  def isRecentLaboratoryTestResultMissingInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosedWithInHistory(visit, m, elementName, patientHistoryList)

  }

/*
  def wasAssessmentNotPerformedInHistory(r: CassandraRow, MeasureProperty: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    isDiagnosedWithEqualInMonths(r, MeasureProperty, histroyElement, month, patientHistoryList)
  }*/

  def isRecentLaboratoryTestResultMissing(r: CassandraRow, MeasureProperty:MeasureProperty, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    patientHistoryList.value.exists(x => !x.isNullAt("element_date") &&
      x.getString("patientuid").equalsIgnoreCase(r.getString("patientuid")) &&
      histroyElement.equalsIgnoreCase( x.getString("element")) &&
      (x.isNullAt("elementvalue") )
    )

  }

  def isDiagnosticPerformedNotDoneOnEncounter(visit:CassandraRow,measureProperty:MeasureProperty,diagnosisElement:String): Boolean ={
    !dataType_On_Encounter(visit: CassandraRow, measureProperty, diagnosisElement)
  }

   def IsPhysicalExamPerformedDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }
  def isMedicationOrderStartAfterStartOfLessOrEqualInDays(visit: CassandraRow,m: MeasureProperty, currentRowelement: String, element2: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    startAfterStartOfWithinDaysLessorEqual(visit,m, currentRowelement, element2, days, patientHistoryList)
  }



  def isDiagnosisOverlapsEncounter(visit:CassandraRow, m:MeasureProperty,elementDate:String, histroyElement: String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isElementPresentBeforeOrEqual(visit: CassandraRow, m, elementDate, histroyElement, patientHistoryList)
  }

  def isMedicationActiveOnEncounter(visit:CassandraRow, m:MeasureProperty,element:String):Boolean= {
    dataType_On_Encounter(visit: CassandraRow, m, element)
  }

  def isMedicationAdministeredOnEncounter(visit:CassandraRow, m:MeasureProperty,element:String):Boolean= {
    dataType_On_Encounter(visit: CassandraRow, m, element)
  }

  def wasMedicationActiveBeforeEnd(visit:CassandraRow, m:MeasureProperty,elementName:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosisWithBeforeEnd(visit, m, elementName, patientHistoryList)
  }



  def isProcedurePerformedDuringEmergencyVisit(visit:CassandraRow, m:MeasureProperty,procedureElement:String, emergency_Visit_Arrival_Date:String,emergency_Visit_Departure_Date:String):Boolean= {

    isElementPresentBetweenTwoDate(visit, m,procedureElement, emergency_Visit_Arrival_Date,emergency_Visit_Departure_Date)

  }

  def isDiagnosticStudyOrderedDuringEmergencyVisit(visit:CassandraRow, m:MeasureProperty,procedureElement:String, emergency_Visit_Arrival_Date:String,emergency_Visit_Departure_Date:String):Boolean= {

    isElementPresentBetweenTwoDate(visit, m,procedureElement, emergency_Visit_Arrival_Date,emergency_Visit_Departure_Date)

  }

  def isGlasgowComaScaleResultEqualDuringEmergencyVisit(visit:CassandraRow, m:MeasureProperty,procedureElement:String, emergency_Visit_Arrival_Date:String,emergency_Visit_Departure_Date:String,resultValue:Double):Boolean= {

    isElementPresentBetweenTwoDatesAndResultValueEqual(visit:CassandraRow, m:MeasureProperty,procedureElement, emergency_Visit_Arrival_Date,emergency_Visit_Departure_Date,resultValue)

  }
  def isDiagnosedDuringEmergencyVisit(visit:CassandraRow, m:MeasureProperty,procedureElement:String, emergency_Visit_Arrival_Date:String,emergency_Visit_Departure_Date:String,resultValue:Double):Boolean= {

    isElementPresentBetweenTwoDate(visit:CassandraRow, m:MeasureProperty,procedureElement:String, emergency_Visit_Arrival_Date:String,emergency_Visit_Departure_Date:String)

  }


  def wasMedicationActiveInHistory(visit:CassandraRow, m:MeasureProperty, diagnosisElement:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementInHistory(visit, m, diagnosisElement, patientHistoryList)
  }

  def isAssessmentPerformedDuringEmergencyVisit(visit:CassandraRow, m:MeasureProperty,procedureElement:String, emergency_Visit_Arrival_Date:String,emergency_Visit_Departure_Date:String):Boolean= {

    isElementPresentBetweenTwoDate(visit, m,procedureElement, emergency_Visit_Arrival_Date,emergency_Visit_Departure_Date)

  }

  def wasAssessmentPerformedInHistory(visit:CassandraRow, m:MeasureProperty, diagnosisElement:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isElementPresentBeforeEncounterDate(visit: CassandraRow, m: MeasureProperty, diagnosisElement: String, patientHistoryList)

  }

  def wasDiagnosedBeforeorEqualEncounter(visit:CassandraRow, m:MeasureProperty, diagnosisElement:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isElementPresentBeforeorEqualEncounterDate(visit: CassandraRow, m: MeasureProperty, diagnosisElement: String, patientHistoryList)

  }


  /**
    * this function will check whether Symptom Started During Arrival and Departure of Emergency Department
    * @param visit current visit
    * @param m measure property
    * @param procedureElement procedure element
    * @param emergency_Visit_Arrival_Date emergency visit arrival date
    * @param emergency_Visit_Departure_Date emergency visit departure date
    * @return true if Symptom Started During Arrival and Departure of Emergency Department
    */
  def isSymptomStartedDuringEmergencyVisit(visit:CassandraRow, m:MeasureProperty,procedureElement:String, emergency_Visit_Arrival_Date:String,emergency_Visit_Departure_Date:String):Boolean= {

    isElementPresentBetweenTwoDate(visit, m,procedureElement, emergency_Visit_Arrival_Date,emergency_Visit_Departure_Date)

  }
  /**
    *
    * @param visit current visit
    * @param m measure property
    * @param elementDate counseling element
    * @param histroyElement1 most recent screening element
    * @param histroyElement2 tobacco user
    * @param month month in integer
    * @param patientHistoryMostRecentList patientHistoryMostRecentList
    * @param patientHistoryList patientHistoryList
    * @return
    */
  def wasMedicationNotOrderedAfterTobaccoScreeningUser(visit: CassandraRow, m: MeasureProperty, elementDate: String ,histroyElement1: String ,histroyElement2: String, month: Int, patientHistoryMostRecentList: List[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasCounselingNotPerformedAfterTobaccoScreeningUser(visit, m, elementDate ,histroyElement1 ,histroyElement2, month, patientHistoryMostRecentList,patientHistoryList)
  }

  /**
    *  this function will check whether Medication Intoleranced Or Allergied is Before Or EqualEncounter
    * @param visit current current
    * @param m measure property
    * @param Element element name
    * @param patientHistoryList patient history list
    * @return true if Medication Intoleranced Or Allergied is Before Or EqualEncounter
    */
  def wasMedicationAllergyInHistory(visit: CassandraRow, m:MeasureProperty, Element: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeorEqualEncounterDate(visit, m, Element, patientHistoryList)
  }

  def wasMedicationIntoleraneInHistory(visit: CassandraRow, m:MeasureProperty, Element: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeorEqualEncounterDate(visit, m, Element, patientHistoryList)
  }



  /**
    * this function will check whether Medication Ordered NotDone Before Or EqualEncounter
    * @param visit current current
    * @param m measure property
    * @param Element element name
    * @param patientHistoryList  patient history list
    * @return true if Medication Ordered NotDone Before Or EqualEncounter
    */
  def wasMedicationOrderedNotDoneBeforeOrEqualEncounter(visit: CassandraRow, m:MeasureProperty,Element: String,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeorEqualEncounterDate(visit, m, Element, patientHistoryList)
  }



  /** this function will check whether Medication Ordered NotDone during measurement period
    * @param visit current current
    * @param m measure property
    * @param elementName element name
    * @param patientHistoryList patient history list
    * @return true if Medication Ordered NotDone during measurement period
    */
  def isMedicationOrdered(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }

  /**
    *
    * @param visit                 current current
    * @param MeasureProperty       measure property
    * @param tobaccoUserElement    tobaccoUserElement
    * @param tobaccoNonUserElement  tobaccoNonUserElement
    * @param medicalReasonElement medicalReasonElement
    * @param patientMostRecentHistoryList patientMostRecentHistoryList
    */
  def isMedicationNotOrderedAfterTobaccoScreeningUser(visit: CassandraRow, MeasureProperty: MeasureProperty, tobaccoUserElement: String, tobaccoNonUserElement: String, medicalReasonElement: String, patientMostRecentHistoryList: Broadcast[List[CassandraRow]]): Unit ={
    isCounselingNotPerformedAfterTobaccoScreeningUser(visit, MeasureProperty, tobaccoUserElement, tobaccoNonUserElement, medicalReasonElement, patientMostRecentHistoryList)
  }

  /**
  This function checks element present and checks element Date is before end date and EyeElement Date is equal to element Date.
    * @param currentVisit       currentvisit  from Cassandra tblencounter
    * @param m                  measure property
    * @param element            Element from tblencounter
    * @param elementDate       ElementDate from tblencounter
    * @param EyeElement        EyeElement that has to be checked
    * @param EyeElementDate    EyeElementDate that has to be checked
    * @return
    */
  def DiagnosisStudyConcurrentwith(currentVisit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, EyeElement: String, EyeElementDate: String): Boolean = {
    var endDate: Date = globalEndDate
    (
      (checkElementPresent(currentVisit, m, element) && isDateOverlapsMeasurementPeriod(currentVisit, m, elementDate))
        &&
        (checkElementPresent(currentVisit, m, EyeElement) && isDateEqual(currentVisit, m, EyeElementDate, elementDate))
      )

  }

  //  this function checks DiagnosticElementDate DiagnosisElementDate equal.
  def isDignosticDateconcurrentwithDignoasisDate(currentVisit: CassandraRow, m: MeasureProperty, DiagnosticElementDate: String, DiagnosisElementDate: String): Boolean = {
    isDateEqual(currentVisit, m, DiagnosticElementDate, DiagnosisElementDate)
  }

  //  this function checks DiagnosticElement and DiagnosisElement present DiagnosticElementDate DiagnosisElementDate equal.
  def isDiagnosticStudyConcurrentwith(currentVisit: CassandraRow, m: MeasureProperty, DiagnosticElement: String, DiagnosticElementDate: String, DiagnosisElement: String, DiagnosisElementDate: String): Boolean = {
    checkElementPresent(currentVisit, m, DiagnosticElement) &&
      checkElementPresent(currentVisit, m, DiagnosisElement) &&
      isDignosticDateconcurrentwithDignoasisDate(currentVisit, m, DiagnosticElementDate, DiagnosisElementDate)
  }
  // to check Patient Characteristic in history whether patient was alive or not
  def wasPateintalive(currentVisit: CassandraRow, measureProperty: MeasureProperty, Element: String, historyList: Broadcast[List[CassandraRow]]): Boolean = {
    wasDiagnosedWith(currentVisit, measureProperty, Element, historyList)
  }
  // this function checks the latest assessment performed in history.
  def wasLatestAssessmentPerformed(currentVisit: CassandraRow, measureProperty: MeasureProperty, Element: String, mostRecentAssessmentPerformed: Broadcast[List[CassandraRow]]): Boolean = {
    wasDiagnosedWith(currentVisit, measureProperty, Element, mostRecentAssessmentPerformed)
  }



  def medication_Allergy_On_Encounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def communication_From_Patient_To_Provider_On_Encounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def isInfluenzaImmunizationAdministered(visit:CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit, measureProperty, element)
  }

  def isInfluenzaVaccineAdministered(visit: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit:CassandraRow, measureProperty, element)
  }

  def isInfluenzaVaccinationProcedure(visit:CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit:CassandraRow, measureProperty, element)
  }

  def isCommunicationFromPatientToProviderPreviousReceiptOfInfluenzaVaccine(visit: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit:CassandraRow, measureProperty, element)
  }

  def isCommunicationFromPatientToProviderPreviousReceiptOfInfluenzaVaccination(visit: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit:CassandraRow, measureProperty, element)
  }

  // Influenza Exception Function's

  def isCommunicationFromPatientToProviderInfluenzaVaccinationDeclined(visit:CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit, measureProperty, element)
  }

  def isActionNotPerformedWithReasonForInfluenza(visit:CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit, measureProperty, element)
  }

  def isAllergyToInfluenza(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }

  def isIntoleranceToInfluenza(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }

  def isLaboratoryTestOrder(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }

  /**
    *
    * @param r  cassandra row
    * @param m  measureProperty case class object contains conditionType as method type and measureName as measure name
    * @param ElementNameToCheckInHistory element name to check in current row
    * @param elementhistoryResult element name to check in history
    * @param NoOfMonths minus number of month from start date
    * @param HistoryList element history data
    * @return boolean value
    */

  def wasPhysicalExamPerformedDuringLastYear(r: CassandraRow, m:MeasureProperty, ElementNameToCheckInHistory: String, elementhistoryResult:String, NoOfMonths: Int, HistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    if (HistoryList.value.length > 0) {
      isExist =wasPhysicalExamPerformedForRetinalDilatedExam(r,m,ElementNameToCheckInHistory,elementhistoryResult,12,HistoryList)
      isExist
    }else isExist
  }

  /**
    *  Checking Assesment element in the measurement period
    * @param visit  cassandra row
    * @param m  measureProperty case class object contains conditionType as method type and measureName as measure name
    * @param elementName
    * @param patientHistoryList
    * @return
    */
  def isAssesmentPerformed(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)

  }

  /**
    * checking Medication element active before the end of the measurement period.
    * @param visit cassandra row
    * @param m  measureProperty case class object contains conditionType as method type and measureName as measure name
    * @param histroyElement
    * @param patientHistoryList
    * @return
    */
  def wasMedicationOrderInHistory(visit: CassandraRow, m:MeasureProperty,  histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementInHistory(visit, m,  histroyElement, patientHistoryList)
  }

  def isLaboratoryTestPerformedAfter(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosedWithInHistory(visit, m, elementName, patientHistoryList)
  }

  //isRecentLaboratoryTestResultGreaterThanValue
  def isRecentLaboratoryTestResultGreaterThanValue(visit:CassandraRow, m:MeasureProperty, elementName:String, result:Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    isAssessmentAfterValue(visit, m, elementName, result, patientHistoryList)
  }

  /**
    * this function check whether Laboratory Test Values is within range in patient history for within no. years from enddate
    * @param visit current visit
    * @param m measure property
    * @param element element name which need to be checked in patient history
    * @param year no. of year back from enddate
    * @param LesserValue is the user given value from which elementvalue must be greater and equal
    * @param greaterValue is the user given value from which elementvalue must be lesser
    * @param patientHistory list of patient history
    * @return true if given Laboratory Test Values is within range for element date within years from enddate
    */
  def wasLaboratoryTestValuesInRangeInHistory(visit: CassandraRow, m: MeasureProperty, element: String, year: Int, LesserValue:Double, greaterValue:Double, patientHistory: Broadcast[List[CassandraRow]]): Boolean = {

    checkElementValuesInRangeInHistory(visit, m, element, year, LesserValue, greaterValue , patientHistory)

  }

  /**
    * this function check whether Laboratory Test Values Greater Or Equal  to given value in patient history before enddate
    * @param visit current visit
    * @param m measure property
    * @param element element name which need to be checked in patient history
    * @param value is the user given value from which elementvalue must be greater and equal
    * @param patientHistory list of patient history
    * @return true if Laboratory Test Values Greater Or Equal to given value for element date before enddate from patient history
    */
  def wasLaboratoryTestValuesGreaterOrEqualInHistory(visit: CassandraRow, m: MeasureProperty, element: String, value:Double, patientHistory: Broadcast[List[CassandraRow]]): Boolean = {

    checkElementGreaterOrEqualInHistory(visit, m, element, value, patientHistory: Broadcast[List[CassandraRow]])

  }
  /**
    * This Function verifies encounter performed in history before end of measurement.
    * @param visit Current visit
    * @param m  Measure Property of that measure
    * @param elementName Element Name to look in patient History.
    * @param patientHistoryList PatientHistory List
    * @return
    */
  def  EncounterPerformedBeforeEnd(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosisWithBeforeEnd(visit,m,elementName,patientHistoryList)
  }


  /**
    * This Function verifies encounter performed in history before end of measurement.
    * @param visit Current visit.
    * @param m  Measure Property of the measure.
    * @param historyElement Element Name to look in patient History.
    * @param patientHistoryList PatientHistory List
    * @return
    */
  def isLaboratoryTestPerformedXYearsBeforeEnd(visit: CassandraRow, m: MeasureProperty, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    isProcedurePerformedXYearsInHistory(visit,m,historyElement,noOfYears,patientHistoryList)
  }

  /**
    * This function verifies procedure is performed before end Date.
    * @param visit current visit of the patient.
    * @param m      Measure Property of the measure.
    * @param historyElement  History Element to look in patient History.
    * @param patientHistoryList Patient History List.
    * @return   Returns those patient whose procedure is performed before endOfMeasurement period.
    */
  def isProcedurePerformedBeforeEnd(visit:CassandraRow, m:MeasureProperty,historyElement:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosisWithBeforeEnd(visit, m,historyElement, patientHistoryList)
  }


  def isMedicationActivePerformedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }

  /**
    * This function verifies the physical Exam performed in range between start of measurment period and end of measurement period
    * or physical exam result in range between start of measurement period and X months before start of measurement period.
    * @param visit Current visit of the patient.
    * @param m     Measure property of the Measure.
    * @param NoOfMonth No. of Month to go back from start of measurement period.
    * @param elementInHistory element that has to be look in History.
    * @param resultElementinhistory Element whose result has to be verified in the range between start of the measurement period and X months before start of the measurement period.
    * @param HistoryList   Patient history List.
    * @return  return those patient whether their physical exam performed in history or their result in the range between start of the measurement period and X months before start of the measurement period.
    */
  def wasPhysicalExamPerformed(visit: CassandraRow, m: MeasureProperty,NoOfMonth: Int,elementInHistory: String,resultElementinhistory: String,HistoryList: Broadcast[List[CassandraRow]]):Boolean={
    physicalExamPerfomedInHistory(visit, m, elementInHistory, HistoryList) ||
      physicalExamResultInxMonthsHistory(visit, m, resultElementinhistory, NoOfMonth, HistoryList)

  }
  def PhysicalExamPerformedMostRecentResultLessorEqualValueAndBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, ValueGreaterOrEqual: Double, MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    mostRecentElementResultGreatAndBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, ValueGreaterOrEqual , month, MostRecentList)

  }

  def PhysicalExamPerformedMostRecentResultGreaterorEqualValueAndBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, ValueGreaterOrEqual: Double,MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {

    mostRecentElementResultGreatAndBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, ValueGreaterOrEqual , month, MostRecentList)

  }
  def physicalExamPerformedMostRecentBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    mostRecentElementBeforeOrEqualInMonth(visit,m,elementDate, mostRecentElement, month,MostRecentList)
  }


  def isInterventionOrderDoneBeforeOrEqualInMonth(r: CassandraRow, MeasureProperty:MeasureProperty,firstDate: String, compareDate: String, Months:Int, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isDateEqual(r: CassandraRow, MeasureProperty, firstDate: String, compareDate: String)
  }

 //All the below 5 function has there _ name and duplicate of these function has too be removed
  def isDiagnosedDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, elements: String*): Boolean = {
    elements.exists(element=>dataType_On_Encounter(r, measureProperty, element))
  }





  /**
    * This function verifies the diagnosisDuringEdorEncounter
    * @param visit Current Visit of the patient.
    * @param m     Measure Property of the Measure.
    * @param element    Element whose Diagnosis is to be checked.
    * @param elementDate       Element Date that has to be checked whether it is equal to other date or it is in between two dates.
    * @param edvisitArrivalDate  edVisitarrivalDate of the patient.
    * @param edvisitDepartureDate edvisitDepartureDate of the patient.
    * @param crtclDate            crtclDate of the patient.
    * @return
    */
  def isDiagnosisDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    checkElementPresent(visit, m, element) &&
      (
        isDateInBeween(visit, m, elementDate, edvisitArrivalDate, edvisitDepartureDate)
          ||
          isDateTimeEqual(visit, m, elementDate, crtclDate)
        )
  }


  /**
    * This function verifies the isLaboratoryTestOrderDuringEDOrCCEncounter
    * @param visit            Current Visit of the patient.
    * @param m                Measure Property of the Measure.
    * @param element          Element whose LaboratoryTestOrder is to be checked.
    * @param elementDate      Element Date that has to be checked whether it is equal to other date or it is in between two dates.
    * @param edvisitArrivalDate  edVisitarrivalDate of the patient.
    * @param edvisitDepartureDate edvisitDepartureDate of the patient.
    * @param crtclDate            crtclDate of the patient.
    * @return
    */
  def isLaboratoryTestOrderDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
   checkElementPresent(visit, m, element) &&
      (
        isDateInBeween(visit, m, elementDate, edvisitArrivalDate, edvisitDepartureDate)
          ||
          isDateTimeEqual(visit, m, elementDate, crtclDate)
        )
  }
  def isDiagnosisWithBefore(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
     isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }

  def  wasEncounterPerformedInHistory(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit,m,elementName,patientHistoryList)
  }

  def wasLaboratoryTestPerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)

  }
  /**
    * This Function verifies encounter performed in history before end of measurement.
    * @param visit Current visit.
    * @param m  Measure Property of the measure.
    * @param historyElement Element Name to look in patient History.
    * @param patientHistoryList PatientHistory List
    * @return
    */
  def wasLaboratoryTestPerformedXYearsBeforeEnd(visit: CassandraRow, m: MeasureProperty, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    isProcedurePerformedXYearsInHistory(visit,m,historyElement,noOfYears,patientHistoryList)
  }


//**************************************************************************************************************************************************

  def isDiagnosedWithBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    isElementBeforeOrEqualInMonths(visit, m, elementDate, histroyElement, month, patientHistoryList)
  }
   //236,72
  def wasProcedurePerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    checkElementInHistory(visit,m,elementName,patientHistoryList)
  }
   //236,119
  def isInterventionPerformed(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementDuringMeasurementPeriod(visit, m,elementName, patientHistoryList)
  }
   //236
  def isPhysicalExamPerformedDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }
    //236
  def  wasEncounterPerformed(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementDuringMeasurementPeriod(visit,m,elementName,patientHistoryList)
  }

  def isActionNotPerformedWithReason(visit: CassandraRow, m:MeasureProperty, element:String, patientHistory: Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit,m,element,patientHistory)
  }

  def isMedicationAdministeredPerformed(visit: CassandraRow, m:MeasureProperty, element:String, patientHistory: Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit,m,element,patientHistory)
  }
   //236
  def wasDiagnosedInHistory(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementInHistory(visit, m,elementName, patientHistoryList)
  }
   //72,128
  def isDiagnosedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }

  //128,119
  def wasInterventionPerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    checkElementInHistory(visit,m,elementName,patientHistoryList)
  }

  //128
  def wasPhysicalExamNotPerformedduringEncounter(r: CassandraRow, MeasureProperty:MeasureProperty,firstDate: String, compareDate: String): Boolean = {
    isDateEqual(r, MeasureProperty, firstDate, compareDate)
  }
   //119
  def wasDiagnosisInHistory(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }

  //119`
  def isEncounterPerformed(visit: CassandraRow, m:MeasureProperty, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    isDiagnosedWithInHistory(visit, m,  histroyElement, patientHistoryList)
  }

  /** this function check whether immunization was administered before end of measuremnet period
    * @param visit visit
    * @param m measure property
    * @param elementName element which will be checked in history
    * @param patientHistoryList patient history list
    * @return true if element was present in history before end of measurement period
    */
  // QPP 111
  def wasImmunizationAdministeredInHistory(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    val isExist = checkElementPresent(visit, m, elementName) &&  checkElementInHistory(visit, m,elementName,patientHistoryList)
    isExist
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure utility
    * @param patientHistoryList get patient history list
    * @return get patient list based on medical conditions
    */

  def getCountFraminghamCADRiskfactorsInHistory(visit: CassandraRow, m: MeasureProperty, patientHistoryList: Broadcast[List[CassandraRow]]): Int = {
    var counter = 0
    if (procedurePerformedStartsBeforeEndOfMeasurementPeriod(visit, m, "crnttobacsmkr", patientHistoryList))
      counter += 1
    if (procedurePerformedStartsBeforeEndOfMeasurementPeriod(visit, m, "fmlyhischd", patientHistoryList))
      counter += 1
    //HDL_Test
    if (isAssessmentBeforeValue(visit, m, 40, "hdl_test", patientHistoryList))
      counter += 1
    if (procedurePerformedStartsBeforeEndOfMeasurementPeriod(visit, m, "diofhy", patientHistoryList))
      counter += 1
    //AnPhTh
    if (isDiagnosedWithInHistory(visit, m, "anphth", patientHistoryList))
      counter += 1
    counter
  }

  def interventionOrderMostRecentBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    mostRecentElementBeforeOrEqualInMonth(visit,m,elementDate, mostRecentElement, month,MostRecentList)
  }
  def isLaboratoryTestPerformedNotDone(r:CassandraRow,measureProperty:MeasureProperty,labTestElement:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    checkElementDuringMeasurementPeriod(r,measureProperty,labTestElement,patientHistoryList)
  }
  //6
  def isProcedurePerformed(visit: CassandraRow, m:MeasureProperty,  histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit, m,  histroyElement, patientHistoryList)
  }

  def isMedicationOrder(visit: CassandraRow, m:MeasureProperty, element:String, patientHistory: Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit,m,element,patientHistory)
  }

  def isDeviceAppliedBeforeOrEqual(visit: CassandraRow, m:MeasureProperty, element:String, patientHistory: Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementInHistory(visit,m,element,patientHistory)
  }
  def isAssessmentPerformed(visit:CassandraRow, m:MeasureProperty, histroyElement: String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementDuringMeasurementPeriod(visit: CassandraRow, m,  histroyElement, patientHistoryList)
  }


  /**
    * This Function verifies encounter performed in history before end of measurement.
    * @param visit Current visit.
    * @param m  Measure Property of the measure.
    * @param historyElement Element Name to look in patient History.
    * @param patientHistoryList PatientHistory List
    * @return
    */
  def wasLaboratoryTestPerformedInXYears(visit: CassandraRow, m: MeasureProperty, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    isProcedurePerformedXYearsInHistory(visit,m,historyElement,noOfYears,patientHistoryList)
  }

  //128

  def wasInterventionOrderedInHistory(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList: Broadcast[ List[CassandraRow] ]): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate, histroyElement: String, patientHistoryList )
  }

  def wasPhysicalExamNotPerformedDuringEncounter(r: CassandraRow, MeasureProperty:MeasureProperty,firstDate: String, compareDate: String): Boolean = {
    isDateEqual(r, MeasureProperty, firstDate, compareDate)
  }

  def isDiagnosedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, elements: String*): Boolean = {
    elements.exists(element=>dataType_On_Encounter(r, measureProperty, element))
  }

  def isMostRecentResultWithinXMonthsInXRange(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    mostRecentElementBeforeOrEqualInMonth(visit,m,elementDate, mostRecentElement, month,MostRecentList)
  }

  def isMostRecentResultWithinXMonthsGreaterThanX(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, ValueGreaterOrEqual: Double, MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    ElementMostRecentResultInBetweenBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, ValueGreaterOrEqual , month, MostRecentList)
  }

  def isInterventionOrderedInXMonths(r: CassandraRow, MeasureProperty:MeasureProperty,firstDate: String, compareDate: String, Months:Int, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isDateEqual(r: CassandraRow, MeasureProperty, firstDate: String, compareDate: String)
  }

  def isMostRecentResultWithinXMonthsLessThanX(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, ValueGreaterOrEqual: Double,MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    mostRecentElementResultGreatAndBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, ValueGreaterOrEqual , month, MostRecentList)
  }

  def isInterventionNotOrderedInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    isElementBeforeOrEqualInMonths(visit, m, elementDate, histroyElement, month, patientHistoryList)

  }
  def wasDignosedInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    isElementBeforeOrEqualInMonths(visit, m, elementDate, histroyElement, month, patientHistoryList)
  }

  // This function verifies the mostRecentLaboratory Test Performed of the Patient during measurement Period.
  def isMostRecentLaboratoryTestResult(visit:CassandraRow, m:MeasureProperty, laboratoryTestElement:String, value:Double, flag:String, mostRecentPatientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    isAssessmentPerformedGreaterThanX(visit,m,laboratoryTestElement,value,flag,mostRecentPatientHistoryList)
  }

  //72
  /**
    * This function is used to check if any Laboratory test not done and reason is specified for it
    * @param r cassandra record for the patient
    * @param measureProperty measurement property
    * @param labTestElement labTestElement is the reason for test not done
    * @param patientHistoryList list of patient history data
    * @return returns true if labTestElement reason found else returns false
    */
  def isLaboratoryTestNotDone(r:CassandraRow,measureProperty:MeasureProperty,labTestElement:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    isDiagnosedWithInHistory(r,measureProperty,labTestElement,patientHistoryList)
  }





  def isImmunizationAdministeredDuringEncounter(visit: CassandraRow, m:MeasureProperty, element:String ): Boolean ={
  dataType_On_Encounter(visit, m, element)
}
///IsMedicationOrderDuringEncounter //isMedicationOrderedDuringEncounter
  def isMedicationActiveOverlapsEncounter(visit:CassandraRow, m:MeasureProperty,elementDate:String, histroyElement: String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isElementPresentBeforeOrEqual(visit: CassandraRow, m, elementDate, histroyElement, patientHistoryList)
  }

  def isCommunicationDoneFromPatientToProviderDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }
  def isMedicationAllergyDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }
  def isMedicationActiveDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }

  def isMedicationOrderedOnEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String):Boolean= {
    dataType_On_Encounter(visit: CassandraRow, m, elementName)
  }

  def isMedicationOrderedDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r: CassandraRow, measureProperty, element)
  }
  def wasMedicationOrderedNotDoneInHistory(visit: CassandraRow, m:MeasureProperty,Element: String,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeorEqualEncounterDate(visit, m, Element, patientHistoryList)
  }

  def isAssessment(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }

  def isAssessmentPerformedBefore(visit:CassandraRow, m:MeasureProperty,elementDate:String, histroyElement: String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isElementPresentBeforeOrEqual(visit: CassandraRow, m, elementDate, histroyElement, patientHistoryList)
  }
  def isInterventionOrderOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }

  def isPhysicalExamPerformedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }

  /**
    * this function will check whether Tobacco Cessation Intervention element Done Before EndDate
    * @param visit current visit
    * @param m measure property
    * @param elementName element name which will be searched in history
    * @param patientHistoryList patient history list
    * @return true if tobacco Cessation Intervention element Done Before EndDate
    */
  def TobaccoCessationInterventionDoneBeforeEndDate(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit, m,elementName, patientHistoryList)
  }


  def isDeviceAppliedBefore(visit: CassandraRow, m:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    wasDiagnosedBefore(visit, m, elementDate, histroyElement, patientHistoryList )
  }



  /**
    * This function verifies the procedure of a patient is performed during emergency encounter.
    * @param visit                Current visit of the patinent.
    * @param m                    Mesaure Property of the measure.
    * @param element              Element that has to be verified during edvisit.
    * @param posElement           place of service  that has to be verified during edvisit.
    * @param edvisitArrivalDate   emergency visit Arrival date of the patient.
    * @param edvisitDepartureDate emergency visit departure  date of the patient.
    * @param crtclDate            Critical Care visit date of the patient.
    * @return                     It will return those patient whose procedure is performed during emergency encounter.
    */
  def isProcedurePerformedDuringEncounter(visit: CassandraRow, m: MeasureProperty, element: String, posElement: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    isDiagnosisDuringEncounter(visit, m, element, posElement, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }

 def wasInterventionPerformedBeforeEnd(r: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterOrEqualEndDateInMonths(r, m, histroyElement, month, patientHistoryList)
  }

  def wasProcedurePerformedBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeEncounterDate(visit,m,elementName,patientHistoryList)
  }


  def wasDiagnosedWithBeforeOrEqual(visit: CassandraRow, m:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    wasElementBeforeOrEqualInHistory(visit, m, elementDate, histroyElement, patientHistoryList )

  }

  def wasProcedurePerformedBeforeOrEqual(visit: CassandraRow, m:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    wasElementBeforeOrEqualInHistory(visit, m, elementDate, histroyElement, patientHistoryList )

  }


  def wasAssessmentPerformedBeforeOrEqual(visit: CassandraRow, m:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    wasElementBeforeOrEqualInHistory(visit, m, elementDate, histroyElement, patientHistoryList )

  }

  def isInterventionPerformedDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }

  def isAssessmentPerformedDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }
  def isMedicationActiveOrdered(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }

  def isInterventionNotDoneDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataType_On_Encounter(r, measureProperty, element)
  }

  /**
    * This function verifies the patient whose result is negative for Retinal Dilated Exam.
    * @param visit  Current Visit of the patient.
    * @param m      Measure Property of the measure.
    * @param ElementCheckInHistory Element that has to verified in the history.
    * @param NoOfMonth            Number of months that has to be go back in history.
    * @param HistoryList          Patient histroy list.
    * @return  It will return those patient whose result is negative for Retinal Dilated Exam.
    */
  def wasNegativeResultWithRetinalDilatedExam(visit: CassandraRow, m: MeasureProperty, ElementCheckInHistory: String,NoOfMonth: Int, HistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasPhysicalExamPerformedXForRetinalDilatedExam(visit, m, ElementCheckInHistory, NoOfMonth, HistoryList)
  }







}
