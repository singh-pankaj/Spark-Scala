package com.figmd.janus.measureComputation.qpp.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ElementMaster, Elements, MeasureProperty, QPP130Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Qpp130 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp130"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {


    /** Below column are missing from cassandra acc_2018, tblencounter_qpp
      * meencodes
      * meencodes_date
      * phythrpevaltn_cpt
      * phythrpevaltn_cpt_date
      * revaphythrp_cpt
      * revaphythrp_cpt_date
      * occutherapy_go_copy_505
      * occutherapy_go_copy_505_date
      * occuthera_reevalution_cpt
      * occuthera_reevalution_cpt_date
      *
      */


    // Filter IPP
    val ippRDD = getIpp(rdd)
    ippRDD.cache()

    // Filter Met
    val metRDD = getMet(ippRDD)
    metRDD.cache()


    val intermediateB = ippRDD.subtract(metRDD)
    intermediateB.cache()

    // Filter Exceptions
    val exceptionRDD = getExceptionRDD(intermediateB)
    exceptionRDD.cache()


    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }


  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP)

    rdd.filter(visit => isPatientAdult(visit, m)
      && isVisitTypeIn(visit, m,
      QPP130Elements.Medications_Encounter_Codes,
      QPP130Elements.Therapeutic_Interventions,
      QPP130Elements.Physical_Therapy_Evaluation_Cpt,
      QPP130Elements.Re_Evaluation_Of_Physical_Therapy_Cpt,
      QPP130Elements.Occupational_Therapy_Cpt,
      QPP130Elements.Occupational_Therapy_Re_Evalution_Cpt)
    )

  }


  def getMet(ipp: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET)

    ipp.filter(visit =>

      (
        isProcedurePerformedDuringEncounter(visit, m, QPP130Elements.Current_Medications_Documented)
          || isProcedurePerformedDuringEncounter(visit, m, QPP130Elements.Current_Medications)
          || isProcedurePerformedDuringEncounter(visit, m, QPP130Elements.Current_Medications_Documented_Snmd)
        )
        &&
        !isProcedurePerformedDuringEncounter(visit, m, QPP130Elements.Current_Medications_Documented_Reason_Not_Specified)
    )
  }


  def getExceptionRDD(intermedaiateRdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION)

    intermedaiateRdd.filter(visit =>

      isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP130Elements.Current_Medications_Documented_Patient_Not_Eligible)
        || isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP130Elements.Medical_Situation)
        || isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP130Elements.Medical_Or_Other_Reason_Not_Done)

    )
  }
}






