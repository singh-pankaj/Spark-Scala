package com.figmd.janus.measureComputation.qpp.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Qpp91 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp91"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd)
    ippRDD.cache()

    //met
    val metRDD = getMet(ippRDD)
    metRDD.cache()

    // Filter Exceptions
    val intermediate = getSubtractRDD(ippRDD, metRDD)

    val exceptionRDD = getExceptionRDD(intermediate)
    exceptionRDD.cache()

    // Filter not meate
    val notMetRDD = getSubtractRDD(intermediate, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, null, null, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }

  // Filter IPP
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP)

    rdd.filter(visit => age_At_Encounter_GreaterThan_Or_EqualTo_2(visit, m)
      && isVisitTypeIn(visit,m)
      && (diagnosis_Overlaps_Encounter(visit, m, ElementMaster.Acute_Actinic_Otitis_Externa_Right_Ear)
      || diagnosis_Overlaps_Encounter(visit, m, ElementMaster.Acute_Actinic_Otitis_Externa_Left_Ear))
      && !teleHealthModifier(visit, m)
      && !encounter_Performed(visit, m, ElementMaster.Pos_20)
    )

  }

  //met
  def getMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET)

    ippRDD.filter(visit =>

      (
        ((medication_Order_Starts_After_Start_Of_Diagnosis(visit, m, ElementMaster.Topical_Preparation, ElementMaster.Acute_Otitis_Media, 30)
          || medication_Order_Starts_After_Start_Of_Diagnosis(visit, m, ElementMaster.Topical_Antibiotics, ElementMaster.Acute_Otitis_Media, 30))
          ||(medication_Active_On_Encounter(visit, m, ElementMaster.Topical_Antibiotics)
          || medication_Active_On_Encounter(visit, m, ElementMaster.Topical_Antibiotics))
          || medication_Administered_During_Encounter(visit, m, ElementMaster.Topical_Preparation)
          )
          && !medication_Not_Administered_During_Encounter(visit, m, ElementMaster.Topical_Preparations_Reason_Not_Specified))
    )
  }


  //ExceptionSourceCode
  def getExceptionRDD(intermediateRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION)

    intermediateRDD.filter(visit =>
      ((diagnosis_Overlaps_Encounter(visit, m, ElementMaster.Tympanic_Membrane_Perforation)
        || diagnosis_Overlaps_Encounter(visit, m, ElementMaster.Acute_Otitis_Media)
        || diagnosis_Overlaps_Encounter(visit, m, "Denominator Exceptions_HNS"))
        || medication_Not_Administered_During_Encounter(visit, m, "Topical preparations_Medical Reason"))
        || medication_Not_Administered_During_Encounter(visit, m, "Topical preparations_Patient Reason")
    )

  }
}
