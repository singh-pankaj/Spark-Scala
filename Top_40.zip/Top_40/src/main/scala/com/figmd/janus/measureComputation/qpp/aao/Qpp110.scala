package com.figmd.janus.measureComputation.qpp.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ElementMaster, Elements, MeasureProperty}
import com.figmd.janus.measureComputation.qpp.aao.Qpp110.{getPatientHistory, isVisitTypeIn}
import com.figmd.janus.measureComputation.qpp.aao.Qpp110.{MEASURE_NAME, saveToWebDM}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Qpp110 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp110"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {


    val patienthistory = getElementHistory(sparkSession
      ,ElementMaster.Allergy_To_Eggs
    ).collect().toList

    val patientHistory:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistory)

    //Backtracking List

    // Filter IPP
    val ippRDD = getIpp(rdd)
    ippRDD.cache()

    val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Exclusion
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter Met
    val metRDD = getMet(ippRDD)
    metRDD.cache()

    val intermediateB = ippRDD.subtract(metRDD)
    intermediateB.cache()

    var getPatientHistoryList = getPatientHistory(sparkSession,rdd, ElementMaster.Allergy_To_Eggs).collect.toList;
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    // Filter Exceptions
    val exceptionRDD = getExceptionRDD(intermediateB,patientHistoryList: Broadcast[List[CassandraRow]])

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
    notMetRDD.cache()




    saveToWebDM(rdd, ippRDD, noteligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }


  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP)

    rdd.filter(visit =>

      isAgeAboveInMonth(visit, m,true,6)
        &&
        (isVisitTypeIn(visit, m, ElementMaster.Face_To_Face_Interaction,
          ElementMaster.Peritoneal_Dialysis_110,
          ElementMaster.Annual_Wellness_Visit,
          ElementMaster.Discharge_Services___Nursing_Facility,
          ElementMaster.Nursing_Facility_Visit,
          ElementMaster.Preventive_Care__Established_Office_Visit__0_To_17,
          ElementMaster.Preventive_Care_Services_Established_Office_Visit_18_and_Up,
          ElementMaster.Hemodialysis_110,
          ElementMaster.Office_Visit,
          ElementMaster.Patient_Provider_Interaction,
          ElementMaster.Home_Healthcare_Services,
          ElementMaster.Care_Services_in_Long_Term_Residential_Facility,
          ElementMaster.Outpatient_Consultation,
          ElementMaster.Health_Risk_Assessment,
          ElementMaster.Preventive_Care_Services_Group_Counseling,
          ElementMaster.Preventive_Care_Services_Other,
          ElementMaster.Preventive_Care_Services_Individual_Counseling,
          ElementMaster.Preventive_Care_Services_Initial_Office_Visit_18_and_Up,
          ElementMaster.Preventive_Care_Services__Initial_Office_Visit__0_To_17
        ))
        &&
        (isTelehealthEncounterNotPerformed(visit, m, ElementMaster.Annual_Wellness_Visit_Telehealth_Modifier,
          ElementMaster.Care_Services_in_Long_Term_Residential_Facility_Telehealth_Modifier,
          ElementMaster.Discharge_Services___Nursing_Facility_Telehealth_Modifier,
          ElementMaster.Hemodialysis_Telehealth_Modifier,
          ElementMaster.Home_Healthcare_Services_Telehealth_Modifier,
          ElementMaster.Health_Risk_Assessment_Telehealth_Modifier,
          ElementMaster.Nursing_Facility_Visit_Telehealth_Modifier,
          ElementMaster.Outpatient_Consultation_Telehealth_Modifier,
          ElementMaster.Office_Visit_Telehealth_Modifier,
          ElementMaster.Preventive_Care___Established_Office_Visit_0_To_17_Telehealth_Modifier,
          ElementMaster.Preventive_Care__Initial_Office_Visit_0_To_17_Telehealth_Modifier,
          ElementMaster.Preventive_Care_Services_Initial_Office_Visit_18_And_Up_Telehealth_Modifier,
          ElementMaster.Preventive_Care_Services___Established_Office_Visit_18_And_Up_Telehealth_Modifier,
          ElementMaster.Preventive_Care_Services___Group_Counseling_Telehealth_Modifier,
          ElementMaster.Preventive_Care_Services_Individual_Counseling_Telehealth_Modifier,
          ElementMaster.Preventive_Care_Services_Other_Telehealth_Modifier,
          ElementMaster.Peritoneal_Dialysis_Telehealth_Modifier,
          ElementMaster.POS_02
        ))
        &&
        (
          // Influenza period date criteria
          (
            isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Encounter_Date)
            )
            ||
            (
              isDuringInfluenzaPeriodLastThreeMonth(visit, m, ElementMaster.Encounter_Date)
              )
          )

    )

  }


  def getMet(ipp: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET)

    ipp.filter(visit =>

      ( isInfluenzaImmunizationAdministered(visit, m, ElementMaster.Influenza_Immunization)
        && (
        (
          (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Influenza_Immunization_Date))
            && (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Encounter_Date))
          )
          ||
          (
            (isDuringInfluenzaPeriodLastFiveMonth(visit, m, ElementMaster.Influenza_Immunization_Date))
              && (isDuringInfluenzaPeriodLastThreeMonth(visit, m, ElementMaster.Encounter_Date))
            )
        )
        )
        ||
        ( isInfluenzaVaccineAdministered(visit, m, ElementMaster.Influenza_Vaccine)
          && (
          (
            (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Influenza_Vaccine_date))
              && (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Encounter_Date))
            )
            ||
            (
              (isDuringInfluenzaPeriodLastFiveMonth(visit, m, ElementMaster.Influenza_Vaccine_date))
                && (isDuringInfluenzaPeriodLastThreeMonth(visit, m, ElementMaster.Encounter_Date))
              )
          )
          )
        ||
        ( isInfluenzaVaccinationProcedure(visit, m, ElementMaster.Influenza_Vaccination)
          && (
          (
            (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Influenza_Vaccination_Date))
              && (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Encounter_Date))
            )
            ||
            (
              (isDuringInfluenzaPeriodLastFiveMonth(visit, m, ElementMaster.Influenza_Vaccination_Date))
                && (isDuringInfluenzaPeriodLastThreeMonth(visit, m, ElementMaster.Encounter_Date))
              )
          )
          )
        ||
        ( isCommunicationFromPatientToProviderPreviousReceiptOfInfluenzaVaccine(visit, m, ElementMaster.Previous_Receipt_Of_Influenza_Vaccine)
          && (
          (
            (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Previous_Receipt_Of_Influenza_Vaccine_Date))
              && (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Encounter_Date))
            )
            ||
            (
              (isDuringInfluenzaPeriodLastFiveMonth(visit, m, ElementMaster.Previous_Receipt_Of_Influenza_Vaccine_Date))
                && (isDuringInfluenzaPeriodLastThreeMonth(visit, m, ElementMaster.Encounter_Date))
              )
          )
          )
        ||
        ( isCommunicationFromPatientToProviderPreviousReceiptOfInfluenzaVaccination(visit, m, ElementMaster.Previous_Receipt_Of_Influenza_Vaccination)
          && (
          (
            (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Previous_Receipt_Of_Influenza_Vaccination_Date))
              && (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Encounter_Date))
            )
            ||
            (
              (isDuringInfluenzaPeriodLastFiveMonth(visit, m, ElementMaster.Previous_Receipt_Of_Influenza_Vaccination_Date))
                && (isDuringInfluenzaPeriodLastThreeMonth(visit, m, ElementMaster.Encounter_Date))
              )
          )
          )

    )
  }


  def getExceptionRDD(intermedaiateRdd: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCEPTION)

    intermedaiateRdd.filter(visit =>
      ( isCommunicationFromPatientToProviderInfluenzaVaccinationDeclined(visit, m, ElementMaster.Influenza_Vaccination_Declined)
        && (
        (
          (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Influenza_Vaccination_Declined_Date))
            && (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Encounter_Date))
          )
          ||
          (
            (isDuringInfluenzaPeriodLastFiveMonth(visit, m, ElementMaster.Influenza_Vaccination_Declined_Date))
              && (isDuringInfluenzaPeriodLastThreeMonth(visit, m, ElementMaster.Encounter_Date))
            )
        )
        )
        || ( isActionNotPerformedWithReasonForInfluenza(visit, m, ElementMaster.Medical_Reason_QPP110)
        && (
        (
          (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Medical_Reason_QPP110_date))
            && (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Encounter_Date))
          )
          ||
          (
            (isDuringInfluenzaPeriodLastFiveMonth(visit, m, ElementMaster.Medical_Reason_QPP110_date))
              && (isDuringInfluenzaPeriodLastThreeMonth(visit, m, ElementMaster.Encounter_Date))
            )
        )
        )
        || ( isActionNotPerformedWithReasonForInfluenza(visit, m, ElementMaster.Patient_Reason_QPP110)
        && (
        (
          (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Patient_Reason_QPP110_date))
            && (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Encounter_Date))
          )
          ||
          (
            (isDuringInfluenzaPeriodLastFiveMonth(visit, m, ElementMaster.Patient_Reason_QPP110_date))
              && (isDuringInfluenzaPeriodLastThreeMonth(visit, m, ElementMaster.Encounter_Date))
            )
        )
        )
        || ( isActionNotPerformedWithReasonForInfluenza(visit, m, ElementMaster.System_Reason_QPP110)
        && (
        (
          (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.System_Reason_QPP110_date))
            && (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Encounter_Date))
          )
          ||
          (
            (isDuringInfluenzaPeriodLastFiveMonth(visit, m, ElementMaster.System_Reason_QPP110_date))
              && (isDuringInfluenzaPeriodLastThreeMonth(visit, m, ElementMaster.Encounter_Date))
            )
        )
        )
        || ( isActionNotPerformedWithReasonForInfluenza(visit, m, ElementMaster.Influenza_Immunization_Exception)
        && (
        (
          (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Influenza_Immunization_Exception_Date))
            && (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ElementMaster.Encounter_Date))
          )
          ||
          (
            (isDuringInfluenzaPeriodLastFiveMonth(visit, m, ElementMaster.Influenza_Immunization_Exception_Date))
              && (isDuringInfluenzaPeriodLastThreeMonth(visit, m, ElementMaster.Encounter_Date))
            )
        )
        )
        || isAllergyToInfluenza(visit, m, ElementMaster.Allergy_To_Eggs, patientHistoryList)
        || isAllergyToInfluenza(visit, m, ElementMaster.Allergy_To_Influenza_Vaccine, patientHistoryList)
        || isIntoleranceToInfluenza(visit, m, ElementMaster.Intolerance_To_Influenza_Vaccine, patientHistoryList)
        || isIntoleranceToInfluenza(visit, m, ElementMaster.Intolerance_Influenza_Vaccine, patientHistoryList)
        || isAllergyToInfluenza(visit, m, ElementMaster.Allergy_Influenza_Vaccine, patientHistoryList)
        || isAllergyToInfluenza(visit, m, ElementMaster.Egg_Substance, patientHistoryList)

    )
  }
}






