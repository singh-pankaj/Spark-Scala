package com.figmd.janus.measureComputation.ecqm.aao

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.{Measure, MeasureUpdate}
import com.figmd.janus.measureComputation.master.{ElementsEcqm139, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Ecqm139 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm139"
  var m = MeasureProperty(MEASURE_NAME,"")

  def refresh(sparkSession: SparkSession, rdd:RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //met
    val metRDD = getMet(ippRDD)
    metRDD.cache()
    // Filter Exceptions
    val intermediate = getinterRDD(ippRDD, metRDD)
    intermediate.cache()
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
   // exceptionRDD.cache()
    // Filter not meate
    val notMetRDD = getinterRDD(intermediate, exceptionRDD)
    notMetRDD.cache()


    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }

  // Filter IPP
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {
    var m = MeasureProperty(MEASURE_NAME,IPP)

    rdd.filter(visit =>  age_At_Encounter_GreaterThan_Or_EqualTo_65(visit, m)
      && encounter_Performed(visit,m,ElementsEcqm139.Face_To_Face_Interaction)
      && encounter_Performed(visit,m,ElementsEcqm139.Office_Visit)
      && encounter_Performed(visit,m,ElementsEcqm139.Preventive_Care_Services_Individual_Counseling)
      && encounter_Performed(visit,m,ElementsEcqm139.Nursing_Facility_Visit)
      && encounter_Performed(visit,m,ElementsEcqm139.Care_Services_in_Long_Term_Residential_Facility)
      && encounter_Performed(visit,m,ElementsEcqm139.Home_Healthcare_Services)
      && encounter_Performed(visit,m,ElementsEcqm139.Preventive_Care_Services_Initial_Office_Visit_18_And_Up)
      && encounter_Performed(visit,m,ElementsEcqm139.Preventive_Care_Services_Established_Office_Visit_18_And_Up)
      && encounter_Performed(visit,m,ElementsEcqm139.Annual_Wellness_Visit)
      && encounter_Performed(visit,m,ElementsEcqm139.Audiology_Visit)
      && encounter_Performed(visit,m,ElementsEcqm139.Ophthalmological_Services)

    )

  }


  // Filter Exclusion
  def getExclusion(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    var m = MeasureProperty(MEASURE_NAME,EXCLUSION)

    rdd.filter(visit =>
          encounter_Performed(visit,m,ElementsEcqm139.Discharged_To_Home_For_Hospice_Care)
      ||  encounter_Performed(visit,m,ElementsEcqm139.Discharged_To_Health_Care_Facility_For_Hospice_Care)
      || (intervention_Order(visit,m,ElementsEcqm139.Hospice_Care_Ambulatory)
      ||  intervention_Performed(visit,m,ElementsEcqm139.Hospice_Care_Ambulatory))
      ||  assesment_Performed(visit,m,ElementsEcqm139.Patient_Not_Ambulatory)
    )
  }

  def getMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    var m = MeasureProperty(MEASURE_NAME,MET)

    ippRDD.filter(visit =>   assesment_Performed(visit, m, ElementsEcqm139.Falls_Screening ))

  }

  }


