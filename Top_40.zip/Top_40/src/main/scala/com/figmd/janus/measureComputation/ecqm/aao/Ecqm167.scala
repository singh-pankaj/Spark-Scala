package com.figmd.janus.measureComputation.ecqm.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Ecqm167 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm167"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    // Filter Exclusion
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter notEligible
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter Met
    val metRDD = getMet(ippRDD)
    metRDD.cache()

    val intermediatRDD = getSubtractRDD(ippRDD, metRDD)
    intermediatRDD.cache()

    // Filter Exception
    val exceptionRDD = getException(intermediatRDD)
    exceptionRDD.cache()


    val notMet = getSubtractRDD(intermediatRDD,exceptionRDD)
    notMet.cache()

    saveToWebDM(initialRDD, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMet, MEASURE_NAME)

  }

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val measureProperty = MeasureProperty(MEASURE_NAME, IPP)
    initialRDD.filter(visit =>

      {
        val c1=isPatientAdult(visit, measureProperty)
        val c2=isDiagnosedWithOnEncounter(visit, measureProperty, ElementMaster.Diabetic_Retinopathy)
        val c3=isVisitTypeIn(visit, measureProperty, ElementMaster.Ophthalmological_Services, ElementMaster.Care_Services_in_Long__Term_Residential_Facility, ElementMaster.Nursing_Facility_Visit, ElementMaster.Office_Visit, ElementMaster.Outpatient_Consultation, ElementMaster.Face_To_Face_Interaction)

        c1 && c2 && c3
      }

    )

  }

  def getMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET)
    ippRDD.filter(visit => {

      val cond1 = (diagnosticStudy_Performed(visit, m, ElementMaster.Macular_Exam) &&
        diagnosticStudy_Performed(visit, m, ElementMaster.Mild_Non_Proliferative_Diabetic_Retinopathy, ElementMaster.Moderate_Diabetic_Retinopathy, ElementMaster.Proliferative_Diabetic_Retinopathy, ElementMaster.Severe_Non_Proliferative_Diabetic_Retinopathy, ElementMaster.Very_Severe_Non_Proliferative_Diabetic_Retinopathy)
        && diagnosticStudy_Performed(visit, m, ElementMaster.Macular_Edema_Findings_Absent, ElementMaster.Macular_Edema_Findings_Absent))
      val cond2 = checkEyeElementsInRange(visit, ElementMaster.Diabetic_Retinopathy__Eye, ElementMaster.Macular_Exam_Eye, ElementMaster.Level_Of_Severity_Of_Retinopathy_Findings_Eye,ElementMaster.Macular_Edema_Findings__Eye)

      cond1 && cond2
    }
    )
  }


  def getException(exceptionRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION)
    exceptionRDD.filter(visit =>
      diagnostic_Study_Not_Done(visit, m, ElementMaster.Medical_Reason_CMS167, ElementMaster.Patient_Reason_CMS167)
    )
  }
}
