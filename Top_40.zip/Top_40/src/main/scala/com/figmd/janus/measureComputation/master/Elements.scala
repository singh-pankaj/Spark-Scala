package com.figmd.janus.measureComputation.master


object Elements{


  val Current_Medication_Documented = "crntmeddocmn"
  val Current_Medication = "crntmed"
  val Current_Medications_Documented_Reason_Not_Specified = "crntmeddoc_patntelig"
  val MEDICAL_SITUATION="medsit"
  val Medical_Or_Other_Reason_Not_Done = "meorotrenodo"
  val Current_Medications_Documented_SNMD = "cumedosn"

}



object Ecqm68Elements {


}

object ElementsEcqm68 {

  val Medications_Encounter_Code_Set = "meencose"
  val Current_Medications_Documented_SNMD = "cumedosn"
  val Medical_Or_Other_Reason_Not_Done = "meorotrenodo "


}


object ElementsEcqm139 {
  val Face_To_Face_Interaction = ""
  val Office_Visit = ""
  val Preventive_Care_Services_Individual_Counseling = ""
  val Nursing_Facility_Visit = ""
  val Care_Services_in_Long_Term_Residential_Facility = ""
  val Home_Healthcare_Services = ""
  val Preventive_Care_Services_Initial_Office_Visit_18_And_Up = ""
  val Preventive_Care_Services_Established_Office_Visit_18_And_Up = ""
  val Annual_Wellness_Visit = ""
  val Audiology_Visit = ""
  val Ophthalmological_Services = ""
  val Discharged_To_Home_For_Hospice_Care=""
  val Discharged_To_Health_Care_Facility_For_Hospice_Care=""
  val Hospice_Care_Ambulatory=""
  val Patient_Not_Ambulatory=""
  val Falls_Screening=""

}
