package com.figmd.janus.util.measure

import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator
import com.figmd.janus.measureComputation.master.MeasureProperty


object PatientHistoryUtility {

  val rdd = WebDataMartCreator.spark.sparkContext.cassandraTable("webdatamart", "patient_history")



  def medication_Active_Till_Encounter(visit: CassandraRow, m: MeasureProperty,medicationElement : String): Unit =
  {
    getPatientHistory(visit.getString("patientId"), medicationElement)

  }

  def medication_Active_Till_Encounter(visit: CassandraRow, m: MeasureProperty): Unit =
  {

  }

  def getPatientHistory(patientId : String, element :String): Boolean =
  {

      val newRdd = rdd.select("el").where(s"patientuid=? and element=?",patientId,element)
      var elementCount =newRdd.count()
      if(elementCount > 0)
        {
          true
        }
      else
        {
           false
        }

    }






}
