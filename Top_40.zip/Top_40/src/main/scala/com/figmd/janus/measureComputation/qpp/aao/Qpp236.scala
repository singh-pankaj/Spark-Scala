package com.figmd.janus.measureComputation.qpp.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP236Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 236
* Measure Title              :- Controlling High Blood Pressure
* Measure Description        :- Percentage of patients 18 - 85 years of age who had a diagnosis of hypertension
                                and whose blood pressure was adequately controlled (< 140/90 mmHg) during the measurement period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/



object  Qpp236  extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp236"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {
    val patienthistory = getElementHistory(sparkSession
      ,QPP236Elements.Essential_Hypertension
      ,QPP236Elements.Pregnancy
      ,QPP236Elements.End_Stage_Renal_Disease
      ,QPP236Elements.Chronic_Kidney_Disease__Stage_5
      ,QPP236Elements.Vascular_Access_For_Dialysis
      ,QPP236Elements.Kidney_Transplant
      ,QPP236Elements.Dialysis_Services
      ,QPP236Elements.Esrd_Monthly_Outpatient_Services
      ,QPP236Elements.Hospice_Services
      ,QPP236Elements.Hospice_Services_Snomedct
      ,QPP236Elements.Hospice_Care
      ,QPP236Elements.Medical_Exclusions
      ,QPP236Elements.Isnp_Or_Long_Term_Care
      ,QPP236Elements.Institutional_Special_Needs_Plans
      ,QPP236Elements.Long_Term_Care_Pos
      ,QPP236Elements.Lowest_Diastolic_Bp
      ,QPP236Elements.Lowest_Systolic_Bp
    ).collect().toList

    val patientHistory:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistory)

    val patienthistoryEshy = getElementHistory(sparkSession,QPP236Elements.Essential_Hypertension)

    val FirstDateList:List[CassandraRow]=minDate(patienthistoryEshy,QPP236Elements.Essential_Hypertension,QPP236Elements.Essential_Hypertension_Date)
    val FirstDatelist:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(FirstDateList)


    // Filter IPP
    val ippRDD = getIpp(rdd,FirstDatelist)
    ippRDD.cache()
    // Filter Exclusions

    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    val exclusionRDD = getExclusionRdd(ippRDD,patientHistory)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateNumerator = getinterRDD(ippRDD, exclusionRDD)
    intermediateNumerator.cache()
    // Filter Met
    val metRDD = getMet(intermediateNumerator)
    metRDD.cache()
    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not meate
    val notMetRDD = getSubtractRDD(intermediateNumerator, metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }


  def getIpp(rdd: RDD[CassandraRow],FirstDatelist:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP)

    rdd.filter(visit =>

             isPatientAdult(visit,m)
        &&   isAgeBelow(visit,m,false,86)
        &&   wasDiagnosedInFirstXMonths(visit,m,QPP236Elements.Essential_Hypertension,FirstDatelist,6)
        &&   isVisitTypeIn(visit,m,QPP236Elements.Adult_Outpatient_Visit)
    )

  }

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistory:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION)

    ippRDD.filter(visit =>
           isDiagnosedWithOnEncounter(visit,m,QPP236Elements.Pregnancy)
        ||
          (
                 isDiagnosedWithOnEncounter(visit,m,QPP236Elements.End_Stage_Renal_Disease)
              || isDiagnosedWithOnEncounter(visit,m,QPP236Elements.Chronic_Kidney_Disease__Stage_5)
            )
        ||
          (
                 wasProcedurePerformedInHistory(visit,m,QPP236Elements.Vascular_Access_For_Dialysis,patientHistory)
              || wasEncounterPerformedInHistory(visit,m,QPP236Elements.Esrd_Monthly_Outpatient_Services,patientHistory)
              || wasProcedurePerformedInHistory(visit,m,QPP236Elements.Kidney_Transplant,patientHistory)
              || wasProcedurePerformedInHistory(visit,m,QPP236Elements.Dialysis_Services,patientHistory)
            )
        || isInterventionPerformed(visit,m,QPP236Elements.Hospice_Services,patientHistory)
        ||
          (
                 wasInterventionPerformedInHistory(visit,m,QPP236Elements.Hospice_Services_Snomedct,patientHistory)
              || wasInterventionPerformedInHistory(visit,m,QPP236Elements.Hospice_Care,patientHistory)
            )
        || wasInterventionPerformedInHistory(visit,m,QPP236Elements.Medical_Exclusions,patientHistory)
        || wasInterventionPerformedInHistory(visit,m,QPP236Elements.Isnp_Or_Long_Term_Care,patientHistory)
        ||
          (
            isAgeAbove(visit,m,true,65)
              &&
              (
                     wasInterventionPerformedInHistory(visit,m,QPP236Elements.Institutional_Special_Needs_Plans,patientHistory)
                  || wasEncounterPerformed(visit,m,QPP236Elements.Long_Term_Care_Pos,patientHistory)
                )
            )
    )
  }

  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET)

    intermediateA.filter(visit =>
           isDiastolicBPSystolicBPPerformedOnEncounter(visit,m,QPP236Elements.Lowest_Systolic_Bp,QPP236Elements.Lowest_Diastolic_Bp,QPP236Elements.Lowest_Systolic_Bp_Date,QPP236Elements.Lowest_Diastolic_Bp_Date,90.0,140)
        ||
          (
               isPhysicalExamPerformedDuringEncounter(visit,m,QPP236Elements.Systolic_Bp)
            && isPhysicalExamPerformedDuringEncounter(visit,m,QPP236Elements.Diastolic_Bp)
          )
          && !(
                (
                     isPhysicalExamPerformedDuringEncounter(visit,m,QPP236Elements.Systolic_Blood_Pressure_Not_Met)
                  && isPhysicalExamPerformedDuringEncounter(visit,m,QPP236Elements.Diastolic_Blood_Pressure_Not_Met)
                )
              || isPhysicalExamPerformedDuringEncounter(visit,m,QPP236Elements.Blood_Pressure_Measurement_Reason_Not_Specified)
              )
    )
  }

}
