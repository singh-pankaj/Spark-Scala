package com.figmd.janus.measureComputation.nonqpp

import java.util.Date
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.{Measure, MeasureUpdate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, ACEP24Elements}
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Acep24 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Acep24"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, rdd, ACEP24Elements.Abdominal_Hysterectomy).collect.toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(rdd)
    ippRDD.cache()

    // Filter Exclusion
    val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA)
    metRDD.cache()

    val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA, metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, noteligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }


  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP)

    rdd.filter(visit =>
      isFemale(visit, m)
        && isAgeBetween(visit,m,14,51)
        && isVisitTypeIn(visit, m, ACEP24Elements.Critical_Care_Evaluation_And_Management, ACEP24Elements.Emergency_Department_Visit)
        && isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP24Elements.Abdominal_Pain, ACEP24Elements.Abdominal_Pain_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP24Elements.Critical_Care_Evaluation_And_Management_Date)
    )

  }

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION)

    ippRDD.filter(visit => (
      wasProcedurePerformedInHistory(visit, m, AdminElements.Encounter_Date, ACEP24Elements.Abdominal_Hysterectomy, patientHistoryList)
        ||
        (
          isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP24Elements.Pregnancy, ACEP24Elements.Pregnancy_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP24Elements.Critical_Care_Evaluation_And_Management_Date)
            && !isLaboratoryTestOrderDuringEDOrCCEncounter(visit, m, ACEP24Elements.Pregnancy__Urine_Serum_, ACEP24Elements.Pregnancy__Urine_Serum__Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP24Elements.Critical_Care_Evaluation_And_Management_Date)
          )

      )
    )
  }


  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET)

    intermediateA.filter(visit =>
      isLaboratoryTestOrderDuringEDOrCCEncounter(visit, m, ACEP24Elements.Pregnancy__Urine_Serum_, ACEP24Elements.Pregnancy__Urine_Serum__Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP24Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }

}







