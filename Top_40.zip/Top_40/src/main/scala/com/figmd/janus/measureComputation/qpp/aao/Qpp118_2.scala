package com.figmd.janus.measureComputation.qpp.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP118_AElements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Qpp118_2 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "M118_2"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD:RDD[CassandraRow] = getPatientHistory(sparkSession,rdd,QPP118_AElements.Office_Visit,
      QPP118_AElements.Nursing_Facility_Visit,QPP118_AElements.Care_Services_In_Long_Term_Residential_Facility,
      QPP118_AElements.Home_Healthcare_Services,QPP118_AElements.Coronary_Artery_Disease,QPP118_AElements.Diabetes,
      QPP118_AElements.Left_Ventricular_Ejection_Fraction,QPP118_AElements.Left_Ventricular_Ejection_Fraction__Lvef_,
      QPP118_AElements.Twod_Echocardiography,QPP118_AElements.Lvef_Assessment,QPP118_AElements.Ace_Inhibitor_Or_Arb_1,
      QPP118_AElements.Ace_Or_Arb_Documented_Reasons,QPP118_AElements.Allergy_To_Ace_Inhibitor_Or_Arb,
      QPP118_AElements.Intolerance_To_Ace_Inhibitor_Or_Arb,QPP118_AElements.Aortic_Or_Mitral_Valve_Diseases,
      QPP118_AElements.Medical_Reason,QPP118_AElements.Patient_Reason,QPP118_AElements.Renal_Failure_Due_To_Ace_Inhibitor,
      QPP118_AElements.Lack_Of_Drug_Availability,QPP118_AElements.Pregnancy)

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    // Filter IPP
    val ippRDD = getIpp(rdd,patientHistoryRDD, patientHistoryList)
    ippRDD.cache()

    val notEligible = sparkSession.sparkContext.emptyRDD[CassandraRow]
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter Met
    val metRDD = getMet(ippRDD, patientHistoryList)
    metRDD.cache()

    val intermediateB = ippRDD.subtract(metRDD)
    intermediateB.cache()

    // Filter Exceptions

    val exceptionRDD = getExceptionRDD(intermediateB, patientHistoryList)

    // Filter Not Met
    val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, notEligible, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
  }

  def getIpp(rdd: RDD[CassandraRow],patientHistoryRDD:RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP)
    val elements= Seq(QPP118_AElements.Office_Visit,QPP118_AElements.Nursing_Facility_Visit,QPP118_AElements.Care_Services_In_Long_Term_Residential_Facility,QPP118_AElements.Home_Healthcare_Services)
    //val mostRecentElements=countElement(rdd,m,2,elements)
  //  mostRecentElements.foreach(println)
    rdd.filter(visit =>
      (
        isAgeAbove(visit, m, true, 18)
          && isVisitTypeIn(visit, m, QPP118_AElements.Office_Visit, QPP118_AElements.Nursing_Facility_Visit, QPP118_AElements.Care_Services_In_Long_Term_Residential_Facility, QPP118_AElements.Home_Healthcare_Services)
        //  && mostRecentElements.contains(visit.getString("patientuid"))
          &&
          (
            (isDiagnosedDuringEncounter(visit, m, QPP118_AElements.Coronary_Artery_Disease)
              &&
              isDiagnosedDuringEncounter(visit,m,QPP118_AElements.Diabetes)
              &&
              ( wasDiagnosticStudyPerformedInHistory(visit, m, QPP118_AElements.Left_Ventricular_Ejection_Fraction, patientHistoryList)
                || wasDiagnosticStudyPerformedInHistory(visit, m, QPP118_AElements.Left_Ventricular_Ejection_Fraction__Lvef_, patientHistoryList)
                || (
                (wasProcedurePerformedInHistory(visit, m, QPP118_AElements.Twod_Echocardiography, QPP118_AElements.Twod_Echocardiography, patientHistoryList)
                  && wasDiagnosticStudyPerformedInHistory(visit, m, QPP118_AElements.Left_Ventricular_Ejection_Fraction__Lvef_, patientHistoryList))
                  ||
                  (wasProcedurePerformedInHistory(visit, m, QPP118_AElements.Twod_Echocardiography, QPP118_AElements.Twod_Echocardiography, patientHistoryList)
                    && wasDiagnosticStudyPerformedInHistory(visit, m, QPP118_AElements.Left_Ventricular_Ejection_Fraction, patientHistoryList))
                  || isAssessmentPerformedLessThanX(visit,m,40,QPP118_AElements.Lvef_Assessment,patientHistoryList)
                )))
              ||
              (isDiagnosedDuringEncounter(visit, m, QPP118_AElements.Coronary_Artery_Disease)
                && isDiagnosedDuringEncounter(visit,m,QPP118_AElements.Diabetes))
            )
          && ! isTelehealthEncounterNotPerformed(visit, m, QPP118_AElements.Home_Healthcare_Services_Telehealth_Modifier, QPP118_AElements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier, QPP118_AElements.Nursing_Facility_Visit_Telehealth_Modifier, QPP118_AElements.Office_Visit_Telehealth_Modifier)
          && isPOSEncounterNotPerformed (visit, m, QPP118_AElements.Pos_02)
        )
    )
  }

  def getMet(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP)

    ippRDD.filter(visit =>
      isMedicationOrderedDuringEncounter(visit,m,QPP118_AElements.Ace_Inhibitor_Or_Arb_Therapy)
        ||
        isMedicationOrderedDuringEncounter(visit,m,QPP118_AElements.Ace_Inhibitor_Or_Arb_1)
        ||
        wasMedicationActiveInHistory(visit,m,QPP118_AElements.Ace_Inhibitor_Or_Arb_1,patientHistoryList)
          &&
          !isMedicationOrdered (visit,m,QPP118_AElements.Ace_Or_Arb_Therapy_Reason_Not_Specified,patientHistoryList)

    )
  }

  def getExceptionRDD(intermediateB: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION)
    intermediateB.filter(visit =>
      (
        isMedicationOrdered(visit,m,QPP118_AElements.Ace_Or_Arb_Documented_Reasons,patientHistoryList)
          ||
          (
            (wasMedicationAllergyInHistory(visit,m,QPP118_AElements.Allergy_To_Ace_Inhibitor_Or_Arb,patientHistoryList)
              ||
              wasMedicationIntoleraneInHistory(visit,m,QPP118_AElements.Intolerance_To_Ace_Inhibitor_Or_Arb,patientHistoryList)
              ||
              wasDiagnosedInHistory(visit,m,QPP118_AElements.Aortic_Or_Mitral_Valve_Diseases,patientHistoryList)
              ||
              wasMedicationOrderedNotDoneInHistory(visit,m,QPP118_AElements.Medical_Reason,patientHistoryList)
              ||
              wasMedicationOrderedNotDoneInHistory(visit,m,QPP118_AElements.Patient_Reason,patientHistoryList)
              ||
              wasDiagnosedInHistory(visit,m,QPP118_AElements.Renal_Failure_Due_To_Ace_Inhibitor,patientHistoryList))
              ||
              isMedicationOrdered(visit,m,QPP118_AElements.Lack_Of_Drug_Availability,patientHistoryList)
            )
          ||
          isDiagnosedDuringEncounter(visit,m,QPP118_AElements.Pregnancy)
        )
    )
  }
}
