package com.figmd.janus.util.measure
import com.figmd.janus.WebDataMartCreator.{measure_list, postgresUtility, prop}


class SetPropertyArgs(args: Array[String]) {

/*
  val credentials = new BasicAWSCredentials("AKIAJC2BI34Q3U2RAHKA","TAgxUwck8azCQFSufpC+UW6d/c7Puh7HB2GShRY2")
  val s3Client = AmazonS3ClientBuilder.standard()
    .withCredentials(new AWSStaticCredentialsProvider(credentials))
    .build()

  val s3Object = s3Client.getObject(new GetObjectRequest(args(0),args(1)))
  val myData = Source.fromInputStream(s3Object.getObjectContent).getLines.filter(l => !l.startsWith("#")).toArray

  for(property<- myData){
    val sp = property.split("=")
    val key = sp(0)
    val value = sp(1)
    prop.setProperty(key,value)
    //println(key+" ++>>>> "+ApplicationConfig.prop.getProperty(key))
  }
*/


/*
  prop.setProperty("wf_id", args(0))
  prop.setProperty("postgresHostName", args(1))
  prop.setProperty("postgresHostPort", args(2))
  prop.setProperty("postgresConfigDatabaseName", args(3))
  prop.setProperty("postgresHostUserName", args(4))
  prop.setProperty("postgresUserPass", args(5))
  prop.setProperty("equal_measure_list", args(6))
  prop.setProperty("num_executors", args(7))
  prop.setProperty("executor_cores", args(8))
  prop.setProperty("executor_memory", args(9))
  prop.setProperty("keyspace_datamart", args(10))
  prop.setProperty("keyspace_datamart_table_name", args(11))
  prop.setProperty("keyspace_webdatamart", args(12))
  prop.setProperty("cassandra_host", args(13))
  prop.setProperty("cassandra_port", args(14))
  prop.setProperty("spark_master_url", args(15))
  prop.setProperty("measure_computation_output_path", args(16))
  prop.setProperty("mode", args(17))
  prop.setProperty("postgresManagementDatabaseName", args(18))
  prop.setProperty("wfType", args(19))
  prop.setProperty("DateRange", args(20))
  prop.setProperty("cms_measure_list", args(21))
  prop.setProperty("qpp_measure_list", args(22))
  prop.setProperty("nonqpp_measure_list", args(23))
  prop.setProperty("practice_id_list", args(24))
  prop.setProperty("median_measure_list", args(25))
  prop.setProperty("patientHistory", args(26))
*/


    prop.setProperty("wf_id", "wf_id_test")
    prop.setProperty("postgresHostName","10.20.201.103")
    prop.setProperty("postgresHostPort","5432")
    prop.setProperty("postgresConfigDatabaseName","config_db")
    prop.setProperty("postgresManagementDatabaseName","aaomgt")
    prop.setProperty("postgresHostUserName","postgres")
    prop.setProperty("postgresUserPass","Janus@123")
    prop.setProperty("num_executors","3")
    prop.setProperty("executor_cores","3")
    prop.setProperty("executor_memory","4G")
  prop.setProperty("keyspace_datamart", args(0))
//    prop.setProperty("keyspace_datamart","testcases")//acepnonqpp1718 acep2018 acep_aug_2018, acc_2018 aao_2018 abfm_2018
    prop.setProperty("keyspace_datamart_table_name",args(1))
  //prop.setProperty("keyspace_datamart_table_name", args(1))
  //tblencounter_nonqpp, tblencounter_qpp tblencounter_mat
    prop.setProperty("keyspace_webdatamart","test_data")

    prop.setProperty("patientHistory",args(2))//tblencounter_nonqpp
    prop.setProperty("cassandra_port","9042")
    prop.setProperty("measure_computation_output_path","hdfs://ip-10-20-201-103.us-gov-west-1.compute.internal:8020/tmp/cms")

    prop.setProperty("cassandra_host","10.20.201.152") //10.20.201.152
//
//  prop.setProperty("mode","cluster")
//    prop.setProperty("spark_master_url","yarn")

    prop.setProperty("spark_master_url","local[8]")
    prop.setProperty("mode","client")

    prop.setProperty("wfType","REGULAR")
    prop.setProperty("DateRange","[2018-01-01~2018-12-31]")
    prop.setProperty("equal_measure_list","NA")
    prop.setProperty("cms_measure_list","NA")//M127,M142v5,M138v5_1,M138v5_2,M138v5_3,M131v6,M68v6,M167v5
    prop.setProperty("qpp_measure_list","NA")
    prop.setProperty("nonqpp_measure_list",args(3))
    prop.setProperty("practice_id_list","NA")//31f659ea-994b-4570-9180-f302c7ce5fae,6fab4a70-6e66-4676-a507-3562c5b7cd39
    prop.setProperty("median_measure_list","NA")
    prop.setProperty("log_file","/tmp/CMS/logger")


  //#############################################################################################################################################

  prop.setProperty("keyspace_datamart_table_name_emergencydept_master", "emergencydept_master")
  prop.setProperty("table_name_measure_master", "janus_measure_master")

  commandLineArgumentValidation()

  //practice list for measure computation
  if (prop.getProperty("practice_id_list") != "NA" && prop.getProperty("practice_id_list") != "")
    prop.setProperty("practiceListCondition", "and practiceuid in(" + prop.getProperty("practice_id_list") + ")")
  else
    prop.setProperty("practiceListCondition", "")
  var equal_measure_list = ""
  var qpp_measure_list = ""
  var nonqpp_measure_list = ""
  var cms_measure_list = ""
  var median_measure_list = ""


  equal_measure_list = prop.getProperty("equal_measure_list")
  qpp_measure_list = prop.getProperty("qpp_measure_list")
  nonqpp_measure_list = prop.getProperty("nonqpp_measure_list")
  cms_measure_list = prop.getProperty("cms_measure_list")
  median_measure_list = prop.getProperty("median_measure_list")

  if (!equal_measure_list.equalsIgnoreCase("NA") && !equal_measure_list.equalsIgnoreCase("")) {
    if (measure_list.isEmpty) {
      measure_list = equal_measure_list
    } else {
      measure_list += "," + equal_measure_list
    }
  }
  if (!qpp_measure_list.equalsIgnoreCase("NA") && !qpp_measure_list.equalsIgnoreCase("")) {
    if (measure_list.isEmpty) {
      measure_list = qpp_measure_list
    } else {
      measure_list += "," + qpp_measure_list
    }
  }

  if (!nonqpp_measure_list.equalsIgnoreCase("NA") && !nonqpp_measure_list.equalsIgnoreCase("")) {
    if (measure_list.isEmpty) {
      measure_list = nonqpp_measure_list
    } else {
      measure_list += "," + nonqpp_measure_list
    }
  }
  if (!cms_measure_list.equalsIgnoreCase("NA") && !cms_measure_list.equalsIgnoreCase("")) {
    if (measure_list.isEmpty) {
      measure_list = cms_measure_list
    } else {
      measure_list += "," + cms_measure_list
    }
  }
  if (!median_measure_list.equalsIgnoreCase("NA") && !median_measure_list.equalsIgnoreCase("")) {
    if (measure_list.isEmpty) {
      measure_list = median_measure_list
    } else {
      measure_list += "," + median_measure_list
    }
  }

  println("Measure List:::" + measure_list)

  // command line arguments validation check
  def commandLineArgumentValidation(): Unit = {

    if (!prop.containsKey("wf_id")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0002", "CRITICAL", "Argument workflow id should not null.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("postgresHostName")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0003", "CRITICAL", "Postgres host ip should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("postgresHostPort")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0004", "CRITICAL", "Postgres host port should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("postgresConfigDatabaseName")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0005", "CRITICAL", "config database name should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("postgresHostUserName")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0006", "CRITICAL", "Postgres host user name should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("postgresUserPass")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0007", "CRITICAL", "Postgres host user password should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("keyspace_datamart")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0008", "CRITICAL", "cassandra datamart keyspace name should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("keyspace_datamart_table_name")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0009", "CRITICAL", "cassandra datamart table name should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("keyspace_webdatamart")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0010", "CRITICAL", "cassandra web datamart keyspace name should not empty.", "FAIL")
      System.exit(-1)
    }

    if (!prop.containsKey("cassandra_host")) {
      println("cassandra host ip should not empty.")
      postgresUtility.insertIntoProcessDetails(measure_list, "W0011", "CRITICAL", "cassandra host ip should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("cassandra_port")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0012", "CRITICAL", "cassandra host port should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("spark_master_url")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0013", "CRITICAL", "spark master should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("measure_computation_output_path")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0014", "CRITICAL", "measure computation output path should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("mode")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0015", "CRITICAL", "spark mode should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("postgresManagementDatabaseName")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0016", "CRITICAL", "management database name should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("wfType")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0017", "CRITICAL", "workflow type should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("DateRange")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0018", "CRITICAL", "measure computation date range should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("patientHistory")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0019", "CRITICAL", "patient history talble name should not empty.", "FAIL")
      System.exit(-1)
    }
    if ((!prop.containsKey("equal_measure_list")|| prop.getProperty("equal_measure_list").equalsIgnoreCase("NA")) &&
      (!prop.containsKey("cms_measure_list")|| prop.getProperty("cms_measure_list").equalsIgnoreCase("NA")) &&
      (!prop.containsKey("qpp_measure_list")|| prop.getProperty("qpp_measure_list").equalsIgnoreCase("NA")) &&
      (!prop.containsKey("nonqpp_measure_list")|| prop.getProperty("nonqpp_measure_list").equalsIgnoreCase("NA")) &&
      (!prop.containsKey("median_measure_list")|| prop.getProperty("median_measure_list").equalsIgnoreCase("NA"))) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0020", "CRITICAL", "All equal,qpp,non qpp,cms,median measure list should not empty.", "FAIL")
      System.exit(-1)
    }


  }


}
