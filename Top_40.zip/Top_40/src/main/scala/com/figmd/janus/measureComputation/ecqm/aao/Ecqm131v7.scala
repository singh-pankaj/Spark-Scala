package com.figmd.janus.measureComputation.ecqm.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Ecqm131v7 extends MeasureUtilityUpdate with MeasureUpdate  {

  val MEASURE_NAME = "Ecqm131v7"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    // Filter IPP

    val ippRDD = getIpp(rdd)
    ippRDD.cache()


    //getPatientHistoryList
    val patientHistoryRDD = getElementHistory(sparkSession,
      ElementMaster.Discharged_To_Home_For_Hospice_Care,
      ElementMaster.Discharged_To_Health_Care_Facility_For_Hospice_Care,
      ElementMaster.Hospice_Care_Ambulatory,
      ElementMaster.Pneumococcal_Vaccine,
      ElementMaster.Retinal_Or_Dilated_Eye_Exam,
      ElementMaster.Negative_Finding
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    //Filter Denominator Exclusion
    val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = getinterRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA, patientHistoryList)
    metRDD.cache()


    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exceptionRDD.cache()

    // Filter not met
    val notMetRDD = getinterRDD(intermediateA, metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, sparkSession.sparkContext.emptyRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }

  // IPP-Denominator criteria
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP)

    rdd.filter(visit =>

      isDiagnosedWithOnEncounter(visit,m,ElementMaster.Diabetes)
        &&
        isPatientAdult(visit,m)
        && isAgeBelow(visit,m,false,75)
        &&
        isVisitTypeIn(visit, m,
          ElementMaster.Office_Visit,
          ElementMaster.Home_Healthcare_Services,
          ElementMaster.Annual_Wellness_Visit,
          ElementMaster.Preventive_Care_Services_Initial_Office_Visit_18_and_Up,
          ElementMaster.Preventive_Care_Services_Established_Office_Visit_18_and_Up,
          ElementMaster.Face_To_Face_Interaction,
          ElementMaster.Ophthalmological_Services)
    )

  }


      // Denominator Exclusion criteria
      def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
      val m = MeasureProperty(MEASURE_NAME, EXCLUSION)
      ippRDD.filter(visit =>

        isEncounterPerformedInHistory(visit, m, ElementMaster.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        ||
        isEncounterPerformedInHistory(visit, m, ElementMaster.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        ||
        wasInterventionPerformedOrOrderedInHistory(visit, m, ElementMaster.Discharged_To_Home_For_Hospice_Care, patientHistoryList)

    )
  }

      // Numerator criteria
      def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
      val m = MeasureProperty(MEASURE_NAME, MET)
       intermediateA.filter(visit =>
        wasPhysicalExamPerformedForRetinalDilatedExam(visit, m,ElementMaster.Retinal_Or_Dilated_Eye_Exam, ElementMaster.Negative_Finding,12,patientHistoryList)
        )
   }

      }
