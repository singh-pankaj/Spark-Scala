package com.figmd.janus.measureComputation.qpp.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


object Qpp402 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp402"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {
    var getPatientHistoryList = getPatientHistory(sparkSession,rdd,ElementMaster.Advice_To_Quit_Smoking_Or_Tobacco_Use_Qpp402,ElementMaster.Assistance_With_Or_Referral_Cessation_Programs_Qpp402,ElementMaster.Cessation_Counselling_Qpp402,ElementMaster.Currently_Tobacco_Non_User_Qpp402,ElementMaster.Enrollment_In_Cessation_Programs_Qpp402,ElementMaster.Tobacco_Assessment_Reason_Not_Specified_Qpp402,ElementMaster.Tobacco_Non_User_Qpp402,ElementMaster.Tobacco_Use_Cessation_Counseling_Qpp402,ElementMaster.Tobacco_Use_Screening_Qpp402,ElementMaster.Tobacco_User_And_Tobacco_Cessation_Qpp402,ElementMaster.Tobacco_User_Qpp402)
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList.collect().toList)

    val ippRDD = getIpp(rdd)
    ippRDD.cache()

    val exclusionRDD =sparkSession.sparkContext.emptyRDD[CassandraRow];
    exclusionRDD.cache()

    val metRDD = getMet(ippRDD,patientHistoryList: Broadcast[List[CassandraRow]])
    metRDD.cache()

    val exceptionRDD =sparkSession.sparkContext.emptyRDD[CassandraRow];
    exceptionRDD.cache()


    val notMetRDD = getSubtractRDD(ippRDD,metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, sparkSession.sparkContext.emptyRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }


  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP)

    rdd.filter(visit =>  isAgeBetween(visit,m,12,21)
        &&
          isVisitTypeIn
                     (visit, m, ElementMaster.Annual_Wellness_Visit_Qpp402, ElementMaster.Health___Behavioral_Assessment___Individual_Qpp402,ElementMaster.Health_And_Behavioral_Assessment___Initial_Qpp402
                       , ElementMaster.Health_And_Behavioral_Assessment__Reassessment_Qpp402, ElementMaster.Occupational_Therapy_Evaluation_Qpp402, ElementMaster.Office_Visit_Qpp402
                       , ElementMaster.Ophthalmological_Services_Qpp402, ElementMaster.Psych_Visit___Diagnostic_Evaluation_Qpp402, ElementMaster.Psych_Visit___Psychotherapy_Qpp402
                       , ElementMaster.Psychoanalysis_Qpp402, ElementMaster.Psychotherapy_For_Crisis_Qpp402, ElementMaster.Smoking_And_Tobacco_Use_Cessation_Counseling_Visit_Qpp402
                     )

              )
  }


  def getMet(ippRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET)

    ippRDD.filter(visit =>
           ( isInterventionPerformedBeforeOrEqualInMonthInHistory(visit,m,ElementMaster.Tobacco_User_And_Tobacco_Cessation_Qpp402,18,patientHistoryList))
             || (isAssesmentPerformedBeforeOrEqualInMonthInHistory(visit,m,ElementMaster.Tobacco_Use_Screening_Qpp402,18,patientHistoryList)
               && isPatientTobaccoUser(visit,m,ElementMaster.Tobacco_User_Qpp402,patientHistoryList)
               &&
                ( isInterventionPerformedBeforeOrEqualInMonthInHistory(visit,m,ElementMaster.Advice_To_Quit_Smoking_Or_Tobacco_Use_Qpp402,18,patientHistoryList)
                || isInterventionPerformedBeforeOrEqualInMonthInHistory(visit,m,ElementMaster.Assistance_With_Or_Referral_Cessation_Programs_Qpp402,18,patientHistoryList)
                || isInterventionPerformedBeforeOrEqualInMonthInHistory(visit,m,ElementMaster.Cessation_Counselling_Qpp402,18,patientHistoryList)
                || isInterventionPerformedBeforeOrEqualInMonthInHistory(visit,m,ElementMaster.Enrollment_In_Cessation_Programs_Qpp402,18,patientHistoryList)
                || isInterventionPerformedBeforeOrEqualInMonthInHistory(visit,m,ElementMaster.Tobacco_Use_Cessation_Counseling_Qpp402,18,patientHistoryList)
               )
           )
        || ( isInterventionPerformedBeforeOrEqualInMonthInHistory(visit,m,ElementMaster.Currently_Tobacco_Non_User_Qpp402,18,patientHistoryList))
        || ( isAssesmentPerformedBeforeOrEqualInMonthInHistory(visit,m,ElementMaster.Tobacco_Use_Screening_Qpp402,18,patientHistoryList)
              && isPatientTobaccoUser(visit,m,ElementMaster.Tobacco_Non_User_Qpp402,patientHistoryList)))
  }


}
