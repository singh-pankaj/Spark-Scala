package com.figmd.janus.measureComputation.ecqm.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.util.measure.{MeasureUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Ecqm155v6B2 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Ecqm155v6B2"
  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd)
    ippRDD.cache()

    //NotEligible
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    //Backtracking
    var getPatientHistoryList = getPatientHistory(sparkSession,rdd,ElementMaster.Hospice_Care_Ambulatory,ElementMaster.Pregnancy,ElementMaster.Encounter_Inpatient,ElementMaster.Discharged_To_Home_For_Hospice_Care,ElementMaster.Discharged_To_Health_Care_Facility_For_Hospice_Care)
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList.collect().toList)


    //Filter Exclusion
    val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA,patientHistoryList)
    metRDD.cache()

    // Filter Exceptions
    val intermediate = getSubtractRDD(intermediateA, metRDD)

    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter NotMet
    val notMetRDD = getSubtractRDD(intermediate, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }

  // Filter IPP
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP)
    rdd.filter(visit =>  isAgeBetween(visit,m,11,17)
      && isVisitTypeIn(visit,m,ElementMaster.Face_To_Face_Interaction,ElementMaster.Office_Visit,ElementMaster.Preventive_Care_Services_Individual_Counseling,ElementMaster.Preventive_Care_Services__Initial_Office_Visit__0_To_17,ElementMaster.Preventive_Care__Established_Office_Visit__0_To_17,ElementMaster.Preventive_Care_Services_Group_Counseling,ElementMaster.Home_Health_Services)
    )

  }

  //Filter Exclusion
  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION)

    ippRDD.filter(visit => (

      encounterPerformed(visit,m,ElementMaster.Encounter_Inpatient,patientHistoryList)
        &&    (encounterPerformed(visit,m,ElementMaster.Discharged_To_Home_For_Hospice_Care,patientHistoryList)
        ||  encounterPerformed(visit,m,ElementMaster.Discharged_To_Health_Care_Facility_For_Hospice_Care,patientHistoryList))
      )
      || wasInterventionPerformedOrOrderedInHistory(visit,m,ElementMaster.Hospice_Care_Ambulatory,patientHistoryList)
      || isDiagnosedWithOnEncounter(visit,m,ElementMaster.Pregnancy)
    )

  }

  //Filter Met
  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET)

    intermediateA.filter(visit =>

      isInterventionPerformedOnEncounter(visit,m,ElementMaster.Counseling_For_Nutrition)

    )
  }



}