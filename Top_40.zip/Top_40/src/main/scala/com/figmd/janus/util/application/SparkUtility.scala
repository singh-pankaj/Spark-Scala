package com.figmd.janus.util.application

import java.util.UUID

import com.datastax.spark.connector._
import com.figmd.janus.WebDataMartCreator.prop
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ListBuffer

class SparkUtility extends Serializable {

  val fileUtility = new FileUtility();

  var appName = fileUtility.getProperty("spark.app.name");



  var num_executors=prop.getProperty("num_executors")
  var executor_cores=prop.getProperty("executor_cores")
  var executor_memory=prop.getProperty("executor_memory")
  var cassHostName = prop.getProperty("cassandra_host");
  var sparkMasterUrl = prop.getProperty("spark_master_url");
  var port = prop.getProperty("cassandra_port");
  var mode = prop.getProperty("mode");

  //Filter practiceid from rdd
  def filterPracticeIdFromInitialRDD(spark:SparkSession, RDD: RDD[CassandraRow]): RDD[CassandraRow]  ={

    //println("3:::::::" +practiceUIdList(0))
    if(!prop.getProperty("practice_id_list").equalsIgnoreCase("NA") && !prop.getProperty("practice_id_list").equalsIgnoreCase("")) {
      var practiceUIdList = prop.getProperty("practice_id_list").split(",")
      var list = new ListBuffer[UUID]()

      for (practiceUId <- practiceUIdList) {
        list += UUID.fromString(practiceUId.toString)
      }

      //println("1:::::::" + RDD.count())
      val rdd = RDD.filter(r => list.contains(r.getUUID("practiceuid")))
      //println("2:::::::" + rdd.count())
      return rdd
    }else{
      return RDD
    }
  }

  def getSparkContext(): SparkSession =
  {
    val spark = SparkSession.builder.master(sparkMasterUrl).appName(appName)
      .config("spark.cassandra.connection.host",cassHostName)
      .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .config("executor-memory",executor_memory)
      .config("spark.submit.deployMode", mode)
      .config("executor-cores", executor_cores)
      .config("num-executors",num_executors)
      .config("spark.rdd.compress", "true")
      //.config("spark.driver.memory", "0g")
      //.config("spark.closure.serializer","org.apache.spark.serializer.JavaSerializer")
      .config("spark.io.compression.codec", "snappy")
      .getOrCreate()
    return spark;
  }

/*  def getRDD(): Any =
  {
    var sprkSession=getSparkContext();
    var rdd = sprkSession.sparkContext.cassandraTable("webdatamart", "tblencounter_small")
    return rdd.getClass;
  }*/
}
