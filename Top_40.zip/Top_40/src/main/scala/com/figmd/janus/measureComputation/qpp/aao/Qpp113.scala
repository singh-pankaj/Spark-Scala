package com.figmd.janus.measureComputation.qpp.aao


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.{MeasureUpdate}
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP113Elements}

object Qpp113 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp113"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getElementHistory(sparkSession, QPP113Elements.Malignant_Neoplasm_Of_Colon, QPP113Elements.Total_Colectomy, QPP113Elements.History_Of_Colorectal_Cancer, QPP113Elements.Hospice_Services, QPP113Elements.Hospice_Services_Snomedct, QPP113Elements.Hospice_Care, QPP113Elements.Isnp_Or_Long_Term_Care, QPP113Elements.Institutional_Special_Needs_Plans, QPP113Elements.Long_Term_Care_Pos, QPP113Elements.Colonoscopy, QPP113Elements.Fecal_Occult_Blood_Test__Fobt_, QPP113Elements.Flexible_Sigmoidoscopy, QPP113Elements.Fit_Dna, QPP113Elements.Ct_Colonography, QPP113Elements.Colorectal_Cancer_Screening, QPP113Elements.Colorectal_Cancer_Screening_Reason_Not_Specified).collect.toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)
    println(getPatientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(rdd)
    ippRDD.cache()

    // Eligible IPP
    val eligibleRdd = sparkSession.sparkContext.emptyRDD[CassandraRow]
    eligibleRdd.cache()

    // Filter Exclusions
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    notEligibleRDD.cache()

    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList: Broadcast[List[CassandraRow]])
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA, patientHistoryList: Broadcast[List[CassandraRow]])
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getinterRDD(intermediateA, metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }


  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP)

    rdd.filter(visit =>

           isAgeBetween(visit,m,50,76)
        && isVisitTypeIn(visit, m, QPP113Elements.Office_Visit, QPP113Elements.Face_To_Face_Interaction, QPP113Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up_Cpt, QPP113Elements.Preventive_Care_Services___Established_Office_Visit_18_And_Up, QPP113Elements.Home_Healthcare_Services, QPP113Elements.Annual_Wellness_Visit, QPP113Elements.Initial_Preventive_Physical_Examination, QPP113Elements.Initial_Preventive_Medicine_Evaluation, QPP113Elements.Periodic_Preventive_Medicine_Evaluation)
    )
  }


  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION)

    ippRDD.filter(visit =>
           wasDiagnosedWithInHistory(visit, m, QPP113Elements.Malignant_Neoplasm_Of_Colon, patientHistoryList)
        || wasProcedurePerformedInHistory(visit, m, QPP113Elements.Total_Colectomy, patientHistoryList)
        || wasDiagnosedWithInHistory(visit, m, QPP113Elements.History_Of_Colorectal_Cancer, patientHistoryList)
        || isInterventionPerformed(visit, m, QPP113Elements.Hospice_Services, patientHistoryList)
        || wasInterventionPerformedInHistory(visit, m, QPP113Elements.Hospice_Services_Snomedct, patientHistoryList)
        || wasInterventionPerformedInHistory(visit, m, QPP113Elements.Hospice_Care, patientHistoryList)
        || isInterventionPerformed(visit, m, QPP113Elements.Isnp_Or_Long_Term_Care, patientHistoryList)
        || (   isAgeAbove(visit, m, true, 65)
            && wasInterventionPerformedInHistory(visit, m, QPP113Elements.Institutional_Special_Needs_Plans, patientHistoryList)
            )
        || (   isAgeAbove(visit, m, true, 65)
            && wasEncounterPerformedInHistory(visit, m, QPP113Elements.Long_Term_Care_Pos, patientHistoryList)
           )
    )
  }

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET)

    intermediateA.filter(visit =>
      (
             wasProcedurePerformedXYearsInHistory(visit, m, QPP113Elements.Colonoscopy, 10, patientHistoryList)
          || isLaboratoryTestPerformed(visit, m, QPP113Elements.Fecal_Occult_Blood_Test__Fobt_, patientHistoryList)
          || wasProcedurePerformedInXYears(visit, m, QPP113Elements.Flexible_Sigmoidoscopy, 5, patientHistoryList)
          || wasLaboratoryTestPerformedInXYears(visit, m, QPP113Elements.Fit_Dna, 3, patientHistoryList)
          || wasProcedurePerformedInXYears(visit, m, QPP113Elements.Ct_Colonography, 5, patientHistoryList)
          || isProcedurePerformed(visit, m, QPP113Elements.Colorectal_Cancer_Screening, patientHistoryList)
       )  && !isProcedurePerformed(visit, m, QPP113Elements.Colorectal_Cancer_Screening_Reason_Not_Specified, patientHistoryList)
    )
  }
}
