package com.figmd.janus.util.measure

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator
import com.figmd.janus.WebDataMartCreator.{global_measure_name, prop}
import com.figmd.janus.measureComputation.master.MeasureProperty
import com.figmd.janus.util.measure.messages._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.joda.time.DateTime





class HistoryLookUpUtility extends MeasureUtility {



  /**
    *
    * @param sparkSession
    * @param Element
    * @return patient history rdd
    */

  def getElementHistory(sparkSession: SparkSession, Element: String*): RDD[CassandraRow] = {
    var element: List[String] = Element.toList
    val historyRDD = sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"),
      prop.getProperty("patientHistory")).select("patientuid", "element", "element_date", "elementvalue")
      .filter(historyVisit => !historyVisit.isNullAt("patientuid") && !historyVisit.isNullAt("element") && !historyVisit.isNullAt("element_date") && element.contains((historyVisit.getString("element")).toLowerCase()))
    historyRDD
  }


  // get element date difference minus month , m:MeasureProperty
  def ElementInBackRange(r: CassandraRow, m: MeasureProperty, endDate: Date, ElementDate: String, NoOfMonths: Int): Boolean = {

    val end_Date = new DateTime(endDate)
    var isExist = false
    try {
      isExist = !r.isNullAt(ElementDate) && ((r.getDateTime(ElementDate).isBefore(end_Date) && r.getDateTime(ElementDate).isAfter(end_Date.minusMonths(NoOfMonths)))
        || r.getDateTime(ElementDate).equals(end_Date) || r.getDateTime(ElementDate).equals(end_Date.minusMonths(NoOfMonths)))

      val argsArray: Array[String] = Array(endDate.toString, end_Date.toString, NoOfMonths.toString)
      measureLogger(r, m, "ElementInBackRange", endDate.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementInBackRange:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  //getPatientHistory Elements
  def getPatientHistory(sparkSession: SparkSession, rdd: RDD[CassandraRow], Element: String*): RDD[CassandraRow] = {
    var element: List[String] = Element.toList

    var IPP_Patient_List = rdd.map(l => l.getString("patientuid")).collect().toList

    val historyRDD = sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"),
      prop.getProperty("patientHistory")).select("patientuid", "element", "element_date", "elementvalue")
      .filter(r => !r.isNullAt("element_date") && IPP_Patient_List.contains(r.getString("patientuid")) && element.contains(r.getString("element").toLowerCase()))

    return historyRDD
  }



  /**
    *
    * @param r                  Current visit of the patient
    * @param m                  m
    * @param elementDate        element date for
    * @param histroyElement     history element as input
    * @param patientHistoryList history element list
    * @return yes and no based on isDateStartsAfterOrConcurrentWithStartOfHistory
    */


  def isDateStartsAfterOrConcurrentWithStartOfHistory(r: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        for (x <- patientHistoryList.value) {
          if (!r.isNullAt(elementDate) && !x.isNullAt("element_date")

            && r.getString("patientuid").equals(x.getString("patientuid"))
            && histroyElement.equalsIgnoreCase(x.getString("element")) &&

            (x.getDateTime("element_date").isAfter(r.getDateTime(elementDate)) ||
              x.getDateTime("element_date").isEqual(r.getDateTime(elementDate))
              )
          )
            isExist = true
        }
        val argsArray: Array[String] = Array(histroyElement, r.getString(elementDate))
        measureLogger(r, m, "isDateStartsAfterOrConcurrentWithStartOfHistory", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isDateStartsAfterOrConcurrentWithStartOfHistory:" + e.printStackTrace(), "FAIL")
      }
    }

    return isExist
  }

  /**
    *
    * @param r                  Current visit of the patient
    * @param m                  m
    * @param elementDate        element date
    * @param histroyElement     get patient history element
    * @param patientHistoryList get patient history list
    * @return yes and no based on startAfterStartOfHistory
    */


  def startAfterStartOfHistory(r: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, patientHistoryList: List[CassandraRow]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.length > 0) {
        for (x <- patientHistoryList) {

          if (!r.isNullAt(elementDate) && !x.isNullAt("element_date")

            && r.getString("patientuid").equals(x.getString("patientuid"))

            && histroyElement.equalsIgnoreCase(x.getString("element")) &&

            x.getDateTime("element_date").isAfter(r.getDateTime(elementDate))

          )
            isExist = true
        }
        val argsArray: Array[String] = Array(histroyElement, r.getString(elementDate))
        measureLogger(r, m, "startAfterStartOfHistory", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:startAfterStartOfHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    return isExist
  }


  /**
    * this function check whether element was present before some months from current visit element date in history
    *
    * @param visit              current visit
    * @param m    measure property
    * @param elementDate        element date from  which history date will be compared
    * @param historyElement     element that eill be checed in history
    * @param month              no. of month before current visit element
    * @param patientHistoryList patient history element
    * @return true if element was present before some months from current visit element date in history
    */
  def startBeforeOrConcurrentStartOfMeasurementPeriodElementHistory(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {

        isExist= patientHistoryList.value.exists(x =>

          !x.isNullAt("element_date")

            && visit.getString("patientuid").equals(x.getString("patientuid"))

            && historyElement.equalsIgnoreCase(x.getString("element"))


            && (visit.getDateTime(elementDate).minusMonths(month).isBefore(x.getDateTime("element_date"))
            || visit.getDateTime(elementDate).minusMonths(month).isEqual(x.getDateTime("element_date")))

        )
      }

      val argsArray: Array[String] = Array(historyElement, visit.getString(elementDate))
      measureLogger(visit, m, "startBeforeOrConcurrentStartOfMeasurementPeriodElementHistory", historyElement, isExist, argsArray)
    }

    catch
      {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:startBeforeOrConcurrentStartOfMeasurementPeriodElementHistory:" + e.printStackTrace(), "FAIL")
        }
      }
    return isExist
  }

  /**
    * this function will check whether element was present after we go some year back from elementDate
    * @param visit visit
    * @param m measure Property
    * @param elementDate Element date from which year will be minus
    * @param historyElement history element that will be compare to current element
    * @param year no. of year go back from element date
    * @param patientHistoryList patient History List
    * @return true if element was present after we go some year back from elementDate
    */
  def startAfterAndConcurrentWithStartOfMeasurementPeriodYearHistory(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, year: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist= patientHistoryList.value.exists(x =>

          !x.isNullAt("element_date")
            && visit.getString("patientuid").equals(x.getString("patientuid"))

            && historyElement.equalsIgnoreCase(x.getString("element"))

            && (
            visit.getDateTime(elementDate).minusYears(year).isAfter(x.getDateTime("element_date"))
              || visit.getDateTime(elementDate).minusYears(year).isEqual(x.getDateTime("element_date"))
            )
        )
      }
      val argsArray: Array[String] = Array(historyElement, visit.getString(elementDate))
      measureLogger(visit, m, "startAfterAndConcurrentWithStartOfMeasurementPeriodYearHistory", historyElement, isExist, argsArray)
    }
    catch
      {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:startAfterAndConcurrentWithStartOfMeasurementPeriodYearHistory:" + e.printStackTrace(), "FAIL")
        }
      }
    isExist
  }

  /**
    *
    * @param Visit Current Cassandra Row from Tblencounter
    * @param m Measure Name and Measure Condition
    * @param Element CondtnsComplctngPrgnancy

    * @param historyList Patient History List
    * @return
    */
  def wasDiagnosedWith(Visit: CassandraRow, m: MeasureProperty, Element: String,  historyList: Broadcast[List[CassandraRow]]): Boolean = {

    var isExist = false
    if (historyList.value.length > 0) {
      try {
        isExist = historyList.value.exists(histvisit => (!histvisit.isNullAt("patientuid") && !histvisit.isNullAt("element")
          && Visit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid"))
          && histvisit.getString("element").equalsIgnoreCase(Element)))
        val argsArray: Array[String] = Array(Element)
        measureLogger(Visit, m, "wasDiagnosedWith", historyList.toString(), isExist, argsArray)
      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasDiagnosedWith:" + e.printStackTrace(), "FAIL")
        }
      }
    }
    isExist
  }



  /**
    * This Function checks Retinal Dilated
    * @param visit
    * @param m
    * @param ElementNameToCheckInHistory
    * @param elementhistoryResult
    * @param NoOfMonth
    * @param HistoryList
    * @return
    */
  def  wasPhysicalExamPerformedForRetinalDilatedExam(visit: CassandraRow, m:MeasureProperty, ElementNameToCheckInHistory: String, elementhistoryResult: String,NoOfMonth: Int, HistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {

      if (HistoryList.value.length > 0) {
        var isExist = false
        var dt: Date = globalEndDate
        val c = Calendar.getInstance
        c.setTime(dt)
        c.add(Calendar.MONTH, -NoOfMonth)
        val PreviousDate = c.getTime
        isExist = HistoryList.value.exists(histvisit =>
          !histvisit.isNullAt("element") && !histvisit.isNullAt("element_date")
            && histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
            &&
            (
              histvisit.getString("element").equalsIgnoreCase(ElementNameToCheckInHistory)
                ||
                histvisit.getString("element").equalsIgnoreCase(elementhistoryResult)
              )
            &&
            ((histvisit.getDate("element_date").after(PreviousDate) &&
              histvisit.getDate("element_date").before(dt)) || histvisit.getDate("element_date").equals(PreviousDate) ||
              histvisit.getDate("element_date").equals(dt)
              ))
      }
      val argsArray: Array[String] = Array(ElementNameToCheckInHistory)
      measureLogger(visit, m, "wasPhysicalExamPerformedForRetinalDilatedExam", elementhistoryResult.toString(), isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPhysicalExamPerformedForRetinalDilatedExam:" + e.printStackTrace(), "FAIL")
      }
    }

    isExist
  }


  /**
    *
    * @param visit cassendra row
    * @param m  property
    * @param elementDate get date fromuser
    * @param histroyElement get date fromuser
    * @param patientHistoryList get date fromuser
    * @return true or false based on  isAssessmentPerformedBefore
    */

  def isAssessmentPerformedBeforeOrEqual(visit: CassandraRow, m:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) && histroyElement.equalsIgnoreCase(x.getString("element")) &&
          histroyElement.equalsIgnoreCase(x.getString("element")) &&
          (x.getDateTime("element_date").isBefore(visit.getDateTime(elementDate)) ||
            x.getDateTime("element_date").isEqual(visit.getDateTime(elementDate))
            )
        )
      }
      val argsArray: Array[String] = Array(elementDate)
      measureLogger(visit, m, "isAssessmentPerformedBeforeOrEqual", histroyElement.toString(), isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentPerformedBeforeOrEqual:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  def isDiagnosticStudycBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r, MeasureProperty, elementDate, histroyElement, patientHistoryList )
  }


  /**
    *
    * @param visit cassendra row
    * @param m measure property
    * @param Value get value from user
    * @param histroyElement get history element
    * @param patientHistoryList get history List
    * @return true or false based on isAssessmentBeforeValue
    */

  def isAssessmentBeforeValue(visit: CassandraRow, m:MeasureProperty, Value:Int, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) && x.getString("element").equalsIgnoreCase(histroyElement) &&
          x.getInt("elementvalue") < Value
        )
      }
      val argsArray: Array[String] = Array(Value.toString)
      measureLogger(visit, m, "isAssessmentBeforeValue", histroyElement.toString(), isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentBeforeValue:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist

  }

  /**
    *
    * @param visit cassendra row
    * @param m measure property
    * @param elementName get history element
    * @param result
    * @param patientHistoryList get history List
    * @return
    */
  def isAssessmentAfterValue(visit:CassandraRow, m:MeasureProperty, elementName:String, result:Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        var startDate: Date = globalStartDate
        var endDate: Date = globalEndDate

        isExist = patientHistoryList.value.exists(x => !x.isNullAt("element_date") &&
          ((x.getDate("element_date").before(endDate) && x.getDate("element_date").after(startDate)) || x.getDate("element_date").equals(startDate) || x.getDate("element_date").equals(endDate)) &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) && x.getString("element").equalsIgnoreCase(elementName) &&
          x.getInt("elementvalue") > result
        )
      }

      val argsArray: Array[String] = Array(result.toString)
      measureLogger(visit, m, "isAssessmentAfterValue", patientHistoryList.toString(), isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentAfterValue:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    * G
    * @param visit cassendra row
    * @param m measure property
    * @param elementName get history element
    * @param patientHistoryList get history List
    * @return
    */
  def isDiagnosedWithInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        var startDate: Date = globalStartDate
        var endDate: Date = globalEndDate
        isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") && !x.isNullAt("patientuid") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) && x.getString("element").equalsIgnoreCase(elementName) &&
          ((x.getDate("element_date").after(startDate) && x.getDate("element_date").before(endDate))
            || x.getDate("element_date").equals(startDate) || x.getDate("element_date").equals(endDate))
        )
      }
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "isDiagnosedWithInHistory", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isDiagnosedWithInHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }


  /** PARENT function
    * G
    * @param visit cassendra row
    * @param m measure property
    * @param elementName get history element
    * @param patientHistoryList get history List
    * @return
    */
  def checkElementInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        var endDate: Date = globalEndDate
        isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") && !x.isNullAt("patientuid") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) && x.getString("element").equalsIgnoreCase(elementName)&&
          ((x.getDate("element_date").before(endDate)) || x.getDate("element_date").equals(endDate)
            )
        )
      }
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "checkElementInHistory", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementInHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }



  /** PARENT function
    * G
    * @param visit cassendra row
    * @param m measure property
    * @param elementName get history element
    * @param patientHistoryList get history List
    * @return
    */
  def checkElementDuringMeasurementPeriod(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        var startDate: Date = globalStartDate
        var endDate: Date = globalEndDate
        isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") && !x.isNullAt("patientuid") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) && x.getString("element").equalsIgnoreCase(elementName) &&
          ((x.getDate("element_date").after(startDate) && x.getDate("element_date").before(endDate)) || x.getDate("element_date").equals(startDate) || x.getDate("element_date").equals(endDate))
        )
      }
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "checkElementDuringMeasurementPeriod", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementDuringMeasurementPeriod:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }


  /**
    *
    * @param historyRDD Patient History RDD
    * @param ElementDate ElementDate whose First Date has to be calculate in History
    * @return List of Cassandra
    */

  def recentLaboratoryTestResultInHistory(historyRDD:RDD[CassandraRow], Element:String, ElementDate:String, value:Double):List[CassandraRow]={

    val minDateElements=historyRDD.filter(l=> !l.isNullAt("element")&& !l.isNullAt("element_date") && l.getString("element").equalsIgnoreCase(Element))
      .map(l => (l.getString("patientuid"), l.getDate("element_date"))).reduceByKey((x,y)=>if(x.after(y)) x else y).collect()
    historyRDD.filter(r=>minDateElements.contains((r.getString("patientuid"),r.getDate("element_date"))) && r.getDouble("elementvalue")<value).collect.toList
  }

  /**
    *
    * @param historyRDD Patient History RDD
    * @param ElementDate ElementDate whose First Date has to be calculate in History
    * @return List of Cassandra
    */

  def minDate(historyRDD:RDD[CassandraRow],Element:String,ElementDate:String):List[CassandraRow]={
    val minDateElements=historyRDD.filter(l=> !l.isNullAt("element")&& !l.isNullAt("element_date") && l.getString("element").equalsIgnoreCase(Element))
      .map(l => (l.getString("patientuid"), l.getDate("element_date"))).reduceByKey((x,y)=>if(x.before(y)) x else y).collect()
    historyRDD.filter(r=>minDateElements.contains((r.getString("patientuid"),r.getDate("element_date")))).collect.toList
  }

  /**
    *
    * @param visit current Cassandra row
    * @param m  measure Property
    * @param elementName element name whose date will be checked
    * @param patientHistoryList list of patient history
    * @return true if element is already present before encounter Date
    */
  def isElementPresentBeforeEncounterDate(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") && !x.isNullAt("patientuid") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString("element").equalsIgnoreCase(elementName)
          && x.getDate("element_date").before(visit.getDate("encounterdate"))
        )
      }
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "isElementPresentBeforeEncounterDate", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }


  /**
    *
    * @param r r is cassandra row to be used for condition check
    * @param ippEye ippEye is the base element
    * @param otherEyes otherEyes is the condition element to be checked with
    * @return returns true result based on cassandra row pass condition else returns false
    */

  def checkEyeElementsInRange(r:CassandraRow, ippEye:String, otherEyes:String*): Boolean ={
    val eyeCondCriterias1=Array(3,4)
    val eyeCondCriterias2=Array(1,2,3,4)
    def returnEyeValue(cr:CassandraRow,element:String):Any={
      if(cr.isNullAt(element)) null else cr.getString(element).toInt
    }
    val ippEye1 = returnEyeValue(r,ippEye)
    otherEyes.forall(eye=>{
      val conditionEye= returnEyeValue(r,eye)
      (conditionEye==ippEye1)|| (eyeCondCriterias1.contains(conditionEye) && eyeCondCriterias2.contains(ippEye1))|| (eyeCondCriterias2.contains(conditionEye) && eyeCondCriterias1.contains(ippEye1)) || conditionEye ==null || ippEye1 == null
    })
  }

  /**
    *
    * @param visit Cassendra Row
    * @param m measures
    * @param elementName get element from user
    * @param patientHistoryList get patient list
    * @return return true or false based on isDiagnosisWithBeforeEnd
    */
  def isDiagnosisWithBeforeEnd(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        var endDate: Date = globalEndDate
        isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") && !x.isNullAt("patientuid") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) && x.getString("element").equalsIgnoreCase(elementName) &&
          ((x.getDate("element_date").before(endDate)) || x.getDate("element_date").equals(endDate)
            )

        )
      }//else false
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "isDiagnosisWithBeforeEnd", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isDiagnosisWithBeforeEnd:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }


  /**
    *
    * @param currentVisit    CurrentVisit come From CassandraRow
    * @param m Measure condition and Measure Name
    * @param Element         Element(Dialysis Services)which has to be check in history.

    * @param historyList     List of All the Element that will require in the measure
    * @return Boolean
    */
  //"Procedure, Performed: Dialysis Services"
  def procedurePerformedStartsBeforeEndOfMeasurementPeriod(currentVisit: CassandraRow, m: MeasureProperty, Element: String, historyList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    if (historyList.value.length > 0) {
      try {
        var endDate: Date =globalEndDate
        isExist = historyList.value.exists(histvisit => (!histvisit.isNullAt("patientuid") && !histvisit.isNullAt("element")
          && currentVisit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid"))
          && (histvisit.getString("element").equalsIgnoreCase(Element) && histvisit.getDate("element_date").before(endDate))
          ))
        val argsArray: Array[String] = Array(Element, endDate.toString)
        measureLogger(currentVisit, m, "procedurePerformedStartsBeforeEndOfMeasurementPeriod", historyList.toString(), isExist, argsArray)
      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:procedurePerformedStartsBeforeEndOfMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        }
      }
    }
    isExist
  }

  def isDiagnosedWithEqualInMonths(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        val endDate: Date = globalEndDate
        val end_Date = new DateTime(endDate)
        isExist = patientHistoryList.value.exists(x =>


          !x.isNullAt("element_date")
            &&
            visit.getString("patientuid").equals(x.getString("patientuid"))

            && x.getString("element").equalsIgnoreCase(histroyElement)
            &&
            (
              x.getDateTime("element_date").isBefore(end_Date.minusMonths(month))
                ||
                x.getDateTime("element_date").isEqual(end_Date.minusMonths(month))
              )
        )
        val argsArray: Array[String] = Array(month.toString, endDate.toString)
        measureLogger(visit, m, "isDiagnosedWithEqualInMonths", histroyElement.toString(), isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
       // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isDiagnosedWithEqualInMonths:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  def isElementBeforeOrEqualInMonths(r: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist = patientHistoryList.value.exists(x =>

          !x.isNullAt("element_date")

            && r.getString("patientuid").equals(x.getString("patientuid"))

            && histroyElement.equalsIgnoreCase(x.getString("element"))

            && (r.getDateTime(elementDate).minusMonths(month).isBefore(x.getDateTime("element_date"))
            || r.getDateTime(elementDate).minusMonths(month).isEqual(x.getDateTime("element_date")))
        )
        val argsArray: Array[String] = Array(month.toString)
        measureLogger(r, m, "isElementBeforeOrEqualInMonths", histroyElement.toString(), isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementBeforeOrEqualInMonths:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  def isElementStartAfterStartOfElementInDays(r: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {

      if (patientHistoryList.value.length > 0) {
        isExist=patientHistoryList.value.exists(x =>

          !x.isNullAt("element_date")

            && r.getString("patientuid").equals(x.getString("patientuid"))
            && histroyElement.equalsIgnoreCase(x.getString("element"))
            &&
            (
              (x.getDateTime("element_date").isBefore(r.getDateTime(elementDate).plusDays(days))
                &&
                x.getDateTime("element_date").isAfter(r.getDateTime(elementDate)))
                ||
                x.getDateTime("element_date").isEqual(r.getDateTime(elementDate).plusDays(days))
                ||
                x.getDateTime("element_date").isEqual(r.getDateTime(elementDate))
              )
        )
        val argsArray: Array[String] = Array(days.toString)
        measureLogger(r, m, "isElementStartAfterStartOfElementInDays", histroyElement.toString(), isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementStartAfterStartOfElementInDays:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *
    * @param r CurrentVisit RDD coming from tblencounter
    * @param m Measure condition and Measure Name
    * @param elementDate Element which has to be check in current.
    * @param mostRecentElement Element which has to be check in mostrecent.
    * @param ValueStartRange Element Start value which has to be check in most recent .
    * @param ValueEndRange  Element end value which has to be check in most recent .
    * @param month  no of months minus from current
    * @param MostRecentList list of most recent elements
    * @return true if value found with in range in most recent list
    */


  def ElementMostRecentResultInBetweenBeforeOrEqualInMonth(r: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, ValueStartRange: Double , ValueEndRange: Double,month: Int, MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (MostRecentList.value.length > 0) {
        isExist=MostRecentList.value.exists(x =>
          !x.isNullAt("element_date")
            && r.getString("patientuid").equals(x.getString("patientuid"))
            && mostRecentElement.equalsIgnoreCase(x.getString("element"))
            && ((x.getDateTime("element_date").isBefore(r.getDateTime(elementDate)) &&  x.getDateTime("element_date").isAfter(r.getDateTime(elementDate).minusMonths(month)))
            || x.getDateTime("element_date").equals(r.getDateTime(elementDate)) || x.getDateTime("element_date").isAfter(r.getDateTime(elementDate).minusMonths(month)))
            && (x.getDouble("elementvalue") >= ValueStartRange && x.getDouble("elementvalue") < ValueEndRange)
        )
        val argsArray: Array[String] = Array(month.toString)
        measureLogger(r, m, "ElementMostRecentResultInBetweenBeforeOrEqualInMonth", mostRecentElement.toString(), isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultInBetweenBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }


  def ElementMostRecentResultInBetweenBeforeOrEqualInMonth(r: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, ValueGreaterOrEqual:Double , month: Int, MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (MostRecentList.value.length > 0) {
        isExist=MostRecentList.value.exists(x =>
          !x.isNullAt("element_date")

            && r.getString("patientuid").equals(x.getString("patientuid"))

            && mostRecentElement.equalsIgnoreCase(x.getString("element"))

            && (r.getDateTime(elementDate).minusMonths(month).isBefore(x.getDateTime("element_date"))
            || r.getDateTime(elementDate).minusMonths(month).isEqual(x.getDateTime("element_date")))

            && x.getDouble("elementvalue") >= ValueGreaterOrEqual
        )
        val argsArray: Array[String] = Array(month.toString)
        measureLogger(r, m, "ElementMostRecentResultInBetweenBeforeOrEqualInMonth", mostRecentElement.toString(), isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultInBetweenBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }


  def mostRecentDiastolicBPSystolicBPAdultOutpatientVisit(historyRDD: RDD[CassandraRow],Element: String, ElementDate: String): List[CassandraRow] = {
    val mostRecentElements = historyRDD.filter(l => !l.isNullAt("element") && !l.isNullAt("element_date") && l.getString("element").equalsIgnoreCase(Element))
      .map(l => (l.getString("patientuid"), l.getDate("element_date")))
      .reduceByKey((x, y) => if (x.after(y)) x else y).collect()
    historyRDD.filter(r => mostRecentElements.contains((r.getString("patientuid"), r.getDate("element_date")))).collect().toList
  }

  def DiastolicBPSystolicBPAdultOutpatientVisit(currentVisit: CassandraRow, measureProperty: MeasureProperty, Element1: String,Element2: String, Element1Date: String, Element2Date: String, Lower: Double, Upper: Double): Boolean = {
    var isExist = false
    try{
      isExist= (!currentVisit.isNullAt(Element1) && isDateEqual(currentVisit,measureProperty,Element1Date,"encounterdate") && currentVisit.getDouble(Element1)<Upper ) &&
        (  !currentVisit.isNullAt(Element2)  &&  isDateEqual(currentVisit,measureProperty,Element2Date,"encounterdate")  &&  currentVisit.getDouble(Element2)< Lower)
      val argsArray: Array[String] = Array(Element1,Upper.toString,Element2,Lower.toString)
      measureLogger(currentVisit, measureProperty, "DiastolicBPSystolicBPAdultOutpatientVisit",Element1,isExist,argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:DiastolicBPSystolicBPAdultOutpatientVisit:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }


  /*  def DiastolicBPSystolicBPAdultOutpatientVisit(currentVisit: CassandraRow, measureProperty: MeasureProperty,Element: String,Element1:String,Element2:String,Lower:Double,Upper:Double, SystolicDiasystolicBpList: Broadcast[List[CassandraRow]]): Boolean = {
      var isExist = false
      try {

        var cond=SystolicDiasystolicBpList.value.exists(histvisit => !histvisit.isNullAt("patientuid") && !histvisit.isNullAt("element") && !histvisit.isNullAt("element_date")
          && currentVisit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid")))


        var isExist1 = SystolicDiasystolicBpList.value.exists(histvisit =>
          (histvisit.getString("element").equalsIgnoreCase(Element1)&&histvisit.getDouble("elementvalue")<Upper)
        )
        var isExist2= SystolicDiasystolicBpList.value.exists(histvisit =>
          histvisit.getString("element").equalsIgnoreCase(Element2) && histvisit.getDouble("elementvalue")<Lower)

        isExist=cond && isExist1 && isExist2

        val argsArray: Array[String] = Array(Element1,Element2,Upper.toString,Lower.toString)
        // measureLoggerPatientHistory(currentVisit, measureProperty, "DiastolicBPSystolicBPAdultOutpatientVisit",Element , isExist, argsArray)

      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:DiastolicBPSystolicBPAdultOutpatientVisit:" + e.printStackTrace(), "FAIL")
        }
      }
      isExist
    }*/


  def isLatestDiagnosticStudy(currentVisit: CassandraRow, measureProperty: MeasureProperty,Element: String,Element1:String,Element2:String,Lower:Double,Upper:Double, SystolicDiasystolicBpList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {

      var cond=SystolicDiasystolicBpList.value.exists(histvisit => !histvisit.isNullAt("patientuid") && !histvisit.isNullAt("element") && !histvisit.isNullAt("element_date")
        && currentVisit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid")))

      var isExist1 = SystolicDiasystolicBpList.value.exists(histvisit =>
        (histvisit.getString("element").equalsIgnoreCase(Element1)&&(histvisit.getDouble("elementvalue")<=Upper))

      )
      var isExist2 = SystolicDiasystolicBpList.value.exists(histvisit =>
        (histvisit.getString("element").equalsIgnoreCase(Element2) && (histvisit.getDouble("elementvalue")<=Lower))
      )
      isExist=cond && isExist1 && isExist2

      val argsArray: Array[String] = Array(Element1,Element2,Upper.toString,Lower.toString)
      //measureLoggerPatientHistory(currentVisit, measureProperty, "isLatestDiagnosticStudy",Element , isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isLatestDiagnosticStudy:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }



  def patienthistList(historyRDD: RDD[CassandraRow]): List[CassandraRow] = {
    historyRDD.collect().toList
  }


  /**
    *
    * @param currentVisit    CurrentVisit RDD coming from tblencounter
    * @param measureProperty Measure condition and Measure Name
    * @param Element         Element which has to be check in history.
    * @param ElementDate     Element date which has to be before start Date plus six month.
    * @param historyList     List of History Element
    * @param NoOfMonths      No of Months to be added in the start Date
    * @return Boolean
    */
  def DiagnosisEssentialHypertensionFirstXMonthsOverlaps(currentVisit: CassandraRow, measureProperty: MeasureProperty, Element: String, ElementDate: String, historyList: Broadcast[List[CassandraRow]], NoOfMonths: Int = 6): Boolean = {
    var isExist = false
    if (historyList.value.length > 0) {
      var StartDate = globalStartDate

      var EndDate = globalEndDate
      var dt: Date = StartDate
      var c = Calendar.getInstance
      c.setTime(dt)
      c.add(Calendar.MONTH, +NoOfMonths)
      c.add(Calendar.DAY_OF_MONTH, -1)

      var ForwardDate = c.getTime

      try {
        isExist = historyList.value.exists(histvisit => !histvisit.isNullAt("patientuid") && !histvisit.isNullAt("element") && !histvisit.isNullAt("element_date")
          && currentVisit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid"))
          && histvisit.getString("element").equalsIgnoreCase(Element)
          && (histvisit.getDate("element_date").before(ForwardDate) || histvisit.getDate("element_date").equals(ForwardDate))
        )
        val argsArray: Array[String] = Array(Element, ElementDate, EndDate.toString)
        //measureLoggerPatientHistory(currentVisit, measureProperty, "procedurePerformedStartsBeforeEndOfMeasurementPeriod", EndDate.toString, isExist, argsArray)


      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:procedurePerformedStartsBeforeEndOfMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        }
      }
    }
    isExist

  }

  /**
  //    Status Done
    * @param currentVisit    CurrentVisit come From CassandraRow
    * @param measureProperty Measure condition and Measure Name
    * @param Element         Element(Dialysis Services)which has to be check in history.
    * @param ElementDate     Element(Dialysis Services Date)which has to be check in history.
    * @param historyList     List of All the Element that will require in the measure
    * @return Boolean
    */
  //"Procedure, Performed: Dialysis Services"
  def procedurePerformedStartsBeforeEndOfMeasurementPeriod(currentVisit: CassandraRow, measureProperty: MeasureProperty, Element: String, ElementDate: String, historyList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    if (historyList.value.length > 0) {
      var StartDate =globalStartDate

      var EndDate = globalEndDate

      try {
        isExist = historyList.value.exists(histvisit => (!histvisit.isNullAt("patientuid") && !histvisit.isNullAt("element")
          && currentVisit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid"))
          && (histvisit.getString("element").equalsIgnoreCase(Element) && histvisit.getDate("element_date").before(EndDate))
          ))
        val argsArray: Array[String] = Array(Element, ElementDate, EndDate.toString)
        measureLogger(currentVisit, measureProperty, "procedurePerformedStartsBeforeEndOfMeasurementPeriod", EndDate.toString, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:procedurePerformedStartsBeforeEndOfMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        }
      }
    }
    isExist
  }

  /**
    *
    * @param currentVisit    Current Cassandra Row from Tblencounter
    * @param measureProperty Measure Name and Measure Condition
    * @param Element         Element Which has to be look in the History
    * @param ElementDate     Element Date Which has to be look in the History
    * @param historyList     List of All the Element that will require in the measure
    * @return
    */

  def encounterPerformedStartBeforeEndOfMeasurementPeriod(currentVisit: CassandraRow, measureProperty: MeasureProperty, Element: String, ElementDate: String, historyList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    if (historyList.value.length > 0) {
      var StartDate = globalStartDate
      var EndDate = globalEndDate

      try {

        isExist = historyList.value.exists(histvisit => (!histvisit.isNullAt("patientuid") && !histvisit.isNullAt("element") && currentVisit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid"))
          && (histvisit.getString("element").equalsIgnoreCase(Element) && (histvisit.getDate("element_date").before(EndDate)))))
        val argsArray: Array[String] = Array(Element, ElementDate, EndDate.toString)
        measureLogger(currentVisit, measureProperty, "encounterPerformedStartBeforeEndOfMeasurementPeriod", EndDate.toString, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:encounterPerformedStartBeforeEndOfMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        }
      }
    }
    isExist
  }






  /*
  * @ param MappingElement RDD whose Element Date has to be mapped with most Recent Date.
  * @ historyElement RDD whose Element Date has to be calaulated the most Recent Date.
  * @return it will return RDD[CassandraRow]
  * */
  def mostRecentAssessmentPerformed(historyRDD:RDD[CassandraRow],patientUid:String,Element:String,MEASURE_NAME: String):List[CassandraRow]= {
    val mostRecentElements = historyRDD.filter(l => !l.isNullAt("element") && !l.isNullAt("element_date") && l.getString("element").equalsIgnoreCase(Element))
      .map(l => (l.getString("patientuid"), l.getDate("element_date")))
      .reduceByKey((x, y) => if (x.after(y)) x else y).collect()
    historyRDD.filter(r => mostRecentElements.contains((r.getString("patientuid"), r.getDate("element_date")))).collect().toList
  }
   
   //isElementBeforeOrEqualInMonthsBeforeEndOfMeasurementPeriod
  /** PARENT Function
    * check element date after substracting given months from the end date
    * @param r current cassendra row
    * @param m measure property
    * @param histroyElement checking history element after end date
    * @param month substract given month in end date
    * @param patientHistoryList check element in patient history list
    * @return if check element date after substracting given months from the end date
    */
  def wasElementAfterOrEqualEndDateInMonths(r: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        val endDate: Date = globalEndDate
        val end_date = new DateTime(endDate)
        isExist= patientHistoryList.value.exists(x =>
          !x.isNullAt("element_date")

            && r.getString("patientuid").equals(x.getString("patientuid"))

            && histroyElement.equalsIgnoreCase(x.getString("element"))

            && (end_date.minusMonths(month).isAfter(x.getDateTime("element_date"))
            || end_date.minusMonths(month).isEqual(x.getDateTime("element_date")))
        )
      }
      val argsArray: Array[String] = Array(month.toString)
      measureLogger(r, m, "encounterPerformedStartBeforeEndOfMeasurementPeriod", histroyElement.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:encounterPerformedStartBeforeEndOfMeasurementPeriod:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  def ElementMostRecentResultLessBeforeOrEqualInMonth(r: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, ValueLess:Double , month: Int, MostRecentList:List[CassandraRow]): Boolean = {
    var isExist = false
    try {
      if (MostRecentList.length > 0) {
        isExist=MostRecentList.exists(x =>

          !x.isNullAt("element_date")

            && r.getString("patientuid").equals(x.getString("patientuid"))

            && mostRecentElement.equalsIgnoreCase(x.getString("element"))

            && (r.getDateTime(elementDate).minusMonths(month).isBefore(x.getDateTime("element_date"))
            || r.getDateTime(elementDate).minusMonths(month).isEqual(x.getDateTime("element_date")))

            && x.getDouble("elementvalue") < ValueLess
        )
      }
      val argsArray: Array[String] = Array(month.toString,ValueLess.toString)
      measureLogger(r, m, "ElementMostRecentResultLessBeforeOrEqualInMonth", mostRecentElement.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *
    * @param visit
    * @param m
    * @param element
    * @param year
    * @param value
    * @param mostRecentElement
    * @return
    */
  def getRecentLaboratoryTestResultValueLess(visit: CassandraRow,m: MeasureProperty,element:String, year:Int, value:Double, mostRecentElement:List[CassandraRow]):Boolean={
    var isExist = false
    try {
      if (mostRecentElement.length > 0) {
        val StartDate = globalStartDate
        val start_date = new DateTime(StartDate)
        isExist=mostRecentElement.filter(x => x.getDateTime("element_date").isAfter(start_date.minusYears(year)) || x.getDateTime("element_date").isEqual(start_date.minusYears(year)))
          .exists(x => x.getString("patientuid").equals(visit.getString("patientuid"))
            && x.getString("element").equalsIgnoreCase(element)
            && x.getDouble("elementvalue") < value
          )
      }
      val argsArray: Array[String] = Array(year.toString,value.toString)
      measureLogger(visit, m, "getRecentLaboratoryTestResultValueLess", mostRecentElement.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:getRecentLaboratoryTestResultValueLess:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }



  /**
    *
    * @param r current cassandra row
    * @param m MeasureProperty
    * @param currentRowelement element of cureent row
    * @param element2  element whose date will be compared current row
    * @param days   within how many days element2 will be performed after currentRowelement
    * @param patientHistoryList patient history
    * @return whether element2 performed within <=days after currentRowelement performed
    */

  def startAfterStartOfWithinDaysLessorEqual(r: CassandraRow,m: MeasureProperty, currentRowelement: String, element2: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      isExist=patientHistoryList.value.exists(x =>
        !x.isNullAt("element_date")
          && r.getString("patientuid").equals(x.getString("patientuid"))
          && element2.toLowerCase.equals(x.getString("element").toLowerCase)
          && (r.getDateTime(currentRowelement).plusDays(days).isBefore(x.getDateTime("element_date"))
          || r.getDateTime(currentRowelement).plusDays(days).isEqual(x.getDateTime("element_date")))
      )
      val argsArray: Array[String] = Array(currentRowelement.toString, days.toString)
      measureLogger(r, m, "startAfterStartOfWithinDaysLessorEqual", element2.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:startAfterStartOfWithinDaysLessorEqual:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }



  /**
    *
    * @param r current cassandra row
    * @param m MeasureProperty
    * @param currentRowelement element of current row
    * @param element2 element whose date will be compared current row
    * @param patientHistoryList  patient history
    * @return whether element2 performed after element1
    */
  def startAfterStartOfEncounter(r: CassandraRow,m: MeasureProperty, currentRowelement: String, element2: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist = patientHistoryList.value.exists(x =>

          !r.isNullAt(currentRowelement) && !x.isNullAt("element_date")
            && r.getString("patientuid").equals(x.getString("patientuid"))
            && element2.equalsIgnoreCase(x.getString("element")) &&
            x.getDateTime("element_date").isAfter(r.getDateTime(currentRowelement))
        )
        val argsArray: Array[String] = Array(currentRowelement.toString)
        measureLogger(r, m, "startAfterStartOfWithinDaysLessorEqual", element2.toString, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:startAfterStartOfWithinDaysLessorEqual:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *
    * @param r current cassandra row
    * @param m measures
    * @param elementDate get element date
    * @return yes and no based on isDuringMeasurementPeriod
    */

  def isDuringMeasurementPeriod(r: CassandraRow ,m:MeasureProperty, elementDate: String): Boolean = {
    var isExist =false
    try {

      var sDate = convertDateToDDMMYYYY(globalStartDate.toString)
      var eDate = convertDateToDDMMYYYY(globalEndDate.toString)
      isExist = !r.isNullAt(elementDate) && ((r.getDate(elementDate).after(globalStartDate) && r.getDate(elementDate).before(globalEndDate)) || r.getDate(elementDate).equals(globalStartDate) || r.getDate(elementDate).equals(globalEndDate))
      val argsArray: Array[String] = Array(elementDate, sDate, eDate)
      measureLogger(r, m, "isDuringMeasurementPeriod", globalStartDate.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isDuringMeasurementPeriod:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }

  //Function for element present more than or equal to element present count
  def checkElementCountGreaterOrEqualElementPresentCountAndMeasurePeriod(r: CassandraRow,m:MeasureProperty, ElementPresentCount: Int, elements: String*): Boolean = {
    try {

      //      for (eCounter <- 0 to elements.length - 1) {
      //        if (checkElementPresent(r, m, elements(eCounter)) && isDuringMeasurementPeriod(r, m, elements(eCounter) + "_date")) {
      //          count = count + 1
      //        }
      //      }

      ElementPresentCount <= elements.foldLeft(0)((x,y)=>if(checkElementPresent(r, m, y) && isDuringMeasurementPeriod(r, m, y + "_date")) x+1 else x)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementCountGreaterOrEqualElementPresentCount:" + e.printStackTrace(), "FAIL")
        System.exit(-1)
        false
      }
    }
  }


  //Function for element present more than or equal to element present count
  def numberOfEncounterPerformedCountinHistory(r: CassandraRow,m:MeasureProperty,noOfMonth:Int, patientHistoryList: Broadcast[List[CassandraRow]], element: String): Int = {
    var isExist = 0
    val End_Date = new DateTime(globalEndDate)

    try {
      if (patientHistoryList.value.length > 0) {
        isExist=patientHistoryList.value.filter(x=> !x.isNullAt("element_date") &&
          x.getString("patientuid").equalsIgnoreCase(r.getString("patientuid")) &&
          x.getString("element").equalsIgnoreCase(element) &&
          ((x.getDateTime("element_date").isBefore(End_Date) && x.getDateTime("element_date").isAfter(End_Date.minusMonths(noOfMonth))) ||
            x.getDateTime("element_date").equals(End_Date) || x.getDateTime("element_date").equals(End_Date)
            )).size
        isExist
      }
      isExist
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementCountGreaterOrEqualElementPresentCount:" + e.printStackTrace(), "FAIL")
        System.exit(-1)

      }
        isExist
    }
  }



 /* // function for isDiagnosedWithEqualBeforeEnd

  /**
    *
    * @param r Cassendra Row
    * @param m measure property
    * @param histroyElement get history element
    * @param patientHistoryList get history element
    * @return yes and no based on isDiagnosedWithEqualBeforeEnd
    */

  def isDiagnosedWithBeforeOrEqualEnd(r: CassandraRow, m: MeasureProperty, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist =false
    try {

      val end_Date = new DateTime(globalEndDate)
      isExist = patientHistoryList.value.exists(x =>

        !x.isNullAt("element_date")

          && r.getString("patientuid").equals(x.getString("patientuid"))

          && histroyElement.equalsIgnoreCase(x.getString("element"))

          && (
          (x.getDateTime("element_date").isBefore(end_Date)) || x.getDate("element_date").equals(end_Date)

          )
      )
      val argsArray: Array[String] = Array(histroyElement)
      measureLogger(r, m, "isDiagnosedWithEqualBeforeEnd", globalStartDate.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isDiagnosedWithEqualBeforeEnd:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }*/



  //function for isRecentLaboratoryTestResultGreaterThanValue

  /**
    *
    * @param r cassendra row
    * @param m measure property
    * @param Value get limit value from user
    * @param histroyElement get history element
    * @param patientHistoryList get patient history list
    * @return yes and no based on isRecentLaboratoryTestResultGreaterThanValue
    */
  def isRecentLaboratoryTestResultGreaterThanValue(r: CassandraRow, m:MeasureProperty, Value:Int, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist =false
    try {
      isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") && !x.isNullAt("elementvalue")&&
        x.getString("patientuid").equalsIgnoreCase(r.getString("patientuid")) &&
        histroyElement.equalsIgnoreCase( x.getString("element")) &&
        (x.getDouble("elementvalue")> Value)
      )
      val argsArray: Array[String] = Array(histroyElement)
      measureLogger(r, m, "isRecentLaboratoryTestResultGreaterThanValue", globalStartDate.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isDiagnosedWithEqualBeforeEnd:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }

  /**
    *
    * @param r cassendra row
    * @param m measure property
    * @param histroyElement1 get 1st history element
    * @param histroyElement2 get 2nd history element
    * @param month  get number of month
    * @param patientHistoryList get patient history list
    * @return yes and no based on  isTobaccoUseScreeningNonUserWithin24Months
    */

  def isTobaccoUseScreeningNonUserWithin24Months(r: CassandraRow, m: MeasureProperty, histroyElement1: String,histroyElement2: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist =false
    try {
      val endDate: Date = globalEndDate
      val end_Date = new DateTime(endDate)
      isExist=patientHistoryList.value.exists(x =>

        !x.isNullAt("element_date")

          && r.getString("patientuid").equals(x.getString("patientuid"))
          && histroyElement1.equalsIgnoreCase(x.getString("element")).equals(histroyElement2.equalsIgnoreCase(x.getString("element")))
          && (
          (x.getDateTime("element_date").isBefore(end_Date) && x.getDateTime("element_date").isAfter(end_Date.minusMonths(month))) ||
            (x.getDateTime("element_date").equals(end_Date.minusMonths(month)) || x.getDateTime("element_date").isEqual(end_Date))
          )
      )
      val argsArray: Array[String] = Array(histroyElement1,histroyElement2,month.toString)
      measureLogger(r, m, "isTobaccoUseScreeningNonUserWithin24Months", globalStartDate.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isTobaccoUseScreeningNonUserWithin24Months:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }

  /**
    *
    * @param historyRDD Patient History RDD
    * @param ElementDate ElementDate whose First Date has to be calculate in History
    * @return List of Cassandra
    */

  def recentLaboratoryTestResultInHistory(historyRDD:RDD[CassandraRow], Element:String, ElementDate:String, minValue:Double=Integer.MIN_VALUE,maxValue:Double= Integer.MAX_VALUE):List[CassandraRow]={

    val minDateElements=historyRDD.filter(l=> !l.isNullAt("element")&& !l.isNullAt("element_date") && l.getString("element").equalsIgnoreCase(Element))
      .map(l => (l.getString("patientuid"), l.getDate("element_date"))).reduceByKey((x,y)=>if(x.after(y)) x else y).collect()
    historyRDD.filter(r=>minDateElements.contains((r.getString("patientuid"),r.getDate("element_date"))) && (r.getDouble("elementvalue")>=minValue && r.getDouble("elementvalue")<=maxValue)).collect.toList
  }

  /**
    * this function check whether element present between Emergency_Visit_Arrival_Date and visit Emergency_Visit_Departure_Date
    * @param m measure property
    * @param element procedure element
    * @param Emergency_Visit_Arrival_Date emergency visit arrival date
    * @param Emergency_Visit_Departure_Date emergency visit departure date
    * @return  true if element present between Emergency_Visit_Arrival_Date and Emergency_Visit_Departure_Date
    */
  def isElementPresentBetweenTwoDate(visit:CassandraRow, m:MeasureProperty,element:String,  Emergency_Visit_Arrival_Date :String,Emergency_Visit_Departure_Date:String):Boolean= {
    var isExist =false
    try {
      isExist = ( !visit.isNullAt(element)  && !visit.isNullAt( Emergency_Visit_Arrival_Date ) && !visit.isNullAt(Emergency_Visit_Departure_Date) &&

        ((visit.getDateTime(element+"_date").isBefore(visit.getDateTime(Emergency_Visit_Departure_Date))
          && visit.getDateTime(element+"_date").isAfter(visit.getDateTime( Emergency_Visit_Arrival_Date )))

          || visit.getDateTime(element+"_date").equals(visit.getDateTime(Emergency_Visit_Departure_Date))

          || visit.getDateTime(element+"_date").equals(visit.getDateTime(Emergency_Visit_Arrival_Date)))
        )
      val argsArray: Array[String] = Array(element,Emergency_Visit_Arrival_Date,Emergency_Visit_Departure_Date)
      measureLogger(visit, m, "isTobaccoUseScreeningNonUserWithin24Months", globalStartDate.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isTobaccoUseScreeningNonUserWithin24Months:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }


  /**
    * this function check whether element present between Emergency_Visit_Arrival_Date and visit Emergency_Visit_Departure_Date and check result value also
    * @param visit current visit
    * @param m measure property
    * @param element procedure element
    * @param Emergency_Visit_Arrival_Date emergency visit arrival date
    * @param Emergency_Visit_Departure_Date emergency visit departure date
    * @return  true ifelement present between Emergency_Visit_Arrival_Date and visit visit Emergency_Visit_Departure_Date and check result value also
    */

  def isElementPresentBetweenTwoDatesAndResultValueEqual(visit:CassandraRow, m:MeasureProperty, element:String, Emergency_Visit_Arrival_Date:String,Emergency_Visit_Departure_Date:String,resultValue:Double):Boolean= {
    var isExist =false
    try {

      isExist = ( !visit.isNullAt(element)  && !visit.isNullAt(Emergency_Visit_Arrival_Date) && !visit.isNullAt(Emergency_Visit_Departure_Date) &&

        ((visit.getDateTime(element+"_date").isBefore(visit.getDateTime(Emergency_Visit_Departure_Date))
          && visit.getDateTime(element+"_date").isAfter(visit.getDateTime(Emergency_Visit_Arrival_Date)))

          || visit.getDateTime(element+"_date").equals(visit.getDateTime(Emergency_Visit_Arrival_Date))

          || visit.getDateTime(element+"_date").equals(visit.getDateTime(Emergency_Visit_Departure_Date)))

        && visit.getDouble(element) == resultValue
        )
      val argsArray: Array[String] = Array(element,Emergency_Visit_Arrival_Date,Emergency_Visit_Departure_Date)
      measureLogger(visit, m, "isElementPresentBetweenTwoDatesAndResultValueEqual", globalStartDate.toString, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBetweenTwoDatesAndResultValueEqual:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }

  /**
    *
    * @param visit current visit
    * @param m measure property
    * @param elementDate counseling element
    * @param histroyElement1 most recent screening element
    * @param histroyElement2 tobacco user
    * @param month month in integer
    * @param patientHistoryMostRecentList patientHistoryMostRecentList
    * @param patientHistoryList patientHistoryList
    * @return
    */

  def wasCounselingNotPerformedAfterTobaccoScreeningUser(visit: CassandraRow, m: MeasureProperty, elementDate: String ,histroyElement1: String ,histroyElement2: String, month: Int, patientHistoryMostRecentList: List[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    val end_Date = new DateTime(globalEndDate)
    var isExist = false
    try {
      isExist = patientHistoryMostRecentList.exists(x =>

        visit.getString("patientuid").equals(x.getString("patientuid"))

          && visit.getDateTime(elementDate).isBefore(end_Date)

          && histroyElement1.equalsIgnoreCase(x.getString("element"))

          && (

          (x.getDateTime("element_date").isBefore(end_Date) && x.getDateTime("element_date").isAfter(end_Date.minusMonths(month)))

            || x.getDateTime("element_date").isEqual(end_Date.minusMonths(month)) || x.getDateTime("element_date").isEqual(end_Date))

          &&

          patientHistoryList.value.exists(y => !y.isNullAt("element_date") && y.getString("patientuid").equals(x.getString("patientuid"))

            && histroyElement2.equalsIgnoreCase(y.getString("element"))

            && y.getDateTime("element_date").isEqual(x.getDateTime("element_date"))

          )

          && (visit.getDateTime(elementDate).isAfter(x.getDateTime("element_date")) || visit.getDateTime(elementDate).isEqual(x.getDateTime("element_date")))


      )
      val argsArray: Array[String] = Array(month.toString,histroyElement1,histroyElement2)
      measureLogger(visit, m, "wasCounselingNotPerformedAfterTobaccoScreeningUser", elementDate, isExist, argsArray)


    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasCounselingNotPerformedAfterTobaccoScreeningUser:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }



  /*
    /**
      *  $TobaccoCessationIntervention starts after or concurrent with start of $TobaccoUseScreeningUser
      *
      * $TobaccoCessationIntervention =
      * Union of:
      * "Intervention, Performed: Tobacco Use Cessation Counseling"
      * "Medication, Order: Tobacco Use Cessation Pharmacotherapy"
      * "Medication, Active: Tobacco Use Cessation Pharmacotherapy"
      * * $TobaccoUseScreeningUser
      * * "Assessment, Performed: Tobacco Use Screening" satisfies all:
      * * Most Recent: <= 24 month(s) starts before end of "Measurement Period"
      * * (result: Tobacco User)
      *
      * @param visit current visit
      * @param m measure property
      * @param tobaccoUserElement tobaccoUserElement
      * @param tobaccoNonUserElement tobaccoNonUserElement
      * @param month minus number of month
      * @param toUsCeCo medicalReasonElement
      * @param toUsCePh
      * @param patientHistoryList most recent history list
      * @return
      */

    def wasTobaccoCessationInterventionDone(visit: CassandraRow, m: MeasureProperty, tobaccoUserElement: String, tobaccoNonUserElement: String, month: Int, toUsCeCo: String,toUsCePh:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
      var isExist =false
      try {
        val tobaccoUseScreeningUser1 = tobaccoUseScreeningUser(visit, m, tobaccoUserElement, tobaccoNonUserElement,  month, patientHistoryList)
        isExist=patientHistoryList.value.exists(x =>
          !x.isNullAt("element_date")
            && visit.getString("patientuid").equals(x.getString("patientuid"))
            && toUsCeCo.equalsIgnoreCase(x.getString("element"))
            && (x.getDateTime("element_date").equals(tobaccoUseScreeningUser1.map(y => y.getDateTime("element_date")).toList(0)) ||
            x.getDateTime("element_date").isAfter(tobaccoUseScreeningUser1.map(y => y.getDateTime("element_date")).toList(0))        )
        )||
          patientHistoryList.value.exists(x =>
            !x.isNullAt("element_date")
              && visit.getString("patientuid").equals(x.getString("patientuid"))
              && toUsCePh.equalsIgnoreCase(x.getString("element"))
              && (x.getDateTime("element_date").equals(tobaccoUseScreeningUser1.map(y => y.getDateTime("element_date")).toList(0)) ||
              x.getDateTime("element_date").isAfter(tobaccoUseScreeningUser1.map(y => y.getDateTime("element_date")).toList(0))        )
          )
        val argsArray: Array[String] = Array(tobaccoUserElement,tobaccoNonUserElement,tobaccoNonUserElement,month.toString)
        measureLogger(visit, m, "wasTobaccoCessationInterventionDone", toUsCeCo.toString, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasTobaccoCessationInterventionDone:" + e.printStackTrace(), "FAIL")
        }
      }
      isExist;
    }
  */


  /**
    * $TobaccoUseScreeningUser
    * "Assessment, Performed: Tobacco Use Screening" satisfies all:
    * Most Recent: <= 24 month(s) starts before end of "Measurement Period"
    * (result: Tobacco User)
    * @param visit current visit
    * @param m measure property
    * @param tobaccoUserElement tobaccoUserElement
    * @param tobaccoNonUserElement tobaccoNonUserElement
    * @param month minus number of month
    * @param patientHistoryList most recent history list
    * @return
    */

  def tobaccoUseScreeningUser(visit: CassandraRow, m: MeasureProperty, tobaccoUserElement: String,tobaccoNonUserElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): List[CassandraRow] ={
    val endDate: Date =globalEndDate
    val end_Date = new DateTime(endDate)
    var isExistListOfCassandraRow =patientHistoryList.value.filter(x =>
      !x.isNullAt("element_date")
        && visit.getString("patientuid").equals(x.getString("patientuid"))
        && (tobaccoUserElement.equalsIgnoreCase(x.getString("element"))
        || tobaccoNonUserElement.equalsIgnoreCase(x.getString("element")))
        && (x.getDateTime("element_date").isBefore(end_Date) && x.getDateTime("element_date").isAfter(end_Date.minusMonths(month))) ||
        x.getDateTime("element_date").equals(end_Date.minusMonths(month)) || x.getDateTime("element_date").isEqual(end_Date)
    )
    isExistListOfCassandraRow
  }

  /*def mostRecentElementList(historyRDD: RDD[CassandraRow], Element: String): List[CassandraRow] = {

    val mostRecentElements = historyRDD.filter(l => !l.isNullAt("element") && !l.isNullAt("element_date") && l.getString("element").equalsIgnoreCase(Element))
      .map(l => (l.getString("patientuid"), l.getDate("element_date")))
      .reduceByKey((x, y) => if (x.after(y)) x else y).collect()

    // mostRecentElements.foreach(r=>println(r))
    historyRDD.filter(r => mostRecentElements.contains((r.getString("patientuid"), r.getDate("element_date")))).collect().toList
  }*/

  /**
    * This function will return list of most recent data from patient history
    * @param historyRDD History RDD
    * @param Element    element of which most recent record we need
    * @return list of cassandra row will contains patient most recent element record
    */
  def mostRecentElementList(historyRDD: RDD[CassandraRow], Element: String*): List[CassandraRow] = {

    val mostRecentElements = historyRDD.filter(l => !l.isNullAt("element") && !l.isNullAt("element_date")

      && Element.contains(l.getString("element").toLowerCase))

      .map(l => ((l.getString("patientuid"), l.getString("element")), l.getDate("element_date")))

      .reduceByKey((x, y) => if (x.after(y)) x else y)

      .collect().toList

    val mostRecentList = historyRDD.filter(r => mostRecentElements.exists(x => x._1._1.equalsIgnoreCase(r.getString("patientuid")) && x._1._2.equalsIgnoreCase(r.getString("element"))

      && x._2.equals(r.getDate("element_date"))
    )).collect().toList

    mostRecentList

  }

  /**
    * this function will check whether element present before or equal end of measurement period
    * @param visit current visit
    * @param m measure property
    * @param elementName element name
    * @param patientHistoryList patient history
    * @return true if element present before or equal end of measurement period
    */
  def isElementPresentBeforeorEqualEncounterDate(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    var isExist =false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") && !x.isNullAt("patientuid") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString("element").equalsIgnoreCase(elementName)
          && (x.getDate("element_date").before(visit.getDate("encounterdate"))
          || x.getDate("element_date").equals(visit.getDate("encounterdate")))

        )
      }
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "wasTobaccoCessationInterventionDone", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasTobaccoCessationInterventionDone:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }


  /**
    * $tobaccoUseScreeningUserDuringMeasure
    * "Assessment, Performed: Tobacco Use Screening" satisfies all:
    * Most Recent: DuringMeasurement Period"
    * (result: Tobacco User OR Tobacco NonUser)
    * @param visit current visit
    * @param MeasureProperty measure property
    * @param tobaccoUserElement tobaccoUserElement
    * @param tobaccoNonUserElement tobaccoNonUserElement
    * @param patientMostRecentHistoryList most recent history list
    * @return
    */

  def istobaccoUseScreeningUser(visit: CassandraRow, MeasureProperty: MeasureProperty, tobaccoUserElement: String,tobaccoNonUserElement: String,  patientMostRecentHistoryList: Broadcast[List[CassandraRow]]): List[CassandraRow] ={
    val endDate: Date =globalEndDate
    val startdate:Date =globalStartDate

    val end_Date = new DateTime(endDate)
    val start_Date = new DateTime(endDate)
    val tobaccoUseScreeningUserOrNonUser =patientMostRecentHistoryList.value.filter(x =>
      !x.isNullAt("element_date")
        && visit.getString("patientuid").equals(x.getString("patientuid"))
        &&
        (
          tobaccoUserElement.equalsIgnoreCase(x.getString("element"))
            ||
            tobaccoNonUserElement.equalsIgnoreCase(x.getString("element"))
          )
        && ((x.getDateTime("element_date").isBefore(end_Date) && x.getDateTime("element_date").isAfter(start_Date)) ||
        x.getDateTime("element_date").equals(start_Date) || x.getDateTime("element_date").isEqual(end_Date))
    )
    tobaccoUseScreeningUserOrNonUser
  }

  //  /**
  //    *  $TobaccoCessationIntervention starts after or concurrent with start of $TobaccoUseScreeningUser
  //    * $TobaccoCessationIntervention =
  //    * Union of:
  //    * "Intervention, Performed: Tobacco Use Cessation Counseling"
  //    * "Medication, Order: Tobacco Use Cessation Pharmacotherapy"
  //    * "Medication, Active: Tobacco Use Cessation Pharmacotherapy"
  //    *  $TobaccoUseScreeningUser
  //    *  "Assessment, Performed: Tobacco Use Screening" satisfies all:
  //    *  Most Recent: During  "Measurement Period"
  //    * (result: Tobacco User)
  /**
    * @param visit current visit
    * @param MeasureProperty measure property
    * @param tobaccoUserElement tobaccoUserElement
    * @param tobaccoNonUserElement tobaccoNonUserElement
    * @param toUsCeCo Tobacco Use Cessation Counseling
    * @param toUsCePh Tobacco Use Cessation Pharmacotherapy
    * @param patientMostRecentHistoryList most recent history list
    * @return
    */

  def isTobaccoCessationInterventionDone(visit: CassandraRow, MeasureProperty: MeasureProperty, tobaccoUserElement: String, tobaccoNonUserElement: String, toUsCeCo: String,toUsCePh:String, patientMostRecentHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    val tobaccoUseScreeningUser1 = istobaccoUseScreeningUser(visit, MeasureProperty, tobaccoUserElement, tobaccoNonUserElement,  patientMostRecentHistoryList)

    patientMostRecentHistoryList.value.exists(x =>
      !x.isNullAt("element_date")
        && visit.getString("patientuid").equals(x.getString("patientuid"))
        && toUsCeCo.equalsIgnoreCase(x.getString("element"))
        && (x.getDateTime("element_date").equals(tobaccoUseScreeningUser1.map(y => y.getDateTime("element_date")).toList(0)) ||
        x.getDateTime("element_date").isAfter(tobaccoUseScreeningUser1.map(y => y.getDateTime("element_date")).toList(0))        )
    )    ||
      patientMostRecentHistoryList.value.exists(x =>
        !x.isNullAt("element_date")
          && visit.getString("patientuid").equals(x.getString("patientuid"))
          && toUsCePh.equalsIgnoreCase(x.getString("element"))
          &&
          (x.getDateTime("element_date").equals(tobaccoUseScreeningUser1.map(y => y.getDateTime("element_date")).toList(0)) ||
            x.getDateTime("element_date").isAfter(tobaccoUseScreeningUser1.map(y => y.getDateTime("element_date")).toList(0)) )

      )

  }

  /**
    *  $CounselingNotPerformed starts after or concurrent with start of $TobaccoUseScreeningUser
    *  $CounselingNotPerformed
    *  "Intervention, Performed not done: Medical Reason" for "Tobacco Use Cessation Counseling" starts before end of "Measurement Period"
    * * $TobaccoUseScreeningUser
    * * "Assessment, Performed: Tobacco Use Screening" satisfies all:
    * * Most Recent: During "Measurement Period"
    * * (result: Tobacco User)
    *
    * @param visit current visit
    * @param MeasureProperty measure property
    * @param tobaccoUserElement tobaccoUserElement
    * @param tobaccoNonUserElement tobaccoNonUserElement
    * @param medicalReasonElement medicalReasonElement
    * @param patientMostRecentHistoryList most recent history list
    * @return
    */

  def isCounselingNotPerformedAfterTobaccoScreeningUser(visit: CassandraRow, MeasureProperty: MeasureProperty, tobaccoUserElement: String, tobaccoNonUserElement: String, medicalReasonElement: String,  patientMostRecentHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    val tobaccoUseScreeningUser1 = istobaccoUseScreeningUser(visit, MeasureProperty, tobaccoUserElement, tobaccoNonUserElement,patientMostRecentHistoryList)

    patientMostRecentHistoryList.value.exists(x =>
      !x.isNullAt("element_date")
        && visit.getString("patientuid").equals(x.getString("patientuid"))
        && medicalReasonElement.equalsIgnoreCase(x.getString("element"))
        && (x.getDateTime("element_date").equals(tobaccoUseScreeningUser1.map(y => y.getDateTime("element_date")).toList(0)) ||
        x.getDateTime("element_date").isAfter(tobaccoUseScreeningUser1.map(y => y.getDateTime("element_date")).toList(0))
        )
    )
  }

  /**
    * This function check IOP - Moderate Stage.
    * @param currentvisit   currentvisit from tblencounter on which computation has to be done.
    * @param m              measureproperty
    * @param currentelement currentelement that has to be checked
    * @param currentelementDate currentelement_Date that has to be checked
    * @param compareDate Compare_Date that has to be compare currentelementDate
    * @param lowervalue lowervalue of Moderate Stage.
    * @param uppervalue uppervalue of Moderate Stage.
    * @return
    */
  def isIOPModerateStage(currentvisit: CassandraRow, m: MeasureProperty, currentelement: String, currentelementDate: String, compareDate: String, lowervalue: Double = 16, uppervalue: Double = 18): Boolean = {
    var isExist =false
    try {
      isExist = !checknull(currentvisit, m, currentelement)     &&
        isDateEqual(currentvisit, m, currentelementDate, compareDate)      &&
        (currentvisit.getDouble(currentelement) >= lowervalue && currentvisit.getDouble(currentelement) <= uppervalue)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isIOPModerateStage:" + e.printStackTrace(), "FAIL")
      }

    }
    isExist
  }

  /**
    * This function check IOP - Mild Stage.
    * @param currentvisit   currentvisit from tblencounter on which computation has to be done.
    * @param m              measureproperty
    * @param currentelement currentelement that has to be checked
    * @param currentelementDate currentelement_Date that has to be checked
    * @param compareDate Compare_Date that has to be compare currentelementDate
    * @param lowervalue lowervalue of Mild Stage.
    * @param uppervalue uppervalue of Mild Stage.
    * @return
    */
  def isIOPMildStage(currentvisit: CassandraRow, m: MeasureProperty, currentelement: String, currentelementDate: String, compareDate: String, lowervalue: Double = 19, uppervalue: Double = 22): Boolean = {
    var isExist =false
    try {
      isExist =
        (
          !checknull(currentvisit, m, currentelement)
            &&
            isDateEqual(currentvisit, m, currentelementDate, compareDate)
            &&
            (
              currentvisit.getInt(currentelement) >= lowervalue
                &&
                currentvisit.getInt(currentelement) <= uppervalue
              )
          )


    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isIOPMildStage:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }
  /**
    * This function check IOP - Severe Stage.
    * @param currentvisit   currentvisit from tblencounter on which computation has to be done.
    * @param m              measureproperty
    * @param currentelement currentelement that has to be checked
    * @param currentelementDate currentelement_Date that has to be checked
    * @param compareDate Compare_Date that has to be compare currentelementDate
    * @param lowervalue lowervalue of Severe Stage.
    * @return
    */

  def isIOPSevereStage(currentvisit: CassandraRow, m: MeasureProperty, currentelement: String, currentelementDate: String, compareDate: String, lowervalue: Double = 15): Boolean = {
    var isExist=false
    try {
      isExist =
        (
          !checknull(currentvisit, m, currentelement)
            &&
            isDateEqual(currentvisit, m, currentelementDate, compareDate)
            &&
            currentvisit.getDouble(currentelement) >= lowervalue

          )


    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isIOPSevereStage:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }
  /**
    * This function takes history element and check its date is equal or before currentElementDate minus 90 days.
    * @param currentvisit       currentvisit  from Cassandra tblencounter
    * @param m                  measure property
    * @param currentElementDate Current ElementDate from tblencounter
    * @param historyElement     History Element that has checked whether it is present or not.
    * @param noOfDays          mention no of days in function
    * @param ElementHistList   History element list from patient history table.
    * @return
    */
  def wasDignoasisProcedurePerformedXDaysInHistory(currentvisit: CassandraRow, m: MeasureProperty,  currentElementDate: String, historyElement: String,noOfDays: Int = 90, ElementHistList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist =false
    try {
      isExist = ElementHistList.value.exists(histvist => !histvist.isNullAt("patientuid") && !histvist.isNullAt("elementvalue")
        &&
        histvist.getString("patientuid").equalsIgnoreCase(currentvisit.getString("patientuid"))
        &&
        histvist.getString("element").equalsIgnoreCase(historyElement)
        &&
        (
          histvist.getDateTime("element_date").isEqual(currentvisit.getDateTime(currentElementDate).minusDays(noOfDays))
            ||
            histvist.getDateTime("element_date").isBefore(currentvisit.getDateTime(currentElementDate).minusDays(noOfDays))
          )

      )


    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:wasDignoasisProcedurePerformedXDaysInHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist

  }

  /**
    *  This function checks procedure performed 92 days from end date and checks history element date is in between end date and end date minus 92 days
    * @param currentvisit   currentvisit from tblencounter on which computation has to be done.
    * @param m              measureproperty
    * @param histElement    histElement
    * @param ElementHistList history Element list from Patient history List.
    * @param noOfDays    no of days that has to be go in history
    * @return
    */
  def isProcedurePerformed92DaysFromEndDate(currentvisit: CassandraRow, m: MeasureProperty, histElement: String, ElementHistList: Broadcast[List[CassandraRow]], noOfDays: Int = 92): Boolean = {
    val endDate: Date = globalEndDate
    val StartDate: Date = globalStartDate
    var isExist = false
    if (ElementHistList.value.length > 0) {
      try {
        endDate.setTime(endDate.getTime - (noOfDays * 86400000))

         isExist = ElementHistList.value.exists(histvisit => !histvisit.isNullAt("patientuid") && histvisit.getString("patientuid")
          .equalsIgnoreCase(currentvisit.getString("patientuid")) && histvisit.getString("element").equalsIgnoreCase(histElement)
          && histvisit.getDate("element_date").equals(StartDate) || histvisit.getDate("element_date").equals(endDate) ||
          (
            histvisit.getDate("element_date").after(StartDate) && histvisit.getDate("element_date").before(endDate)
            ))


      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isProcedurePerformed92DaysFromEndDate:" + e.printStackTrace(), "FAIL")
        }
      }
    }
    isExist
  }


  /**
    *   // This function checks history Element Date is before or equal to currentElementDate.
    * @param currentvisit   currentvisit from tblencounter on which computation has to be done.
    * @param m              measureproperty
    * @param Element       history Element
    * @param currentElement_Date CurrentElement_ date from tblencounter
    * @param ElementHistList   history Element list from Patient history List.
    * @return
    */
  def isDiagnosedInHistory(currentvisit: CassandraRow, m: MeasureProperty, Element: String, currentElement_Date: String, ElementHistList: Broadcast[List[CassandraRow]]): Boolean = {

    var isExist = false
    if (ElementHistList.value.length > 0) {
      try {

         isExist = ElementHistList.value.exists(histvisit => !histvisit.isNullAt("patientuid") && histvisit.getString("patientuid")
          .equalsIgnoreCase(currentvisit.getString("patientuid")) && !histvisit.isNullAt("element") && histvisit.getString("element").equalsIgnoreCase(Element) &&
          (histvisit.getDate("element_date").before(currentvisit.getDate(currentElement_Date)) || histvisit.getDate("element_date").equals(currentvisit.getDate(currentElement_Date)))
        )


      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDiagnosedInHistory:" + e.printStackTrace(), "FAIL")
        }
      }
    }
    isExist
  }


  /**
  //  This function checks Best corrected visual Acuity with in 90 days from the currentElement_Date.
    * @param currentvisit   currentvisit from tblencounter on which computation has to be done.
    * @param m              measureproperty
    * @param Element       history Element
    * @param currentElement_Date CurrentElement_ date from tblencounter
    * @param ElementHistList   history Element list from Patient history List.
    * @param noofDays             no of days before that has to be checked.
    */

  def isBestCorrectedVisualAcuityValuewithin90days(currentvisit: CassandraRow, m: MeasureProperty, Element: String, currentElement_Date: String, noofDays:Int=90, ElementHistList: Broadcast[List[CassandraRow]]): Boolean = {

    val elementValue: Array[String] = Array("20/10", "20/11", "20/12", "20/13", "20/14", "20/15", "20/16", "20/17", "20/18", "20/19", "20/2", "20/20", "20/21", "20/22", "20/23", "20/24", "20/25", "20/26", "20/28", "20/29", "20/3", "20/30", "20/31", "20/32", "20/33", "20/34", "20/35", "20/36", "20/37", "20/38", "20/39", "20/4", "20/5", "20/6", "20/7", "20/8", "20/9", "20/40")
    var isExist = false
    if (ElementHistList.value.length > 0) {
      try {

         isExist = ElementHistList.value.exists(histvist => !histvist.isNullAt("patientuid") && !histvist.isNullAt("elementvalue") &&
          histvist.getString("element").equalsIgnoreCase(Element) &&
          (!currentvisit.isNullAt(currentElement_Date)
            &&
            (
              currentvisit.getDateTime(currentElement_Date).minusDays(noofDays).equals(histvist.getDateTime("element_date"))
                ||
                currentvisit.getDateTime(currentElement_Date).minusDays(noofDays).isAfter(histvist.getDateTime("element_date"))
              )
            )
          &&
          elementValue.contains(histvist.getString("elementvalue"))
        )


      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isBestCorrectedVisualAcuityValuewithin90days:" + e.printStackTrace(), "FAIL")
        }
      }
    }
    isExist
  }

  //  Best Corrected Visual Acuity
  /**
  //  This function checks Best corrected visual Acuity with in 90 days from the currentElement_Date.
    * @param currentvisit   currentvisit from tblencounter on which computation has to be done.
    * @param m              measureproperty
    * @param historyElement       history Element
    * @param currentElementDate CurrentElement_ date from tblencounter
    * @param ElementHistList   history Element list from Patient history List.
    * @param noOfDays      No of Days.
    */
  def isPhysicalExamPerformedVisualAcuity(currentvisit: CassandraRow, m: MeasureProperty, historyElement: String, currentElementDate: String, ElementHistList: Broadcast[List[CassandraRow]], noOfDays: Int = 90): Boolean = {
    var isExist=false
    if (ElementHistList.value.length > 0) {
      try {
        isExist = ElementHistList.value.exists(histvist => !histvist.isNullAt("patientuid") && !histvist.isNullAt("elementvalue")
          &&
          histvist.getString("patientuid").equalsIgnoreCase(currentvisit.getString("patientuid"))
          &&
          histvist.getString("element").equalsIgnoreCase(historyElement)
          &&
          (
            histvist.getDateTime("element_date").equals(currentvisit.getDateTime(currentElementDate))
              ||
              histvist.getDateTime("element_date").plusDays(noOfDays).equals(currentvisit.getDateTime(currentElementDate)
              )
              ||
              (
                histvist.getDateTime("element_date").isBefore(currentvisit.getDateTime(currentElementDate))
                  &&
                  histvist.getDateTime("element_date").plusDays(noOfDays).isAfter(currentvisit.getDateTime(currentElementDate))
                )
            )
          &&
          !histvist.isNullAt("elementvalue")
        )
      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isBestCorrectedVisualAcuityValuewithin90days:" + e.printStackTrace(), "FAIL")
        }
      }
    }
    isExist
  }


  /**
  //Function returns whether procedure is performed with in 24 month from end Date
    * @param currentVisit Current Visit CassandraRow
    * @param measureProperty measure Property
    * @param Element history element
    * @param historyList History List
    * @param NoOfMonths No.Of months
    * @return
    */
  def wasprocedureperformedwithin24month(currentVisit: CassandraRow, measureProperty: MeasureProperty, Element: String, historyList: Broadcast[List[CassandraRow]], NoOfMonths: Int = 24): Boolean = {

    val End_Date = new DateTime(globalEndDate)
    var isExist = false
    try {
      if (historyList.value.length > 0) {
        isExist= historyList.value.exists(histvisit => !histvisit.isNullAt("patientuid") && !histvisit.isNullAt("element") && !histvisit.isNullAt("element_date")
          && currentVisit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid"))
          && histvisit.getString("element").equalsIgnoreCase(Element)
          &&
          (
            (histvisit.getDateTime("element_date").isBefore(End_Date) && histvisit.getDateTime("element_date").isAfter(End_Date.minusMonths(NoOfMonths)))
              ||
              histvisit.getDateTime("element_date").equals(End_Date) || histvisit.getDateTime("element_date").isEqual(End_Date.minusMonths(NoOfMonths))
            )
        )

      }
    }

    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:wasprocedureperformedwithin24month:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist

  }

  /**
    *
    * @param r  patient visit to be checked
    * @param m  measureProperty case class object contains conditionType as method type and measureName as measure name
    * @param ElementNameToCheckInHistory element name to check in history
    * @param NoOfYear minus number of year from start date
    * @param HistoryList element history data
    * @return boolean value
    */

  def wasLaboratoryTestPerformedInHistoryInYears(r: CassandraRow, m:MeasureProperty, ElementNameToCheckInHistory: String, NoOfYear: Int, HistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (HistoryList.value.length > 0) {
        val End_Date = new DateTime(globalEndDate)
        val ElementNameToCheckHistory_Date = ElementNameToCheckInHistory + "_date"
        isExist = (!r.isNullAt(ElementNameToCheckHistory_Date)
          && HistoryList.value.exists(x => isExist && x.getString("patientuid").equalsIgnoreCase(r.getString("patientuid"))
          && x.getString("element").equalsIgnoreCase(ElementNameToCheckInHistory) && x.getDateTime(ElementNameToCheckHistory_Date).isAfter(End_Date.minusYears(NoOfYear))))
      }
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:wasLaboratoryTestPerformedInHistoryInYears:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist

  }

  /**
    *  this function returns true if the element value less than from most recent list and element of most recent list will be within some years from enddate
    * @param visit current visit
    * @param m measure property
    * @param element element name which will be cheked in most reent list
    * @param year no. year which will minus from end date
    * @param value value from which lesser value expected in most recent list
    * @param mostRecentElement list of most recent element
    * @return true if value in most recent is lesser than given value and element date is within years of enddate
    */
  def isElementValuelessInMostRecentList(visit: CassandraRow, m: MeasureProperty, element: String, year: Int, value: Double, mostRecentElement: List[CassandraRow]): Boolean = {
    var isExist =false
    try {
      if (mostRecentElement.length > 0) {
        val endDate = globalEndDate
        val end_date = new DateTime(endDate)

        isExist=mostRecentElement.exists(x => x.getString("patientuid").equals(visit.getString("patientuid"))
          && x.getString("element").equalsIgnoreCase(element)
          && (x.getDateTime("element_date").isAfter(end_date.minusYears(year)) || x.getDateTime("element_date").isEqual(end_date.minusYears(year)))
          && x.getDouble("elementvalue") < value
        )
      }
      val argsArray: Array[String] = Array(element,year.toString)
      measureLogger(visit, m, "wasTobaccoCessationInterventionDone", value.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasTobaccoCessationInterventionDone:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }

  /**
    * this function check whether value is given within range in patient history for within no. years from enddate
    * @param visit current visit
    * @param m measure property
    * @param element element name which need to be checked in patient history
    * @param year no. of year back from enddate
    * @param lesserValue is the user given value from which elementvalue must be greater and equal
    * @param greaterValue is the user given value from which elementvalue must be lesser
    * @param patientHistory list of patient history
    * @return true if given value is within range for element date within years from enddate
    */
  def checkElementValuesInRangeInHistory(visit: CassandraRow, m: MeasureProperty, element: String, year: Int, lesserValue:Double, greaterValue:Double, patientHistory: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist =false
    try {
      if (patientHistory.value.length > 0) {
        val endDate = globalEndDate
        val end_date = new DateTime(endDate)

        isExist = patientHistory.value.exists(x => !x.isNullAt("patientuid") && !visit.isNullAt("patientuid")
          &&  x.getString("patientuid").equals(visit.getString("patientuid"))
          && x.getString("element").equalsIgnoreCase(element)
          && (x.getDateTime("element_date").isAfter(end_date.minusYears(year)) || x.getDateTime("element_date").isEqual(end_date.minusYears(year)))
          && x.getDouble("elementvalue") <= greaterValue
          && x.getDouble("elementvalue") > lesserValue
        )
      }
      val argsArray: Array[String] = Array(element,year.toString)
      measureLogger(visit, m, "checkElementValuesInRangeInHistory", greaterValue.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementValuesInRangeInHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    * this function check whether value is greater than or equal to given value in patient history before enddate
    * @param visit current visit
    * @param m measure property
    * @param element element name which need to be checked in patient history
    * @param value is the user given value from which elementvalue must be greater and equal
    * @param patientHistory list of patient history
    * @return true if given value is greater than or equal to given value for element date before enddate from patient history
    */
  def checkElementGreaterOrEqualInHistory(visit: CassandraRow, m: MeasureProperty, element: String, value:Double, patientHistory: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist =false
    try {
      if (patientHistory.value.length > 0) {
        val endDate = globalEndDate
        val end_date = new DateTime(endDate)

        isExist = patientHistory.value.exists(x => !x.isNullAt("patientuid") && !visit.isNullAt("patientuid")
          &&  x.getString("patientuid").equals(visit.getString("patientuid"))
          && x.getString("element").equalsIgnoreCase(element)
          && x.getDateTime("element_date").isBefore(end_date)
          && x.getDouble("elementvalue") >= value
        )
      }
      val argsArray: Array[String] = Array(element)
      measureLogger(visit, m, "checkElementValuesInRangeInHistory", value.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementValuesInRangeInHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }

  // This function in History Lookup utility.
  /**
    *
    * This function verifies that History element is present in the range between end of MeasurementPeriod and endDate minus noOfyear.
    * @param visit           Current Visit of the patient.
    * @param m               Measure Property of the measure.
    * @param historyElement  History Element that has to be look in the Patient History Table.
    * @param noOfYears       Number of Year that has to be subtracted from endOfmeasurement Period(endDate).
    * @param patientHistoryList Patient History List.
    * @return   It will return whether the procedure of a patient is performed in the range between end of MeasurementPeriod and endDate minus noOfyear.
    */
  def isProcedurePerformedXYearsInHistory(visit: CassandraRow, m: MeasureProperty, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var End_Date = new DateTime(globalEndDate)
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist = patientHistoryList.value.exists(histvisit => !histvisit.isNullAt("patientuid") && !histvisit.isNullAt("element") && !histvisit.isNullAt("element_date")
          &&
          visit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid"))
          &&
          histvisit.getString("element").equalsIgnoreCase(historyElement)
          &&
          (
            (histvisit.getDateTime("element_date").isBefore(End_Date) && histvisit.getDateTime("element_date").isAfter(End_Date.minusYears(noOfYears)))
              ||
              histvisit.getDateTime("element_date").equals(End_Date) || histvisit.getDateTime("element_date").equals(End_Date.minusYears(noOfYears))
            )
        )
        val argsArray: Array[String] = Array(historyElement,noOfYears.toString)
        measureLogger(visit, m, "isProcedurePerformedXYearsInHistory", historyElement, isExist, argsArray)

      }
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isProcedurePerformedXYearsInHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }


  /**
    * This Function verifies physical exam performed before end of Measurement period.
    * @param visit                  Current visit of the patient.
    * @param m                      Measure Property of the Measure.
    * @param resultElementInHistory Element whose result is to be verified in the period between start of measurement period  and start of measurement period before 12 months.
    * @param NoOfMonth              Number of Months.
    * @param HistoryList            Patient History List.
    * @return
    */
  def physicalExamResultInxMonthsHistory(visit: CassandraRow, m: MeasureProperty, resultElementInHistory: String, NoOfMonth: Int, HistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    val start_Date = new DateTime(globalStartDate)
    var isExist = false

    if (HistoryList.value.length > 0) {
      try {

        isExist = HistoryList.value.exists(histvisit =>
          !histvisit.isNullAt("element") && !histvisit.isNullAt("element_date")
            &&
            histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
            &&
            histvisit.getString("element").equalsIgnoreCase(resultElementInHistory)
            &&
            (
              (
                histvisit.getDateTime("element_date").isAfter(start_Date.minusMonths(NoOfMonth))
                  &&
                  histvisit.getDateTime("element_date").isBefore(start_Date)
                )

                || histvisit.getDateTime("element_date").equals(start_Date)
              )
        )
        val argsArray:Array[String]=Array(resultElementInHistory,start_Date.toString)
        measureLogger(visit, m, "physicalExamResultInxMonthsHistory", resultElementInHistory, isExist,argsArray)
      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:physicalExamResultInxMonthsHistory:" + e.printStackTrace(), "FAIL")
        }
      }
    }
    isExist

  }
  /**
    * This Function verifies physical exam performed before end of Measurement period.
    * @param visit                  Current visit of the patient.
    * @param m                      Measure Property of the Measure.
    * @param Elementinhistory       Element that has to be look in patient history table.
    * @param HistoryList            Patient History List.
    * @return
    */
  def physicalExamPerfomedInHistory(visit: CassandraRow, m: MeasureProperty, Elementinhistory: String, HistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    var sdate= globalStartDate
    var edate = globalEndDate
    //val StartDate = globalStartDate

    if (HistoryList.value.length > 0) {
      try {

        isExist = HistoryList.value.exists(histvisit =>
          !histvisit.isNullAt("element") && !histvisit.isNullAt("element_date")
            &&
            histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
            &&
            histvisit.getString("element").equalsIgnoreCase(Elementinhistory)
            &&
            (
              (
                histvisit.getDate("element_date").after(sdate)
                  &&
                  histvisit.getDate("element_date").before(edate)
                )
                ||
                histvisit.getDate("element_date").equals(sdate)
                ||
                histvisit.getDate("element_date").equals(edate)
              )
        )

        val argsArray:Array[String]=Array(Elementinhistory,sdate.toString,edate.toString)
        measureLogger(visit, m, "physicalExamPerfomedInHistory", Elementinhistory.toString, isExist,argsArray)
      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:physicalExamPerfomedInHistory:" + e.printStackTrace(), "FAIL")
        }
      }
    }
    isExist
  }

  /**
    *
    * @param r current cassandra row
    * @param m MeasureProperty
    * @param currentRowelement element of current row
    * @param element2 element whose date will be compared current row
    * @param patientHistoryList  patient history
    * @return whether element2 performed after element1
    */
  def isCommunicationFromProvidertoProviderNotDoneAfter(r: CassandraRow,m: MeasureProperty, currentRowelement: String, element2: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist =false
    try {
      //var flag = false
      if (patientHistoryList.value.length > 0) {

        isExist=  patientHistoryList.value.exists(  x =>

          !r.isNullAt(currentRowelement) && !x.isNullAt("element_date")

            && r.getString("patientuid").equals(x.getString("patientuid"))

            && element2.equalsIgnoreCase(x.getString("element")) &&

            x.getDateTime("element_date").isAfter(r.getDateTime(currentRowelement))||
            x.getDateTime("element_date").isEqual(r.getDateTime(currentRowelement))
        )
      }
      val argsArray: Array[String] = Array(currentRowelement)
      measureLogger(r, m, "isCommunicationFromProvidertoProviderNotDoneAfter", element2, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isCommunicationFromProvidertoProviderNotDoneAfter:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }

  /**
    * This function verifies that the patient has encountered emergency visit before 72 hours of current encounter
    * @param visit  current visit of the patient.
    * @param m      Measure property of the measure.
    * @param historyCritcalVisitElement  CriticalCare Element that has to looked in the history.
    * @param historyEmergencyVisitElement Emergency Department Visit element that has to be looked in the history.
    * @param noOfhours                    No of hours that has to be look before from current encounter.
    * @param patientHistoryElement        Patient History List
    * @return                             It will return those patient who has encounter an emergency visit before 72 hours from current encounter.
    */


  def wasVisitedWithinLast72Hours(visit:CassandraRow,m:MeasureProperty,historyCritcalVisitElement:String,historyEmergencyVisitElement:String,noOfhours:Int=72,patientHistoryElement:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist= false
    try{
      isExist = patientHistoryElement.value.exists(histvisit=> !histvisit.isNullAt("element") && !histvisit.isNullAt("element_date") &&
        visit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid"))
        &&
        (
          histvisit.getString("element").equalsIgnoreCase(historyCritcalVisitElement)
            ||
            histvisit.getString("element").equalsIgnoreCase(historyEmergencyVisitElement)
          )
        &&
        (
          visit.getDateTime("encounterdate").minusHours(noOfhours).equals(histvisit.getDateTime("element_date"))
            ||
            visit.getDateTime("encounterdate").minusHours(noOfhours).isBefore(histvisit.getDateTime("element_date"))
          )

      )
      val argsArray:Array[String]=Array(historyCritcalVisitElement,historyEmergencyVisitElement)
      //measureLogger(visit, m, "wasVisitedWithinLast72Hours", "EmergencyVisit", isExist,argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasVisitedWithinLast72Hours:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }
  /** This function verifies the assessment is performed of a patient before current encounter of the patient.
    * @param visit              Current visit of the patient.
    * @param m                  Measure Property of the Measure.
    * @param histroyElement     history element whose assessment has to be verified in the history.
    * @param patientHistoryList Patient history List.
    * @return                   It will return those patient whose assessment is performed before encounter date.
    */

  def isAssessmentPerformedinHistory(visit: CassandraRow, m: MeasureProperty, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist = patientHistoryList.value.exists( x=>
          !visit.isNullAt("encounterdate") && !x.isNullAt("element_date")
            && visit.getString("patientuid").equals(x.getString("patientuid"))
            && histroyElement.equalsIgnoreCase(x.getString("element")) &&
            (x.getDateTime("element_date").isBefore(visit.getDateTime("encounterdate")) ||
              x.getDateTime("element_date").isEqual(visit.getDateTime("encounterdate"))
              )
        )
      }
      val argsArray: Array[String] = Array(histroyElement, visit.getString("encounterdate"))
      measureLogger(visit, m, "isAssessmentPerformedinHistory", histroyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentPerformedinHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist

  }

  def mostRecentElementResultGreatAndBeforeOrEqualInMonth(r: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, ValueStartRange:Double ,month: Int,MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (MostRecentList.value.length > 0) {

        isExist = MostRecentList.value.exists(x =>

          !x.isNullAt("element_date")

            && r.getString("patientuid").equals(x.getString("patientuid"))

            && mostRecentElement.equalsIgnoreCase(x.getString("element"))

            && (r.getDateTime(elementDate).minusMonths(month).isBefore(x.getDateTime("element_date"))
            || r.getDateTime(elementDate).minusMonths(month).isEqual(x.getDateTime("element_date")))

            && (x.getDouble("elementvalue") >= ValueStartRange)
        )

      }
      val argsArray: Array[String] = Array(mostRecentElement, elementDate)
      measureLogger(r, m, "isAssessmentPerformedinHistory", mostRecentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentPerformedinHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    return isExist

  }





  //
  //function for isDateOverlapsMeasurementPeriod ( used in this function DiagnosisStudyConcurrentwith)
  def isDateOverlapsMeasurementPeriod(r: CassandraRow, m:MeasureProperty, checkDate: String): Boolean = {
    var isExist = false
    var endDate:Date= globalEndDate

    try {
      var eDate = convertDateToDDMMYYYY(endDate.toString)
      isExist = !r.isNullAt(checkDate) && (r.getDate(checkDate).before(endDate) || r.getDate(checkDate).equals(endDate))
      val argsArray: Array[String] = Array(checkDate, eDate)
      measureLogger(r, m, "isDateOverlapsMeasurementPeriod", checkDate.toString, isExist, argsArray)
      isExist
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDateOverlapsMeasurementPeriod:" + e.printStackTrace(), "FAIL")

      }
    }
    isExist
  }




  /**
    *
    * @param r most recent patient
    * @param m measures
    * @param elementDate get element date
    * @param mostRecentElement get most recent element
    * @param month get input as months
    * @param MostRecentList get most recent element
    * @return yes and no based on mostRecentElementBeforeOrEqualInMonth
    */



  def mostRecentElementBeforeOrEqualInMonth(r: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String,month: Int,  MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    if (MostRecentList.value.length > 0) {
      try {
        isExist = MostRecentList.value.exists(x =>
          !x.isNullAt("element_date")
            && r.getString("patientuid").equals(x.getString("patientuid"))
            && mostRecentElement.equalsIgnoreCase(x.getString("element"))
            && (r.getDateTime(elementDate).minusMonths(month).isBefore(x.getDateTime("element_date"))
            || r.getDateTime(elementDate).minusMonths(month).isEqual(x.getDateTime("element_date")))
        )
        val argsArray: Array[String] = Array(mostRecentElement, elementDate.toString)
        measureLogger(r, m, "mostRecentElementBeforeOrEqualInMonth", elementDate.toString, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:mostRecentElementBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        }

      }
    }
    isExist
  }
  /**
    * This function verifies the null in history.
    * @param visit visit of the patient.
    * @param checkElements Element that has to be cheked.
    * @return
    */
  def isNullInhistory(visit: CassandraRow, checkElements: String*): Boolean = {
    var isExist = false
    try {
      isExist= checkElements.forall(element=> !visit.isNullAt(element))

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isNullInhistory:" + e.printStackTrace(), "FAIL")

      }
    }
    isExist
  }

  /**
    *This function is new function wasDiagnosedWithInHistory .
    * @param visit Cassendra Row
    * @param m measures
    * @param elementName get element from user
    * @param patientHistoryList get patient list
    * @return return true or false based on isDiagnosisWithBeforeEnd
    */
  def wasDiagnosedWithInHistory(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false
    val endDate: Date = globalEndDate
    try {
      if (patientHistoryList.value.length > 0) {

        isExist = patientHistoryList.value.exists(x => !x.isNullAt("element_date") && !x.isNullAt("patientuid") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) && x.getString("element").equalsIgnoreCase(elementName) &&
          ((x.getDate("element_date").before(endDate)) || x.getDate("element_date").equals(endDate)
            )

        )
      }
      val argsArray: Array[String] = Array(elementName.toString)
      measureLogger(visit, m, "wasDiagnosedWithInHistory", patientHistoryList.toString(), isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasDiagnosedWithInHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }
  /**
    *
    * This function verifies that History element is present in the range between end of MeasurementPeriod and endDate minus noOfyear.
    * @param visit           Current Visit of the patient.
    * @param m               Measure Property of the measure.
    * @param historyElement  History Element that has to be look in the Patient History Table.
    * @param noOfYears       Number of Year that has to be subtracted from endOfmeasurement Period(endDate).
    * @param patientHistoryList Patient History List.
    * @return   It will return whether the procedure of a patient is performed in the range between end of MeasurementPeriod and endDate minus noOfyear.
    */
/*  def wasProcedurePerformedXYearsInHistory(visit: CassandraRow, m: MeasureProperty, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var endDate: Date = globalEndDate
    var cal = Calendar.getInstance
    cal.setTime(endDate)
    cal.add(Calendar.YEAR, -noOfYears)
    var PreviousDate = cal.getTime
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist = patientHistoryList.value.exists(histvisit => !histvisit.isNullAt("patientuid") && !histvisit.isNullAt("element") && !histvisit.isNullAt("element_date")
          &&
          visit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid"))
          &&
          histvisit.getString("element").equalsIgnoreCase(historyElement)
          &&
          (
            (histvisit.getDate("element_date").before(globalEndDate) && histvisit.getDate("element_date").after(PreviousDate))
              ||
              histvisit.getDate("element_date").equals(globalEndDate) || histvisit.getDate("element_date").equals(PreviousDate)
            )
        )

      }
      isExist
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isProcedurePerformedXYearsInHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }*/
def wasProcedurePerformedXYearsInHistory(visit: CassandraRow, m: MeasureProperty, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

  val End_Date = new DateTime(globalEndDate)
  var isExist = false

  try {
    if (patientHistoryList.value.length > 0) {
      isExist = patientHistoryList.value.exists(histvisit => !histvisit.isNullAt("patientuid") && !histvisit.isNullAt("element") && !histvisit.isNullAt("element_date")
        &&
        visit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid"))
        &&
        histvisit.getString("element").equalsIgnoreCase(historyElement)
        &&
        (
          (histvisit.getDateTime("element_date").isBefore(End_Date) && histvisit.getDateTime("element_date").isAfter(End_Date.minusYears(noOfYears)))
            ||
            histvisit.getDateTime("element_date").equals(End_Date) || histvisit.getDateTime("element_date").equals(End_Date)
          )
      )
      val argsArray: Array[String] = Array(historyElement,noOfYears.toString)
      measureLogger(visit, m, "wasProcedurePerformedXYearsInHistory", historyElement, isExist, argsArray)

    }

  }
  catch {
    case e: Exception => {
      postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:wasProcedurePerformedXYearsInHistory:" + e.printStackTrace(), "FAIL")
    }
  }
  isExist
}


  /** PARENT Function
    * this function will give list of patientuid and count of all the element passed in arugment from historyRDD within measurement Period
    * @param historyRdd   history RDD
    * @param element      elements of which we need count patient wise
    * @return List of patientuid and count of element passed in parameter
    */

  def countElement( historyRdd: RDD[CassandraRow], element: String*): List[(String, Int)] = {

    val countRdd = historyRdd.filter( r=>

      ((r.getDate("element_date").after(globalStartDate) && r.getDate("element_date").before(globalEndDate)) || r.getDate("element_date").equals(globalStartDate) || r.getDate("element_date").equals(globalStartDate))

        && element.toList.contains(r.getString("element").toLowerCase()))

      .map(z => (z.getString("patientuid"), 1)).reduceByKey(_ + _)

      .collect().toList

    countRdd
  }
//*************************************************************************************************************************************************************
//*************************************************************************************************************************************************************
//*************************************************************************************************************************************************************

  /**
    * 236,
    * @param Visit    CurrentVisit RDD coming from tblencounter
    * @param m Measure condition and Measure Name
    * @param Element         Element which has to be check in history.
    * @param historyList     List of History Element
    * @param NoOfMonths      No of Months to be added in the start Date
    * @return Boolean
    */
  def wasDiagnosedInFirstXMonths(Visit: CassandraRow, m: MeasureProperty, Element: String, historyList: Broadcast[List[CassandraRow]], NoOfMonths: Int = 6): Boolean = {
    var isExist = false
    if (historyList.value.length > 0) {
      var StartDate = globalStartDate
      var EndDate = globalEndDate

      val ForwardDate = new DateTime(StartDate)

       try {
        isExist = historyList.value.exists(histvisit => !histvisit.isNullAt("patientuid") && !histvisit.isNullAt("element") && !histvisit.isNullAt("element_date")
          && Visit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid"))
          && histvisit.getString("element").equalsIgnoreCase(Element)
          && (histvisit.getDateTime("element_date").isBefore(ForwardDate.plusMonths(NoOfMonths)) || histvisit.getDate("element_date").equals(ForwardDate.plusMonths(NoOfMonths)))
        )
        val argsArray: Array[String] = Array(Element,EndDate.toString)
        measureLogger(Visit, m, "wasDiagnosedInFirstXMonths",Element, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasDiagnosedInFirstXMonths:" + e.printStackTrace(), "FAIL")
        }
      }
    }
    isExist

  }

  //236
  def isDiastolicBPSystolicBPPerformedOnEncounter(currentVisit: CassandraRow, measureProperty: MeasureProperty, Element1: String,Element2: String, Element1Date: String, Element2Date: String, Lower: Double, Upper: Double): Boolean = {
    var isExist = false
    try{
      isExist= (!currentVisit.isNullAt(Element1) && isDateEqual(currentVisit,measureProperty,Element1Date,"encounterdate") && currentVisit.getDouble(Element1)<Upper ) &&
        (  !currentVisit.isNullAt(Element2)  &&  isDateEqual(currentVisit,measureProperty,Element2Date,"encounterdate")  &&  currentVisit.getDouble(Element2)< Lower)
      val argsArray: Array[String] = Array(Element1,Upper.toString,Element2,Lower.toString)
      measureLogger(currentVisit, measureProperty, "isDiastolicBPSystolicBPPerformedOnEncounter",Element1,isExist,argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isDiastolicBPSystolicBPPerformedOnEncounter:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }



  //acep24
  /**
    *
    * @param visit cassendra row
    * @param m  property
    * @param elementDate get date fromuser
    * @param histroyElement get date fromuser
    * @param patientHistoryList get date fromuser
    * @return true or false based on  isAssessmentPerformedBefore
    */

  def wasProcedurePerformedInHistory(visit: CassandraRow, m:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) &&
          histroyElement.equalsIgnoreCase(x.getString("element")) &&
          (x.getDateTime("element_date").isBefore(visit.getDateTime(elementDate)) ||
            x.getDateTime("element_date").isEqual(visit.getDateTime(elementDate))
            )
        )
      }
      val argsArray: Array[String] = Array(elementDate)
      measureLogger(visit, m, "isAssessmentPerformedBeforeOrEqual", histroyElement.toString(), isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentPerformedBeforeOrEqual:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /***********************************  sagar  ************/

  /**
    *
    * This function verifies that History element is present in the range between end of MeasurementPeriod and endDate minus noOfyear.
    * @param visit           Current Visit of the patient.
    * @param m               Measure Property of the measure.
    * @param historyElement  History Element that has to be look in the Patient History Table.
    * @param noOfYears       Number of Year that has to be subtracted from endOfmeasurement Period(endDate).
    * @param patientHistoryList Patient History List.
    * @return   It will return whether the procedure of a patient is performed in the range between end of MeasurementPeriod and endDate minus noOfyear.
    */
  def wasProcedurePerformedInXYears(visit: CassandraRow, m: MeasureProperty, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    val endDate = new DateTime(globalEndDate)
    var isExist = false

    try {
      if (patientHistoryList.value.length > 0) {
        isExist = patientHistoryList.value.exists(histvisit => !histvisit.isNullAt("patientuid") && !histvisit.isNullAt("element") && !histvisit.isNullAt("element_date")
          &&
          visit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid"))
          &&
          histvisit.getString("element").equalsIgnoreCase(historyElement)
          &&
          (
            (histvisit.getDateTime("element_date").isBefore(endDate) && histvisit.getDateTime("element_date").isAfter(endDate.minusYears(noOfYears)))
              ||
              histvisit.getDateTime("element_date").equals(endDate) || histvisit.getDateTime("element_date").equals(endDate.minusYears(noOfYears))
            )
        )
        val argsArray: Array[String] = Array(historyElement,noOfYears.toString)
        measureLogger(visit, m, "wasProcedurePerformedInXYears", historyElement, isExist, argsArray)

      }

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:wasProcedurePerformedInXYears:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }


  /**
    * This is renamed function and renamed from  isAssessmentBeforeValue
    * This function verifies the assessment is performed less than a value.
    * @param visit current visit of the patient.
    * @param m     measure property of the measure.
    * @param Value  value that is to be compared
    * @param histroyElement history element that has to be verified in the history.
    * @param patientHistoryList patient history list .
    * @return true or false based on isAssessmentPerformedLessThanX
    */

  def isAssessmentPerformedLessThanX(visit: CassandraRow, m:MeasureProperty, Value:Double, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) && x.getString("element").equalsIgnoreCase(histroyElement) &&
          x.getDouble("elementvalue") < Value
        )
      }
      val argsArray: Array[String] = Array(Value.toString)
      measureLogger(visit, m, "isAssessmentPerformedLessThanX", histroyElement.toString(), isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentPerformedLessThanX:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *
    * @param visit current Cassandra row
    * @param m  measure Property
    * @param elementName element name whose date will be checked
    * @param patientHistoryList list of patient history
    * @return true if element is already present before encounter Date
    */
  def wasEncounterPerformedBeforeEncounter(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") && !x.isNullAt("patientuid") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString("element").equalsIgnoreCase(elementName)
          && x.getDate("element_date").before(visit.getDate("encounterdate"))
        )
      }
      val argsArray: Array[String] = Array(elementName,visit.getString("encounterdate"))
      measureLogger(visit, m, "wasEncounterPerformedBeforeEncounter", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasEncounterPerformedBeforeEncounter:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  def isElementPresentBeforeOrEqual(visit: CassandraRow, m: MeasureProperty, element: String, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementDate:String = if(!element.equalsIgnoreCase("encounterdate")) element+"_date" else element
    try {
      if (patientHistoryList.value.length > 0) {

        isExist=  patientHistoryList.value.exists( x =>
          !visit.isNullAt(elementDate)
            &&   !x.isNullAt("element_date")
            && visit.getString("patientuid").equals(x.getString("patientuid"))

            && histroyElement.equalsIgnoreCase(x.getString("element")) &&

            (x.getDateTime("element_date").isBefore(visit.getDateTime(elementDate)) ||
              x.getDateTime("element_date").isEqual(visit.getDateTime(elementDate))
              )

        )


        val argsArray: Array[String] = Array(histroyElement, visit.getString(elementDate))
        measureLogger(visit, m, "isAssessmentPerformed", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        println(""+e.getMessage)
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentPerformed:" + e.printStackTrace(), "FAIL")
      }
    }

    return isExist

  }




  /**
    * This Function verifies the assessment of a patient is performed  greater than value.
    * @param visit current Visit of the patient.
    * @param m measure property of the measure(mesureId and condition)
    * @param elementName ElementName that has to be look in the history.
    * @param value       Value that has to be verified.
    * @param flag        flag that will define the condition whether to check greater or greaterEqualto condition.
    * @param patientHistoryList Patient history list.
    * @return
    */
  def isAssessmentPerformedGreaterThanX(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        var startDate: Date = globalStartDate
        var endDate: Date = globalEndDate

        def valueStatus(visit:CassandraRow,flag:String,value:Double):Boolean= {
          var elementValue=  visit.getDouble ("elementvalue")
          var status: Boolean = flag match {
            case "ge" => elementValue >= value
            case "gt" => elementValue > value
            case "lt" =>  elementValue < value
            case "le" =>  elementValue <= value
          }
          status
        }

        isExist = patientHistoryList.value.exists(x => !x.isNullAt("patientuid") && !x.isNullAt("element") && !x.isNullAt("element_date")
          &&
          !x.isNullAt("elementvalue")
          &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          &&
          x.getString("element").equalsIgnoreCase(elementName)
          &&
          (
            (x.getDate("element_date").before(endDate) && x.getDate("element_date").after(startDate))
              ||
              x.getDate("element_date").equals(startDate) || x.getDate("element_date").equals(endDate)
            )
          && valueStatus(x,flag,value))

      }

      val argsArray: Array[String] = Array(value.toString)
      measureLogger(visit, m, "isAssessmentPerformedGreaterThanX", elementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentPerformedGreaterThanX:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }


  /**
    * This Function verifies the Most Recent Laboratory test of a patient is performed greater,lesser,greaterEqualto and lesserEqualto than required value.
    *
    * @param visit              current Visit of the patient.
    * @param m                  measure property of the measure(measureId and condition)
    * @param elementName        Element Name that has to be look in the history.
    * @param value              Value that has to be verified.
    * @param flag               flag that will define the condition whether to check greater or greaterEqualto condition.
    * @param patientHistoryList Patient history list.
    * @return It will return those patient whose MostRecent Laboratory Test result value in a range between endDate and endDate before X years.
    */
  def isMostRecentLaboratoryTestResultInXYears(visit: CassandraRow, m: MeasureProperty, elementName: String, value: Double, flag: String, years: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        var endDate: Date = globalEndDate
        var end_Date: DateTime = new DateTime(endDate)

        def valueStatus(visit: CassandraRow, flag: String, value: Double): Boolean = {
          var elementValue = visit.getDouble("elementvalue")
          var status: Boolean = flag match {
            case "ge" => elementValue >= value
            case "gt" => elementValue > value
            case "lt" => elementValue < value
            case "le" => elementValue <= value
          }
          status
        }

        isExist = patientHistoryList.value.exists(x => !x.isNullAt("patientuid") && !x.isNullAt("element") && !x.isNullAt("element_date")
          &&
          !x.isNullAt("elementvalue")
          &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          &&
          x.getString("element").equalsIgnoreCase(elementName)
          &&
          (
            (x.getDateTime("element_date").isBefore(end_Date) && x.getDateTime("element_date").isAfter(end_Date.minusYears(years)))
              ||
              x.getDateTime("element_date").equals(end_Date.minusYears(years)) || x.getDateTime("element_date").equals(end_Date)
            )
          && valueStatus(x, flag, value))

      }

      val argsArray: Array[String] = Array(elementName, value.toString)
      measureLogger(visit, m, "isMostRecentLaboratoryTestResultInXYears", elementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isMostRecentLaboratoryTestResultInXYears:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    * This function verifies that History element is present in the range between start_date of MeasurementPeriod and Encounter_date
    * @param visit           Current Visit of the patient.
    * @param m               Measure Property of the measure.
    * @param histroyElement  History Element that has to be look in the Patient History Table.
    * @param patientHistoryList Patient History List.
    * @return   It will return whether the procedure of a patient is performed in the range between start_date of MeasurementPeriod and Encounter_date
    */
  def isInterventionOrderAfterStartDateBeforeEncounterDate(visit:CassandraRow, m:MeasureProperty,histroyElement:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={

    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist = patientHistoryList.value.exists(x => !x.isNullAt("element_date") && !x.isNullAt("patientuid") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString("element").equalsIgnoreCase(histroyElement)

          &&   ((x.getDate("element_date").before(visit.getDate("encounterdate")) && x.getDate("element_date").after(globalStartDate))
          || x.getDate("element_date").equals(visit.getDate("encounterdate")) || x.getDate("element_date").equals(globalStartDate))

        )
      }

      val argsArray:Array[String]=Array(histroyElement,visit.getString("encounterdate"))
      measureLogger(visit, m, "", histroyElement, isExist,argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception::" + e.printStackTrace(), "FAIL")
      }
    }

    isExist

  }
  /**
    * This Function verifies the assessment of a patient  is performed before encounterDate greater,lesser,greaterEqualto and lesserEqualto than required value.
    *
    * @param visit              current Visit of the patient.
    * @param m                  measure property of the measure(measureId and condition)
    * @param value              value that has to verified with the element value.
    * @param elementName        Element Name that has to be look in the history.
    * @param flag               flag that will define the condition whether to check greater or greaterEqualto condition.
    * @param patientHistoryList Patient history list.
    * @return It will return those patient whose MostRecent Laboratory Test result value in a range between endDate and endDate before X years.
    */
  def isAssessmentLessThanBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, value: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {

        def valueStatus(visit: CassandraRow, flag: String, value: Double): Boolean = {
          var elementValue = visit.getDouble("elementvalue")
          var status: Boolean = flag match {
            case "ge" => elementValue >= value
            case "gt" => elementValue > value
            case "lt" => elementValue < value
            case "le" => elementValue <= value
          }
          status
        }

        isExist = patientHistoryList.value.exists(x => !x.isNullAt("patientuid") && !x.isNullAt("element") && !x.isNullAt("element_date")
          &&
          !visit.isNullAt("encounterdate")
          &&
          !x.isNullAt("elementvalue")
          &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          &&
          x.getString("element").equalsIgnoreCase(elementName)
          &&
          x.getDateTime("element_date").isBefore(visit.getDateTime("encounterdate"))
          && valueStatus(x, flag, value))

      }

      val argsArray: Array[String] = Array(elementName, value.toString)
      measureLogger(visit, m, "isAssessmentLessThanBeforeEncounter", elementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentLessThanBeforeEncounter:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *
    * @param visit current Visit of the patient.
    * @param m    measure property of the measure(measureId and condition)
    * @param histroyElement1 histroyElement1 Name that has to be look in the history.
    * @param histroyElement2 histroyElement2 Name that has to be look in the history.
    * @param month Month minus from end date
    * @param patientHistoryMostRecentList most recent Patient history list.
    * @param patientHistoryList Patient history list.
    * @return It will return if Patient Tobacco NonUser Within 24Months
    */
  def wasPatientTobaccoNonUserWithin24Months(visit: CassandraRow, m: MeasureProperty, histroyElement1: String ,histroyElement2: String, month: Int, patientHistoryMostRecentList: List[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    var isExist = false
    val end_Date = new DateTime(globalEndDate)
    try {
      isExist=patientHistoryMostRecentList.exists(x =>
        visit.getString("patientuid").equals(x.getString("patientuid"))
          && histroyElement1.equalsIgnoreCase(x.getString("element"))
          && (
          (x.getDateTime("element_date").isBefore(end_Date) && x.getDateTime("element_date").isAfter(end_Date.minusMonths(month)))

            || x.getDateTime("element_date").isEqual(end_Date.minusMonths(month)) || x.getDateTime("element_date").isEqual(end_Date))
          &&
          patientHistoryList.value.exists(y => !y.isNullAt("element_date") && y.getString("patientuid").equals(x.getString("patientuid"))

            && histroyElement2.equalsIgnoreCase(y.getString("element"))

            && y.getDateTime("element_date").isEqual(x.getDateTime("element_date"))
          )
      )
      val argsArray: Array[String] = Array(histroyElement1, month.toString)
      measureLogger(visit, m, "wasPatientTobaccoNonUserWithin24Months", histroyElement2, isExist, argsArray)
    }
    catch
    {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPatientTobaccoNonUserWithin24Months:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *
    * @param visit current Visit of the patient.
    * @param m    measure property of the measure(measureId and condition)
    * @param histroyElement1 histroyElement1 Name that has to be look in the history.
    * @param histroyElement2 histroyElement2 Name that has to be look in the history.
    * @param month Month minus from end date
    * @param patientHistoryMostRecentList most recent Patient history list.
    * @param patientHistoryList Patient history list.
    * @return It will return if Patient Tobacco User Within 24Months
    */
  def wasPatientTobaccoUserWithin24Months(visit: CassandraRow, m: MeasureProperty, histroyElement1: String ,histroyElement2: String , month: Int, patientHistoryMostRecentList: List[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val end_Date = new DateTime(globalEndDate)
    try {
      isExist=patientHistoryMostRecentList.exists(x =>
      visit.getString("patientuid").equals(x.getString("patientuid"))
        && histroyElement1.equalsIgnoreCase(x.getString("element"))
        && (
        (x.getDateTime("element_date").isBefore(end_Date) && x.getDateTime("element_date").isAfter(end_Date.minusMonths(month)))

          ||  x.getDateTime("element_date").isEqual(end_Date.minusMonths(month)) || x.getDateTime("element_date").isEqual(end_Date))
        &&
        patientHistoryList.value.exists( y => !y.isNullAt("element_date") && y.getString("patientuid").equals(x.getString("patientuid"))

          && histroyElement2.equalsIgnoreCase(y.getString("element"))

          && y.getDateTime("element_date").isEqual(x.getDateTime("element_date"))
        )
    )
      val argsArray: Array[String] = Array(histroyElement1, month.toString)
      measureLogger(visit, m, "wasPatientTobaccoUserWithin24Months", histroyElement2, isExist, argsArray)
  }

    catch
    {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPatientTobaccoUserWithin24Months:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *
    * @param visit current Visit of the patient.
    * @param m    measure property of the measure(measureId and condition)
    * @param histroyElement1 histroyElement1 Name that has to be look in the history.
    * @param histroyElement2 histroyElement2 Name that has to be look in the history.
    * @param month Month minus from end date
    * @param patientHistoryMostRecentList most recent Patient history list.
    * @param patientHistoryList Patient history list.
    * @return It will return if Patient tobacco Cessation Intervention Done After Tobacco Screening User
    */

  def tobaccoCessationInterventionDoneAfterTobaccoScreeningUser(visit: CassandraRow, m: MeasureProperty, elementDate: String ,histroyElement1: String ,histroyElement2: String, month: Int, patientHistoryMostRecentList: List[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val end_Date = new DateTime(globalEndDate)
    try {
      isExist = patientHistoryMostRecentList.exists(x =>
        visit.getString("patientuid").equals(x.getString("patientuid"))

          && histroyElement1.equalsIgnoreCase(x.getString("element"))
          && (
          (x.getDateTime("element_date").isBefore(end_Date) && x.getDateTime("element_date").isAfter(end_Date.minusMonths(month)))

            || x.getDateTime("element_date").isEqual(end_Date.minusMonths(month)) || x.getDateTime("element_date").isEqual(end_Date))
          &&
          patientHistoryList.value.exists(y => !y.isNullAt("element_date") && y.getString("patientuid").equals(x.getString("patientuid"))
            && histroyElement2.equalsIgnoreCase(y.getString("element"))
            && y.getDateTime("element_date").isEqual(x.getDateTime("element_date"))
          )
          && (visit.getDateTime(elementDate).isAfter(x.getDateTime("element_date")) || visit.getDateTime(elementDate).isEqual(x.getDateTime("element_date")))
      )
      val argsArray: Array[String] = Array(histroyElement1, month.toString)
      measureLogger(visit, m, "TobaccoCessationInterventionDoneAfterTobaccoScreeningUser", histroyElement2, isExist, argsArray)
    }
    catch
    {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPatientTobaccoUserWithin24Months:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *
    * @param visit current Visit of the patient.
    * @param m measure property of the measure(measureId and condition)
    * @param elementName histroyElement Name that has to be look in the history.
    * @param patientHistoryList Patient history list.
    * @return It will return true if Influenza element was present Period Last Five Month In History
    */
  def wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit: CassandraRow, m:MeasureProperty, elementName: String,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {

    val year = Integer.parseInt(globalStartDate.toString.takeRight(4))-1
    val sdf = new SimpleDateFormat(dateFormat)
    val sDate: Date = sdf.parse(year + "-08-01")
    val eDate: Date = sdf.parse(year + "-12-31")
    var isExist = false

    try{
      if (patientHistoryList.value.length > 0) {
        isExist = patientHistoryList.value.exists(x => !x.isNullAt("element_date") && !x.isNullAt("patientuid")
          && x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString("element").equalsIgnoreCase(elementName)
          &&
          ((x.getDate("element_date").after(sDate) && x.getDate("element_date").before(eDate)) ||
            (x.getDate("element_date").equals(sDate) || x.getDate("element_date").equals(eDate)))
        )
      }

      val argsArray: Array[String] = Array(elementName, sDate.toString, eDate.toString)
      measureLogger(visit, m, "isDuringInfluenzaPeriodLastFiveMonthInHistory", sDate.toString, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDuringInfluenzaPeriodLastFiveMonthInHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *

    * This Function verifies the mostRecent Physical Exam performed  of a patient  is performed before another Element greater,lesser,greaterEqualto and lesserEqualto than required value.
    * @param visit              current Visit of the patient.
    * @param m                  measure property of the measure(measureId and condition)
    * @param value              value that has to verified with the element value.
    * @param historyElementName Element Name that has to be look in the history.
    * @param currentElement     Current element whose date has to be compared.
    * @param flag               flag that will define the condition whether to check greater or greaterEqualto condition.
    * @param patientHistoryList Patient history list.
    * @return It will return those patient whose Test result value before another ElementDate.
    */
  def isMostRecentPhysicalExamPerformedBefore(visit: CassandraRow, m: MeasureProperty, historyElementName: String, currentElement:String, value: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        val currentElementDate=currentElement+"_date"

        def valueStatus(visit: CassandraRow, flag: String, value: Double): Boolean = {
          var elementValue = visit.getDouble("elementvalue")
          var status: Boolean = flag match {
            case "ge" => elementValue >= value
            case "gt" => elementValue > value
            case "lt" => elementValue < value
            case "le" => elementValue <= value
          }
          status
        }


        isExist = patientHistoryList.value.exists(x => !x.isNullAt("patientuid") && !x.isNullAt("element") && !x.isNullAt("element_date")
          && !visit.isNullAt(currentElement) && !visit.isNullAt(currentElementDate)
          &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          &&
          x.getString("element").equalsIgnoreCase(historyElementName)
          &&
          x.getDateTime("element_date").isBefore(visit.getDateTime(currentElementDate))
          &&
          valueStatus(x, flag, value))

      }

      val argsArray: Array[String] = Array(historyElementName, value.toString)
      measureLogger(visit, m, "isMostRecentPhysicalExamPerformedBefore", historyElementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isMostRecentPhysicalExamPerformedBefore:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *
    * @param visit current Visit of the patient.
    * @param m measure property of the measure(measureId and condition)
    * @param histroyElement Element Name that has to be look in the history.
    * @param month Month minus from end date
    * @param patientHistoryList  Patient history list.
    * @return It will return true if Assessment was Not Performed In History
    */

  def wasAssessmentNotPerformedInHistory(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        val endDate: Date = globalEndDate
        val end_Date = new DateTime(endDate)
        isExist = patientHistoryList.value.exists(x =>


          !x.isNullAt("element_date")
            &&
            visit.getString("patientuid").equals(x.getString("patientuid"))

            && x.getString("element").equalsIgnoreCase(histroyElement)
            &&
            (
              x.getDateTime("element_date").isBefore(end_Date)
                ||
                x.getDateTime("element_date").isEqual(end_Date)
              )
            &&
            (
              x.getDateTime("element_date").isAfter(end_Date.minusMonths(month))
                ||
                x.getDateTime("element_date").isEqual(end_Date.minusMonths(month))
              )
        )
        val argsArray: Array[String] = Array(month.toString, endDate.toString)
        measureLogger(visit, m, "wasAssessmentNotPerformedInHistory", histroyElement.toString(), isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAssessmentNotPerformedInHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *
    * @param visit cassendra row
    * @param m  property
    * @param elementDate get date fromuser
    * @param histroyElement get date fromuser
    * @param patientHistoryList get date fromuser
    * @return true or false based on  wasDiagnosedBefore
    */

  def wasDiagnosedBefore(visit: CassandraRow, m:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) && histroyElement.equalsIgnoreCase(x.getString("element")) &&
          histroyElement.equalsIgnoreCase(x.getString("element")) &&
          (x.getDateTime("element_date").isBefore(visit.getDateTime(elementDate))
            )
        )
      }
      val argsArray: Array[String] = Array(elementDate)
      measureLogger(visit, m, "wasDiagnosedBefore", histroyElement.toString(), isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasDiagnosedBefore:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  def mostRecentHemoglobinA1cLevelElementList(historyRDD: RDD[CassandraRow], Element: String*): List[CassandraRow] = {

    val mostRecentElements = historyRDD.filter(l => !l.isNullAt("element") && !l.isNullAt("element_date")

      && Element.contains(l.getString("element").toLowerCase))

      .map(l => ((l.getString("patientuid")), l.getDate("element_date")))

      .reduceByKey((x, y) => if (x.after(y)) x else y)

      .collect().toList

    val mostRecentList = historyRDD.filter(r => mostRecentElements.exists(x => x._1.equalsIgnoreCase(r.getString("patientuid"))

      && x._2.equals(r.getDate("element_date"))
    )).collect().toList

    mostRecentList

  }

  /**
    *
    * @param visit current Visit of the patient.
    * @param m    measure property of the measure(measureId and condition)
    * @param histroyElement1 histroyElement1 Name that has to be look in the history.
    * @param histroyElement2 histroyElement2 Name that has to be look in the history.
    * @param month Month minus from end date
    * @param patientHistoryMostRecentList most recent Patient history list.
    * @param patientHistoryList Patient history list.
    * @return It will return if Patient Tobacco User Within XMonths
    */
  def wasPatientTobaccoUserWithinXMonths(visit: CassandraRow, m: MeasureProperty, histroyElement1: String ,histroyElement2: String , month: Int, patientHistoryMostRecentList: List[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val end_Date = new DateTime(globalEndDate)
    try {
      isExist=patientHistoryMostRecentList.exists(x =>
        visit.getString("patientuid").equals(x.getString("patientuid"))
          && histroyElement1.equalsIgnoreCase(x.getString("element"))
          && (
          (x.getDateTime("element_date").isBefore(end_Date) && x.getDateTime("element_date").isAfter(end_Date.minusMonths(month)))

            ||  x.getDateTime("element_date").isEqual(end_Date.minusMonths(month)) || x.getDateTime("element_date").isEqual(end_Date))
          &&
          patientHistoryList.value.exists( y => !y.isNullAt("element_date") && y.getString("patientuid").equals(x.getString("patientuid"))

            && histroyElement2.equalsIgnoreCase(y.getString("element"))

            && y.getDateTime("element_date").isEqual(x.getDateTime("element_date"))
          )
      )
      val argsArray: Array[String] = Array(histroyElement1, month.toString)
      measureLogger(visit, m, "wasPatientTobaccoUserWithinXMonths", histroyElement2, isExist, argsArray)
    }

    catch
      {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPatientTobaccoUserWithinXMonths:" + e.printStackTrace(), "FAIL")
        }
      }
    isExist
  }

  /**
    * PARENT Function
    * @param visit cassendra row
    * @param m  property
    * @param elementDate get date fromuser
    * @param histroyElement get date fromuser
    * @param patientHistoryList get date fromuser
    * @return true or false based on Element Before Or Equal In History
    */

  def wasElementBeforeOrEqualInHistory(visit: CassandraRow, m:MeasureProperty, elementDate:String, histroyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist=patientHistoryList.value.exists(x => !x.isNullAt("element_date") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) && histroyElement.equalsIgnoreCase(x.getString("element")) &&
          histroyElement.equalsIgnoreCase(x.getString("element")) &&
          (x.getDateTime("element_date").isBefore(visit.getDateTime(elementDate)) ||
            x.getDateTime("element_date").isEqual(visit.getDateTime(elementDate))
            )
        )
      }
      val argsArray: Array[String] = Array(elementDate)
      measureLogger(visit, m, "wasElementBeforeOrEqualInHistory", histroyElement.toString(), isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementBeforeOrEqualInHistory:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *
    * @param visit current Visit of the patient.
    * @param m    measure property of the measure(measureId and condition)
    * @param histroyElement1 histroyElement1 Name that has to be look in the history.
    * @param histroyElement2 histroyElement2 Name that has to be look in the history.
    * @param patientHistoryMostRecentList most recent Patient history list.
    * @param patientHistoryList Patient history list.
    * @return returns true if on most recent date elements "Diastolic Blood Pressure" and "Systolic Blood Pressure" are not null.
    */
  def mostRecentPhysicalExamPerforrmedDuringEncounter(visit: CassandraRow, m: MeasureProperty, histroyElement1: String ,histroyElement2: String , patientHistoryMostRecentList: List[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val end_Date = new DateTime(globalEndDate)
    try {
      isExist=patientHistoryMostRecentList.exists(x =>
        visit.getString("patientuid").equals(x.getString("patientuid"))
          && histroyElement1.equalsIgnoreCase(x.getString("element"))
          && (
          (x.getDateTime("element_date").isBefore(end_Date) || x.getDateTime("element_date").isEqual(end_Date))
            &&
            patientHistoryList.value.exists( y => !y.isNullAt("element_date") && y.getString("patientuid").equals(x.getString("patientuid"))

              && histroyElement2.equalsIgnoreCase(y.getString("element"))

              && y.getDateTime("element_date").isEqual(x.getDateTime("element_date"))
            )
          ))
      val argsArray: Array[String] = Array(histroyElement1)
      measureLogger(visit, m, "mostRecentPhysicalExamPerforrmedDuringEncounter", histroyElement2, isExist, argsArray)
    }

    catch
      {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:mostRecentPhysicalExamPerforrmedDuringEncounter:" + e.printStackTrace(), "FAIL")
        }
      }
    isExist
  }

  /**
    *
    * @param visit current visit
    * @param m measure property
    * @param elementDate counselling element
    * @param histroyElement1 most recent screening element
    * @param histroyElement2 tobacco user
    * @param day day in integer
    * @param patientHistoryList1 patientHistoryList1
    * @param patientHistoryList2 patientHistoryList2
    * @return
    */

  def interventionOrderWithinOneDayofEncounter(visit: CassandraRow, m: MeasureProperty, elementDate: String ,histroyElement1: String ,histroyElement2: String, day: Int, patientHistoryList1: Broadcast[List[CassandraRow]],patientHistoryList2: Broadcast[List[CassandraRow]]): Boolean = {

    val end_Date = new DateTime(globalEndDate)
    var isExist = false
    try {
      isExist = patientHistoryList1.value.exists(x =>

        visit.getString("patientuid").equals(x.getString("patientuid"))

          && histroyElement1.equalsIgnoreCase(x.getString("element"))

          &&

          patientHistoryList2.value.exists(y => y.getString("patientuid").equals(x.getString("patientuid"))

            && histroyElement2.equalsIgnoreCase(y.getString("element"))

            && y.getDateTime("element_date").isEqual(x.getDateTime("element_date"))

          )

          && (

          x.getDateTime("element_date").isEqual(visit.getDateTime(elementDate)) || x.getDateTime("element_date").isBefore(visit.getDateTime(elementDate).plusDays(day))
          )


      )

      val argsArray: Array[String] = Array(day.toString,histroyElement1,histroyElement2)
      measureLogger(visit, m, "interventionOrderWithinOneDayofEncounter", elementDate, isExist, argsArray)


    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:interventionOrderWithinOneDayofEncounter:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *
    * This function verifies that History element is present in the range between encounterDate and encounterDate minus noOfyear.
    * @param visit           Current Visit of the patient.
    * @param m               Measure Property of the measure.
    * @param elementDate     element date from current visit
    * @param historyElement  History Element that has to be look in the Patient History Table.
    * @param noOfYears       Number of Year that has to be subtracted from endOfmeasurement Period(endDate).
    * @param patientHistoryList Patient History List.
    * @return   It will return whether the physical exam of a patient was performed in the range between encounterDate and encounterDate minus noOfyear.
    */
  def physicalExamPerformedNotDoneSysDiasWithinOneYearBeforeElement(visit: CassandraRow, m: MeasureProperty, elementDate: String,historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.length > 0) {
        isExist = patientHistoryList.value.exists(histvisit => visit.getString("patientuid").equalsIgnoreCase(histvisit.getString("patientuid"))
          &&
          histvisit.getString("element").equalsIgnoreCase(historyElement)
          &&
          (
            (histvisit.getDateTime("element_date").isBefore(visit.getDateTime(elementDate)) && histvisit.getDateTime("element_date").isAfter(visit.getDateTime(elementDate).minusYears(noOfYears)))
              ||
              histvisit.getDateTime("element_date").equals(visit.getDateTime(elementDate)) || histvisit.getDateTime("element_date").equals(visit.getDateTime(elementDate).minusYears(noOfYears))
            )
        )
        val argsArray: Array[String] = Array(elementDate,historyElement,noOfYears.toString)
        measureLogger(visit, m, "physicalExamPerformedNotDoneSysDiasWithinOneYearBeforeElement", elementDate, isExist, argsArray)

      }
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:physicalExamPerformedNotDoneSysDiasWithinOneYearBeforeElement:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }
  /**
    *
    * @param visit current visit
    * @param m measure property
    * @param histroyElement1 element
    * @param histroyElement2 element to be checked in range
    * @param day day in integer
    * @param patientHistoryList1 patientHistoryList1
    * @param patientHistoryList2 patientHistoryList2
    * @return returns true if historyelement2 is in between historyelement1_date and (historyelement1_date + 1 day)
    */

  def isReasonElementPresentWithinDayAfterElement(visit: CassandraRow, m: MeasureProperty ,histroyElement1: String ,histroyElement2: String, day: Int, patientHistoryList1: Broadcast[List[CassandraRow]],patientHistoryList2: Broadcast[List[CassandraRow]]): Boolean = {

    var isExist = false
    try {
      isExist = patientHistoryList1.value.exists(x =>

        visit.getString("patientuid").equals(x.getString("patientuid"))

          && histroyElement1.equalsIgnoreCase(x.getString("element"))

          &&

          patientHistoryList2.value.exists(y => y.getString("patientuid").equals(x.getString("patientuid"))

            && histroyElement2.equalsIgnoreCase(y.getString("element"))

            && (
            y.getDateTime("element_date").isEqual(x.getDateTime("element_date"))
              ||
              y.getDateTime("element_date").isBefore(x.getDateTime("element_date").plusDays(day))
            )

          )


      )

      val argsArray: Array[String] = Array(histroyElement1,histroyElement2)
      measureLogger(visit, m, "IsReasonElementPresentWithinDayAfterElement", day.toString, isExist, argsArray)


    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:IsReasonElementPresentWithinDayAfterElement:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }
  /**
    * This Function verifies the physical exam performed of patient for Retinal Dilated.
    * @param visit                          current visit of the patient.
    * @param m                              Measure Property of the measure.
    * @param ElementCheckInHistory    Element that has to be verified in the history.
    * @param NoOfMonth                      No of months that has to be go back from start date.
    * @param HistoryList                    Patient History List.
    * @return This Function verifies those patient whose Retinal dialted Exam is performed in a range between start of the measurement period and start date minus no. of months.
    */
  def  wasPhysicalExamPerformedXForRetinalDilatedExam(visit: CassandraRow, m:MeasureProperty, ElementCheckInHistory: String,NoOfMonth: Int, HistoryList:Broadcast[List[CassandraRow]]): Boolean = {

    var isExist = false

    try {
      if (HistoryList.value.length > 0) {
        var sDate: Date = globalStartDate

        var startDate = new DateTime(sDate)

        isExist = HistoryList.value.exists(histvisit =>isNullInhistory(histvisit,"element","element_date")
          && histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          &&
          histvisit.getString("element").equalsIgnoreCase(ElementCheckInHistory)
          &&
          (
            (
              histvisit.getDateTime("element_date").isAfter(startDate.minusMonths(NoOfMonth))
                &&
                histvisit.getDateTime("element_date").isBefore(startDate)
              )
              ||
              histvisit.getDate("element_date").equals(startDate.minusMonths(NoOfMonth))
              ||
              histvisit.getDate("element_date").equals(startDate)
            )
        )
      }
      val argsArray: Array[String] = Array(ElementCheckInHistory,NoOfMonth.toString)
      measureLogger(visit, m, "wasPhysicalExamPerformedXForRetinalDilatedExam",ElementCheckInHistory , isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPhysicalExamPerformedXForRetinalDilatedExam:" + e.printStackTrace(), "FAIL")
      }
    }

    isExist
  }

  /**
    *
    * @param visit
    * @param m
    * @param histroyElement1
    * @param histroyElement2
    * @param month
    * @param patientHistoryList
    * @return
    */
  def wasPatientTobaccoUserWithinXMonths(visit: CassandraRow, m: MeasureProperty, histroyElement1: String ,histroyElement2: String , month: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val end_Date = new DateTime(globalEndDate)
    try {

      isExist=patientHistoryList.value.exists(x =>
        visit.getString("patientuid").equals(x.getString("patientuid"))
          && histroyElement1.equalsIgnoreCase(x.getString("element"))

          && (
          (x.getDateTime("element_date").isBefore(end_Date) && x.getDateTime("element_date").isAfter(end_Date.minusMonths(month)))

            ||  x.getDateTime("element_date").isEqual(end_Date.minusMonths(month)) || x.getDateTime("element_date").isEqual(end_Date))


          && patientHistoryList.value.exists( y =>  visit.getString("patientuid").equals(y.getString("patientuid"))
          && histroyElement2.equalsIgnoreCase(y.getString("element"))

          &&   x.getDateTime("element_date").equals(y.getDateTime("element_date")))


      )
      val argsArray: Array[String] = Array(histroyElement1, month.toString)
      measureLogger(visit, m, "wasPatientTobaccoUserWithinXMonths", histroyElement2, isExist, argsArray)
    }

    catch
      {
        case e: Exception => {
          postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPatientTobaccoUserWithinXMonths:" + e.printStackTrace(), "FAIL")
        }
      }
    isExist
  }


  /**
    * This function checks whether the count of element passed in countElementList is >= the count
    * @param visit            current visit
    * @param m  Measure Property of the measure.
    * @param Count            no. of count from which will be compared from countElementList
    * @param countElementList List of patient and count of element
    * @return true if count of element in list is greater or equal to count passed in parameter for that patientuid
    */
  def getEncounterCountFromHistory(visit: CassandraRow,m:MeasureProperty, Count: Int, countElementList: List[(String, Int)]): Boolean = {

    countElementList.exists(r => r._1.equalsIgnoreCase(visit.getString("patientuid")) && r._2 >= Count)
  }














}
