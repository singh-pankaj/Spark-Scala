package com.figmd.janus.measureComputation.master

case class MeasureProperty(MeasureName: String, ConditionType: String){

}
