package com.figmd.janus.measureComputation.qpp.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master.{MeasureProperty,ElementMaster}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast

object Qpp47 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp47"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    val patient_history_list = getPatientHistory(sparkSession,rdd,ElementMaster.Pos_23,ElementMaster.Hospice_Services, ElementMaster.Hospice_Services_SNOMEDCT,ElementMaster.Hospice_Care,ElementMaster.Documentation_Of_Advance_Care_Plan_Or_Surrogate_Decision_Maker,ElementMaster.Documentation_Of_Advance_Care_Plan)
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(rdd,patientHistoryList)
    ippRDD.cache()

    //Filter Eligable IPP
    val EligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    /*exclusion RDD*/
    val exclusionRDD = getExclusionRdd(ippRDD,patientHistoryList)
    exclusionRDD.cache()

    // Filter Intermediate RDD
    val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA,patientHistoryList)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA, metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD,EligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
  }

  def getIpp(rdd: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP)

    rdd.filter(visit =>
      (
        isAgeAbove(visit,m,true,65)
          &&
          isVisitTypeIn(visit,m,ElementMaster.Subsequent_Hospital_Care,ElementMaster.Annual_Wellness_Visit,ElementMaster.Home_Healthcare_Services,ElementMaster.Care_Services_In_Long_Term_Residential_Facility,ElementMaster.Nursing_Facility_Visit,
            //ElementMaster.Discharge_Services_Hospital_Inpatient_Same_Day_Discharge
            ElementMaster.Hospital_Inpatient_Visit___Initial,
            //ElementMaster.Hospital_Observation_Care_Initial,
            ElementMaster.Office_Visit,
            ElementMaster.Critical_Care,ElementMaster.Initial_Preventive_Physical_Examination)

          &&
          !(
            isEncounterPerformedInHistory(visit,m,ElementMaster.Pos_23,patientHistoryList)
           )
        )
    )
  }

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION)
    ippRDD.filter(visit => (
      isInterventionPerformedInHistory(visit,m,ElementMaster.Hospice_Services,patientHistoryList)
        ||
        (
          isInterventionBeforeEnd(visit,m,ElementMaster.Hospice_Services_SNOMEDCT,patientHistoryList)
          ||
          isInterventionBeforeEnd(visit,m,ElementMaster.Hospice_Care,patientHistoryList)
        )
      )
    )
  }

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET)
    intermediateA.filter(visit => (
      isInterventionPerformedInHistory(visit,m,ElementMaster.Documentation_Of_Advance_Care_Plan_Or_Surrogate_Decision_Maker,patientHistoryList)
      ||
      isInterventionPerformedInHistory(visit,m,ElementMaster.Documentation_Of_Advance_Care_Plan,patientHistoryList)
      )
    )
  }
}