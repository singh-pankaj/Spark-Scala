package com.figmd.janus.measureComputation.ecqm.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


object Ecqm127v6 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm127v6"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd)
    ippRDD.cache()

    //getPatientHistoryList
    val patientHistoryRDD = getElementHistory(sparkSession,
      ElementMaster.Discharged_To_Home_For_Hospice_Care,
      ElementMaster.Discharged_To_Health_Care_Facility_For_Hospice_Care,
      ElementMaster.Hospice_Care_Ambulatory,
      ElementMaster.Pneumococcal_Vaccine,
      ElementMaster.Pneumococcal_Vaccine_Administered,
      ElementMaster.History_Of_Pneumococcal_Vaccine).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    //Filter Denominator Exclusion
    val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = getinterRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA, patientHistoryList)
    //metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exceptionRDD.cache()

    // Filter not met
    val notMetRDD = getinterRDD(intermediateA, metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, sparkSession.sparkContext.emptyRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
  }


  // IPP-Denominator criteria
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP)
    rdd.filter(visit =>
      isPatientElderly(visit, m)
        &&
        isVisitTypeIn(visit, m,
          ElementMaster.Office_Visit,
          ElementMaster.Face_To_Face_Interaction,
          ElementMaster.Annual_Wellness_Visit,
          ElementMaster.Home_Healthcare_Services,
          ElementMaster.Preventive_Care_Services_Established_Office_Visit_18_and_Up,
          ElementMaster.Preventive_Care_Services_Initial_Office_Visit_18_and_Up
        )
    )
  }


  // Denominator Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION)
    ippRDD.filter(visit =>
      isEncounterPerformedInHistory(visit, m, ElementMaster.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        ||
        isEncounterPerformedInHistory(visit, m, ElementMaster.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        ||
        wasInterventionPerformedOrOrderedInHistory(visit, m, ElementMaster.Hospice_Care_Ambulatory, patientHistoryList)
    )
  }


  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET)
    intermediateA.filter(visit =>
      isImmunizationAdministered(visit, m, ElementMaster.Pneumococcal_Vaccine, patientHistoryList)
        ||
        isProcedurePerformed(visit, m, ElementMaster.Pneumococcal_Vaccine_Administered, patientHistoryList)
        ||
        isAssessmentPerformedBefore(visit, m, ElementMaster.History_Of_Pneumococcal_Vaccine_Date,ElementMaster.History_Of_Pneumococcal_Vaccine, patientHistoryList)
    )
  }

}