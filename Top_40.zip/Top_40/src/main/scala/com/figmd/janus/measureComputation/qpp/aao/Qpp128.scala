package com.figmd.janus.measureComputation.qpp.aao


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.util.measure.{MeasureUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


object Qpp128 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "M128"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, rdd,
      ElementMaster.Palliative_Care, ElementMaster.Palliative_care_encounter, ElementMaster.Patient_Reason_Refused, ElementMaster.Pregnancy_Dx, ElementMaster.BMI_LOINC_Value, ElementMaster.Bmi_Normal,
      ElementMaster.Above_Normal_Follow_Up, ElementMaster.Referrals_where_weight_assessment_may_occur, ElementMaster.Above_Normal_Medications, ElementMaster.Medical_Or_Other_Reason_not_done)
    val patientHistoryBroadCastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(rdd, patientHistoryBroadCastList)
    ippRDD.cache()


    val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadCastList)
    exclusionRDD.cache()

    // Filter Exclusions
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    notEligibleRDD.cache()


    val intermidiateRDD = getSubtractRDD(ippRDD, exclusionRDD)
    intermidiateRDD.cache()

    val metRDD = getMet(sparkSession: SparkSession, intermidiateRDD, patientHistoryRDD, patientHistoryBroadCastList)
    metRDD.cache()

    println(">>>>>>>>>>>>>>>>>>>>>>MET")
    metRDD.map(l => l.getString("patientuid")).collect().foreach(println)

    val intermediateA = getSubtractRDD(intermidiateRDD, metRDD)
    intermediateA.cache()

    // Filter Exceptions
    val exceptionRDD = getException(intermediateA, patientHistoryBroadCastList)
    exceptionRDD.cache()

    // Filter not mate
    val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, "Qpp128")

  }


  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadCastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP)

    rdd.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m, ElementMaster.Bmi_Encounter_Code_Set)
        && !isVisitTypeIn(visit, m, ElementMaster.Bmi_Encounter_Telehealth_Modifier)
        && !isEncounterPerformedConcurrentwith(visit, m, ElementMaster.POS_02_Date, ElementMaster.Encounter_Date)
    )
  }


  def getExclusionRdd(eligibleRdd: RDD[CassandraRow], patientHistoryBroadCastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION)
    eligibleRdd.filter(visit =>
      (
        isElementPresentBeforeEncounterDate(visit, m, ElementMaster.Palliative_care_encounter, patientHistoryBroadCastList)
          || isInterventionPerformedBefore(visit, m, ElementMaster.Palliative_Care, ElementMaster.Encounter_Date, patientHistoryBroadCastList)
          || wasPhysicalExamNotPerformedduringEncounter(visit, m, ElementMaster.Encounter_Date, ElementMaster.Patient_Reason_Refused)
          || isDiagnosedWithOnEncounter(visit, m, ElementMaster.Pregnancy_Dx) //change made

        )
    )
  }


  def getMet(sparkSession: SparkSession, intermidiateRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryBroadCastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET)
    val mostRecentBroadcaseElementList = sparkSession.sparkContext.broadcast(mostRecentElementList(patientHistoryRDD, ElementMaster.BMI_LOINC_Value, ElementMaster.Bmi_Normal))

    println("====mostrecent list =====")
    mostRecentElementList(patientHistoryRDD, ElementMaster.BMI_LOINC_Value, ElementMaster.Bmi_Normal).foreach(println)

    intermidiateRDD.filter(visit =>

      //  physicalExamPerformedMostRecentResultInBetweenBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.BMI_LOINC_Value, 12, 18, 25, mostRecentBroadcaseElementList)
      //||
      physicalExamPerformedMostRecentBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Bmi_Normal, 12, mostRecentBroadcaseElementList)
        ||
        (
          PhysicalExamPerformedMostRecentResultGreaterorEqualValueAndBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.BMI_LOINC_Value, 12, 25, mostRecentBroadcaseElementList)
            &&
            (
              isInterventionOrderDoneBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Above_Normal_Follow_Up_Date, 12, patientHistoryBroadCastList)
                || isInterventionOrderDoneBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Referrals_where_weight_assessment_may_occur_Date, 12, patientHistoryBroadCastList)
                || isInterventionOrderDoneBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Above_Normal_Medications_Date, 12, patientHistoryBroadCastList)
              )
          )
        ||
        isInterventionOrderDoneBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Above_Normal_Follow_Up_G_Date, 12, patientHistoryBroadCastList)
        ||
        (

          PhysicalExamPerformedMostRecentResultLessorEqualValueAndBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.BMI_LOINC_Value, 12, 18, mostRecentBroadcaseElementList)
            &&
            (
              isInterventionOrderDoneBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Above_Normal_Follow_Up_Date, 12, patientHistoryBroadCastList)
                || isInterventionOrderDoneBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Referrals_where_weight_assessment_may_occur_Date, 12, patientHistoryBroadCastList)
                || isInterventionOrderDoneBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Above_Normal_Medications_Date, 12, patientHistoryBroadCastList)
              )
          )
        ||
        isInterventionOrderDoneBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Below_Normal_Follow_Up_G_Date, 12, patientHistoryBroadCastList)

    )

  }


  def getException(intermediateA: RDD[CassandraRow], patientHistoryBroadCastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION)
    intermediateA.filter(visit =>
      (
        isInterventionOrderNotDoneBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Medical_Or_Other_Reason_not_done, 12, patientHistoryBroadCastList)
          ||
          (
            isPatientElderly(visit, m)
              &&

              (
                 isDiagnosedWithBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Nutritional_Deficiency, 12, patientHistoryBroadCastList)
              || isDiagnosedWithBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Dementia, 12, patientHistoryBroadCastList)
              || isDiagnosedWithBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Confusion, 12, patientHistoryBroadCastList)
              || isDiagnosedWithBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Mental_Illness, 12, patientHistoryBroadCastList)
              || isDiagnosedWithBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Physical_Disability, 12, patientHistoryBroadCastList)
              || isDiagnosedWithBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Medical_Conditions, 12, patientHistoryBroadCastList))

            )
          || isDiagnosedWithBeforeOrEqualInMonth(visit, m, ElementMaster.Encounter_Date, ElementMaster.Urgent_Or_Emergent_Medical_Situation, 12, patientHistoryBroadCastList)

        )
    )
  }
}



