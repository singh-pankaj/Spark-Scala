package com.figmd.janus.measureComputation.qpp.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP111Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 111
* Measure Title              :- Pneumococcal Vaccination Status for Older Adults
* Measure Description        :- Percentage of patients 65 years of age and older who have ever received a pneumococcal vaccine
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp111  extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp111"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {
    // Filter IPP


    val ippRDD = getIpp(rdd)
    ippRDD.cache()

    //getPatientHistoryList
    val patientHistoryRDD = getElementHistory(sparkSession,
      QPP111Elements.Hospice_Services,
      QPP111Elements.Hospice_Services_Snomedct,
      QPP111Elements.Hospice_Care,
      QPP111Elements.Pneumococcal_Vaccine_2,
      QPP111Elements.Pneumococcal_Vaccine_Administered,
      QPP111Elements.History_Of_Pneumococcal_Vaccine,
      QPP111Elements.Pneumococcal_Vaccine_1,
      QPP111Elements.Pneumococcal_Vaccination).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)




    //Filter Denominator Exclusion
    val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = getinterRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA, patientHistoryList)
    //    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exceptionRDD.cache()

    // Filter not met
    val notMetRDD = getinterRDD(intermediateA, metRDD)
    notMetRDD.cache()
    //



    saveToWebDM(rdd, ippRDD, exceptionRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
  }


  // IPP-Denominator criteria
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP)
    rdd.filter(visit =>
      isPatientElderly(visit, m)
        &&
        isVisitTypeIn(visit, m,
          QPP111Elements.Office_Visit,
          QPP111Elements.Face_To_Face_Interaction,
          QPP111Elements.Annual_Wellness_Visit,
          QPP111Elements.Home_Healthcare_Services,
          QPP111Elements.Preventive_Care_Services_Initial_Office_Visit_18_And_Up,
          QPP111Elements.Preventive_Care_Services_Established_Office_Visit_18_And_Up,
          QPP111Elements.Initial_Preventive_Physical_Examination)
    )
  }



  // Denominator Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION)
    ippRDD.filter(visit =>
      isInterventionPerformed(visit, m, QPP111Elements.Hospice_Services, patientHistoryList)
        ||
        wasInterventionPerformedOrOrderedInHistory(visit, m, QPP111Elements.Hospice_Services_Snomedct, patientHistoryList)
        ||
        wasInterventionPerformedOrOrderedInHistory(visit, m, QPP111Elements.Hospice_Care, patientHistoryList)
    )
  }


  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET)
    intermediateA.filter(visit =>
      (
        wasImmunizationAdministeredInHistory(visit, m, QPP111Elements.Pneumococcal_Vaccine_2, patientHistoryList)
          ||
          wasProcedurePerformedInHistory(visit, m, QPP111Elements.Pneumococcal_Vaccine_Administered, patientHistoryList)
          ||
          wasImmunizationAdministeredInHistory(visit, m, QPP111Elements.Pneumococcal_Vaccine_1, patientHistoryList)
          ||
          wasImmunizationAdministeredInHistory(visit, m, QPP111Elements.History_Of_Pneumococcal_Vaccine, patientHistoryList)
          ||
          wasImmunizationAdministeredInHistory(visit, m, QPP111Elements.Pneumococcal_Vaccination, patientHistoryList)
        )
        && !isImmunizationAdministeredDuringEncounter(visit,m, QPP111Elements.Pneumococcal_Vaccine_Reason_Not_Specified)
    )
  }

}
