package com.figmd.janus.measureComputation.qpp.aao

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.QPP119Elements
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.measureComputation.master.AdminElements

object Qpp119 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp119"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    var patient_history_list = getPatientHistory(sparkSession,rdd,
      QPP119Elements.Initial_Preventive_Physical_Examination,
      QPP119Elements.Annual_Wellness_Visit,
      QPP119Elements.Face_To_Face_Interaction,
      QPP119Elements.Home_Healthcare_Services,
      QPP119Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
      QPP119Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
      QPP119Elements.Office_Visit,
      QPP119Elements.Hospice_Services,
      QPP119Elements.Hospice_Services_Snomedct,
      QPP119Elements.Hospice_Care,
      QPP119Elements.Ace_Inhibitor_Or_Arb,
      QPP119Elements.Hypertensive_Chronic_Kidney_Disease,
      QPP119Elements.Kidney_Failure,
      QPP119Elements.Glomerulonephritis_And_Nephrotic_Syndrome,
      QPP119Elements.Diabetic_Nephropathy,
      QPP119Elements.Diabetic_Nephropathy,
      QPP119Elements.Proteinuria,
      QPP119Elements.Kidney_Transplant,
      QPP119Elements.Vascular_Access_For_Dialysis,
      QPP119Elements.Dialysis_Services,
      QPP119Elements.Other_Services_Related_To_Dialysis,
      QPP119Elements.Dialysis_Education,
      QPP119Elements.Esrd_Monthly_Outpatient_Services,
      QPP119Elements.Urine_Protein_Tests,
      QPP119Elements.Positive_Microalbuminuria,
      QPP119Elements.Positive_Macroalbuminuria,
      QPP119Elements.Negative_Microalbuminuria,
      QPP119Elements.Treatment_For_Nephropathy,
      QPP119Elements.Ace_Or_Arb_Therapy,
      QPP119Elements.Macroalbuminuria_Test_Not_Met).collect().toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(rdd,patientHistoryList)
    ippRDD.cache()

    //eligible RDD
    val eligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,patientHistoryList)
    exclusionRDD.cache()

    // Filter Intermediate RDD
    val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA,patientHistoryList)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA, metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, eligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
  }

  def getIpp(rdd: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP)

    rdd.filter(visit =>
      isPatientAdult(visit, m)
        &&
        isAgeBelow(visit, m,false,76)
        &&
        isDiagnosedOnEncounter(visit,m,QPP119Elements.Diabetes)
        &&
        (
          isVisitTypeIn(visit,m,
            QPP119Elements.Office_Visit,
            QPP119Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
            QPP119Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
            QPP119Elements.Home_Healthcare_Services,
            QPP119Elements.Face_To_Face_Interaction,
            QPP119Elements.Annual_Wellness_Visit,
            QPP119Elements.Initial_Preventive_Physical_Examination)
          )
    )
  }

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION)

    ippRDD.filter(visit => (

      isInterventionPerformed(visit,m,QPP119Elements.Hospice_Services,patientHistoryList)
        ||
        (
          wasInterventionPerformedInHistory(visit,m,QPP119Elements.Hospice_Services_Snomedct,patientHistoryList)
            ||
            wasInterventionPerformedInHistory(visit,m,QPP119Elements.Hospice_Care,patientHistoryList)
          )

      )
    )
  }

  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET)

    intermediateA.filter(visit => (
      (
        wasMedicationOrderInHistory(visit,m,QPP119Elements.Ace_Inhibitor_Or_Arb,patientHistoryList)
          ||
          wasDiagnosisInHistory(visit,m,QPP119Elements.Hypertensive_Chronic_Kidney_Disease,patientHistoryList)
          ||
          wasDiagnosisInHistory(visit,m,QPP119Elements.Kidney_Failure,patientHistoryList)
          ||
          wasDiagnosisInHistory(visit,m,QPP119Elements.Glomerulonephritis_And_Nephrotic_Syndrome,patientHistoryList)
          ||
          wasDiagnosisInHistory(visit,m,QPP119Elements.Diabetic_Nephropathy,patientHistoryList)
          ||
          wasDiagnosisInHistory(visit,m,QPP119Elements.Proteinuria,patientHistoryList)
        )
        ||
        (
          isProcedurePerformed(visit,m,QPP119Elements.Kidney_Transplant,patientHistoryList)
            ||
            isProcedurePerformed(visit,m,QPP119Elements.Vascular_Access_For_Dialysis,patientHistoryList)
            ||
            isProcedurePerformed(visit,m,QPP119Elements.Dialysis_Services,patientHistoryList)
            ||
            isInterventionPerformed(visit,m,QPP119Elements.Other_Services_Related_To_Dialysis,patientHistoryList)
            ||
            isInterventionPerformed(visit,m,QPP119Elements.Dialysis_Education,patientHistoryList)
            ||
            isEncounterPerformed(visit,m,QPP119Elements.Esrd_Monthly_Outpatient_Services,patientHistoryList)
            ||
            isLaboratoryTestPerformed(visit,m,QPP119Elements.Urine_Protein_Tests,patientHistoryList)
          )
        ||
        (
          isLaboratoryTestPerformed(visit,m,QPP119Elements.Positive_Microalbuminuria,patientHistoryList)
            ||
            isLaboratoryTestPerformed(visit,m,QPP119Elements.Positive_Macroalbuminuria,patientHistoryList)
            ||
            isLaboratoryTestPerformed(visit,m,QPP119Elements.Negative_Microalbuminuria,patientHistoryList)
            ||
            isProcedurePerformed(visit,m,QPP119Elements.Treatment_For_Nephropathy,patientHistoryList)
            ||
            isMedicationAdministeredPerformed(visit,m,QPP119Elements.Ace_Or_Arb_Therapy,patientHistoryList)
          )
      )
      &&
      !(
        isLaboratoryTestPerformedNotDone(visit,m,QPP119Elements.Macroalbuminuria_Test_Not_Met,patientHistoryList)

        )
    )
  }
}