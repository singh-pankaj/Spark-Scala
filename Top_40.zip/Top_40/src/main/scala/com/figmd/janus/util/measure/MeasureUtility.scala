package com.figmd.janus.util.measure

import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import java.time.{LocalDate, LocalDateTime, Period, ZoneId}
import java.util.{Calendar, Date, Properties}

import org.joda.time.DateTime
import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator
import com.figmd.janus.WebDataMartCreator.{ global_measure_name, prop}
import com.figmd.janus.measureComputation.master.MeasureProperty
import com.figmd.janus.util.application.{DateUtility, FileUtility, PostgreUtility, SparkUtility}
import com.figmd.janus.util.measure.messages._
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
//import com.figmd.janus.util.measure.HistoryLookUpUtility
import org.apache.hadoop.fs.FileSystem
import org.apache.log4j._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


class MeasureUtility  extends Serializable {


  @transient lazy val dateUtility = new DateUtility();
  @transient lazy val fileUtility = new FileUtility();
  @transient lazy val sparkUtility = new SparkUtility()
  @transient lazy val hdfsConf = FileSystem.get(sparkUtility.getSparkContext().sparkContext.hadoopConfiguration)
  @transient lazy val postgresUtilityObj = new PostgreUtility()
  @transient lazy val wfType = prop.getProperty("wfType")

  @transient lazy val DATE_TIME_FORMAT_EEE = DateTimeFormatter.ofPattern(fileUtility.getProperty("date.format.eee"))
  @transient lazy val DATE_FORMAT = DateTimeFormatter.ofPattern(fileUtility.getProperty("date.format.dd.mm.yyyy"))



  //    var logfilename =""
  lazy val logfilename = fileUtility.getProperty("file.output.path.log")
  //  log4j.appender.rolling.file=${spark.yarn.app.container.log.dir}/spark.log
  @transient lazy val loggerObj: Logger = Logger.getLogger(this.getClass.getName)
  var dateFormat = fileUtility.getProperty("date.format")
  var logFile = prop.getProperty("measure_computation_output_path");
  final var IPP = "IPP"
  final var MET = "MET"
  final var EXCEPTION = "EXCEPTION"
  final var EXCLUSION = "EXCLUSION"
  final var ELIGIBLE = "ELIGIBLE"
  var message = "";
  var str = dateUtility.now + "~" + "1" + "~"

  //non Log4j
  /*var propobj: Properties = new Properties()
  propobj = fileUtility.getPropertyLog4j()
*/
  //Log4j
  val propobj: Properties = new Properties()
  propobj.setProperty("log4j.reset","true")
  propobj.setProperty("log4j.rootLogger","WARN,file")
  propobj.setProperty("log4j.appender.file","org.apache.log4j.FileAppender")
  propobj.setProperty("log4j.appender.file.File","/tmp/CMS/logger_test")
  propobj.setProperty("log4j.appender.file.ImmediateFlush","true")
  propobj.setProperty("log4j.appender.file.Threshold","WARN")
  propobj.setProperty("log4j.appender.file.layout","org.apache.log4j.PatternLayout")
  propobj.setProperty("log4j.appender.file.layout.ConversionPattern","%m%n")
  propobj.setProperty("log4j.appender.file.File", logfilename)


  PropertyConfigurator.configure(propobj)


  var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)

  val globalStartDate: Date = SIMPLE_DATE_FORMAT.parse("2018-01-01")
  val globalEndDate: Date = SIMPLE_DATE_FORMAT.parse("2018-12-31")
  val globalStartDate1: String ="2018-01-01"
  val globalEndDate1: String ="2018-12-31"

  def convertDateToDDMMYYYY(dateString: String): String = {
    //println("::::::::::::::::::::::::::::::::"+dateString)
    LocalDateTime.parse(dateString, DATE_TIME_FORMAT_EEE).format(DATE_FORMAT)
  }


  /**
    * This function verifies the age of the patient is above the required age.
    * @param r              current visit of the patient.
    * @param measureProperty Measure property of the measure.
    * @param equalFlag      It is used for the greaterorequalto Or greater condition
    * @param compareYears   Number of years to that we have to compare.
    * @return It return true if age is Above 18
    */
  def isAgeAbove(r: CassandraRow, measureProperty: MeasureProperty,equalFlag:Boolean, compareYears: Int = 18): Boolean = {
    var isExist = false
    try {
      val start_Date = returnDate(r, "dob")
      val end_Date = returnDate(r, "encounterdate")

      var ageDiffYears: Int = 0
      if (start_Date._1 != null && end_Date._1 != null) {
        ageDiffYears = Period.between(start_Date._1, end_Date._1).getYears
        if (equalFlag)
          isExist = ageDiffYears >= compareYears
        else
          isExist = ageDiffYears > compareYears
      }

      val argsArray: Array[String] = Array(start_Date._2, end_Date._2, compareYears.toString)
      measureLogger(r, measureProperty, "isAgeAbove", "dob", isExist, argsArray)

    }
    catch {
      case e: Exception => {
        println("ERROR::::"+e.printStackTrace)
         postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeAbove:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }

  def returnDate(r: CassandraRow, field: String): (LocalDate, String) = {
    r.isNullAt(field) match {
      case false => (r.getDate(field).toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), convertDateToDDMMYYYY(r.getDate(field).toString))
      case true => (null, null)
    }
  }
  /*
* @param r as cassandra row
* @param measureProperty case class object contains conditionType as method type and measureName as measure name
* @param startDateDOB as privious date
* @param endDateEncounter as latest date
* @param checkValue as vlaue to check with cassandra value
* @return function return boolean value
* Check age diff is less to given age argument
* */
  def isAgeBelow(r: CassandraRow, measureProperty: MeasureProperty,equalFlag:Boolean, compareYears: Int = 18): Boolean = {
    var isExist = false
    try {

      val start_Date = returnDate(r, "dob")
      val end_Date = returnDate(r, "encounterdate")

      var ageDiffYears: Int = 0
      if (start_Date._1 != null && end_Date._1 != null) {
        ageDiffYears = Period.between(start_Date._1, end_Date._1).getYears
        if (equalFlag)
          isExist = ageDiffYears <= compareYears
        else
          isExist = ageDiffYears < compareYears
      }

      val argsArray: Array[String] = Array(start_Date._2, end_Date._2, compareYears.toString)
      measureLogger(r, measureProperty, "isAgeBelow", "dob", isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeBelow:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }

  def convertDateToYYYYDDMM(dateString: String): String = {
    //println("::::::::::::::::::::::::::::::::"+dateString)
    LocalDateTime.parse(dateString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
  }


  // check element present
  def checkElementPresent(visit: CassandraRow, m: MeasureProperty, elementName: String): Boolean = {

    var isElementExist = false

    try {
      isElementExist = !visit.isNullAt(elementName) && visit.getString(elementName).equalsIgnoreCase("1")
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "checkElementPresent", elementName, isElementExist, argsArray)
    } catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementPresent:" + e.printStackTrace(), "FAIL")
      }
    }

    isElementExist;

  }
  //Function for isAgeBetween
  def isAgeBetween(r: CassandraRow, m:MeasureProperty,compareYears1: Double, compareYears2: Double): Boolean = {
    var isExist = false
    try {
      var encounterDate = ""
      if (!r.isNullAt("encounterdate")) {
        encounterDate = convertDateToDDMMYYYY(r.getDate("encounterdate").toString)
      } else {
        encounterDate = ""
      }
      var dobDate = ""
      if (!r.isNullAt("dob")) {
        dobDate = convertDateToDDMMYYYY(r.getDate("dob").toString)
      } else {
        dobDate = ""
      }
      val start_Date = r.getDate("dob").toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
      val end_Date = r.getDate("encounterdate").toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
      val AgeDiffYears = Period.between(start_Date, end_Date).getYears

      isExist = !r.isNullAt("dob") && !r.isNullAt("encounterdate") && ((AgeDiffYears > compareYears1 && AgeDiffYears < compareYears2) || AgeDiffYears == compareYears1)
      val argsArray: Array[String] = Array(dobDate, encounterDate, compareYears1.toString, compareYears2.toString)
      measureLogger(r, m, "isAgeBetween", dobDate, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeBetween:" + e.printStackTrace(), "FAIL")

      }
    }
    isExist
  }




  def checknull(r: CassandraRow, m:MeasureProperty, checkElement: String): Boolean = {
    var isExist = false
    try {
      isExist = r.isNullAt(checkElement) || r.getString(checkElement) == "0" || r.getString(checkElement).equals("0") || r.getString(checkElement).equalsIgnoreCase("null")
      val argsArray: Array[String] = Array(checkElement)
      measureLogger(r, m, "checknull", checkElement, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:checknull:" + e.printStackTrace(), "FAIL")

      }
    }
    isExist
  }


  // function for isElementDateStartAfterStartOfWithInDays
  def isElementDateStartAfterStartOfWithInDays(r: CassandraRow, m:MeasureProperty, checkDate: String, compareDate: String, no_of_Days: Int): Boolean = {
    var isExist = false
    try {
      var cDate = ""
      if (!r.isNullAt(compareDate)) {
        cDate = convertDateToDDMMYYYY(r.getDate(compareDate).toString)
      } else {
        cDate = compareDate
      }

      isExist = !r.isNullAt(checkDate) && !r.isNullAt(compareDate) && !r.isNullAt(checkDate) && ((
        r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate).plusDays(no_of_Days)) &&
          r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate))
        ) || r.getDateTime(checkDate).equals(r.getDateTime(compareDate).plusDays(no_of_Days)) || r.getDate(checkDate).equals(r.getDate(compareDate))
        )
      val argsArray: Array[String] = Array(checkDate, cDate, cDate, no_of_Days.toString)
      measureLogger(r, m, "isElementDateStartAfterStartOfWithInDays", checkDate, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementDateStartAfterStartOfWithInDays:" + e.printStackTrace(), "FAIL")

      }
    }
    isExist
  }




  // function for isDateEqual
  def isDateEqual(r: CassandraRow, m:MeasureProperty, firstDate: String, compareDate: String): Boolean = {
    var isExist = false
    try {
      var cDate = ""
      if (!r.isNullAt(compareDate)) {
        cDate = convertDateToDDMMYYYY(r.getDate(compareDate).toString)
      } else {
        cDate = compareDate
      }
      var fDate = ""
      if (!r.isNullAt(firstDate)) {
        fDate = convertDateToDDMMYYYY(r.getDate(firstDate).toString)
      } else {
        fDate = firstDate
      }

      isExist = !r.isNullAt(firstDate) && !r.isNullAt(compareDate) && (r.getDate(firstDate).getDate.equals(r.getDate(compareDate).getDate) && r.getDate(firstDate).getMonth.equals(r.getDate(compareDate).getMonth) && r.getDate(firstDate).getYear.equals(r.getDate(compareDate).getYear))


      val argsArray: Array[String] = Array(fDate, cDate)
      measureLogger(r, m, "isDateEqual", fDate, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDateEqual:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }





  //  def measureLogger(r: CassandraRow, measureName: String, conditionType: String, conditionName: String, elementName: String, status: Boolean, description : String): Unit = {
  //    try {
  //      //var logStr=""+measureName +"~"+quarterEndDate +"~"+wfType +"~"+r.getString("practiceuid")+"~"+ r.getString("patientuid")+"~"+ r.getString("visituid") + "~" + conditionType + "~" + conditionName + "~" + elementName + "~" + status + "~" + description
  //      var logStr = "" + measureName + "~" + r.getString("practiceuid") + "~" + r.getString("patientuid") + "~" + r.getString("visituid") + "~" + conditionType + "~" + conditionName + "~" + elementName + "~" + status + "~" + description
  //      //loggerObj.warn(logStr)
  //    }
  //    catch {
  //      case e: Exception => println(e.printStackTrace)
  //    }
  //  }

  def measureLogger(r: CassandraRow, m: MeasureProperty, functionName: String, elementName: String, status: Boolean, arr: Array[String]): Unit = {
    try {
       val description = messageMap(functionName + "_" + status).format(arr: _*)
      // val logStr = "" +  m.MeasureName + "~" + r.getString("practiceuid") + "~" + r.getString("patientuid") + "~" + r.getString("visituid") + "~" + m.ConditionType + "~" + functionName + "~" + elementName + "~" + status + "~" + description
       val logStr =  "" +  m.MeasureName +"~" + m.ConditionType + "~" + functionName + "~" + elementName + "~" + status + "~" + description
       loggerObj.warn(logStr)
    }
    catch {
      case e: Exception => println(e.printStackTrace())
      //System.exit(0)
    }

    /*
        if(File(fileUtility.getProperty("file.output.path.log") ).exists)
        File(fileUtility.getProperty("file.output.path.log") ).appendAll(r.getString("practiceuid")+"~"+ measureName +"~"+r.getString("patientuid")+"~"+ r.getString("visituid") + "~" + conditionType + "~" + conditionName + "~" + elementName + "~" + status + "~" + description  + "\n")
        else {
          File(fileUtility.getProperty("file.output.path.log") ).createFile()
          File(fileUtility.getProperty("file.output.path.log") ).appendAll(r.getString("practiceuid")+"~"+ measureName +"~"+r.getString("patientuid")+"~"+ r.getString("visituid") + "~" + conditionType + "~" + conditionName + "~" + elementName + "~" + status + "~" + description  + "\n")
        }
    */


    // log.info(r.getString("practiceuid") + "," + r.getString("patientuid") + "," + r.getString("visituid") + "," + measureName + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description)

    /*      val file=File(logFile)

           if (file.exists)
             file.appendAll(r.getString("practiceuid") + "~" +measureName + "~" +r.getString("patientuid") + "~" +r.getString("visituid") + "~" +conditionType + "~" +conditionName + "~" +elementName + "~" +status + "~" +description + "\n")
           else{
             file.createFile(true)
             file.appendAll(r.getString("practiceuid") + "~" +measureName + "~" +r.getString("patientuid") + "~" +r.getString("visituid") + "~" +conditionType + "~" +conditionName + "~" +elementName + "~" +status + "~" +description + "\n")
           }*/


    //hdfsConf.append(new org.apache.hadoop.fs.Path(fileUtility.getProperty("file.output.path")+"/"+measureName+"/"+measureName+".log")).writeBytes(r.getString("practiceuid")+","+ measureName +","+r.getString("patientuid")+","+ r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description  + "\n")

    //        @transient lazy val hdfs= FileSystem.get(new SparkUtility().getSparkContext().sparkContext.hadoopConfiguration)


    /*
            val path=new org.apache.hadoop.fs.Path(fileUtility.getProperty("file.output.path")+"/"+measureName+"/"+measureName+".log")
            //@transient lazy val oStream=hdfsConf.create(path)
            //oStream.writeUTF(r.getString("practiceuid")+","+ measureName +","+r.getString("patientuid")+","+ r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description  + "\n")
            //logarray.add(r.getString("practiceuid")+","+ measureName +","+r.getString("patientuid")+","+ r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description  + "\n")
            if(hdfsConf.isFile(path))
              hdfsConf.append(path).writeBytes(r.getString("practiceuid") + "," + measureName + "," + r.getString("patientuid") + "," + r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description + "\n")
            else {
              hdfsConf.create(path)
              hdfsConf.append(path).writeBytes(r.getString("practiceuid") + "," + measureName + "," + r.getString("patientuid") + "," + r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description + "\n")
            }*/

  }


  def getFiledList(measureName: String): Seq[String] = {
    var elements = fileUtility.getProperty("measure." + measureName + ".element.select");
    elements.split(",").toSeq
  }

  def getNotMet(ippRDD: RDD[CassandraRow], metRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    ippRDD.subtract(metRDD)
  }

  def getinterRDD(firstRDD: RDD[CassandraRow], secoundRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    firstRDD.subtract(secoundRDD)
  }

  def getExceptionRdd(exceptionRDD: RDD[CassandraRow], notMetRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    exceptionRDD.subtract(notMetRDD)
  }

  def getNotMetWithoutException(notMetRDD: RDD[CassandraRow], exceptionRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    notMetRDD.subtract(exceptionRDD)
  }

  def getSubtractRDD(firstRDD: RDD[CassandraRow], secoundRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    firstRDD.subtract(secoundRDD)
  }

  def isIppEqualsEligible: Boolean = {
    if (fileUtility.getProperty("isIPPequalsEligible").equalsIgnoreCase("true")) {
      true;
    }
    else {
      false;
    }
  }

  def getIPPString(): String = {
    str + "1" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0"
  }

  def saveToWebDM(rdd: RDD[CassandraRow], ippRDD: RDD[CassandraRow], notEligibleRDD: RDD[CassandraRow], exclusionRDD: RDD[CassandraRow], metRDD: RDD[CassandraRow], exceptionRDD: RDD[CassandraRow], notMetRDD: RDD[CassandraRow], measureId: String): Unit = {
    try {
      var quarterEndDate = prop.getProperty("quarterEndDate").trim


      if (WebDataMartCreator.debugMode == 1) {
        println("*********************************************************")
        println(" " + measureId + " *** rdd          ***" + rdd.count())
        println(" " + measureId + " *** IPP          ***" + ippRDD.count())
        println(" " + measureId + " *** notEligibleRDD          ***" + notEligibleRDD.count())
        println(" " + measureId + " *** exclusionRDD          ***" + exclusionRDD.count())
        println(" " + measureId + " *** exceptionRDD ***" + exceptionRDD.count())
        println(" " + measureId + " *** metRDD       ***" + metRDD.count())
        println(" " + measureId + " *** notMetRDD    ***" + notMetRDD.count())

        //        if (!rdd.isEmpty())             println(" " + measureId + " *** rdd          ***" + rdd.count()) else println("CMS " + measureId + " *** rdd          ***0")
        //        if (!ippRDD.isEmpty())          println(" " + measureId + " *** IPP          ***" + ippRDD.count()) else println(" " + measureId + " *** IPP          ***0")
        //        if (!notEligibleRDD.isEmpty())  println(" " + measureId + " *** notEligibleRDD          ***" + notEligibleRDD.count()) else println(" " + measureId + " *** notEligibleRDD          ***0")
        //        if (!exclusionRDD.isEmpty())    println(" " + measureId + " *** exclusionRDD          ***" + exclusionRDD.count()) else println(" " + measureId + " *** exclusionRDD          ***0")
        //        if (!exceptionRDD.isEmpty())    println(" " + measureId + " *** exceptionRDD ***" + exceptionRDD.count()) else println(" " + measureId + " *** exceptionRDD ***0")
        //        if (!metRDD.isEmpty())          println(" " + measureId + " *** metRDD       ***" + metRDD.count()) else println(" " + measureId + " *** metRDD       ***0")
        //        if (!notMetRDD.isEmpty())       println(" " + measureId + " *** notMetRDD    ***" + notMetRDD.count()) else println(" " + measureId + " *** notMetRDD    ***0")
        println("*********************************************************")
      }
      else if (WebDataMartCreator.debugMode == 0) {
        var path = new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId + "/" + quarterEndDate)

        if (hdfsConf.isDirectory(path))
          hdfsConf.delete(path, true)

        if (!notEligibleRDD.isEmpty()) notEligibleRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getNotEligiblePopulationString()).cache().saveAsTextFile(path + "/notEligible")
        if (!exclusionRDD.isEmpty()) exclusionRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getExclusionString()).cache().saveAsTextFile(path + "/exclusion")
        if (!metRDD.isEmpty()) metRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getMetString()).cache().saveAsTextFile(path + "/met")
        if (!exceptionRDD.isEmpty()) exceptionRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getExceptionString()).cache().saveAsTextFile(path + "/exception")
        if (!notMetRDD.isEmpty()) notMetRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getNotMetString()).cache().saveAsTextFile(path + "/notMet")

        //      notEligibleRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getNotEligiblePopulationString()).cache().saveAsTextFile(path + "/notEligible")
        //      exclusionRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getExclusionString()).cache().saveAsTextFile(path + "/exclusion")
        //      metRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getMetString()).cache().saveAsTextFile(path + "/met")
        //      exceptionRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getExceptionString()).cache().saveAsTextFile(path + "/exception")
        //      notMetRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getNotMetString()).cache().saveAsTextFile(path + "/notMet")
        //        postgresUtilityObj.insertIntoProcessDetails(measureId, "", "", "Measure computation done successfully", "PASS")
      }
    else {
        var path = new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId + "/" + quarterEndDate)

        if (hdfsConf.isDirectory(path))
          hdfsConf.delete(path, true)

        if (!ippRDD.isEmpty()) ippRDD.map(l => l.toString()).cache().saveAsTextFile(path + "/ipp")
        if (!notEligibleRDD.isEmpty()) notEligibleRDD.map(l => l.toString()).cache().saveAsTextFile(path + "/noteligible")
        if (!exclusionRDD.isEmpty()) exclusionRDD.map(l => l.toString()).cache().saveAsTextFile(path + "/exclusion")
        if (!metRDD.isEmpty()) metRDD.map(l => l.toString()).cache().saveAsTextFile(path + "/met")
        if (!exceptionRDD.isEmpty()) exceptionRDD.map(l => l.toString()).cache().saveAsTextFile(path + "/exception")
        if (!notMetRDD.isEmpty()) notMetRDD.map(l => l.toString()).cache().saveAsTextFile(path + "/notmet")

      }

      ippRDD.unpersist(true);
      metRDD.unpersist(true);
      notMetRDD.unpersist(true);
      exceptionRDD.unpersist(true);
      notEligibleRDD.unpersist(true);
      exclusionRDD.unpersist(true);

    }
    catch {
      case e: Exception => {
        println("ERROR:"+e.getMessage)
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:saveToWebDM:" + e.getMessage, "FAIL")

      }
    }
  }

  def getMetString(): String = {
    str + "1" + "~" + "0" + "~" + "1" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0"
  }

  def getNotMetString(): String = {
    str + "1" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "1" + "~" + "0" + "~" + "0"
  }


  /*  def saveToWebDM(notEligibleRDD: RDD[CassandraRow], exclusionRDD: RDD[CassandraRow], metRDD: RDD[CassandraRow], exceptionRDD: RDD[CassandraRow], notMetRDD: RDD[CassandraRow], measureId: String): Unit = {
      var quarterEndDate = prop.getProperty("quarterEndDate").trim

      var path = new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId + "/" + quarterEndDate)
      if (hdfsConf.isDirectory(path))
        hdfsConf.delete(path, true)

      notEligibleRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getNotEligiblePopulationString()).cache().saveAsTextFile(path + "/notEligible")
      exclusionRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getExclusionString()).cache().saveAsTextFile(path + "/exclusion")
      metRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getMetString()).cache().saveAsTextFile(path + "/met")
      exceptionRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getExceptionString()).cache().saveAsTextFile(path + "/exception")
      notMetRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getNotMetString()).cache().saveAsTextFile(path + "/notMet")
    }*/

  def getExceptionString(): String = {
    str + "1" + "~" + "0" + "~" + "0" + "~" + "1" + "~" + "0" + "~" + "0" + "~" + "0"
  }

  def getNotEligiblePopulationString(): String = {
    str + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0"
  }

  //  def deletePriviousBatch(): Unit =
  //  {
  //    val hdfs= FileSystem.get(new SparkUtility().getSparkContext().sparkContext.hadoopConfiguration)
  //    if(hdfs.isDirectory(new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType)))
  //      hdfs.delete(new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType),true)
  //    println("Deleted directory path: "+prop.getProperty("measure_computation_output_path") + "/" + wfType)
  //    hdfs.close()
  //  }

  def getExclusionString(): String = {
    str + "1" + "~" + "1" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0"
  }

  def generateCSVString(r: CassandraRow, measureId: String, quarterEndDate: String): String = {
    try {
      val dFormat = "yyyy-MM-dd HH:mm:ssZ"
      val defaultValue = "0000-00-00 00:00:00.000000Z"
      //    val dFormat="EEE MMM dd HH:mm:ss zzz yyyy"
      //    val defaultValue="0000-00-00 00:00:00.000000+0000"

      (if (r.isNullAt("practiceuid")) "" else r.getString("practiceuid")) + "~" +
        (if (r.isNullAt("serviceprovideruid")) "" else r.getString("serviceprovideruid")) + "~" +
        (if (r.isNullAt("locationid")) "" else r.getString("locationid")) + "~" +
        (if (r.isNullAt("patientuid")) "" else r.getString("patientuid")) + "~" +
        (if (r.isNullAt("visituid")) "" else r.getString("visituid")) + "~" +
        (if (r.isNullAt("genderuid")) "" else r.getString("genderuid")) + "~" +
        (if (r.isNullAt("dob")) defaultValue else LocalDateTime.parse(r.getString("dob").toString, DateTimeFormatter.ofPattern(dFormat)).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" +
        (if (r.isNullAt("encounterdate")) defaultValue else LocalDateTime.parse(r.getString("encounterdate").toString, DateTimeFormatter.ofPattern(dFormat)).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" +
        (if (r.isNullAt("firstname")) "" else r.getString("firstname")) + "~" +
        (if (r.isNullAt("midname")) "" else r.getString("midname")) + "~" +
        (if (r.isNullAt("lastname")) "" else r.getString("lastname")) + "~" +
        (if (r.isNullAt("patient_mrn")) "" else r.getString("patient_mrn")) + "~" +
        (if (r.isNullAt("ssn")) "" else r.getString("ssn")) + "~" +
        "~" + measureId
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:saveToWebDM:" + e.printStackTrace(), "FAIL")
        ""
      }
    }
  }



  def convertDateToYYYYDDMM1(dateString: String): String = {
    //println("::::::::::::::::::::::::::::::::"+dateString)
    LocalDateTime.parse(dateString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
  }






  /*def saveRDD(MEASURE_NAME:String,ippRDD:RDD[CassandraRow],locationRDD:RDD[(AnyRef,Double,Int)]): Unit ={
    println("CMS " + MEASURE_NAME)
    if (WebDataMartCreator.debugMode == 1) {
      println("CMS " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
      println("CMS " + MEASURE_NAME + " *** locationRdd    ***" + locationRDD.count())
    }
    else {
      saveToWebDM_median(locationRDD, MEASURE_NAME)
      postgresUtilityObj.insertIntoProcessDetails(MEASURE_NAME, "", "", "Measure computation done successfully", "PASS")
    }

    locationRDD.unpersist(true);
  }
*/



  def saveRDD(MEASURE_NAME: String, ippRDD: RDD[(AnyRef, AnyRef, AnyRef, Double)], practiceRDD: RDD[(AnyRef, Double, Int)],
              locationRDD: RDD[(AnyRef, AnyRef, Double, Int)]
              , providerRDD: RDD[(AnyRef, AnyRef, Double, Int)], providerLocationRDD: RDD[(AnyRef, AnyRef, AnyRef, Double, Int)]): Unit = {
    try {
      if (WebDataMartCreator.debugMode == 1) {
        println("CMS " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
        println("CMS " + MEASURE_NAME + " *** practiceRDD    ***" + practiceRDD.count())
        println("CMS " + MEASURE_NAME + " *** locationRdd    ***" + locationRDD.count())
        println("CMS " + MEASURE_NAME + " *** ProviderRdd    ***" + providerRDD.count())
        println("CMS " + MEASURE_NAME + " *** Provider+locationRdd   ***" + providerLocationRDD.count())
      }
      else {
        saveToWebDM_MD(practiceRDD, locationRDD, providerRDD, providerLocationRDD, MEASURE_NAME)
        postgresUtilityObj.insertIntoProcessDetails(MEASURE_NAME, "", "", "Measure computation done successfully", "PASS")
      }

      practiceRDD.unpersist(true);
      locationRDD.unpersist(true);
      providerRDD.unpersist(true);
      providerLocationRDD.unpersist(true);
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:saveRDD:" + e.printStackTrace(), "FAIL")

      }
    }
  }

  def saveToWebDM_MD(practiceRDD: RDD[(AnyRef, Double, Int)]
                     , locationRDD: RDD[(AnyRef, AnyRef, Double, Int)],
                     providerRDD: RDD[(AnyRef, AnyRef, Double, Int)], providerLocationRDD: RDD[(AnyRef, AnyRef, AnyRef, Double, Int)],
                     measureId: String): Unit = {
    try {
      var quarterEndDate = prop.getProperty("quarterEndDate").trim
      var wfType = prop.getProperty("wfType").trim


      var path = new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId + "/" + quarterEndDate)
      if (hdfsConf.isDirectory(path))
        hdfsConf.delete(path, true)

      practiceRDD.filter(r => if (r._1 != "") true else false).map(l => if (l._1 != "" && l._2 != "" && l._3 != "") {
        l._1 + "~" + l._2 + "~" + l._3 + "~" + measureId + "~" + quarterEndDate + "~" + wfType
      }).cache().saveAsTextFile(path + "/practice")
      locationRDD.filter(r => if (r._1 != "") true else false).map(l => if (l._1 != "" && l._2 != "" && l._3 != "" && l._4 != "") {
        l._1 + "~" + l._2 + "~" + l._3 + "~" + l._4 + "~" + measureId + "~" + quarterEndDate + "~" + wfType
      }).cache().saveAsTextFile(path + "/location")
      providerRDD.filter(r => if (r._1 != "") true else false).map(l => if (l._1 != "" && l._2 != "" && l._3 != "" && l._4 != "") {
        l._1 + "~" + l._2 + "~" + l._3 + "~" + l._4 + "~" + measureId + "~" + quarterEndDate + "~" + wfType
      }).cache().saveAsTextFile(path + "/provider")
      providerLocationRDD.filter(r => if (r._1 != "") true else false).map(l => if (l._1 != "" && l._2 != "" && l._3 != "" && l._4 != "" && l._5 != "") {
        l._1 + "~" + l._2 + "~" + l._3 + "~" + l._4 + "~" + l._5 + "~" + measureId + "~" + quarterEndDate + "~" + wfType
      }).cache().saveAsTextFile(path + "/providerlocation")
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:saveToWebDM_MD:" + e.printStackTrace(), "FAIL")

      }
    }
  }


  def checkElementCountGreaterOrEqualElementCount(r: CassandraRow,m:MeasureProperty, ElementPresentCount: Int,  elements: String*): Boolean = {
    var count = 0
    for (eCounter <- 0 to elements.length - 1) {
      if (checkElementPresent(r, m, elements(eCounter))) {
        count = count + 1
      }
    }
    if (count >= ElementPresentCount) {
      true
    } else false
  }

  // function for isDuringInfluenzaPeriodFirstThreeMonth
  def isDuringInfluenzaPeriodFirstThreeMonth(r: CassandraRow, m:MeasureProperty, elementName: String): Boolean = {
    var isExist=false
    try {
      val year = globalStartDate.toString.takeRight(4)
      val sdf = new SimpleDateFormat("yyyy-MM-dd")
      val sDate: Date = sdf.parse(year + "-01-01")
      val eDate: Date = sdf.parse(year + "-03-31")

      isExist = !r.isNullAt(elementName) && (
        (sDate.before(eDate) || sDate.equals(eDate)) &&
          ((r.getDate(elementName).after(sDate) && r.getDate(elementName).before(eDate)) ||
            (r.getDate(elementName).equals(sDate) || r.getDate(elementName).equals(eDate)))
        )

      val argsArray: Array[String] = Array(elementName, sDate.toString, eDate.toString)
      measureLogger(r, m, "isDuringInfluenzaPeriodFirstThreeMonth", sDate.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDuringInfluenzaPeriodFirstThreeMonth:" + e.printStackTrace(), "FAIL")

      }
    }
    isExist
  }


  // function for isDuringInfluenzaPeriodLastThreeMonth
  def isDuringInfluenzaPeriodLastThreeMonth(r: CassandraRow, m:MeasureProperty, elementName: String): Boolean = {
    try {
      val year = globalEndDate.toString.takeRight(4)
      val sdf = new SimpleDateFormat("yyyy-MM-dd")
      val sDate: Date = sdf.parse(year + "-10-01")
      val eDate: Date = sdf.parse(year + "-12-31")

      val status = !r.isNullAt(elementName) && (
        (sDate.before(eDate) || sDate.equals(eDate)) &&
          (
            (r.getDate(elementName).after(sDate) && r.getDate(elementName).before(eDate))
              ||
              r.getDate(elementName).equals(sDate) || r.getDate(elementName).equals(eDate)
            )
        )

      val argsArray: Array[String] = Array(elementName, sDate.toString, eDate.toString)
      measureLogger(r, m, "isDuringInfluenzaPeriodLastThreeMonth", sDate.toString, status, argsArray)

      return status;
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDuringInfluenzaPeriodLastThreeMonth:" + e.printStackTrace(), "FAIL")
        false
      }
    }

  }


  // function for isDuringInfluenzaPeriodLastFiveMonth
  def isDuringInfluenzaPeriodLastFiveMonth(r: CassandraRow, m:MeasureProperty, elementName: String): Boolean = {
    try {
      val year = globalEndDate.toString.takeRight(4)
      val sdf = new SimpleDateFormat(dateFormat)
      val sDate: Date = sdf.parse(year + "-08-01")
      val eDate: Date = sdf.parse(year + "-12-31")

      val status = !r.isNullAt(elementName) && (
        (sDate.before(eDate) || sDate.equals(eDate)) &&
          ((r.getDate(elementName).after(sDate) && r.getDate(elementName).before(eDate)) ||
            (r.getDate(elementName).equals(sDate) || r.getDate(elementName).equals(eDate)))
        )
      val argsArray: Array[String] = Array(elementName, sDate.toString, eDate.toString)
      measureLogger(r, m, "isDuringInfluenzaPeriodLastFiveMonth", sDate.toString, status, argsArray)

      return status;
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDuringInfluenzaPeriodLastFiveMonth:" + e.printStackTrace(), "FAIL")
        false
      }
    }
  }

  /**
    *This function verifies the gender is female.
    * @param visit current visit of the patient.
    * @param m Measure Property of the measure.
    * @return
    */
  def isFemale(visit: CassandraRow, m: MeasureProperty): Boolean = {
    var isElementExist = false
    try {
      isElementExist= !visit.isNullAt("sex") && visit.getString("sex").equalsIgnoreCase("2")
    } catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isFemale:" + e.printStackTrace(), "FAIL")
      }
    }
    isElementExist;
  }
  /**
    *This function verifies the gender is isMale.
    * @param visit current visit of the patient.
    * @param m Measure Property of the measure.
    * @return
    */
  def isMale(visit: CassandraRow, m: MeasureProperty): Boolean = {
    var isElementExist = false
    try {
      isElementExist= !visit.isNullAt("sex") && visit.getString("sex").equalsIgnoreCase("1")
    } catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isMale:" + e.printStackTrace(), "FAIL")
      }
    }
    isElementExist;
  }

/*  /**
    *
    * @param rdd history rdd
    * @param m measure name and condition type
    * @param elementCount number of element count
    * @param elementNames name of elements
    * @return
    */
  def countElement(rdd: RDD[CassandraRow], m: MeasureProperty,elementCount: Int,elementNames: Seq[String]): Array[String] = {
    val patientVisit:Array[String]=rdd.filter(r=> {
      elementNames.filter(element => !r.isNullAt(element)).size>0
    }).map(r=>(r.getString("patientuid"),1)).reduceByKey((x,y)=>x+y).filter(r=>r._2 >= elementCount).map(r=>r._1).collect()
    patientVisit
  }*/

  /**
    *
    * @param r   Current visit of the patient
    * @param measureProperty Measure Property of the measure
    * @param equalFlag  Equal flag is for checking the condition greaterorEqual or greater condition.
    * @param compareMonth number of months that to be compared.
    * @return
    */
  def isAgeAboveInMonth(r: CassandraRow, measureProperty: MeasureProperty,equalFlag:Boolean, compareMonth: Int): Boolean = {
    var isExist = false

    try {
      var eDate = ""
      if (!r.isNullAt("encounterdate")) {
        eDate = convertDateToDDMMYYYY(r.getDate("encounterdate").toString)
      } else {
        eDate = "encounterdate"
      }
      var sDate = ""
      if (!r.isNullAt("dob")) {
        sDate = convertDateToDDMMYYYY(r.getDate("dob").toString)
      } else {
        sDate = "dob"
      }

      if(equalFlag)
        isExist = !r.isNullAt("dob") && !r.isNullAt("encounterdate") && dateUtility.getMonthDiff(r.getDate("dob"),r.getDate("encounterdate")) >= compareMonth

      else
        isExist = !r.isNullAt("dob") && !r.isNullAt("encounterdate") && dateUtility.getMonthDiff(r.getDate("dob"),r.getDate("encounterdate")) > compareMonth
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeAboveInMonth:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }

  def isDateInBeween(visit:CassandraRow,m:MeasureProperty,elementDate:String,edvisitArrivalDate:String,edvisitDepartureDate:String):Boolean={
    var isExist= false
    try{
      isExist = !visit.isNullAt(elementDate) && !visit.isNullAt(edvisitArrivalDate) && !visit.isNullAt(edvisitArrivalDate) &&
        (
          visit.getDateTime(elementDate).equals(visit.getDateTime(edvisitArrivalDate)) || visit.getDateTime(elementDate).equals(visit.getDateTime(edvisitDepartureDate))
            ||
            (
              visit.getDateTime(elementDate).isAfter(visit.getDateTime(edvisitArrivalDate)) && visit.getDateTime(elementDate).isBefore(visit.getDateTime(edvisitDepartureDate))
              )
          )
      val argsArray: Array[String] = Array(elementDate,edvisitArrivalDate,edvisitDepartureDate)
      measureLogger(visit, m, "isAgeBetween", elementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDateInBeween:" + e.printStackTrace(), "FAIL")

      }
    }
    isExist
  }

  /**
    *
    * @param visit current patient visit
    * @param m measureperperty
    * @param element1 get element 1
    * @param value get element value
    * @return yes nad no based on isPhysicalExamPerformedValueLessThanOnEncounter
    */

  def isPhysicalExamPerformedValueLessThanOnEncounter(visit:CassandraRow, m:MeasureProperty,element1:String,value:Double):Boolean= {
    if ( !visit.isNullAt(element1) && visit.getDouble(element1) < value && isDateEqual(visit, m, element1+"_date", "encounterdate") )
      true
    else
      false
  }

  //Function needs to add in the measureutility.
  // function for isDateEqual
  def isDateTimeEqual(r: CassandraRow, m:MeasureProperty, firstDate: String, compareDate: String): Boolean = {
    var isExist = false
    try {
      var cDate = ""
      if (!r.isNullAt(compareDate)) {
        cDate = convertDateToDDMMYYYY(r.getDate(compareDate).toString)
      } else {
        cDate = compareDate
      }
      var fDate = ""
      if (!r.isNullAt(firstDate)) {
        fDate = convertDateToDDMMYYYY(r.getDate(firstDate).toString)
      } else {
        fDate = firstDate
      }

      isExist = !r.isNullAt(firstDate) && !r.isNullAt(compareDate) && (r.getDateTime(firstDate).equals(r.getDateTime(compareDate)))


      val argsArray: Array[String] = Array(fDate, cDate)
      measureLogger(r, m, "isDateTimeEqual", fDate, isExist, argsArray)

    }
    catch {
      case e: Exception => {
       // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDateTimeEqual:" + e.printStackTrace(), "FAIL")

      }
    }
    isExist;
  }

  /**
    * This function verifies the Blood pressure of the patient is in control on the current encounter.
    * @param currentVisit    Current visit of the patient.
    * @param measureProperty Measure property of the Measure
    * @param Element1        Element1 whose value  has to be verified.
    * @param Element2        Element2 whose value  has to be verified.
    * @param lowerValue      Lower value with that Element1 value has to be verified.
    * @param upperValue      Upper value with that Element2 value has to be verified.
    * @return This fuction will return those patient whose element value is less than
    */
  def  isBloodPressureInControl(currentVisit: CassandraRow, measureProperty: MeasureProperty, Element1: String,Element2: String, lowerValue: Double, upperValue: Double): Boolean = {
    var isExist = false
    try{
      val Element1Date=Element1+"_date"
      val Element2Date=Element2+"_date"

      isExist= (!currentVisit.isNullAt(Element1) && isDateEqual(currentVisit,measureProperty,Element1Date,"encounterdate") && currentVisit.getDouble(Element1)<lowerValue ) &&
        (  !currentVisit.isNullAt(Element2)  &&  isDateEqual(currentVisit,measureProperty,Element2Date,"encounterdate")  &&  currentVisit.getDouble(Element2)<upperValue)

      val argsArray: Array[String] = Array(Element1,upperValue.toString,Element2,lowerValue.toString)
      measureLogger(currentVisit, measureProperty, "isBloodPressureInControl",Element1,isExist,argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isBloodPressureInControl:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    * This function verifies the isDiagnosisDuringEncounter
    * @param visit                Current Visit of the patient.
    * @param m                    Measure Property of the Measure.
    * @param element              Element whose LaboratoryTestOrder is to be checked.
    * @param edvisitArrivalDate   edVisitarrivalDate of the patient.
    * @param edvisitDepartureDate edvisitDepartureDate of the patient.
    * @param crtclDate            crtclDate of the patient.
    * @return
    */
  def isDiagnosisDuringEncounter(visit: CassandraRow, m: MeasureProperty, element: String,  posElement:String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {

    val elementDate:String=element+"_date"
    val posElementDate:String = posElement+"_date"

    (
      (checkElementPresent(visit, m, element) &&

        (
          isDateInBeween(visit, m, elementDate, edvisitArrivalDate, edvisitDepartureDate)
            ||
            isDateTimeEqual(visit, m, elementDate, crtclDate)
          )
        )

        &&

        (checkElementPresent(visit, m, posElement) &&

          (
            isDateInBeween(visit, m, posElementDate, edvisitArrivalDate, edvisitDepartureDate)
              ||
              isDateTimeEqual(visit, m, posElementDate, crtclDate)
            )
          )
      )

  }








}