
package com.figmd.janus.measureComputation.qpp.aao

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.{Measure, MeasureUpdate}
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.measureComputation.qpp.aao.Qpp119.{getExclusionRdd, getMet, getSubtractRDD}
import org.apache.spark.broadcast.Broadcast
//import com.figmd.janus.measureComputation.qppMeasures.QPP326.isDateEqual
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Qpp326 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp326"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, rdd:RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getElementHistory(sparkSession,ElementMaster.Nonvalvular_Atrial_Fibrillation_Or_Atrial_Flutter,ElementMaster.Pneumonia,ElementMaster.Hyperthyroidism,ElementMaster.Pregnancy_Qpp326,ElementMaster.Cardiac_Surgery,ElementMaster.Transient_Or_Reversible_Cause_Of_Af,ElementMaster.Hospice_Services_SNOMEDCT,ElementMaster.Hospice_Care,ElementMaster.Palliative_Care,ElementMaster.Palliative_care_encounter,ElementMaster.Prescription_For_Warfarin,ElementMaster.Prescription_For_Warfarin_Documentation_Grp,ElementMaster.Warfarin_Prescription).collect.toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(rdd,patientHistoryList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    // Eligible IPP
    val eligibleRdd = sparkSession.sparkContext.emptyRDD[CassandraRow]
    eligibleRdd.cache()

    // Filter Exclusions
    val notEligibleRDD =sparkSession.sparkContext.emptyRDD[CassandraRow]
    notEligibleRDD.cache()

    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,patientHistoryList: Broadcast[List[CassandraRow]])
    exclusionRDD.cache()
    // Filter Intermediate

    val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA,patientHistoryList: Broadcast[List[CassandraRow]])
    metRDD.cache()
    //for Exception B required
    val intermediateB =  getinterRDD(intermediateA,metRDD)
    // Filter Exceptions
    val exceptionRDD = getException(intermediateB)
    // Filter not met
    val notMetRDD =  getinterRDD(intermediateB,exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }
  // Filter IPP
  def getIpp(rdd:RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP)

    rdd.filter(visit => isPatientAdult(visit, m)
      &&

      isVisitTypeIn(visit,m,ElementMaster.Initial_Nursing_Facility,ElementMaster.Nursing_Facility_Visit_QPP326,ElementMaster.Office_Visit,ElementMaster.emergency_department_visit,ElementMaster.care_services_in_long_term_residential_facility,ElementMaster.home_healthcare_services)
&&
       isVisitTypeIn(visit,m,ElementMaster.Initial_Nursing_Facility,ElementMaster.Nursing_Facility_Visit_QPP326,ElementMaster.Office_Visit,ElementMaster.emergency_department_visit,ElementMaster.care_services_in_long_term_residential_facility,ElementMaster.home_healthcare_services)


      &&
      isDiagnosedWithBeforeOrEqual(visit,m,ElementMaster.Encounter_Date,ElementMaster.Nonvalvular_Atrial_Fibrillation_Or_Atrial_Flutter,patientHistoryList)

      &&
      !isTelehealthEncounterNotPerformed(visit,m,ElementMaster.Emergency_Department_Visit_Telehealth_Modifier,ElementMaster.Initial_Nursing_Facility_Telehealth_Modifiers,ElementMaster.Domiciliary_or_rest_home_visit_Telehealth_Modifier,ElementMaster.Office_Visit_Telehealth_Modifier,ElementMaster.Home_Healthcare_Services_Telehealth_Modifier,ElementMaster.Nursing_Facility_Visit_Telehealth_Modifier)

      &&

      isPOSEncounterNotPerformed(visit,m,ElementMaster.POS_02)
    )
  }

  //Exclusion

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCLUSION)

    ippRDD.filter(visit =>

      (isDiagnosedWithBeforeOrEqual(visit,m,ElementMaster.Encounter_Date,ElementMaster.Pneumonia,patientHistoryList)
        ||
        isDiagnosedWithBeforeOrEqual(visit,m,ElementMaster.Encounter_Date,ElementMaster.Hyperthyroidism,patientHistoryList)
        ||
        isDiagnosedWithBeforeOrEqual(visit,m,ElementMaster.Encounter_Date,ElementMaster.Pregnancy_Qpp326,patientHistoryList)
        ||
        isDiagnosedWithBeforeOrEqual(visit,m,ElementMaster.Encounter_Date,ElementMaster.Cardiac_Surgery,patientHistoryList)
        ||
        isAssessmentPerformedBefore(visit,m,ElementMaster.Encounter_Date,ElementMaster.Transient_Or_Reversible_Cause_Of_Af,patientHistoryList))

        || (isInterventionPerformedBeforeEnd(visit,m,ElementMaster.Hospice_Services_SNOMEDCT,patientHistoryList)
        ||
        isInterventionPerformedBeforeEnd(visit,m,ElementMaster.Hospice_Care,patientHistoryList)
        ||
        isInterventionPerformedBeforeEnd(visit,m,ElementMaster.Palliative_Care,patientHistoryList)
        ||
        isInterventionPerformedBeforeEnd(visit,m,ElementMaster.Palliative_care_encounter,patientHistoryList)
        )
        || intervention_Performed(visit,m,ElementMaster.Comfort_Care)
        || getCHA2DS2_VASc(visit,m,ElementMaster.Heart_Failure,ElementMaster.Hypertension,ElementMaster.Diabetes_Mellitus,ElementMaster.Prior_Stroke,ElementMaster.Vascular_Disease,ElementMaster.Sex) <=1
        || isAssessmentPerformedOnEncounter(visit,m,ElementMaster.Cha2ds2_Vasc_Hcpcs)
        ||(isAssessmentValueLessOrEqualDuringEncounter(visit,m,ElementMaster.Cha2ds2_Vasc_Risk_Score,1)
        &&
        isAssessmentPerformedOnEncounter(visit,m,ElementMaster.Cha2ds2_Vasc_Risk_Score)
        )
    )

  }

  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET)

    intermediateA.filter(visit =>
      (
        InterventionPerformedInHistory(visit,m,ElementMaster.Prescription_For_Warfarin,patientHistoryList)
          ||
          InterventionPerformedInHistory(visit,m,ElementMaster.Prescription_For_Warfarin_Documentation_Grp,patientHistoryList)
          ||
          isMedicationPerformedInHistory(visit,m,ElementMaster.Warfarin_Prescription,patientHistoryList)
        )

    )
  }


  def getException(intermediateB:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCEPTION)

    intermediateB.filter(visit =>

      (interventionNotPerformedDuringEncounter(visit,m,ElementMaster.Presc_Warf_Medical_Reason)
        ||
        interventionNotPerformedDuringEncounter(visit,m,ElementMaster.Medical_Reason_Qpp326)
        ||
        interventionNotPerformedDuringEncounter(visit,m,ElementMaster.Presc_Warf_Patient_Reason)
        ||
        interventionNotPerformedDuringEncounter(visit,m,ElementMaster.Patient_Reason)
        ||
        interventionNotPerformedDuringEncounter(visit,m,ElementMaster.Af_System_Reason)
        ||
        interventionNotPerformedDuringEncounter(visit,m,ElementMaster.System_Reason)

        )
    )
  }

}
