package com.figmd.measures.test.functions

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.WebDataMartCreator.prop
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import com.figmd.measures.test.utils.TestUtil.spark._
import org.scalatest.FunSuite

class MeasureUtilityUpdate_Test extends FunSuite{

  val m = MeasureProperty("M68", "IPP")
  prop.setProperty("quarterStartDate","2018-01-01")
  prop.setProperty("quarterEndDate","2018-03-31")
  val mu:MeasureUtilityUpdate=new MeasureUtilityUpdate()


  //isVisitTypeIn
  test("ItShouldReturnTrueIfAnyVisitTypePerformed"){
    val visit= CassandraRow.fromMap(Map("patientuid"->"p1","visituid"->"v1","dob"->"1975-08-19 00:00:00.000+00:00","encounterdate"->"2018-08-19 00:00:00.000+00:00","ofvi_1"->"1","ofvi_1_date"->"2018-08-19 00:00:00.000+00:00","hohese"->"1","hohese_date"->"2018-08-19 00:00:00.000+00:00","anwevi_1"->"1","anwevi_1_date"->"2018-08-19 00:00:00.000+00:00","prcaseofvi18anup_1"->null,"prcaseofvi18anup_1_date"->null,"prcaseesofvi18anup_1"->null,"prcaseesofvi18anup_1"->null,"fain"->null,"fain_date"->null))
    val actualResult=mu.isVisitTypeIn(visit,m,ElementMaster.Office_Visit,ElementMaster.Home_Healthcare_Services,ElementMaster.Annual_Wellness_Visit,ElementMaster.Preventive_Care_Services_Initial_Office_Visit_18_and_Up,ElementMaster.Preventive_Care_Services_Established_Office_Visit_18_and_Up,ElementMaster.Face_To_Face_Interaction)
    assert(actualResult === true)
  }

  //isVisitTypeIn
  test("ItShouldReturnFalseIfAnyVisitTypePerformed"){
    val visit= CassandraRow.fromMap(Map("patientuid"->"p1","visituid"->"v1","dob"->"1975-08-19 00:00:00.000+00:00","encounterdate"->"2018-08-19 00:00:00.000+00:00","ofvi_1"->null,"ofvi_1_date"->"2018-08-19 00:00:00.000+00:00","hohese"->null,"hohese_date"->"2018-08-19 00:00:00.000+00:00","anwevi_1"->null,"anwevi_1_date"->"2018-08-19 00:00:00.000+00:00","prcaseofvi18anup_1"->null,"prcaseofvi18anup_1_date"->null,"prcaseesofvi18anup_1"->null,"prcaseesofvi18anup_1"->null,"fain"->null,"fain_date"->null))
    val actualResult=mu.isVisitTypeIn(visit,m,ElementMaster.Office_Visit,ElementMaster.Home_Healthcare_Services,ElementMaster.Annual_Wellness_Visit,ElementMaster.Preventive_Care_Services_Initial_Office_Visit_18_and_Up,ElementMaster.Preventive_Care_Services_Established_Office_Visit_18_and_Up,ElementMaster.Face_To_Face_Interaction)
    assert(actualResult === false)
  }

  test("ItShouldReturnTrueIfPatientIsAdult"){
    val visit= CassandraRow.fromMap(Map("patientuid"->"p1","visituid"->"v1","dob"->"1975-08-19 00:00:00.000+00:00","encounterdate"->"2018-08-19 00:00:00.000+00:00"))
    val actualResult=mu.isPatientAdult(visit,m)
    assert(actualResult === true)
  }

  test("ItShouldReturnTrueIfPatientIsNotAdult"){
    val visit= CassandraRow.fromMap(Map("patientuid"->"p1","visituid"->"v1","dob"->"2015-08-19 00:00:00.000+00:00","encounterdate"->"2018-08-19 00:00:00.000+00:00"))
    val actualResult=mu.isPatientAdult(visit,m)
    assert(actualResult === false)
  }

  test("ItShouldReturnTrueIfPatientIsElder"){
    val visit= CassandraRow.fromMap(Map("patientuid"->"p1","visituid"->"v1","dob"->"1950-08-19 00:00:00.000+00:00","encounterdate"->"2018-08-19 00:00:00.000+00:00"))
    val actualResult=mu.isPatientElderly(visit,m)
    assert(actualResult === true)
  }

  test("ItShouldReturnTrueIfPatientIsNotElder"){
    val visit= CassandraRow.fromMap(Map("patientuid"->"p1","visituid"->"v1","dob"->"2015-08-19 00:00:00.000+00:00","encounterdate"->"2018-08-19 00:00:00.000+00:00"))
    val actualResult=mu.isPatientElderly(visit,m)
    assert(actualResult === false)
  }

  test("ItShouldReturnTrueIfInterventionWasPerformedInHistory"){

    val patientHistoryList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "ditohofohoca", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    )

    val visit= CassandraRow.fromMap(Map("patientuid"->"P1","visituid"->"v1","dob"->"2015-08-19 00:00:00.000+00:00","encounterdate"->"2018-08-19 00:00:00.000+00:00","ditohofohoca"->"1","ditohofohoca_date"->"1985-04-20 00:00:00.000+00:00"))
    val actualResult=mu.wasInterventionPerformedOrOrderedInHistory(visit,m,ElementMaster.Discharged_To_Home_For_Hospice_Care,sparkContext.broadcast(patientHistoryList))
    assert(actualResult===true)
  }


  test("ItShouldReturnFalseIfInterventionWasNotPerformedInHistory"){

    val patientHistoryList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P6", "element" -> "ditohofohoca", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    )
    val visit= CassandraRow.fromMap(Map("patientuid"->"P1","visituid"->"v1","dob"->"2015-08-19 00:00:00.000+00:00","encounterdate"->"2018-08-19 00:00:00.000+00:00","ditohofohoca"->"1","ditohofohoca_date"->"1985-04-20 00:00:00.000+00:00"))
    val actualResult=mu.wasInterventionPerformedOrOrderedInHistory(visit,m,ElementMaster.Discharged_To_Home_For_Hospice_Care,sparkContext.broadcast(patientHistoryList))
    assert(actualResult===false)
  }

  test("ItShouldReturnTrueIfEncounterIsPerformed"){

    val patientHistoryList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "ditohofohoca", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    )

    val visit= CassandraRow.fromMap(Map("patientuid"->"P1","visituid"->"v1","dob"->"2015-08-19 00:00:00.000+00:00","encounterdate"->"2018-08-19 00:00:00.000+00:00","ditohofohoca"->"1","ditohofohoca_date"->"1985-04-20 00:00:00.000+00:00"))
    val actualResult=mu.isEncounterPerformed(visit,m,ElementMaster.Discharged_To_Home_For_Hospice_Care,sparkContext.broadcast(patientHistoryList))
    assert(actualResult===true)
  }


  test("ItShouldReturnFalseIfEncounterIsNotPerformed"){

    val patientHistoryList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "ditohofohoca1", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    )
    val visit= CassandraRow.fromMap(Map("patientuid"->"P1","visituid"->"v1","dob"->"2015-08-19 00:00:00.000+00:00","encounterdate"->"2018-08-19 00:00:00.000+00:00","ditohofohoca"->"1","ditohofohoca_date"->"1985-04-20 00:00:00.000+00:00"))
    val actualResult=mu.isEncounterPerformed(visit,m,ElementMaster.Discharged_To_Home_For_Hospice_Care,sparkContext.broadcast(patientHistoryList))
    assert(actualResult===false)
  }


  test("ItShouldReturnTrueIfProcedureIsPerformed"){

    val patientHistoryList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "pnvaad", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    )

    val visit= CassandraRow.fromMap(Map("patientuid"->"P1","visituid"->"v1","dob"->"2015-08-19 00:00:00.000+00:00","encounterdate"->"2018-08-19 00:00:00.000+00:00","ditohofohoca"->"1","ditohofohoca_date"->"1985-04-20 00:00:00.000+00:00"))
    val actualResult=mu.isProcedurePerformed(visit,m,ElementMaster.Pneumococcal_Vaccine_Administered,sparkContext.broadcast(patientHistoryList))
    assert(actualResult===true)
  }


  test("ItShouldReturnFalseIfProcedureIsNotPerformed"){

    val patientHistoryList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "pnvaad1", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    )
    val visit= CassandraRow.fromMap(Map("patientuid"->"P1","visituid"->"v1","dob"->"2015-08-19 00:00:00.000+00:00","encounterdate"->"2018-08-19 00:00:00.000+00:00","ditohofohoca"->"1","ditohofohoca_date"->"1985-04-20 00:00:00.000+00:00"))
    val actualResult=mu.isProcedurePerformed(visit,m,ElementMaster.Pneumococcal_Vaccine_Administered,sparkContext.broadcast(patientHistoryList))
    assert(actualResult===false)
  }

}
