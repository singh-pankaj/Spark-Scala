package com.figmd.measures.test.functions

import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.{DateTimeFormatter, DateTimeParseException}
import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.WebDataMartCreator.prop
import com.figmd.janus.util.application.{DateUtility, FileUtility}
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat
import org.junit.Assert.{assertEquals, assertFalse, assertTrue}
import org.junit.Test

import scala.util.Try

class DateFunctions_Test {

  val fileUtility = new FileUtility();
  val startDate = "2018-01-01"
  val endDate = "2018-03-31"
  val dateFormat = "yyyy-MM-dd"
  val dateTimeFormat = "yyyy-MM-dd HH:mm:ss"
  val sdf=new SimpleDateFormat(dateFormat)
  prop.setProperty("quarterStartDate","2018-01-01")
  prop.setProperty("quarterEndDate","2018-03-31")
  val dateUtility:DateUtility=new DateUtility()


  //  final var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
  @transient lazy val DATE_FORMAT = DateTimeFormatter.ofPattern(dateFormat)
  @transient lazy val DATE_TIME_FORMAT = DateTimeFormatter.ofPattern(dateTimeFormat)
  @transient lazy val DATE_TIME_FORMAT_EEE = DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")
  val now = LocalDateTime.now().format(DATE_TIME_FORMAT)
  val today = LocalDateTime.now().format(DATE_FORMAT)


  @Test
  def itShouldReturnStartDateForProperDateStingInput: Unit ={
    val actualResult:Date=dateUtility.getStart()
    val expectedResult=sdf.parse("2018-01-01")
    assertEquals(expectedResult,actualResult)
  }

  @Test
  def itShouldReturnEndDateForProperDateStingInput: Unit ={
    val actualResult:Date=dateUtility.getEndDate()
    val expectedResult=sdf.parse("2018-03-31")
    assertEquals(expectedResult,actualResult)
  }

  @Test
  def itShouldParseProperInputStringToDate: Unit ={
    //dateParse
    val actualResult:Date=dateUtility.dateParse("2018-01-01")
    val expectedResult=sdf.parse("2018-01-01")
    assertEquals(expectedResult,actualResult)
  }

  @Test(expected = classOf[java.text.ParseException])
  def itShouldThroughExceptionForWrongInputDateString: Unit ={
    //dateParse
    val actualResult:Date=dateUtility.dateParse("abc-01-01")
    val expectedResult=sdf.parse("2018-01-01")
    assertEquals(expectedResult,actualResult)
  }

  /*@Test
  def itShouldParseProperInputStringToTimestamp: Unit ={
    //dateParse
    val actualResult:DateTime=dateUtility.dateTimeParse("2018-01-01 12:12:12")
    val expectedResult=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("2018-01-01 00 12:12:12")
    assertEquals(expectedResult,actualResult)
  }

  @Test(expected = classOf[java.text.ParseException])
  def itShouldThroughExceptionForWrongInputTimeStampString: Unit ={

    val actualResult:Date=dateUtility.dateParse("01-01-2018")
    val expectedResult=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("abc-01-01 00:00:00")
    assertEquals(expectedResult,actualResult)
  }*/


  @Test
  def itShouldReturnDaysDifferenceBetweenTwoDate(): Unit =
  {
    val endDate=sdf.parse("2018-03-31")
    val expectedResult:Long=30L
    val startDate="2018-03-01"
    val actualResult:Long=dateUtility.getDaysDiffForDateType(startDate,endDate)
    assertEquals(expectedResult,actualResult)
  }

  @Test(expected = classOf[java.text.ParseException])
  def itShouldThrowExceptionForDaysDifferenceBetweenTwoDateForWrongInputDateString(): Unit =
  {
    val endDate=sdf.parse("2018-03-31")
    val expectedResult:Long=30L
    val startDate="abc-03-01"
    val actualResult:Long=dateUtility.getDaysDiffForDateType(startDate,endDate)
    assertEquals(expectedResult,actualResult)
  }

  @Test
  def itShouldReturnDaysDifferenceBetweenTwoDateString(): Unit =
  {
    val endDate="2018-03-31"
    val startDate="2018-03-01"
    val actualResult=dateUtility.getDateDiff1(startDate,endDate)
    assertTrue(actualResult)
  }

  @Test(expected = classOf[java.text.ParseException])
  def itShouldThrowExceptionForDaysDifferenceBetweenTwoDateForWrongInputDateString2(): Unit = {
    val endDate = "2018-03-31"
    val startDate = "abc-03-01"
    val actualResult = dateUtility.getDateDiff1(startDate, endDate)
    assertTrue(actualResult)
  }

  @Test
  def itShouldCheckIfTwoDatesAreEqual(): Unit ={
    val startDate="2018-01-01"
    val endDate="2018-01-01"
    assertTrue(isParsing(startDate))
    assertTrue(isParsing(endDate))
    val actualResult:Boolean=dateUtility.chkDateEqual(startDate,endDate);

    assertTrue(actualResult)
  }

  @Test
  def itShouldCheckIfTwoDatesAreNotEqual(): Unit ={
    val startDate="2018-01-01"
    val endDate="2018-01-02"
    val actualResult:Boolean=dateUtility.chkDateEqual(startDate,endDate);
    assertTrue(isParsing(startDate))
    assertTrue(isParsing(endDate))
    assertFalse(actualResult)
  }

  @Test
  def itShouldCheckAgeForGivenDOBString(): Unit ={
    val dob:String="22-10-2015"
    val expectedResult=3L
    val actualResult=dateUtility.getAge(dob)
    assertEquals(expectedResult,actualResult)
  }

  @Test(expected = classOf[DateTimeParseException])
  def itShouldThrowExceptionForInvalidDOBString(): Unit ={
    val dob:String="22abc-10-2015"
    val expectedResult=3L
    val actualResult=dateUtility.getAge(dob)
    assertEquals(expectedResult,actualResult)
  }

  /*
    @Test
    def itShouldCheckAgeForGivenDOBAndArrivalDateStrings(): Unit ={
      val dob:String="2015-10-22"
      val arrivalDate:String="2018-10-22"
      val expectedResult=3L
      val actualResult=dateUtility.getAge(dob,arrivalDate)
      assertEquals(expectedResult,actualResult)
    }
  */

  @Test
  def itShouldCheckAgeForGivenDOBAndArrivalDateStrings(): Unit ={
    val dob:String="2015-10-22"
    val expectedResult=3.00084
    val arrival_date="2018-10-22"
    val actualResult=dateUtility.getAge(dob,arrival_date)
    assertEquals(expectedResult,actualResult,00084f)
  }



  @Test
  def itShouldCheckDaysDiffBetweenTwoDates(): Unit ={
    //getDaysDiff
    val expectedResult=31L
    val startDate="2018-05-10"
    val endDate="2018-06-10"
    assertTrue("Parsing string to date : ",isParsing(startDate))
    assertTrue("Parsing string to date : ",isParsing(endDate))
    val actualResult= dateUtility.getDaysDiff(startDate,endDate)
    assertEquals(expectedResult,actualResult)
  }


  @Test(expected = classOf[java.text.ParseException])
  def itShouldCheckDaysDiffBetweenTwoDatesForInvalidDateString(): Unit ={

    val expectedResult=31L
    val startDate="abc-05-10"
    val endDate="2018-06-10"
    val actualResult= dateUtility.getDaysDiff(startDate,endDate)
    assertEquals(expectedResult,actualResult)
  }

  @Test
  def itShouldCheckMinutesDiffBetweenTwoDates(): Unit ={
    //getDaysDiff
    val expectedResult=50L
    val startDate="2018-05-10 12:00:00"
    val endDate="2018-05-10 12:50:00"
    assertTrue("Parsing string to date : ",isParsing(startDate))
    assertTrue("Parsing string to date : ",isParsing(endDate))
    val actualResult= dateUtility.getMinutesDiff(startDate,endDate)
    assertEquals(expectedResult,actualResult)
  }


  @Test(expected = classOf[java.text.ParseException])
  def itShouldThrowExceptionForInvalidDateString(): Unit ={
    //getDaysDiff
    val expectedResult=31L
    val startDate="abc-05-10 12:00:00"
    val endDate="2018-05-10 12:50:00"
    /*  assertTrue("Parsing string to date :",isParsing(startDate))
      assertTrue("Parsing string to date : ",isParsing(endDate))*/
    val actualResult= dateUtility.getMinutesDiff(startDate,endDate)
    assertEquals(expectedResult,actualResult)
  }

/*
  @Test
  def itShouldCheckHoursDiffBetweenTwoDateTimes(): Unit ={
    //getDaysDiff
    val expectedResult=12L
    val startDate="2018-05-10 00:00:00"
    val endDate="2018-05-10 12:00:00"
    assertTrue("Parsing string to date : ",isParsing(startDate))
    assertTrue("Parsing string to date : ",isParsing(endDate))
    val actualResult= dateUtility.getDateDiffInHours(startDate,endDate)
    assertEquals(expectedResult,actualResult)
  }
*/


  /*@Test(expected = classOf[java.text.ParseException])
  def itShouldThrowExceptionForInvalidDateTimeString(): Unit ={
    //getDaysDiff
    val expectedResult=12L
    val startDate="abc-05-10 12:00:00"
    val endDate="2018-05-10 12:50:00"
    /* assertTrue("Parsing string to date :",isParsing(startDate))
     assertTrue("Parsing string to date : ",isParsing(endDate))*/
    val actualResult= dateUtility.getDateDiffInHours(startDate,endDate)
    assertEquals(expectedResult,actualResult)
  }
*/

  @Test
  def itShouldCheckHoursDiffLessToHours(): Unit ={
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","startDate"->"2018-02-20 00:00:00.000+00:00","endDate"->"2018-02-21 00:00:00.000+00:00"))
    val actualResult= dateUtility.get_DateDiffHours_lessthan(cr.getDateTime("startDate"),cr.getDateTime("endDate"),25)
    assertTrue(actualResult)
  }

  @Test
  def itShouldCheckHoursDiffNotLessToHours(): Unit ={
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","startDate"->"2018-02-20 00:00:00.000+00:00","endDate"->"2018-02-21 00:00:00.000+00:00"))
    val cr1:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","startDate"->"2018-02-20 00:00:00.000+00:00","endDate"->"2018-02-21 00:00:00.000+00:00"))
    val expectedResult=24L
    val actualResult= dateUtility.get_DateDiffHours_lessthan(cr.getDateTime("startDate"),cr.getDateTime("endDate"),20)
    val actualResult1= dateUtility.get_DateDiffHours_lessthan(cr.getDateTime("startDate"),cr.getDateTime("endDate"),24)
    assertFalse(actualResult)
    assertFalse(actualResult1)
  }

  @Test
  def itShouldParseDateTimeStringToDateTimeWithTimeZone(): Unit ={
    //2018-04-25T14:05:15.953Z
    val formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ssZ");
    val expectedResult:DateTime = formatter.parseDateTime("2000-01-05 20:30:00+05:30");
    val actualResult=dateUtility.dateTimeParse("2000-01-05 20:30:00+05:30")
    assertEquals(expectedResult,actualResult)
  }

  @Test(expected = classOf[IllegalArgumentException])
  def itShouldThrowExceptionForBadDateTimeWithTimeZone(): Unit ={
    //2018-04-25T14:05:15.953Z
    val formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ssZ");
    val expectedResult:DateTime = formatter.parseDateTime("2000-01-05 20:30:00+05:30");
    val actualResult=dateUtility.dateTimeParse("abc2000-01-05 20:30:00+05:30")
    assertEquals(expectedResult,actualResult)
  }

  @Test
  def itShouldParseDateTimeStringToDateTime(): Unit ={

    val formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
    val expectedResult:DateTime = formatter.parseDateTime("2000-01-05 20:30:00");
    val actualResult=dateUtility.dateTimeParse1("2000-01-05 20:30:00")
    assertEquals(expectedResult,actualResult)
  }

  @Test(expected = classOf[IllegalArgumentException])
  def itShouldThrowExceptionForBadDateTime(): Unit ={

    val formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
    val expectedResult:DateTime = formatter.parseDateTime("2000-01-05 20:30:00");
    val actualResult=dateUtility.dateTimeParse1("abc2000-01-05 20:30:00")
    assertEquals(expectedResult,actualResult)
  }

  def isParsing(inputValue:String): Boolean ={
    Try(sdf.parse(inputValue)).isSuccess
  }

}
