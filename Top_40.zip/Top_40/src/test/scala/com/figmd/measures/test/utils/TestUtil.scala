package com.figmd.measures.test.utils

import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.util.application.FileUtility
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


object TestUtil {

  val spark: SparkSession = SparkSession.builder()
    .master("local")
    .appName("testing")
    .config("spark.cassandra.connection.host", "18.216.196.168")
    .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    .config("spark.io.compression.codec", "snappy")
    .config("spark.sql.warehouse.dir", "file:///tmp")
    .getOrCreate()



  def getCassandraEncounterRDD(measureName: String, keyspace: String, table: String): RDD[CassandraRow] = {
    val cols = new FileUtility().getProperty(s"measure.$measureName.element.select").split(",").map(field => toNamedColumnRef(field))
    val cassandraRDD: RDD[CassandraRow] = spark.sparkContext.cassandraTable(keyspace, table).select(cols: _*)
    cassandraRDD
  }


  def getCassandraPatientHistoryRDD(keyspace: String, table: String,elements:String*): RDD[CassandraRow] = {
    val historyRDD:RDD[CassandraRow] = spark.sparkContext.cassandraTable(keyspace,table).select("patientuid", "element", "element_date","elementvalue")
      .filter(historyVisit => !historyVisit.isNullAt("patientuid") && !historyVisit.isNullAt("element")&& !historyVisit.isNullAt("element_date") && elements.contains((historyVisit.getString("element")).toLowerCase()))
    historyRDD
  }


  def getCassandraEncounterRDD(measureName:String): RDD[CassandraRow] ={
    generateCassandraRDD(measureName,"TblEncounter")
  }

  def getCassandraPatientHistoryRDD(measureName:String,elements:String*): RDD[CassandraRow] = {
    val rdd:RDD[CassandraRow]=generateCassandraRDD(measureName,"Patient_History")
    val patientHistoryRDD=rdd.filter(historyVisit => !historyVisit.isNullAt("patientuid") && !historyVisit.isNullAt("element")&& !historyVisit.isNullAt("element_date") && elements.contains((historyVisit.getString("element")).toLowerCase()))

    patientHistoryRDD
  }

  def generateCassandraRDD(measureName:String,recordType:String): RDD[CassandraRow] ={
    val df=spark.read.option("header","true").csv(s"src/test/testData/${measureName}_${recordType}_TestData.csv")
    val fields=df.schema.fieldNames.map(f=>f.toLowerCase)

    val cassandraRDD:RDD[CassandraRow]=  df.rdd.map(r=> {
      CassandraRow.fromMap((fields zip r.toSeq).toMap)
    })
    cassandraRDD
  }
}