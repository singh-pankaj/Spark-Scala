package com.figmd.measures.test.functions

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.WebDataMartCreator.prop
//import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.util.measure._
import org.scalatest.{FlatSpec, FunSuite, Matchers}
import com.figmd.janus.measureComputation.master.{ElementMaster, MeasureProperty}

class MeasureUtility_Test extends FunSuite with Matchers{


  val m = MeasureProperty("M68", "IPP")
  prop.setProperty("quarterStartDate","2018-01-01")
  prop.setProperty("quarterEndDate","2018-03-31")
  val mup:MeasureUtilityUpdate=new MeasureUtilityUpdate()
  val mu:MeasureUtility= new MeasureUtility()
  val hluobj:HistoryLookUpUtility=new HistoryLookUpUtility()

  // This is True case for the isDateEqual
  test("ItShouldReturnTrueIfDateEqual"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","firstDate"->"2018-02-20 00:00:00.000","endDate"->"2018-02-20 00:00:00.000"))
    val actualResult:Boolean= mu.isDateEqual(cr,m,"firstDate","endDate")
    assert(actualResult===true)
  }

  // This is False case for the isDateEqual
  test("ItShouldReturnFalseIfDateEqual"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","firstDate"->"2018-02-20 00:00:00.000","endDate"->"2019-02-20 00:00:00.000"))
    val actualResult:Boolean= mu.isDateEqual(cr,m,"firstDate","endDate")
    assert(actualResult===false)
  }



  // This is True case for the isElementDateStartAfterStartOfWithInDays
  test("ItShouldReturnTrueforisElementDateStartAfterStartOfWithInDays"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","encounterdate"->"2018-05-26 1:45:00.000","startDate"->"2018-05-20 1:45:00.000"))
    val cr1:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","encounterdate"->"2018-05-26 1:45:00.000","startDate"->"2018-05-20 1:45:00.000"))
    val actualResult:Boolean= mu.isElementDateStartAfterStartOfWithInDays(cr,m,"encounterdate","startDate", 6)
    val actualResult1:Boolean= mu.isElementDateStartAfterStartOfWithInDays(cr, m,"encounterdate","startDate", 8)
    assert(actualResult===true)
    assert(actualResult1===true)
  }

  // This is False case for the isElementDateStartAfterStartOfWithInDays
  test("ItShouldReturnFalseforisElementDateStartAfterStartOfWithInDays"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","encounterdate"->"2018-05-26 1:45:00.000","startDate"->"2018-05-20 1:45:00.000"))
    val actualResult:Boolean= mu.isElementDateStartAfterStartOfWithInDays(cr, m,"encounterdate","startDate",2)
    assert(actualResult===false)
  }



  // This is True case for the isDateOverlapsMeasurementPeriod
  test("ItShouldReturnTrueforisDateOverlapsMeasurementPeriod")
  {
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","checkDate"->"2017-01-5 00:00:00.000","endDate"->"2008-01-1 00:00:00.000"))
    val actualResult:Boolean= hluobj.isDateOverlapsMeasurementPeriod(cr,m,"checkDate")
    assert(actualResult===true)
  }


  // This is False case for the isDateOverlapsMeasurementPeriod
  test("ItShouldReturnFalseforisDateOverlapsMeasurementPeriod")
  {
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","checkDate"->"2019-03-31 00:00:00.000","endDate"->"2008-01-1 00:00:00.000"))
    val actualResult:Boolean= hluobj.isDateOverlapsMeasurementPeriod(cr,m,"checkDate")
    assert(actualResult===false)
  }

  // This is True case for the isAgeBetween
  test("ItShouldReturnTrueForisAgeBetween"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","dob"->"2000-01-05 00:00:00.000","encounterdate"->"2008-01-01 00:00:00.000"))
    val actualResult:Boolean= mu.isAgeBetween(cr,m,2,10)
    assert(actualResult===true)
  }

  // This is False case for the isAgeBetween
  test("ItShouldReturnFalseForisAgeBetween"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","dob"->"2000-01-5 00:00:00.000","encounterdate"->"2008-01-1 00:00:00.000"))
    val actualResult:Boolean= mu.isAgeBetween(cr,m,2,5)
    assert(actualResult===false)
  }


  // This is True case for the isAgeAbove
  test("ItShouldReturnTrueForisAgeAbove"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","dob"->"1982-01-5 00:00:00.000","encounterdate"->"2008-01-1 00:00:00.000"))
    val actualResult:Boolean= mu.isAgeAbove(cr,m,true,21)
    assert(actualResult===true)
  }

  // This is False case for the isAgeAbove
  test("ItShouldReturnFalseForisAgeAbove"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","dob"->"1988-01-5 00:00:00.000","encounterdate"->"2008-01-1 00:00:00.000"))
    val actualResult:Boolean= mu.isAgeAbove(cr,m,false,21)
    assert(actualResult===false)
  }

  // This is True case for the isAgeBelow
  test("ItShouldReturnFalseForisAgeBelow"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","dob"->"1980-01-5 00:00:00.000","encounterdate"->"2008-01-1 00:00:00.000"))
    val actualResult:Boolean= mu.isAgeBelow(cr,m,true,18)
    assert(actualResult===false)
  }

  // This is True case for the isAgeBelow
  test("ItShouldReturnTrueForisAgeBelow"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"patientuid","visituid"->"v1","dob"->"1988-01-5 00:00:00.000","encounterdate"->"2008-01-1 00:00:00.000"))
    val actualResult:Boolean= mu.isAgeBelow(cr,m,false,21)
    assert(actualResult===true)
  }

  // This is True case for the checkElementPresent
  test("ItShouldReturnTrueForcheckElementPresent"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","dob"->"1980-01-5 00:00:00.000","element"->"1"))
    val actualResult:Boolean= mu.checkElementPresent(cr,m,"element")
    assert(actualResult===true)
  }
  // This is false case for the checkElementPresent
  test("ItShouldReturnfalseForcheckElementPresent"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","dob"->"1988-01-5 00:00:00.000","element"->"0"))
    val actualResult:Boolean= mu.checkElementPresent(cr,m,"element")
    assert(actualResult===false)
  }

  // This is True case for the isFemale
  test("ItShouldReturnTrueForisFemale"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","dob"->"1980-01-5 00:00:00.000","sex"->"2"))
    val actualResult:Boolean= mu.isFemale(cr,m)
    assert(actualResult===true)
  }

  // This is false case for the isFemale
  test("ItShouldReturnfalseForisFemale"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","dob"->"1988-01-5 00:00:00.000","sex"->"0"))
    val cr1:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v2","dob"->"1988-01-5 00:00:00.000","sex"->"3"))
    val actualResult:Boolean= mu.isFemale(cr,m)
    val actualResult1:Boolean= mu.isFemale(cr1,m)
    assert(actualResult===false)
    assert(actualResult1===false)
  }
  // This is True case for the isDuringInfluenzaPeriodFirstThreeMonth
  test("ItShouldReturnTrueForisDuringInfluenzaPeriodFirstThreeMonth"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","encounterdate"->"2018-01-5 00:00:00.000","sex"->"2"))
    val cr1:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","encounterdate"->"2018-03-31 00:00:00.000","sex"->"2"))
    val actualResult:Boolean= mu.isDuringInfluenzaPeriodFirstThreeMonth(cr,m,"encounterdate")
    val actualResult1:Boolean= mu.isDuringInfluenzaPeriodFirstThreeMonth(cr1,m,"encounterdate")
    assert(actualResult===true)
    assert(actualResult1===true)
  }
  // This is false case for the isDuringInfluenzaPeriodFirstThreeMonth
  test("ItShouldReturnfalseForisDuringInfluenzaPeriodFirstThreeMonth"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","encounterdate"->"2018-05-08 00:00:00.000","sex"->"0"))
    val cr1:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v2","encounterdate"->"2018-09-05 00:00:00.000","sex"->"3"))
    val actualResult:Boolean= mu.isDuringInfluenzaPeriodFirstThreeMonth(cr,m,"encounterdate")
    val actualResult1:Boolean= mu.isDuringInfluenzaPeriodFirstThreeMonth(cr1,m,"encounterdate")
    assert(actualResult===false)
    assert(actualResult1===false)
  }


  // This is True case for the isDuringInfluenzaPeriodLastThreeMonth
  test("ItShouldReturnTrueForisDuringInfluenzaPeriodLastThreeMonth"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","encounterdate"->"2018-10-01 00:00:00.000"))
    val cr1:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","encounterdate"->"2018-12-31 00:00:00.000"))
    val cr2:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","encounterdate"->"2018-10-10 00:00:00.000"))
    val actualResult:Boolean= mu.isDuringInfluenzaPeriodLastThreeMonth(cr,m,"encounterdate")
    val actualResult1:Boolean= mu.isDuringInfluenzaPeriodLastThreeMonth(cr1,m,"encounterdate")
    val actualResult2:Boolean= mu.isDuringInfluenzaPeriodLastThreeMonth(cr2,m,"encounterdate")
    assert(actualResult===true)
    assert(actualResult1===true)
    assert(actualResult2===true)
  }
  // This is false case for the isDuringInfluenzaPeriodLastThreeMonth
  test("ItShouldReturnfalseForisDuringInfluenzaPeriodLastThreeMonth"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"pp1","visituid"->"v1","encounterdate"->"2018-05-5 00:00:00.000","sex"->"0"))
    val cr1:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"pp2","visituid"->"v2","encounterdate"->"2018-09-5 00:00:00.000","sex"->"3"))
    val actualResult:Boolean= mu.isDuringInfluenzaPeriodLastThreeMonth(cr,m,"encounterdate")
    val actualResult1:Boolean= mu.isDuringInfluenzaPeriodLastThreeMonth(cr1,m,"encounterdate")
    assert(actualResult===false)
    assert(actualResult1===false)
  }

  // This is True case for the isDuringInfluenzaPeriodLastFiveMonth
  test("ItShouldReturnTrueForisDuringInfluenzaPeriodLastFiveMonth"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","encounterdate"->"2018-08-01 00:00:00.000"))
    val cr1:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","encounterdate"->"2018-12-31 00:00:00.000"))
    val cr2:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","encounterdate"->"2018-10-10 00:00:00.000"))
    val actualResult:Boolean= mu.isDuringInfluenzaPeriodLastFiveMonth(cr,m,"encounterdate")
    val actualResult1:Boolean= mu.isDuringInfluenzaPeriodLastFiveMonth(cr1,m,"encounterdate")
    val actualResult2:Boolean= mu.isDuringInfluenzaPeriodLastFiveMonth(cr2,m,"encounterdate")
    assert(actualResult===true)
    assert(actualResult1===true)
    assert(actualResult2===true)
  }
  // This is false case for the isDuringInfluenzaPeriodLastFiveMonth
  test("ItShouldReturnfalseForisDuringInfluenzaPeriodLastFiveMonth"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"pp1","visituid"->"v1","encounterdate"->"2018-05-05 00:00:00.000","sex"->"0"))
    val cr1:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"pp2","visituid"->"v2","encounterdate"->"2018-03-07 00:00:00.000","sex"->"3"))
    val actualResult:Boolean= mu.isDuringInfluenzaPeriodLastFiveMonth(cr,m,"encounterdate")
    val actualResult1:Boolean= mu.isDuringInfluenzaPeriodLastFiveMonth(cr1,m,"encounterdate")
    assert(actualResult===false)
    assert(actualResult1===false)
  }

  // This is True case for the isAgeAboveInMonth
  test("ItShouldReturnTrueForisAgeAboveInMonth"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","dob"-> "1988-08-01 00:00:00.000" ,"encounterdate"->"2018-08-01 00:00:00.000"))
    val cr1:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","dob"-> "2016-08-01 00:00:00.000" ,"encounterdate"->"2018-08-01 00:00:00.000"))
    val cr2:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","dob"-> "2017-05-01 00:00:00.000" ,"encounterdate"->"2018-08-01 00:00:00.000"))
    val actualResult:Boolean= mu.isAgeAboveInMonth(cr,m,true,15)
    val actualResult1:Boolean= mu.isAgeAboveInMonth(cr1,m,true,18)
    val actualResult2:Boolean= mu.isAgeAboveInMonth(cr2,m,false,14)
    assert(actualResult===true)
    assert(actualResult1===true)
    assert(actualResult2===true)
  }

  // This is False case for the isAgeAboveInMonth
  test("ItShouldReturnFalseForisAgeAboveInMonth"){
    val cr:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","dob"-> "2018-03-01 00:00:00.000" ,"encounterdate"->"2018-08-01 00:00:00.000"))
    val cr1:CassandraRow= CassandraRow.fromMap(Map("practiceuid"->"practiceuid1","patientuid"->"p1","visituid"->"v1","dob"-> "2017-09-01 00:00:00.000" ,"encounterdate"->"2018-08-01 00:00:00.000"))
    val actualResult:Boolean= mu.isAgeAboveInMonth(cr,m,true,10)
    val actualResult1:Boolean= mu.isAgeAboveInMonth(cr1,m,true,18)
    assert(actualResult===false)
    assert(actualResult1===false)

  }







}
