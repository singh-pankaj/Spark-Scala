package com.figmd.measures.test.measure

import java.text.SimpleDateFormat
import java.util.Date

import com.figmd.janus.measureComputation.ecqm.aao.Ecqm68v7._
import com.datastax.spark.connector.CassandraRow
import com.figmd.measures.test.utils.TestUtil
import org.apache.spark.rdd.RDD
import org.junit.{Assert, Before, Ignore, Test}

@Ignore
class Ecqm68v7_Test {

  val sdf:SimpleDateFormat= new SimpleDateFormat("yyyy-MM-dd")
  val startDate:Date= sdf.parse("2018-01-01")
  val endDate:Date=sdf.parse("2018-06-06")
  val measureName:String="M68v6"
  val keySpaceName:String="testcases"
  val tableName:String="tblencounter_m68_1"
  var inputCassandraRDD:RDD[CassandraRow]= TestUtil.spark.sparkContext.emptyRDD[CassandraRow]
  var iPPRDD:RDD[CassandraRow]= TestUtil.spark.sparkContext.emptyRDD[CassandraRow]


  @Before
  def initializingCassandraRDD(): Unit ={
    inputCassandraRDD= TestUtil.getCassandraEncounterRDD(measureName,keySpaceName,tableName)
    iPPRDD= getIpp(inputCassandraRDD).cache()
  }

  @Test
  def itShouldValidateCorrectIPP(): Unit ={

    //Given
    val expectedResult:Long= 6L

    //When

    val actualResult= iPPRDD.count()

    //Then
    Assert.assertEquals("This will check if IPP count is returned as expected",expectedResult,actualResult)

  }

  @Test
  def itShouldValidateCorrectMet():Unit={
    //Given
    val expectedResult:Long= 1L

    //When
    val metRDD:RDD[CassandraRow]=getMet(iPPRDD)
    val actualResult:Long= metRDD.count

    //Then
    Assert.assertEquals("This will check if met count is returned as expected",expectedResult,actualResult)

  }

  @Test
  def itShouldValidateCorrectExceptionRDD(): Unit ={

    //Given
    val expectedResult:Long= 1L

    //When

    val metRDD:RDD[CassandraRow]=getMet(iPPRDD)
    val intermediateRDD:RDD[CassandraRow] = getinterRDD(iPPRDD, metRDD)
    val exceptionRDD:RDD[CassandraRow]= getExceptionRDD(intermediateRDD)
    val actualResult=exceptionRDD.count()

    //Then
    Assert.assertEquals("This will check if exception count is returned as expected",expectedResult,actualResult)
  }

}
