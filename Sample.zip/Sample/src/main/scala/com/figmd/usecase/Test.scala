package com.figmd.usecase

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

import org.apache.spark.sql.functions.{lit, row_number, udf, when}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.row_number
object Test {

  val updateWithJoin = udf[String,String,String]((column1: String, column2: String) => {
    if (column1 == null) column2
    else column1
  })

  def main(args: Array[String]): Unit = {

    val spark = SparkSession
      .builder()
      .master("local[*]")
      .appName("Test")
      .getOrCreate()
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)

    import  spark.implicits._
        val file1 = spark.read.option("header","true").csv("PatInfo.csv")

        val dup =  file1.withColumn("rank", row_number().over(Window.partitionBy($"PatientId",$"SSN").orderBy($"Fname".desc)))
         .filter("rank > 1")
         .withColumn("ErrorNote",lit("Duplicate Record"))
         .withColumn("StatusId",lit(4))
         .drop("rank")

        val where = file1.filter($"PatientId".isNull || $"SSN".isNull)
          .withColumn("ErrorNote",lit("PatientId OR SSN is NUll"))
          .withColumn("StatusId",lit(3))

        val allRecords = where.union(dup)
        //allRecords.show()

        val where1 = file1.filter($"PatientId".isNull || $"SSN".isNull)
        val cleanedData = file1.except(where1)

        val file2 = spark.read.option("header","true").csv("lookup.csv")
        val df4 = spark.read.option("header","true").csv("abct.csv")

        val df5 = cleanedData.union(df4)

        val df3 = df5.as("df1").join(file2.as("df2"),Seq("PatientId"),"left_outer")
          .select($"df1.*",$"df2.SSN".as("aliasSSN"))
          .withColumn("SSN",updateWithJoin($"SSN",$"aliasSSN"))
          .drop("aliasSSN")
          .sort("PatientId")
        //df3.show(false)

    val df6 = spark.read.option("header","true").csv("emptyFile.csv")
    df6.show(false)
    val df7 =  df3.except(df6)
    df7.show(false)






  }

}