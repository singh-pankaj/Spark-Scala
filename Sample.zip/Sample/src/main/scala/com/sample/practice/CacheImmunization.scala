package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions._

class CacheImmunization {

  def ImmunizationFunc(spark : SparkSession,MergePracticeMap : DataFrame
                       ,CDRPatientCrosswalkTable : DataFrame
                       ,MultiTableExtendTable : DataFrame
                       ,distIndUid : DataFrame
                       ,distspUID : DataFrame
                       ,ViewFacility_Prod : DataFrame
                       ,PatientImmunizationTable : DataFrame
                       ,MasterMedicationRoute_Prod : DataFrame
                       ,Master_prod : DataFrame
                       ,MasterCode_Prod : DataFrame
                       ,Patient_Prod_Delta : DataFrame
                       ,Individual_prod_Delta4 : DataFrame
                       ,ViewServiceProvider_prod : DataFrame
                       ,MappingPracticeCommonData_Delta : DataFrame
                       ,MappingPracticeProcedure_Delta : DataFrame
                       ,MappingPracticeProblem_Delta : DataFrame
                      ,ServiceProvider_prod_Delta3 : DataFrame) : List[DataFrame] = {

    val logger = LoggerFactory.getLogger("")

    import spark.implicits._

    val CacheImmunizationFile = spark.read.option("delimiter", "\u0017")
      .csv("")

    val CacheImmunizationlookup=Map("_c0" -> "PatientId","_c1" -> "ImmunizationCode","_c2" -> "ImmunizationName",
      "_c3" -> "ImmunizationCategory","_c4" -> "ImmuStartDate","_c5" -> "ImmuStopDate","_c6" -> "AdministeredEffectiveDate",
      "_c7" -> "ServiceProviderNPI","_c8" -> "ServiceProviderLastName","_c9" -> "ServiceProviderFirstName",
      "_c10" -> "RepeatNumber","_c11" -> "MedicationRouteCode","_c12" -> "MedicationRouteText","_c13" -> "DoseQuantity",
      "_c14" -> "DoseQuantityUnitCode","_c15" -> "DoseQuantityUnitText","_c16" -> "MedicationProductFormCode",
      "_c17" -> "MedicationProductFormText","_c18" -> "ProcedureCode","_c19" -> "ProcedureText","_c20" -> "ProcedureCategory",
      "_c21" -> "NegationInd","_c22" -> "MedicationBrandName","_c23" -> "MedicationGenericName","_c24" -> "MaxDoseQuantity",
      "_c25" -> "DispensingTimeOfSupply","_c26" -> "DispensingDoseQuantity","_c27" -> "SupplyPrescriberLastName",
      "_c28" -> "SupplyPrescriberFirstName","_c29" -> "SupplyPerformerLastName","_c30" -> "SupplyPerformerFirstName",
      "_c31" -> "ServiceLocationId","_c32" -> "ServiceLocationName","_c33" -> "MedicationIndicationCriteria",
      "_c34" -> "MedicationIndicationProblemCode","_c35" -> "MedicationIndicationProblemText",
      "_c36" -> "MedicationIndicationProblemCategory","_c37" -> "MedicationSeriesNumber",
      "_c38" -> "MedicationReactionProblemCode","_c39" -> "MedicationReactionProblemText",
      "_c40" -> "MedicationReactionProblemCategory","_c41" -> "MedicationReactionProblemSeverityCode",
      "_c42" -> "MedicationReactionProblemSeverityText","_c43" -> "MedicationStatusCode","_c44" -> "MedicationStatusText",
      "_c45" -> "MedicineManufacturer","_c46" -> "MedicineId","_c47" -> "ProductInstanceScopingEntityId",
      "_c48" -> "SubstanceLotNumber","_c49" -> "SubstanceExpirationDate","_c50" -> "ActionCode","_c51" -> "AdministrationSite"
      ,"_c52" -> "ImmunizationKey","_c53" -> "PracticeUid","_c54" -> "BatchUid")

    val tempCacheImmunization = spark.read.option("header", "true").csv("s3n://bd-dev/aao_test/Schema/CDRSchema.txt")
    var tempCacheImmunization1 = CacheImmunizationFile.select(CacheImmunizationFile.columns.map(c => col(c).as(CacheImmunizationlookup.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")
    val allcols = tempCacheImmunization.columns.toSet
    val viewcols = tempCacheImmunization1.columns.toSet
    val total = allcols ++ viewcols

    logger.warn("Files are reading")

    tempCacheImmunization1 = tempCacheImmunization.select(FunctionUtility.addColumns(allcols, total): _*)
      .union(tempCacheImmunization1.select(FunctionUtility.addColumns(viewcols, total): _*))

    //#//
    //#// Update Start
    //#//

    //Create MergePracticeMapDF


    val TempMergePracticeMapDf = tempCacheImmunization1.filter($"StatusId".isNull)
      .select("practiceuid").distinct()

    val MergePracticeMapDF = MergePracticeMap.as("df1")
      .join(TempMergePracticeMapDf.as("df2"), $"df1.NewPracticeUid" === $"df2.practiceuid", "left")
      .select("df1.*")


    //Update CacheImmunization where stausId is null
    val UpdateCacheImmunization1 = tempCacheImmunization1.filter($"StatusId".isNull).as("df1")
      .join(MergePracticeMapDF.as("df2"), Seq("NewPracticeUid"))
      .select($"df1.*", $"df2.OriginalPracticeuid".as("AliasOriginalPracticeuid"))
      .withColumn("PracticeUid", $"AliasOriginalPracticeuid")
      .drop("AliasOriginalPracticeuid")

    val wherclause1 = tempCacheImmunization1.filter($"StatusId".isNull).as("df1")
      .join(MergePracticeMapDF.as("df2"), Seq("NewPracticeUid"))
      .select($"df1.*")

    val ExceptUpdateCacheImmunization1 = tempCacheImmunization1.except(wherclause1)
    // Updated CacheImmunizationTable to CacheImmunizationDF
    var CacheImmunizationDF = UpdateCacheImmunization1.union(ExceptUpdateCacheImmunization1)

    CacheImmunizationDF = CacheImmunizationDF.withColumn("StatusId", lit(1))

    //Update ChImmunization columns
    CacheImmunizationDF = CacheImmunizationDF
      .withColumn("OldPracticeUid", $"PracticeUid")
      .withColumn("PatientId", ltrim(rtrim($"PatientId")))
      .withColumn("ImmunizationName", ltrim(rtrim($"ImmunizationName")))
      .withColumn("ImmunizationCode", ltrim(rtrim($"ImmunizationCode")))
      .withColumn("ServiceProviderNPI", ltrim(rtrim($"ServiceProviderNPI")))

    //Update ChImmunization where PatientId is null
    val UpdatechImmunization2 = CacheImmunizationDF.filter($"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val whereclause2 = CacheImmunizationDF.filter($"PatientId".isNull)


    val ExceptUpdatechImmunization2 = CacheImmunizationDF.except(whereclause2)
    // Updated CacheImmunization1 to chImmunization
    CacheImmunizationDF = UpdatechImmunization2.union(ExceptUpdatechImmunization2)

    //Update ChImmunization from CRD Patient CrossWalk
    val UpdatechImmunization3 = CacheImmunizationDF.filter($"StatusId" === 1).as("df1")
      .join(CDRPatientCrosswalkTable.as("df2"), $"df1.PatientId" === $"df2.New_PatientId"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.Old_PatientId".as("AliasOld_PatientId"))
      .withColumn("PatientId", $"AliasOld_PatientId")
      .drop("AliasOld_PatientId")

    val wherclause3 = CacheImmunizationDF.filter($"StatusId" === 1).as("df1")
      .join(CDRPatientCrosswalkTable.as("df2"), $"df1.PatientId" === $"df2.New_PatientId"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdatechImmunization3 = CacheImmunizationDF.except(wherclause3)
    // Updated ChImmunization2 to ChImmunization3
    CacheImmunizationDF = UpdatechImmunization3.union(ExceptUpdatechImmunization3)

    val UpdateImmuStartDateisNull = CacheImmunizationDF.filter($"StatusId" === 1 && $"ImmuStartDate".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("Errornote", lit("ImmuStartDate Not Found"))

    val whereclause4_1 = CacheImmunizationDF.filter($"StatusId" === 1 && $"ImmuStartDate".isNull)

    val Exceptwhereclause4_1 = CacheImmunizationDF.except(whereclause4_1)
    // Updated ChImmunization3 to ChImmunization4
    CacheImmunizationDF = UpdateImmuStartDateisNull.union(Exceptwhereclause4_1)

    val UpdateImmunizationNameisNull = CacheImmunizationDF.filter($"StatusId" === 1
      && $"ImmunizationName".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Immunization Code And  Immunization Name Is Missing"))

    val whereclause4_2 = CacheImmunizationDF.filter($"StatusId" === 1)

    val Exceptwhereclause5 = CacheImmunizationDF.except(whereclause4_2)
    // Updated ChImmunization3 to ChImmunization4
    CacheImmunizationDF = UpdateImmunizationNameisNull.union(Exceptwhereclause5)

    val UpdateImmunizationNameAndImmunizationCategoryIsNull = CacheImmunizationDF.filter($"StatusId" === 1
      && $"ImmunizationName".isNull
      && $"ImmunizationCategory".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("Errornote", lit("Immunization name And  Immunization Category Is Missing"))

    val whereclause4 =  CacheImmunizationDF.filter($"StatusId" === 1
      && $"ImmunizationName".isNull
      && $"ImmunizationCategory".isNull)

    val ExceptUpdatechImmunization4 = CacheImmunizationDF.except(whereclause4)
    // Updated ChImmunization3 to ChImmunization4
    CacheImmunizationDF = UpdateImmunizationNameAndImmunizationCategoryIsNull.union(ExceptUpdatechImmunization4)

    val UpdatechImmunization5 = CacheImmunizationDF.filter($"StatusId" === 1
      && $"ServiceProviderNPI".isNull).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI" && $"element2.isNull").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ServiceProviderLastName" === $"df2.element2")
      .select($"df1.*", $"df2.value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue")
      .drop("AliasValue")

    val whereclause5 = CacheImmunizationDF.filter($"StatusId" === 1
      && $"ServiceProviderNPI".isNull).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI" && $"element2.isNull").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ServiceProviderLastName" === $"df2.element2")
      .select($"df1.*")

    val ExceptUpdatechImmunization5 = CacheImmunizationDF.except(whereclause5)
    // Updated ChImmunization4 to ChImmunization5
    CacheImmunizationDF = UpdatechImmunization5.union(ExceptUpdatechImmunization5)

    //Update ChImmunization where ServiceProviderNPI is not 10
    val UpdatechImmunization6 = CacheImmunizationDF.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid NPI Found,Length should be 10"))

    val ExceptUpdatechImmunization6 = CacheImmunizationDF.except(UpdatechImmunization6)
    // Updated ChImmunization5 to ChImmunization6
    CacheImmunizationDF = UpdatechImmunization6.union(ExceptUpdatechImmunization6)

    //Update ChImmunization where ImmunizationCodeUid is null
    val UpdatechImmunizationImmunizationCodeUidIsNull = CacheImmunizationDF
      .filter($"StatusId = 1" && $"ImmunizationCodeUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ImmunizationCode").as("df2"),
        $"df1.ImmunizationCode" === $"df2.Code")
      .select($"df1.*", $"df2.MasterUid".as("AliasMasterUid"))
      .withColumn("ImmunizationCodeUid", $"AliasMasterUid")
      .drop("AliasMasterUid")

    val whereclauseImmunizationCodeUidIsNull =  CacheImmunizationDF
      .filter($"StatusId = 1" && $"ImmunizationCodeUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ImmunizationCode").as("df2"),
        $"df1.ImmunizationCode" === $"df2.Code")
      .select($"df1.*")

    val exceptUpdatImmunizationCodeUidIsNull = CacheImmunizationDF.except(whereclauseImmunizationCodeUidIsNull)
    CacheImmunizationDF = UpdatechImmunizationImmunizationCodeUidIsNull.union(exceptUpdatImmunizationCodeUidIsNull)
    //check
    //Update when Type = ImmunizationCode
    val updateChImmunizationWhenImmunizationCode = CacheImmunizationDF
      .filter($"StatusId" === 1 && $"ImmunizationCodeUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ImmunizationCode").as("df2"), $"df1.ImmunizationName" === $"df2.Name")
      .select($"df1.*", $"df2.MasterUid".as("AliasMasterUid"))
      .withColumn("ImmunizationCodeUid", $"AliasMasterUid")
      .drop("AliasMasterUid")

    val whereclauseImmunizationCodeUid = CacheImmunizationDF
      .filter($"StatusId" === 1 && $"ImmunizationCodeUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ImmunizationCode").as("df2"), $"df1.ImmunizationName" === $"df2.Name")
      .select($"df1.*")

    val ExceptUpdatechImmunization7 = CacheImmunizationDF.except(whereclauseImmunizationCodeUid)
    // Updated ChImmunization6 to ChImmunization7
    CacheImmunizationDF = whereclauseImmunizationCodeUid.union(ExceptUpdatechImmunization7)

    val UpdateChImmunization8 = CacheImmunizationDF.filter($"StatusId" === 1
      && ($"ImmunizationCodeUid".isNull || rtrim(ltrim($"ImmunizationName")).isNotNull))
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("mmunizationCode Not Mapped"))

    val whereclause8 = CacheImmunizationDF.filter($"StatusId" === 1
      && ($"ImmunizationCodeUid".isNull || rtrim(ltrim($"ImmunizationName")).isNotNull))

    val ExceptUpdatechImmunization8 = CacheImmunizationDF.except(whereclause8)
    // Updated ChImmunization7 to UpdateChImmunization8
    CacheImmunizationDF = UpdateChImmunization8.union(ExceptUpdatechImmunization8)

    val UpdateChImmunization9 = CacheImmunizationDF.filter($"StatusId" === 1).as("df1")
      .join(Patient_Prod_Delta.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod_Delta4.as("df3"), $"df1.PracticeUid" === $"df3.PracticeUid"
        && $"df2.PatientUid" === $"df3.IndividualUid")
      .select($"df1.*", $"df2.PatientUid".as("AliasPatientUid"))
      .withColumn("PatientUid", $"AliasPatientUid")
      .drop("AliasPatientUid")

    val whereclause9 = CacheImmunizationDF.filter($"StatusId" === 1).as("df1")
      .join(Patient_Prod_Delta.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod_Delta4.as("df3"), $"df1.PracticeUid" === $"df3.PracticeUid"
        && $"df2.PatientUid" === $"df3.IndividualUid")
      .select($"df1.*")

    val ExceptUpdatechImmunization9 = CacheImmunizationDF.except(whereclause9)
    // Updated ChImmunization8 to UpdateChImmunization9
    CacheImmunizationDF = UpdateChImmunization9.union(ExceptUpdatechImmunization9)

    val UpdateChImmunization10 = CacheImmunizationDF.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val whereclause10 = CacheImmunizationDF.filter($"StatusId" === 1 && $"PatientUid".isNull)
    val ExceptUpdatechImmunization10 = CacheImmunizationDF.except(whereclause10)
    // Updated ChImmunization9 to UpdateChImmunization10
    CacheImmunizationDF = UpdateChImmunization10.union(ExceptUpdatechImmunization10)

    //Serviceprovideruid update
    val UpdateChImmunization11 = CacheImmunizationDF.filter($"StatusId" === 1).as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.ServiceProviderUid".as("AliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"AliasServiceProviderUid")
      .drop("ServiceProviderUid")

    val whereclause11 = CacheImmunizationDF.filter($"StatusId" === 1).as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
      && $"df1.PracticeUid" === $"df2.PracticeUid")
    .select($"df1.*")

    val ExceptUpdatechImmunization11 = CacheImmunizationDF.except(whereclause10)
    // Updated ChImmunization10 to UpdateChImmunization11
    CacheImmunizationDF = UpdateChImmunization11.union(ExceptUpdatechImmunization11)

    //new insert into individual & serviceprovider

    val PhyTable = CacheImmunizationDF.filter($"StatusId" === 1
      && $"ServiceProviderUid".isNull
      && ltrim(rtrim($"ServiceProviderNPI")).isNotNull)
      .select("ServiceProviderNPI", "PracticeUid")
      .groupBy($"ServiceProviderNPI", $"PracticeUid")
      .agg(max(ltrim(rtrim($"ServiceProviderFirstName"))).as("ServiceProviderFirstName"),
        max(ltrim(rtrim($"ServiceProviderLastName"))).as("ServiceProviderLastName"))
      .withColumn("Physician_MidName", lit(null))

    val AlterTablePhy = PhyTable
      .withColumn("ServiceProviderUid", FunctionUtility.getNewUid())

    val UpdateChImmunization12 = CacheImmunizationDF.filter($"StatusId" === 1 && $"ServiceProviderUid".isNull).as("df1")
      .join(AlterTablePhy.as("df2"), Seq("ServiceProviderNPI", "PracticeUid"))
      .select($"df1.*", $"df2.ServiceProviderUid".as("AliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"AliasServiceProviderUid")
      .drop("AliasServiceProviderUid")

    val whereclause12 = CacheImmunizationDF.filter($"StatusId" === 1 && $"ServiceProviderUid".isNull).as("df1")
      .join(AlterTablePhy.as("df2"), Seq("ServiceProviderNPI", "PracticeUid"))
      .select($"df1.*")

    val ExceptUpdatechImmunization12 = CacheImmunizationDF.except(whereclause12)
    // Updated ChImmunization11 to UpdateChImmunization12
    CacheImmunizationDF = UpdateChImmunization12.union(ExceptUpdatechImmunization12)


    val InsertIntoIndivisualDF = AlterTablePhy.as("df1")
      .join(distIndUid.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.IndividualUid"))
      .select($"df1.ServiceProviderUid".as("IndividualUid"), $"df1.ServiceProviderFirstName".as("First")
        , $"df1.Physician_MidName".as("Middle"), $"ServiceProviderLastName".as("Last"),
        $"df1.PracticeUid".as("PracticeUid")).distinct()

    val inscols = Individual_prod_Delta4.columns.toSet
    val insert_Indi = InsertIntoIndivisualDF.columns.toSet
    val tot1 = inscols ++ insert_Indi
    val Individual_prod_Delta5 = Individual_prod_Delta4.select(FunctionUtility.addColumns(inscols, tot1): _*)
      .union(InsertIntoIndivisualDF.select(FunctionUtility.addColumns(insert_Indi, tot1): _*))


    val insertdataServiceProv = AlterTablePhy.as("df1")
      .join(distspUID.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.ServiceProviderUid"))
      .withColumn("ListName", when($"df1.Physician_MidName".isNotNull, concat_ws(" "
        , $"ServiceProviderLastName", $"ServiceProviderFirstName", $"Physician_MidName"))
        .otherwise(concat_ws(" ", $"ServiceProviderLastName", $"ServiceProviderFirstName")))
      .select($"df1.ServiceProviderUid", $"ListName", $"df1.ServiceProviderNPI".as("NPI"))
      .withColumn("ExternalID", lit(null))
      .withColumn("Type", lit(4))

    val cols2 = ServiceProvider_prod_Delta3.columns.toSet
    val insert2 = insertdataServiceProv.columns.toSet
    val tot2 = cols2 ++ insert2

    val ServiceProvider_prod_Delta4 = ServiceProvider_prod_Delta3.select(FunctionUtility.addColumns(cols2, tot2): _*)
      .union(insertdataServiceProv.select(FunctionUtility.addColumns(insert2, tot2): _*))


    val UpdateChImmunization13 = CacheImmunizationDF.filter($"StatusId" === 1).as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationid" === $"df2.id"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.ServiceLocationUid".as("AliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"AliasServiceLocationUid")
      .drop("AliasServiceLocationUid")

    val whereclause13 = CacheImmunizationDF.filter($"StatusId" === 1).as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationid" === $"df2.id"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdatechImmunization13 = CacheImmunizationDF.except(whereclause13)
    // Updated ChImmunization12 to UpdateChImmunization13
    CacheImmunizationDF = UpdateChImmunization13.union(ExceptUpdatechImmunization13)

    val UpdateChImmunizationPatientImmunizationUid1 = CacheImmunizationDF.filter($"StatusId" === 1).as("df1")
      .join(PatientImmunizationTable.as("df2"),
        Seq("PatientUid", "ImmunizationCode", "ImmunizationName", "ImmuStartDate"))
      .select($"df1.*", $"df2.PatientImmunizationUid".as("AliasPatientImmunizationUid"))
      .withColumn("PatientImmunizationUid", $"AliasPatientImmunizationUid")
      .drop("AliasPatientImmunizationUid")

    val whereclausePatientImmunizationUid1 = CacheImmunizationDF.filter($"StatusId" === 1).as("df1")
      .join(PatientImmunizationTable.as("df2"),
        Seq("PatientUid", "ImmunizationCode", "ImmunizationName", "ImmuStartDate"))
      .select($"df1.*")


    val exceptupdatePatientImmunizationUid1 = CacheImmunizationDF.except(whereclausePatientImmunizationUid1)
    CacheImmunizationDF = UpdateChImmunizationPatientImmunizationUid1.union(exceptupdatePatientImmunizationUid1)

    val UpdateChImmunizationPatientImmunizationUid2 = CacheImmunizationDF.filter($"StatusId" === 1
      && $"ImmunizationName".isNull).as("df1")
      .join(PatientImmunizationTable.as("df2"),
        Seq("PatientUid", "ImmunizationCode", "ImmunizationName", "ImmunizationCategory", "ImmuStartDate"))
      .select($"df1.*", $"df2.PatientImmunizationUid".as("AliasPatientImmunizationUid"))
      .withColumn("PatientImmunizationUid", $"AliasPatientImmunizationUid")
      .drop("AliasPatientImmunizationUid")


    val whereclausePatientImmunizationUid2 = CacheImmunizationDF.filter($"StatusId" === 1
      && $"ImmunizationName".isNull).as("df1")
      .join(PatientImmunizationTable.as("df2"),
        Seq("PatientUid", "ImmunizationCode", "ImmunizationName", "ImmunizationCategory", "ImmuStartDate"))
      .select($"df1.*")

    val exceptupdatePatientImmunizationUid2 = CacheImmunizationDF.except(whereclausePatientImmunizationUid2)
    CacheImmunizationDF = UpdateChImmunizationPatientImmunizationUid2.union(exceptupdatePatientImmunizationUid2)



    val UpdateChImmunizationPatientImmunizationUid3 = CacheImmunizationDF.filter($"StatusId" === 1
      && $"ImmunizationCode".isNull).as("df1")
      .join(PatientImmunizationTable.as("df2"),
        Seq("PatientUid", "ImmunizationName", "ImmuStartDate"))
      .select($"df1.*", $"df2.PatientImmunizationUid".as("AliasPatientImmunizationUid"))
      .withColumn("PatientImmunizationUid", $"AliasPatientImmunizationUid")
      .drop("AliasPatientImmunizationUid")

    val whereclausePatientImmunizationUid3 =CacheImmunizationDF.filter($"StatusId" === 1
      && $"ImmunizationCode".isNull).as("df1")
      .join(PatientImmunizationTable.as("df2"),
        Seq("PatientUid", "ImmunizationName", "ImmuStartDate"))
      .select($"df1.*")

    val ExceptUpdatechImmunization14 = CacheImmunizationDF.except(whereclausePatientImmunizationUid3)
    // Updated ChImmunization12 to UpdateChImmunization13
    CacheImmunizationDF = UpdateChImmunizationPatientImmunizationUid3.union(ExceptUpdatechImmunization14)



    val CleanData1 = CacheImmunizationDF.dropDuplicates("PatientUid", "ImmunizationCodeUid", "ImmunizationName", "ImmuStartDate")
    var DropDuplicates1 = CacheImmunizationDF.except(CleanData1)
    val CleanData2 = CleanData1.dropDuplicates("PatientUid", "ImmunizationCodeUid", "ImmunizationCategory", "ImmuStartDate")
    val DropDuplicates2 = CleanData1.except(CleanData2)
    var CleanData3 = CleanData2.dropDuplicates("PatientUid", "ImmunizationName", "ImmuStartDate")
    val DropDuplicates3 = CleanData2.except(CleanData3)

    DropDuplicates1 = DropDuplicates1
      .union(DropDuplicates2)
      .union(DropDuplicates3)


    DropDuplicates1 = DropDuplicates1.union(DropDuplicates3)



    val TempPatientImmunizationDF = CleanData3.filter($"StatusId" === 1
      && $"ImmunizationCodeUid".isNotNull
      && $"ImmunizationName".isNotNull
      && $"ImmuStartDate".isNotNull)
      .select("PatientUid", "ImmunizationCodeUid", "ImmunizationName", "ImmuStartDate")
      .distinct()
      .withColumn("PatientImmunizationUid", FunctionUtility.getNewUid())

    val UpdateChImmunization18 = CleanData3.filter($"StatusId" === 1).as("df1")
      .join(TempPatientImmunizationDF.as("df2"), Seq("PatientUid", "ImmunizationCodeUid", "ImmunizationName", "ImmuStartDate"))
      .select($"df1.*", $"df2.PatientImmunizationUid".as("AliasPatientImmunizationUid"))
      .withColumn("PatientImmunizationUid", $"AliasPatientImmunizationUid")
      .drop("AliasPatientImmunizationUid")

    val whereclause18 =  CleanData3.filter($"StatusId" === 1).as("df1")
      .join(TempPatientImmunizationDF.as("df2"), Seq("PatientUid", "ImmunizationCodeUid", "ImmunizationName", "ImmuStartDate"))
      .select($"df1.*")
    val ExceptUpdatechImmunization18 = CleanData3.except(whereclause18)
    // Updated ChImmunization17 to UpdateChImmunization18
    CleanData3 = UpdateChImmunization18.union(ExceptUpdatechImmunization18)

    val TempPatientImmunizationDF1 = CleanData3
      .filter($"StatusId" === 1
        && $"ImmunizationCode".isNotNull
        && $"ImmunizationCategory".isNotNull
        && $"ImmuStartDate".isNotNull)
      .select("PatientUid", "ImmunizationCode", "ImmunizationCategory", "ImmuStartDate")
      .distinct()
      .withColumn("PatientImmunizationUid", FunctionUtility.getNewUid())

    val UpdateChImmunization19 = CleanData3.filter($"StatusId" === 1).as("df1")
      .join(TempPatientImmunizationDF1.as("df2"), Seq("PatientUid", "ImmunizationCode", "ImmunizationCategory", "ImmuStartDate"))
      .select($"df1.*", $"df2.PatientImmunizationUid".as("AliasPatientImmunizationUid"))
      .withColumn("PatientImmunizationUid", $"AliasPatientImmunizationUid")
      .drop("AliasPatientImmunizationUid")

    val whereclause19 = CleanData3.filter($"StatusId" === 1).as("df1")
      .join(TempPatientImmunizationDF1.as("df2"), Seq("PatientUid", "ImmunizationCode", "ImmunizationCategory", "ImmuStartDate"))
      .select($"df1.*")
    val ExceptUpdatechImmunization19 = CleanData3.except(whereclause19)
    // Updated ChImmunization18 to UpdateChImmunization19
    CleanData3 = UpdateChImmunization19.union(ExceptUpdatechImmunization19)

    val TempPatientImmunizationDF2 = CleanData3
      .filter($"StatusId" === 1
        && $"ImmunizationCode".isNull
        && $"ImmuStartDate".isNotNull)
      .select("PatientUid", "ImmunizationName", "ImmuStartDate")
      .distinct()
      .withColumn("PatientImmunizationUid", FunctionUtility.getNewUid())

    val UpdateChImmunization20 = CleanData3.filter($"StatusId" === 1).as("df1")
      .join(TempPatientImmunizationDF2.as("df2"), Seq("PatientUid", "ImmunizationName", "ImmuStartDate"))
      .select($"df1.*", $"df2.PatientImmunizationUid".as("AliasPatientImmunizationUid"))
      .withColumn("PatientImmunizationUid", $"AliasPatientImmunizationUid")
      .drop("AliasPatientImmunizationUid")

    val whereclause20 = CleanData3.filter($"StatusId" === 1).as("df1")
      .join(TempPatientImmunizationDF2.as("df2"), Seq("PatientUid", "ImmunizationName", "ImmuStartDate"))
      .select($"df1.*")

    val ExceptUpdatechImmunization20 = CleanData3.except(whereclause20)
    // Updated ChImmunization19 to UpdateChImmunization20
    CleanData3 = UpdateChImmunization20.union(ExceptUpdatechImmunization20)

    val UpdateChImmunization21 = CleanData3.filter($"StatusId" === 1 && $"RouteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "78003645-6400-4814-8272-1E3EA58E51C1").as("df2"),
        $"df1.MedicationRouteCode" === $"df2.PracticeValue"
          && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.MappedUid".as("AliasMappedUid"))
      .withColumn("RouteUid", $"AliasMappedUid")
      .drop("AliasMappedUid")

    val whereclause21 = CleanData3.filter($"StatusId" === 1 && $"RouteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "78003645-6400-4814-8272-1E3EA58E51C1").as("df2"),
        $"df1.MedicationRouteCode" === $"df2.PracticeValue"
          && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdatechImmunization21 = CleanData3.except(whereclause21)
    // Updated ChImmunization20 to UpdateChImmunization21
    CleanData3 = UpdateChImmunization21.union(ExceptUpdatechImmunization21)

    val UpdateChImmunization22 = CleanData3.filter($"StatusId" === 1 && $"RouteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "78003645-6400-4814-8272-1E3EA58E51C1").as("df2"),
        $"df1.MedicationRouteText" === $"df2.PracticeValue"
          && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.MappedUid".as("AliasMappedUid"))
      .withColumn("RouteUid", $"AliasMappedUid")
      .drop("AliasMappedUid")

    val whereclause22 = CleanData3.filter($"StatusId" === 1 && $"RouteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "78003645-6400-4814-8272-1E3EA58E51C1").as("df2"),
        $"df1.MedicationRouteText" === $"df2.PracticeValue"
          && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdatechImmunization22 = CleanData3.except(whereclause22)
    // Updated ChImmunization21 to UpdateChImmunization22
    CleanData3 = UpdateChImmunization22.union(ExceptUpdatechImmunization22)

    val UpdateChImmunization23 = CleanData3.filter($"StatusId" === 1 && $"RouteUid".isNull).as("df1")
      .join(MasterMedicationRoute_Prod.as("df2"),
        $"df1.MedicationRouteCode" === $"df2.ExternalID")
      .select($"df1.*", $"df2.MedicationRouteUid".as("AliasMedicationRouteUid"))
      .withColumn("RouteUid", $"AliasMedicationRouteUid")
      .drop("AliasMedicationRouteUid")
    val whereclause23 = CleanData3.filter($"StatusId" === 1 && $"RouteUid".isNull).as("df1")
      .join(MasterMedicationRoute_Prod.as("df2"),
        $"df1.MedicationRouteCode" === $"df2.ExternalID")
      .select($"df1.*")

    val ExceptUpdatechImmunization23 = CleanData3.except(whereclause23)
    // Updated ChImmunization22 to UpdateChImmunization23
    CleanData3 = UpdateChImmunization23.union(ExceptUpdatechImmunization23)

    val UpdateChImmunization24 = CleanData3.filter($"StatusId" === 1 && $"RouteUid".isNull).as("df1")
      .join(MasterMedicationRoute_Prod.as("df2"),
        $"df1.MedicationRouteText" === $"df2.Description")
      .select($"df1.*", $"df2.MedicationRouteUid".as("AliasMedicationRouteUid"))
      .withColumn("RouteUid", $"AliasMedicationRouteUid")
      .drop("AliasMedicationRouteUid")

    val whereclause24 = CleanData3.filter($"StatusId" === 1 && $"RouteUid".isNull).as("df1")
      .join(MasterMedicationRoute_Prod.as("df2"),
        $"df1.MedicationRouteText" === $"df2.Description")
      .select($"df1.*")

    val ExceptUpdatechImmunization24 = CleanData3.except(whereclause24)
    // Updated ChImmunization23 to UpdateChImmunization24
    CleanData3 = UpdateChImmunization24.union(ExceptUpdatechImmunization24)

    val UpdateChImmunization25 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationProductFormUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "78003645-6400-4814-8272-1E3EA58E51C1").as("df2"),
        $"df1.MedicationProductFormCode" === $"df2.PracticeValue"
          && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.MedicationRouteUid".as("AliasMedicationRouteUid"))
      .withColumn("RouteUid", $"AliasMedicationRouteUid")
      .drop("AliasMappedUid")

    val whereclause25 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationProductFormUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "78003645-6400-4814-8272-1E3EA58E51C1").as("df2"),
        $"df1.MedicationProductFormCode" === $"df2.PracticeValue"
          && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdatechImmunization25 = CleanData3.except(whereclause25)
    // Updated ChImmunization24 to UpdateChImmunization25
    CleanData3 = UpdateChImmunization25.union(ExceptUpdatechImmunization25)

    val UpdateChImmunization26 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationProductFormUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "78003645-6400-4814-8272-1E3EA58E51C1").as("df2"),
        $"df1.MedicationProductFormText" === $"df2.PracticeValue"
          && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.MedicationRouteUid".as("AliasMedicationRouteUid"))
      .withColumn("RouteUid", $"AliasMedicationRouteUid")
      .drop("AliasMappedUid")

    val whereclause26 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationProductFormUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "78003645-6400-4814-8272-1E3EA58E51C1").as("df2"),
        $"df1.MedicationProductFormText" === $"df2.PracticeValue"
          && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdatechImmunization26 = CleanData3.except(whereclause26)
    // Updated ChImmunization25 to UpdateChImmunization26
    CleanData3 = UpdateChImmunization26.union(ExceptUpdatechImmunization26)

    val UpdateChImmunization27 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationProductFormUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "MedicationProductForm").as("df2"),
        $"df1.MedicationProductFormCode" === $"df2.Code")
      .select($"df1.*", $"df2.MasterUid".as("AliasMasterUid"))
      .withColumn("MasterMedicationProductFormUid", $"AliasMasterUid")
      .withColumn("ErrorNote", lit(null))
      .drop("AliasMasterUid")

    val whereclause27 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationProductFormUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "MedicationProductForm").as("df2"),
        $"df1.MedicationProductFormCode" === $"df2.Code")
      .select($"df1.*")

    val ExceptUpdatechImmunization27 = CleanData3.except(whereclause27)
    // Updated ChImmunization26 to UpdateChImmunization27
    CleanData3 = UpdateChImmunization27.union(ExceptUpdatechImmunization27)

    val UpdateChImmunization28 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationProductFormUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "MedicationProductForm").as("df2"),
        $"df1.MedicationProductFormText" === $"df2.Name")
      .select($"df1.*", $"df2.MasterUid".as("AliasMasterUid"))
      .withColumn("MasterMedicationProductFormUid", $"AliasMasterUid")
      .withColumn("ErrorNote", lit(null))
      .drop("AliasMasterUid")

    val whereclause28 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationProductFormUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "MedicationProductForm").as("df2"),
        $"df1.MedicationProductFormText" === $"df2.Name")
      .select($"df1.*")

    val ExceptUpdatechImmunization28 = CleanData3.except(whereclause28)
    // Updated ChImmunization27 to UpdateChImmunization28
    CleanData3 = UpdateChImmunization28.union(ExceptUpdatechImmunization28)

    val UpdateChImmunization29 = CleanData3.filter($"StatusId" === 1 && $"ProcedureUid".isNull).as("df1")
      .join(MappingPracticeProcedure_Delta.as("df2"), $"df1.ProcedureCode" === $"df2.PracticeValue")
      .select($"df1.*", $"df2.CodeUid".as("AliasCodeUid"))
      .withColumn("ProcedureUid", $"AliasCodeUid")
      .drop("AliasCodeUid")

    val whereclause29 = CleanData3.filter($"StatusId" === 1 && $"ProcedureUid".isNull).as("df1")
      .join(MappingPracticeProcedure_Delta.as("df2"), $"df1.ProcedureCode" === $"df2.PracticeValue")
      .select($"df1.*")
    val ExceptUpdatechImmunization29 = CleanData3.except(whereclause29)
    // Updated ChImmunization28 to UpdateChImmunization29
    CleanData3 = UpdateChImmunization29.union(ExceptUpdatechImmunization29)

    val UpdateChImmunization30 = CleanData3.filter($"StatusId" === 1 && $"ProcedureUid".isNull).as("df1")
      .join(MasterCode_Prod.as("df2"), $"df1.ProcedureCode" === $"df2.Code"
        && $"df1.ProcedureCategory" === $"df2.CodeSystem")
      .select($"df1.*", $"df2.CodeUid".as("AliasCodeUid"))
      .withColumn("ProcedureUid", $"AliasCodeUid")
      .withColumn("ErrorNote", lit(null))
      .drop("AliasCodeUid")

    val whereclause30 = CleanData3.filter($"StatusId" === 1 && $"ProcedureUid".isNull).as("df1")
      .join(MasterCode_Prod.as("df2"), $"df1.ProcedureCode" === $"df2.Code"
        && $"df1.ProcedureCategory" === $"df2.CodeSystem")
      .select($"df1.*")

    val ExceptUpdatechImmunization30 = CleanData3.except(whereclause30)
    // Updated ChImmunization29 to UpdateChImmunization30
    CleanData3 = UpdateChImmunization30.union(ExceptUpdatechImmunization30)

    val UpdateChImmunization31 = CleanData3.filter($"StatusId" === 1
      && $"ProcedureUid".isNull
      && $"ProcedureCode".isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ProcedureCodeNot Mapped"))

    val whereclause31 = CleanData3.filter($"StatusId" === 1
      && $"ProcedureUid".isNull
      && $"ProcedureCode".isNotNull)

    val ExceptUpdatechImmunization31 = CleanData3.except(whereclause31)
    // Updated ChImmunization30 to UpdateChImmunization31
    CleanData3 = UpdateChImmunization31.union(ExceptUpdatechImmunization31)


    val UpdateChImmunization32 = CleanData3.filter($"StatusId" === 1
      && $"MedicationIndicationProblemCodeUid".isNull).as("df1")
      .join(MappingPracticeProblem_Delta.as("df2"), $"df1.MedicationIndicationProblemCode" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.CodeUid".as("AliasCodeUid"))
      .withColumn("MedicationIndicationProblemCodeUid", $"AliasCodeUid")
      .drop("AliasCodeUid")

    val whereclause32 = CleanData3.filter($"StatusId" === 1
      && $"MedicationIndicationProblemCodeUid".isNull).as("df1")
      .join(MappingPracticeProblem_Delta.as("df2"), $"df1.MedicationIndicationProblemCode" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdatechImmunization32 = CleanData3.except(whereclause32)
    // Updated ChImmunization31 to UpdateChImmunization32
    CleanData3 = UpdateChImmunization32.union(ExceptUpdatechImmunization32)

    val UpdateChImmunization33 = CleanData3.filter($"StatusId" === 1
      && $"MedicationIndicationProblemCodeUid".isNull).as("df1")
      .join(MappingPracticeProblem_Delta.as("df2"), $"df1.MedicationIndicationProblemText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.CodeUid".as("AliasCodeUid"))
      .withColumn("MedicationIndicationProblemCodeUid", $"AliasCodeUid")
      .drop("AliasCodeUid")

    val whereclause33 = CleanData3.filter($"StatusId" === 1
      && $"MedicationIndicationProblemCodeUid".isNull).as("df1")
      .join(MappingPracticeProblem_Delta.as("df2"), $"df1.MedicationIndicationProblemText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdatechImmunization33 = CleanData3.except(whereclause33)
    // Updated ChImmunization32 to UpdateChImmunization33
    CleanData3 = UpdateChImmunization33.union(ExceptUpdatechImmunization33)

    val UpdateChImmunization34 = CleanData3.filter($"StatusId" === 1
      && $"MedicationIndicationProblemCodeUid".isNull).as("df1")
      .join(MasterCode_Prod.as("df2"), $"df1.MedicationIndicationProblemCode" === $"df2.Code")
      .select($"df1.*", $"df2.CodeUid".as("AliasCodeUid"))
      .withColumn("MedicationIndicationProblemCodeUid", $"AliasCodeUid")
      .drop("AliasCodeUid")

    val whereclause34 =  CleanData3.filter($"StatusId" === 1
      && $"MedicationIndicationProblemCodeUid".isNull).as("df1")
      .join(MasterCode_Prod.as("df2"), $"df1.MedicationIndicationProblemCode" === $"df2.Code")
      .select($"df1.*")

    val ExceptUpdatechImmunization34 = CleanData3.except(whereclause34)
    // Updated ChImmunization33 to UpdateChImmunization34
    CleanData3 = UpdateChImmunization34.union(ExceptUpdatechImmunization34)

    val UpdateChImmunization35 = CleanData3.filter($"StatusId" === 1
      && ltrim(rtrim($"ProcedureCode")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("MedicationIndicationProblemCode Not Mapped"))


    val whereclause35 = CleanData3.filter($"StatusId" === 1
      && ltrim(rtrim($"ProcedureCode")).isNotNull)

    val ExceptUpdatechImmunization35 = CleanData3.except(whereclause35)
    // Updated ChImmunization34 to UpdateChImmunization35
    CleanData3 = UpdateChImmunization35.union(ExceptUpdatechImmunization35)

    val UpdateChImmunization36 = CleanData3.filter($"MedicationReactionProblemCodeUid".isNull
      && $"StatusId" === 1).as("df1")
      .join(MappingPracticeProblem_Delta.as("df2"), $"df1.MedicationReactionProblemCode" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.CodeUid".as("AliasCodeUid"))
      .withColumn("MedicationReactionProblemCodeUid", $"AliasCodeUid")
      .drop("AliasCodeUid")

    val whereclause36 = CleanData3.filter($"MedicationReactionProblemCodeUid".isNull
      && $"StatusId" === 1).as("df1")
      .join(MappingPracticeProblem_Delta.as("df2"), $"df1.MedicationReactionProblemCode" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdatechImmunization36 = CleanData3.except(whereclause36)
    // Updated ChImmunization35 to UpdateChImmunization36
    CleanData3 = UpdateChImmunization36.union(ExceptUpdatechImmunization36)

    val UpdateChImmunization37 = CleanData3.filter($"MedicationReactionProblemCodeUid".isNull
      && $"StatusId" === 1).as("df1")
      .join(MappingPracticeProblem_Delta.as("df2"), $"df1.MedicationReactionProblemText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.CodeUid".as("AliasCodeUid"))
      .withColumn("MedicationReactionProblemCodeUid", $"AliasCodeUid")
      .drop("AliasCodeUid")

    val whereclause37 =  CleanData3.filter($"MedicationReactionProblemCodeUid".isNull
      && $"StatusId" === 1).as("df1")
      .join(MappingPracticeProblem_Delta.as("df2"), $"df1.MedicationReactionProblemText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdatechImmunization37 = CleanData3.except(whereclause37)
    // Updated ChImmunization36 to UpdateChImmunization37
    CleanData3 = UpdateChImmunization37.union(ExceptUpdatechImmunization37)

    val UpdateChImmunization38 = CleanData3.filter($"StatusId" === 1
      && $"MedicationReactionProblemCodeUid".isNull).as("df1")
      .join(MasterCode_Prod.as("df2"), $"df1.MedicationIndicationProblemCode" === $"df2.Code"
        && $"df1.MedicationReactionProblemCategory" === $"df2.CodeSystem")
      .select($"df1.*", $"df2.CodeUid".as("AliasCodeUid"))
      .withColumn("MedicationIndicationProblemCodeUid", $"AliasCodeUid")
      .drop("AliasCodeUid")

    val whereclause38 =  CleanData3.filter($"StatusId" === 1
      && $"MedicationReactionProblemCodeUid".isNull).as("df1")
      .join(MasterCode_Prod.as("df2"), $"df1.MedicationIndicationProblemCode" === $"df2.Code"
        && $"df1.MedicationReactionProblemCategory" === $"df2.CodeSystem")
      .select($"df1.*")

    val ExceptUpdatechImmunization38 = CleanData3.except(whereclause38)
    // Updated ChImmunization37 to UpdateChImmunization38
    CleanData3 = UpdateChImmunization38.union(ExceptUpdatechImmunization38)

    val UpdateChImmunization39 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationReactionProblemServerityUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ProblemSeverity").as("df2"),
        $"df1.MedicationReactionProblemSeverityCode" === $"df2.Code")
      .select($"df1.*", $"df2.MasterUid".as("AliasMasterUid"))
      .withColumn("MasterMedicationReactionProblemServerityUid", $"AliasMasterUid")
      .drop("AliasMasterUid")

    val whereclause39 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationReactionProblemServerityUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ProblemSeverity").as("df2"),
        $"df1.MedicationReactionProblemSeverityCode" === $"df2.Code")
      .select($"df1.*")

    val ExceptUpdatechImmunization39 = CleanData3.except(whereclause39)
    // Updated ChImmunization38 to UpdateChImmunization39
    CleanData3 = UpdateChImmunization39.union(ExceptUpdatechImmunization39)

    val UpdateChImmunization40 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationReactionProblemServerityUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ProblemSeverity").as("df2"),
        $"df1.MedicationReactionProblemSeverityText" === $"df2.Name")
      .select($"df1.*", $"df2.MasterUid".as("AliasMasterUid"))
      .withColumn("MasterMedicationReactionProblemServerityUid", $"AliasMasterUid")
      .drop("AliasMasterUid")

    val whereclause40 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationReactionProblemServerityUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ProblemSeverity").as("df2"),
        $"df1.MedicationReactionProblemSeverityText" === $"df2.Name")
      .select($"df1.*")

    val ExceptUpdatechImmunization40 = CleanData3.except(whereclause40)
    // Updated ChImmunization39 to UpdateChImmunization40
    CleanData3 = UpdateChImmunization40.union(ExceptUpdatechImmunization40)


    val UpdateChImmunization41 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationStatusUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "E3BE332C-0E43-4602-8B10-0344BAD2989F").as("df2"),
        $"df1.MedicationStatusCode" === $"df2.PracticeValue"
          || $"df1.MedicationStatusText" === $"df2.PracticeValue"
          && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.MedicationRouteUid".as("AliasMedicationRouteUid"))
      .withColumn("MasterMedicationStatusUid", $"AliasMedicationRouteUid")
      .drop("AliasMappedUid")

    val whereclause41 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationStatusUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "E3BE332C-0E43-4602-8B10-0344BAD2989F").as("df2"),
        $"df1.MedicationStatusCode" === $"df2.PracticeValue"
          || $"df1.MedicationStatusText" === $"df2.PracticeValue"
          && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdatechImmunization41 = CleanData3.except(whereclause41)
    // Updated ChImmunization40 to UpdateChImmunization41
    CleanData3 = UpdateChImmunization41.union(ExceptUpdatechImmunization41)


    val UpdateChImmunization42 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationStatusUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "MedicationStatus").as("df2"),
        $"df1.MedicationStatusCode" === $"df2.Code")
      .select($"df1.*", $"df2.MasterUid".as("AliasMasterUid"))
      .withColumn("MasterMedicationStatusUid", $"AliasMasterUid")
      .drop("AliasMasterUid")

    val whereclause42 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationStatusUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "MedicationStatus").as("df2"),
        $"df1.MedicationStatusCode" === $"df2.Code")
      .select($"df1.*")

    val ExceptUpdatechImmunization42 = CleanData3.except(whereclause42)
    // Updated ChImmunization41 to UpdateChImmunization42
    CleanData3 = UpdateChImmunization42.union(ExceptUpdatechImmunization42)

    val UpdateChImmunization43 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationStatusUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "MedicationStatus").as("df2"),
        $"df1.MedicationStatusText" === $"df2.Name")
      .select($"df1.*", $"df2.MasterUid".as("AliasMasterUid"))
      .withColumn("MasterMedicationStatusUid", $"AliasMasterUid")
      .drop("AliasMasterUid")

    val whereclause43 = CleanData3.filter($"StatusId" === 1
      && $"MasterMedicationStatusUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "MedicationStatus").as("df2"),
        $"df1.MedicationStatusText" === $"df2.Name")
      .select($"df1.*")

    val ExceptUpdatechImmunization43 = CleanData3.except(whereclause43)
    // Updated ChImmunization42 to UpdateChImmunization43
    CleanData3 = UpdateChImmunization43.union(ExceptUpdatechImmunization43)

    val UpdateChImmunization44 = CleanData3.filter($"StatusId" === 1
      && ltrim(rtrim($"MedicationStatusText")).isNotNull
      || ltrim(rtrim($"MedicationStatusCode")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ErrorNote", lit("MedicationStatusText/Code Not Mapped"))

    val whereclause44 =  CleanData3.filter($"StatusId" === 1
      && ltrim(rtrim($"MedicationStatusText")).isNotNull
      || ltrim(rtrim($"MedicationStatusCode")).isNotNull)

    val ExceptUpdatechImmunization44 = CleanData3.except(whereclause44)
    // Updated ChImmunization43 to UpdateChImmunization44
    CleanData3 = UpdateChImmunization44.union(ExceptUpdatechImmunization44)

    val UpdatepphDF= CleanData3.filter($"StatusId" === 1).as("df1")
      .join(PatientImmunizationTable.as("df2"), Seq("PatientImmunizationUid"))
      .select($"df2.*",$"df1.patientUid".as("AliaspatientUid"),$"df1.ImmunizationCodeUid".as("AliasImmunizationCodeUid"),
        $"df1.ImmunizationName".as("AliasImmunizationName"),$"df1.ImmunizationCode".as("AliasImmunizationCode"),
        $"df1.ImmunizationCategory".as("AliasImmunizationCategory"),$"df1.ImmuStartDate".as("AliasImmuStartDate"),
        $"df1.ImmuStopDate".as("AliasImmuStopDate"),$"df1.AdministeredEffectiveDate".as("AliasAdministeredEffectiveDate"),
        $"df1.ServiceProviderUid".as("AliasServiceProviderUid"),$"df1.RepeatNumber".as("AliasRepeatNumber"),
        $"df1.RouteUid".as("AliasRouteUid"),$"df1.DoseQuantity".as("AliasDoseQuantity"),
        $"df1.DoseQuantityUnitCode".as("AliasDoseQuantityUnitCode"),$"df1.DoseQuantityUnitText".as("AliasDoseQuantityUnitText"),
        $"df1.MasterMedicationProductFormUid".as("AliasMasterMedicationProductFormUid"),$"df1.ProcedureUid".as("AliasProcedureUid"),
        $"df1.CreatedDate".as("AliasCreatedDate"),$"df1.ModifiedDate".as("AliasModifiedDate"),$"df1.NegationInd".as("AliasNegationInd"),
        $"df1.MedicationBrandName".as("AliasMedicationBrandName"),$"df1.MedicationGenericName".as("AliasMedicationGenericName"),
        $"df1.MaxDoseQuantity".as("AliasMaxDoseQuantity"),$"df1.DispensingTimeOfSupply".as("AliasDispensingTimeOfSupply"),
        $"df1.DispensingDoseQuantity".as("AliasDispensingDoseQuantity"),$"df1.SupplyPrescriberLastName".as("AliasSupplyPrescriberLastName"),
        $"df1.SupplyPrescriberFirstName".as("AliasSupplyPrescriberFirstName"),$"df1.SupplyPerformerLastName".as("AliasSupplyPerformerLastName"),
        $"df1.SupplyPerformerFirstName".as("AliasSupplyPerformerFirstName"),$"df1.ServiceLocationName".as("AliasServiceLocationName"),
        $"df1.ServiceLocationUid".as("AliasServiceLocationUid"),$"df1.MedicationIndicationCriteria".as("AliasMedicationIndicationCriteria"),
        $"df1.MedicationIndicationProblemCodeUid".as("AliasMedicationIndicationProblemCodeUid"),
        $"df1.MedicationSeriesNumber".as("AliasMedicationSeriesNumber"),
        $"df1.MedicationReactionProblemCodeUid".as("AliasMedicationReactionProblemCodeUid"),
        $"df1.MasterMedicationReactionProblemServerityUid".as("AliasMasterMedicationReactionProblemServerityUid"),
        $"df1.MasterMedicationStatusUid".as("AliasMasterMedicationStatusUid"),$"df1.MedicineManufacturer".as("AliasMedicineManufacturer"),
        $"df1.MedicineId".as("AliasMedicineId"),$"df1.ProductInstanceScopingEntityId".as("AliasProductInstanceScopingEntityId"),
        $"df1.Ordercontrol".as("AliasOrdercontrol"),$"df1.PlacerOrderNumber".as("AliasPlacerOrderNumber"),
        $"df1.FillerOrderNumber".as("AliasFillerOrderNumber"),$"df1.EnteredByFirstName".as("AliasEnteredByFirstName"),
        $"df1.EnteredByMiddleName".as("AliasEnteredByMiddleName"),$"df1.EnteredByLastName".as("AliasEnteredByLastName"),
        $"df1.OrderingProviderFirstName".as("AliasOrderingProviderFirstName"),$"df1.OrderingProviderMiddleName".as("AliasOrderingProviderMiddleName"),
        $"df1.OrderingProviderLastName".as("AliasOrderingProviderLastName"),$"df1.EnteringOrganization".as("AliasEnteringOrganization"),
        $"df1.SubstanceLotNumber".as("AliasSubstanceLotNumber"),$"df1.SubstanceExpirationDate".as("AliasSubstanceExpirationDate"),
        $"df1.ActionCode".as("AliasActionCode"),$"df1.AdministrationSite".as("AliasAdministrationSite"),$"df1.immunizationkey".as("Aliasimmunizationkey"),
        $"df1.ImmunizationCategory".as("AliasImmunizationCategory"))
      .withColumn("patientUid" , $"AliaspatientUid")
      .withColumn("ImmunizationCodeUid" , $"AliasImmunizationCodeUid")
      .withColumn("ImmunizationName" , $"AliasImmunizationName")
      .withColumn("ImmunizationCode" , $"AliasImmunizationCode")
      .withColumn("ImmunizationCategory" , $"AliasImmunizationCategory")
      .withColumn("ImmuStartDate" , $"AliasImmuStartDate")
      .withColumn("ImmuStopDate" , $"AliasImmuStopDate")
      .withColumn("AdministeredEffectiveDate" , $"AliasAdministeredEffectiveDate")
      .withColumn("ServiceProviderUid" , $"AliasServiceProviderUid")
      .withColumn("RepeatNumber" , $"AliasRepeatNumber")
      .withColumn("RouteUid" , $"AliasRouteUid")
      .withColumn("DoseQuantity" , $"AliasDoseQuantity")
      .withColumn("DoseQuantityUnitCode" , $"AliasDoseQuantityUnitCode")
      .withColumn("DoseQuantityUnitText" , $"AliasDoseQuantityUnitText")
      .withColumn("MasterMedicationProductFormUid" , $"AliasMasterMedicationProductFormUid")
      .withColumn("ProcedureUid" , $"AliasProcedureUid")
      .withColumn("CreatedDate" , $"AliasCreatedDate")
      .withColumn("ModifiedDate" , $"AliasModifiedDate")
      .withColumn("NegationInd" , $"AliasNegationInd")
      .withColumn("MedicationBrandName" , $"AliasMedicationBrandName")
      .withColumn("MedicationGenericName" , $"AliasMedicationGenericName")
      .withColumn("MaxDoseQuantity" , $"AliasMaxDoseQuantity")
      .withColumn("DispensingTimeOfSupply" , $"AliasDispensingTimeOfSupply")
      .withColumn("DispensingDoseQuantity" , $"AliasDispensingDoseQuantity")
      .withColumn("SupplyPrescriberLastName" , $"AliasSupplyPrescriberLastName")
      .withColumn("SupplyPrescriberFirstName" , $"AliasSupplyPrescriberFirstName")
      .withColumn("SupplyPerformerLastName" , $"AliasSupplyPerformerLastName")
      .withColumn("SupplyPerformerFirstName" , $"AliasSupplyPerformerFirstName")
      .withColumn("ServiceLocationName" , $"AliasServiceLocationName")
      .withColumn("ServiceLocationUid" , $"AliasServiceLocationUid")
      .withColumn("MedicationIndicationCriteria" , $"AliasMedicationIndicationCriteria")
      .withColumn("MedicationIndicationProblemCodeUid" , $"AliasMedicationIndicationProblemCodeUid")
      .withColumn("MedicationSeriesNumber" , $"AliasMedicationSeriesNumber")
      .withColumn("MedicationReactionProblemCodeUid" , $"AliasMedicationReactionProblemCodeUid")
      .withColumn("MasterMedicationReactionProblemServerityUid" , $"AliasMasterMedicationReactionProblemServerityUid")
      .withColumn("MasterMedicationStatusUid" , $"AliasMasterMedicationStatusUid")
      .withColumn("MedicineManufacturer" , $"AliasMedicineManufacturer")
      .withColumn("MedicineId" , $"AliasMedicineId")
      .withColumn("ProductInstanceScopingEntityId" , $"AliasProductInstanceScopingEntityId")
      .withColumn("Ordercontrol" , $"AliasOrdercontrol")
      .withColumn("PlacerOrderNumber" , $"AliasPlacerOrderNumber")
      .withColumn("FillerOrderNumber" , $"AliasFillerOrderNumber")
      .withColumn("EnteredByFirstName" , $"AliasEnteredByFirstName")
      .withColumn("EnteredByMiddleName" , $"AliasEnteredByMiddleName")
      .withColumn("EnteredByLastName" , $"AliasEnteredByLastName")
      .withColumn("OrderingProviderFirstName" , $"AliasOrderingProviderFirstName")
      .withColumn("OrderingProviderMiddleName" , $"AliasOrderingProviderMiddleName")
      .withColumn("OrderingProviderLastName" , $"AliasOrderingProviderLastName")
      .withColumn("EnteringOrganization" , $"AliasEnteringOrganization")
      .withColumn("SubstanceLotNumber" , $"AliasSubstanceLotNumber")
      .withColumn("SubstanceExpirationDate" , $"AliasSubstanceExpirationDate")
      .withColumn("ActionCode" , $"AliasActionCode")
      .withColumn("AdministrationSite" , $"AliasAdministrationSite")
      .withColumn("patientimmunizationkey" , $"Aliasimmunizationkey")
      .withColumn("CodeSystem" , $"AliasImmunizationCategory")
      .drop("AliaspatientUid","AliasImmunizationCodeUid","AliasImmunizationName","AliasImmunizationCode",
        "AliasImmunizationCategory","AliasImmuStartDate","AliasImmuStopDate","AliasAdministeredEffectiveDate",
        "AliasServiceProviderUid","AliasRepeatNumber","AliasRouteUid","AliasDoseQuantity","AliasDoseQuantityUnitCode",
        "AliasDoseQuantityUnitText","AliasMasterMedicationProductFormUid","AliasProcedureUid","AliasCreatedDate",
        "AliasModifiedDate","AliasNegationInd","AliasMedicationBrandName","AliasMedicationGenericName",
        "AliasMaxDoseQuantity","AliasDispensingTimeOfSupply","AliasDispensingDoseQuantity",
        "AliasSupplyPrescriberLastName","AliasSupplyPrescriberFirstName","AliasSupplyPerformerLastName",
        "AliasSupplyPerformerFirstName","AliasServiceLocationName","AliasServiceLocationUid",
        "AliasMedicationIndicationCriteria","AliasMedicationIndicationProblemCodeUid","AliasMedicationSeriesNumber",
        "AliasMedicationReactionProblemCodeUid","AliasMasterMedicationReactionProblemServerityUid",
        "AliasMasterMedicationStatusUid","AliasMedicineManufacturer","AliasMedicineId",
        "AliasProductInstanceScopingEntityId","AliasOrdercontrol","AliasPlacerOrderNumber","AliasFillerOrderNumber",
        "AliasEnteredByFirstName","AliasEnteredByMiddleName","AliasEnteredByLastName","AliasOrderingProviderFirstName",
        "AliasOrderingProviderMiddleName","AliasOrderingProviderLastName","AliasEnteringOrganization",
        "AliasSubstanceLotNumber","AliasSubstanceExpirationDate","AliasActionCode","AliasAdministrationSite",
        "Aliasimmunizationkey","AliasImmunizationCategory")


    val whereclauseUpdatepphDF = CleanData3.filter($"StatusId" === 1).as("df1")
      .join(PatientImmunizationTable.as("df2"), Seq("PatientImmunizationUid"))
      .select($"df2.*")

    val ExceptUpdatepphDF = PatientImmunizationTable.except(whereclauseUpdatepphDF)
    var PatientImmunizationTable_Delta = UpdatepphDF.union(ExceptUpdatepphDF)

    val InsertIntoPatientImmunization = PatientImmunizationTable_Delta.filter($"StatusId" === 1
      && $"PatientImmunizationUid".isNull).as("df1")
      .join(CleanData3.as("df2"), $"df1.PatientImmunizationUid" === $"df2.PatientImmunizationUid","left")
      .select($"df2.ProcedureUid",$"df2.ModifiedDate",$"df2.ImmunizationCodeUid".as("ImmunizationcodeUid"),$"df2.NegationInd",$"df2.MedicationBrandName",
        $"df2.MedicationGenericName",$"df2.MaxDoseQuantity",$"df2.DispensingTimeOfSupply",$"df2.DispensingDoseQuantity",
        $"df2.SupplyPrescriberLastName",$"df2.SupplyPrescriberFirstName",$"df2.SupplyPerformerLastName",
        $"df2.SupplyPerformerFirstName",$"df2.ServiceLocationName",$"df2.ServiceLocationUid",
        $"df2.MedicationIndicationCriteria",$"df2.MedicationIndicationProblemCodeUid",$"df2.MedicationSeriesNumber",
        $"df2.MedicationReactionProblemCodeUid",$"df2.MasterMedicationReactionProblemServerityUid",
        $"df2.MasterMedicationStatusUid",$"df2.MedicineManufacturer",$"df2.MedicineId",$"df2.ProductInstanceScopingEntityId",
        $"df2.Ordercontrol",$"df2.PlacerOrderNumber",$"df2.FillerOrderNumber",$"df2.EnteredByFirstName",
        $"df2.EnteredByMiddleName",$"df2.EnteredByLastName",$"df2.OrderingProviderFirstName",$"df2.OrderingProviderMiddleName",
        $"df2.OrderingProviderLastName",$"df2.EnteringOrganization",$"df2.SubstanceLotNumber",$"df2.SubstanceExpirationDate",
        $"df2.ActionCode",$"df2.AdministrationSite",$"df2.ImmunizationCategory".as("CodeSystem"))
      .withColumn("CreatedDate", lit(current_timestamp))

    val ImmCols = PatientImmunizationTable_Delta.columns.toSet
    val insert_Imm = InsertIntoPatientImmunization.columns.toSet
    val tot_cols3 = ImmCols ++ insert_Imm

    PatientImmunizationTable_Delta = PatientImmunizationTable_Delta.select(FunctionUtility.addColumns(ImmCols, tot_cols3): _*)
      .union(InsertIntoPatientImmunization.select(FunctionUtility.addColumns(insert_Imm, tot_cols3): _*))


    List(PatientImmunizationTable_Delta,Individual_prod_Delta5,ServiceProvider_prod_Delta4)
  }

}

