package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class CachePlanOfCare {

  def CachePlanOfCareFunc(spark : SparkSession,MergePracticeMap : DataFrame
                          ,CDRPatientCrosswalkTable : DataFrame
                          ,Master_prod : DataFrame
                          ,Patient_Prod_Delta : DataFrame
                          ,Individual_prod_Delta5 : DataFrame
                          ,MappingPracticeCommonData_Delta : DataFrame
                          ,PatientProblem_Prod : DataFrame) : List[DataFrame] = {

    val logger = LoggerFactory.getLogger("")
    import spark.implicits._
    //Start PlanOfCare

    var CachePlanOfCare = spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/52ddf45c-6d51-418f-be58-eb8ce57fa2a1_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")

    val lookup3_CachePlanOFCare = Map("_c0" -> "PatientId", "_c1" -> "PatientRaceCode", "_c2" -> "PatientRaceText"
      , "_c3" -> "PatientRaceKey", "_c4" -> "PracticeUid"
      , "_c5" -> "BatchUid", "_c6" -> "dummy1", "_c7" -> "dummy2")

    CachePlanOfCare = CachePlanOfCare.select(CachePlanOfCare.columns.map(c => col(c).as(lookup3_CachePlanOFCare.getOrElse(c, c))): _*)

    val tempCachePlanOfCareCols = spark.read.option("header", "true")
      .csv("/home/ravikant.petkar/Downloads/AAO_Projects/AAO_DATA/Schema/CachePlanOfCare")

    val CachePlanOfCareColls = tempCachePlanOfCareCols.columns.toSet
    val viewCachePlanOFCarecolls = CachePlanOfCare.columns.toSet
    val total_view_CachePlanOFCare = CachePlanOfCareColls ++ viewCachePlanOFCarecolls

    CachePlanOfCare = tempCachePlanOfCareCols.select(FunctionUtility.addColumns(CachePlanOfCareColls, total_view_CachePlanOFCare): _*)
      .union(CachePlanOfCare.select(FunctionUtility.addColumns(viewCachePlanOFCarecolls, total_view_CachePlanOFCare): _*))
      .drop("dummy1", "dummy2")

    CachePlanOfCare = CachePlanOfCare.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))


    //Update PracticeUid = OriginalPracticeuid

    val dist_Prac_Uid_CachePlanOfCare = CachePlanOfCare.filter($"StatusId".isNull).select("PracticeUid").distinct()

    val tempMergePracticeMap_CachePlanOfCare = MergePracticeMap.as("df1").join(dist_Prac_Uid_CachePlanOfCare.as("df2")
      , $"df1.NewPracticeuid" === $"df2.PracticeUid").select($"df1.*")

    //Update PracticeUid with OriginalPracticeuid of CachePlanOfCare
    CachePlanOfCare = CachePlanOfCare.as("df1").join(tempMergePracticeMap_CachePlanOfCare.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeuid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeuid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeuid of CachePlanOfCare is Done.............................")

    CachePlanOfCare = CachePlanOfCare.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CachePlanOfCare
    CachePlanOfCare = CachePlanOfCare.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PatientId", rtrim(ltrim($"df1.PatientId")))
      .withColumn("PlanOfCareCode", rtrim(ltrim($"df1.PlanOfCareCode")))
      .withColumn("PlanOfCareText", rtrim(ltrim($"df1.PlanOfCareText")))

    logger.warn("Update Multiple Columns of CachePlanOfCare is Done............")

    //Update Multiple Status Of CachePlanOfCare
    val update_Status_CachePlanOfCare = CachePlanOfCare.filter($"StatusId" === 1 && $"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val where_Status_CachePlanOfCare = CachePlanOfCare.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_Status_CachePlanOfCare.count > 0) {
      val ex = CachePlanOfCare.except(where_Status_CachePlanOfCare)
      CachePlanOfCare = ex.union(update_Status_CachePlanOfCare)
    }

    logger.warn("Update Multiple Status Of CachePlanOfCare is Done............")

    //Update PatientId using CDRPatientCrosswalk In CachePLanOfCare Table

    val updatePatientIdCachePlanOfcare = CachePlanOfCare.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientIdCachePlanOfCare = CachePlanOfCare.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientIdCachePlanOfCare.count > 0) {
      val ex = CachePlanOfCare.except(where_PatientIdCachePlanOfCare)
      CachePlanOfCare = ex.union(updatePatientIdCachePlanOfcare)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk In CachePlanOfCare Table is Done............")

    //Update PatientUid Of CachePlanOfCare using Individual and Patient table

    val aa12 = CachePlanOfCare.filter($"StatusId" === 1 && $"PlanOfCareCode".isNull
      && $"PlanOfCareText".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PlanOfCareCode,PlanOfCareText  Not Found"))

    val bb12 = CachePlanOfCare.filter($"StatusId" === 1 && $"EffectiveDate".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Effective Date Is Null/Blank"))

    val update_status_CachePlanOfCare2 = aa12.union(bb12)

    val where_CachePlanOfCode = CachePlanOfCare.filter($"StatusId" === 1 && ($"PlanOfCareCode".isNull
      && $"PlanOfCareText".isNull))

    if (where_CachePlanOfCode.count > 0) {
      val ex = CachePlanOfCare.except(where_CachePlanOfCode)
      CachePlanOfCare = ex.union(update_status_CachePlanOfCare2)

    }

    val update_PatientUid_CachePlanOfCare = CachePlanOfCare.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta5.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val where_Pc  = CachePlanOfCare.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta5.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    val ex_PC = CachePlanOfCare.except(where_Pc)
    CachePlanOfCare = ex_PC.union(update_PatientUid_CachePlanOfCare)

    val update_Status_CachePlanOfCare2 = CachePlanOfCare.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_Status_CachePlanOfCare2 = CachePlanOfCare.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_Status_CachePlanOfCare2.count > 0) {
      val ex = CachePlanOfCare.except(where_Status_CachePlanOfCare2)
      CachePlanOfCare = ex.union(update_Status_CachePlanOfCare2)
    }

    logger.warn("Update PatientUid Of CachePlanOfCare using Individual and Patient table is Done............")

    //update PlanOfCareUid of CachePlanOfCare using MappingPracticeCommon
    val update_CachePlanOfCareCodeUid = CachePlanOfCare.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PlanOfCareCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectiONUid" === "45E70FEA-CB49-4305-BFC3-870AA637764E")
      .where($"df1.StatusId" === 1 && $"df1.PlanOfCareUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("PlanOfCareUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_CachePlanOfCareUid = CachePlanOfCare.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemTypeCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "45E70FEA-CB49-4305-BFC3-870AA637764E")
      .where($"df1.StatusId" === 1 && $"df1.ProblemTypeCodeUid".isNull)
      .select($"df1.*")

    if (where_CachePlanOfCareUid.count > 0) {
      val ex = CachePlanOfCare.except(where_CachePlanOfCareUid)
      CachePlanOfCare = ex.union(update_CachePlanOfCareCodeUid)
    }
    logger.warn("update ProblemTypeCodeUid of CachePlanOfCare using MappingPracticeCommon is Done....")

    //update CachePlanOfCareUid of CachePlanOfCare using MappingPracticeCommon
    val update_CachePlanOfCareUid2 = CachePlanOfCare.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PlanOfCareText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectiONUid" === "45E70FEA-CB49-4305-BFC3-870AA637764E")
      .where($"df1.StatusId" === 1 && $"df1.PlanOfCareUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("PlanOfCareUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_CachePlanOfCareUid2 = CachePlanOfCare.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PlanOfCareText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "45E70FEA-CB49-4305-BFC3-870AA637764E")
      .where($"df1.StatusId" === 1 && $"df1.PlanOfCareUid".isNull)
      .select($"df1.*")

    if (where_CachePlanOfCareUid2.count > 0) {
      val ex = CachePlanOfCare.except(where_CachePlanOfCareUid2)
      CachePlanOfCare = ex.union(update_CachePlanOfCareUid2)
    }
    logger.warn("update PlanOfCareUid of CachePlanOfCare using MappingPracticeCommon is Done....")

    //Update PlanOfCareUid from Master Table of CachePlanOfCare
    val update_PlanOfCareUid3 = CachePlanOfCare.as("df1").join(Master_prod.as("df2"),
      $"df1.PlanOfCareCode" === $"df2.Code" || $"df1.PlanOfCareText" === $"df2.Name" && ($"df2.TYPE" like "planofcare[_]%"))
      .filter($"df1.StatusId" === 1 && $"df1.PlanOfCareUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("PlanOfCareUid", $"aliasMasterUid")
      .withColumn("ErrorNote", lit("Null"))
      .drop("aliasMasterUid")

    val where_PlanOfCareUid3 = CachePlanOfCare.as("df1").join(Master_prod.as("df2"),
      $"df1.PlanOfCareCode" === $"df2.Code" || $"df1.PlanOfCareText" === $"df2.Name" && ($"df2.TYPE" like "planofcare[_]%"))
      .filter($"df1.StatusId" === 1 && $"df1.PlanOfCareUid".isNull)
      .select($"df1.*")

    if (where_PlanOfCareUid3.count > 0) {
      val ex = CachePlanOfCare.except(where_PlanOfCareUid3)
      CachePlanOfCare = ex.union(update_PlanOfCareUid3)
    }
    logger.warn("Update PlanOfCareUid from Master Table of CachePlanOfCode is Done......")

    //Update Status if PlanOfCareData is not Null OR PlanOfCareCode/Text is not Null Of CachePlanOfCare table
    val update_Status_CachePlanOfCare337 = CachePlanOfCare.filter($"StatusId" === 1
      && rtrim(ltrim($"PlanOfCareCode")).isNotNull || rtrim(ltrim($"PlanOfCareText")).isNotNull && $"ProblemStatusUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PlanOfCareCode/Text Not Mapped"))

    val where_Status_CachePlanOfCare337 = CachePlanOfCare.filter($"StatusId" === 1
      && rtrim(ltrim($"PlanOfCareCode")).isNotNull || rtrim(ltrim($"PlanOfCareText")).isNotNull && $"ProblemStatusUid".isNull)

    if (where_Status_CachePlanOfCare337.count > 0) {
      val ex = CachePlanOfCare.except(where_Status_CachePlanOfCare337)
      CachePlanOfCare = ex.union(update_Status_CachePlanOfCare337)
    }
    logger.warn("Update Status if PlanOfCareData is not Null OR PlanOfCareCode/Text is not Null Of CachePlanOfCare table is Done......")

    //update PlanOfCareStatusUid of CachePlanOfCare using MappingPracticeCommon
    val update_CachePlanOfCareStatusUid = CachePlanOfCare.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PlanOfCareStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectiONUid" === "73AC1A40-2CB5-4ED1-AE2B-7029CA71C871")
      .where($"df1.StatusId" === 1 && $"df1.PlanOfCareStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("PlanOfCareStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_PlanOfCareStatusUid = CachePlanOfCare.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PlanOfCareStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "73AC1A40-2CB5-4ED1-AE2B-7029CA71C871")
      .where($"df1.StatusId" === 1 && $"df1.PlanOfCareStatusUid".isNull)
      .select($"df1.*")

    if (where_PlanOfCareStatusUid.count > 0) {
      val ex = CachePlanOfCare.except(where_PlanOfCareStatusUid)
      CachePlanOfCare = ex.union(update_CachePlanOfCareStatusUid)
    }
    logger.warn("update PlanOfCareStatusUid of CachePlanOfCare using MappingPracticeCommon is Done....")

    //update PlanOfCareStatusUid of CachePlanOfCare using MappingPracticeCommon 2
    val update_CachePlanOfCareStatusUid2 = CachePlanOfCare.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PlanOfCareStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectiONUid" === "73AC1A40-2CB5-4ED1-AE2B-7029CA71C871")
      .where($"df1.StatusId" === 1 && $"df1.PlanOfCareStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("PlanOfCareStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_PlanOfCareStatusUid2 = CachePlanOfCare.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PlanOfCareStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "73AC1A40-2CB5-4ED1-AE2B-7029CA71C871")
      .where($"df1.StatusId" === 1 && $"df1.PlanOfCareStatusUid".isNull)
      .select($"df1.*")

    if (where_PlanOfCareStatusUid2.count > 0) {
      val ex = CachePlanOfCare.except(where_PlanOfCareStatusUid2)
      CachePlanOfCare = ex.union(update_CachePlanOfCareStatusUid2)
    }
    logger.warn("update PlanOfCareStatusUid of CachePlanOfCare using MappingPracticeCommon 2 is Done....")

    //update PlanOfCareStatusUid of CachePlanOfCare using Master table
    val update_PlanOfCareStatusUid_CachePlanOfCare3 = CachePlanOfCare.as("df1").join(Master_prod.as("df2"),
      $"df1.PlanOfCareStatusCode" === $"df2.Code" || $"df1.PlanOfCareStatusText" === $"df2.Name" && $"df2.PlanOfCareStatus")
      .filter($"df1.StatusId" === 1 && $"df1.PlanOfCareStatusUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("PlanOfCareStatusUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_PlanOfCareStatusUid_CachePlanOfCare3 = CachePlanOfCare.as("df1").join(Master_prod.as("df2"),
      $"df1.PlanOfCareStatusCode" === $"df2.Code")
      .filter($"df1.StatusId" === 1 && $"df1.PlanOfCareStatusUid".isNull)
      .select($"df1.*")

    if (where_PlanOfCareStatusUid_CachePlanOfCare3.count > 0) {
      val ex = CachePlanOfCare.except(where_PlanOfCareStatusUid_CachePlanOfCare3)
      CachePlanOfCare = ex.union(update_PlanOfCareStatusUid_CachePlanOfCare3)
    }
    logger.warn("update PlanOfCareStatusUid of CachePlanOfCare using Master table is Done......")

    //Update Status if PlanOfCareStatusCode is not Null OR PlanOfCareStatusText is not Null Of CachePlanOfCare table
    val update_Status_CachePlanOfCare3378 = CachePlanOfCare.filter($"StatusId" === 1
      && rtrim(ltrim($"PlanOfCareStatusCode")).isNotNull || rtrim(ltrim($"PlanOfCareStatusText")).isNotNull
      && $"PlanOfCareStatusUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PlanOfCareStatusCode/Text Not Mapped"))

    val where_Status_CachePlanOfCare3378 = CachePlanOfCare.filter($"StatusId" === 1
      && rtrim(ltrim($"PlanOfCareStatusCode")).isNotNull || rtrim(ltrim($"PlanOfCareStatusText")).isNotNull
      && $"PlanOfCareStatusUid".isNull)

    if (where_Status_CachePlanOfCare3378.count > 0) {
      val ex = CachePlanOfCare.except(where_Status_CachePlanOfCare3378)
      CachePlanOfCare = ex.union(update_Status_CachePlanOfCare3378)
    }
    logger.warn("Update Status if PlanOfCareStatusCode is not Null OR PlanOfCareStatusText is not Null Of CachePlanOfCare table is Done......")

    //Update PatientPlanOfCareUid of CachePlacOfCare using PatientProblem_Prod table

    val update_PatientPlanOfCareUid_CachePlanOfCare = CachePlanOfCare.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PlanOfCareUid" === $"df2.MasterPlanOfCareUid" && $"df1.EffectiveDate" === $"df2.EffectiveDate" && $"df1.PatientPlanOfCareUid".isNull)
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientPlanOfCareUid".as("aliasPatientProblemUid"))
      .withColumn("PatientPlanOfCareUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientPlanOfCareUid_CachePlanOfCare = CachePlanOfCare.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PlanOfCareUid" === $"df2.MasterPlanOfCareUid" && $"df1.EffectiveDate" === $"df2.EffectiveDate"  && $"df1.PatientPlanOfCareUid".isNull)
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientPlanOfCareUid_CachePlanOfCare.count > 0) {
      val ex = CachePlanOfCare.except(where_PatientPlanOfCareUid_CachePlanOfCare)
      CachePlanOfCare = ex.union(update_PatientPlanOfCareUid_CachePlanOfCare)
    }

    logger.warn("Update PatientPlanOfCareUid of CachePlacOfCare using PatientProblem_Prod table is Done............")

    //Update PatientPlanOfCareUid of CachePlacOfCare using PatientProblem_Prod table 2

    val update_PatientPlanOfCareUid_CachePlanOfCare2 = CachePlanOfCare.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PlanOfCareUid" === $"df2.MasterPlanOfCareUid" && $"df1.PatientPlanOfCareUid".isNull
        && $"df1.EffectiveDate".isNull)
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientPlanOfCareUid".as("aliasPatientProblemUid"))
      .withColumn("PatientPlanOfCareUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientPlanOfCareUid_CachePlanOfCare2 = CachePlanOfCare.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PlanOfCareUid" === $"df2.MasterPlanOfCareUid" && $"df1.PatientPlanOfCareUid".isNull
        && $"df1.EffectiveDate".isNull)
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientPlanOfCareUid_CachePlanOfCare2.count > 0) {
      val ex = CachePlanOfCare.except(where_PatientPlanOfCareUid_CachePlanOfCare2)
      CachePlanOfCare = ex.union(update_PatientPlanOfCareUid_CachePlanOfCare2)
    }

    logger.warn("Update PatientPlanOfCareUid of CachePlacOfCare using PatientProblem_Prod table 2 is Done............")

    //create #PlanOfCare

    val PlanOfCare2121 = CachePlanOfCare.filter($"StatusId" === 1 && $"PatientPlanOfCareUid".isNull && $"EffectiveDate".isNull)
      .select("PatientUid", "PlanOfCareUid", "EffectiveDate").distinct()
      .withColumn("PatientPlanOfCareUid", FunctionUtility.getNewUid())

    //Update New PatientPlanOfCareUid of CachePlanOfCare Table Using #PlanOfCare Table

    val update_PatientPUid_CachePlanOfCare = CachePlanOfCare.as("df1").join(PlanOfCare2121.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PlanOfCareUid" === $"df2.PlanOfCareUid" && $"df1.EffectiveDate" === $"df2.EffectiveDate")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientPlanOfCareUid".as("aliasPatientProblemUid"))
      .withColumn("PatientPlanOfCareUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientPUid_CachePlanOfCare = CachePlanOfCare.as("df1").join(PlanOfCare2121.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PlanOfCareUid" === $"df2.PlanOfCareUid" && $"df1.EffectiveDate" === $"df2.EffectiveDate")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientPUid_CachePlanOfCare.count > 0) {
      val ex = CachePlanOfCare.except(where_PatientPUid_CachePlanOfCare)
      CachePlanOfCare = ex.union(update_PatientPUid_CachePlanOfCare)
    }
    logger.warn("Update New PatientPlanOfCareUid of CachePlanOfCare Table Using #PlanOfCare Table is Done............")

    //create #PlanOfCare1

    val PlanOfCare21212 = CachePlanOfCare.filter($"StatusId" === 1 && $"PatientPlanOfCareUid".isNull && $"EffectiveDate".isNull)
      .select("PatientUid", "PlanOfCareUid").distinct()
      .withColumn("PatientPlanOfCareUid", FunctionUtility.getNewUid())

    //Update New PatientPlanOfCareUid of CachePlanOfCare Table Using #PlanOfCare2 Table

    val update_PatientPUid_CachePlanOfCare2 = CachePlanOfCare.as("df1").join(PlanOfCare21212.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PlanOfCareUid" === $"df2.PlanOfCareUid" && $"df2.PatientPlanOfCareUid".isNull)
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull && $"df1.CodeUid".isNull)
      .select($"df1.*", $"df2.PatientPlanOfCareUid".as("aliasPatientProblemUid"))
      .withColumn("PatientPlanOfCareUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientPUid_CachePlanOfCare2 = CachePlanOfCare.as("df1").join(PlanOfCare21212.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PlanOfCareUid" === $"df2.PlanOfCareUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull && $"df1.CodeUid".isNull)
      .select($"df1.*")

    if (where_PatientPUid_CachePlanOfCare2.count > 0) {
      val ex = CachePlanOfCare.except(where_PatientPUid_CachePlanOfCare2)
      CachePlanOfCare = ex.union(update_PatientPUid_CachePlanOfCare2)
    }
    logger.warn("Update New PatientPlanOfCareUid of CachePlanOfCare Table Using #PlanOfCare2 Table is Done............")

    val update_PatientPlanOfCareUid_CachePlanOfCare21 = CachePlanOfCare.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientPlanOfCareUid" === $"df2.PatientPlanOfCareUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.InstructiONs".as("aliasInstruction"), $"df2.PracticeCode".as("aliasPracticeCode"),
        $"df2.PracticeDescription".as("aliasPracDescption"), $"df2.MasterPlanOfCareStatusUid".as("aliasMasterPlanOfcarestsUid"),
        $"df2.PlanOfCareStatusUid".as("aliasPlanOfCarestsUid"), $"df2.PlanOfCareGroup".as("aliasPlanOfGrp"))
      .withColumn("InstructiONs", $"aliasInstruction").withColumn("PlanOfCareCode", $"aliasPracticeCode").withColumn("PlanOfCareText", $"aliasPracDescption").withColumn("PlanOfCareStatusUid", $"aliasMasterPlanOfcarestsUid").
      withColumn("PlanOfCareGroup", $"aliasPlanOfGrp")
      .drop("aliasInstruction")

    val where_PatientPlanOfCareUid_CachePlanOfCare21 = CachePlanOfCare.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientPlanOfCareUid" === $"df2.PatientPlanOfCareUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientPlanOfCareUid_CachePlanOfCare21.count > 0) {
      val ex = CachePlanOfCare.except(where_PatientPlanOfCareUid_CachePlanOfCare21)
      CachePlanOfCare = ex.union(update_PatientPlanOfCareUid_CachePlanOfCare21)
    }
    logger.warn("Update UPDATE Old Record In PatientPlanOfCare of CachePlanOfCare Table Using #PatientProblem_Prod Table is Done............")

    //Insert care plan Data Into PatientPlanOfCare
    val insert_PatientPlanOfCare = CachePlanOfCare.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientPlanOfCareUid" === $"df2.PatientPlanOfCareUid", "left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.PatientPlanOfCareUid".isNull)
      .select($"df1.PatientPlanOfCareUid", $"df1.PatientUid", $"df1.EffectiveDate", $"df1.InstructiONs"
        , $"df1.PlanOfCareUid", $"df1.PlanOfCareStatusUid", $"df1.PlanOfCareGroup", $"df1.PlanOfCareCode", $"df1.PracticeCode", $"df1.PlanOfCareText")

    logger.warn("Insert data into PatientPlanOfCare table Using CachePlanOfCare table is Done............")

    val allcols = PatientProblem_Prod.columns.toSet
    val insertcols = insert_PatientPlanOfCare.columns.toSet
    val tot_cols3 = allcols ++ insertcols

    val PatientProblem_Prod_Delta = PatientProblem_Prod.select(FunctionUtility.addColumns(allcols, tot_cols3): _*)
      .union(insert_PatientPlanOfCare.select(FunctionUtility.addColumns(insertcols, tot_cols3): _*))

    logger.warn("Update Status of CachePlanOfCare table is Done............")

    //End CachePlanOfCare Sp..........................................


    List(PatientProblem_Prod_Delta)
  }

}
