package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class CacheResultObservation {

  def CacheResultObservationFunc(spark : SparkSession,MergePracticeMap : DataFrame
                                 ,CDRPatientCrosswalkTable : DataFrame
                                 ,MasterCode_Prod : DataFrame
                                 ,MultiTableExtendTable : DataFrame
                                 ,Individual : DataFrame
                                 ,ProviderNPIChangeTable : DataFrame
                                 ,ViewServiceProvider_prod : DataFrame
                                 ,distIndUid : DataFrame
                                 ,distspUID : DataFrame
                                 ,Master_prod : DataFrame
                                 ,MappingPracticeLabResult_Delta : DataFrame
                                 ,Patient_Prod_Delta : DataFrame
                                 ,Individual_prod_Delta5 : DataFrame
                                 ,ServiceProvider_prod_Delta4 : DataFrame
                                 ,PatientResultObservation_Prod : DataFrame
                                 ,MappingPracticeCommonData_Delta : DataFrame
                                 ,MappingPracticeProcedure_Delta : DataFrame) : List[DataFrame] = {

    val logger = LoggerFactory.getLogger("")

    import spark.implicits._

    //Start CacheResultObservation
    var CacheResultObservation =  spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9")

    val lookup10 = Map("_c0" -> "PatientId", "_c1" -> "ObservationCode", "_c2" -> "ObservationName"
      , "_c3" -> "ObservationCategory", "_c4" -> "ObservationDate", "_c5" -> "ObservationValue"
      , "_c6" -> "ObsInterpretationCode", "_c7" -> "ObsInterpretationText", "_c8" -> "TargetSiteCode"
      , "_c9" -> "TargetSiteText", "_c10" -> "ServiceProviderNPI", "_c11" -> "ServiceProviderLastName"
      , "_c12" -> "ServiceProviderFirstName", "_c13" -> "NegationInd","_c14" -> "ReferenceLowerRange"
      ,"_c15" -> "ReferenceUpperRange", "_c16" -> "MethodCode", "_c17" -> "MethodCodeText"
      , "_c18" -> "SpecimenId", "_c19" -> "ProcedureCode", "_c20" -> "ProcedureText"
      , "_c21" -> "ProcedureCategory", "_c22" -> "ResultObservationStatus", "_c23" -> "ResultOrderDescription"
      , "_c24" -> "ResultOrderDate", "_c25" -> "ResultOBSUnit", "_c26" -> "LaboratoryID"
      , "_c27" -> "LaboratoryName", "_c28" -> "ResultOrderCode", "_c29" -> "Obssubid"
      , "_c30" -> "ResultObservationKey", "_c31" -> "PracticeUid", "_c32" -> "BatchUid"
      , "_c33" -> "dummy1", "_c34" -> "dummy2")

    CacheResultObservation = CacheResultObservation.select(CacheResultObservation.columns.map(c => col(c).as(lookup10.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    val tempCacheResultObservation = spark.read.option("header", "true")
      .csv("/home/gajanan.doifode/AAO_DATA/Schema/CacheResultObservation.txt")

    val CacheRObservationAllcols = tempCacheResultObservation.columns.toSet
    val CacheRObservationViewcols = CacheResultObservation.columns.toSet
    val tot_viewCRO_cacheRObs = CacheRObservationAllcols ++ CacheRObservationViewcols

    CacheResultObservation = tempCacheResultObservation.select(FunctionUtility.addColumns(CacheRObservationAllcols, tot_viewCRO_cacheRObs): _*)
      .union(CacheResultObservation.select(FunctionUtility.addColumns(CacheRObservationViewcols, tot_viewCRO_cacheRObs): _*))

    CacheResultObservation = CacheResultObservation.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    val dist_PUID_ResObs = CacheResultObservation.filter($"StatusId".isNull).select("PracticeUid").distinct()

    val MergePracticeMap_ResObs = MergePracticeMap.as("df1").join(dist_PUID_ResObs.as("df2")
      , $"df1.NewPracticeUid" === $"df2.PracticeUid").select($"df1.*")


    //Update PracticeUid with OriginalPracticeUid of CacheResultObservation
    CacheResultObservation = CacheResultObservation.as("df1").join(MergePracticeMap_ResObs.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeUid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeUid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeUid of CacheResultObservation is Done.................")

    CacheResultObservation = CacheResultObservation.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CacheResultObservation
    CacheResultObservation = CacheResultObservation.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PatientId", ltrim(rtrim($"df1.PatientId")))
      .withColumn("ServiceProviderNPI", ltrim(rtrim($"df1.ServiceProviderNPI")))
      .withColumn("ObservationCode", ltrim(rtrim($"df1.ObservationCode")))
      .withColumn("PracticeSideNPI", ltrim(rtrim($"df1.ServiceProviderNPI")))

    logger.warn("Update Multiple Columns of CacheResultObservation is Done............")

    //update status if PatientId is null Of CacheResultObservation
    val update_status_ResObs = CacheResultObservation.filter($"StatusId" === 1 && $"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val where_status_ResObs = CacheResultObservation.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_status_ResObs.count > 0) {
      val ex = CacheResultObservation.except(where_status_ResObs)
      CacheResultObservation = ex.union(update_status_ResObs)
    }

    logger.warn("update status if PatientId is null Of CacheResultObservation is Done........")

    //Update PatientId using CDRPatientCrosswalk Of CacheResultObservation Table
    val update_PatientId_ResObs = CacheResultObservation.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientId_ResObs = CacheResultObservation.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientId_ResObs.count > 0) {
      val ex = CacheResultObservation.except(where_PatientId_ResObs)
      CacheResultObservation = ex.union(update_PatientId_ResObs)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk Of CacheResultObservation Table is Done........")

    //Update ObservationCodeUid of CacheResultObservation
    val update_ObservationCode = CacheResultObservation.as("df1").join(MappingPracticeLabResult_Delta.as("df2")
      ,$"df1.ObservationCode" === $"d2.PracticeValue" || rtrim(ltrim($"df1.ObservationName")) === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid" && $"df2.CodeUid".isNotNull)
      .filter($"df1.StatusId" === 1 && $"df1.ObservationCodeUid".isNull)
      .select($"df1.*",$"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("ObservationCodeUid",$"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_ObservationCode = CacheResultObservation.as("df1").join(MappingPracticeLabResult_Delta.as("df2")
      ,$"df1.ObservationCode" === $"d2.PracticeValue" || rtrim(ltrim($"df1.ObservationName")) === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid" && $"df2.CodeUid".isNotNull)
      .filter($"df1.StatusId" === 1 && $"df1.ObservationCodeUid".isNull)
      .select($"df1.*")

    if (where_ObservationCode.count > 0) {
      val ex = CacheResultObservation.except(where_ObservationCode)
      CacheResultObservation = ex.union(update_ObservationCode)
    }

    logger.warn("Update ObservationCodeUid of CacheResultObservation is Done........")


    //Update ObservationCodeUid of CacheResultObservation 2
    val update_ObservationCode2 = CacheResultObservation.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.ObservationCode" === $"df2.Code" && $"df1.ObservationCategory" === $"df2.CodeSystem")
      .where($"df1.StatusId" === 1 && $"df1.ObservationCodeUid".isNull)
      .select($"df1.*", $"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("ObservationCodeUid", $"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_ObservationCode2 = CacheResultObservation.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.ObservationCode" === $"df2.Code" && $"df1.ObservationCategory" === $"df2.CodeSystem")
      .where($"df1.StatusId" === 1 && $"df1.ObservationCodeUid".isNull)
      .select($"df1.*")

    if (where_ObservationCode2.count > 0) {
      val ex = CacheResultObservation.except(where_ObservationCode2)
      CacheResultObservation = ex.union(update_ObservationCode2)
    }

    logger.warn("Update ObservationCodeUid of CacheResultObservation 2 is Done........")

    //update status if ObservationName & ObservationCode is null Of CacheResultObservation
    val update_status_ResObs1 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationCode".isNull ||
      $"ObservationCode" === "NULL" && $"ObservationName".isNull || $"ObservationName" === "NULL")
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ObservationCode,Name Not Found"))

    val where_status_ResObs1 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationCode".isNull ||
      $"ObservationCode" === "NULL" && $"ObservationName".isNull || $"ObservationName" === "NULL")

    if (where_status_ResObs1.count > 0) {
      val ex = CacheResultObservation.except(where_status_ResObs1)
      CacheResultObservation = ex.union(update_status_ResObs1)
    }

    logger.warn("update status if ObservationName & ObservationCode is null Of CacheResultObservation  is Done........")

    //update status if ObservationName & ObservationCodeUid is null Of CacheResultObservation
    val update_status_ResObs2 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationName".isNull
      && $"ObservationCodeUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ObservationCode,Name Not Found"))

    val where_status_ResObs2 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationName".isNull
      && $"ObservationCodeUid".isNull)

    if (where_status_ResObs2.count > 0) {
      val ex = CacheResultObservation.except(where_status_ResObs2)
      CacheResultObservation = ex.union(update_status_ResObs2)
    }

    logger.warn("update status if ObservationName & ObservationCodeUid is null Of CacheResultObservation  is Done........")

    //update status if ObservationName & ObservationName is null Of CacheResultObservation 2
    val update_status_ResObs3 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationName".isNull
      && $"ObservationCode".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ObservationCode and ObservationText Not Found"))

    val where_status_ResObs3 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationName".isNull
      && $"ObservationCode".isNull)

    if (where_status_ResObs3.count > 0) {
      val ex = CacheResultObservation.except(where_status_ResObs3)
      CacheResultObservation = ex.union(update_status_ResObs3)
    }

    logger.warn("update status if ObservationName & ObservationCode is null Of CacheResultObservation 2 is Done........")

    //update status if ObservationName is null of CacheResultObservation
    val update_status_ResObs4 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationName".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ObservationName Not Found"))

    val where_status_ResObs4 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationName".isNull)

    if (where_status_ResObs4.count > 0) {
      val ex = CacheResultObservation.except(where_status_ResObs4)
      CacheResultObservation = ex.union(update_status_ResObs4)
    }

    logger.warn("update status if ObservationName is null of CacheResultObservation is Done........")

    //Update Status if ObservationCategory is Null CacheResultObservation
    val update_status_ResObs5 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationCategory".isNull
      && $"ObservationCode".isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ObservationCategory Not Found"))

    val where_status_ResObs5 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationCategory".isNull
      && $"ObservationCode".isNotNull)

    if (where_status_ResObs5.count > 0) {
      val ex = CacheResultObservation.except(where_status_ResObs5)
      CacheResultObservation = ex.union(update_status_ResObs5)
    }

    logger.warn("update status if ObservationCategory is null of CacheResultObservation is Done........")

    //Update Status if ObservationValue length > 1000 of CacheResultObservation
    val update_status_ResObs6 = CacheResultObservation.filter($"StatusId" === 1 && length($"ObservationValue") > 1000)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Obs value longer than 1000"))

    val where_status_ResObs6 = CacheResultObservation.filter($"StatusId" === 1 && length($"ObservationValue") > 1000)

    if (where_status_ResObs6.count > 0) {
      val ex = CacheResultObservation.except(where_status_ResObs6)
      CacheResultObservation = ex.union(update_status_ResObs6)
    }

    logger.warn("Update Status if ObservationValue length > 1000 of CacheResultObservation is Done........")

    //Update Status if ObservationDate is null of CacheResultObservation
    val update_status_ResObs7 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationDate".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ObservationDate Not Found"))

    val where_status_ResObs7 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationDate".isNull)

    if (where_status_ResObs7.count > 0) {
      val ex = CacheResultObservation.except(where_status_ResObs7)
      CacheResultObservation = ex.union(update_status_ResObs7)
    }

    logger.warn("Update Status if ObservationDate is null of CacheResultObservation is Done........")

    //Update status if ObservationValue is null of CacheResultObservation
    val update_status_ResObs8 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationValue".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ObservationValue is null"))

    val where_status_ResObs8 = CacheResultObservation.filter($"StatusId" === 1 && $"ObservationValue".isNull)

    if (where_status_ResObs8.count > 0) {
      val ex = CacheResultObservation.except(where_status_ResObs8)
      CacheResultObservation = ex.union(update_status_ResObs8)
    }

    logger.warn("Update status if ObservationValue is null of CacheResultObservation is Done........")

    //update PatientUid Using Patient_prod && Individual_prod of CacheResultObservation
    val update_PatientUid_ResObs = CacheResultObservation.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta5.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientUid".isNull)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val where_PatientUid_ResObs = CacheResultObservation.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta5.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientUid".isNull)
      .select($"df1.*")

    if (where_PatientUid_ResObs.count > 0) {
      val ex = CacheResultObservation.except(where_PatientUid_ResObs)
      CacheResultObservation = ex.union(update_PatientUid_ResObs)
    }

    logger.warn("update PatientUid Using Patient_prod && Individual_prod of CacheResultObservation is Done........")


    //Update status if PatientUid is null of CacheResultObservation
    val update_status_ResObs9 = CacheResultObservation.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_status_ResObs9 = CacheResultObservation.filter($"StatusId" === 1 && $"PatientUid".isNull)

    if (where_status_ResObs9.count > 0) {
      val ex = CacheResultObservation.except(where_status_ResObs9)
      CacheResultObservation = ex.union(update_status_ResObs9)
    }

    logger.warn("Update status if PatientUid is null of CacheResultObservation is Done........")


    //Update ServiceProvideNPI Of CacheMedications
    val Update_SPNPI_ResObs = CacheResultObservation.as("df1").join(MultiTableExtendTable.as("df2")
      , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ServiceProviderNPI" === $"df2.Element1"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"StatusId" === 1)
      .select($"df1.*", $"df2.Value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue").drop($"AliasValue")

    val where_SPNPI_ResObs = CacheResultObservation.as("df1").join(MultiTableExtendTable.as("df2")
      , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ServiceProviderNPI" === $"df2.Element1"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"StatusId" === 1)
      .select($"df1.*")

    if (where_SPNPI_ResObs.count > 0) {
      val ex = CacheResultObservation.except(where_SPNPI_ResObs)
      CacheResultObservation = ex.union(Update_SPNPI_ResObs)
    }

    logger.warn("Update ServiceProvideNPI Of CacheResultObservation is Done........")

    //update ServiceProviderNPI 2 Of CacheMedications
    val Update_SPNPI_ResObs2 = Individual.as("df1")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid")
      .join(CacheResultObservation.as("df3"), $"df3.PracticeUid" === $"df1.PracticeUid" &&
        $"df3.ServiceProviderNPI" === $"df2.OldNPI")
      .filter($"StatusId" === 1)
      .select($"df3.*", $"df2.NewNPI".as("AliasNewNPI"))
      .withColumn("ServiceProviderNPI", $"AliasNewNPI").drop($"AliasNewNPI")

    val where_SPNPI_ResObs2 = Individual.as("df1")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid")
      .join(CacheResultObservation.as("df3"), $"df3.PracticeUid" === $"df1.PracticeUid" &&
        $"df3.ServiceProviderNPI" === $"df2.OldNPI")
      .filter($"StatusId" === 1)
      .select($"df3.*")

    if (where_SPNPI_ResObs2.count > 0) {
      val ex = CacheResultObservation.except(where_SPNPI_ResObs2)
      CacheResultObservation = ex.union(Update_SPNPI_ResObs2)
    }

    logger.warn("update ServiceProviderNPI 2 Of CacheResultObservation is Done........")

    //Update ServiceProvideNPI 3 Of CacheResultObservation
    val update_SPNPI_ResObs3 = CacheResultObservation.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element1" && $"df1.ServiceProviderLastName" === $"df2.Element2"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"df1.StatusId" === 1 && $"df2.Element2".isNotNull)
      .select($"df1.*", $"df2.Value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue").drop($"AliasValue")

    val where_SPNPI_ResObs3 = CacheResultObservation.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element1" && $"df1.ServiceProviderLastName" === $"df2.Element2"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"StatusId" === 1 && $"df2.Element2".isNotNull)
      .select($"df1.*")

    if (where_SPNPI_ResObs3.count > 0) {
      val ex = CacheResultObservation.except(where_SPNPI_ResObs3)
      CacheResultObservation = ex.union(update_SPNPI_ResObs3)
    }

    logger.warn("update ServiceProviderNPI 3 Of CacheResultObservation is Done........")


    //Update status if ServiceProviderNPI length =!= 10 of CacheResultObservation
    val update_status_ResObs10 = CacheResultObservation.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_status_ResObs10 = CacheResultObservation.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)

    if (where_status_ResObs10.count > 0) {
      val ex = CacheResultObservation.except(where_status_ResObs10)
      CacheResultObservation = ex.union(update_status_ResObs10)
    }

    logger.warn("Update status if ServiceProviderNPI length =!= 10 of CacheResultObservation is Done........")

    //Update ServiceProviderUid of CacheResultObservation table
    val update_SPUID_ResObs = CacheResultObservation.as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.ServiceProviderUid".isNull)
      .select($"df1.*", $"df2.ServiceProviderUid".as("aliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"aliasServiceProviderUid")
      .drop("aliasServiceProviderUid")

    val where_SPUID_ResObs = CacheResultObservation.as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.ServiceProviderUid".isNull)
      .select($"df1.*")

    if (where_SPUID_ResObs.count > 0) {
      val ex = CacheResultObservation.except(where_SPUID_ResObs)
      CacheResultObservation = ex.union(update_SPUID_ResObs)
    }

    logger.warn("Update ServiceProviderUid of CacheResultObservation table is Done............")


    //Create Table Phy 2
    val Phy_ResultObs = CacheResultObservation.as("df1")
      .select("ServiceProviderUid", "ServiceProviderNPI", "ServiceProviderFirstName", "ServiceProviderLastName"
        , "PracticeUid", "StatusId")
      .where($"ServiceProviderNPI".isNotNull && $"ServiceProviderUid".isNull && $"StatusId" === 1)
      .groupBy($"ServiceProviderNPI", $"PracticeUid")
      .agg(max("ServiceProviderFirstName").as("ServiceProviderFirstName")
        , max("ServiceProviderLastName").as("ServiceProviderLastName"))
      .withColumn("Physician_MidName", lit("null"))
      .withColumn("ServiceProviderUid",FunctionUtility.getNewUid())

    //Update ServiceProviderUid Using PHY of CacheResultObservation
    val update_SPUID_ResObs2 = CacheResultObservation.as("df1.").join(Phy_ResultObs.as("df2")
      ,$"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderUid".isNull && $"df1.StatusId" === 1)
      .select($"df1.*",$"df2.ServiceProviderUid".as("aliasSPUID"))
      .withColumn("ServiceProviderUid",$"aliasSPUID")
      .drop("aliasSPUID")

    val where_SPUID_ResObs2 = CacheResultObservation.as("df1.").join(Phy_ResultObs.as("df2")
      ,$"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderUid".isNull && $"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_SPUID_ResObs2.count > 0) {
      val ex = CacheResultObservation.except(where_SPUID_ResObs2)
      CacheResultObservation = ex.union(update_SPUID_ResObs2)
    }

    logger.warn("Update ServiceProviderUid Using PHY of CacheResultObservation is Done........")

    //Insert data Into Individual Table using CacheResultObservation
    val insert_Individual_Prod_ResObs = Phy_ResultObs.as("df1")
      .join(distIndUid.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.IndividualUid"))
      .select($"df1.ServiceProviderUid".as("IndividualUid"), $"df1.ServiceProviderFirstName".as("First")
        , $"df1.Physician_MidName".as("Middle"), $"ServiceProviderLastName".as("Last"),
        $"df1.PracticeUid".as("PracticeUid")).distinct()

    val indicols = Individual_prod_Delta5.columns.toSet
    val insertIndividualcols = insert_Individual_Prod_ResObs.columns.toSet
    val tot1 = indicols ++ insertIndividualcols

    val Individual_prod_Delta6 = Individual_prod_Delta5.select(FunctionUtility.addColumns(indicols, tot1): _*)
      .union(insert_Individual_Prod_ResObs.select(FunctionUtility.addColumns(insertIndividualcols, tot1): _*))

    logger.warn("Insert Data into Individual table is Done............")


    //Use toSet and union and insert data into individual table

    logger.warn("Insert data Into Individual Table using CacheResultObservation is Done............")

    //Insert data Into ServiceProvider Table using CacheResultObservation
    val insert_ServiceProv_ResObs = Phy_ResultObs.as("df1").join(distspUID.as("df2")
      , !$"df1.ServiceProviderUid".isin($"df2.ServiceProviderUid"))
      .select($"df1.ServiceProviderUid", when($"df1.Physician_MidName".isNotNull, concat_ws(" "
        , $"ServiceProviderLastName", $"ServiceProviderFirstName", $"Physician_MidName"))
        .otherwise(concat_ws(" ", $"ServiceProviderLastName", $"ServiceProviderFirstName")).as("ListName")
        , $"df1.ServiceProviderNPI".as("NPI"))
      .withColumn("ExternalID", lit(null))
      .withColumn("Type", lit(4))

    val servicePcols = ServiceProvider_prod_Delta4.columns.toSet
    val insertdataServiceProvcols = insert_ServiceProv_ResObs.columns.toSet
    val tot2 = servicePcols ++ insertdataServiceProvcols

    val ServiceProvider_prod_Delta5 = ServiceProvider_prod_Delta4.select(FunctionUtility.addColumns(servicePcols, tot2): _*)
      .union(ServiceProvider_prod_Delta4.select(FunctionUtility.addColumns(insertdataServiceProvcols, tot2): _*))
    //Use toSet and union and insert data into ServiceProvider
    logger.warn("Insert data Into ServiceProvider Table using CacheResultObservation is Done............")


    //Update PatientResultObservationUid of CacheResultObservation
    val update_PatientResultObservationUid =  CacheResultObservation.as("df1").join(PatientResultObservation_Prod.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.ObservationCodeUid" === $"df2.ObservationCodeUid"
        && $"df1.ObservationDate" === $"df2.ResultDate" && $"df1.ObservationName" === $"df2.ObservationDescription")
      .filter($"d1.StatusId" === 1 && $"df1.PatientResultObservationUid".isNull)
      .select($"df1.*",$"df2.PatientResultObservationUid".as("aliasPROUID"))
      .withColumn("PatientResultObservationUid",$"aliasPROUID")
      .drop("aliasPROUID")

    val where_PatientResultObservationUid = CacheResultObservation.as("df1").join(PatientResultObservation_Prod.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.ObservationCodeUid" === $"df2.ObservationCodeUid"
        && $"df1.ObservationDate" === $"df2.ResultDate" && $"df1.ObservationName" === $"df2.ObservationDescription")
      .filter($"d1.StatusId" === 1 && $"df1.PatientResultObservationUid".isNull)
      .select($"df1.*")

    if (where_PatientResultObservationUid.count > 0) {
      val ex = CacheResultObservation.except(where_PatientResultObservationUid)
      CacheResultObservation = ex.union(update_PatientResultObservationUid)
    }

    logger.warn("Update PatientResultObservationUid of CacheResultObservation is Done........")


    //Drop Duplicate records and store in in-memory not update status = 4
    var cleanedCacheResultObservation = CacheResultObservation.dropDuplicates(Seq("PatientUid", "ObservationCodeUid"
      ,"ObservationDate","ObservationName"))
    var duplicateRecords_CacheResultObservation = CacheResultObservation.except(cleanedCacheResultObservation)

    logger.warn("Drop Duplicate records CacheResultObservation is Done............")

    //Create PatientResultObservation
    val tempPatientResultObservation = cleanedCacheResultObservation.filter($"StatusId" === 1 && $"PatientResultObservationUid".isNull)
      .select($"PatientUid",$"ObservationCodeUid",$"ObservationName",$"ObservationDate")
      .withColumn("PatientResultObservationUid",FunctionUtility.getNewUid())

    //Update PatientResultObservationUid of CacheResultObservation 2
    val update_PatientResultObservationUid2 =  cleanedCacheResultObservation.as("df1").join(tempPatientResultObservation.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.ObservationCodeUid" === $"df2.ObservationCodeUid"
        && $"df1.ObservationDate" === $"df2.ObservationDate" && $"df1.ObservationName" === $"df2.ObservationName")
      .filter($"d1.StatusId" === 1)
      .select($"df1.*",$"df2.PatientResultObservationUid".as("aliasPROUID"))
      .withColumn("PatientResultObservationUid",$"aliasPROUID")
      .drop("aliasPROUID")

    val where_PatientResultObservationUid2 = cleanedCacheResultObservation.as("df1").join(tempPatientResultObservation.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.ObservationCodeUid" === $"df2.ObservationCodeUid"
        && $"df1.ObservationDate" === $"df2.ObservationDate" && $"df1.ObservationName" === $"df2.ObservationName")
      .filter($"d1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientResultObservationUid2.count > 0) {
      val ex = cleanedCacheResultObservation.except(where_PatientResultObservationUid2)
      cleanedCacheResultObservation = ex.union(update_PatientResultObservationUid2)
    }

    logger.warn("Update PatientResultObservationUid of CacheResultObservation 2 is Done........")

    //Update PatientResultObservationUid of CacheResultObservation 3
    val update_PatientResultObservationUid3 =  cleanedCacheResultObservation.as("df1").join(PatientResultObservation_Prod.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.ObservationDate" === $"df2.ResultDate"
        && $"df1.ObservationName" === $"df2.ObservationDescription")
      .filter($"d1.StatusId" === 1 && $"df1.PatientResultObservationUid".isNull)
      .select($"df1.*",$"df2.PatientResultObservationUid".as("aliasPROUID"))
      .withColumn("PatientResultObservationUid",$"aliasPROUID")
      .drop("aliasPROUID")

    val where_PatientResultObservationUid3 = cleanedCacheResultObservation.as("df1").join(PatientResultObservation_Prod.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.ObservationDate" === $"df2.ResultDate"
        && $"df1.ObservationName" === $"df2.ObservationDescription")
      .filter($"d1.StatusId" === 1 && $"df1.PatientResultObservationUid".isNull)
      .select($"df1.*")

    if (where_PatientResultObservationUid3.count > 0) {
      val ex = cleanedCacheResultObservation.except(where_PatientResultObservationUid3)
      cleanedCacheResultObservation = ex.union(update_PatientResultObservationUid3)
    }

    logger.warn("Update PatientResultObservationUid of CacheResultObservation 3 is Done........")

    //Drop Duplicate records and store in in-memory not update status = 4
    var cleanedCacheResultObservation2 = cleanedCacheResultObservation.dropDuplicates(Seq("PatientUid"
      ,"ObservationDate","ObservationName"))
    val duplicateRecords_CacheResultObservation2 = cleanedCacheResultObservation.except(cleanedCacheResultObservation2)

    duplicateRecords_CacheResultObservation = duplicateRecords_CacheResultObservation.union(duplicateRecords_CacheResultObservation2)

    logger.warn("Drop Duplicate records CacheResultObservation 2 is Done............")

    //Create tempPatientResultObservation1
    val tempPatientResultObservation1 = cleanedCacheResultObservation2.filter($"StatusId" === 1 &&
      $"PatientResultObservationUid".isNull)
      .select($"PatientUid",$"ObservationName",$"ObservationDate")
      .withColumn("PatientResultObservationUid",FunctionUtility.getNewUid())


    //Update PatientResultObservationUid of CacheResultObservation 4
    val update_PatientResultObservationUid4 =  cleanedCacheResultObservation2.as("df1").join(tempPatientResultObservation1.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid"&& $"df1.ObservationDate" === $"df2.ObservationDate"
        && $"df1.ObservationName" === $"df2.ObservationName")
      .filter($"d1.StatusId" === 1)
      .select($"df1.*",$"df2.PatientResultObservationUid".as("aliasPROUID"))
      .withColumn("PatientResultObservationUid",$"aliasPROUID")
      .drop("aliasPROUID")

    val where_PatientResultObservationUid4 = cleanedCacheResultObservation2.as("df1").join(tempPatientResultObservation1.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid"&& $"df1.ObservationDate" === $"df2.ObservationDate"
        && $"df1.ObservationName" === $"df2.ObservationName")
      .filter($"d1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientResultObservationUid4.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_PatientResultObservationUid4)
      cleanedCacheResultObservation2 = ex.union(update_PatientResultObservationUid4)
    }

    logger.warn("Update PatientResultObservationUid of CacheResultObservation 3 is Done........")

    //update ResultInterpretationUid from MappingPracticeCommonData of cleanedCacheResultObservation
    val update_ResultInterpretationUid = cleanedCacheResultObservation2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.ObsInterpretationCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "8B9E2980-784A-409D-AB98-700FA54EE8B7")
      .where($"df1.StatusId" === 1 && $"df1.ResultInterpretationUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ResultInterpretationUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_ResultInterpretationUid = cleanedCacheResultObservation2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.ObsInterpretationCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "8B9E2980-784A-409D-AB98-700FA54EE8B7")
      .where($"df1.StatusId" === 1 && $"df1.ResultInterpretationUid".isNull)
      .select($"df1.*")

    if (where_ResultInterpretationUid.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_ResultInterpretationUid)
      cleanedCacheResultObservation2 = ex.union(update_ResultInterpretationUid)
    }

    logger.warn("update ResultInterpretationUid from MappingPracticeCommonData of cleanedCacheResultObservation is Done........")

    //update ResultInterpretationUid from MappingPracticeCommonData of cleanedCacheResultObservation 2
    val update_ResultInterpretationUid2 = cleanedCacheResultObservation2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.ObsInterpretationText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "8B9E2980-784A-409D-AB98-700FA54EE8B7")
      .where($"df1.StatusId" === 1 && $"df1.ResultInterpretationUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ResultInterpretationUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_ResultInterpretationUid2 = cleanedCacheResultObservation2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.ObsInterpretationText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "8B9E2980-784A-409D-AB98-700FA54EE8B7")
      .where($"df1.StatusId" === 1 && $"df1.ResultInterpretationUid".isNull)
      .select($"df1.*")

    if (where_ResultInterpretationUid2.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_ResultInterpretationUid2)
      cleanedCacheResultObservation2 = ex.union(update_ResultInterpretationUid2)
    }

    logger.warn("update ResultInterpretationUid from MappingPracticeCommonData of cleanedCacheResultObservation 2 is Done........")

    //update ResultInterpretationUid Using Master_prod of cleanedCacheResultObservation
    val update_ResultInterpretationUid3 = cleanedCacheResultObservation2.as("df1")
      .join(Master_prod.as("df2"), $"df1.ObsInterpretationCode" === $"df2.Code")
      .where($"df1.StatusId" === 1 && $"df1.ResultInterpretationUid".isNull && $"df2.Type" === "ResultInterpretation")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("ResultInterpretationUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_ResultInterpretationUid3 = cleanedCacheResultObservation2.as("df1")
      .join(Master_prod.as("df2"), $"df1.ObsInterpretationCode" === $"df2.Code")
      .where($"df1.StatusId" === 1 && $"df1.ResultInterpretationUid".isNull && $"df2.Type" === "ResultInterpretation")
      .select($"df1.*")

    if (where_ResultInterpretationUid3.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_ResultInterpretationUid3)
      cleanedCacheResultObservation2 = ex.union(update_ResultInterpretationUid3)
    }

    logger.warn("update ResultInterpretationUid Using Master_prod of cleanedCacheResultObservation is Done........")

    //update ResultInterpretationUid Using Master_prod of cleanedCacheResultObservation 2
    val update_ResultInterpretationUid4 = cleanedCacheResultObservation2.as("df1")
      .join(Master_prod.as("df2"), $"df1.ObsInterpretationText" === $"df2.Name")
      .where($"df1.StatusId" === 1 && $"df1.ResultInterpretationUid".isNull && $"df2.Type" === "ResultInterpretation")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("ResultInterpretationUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_ResultInterpretationUid4 = cleanedCacheResultObservation2.as("df1")
      .join(Master_prod.as("df2"), $"df1.ObsInterpretationText" === $"df2.Name")
      .where($"df1.StatusId" === 1 && $"df1.ResultInterpretationUid".isNull && $"df2.Type" === "ResultInterpretation")
      .select($"df1.*")

    if (where_ResultInterpretationUid4.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_ResultInterpretationUid4)
      cleanedCacheResultObservation2 = ex.union(update_ResultInterpretationUid4)
    }

    logger.warn("update ResultInterpretationUid Using Master_prod of cleanedCacheResultObservation 2 is Done........")

    //Update status if ResultInterpretationUid is Null of CacheResultObservation
    val update_status_ResObs11 = cleanedCacheResultObservation2.filter($"StatusId" === 1 && $"ResultInterpretationUid".isNull
      && rtrim(ltrim($"ObsInterpretationCode")).isNotNull || rtrim(ltrim($"ObsInterpretationText")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ResultInterpretationCode\\Text Is Not Mapped"))

    val where_status_ResObs11 = cleanedCacheResultObservation2.filter($"StatusId" === 1 && $"ResultInterpretationUid".isNull
      && rtrim(ltrim($"ObsInterpretationCode")).isNotNull || rtrim(ltrim($"ObsInterpretationText")).isNotNull)

    if (where_status_ResObs11.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_status_ResObs11)
      cleanedCacheResultObservation2 = ex.union(update_status_ResObs11)
    }

    logger.warn("Update status if ResultInterpretationUid is Null of CacheResultObservation is Done........")

    //update ProcedureUid Using MappingPracticeProcedure_Prod of cleanedCacheResultObservation
    val update_ProcedureUid_ResObs = cleanedCacheResultObservation2.as("df1").join(MappingPracticeProcedure_Delta.as("df2")
      , $"df1.ProcedureCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.ProcedureUid".isNull)
      .select($"df1.*", $"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("ProcedureUid", $"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_ProcedureUid_ResObs = cleanedCacheResultObservation2.as("df1").join(MappingPracticeProcedure_Delta.as("df2")
      , $"df1.ProcedureCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.ProcedureUid".isNull)
      .select($"df1.*")

    if (where_ProcedureUid_ResObs.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_ProcedureUid_ResObs)
      cleanedCacheResultObservation2 = ex.union(update_ProcedureUid_ResObs)
    }

    logger.warn("update ProcedureUid Using MappingPracticeProcedure_Prod of cleanedCacheResultObservation is Done........")

    //update ProcedureUid Using MasterCode_Prod of CacheMedications
    val update_ProcedureUid_ResObs2 = cleanedCacheResultObservation2.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.ProcedureCode" === $"df2.Code" && $"df1.ProcedureCategory" === $"df2.CodeSystem")
      .where($"df1.StatusId" === 1 && $"df1.ProcedureUid".isNull)
      .select($"df1.*", $"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("ProcedureUid", $"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_ProcedureUid_ResObs2 = cleanedCacheResultObservation2.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.ProcedureCode" === $"df2.Code" && $"df1.ProcedureCategory" === $"df2.CodeSystem")
      .where($"df1.StatusId" === 1 && $"df1.ProcedureUid".isNull)
      .select($"df1.*")

    if (where_ProcedureUid_ResObs2.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_ProcedureUid_ResObs2)
      cleanedCacheResultObservation2 = ex.union(update_ProcedureUid_ResObs2)
    }

    logger.warn("update ProcedureUid Using MasterCode_Prod of CacheMedications is Done........")

    //Update status if ProcedureUid is Null of CacheResultObservation
    val update_status_ResObs12 = cleanedCacheResultObservation2.filter($"StatusId" === 1 && $"ProcedureUid".isNull
      && rtrim(ltrim($"ProcedureCode")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ProcedureCode Code Is Not Mapped"))

    val where_status_ResObs12 = cleanedCacheResultObservation2.filter($"StatusId" === 1 && $"ProcedureUid".isNull
      && rtrim(ltrim($"ProcedureCode")).isNotNull)

    if (where_status_ResObs12.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_status_ResObs12)
      cleanedCacheResultObservation2 = ex.union(update_status_ResObs12)
    }

    logger.warn("Update status if ProcedureUid is Null of CacheResultObservation is Done........")

    //update TargetSiteUid from MappingPracticeCommonData of cleanedCacheResultObservation
    val update_TargetSiteUid_ResObs = cleanedCacheResultObservation2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.TargetSiteCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .where($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("TargetSiteUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_TargetSiteUid_ResObs = cleanedCacheResultObservation2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.TargetSiteCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .where($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull)
      .select($"df1.*")

    if (where_TargetSiteUid_ResObs.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_TargetSiteUid_ResObs)
      cleanedCacheResultObservation2 = ex.union(update_TargetSiteUid_ResObs)
    }
    logger.warn("update TargetSiteUid from MappingPracticeCommonData of cleanedCacheResultObservation is Done......")

    //update TargetSiteUid from MappingPracticeCommonData of cleanedCacheResultObservation 2
    val update_TargetSiteUid_ResObs2 = cleanedCacheResultObservation2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.TargetSiteText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .where($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("TargetSiteUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_TargetSiteUid_ResObs2 = cleanedCacheResultObservation2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.TargetSiteText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .where($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull)
      .select($"df1.*")

    if (where_TargetSiteUid_ResObs2.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_TargetSiteUid_ResObs2)
      cleanedCacheResultObservation2 = ex.union(update_TargetSiteUid_ResObs2)
    }
    logger.warn("update TargetSiteUid from MappingPracticeCommonData of cleanedCacheResultObservation 2 is Done......")

    //Update TargetSiteUid from Master Table of cleanedCacheResultObservation
    val update_TargetSiteUid_ResObs3 = cleanedCacheResultObservation2.as("df1").join(Master_prod.as("df2"),
      $"df1.TargetSiteText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull && $"df2.Type" === "TargetSite")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("TargetSiteUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_TargetSiteUid_ResObs3 = cleanedCacheResultObservation2.as("df1").join(Master_prod.as("df2"),
      $"df1.TargetSiteText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull && $"df2.Type" === "TargetSite")
      .select($"df1.*")

    if (where_TargetSiteUid_ResObs3.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_TargetSiteUid_ResObs3)
      cleanedCacheResultObservation2 = ex.union(update_TargetSiteUid_ResObs3)
    }
    logger.warn("Update TargetSiteUid from Master Table of cleanedCacheResultObservation is Done......")

    //Update TargetSiteUid from Master Table of cleanedCacheResultObservation 2
    val update_TargetSiteUid_ResObs4 = cleanedCacheResultObservation2.as("df1").join(Master_prod.as("df2"),
      $"df1.TargetSiteCode" === $"df2.Code")
      .filter($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull && $"df2.Type" === "TargetSite")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("TargetSiteUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_TargetSiteUid_ResObs4 = cleanedCacheResultObservation2.as("df1").join(Master_prod.as("df2"),
      $"df1.TargetSiteCode" === $"df2.Code")
      .filter($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull && $"df2.Type" === "TargetSite")
      .select($"df1.*")

    if (where_TargetSiteUid_ResObs4.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_TargetSiteUid_ResObs4)
      cleanedCacheResultObservation2 = ex.union(update_TargetSiteUid_ResObs4)
    }
    logger.warn("Update TargetSiteUid from Master Table of cleanedCacheResultObservation 2 is Done......")

    //Update status if TargetSiteUid is Null of CacheResultObservation
    val update_status_ResObs13 = cleanedCacheResultObservation2.filter($"StatusId" === 1 && $"TargetSiteUid".isNull
      && rtrim(ltrim($"TargetSiteCode")).isNotNull || rtrim(ltrim($"TargetSiteText")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("TargetSite Code\\Text Is Not Mapped"))

    val where_status_ResObs13 = cleanedCacheResultObservation2.filter($"StatusId" === 1 && $"TargetSiteUid".isNull
      && rtrim(ltrim($"TargetSiteCode")).isNotNull || rtrim(ltrim($"TargetSiteText")).isNotNull)

    if (where_status_ResObs13.count > 0) {
      val ex = cleanedCacheResultObservation2.except(where_status_ResObs13)
      cleanedCacheResultObservation2 = ex.union(update_status_ResObs13)
    }
    logger.warn("Update status if TargetSiteUid is Null of CacheResultObservation is Done......")

    //update Data PatientResultObservation
    val update_PatientResultObservation_Prod = PatientResultObservation_Prod.as("df1").join(cleanedCacheResultObservation2.as("df2")
      ,$"df1.PatientResultObservationUid" === $"df2.PatientResultObservationUid")
      .filter($"df2.StatusId" === 1)
      .select($"df1.*",$"df2.ObservationCode".as("aliasOC"),$"df2.ObservationName".as("aliasOName")
        ,$"df2.ResultInterpretationUid".as("aliasRIUid"),$"df2.TargetSiteUid".as("aliasTSUid")
        ,$"df2.ServiceProviderUid".as("aliasSPUid"),$"df2.ReferenceLowerRange".as("aliasRLRange")
        ,$"df2.ReferenceUpperRange".as("aliasRURange"),$"df2.ObservationValue".as("aliasOValue")
        ,$"df2.NegationInd".as("aliasNInd"),$"df2.ProcedureUid".as("aliasPUid")
        ,$"df2.ResultObservationStatus".as("aliasROStatus"),$"df2.ResultOrderDescription".as("aliasRODesc")
        ,$"df2.ResultOrderDate".as("aliasRODate"),$"df2.ResultOBSUnit".as("aliasROBSUnit")
        ,$"df2.ObservationCodeUid".as("aliasObsCodeU")
        ,$"df2.ObservationMethod".as("aliasOMethod"),$"df2.LaboratoryID".as("aliasLID")
        ,$"df2.LaboratoryName".as("aliasLBName"),$"df2.ResultOrderCode".as("aliasROrdCode")
        ,$"df2.ObsSubId".as("aliasObsSubId"),$"df2.ObservationCategory".as("aliasObsCat"))
      .withColumn("PracticeCode",$"aliasOC")
      .withColumn("PracticeDescription",$"aliasOName")
      .withColumn("MasterResultInterpretationUid",$"aliasRIUid")
      .withColumn("MasterTargetSiteUid",$"aliasTSUid")
      .withColumn("ServiceProviderUid",$"aliasSPUid")
      .withColumn("ModifiedDate",current_timestamp())
      .withColumn("ReferenceObservationRange",FunctionUtility.checkColumns($"df2.aliasRLRange",$"df2.aliasRURange"))
      .withColumn("ResultValue",$"aliasOValue")
      .withColumn("NegationInd",$"aliasNInd")
      .withColumn("ProcedureUid",$"aliasPUid")
      .withColumn("ResultObservationStatus",$"aliasROStatus")
      .withColumn("ResultOrderDescription",$"aliasRODesc")
      .withColumn("ResultOrderDate",$"aliasRODate")
      .withColumn("Unit",$"aliasROBSUnit")
      .withColumn("ObservationDescription",$"aliasOName")
      .withColumn("ObservationCodeUid",$"aliasObsCodeU")
      .withColumn("ObservationMethod",$"aliasOMethod")
      .withColumn("LaboratoryID",$"aliasLID")
      .withColumn("LaboratoryName",$"aliasLBName")
      .withColumn("ResultOrderCode",$"aliasROrdCode")
      .withColumn("ObsSubId",$"aliasObsSubId")
      .withColumn("CodeSystem",$"aliasObsCat")
      .drop("aliasOC","aliasOName","aliasRIUid","aliasTSUid","aliasSPUid","aliasRLRange","aliasRURange"
        ,"aliasOValue","aliasNInd","aliasPUid","aliasROStatus","aliasRODesc","aliasRODate","aliasROBSUnit"
        ,"aliasObsCodeU","aliasOMethod","aliasLID","aliasLBName","aliasROrdCode","aliasObsSubId","aliasObsCat")

    val where_PRObs = PatientResultObservation_Prod.as("df1").join(cleanedCacheResultObservation2.as("df2")
      ,$"df1.PatientResultObservationUid" === $"df2.PatientResultObservationUid")
      .filter($"df2.StatusId" === 1)
      .select($"df1.*")

    val ex_PRObs = PatientResultObservation_Prod.except(where_PRObs)
    var PatientResultObservation_Prod_Delta = ex_PRObs.union(update_PatientResultObservation_Prod)

    logger.warn("update Data PatientResultObservation is Done......")

    //Insert Data Into PatientResultObservation
    val insert_Data_PatientResultObservation_ResObs = cleanedCacheResultObservation2.as("df1").join(PatientResultObservation_Prod_Delta.as("df2")
      ,$"df1.PatientResultObservationUid" === $"df2.PatientResultObservationUid","left_outer")
      .where($"df1.StatusId" === 1 && $"df2.PatientResultObservationUid".isNull)
      .select($"df1.PatientResultObservationUid",$"df1.PatientUid",$"df1.ObservationCodeUid",
        $"df1.ObservationDate".as("ResultDate"),$"df1.ObservationValue".as("ResultValue")
        ,$"df1.ResultInterpretationUid".as("MasterResultInterpretationUid"),$"df1.TargetSiteUid".as("MasterTargetSiteUid")
        ,$"df1.ServiceProviderUid",$"df1.ReferenceLowerRange",$"df1.ReferenceUpperRange",$"df1.ObservationCode"
        ,$"df1.ObservationName".as("PracticeDescription"),$"df1.NegationInd",$"df1.SpecimenId"
        ,$"df1.ProcedureUid",$"df1.ResultObservationStatus",$"df1.ResultOrderDescription",$"df1.ResultOrderDate"
        ,$"df1.ResultOBSUnit".as("Unit"),$"df1.ObservationName".as("ObservationDescription")
        ,$"df1.ObservationMethod",$"df1.LaboratoryID",$"df1.LaboratoryName",$"df1.ResultOrderCode"
        ,$"df1.ObsSubId",$"df1.ObservationCategory".as("CodeSystem"))
      .groupBy("PatientResultObservationUid","PatientUid","ObservationCodeUid","ObservationCode"
        ,"ResultDate","ResultValue","MasterResultInterpretationUid","MasterTargetSiteUid","ServiceProviderUid"
        ,"ResultObservationStatus","ResultOrderDescription","ResultOrderDate","Unit","PracticeDescription"
        ,"ObservationMethod","LaboratoryID","LaboratoryName","ResultOrderCode","ObsSubId","CodeSystem")
      .agg(max(FunctionUtility.checkColumns($"ReferenceLowerRange",$"ReferenceUpperRange")).as("ReferenceObservationRange")
        ,max($"ObservationCode").as("PracticeCode"),max($"NegationInd").as("NegationInd")
        ,max($"SpecimenId").as("SpecimenId"),max("ProcedureUid").as("ProcedureUid"))
      .drop("ObservationCode")


    val allcols = PatientResultObservation_Prod_Delta.columns.toSet
    val insertcols = insert_Data_PatientResultObservation_ResObs.columns.toSet
    val tot3 = allcols ++ insertcols

    PatientResultObservation_Prod_Delta = PatientResultObservation_Prod_Delta.select(FunctionUtility.addColumns(allcols, tot3): _*)
      .union(insert_Data_PatientResultObservation_ResObs.select(FunctionUtility.addColumns(insertcols, tot3): _*))
    //End Of CacheResultObservation
    logger.warn("End Of CacheResultObservation is Done......")



    List(PatientResultObservation_Prod_Delta,Individual_prod_Delta6,ServiceProvider_prod_Delta5)
  }

}
