package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory

class CachePatientEthnicity {

  def CachePatientEthnicityFun(spark : SparkSession,Patient_Prod_Delta : DataFrame
                               ,Individual_prod_Delta : DataFrame,IndividualEthnicity_Prod : DataFrame
                               ,MappingPracticeCommonData_Delta : DataFrame
                               ,MergePracticeMap : DataFrame,CDRPatientCrosswalkTable : DataFrame
                               ,MasterEthnicity_Prod : DataFrame) : List[DataFrame] = {

    import spark.implicits._

    //Start CachePatientEthnicity

    val logger = LoggerFactory.getLogger("")

    var CacheEthnicityTable = spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/a06375b5-51cc-4028-88ea-1690c4e7b2e7_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")

    val lookup2 = Map("_c0" -> "PatientId", "_c1" -> "PatientEthnicityCode", "_c2" -> "PatientEthnicityText"
      , "_c3" -> "PatientEthnicityKey", "_c4" -> "PracticeUid"
      , "_c5" -> "BatchUid", "_c6" -> "dummy1", "_c7" -> "dummy2")

    CacheEthnicityTable = CacheEthnicityTable.select(CacheEthnicityTable.columns.map(c => col(c).as(lookup2.getOrElse(c, c))): _*)

    val tempEthallCols = spark.read.option("header", "true")
      .csv("/home/gajanan.doifode/AAO_DATA/Schema/CachePatientEthnicity.txt")

    val allcolsEthnicityTable = tempEthallCols.columns.toSet

    val viewcolsEthnicityTable = CacheEthnicityTable.columns.toSet

    val totalEthnicityTable = allcolsEthnicityTable ++ viewcolsEthnicityTable

    CacheEthnicityTable = tempEthallCols.select(FunctionUtility.addColumns(allcolsEthnicityTable, totalEthnicityTable): _*)
      .union(CacheEthnicityTable.select(FunctionUtility.addColumns(viewcolsEthnicityTable, totalEthnicityTable): _*))
      .drop("dummy1", "dummy2")

    CacheEthnicityTable = CacheEthnicityTable.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))
    CacheEthnicityTable.select("RowId").show()

    val dist_Prac_Uid_PateintEth = CacheEthnicityTable.filter($"StatusId".isNull).select("PracticeUid").distinct()

    val tempMergePracticeMap = MergePracticeMap.as("df1").join(dist_Prac_Uid_PateintEth.as("df2")
      , $"df1.NewPracticeUid" === $"df2.PracticeUid").select($"df1.*")

    CacheEthnicityTable = CacheEthnicityTable.as("df1").join(tempMergePracticeMap.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeUid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeUid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    CacheEthnicityTable = CacheEthnicityTable.withColumn("StatusId", lit(1))

    //Update Multiple Columns
    CacheEthnicityTable = CacheEthnicityTable.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PatientEthnicityCode", rtrim(ltrim($"df1.PatientEthnicityCode")))
      .withColumn("PatientEthnicityText", rtrim(ltrim($"df1.PatientEthnicityText")))
      .withColumn("PatientId", rtrim(ltrim($"df1.PatientId")))

    logger.warn("Update Multiple Columns is Done............")

    val updateStatusET = CacheEthnicityTable.as("df1").filter($"PatientEthnicityCode".isNull
      && $"PatientEthnicityText".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("EthnicityCode/Text is Null"))

    val whereclauseET = CacheEthnicityTable.as("df1").filter($"PatientEthnicityCode".isNull
      && $"PatientEthnicityText".isNull)

    if (whereclauseET.count > 0) {
      val ex = CacheEthnicityTable.except(whereclauseET)
      CacheEthnicityTable = ex.union(updateStatusET)
    }

    logger.warn("Find EthnicityCode/Text is Null update statusid = 3 is Done............")


    //PatientId is Missing'
    val updateStatusET2 = CacheEthnicityTable.filter($"PatientId".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val whereclauseET2 = CacheEthnicityTable.filter($"PatientId".isNull && $"StatusId" === 1)

    if (whereclauseET2.count > 0) {
      val ex = CacheEthnicityTable.except(whereclauseET2)
      CacheEthnicityTable = ex.union(updateStatusET2)
    }

    logger.warn("Find PatientId is Missing update statusid = 3 is Done............")


    val updatePatientIdET = CacheEthnicityTable.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val wherePatientIdET = CacheEthnicityTable.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")


    if (wherePatientIdET.count > 0) {
      val ex = CacheEthnicityTable.except(wherePatientIdET)
      CacheEthnicityTable = ex.union(updatePatientIdET)
    }

    logger.warn("Update patientID = Old_PatientId using CDRPatient Table is Done............")

    //Update PatientUid From PatientId using Multiple Tables
    val updatePatientUidET = CacheEthnicityTable.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientUid".isNull)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val wherePatientUidET = CacheEthnicityTable.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.IndividualUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientUid".isNull)
      .select($"df1.*")


    if (wherePatientUidET.count > 0) {
      val ex = CacheEthnicityTable.except(wherePatientUidET)
      CacheEthnicityTable = ex.union(updatePatientUidET)
    }

    logger.warn("Update PatientUid From PatientId using Multiple Tables is Done............")


    //Patient Not Found of Ethenticity Table

    val updateStatusET3 = CacheEthnicityTable.filter($"PatientUid".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val whereclauseET3 = CacheEthnicityTable.filter($"PatientUid".isNull && $"StatusId" === 1)

    if (whereclauseET3.count > 0) {
      val ex = CacheEthnicityTable.except(whereclauseET3)
      CacheEthnicityTable = ex.union(updateStatusET3)
    }

    logger.warn("Patient Not Found is Done............")


    //Update EthnicityUid from MappingPracticeCommonData

    val updateEthnicityUid = CacheEthnicityTable.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PatientEthnicityCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "27FD699B-2E51-44F4-84F7-984E5837DE36")
      .filter($"df1.StatusId" === 1 && $"df1.EthnicityUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("EthnicityUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val whereEthnicityUid = CacheEthnicityTable.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PatientEthnicityCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "27FD699B-2E51-44F4-84F7-984E5837DE36")
      .filter($"df1.StatusId" === 1 && $"df1.EthnicityUid".isNull)
      .select($"df1.*")

    if (whereEthnicityUid.count > 0) {
      val ex = CacheEthnicityTable.except(whereEthnicityUid)
      CacheEthnicityTable = ex.union(updateEthnicityUid)
    }

    logger.warn("Update EthnicityUid from MappingPracticeCommonData  is Done............")

    //Update EthnicityUid from MappingPracticeCommonData on PatientEthnicityText

    val updateEthnicityUid2 = CacheEthnicityTable.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PatientEthnicityText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "27FD699B-2E51-44F4-84F7-984E5837DE36")
      .filter($"df1.StatusId" === 1 && $"df1.EthnicityUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("EthnicityUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val whereEthnicityUid2 = CacheEthnicityTable.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PatientEthnicityText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "27FD699B-2E51-44F4-84F7-984E5837DE36")
      .filter($"df1.StatusId" === 1 && $"df1.EthnicityUid".isNull)
      .select($"df1.*")

    if (whereEthnicityUid2.count > 0) {
      val ex = CacheEthnicityTable.except(whereEthnicityUid2)
      CacheEthnicityTable = ex.union(updateEthnicityUid2)
    }

    logger.warn("Update EthnicityUid from MappingPracticeCommonData on PatientEthnicityText  is Done............")

    //Update EthnicityUid from MasterEthnicity table on PatientEthnicityCode


    val updateEthnicityUid4 = CacheEthnicityTable.as("df1").join(MasterEthnicity_Prod.as("df2")
      , $"df1.PatientEthnicityCode" === $"df2.ExternalID")
      .filter($"df1.StatusId" === 1 && $"df1.EthnicityUid".isNull)
      .select($"df1.*", $"df2.EthnicityUid".as("aliasEthnicityUid"))
      .withColumn("EthnicityUid", $"aliasEthnicityUid")
      .drop("aliasEthnicityUid")

    val whereEthnicityUid4 = CacheEthnicityTable.as("df1").join(MasterEthnicity_Prod.as("df2")
      , $"df1.PatientEthnicityCode" === $"df2.ExternalID")
      .filter($"df1.StatusId" === 1 && $"df1.EthnicityUid".isNull)
      .select($"df1.*")

    if (whereEthnicityUid4.count > 0) {
      val ex = CacheEthnicityTable.except(whereEthnicityUid4)
      CacheEthnicityTable = ex.union(updateEthnicityUid4)
    }
    logger.warn("Update EthnicityUid from MasterEthnicity table on PatientEthnicityCode  is Done............")

    //Update EthnicityUid from MasterEthnicity table on PatientEthnicityText

    val updateEthnicityUid5 = CacheEthnicityTable.as("df1").join(MasterEthnicity_Prod.as("df2")
      , $"df1.PatientEthnicityText" === $"df2.Description")
      .filter($"df1.StatusId" === 1 && $"df1.EthnicityUid".isNull)
      .select($"df1.*", $"df2.EthnicityUid".as("aliasEthnicityUid"))
      .withColumn("EthnicityUid", $"aliasEthnicityUid")
      .drop("aliasEthnicityUid")

    val whereEthnicityUid5 = CacheEthnicityTable.as("df1").join(MasterEthnicity_Prod.as("df2")
      , $"df1.PatientEthnicityText" === $"df2.Description")
      .filter($"df1.StatusId" === 1 && $"df1.EthnicityUid".isNull)
      .select($"df1.*")

    if (whereEthnicityUid5.count > 0) {
      val ex = CacheEthnicityTable.except(whereEthnicityUid5)
      CacheEthnicityTable = ex.union(updateEthnicityUid5)
    }
    logger.warn("Update EthnicityUid from MasterEthnicity table on PatientEthnicityText  is Done............")

    //Remove Duplicates

    var cleanedCacheEthnicityTable = CacheEthnicityTable.dropDuplicates(Seq("PatientUid", "EthnicityUid"))
    val dropDuplicatesEthnicity1 = CacheEthnicityTable.dropDuplicates(Seq("PatientUid", "PatientEthnicityText"))
    cleanedCacheEthnicityTable = cleanedCacheEthnicityTable.union(dropDuplicatesEthnicity1)

    var duplicatesRecords1 = CacheEthnicityTable.except(cleanedCacheEthnicityTable)
    val duplicaterecords2 = CacheEthnicityTable.except(dropDuplicatesEthnicity1)
    duplicatesRecords1 = duplicatesRecords1.union(duplicaterecords2)

    logger.warn("Remove Duplicates of Ethnicity is Done............")

    //Not Implement

    /* delete from  IE  from #chPatientEthnicityData CPD
      inner join IndividualEthnicity IE on IE.IndividualUid=CPD.PatientUid
    Where CPD.StatusID=1 and CPD.EthnicityUid is not null*/

    //Insert data Into IndividualEthnicity_Prod

    val insert_IndividualEthnicity_Prod = cleanedCacheEthnicityTable.as("df2").join(IndividualEthnicity_Prod.as("df1")
      , $"df2.PatientUid" === $"df1.IndividualUid" && $"df2.PatientEthnicityText" === $"df1.PracticeEthnicityText", "left_outer")
      .filter($"df1.PracticeEthnicityText".isNull && $"df1.IndividualUid".isNull && $"df2.StatusId" === 1)
      .select($"df2.PatientUid".as("IndividualUid"), $"df2.EthnicityUid".as("EthnicityUid"),
        $"df2.PatientEthnicityText".as("PracticeEthniCityText"))
      .withColumn("IndividualEthnicityUid", FunctionUtility.getNewUid())
      .withColumn("cd" +
        "", current_timestamp())


    val IndividualEth_allcols = IndividualEthnicity_Prod.columns.toSet
    val insert_IndividualEth_cols = insert_IndividualEthnicity_Prod.columns.toSet
    val tot_cols = IndividualEth_allcols ++ insert_IndividualEth_cols

    val IndividualEthnicity_Prod1 = IndividualEthnicity_Prod.select(FunctionUtility.addColumns(IndividualEth_allcols, tot_cols): _*)
      .union(insert_IndividualEthnicity_Prod.select(FunctionUtility.addColumns(insert_IndividualEth_cols, tot_cols): _*))
    logger.warn("PatientEthnicity Sp is Done............")

    List(IndividualEthnicity_Prod1)
  }

}
