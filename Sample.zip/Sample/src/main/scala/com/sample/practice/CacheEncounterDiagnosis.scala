package com.sample.practice
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory

class CacheEncounterDiagnosis {

  def CacheEncounterDiagnosisFunc(spark : SparkSession,MergePracticeMap : DataFrame
                                  ,CDRPatientCrosswalkTable : DataFrame, Individual : DataFrame
                                  ,ProviderNPIChangeTable : DataFrame, MultiTableExtendTable : DataFrame
                                  ,Master_prod : DataFrame
                                  ,MasterCode_Prod : DataFrame,ViewFacility_Prod : DataFrame
                                  ,PatientProblem_Prod : DataFrame,PatientProblemHistory_Prod : DataFrame
                                  ,VisitDiagnosis_Prod : DataFrame,Patient_Prod_Delta : DataFrame
                                  ,Individual_prod_Delta2 : DataFrame,ServiceProvider_Prod_Delta1 : DataFrame
                                  ,MappingPracticeProblem_Delta : DataFrame,Visit_Prod_Delta : DataFrame
                                  ,MappingPracticeCommonData_Delta : DataFrame) : List[DataFrame] = {
    import spark.implicits._

    val logger = LoggerFactory.getLogger("")

    //Start Encounter Diagnosis

    var CacheEncounterDiagnosis = spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/608cdee4-97d1-42a2-849d-9d9a95bc5131_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")

    val lookup6 = Map("_c0" -> "PatientId", "_c1" -> "EncounterDate", "_c2" -> "ServiceProviderNPI"
      , "_c3" -> "ServiceProviderLastName", "_c4" -> "ServiceProviderFirstName", "_c5" -> "ServiceLocationId"
      , "_c6" -> "ServiceLocationName", "_c7" -> "EncounterDiagnosisCode"
      , "_c8" -> "EncounterDiagnosisText", "_c9" -> "EncounterDiagnosisCategory", "_c10" -> "EncounterProblemTypeCode"
      , "_c11" -> "EncounterProblemTypeText", "_c12" -> "DocumentationDate", "_c13" -> "ProblemResolutionDate"
      , "_c14" -> "ProblemStatusCode", "_c15" -> "ProblemStatusText", "_c16" -> "ProblemHealthStatusCode"
      , "_c17" -> "ProblemHealthStatusText", "_c18" -> "NegationInd", "_c19" -> "ProblemComment"
      , "_c20" -> "ProblemOnsetDate", "_c21" -> "TargetSiteCode", "_c22" -> "TargetSiteText", "_c23" -> "ListOrder"
      , "_c24" -> "EncounterDiagnosisKey", "_c25" -> "PracticeUid", "_c26" -> "BatchUid", "_c27" -> "dummy1"
      , "_c28" -> "dummy2")

    CacheEncounterDiagnosis = CacheEncounterDiagnosis.select(CacheEncounterDiagnosis.columns.map(c => col(c).as(lookup6.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    val tempCacheEncounterDiagnosis = spark.read.option("header", "true")
      .csv("/home/gajanan.doifode/AAO_DATA/Schema/CacheEncounterDiagnosis.txt")

    val CacheEncounterDiagallcols = tempCacheEncounterDiagnosis.columns.toSet
    val CacheEncounterDiagViewcols = CacheEncounterDiagnosis.columns.toSet
    val tot_viewEnDiag_cacheEnDiag = CacheEncounterDiagallcols ++ CacheEncounterDiagViewcols

    CacheEncounterDiagnosis = tempCacheEncounterDiagnosis.select(FunctionUtility.addColumns(CacheEncounterDiagallcols, tot_viewEnDiag_cacheEnDiag): _*)
      .union(CacheEncounterDiagnosis.select(FunctionUtility.addColumns(CacheEncounterDiagViewcols, tot_viewEnDiag_cacheEnDiag): _*))

    CacheEncounterDiagnosis = CacheEncounterDiagnosis.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    //Distinct PracticeUid of CacheEncounterDiagnosis
    val dist_PrctUid_EncounterDiag = CacheEncounterDiagnosis.filter($"StatusId".isNull).select("PracticeUid").distinct()

    val tempMergePracticeMap_EncounterDiag = MergePracticeMap.as("df1").join(dist_PrctUid_EncounterDiag.as("df2")
      , $"df1.NewPracticeUid" === $"df2.PracticeUid").select($"df1.*")

    //Update PracticeUid with OriginalPracticeUid of CacheEncounterDiagnosis
    CacheEncounterDiagnosis = CacheEncounterDiagnosis.as("df1").join(tempMergePracticeMap_EncounterDiag.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeUid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeUid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeUid of CacheEncounterDiagnosis is Done.............................")

    CacheEncounterDiagnosis = CacheEncounterDiagnosis.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CacheEncounterDiagnosis
    CacheEncounterDiagnosis = CacheEncounterDiagnosis.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("ServiceLocationId", rtrim(ltrim($"df1.ServiceLocationId")))
      .withColumn("ServiceProviderNPI", rtrim(ltrim($"df1.ServiceProviderNPI")))
      .withColumn("PracticeSideNPI", rtrim(ltrim($"df1.ServiceProviderNPI")))
      .withColumn("PatientId", rtrim(ltrim($"df1.PatientId")))

    logger.warn("Update Multiple Columns of CacheEncounterDiagnosis is Done............")

    //Update Multiple Status Of CacheEncounterDiagnosis
    val aa = CacheEncounterDiagnosis.filter($"StatusId" === 1 && $"EncounterDiagnosisCode".isNull
      && $"EncounterDiagnosisText".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("DiagnosisText AND Code is missing"))

    val bb = CacheEncounterDiagnosis.filter($"StatusId" === 1 && $"EncounterDiagnosisCategory".isNull
      && $"EncounterDiagnosisCode".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("EncounterDiagnosisCategory Not Found"))

    val cc = CacheEncounterDiagnosis.filter($"StatusId" === 1 && $"ServiceProviderNPI".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ServiceProvider Not Found"))

    val dd = CacheEncounterDiagnosis.filter($"StatusId" === 1 && $"ServiceLocationId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ServiceLocationID Not Found"))

    val ee = CacheEncounterDiagnosis.filter($"StatusId" === 1 && $"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val update_Status_EncounterDiag = aa.union(bb).union(cc).union(dd).union(ee)

    val where_EncounterDiag = CacheEncounterDiagnosis.filter($"StatusId" === 1 && ($"EncounterDiagnosisCode".isNull
      && $"EncounterDiagnosisText".isNull || $"EncounterDiagnosisCategory".isNull && $"EncounterDiagnosisCode".isNull
      || $"ServiceProviderNPI".isNull || $"ServiceLocationId".isNull || $"PatientId".isNull))

    if (where_EncounterDiag.count > 0) {
      val ex = CacheEncounterDiagnosis.except(where_EncounterDiag)
      CacheEncounterDiagnosis = ex.union(update_Status_EncounterDiag)
    }
    logger.warn("Update Multiple Status Of CacheEncounterDiagnosis is Done............")

    //Update PatientId using CDRPatientCrosswalk In CacheEncounterDiagnosis Table
    val updatePatientIdEncounterDiag = CacheEncounterDiagnosis.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientIdEncounterDiag = CacheEncounterDiagnosis.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientIdEncounterDiag.count > 0) {
      val ex = CacheEncounterDiagnosis.except(where_PatientIdEncounterDiag)
      CacheEncounterDiagnosis = ex.union(updatePatientIdEncounterDiag)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk In CacheEncounterDiagnosis Table is Done............")

    //Update PatientUid Of CacheEncounterDiagnosis using Individual and Patient table
    val update_PatientUid_EncounterDiag = CacheEncounterDiagnosis.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta2.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val where_PatientUid_EncounterDiag = CacheEncounterDiagnosis.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta2.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientUid_EncounterDiag.count > 0) {
      val ex = CacheEncounterDiagnosis.except(where_PatientUid_EncounterDiag)
      CacheEncounterDiagnosis = ex.union(update_PatientUid_EncounterDiag)
    }

    logger.warn("Update PatientUid Of CacheEncounterDiagnosis using Individual and Patient table is Done............")

    //Update Status if PatientUid is Null Of CacheEncounterDiagnosis
    val update_Status_EncounterDiag2 = CacheEncounterDiagnosis.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_Status_EncounterDiag2 = CacheEncounterDiagnosis.filter($"StatusId" === 1 && $"PatientUid".isNull)

    if (where_Status_EncounterDiag2.count > 0) {
      val ex = CacheEncounterDiagnosis.except(where_Status_EncounterDiag2)
      CacheEncounterDiagnosis = ex.union(update_Status_EncounterDiag2)
    }

    logger.warn("Update Status if PatientUid is Null Of CacheEncounterDiagnosis is Done............")

    //Remove Duplicates of CacheEncounterDiagnosis

    var cleanedCacheEncounterDiagnosis = CacheEncounterDiagnosis.dropDuplicates(Seq("PatientUid", "EncounterDiagnosisCode", "DocumentationDate"))

    val dropDuplicatesCacheEncounterDiagnosis2 = CacheEncounterDiagnosis.dropDuplicates(Seq("PatientUid", "DocumentationDate", "EncounterDiagnosisText"))

    cleanedCacheEncounterDiagnosis = cleanedCacheEncounterDiagnosis.union(dropDuplicatesCacheEncounterDiagnosis2)

    var duplicatesRecordsEncounterDiag1 = CacheEncounterDiagnosis.except(cleanedCacheEncounterDiagnosis)
    val duplicaterecordsEncounterDiag2 = CacheEncounterDiagnosis.except(dropDuplicatesCacheEncounterDiagnosis2)

    duplicatesRecordsEncounterDiag1 = duplicatesRecordsEncounterDiag1.union(duplicaterecordsEncounterDiag2)

    logger.warn("Remove Duplicates of CacheEncounterDiagnosis is Done............")

    //Update ServiceProvideNPI Of CacheEncounterDiagnosis
    val updatespNPI_EncounterDiag = Individual.as("df1")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid")
      .join(cleanedCacheEncounterDiagnosis.as("df3"), $"df3.PracticeUid" === $"df1.PracticeUid" &&
        $"df3.ServiceProviderNPI" === $"df2.OldNPI")
      .filter($"StatusId" === 1)
      .select($"df3.*", $"df2.NewNPI".as("AliasNewNPI"))
      .withColumn("ServiceProviderNPI", $"AliasNewNPI").drop($"AliasNewNPI")

    val whereNPI_EncounterDiag = Individual.as("df1")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid")
      .join(cleanedCacheEncounterDiagnosis.as("df3"), $"df3.PracticeUid" === $"df1.PracticeUid"
        && $"df3.ServiceProviderNPI" === $"df2.OldNPI")
      .filter($"StatusId" === 1)
      .select($"df3.*")

    if (whereNPI_EncounterDiag.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis.except(whereNPI_EncounterDiag)
      cleanedCacheEncounterDiagnosis = ex.union(updatespNPI_EncounterDiag)
    }

    logger.warn("Update ServiceProviderNPI with difference condition of CacheEncounterDiagnosis is Done............")

    //Update ServiceProvideNPI 2 Of CacheEncounterDiagnosis
    val updatespNPI_EncDiag2 = cleanedCacheEncounterDiagnosis.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element1" && $"df1.ServiceProviderLastName" === $"df2.Element2"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"StatusId" === 1)
      .select($"df1.*", $"df2.Value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue").drop($"AliasValue")

    val whereNPI_EncDiag2 = cleanedCacheEncounterDiagnosis.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element1" && $"df1.ServiceProviderLastName" === $"df2.Element2"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"StatusId" === 1)
      .select($"df1.*")

    if (whereNPI_EncDiag2.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis.except(whereNPI_EncDiag2)
      cleanedCacheEncounterDiagnosis = ex.union(updatespNPI_EncDiag2)
    }

    logger.warn("Update ServiceProvideNPI 2 Of CacheEncounterDiagnosis is Done............")

    //Update Status if ServiceProviderNPI len is less than 10 of CacheEncounterDiagnosis
    val update_Status_EncounterDiag22 = cleanedCacheEncounterDiagnosis.filter($"StatusId" === 1 &&
      length($"ServiceProviderNPI") =!= 10)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid NPI Found,Length should be 10"))

    val where_Status_EncounterDiag22 = cleanedCacheEncounterDiagnosis.filter($"StatusId" === 1 &&
      length($"ServiceProviderNPI") =!= 10)

    if (where_Status_EncounterDiag22.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis.except(where_Status_EncounterDiag22)
      cleanedCacheEncounterDiagnosis = ex.union(update_Status_EncounterDiag22)
    }

    logger.warn("Update Status if ServiceProviderNPI len is less than 10 of CacheEncounterDiagnosis is Done............")

    //update CodeUid Using mappingPracticeProblem of CacheEncounterDiagnosis
    val update_CodeUid_EncDiag = cleanedCacheEncounterDiagnosis.as("df1").join(MappingPracticeProblem_Delta.as("df2")
      , $"df1.EncounterDiagnosisCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.CodeUid".isNull)
      .select($"df1.*", $"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("CodeUid", $"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_CodeUid_EncDiag = cleanedCacheEncounterDiagnosis.as("df1").join(MappingPracticeProblem_Delta.as("df2")
      , $"df1.EncounterDiagnosisCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.CodeUid".isNull)
      .select($"df1.*")

    if (where_CodeUid_EncDiag.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis.except(where_CodeUid_EncDiag)
      cleanedCacheEncounterDiagnosis = ex.union(update_CodeUid_EncDiag)
    }

    logger.warn("update CodeUid Using mappingPracticeProblem of CacheEncounterDiagnosis is Done............")

    //Create masterCode_prod Table

    //Update CodeUid Of CacheEncounterDiagnosis table using MasterCode table
    val update_CodeUid_EncDiag2 = cleanedCacheEncounterDiagnosis.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.EncounterDiagnosisCode" === $"df2.Code" && $"df2.CodeSystem".isin(1, 2, 3))
      .where($"df1.StatusId" === 1 && $"df1.CodeUid".isNull)
      .select($"df1.*", $"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("CodeUid", $"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_CodeUid_EncDiag2 = cleanedCacheEncounterDiagnosis.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.EncounterDiagnosisCode" === $"df2.Code" && $"df2.CodeSystem".isin(1, 2, 3))
      .where($"df1.StatusId" === 1 && $"df1.CodeUid".isNull)
      .select($"df1.*")

    if (where_CodeUid_EncDiag2.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis.except(where_CodeUid_EncDiag2)
      cleanedCacheEncounterDiagnosis = ex.union(update_CodeUid_EncDiag2)
    }

    logger.warn("Update CodeUid Of CacheEncounterDiagnosis table using MasterCode table  is Done............")

    //Update ServiceProviderUid of CacheEncounterDiagnosis table
    val updateSPUID_EncDiag = cleanedCacheEncounterDiagnosis.as("df1")
      .join(ServiceProvider_Prod_Delta1.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df2.Type".isin(1, 3) && $"df2.Inactive" === 0)
      .select($"df1.*", $"df2.ServiceProviderUid".as("aliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"aliasServiceProviderUid")
      .drop("aliasServiceProviderUid")

    val whereSPUID_EncDiag = cleanedCacheEncounterDiagnosis.as("df1")
      .join(ServiceProvider_Prod_Delta1.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df2.Type".isin(1, 3) && $"df2.Inactive" === 0)
      .select($"df1.*")

    if (whereSPUID_EncDiag.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis.except(whereSPUID_EncDiag)
      cleanedCacheEncounterDiagnosis = ex.union(updateSPUID_EncDiag)
    }

    logger.warn("Update ServiceProviderUid of CacheEncounterDiagnosis table is Done............")

    //Update ServiceLocationUid of CacheEncounterDiagnosis table using ViewFacility
    val update_SLUID_EncDiag = cleanedCacheEncounterDiagnosis.as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationId" === $"df2.ID"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceLocationUid".as("aliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"aliasServiceLocationUid")
      .drop("aliasServiceLocationUid")

    val where_SLUID_EncDiag = cleanedCacheEncounterDiagnosis.as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationId" === $"df2.ID"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_SLUID_EncDiag.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis.except(where_SLUID_EncDiag)
      cleanedCacheEncounterDiagnosis = ex.union(update_SLUID_EncDiag)
    }

    logger.warn("Update ServiceProviderUid of CacheEncounterDiagnosis table is Done............")

    //update VisitUid Of CacheEncounterDiagnosis table Using Visit Table
    val Update_VisitUid_EncDiag = cleanedCacheEncounterDiagnosis.as("df1").join(Visit_Prod_Delta.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ServiceProviderUid" === $"df2.RenderringProviderUid"
        && $"df1.ServiceLocationUid" === $"df2.ServiceLocationUid" && $"df1.EncounterDate" === $"df2.VisitDate")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.VisitUid".as("aliasVisitUid"))
      .withColumn("VisitUid", $"aliasVisitUid")
      .drop("aliasVisitUid")

    val where_VisitUid_EncDiag = cleanedCacheEncounterDiagnosis.as("df1").join(Visit_Prod_Delta.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ServiceProviderUid" === $"df2.RenderringProviderUid"
        && $"df1.ServiceLocationUid" === $"df2.ServiceLocationUid" && $"df1.EncounterDate" === $"df2.VisitDate")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_VisitUid_EncDiag.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis.except(where_VisitUid_EncDiag)
      cleanedCacheEncounterDiagnosis = ex.union(Update_VisitUid_EncDiag)
    }

    logger.warn("Update ServiceProviderUid of CacheEncounterDiagnosis table is Done............")

    //Update Status if Visituid is Null Of CacheEncounterDiagnosis Table
    val update_Status_EncounterDiag223 = cleanedCacheEncounterDiagnosis.filter($"StatusId" === 1 && $"VisitUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Visit Not Generated yet"))

    val where_Status_EncounterDiag223 = cleanedCacheEncounterDiagnosis.filter($"StatusId" === 1 && $"VisitUid".isNull)

    if (where_Status_EncounterDiag223.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis.except(where_Status_EncounterDiag223)
      cleanedCacheEncounterDiagnosis = ex.union(update_Status_EncounterDiag223)
    }

    logger.warn("Update Status if Visituid is Null Of CacheEncounterDiagnosis Table is Done............")

    //Create PatientProblem_Prod table

    //Update PatientProblemUid of CacheEncounterDiagnosis using PatientProblem_Prod table
    val update_PatientProblemUid_ED = cleanedCacheEncounterDiagnosis.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.CodeUid" === $"df2.CodeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*", $"df2.PatientProblemUid".as("aliasPatientProblemUid"))
      .withColumn("PatientProblemUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientProblemUid_ED = cleanedCacheEncounterDiagnosis.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.CodeUid" === $"df2.CodeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*")

    if (where_PatientProblemUid_ED.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis.except(where_PatientProblemUid_ED)
      cleanedCacheEncounterDiagnosis = ex.union(update_PatientProblemUid_ED)
    }

    logger.warn("Update PatientProblemUid of CacheEncounterDiagnosis using PatientProblem_Prod table is Done............")

    //Update PatientProblemUid of CacheEncounterDiagnosis using PatientProblem_Prod table 2
    val update_PatientProblemUid_ED2 = cleanedCacheEncounterDiagnosis.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.EncounterDiagnosisCode" === $"df2.PracticeCode")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*", $"df2.PatientProblemUid".as("aliasPatientProblemUid"))
      .withColumn("PatientProblemUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientProblemUid_ED2 = cleanedCacheEncounterDiagnosis.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.EncounterDiagnosisCode" === $"df2.PracticeCode")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*")

    if (where_PatientProblemUid_ED2.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis.except(where_PatientProblemUid_ED2)
      cleanedCacheEncounterDiagnosis = ex.union(update_PatientProblemUid_ED2)
    }

    logger.warn("Update PatientProblemUid of CacheEncounterDiagnosis using PatientProblem_Prod table 2 is Done............")

    //Update PatientProblemUid of CacheEncounterDiagnosis using PatientProblem_Prod table 3
    val update_PatientProblemUid_ED3 = cleanedCacheEncounterDiagnosis.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.EncounterDiagnosisText" === $"df2.PracticeDescription")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull && $"df1.EncounterDiagnosisCode".isNull &&
        $"df2.PracticeCode".isNull)
      .select($"df1.*", $"df2.PatientProblemUid".as("aliasPatientProblemUid"))
      .withColumn("PatientProblemUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientProblemUid_ED3 = cleanedCacheEncounterDiagnosis.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.EncounterDiagnosisText" === $"df2.PracticeDescription")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull && $"df1.EncounterDiagnosisCode".isNull &&
        $"df2.PracticeCode".isNull)
      .select($"df1.*")

    if (where_PatientProblemUid_ED3.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis.except(where_PatientProblemUid_ED3)
      cleanedCacheEncounterDiagnosis = ex.union(update_PatientProblemUid_ED3)
    }
    logger.warn("Update PatientProblemUid of CacheEncounterDiagnosis using PatientProblem_Prod table 3 is Done............")
    //find Duplicates record
    var cleanedCacheEncounterDiagnosis2 = cleanedCacheEncounterDiagnosis.dropDuplicates(Seq("VisitUid", "CodeUid", "DocumentationDate"))

    val duplicatesRecordsEncounterDiag3 = cleanedCacheEncounterDiagnosis.except(cleanedCacheEncounterDiagnosis2)

    duplicatesRecordsEncounterDiag1 = duplicatesRecordsEncounterDiag3.union(duplicatesRecordsEncounterDiag3)

    logger.warn("find Duplicates record 2 is Done............")

    //create #Problem
    val tempProblem1 = cleanedCacheEncounterDiagnosis2.filter($"StatusId" === 1 && $"PatientProblemUid".isNull)
      .select("PatientUid", "CodeUid").distinct()
      .withColumn("PatientProblemUid", FunctionUtility.getNewUid())

    //Update New PatientProblemUid of CacheEncounterDiagnosis Table Using #Problem Table
    val update_PatientPUid_ED = cleanedCacheEncounterDiagnosis2.as("df1").join(tempProblem1.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.CodeUid" === $"df2.CodeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*", $"df2.PatientProblemUid".as("aliasPatientProblemUid"))
      .withColumn("PatientProblemUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientPUid_ED = cleanedCacheEncounterDiagnosis2.as("df1").join(tempProblem1.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.CodeUid" === $"df2.CodeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*")

    if (where_PatientPUid_ED.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_PatientPUid_ED)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_PatientPUid_ED)
    }
    logger.warn("Update New PatientProblemUid of CacheEncounterDiagnosis Table Using #Problem Table is Done............")

    //create #Problem1
    val tempProblem2 = cleanedCacheEncounterDiagnosis2.filter($"StatusId" === 1 && $"PatientProblemUid".isNull
      && $"EncounterDiagnosisCode".isNotNull)
      .select("PatientUid", "EncounterDiagnosisCode").distinct()
      .withColumn("PatientProblemUid", FunctionUtility.getNewUid())

    //Update New PatientProblemUid of CacheEncounterDiagnosis Table Using #Problem1 Table
    val update_PatientPUid_ED2 = cleanedCacheEncounterDiagnosis2.as("df1").join(tempProblem2.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.EncounterDiagnosisCode" === $"df2.EncounterDiagnosisCode")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*", $"df2.PatientProblemUid".as("aliasPatientProblemUid"))
      .withColumn("PatientProblemUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientPUid_ED2 = cleanedCacheEncounterDiagnosis2.as("df1").join(tempProblem2.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.EncounterDiagnosisCode" === $"df2.EncounterDiagnosisCode")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*")

    if (where_PatientPUid_ED2.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_PatientPUid_ED2)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_PatientPUid_ED2)
    }
    logger.warn("Update New PatientProblemUid of CacheEncounterDiagnosis Table Using #Problem1 Table is Done............")

    //create #Problem2
    val tempProblem3 = cleanedCacheEncounterDiagnosis2.filter($"StatusId" === 1 && $"PatientProblemUid".isNull
      && $"EncounterDiagnosisText".isNotNull)
      .select("PatientUid", "EncounterDiagnosisText").distinct()
      .withColumn("PatientProblemUid", FunctionUtility.getNewUid())

    //Update New PatientProblemUid of CacheEncounterDiagnosis Table Using #Problem1 Table
    val update_PatientPUid_ED3 = cleanedCacheEncounterDiagnosis2.as("df1").join(tempProblem3.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.EncounterDiagnosisText" === $"df2.EncounterDiagnosisText")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull && $"df1.EncounterDiagnosisCode".isNull)
      .select($"df1.*", $"df2.PatientProblemUid".as("aliasPatientProblemUid"))
      .withColumn("PatientProblemUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientPUid_ED3 = cleanedCacheEncounterDiagnosis2.as("df1").join(tempProblem3.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.EncounterDiagnosisText" === $"df2.EncounterDiagnosisText")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull && $"df1.EncounterDiagnosisCode".isNull)
      .select($"df1.*")

    if (where_PatientPUid_ED3.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_PatientPUid_ED3)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_PatientPUid_ED3)
    }
    logger.warn("Update New PatientProblemUid of CacheEncounterDiagnosis Table Using #Problem2 Table is Done............")

    //Insert Data Into ProblemPatient
    val insert_data_ProblemPatient = cleanedCacheEncounterDiagnosis2.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientProblemUid" === $"df2.PatientProblemUid", "left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.PatientProblemUid".isNull)
      .select($"df1.PatientProblemUid", $"df1.PatientUid", $"df1.CodeUid", $"df1.EncounterDiagnosisCode"
        , $"df1.EncounterDiagnosisText", $"df1.EncounterDiagnosisCategory").distinct()
      .groupBy($"PatientProblemUid", $"PatientUid", $"CodeUid")
      .agg(max($"EncounterDiagnosisCode").as("PracticeCode"), max($"EncounterDiagnosisText").as("PracticeDescription")
        , max($"EncounterDiagnosisText").as("Description"), max($"EncounterDiagnosisCategory").as("CodeSystem"))

    //column and union
    logger.warn("Insert data into PatientProblem table Using CacheEncounterDiagnosis table is Done............")

    //Update Status if DocumentationDate is null Of CacheencounterDiagnosis table
    val update_Status_EncounterDiag323 = cleanedCacheEncounterDiagnosis2.filter($"StatusId" === 1 && $"DocumentationDate".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("DocumentationDate not found"))

    val whereStatus_EncounterDiag323 = cleanedCacheEncounterDiagnosis2.filter($"StatusId" === 1 && $"DocumentationDate".isNull)

    if (whereStatus_EncounterDiag323.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(whereStatus_EncounterDiag323)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_Status_EncounterDiag323)
    }
    logger.warn("Update Status if DocumentationDate is null Of CacheencounterDiagnosis table is Done............")

    //Create Table PatientProblemHistory

    //Update PatientProblemHistoryUid of CacheEncounterDiagnosis using PatientProblemHistory_Prod table
    val update_PatientPHistoryUid_ED = cleanedCacheEncounterDiagnosis2.as("df1").join(PatientProblemHistory_Prod.as("df2")
      , $"df1.PatientProblemUid" === $"df2.PatientProblemUid" && $"df1.DocumentationDate" === $"df2.DocumentationDate")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemHistoryUid".isNull)
      .select($"df1.*", $"df2.PatientProblemHistoryUid".as("aliasPatientProblemHistoryUid"))
      .withColumn("PatientProblemHistoryUid", $"aliasPatientProblemHistoryUid")
      .drop("aliasPatientProblemHistoryUid")

    val where_PatientPHistoryUid_ED = cleanedCacheEncounterDiagnosis2.as("df1").join(PatientProblemHistory_Prod.as("df2")
      , $"df1.PatientProblemUid" === $"df2.PatientProblemUid" && $"df1.DocumentationDate" === $"df2.DocumentationDate")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemHistoryUid".isNull)
      .select($"df1.*")

    if (where_PatientPHistoryUid_ED.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_PatientPHistoryUid_ED)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_PatientPHistoryUid_ED)
    }
    logger.warn("Update PatientProblemHistoryUid of CacheEncounterDiagnosis using PatientProblemHistory_Prod table is Done............")

    //create #ProblemHistory
    val tempProblemHistory = cleanedCacheEncounterDiagnosis2.filter($"StatusId" === 1 && $"PatientProblemHistoryUid".isNull)
      .select("PatientProblemUid", "DocumentationDate").distinct()
      .withColumn("PatientProblemHistoryUid", FunctionUtility.getNewUid())

    //Update New PatientProblemHistoryUid of CacheEncounterDiagnosis Table Using #ProblemHistory Table
    val update_PatientPHUID_ED = cleanedCacheEncounterDiagnosis2.as("df1").join(tempProblemHistory.as("df2")
      , $"df1.PatientProblemUid" === $"df2.PatientProblemUid" && $"df1.DocumentationDate" === $"df2.DocumentationDate")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemHistoryUid".isNull)
      .select($"df1.*", $"df2.PatientProblemHistoryUid".as("aliasPatientProblemHistoryUid"))
      .withColumn("PatientProblemHistoryUid", $"aliasPatientProblemHistoryUid")
      .drop("aliasPatientProblemHistoryUid")

    val where_PatientPHUID_ED = cleanedCacheEncounterDiagnosis2.as("df1").join(tempProblemHistory.as("df2")
      , $"df1.PatientProblemUid" === $"df2.PatientProblemUid" && $"df1.DocumentationDate" === $"df2.DocumentationDate")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemHistoryUid".isNull)
      .select($"df1.*")

    if (where_PatientPHUID_ED.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_PatientPHUID_ED)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_PatientPHUID_ED)
    }
    logger.warn("Update New PatientProblemHistoryUid of CacheEncounterDiagnosis Table Using #ProblemHistory Table is Done............")

    //update EncounterProblemTypeCodeUid of CacheEncounterDiagnosis using MappingPracticeCommon
    val update_EncounterProblemTypeCodeUid = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.EncounterProblemTypeCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "163219CF-A146-4869-9354-DA8A65F8DBB0")
      .where($"df1.StatusId" === 1 && $"df1.EncounterProblemTypeCodeUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("EncounterProblemTypeCodeUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_EncounterProblemTypeCodeUid = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.EncounterProblemTypeCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "163219CF-A146-4869-9354-DA8A65F8DBB0")
      .where($"df1.StatusId" === 1 && $"df1.EncounterProblemTypeCodeUid".isNull)
      .select($"df1.*")

    if (where_EncounterProblemTypeCodeUid.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_EncounterProblemTypeCodeUid)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_EncounterProblemTypeCodeUid)
    }
    logger.warn("update EncounterProblemTypeCodeUid of CacheEncounterDiagnosis using MappingPracticeCommon is Done....")

    //update EncounterProblemTypeCodeUid of CacheEncounterDiagnosis using Master table
    val update_EncounterProblemTypeCodeUid2 = cleanedCacheEncounterDiagnosis2.as("df1").join(Master_prod.as("df2"),
      $"df1.EncounterProblemTypeCode" === $"df2.Code" || $"df1.EncounterProblemTypeText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.EncounterProblemTypeCodeUid".isNull && $"df2.Type" === "ProblemType")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("EncounterProblemTypeCodeUid", $"aliasMasterUid").drop("aliasMasterUid")

    val where_EncounterProblemTypeCodeUid2 = cleanedCacheEncounterDiagnosis2.as("df1").join(Master_prod.as("df2"),
      $"df1.EncounterProblemTypeCode" === $"df2.Code" || $"df1.EncounterProblemTypeText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.EncounterProblemTypeCodeUid".isNull && $"df2.Type" === "ProblemType")
      .select($"df1.*")

    if (where_EncounterProblemTypeCodeUid2.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_EncounterProblemTypeCodeUid2)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_EncounterProblemTypeCodeUid2)
    }
    logger.warn("update EncounterProblemTypeCodeUid of CacheEncounterDiagnosis using Master table is Done....")

    //Update Status if EncounterProblemTypeCode is not Null  Of CacheencounterDiagnosis table
    val update_Status_EncounterDiag3234 = cleanedCacheEncounterDiagnosis2.filter($"StatusId" === 1
      && rtrim(ltrim($"EncounterProblemTypeCode")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ProblemTypeCode Not Mapped"))

    val whereStatus_EncounterDiag3234 = cleanedCacheEncounterDiagnosis2.filter($"StatusId" === 1
      && rtrim(ltrim($"EncounterProblemTypeCode")).isNotNull)

    if (whereStatus_EncounterDiag3234.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(whereStatus_EncounterDiag3234)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_Status_EncounterDiag3234)
    }
    logger.warn("Update Status if EncounterProblemTypeCode is not Null Of CacheencounterDiagnosis table is Done............")

    //update ProblemHealthStatusUid of CacheEncounterDiagnosis using MappingPracticeCommonData
    val update_ProblemHealthStatusUid = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemHealthStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "0D033BD1-0523-4823-BE7A-2E83C2D3866B")
      .where($"df1.StatusId" === 1 && $"df1.ProblemHealthStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ProblemHealthStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_ProblemHealthStatusUid = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemHealthStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "0D033BD1-0523-4823-BE7A-2E83C2D3866B")
      .where($"df1.StatusId" === 1 && $"df1.ProblemHealthStatusUid".isNull)
      .select($"df1.*")

    if (where_ProblemHealthStatusUid.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_ProblemHealthStatusUid)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_ProblemHealthStatusUid)
    }
    logger.warn("update ProblemHealthStatusUid of CacheEncounterDiagnosis using MappingPracticeCommonData is Done............")

    //update ProblemHealthStatusUid of CacheEncounterDiagnosis using MappingPracticeCommonData 2
    val update_ProblemHealthStatusUid2 = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemHealthStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "0D033BD1-0523-4823-BE7A-2E83C2D3866B")
      .where($"df1.StatusId" === 1 && $"df1.ProblemHealthStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ProblemHealthStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_ProblemHealthStatusUid2 = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemHealthStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "0D033BD1-0523-4823-BE7A-2E83C2D3866B")
      .where($"df1.StatusId" === 1 && $"df1.ProblemHealthStatusUid".isNull)
      .select($"df1.*")

    if (where_ProblemHealthStatusUid2.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_ProblemHealthStatusUid2)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_ProblemHealthStatusUid2)
    }
    logger.warn("update ProblemHealthStatusUid of CacheEncounterDiagnosis using MappingPracticeCommonData 2 is Done............")

    //update ProblemHealthStatusUid of CacheEncounterDiagnosis using Master table
    val update_ProblemHealthStatusUid3 = cleanedCacheEncounterDiagnosis2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemHealthStatusCode" === $"df2.Code" || $"df1.ProblemHealthStatusText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemHealthStatusUid".isNull && $"df2.Type" === "ProblemHealthStatus")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("ProblemHealthStatusUid", $"aliasMasterUid")
      .withColumn("ErrorNote", lit("null"))
      .drop("aliasMasterUid")

    val where_ProblemHealthStatusUid3 = cleanedCacheEncounterDiagnosis2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemHealthStatusCode" === $"df2.Code" || $"df1.ProblemHealthStatusText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemHealthStatusUid".isNull && $"df2.Type" === "ProblemHealthStatus")
      .select($"df1.*")


    if (where_ProblemHealthStatusUid3.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_ProblemHealthStatusUid3)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_ProblemHealthStatusUid3)
    }
    logger.warn("update ProblemHealthStatusUid of CacheEncounterDiagnosis using Master table is Done............")

    //Update Status if ProblemHealthStatusCode is not Null OR ProblemHealthStatusText is not Null Of CacheencounterDiagnosis table
    val update_Status_EncounterDiag33 = cleanedCacheEncounterDiagnosis2.filter($"StatusId" === 1
      && rtrim(ltrim($"ProblemHealthStatusCode")).isNotNull || rtrim(ltrim($"ProblemHealthStatusText")).isNotNull
      && $"ProblemHealthStatusUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ProblemHealthStatusCode Not Mapped"))

    val whereStatus_EncounterDiag33 = cleanedCacheEncounterDiagnosis2.filter($"StatusId" === 1
      && rtrim(ltrim($"ProblemHealthStatusCode")).isNotNull || rtrim(ltrim($"ProblemHealthStatusText")).isNotNull
      && $"ProblemHealthStatusUid".isNull)

    if (whereStatus_EncounterDiag33.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(whereStatus_EncounterDiag33)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_Status_EncounterDiag33)
    }
    logger.warn("Update Status if ProblemHealthStatusCode is not Null OR ProblemHealthStatusText is not Null Of CacheencounterDiagnosis table is Done......")

    //update ProblemStatusUid from MappingPracticeCommonData of CacheEncounterDiagnosis
    val update_ProblemStatusUid = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "91AC99A5-71CD-44AE-9B1B-21211FB71099")
      .where($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ProblemStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_ProblemStatusUid = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "91AC99A5-71CD-44AE-9B1B-21211FB71099")
      .where($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull)
      .select($"df1.*")

    if (where_ProblemStatusUid.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_ProblemStatusUid)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_ProblemStatusUid)
    }
    logger.warn("update ProblemStatusUid from MappingPracticeCommonData of CacheEncounterDiagnosis is Done......")

    //update ProblemStatusUid from MappingPracticeCommonData of CacheEncounterDiagnosis 2
    val update_ProblemStatusUid2 = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "91AC99A5-71CD-44AE-9B1B-21211FB71099")
      .where($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ProblemStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_ProblemStatusUid2 = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "91AC99A5-71CD-44AE-9B1B-21211FB71099")
      .where($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull)
      .select($"df1.*")

    if (where_ProblemStatusUid2.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_ProblemStatusUid2)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_ProblemStatusUid2)
    }
    logger.warn("update ProblemStatusUid from MappingPracticeCommonData of CacheEncounterDiagnosis 2 is Done......")

    //update ProblemStatusUid of CacheEncounterDiagnosis using Master table
    val update_ProblemStatusUid3 = cleanedCacheEncounterDiagnosis2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemStatusCode" === $"df2.Code")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull && $"df2.Type" === "ProblemStatus"
        && $"df1.ProblemStatusText".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("ProblemStatusUid", $"aliasMasterUid")
      .withColumn("ErrorNote", lit("null"))
      .drop("aliasMasterUid")

    val where_ProblemStatusUid3 = cleanedCacheEncounterDiagnosis2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemStatusCode" === $"df2.Code")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull && $"df2.Type" === "ProblemStatus"
        && $"df1.ProblemStatusText".isNull)
      .select($"df1.*")

    if (where_ProblemStatusUid3.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_ProblemStatusUid3)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_ProblemStatusUid3)
    }
    logger.warn("update ProblemStatusUid of CacheEncounterDiagnosis using Master table is Done......")

    //update ProblemStatusUid of CacheEncounterDiagnosis using Master table 2
    val update_ProblemStatusUid4 = cleanedCacheEncounterDiagnosis2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemStatusText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull && $"df2.Type" === "ProblemStatus"
        && $"df1.ProblemStatusCode".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("ProblemStatusUid", $"aliasMasterUid")
      .withColumn("ErrorNote", lit("null"))
      .drop("aliasMasterUid")

    val where_ProblemStatusUid4 = cleanedCacheEncounterDiagnosis2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemStatusText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull && $"df2.Type" === "ProblemStatus"
        && $"df1.ProblemStatusCode".isNull)
      .select($"df1.*")

    if (where_ProblemStatusUid4.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_ProblemStatusUid4)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_ProblemStatusUid4)
    }
    logger.warn("update ProblemStatusUid of CacheEncounterDiagnosis using Master table 2 is Done......")

    //Update Status if ProblemStatusCode is not Null OR ProblemStatusText is not Null Of CacheencounterDiagnosis table
    val update_Status_EncounterDiag337 = cleanedCacheEncounterDiagnosis2.filter($"StatusId" === 1
      && rtrim(ltrim($"ProblemStatusCode")).isNotNull || rtrim(ltrim($"ProblemStatusText")).isNotNull
      && $"ProblemStatusUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ProblemStatusCode Not Mapped"))

    val where_Status_EncounterDiag337 = cleanedCacheEncounterDiagnosis2.filter($"StatusId" === 1
      && rtrim(ltrim($"ProblemStatusCode")).isNotNull || rtrim(ltrim($"ProblemStatusText")).isNotNull
      && $"ProblemStatusUid".isNull)

    if (where_Status_EncounterDiag337.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_Status_EncounterDiag337)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_Status_EncounterDiag337)
    }
    logger.warn("Update Status if ProblemStatusCode is not Null OR ProblemStatusText is not Null Of CacheencounterDiagnosis table is Done......")

    //update TargetSiteUid from MappingPracticeCommonData of CacheEncounterDiagnosis
    val update_TargetSiteUid = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.TargetSiteCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .where($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("TargetSiteUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_TargetSiteUid = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.TargetSiteCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .where($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull)
      .select($"df1.*")

    if (where_TargetSiteUid.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_TargetSiteUid)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_TargetSiteUid)
    }
    logger.warn("update TargetSiteUid from MappingPracticeCommonData of CacheEncounterDiagnosis is Done......")

    //update TargetSiteUid from MappingPracticeCommonData of CacheEncounterDiagnosis2
    val update_TargetSiteUid2 = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.TargetSiteText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .where($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("TargetSiteUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_TargetSiteUid2 = cleanedCacheEncounterDiagnosis2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.TargetSiteText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .where($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull)
      .select($"df1.*")

    if (where_TargetSiteUid2.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_TargetSiteUid2)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_TargetSiteUid2)
    }
    logger.warn("update TargetSiteUid from MappingPracticeCommonData of CacheEncounterDiagnosis 2 is Done......")

    //Update TargetSiteUid from Master Table of CacheEncounterDiagnosis
    val update_TargetSiteUid3 = cleanedCacheEncounterDiagnosis2.as("df1").join(Master_prod.as("df2"),
      $"df1.TargetSiteCode" === $"df2.Code")
      .filter($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull && $"df2.Type" === "TargetSite")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("TargetSiteUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_TargetSiteUid3 = cleanedCacheEncounterDiagnosis2.as("df1").join(Master_prod.as("df2"),
      $"df1.TargetSiteCode" === $"df2.Code")
      .filter($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull && $"df2.Type" === "TargetSite")
      .select($"df1.*")

    if (where_TargetSiteUid3.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_TargetSiteUid3)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_TargetSiteUid3)
    }
    logger.warn("Update TargetSiteUid from Master Table of CacheEncounterDiagnosis is Done......")

    //Update TargetSiteUid from Master Table of CacheEncounterDiagnosis2
    val update_TargetSiteUid4 = cleanedCacheEncounterDiagnosis2.as("df1").join(Master_prod.as("df2"),
      $"df1.TargetSiteText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull && $"df2.Type" === "TargetSite")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("TargetSiteUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_TargetSiteUid4 = cleanedCacheEncounterDiagnosis2.as("df1").join(Master_prod.as("df2"),
      $"df1.TargetSiteText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull && $"df2.Type" === "TargetSite")
      .select($"df1.*")

    if (where_TargetSiteUid4.count > 0) {
      val ex = cleanedCacheEncounterDiagnosis2.except(where_TargetSiteUid4)
      cleanedCacheEncounterDiagnosis2 = ex.union(update_TargetSiteUid4)
    }
    logger.warn("Update TargetSiteUid from Master Table of CacheEncounterDiagnosis 2 is Done......")

    //Update PatientProblemHistory Table
    val update_PatientProblemHistory_Table = PatientProblemHistory_Prod.as("df1").join(cleanedCacheEncounterDiagnosis2.as("df2")
      , $"df1.PatientProblemHistoryUid" === $"df2.PatientProblemHistoryUid").filter($"df2.StatusId" === 1)
      .select($"df1.*", $"df2.ProblemResolutionDate".as("aliasPRDate"), $"df2.EncounterProblemTypeCodeUid"
        .as("aliasEPTCUid"), $"df2.ProblemHealthStatusUid".as("aliasPHSUid"), $"df2.ProblemStatusUid".as("aliasPSUid"),
        $"df2.TargetSiteUid".as("aliasTSUid"))
      .withColumn("ResolutionDate", $"aliasPRDate")
      .withColumn("MasterProblemTypeUid", $"aliasEPTCUid")
      .withColumn("ProblemHealthStatusUid", $"aliasPHSUid")
      .withColumn("ProblemStatusUid", $"aliasPSUid")
      .withColumn("TargetSiteUid", $"aliasTSUid")
      .withColumn("ModifiedDate", current_timestamp())

    val where_PatientProblemHistory = PatientProblemHistory_Prod.as("df1").join(cleanedCacheEncounterDiagnosis2.as("df2")
      , $"df1.PatientProblemHistoryUid" === $"df2.PatientProblemHistoryUid").filter($"df2.StatusId" === 1)
      .select($"df1.*")

    val ex_PatientProblemHistory = PatientProblemHistory_Prod.except(where_PatientProblemHistory)
    var PatientProblemHistory_Prod1 = ex_PatientProblemHistory.union(update_PatientProblemHistory_Table)

      logger.warn("Update PatientProblemHistory Table is Done......")

    //Insert Data Into PatientProblemHistory
    val insert_Data_PatientProblemHistory = cleanedCacheEncounterDiagnosis2.as("df1").join(PatientProblemHistory_Prod1.as("df2")
      , $"df1.PatientProblemHistoryUid" === $"df2.PatientProblemHistoryUid", "left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.PatientProblemHistoryUid".isNull)
      .select($"df1.PatientProblemHistoryUid", $"df1.PatientProblemUid", $"df1.DocumentationDate"
        , $"df1.ProblemResolutionDate", $"df1.EncounterProblemTypeCodeUid".as("MasterProblemTypeUid")
        , $"df1.ProblemHealthStatusUid", $"df1.ProblemStatusUid", $"df1.TargetSiteUid")
      .groupBy($"PatientProblemHistoryUid", $"PatientProblemUid", $"DocumentationDate", $"MasterProblemTypeUid"
        , $"ProblemHealthStatusUid", $"ProblemStatusUid", $"TargetSiteUid")
      .agg(max($"ProblemResolutionDate").as("ResolutionDate"))

    val PatientPHistory_allcols = PatientProblemHistory_Prod1.columns.toSet
    val insert_PatientPHistory_cols = insert_Data_PatientProblemHistory.columns.toSet
    val tot_cols = PatientPHistory_allcols ++ insert_PatientPHistory_cols

    PatientProblemHistory_Prod1 = PatientProblemHistory_Prod1.select(FunctionUtility.addColumns(PatientPHistory_allcols, tot_cols): _*)
      .union(insert_Data_PatientProblemHistory.select(FunctionUtility.addColumns(insert_PatientPHistory_cols, tot_cols): _*))

    logger.warn("Insert Data Into PatientProblemHistory is Done......")

    //Load VisitDiagnosis table

    //Insert Data Into VisitDiagnosis_Prod
    val insert_VisitDiagnosis_Prod = cleanedCacheEncounterDiagnosis2.as("df1").join(VisitDiagnosis_Prod.as("df2")
      , $"df1.VisitUid" === $"df2.VisitUid" && $"df1.PatientProblemHistoryUid" === $"df2.PatientProblemHistoryUid"
      , "left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.VisitDiagnosisUid".isNull)
      .select($"df1.VisitUid", $"df1.PatientProblemHistoryUid", $"df1.EncounterDiagnosisText", $"df1.ListOrder"
        , $"df1.EncounterDiagnosisCategory")
      .groupBy($"VisitUid", $"PatientProblemHistoryUid", $"EncounterDiagnosisCategory", $"ListOrder")
      .agg(max($"EncounterDiagnosisText").as("Description"))
      .drop("EncounterDiagnosisCategory")

    val VistDiag_allcols = VisitDiagnosis_Prod.columns.toSet
    val insert_VisitDiag = insert_VisitDiagnosis_Prod.columns.toSet
    val tot_VisitDiag = VistDiag_allcols ++ insert_VisitDiag

    val VisitDiagnosis_Prod1 = VisitDiagnosis_Prod.select(FunctionUtility.addColumns(VistDiag_allcols, tot_VisitDiag): _*)
      .union(insert_VisitDiagnosis_Prod.select(FunctionUtility.addColumns(insert_VisitDiag, tot_VisitDiag): _*))


    logger.warn("Insert Data Into VisitDiagnosis_Prod is Done......")

    //End CachePatientDiagnosis Sp..........................................

    List(PatientProblemHistory_Prod1,VisitDiagnosis_Prod1)
  }

}
