package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory

class CachePatientNotesMedication {


  def CachePatientNotesMedicationFunc (spark : SparkSession,MergePracticeMap : DataFrame
                                       ,CDRPatientCrosswalkTable : DataFrame
                                       ,ClinicalInformationModelSection : DataFrame
                                       ,MultiTableExtendTable : DataFrame
                                       ,Individual : DataFrame
                                       ,ProviderNPIChangeTable : DataFrame
                                       ,PatientNoteMedication_Prod : DataFrame
                                       ,Patient_Prod_Delta : DataFrame
                                       ,Individual_prod_Delta7 : DataFrame
                                       ,ViewServiceProvider_prod : DataFrame
                                       ,ViewFacility_Prod : DataFrame
                                       ,ServiceProvider_prod_Delta6 : DataFrame
                                       ,Institution_Prod_Delta3 : DataFrame
                                       ,ServiceLocation_Prod_Delta3 : DataFrame
                                      ,distIndUid : DataFrame,distspUID : DataFrame) : List[DataFrame] = {

    val logger = LoggerFactory.getLogger("")

    import spark.implicits._
    //Start CachePatientNotesMedication
    var CachePatientNotesMedication = spark.read.option("delimiter", "\u0017")
      .csv("/home/ravikant.petkar/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/608cdee4-97d1-42a2-849d-9d9a95bc5131_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")

    val lookupCachePatientNotesMedication = Map("_c0" -> "PatientId", "_c1" -> "EncounterDate", "_c2" -> "SectionName"
      , "_c3" -> "Note", "_c4" -> "ServiceProviderNPI", "_c5" -> "ServiceProviderLastName"
      , "_c6" -> "ServiceProviderFirstName", "_c7" -> "ServiceLocationId"
      , "_c8" -> "ServiceLocationName", "_c9" -> "Group1", "_c10" -> "Group2"
      , "_c11" -> "Group3", "_c12" -> "Group4", "_c13" -> "PracticePatientNoteKey"
      , "_c14" -> "PracticeUid", "_c15" -> "BatchUid", "_c16" -> "dummy1"
      , "_c17" -> "dummy2")

    CachePatientNotesMedication = CachePatientNotesMedication.select(CachePatientNotesMedication.columns.map(c => col(c).as(lookupCachePatientNotesMedication.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    val tempCachePatientNotesMedication = spark.read.option("header", "true")
      .csv("/home/ravikant.petkar/Downloads/AAO_Projects/AAO_DATA/Schema/CachePatientNotesMedication")

    val CachePatientNotesMedicationcols = tempCachePatientNotesMedication.columns.toSet
    val CachePatientNotesMedicationViewcols = CachePatientNotesMedication.columns.toSet
    val tot_viewCachePatientNotesMedication = CachePatientNotesMedicationcols ++ CachePatientNotesMedicationViewcols

    CachePatientNotesMedication = tempCachePatientNotesMedication.select(FunctionUtility.addColumns(CachePatientNotesMedicationcols, tot_viewCachePatientNotesMedication): _*)
      .union(CachePatientNotesMedication.select(FunctionUtility.addColumns(CachePatientNotesMedicationViewcols, tot_viewCachePatientNotesMedication): _*))

    CachePatientNotesMedication = CachePatientNotesMedication.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    //Distinct PracticeUid of CachePatientNotesMedication
    val dist_PrctUid_CachePatientNotesMedication = CachePatientNotesMedication.filter($"StatusId".isNull).select("PracticeUid").distinct()

    val tempMergePracticeMap_CachePatientNotesMedication = MergePracticeMap.as("df1").join(dist_PrctUid_CachePatientNotesMedication.as("df2")
      , $"df1.NewPracticeuid" === $"df2.PracticeUid").select($"df1.*")

    //Update PracticeUid with OriginalPracticeuid of CachePatientNotesMedication
    CachePatientNotesMedication = CachePatientNotesMedication.as("df1").join(tempMergePracticeMap_CachePatientNotesMedication.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeuid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeuid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeuid of CachePatientNotesMedication is Done.............................")

    CachePatientNotesMedication = CachePatientNotesMedication.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CachePatientNotesMedication
    CachePatientNotesMedication = CachePatientNotesMedication.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("ServiceLocationId", rtrim(ltrim($"df1.ServiceLocationId")))
      .withColumn("ServiceProviderNPI", rtrim(ltrim($"df1.ServiceProviderNPI")))
      .withColumn("SectionName", rtrim(ltrim($"df1.SectionName")))
      .withColumn("PatientId", rtrim(ltrim($"df1.PatientId")))
      .withColumn("PracticePatientNoteKey", rtrim(ltrim($"df1.PracticePatientNoteKey")))
      .withColumn("PracticeSideNPI", rtrim(ltrim($"df1.ServiceProviderNPI")))

    logger.warn("Update Multiple Columns of CachePatientNotesMedication is Done............")

    //Update Status Of CachePatientNotesMedication table
    val update_Status_CachePatientNotesMedication323 = CachePatientNotesMedication.filter($"StatusId" === 1 && $"df1.PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val whereStatus_CachePatientNotesMedication323 = CachePatientNotesMedication.filter($"StatusId" === 1 && $"df1.PatientId".isNull)

    if (whereStatus_CachePatientNotesMedication323.count > 0) {
      val ex = CachePatientNotesMedication.except(whereStatus_CachePatientNotesMedication323)
      CachePatientNotesMedication = ex.union(update_Status_CachePatientNotesMedication323)
    }
    logger.warn("Update Status Of CachePatientNotesMedication table is Done............")

    //Update PatientId using CDRPatientCrosswalk In CachePatientNotesMedication Table
    val updatePatientIdCachePatientNotesMedication = CachePatientNotesMedication.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientIdCachePatientNotesMedication = CachePatientNotesMedication.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientIdCachePatientNotesMedication.count > 0) {
      val ex = CachePatientNotesMedication.except(where_PatientIdCachePatientNotesMedication)
      CachePatientNotesMedication = ex.union(updatePatientIdCachePatientNotesMedication)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk In CachePatientNotesMedication Table is Done............")

    //Update Multiple Status Of CachePatientNotesMedication
    val a12 = CachePatientNotesMedication.filter($"StatusId" === 1 && $"PracticePatientNoteKey".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PracticePatientNoteKey is Not Found or Missing"))

    val b12 = CachePatientNotesMedication.filter($"StatusId" === 1 && $"SectionName".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("SectionName is null"))

    val c12 = CachePatientNotesMedication.filter($"StatusId" === 1 && $"Note".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Note is null"))

    val update_Status_CachePatientNotesMedication = a12.union(b12).union(c12)

    val where_CachePatientNotesMedication = CachePatientNotesMedication.filter($"StatusId" === 1 && ($"PracticePatientNoteKey".isNull
      && $"SectionName".isNull && $"Note".isNull))

    if (where_CachePatientNotesMedication.count > 0) {
      val ex = CachePatientNotesMedication.except(where_CachePatientNotesMedication)
      CachePatientNotesMedication = ex.union(update_Status_CachePatientNotesMedication)
    }
    logger.warn("Update Multiple Status Of CachePatientNotesMedication is Done............")


    //Update ClinicalInformationModelSectionUid using ClinicalInformationModelSection In CachePatientNotesMedication Table
    val updateClinicalInformationModelSectionUid = CachePatientNotesMedication.as("df1")
      .join(ClinicalInformationModelSection.as("df2")
      , $"df1.SectionName" === $"df2.Name" && $"df1.ClinicalInformationModelSectionUid".isNull)
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ClinicalInformationModelSectionUid".as("aliasClinicalInformationModelSectionUid"))
      .withColumn("ClinicalInformationModelSectionUid", $"aliasClinicalInformationModelSectionUid")
      .drop("aliasClinicalInformationModelSectionUid")

    val where_ClinicalInformationModelSectionUid = CachePatientNotesMedication.as("df1")
      .join(ClinicalInformationModelSection.as("df2")
      , $"df1.SectionName" === $"df2.Name" && $"df1.ClinicalInformationModelSectionUid".isNull)
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_ClinicalInformationModelSectionUid.count > 0) {
      val ex = CachePatientNotesMedication.except(where_ClinicalInformationModelSectionUid)
      CachePatientNotesMedication = ex.union(updateClinicalInformationModelSectionUid)
    }

    logger.warn("Update ClinicalInformationModelSectionUid using ClinicalInformationModelSection In CachePatientNotesMedication Table is Done............")

    //Update Status Of CachePatientNotesMedication table 2
    val update_Status_CachePatientNotesMedication3234 = CachePatientNotesMedication.filter($"StatusId" === 1 && $"df1.ClinicalInformationModelSectionUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Section Name Invalid or Missing"))

    val whereStatus_CachePatientNotesMedication3234 = CachePatientNotesMedication.filter($"StatusId" === 1 && $"df1.ClinicalInformationModelSectionUid".isNull)

    if (whereStatus_CachePatientNotesMedication3234.count > 0) {
      val ex = CachePatientNotesMedication.except(whereStatus_CachePatientNotesMedication3234)
      CachePatientNotesMedication = ex.union(update_Status_CachePatientNotesMedication3234)
    }
    logger.warn("Update Status Of CachePatientNotesMedication table 2 is Done............")


    //Update value using MultiTableExtend In CachePatientNotesMedication Table
    val updateValue = CachePatientNotesMedication.as("df1").join(MultiTableExtendTable.as("df2")
      , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ServiceProviderNPI" === $"df2.Element1" && $"df2.GroupName" === "ProviderNPI")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.value".as("aliasvalue"))
      .withColumn("ServiceProviderNPI", $"aliasServiceProviderNPI")
      .drop("aliasServiceProviderNPI")

    val where_updateValue = CachePatientNotesMedication.as("df1").join(MultiTableExtendTable.as("df2")
      , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ServiceProviderNPI" === $"df2.Element1" && $"df2.GroupName" === "ProviderNPI")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_updateValue.count > 0) {
      val ex = CachePatientNotesMedication.except(where_updateValue)
      CachePatientNotesMedication = ex.union(updateValue)
    }

    logger.warn("Update value using MultiTableExtend In CachePatientNotesMedication Table is Done............")

    //Update NewNPI using ProviderNPIChange In CachePatientNotesMedication Table
    val updateNewNPI = ProviderNPIChangeTable.as("df1").join(Individual.as("df2")
      , $"df2.IndividualUid" === $"df1.ServiceProviderUid").join(CachePatientNotesMedication.as("df3"), $"df3.PracticeUid" === $"df2.PracticeUid" && $"df3.ServiceProviderNPI" === $"df1.OldNPI")
      .filter($"df3.StatusId" === 1)
      .select($"df3.*", $"df1.NewNPI".as("aliasNewNPI"))
      .withColumn("ServiceProviderNPI", $"aliasServiceProviderNPI")
      .drop("aliasServiceProviderNPI")

    val where_NewNPI = ProviderNPIChangeTable.as("df1").join(Individual.as("df2")
      , $"df2.IndividualUid" === $"df1.ServiceProviderUid").join(CachePatientNotesMedication.as("df3"), $"df3.PracticeUid" === $"df2.PracticeUid" && $"df3.ServiceProviderNPI" === $"df1.OldNPI")
      .filter($"df3.StatusId" === 1)
      .select($"df3.*")

    if (where_NewNPI.count > 0) {
      val ex = CachePatientNotesMedication.except(where_NewNPI)
      CachePatientNotesMedication = ex.union(updateNewNPI)
    }

    logger.warn("Update NewNPI using ProviderNPIChange In CachePatientNotesMedication Table is Done............")

    //Update value using MultiTableExtend In CachePatientNotesMedication Table 2
    val updateValue2 = CachePatientNotesMedication.as("df1").join(MultiTableExtendTable.as("df2")
      , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ServiceProviderFirstName" === $"df2.Element1" && $"df1.ServiceProviderLastName" === $"df2.element2" && $"df2.GroupName" === "ProviderNPI")
      .filter($"df1.StatusId" === 1 && $"df1.ServiceProviderNPI".isNull && $"df2.element2".isNotNull)
      .select($"df1.*", $"df2.value".as("aliasvalue"))
      .withColumn("ServiceProviderNPI", $"aliasServiceProviderNPI")
      .drop("aliasServiceProviderNPI")

    val where_updateValue2 = CachePatientNotesMedication.as("df1").join(MultiTableExtendTable.as("df2")
      , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ServiceProviderFirstName" === $"df2.Element1" && $"df1.ServiceProviderLastName" === $"df2.element2" && $"df2.GroupName" === "ProviderNPI")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_updateValue2.count > 0) {
      val ex = CachePatientNotesMedication.except(where_updateValue2)
      CachePatientNotesMedication = ex.union(updateValue2)
    }
    logger.warn("Update value using MultiTableExtend In CachePatientNotesMedication Table 2 is Done............")

    //Update Status Of CachePatientNotesMedication table 3
    val update_Status_CachePatientNotesMedication32343 = CachePatientNotesMedication.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid NPI Found,Length should be 10"))

    val whereStatus_CachePatientNotesMedication32343 = CachePatientNotesMedication.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)

    if (whereStatus_CachePatientNotesMedication32343.count > 0) {
      val ex = CachePatientNotesMedication.except(whereStatus_CachePatientNotesMedication32343)
      CachePatientNotesMedication = ex.union(update_Status_CachePatientNotesMedication32343)
    }
    logger.warn("Update Status Of CachePatientNotesMedication table 3 is Done............")



    //Update PatientUid using Patient In CachePatientNotesMedication Table 2
    val updatePatientIdCachePatientNotesMedication2 = CachePatientNotesMedication.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta7.as("df3"), $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val where_PatientIdCachePatientNotesMedication2 = CachePatientNotesMedication.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta7.as("df3"), $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientIdCachePatientNotesMedication2.count > 0) {
      val ex = CachePatientNotesMedication.except(where_PatientIdCachePatientNotesMedication2)
      CachePatientNotesMedication = ex.union(updatePatientIdCachePatientNotesMedication2)
    }

    logger.warn("Update PatientUid using Patient In CachePatientNotesMedication Table 2 is Done............")

    //Update ServiceProviderUid using ViewServiceProvider In CachePatientNotesMedication Table 3
    val updateServiceProviderUid12 = CachePatientNotesMedication.as("df1").join(ViewServiceProvider_prod.as("df2")
      , $"df1.ServiceProviderNPI" === $"df2.NPI" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceProviderUid".as("aliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"aliasServiceProviderUid")
      .drop("aliasServiceProviderUid")

    val where_ServiceProviderUid12 = CachePatientNotesMedication.as("df1").join(ViewServiceProvider_prod.as("df2")
      , $"df1.ServiceProviderNPI" === $"df2.NPI" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_ServiceProviderUid12.count > 0) {
      val ex = CachePatientNotesMedication.except(where_ServiceProviderUid12)
      CachePatientNotesMedication = ex.union(updateServiceProviderUid12)
    }

    logger.warn("Update ServiceProviderUid using ViewServiceProvider In CachePatientNotesMedication Table 3 is Done............")

    //Update ServiceLocationUid using ViewFacility In CachePatientNotesMedication Table 4
    val updateServiceProviderUid123 = CachePatientNotesMedication.as("df1").join(ViewFacility_Prod.as("df2")
      , $"df1.ServiceLocationid" === $"df2.id" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceLocationUid".as("aliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"aliasServiceLocationUid")
      .drop("aliasServiceLocationUid")

    val where_ServiceProviderUid123 = CachePatientNotesMedication.as("df1").join(ViewFacility_Prod.as("df2")
      , $"df1.ServiceLocationid" === $"df2.id" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_ServiceProviderUid123.count > 0) {
      val ex = CachePatientNotesMedication.except(where_ServiceProviderUid123)
      CachePatientNotesMedication = ex.union(updateServiceProviderUid123)
    }

    logger.warn("Update ServiceLocationUid using ViewFacility In CachePatientNotesMedication Table 4 is Done............")

    //Update Status Of CachePatientNotesMedication table 4
    val update_Status_CachePatientNotesMedication323434 = CachePatientNotesMedication.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val whereStatus_CachePatientNotesMedication323434 = CachePatientNotesMedication.filter($"StatusId" === 1 && $"PatientUid".isNull)

    if (whereStatus_CachePatientNotesMedication323434.count > 0) {
      val ex = CachePatientNotesMedication.except(whereStatus_CachePatientNotesMedication323434)
      CachePatientNotesMedication = ex.union(update_Status_CachePatientNotesMedication323434)
    }
    logger.warn("Update Status Of CachePatientNotesMedication table 4 is Done............")

    //Create #PHY table Using CachePatientNotesMedication Table
    var tempPhyNotesMedication = CachePatientNotesMedication.as("df1")
      .select("ServiceProviderUid", "ServiceProviderNPI", "ServiceProviderFirstName","Physician_MidName", "ServiceProviderLastName"
        , "PracticeUid")
      .where($"ServiceProviderNPI".isNotNull && $"ServiceProviderUid".isNotNull && $"StatusId" === 1)
      .groupBy($"ServiceProviderNPI", $"PracticeUid")
      .agg(max("ServiceProviderFirstName").as("ServiceProviderFirstName")
        , max("ServiceProviderLastName").as("ServiceProviderLastName"))
      .withColumn("Physician_MidName", lit("null"))

    //Update ServiceLocationUid using tempPhyVitalObservation In CachePatientNotesMedication Table 6
    val updateServiceProviderUidNotesMedication56 = CachePatientNotesMedication.as("df1").join(tempPhyNotesMedication.as("df2")
      , $"df1.PracticeUid" === $"df3.PracticeUid" && $"df1.ServiceProviderUid".isNull && $"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceProviderUid".as("aliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"aliasServiceProviderUid")
      .drop("aliasServiceProviderUid")

    val where_ServiceProviderUidNotesMedication56 = CachePatientNotesMedication.as("df1").join(tempPhyNotesMedication.as("df2")
      , $"df1.PracticeUid" === $"df3.PracticeUid" && $"df1.ServiceProviderUid".isNull && $"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_ServiceProviderUidNotesMedication56.count > 0) {
      val ex = CachePatientNotesMedication.except(where_ServiceProviderUidNotesMedication56)
      CachePatientNotesMedication = ex.union(updateServiceProviderUidNotesMedication56)
    }

    logger.warn("Update ServiceLocationUid using ViewFacility In CachePatientNotesMedication Table 6 is Done............")

    //Insert data Into Individual Table Of CachePatientNotesMedication
    val insert_Individual = tempPhyNotesMedication.as("df1")
      .join(distIndUid.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.IndividualUid"))
      .select($"df1.ServiceProviderUid".as("IndividualUid"), $"df1.ServiceProviderFirstName".as("First")
        , $"df1.Physician_MidName".as("Middle"), $"ServiceProviderLastName".as("Last"),
        $"df1.PracticeUid".as("PracticeUid")).distinct()

    val indicols = Individual_prod_Delta7.columns.toSet
    val insertIndividualcols = insert_Individual.columns.toSet
    val tot = indicols ++ insertIndividualcols

    val Individual_prod_Delta8 = Individual_prod_Delta7.select(FunctionUtility.addColumns(indicols, tot): _*)
      .union(insert_Individual.select(FunctionUtility.addColumns(insertIndividualcols, tot): _*))

    logger.warn("Insert data Into Individual Table Of CachePatientNotesMedication is Done............")

    //Insert data Into ServiceProvider Table Of CachePatientNotesMedication
    val insertdataServiceProv = tempPhyNotesMedication.as("df1").join(distspUID.as("df2")
      , !$"df1.ServiceProviderUid".isin($"df2.ServiceProviderUid"))
      .select($"df1.ServiceProviderUid", when($"df1.Physician_MidName".isNotNull, concat_ws(" "
        , $"ServiceProviderLastName", $"ServiceProviderFirstName", $"Physician_MidName"))
        .otherwise(concat_ws(" ", $"ServiceProviderLastName", $"ServiceProviderFirstName")).as("ListName")
        , $"df1.ServiceProviderNPI".as("NPI"))
      .withColumn("ExternalID", lit(null))
      .withColumn("Type", lit(4))

    val servicePcols = ServiceProvider_prod_Delta6.columns.toSet
    val insertdataServiceProvcols = insertdataServiceProv.columns.toSet
    val tot1 = servicePcols ++ insertdataServiceProvcols

    val ServiceProvider_prod_Delta7 = ServiceProvider_prod_Delta6.select(FunctionUtility.addColumns(servicePcols, tot1): _*)
      .union(insertdataServiceProv.select(FunctionUtility.addColumns(insertdataServiceProvcols, tot1): _*))

    //Use toset and union and insert data into ServiceProvider table
    logger.warn("Insert data Into ServiceProvider Table Of CachePatientNotesMedication is Done............")

    //create #loc12
    val loc12 = CachePatientNotesMedication.filter($"StatusId" === 1 && rtrim(ltrim($"ServiceLocationId")).isNull && $"ServiceLocationUid".isNull)
      .select("ServiceLocationId", "ServiceLocationName", "PracticeUid").distinct()
      .withColumn("ServiceLocationUid", FunctionUtility.getNewUid())

    val updateloc12 = CachePatientNotesMedication
      .filter( rtrim(ltrim($"ServiceLocationName")).isNull)
      .select($"ServiceLocationId".as("aliasServiceLocationUid"))
      .withColumn("ServiceLocationName", $"aliasServiceLocationName")
      .drop("aliasServiceLocationName")

    val where_loc12 = CachePatientNotesMedication
      .filter(rtrim(ltrim($"ServiceLocationName")).isNull)
      .select($"*")

    if (where_loc12.count > 0) {
      val ex = CachePatientNotesMedication.except(where_loc12)
      CachePatientNotesMedication = ex.union(updateloc12)
    }

    //Update ServiceLocationUid using loc In CachePatientNotesMedication Table 4
    val updateServiceLocationUid1234 = CachePatientNotesMedication.as("df1").join(loc12.as("df2")
      , $"df1.ServiceLocationId" === $"df2.ServiceLocationId.id" && $"df1.ServiceLocationName" === $"df2.ServiceLocationName" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceLocationUid".as("aliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"aliasServiceLocationUid")
      .drop("aliasServiceLocationUid")

    val where_ServiceLocationUid1234 = CachePatientNotesMedication.as("df1").join(loc12.as("df2")
      , $"df1.ServiceLocationId" === $"df2.ServiceLocationId.id" && $"df1.ServiceLocationName" === $"df2.ServiceLocationName" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_ServiceLocationUid1234.count > 0) {
      val ex = CachePatientNotesMedication.except(where_ServiceLocationUid1234)
      CachePatientNotesMedication = ex.union(updateServiceLocationUid1234)
    }

    logger.warn("Update ServiceLocationUid using loc In CachePatientNotesMedication Table 4 is Done............")

    //Insert Data Into Institution
    val insert_data_Institution12 = loc12.as("df1")
      .select($"df1.ServiceLocationUid", $"df1.ServiceLocationName", $"df1.PracticeUid").distinct()

    val allcols2 = Institution_Prod_Delta3.columns.toSet
    val insertcols2 = insert_data_Institution12.columns.toSet
    val tot4 = allcols2 ++ insertcols2

    val Institution_Prod_Delta4 =  Institution_Prod_Delta3.select(FunctionUtility.addColumns(allcols2, tot4): _*)
      .union(insert_data_Institution12.select(FunctionUtility.addColumns(insertcols2, tot4): _*))
    //column and union
    logger.warn("Insert Data Into Institution table is Done............")

    //Insert Data Into ServiceLocation
    val insert_data_ServiceLocation = loc12.as("df1")
      .select($"df1.ServiceLocationUid", $"df1.ServiceLocationId").distinct()

    val allcols3 = ServiceLocation_Prod_Delta3.columns.toSet
    val insert3 = insert_data_ServiceLocation.columns.toSet
    val tot5 = allcols3 ++ insert3

    val ServiceLocation_Prod_Delta4 = ServiceLocation_Prod_Delta3.select(FunctionUtility.addColumns(allcols3, tot5): _*)
      .union(insert_data_ServiceLocation.select(FunctionUtility.addColumns(insert3, tot5): _*))

    //column and union
    logger.warn("Insert Data Into ServiceLocation table is Done............")

    //Update PatientNoteMedicationuid of CachePatientNotesMedication using PatientNoteMedication table 4
    val update_PatientNoteMedicationuid12 = CachePatientNotesMedication.as("df1")
      .join(PatientNoteMedication_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientNoteMedicationuid".as("aliasPatientNoteMedicationuid"))
      .withColumn("PatientNoteMedicationuid", $"aliasPatientNoteMedicationuid")
      .drop("aliasPatientNoteMedicationuid")

    val where_PatientNoteMedicationuid12 = CachePatientNotesMedication.as("df1")
      .join(PatientNoteMedication_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientNoteMedicationuid12.count > 0) {
      val ex = CachePatientNotesMedication.except(where_PatientNoteMedicationuid12)
      CachePatientNotesMedication = ex.union(update_PatientNoteMedicationuid12)
    }
    logger.warn("Update PatientNoteMedicationuid of CachePatientNotesMedication using PatientNoteMedication table 4 is Done............")

    //Remove Duplicates of CachePatientNotesMedication

    var cleanedCachePatientNotesMedication = CachePatientNotesMedication.filter($"StatusId" === 1 && $"PracticePatientNoteKey".isNotNull)
      .dropDuplicates(Seq("PatientUid", "PracticePatientNoteKey"))

    var duplicatesRecordsCachePatientNotesMedication1 = CachePatientNotesMedication.except(cleanedCachePatientNotesMedication)

    logger.warn("Remove Duplicates of CachePatientNotesMedication is Done............")

    val PatientNoteMedication_Prod1 = cleanedCachePatientNotesMedication.filter($"StatusId" === 1 && $"PatientNoteMedicationuid".isNull && $"PracticePatientNoteKey".isNotNull)
      .select("PatientUid", "PracticePatientNoteKey").distinct()
      .withColumn("PatientNoteMedicationuid", FunctionUtility.getNewUid())

    //Update New PatientMedicationUId of CachePatientNotesMedication Table Using #PatientNoteMedication2 Table
    val update_PatientMedicationUId15 = cleanedCachePatientNotesMedication.as("df1").join(PatientNoteMedication_Prod1.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey")
      .filter($"df1.StatusId" === 1 )
      .select($"df1.*", $"df2.PatientNoteMedicationuid".as("aliasPatientNoteMedicationuid"))
      .withColumn("PatientNoteMedicationuid", $"aliasPatientNoteMedicationuid")
      .drop("aliasPatientNoteMedicationuid")

    val where_PatientMedicationUId15 = cleanedCachePatientNotesMedication.as("df1").join(PatientNoteMedication_Prod1.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientMedicationUId15.count > 0) {
      val ex = cleanedCachePatientNotesMedication.except(where_PatientMedicationUId15)
      cleanedCachePatientNotesMedication = ex.union(update_PatientMedicationUId15)
    }
    logger.warn("Update New PatientProblemUid of CachePatientNotesMedication Table Using #PatientNoteMedication2 Table is Done............")

    //Update #PatientNoteMedication2 Table
    val update_PatientNoteMedication2 = cleanedCachePatientNotesMedication.as("df2").join(PatientNoteMedication_Prod.as("df1")
      , $"df1.PatientNoteMedicationuid" === $"df2.PatientNoteMedicationuid")
      .filter($"df2.StatusId" === 1 )
      .select($"df1.*", $"df2.Note".as("aliasNote"), $"df2.Group1".as("aliasGroup1"), $"df2.Group2".as("aliasGroup2"), $"df2.Group3".as("aliasGroup3"), $"df2.Group4".as("aliasGroup4"),
        $"df2.PracticePatientNoteKey".as("aliasPracticePatientNoteKey"))
      .withColumn("Note", $"aliasNote")
      .withColumn("Group1", $"aliasGroup1")
      .withColumn("Group2", $"aliasGroup2")
      .withColumn("Group3", $"aliasGroup3")
      .withColumn("Group4", $"aliasGroup4")
      .withColumn("PracticePatientNoteKey", $"aliasPracticePatientNoteKey")
      .withColumn("ModifiedDate", lit(current_timestamp))
      .drop("aliasNote","aliasGroup1","aliasGroup2","aliasGroup3","aliasGroup4","aliasPracticePatientNoteKey")


    val where_PatientNoteMedication2 = cleanedCachePatientNotesMedication.as("df2").join(PatientNoteMedication_Prod.as("df1")
      , $"df1.PatientNoteMedicationuid" === $"df2.PatientNoteMedicationuid")
      .filter($"df2.StatusId" === 1 )
      .select($"df1.*")

      val ex_PM = cleanedCachePatientNotesMedication.except(where_PatientNoteMedication2)
      var PatientNoteMedication_Prod_Delta = ex_PM.union(update_PatientNoteMedication2)

    logger.warn("Update #PatientNoteMedication2 Table is Done............")

    //Insert Data Into PatientNoteMedication
    val insert_Data_PatientNoteMedication = cleanedCachePatientNotesMedication.as("df1").join(PatientNoteMedication_Prod_Delta.as("df2")
      ,$"df1.PatientNoteMedicationuid" === $"df2.PatientNoteMedicationuid","left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.PatientNoteMedicationuid".isNull)
      .select($"df1.PatientNoteMedicationuid",$"df1.PatientUid",$"df1.ClinicalInformationModelSectionUid"
        ,$"df1.ProblemResolutionDate",$"df1.EncounterProblemTypeCodeUid"
        ,$"df1.Note",$"df1.EncounterDate",$"df1.ServiceProviderUid" ,$"df1.ServiceLocationUid",$"df1.Group1"
        ,$"df1.Group2",$"df1.Group3",$"df1.Group4",$"df1.PracticePatientNoteKey")

    val allcols5 = PatientNoteMedication_Prod_Delta.columns.toSet
    val insert5 = insert_Data_PatientNoteMedication.columns.toSet
    val tot6 = allcols5 ++ insert5

    PatientNoteMedication_Prod_Delta = PatientNoteMedication_Prod_Delta.select(FunctionUtility.addColumns(allcols5, tot6): _*)
      .union(insert_Data_PatientNoteMedication.select(FunctionUtility.addColumns(insert5, tot6): _*))

    logger.warn("Insert Data Into PatientProblemHistory is Done......")

    //End CachePatientNotesMedication Sp..........................................


    List(PatientNoteMedication_Prod_Delta,Individual_prod_Delta8,ServiceProvider_prod_Delta7,Institution_Prod_Delta4
    ,ServiceLocation_Prod_Delta4)
  }
}
