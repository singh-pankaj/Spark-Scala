package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory

class CacheEncounter {

  def CacheEncounterFunc(spark : SparkSession,Patient_Prod_Delta : DataFrame,Individual_prod_Delta : DataFrame
                         ,Address_Prod_Delta : DataFrame,MappingPracticeCommonData_Delta : DataFrame
                         ,MergePracticeMap : DataFrame
                         ,ViewServiceProvider : DataFrame,CDRPatientCrosswalkTable : DataFrame
                         ,MultiTableExtendTable : DataFrame
                         ,Individual : DataFrame,ProviderNPIChangeTable : DataFrame
                         ,Institution_Prod : DataFrame
                         ,ViewFacility_Prod : DataFrame,distIndUid : DataFrame,distspUID : DataFrame
                         ,MasterCity_prod : DataFrame
                         ,MasterCityPostalCode_prod : DataFrame,MasterPostalCode_prod : DataFrame
                         ,MasterState_Prod : DataFrame,Visit_Prod : DataFrame
                         ,Master_prod : DataFrame,ServiceLocation_Prod : DataFrame
                        ,ServiceProvider_prod_Delta : DataFrame) : List[DataFrame] = {

    val logger = LoggerFactory.getLogger("")

    import spark.implicits._

    //Start Encounter

    //Its Required
    // val df2 =CacheEncounter.withColumn("_c3", to_timestamp($"_c3", "MM/dd/yyyy HH:mm:ss")).select("_c3")

    var CacheEncounter = spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/8ff9928e-7288-4491-8aa0-c7e0da5bbba8_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")

    val lookup4 = Map("_c0" -> "PatientId", "_c1" -> "EncounterTypeCode", "_c2" -> "EncounterTypeText", "_c3" -> "EncounterStartDate"
      , "_c4" -> "EncounterEndDate", "_c5" -> "ServiceProviderNPI", "_c6" -> "ServiceProviderLastName", "_c7" -> "ServiceProviderFirstName"
      , "_c8" -> "ServiceProviderRoleCode", "_c9" -> "ServiceProviderRoleText", "_c10" -> "ServiceLocationId"
      , "_c11" -> "ServiceLocationName", "_c12" -> "ServiceLocationRoleTypeCode", "_c13" -> "ServiceLocationRoleTypeText"
      , "_c14" -> "ReasonForVisit", "_c15" -> "Service_Location_AddressLine", "_c16" -> "Service_Location_City"
      , "_c17" -> "Service_Location_State", "_c18" -> "Service_Location_PostalCode", "_c19" -> "Encounter_Status"
      , "_c20" -> "EncounterTIN", "_c21" -> "EncounterKey", "_c22" -> "PracticeUid", "_c23" -> "BatchUid", "_c24" -> "dummy1", "_c25" -> "dummy2")

    CacheEncounter = CacheEncounter.select(CacheEncounter.columns.map(c => col(c).as(lookup4.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")


    val tempCacheEncounter = spark.read.option("header", "true")
      .csv("/home/gajanan.doifode/AAO_DATA/Schema/CacheEncounter.txt")

    val CacheEncounterallcols = tempCacheEncounter.columns.toSet
    val CacheencounterViewcols = CacheEncounter.columns.toSet
    val tot_viewEn_cacheEn = CacheEncounterallcols ++ CacheencounterViewcols

    CacheEncounter = tempCacheEncounter.select(FunctionUtility.addColumns(CacheEncounterallcols, tot_viewEn_cacheEn): _*)
      .union(CacheEncounter.select(FunctionUtility.addColumns(CacheencounterViewcols, tot_viewEn_cacheEn): _*))

    CacheEncounter = CacheEncounter.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))


    //Create TempMergePracticeMapEncounter
    val dist_Prac_Uid_Encounter = CacheEncounter.filter($"StatusId".isNull).select("PracticeUid").distinct()

    val tempMergePracticeMapEncounter = MergePracticeMap.as("df1").join(dist_Prac_Uid_Encounter.as("df2")
      , $"df1.NewPracticeUid" === $"df2.PracticeUid").select($"df1.*")

    //Practiceuid Update for multiple instance
    CacheEncounter = CacheEncounter.as("df1").join(tempMergePracticeMapEncounter.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeUid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeUid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Practiceuid Update for multiple instance is Done............")
    CacheEncounter = CacheEncounter.withColumn("StatusId", lit(1))

    //create Table tempViewServiceProvider
    val tempViewServiceProvider = ViewServiceProvider.as("df1").join(dist_Prac_Uid_Encounter.as("df2")
      , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.Inactive" === 0)
      .select("df1.*")

    //Update columns Of Encounter
    CacheEncounter = CacheEncounter.filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"PracticeUid")
      .withColumn("PatientId", rtrim(ltrim($"PatientId")))
      .withColumn("ServiceLocationId", rtrim(ltrim($"ServiceLocationId")))
      .withColumn("ServiceProviderNPI", rtrim(ltrim($"ServiceProviderNPI")))
      .withColumn("EncounterTypeCode", rtrim(ltrim($"EncounterTypeCode")))
      .withColumn("PracticeSideNPI", rtrim(ltrim($"PracticeSideNPI")))
      .withColumn("VisitDate", $"EncounterStartDate")

    logger.warn("Update columns Of Encounter is Done............")

    //Update Status Of Multiple Columns In Encounter Table
    val a = CacheEncounter.filter($"ServiceLocationId".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Service Location Id not found"))

    val b = CacheEncounter.filter($"EncounterStartDate".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Encouter Date  not found"))

    val c = CacheEncounter.filter($"EncounterStartDate" > date_add(current_date(), 5) && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Future Visit found"))

    val d = CacheEncounter.filter($"PatientId".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val updateAllEncounter = a.union(b).union(c).union(d)

    val whereclauseEncounter = CacheEncounter.filter($"StatusId" === 1 && ($"ServiceLocationId".isNull ||
      $"EncounterStartDate".isNull || $"EncounterStartDate" > date_add(current_date(), 5) || $"PatientId".isNull))

    if (whereclauseEncounter.count > 0) {
      val ex = CacheEncounter.except(whereclauseEncounter)
      CacheEncounter = ex.union(updateAllEncounter)
    }

    logger.warn("Update Status Of Multiple Columns In Encounter Table is Done............")

    //Update PatientId from PatientId Crosswalk of Encounter
    val updatePatientIdEncounter = CacheEncounter.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val wherePatientIdEncounter = CacheEncounter.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")


    if (wherePatientIdEncounter.count > 0) {
      val ex = CacheEncounter.except(wherePatientIdEncounter)
      CacheEncounter = ex.union(updatePatientIdEncounter)
    }

    logger.warn("Update PatientId from Old_PatientId Crosswalk of Encounter is Done............")

    //Update ServiceProviderNPI of CacheEncounter
    val updatespNPIEncounter = CacheEncounter.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.GroupName" === "ProviderNPI" && $"df1.ServiceProviderNPI" === $"df2.Element1")
      .filter($"StatusId" === 1)
      .select($"df1.*", $"df2.Value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue").drop($"AliasValue")

    val wherclauseNPIEncounter = CacheEncounter.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.GroupName" === "ProviderNPI" && $"df1.ServiceProviderNPI" === $"df2.Element1", "inner")
      .filter($"StatusId" === 1)
      .select($"df1.*")

    if (wherclauseNPIEncounter.count > 0) {
      val ex = CacheEncounter.except(wherclauseNPIEncounter)
      CacheEncounter = ex.union(updatespNPIEncounter)
    }

    logger.warn("Update ServiceProviderNPI of CacheEncounter is Done............")

    //Update ServiceProviderNPI of CacheEncounter using Multiple Conditions
    val updatespNPIEncounter2 = CacheEncounter.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.GroupName" === "ProviderNPI" && $"df1.ServiceProviderFirstName" === $"df2.Element1" &&
        $"df1.ServiceProviderLastName" === $"df2.Element2")
      .filter($"StatusId" === 1 && $"df1.ServiceProviderNPI".isNull && $"df2.Element2".isNotNull)
      .select($"df1.*", $"df2.Value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue").drop($"AliasValue")

    val whereNPIEncounter2 = CacheEncounter.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.GroupName" === "ProviderNPI" && $"df1.ServiceProviderFirstName" === $"df2.Element1" &&
        $"df1.ServiceProviderLastName" === $"df2.Element2")
      .filter($"StatusId" === 1 && $"df1.ServiceProviderNPI".isNull && $"df2.Element2".isNotNull)
      .select($"df1.*")

    if (whereNPIEncounter2.count > 0) {
      val ex = CacheEncounter.except(whereNPIEncounter2)
      CacheEncounter = ex.union(updatespNPIEncounter2)
    }

    logger.warn("Update ServiceProviderNPI of CacheEncounter using Multiple Conditions is Done............")

    //Update ServiceProviderNPI of CacheEncounter using Multiple Conditions on Multiple Table
    val updatespNPIEncounter3 = Individual.as("df1")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid")
      .join(CacheEncounter.as("df3"), $"df3.PracticeUid" === $"df1.PracticeUid" &&
        $"df3.ServiceProviderNPI" === $"df2.OldNPI")
      .filter($"StatusId" === 1)
      .select($"df3.*", $"df2.NewNPI".as("AliasNewNPI"))
      .withColumn("ServiceProviderNPI", $"AliasNewNPI").drop($"AliasNewNPI")

    val whereNPIEncounter3 = Individual.as("df1")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid")
      .join(CacheEncounter.as("df3"), $"df3.PracticeUid" === $"df1.PracticeUid" &&
        $"df3.ServiceProviderNPI" === $"df2.OldNPI")
      .filter($"StatusId" === 1)
      .select($"df3.*")

    if (whereNPIEncounter3.count > 0) {
      val ex = CacheEncounter.except(whereNPIEncounter3)
      CacheEncounter = ex.union(updatespNPIEncounter3)
    }

    logger.warn("Update ServiceProviderNPI of CacheEncounter using Multiple Conditions on Multiple Table is Done............")

    //Update status if NPI is Null And Invalid

    val e = CacheEncounter.filter($"ServiceProviderNPI".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Service Provider NPI not found"))

    val f = CacheEncounter.filter(length($"ServiceProviderNPI") =!= 10 && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid NPI Found,Length should be 10"))

    val updateNPIEncounter4 = e.union(f)

    val whereNPIEncounter4 = CacheEncounter.filter($"StatusId" === 1 && ($"ServiceProviderNPI".isNull || length($"ServiceProviderNPI") =!= 10))

    if (whereNPIEncounter4.count > 0) {
      val ex = CacheEncounter.except(whereNPIEncounter4)
      CacheEncounter = ex.union(updateNPIEncounter4)
    }
    logger.warn("Update status if NPI is Null And Invalid is Done............")


    //Drop Duplicate records and store in in-memory not update status = 4 for Encounter
    var cleanedCacheEncounter = CacheEncounter.dropDuplicates(Seq("PatientId", "PracticeUid"
      , "VisitDate", "ServiceProviderNPI", "ServiceLocationId"))

    val duplicateRecordsEncounter = CacheEncounter.except(cleanedCacheEncounter)

    logger.warn("Drop Duplicate records and store in in-memory not update status = 4 for Encounter is Done............")

    //Update PatientUid Of Encounter Table Using Master Table
    val updatePatientUidEncounter = cleanedCacheEncounter.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val wherePatientUidEncounter = cleanedCacheEncounter.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (wherePatientUidEncounter.count > 0) {
      val ex = cleanedCacheEncounter.except(wherePatientUidEncounter)
      cleanedCacheEncounter = ex.union(updatePatientUidEncounter)
    }

    logger.warn("Update PatientUid Of Encounter Table Using Master Table is Done............")

    //Update staus If PatientUid Is null
    val updateStatus5 = cleanedCacheEncounter.filter($"PatientUid".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val wherestatus5 = cleanedCacheEncounter.filter($"PatientUid".isNull && $"StatusId" === 1)

    if (wherestatus5.count > 0) {
      val ex = cleanedCacheEncounter.except(wherestatus5)
      cleanedCacheEncounter = ex.union(updateStatus5)
    }

    logger.warn("Update status If PatientUid Is null is Done............")

    // Update ServiceProviderUid of Encounter
    val updateServiceProviderUidEncounter = cleanedCacheEncounter.as("df1").join(tempViewServiceProvider.as("df2")
      , $"df1.ServiceProviderNPI" === $"df2.NPI" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1 && $"df2.Type".isin(1, 3) && $"df2.Inactive" === 0)
      .select($"df1.*", $"df2.ServiceProviderUid".as("aliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"aliasServiceProviderUid")
      .drop("aliasServiceProviderUid")

    val whereServiceProviderUidEncounter = cleanedCacheEncounter.as("df1").join(tempViewServiceProvider.as("df2")
      , $"df1.ServiceProviderNPI" === $"df2.NPI" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1 && $"df2.Type".isin(1, 3) && $"df2.Inactive" === 0)
      .select($"df1.*")

    if (whereServiceProviderUidEncounter.count > 0) {
      val ex = cleanedCacheEncounter.except(whereServiceProviderUidEncounter)
      cleanedCacheEncounter = ex.union(updateServiceProviderUidEncounter)
    }

    logger.warn("Update ServiceProviderUid of Encounter is Done............")



    //Update ServiceLocationUid of Encounter
    val updateServiceLocationUidEncounter = cleanedCacheEncounter.as("df1").join(ViewFacility_Prod.as("df2")
      , $"df1.ServiceLocationId" === $"df2.ID" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceLocationUid".as("aliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"aliasServiceLocationUid")
      .drop("aliasServiceLocationUid")

    val whereServiceLocationUidEncounter = cleanedCacheEncounter.as("df1").join(ViewFacility_Prod.as("df2")
      , $"df1.ServiceLocationId" === $"df2.ID" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (whereServiceLocationUidEncounter.count > 0) {
      val ex = cleanedCacheEncounter.except(whereServiceLocationUidEncounter)
      cleanedCacheEncounter = ex.union(updateServiceLocationUidEncounter)
    }

    logger.warn("Update ServiceLocationUid of Encounter is Done............")

    //Update status If ServiceProvider Is null
    val updateServiceProviderEncounter = cleanedCacheEncounter.filter($"ServiceProviderUid".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ServiceProvider Not Found On Management"))

    val wheresServiceProviderEncounter = cleanedCacheEncounter.filter($"ServiceProviderUid".isNull && $"StatusId" === 1)

    if (wheresServiceProviderEncounter.count > 0) {
      val ex = cleanedCacheEncounter.except(wheresServiceProviderEncounter)
      cleanedCacheEncounter = ex.union(updateServiceProviderEncounter)
    }

    logger.warn("Update status If ServiceProvider Is null is Done............")

    //Create #PHY table Using cleanedCaheEncounter Table
    var tempPhy = cleanedCacheEncounter.as("df1")
      .select("ServiceProviderUid", "ServiceProviderNPI", "ServiceProviderFirstName", "ServiceProviderLastName"
        , "PracticeUid", "StatusId")
      .where($"ServiceProviderNPI".isNotNull && $"ServiceProviderUid".isNotNull && $"StatusId" === 1)
      .groupBy($"ServiceProviderNPI", $"PracticeUid", $"ServiceProviderUid")
      .agg(max("ServiceProviderFirstName").as("ServiceProviderFirstName")
        , max("ServiceProviderLastName").as("ServiceProviderLastName"))
      .withColumn("Physician_MidName", lit("null"))

    //Insert data Into Individual Table Of CacheEncounter
    val insert_Individual_Prod2 = tempPhy.as("df1")
      .join(distIndUid.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.IndividualUid"))
      .select($"df1.ServiceProviderUid".as("IndividualUid"), $"df1.ServiceProviderFirstName".as("First")
        , $"df1.Physician_MidName".as("Middle"), $"ServiceProviderLastName".as("Last"),
        $"df1.PracticeUid".as("PracticeUid")).distinct()

    val allcols_Individual = Individual_prod_Delta.columns.toSet
    val insert_individualcols = insert_Individual_Prod2.columns.toSet
    val tot_Individual = allcols_Individual ++ insert_individualcols

    var Individual_prod_Delta1 = Individual_prod_Delta.select(FunctionUtility.addColumns(allcols_Individual, tot_Individual): _*)
      .union(insert_Individual_Prod2.select(FunctionUtility.addColumns(insert_individualcols, tot_Individual): _*))

    logger.warn("Insert data Into Individual Table Of CacheEncounter is Done............")

    //Insert data Into ServiceProvider Table Of CacheEncounter
    val insertdataServiceProv2 = tempPhy.as("df1").join(distspUID.as("df2")
      , !$"df1.ServiceProviderUid".isin($"df2.ServiceProviderUid"))
      .select($"df1.ServiceProviderUid", when($"df1.Physician_MidName".isNotNull, concat_ws(" "
        , $"ServiceProviderLastName", $"ServiceProviderFirstName", $"Physician_MidName"))
        .otherwise(concat_ws(" ", $"ServiceProviderLastName", $"ServiceProviderFirstName")).as("ListName")
        , $"df1.ServiceProviderNPI".as("NPI"))
      .withColumn("ExternalID", lit(null))
      .withColumn("Type", lit(1))

    val allcols_ServiceProvider = ServiceProvider_prod_Delta.columns.toSet
    val insert_serviceProvider  = insertdataServiceProv2.columns.toSet
    val tot_ServiceProvider = allcols_ServiceProvider ++ insert_serviceProvider

    val ServiceProvider_Prod_Delta1 = ServiceProvider_prod_Delta.select(FunctionUtility.addColumns(allcols_ServiceProvider, tot_ServiceProvider): _*)
      .union(insertdataServiceProv2.select(FunctionUtility.addColumns(insert_serviceProvider, tot_ServiceProvider): _*))
    logger.warn("Insert data Into ServiceProvider Table Of CacheEncounter is Done............")

    // Create tempLoc table
    var tempLoc = cleanedCacheEncounter.select($"ServiceLocationUid", $"ServiceLocationId", $"ServiceLocationName"
      , $"Service_Location_AddressLine", $"Service_Location_City", $"Service_Location_State", $"Service_Location_PostalCode"
      , $"PracticeUid").where($"StatusId" === 1 && ltrim(rtrim($"ServiceLocationId")).isNotNull).distinct()


    val temploc2 = tempLoc.select($"ServiceLocationId", $"PracticeUid")
      .groupBy($"ServiceLocationId", $"PracticeUid").count().filter("count > 1")

    //Update Status when Duplicate Location For Different Address of Encounter Table
    val updatestatusEncounter = cleanedCacheEncounter.as("df1").join(temploc2.as("df2")
      , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ServiceLocationId" === $"df2.ServiceLocationId"
        && $"df1.StatusId" === 1).select($"df1.*")
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Duplicate Location For Different Address"))

    val wherestatusEncounter = cleanedCacheEncounter.as("df1").join(temploc2.as("df2")
      , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ServiceLocationId" === $"df2.ServiceLocationId"
        && $"df1.StatusId" === 1).select($"df1.*")

    if (wherestatusEncounter.count > 0) {
      val ex = cleanedCacheEncounter.except(wherestatusEncounter)
      cleanedCacheEncounter = ex.union(updatestatusEncounter)
    }

    logger.warn("Update Status when Duplicate Location For Different Address of Encounter Table is Done............")

    // update #Loc set ServiceLocationName=ServiceLocationId
    val updateLoc = tempLoc.filter(ltrim(rtrim($"ServiceLocationName")).isNull)
      .withColumn("ServiceLocationName", $"ServiceLocationId")

    val whereLoc = tempLoc.filter(ltrim(rtrim($"ServiceLocationName")).isNull)

    if (whereLoc.count > 0) {
      val ex = tempLoc.except(whereLoc)
      tempLoc = ex.union(updateLoc)
    }

    logger.warn("update #Loc set ServiceLocationName=ServiceLocationId is Done............")

    //generate UUD for TempLoc table of Encounter
    tempLoc = tempLoc.withColumn("CityUid", FunctionUtility.getNewUid())
      .withColumn("StateUid", FunctionUtility.getNewUid())
      .withColumn("PostalCodeUid", FunctionUtility.getNewUid())
      .withColumn("AddressUid", FunctionUtility.getNewUid())

    /*update #Loc set ServiceLocationUid=newid() where ServiceLocationUid is null*/
    val updateLoc2 = tempLoc.filter(ltrim(rtrim($"ServiceLocationUid")).isNull)
      .withColumn("ServiceLocationUid", FunctionUtility.getNewUid())

    val whereLoc2 = tempLoc.filter(ltrim(rtrim($"ServiceLocationUid")).isNull)

    if (whereLoc2.count > 0) {
      val ex = tempLoc.except(whereLoc2)
      tempLoc = ex.union(updateLoc2)
    }

    logger.warn("update #Loc set ServiceLocationUid=newid() where ServiceLocationUid is null is Done............")


    //update AddressUid of Loc Table
    val updateAddressUidLoc = tempLoc.as("df1").join(ViewFacility_Prod.as("df2")
      , $"df1.ServiceLocationUid" === $"df2.ServiceLocationUid" && $"df2.Address1Uid".isNotNull)
      .select($"df1.*", $"df2.Address1Uid".as("aliasAddress1Uid"))
      .withColumn("AddressUid", $"aliasAddress1Uid")
      .drop("aliasAddress1Uid")

    val whereAddressUidLoc = tempLoc.as("df1").join(ViewFacility_Prod.as("df2")
      , $"df1.ServiceLocationUid" === $"df2.ServiceLocationUid" && $"df2.Address1Uid".isNotNull)
      .select($"df1.*")

    if (whereAddressUidLoc.count > 0) {
      val ex = tempLoc.except(whereAddressUidLoc)
      tempLoc = ex.union(updateAddressUidLoc)
    }

    logger.warn("update AddressUid of Loc Table  is Done............")


    //Update CityUid Of Loc Table
    val updateCityUidLoc = tempLoc.as("df1").join(MasterCity_prod.as("df2"),
      $"df1.Service_Location_City" === $"df2.Name", "left_outer").join(MasterPostalCode_prod.as("df3"),
      ltrim(rtrim($"df1.Service_Location_PostalCode")).substr(0, 5) === $"df3.Code", "left_outer")
      .join(MasterCityPostalCode_prod.as("df4"), $"df3.PostalCodeUid" === $"df4.PostalCodeUid")
      .select($"df1.*", $"df2.CityUid".as("aliasCityUid1"), $"df4.CityUid".as("aliasCityUid2"))
      .withColumn("CityUid", when($"aliasCityUid1".isNull, $"aliasCityUid2").otherwise($"aliasCityUid1"))
      .drop("aliasCityUid1", "aliasCityUid2")

    val whereCityUidLoc = tempLoc.as("df1").join(MasterCity_prod.as("df2"),
      $"df1.Service_Location_City" === $"df2.Name", "left_outer").join(MasterPostalCode_prod.as("df3"),
      ltrim(rtrim($"df1.Service_Location_PostalCode")).substr(0, 5) === $"df3.Code", "left_outer")
      .join(MasterCityPostalCode_prod.as("df4"), $"df3.PostalCodeUid" === $"df4.PostalCodeUid")
      .select($"df1.*")

    if (whereCityUidLoc.count > 0) {
      val ex = tempLoc.except(whereCityUidLoc)
      tempLoc = ex.union(updateCityUidLoc)
    }

    logger.warn("Update CityUid Of Loc Table is Done............")

    //Update PostalCodeUid Of tempLoc Table
    val updatePostalCodeLoc = tempLoc.as("df1").join(MasterPostalCode_prod.as("df2"),
      ltrim(rtrim($"df1.Service_Location_PostalCode")).substr(0, 5) === $"df2.Code")
      .select($"df1.*", $"df2.PostalCodeUid".as("aliasPostalCodeUid"))
      .withColumn("PostalCodeUid", $"aliasPostalCodeUid").drop("aliasPostalCodeUid")

    val wherePostalCodeLoc = tempLoc.as("df1").join(MasterPostalCode_prod.as("df2"),
      ltrim(rtrim($"df1.Service_Location_PostalCode")).substr(0, 5) === $"df2.Code")
      .select($"df1.*")

    if (wherePostalCodeLoc.count > 0) {
      val ex = tempLoc.except(wherePostalCodeLoc)
      tempLoc = ex.union(updatePostalCodeLoc)
    }

    logger.warn("Update PostalCodeUid Of tempLoc Table is Done............")

    //Update StateUid of tempLoc Table
    val updateStateUidLoc = tempLoc.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.Service_Location_State" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "154025B1-8903-4F3D-832C-7C2CF429C52C")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("StateUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val whereStateUidLoc = tempLoc.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.Service_Location_State" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "154025B1-8903-4F3D-832C-7C2CF429C52C")
      .select($"df1.*")

    if (whereStateUidLoc.count > 0) {
      val ex = tempLoc.except(whereStateUidLoc)
      tempLoc = ex.union(updateStateUidLoc)
    }

    logger.warn("Update StateUid of tempLoc Table is Done............")

    //Update StateUid of tempLoc using MasterTable
    val updateStateUidLoc2 = tempLoc.as("df1").join(MasterState_Prod.as("df2"),
      $"df1.Service_Location_State" === $"df2.Name" && $"df1.Service_Location_State" === $"df2.code")
      .filter($"df1.StateUid".isNull)
      .select($"df1.*", $"df2.StateUid".as("aliasStateUid"))
      .withColumn("StateUid", $"aliasStateUid")
      .drop("aliasStateUid")

    val whereStateUidLoc2 = tempLoc.as("df1").join(MasterState_Prod.as("df2"),
      $"df1.Service_Location_State" === $"df2.Name" && $"df1.Service_Location_State" === $"df2.code")
      .filter($"df1.StateUid".isNull)
      .select($"df1.*")


    if (whereStateUidLoc2.count > 0) {
      val ex = tempLoc.except(whereStateUidLoc2)
      tempLoc = ex.union(updateStateUidLoc2)
    }

    logger.warn("Update StateUid of tempLoc using MasterTable is Done............")

    //Update Address table Using tempLoc table
    val updateAddressEncounter = tempLoc.as("df2").join(Address_Prod_Delta.as("df1")
      , $"df1.AddressUid" === $"df2.AddressUid", "left_outer")
      .select($"df1.*", $"df2.Service_Location_AddressLine".as("aliasAddLine")
        , $"df2.CityUid".as("aliasCityUid"), $"df2.StateUid".as("aliasStateUid")
        , $"df2.PostalCodeUid".as('aliasPostalCodeUid))
      .withColumn("Line1", when($"Line1".isNull, substring($"aliasAddLine", 1, 255)).otherwise($"Line1"))
      .withColumn("CityUid", $"aliasCityUid")
      .withColumn("StateUid", $"aliasStateUid")
      .withColumn("PostalCodeUid", $"aliasPostalCodeUid")
      .withColumn("ModifiedDate", current_timestamp())
      .drop("aliasAddLine", "aliasCityUid", "aliasStateUid", "aliasPostalCodeUid")

    val where_address = tempLoc.as("df2").join(Address_Prod_Delta.as("df1")
      , $"df1.AddressUid" === $"df2.AddressUid", "left_outer")
      .select($"df1.*")

    val ex_address = Address_Prod_Delta.except(where_address)
    var Address_Prod_Delta1 = ex_address.union(updateAddressEncounter)

    logger.warn("Update Address table Using tempLoc table is Done............")

    //Insert Data Into Address table Using tempLoc table Of Encounter
    val Insert_Address_Encounter = tempLoc.as("df1").join(Address_Prod_Delta.as("df2")
      , $"df1.AddressUid" === $"df2.AddressUid")
      .filter($"df2.AddressUid".isNull && ($"df1.Service_Location_AddressLine".isNotNull || $"df1.Service_Location_City".isNotNull
        || $"df1.Service_Location_State".isNotNull || $"df1.Service_Location_PostalCode".isNotNull))
      .select($"df1.AddressUid", $"df1.CityUid", $"df1.StateUid",
        substring($"df1.Service_Location_AddressLine", 1, 255).as("Line1"), $"df1.PostalCodeUid").distinct()

    val allcols_Address = Address_Prod_Delta.columns.toSet
    val insert_Addresscols = Insert_Address_Encounter.columns.toSet
    val tot_address = allcols_Address ++ insert_Addresscols

     Address_Prod_Delta1 = Address_Prod_Delta.select(FunctionUtility.addColumns(allcols_Address, tot_address): _*)
      .union(Insert_Address_Encounter.select(FunctionUtility.addColumns(insert_Addresscols, tot_address): _*))

    logger.warn("Insert Data Into Address table Using tempLoc table Of Encounter is Done............")

    //Update Data Of Institution_Prod table Using tempLoc

    val updateAddress1Uid_Insti = Institution_Prod.as("df1").join(tempLoc.as("df2")
      , $"df1.InstitutionUid" === $"df2.ServiceLocationUid")
      .select($"df1.*", $"df2.Service_Location_AddressLine".as("aliasSLA")
        , $"df2.Service_Location_City".as("aliasSLC"), $"df2.Service_Location_State".as("aliasSLS")
        , $"df2.Service_Location_PostalCode".as("aliasSLP"), $"df2.ServiceLocationName".as("aliasSLN")
        , $"df2.AddressUid".as("aliasAUID"))
      .withColumn("Address1Uid", when($"aliasSLA".isNotNull || $"aliasSLC".isNotNull || $"aliasSLS".isNotNull
        || $"aliasSLP", $"aliasAUID").otherwise($"df1.Address1Uid"))
      .withColumn("Name", $"aliasSLN")
      .withColumn("ModifiedDate", current_timestamp())
      .drop("aliasSLA", "aliasSLC", "aliasSLS", "aliasSLP", "aliasAUID", "aliasSLN")

    val where_Institution = Institution_Prod.as("df1").join(tempLoc.as("df2")
      , $"df1.InstitutionUid" === $"df2.ServiceLocationUid").select($"df1.*")

    val ex_Institution = Institution_Prod.except(where_Institution)
    var Institution_Prod1 = ex_Institution.union(updateAddress1Uid_Insti)

    logger.warn("Update Data Of Institution_Prod table Using tempLoc is Done............")

    //Insert into Institution

    val Insert_Institution_Prod = tempLoc.as("df1").join(Institution_Prod1.as("df2")
      , $"df1.ServiceLocationUid" === $"df2.InstitutionUid", "left_outer")
      .filter($"df2.InstitutionUid".isNull)
      .select($"df1.ServiceLocationUid".as("InstitutionUid"), $"df1.ServiceLocationName".as("Name")
        , $"df1.PracticeUid", when($"df1.Service_Location_AddressLine".isNotNull || $"df1.Service_Location_City".isNotNull
          || $"df1.Service_Location_State".isNotNull || $"df1.Service_Location_PostalCode".isNotNull, $"df1.AddressUid")
          .otherwise($"df2.Address1Uid").as("Address1Uid"))
      .withColumn("Type", lit(5))


    val Institition_allcols = Institution_Prod1.columns.toSet
    val insert_Institition_cols = Insert_Institution_Prod.columns.toSet
    val tot_cols = Institition_allcols ++ insert_Institition_cols

    Institution_Prod1  = Institution_Prod1.select(FunctionUtility.addColumns(Institition_allcols, tot_cols): _*)
      .union(Insert_Institution_Prod.select(FunctionUtility.addColumns(insert_Institition_cols, tot_cols): _*))

    logger.warn("Insert into Institution Using tempLoc is Done............")

    //Insert Data Into ServiceLocation Using tempLoc table
    val Insert_ServiceLocation_Prod = tempLoc.as("df1").join(ServiceLocation_Prod.as("df2")
      , $"df1.ServiceLocationUid" === $"df2.ServiceLocationUid")
      .filter($"df2.ServiceLocationUid".isNull)
      .select($"df1.ServiceLocationUid", $"df1.ServiceLocationId".as("ExternalID"))

    val ServiceLoc_allcols = ServiceLocation_Prod.columns.toSet
    val Insert_ServiceLoc_cols = Insert_ServiceLocation_Prod.columns.toSet
    val tot_cols_Service = ServiceLoc_allcols ++ Insert_ServiceLoc_cols

    val ServiceLocation_Prod1 = ServiceLocation_Prod.select(FunctionUtility.addColumns(ServiceLoc_allcols, tot_cols_Service): _*)
      .union(Insert_ServiceLocation_Prod.select(FunctionUtility.addColumns(Insert_ServiceLoc_cols, tot_cols_Service): _*))

    logger.warn("Insert Data Into ServiceLocation Using tempLoc table is Done............")

    //Update ServiceLocationUid of CleanedCacheEncounter Using tempLoc
    val update_ServiceLUID = cleanedCacheEncounter.as("df1").join(tempLoc.as("df2")
      , $"df1.ServiceLocationId" === $"df2.ServiceLocationId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceLocationUid".as("aliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"aliasServiceLocationUid")
      .drop("aliasServiceLocationUid")

    val where_ServiceLUID = cleanedCacheEncounter.as("df1").join(tempLoc.as("df2")
      , $"df1.ServiceLocationId" === $"df2.ServiceLocationId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")


    if (where_ServiceLUID.count > 0) {
      val ex = cleanedCacheEncounter.except(where_ServiceLUID)
      cleanedCacheEncounter = ex.union(update_ServiceLUID)
    }
    logger.warn("Update ServiceLocationUid of CleanedCacheEncounter Using tempLoc is Done............")


    //Update VisitUid Of CleanedCacheEncounter
    val update_VisitUid = cleanedCacheEncounter.as("df1").join(Visit_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ServiceProviderUid" === $"df2.RenderringProviderUid"
        && $"df1.ServiceLocationUid" === $"df2.ServiceLocationUid" && $"df1.VisitDate" === $"df2.VisitDate")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.VisitUid".as("aliasVisitUid"))
      .withColumn("VisitUid", $"aliasVisitUid")
      .drop("aliasVisitUid")

    val where_VisitUid = cleanedCacheEncounter.as("df1").join(Visit_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ServiceProviderUid" === $"df2.RenderringProviderUid"
        && $"df1.ServiceLocationUid" === $"df2.ServiceLocationUid" && $"df1.VisitDate" === $"df2.VisitDate")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_VisitUid.count > 0) {
      val ex = cleanedCacheEncounter.except(where_VisitUid)
      cleanedCacheEncounter = ex.union(update_VisitUid)
    }
    logger.warn("Update VisitUid Of CleanedCacheEncounter is Done............")

    //Update MasterVisitTypeUid using MappingPracticeCommonData of Encounter
    val updateMasterVTUid = cleanedCacheEncounter.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.EncounterTypeCode" === $"df2.PracticeValue" || $"df1.EncounterTypeText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "E7358399-4DA2-472B-B2E8-1C018EE94F0A")
      .where($"df1.StatusId" === 1 && $"df1.MasterVisitTypeUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("MasterVisitTypeUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val whereMasterVTUid = cleanedCacheEncounter.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.EncounterTypeCode" === $"df2.PracticeValue" || $"df1.EncounterTypeText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "E7358399-4DA2-472B-B2E8-1C018EE94F0A")
      .where($"df1.StatusId" === 1 && $"df1.MasterVisitTypeUid".isNull)
      .select($"df1.*")

    if (whereMasterVTUid.count > 0) {
      val ex = cleanedCacheEncounter.except(whereMasterVTUid)
      cleanedCacheEncounter = ex.union(updateMasterVTUid)
    }
    logger.warn("Update MasterVisitTypeUid using MappingPracticeCommonData of Encounter is Done............")

    //Update MasterVisitTypeUid using Master of Encounter
    val updateMasterVTUid2 = cleanedCacheEncounter.as("df1").join(Master_prod.as("df2"),
      $"df1.EncounterTypeCode" === $"df2.Code" && $"df2.Type" === "VisitType")
      .filter($"df1.StatusId" === 1 && $"df1.MasterVisitTypeUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("MasterVisitTypeUid", $"aliasMasterUid").drop("aliasMasterUid")

    val whereMasterVTUid2 = cleanedCacheEncounter.as("df1").join(Master_prod.as("df2"),
      $"df1.EncounterTypeCode" === $"df2.Code" && $"df2.Type" === "VisitType")
      .filter($"df1.StatusId" === 1 && $"df1.MasterVisitTypeUid".isNull)
      .select($"df1.*")


    if (whereMasterVTUid2.count > 0) {
      val ex = cleanedCacheEncounter.except(whereMasterVTUid2)
      cleanedCacheEncounter = ex.union(updateMasterVTUid2)
    }
    logger.warn("Update MasterVisitTypeUid using Master of Encounter is Done............")

    //Update Visit_Prod Table (MasterVisitTypeUid is Not Null)
    val update_Visit_Prod = Visit_Prod.as("df1").join(cleanedCacheEncounter.as("df2")
      , $"df1.VisitUid" === $"df2.VisitUid").where($"df2.StatusId" === 1 && $"df2.MasterVisitTypeUid".isNotNull)
      .select($"df1.*", $"df2.ReasonForVisit".as("aliasRFVisit"), $"df2.MasterVisitTypeUid".as("aliasMVTUid")
        , $"df2.Encounter_Status".as("aliasEncounter_Status"), $"df2.EncounterTypeCode".as("aliasETCode")
        , $"df2.EncounterTIN".as("aliasETIN"))
      .withColumn("Note", $"aliasRFVisit")
      .withColumn("ModifiedDate", current_timestamp())
      .withColumn("MasterVisitTypeUid", $"aliasMVTUid")
      .withColumn("Encounter_Status", $"aliasEncounter_Status")
      .withColumn("EncounterTypeCode", $"aliasETCode")
      .withColumn("EncounterTIN", $"aliasETIN")
      .drop("aliasRFVisit", "aliasMVTUid", "aliasEncounter_Status", "aliasETCode", "aliasETIN")

    val where_Visit = Visit_Prod.as("df1").join(cleanedCacheEncounter.as("df2")
      , $"df1.VisitUid" === $"df2.VisitUid").where($"df2.StatusId" === 1 && $"df2.MasterVisitTypeUid".isNotNull)
      .select($"df1.*")

    val ex_Visit = Visit_Prod.except(where_Visit)

    var Visit_Prod1 = ex_Visit.union(update_Visit_Prod)

    logger.warn("Update Visit_Prod Table Encounter(MasterVisitTypeUid is Not Null) is Done............")

    //Update Visit_Prod Table (MasterVisitTypeUid is Null)
    val update_Visit_Prod2 = Visit_Prod1.as("df1").join(cleanedCacheEncounter.as("df2")
      , $"df1.VisitUid" === $"df2.VisitUid").where($"df2.StatusId" === 1 && $"df2.MasterVisitTypeUid".isNull)
      .select($"df1.*", $"df2.ReasonForVisit".as("aliasRFVisit"), $"df2.Encounter_Status".as("aliasEncounter_Status")
        , $"df2.EncounterTypeCode".as("aliasETCode")
        , $"df2.EncounterTIN".as("aliasETIN"))
      .withColumn("Note", $"aliasRFVisit")
      .withColumn("ModifiedDate", current_timestamp())
      .withColumn("Encounter_Status", $"aliasEncounter_Status")
      .withColumn("EncounterTypeCode", $"aliasETCode")
      .withColumn("EncounterTIN", $"aliasETIN")
      .drop("aliasRFVisit", "aliasEncounter_Status", "aliasETCode", "aliasETIN")

    val where_visit2 = Visit_Prod1.as("df1").join(cleanedCacheEncounter.as("df2")
      , $"df1.VisitUid" === $"df2.VisitUid").where($"df2.StatusId" === 1 && $"df2.MasterVisitTypeUid".isNull)
      .select($"df1.*")

    val ex_Visit2 = Visit_Prod1.except(where_visit2)
    Visit_Prod1 = ex_Visit2.union(update_Visit_Prod2)

    logger.warn("Update Visit_Prod Table Encounter(MasterVisitTypeUid is Null) is Done............")

    //Create NewEnc Table
    val tempNewEnc = cleanedCacheEncounter.filter($"StatusId" === 1 && $"VisitUid".isNull)
      .select("PatientUid", "ServiceProviderUid", "ServiceLocationUid", "VisitDate").distinct()
      .withColumn("VisitUid", FunctionUtility.getNewUid())

    //Update VisitUid Using tempNewEnc table Of Encounter
    val update_VisitUid2 = cleanedCacheEncounter.as("df1").join(tempNewEnc.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ServiceProviderUid" === $"df2.ServiceProviderUid"
        && $"df1.ServiceLocationUid" === $"df2.ServiceLocationUid" && $"df1.VisitDate" === $"df2.VisitDate")
      .filter($"df1.StatusId" === 1 && $"df1.VisitUid".isNull)
      .select($"df1.*", $"df2.VisitUid".as("aliasVisitUid"))
      .withColumn("VisitUid", $"aliasVisitUid")
      .drop("aliasVisitUid")

    val where_VisitUid2 = cleanedCacheEncounter.as("df1").join(tempNewEnc.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ServiceProviderUid" === $"df2.ServiceProviderUid"
        && $"df1.ServiceLocationUid" === $"df2.ServiceLocationUid" && $"df1.VisitDate" === $"df2.VisitDate")
      .filter($"df1.StatusId" === 1 && $"df1.VisitUid".isNull)
      .select($"df1.*")

    if (where_VisitUid2.count > 0) {
      val ex = cleanedCacheEncounter.except(where_VisitUid2)
      cleanedCacheEncounter = ex.union(update_VisitUid2)
    }
    logger.warn("Update VisitUid Using tempNewEnc table Of Encounter is Done............")

    //Create Dup Table
    val tempDup = cleanedCacheEncounter.filter($"StatusId" === 1).select("VisitUid")
      .groupBy($"VisitUid").count().filter("count > 1")

    //Update StatusId if  Duplicate Encounter is Found
    val update_Status_VisitUid = cleanedCacheEncounter.as("df1").join(tempDup.as("df2")
      , $"df1.VisitUid" === $"df2.VisitUid").where($"df1.StatusId" === 1)
      .select($"df1.*")
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", current_timestamp())
      .withColumn("ErrorNote", lit("Duplicate Encounter Found"))

    val where_Status_VisitUid = cleanedCacheEncounter.as("df1").join(tempDup.as("df2")
      , $"df1.VisitUid" === $"df2.VisitUid").where($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_Status_VisitUid.count > 0) {
      val ex = cleanedCacheEncounter.except(where_Status_VisitUid)
      cleanedCacheEncounter = ex.union(update_Status_VisitUid)
    }
    logger.warn("Update StatusId if  Duplicate Encounter is Found is Done............")


    // Insert Data Into Visit table Using Encounter Table
    val Insert_Data_Visit_Prod = cleanedCacheEncounter.as("df1").join(Visit_Prod1.as("df2")
      , $"df1.VisitUid" === $"df2.VisitUid", "left_outer").where($"df1.StatusId" === 1 && $"df2.VisitUid".isNull)
      .select($"df1.VisitUid", $"df1.+", $"df1.VisitDate", $"df1.ReasonForVisit", $"df1.ServiceProviderUid"
        .as("RenderringProviderUid"), $"df1.ServiceLocationUid", $"df1.PracticeUid", $"df1.MasterVisitTypeUid"
        , $"df1.EncounterStartDate", $"df1.EncounterEndDate", $"df1.Encounter_Status", $"df1.EncounterTypeCode"
        , $"df1.EncounterTIN", $"df1.EncounterKey".as("VisitKey"))
      .groupBy("VisitUid", "PatientUid", "VisitDate", "RenderringProviderUid", "ServiceLocationUid", "PracticeUid"
        , "MasterVisitTypeUid", "Encounter_Status", "EncounterTypeCode", "EncounterTIN", "VisitKey")
      .agg(max($"ReasonForVisit").as("Note"), min($"EncounterStartDate").as("StartDate"),
        max($"EncounterEndDate").as("EndDate"))

    val Visit_allcols = Visit_Prod1.columns.toSet
    val insert_Visit_cols = Insert_Data_Visit_Prod.columns.toSet
    val tot_Visit = Visit_allcols ++ insert_Visit_cols

    Visit_Prod1 = Visit_Prod1.select(FunctionUtility.addColumns(Visit_allcols, tot_Visit): _*)
      .union(Insert_Data_Visit_Prod.select(FunctionUtility.addColumns(insert_Visit_cols, tot_Visit): _*))


    //End Encounter

    logger.warn("End Encounter is Done..............................................................................")

   List(Address_Prod_Delta1,Institution_Prod1,ServiceLocation_Prod1,Visit_Prod1,Individual_prod_Delta1
     ,ServiceProvider_Prod_Delta1)
  }

}
