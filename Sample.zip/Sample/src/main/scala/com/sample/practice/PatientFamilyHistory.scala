package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions._

class PatientFamilyHistory {


  def PatientFamilyHistoryFunc(spark : SparkSession,MergePracticeMap : DataFrame
                               ,CDRPatientCrosswalkTable : DataFrame
                               ,MasterGender_Prod : DataFrame
                               ,MasterRelationship_Prod : DataFrame
                               ,MasterCode_Prod : DataFrame
                               ,Master_prod : DataFrame
                               ,MappingPracticeCommonData_Delta : DataFrame
                               ,Patient_Prod_Delta : DataFrame
                               ,Individual_prod_Delta6 : DataFrame
                               ,PatientFamilyHistoryDF : DataFrame
                               ,MappingPracticeProblem_Delta : DataFrame) : List[DataFrame] = {
    val logger = LoggerFactory.getLogger("")

    import spark.implicits._

    val CacheFamilyHistoryFile = spark.read.option("delimiter", "\u0017")
      .csv("")

    val CacheFamilyHistorylookup=Map("_c0" -> "PatientId","_c1" -> "FamilyMemberLastName","_c2" -> "FamilyMemberFirstName",
      "_c3" -> "RelationshipToPatientCode","_c4" -> "RelationshipToPatientText","_c5" -> "FamilyMemberGender",
      "_c6" -> "FamilyMemberDOB","_c7" -> "EffectiveDate","_c8" -> "ProblemCode","_c9" -> "ProblemText",
      "_c10" -> "ProblemCategory","_c11" -> "ProblemTypeCode","_c12" -> "ProblemTypeText","_c13" -> "FamilyMemberAge",
      "_c14" -> "IsFamilyMemberAlive","_c15" -> "FamilyHistoryKey","_c16" -> "PracticeUid","_c17" -> "BatchUid")

    val tempCacheFamilyHistory = spark.read.option("header", "true").csv("s3n://bd-dev/aao_test/Schema/CDRSchema.txt")
    var tempCacheFamilyHistory1 = CacheFamilyHistoryFile.select(CacheFamilyHistoryFile.columns.map(c => col(c).as(CacheFamilyHistorylookup.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")
    val allcols = tempCacheFamilyHistory.columns.toSet
    val viewcols = tempCacheFamilyHistory1.columns.toSet
    val total = allcols ++ viewcols

    logger.warn("Files are reading")
    tempCacheFamilyHistory1 = tempCacheFamilyHistory.select(FunctionUtility.addColumns(allcols, total): _*)
      .union(tempCacheFamilyHistory1.select(FunctionUtility.addColumns(viewcols, total): _*))

    //#//
    //#// Update Start
    //#//

    //Create MergePracticeMapDF
    val TempMergePracticeMapDf = tempCacheFamilyHistory1.filter($"StatusId".isNull)
      .select("practiceuid").distinct()

    val MergePracticeMapDF = MergePracticeMap.as("df1")
      .join(TempMergePracticeMapDf.as("df2"), $"df1.NewPracticeUid" === $"df2.practiceuid", "left")
      .select("df1.*")


    var UpdateCacheFamilyHistory = tempCacheFamilyHistory1.filter($"StatusId".isNull).as("df1")
      .join(MergePracticeMapDF.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.OriginalPracticeuid".as("AliasOriginalPracticeuid"))
      .withColumn("Practiceuid", $"AliasOriginalPracticeuid")
      .drop("AliasOriginalPracticeuid")


    val whereclauseCacheFamilyHistory1 = tempCacheFamilyHistory1.filter($"StatusId".isNull).as("df1")
      .join(MergePracticeMapDF.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdateCacheVitalSigns1 = tempCacheFamilyHistory1.except(whereclauseCacheFamilyHistory1)
    // Updated CacheVitalSignsTable to CacheVitalSigns1
    var UpdateCacheFamilyHistory1 = UpdateCacheFamilyHistory.union(ExceptUpdateCacheVitalSigns1)

    UpdateCacheFamilyHistory1 = UpdateCacheFamilyHistory1.withColumn("StatusId" , lit(1))


    UpdateCacheFamilyHistory1 = UpdateCacheFamilyHistory1.filter($"StatusID" === 1)
      .withColumn("OldPracticeUid", $"PracticeUid")
      .withColumn("PatientId", ltrim(rtrim($"PatientId")))
      .withColumn("ProblemCode", ltrim(rtrim($"ProblemCode")))
      .withColumn("ProblemTypeCode", ltrim(rtrim($"ProblemTypeCode")))
      .withColumn("RelationshipToPatientText", ltrim(rtrim($"RelationshipToPatientText")))
      .withColumn("RelationshipToPatientCode", ltrim(rtrim($"RelationshipToPatientCode")))

    val UpdateChPatientFamilyHistoryData1 = UpdateCacheFamilyHistory1.filter($"PatientId".isNull).as("df1")
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val whereclause1 = UpdateCacheFamilyHistory1.filter($"PatientId".isNull).as("df1")

    val ExceptUpdateChPatientFamilyHistoryData1 = UpdateCacheFamilyHistory1.except(whereclause1)
    // Updated ChPatientFamilyHistoryData into ChPatientFamilyHistoryData2
    UpdateCacheFamilyHistory1 = UpdateChPatientFamilyHistoryData1.union(ExceptUpdateChPatientFamilyHistoryData1)

    val UpdateChPatientFamilyHistoryData2 = UpdateCacheFamilyHistory1.filter($"StatusId" === 1).as("df1")
      .join(CDRPatientCrosswalkTable.as("df2"), $"df1.PatientId" === $"df2.New_PatientId"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.Old_PatientId".as("AliasOld_PatientId"))
      .withColumn("PatientId", $"AliasOld_PatientId")
      .drop("AliasOld_PatientId")

    val whereclause2 =  UpdateCacheFamilyHistory1.filter($"StatusId" === 1).as("df1")
      .join(CDRPatientCrosswalkTable.as("df2"), $"df1.PatientId" === $"df2.New_PatientId"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData2 = UpdateCacheFamilyHistory1.except(whereclause2)
    // Updated ChPatientFamilyHistoryData1 into ChPatientFamilyHistoryData2
    UpdateCacheFamilyHistory1 = UpdateChPatientFamilyHistoryData2.union(ExceptUpdateChPatientFamilyHistoryData2)

    val UpdateChPatientFamilyHistoryDataProblemTextIdNull = UpdateCacheFamilyHistory1.filter($"StatusId" === 1
      && ltrim(rtrim($"Problemtext")).isNull
      && ltrim(rtrim($"ProblemCode")).isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ProblemText/Code Missing"))

    val whereclause2_1 = UpdateCacheFamilyHistory1.filter($"StatusId" === 1
      && ltrim(rtrim($"Problemtext")).isNull
      && ltrim(rtrim($"ProblemCode")).isNull)

    val exceptupdate2_1 = UpdateCacheFamilyHistory1.except(whereclause2_1)
    UpdateCacheFamilyHistory1 = UpdateChPatientFamilyHistoryDataProblemTextIdNull.union(exceptupdate2_1)

    val UpdateChPatientFamilyHistoryPatientTextgtr = UpdateCacheFamilyHistory1.filter($"StatusId" === 1
      && ltrim(rtrim($"RelationshipToPatientText")).isNotNull
      && length($"RelationshipToPatientText") > 100)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Relationship To PatientText should not be Greater than 100 character"))

    val whereclause2_2 = UpdateCacheFamilyHistory1.filter($"StatusId" === 1
      && ltrim(rtrim($"RelationshipToPatientText")).isNotNull
      && length($"RelationshipToPatientText") > 100)

    val exceptupdate2_2 = UpdateCacheFamilyHistory1.except(whereclause2_2)
    UpdateCacheFamilyHistory1 = UpdateChPatientFamilyHistoryPatientTextgtr.union(exceptupdate2_2)

    val UpdateChPFHDRelationshipToPatientTextNull = UpdateCacheFamilyHistory1
      .filter($"StatusId" === 1 && ltrim(rtrim($"RelationshipToPatientText")).isNull
        && ltrim(rtrim($"RelationshipToPatientCode")).isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("RelationshipToPatientText Not Found/Missing"))

    val whereclause2_3 = UpdateCacheFamilyHistory1
      .filter($"StatusId" === 1 && ltrim(rtrim($"RelationshipToPatientText")).isNull
        && ltrim(rtrim($"RelationshipToPatientCode")).isNull)

    val Exceptwhereclause2_3 = UpdateCacheFamilyHistory1.except(whereclause2_3)
    // Updated ChPatientFamilyHistoryData2 into ChPatientFamilyHistoryData3
    UpdateCacheFamilyHistory1 = UpdateChPFHDRelationshipToPatientTextNull.union(Exceptwhereclause2_3)

    val UpdateChPatientFamilyHistoryData4 = UpdateCacheFamilyHistory1
      .filter($"StatusId" === 1 && ltrim(rtrim($"RelationshipToPatientText")).isNull
        && ltrim(rtrim($"RelationshipToPatientCode")).isNotNull)
      .withColumn("RelationshipToPatientText", $"RelationshipToPatientCode")

    val whereclause4 = UpdateCacheFamilyHistory1
      .filter($"StatusId" === 1 && ltrim(rtrim($"RelationshipToPatientText")).isNull
        && ltrim(rtrim($"RelationshipToPatientCode")).isNotNull)

    val ExceptUpdateChPatientFamilyHistoryData4 = UpdateCacheFamilyHistory1.except(whereclause4)
    // Updated ChPatientFamilyHistoryData3 into ChPatientFamilyHistoryData4
    UpdateCacheFamilyHistory1 = UpdateChPatientFamilyHistoryData4.union(ExceptUpdateChPatientFamilyHistoryData4)


    val CleanData1 = UpdateCacheFamilyHistory1.dropDuplicates("PatientId", "PracticeUid", "problemCode", "effectivedate", "RelationshipToPatientText")
    var DropDuplicates1 = UpdateCacheFamilyHistory1.except(CleanData1)
    val CleanData2 = CleanData1.dropDuplicates("PatientId", "PracticeUid", "problemtext", "effectivedate", "RelationshipToPatientText")
    val DropDuplicates2 = CleanData1.except(CleanData2)
    val CleanData3 = CleanData2.dropDuplicates("PatientId", "PracticeUid", "problemCode", "RelationshipToPatientText")
    val DropDuplicates3 = CleanData2.except(CleanData3)
    var CleanData4 = CleanData3.dropDuplicates("PatientId", "PracticeUid", "problemtext", "RelationshipToPatientText")
    val DropDuplicates4 = CleanData3.except(CleanData4)

    DropDuplicates1 = DropDuplicates1
      .union(DropDuplicates2)
      .union(DropDuplicates3)
      .union(DropDuplicates4)

    DropDuplicates1 = DropDuplicates1.union(DropDuplicates4)


    val UpdateChPatientFamilyHistoryData9 = CleanData4.filter($"StatusId" === 1
      && $"PatientUid".isNull).as("df1")
      .join(Patient_Prod_Delta.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod_Delta6.as("df3"), $"df3.IndividualUid" === $"df2.PatientUid"
        && $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*", $"df2.PatientUid".as("AliasPatientUid"))
      .withColumn("PatientUid", $"AliasPatientUid")
      .drop("AliasPatientUid")

    val whereclause9 =  CleanData4.filter($"StatusId" === 1
      && $"PatientUid".isNull).as("df1")
      .join(Patient_Prod_Delta.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod_Delta6.as("df3"), $"df3.IndividualUid" === $"df2.PatientUid"
        && $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*")
    val ExceptUpdateChPatientFamilyHistoryData9 = CleanData4.except(whereclause9)
    // Updated ChPatientFamilyHistoryData8 into ChPatientFamilyHistoryData9
    CleanData4 = UpdateChPatientFamilyHistoryData9.union(ExceptUpdateChPatientFamilyHistoryData9)


    val UpdateChPatientFamilyHistoryData10 = CleanData4.filter($"StatusId" === 1
      && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val whereclause10 = CleanData4.filter($"StatusId" === 1
      && $"PatientUid".isNull)

    val ExceptUpdateChPatientFamilyHistoryData10 = CleanData4.except(whereclause10)
    // Updated ChPatientFamilyHistoryData9 into ChPatientFamilyHistoryData10
    CleanData4 = UpdateChPatientFamilyHistoryData10.union(ExceptUpdateChPatientFamilyHistoryData10)

    val UpdateChPatientFamilyHistoryData11 = CleanData4.filter($"StatusId" === 1
      && $"ResultInterpretationUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "18D5C957-AC54-49A8-8609-E8DDC8F6C721").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.FamilyMemberGender" === $"df2.PracticeValue")
      .select($"df1.*", $"df2.MappedUid".as("AliasMappedUid"))
      .withColumn("FamilyMemberGenderUid", $"AliasMappedUid")
      .drop("AliasMappedUid")

    val whereclause11 = CleanData4.filter($"StatusId" === 1
      && $"ResultInterpretationUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "18D5C957-AC54-49A8-8609-E8DDC8F6C721").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.FamilyMemberGender" === $"df2.PracticeValue")
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData11 = CleanData4.except(whereclause11)
    // Updated ChPatientFamilyHistoryData10 into ChPatientFamilyHistoryData11
    CleanData4 = UpdateChPatientFamilyHistoryData11.union(ExceptUpdateChPatientFamilyHistoryData11)

    val UpdateChPatientFamilyHistoryData12 = CleanData4.filter($"StatusId" === 1
      && $"FamilyMemberGenderUid".isNull).as("df1")
      .join(MasterGender_Prod.as("df2"), $"FamilyMemberGender" === $"df2.ExternalID")
      .select($"df1.*", $"df2.GenderUid".as("AliasGenderUid"))
      .withColumn("FamilyMemberGenderUid", $"AliasGenderUid")
      .drop("AliasGenderUid")

    val whereclause12 =  CleanData4.filter($"StatusId" === 1
      && $"FamilyMemberGenderUid".isNull).as("df1")
      .join(MasterGender_Prod.as("df2"), $"FamilyMemberGender" === $"df2.ExternalID")
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData12 = CleanData4.except(whereclause12)
    // Updated ChPatientFamilyHistoryData11 into ChPatientFamilyHistoryData12
    CleanData4 = UpdateChPatientFamilyHistoryData12.union(ExceptUpdateChPatientFamilyHistoryData12)

    //Update rest Of the recored in error when statusId = 1 & GenderUid is null
    val UpdateChPatientFamilyHistoryData13 = CleanData4.filter($"StatusId" === 1
      && $"FamilyMemberGenderUid".isNull
      && rtrim(ltrim($"FamilyMemberGender")))
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Gender Not Mapped"))

    val whereclause13 = CleanData4.filter($"StatusId" === 1
      && $"FamilyMemberGenderUid".isNull
      && rtrim(ltrim($"FamilyMemberGender")))
    val ExceptUpdateChPatientFamilyHistoryData13 = CleanData4.except(whereclause13)
    // Updated ChPatientFamilyHistoryData12 into ChPatientFamilyHistoryData13
    CleanData4 = UpdateChPatientFamilyHistoryData13.union(ExceptUpdateChPatientFamilyHistoryData13)

    val UpdateChPatientFamilyHistoryData14 = CleanData4.filter($"StatusId" === 1
      && $"RelationshipToPatientText".isNull && $"PatientRelationshipToFamilyMemberUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "02603092-7A9C-4ADD-990B-E446B72BD76C").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.RelationshipToPatientCode" === $"df2.PracticeValue")
      .select($"df1.*", $"df2.MappedUid".as("AliasMappedUid"))
      .withColumn("PatientRelationshipToFamilyMemberUid", $"AliasMappedUid")
      .drop("AliasMappedUid")

    val whereclause14 = CleanData4.filter($"StatusId" === 1
      && $"RelationshipToPatientText".isNull && $"PatientRelationshipToFamilyMemberUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "02603092-7A9C-4ADD-990B-E446B72BD76C").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.RelationshipToPatientCode" === $"df2.PracticeValue")
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData14 = CleanData4.except(whereclause14)
    // Updated ChPatientFamilyHistoryData13 into ChPatientFamilyHistoryData14
    CleanData4 = UpdateChPatientFamilyHistoryData14.union(ExceptUpdateChPatientFamilyHistoryData14)

    val UpdateChPatientFamilyHistoryData15 = CleanData4.filter($"StatusId" === 1
      && $"RelationshipToPatientCode".isNull && $"PatientRelationshipToFamilyMemberUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "02603092-7A9C-4ADD-990B-E446B72BD76C").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.RelationshipToPatientText" === $"df2.PracticeValue")
      .select($"df1.*", $"df2.MappedUid".as("AliasMappedUid"))
      .withColumn("PatientRelationshipToFamilyMemberUid", $"AliasMappedUid")
      .drop("AliasMappedUid")

    val whereclause15 =  CleanData4.filter($"StatusId" === 1
      && $"RelationshipToPatientCode".isNull && $"PatientRelationshipToFamilyMemberUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "02603092-7A9C-4ADD-990B-E446B72BD76C").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.RelationshipToPatientText" === $"df2.PracticeValue")
      .select($"df1.*")
    val ExceptUpdateChPatientFamilyHistoryData15 = CleanData4.except(whereclause15)
    // Updated ChPatientFamilyHistoryData14 into ChPatientFamilyHistoryData15
    CleanData4 = UpdateChPatientFamilyHistoryData15.union(ExceptUpdateChPatientFamilyHistoryData15)

    //Update PatientRelationshipToFamilyMemberUid from MasterRelationship
    val UpdateChPatientFamilyHistoryData16 = CleanData4.filter($"StatusId" === 1
      && $"PatientRelationshipToFamilyMemberUid".isNull).as("df1")
      .join(MasterRelationship_Prod.as("df2"), $"df1.RelationshipToPatientCode" === $"df2.Externalid")
      .select($"df1.*", $"df2.RelationshipUid".as("AliasRelationshipUid"))
      .withColumn("RelationshipToPatientCode", $"AliasRelationshipUid")
      .drop("AliasRelationshipUid")

    val whereclause16 = CleanData4.filter($"StatusId" === 1
      && $"PatientRelationshipToFamilyMemberUid".isNull).as("df1")
      .join(MasterRelationship_Prod.as("df2"), $"df1.RelationshipToPatientCode" === $"df2.Externalid")
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData16 = CleanData4.except(whereclause16)
    // Updated ChPatientFamilyHistoryData15 into ChPatientFamilyHistoryData16
    CleanData4 = UpdateChPatientFamilyHistoryData16.union(ExceptUpdateChPatientFamilyHistoryData16)

    val UpdateChPatientFamilyHistoryData17 = CleanData4.filter($"StatusId" === 1
      && $"PatientRelationshipToFamilyMemberUid".isNull).as("df1")
      .join(MasterRelationship_Prod.as("df2"), $"df1.RelationshipToPatientText" === $"df2.Description")
      .select($"df1.*", $"df2.RelationshipUid".as("AliasRelationshipUid"))
      .withColumn("RelationshipToPatientCode", $"AliasRelationshipUid")
      .drop("AliasRelationshipUid")

    val whereclause17 = CleanData4.filter($"StatusId" === 1
      && $"PatientRelationshipToFamilyMemberUid".isNull).as("df1")
      .join(MasterRelationship_Prod.as("df2"), $"df1.RelationshipToPatientText" === $"df2.Description")
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData17 = CleanData4.except(whereclause17)
    // Updated ChPatientFamilyHistoryData16 into ChPatientFamilyHistoryData17
    CleanData4 = UpdateChPatientFamilyHistoryData17.union(ExceptUpdateChPatientFamilyHistoryData17)

    val UpdateChPatientFamilyHistoryData18 = CleanData4.filter($"StatusId" === 1
      && $"ProblemCodeUid".isNull).as("df1")
      .join(MappingPracticeProblem_Delta.as("df2"), $"df1.ProblemCode" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.CodeUid".as("AliasCodeUid"))
      .withColumn("ProblemCodeUid", $"AliasCodeUid")
      .drop("AliasCodeUid")

    val whereclause18 = CleanData4.filter($"StatusId" === 1
      && $"ProblemCodeUid".isNull).as("df1")
      .join(MappingPracticeProblem_Delta.as("df2"), $"df1.ProblemCode" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData18 = CleanData4.except(whereclause18)
    // Updated ChPatientFamilyHistoryData17 into ChPatientFamilyHistoryData18
    CleanData4 = UpdateChPatientFamilyHistoryData18.union(ExceptUpdateChPatientFamilyHistoryData18)

    val UpdateChPatientFamilyHistoryData19 = CleanData4.filter($"StatusId" === 1
      && $"ProblemCodeUid".isNull).as("df1")
      .join(MasterCode_Prod.as("df2"), $"df1.ProblemCode" === $"df2.Code"
        && $"df1.ProblemCategory" === $"df2.CodeSystem")
      .select($"df1.*", $"df2.CodeUid".as("AliasCodeUid"))
      .withColumn("ProblemCodeUid", $"AliasCodeUid")
      .drop("AliasCodeUid")

    val whereclause19 =  CleanData4.filter($"StatusId" === 1
      && $"ProblemCodeUid".isNull).as("df1")
      .join(MasterCode_Prod.as("df2"), $"df1.ProblemCode" === $"df2.Code"
        && $"df1.ProblemCategory" === $"df2.CodeSystem")
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData19 = CleanData4.except(whereclause19)
    // Updated ChPatientFamilyHistoryData18 into ChPatientFamilyHistoryData19
    CleanData4 = UpdateChPatientFamilyHistoryData19.union(ExceptUpdateChPatientFamilyHistoryData19)

    val UpdateChPatientFamilyHistoryData20 = CleanData4.filter($"StatusId" === 1
      && $"ProblemCodeUid".isNull && $"problemtext".isNotNull).as("df1")
      .join(MasterCode_Prod.as("df2"), $"df1.problemtext" === $"df2.description"
        && $"df1.ProblemCategory" === $"df2.CodeSystem")
      .select($"df1.*", $"df2.CodeUid".as("AliasCodeUid"))
      .withColumn("ProblemCodeUid", $"AliasCodeUid")
      .drop("AliasCodeUid")

    val whereclause20 = CleanData4.filter($"StatusId" === 1
      && $"ProblemCodeUid".isNull && $"problemtext".isNotNull).as("df1")
      .join(MasterCode_Prod.as("df2"), $"df1.problemtext" === $"df2.description"
        && $"df1.ProblemCategory" === $"df2.CodeSystem")
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData20 = CleanData4.except(whereclause20)
    // Updated ChPatientFamilyHistoryData19 into ChPatientFamilyHistoryData20
    CleanData4 = UpdateChPatientFamilyHistoryData20.union(ExceptUpdateChPatientFamilyHistoryData20)

    //Update ProblemTypeCodeUid from MappingPracticeCommonData
    val UpdateChPatientFamilyHistoryData21 = CleanData4.filter($"StatusId" === 1
      && $"ProblemTypeCodeUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "163219CF-A146-4869-9354-DA8A65F8DBB0").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ProblemTypeCode" === $"df2.PracticeValue")
      .select($"df1.*", $"df2.MappedUid".as("AliasMappedUid"))
      .withColumn("ProblemTypeCodeUid", $"AliasMappedUid")
      .drop("AliasMappedUid")


    val whereclause21 = CleanData4.filter($"StatusId" === 1
      && $"ProblemTypeCodeUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "163219CF-A146-4869-9354-DA8A65F8DBB0").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ProblemTypeCode" === $"df2.PracticeValue")
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData21 = CleanData4.except(whereclause21)
    // Updated ChPatientFamilyHistoryData20 into ChPatientFamilyHistoryData21
    CleanData4 = UpdateChPatientFamilyHistoryData21.union(ExceptUpdateChPatientFamilyHistoryData21)

    val UpdateChPatientFamilyHistoryData22 = CleanData4.filter($"StatusId" === 1
      && $"ProblemTypeCodeUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "163219CF-A146-4869-9354-DA8A65F8DBB0").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ProblemTypeText" === $"df2.PracticeValue")
      .select($"df1.*", $"df2.MappedUid".as("AliasMappedUid"))
      .withColumn("ProblemTypeCodeUid", $"AliasMappedUid")
      .drop("AliasMappedUid")

    val whereclause22 = CleanData4.filter($"StatusId" === 1
      && $"ProblemTypeCodeUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "163219CF-A146-4869-9354-DA8A65F8DBB0").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ProblemTypeText" === $"df2.PracticeValue")
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData22 = CleanData4.except(whereclause22)
    // Updated ChPatientFamilyHistoryData21 into ChPatientFamilyHistoryData22
    CleanData4 = UpdateChPatientFamilyHistoryData22.union(ExceptUpdateChPatientFamilyHistoryData22)

    val UpdateChPatientFamilyHistoryData23 = CleanData4.filter($"StatusId" === 1
      && $"ProblemTypeCodeUid".isNull && $"Type" === "ProblemType").as("df1")
      .join(Master_prod.as("df2"), $"df1.ProblemTypeCode" === $"df2.Code" || $"df1.ProblemTypeText" === $"df2.Name")
      .select($"df1.*", $"df2.MasterUid".as("AliasMasterUid"))
      .withColumn("ProblemTypeCodeUid", $"AliasMasterUid")
      .withColumn("ErrorNote", lit(null))
      .drop("AliasMasterUid")

    val whereclause23 = CleanData4.filter($"StatusId" === 1
      && $"ProblemTypeCodeUid".isNull && $"Type" === "ProblemType").as("df1")
      .join(Master_prod.as("df2"), $"df1.ProblemTypeCode" === $"df2.Code" || $"df1.ProblemTypeText" === $"df2.Name")
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData23 = CleanData4.except(whereclause23)
    // Updated ChPatientFamilyHistoryData22 into ChPatientFamilyHistoryData23
    CleanData4 = UpdateChPatientFamilyHistoryData23.union(ExceptUpdateChPatientFamilyHistoryData23)

    val UpdateChPatientFamilyHistoryData24 = CleanData4
      .filter($"StatusId" === 1 && $"ProblemTypeCodeUid".isNull
        && (ltrim(rtrim($"ProblemTypeCode")).isNotNull or ltrim(rtrim($"ProblemTypeText")).isNotNull))
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ProblemTypeCode Not Mapped"))

    val ExceptUpdateChPatientFamilyHistoryData24 = CleanData4.except(UpdateChPatientFamilyHistoryData24)
    // Updated ChPatientFamilyHistoryData23 into ChPatientFamilyHistoryData24
    CleanData4 = UpdateChPatientFamilyHistoryData24.union(ExceptUpdateChPatientFamilyHistoryData24)

    val UpdateChPatientFamilyHistoryData25 = CleanData4.filter($"StatusId" === 1
      && $"PatientFamilyHistoryUid".isNull).as("df1")
      .join(PatientFamilyHistoryDF.as("df2"),$"df1.PatientUid" === $"df2.PatientUid"
        && ($"df1.problemCode" === $"df2.problemCode" || $"df1.problemText" === $"df2.ProblemDescription")
        && $"df1.effectivedate" === $"df2.Observationdate"
        && $"df1.RelationshipToPatientText" === $"df2.PatientRelationshipToFamilyMemberText")
      .select($"df1.*" , $"df2.PatientFamilyHistoryUid".as("AliasPatientFamilyHistoryUid"))
      .withColumn("PatientFamilyHistoryUid", $"AliasPatientFamilyHistoryUid")
      .drop("AliasPatientFamilyHistoryUid")

    val whereclause25 = CleanData4.filter($"StatusId" === 1
      && $"PatientFamilyHistoryUid".isNull).as("df1")
      .join(PatientFamilyHistoryDF.as("df2"),$"df1.PatientUid" === $"df2.PatientUid"
        && ($"df1.problemCode" === $"df2.problemCode" || $"df1.problemText" === $"df2.ProblemDescription")
        && $"df1.effectivedate" === $"df2.Observationdate"
        && $"df1.RelationshipToPatientText" === $"df2.PatientRelationshipToFamilyMemberText")
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData25 = CleanData4.except(whereclause25)
    // Updated ChPatientFamilyHistoryData24 into ChPatientFamilyHistoryData25
    CleanData4 = UpdateChPatientFamilyHistoryData25.union(ExceptUpdateChPatientFamilyHistoryData25)

    val TempPatientFamilyHistory = CleanData4
      .filter($"StatusId" ===1 && $"PatientFamilyHistoryUid".isNull
        && ($"problemCode".isNotNull || $"problemText".isNotNull)
        && $"effectivedate".isNotNull)
      .select("PatientUid","problemCode","problemText","effectivedate","RelationshipToPatientText","PracticeUid")
      .distinct()
      .withColumn("PatientFamilyHistoryUid", FunctionUtility.getNewUid())

    val UpdateChPatientFamilyHistoryData26 = CleanData4.filter($"StatusId" === 1
      && $"PatientFamilyHistoryUid".isNull).as("df1")
      .join(TempPatientFamilyHistory.as("df2"),$"df1.PatientUid" === $"df12.PatientUid"
        && $"df1.PracticeUid" === $"df12.PracticeUid"
        && $"df1.RelationshipToPatientText" === $"df12.RelationshipToPatientText"
        && $"df1.effectivedate" === $"df12.effectivedate"
        && ($"df1.problemCode" === $"df12.problemCode" || $"df1.problemText" === $"df12.problemText"))
      .select($"df1.*",$"df2.PatientFamilyHistoryUid".as("AliasPatientFamilyHistoryUid"))
      .withColumn("PatientFamilyHistoryUid" , $"AliasPatientFamilyHistoryUid")
      .drop("AliasPatientFamilyHistoryUid")

    val whereclause26 = CleanData4.filter($"StatusId" === 1
      && $"PatientFamilyHistoryUid".isNull).as("df1")
      .join(TempPatientFamilyHistory.as("df2"),$"df1.PatientUid" === $"df12.PatientUid"
        && $"df1.PracticeUid" === $"df12.PracticeUid"
        && $"df1.RelationshipToPatientText" === $"df12.RelationshipToPatientText"
        && $"df1.effectivedate" === $"df12.effectivedate"
        && ($"df1.problemCode" === $"df12.problemCode" || $"df1.problemText" === $"df12.problemText"))
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData26 = CleanData4.except(whereclause26)
    // Updated ChPatientFamilyHistoryData25 into ChPatientFamilyHistoryData26
    CleanData4 = UpdateChPatientFamilyHistoryData26.union(ExceptUpdateChPatientFamilyHistoryData26)

    val TempPatientFamilyHistory1 = CleanData4
      .filter($"StatusId" === 1
        && $"PatientFamilyHistoryUid".isNull
        && ($"problemCode".isNotNull || $"problemText".isNotNull )
        && $"effectivedate".isNull)
      .select("PatientUid","problemCode","problemText","RelationshipToPatientText","PracticeUid")
      .distinct()
      .withColumn("PatientFamilyHistoryUid", FunctionUtility.getNewUid())

    val UpdateChPatientFamilyHistoryData27 = CleanData4.filter($"StatusId" === 1
      && $"PatientFamilyHistoryUid".isNull).as("df1")
      .join(TempPatientFamilyHistory1.as("df2"),$"df1.PatientUid" === $"df12.PatientUid"
        && $"df1.PracticeUid" === $"df12.PracticeUid"
        && $"df1.RelationshipToPatientText" === $"df12.RelationshipToPatientText"
        && ($"df1.problemCode" === $"df12.problemCode" || $"df1.problemText" === $"df12.problemText"))
      .select($"df1.*",$"df2.PatientFamilyHistoryUid".as("AliasPatientFamilyHistoryUid"))
      .withColumn("PatientFamilyHistoryUid" , $"AliasPatientFamilyHistoryUid")
      .drop("AliasPatientFamilyHistoryUid")

    val whereclause27 = CleanData4.filter($"StatusId" === 1
      && $"PatientFamilyHistoryUid".isNull).as("df1")
      .join(TempPatientFamilyHistory1.as("df2"),$"df1.PatientUid" === $"df12.PatientUid"
        && $"df1.PracticeUid" === $"df12.PracticeUid"
        && $"df1.RelationshipToPatientText" === $"df12.RelationshipToPatientText"
        && ($"df1.problemCode" === $"df12.problemCode" || $"df1.problemText" === $"df12.problemText"))
      .select($"df1.*")

    val ExceptUpdateChPatientFamilyHistoryData27 = CleanData4.except(whereclause27)
    // Updated ChPatientFamilyHistoryData26 into ChPatientFamilyHistoryData27
    CleanData4 = UpdateChPatientFamilyHistoryData27.union(ExceptUpdateChPatientFamilyHistoryData27)

    //Confirm
    val UpdatePatientFamilyHistory1 = PatientFamilyHistoryDF.as("df1")
      .join(CleanData4.filter($"StatusId"===1
        && $"cpd.PatientFamilyHistoryUid".isNotNull).as("df2") ,
        $"df1.PatientFamilyHistoryUid" === $"df2.PatientFamilyHistoryUid" && $"df1.PatientUid" === $"df2.PatientUid")
      .select($"df1.*", $"df2.ProblemCodeUid".as("cpd.ProblemCodeUid"),$"df2.problemText".as("cpd.problemText"),
        $"df2.ProblemCode".as("cpd.ProblemCode"),$"df2.ProblemTypeCodeUid".as("cpd.ProblemTypeCodeUid"),
        $"df2.FamilyMemberAge".as("cpd.FamilyMemberAge"),$"df2.FamilyMemberLastName".as("cpd.FamilyMemberLastName"),
        $"df2.FamilyMemberFirstName".as("cpd.FamilyMemberFirstName"),
        $"df2.isfamilymemberalive".as("cpd.isfamilymemberalive"),$"df2.effectivedate".as("cpd.effectivedate"),
        $"df2.RelationshipToPatientText".as("cpd.RelationshipToPatientText"),
        $"df2.ProblemCategory".as("cpd.ProblemCategory"))
      .withColumn("ProblemCodeUid",$"AliasProblemCodeUid")
      .withColumn("ProblemDescription",$"AliasproblemText")
      .withColumn("ProblemCode",$"AliasProblemCode")
      .withColumn("MasterProblemTypeUid",$"AliasProblemTypeCodeUid")
      .withColumn("FamilyMemberAge",$"AliasFamilyMemberAge")
      .withColumn("FamilyMemberLastName",$"AliasFamilyMemberLastName")
      .withColumn("FamilyMemberFirstName",$"AliasFamilyMemberFirstName")
      .withColumn("IsAlive",$"Aliasisfamilymemberalive")
      .withColumn("ObservationDate",$"Aliaseffectivedate")
      .withColumn("PatientRelationshipToFamilyMemberText",$"AliasRelationshipToPatientText")
      .withColumn("CodeSystem",$"AliasProblemCategory")

    val whereclauseFamilyHistory1 = PatientFamilyHistoryDF.as("df1")
      .join(CleanData4.filter($"StatusId"===1
        && $"cpd.PatientFamilyHistoryUid".isNotNull).as("df2") ,
        $"df1.PatientFamilyHistoryUid" === $"df2.PatientFamilyHistoryUid" && $"df1.PatientUid" === $"df2.PatientUid")
      .select($"df1.*")

    val ExceptUpdatePatientFamilyHistory1 = PatientFamilyHistoryDF.except(whereclauseFamilyHistory1)
    var PatientFamilyHistory_Prod_Delta = UpdatePatientFamilyHistory1.union(ExceptUpdatePatientFamilyHistory1)

    val InsertIntoPatientFamilyHistory = CleanData4
      .join(PatientFamilyHistory_Prod_Delta, Seq("PatientFamilyHistoryUid"), "left")
      .select($"df1.PatientFamilyHistoryUid",$"df1.PatientUid",$"df1.PatientRelationshipToFamilyMemberUid",
        $"df1.ProblemTypeCodeUid".as("MasterProblemTypeUid"),$"df1.ProblemCodeUid",$"df1.ProblemCode",
        $"df1.FamilyMemberAge", $"df1.isfamilymemberalive".as("IsAlive"),$"df1.FamilyMemberLastName",
        $"df1.FamilyMemberFirstName", $"df1.effectivedate".as("ObservationDate"),
        $"df1.RelationshipToPatientText".as("PatientRelationshipToFamilyMemberText"),
        $"df1.ProblemCategory".as("CodeSystem"))
      .groupBy($"PatientFamilyHistoryUid",$"PatientUid",$"PatientRelationshipToFamilyMemberUid",$"MasterProblemTypeUid",
        $"ProblemCodeUid",$"ProblemCode",$"FamilyMemberAge",$"IsAlive",$"FamilyMemberLastName",
        $"FamilyMemberFirstName",$"ObservationDate",$"PatientRelationshipToFamilyMemberText",$"CodeSystem")
      .agg(max($"ProblemText").as("ProblemDescription"))

    val allcols1 = PatientFamilyHistory_Prod_Delta.columns.toSet
    val insertcols = InsertIntoPatientFamilyHistory.columns.toSet
    val tot3 = allcols1 ++ insertcols

    PatientFamilyHistory_Prod_Delta = PatientFamilyHistory_Prod_Delta.select(FunctionUtility.addColumns(allcols1, tot3): _*)
      .union(InsertIntoPatientFamilyHistory.select(FunctionUtility.addColumns(insertcols, tot3): _*))

    List(PatientFamilyHistory_Prod_Delta)
  }
}
