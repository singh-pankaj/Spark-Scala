package com.sample.practice

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

class CacheProblem {

  def CacheProblemFunc(spark : SparkSession,MergePracticeMap : DataFrame
                       ,CDRPatientCrosswalkTable : DataFrame
                       ,MasterCode_Prod : DataFrame
                       ,PatientProblem_Prod : DataFrame
                       ,Master_prod : DataFrame
                       ,Patient_Prod_Delta : DataFrame
                       ,Individual_prod_Delta2 : DataFrame
                       ,MappingPracticeProblem_Delta : DataFrame
                       ,PatientProblemHistory_Prod_Delta : DataFrame
                       ,MappingPracticeCommonData_Delta : DataFrame) : List[DataFrame] = {

    val logger = LoggerFactory.getLogger("")
    import spark.implicits._
    var cacheProblemDemo = spark.read.option("delimiter", "\u0017").csv("/home/ravikant.petkar/Downloads/AAO_Projects/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/c02a8880-be91-4479-add2-02fe91f48db0_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")

    //cacheFile.collect.foreach(println)

    val lookup_cacheProblem = Map("_c0" -> "PatientId", "_c1" -> "ProblemCode", "_c2" -> "ProblemText", "_c3" -> "ProblemCategory", "_c4" -> "ProblemTypeCode", "_c5" -> "ProblemTypeText", "_c6" -> "DocumentationDate",
      "_c7" -> "ProblemResolutionDate", "_c8" -> "ProblemStatusCode", "_c9" -> "ProblemStatusText", "_c10" -> "ProblemHealthStatusCode", "_c11" -> "ProblemHealthStatusText", "_c12" -> "NegationInd",
      "_c13" -> "ProblemComment", "_c14" -> "ProblemOnsetDate", "_c15" -> "TargetSiteCode", "_c16" -> "TargetSiteText", "_c17" -> "ProblemKey", "_c18" -> "PracticeUid", "_c19" -> "BatchUid",
      "_c20" -> "dummy1", "_c21" -> "dummy2")

    cacheProblemDemo = cacheProblemDemo.select(cacheProblemDemo.columns.map(c => col(c).as(lookup_cacheProblem.getOrElse(c, c))): _*).drop("dummy1", "dummy2")

    val tempCacheProblemdemo = spark.read.option("header", "true").csv("/home/ravikant.petkar/Downloads/AAO_Projects/AAO_DATA/Schema/CacheProblem")

    val cacheProblemDemocols = tempCacheProblemdemo.columns.toSet
    val cacheProblemDemoViewcols = cacheProblemDemo.columns.toSet
    val tot_viewEnDiag_cacheProblemDemoViewcols = cacheProblemDemocols ++ cacheProblemDemoViewcols

    logger.warn("Files are reading")

    cacheProblemDemo = tempCacheProblemdemo.select(FunctionUtility.addColumns(cacheProblemDemocols, tot_viewEnDiag_cacheProblemDemoViewcols): _*)
      .union(cacheProblemDemo.select(FunctionUtility.addColumns(cacheProblemDemoViewcols, tot_viewEnDiag_cacheProblemDemoViewcols): _*))

    cacheProblemDemo = cacheProblemDemo.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    //Distinct PracticeUid of CacheProblem

    val dist_PrctUid_CacheProblem = cacheProblemDemo.filter($"StatusId".isNull).select("PracticeUid").distinct()

    val tempMergePracticeMap_CacheProblem = MergePracticeMap.as("df1").join(dist_PrctUid_CacheProblem.as("df2")
      , $"df1.NewPracticeuid" === $"df2.PracticeUid").select($"df1.*")

    //Update PracticeUid with OriginalPracticeuid of CacheProblem

    cacheProblemDemo = cacheProblemDemo.as("df1").join(tempMergePracticeMap_CacheProblem.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeuid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeuid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeuid of CacheProblem is Done.............................")

    cacheProblemDemo = cacheProblemDemo.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CacheProblem
    cacheProblemDemo = cacheProblemDemo.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PatientId", rtrim(ltrim($"df1.PatientId")))
      .withColumn("ProblemCode", rtrim(ltrim($"df1.ProblemCode")))

    logger.warn("Update Multiple Columns of CacheProblem is Done............")

    //Update Multiple Status Of CacheProblem
    val update_Status_CacheProblem = cacheProblemDemo.filter($"StatusId" === 1 && $"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val where_Status_CacheProblem = cacheProblemDemo.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_Status_CacheProblem.count > 0) {
      val ex = cacheProblemDemo.except(where_Status_CacheProblem)
      cacheProblemDemo = ex.union(update_Status_CacheProblem)
    }

    logger.warn("Update Multiple Status Of CacheProblem is Done............")

    //Update PatientId using CDRPatientCrosswalk In CacheProblem Table

    val updatePatientIdCacheProblem = cacheProblemDemo.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientIdCacheProblem = cacheProblemDemo.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientIdCacheProblem.count > 0) {
      val ex = cacheProblemDemo.except(where_PatientIdCacheProblem)
      cacheProblemDemo = ex.union(updatePatientIdCacheProblem)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk In CacheProblem Table is Done............")

    //Update PatientUid Of CacheProblem using Individual and Patient table

    val aa1 = cacheProblemDemo.filter($"StatusId" === 1 && $"ProblemCategory".isNull
      && $"ProblemCode".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Problem Category Not Found"))

    val bb1 = cacheProblemDemo.filter($"StatusId" === 1 && $"ProblemCode".isNull
      && $"ProblemText".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Problem Text And Problem Code Missing"))

    val update_status_CacheProblem2 = aa1.union(bb1)

    val where_CacheProblem = cacheProblemDemo.filter($"StatusId" === 1 && ($"ProblemCategory".isNull
      && $"ProblemCode".isNull || $"ProblemCode".isNull && $"ProblemText".isNull))

    if (where_CacheProblem.count > 0) {
      val ex = cacheProblemDemo.except(where_CacheProblem)
      cacheProblemDemo = ex.union(update_status_CacheProblem2)
    }

    val update_PatientUid_CacheProblem = cacheProblemDemo.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta2.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val where_PatientUid_CacheProblem12 = cacheProblemDemo.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta2.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientUid_CacheProblem12.count > 0) {
      val ex = cacheProblemDemo.except(where_PatientUid_CacheProblem12)
      cacheProblemDemo = ex.union(update_PatientUid_CacheProblem)
    }


    val update_Status_CacheProblem2 = cacheProblemDemo.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_Status_CacheProblem2 = cacheProblemDemo.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_Status_CacheProblem2.count > 0) {
      val ex = cacheProblemDemo.except(where_Status_CacheProblem2)
      cacheProblemDemo = ex.union(update_Status_CacheProblem2)
    }

    logger.warn("Update PatientUid Of CacheProblem using Individual and Patient table is Done............")

    //Update Status if PatientUid is Null Of CacheProblem
    val update_Status_CacheProblem3 = cacheProblemDemo.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_Status_CacheProblem3 = cacheProblemDemo.filter($"StatusId" === 1 && $"PatientUid".isNull)

    if (where_Status_CacheProblem3.count > 0) {
      val ex = cacheProblemDemo.except(where_Status_CacheProblem3)
      cacheProblemDemo = ex.union(update_Status_CacheProblem3)
    }

    logger.warn("Update Status if PatientUid is Null Of CacheProblem is Done............")

    //Remove Duplicates of CacheProblem

    var cleanedCacheProblem = cacheProblemDemo.filter($"StatusId" === 1)
      .dropDuplicates(Seq("PatientUid", "ProblemCode", "DocumentationDate"))

    val dropDuplicatesCacheCacheProblem = cacheProblemDemo.filter($"StatusId" === 1 &&
      $"ProblemCode".isNull)
      .dropDuplicates(Seq("PatientUid", "DocumentationDate", "problemtext"))

    cleanedCacheProblem = cleanedCacheProblem.union(dropDuplicatesCacheCacheProblem)

    var duplicatesRecordsCacheProblem1 = cacheProblemDemo.except(cleanedCacheProblem)
    val duplicaterecordsCacheProblem2 = cacheProblemDemo.except(dropDuplicatesCacheCacheProblem)

    duplicatesRecordsCacheProblem1 = duplicatesRecordsCacheProblem1.union(duplicaterecordsCacheProblem2)

    logger.warn("Remove Duplicates of CacheProblem is Done............")

    //update CodeUid Using mappingPracticeProblem of CacheProblem
    val update_CodeUid_CacheProblem = cleanedCacheProblem.as("df1").join(MappingPracticeProblem_Delta.as("df2")
      , $"df1.ProblemCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.CodeUid".isNull)
      .select($"df1.*", $"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("CodeUid", $"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_CodeUid_CacheProblem = cleanedCacheProblem.as("df1").join(MappingPracticeProblem_Delta.as("df2")
      , $"df1.ProblemCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.CodeUid".isNull)
      .select($"df1.*")

    if (where_CodeUid_CacheProblem.count > 0) {
      val ex = cleanedCacheProblem.except(where_CodeUid_CacheProblem)
      cleanedCacheProblem = ex.union(update_CodeUid_CacheProblem)
    }

    logger.warn("update CodeUid Using mappingPracticeProblem of CacheProblem is Done............")


    //Update CodeUid Of CacheProblem table using MasterCode table

    val update_CodeUid_CacheProblem2 = cleanedCacheProblem.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.ProblemCode" === $"df2.Code" && $"df2.CodeSystem".isin(1, 2, 3))
      .where($"df1.StatusId" === 1 && $"df1.CodeUid".isNull)
      .select($"df1.*", $"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("CodeUid", $"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_CodeUid_CacheProblem2 = cleanedCacheProblem.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.ProblemCode" === $"df2.Code" && $"df2.CodeSystem".isin(1, 2, 3))
      .where($"df1.StatusId" === 1 && $"df1.CodeUid".isNull)
      .select($"df1.*")

    if (where_CodeUid_CacheProblem2.count > 0) {
      val ex = cleanedCacheProblem.except(where_CodeUid_CacheProblem2)
      cleanedCacheProblem = ex.union(update_CodeUid_CacheProblem2)
    }

    logger.warn("Update CodeUid Of CacheProblem table using MasterCode table  is Done............")


    //Update PatientProblemUid of CacheProblem using PatientProblem_Prod table

    val update_PatientProblemUid_CacheProblem = cleanedCacheProblem.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.CodeUid" === $"df2.CodeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*", $"df2.PatientProblemUid".as("aliasPatientProblemUid"))
      .withColumn("PatientProblemUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientProblemUid_CacheProblem = cleanedCacheProblem.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.CodeUid" === $"df2.CodeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*")

    if (where_PatientProblemUid_CacheProblem.count > 0) {
      val ex = cleanedCacheProblem.except(where_PatientProblemUid_CacheProblem)
      cleanedCacheProblem = ex.union(update_PatientProblemUid_CacheProblem)
    }

    logger.warn("Update PatientProblemUid of CacheProblem using PatientProblem_Prod table is Done............")

    //Update PatientProblemUid of CacheProblem using PatientProblem_Prod table 2

    val update_PatientProblemUid_CacheProblem2 = cleanedCacheProblem.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ProblemCode" === $"df2.PracticeCode")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*", $"df2.PatientProblemUid".as("aliasPatientProblemUid"))
      .withColumn("PatientProblemUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientProblemUid_CacheProblem2 = cleanedCacheProblem.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ProblemCode" === $"df2.PracticeCode")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*")

    if (where_PatientProblemUid_CacheProblem2.count > 0) {
      val ex = cleanedCacheProblem.except(where_PatientProblemUid_CacheProblem2)
      cleanedCacheProblem = ex.union(update_PatientProblemUid_CacheProblem2)
    }

    logger.warn("Update PatientProblemUid of CacheProblem using PatientProblem_Prod table 2 is Done............")

    //Update PatientProblemUid of CacheProblem using PatientProblem_Prod table 3

    val update_PatientProblemUid_CacheProblem3 = cleanedCacheProblem.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ProblemText" === $"df2.Description")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull && $"df1.Problemcode".isNull &&
        $"df2.PracticeCode".isNull)
      .select($"df1.*", $"df2.PatientProblemUid".as("aliasPatientProblemUid"))
      .withColumn("PatientProblemUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientProblemUid_CacheProblem3 = cleanedCacheProblem.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ProblemText" === $"df2.Description")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull && $"df1.Problemcode".isNull &&
        $"df2.PracticeCode".isNull)
      .select($"df1.*")

    if (where_PatientProblemUid_CacheProblem3.count > 0) {
      val ex = cleanedCacheProblem.except(where_PatientProblemUid_CacheProblem3)
      cleanedCacheProblem = ex.union(update_PatientProblemUid_CacheProblem3)
    }
    logger.warn("Update PatientProblemUid of CacheProblem using PatientProblem_Prod table 3 is Done............")

    //find Duplicates record

    var cleanedCacheProblem2 = cleanedCacheProblem.filter($"StatusId" === 1)
      .dropDuplicates(Seq("VisitUid", "CodeUid", "DocumentationDate"))

    val duplicatesRecordsCacheProblem3 = cleanedCacheProblem.except(cleanedCacheProblem2)

    duplicatesRecordsCacheProblem1 = duplicatesRecordsCacheProblem3.union(duplicatesRecordsCacheProblem3)

    logger.warn("find Duplicates record 2 is Done............")

    //create #Problem

    val tempProblem21 = cleanedCacheProblem2.filter($"StatusId" === 1 && $"PatientProblemUid".isNull)
      .select("PatientUid", "CodeUid").distinct()
      .withColumn("PatientProblemUid", FunctionUtility.getNewUid())

    //Update New PatientProblemUid of CacheProblem Table Using #Problem Table

    val update_PatientPUid_CacheProblem = cleanedCacheProblem2.as("df1").join(tempProblem21.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.CodeUid" === $"df2.CodeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull && $"df1.CodeUid".isNull)
      .select($"df1.*", $"df2.PatientProblemUid".as("aliasPatientProblemUid"))
      .withColumn("PatientProblemUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientPUid_CacheProblem = cleanedCacheProblem2.as("df1").join(tempProblem21.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.CodeUid" === $"df2.CodeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*")

    if (where_PatientPUid_CacheProblem.count > 0) {
      val ex = cleanedCacheProblem2.except(where_PatientPUid_CacheProblem)
      cleanedCacheProblem2 = ex.union(update_PatientPUid_CacheProblem)
    }
    logger.warn("Update New PatientProblemUid of CacheEncounterDiagnosis Table Using #Problem Table is Done............")

    //create #Problem1
    val tempProblem22 = cleanedCacheProblem2.filter($"StatusId" === 1 && $"PatientProblemUid".isNull
      && $"ProblemCode".isNotNull)
      .select("PatientUid", "ProblemCode").distinct()
      .withColumn("PatientProblemUid", FunctionUtility.getNewUid())

    //Update New PatientProblemUid of CacheProblem Table Using #Problem1 Table
    val update_PatientPUid_CacheProblem2 = cleanedCacheProblem2.as("df1").join(tempProblem22.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ProblemCode" === $"df2.ProblemCode")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*", $"df2.PatientProblemUid".as("aliasPatientProblemUid"))
      .withColumn("PatientProblemUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientPUid_CacheProblem2 = cleanedCacheProblem2.as("df1").join(tempProblem22.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ProblemCode" === $"df2.ProblemCode")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*")

    if (where_PatientPUid_CacheProblem2.count > 0) {
      val ex = cleanedCacheProblem2.except(where_PatientPUid_CacheProblem2)
      cleanedCacheProblem2 = ex.union(update_PatientPUid_CacheProblem2)
    }
    logger.warn("Update New PatientProblemUid of CacheProblem Table Using #Problem1 Table is Done............")

    //create #Problem2
    val tempProblem23 = cleanedCacheProblem2.filter($"StatusId" === 1 && $"PatientProblemUid".isNull
      && $"problemcode".isNotNull)
      .select("PatientUid", "ProblemText").distinct()
      .withColumn("PatientProblemUid", FunctionUtility.getNewUid())

    //Update New PatientProblemUid of CacheProblem Table Using #Problem2 Table
    val update_PatientPUid_CacheProblem3 = cleanedCacheProblem2.as("df1").join(tempProblem23.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ProblemText" === $"df2.ProblemText")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*", $"df2.PatientProblemUid".as("aliasPatientProblemUid"))
      .withColumn("PatientProblemUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_PatientPUid_CacheProblem3 = cleanedCacheProblem2.as("df1").join(tempProblem23.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ProblemText" === $"df2.ProblemText")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemUid".isNull)
      .select($"df1.*")

    if (where_PatientPUid_CacheProblem3.count > 0) {
      val ex = cleanedCacheProblem2.except(where_PatientPUid_CacheProblem3)
      cleanedCacheProblem2 = ex.union(update_PatientPUid_CacheProblem3)
    }
    logger.warn("Update New PatientProblemUid of CacheProblem Table Using #Problem2 Table is Done............")

    val update_PatientProblem_CacheProblem32 = cleanedCacheProblem2.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientProblemUid" === $"df2.PatientProblemUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.NegationInd".as("aliasNegationInd"), $"df2.ProblemComment".as("aliasProblemComment"))
      .withColumn("NegationInd", $"aliasNegationInd").withColumn("ProblemComment", $"aliasProblemComment")
      .drop("aliasNegationInd").drop("aliasProblemComment")

    val where_PatientProblem_CacheProblem3 = cleanedCacheProblem2.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientProblemUid" === $"df2.PatientProblemUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientProblem_CacheProblem3.count > 0) {
      val ex = cleanedCacheProblem2.except(where_PatientProblem_CacheProblem3)
      cleanedCacheProblem2 = ex.union(update_PatientProblem_CacheProblem32)
    }
    logger.warn("Update PatientProblem from for older records of CacheProblem Table Using #PatientProblem_Prod Table is Done............")

    //Insert Data Into ProblemPatient_CacheProblem
    val insert_data_ProblemPatient_CacheProblem = cleanedCacheProblem2.as("df1").join(PatientProblem_Prod.as("df2")
      , $"df1.PatientProblemUid" === $"df2.PatientProblemUid", "left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.PatientProblemUid".isNull)
      .select($"df1.PatientProblemUid", $"df1.PatientUid", $"df1.CodeUid", $"df1.ProblemCode"
        , $"df1.ProblemText", $"df1.NegationInd", $"df1.ProblemComment", $"df1.ProblemCategory").distinct()
      .groupBy($"PatientProblemUid", $"PatientUid", $"CodeUid")
      .agg(max($"ProblemText").as("PracticeDescription"), max($"NegationInd").as("NegationInd")
        , max($"ProblemComment").as("ProblemComment"), max($"ProblemText").as("PracticeDescription"), max($"ProblemCategory").as("CodeSystem"))
    //column and union
    logger.warn("Insert data into PatientProblem table Using CacheProblem table is Done............")

    //Update Status if DocumentationDate is null Of CacheProblem table
    val update_Status_CacheProblem323 = cleanedCacheProblem2.filter($"StatusId" === 1 && $"DocumentationDate".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Problem  Documentation date not found"))

    val whereStatus_CacheProblem323 = cleanedCacheProblem2.filter($"StatusId" === 1 && $"DocumentationDate".isNull)

    if (whereStatus_CacheProblem323.count > 0) {
      val ex = cleanedCacheProblem2.except(whereStatus_CacheProblem323)
      cleanedCacheProblem2 = ex.union(update_Status_CacheProblem323)
    }
    logger.warn("Update Status if DocumentationDate is null Of CacheProblem table is Done............")

    //Update PatientProblemHistoryUid of CacheProblem using PatientProblemHistory_Prod table
    val update_PatientPHistoryUid_CacheProblem = cleanedCacheProblem2.as("df1").join(PatientProblemHistory_Prod_Delta.as("df2")
      , $"df1.PatientProblemUid" === $"df2.PatientProblemUid" && $"df1.DocumentationDate" === $"df2.DocumentationDate")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemHistoryUid".isNull)
      .select($"df1.*", $"df2.PatientProblemHistoryUid".as("aliasPatientProblemHistoryUid"))
      .withColumn("PatientProblemHistoryUid", $"aliasPatientProblemHistoryUid")
      .drop("aliasPatientProblemHistoryUid")

    val where_PatientPHistoryUid_CacheProblem = cleanedCacheProblem2.as("df1").join(PatientProblemHistory_Prod_Delta.as("df2")
      , $"df1.PatientProblemUid" === $"df2.PatientProblemUid" && $"df1.DocumentationDate" === $"df2.DocumentationDate")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemHistoryUid".isNull)
      .select($"df1.*")

    if (where_PatientPHistoryUid_CacheProblem.count > 0) {
      val ex = cleanedCacheProblem2.except(where_PatientPHistoryUid_CacheProblem)
      cleanedCacheProblem2 = ex.union(update_PatientPHistoryUid_CacheProblem)
    }
    logger.warn("Update PatientProblemHistoryUid of CacheProblem using PatientProblemHistory_Prod table is Done............")

    //create #ProblemHistory
    val tempProblemHistory = cleanedCacheProblem2.filter($"StatusId" === 1 && $"PatientProblemHistoryUid".isNull)
      .select("PatientProblemUid", "DocumentationDate").distinct()
      .withColumn("PatientProblemHistoryUid", FunctionUtility.getNewUid())

    //Update New PatientProblemHistoryUid of CacheProblem Table Using #ProblemHistory Table
    val update_PatientPHUID_CacheProblem = cleanedCacheProblem2.as("df1").join(tempProblemHistory.as("df2")
      , $"df1.PatientProblemUid" === $"df2.PatientProblemUid" && $"df1.DocumentationDate" === $"df2.DocumentationDate")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemHistoryUid".isNull)
      .select($"df1.*", $"df2.PatientProblemHistoryUid".as("aliasPatientProblemHistoryUid"))
      .withColumn("PatientProblemHistoryUid", $"aliasPatientProblemHistoryUid")
      .drop("aliasPatientProblemHistoryUid")

    val where_PatientPHUID_CacheProblem = cleanedCacheProblem2.as("df1").join(tempProblemHistory.as("df2")
      , $"df1.PatientProblemUid" === $"df2.PatientProblemUid" && $"df1.DocumentationDate" === $"df2.DocumentationDate")
      .filter($"df1.StatusId" === 1 && $"df1.PatientProblemHistoryUid".isNull)
      .select($"df1.*")

    if (where_PatientPHUID_CacheProblem.count > 0) {
      val ex = cleanedCacheProblem2.except(where_PatientPHUID_CacheProblem)
      cleanedCacheProblem2 = ex.union(update_PatientPHUID_CacheProblem)
    }
    logger.warn("Update New PatientProblemHistoryUid of CacheProblem Table Using #ProblemHistory Table is Done............")

    //update CacheProblemTypeCodeUid of CacheProblem using MappingPracticeCommon
    val update_CacheProblemTypeCodeUid = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemTypeCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "163219CF-A146-4869-9354-DA8A65F8DBB0")
      .where($"df1.StatusId" === 1 && $"df1.ProblemTypeCodeUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ProblemTypeCodeUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_CacheProblemTypeCodeUid = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemTypeCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "163219CF-A146-4869-9354-DA8A65F8DBB0")
      .where($"df1.StatusId" === 1 && $"df1.ProblemTypeCodeUid".isNull)
      .select($"df1.*")

    if (where_CacheProblemTypeCodeUid.count > 0) {
      val ex = cleanedCacheProblem2.except(where_CacheProblemTypeCodeUid)
      cleanedCacheProblem2 = ex.union(update_CacheProblemTypeCodeUid)
    }
    logger.warn("update ProblemTypeCodeUid of CacheProblem using MappingPracticeCommon is Done....")

    //update CacheProblemTypeCodeUid of CacheProblem using MappingPracticeCommon
    val update_CacheProblemTypeCodeUid2 = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemTypeText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "163219CF-A146-4869-9354-DA8A65F8DBB0")
      .where($"df1.StatusId" === 1 && $"df1.ProblemTypeCodeUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ProblemTypeCodeUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_CacheProblemTypeCodeUid2 = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemTypeText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "163219CF-A146-4869-9354-DA8A65F8DBB0")
      .where($"df1.StatusId" === 1 && $"df1.ProblemTypeCodeUid".isNull)
      .select($"df1.*")

    if (where_CacheProblemTypeCodeUid2.count > 0) {
      val ex = cleanedCacheProblem2.except(where_CacheProblemTypeCodeUid2)
      cleanedCacheProblem2 = ex.union(update_CacheProblemTypeCodeUid2)
    }
    logger.warn("update ProblemTypeCodeUid of CacheProblem using MappingPracticeCommon is Done....")

    //update ProblemTypeCodeUid of CacheProblem using Master table
    val update_CacheProblemTypeCodeUid3 = cleanedCacheProblem2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemTypeCode" === $"df2.Code" || $"df1.ProblemTypeText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemTypeCodeUid".isNull && $"df2.Type" === "ProblemType")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("ProblemTypeCode", $"aliasMasterUid").drop("aliasMasterUid")

    val where_CacheProblemTypeCodeUid3 = cleanedCacheProblem2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemTypeCode" === $"df2.Code" || $"df1.ProblemTypeText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemTypeCodeUid".isNull && $"df2.Type" === "ProblemType")
      .select($"df1.*")

    if (where_CacheProblemTypeCodeUid3.count > 0) {
      val ex = cleanedCacheProblem2.except(where_CacheProblemTypeCodeUid3)
      cleanedCacheProblem2 = ex.union(update_CacheProblemTypeCodeUid3)
    }
    logger.warn("update CacheProblemTypeCodeUid of CacheProblem using Master table is Done....")

    //Update Status if CacheProblemTypeCode is not Null  Of CacheProblem table
    val update_Status_CacheProblem3234 = cleanedCacheProblem2.filter($"StatusId" === 1
      && rtrim(ltrim($"ProblemTypeCode")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ProblemTypeCode Not Mapped"))

    val whereStatus_CacheProblem3234 = cleanedCacheProblem2.filter($"StatusId" === 1
      && (rtrim(ltrim($"ProblemTypeCode")).isNotNull || rtrim(ltrim($"ProblemTypeText")).isNotNull))

    if (whereStatus_CacheProblem3234.count > 0) {
      val ex = cleanedCacheProblem2.except(whereStatus_CacheProblem3234)
      cleanedCacheProblem2 = ex.union(update_Status_CacheProblem3234)
    }
    logger.warn("Update Status if ProblemTypeCode is not Null Of CacheProblem table is Done............")

    //update ProblemHealthStatusUid of CacheProblem using MappingPracticeCommonData
    val update_ProblemHealthStatusUid_CacheProblem = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemHealthStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "0D033BD1-0523-4823-BE7A-2E83C2D3866B")
      .where($"df1.StatusId" === 1 && $"df1.ProblemHealthStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ProblemHealthStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_ProblemHealthStatusUid_CacheProblem = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemHealthStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "0D033BD1-0523-4823-BE7A-2E83C2D3866B")
      .where($"df1.StatusId" === 1 && $"df1.ProblemHealthStatusUid".isNull)
      .select($"df1.*")

    if (where_ProblemHealthStatusUid_CacheProblem.count > 0) {
      val ex = cleanedCacheProblem2.except(where_ProblemHealthStatusUid_CacheProblem)
      cleanedCacheProblem2 = ex.union(update_ProblemHealthStatusUid_CacheProblem)
    }
    logger.warn("update ProblemHealthStatusUid of CacheProblem using MappingPracticeCommonData is Done............")

    //update ProblemHealthStatusUid of CacheProblem using MappingPracticeCommonData 2
    val update_ProblemHealthStatusUid_CacheProblem2 = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemHealthStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "0D033BD1-0523-4823-BE7A-2E83C2D3866B")
      .where($"df1.StatusId" === 1 && $"df1.ProblemHealthStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ProblemHealthStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_ProblemHealthStatusUid_CacheProblem2 = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemHealthStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "0D033BD1-0523-4823-BE7A-2E83C2D3866B")
      .where($"df1.StatusId" === 1 && $"df1.ProblemHealthStatusUid".isNull)
      .select($"df1.*")

    if (where_ProblemHealthStatusUid_CacheProblem2.count > 0) {
      val ex = cleanedCacheProblem2.except(where_ProblemHealthStatusUid_CacheProblem2)
      cleanedCacheProblem2 = ex.union(update_ProblemHealthStatusUid_CacheProblem2)
    }
    logger.warn("update ProblemHealthStatusUid of CacheProblem using MappingPracticeCommonData 2 is Done............")

    //update ProblemHealthStatusUid of CacheProblem using Master table
    val update_ProblemHealthStatusUid_CacheProblem3 = cleanedCacheProblem2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemHealthStatusCode" === $"df2.Code" || $"df1.ProblemHealthStatusText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemHealthStatusUid".isNull && $"df2.Type" === "ProblemHealthStatus")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("ProblemHealthStatusUid", $"aliasMasterUid")
      .withColumn("ErrorNote", lit("null"))
      .drop("aliasMasterUid")

    val where_ProblemHealthStatusUid_CacheProblem3 = cleanedCacheProblem2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemHealthStatusCode" === $"df2.Code" || $"df1.ProblemHealthStatusText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemHealthStatusUid".isNull && $"df2.Type" === "ProblemHealthStatus")
      .select($"df1.*")


    if (where_ProblemHealthStatusUid_CacheProblem3.count > 0) {
      val ex = cleanedCacheProblem2.except(where_ProblemHealthStatusUid_CacheProblem3)
      cleanedCacheProblem2 = ex.union(update_ProblemHealthStatusUid_CacheProblem3)
    }
    logger.warn("update ProblemHealthStatusUid of CacheProblem using Master table is Done............")

    //Update Status if ProblemHealthStatusCode is not Null OR ProblemHealthStatusText is not Null Of CacheProblem table
    val update_Status_CacheProblem33 = cleanedCacheProblem2.filter($"StatusId" === 1
      && rtrim(ltrim($"ProblemHealthStatusCode")).isNotNull || rtrim(ltrim($"ProblemHealthStatusText")).isNotNull
      && $"ProblemHealthStatusUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ProblemHealthStatusCode Not Mapped"))

    val whereStatus_CacheProblem33 = cleanedCacheProblem2.filter($"StatusId" === 1
      && rtrim(ltrim($"ProblemHealthStatusCode")).isNotNull || rtrim(ltrim($"ProblemHealthStatusText")).isNotNull
      && $"ProblemHealthStatusUid".isNull)

    if (whereStatus_CacheProblem33.count > 0) {
      val ex = cleanedCacheProblem2.except(whereStatus_CacheProblem33)
      cleanedCacheProblem2 = ex.union(update_Status_CacheProblem33)
    }
    logger.warn("Update Status if ProblemHealthStatusCode is not Null OR ProblemHealthStatusText is not Null Of CacheProblem table is Done......")

    //update ProblemStatusUid from MappingPracticeCommonData of CacheProblem
    val update_ProblemStatusUid_CacheProblem = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "91AC99A5-71CD-44AE-9B1B-21211FB71099")
      .where($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ProblemStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_ProblemStatusUid_CacheProblem = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "91AC99A5-71CD-44AE-9B1B-21211FB71099")
      .where($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull)
      .select($"df1.*")

    if (where_ProblemStatusUid_CacheProblem.count > 0) {
      val ex = cleanedCacheProblem2.except(where_ProblemStatusUid_CacheProblem)
      cleanedCacheProblem2 = ex.union(update_ProblemStatusUid_CacheProblem)
    }
    logger.warn("update ProblemStatusUid from MappingPracticeCommonData of CacheProblem is Done......")

    //update ProblemStatusUid from MappingPracticeCommonData of CacheProblem 2
    val update_ProblemStatusUid_CacheProblem2 = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "91AC99A5-71CD-44AE-9B1B-21211FB71099")
      .where($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ProblemStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_ProblemStatusUid_CacheProblem2 = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.ProblemStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "91AC99A5-71CD-44AE-9B1B-21211FB71099")
      .where($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull)
      .select($"df1.*")

    if (where_ProblemStatusUid_CacheProblem2.count > 0) {
      val ex = cleanedCacheProblem2.except(where_ProblemStatusUid_CacheProblem2)
      cleanedCacheProblem2 = ex.union(update_ProblemStatusUid_CacheProblem2)
    }
    logger.warn("update ProblemStatusUid from MappingPracticeCommonData of CacheProblem 2 is Done......")

    //update ProblemStatusUid of CacheProblem using Master table
    val update_ProblemStatusUid_CacheProblem3 = cleanedCacheProblem2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemStatusCode" === $"df2.Code")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull && $"df2.Type" === "ProblemStatus"
        && $"df1.ProblemStatusText".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("ProblemStatusUid", $"aliasMasterUid")
      .withColumn("ErrorNote", lit("null"))
      .drop("aliasMasterUid")

    val where_ProblemStatusUid_CacheProblem3 = cleanedCacheProblem2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemStatusCode" === $"df2.Code")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull && $"df2.Type" === "ProblemStatus"
        && $"df1.ProblemStatusText".isNull)
      .select($"df1.*")

    if (where_ProblemStatusUid_CacheProblem3.count > 0) {
      val ex = cleanedCacheProblem2.except(where_ProblemStatusUid_CacheProblem3)
      cleanedCacheProblem2 = ex.union(update_ProblemStatusUid_CacheProblem3)
    }
    logger.warn("update ProblemStatusUid of CacheProblem using Master table is Done......")

    //update ProblemStatusUid of CacheProblem using Master table 2
    val update_ProblemStatusUid_CacheProblem4 = cleanedCacheProblem2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemStatusText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull && $"df2.Type" === "ProblemStatus"
        && $"df1.ProblemStatusCode".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("ProblemStatusUid", $"aliasMasterUid")
      .withColumn("ErrorNote", lit("null"))
      .drop("aliasMasterUid")

    val where_ProblemStatusUid_CacheProblem4 = cleanedCacheProblem2.as("df1").join(Master_prod.as("df2"),
      $"df1.ProblemStatusText" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ProblemStatusUid".isNull && $"df2.Type" === "ProblemStatus"
        && $"df1.ProblemStatusCode".isNull)
      .select($"df1.*")

    if (where_ProblemStatusUid_CacheProblem4.count > 0) {
      val ex = cleanedCacheProblem2.except(where_ProblemStatusUid_CacheProblem4)
      cleanedCacheProblem2 = ex.union(update_ProblemStatusUid_CacheProblem4)
    }
    logger.warn("update ProblemStatusUid of CacheProblem using Master table 2 is Done......")

    //Update Status if ProblemStatusCode is not Null OR ProblemStatusText is not Null Of CacheProblem table
    val update_Status_CacheProblem337 = cleanedCacheProblem2.filter($"StatusId" === 1
      && rtrim(ltrim($"ProblemStatusCode")).isNotNull || rtrim(ltrim($"ProblemStatusText")).isNotNull
      && $"ProblemStatusUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ProblemStatusCode Not Mapped"))

    val where_Status_CacheProblem337 = cleanedCacheProblem2.filter($"StatusId" === 1
      && rtrim(ltrim($"ProblemStatusCode")).isNotNull || rtrim(ltrim($"ProblemStatusText")).isNotNull
      && $"ProblemStatusUid".isNull)

    if (where_Status_CacheProblem337.count > 0) {
      val ex = cleanedCacheProblem2.except(where_Status_CacheProblem337)
      cleanedCacheProblem2 = ex.union(update_Status_CacheProblem337)
    }
    logger.warn("Update Status if ProblemStatusCode is not Null OR ProblemStatusText is not Null Of CacheProblem table is Done......")

    //update TargetSiteUid from MappingPracticeCommonData of CacheProblem
    val update_TargetSiteUid_CacheProblem = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.TargetSiteCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .where($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("TargetSiteUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_TargetSiteUid_CacheProblem = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.TargetSiteCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .where($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull)
      .select($"df1.*")

    if (where_TargetSiteUid_CacheProblem.count > 0) {
      val ex = cleanedCacheProblem2.except(where_TargetSiteUid_CacheProblem)
      cleanedCacheProblem2 = ex.union(update_TargetSiteUid_CacheProblem)
    }
    logger.warn("update TargetSiteUid from MappingPracticeCommonData of CacheProblem is Done......")

    //update TargetSiteUid from MappingPracticeCommonData of CacheProblem 2
    val update_TargetSiteUid_CacheProblem2 = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.TargetSiteText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .where($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("TargetSiteUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_TargetSiteUid_CacheProblem2 = cleanedCacheProblem2.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.TargetSiteText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .where($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull)
      .select($"df1.*")

    if (where_TargetSiteUid_CacheProblem2.count > 0) {
      val ex = cleanedCacheProblem2.except(where_TargetSiteUid_CacheProblem2)
      cleanedCacheProblem2 = ex.union(update_TargetSiteUid_CacheProblem2)
    }
    logger.warn("update TargetSiteUid from MappingPracticeCommonData of CacheProblem 2 is Done......")

    //Update TargetSiteUid from Master Table of CacheProblem
    val update_TargetSiteUid_CacheProblem3 = cleanedCacheProblem2.as("df1").join(Master_prod.as("df2"),
      $"df1.TargetSiteCode" === $"df2.Code")
      .filter($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull && $"df2.Type" === "TargetSite")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("TargetSiteUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_TargetSiteUid_CacheProblem3 = cleanedCacheProblem2.as("df1").join(Master_prod.as("df2"),
      $"df1.TargetSiteCode" === $"df2.Code")
      .filter($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull && $"df2.Type" === "TargetSite")
      .select($"df1.*")

    if (where_TargetSiteUid_CacheProblem3.count > 0) {
      val ex = cleanedCacheProblem2.except(where_TargetSiteUid_CacheProblem3)
      cleanedCacheProblem2 = ex.union(update_TargetSiteUid_CacheProblem3)
    }
    logger.warn("Update TargetSiteUid from Master Table of CacheProblem is Done......")

    //Update TargetSiteUid from Master Table of CacheProblem 2
    val update_TargetSiteUid_CacheProblem4 = cleanedCacheProblem2.as("df1").join(Master_prod.as("df2"),
      $"df1.TargetSiteText" === $"df2.Code")
      .filter($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull && $"df2.Type" === "TargetSite")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("TargetSiteUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_TargetSiteUid_CacheProblem4 = cleanedCacheProblem2.as("df1").join(Master_prod.as("df2"),
      $"df1.TargetSiteText" === $"df2.Code")
      .filter($"df1.StatusId" === 1 && $"df1.TargetSiteUid".isNull && $"df2.Type" === "TargetSite")
      .select($"df1.*")

    if (where_TargetSiteUid_CacheProblem4.count > 0) {
      val ex = cleanedCacheProblem2.except(where_TargetSiteUid_CacheProblem4)
      cleanedCacheProblem2 = ex.union(update_TargetSiteUid_CacheProblem4)
    }
    logger.warn("Update TargetSiteUid from Master Table of CacheProblem 2 is Done......")

    //Update PatientProblemHistory Table CacheProblem
    val update_PatientProblemHistory_Table_CacheProblem = PatientProblemHistory_Prod_Delta.as("df1").join(cleanedCacheProblem2.as("df2")
      ,$"df1.PatientProblemHistoryUid" === $"df2.PatientProblemHistoryUid").filter($"df2.StatusId" === 1)
      .select($"df1.*",$"df2.ProblemResolutionDate".as("aliasPRDate"),$"df2.ProblemTypeCodeUid"
        .as("aliasEPTCUid"),$"df2.ProblemHealthStatusUid".as("aliasPHSUid"),$"df2.ProblemStatusUid".as("aliasPSUid"),
        $"df2.TargetSiteUid".as("aliasTSUid"),$"df2.TargetSiteCode".as("aliasTSCUid"), $"df2.TargetSiteText".as("aliasTSText") )
      .withColumn("ResolutionDate",$"aliasPRDate")
      .withColumn("MasterProblemTypeUid",$"aliasEPTCUid")
      .withColumn("masterProblemStatusUid",$"aliasEPTSCUid")
      .withColumn("MasterProblemHealthStatusUid",$"aliasEPHTSCUid")
      .withColumn("TargetSiteUid",$"aliasTSUid")
      .withColumn("TargetSiteCode",$"aliasTSCode")
      .withColumn("TargetSiteText",$"aliasTText")
      .withColumn("ModifiedDate",current_timestamp())
      .drop("aliasPRDate","aliasEPTCUid","aliasEPTSCUid","aliasEPHTSCUid","aliasTSUid","aliasTSCode","aliasTText")

   val where_PatientProblemHistory  = PatientProblemHistory_Prod_Delta.as("df1").join(cleanedCacheProblem2.as("df2")
     ,$"df1.PatientProblemHistoryUid" === $"df2.PatientProblemHistoryUid").filter($"df2.StatusId" === 1)
     .select($"df1.*")

    val ex_PatientProblemHistory = PatientProblemHistory_Prod_Delta.except(where_PatientProblemHistory)
    var PatientProblemHistory_Prod_Delta1 = ex_PatientProblemHistory.union(update_PatientProblemHistory_Table_CacheProblem)

    logger.warn("Update PatientProblemHistory Table 2 is Done......")

    //Insert Data Into PatientProblemHistory CacheProblem
    val insert_PatientProblemHistory = cleanedCacheProblem2.as("df1").join(PatientProblemHistory_Prod_Delta1.as("df2")
      ,$"df1.PatientProblemHistoryUid" === $"df2.PatientProblemHistoryUid","left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.PatientProblemHistoryUid".isNull)
      .select($"df1.PatientProblemHistoryUid",$"df1.PatientProblemUid",$"df1.DocumentationDate"
        ,$"df1.ProblemResolutionDate",$"df1.ProblemTypeCodeUid".as("MasterProblemTypeUid")
        ,$"df1.ProblemHealthStatusUid",$"df1.ProblemStatusUid",$"df1.ProblemOnsetDate",$"df1.TargetSiteCode",$"df1.TargetSiteText",$"df1.TargetSiteUid")
      .groupBy($"PatientProblemHistoryUid",$"PatientProblemUid",$"DocumentationDate",$"MasterProblemTypeUid"
        ,$"ProblemHealthStatusUid",$"ProblemStatusUid",$"ProblemOnsetDate",$"TargetSiteCode",$"TargetSiteText",$"TargetSiteUid")
      .agg(max($"ProblemResolutionDate")).as("ResolutionDate")

    val PatientPHistory_allcols = PatientProblemHistory_Prod_Delta1.columns.toSet
    val insert_PatientPHistory_cols = insert_PatientProblemHistory.columns.toSet
    val tot_cols = PatientPHistory_allcols ++ insert_PatientPHistory_cols

    PatientProblemHistory_Prod_Delta1 = PatientProblemHistory_Prod_Delta1.select(FunctionUtility.addColumns(PatientPHistory_allcols, tot_cols): _*)
      .union(insert_PatientProblemHistory.select(FunctionUtility.addColumns(insert_PatientPHistory_cols, tot_cols): _*))



    logger.warn("Insert Data Into PatientProblemHistory_CacheProblem is Done......")



    //End CacheProblem Sp..........................................



    List(PatientProblemHistory_Prod_Delta1)
  }

}
