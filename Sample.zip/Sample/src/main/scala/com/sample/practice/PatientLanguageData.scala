package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory

class PatientLanguageData {

  def PatientLanguageDataFunc(spark : SparkSession,MergePracticeMap : DataFrame
                              ,CDRPatientCrosswalkTable : DataFrame
                              ,Master_prod : DataFrame
                              ,PatientLanguage_Prod : DataFrame
                              ,MappingPracticeCommonData_Delta : DataFrame
                              ,Patient_Prod_Delta : DataFrame
                              ,Individual_prod_Delta6 : DataFrame) : List[DataFrame] = {

    val logger = LoggerFactory.getLogger("")

    import spark.implicits._

    //Start ImportPatientLanguageData

    var CachePatientLanguage =  spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9")

    val lookup11 = Map("_c0" -> "PatientId", "_c1" -> "LanguageCode", "_c2" -> "LanguageText"
      , "_c3" -> "LangaugeAbilityModeCode", "_c4" -> "LangaugeAbilityModeText", "_c5" -> "LanguageProficiencyLevelCode"
      , "_c6" -> "LanguageProficiencyLevelText", "_c7" -> "IsPreferred", "_c8" -> "PatientLanguageKey"
      , "_c9" -> "PracticeUid", "_c10" -> "BatchUid", "_c11" -> "dummy1"
      , "_c12" -> "dummy2")

    CachePatientLanguage = CachePatientLanguage.select(CachePatientLanguage.columns.map(c => col(c).as(lookup11.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    val tempCachePatientLanguage = spark.read.option("header", "true")
      .csv("/home/gajanan.doifode/AAO_DATA/Schema/CachePatientLanguage.txt")

    val CachePLanguageAllcols = tempCachePatientLanguage.columns.toSet
    val CachePLanguageViewcols = CachePatientLanguage.columns.toSet
    val tot_viewCPL_cachePLang = CachePLanguageAllcols ++ CachePLanguageViewcols

    CachePatientLanguage = tempCachePatientLanguage.select(FunctionUtility.addColumns(CachePLanguageAllcols, tot_viewCPL_cachePLang): _*)
      .union(CachePatientLanguage.select(FunctionUtility.addColumns(CachePLanguageViewcols, tot_viewCPL_cachePLang): _*))

    CachePatientLanguage = CachePatientLanguage.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    val dist_PUID_PatLang = CachePatientLanguage.filter($"StatusId".isNull).select("PracticeUid").distinct()

    val MergePracticeMap_PatLang = MergePracticeMap.as("df1").join(dist_PUID_PatLang.as("df2")
      , $"df1.NewPracticeUid" === $"df2.PracticeUid").select($"df1.*")

    logger.warn("MergePracticeMap_PatLang is Created is Done......")

    //Update PracticeUid with OriginalPracticeUid of CachePatientLanguage
    CachePatientLanguage = CachePatientLanguage.as("df1").join(MergePracticeMap_PatLang.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeUid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeUid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeUid of CachePatientLanguage is Done.................")

    CachePatientLanguage = CachePatientLanguage.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CachePatientLanguage
    CachePatientLanguage = CachePatientLanguage.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PatientId", ltrim(rtrim($"df1.PatientId")))
      .withColumn("LanguageCode", ltrim(rtrim($"df1.LanguageCode")))
      .withColumn("LanguageText", ltrim(rtrim($"df1.LanguageText")))

    logger.warn("Update Multiple Columns of CachePatientLanguage is Done............")

    //update status if PatientId is null Of CachePatientLanguage
    val update_status_PatLang = CachePatientLanguage.filter($"StatusId" === 1 && $"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val where_status_PatLang = CachePatientLanguage.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_status_PatLang.count > 0) {
      val ex = CachePatientLanguage.except(where_status_PatLang)
      CachePatientLanguage = ex.union(update_status_PatLang)
    }

    logger.warn("update status if PatientId is null Of CachePatientLanguage is Done........")

    //update status if LanguageCode & LanguageText is null Of CachePatientLanguage
    val update_status_PatLang2 = CachePatientLanguage.filter($"StatusId" === 1 && $"LanguageCode".isNull
      && $"LanguageText".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("LanguageCode/LanguageText is Null"))

    val where_status_PatLang2 = CachePatientLanguage.filter($"StatusId" === 1 && $"LanguageCode".isNull
      && $"LanguageText".isNull)

    if (where_status_PatLang2.count > 0) {
      val ex = CachePatientLanguage.except(where_status_PatLang2)
      CachePatientLanguage = ex.union(update_status_PatLang2)
    }

    logger.warn("update status if LanguageCode & LanguageText is null Of CachePatientLanguage is Done........")

    //Update PatientId using CDRPatientCrosswalk Of CachePatientLanguage Table
    val update_PatientId_PatLang = CachePatientLanguage.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientId_PatLang = CachePatientLanguage.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientId_PatLang.count > 0) {
      val ex = CachePatientLanguage.except(where_PatientId_PatLang)
      CachePatientLanguage = ex.union(update_PatientId_PatLang)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk Of CachePatientLanguage Table is Done........")

    //update PatientUid Using Patient_prod && Individual_prod of CachePatientLanguage
    val update_PatientUid_PatLang = CachePatientLanguage.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta6.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientUid".isNull)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val where_PatientUid_PatLang = CachePatientLanguage.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta6.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientUid".isNull)
      .select($"df1.*")

    if (where_PatientUid_PatLang.count > 0) {
      val ex = CachePatientLanguage.except(where_PatientUid_PatLang)
      CachePatientLanguage = ex.union(update_PatientUid_PatLang)
    }

    logger.warn("Update PatientUid using CDRPatientCrosswalk Of CachePatientLanguage Table is Done........")


    //Update LanguageUid of CachePatientLanguage
    val update_LanguageUid = CachePatientLanguage.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.LanguageCode" === $"d2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "C3F65D3B-1D9A-4640-967F-2848461DC1AD")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageUid".isNull)
      .select($"df1.*",$"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("LanguageUid",$"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_LanguageUid = CachePatientLanguage.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.LanguageCode" === $"d2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "C3F65D3B-1D9A-4640-967F-2848461DC1AD")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageUid".isNull)
      .select($"df1.*")

    if (where_LanguageUid.count > 0) {
      val ex = CachePatientLanguage.except(where_LanguageUid)
      CachePatientLanguage = ex.union(update_LanguageUid)
    }

    logger.warn("Update LanguageUid of CachePatientLanguage is Done........")


    //Update LanguageUid of CachePatientLanguage 2
    val update_LanguageUid2 = CachePatientLanguage.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.LanguageText" === $"d2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "C3F65D3B-1D9A-4640-967F-2848461DC1AD")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageUid".isNull)
      .select($"df1.*",$"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("LanguageUid",$"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_LanguageUid2 = CachePatientLanguage.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.LanguageText" === $"d2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "C3F65D3B-1D9A-4640-967F-2848461DC1AD")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageUid".isNull)
      .select($"df1.*")

    if (where_LanguageUid2.count > 0) {
      val ex = CachePatientLanguage.except(where_LanguageUid2)
      CachePatientLanguage = ex.union(update_LanguageUid2)
    }

    logger.warn("Update LanguageUid of CachePatientLanguage is 2 Done........")

    //Update LanguageUid from Master Table of CachePatientLanguage
    val update_LanguageUid3 = CachePatientLanguage.as("df1").join(Master_prod.as("df2"),
      $"df1.LanguageText" === $"df2.Name" && $"df2.Type" === "Language")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("LanguageUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_LanguageUid3 = CachePatientLanguage.as("df1").join(Master_prod.as("df2"),
      $"df1.LanguageText" === $"df2.Name" && $"df2.Type" === "Language")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageUid".isNull)
      .select($"df1.*")

    if (where_LanguageUid3.count > 0) {
      val ex = CachePatientLanguage.except(where_LanguageUid3)
      CachePatientLanguage = ex.union(update_LanguageUid3)
    }

    logger.warn("Update LanguageUid from Master Table of CachePatientLanguage Done........")

    //Update LanguageUid from Master Table of CachePatientLanguage 2
    val update_LanguageUid4 = CachePatientLanguage.as("df1").join(Master_prod.as("df2"),
      $"df1.LanguageCode" === $"df2.Code" && $"df2.Type" === "Language")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("LanguageUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_LanguageUid4 = CachePatientLanguage.as("df1").join(Master_prod.as("df2"),
      $"df1.LanguageCode" === $"df2.Code" && $"df2.Type" === "Language")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageUid".isNull)
      .select($"df1.*")

    if (where_LanguageUid4.count > 0) {
      val ex = CachePatientLanguage.except(where_LanguageUid4)
      CachePatientLanguage = ex.union(update_LanguageUid4)
    }

    logger.warn("Update LanguageUid from Master Table of CachePatientLanguage 2 is Done........")
    //update status if PatientUid is null Of CachePatientLanguage
    val update_status_PatLang3 = CachePatientLanguage.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_status_PatLang3 = CachePatientLanguage.filter($"StatusId" === 1 && $"PatientUid".isNull)

    if (where_status_PatLang3.count > 0) {
      val ex = CachePatientLanguage.except(where_status_PatLang3)
      CachePatientLanguage = ex.union(update_status_PatLang3)
    }

    logger.warn("update status if PatientUid is null Of CachePatientLanguage is Done........")

    //update status if LanguageUid is null Of CachePatientLanguage
    val update_status_PatLang4 = CachePatientLanguage.filter($"StatusId" === 1 && $"LanguageUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Language Not Mapped"))

    val where_status_PatLang4 = CachePatientLanguage.filter($"StatusId" === 1 && $"LanguageUid".isNull)

    if (where_status_PatLang4.count > 0) {
      val ex = CachePatientLanguage.except(where_status_PatLang4)
      CachePatientLanguage = ex.union(update_status_PatLang4)
    }

    logger.warn("update status if LanguageUid is null Of CachePatientLanguage is Done........")


    //Update PatientLanguageUid using PatientLanguage of CachePatientLanguage
    val update_PatientLanguageUid = CachePatientLanguage.as("df1").join(PatientLanguage_Prod.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.LanguageUid" === $"df1.MasterLanguageUid")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageUid".isNotNull)
      .select($"df1.*",$"df2.PatientLanguageUid".as("aliasPLangUid"))
      .withColumn("PatientLanguageUid",$"aliasPLangUid")
      .drop("aliasPLangUid")

    val where_PatientLanguageUid = CachePatientLanguage.as("df1").join(PatientLanguage_Prod.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.LanguageUid" === $"df1.MasterLanguageUid")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageUid".isNotNull)
      .select($"df1.*")

    if (where_PatientLanguageUid.count > 0) {
      val ex = CachePatientLanguage.except(where_PatientLanguageUid)
      CachePatientLanguage = ex.union(update_PatientLanguageUid)
    }

    logger.warn("Update PatientLanguageUid using PatientLanguage of CachePatientLanguage is Done........")

    //Drop Duplicates records Of CachePatientLanguage
    var cleanedCachePatientLanguage = CachePatientLanguage.dropDuplicates(Seq("PatientUid", "LanguageUid"))
    val duplicateRecords_cleanedCachePatientLanguage = CachePatientLanguage.except(cleanedCachePatientLanguage)

    logger.warn("Drop Duplicates records Of CachePatientLanguage is Done........")

    //Update LanguageAbilityModeUid of CachePatientLanguage
    val update_LanguageAbilityModeUid = cleanedCachePatientLanguage.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.LangaugeAbilityModeCode" === $"d2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "C418FE8B-7C75-4114-B97E-CCFB6BA503F9")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageAbilityModeUid".isNull)
      .select($"df1.*",$"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("LanguageAbilityModeUid",$"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_LanguageAbilityModeUid = cleanedCachePatientLanguage.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.LangaugeAbilityModeCode" === $"d2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "C418FE8B-7C75-4114-B97E-CCFB6BA503F9")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageAbilityModeUid".isNull)
      .select($"df1.*")

    if (where_LanguageAbilityModeUid.count > 0) {
      val ex = cleanedCachePatientLanguage.except(where_LanguageAbilityModeUid)
      cleanedCachePatientLanguage = ex.union(update_LanguageAbilityModeUid)
    }

    logger.warn("Update LanguageAbilityModeUid of CachePatientLanguage is Done........")

    //Update LanguageAbilityModeUid of CachePatientLanguage 2
    val update_LanguageAbilityModeUid2 = cleanedCachePatientLanguage.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.LangaugeAbilityModeText" === $"d2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "C418FE8B-7C75-4114-B97E-CCFB6BA503F9")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageAbilityModeUid".isNull)
      .select($"df1.*",$"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("LanguageAbilityModeUid",$"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_LanguageAbilityModeUid2 = cleanedCachePatientLanguage.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.LangaugeAbilityModeText" === $"d2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "C418FE8B-7C75-4114-B97E-CCFB6BA503F9")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageAbilityModeUid".isNull)
      .select($"df1.*")

    if (where_LanguageAbilityModeUid2.count > 0) {
      val ex = cleanedCachePatientLanguage.except(where_LanguageAbilityModeUid2)
      cleanedCachePatientLanguage = ex.union(update_LanguageAbilityModeUid2)
    }

    logger.warn("Update LanguageAbilityModeUid of CachePatientLanguage 2 is Done........")

    //Update LanguageAbilityModeUid from Master Table of CachePatientLanguage
    val update_LanguageAbilityModeUid3 = cleanedCachePatientLanguage.as("df1").join(Master_prod.as("df2"),
      $"df1.LangaugeAbilityModeText" === $"df2.Name" && $"df2.Type" === "LanguageAbilityMode")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageAbilityModeUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("LanguageAbilityModeUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_LanguageAbilityModeUid3 = cleanedCachePatientLanguage.as("df1").join(Master_prod.as("df2"),
      $"df1.LangaugeAbilityModeText" === $"df2.Name" && $"df2.Type" === "LanguageAbilityMode")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageAbilityModeUid".isNull)
      .select($"df1.*")

    if (where_LanguageAbilityModeUid3.count > 0) {
      val ex = cleanedCachePatientLanguage.except(where_LanguageAbilityModeUid3)
      cleanedCachePatientLanguage = ex.union(update_LanguageAbilityModeUid3)
    }

    logger.warn("Update LanguageAbilityModeUid from Master Table of CachePatientLanguage Done........")

    //Update LanguageAbilityModeUid from Master Table of CachePatientLanguage 2
    val update_LanguageAbilityModeUid4 = cleanedCachePatientLanguage.as("df1").join(Master_prod.as("df2"),
      $"df1.LangaugeAbilityModeCode" === $"df2.Code" && $"df2.Type" === "LanguageAbilityMode")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageAbilityModeUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("LanguageAbilityModeUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_LanguageAbilityModeUid4 = cleanedCachePatientLanguage.as("df1").join(Master_prod.as("df2"),
      $"df1.LangaugeAbilityModeCode" === $"df2.Code" && $"df2.Type" === "LanguageAbilityMode")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageAbilityModeUid".isNull)
      .select($"df1.*")

    if (where_LanguageAbilityModeUid4.count > 0) {
      val ex = cleanedCachePatientLanguage.except(where_LanguageAbilityModeUid4)
      cleanedCachePatientLanguage = ex.union(update_LanguageAbilityModeUid4)
    }

    logger.warn("Update LanguageAbilityModeUid from Master Table of CachePatientLanguage 2 Done........")

    //update status if LanguageAbilityModeUid is null Of CachePatientLanguage
    val update_status_PatLang5 = cleanedCachePatientLanguage.filter($"StatusId" === 1 && $"LanguageAbilityModeUid".isNull
      && rtrim(ltrim($"LangaugeAbilityModeCode")).isNotNull || rtrim(ltrim($"LangaugeAbilityModeText")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Language Ability Mode Is Not Mapped"))

    val where_status_PatLang5 = cleanedCachePatientLanguage.filter($"StatusId" === 1 && $"LanguageAbilityModeUid".isNull
      && rtrim(ltrim($"LangaugeAbilityModeCode")).isNotNull || rtrim(ltrim($"LangaugeAbilityModeText")).isNotNull)

    if (where_status_PatLang5.count > 0) {
      val ex = cleanedCachePatientLanguage.except(where_status_PatLang5)
      cleanedCachePatientLanguage = ex.union(update_status_PatLang5)
    }

    logger.warn("update status if LanguageAbilityModeUid is null Of CachePatientLanguage Done........")

    //Update LanguageProficiencyLevelUid of CachePatientLanguage
    val update_LanguageProficiencyLevelUid = cleanedCachePatientLanguage.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.LanguageProficiencyLevelCode" === $"d2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "34421076-14B0-430A-AB22-0B5245CA8E6B")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageProficiencyLevelUid".isNull)
      .select($"df1.*",$"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("LanguageProficiencyLevelUid",$"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_LanguageProficiencyLevelUid = cleanedCachePatientLanguage.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.LanguageProficiencyLevelCode" === $"d2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "34421076-14B0-430A-AB22-0B5245CA8E6B")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageProficiencyLevelUid".isNull)
      .select($"df1.*")

    if (where_LanguageProficiencyLevelUid.count > 0) {
      val ex = cleanedCachePatientLanguage.except(where_LanguageProficiencyLevelUid)
      cleanedCachePatientLanguage = ex.union(update_LanguageProficiencyLevelUid)
    }

    logger.warn("Update LanguageProficiencyLevelUid of CachePatientLanguage is Done........")

    //Update LanguageProficiencyLevelUid of CachePatientLanguage 2
    val update_LanguageProficiencyLevelUid2 = cleanedCachePatientLanguage.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.LanguageProficiencyLevelText" === $"d2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "34421076-14B0-430A-AB22-0B5245CA8E6B")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageProficiencyLevelUid".isNull)
      .select($"df1.*",$"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("LanguageProficiencyLevelUid",$"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_LanguageProficiencyLevelUid2 = cleanedCachePatientLanguage.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.LanguageProficiencyLevelText" === $"d2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "34421076-14B0-430A-AB22-0B5245CA8E6B")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageProficiencyLevelUid".isNull)
      .select($"df1.*")

    if (where_LanguageProficiencyLevelUid2.count > 0) {
      val ex = cleanedCachePatientLanguage.except(where_LanguageProficiencyLevelUid2)
      cleanedCachePatientLanguage = ex.union(update_LanguageProficiencyLevelUid2)
    }

    logger.warn("Update LanguageProficiencyLevelUid of CachePatientLanguage 2 is Done........")

    //Update LanguageProficiencyLevelUid from Master Table of CachePatientLanguage
    val update_LanguageProficiencyLevelUid3 = cleanedCachePatientLanguage.as("df1").join(Master_prod.as("df2"),
      $"df1.LanguageProficiencyLevelText" === $"df2.Name" && $"df2.Type" === "LanguageAbilityProficiency")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageProficiencyLevelUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("LanguageProficiencyLevelUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_LanguageProficiencyLevelUid3 = cleanedCachePatientLanguage.as("df1").join(Master_prod.as("df2"),
      $"df1.LanguageProficiencyLevelText" === $"df2.Name" && $"df2.Type" === "LanguageAbilityProficiency")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageProficiencyLevelUid".isNull)
      .select($"df1.*")

    if (where_LanguageProficiencyLevelUid3.count > 0) {
      val ex = cleanedCachePatientLanguage.except(where_LanguageProficiencyLevelUid3)
      cleanedCachePatientLanguage = ex.union(update_LanguageProficiencyLevelUid3)
    }

    logger.warn("Update LanguageProficiencyLevelUid from Master Table of CachePatientLanguage is Done........")

    //Update LanguageProficiencyLevelUid from Master Table of CachePatientLanguage 2
    val update_LanguageProficiencyLevelUid4 = cleanedCachePatientLanguage.as("df1").join(Master_prod.as("df2"),
      $"df1.LanguageProficiencyLevelCode" === $"df2.Code" && $"df2.Type" === "LanguageAbilityProficiency")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageProficiencyLevelUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("LanguageProficiencyLevelUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_LanguageProficiencyLevelUid4 = cleanedCachePatientLanguage.as("df1").join(Master_prod.as("df2"),
      $"df1.LanguageProficiencyLevelCode" === $"df2.Code" && $"df2.Type" === "LanguageAbilityProficiency")
      .filter($"df1.StatusId" === 1 && $"df1.LanguageProficiencyLevelUid".isNull)
      .select($"df1.*")

    if (where_LanguageProficiencyLevelUid4.count > 0) {
      val ex = cleanedCachePatientLanguage.except(where_LanguageProficiencyLevelUid4)
      cleanedCachePatientLanguage = ex.union(update_LanguageProficiencyLevelUid4)
    }

    logger.warn("Update LanguageProficiencyLevelUid from Master Table of CachePatientLanguage 2 is Done........")

    //update status if LanguageAbilityModeUid is null Of CachePatientLanguage
    val update_status_PatLang6 = cleanedCachePatientLanguage.filter($"StatusId" === 1 && $"LanguageProficiencyLevelUid".isNull
      && rtrim(ltrim($"LanguageProficiencyLevelCode")).isNotNull || rtrim(ltrim($"LanguageProficiencyLevelText")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Language Ability Proficiency Is Not Mapped"))

    val where_status_PatLang6 = cleanedCachePatientLanguage.filter($"StatusId" === 1 && $"LanguageProficiencyLevelUid".isNull
      && rtrim(ltrim($"LanguageProficiencyLevelCode")).isNotNull || rtrim(ltrim($"LanguageProficiencyLevelText")).isNotNull)

    if (where_status_PatLang6.count > 0) {
      val ex = cleanedCachePatientLanguage.except(where_status_PatLang6)
      cleanedCachePatientLanguage = ex.union(update_status_PatLang6)
    }

    logger.warn("update status if LanguageAbilityModeUid is null Of CachePatientLanguage is Done........")

    //Update PatientLanguage_Prod
    val update_PatientLanguage_Prod = PatientLanguage_Prod.as("df1").join(cleanedCachePatientLanguage.as("df2")
      ,$"df1.PatientLanguageUid" === $"df2.PatientLanguageUid")
      .filter($"df2.StatusId" === 1)
      .select($"df1.*",$"df2.LanguageUid".as("aliasLangUid"),$"df2.LanguageAbilityModeUid".as("aliasLAMUid")
        ,$"df2.LanguageProficiencyLevelUid".as("aliasLPLUid"),$"df2.IsPreferred".as("aliasIsPreferred")
        ,$"df2.LanguageCode".as("aliasLangCode"),$"df2.LanguageText".as("aliasLangText"))
      .withColumn("MasterLanguageUid",$"aliasLangUid")
      .withColumn("MasterLangAbilityModeUid",$"aliasLAMUid")
      .withColumn("MasterLangProficiencyLevelUid",$"aliasLPLUid")
      .withColumn("PreferenceInd",$"aliasIsPreferred")
      .withColumn("ModifiedDate",current_timestamp())
      .withColumn("LanguageCode",$"aliasLangCode")
      .withColumn("LanguageText",$"aliasLangText")
      .drop("aliasLangUid","aliasLAMUid","aliasLPLUid","aliasIsPreferred","aliasLangCode","aliasLangText")

    val where_Lang = PatientLanguage_Prod.as("df1").join(cleanedCachePatientLanguage.as("df2")
      ,$"df1.PatientLanguageUid" === $"df2.PatientLanguageUid")
      .filter($"df2.StatusId" === 1)
      .select($"df1.*")

    val ex_lang = PatientLanguage_Prod.except(where_Lang)
    var PatientLanguage_Prod_Delta = ex_lang.union(update_PatientLanguage_Prod)

    logger.warn("Update PatientLanguage_Prod Done........")

    //Insert Data Into PatientLanguage_Prod
    val insert_PatientLanguage_Prod = cleanedCachePatientLanguage.as("df1").join(PatientLanguage_Prod_Delta.as("df2")
      ,$"df1.PatientLanguageUid" === $"df2.PatientLanguageUid","left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.PatientLanguageUid".isNull)
      .select($"df1.PatientUid",$"df1.LanguageUid".as("MasterLanguageUid"),$"df1.LanguageAbilityModeUid"
        .as("MasterLangAbilityModeUid"),$"df1.LanguageProficiencyLevelUid".as("MasterLangProficiencyLevelUid")
        ,$"df1.IsPreferred".as("PreferenceInd"),$"df1.LanguageCode",$"df1.LanguageText")
      .withColumn("PatientLanguageUid",FunctionUtility.getNewUid())
      .withColumn("CreatedDate",current_timestamp())

    val allcols3 = PatientLanguage_Prod_Delta.columns.toSet
    val insertcols3 = insert_PatientLanguage_Prod.columns.toSet
    val tot3 = allcols3 ++ insertcols3

    PatientLanguage_Prod_Delta = PatientLanguage_Prod_Delta.select(FunctionUtility.addColumns(allcols3, tot3): _*)
      .union(insert_PatientLanguage_Prod.select(FunctionUtility.addColumns(insertcols3, tot3): _*))


    logger.warn("Insert Data Into PatientLanguage_Prod Done........")
    logger.warn("End CachePatientLanguage...............................")

    //End CachePatientLanguage


    List(PatientLanguage_Prod_Delta)

  }



}
