package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory

class ImportVitalSignsData {

  def ImportVitalSignsDataFunc(spark : SparkSession,MergePracticeMap : DataFrame
                               ,CDRPatientCrosswalkTable : DataFrame
                               ,Master_prod : DataFrame
                               ,MasterCode_Prod : DataFrame
                               ,MappingPracticeCommonData_Delta : DataFrame
                               ,Patient_Prod_Delta : DataFrame
                               ,Individual_prod_Delta6 : DataFrame
                               ,PatientVitalSignObservation_Prod : DataFrame) : List[DataFrame] = {
    val logger = LoggerFactory.getLogger("")

    import spark.implicits._

    val CacheVitalSignsFile = spark.read.option("delimiter", "\u0017")
      .csv("")

    val CacheVitalSignslookup=Map("_c0" -> "PatientId","_c1" -> "ObservationCode","_c2" -> "ObservationName",
      "_c3" -> "ObservationCategory","_c4" -> "ObservationDate","_c5" -> "ObservationValue","_c6" -> "ObsInterpretationCode",
      "_c7" -> "ObsInterpretationText","_c8" -> "TargetSiteCode","_c9" -> "TargetSiteText","_c10" -> "NegationInd",
      "_c11" -> "ReferenceLowerRange","_c12" -> "ReferenceUpperRange","_c13" -> "MethodCode","_c14" -> "MethodCodeText",
      "_c15" -> "ResultOBSUnit","_c16" -> "VitalSignsKey","_c17" -> "PracticeUid","_c18" -> "BatchUid")

    val tempCacheVitalSigns = spark.read.option("header", "true").csv("s3n://bd-dev/aao_test/Schema/CDRSchema.txt")
    var tempCacheVitalSigns1 = CacheVitalSignsFile.select(CacheVitalSignsFile.columns.map(c => col(c).as(CacheVitalSignslookup.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")
    val allcols = tempCacheVitalSigns1.columns.toSet
    val viewcols = tempCacheVitalSigns1.columns.toSet
    val total = allcols ++ viewcols

    tempCacheVitalSigns1 = tempCacheVitalSigns.select(FunctionUtility.addColumns(allcols, total): _*)
      .union(tempCacheVitalSigns1.select(FunctionUtility.addColumns(viewcols, total): _*))


    //#//
    //#// Update Start
    //#//

    //Create MergePracticeMapDF
    val TempMergePracticeMapDf = tempCacheVitalSigns1.filter($"StatusId".isNull)
      .select("practiceuid").distinct()

    val MergePracticeMapDF = MergePracticeMap.as("df1")
      .join(TempMergePracticeMapDf.as("df2"), $"df1.NewPracticeUid" === $"df2.practiceuid", "left")
      .select("df1.*")

    val UpdateCacheVitalSigns1 = tempCacheVitalSigns1.filter($"StatusId".isNull).as("df1")
      .join(MergePracticeMapDF.as("df2"), $"df1.PracticeUid" === $"df2.NewPracticeUid")
      .select($"df1.*", $"df2.OriginalPracticeuid".as("AliasOriginalPracticeuid"))
      .withColumn("PracticeUid", $"AliasOriginalPracticeuid")


    val whereclauseCacheVitalSigns1 = tempCacheVitalSigns1.filter($"StatusId".isNull).as("df1")
      .join(MergePracticeMapDF.as("df2"), $"df1.PracticeUid" === $"df2.NewPracticeUid")
      .select($"df1.*")

    val ExceptUpdateCacheVitalSigns1 = tempCacheVitalSigns1.except(whereclauseCacheVitalSigns1)
    // Updated CacheVitalSignsTable to CacheVitalSigns1
    var CacheVitalSigns1 = UpdateCacheVitalSigns1.union(ExceptUpdateCacheVitalSigns1)

    var ChVitalSigns = CacheVitalSigns1.withColumn("StatusId", lit(1))

    ChVitalSigns = ChVitalSigns.filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"PracticeUid")
      .withColumn("PatientId", ltrim(rtrim($"PatientId")))
      .withColumn("ObservationCode", ltrim(rtrim($"ObservationCode")))

    val UpdateChVitalSigns1 = ChVitalSigns.filter($"PatientId".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val whereclause1 = ChVitalSigns.filter($"PatientId".isNull && $"StatusId" === 1)
    val ExceptUpdateChVitalSigns1 = ChVitalSigns.except(whereclause1)
    // Updated CacheVitalSigns1 to CacheVitalSigns2
    ChVitalSigns = UpdateChVitalSigns1.union(ExceptUpdateChVitalSigns1)

    val UpdateChVitalSigns2 = ChVitalSigns.filter($"StatusId" === 1).as("df1")
      .join(CDRPatientCrosswalkTable.as("df2"), $"df1.PatientId" === $"df2.New_PatientId"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.Old_PatientId".as("AliasOld_PatientId"))
      .withColumn("PatientId", $"AliasOld_PatientId")
      .drop("AliasOld_PatientId")

    val whereclause2 =  ChVitalSigns.filter($"StatusId" === 1).as("df1")
      .join(CDRPatientCrosswalkTable.as("df2"), $"df1.PatientId" === $"df2.New_PatientId"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")
    val ExceptUpdateChVitalSigns2 = ChVitalSigns.except(whereclause2)
    // Updated CacheVitalSigns1 to CacheVitalSigns2
    ChVitalSigns = UpdateChVitalSigns2.union(ExceptUpdateChVitalSigns2)

    val UpdateChVitalObservationCategoryNotFound = ChVitalSigns.filter($"StatusId" === 1
      && $"ObservationCategory".isNull
      && $"ObservationCode".isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ObservationCategory Not Found"))

    val whereclause3_1 = ChVitalSigns.filter($"StatusId" === 1
      && $"ObservationCategory".isNull
      && $"ObservationCode".isNotNull)

    val ExceptUpdateChVitalSigns3_1 = ChVitalSigns.except(whereclause3_1)
    // Updated CacheVitalSigns2 to CacheVitalSigns3_1
    ChVitalSigns = UpdateChVitalObservationCategoryNotFound.union(ExceptUpdateChVitalSigns3_1)


    val UpdateChVitalSignsObservationValueisNull = ChVitalSigns.filter($"StatusId" === 1
      && $"ObservationValue".isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ObservationValue is null"))

    val whereclause3_2 = ChVitalSigns.filter($"StatusId" === 1
      && $"ObservationValue".isNotNull)

    val ExceptUpdateChVitalSigns3_2 = ChVitalSigns.except(whereclause3_2)
    // Updated CacheVitalSigns2 to CacheVitalSigns3_2
    ChVitalSigns = UpdateChVitalSignsObservationValueisNull.union(ExceptUpdateChVitalSigns3_2)


    val UpdateChVitalSignsObservationdateNotFound = ChVitalSigns.filter($"StatusId" === 1
      && $"ObservationDate".isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Observationdate Not Found"))


    val whereclause3_3 = ChVitalSigns.filter($"StatusId" === 1
      && $"ObservationDate".isNotNull)


    val ExceptUpdateChVitalSigns3_3 = ChVitalSigns.except(whereclause3_3)
    // Updated CacheVitalSigns2 to CacheVitalSigns3_3
    ChVitalSigns = UpdateChVitalSignsObservationdateNotFound.union(ExceptUpdateChVitalSigns3_3)

    val UpdateChVitalObservationCodeAndObservationTextNotFound = ChVitalSigns.filter($"StatusId" === 1
      && $"ObservationCategory".isNull
      && $"ObservationCode".isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ObservationCode and ObservationText Not Found"))

    val whereclause3_4 = ChVitalSigns.filter($"StatusId" === 1
      && $"ObservationCategory".isNull
      && $"ObservationCode".isNotNull)

    val ExceptUpdateChVitalSigns3_4 = ChVitalSigns.except(whereclause3_4)
    // Updated CacheVitalSigns2 to CacheVitalSigns3_4
    ChVitalSigns = UpdateChVitalObservationCodeAndObservationTextNotFound.union(ExceptUpdateChVitalSigns3_4)

    val UpdateChVitalObservationCodeNameNotFound = ChVitalSigns.filter($"StatusId" === 1
      && $"ObservationCategory".isNull
      && $"ObservationCode".isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("bservationCode,Name Not Found"))

    val whereclause3_5 = ChVitalSigns.filter($"StatusId" === 1
      && $"ObservationCategory".isNull
      && $"ObservationCode".isNotNull)

    val ExceptUpdateChVitalSigns3_5 = ChVitalSigns.except(whereclause3_5)
    // Updated CacheVitalSigns2 to CacheVitalSigns3_5
    ChVitalSigns = UpdateChVitalObservationCodeNameNotFound.union(ExceptUpdateChVitalSigns3_5)

    val UpdateChVitalSigns4 = ChVitalSigns.filter($"StatusId" === 1 && $"ObservationCodeUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.filter($"MapperMasterCollectionUid" === "2A1D3EEB-6635-4535-9282-9A0C60FBA38A"
        && $"MappedUid".isNotNull).as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ObservationCode" === $"df2.PracticeValue")
      .select($"df1.*", $"df2.MappedUid".as("AliasMappedUid"))
      .withColumn("ObservationCodeUid", $"AliasMappedUid")
      .drop("AliasMappedUid")

    val whereclause4 = ChVitalSigns.filter($"StatusId" === 1 && $"ObservationCodeUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.filter($"MapperMasterCollectionUid" === "2A1D3EEB-6635-4535-9282-9A0C60FBA38A"
        && $"MappedUid".isNotNull).as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ObservationCode" === $"df2.PracticeValue")
      .select($"df1.*")

    val ExceptUpdateChVitalSigns4 = ChVitalSigns.except(whereclause4)
    // Updated CacheVitalSigns3 to CacheVitalSigns4
    ChVitalSigns = UpdateChVitalSigns4.union(ExceptUpdateChVitalSigns4)

    val UpdateChVitalSigns5 = ChVitalSigns.filter($"StatusId" === 1 && $"ObservationCodeUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.filter($"MapperMasterCollectionUid" === "2A1D3EEB-6635-4535-9282-9A0C60FBA38A"
        && $"MappedUid".isNotNull).as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && ltrim(rtrim($"df1.ObservationName")) === $"df2.PracticeValue")
      .select($"df1.*", $"df2.MappedUid".as("AliasMappedUid"))
      .withColumn("ObservationCodeUid", $"AliasMappedUid")
      .drop("AliasMappedUid")

    val whereclause5 = ChVitalSigns.filter($"StatusId" === 1 && $"ObservationCodeUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.filter($"MapperMasterCollectionUid" === "2A1D3EEB-6635-4535-9282-9A0C60FBA38A"
        && $"MappedUid".isNotNull).as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && ltrim(rtrim($"df1.ObservationName")) === $"df2.PracticeValue")
      .select($"df1.*")

    val ExceptUpdateChVitalSigns5 = ChVitalSigns.except(whereclause5)
    // Updated CacheVitalSigns4 to CacheVitalSigns5
    ChVitalSigns = UpdateChVitalSigns5.union(ExceptUpdateChVitalSigns5)

    val UpdateChVitalSigns6 = ChVitalSigns.filter($"ObservationCodeUid".isNull && $"StatusId" === 1).as("df1")
      .join(MasterCode_Prod.as("df2"), $"df1.ObservationCode" === $"df2.Code"
        && $"df1.CodeSystem" === $"df2.ObservationCategory")
      .select($"df1.*", $"df2.CodeUid".as("AliasCodeUid"))
      .withColumn("ObservationCodeUid", $"AliasCodeUid")
      .withColumn("ErrorNote", lit(null))
      .drop("AliasCodeUid")

    val whereclause6 = ChVitalSigns.filter($"ObservationCodeUid".isNull && $"StatusId" === 1).as("df1")
      .join(MasterCode_Prod.as("df2"), $"df1.ObservationCode" === $"df2.Code"
        && $"df1.CodeSystem" === $"df2.ObservationCategory")
      .select($"df1.*")

    val ExceptUpdateChVitalSigns6 = ChVitalSigns.except(whereclause6)
    // Updated CacheVitalSigns5 to CacheVitalSigns6
    ChVitalSigns = UpdateChVitalSigns6.union(ExceptUpdateChVitalSigns6)

    val UpdateChVitalSigns7 = ChVitalSigns.filter($"StatusId" === 1).as("df1")
      .join(Patient_Prod_Delta.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod_Delta6.as("df3"), $"df3.IndividualUid" === $"df2.PatientUid"
        && $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*", $"df2.PatientUid".as("AliasPatientUid"))
      .withColumn("PatientUid", $"AliasPatientUid")
      .drop("AliasPatientUid")

    val whereclause7 = ChVitalSigns.filter($"StatusId" === 1).as("df1")
      .join(Patient_Prod_Delta.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod_Delta6.as("df3"), $"df3.IndividualUid" === $"df2.PatientUid"
        && $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*")

    val ExceptUpdateChVitalSigns7 = ChVitalSigns.except(whereclause7)
    // Updated CacheVitalSigns6 to CacheVitalSigns7
    ChVitalSigns = UpdateChVitalSigns7.union(ExceptUpdateChVitalSigns7)

    val UpdateChVitalSigns8 = ChVitalSigns.filter($"StatusId" === 1 && $"PatientUid".isNull).as("df1")
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val whereclause8 = ChVitalSigns.filter($"StatusId" === 1 && $"PatientUid".isNull).as("df1")
    val ExceptUpdateChVitalSigns8 = ChVitalSigns.except(whereclause8)
    // Updated CacheVitalSigns7 to CacheVitalSigns8
    ChVitalSigns = UpdateChVitalSigns8.union(ExceptUpdateChVitalSigns8)

    val v = ChVitalSigns.filter($"StatusId" === 1)

    val UpdateV = v.as("df1")
      .join(PatientVitalSignObservation_Prod.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.ObservationCodeUid" === $"df2.ObservationCodeUid"
        && $"df1.ObservationDate" === $"df2.ResultDate"
        && $"df1.ObservationName" === $"df2.PracticeDescription")
      .select($"df1.*", $"df2.PatientVitalSignObservationUid".as("AliasPatientVitalSignObservationUid"))
      .withColumn("PatientVitalSignObservationUid", $"AliasPatientVitalSignObservationUid")
      .drop("AliasPatientVitalSignObservationUid")

    val whereclausev =  v.as("df1")
      .join(PatientVitalSignObservation_Prod.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.ObservationCodeUid" === $"df2.ObservationCodeUid"
        && $"df1.ObservationDate" === $"df2.ResultDate"
        && $"df1.ObservationName" === $"df2.PracticeDescription")
      .select($"df1.*")

    val ExceptUpdateV = v.except(whereclausev)
    // Updated CacheVitalSigns7 to CacheVitalSigns8
    val v1 = v.union(ExceptUpdateV)

    val UpdateChVitalSigns9 = ChVitalSigns.join(v1, Seq("RowId"))
      .select($"ChVitalSigns8.*", $"v1.PatientResultObservationUid".as("AliasPatientResultObservationUid"))
      .withColumn("PatientResultObservationUid", $"AliasPatientResultObservationUid")
      .drop("AliasPatientResultObservationUid")

    val whereclause9 = ChVitalSigns.join(v1, Seq("RowId"))
      .select($"ChVitalSigns8.*")
    val ExceptUpdateChVitalSigns9 = ChVitalSigns.except(whereclause9)
    // Updated CacheVitalSigns8 to CacheVitalSigns9
    ChVitalSigns = UpdateChVitalSigns9.union(ExceptUpdateChVitalSigns9)

    var CleanData1 = ChVitalSigns.dropDuplicates("PatientUid", "ObservationCodeUid", "ObservationName", "ObservationDate")
    var DropDuplicates1 = ChVitalSigns.except(CleanData1)

    //Generating PatientResultObservationUid and update #chVitalSigns from newly created Uids
    val TempPatientVitalSignObservation = CleanData1.filter($"StatusId" === 1 && $"PatientResultObservationUid".isNull)
      .select("PatientUid,ObservationName,ObservationCodeUid,ObservationDate").distinct()
      .withColumn("PatientResultObservationUid", FunctionUtility.getNewUid())

    val UpdateChVitalSigns11 = CleanData1.filter($"StatusId" === 1).as("df1")
      .join(TempPatientVitalSignObservation.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.ObservationCodeUid" === $"df2.ObservationCodeUid"
        && $"df1.ObservationDate" === $"df2.ObservationDate"
        && $"df1.ObservationName" === $"df2.ObservationName")
      .select($"df1.*", $"df2.PatientResultObservationUid".as("AliasPatientResultObservationUid"))
      .withColumn("PatientResultObservationUid", $"AliasPatientResultObservationUid")
      .drop("AliasPatientResultObservationUid")


    val whereclause11 = CleanData1.filter($"StatusId" === 1).as("df1")
      .join(TempPatientVitalSignObservation.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.ObservationCodeUid" === $"df2.ObservationCodeUid"
        && $"df1.ObservationDate" === $"df2.ObservationDate"
        && $"df1.ObservationName" === $"df2.ObservationName")
      .select($"df1.*")
    val ExceptUpdateChVitalSigns11 = CleanData1.except(whereclause11)
    // Updated CacheVitalSigns10 to CacheVitalSigns11
    ChVitalSigns = UpdateChVitalSigns11.union(ExceptUpdateChVitalSigns11)

    val UpdateChVitalSigns12 = CleanData1.filter($"StatusId" === 1
      && $"PatientResultObservationUid".isNull).as("df1")
      .join(TempPatientVitalSignObservation.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.ObservationDate" === $"df2.ObservationDate"
        && $"df1.ObservationName" === $"df2.ObservationName")
      .select($"df1.*", $"df2.PatientResultObservationUid".as("AliasPatientResultObservationUid"))
      .withColumn("PatientResultObservationUid", $"AliasPatientResultObservationUid")
      .drop("AliasPatientResultObservationUid")

    val whereclause12 = CleanData1.filter($"StatusId" === 1
      && $"PatientResultObservationUid".isNull).as("df1")
      .join(TempPatientVitalSignObservation.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.ObservationDate" === $"df2.ObservationDate"
        && $"df1.ObservationName" === $"df2.ObservationName")
      .select($"df1.*")

    val ExceptUpdateChVitalSigns12 = CleanData1.except(whereclause12)
    // Updated CacheVitalSigns11 to CacheVitalSigns12
    ChVitalSigns = UpdateChVitalSigns12.union(ExceptUpdateChVitalSigns12)


    var CleanData2 = ChVitalSigns.dropDuplicates("PatientUid", "ObservationName", "ObservationDate")
    val DropDuplicates2 = ChVitalSigns.except(CleanData1)

    DropDuplicates1 = DropDuplicates1.union(DropDuplicates2)


    val TempPatientResultObservation = CleanData2.filter($"StatusId" === 1 && $"PatientResultObservationUid".isNull)
      .select("PatientUid", "ObservationName", "ObservationDate").distinct()
      .withColumn("PatientResultObservationUid", FunctionUtility.getNewUid())

    val UpdateChVitalSigns14 = CleanData2.filter($"StatusId" === 1
      && $"PatientResultObservationUid".isNull).as("df1")
      .join(TempPatientResultObservation.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.ObservationName" === $"df2.ObservationName"
        && $"df1.ObservationDate" === $"df2.ObservationDate")
      .select($"df1.*", $"df2.PatientResultObservationUid".as("AliasPatientResultObservationUid"))
      .withColumn("PatientResultObservationUid", $"AliasPatientResultObservationUid")
      .drop("AliasPatientResultObservationUid")

    val whereclause14 = CleanData2.filter($"StatusId" === 1
      && $"PatientResultObservationUid".isNull).as("df1")
      .join(TempPatientResultObservation.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.ObservationName" === $"df2.ObservationName"
        && $"df1.ObservationDate" === $"df2.ObservationDate")
      .select($"df1.*")
    val ExceptUpdateChVitalSigns14 = CleanData2.except(whereclause14)
    // Updated CacheVitalSigns13 to CacheVitalSigns14
    CleanData2 = UpdateChVitalSigns14.union(ExceptUpdateChVitalSigns14)

    val UpdateChVitalSigns15 = CleanData2.filter($"StatusId" === 1).as("df1")
      .join(Master_prod.filter($"Type" === "ResultInterpretation").as("df2"), $"df1.ObsInterpretationCode" === $"df2.Code"
        && $"df1.ObsInterpretationText" === $"df2.Name")
      .select($"df1.*", $"df2.MasterUid".as("AliasMasterUid"))
      .withColumn("ResultInterpretationUid", $"AliasMasterUid")
      .drop("AliasMasterUid")


    val whereclause15 =  CleanData2.filter($"StatusId" === 1).as("df1")
      .join(Master_prod.filter($"Type" === "ResultInterpretation").as("df2"), $"df1.ObsInterpretationCode" === $"df2.Code"
        && $"df1.ObsInterpretationText" === $"df2.Name")
      .select($"df1.*")

    val ExceptUpdateChVitalSigns15 = CleanData2.except(whereclause15)
    // Updated CacheVitalSigns14 to CacheVitalSigns15
    CleanData2 = UpdateChVitalSigns15.union(ExceptUpdateChVitalSigns15)

    //Update ResultInterpretationUid from MappingPracticeCommonData & master
    val UpdateChVitalSigns16 = CleanData2.filter($"StatusId" === 1
      && $"ResultInterpretationUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "8B9E2980-784A-409D-AB98-700FA54EE8B7").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ObsInterpretationCode" === $"df2.PracticeValue")
      .select($"df1.*", $"df2.MappedUid".as("AliasMappedUid"))
      .withColumn("ResultInterpretationUid", $"AliasMappedUid")
      .drop("AliasMappedUid")

    val whereclause16 = CleanData2.filter($"StatusId" === 1
      && $"ResultInterpretationUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "8B9E2980-784A-409D-AB98-700FA54EE8B7").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ObsInterpretationCode" === $"df2.PracticeValue")
      .select($"df1.*")

    val ExceptUpdateChVitalSigns16 = CleanData2.except(whereclause16)
    // Updated CacheVitalSigns15 to CacheVitalSigns16
    CleanData2 = UpdateChVitalSigns16.union(ExceptUpdateChVitalSigns16)

    val UpdateChVitalSigns17 = CleanData2.filter($"StatusId" === 1
      && $"ResultInterpretationUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "8B9E2980-784A-409D-AB98-700FA54EE8B7").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ObsInterpretationText" === $"df2.PracticeValue")
      .select($"df1.*", $"df2.MappedUid".as("AliasMappedUid"))
      .withColumn("ResultInterpretationUid", $"AliasMappedUid")
      .drop("AliasMappedUid")

    val whereclause17 = CleanData2.filter($"StatusId" === 1
      && $"ResultInterpretationUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "8B9E2980-784A-409D-AB98-700FA54EE8B7").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ObsInterpretationText" === $"df2.PracticeValue")
      .select($"df1.*")

    val ExceptUpdateChVitalSigns17 = CleanData2.except(whereclause17)
    // Updated CacheVitalSigns16 to CacheVitalSigns17
    CleanData1 = UpdateChVitalSigns17.union(ExceptUpdateChVitalSigns17)

    val UpdateChVitalSigns18 = CleanData2.filter($"StatusId" === 1 && $"ResultInterpretationUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ResultInterpretation").as("df2"), $"df1.TargetSiteCode" === $"df2.Code")
      .select($"df1.*", $"df2.MasterUid".as("AliasMasterUid"))
      .withColumn("ResultInterpretationUid", $"AliasMasterUid")
      .drop("AliasMasterUid")

    val whereclause18 = CleanData2.filter($"StatusId" === 1 && $"ResultInterpretationUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ResultInterpretation").as("df2"), $"df1.TargetSiteCode" === $"df2.Code")
      .select($"df1.*")

    val ExceptUpdateChVitalSigns18 = CleanData2.except(whereclause18)
    // Updated CacheVitalSigns17 to CacheVitalSigns18
    CleanData2 = UpdateChVitalSigns18.union(ExceptUpdateChVitalSigns18)

    val UpdateChVitalSigns19 = CleanData2.filter($"StatusId" === 1 && $"ResultInterpretationUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ResultInterpretation").as("df2"), $"df1.TargetSiteText" === $"df2.Name")
      .select($"df1.*", $"df2.MasterUid".as("AliasMasterUid"))
      .withColumn("ResultInterpretationUid", $"AliasMasterUid")
      .drop("AliasMasterUid")

    val whereclause19 = CleanData2.filter($"StatusId" === 1 && $"ResultInterpretationUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ResultInterpretation").as("df2"), $"df1.TargetSiteText" === $"df2.Name")
      .select($"df1.*")

    val ExceptUpdateChVitalSigns19 = CleanData2.except(whereclause19)
    // Updated CacheVitalSigns18 to CacheVitalSigns19
    CleanData2 = UpdateChVitalSigns19.union(ExceptUpdateChVitalSigns19)

    //Update TargetSiteUid from MappingPracticeCommonData  and master
    val UpdateChVitalSigns20 = CleanData2.filter($"StatusId" === 1
      && $"TargetSiteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" || $"df1.TargetSiteText" === $"PracticeValue"
          && $"df1.TargetSiteCode" === $"df2.PracticeValue")
      .select($"df1.*", $"df2.MappedUid".as("AliasMappedUid"))
      .withColumn("TargetSiteUid", $"AliasMappedUid")
      .drop("AliasMappedUid")

    val whereclause20 = CleanData2.filter($"StatusId" === 1
      && $"TargetSiteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta
        .filter($"MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" || $"df1.TargetSiteText" === $"PracticeValue"
          && $"df1.TargetSiteCode" === $"df2.PracticeValue")
      .select($"df1.*")
    val ExceptUpdateChVitalSigns20 = CleanData2.except(whereclause20)
    // Updated CacheVitalSigns19 to CacheVitalSigns20
    CleanData2 = UpdateChVitalSigns20.union(ExceptUpdateChVitalSigns20)

    val UpdateChVitalSigns21 = CleanData2.filter($"StatusId" === 1 && $"TargetSiteUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ResultInterpretation").as("df2"),
        $"df1.TargetSiteText" === $"df2.Name" || $"df1.TargetSiteCode" === $"df2.Code")
      .select($"df1.*", $"df2.MasterUid".as("AliasMasterUid"))
      .withColumn("TargetSiteUid", $"AliasMasterUid")
      .drop("AliasMasterUid")

    val whereclause21 = CleanData2.filter($"StatusId" === 1 && $"TargetSiteUid".isNull).as("df1")
      .join(Master_prod.filter($"Type" === "ResultInterpretation").as("df2"),
        $"df1.TargetSiteText" === $"df2.Name" || $"df1.TargetSiteCode" === $"df2.Code")
      .select($"df1.*")

    val ExceptUpdateChVitalSigns21 = CleanData2.except(whereclause21)
    // Updated CacheVitalSigns20 to CacheVitalSigns21
    CleanData2 = UpdateChVitalSigns21.union(ExceptUpdateChVitalSigns21)

    val UpdatePph = CleanData2.filter($"StatusId =1").as("df1")
      .join(PatientVitalSignObservation_Prod.as("df2"),
        $"df1.ObservationCodeUid" === $"df2.ObservationCodeUid"
          && $"df1.PatientVitalSignObservationKey" === $"df2.PatientVitalSignObservationUid"
          && $"df1.CodeSystem" === $"df2.ObservationCategory")
      .select($"df2.*", $"df1.ObservationCode".as("AliasObservationCode"),
        $"df1.ObservationName".as("AliasObservationName"),
        $"df1.ResultInterpretationUid".as("AliasResultInterpretationUid"),
        $"df1.TargetSiteUid".as("AliasTargetSiteUid"),
        $"df1.ReferenceLowerRange".as("AliasReferenceLowerRange"),
        $"df1.ReferenceUpperRange".as("AliasReferenceUpperRange"),
        $"df1.ObservationValue".as("AliasObservationValue"),
        $"df1.NegationInd".as("AliasNegationInd"),
        $"df1.ProcedureUid".as("AliasProcedureUid"),
        $"df1.ResultOBSUnit".as("AliasResultOBSUnit"))
      .withColumn("PracticeCode", $"AliasObservationCode")
      .withColumn("PracticeDescription", $"AliasObservationName")
      .withColumn("MasterResultInterpretationUid", $"AliasResultInterpretationUid")
      .withColumn("MasterTargetSiteUid", $"AliasTargetSiteUid")
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ReferenceObservationRange", when($"AliasReferenceLowerRange".isNotNull,
        when($"AliasReferenceUpperRange".isNotNull, $"df1.AliasReferenceLowerRange" - $"df1.AliasReferenceUpperRange")))
      .withColumn("ResultValue", $"AliasObservationValue")
      .withColumn("NegationInd", $"AliasNegationInd")
      .withColumn("ProcedureUid", $"AliasProcedureUid")
      .withColumn("Unit", $"AliasResultOBSUnit")
      .withColumn("IsVital", lit(1))
      .withColumn("ObservationCodeUid", $"AliasObservationCodeUid")
      .withColumn("PatientVitalSignObservationKey", $"AliasVitalSignsKey")
      .withColumn("CodeSystem", $"AliasObservationCategory")
      .drop("AliasObservationCode", "AliasObservationName", "AliasResultInterpretationUid",
        "AliasTargetSiteUid", "AliasReferenceLowerRange", "AliasReferenceUpperRange",
        "AliasObservationValue", "AliasNegationInd", "AliasProcedureUid", "AliasResultOBSUnit")

    val whereclauseupdatepph = CleanData2.filter($"StatusId =1").as("df1")
      .join(PatientVitalSignObservation_Prod.as("df2"),
        $"df1.ObservationCodeUid" === $"df2.ObservationCodeUid"
          && $"df1.PatientVitalSignObservationKey" === $"df2.PatientVitalSignObservationUid"
          && $"df1.CodeSystem" === $"df2.ObservationCategory")
      .select($"df2.*")

    val exceptUpdatePph = PatientVitalSignObservation_Prod.except(whereclauseupdatepph)
    var PatientVitalSignObservation_Prod_Delta = UpdatePph.union(exceptUpdatePph)

    val InsertIntoPatientVitalSignObservation =  CleanData2.filter($"StatusId" === 1).as("df1")
      .join(PatientVitalSignObservation_Prod_Delta.filter($"PatientVitalSignObservationUid".isNull).as("df2"),
        $"df1.PatientResultObservationUid" === $"df2.PatientVitalSignObservationUid")
      .select($"df1.PatientResultObservationUid".as("PatientVitalSignObservationUid"), $"df1.PatientUid", $"df1.ObservationCodeUid", $"df1.ObservationCode",
        $"df1.ObservationDate".as("ResultDate"), $"df1.ObservationValue".as("ResultValue"),
        $"df1.ResultInterpretationUid".as("MasterResultInterpretationUid"), $"df1.TargetSiteUid".as("MasterTargetSiteUid"),
        $"df1.ResultOBSUnit", $"df1.ObservationName", $"df1.ObservationCategory".as("CodeSystem"))
      .groupBy($"PatientVitalSignObservationUid", $"PatientUid", $"ObservationCodeUid", $"ObservationCode",$"ResultDate",
        $"ResultValue", $"MasterResultInterpretationUid", $"MasterTargetSiteUid",$"ResultOBSUnit", $"ObservationName",
        $"CodeSystem")
      .agg(max(when($"ReferenceUpperRange".isNotNull, concat_ws("-",$"df1.ReferenceLowerRange",$"df1.ReferenceUpperRange"))
        .otherwise($"ReferenceLowerRange")).as("ReferenceObservationRange"),
        max($"ObservationCode").as("PracticeCode"),
        max($"ObservationName").as("PracticeDescription"),
        max($"NegationInd").as("NegationInd"),
        max($"ProcedureUid").as("ProcedureUid"),
        max("ResultOBSUnit").as("Unit"))
      .withColumn("ServiceProviderUid", lit(null))
      .withColumn("SpecimenId", lit(null))
      .withColumn("IsVital", lit(1))

    val allcols1 = PatientVitalSignObservation_Prod_Delta.columns.toSet
    val insertcols = InsertIntoPatientVitalSignObservation.columns.toSet
    val tot3 = allcols1 ++ insertcols

    PatientVitalSignObservation_Prod_Delta = PatientVitalSignObservation_Prod_Delta.select(FunctionUtility.addColumns(allcols1, tot3): _*)
      .union(InsertIntoPatientVitalSignObservation.select(FunctionUtility.addColumns(insertcols, tot3): _*))

    List(PatientVitalSignObservation_Prod_Delta)
  }

}
