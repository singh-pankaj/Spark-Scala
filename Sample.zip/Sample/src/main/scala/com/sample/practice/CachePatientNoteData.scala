package com.sample.practice

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

class CachePatientNoteData {

  def CachePatientNoteDataFunc(spark : SparkSession,MergePracticeMap : DataFrame
                               ,CDRPatientCrosswalkTable : DataFrame
                               ,ClinicalInformationModelSection : DataFrame
                               ,MultiTableExtendTable : DataFrame
                               ,ProviderNPIChangeTable : DataFrame
                               ,Individual : DataFrame
                               ,distIndUid : DataFrame
                               ,distspUID : DataFrame
                               ,PatientNoteTable_prod : DataFrame
                               ,Patient_Prod_Delta : DataFrame
                               ,Individual_prod_Delta6 : DataFrame
                               ,ViewServiceProvider_prod : DataFrame
                               ,ViewFacility_Prod : DataFrame
                               ,ServiceProvider_prod_Delta5 : DataFrame
                               ,Institution_Prod_Delta2 : DataFrame
                               ,ServiceLocation_Prod_Delta2 : DataFrame) : List[DataFrame]  = {

    val logger = LoggerFactory.getLogger("")

    import spark.implicits._

    val CachePatientNotesFile = spark.read.option("delimiter", "\u0017")
      .csv("")

    val CachePatientNoteslookup = Map("_c0" -> "PatientId", "_c1" -> "EncounterDate", "_c2" -> "SectionName", "_c3" -> "Note",
      "_c4" -> "ServiceProviderNPI", "_c5" -> "ServiceProviderLastName", "_c6" -> "ServiceProviderFirstName",
      "_c7" -> "ServiceLocationId", "_c8" -> "ServiceLocationName", "_c9" -> "Group1", "_c10" -> "Group2", "_c11" -> "Group3",
      "_c12" -> "Group4", "_c13" -> "PracticePatientNoteKey", "_c14" -> "PracticeUid", "_c15" -> "BatchUid")

    val tempCachePatientNotes = spark.read.option("header", "true").csv("s3n://bd-dev/aao_test/Schema/CDRSchema.txt")
    var tempCachePatientNotes1 = CachePatientNotesFile.select(CachePatientNotesFile.columns.map(c => col(c).as(CachePatientNoteslookup.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")
    val allcols = tempCachePatientNotes1.columns.toSet
    val viewcols = tempCachePatientNotes1.columns.toSet
    val total = allcols ++ viewcols

    tempCachePatientNotes1 = tempCachePatientNotes.select(FunctionUtility.addColumns(allcols, total): _*)
      .union(tempCachePatientNotes1.select(FunctionUtility.addColumns(viewcols, total): _*))

    //Create MergePracticeMapDF


    val TempMergePracticeMapDf = tempCachePatientNotes1.filter($"StatusId".isNull)
      .select("practiceuid").distinct()

    val MergePracticeMapDF = MergePracticeMap.as("df1")
      .join(TempMergePracticeMapDf.as("df2"), $"df1.NewPracticeUid" === $"df2.practiceuid", "left")
      .select("df1.*")

    val UpdateCachePatientNotes1 = tempCachePatientNotes1.filter($"StatusId".isNull).as("df1")
      .join(MergePracticeMapDF.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.OriginalPracticeuid".as("AliasOriginalPracticeuid"))
      .withColumn("Practiceuid", $"AliasOriginalPracticeuid")
      .drop("AliasOriginalPracticeuid")

    val whereclauseCachePatientNotes1 = tempCachePatientNotes1.filter($"StatusId".isNull).as("df1")
      .join(MergePracticeMapDF.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdateCachePatientNotes1 = tempCachePatientNotes1.except(whereclauseCachePatientNotes1)
    // Updated CachePatientNotesTable into CachePatientNotes1
    var CachePatientNotesDF = UpdateCachePatientNotes1.union(ExceptUpdateCachePatientNotes1)

    var CachePatientNotes1 = CachePatientNotesDF.withColumn("StatusId", lit(1))

    CachePatientNotes1 = CachePatientNotes1.filter($"StatusID" === 1)
      .withColumn("OldPracticeUid", $"PracticeUid")
      .withColumn("PatientId", ltrim(rtrim($"PatientId")))
      .withColumn("ProblemCode", ltrim(rtrim($"ProblemCode")))
      .withColumn("ProblemTypeCode", ltrim(rtrim($"ProblemTypeCode")))
      .withColumn("RelationshipToPatientText", ltrim(rtrim($"RelationshipToPatientText")))
      .withColumn("RelationshipToPatientCode", ltrim(rtrim($"RelationshipToPatientCode")))

    val UpdateChPatientNotes1 = CachePatientNotes1.filter($"PatientId".isNull).as("df1")
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val whereclause1 = CachePatientNotes1.filter($"PatientId".isNull).as("df1")

    val ExceptChPatientNotes1 = CachePatientNotes1.except(whereclause1)
    // Updated CachePatientNotes1 into CachePatientNotes2
    CachePatientNotes1 = CachePatientNotes1.union(ExceptChPatientNotes1)

    val UpdateChPatientNotes2 = CachePatientNotes1.filter($"StatusId" === 1).as("df1")
      .join(CDRPatientCrosswalkTable.as("df2"), $"df1.PatientId" === $"df2.New_PatientId"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.Old_PatientId".as("AliasOld_PatientId"))
      .withColumn("PatientId", $"AliasOld_PatientId")
      .drop("AliasOld_PatientId")

    val whereclause2 = CachePatientNotes1.filter($"StatusId" === 1).as("df1")
      .join(CDRPatientCrosswalkTable.as("df2"), $"df1.PatientId" === $"df2.New_PatientId"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")
    val ExceptUpdateChPatientNotes2 = CachePatientNotes1.except(whereclause2)
    // Updated CachePatientNotes1 into CachePatientNotes2
    CachePatientNotes1 = UpdateChPatientNotes2.union(ExceptUpdateChPatientNotes2)

    val UpdateChPatientNotesSectionnameNull = CachePatientNotes1.filter($"StatusId" === 1
      && $"SectionName".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("SectionName is null"))

    val whereclause3_1 = CachePatientNotes1.filter($"StatusId" === 1
      && $"SectionName".isNull)

    val exceptwhereclause3_1 = CachePatientNotes1.except(whereclause3_1)
    CachePatientNotes1 = UpdateChPatientNotesSectionnameNull.union(exceptwhereclause3_1)

    val UpdateChPatientNotesNoteNull = CachePatientNotes1.filter($"StatusId" === 1
      && $"Note".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Note is null"))

    val whereclause3_2 = CachePatientNotes1.filter($"StatusId" === 1
      && $"Note".isNull)

    val ExceptUpdateChPatientNotes3 = CachePatientNotes1.except(whereclause3_2)
    // Updated ChPatientNotes2 into ChPatientNotes3
    CachePatientNotes1 = UpdateChPatientNotesNoteNull.union(ExceptUpdateChPatientNotes3)

    val UpdateChPatientNotes4 = CachePatientNotes1.filter($"ClinicalInformationModelSectionUid".isNull
      && $"StatusId" === 1)
      .join(ClinicalInformationModelSection.as("df2"), $"df1.SectionName" === $"df2.Name")
      .select($"df1.*", $"df2.ClinicalInformationModelSectionUid".as("AliasClinicalInformationModelSectionUid"))
      .withColumn("ClinicalInformationModelSectionUid", $"AliasClinicalInformationModelSectionUid")
      .drop("AliasClinicalInformationModelSectionUid")

    val whereclause4 = CachePatientNotes1.filter($"ClinicalInformationModelSectionUid".isNull
      && $"StatusId" === 1)
      .join(ClinicalInformationModelSection.as("df2"), $"df1.SectionName" === $"df2.Name")
      .select($"df1.*")

    val ExceptUpdateChPatientNotes4 = CachePatientNotes1.except(whereclause4)
    // Updated ChPatientNotes3 into ChPatientNotes4
    CachePatientNotes1 = UpdateChPatientNotes4.union(ExceptUpdateChPatientNotes4)

    val UpdateChPatientNotes5 = CachePatientNotes1.filter($"StatusId" === 1
      && $"ClinicalInformationModelSectionUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Section Name Invalid or Missing"))

    val whereclause5 = CachePatientNotes1.filter($"StatusId" === 1
      && $"ClinicalInformationModelSectionUid".isNull)

    val ExceptUpdateChPatientNotes5 = CachePatientNotes1.except(whereclause5)
    // Updated ChPatientNotes4 into ChPatientNotes5
    CachePatientNotes1 = UpdateChPatientNotes5.union(ExceptUpdateChPatientNotes5)

    val UpdateChPatientNotes6 = CachePatientNotes1.filter($"StatusId" === 1).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ServiceProviderNPI" === $"df2.Element1")
      .select($"df1.*", $"df2.value".as("Aliasvalue"))
      .withColumn("ServiceProviderNPI", $"Aliasvalue")
      .drop("Aliasvalue")

    val whereclause6 = CachePatientNotes1.filter($"StatusId" === 1).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ServiceProviderNPI" === $"df2.Element1")
      .select($"df1.*")

    val ExceptUpdateChPatientNotes6 = CachePatientNotes1.except(whereclause6)
    // Updated ChPatientNotes5 into ChPatientNotes6
    CachePatientNotes1 = UpdateChPatientNotes6.union(ExceptUpdateChPatientNotes6)

    val UpdateChPatientNotes7 = ProviderNPIChangeTable.as("df1")
      .join(Individual.as("df2"), $"df1.ServiceProviderUid" === $"df2.IndividualUid")
      .join(CachePatientNotes1.filter($"StatusId" === 1).as("df3"), $"df2.PracticeUid" === $"df3.PracticeUid"
        && $"df3.ServiceProviderNPI" === $"df1.OldNPI")
      .select($"df3.*", $"df1.NewNPI".as("AliasNewNPI"))
      .withColumn("ServiceProviderNPI", $"AliasNewNPI")
      .drop("AliasNewNPI")

    val whereclause7 = ProviderNPIChangeTable.as("df1")
      .join(Individual.as("df2"), $"df1.ServiceProviderUid" === $"df2.IndividualUid")
      .join(CachePatientNotes1.filter($"StatusId" === 1).as("df3"), $"df2.PracticeUid" === $"df3.PracticeUid"
        && $"df3.ServiceProviderNPI" === $"df1.OldNPI")
      .select($"df3.*")

    val ExceptUpdateChPatientNotes7 = CachePatientNotes1.except(whereclause7)
    // Updated ChPatientNotes6 into ChPatientNotes7
    CachePatientNotes1 = UpdateChPatientNotes7.union(ExceptUpdateChPatientNotes7)

    val UpdateChPatientNotes8 = CachePatientNotes1.filter($"StatusId" === 1
      && $"ServiceProviderNPI".isNull
      && $"element2".isNotNull).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI").as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element2")
      .select($"df1.*", $"df2.value".as("Aliasvalue"))
      .withColumn("ServiceProviderNPI", $"Aliasvalue")
      .drop("Aliasvalue")

    val whereclause8 = CachePatientNotes1.filter($"StatusId" === 1
      && $"ServiceProviderNPI".isNull
      && $"element2".isNotNull).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI").as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element2")
      .select($"df1.*")

    val ExceptUpdateChPatientNotes8 = CachePatientNotes1.except(whereclause8)
    // Updated ChPatientNotes7 into ChPatientNotes8
    CachePatientNotes1 = UpdateChPatientNotes8.union(ExceptUpdateChPatientNotes8)

    val UpdateChPatientNotes9 = CachePatientNotes1.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid NPI Found,Length should be 10"))

    val whereclause9 = CachePatientNotes1.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)

    val ExceptUpdateChPatientNotes9 = CachePatientNotes1.except(whereclause9)
    // Updated ChPatientNotes8 into ChPatientNotes9
    CachePatientNotes1 = UpdateChPatientNotes9.union(ExceptUpdateChPatientNotes9)

    val UpdateChPatientNotes10 = CachePatientNotes1.as("df1")
      .join(Patient_Prod_Delta.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod_Delta6.as("df3"), $"df2.PatientUid" === $"df3.IndividualUid"
        && $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*", $"df2.PatientUid".as("AliasPatientUid"))
      .withColumn("PatientUid", $"AliasPatientUid")
      .drop("AliasPatientUid")

    val whereclause10 = CachePatientNotes1.as("df1")
      .join(Patient_Prod_Delta.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod_Delta6.as("df3"), $"df2.PatientUid" === $"df3.IndividualUid"
        && $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*")

    val ExceptUpdateChPatientNotes10 = CachePatientNotes1.except(whereclause10)
    // Updated ChPatientNotes9 into ChPatientNotes10
    CachePatientNotes1 = UpdateChPatientNotes10.union(ExceptUpdateChPatientNotes10)

    val UpdateChPatientNotes11 = CachePatientNotes1.filter($"StatusId" === 1).as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.ServiceProviderUid".as("AliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"AliasServiceProviderUid")
      .drop("AliasServiceProviderUid")

    val whereclause11 = CachePatientNotes1.filter($"StatusId" === 1).as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdateChPatientNotes11 = CachePatientNotes1.except(whereclause11)
    // Updated ChPatientNotes10 into ChPatientNotes11
    CachePatientNotes1 = UpdateChPatientNotes11.union(ExceptUpdateChPatientNotes11)

    val UpdateChPatientNotes12 = CachePatientNotes1.filter($"StatusId" === 1).as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationid" === $"df2.id"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.ServiceLocationUid".as("AliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"AliasServiceLocationUid")
      .drop("AliasServiceLocationUid")

    val whereclause12 = CachePatientNotes1.filter($"StatusId" === 1).as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationid" === $"df2.id"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")
    val ExceptUpdateChPatientNotes12 = CachePatientNotes1.except(whereclause12)
    // Updated ChPatientNotes11 into ChPatientNotes12
    CachePatientNotes1 = UpdateChPatientNotes12.union(ExceptUpdateChPatientNotes12)

    val UpdateChPatientNotes13 = CachePatientNotes1.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val whereclause13 = CachePatientNotes1.filter($"StatusId" === 1 && $"PatientUid".isNull)

    val ExceptUpdateChPatientNotes13 = CachePatientNotes1.except(whereclause13)
    // Updated ChPatientNotes12 into ChPatientNotes13
    CachePatientNotes1 = UpdateChPatientNotes13.union(ExceptUpdateChPatientNotes13)

    val InsertIntoPHY = CachePatientNotes1.filter($"ServiceProviderNPI".isNotNull
      && $"ServiceProviderUid".isNull && $"StatusId" === 1)
      .groupBy($"ServiceProviderNPI", $"PracticeUid")
      .agg(max(ltrim(rtrim($"ServiceProviderFirstName"))).as("ServiceProviderFirstName"),
        max(ltrim(rtrim($"ServiceProviderLastName"))).as("ServiceProviderLastName"))
      .withColumn("Physician_MidName", lit(null))
      .withColumn("ServiceProviderUid", FunctionUtility.getNewUid())

    val UpdateChPatientNotes14 = CachePatientNotes1.filter($"StatusId" === 1
      && $"ServiceProviderUid".isNull).as("df1")
      .join(InsertIntoPHY.as("df2"), Seq("ServiceProviderNPI", "PracticeUid"))
      .select($"df1.*", $"df2.ServiceProviderUid".as("AliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"AliasServiceProviderUid")
      .drop("AliasServiceProviderUid")

    val whereclause14 = CachePatientNotes1.filter($"StatusId" === 1
      && $"ServiceProviderUid".isNull).as("df1")
      .join(InsertIntoPHY.as("df2"), Seq("ServiceProviderNPI", "PracticeUid"))
      .select($"df1.*")

    val ExceptUpdateChPatientNotes14 = CachePatientNotes1.except(whereclause14)
    // Updated ChPatientNotes13 into ChPatientNotes14
    CachePatientNotes1 = UpdateChPatientNotes14.union(ExceptUpdateChPatientNotes14)

    val InsertIntoIndividual = InsertIntoPHY.as("df1")
      .join(distIndUid.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.IndividualUid"))
      .select($"df1.ServiceProviderUid".as("IndividualUid"), $"df1.ServiceProviderFirstName".as("First"),
        $"df1.Physician_MidName".as("Middle"), $"df1.ServiceProviderLastName".as("Last"), $"df1.PracticeUid")
      .distinct()

    val allcols1 = Individual_prod_Delta6.columns.toSet
    val insertcols = InsertIntoIndividual.columns.toSet
    val tot1 = allcols1 ++ insertcols

    val Individual_prod_Delta7 = Individual_prod_Delta6.select(FunctionUtility.addColumns(allcols1, tot1): _*)
      .union(InsertIntoIndividual.select(FunctionUtility.addColumns(insertcols, tot1): _*))


    val InsertIntoServiceProvider = InsertIntoPHY.as("df1")
      .join(distspUID.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.ServiceProviderUid"))

      .withColumn("ListName", when(ltrim(rtrim($"Physician_MidName")).isNotNull,
        concat_ws(" ", ltrim(rtrim($"ServiceProviderLastName")),
          ltrim(rtrim($"ServiceProviderFirstName")),
          ltrim(rtrim($"Physician_MidName"))))
        .otherwise(concat(ltrim(rtrim($"ServiceProviderLastName")), ltrim(rtrim($"ServiceProviderFirstName")))))
      .select($"df1.ServiceProviderUid", $"df1.ServiceProviderNPI".as("NPI"))
      .withColumn("ExternalID", lit(null))
      .withColumn("Type", lit(4))

    val allcols2 = ServiceProvider_prod_Delta5.columns.toSet
    val insertcols2 = InsertIntoServiceProvider.columns.toSet
    val tot2 = allcols2 ++ insertcols2

    val ServiceProvider_prod_Delta6 = ServiceProvider_prod_Delta5.select(FunctionUtility.addColumns(allcols2, tot2): _*)
      .union(InsertIntoServiceProvider.select(FunctionUtility.addColumns(insertcols2, tot2): _*))

    val InsertIntoLoc = CachePatientNotes1.filter($"StatusId" === 1
      && $"ServiceLocationUid".isNull && ltrim(rtrim($"ServiceLocationId")).isNotNull)
      .select("ServiceLocationId", "ServiceLocationName", "PracticeUid").distinct()
      .withColumn("ServiceLocationName", when(ltrim(rtrim($"ServiceLocationName")).isNull, $"ServiceLocationId")
        .otherwise($"ServiceLocationName"))
      .withColumn("ServiceLocationUid", FunctionUtility.getNewUid())


    val UpdateChPatientNotes15 = CachePatientNotes1.filter($"StatusId" === 1).as("df1")
      .join(InsertIntoLoc.as("df2"), $"df1.ServiceLocationId" === $"df2.ServiceLocationId"
        && $"df1.ServiceLocationName" === $"df2.ServiceLocationName"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.ServiceLocationUid".as("AliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"AliasServiceLocationUid")
      .drop("AliasServiceLocationUid")

    val whereclause15 = CachePatientNotes1.filter($"StatusId" === 1).as("df1")
      .join(InsertIntoLoc.as("df2"), $"df1.ServiceLocationId" === $"df2.ServiceLocationId"
        && $"df1.ServiceLocationName" === $"df2.ServiceLocationName"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdateChPatientNotes15 = CachePatientNotes1.except(whereclause15)
    // Updated ChPatientNotes14 into ChPatientNotes15
    CachePatientNotes1 = UpdateChPatientNotes15.union(ExceptUpdateChPatientNotes15)

    val InstitutionDF = InsertIntoLoc
      .select($"ServiceLocationUid".as("InstitutionUid"), $"ServiceLocationName".as("Name"), $"PracticeUid").distinct()
      .withColumn("Type", lit(5))

    val allcols3 = Institution_Prod_Delta2.columns.toSet
    val insert3 = InstitutionDF.columns.toSet
    val tot3 = allcols3 ++ insert3

    val Institution_Prod_Delta3 = Institution_Prod_Delta2.select(FunctionUtility.addColumns(allcols3, tot3): _*)
      .union(InstitutionDF.select(FunctionUtility.addColumns(insert3, tot3): _*))

    val InsertIntoServiceLocation = InsertIntoLoc
      .select($"ServiceLocationUid", $"ServiceLocationId".as("ExternalID"))

    val allcols4 = ServiceLocation_Prod_Delta2.columns.toSet
    val insert4 = InsertIntoServiceLocation.columns.toSet
    val tot4 = allcols4 ++ insert4

    val ServiceLocation_Prod_Delta3 = ServiceLocation_Prod_Delta2.select(FunctionUtility.addColumns(allcols4, tot4): _*)
      .union(InsertIntoServiceLocation.select(FunctionUtility.addColumns(insert4, tot4): _*))

    //CachePatientNotes as Patientnote
    //confirm
    val UpdateChPatientNotes16 = CachePatientNotes1.filter($"StatusId" === 1)
      .join(PatientNoteTable_prod, Seq("PatientUid", "PracticePatientNoteKey"))
      .select($"ChPatientNotes15.*", $"CachePatientNotes2.PatientNoteUid".as("AliasPatientNoteUid"))
      .withColumn("PatientNoteUid", $"AliasPatientNoteUid")
      .drop("AliasPatientNoteUid")

    val whereclause16 = CachePatientNotes1.filter($"StatusId" === 1)
      .join(PatientNoteTable_prod, Seq("PatientUid", "PracticePatientNoteKey"))
      .select($"ChPatientNotes15.*")
    val ExceptUpdateChPatientNotes16 = CachePatientNotes1.except(whereclause16)
    // Updated ChPatientNotes15 into ChPatientNotes16
    CachePatientNotes1 = UpdateChPatientNotes16.union(ExceptUpdateChPatientNotes16)

    var CleanData1 = CachePatientNotes1.dropDuplicates("PatientUid", "PracticePatientNoteKey")
    val DropDuplicates1 = CachePatientNotes1.except(CleanData1)

    val InsertIntoPatientNote = CleanData1
      .filter($"StatusId" === 1 && $"PatientNoteUid".isNull && $"PracticePatientNoteKey".isNotNull)
      .select("PatientUid", "PracticePatientNoteKey")
      .withColumn("PatientNoteUid", FunctionUtility.getNewUid())

    val UpdateChPatientNotes18 = CleanData1.filter($"StatusId" === 1).as("df1")
      .join(InsertIntoPatientNote.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey")
      .select($"df1.*", $"df2.PatientNoteUid".as("AliasPatientNoteUid"))
      .withColumn("PatientNoteUid", $"AliasPatientNoteUid")
      .drop("AliasPatientNoteUid")

    val whereclause18 = CleanData1.filter($"StatusId" === 1).as("df1")
      .join(InsertIntoPatientNote.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey")
      .select($"df1.*")

    val ExceptUpdateChPatientNotes18 = CachePatientNotes1.except(whereclause18)
    // Updated ChPatientNotes17 into ChPatientNotes18
    CleanData1 = UpdateChPatientNotes18.union(ExceptUpdateChPatientNotes18)

    //confirm

    val UpdatePatientNote = CleanData1.filter($"StatusId" === 1).as("df1")
      .join(PatientNoteTable_prod.as("df2"), $"df1.PatientNoteUid" === $"df2.PatientNoteUid")
      .select($"df2.*", $"df1.Note".as("AliasNote"), $"df1.Group1".as("AliasGroup1"),
        $"df1.Group2".as("AliasGroup2"), $"df1.Group3".as("AliasGroup3"), $"df1.Group4".as("AliasGroup4"),
        $"df1.PracticePatientNoteKey".as("AliasPracticePatientNoteKey"))
      .withColumn("Note", $"AliasNote")
      .withColumn("Group1", $"AliasGroup1")
      .withColumn("Group2", $"AliasGroup2")
      .withColumn("Group3", $"AliasGroup3")
      .withColumn("Group4", $"AliasGroup4")
      .withColumn("PracticePatientNoteKey", $"AliasPracticePatientNoteKey")
      .withColumn("ModifiedDate", lit(current_timestamp))
      .drop("AliasNote", "AliasGroup1", "AliasGroup2", "AliasGroup3", "AliasGroup4", "AliasPracticePatientNoteKey")

    val whereclausePatientNote1 = CleanData1.filter($"StatusId" === 1).as("df1")
      .join(PatientNoteTable_prod.as("df2"), $"df1.PatientNoteUid" === $"df2.PatientNoteUid")
      .select($"df2.*")

    val ExceptUpdatPatientNote = CleanData1.except(whereclausePatientNote1)
    var PatientNoteTable_prod_Delta = UpdatePatientNote.union(ExceptUpdatPatientNote)

    //Insert record into PatientNotes after updating all uid's in cache notes table
    val InsertIntoUpdatPatientNote1 = CleanData1.filter($"StatusId" === 1).as("df1")
      .join(PatientNoteTable_prod_Delta.filter($"PatientNoteUid".isNull).as("df2"), $"df1.PatientNoteUid" === $"df2.PatientNoteUid", "left_outer")
      .select($"df2.*", $"df1.PatientNoteUid",
        $"df1.PatientUid",
        $"df1.ClinicalInformationModelSectionUid",
        $"df1.Note",
        $"df1.EncounterDate".as("ReferenceDate"),
        $"df1.ServiceProviderUid",
        $"df1.ServiceLocationUid",
        $"df1.Group1",
        $"df1.Group2",
        $"df1.Group3",
        $"df1.Group4",
        $"df1.PracticePatientNoteKey")
      .withColumn("CreatedDate", lit(current_timestamp))
      .withColumn("CreatedByUid", lit(null))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ModifiedByUid", lit(null))

    val allcols5 = PatientNoteTable_prod_Delta.columns.toSet
    val insert5 = InsertIntoUpdatPatientNote1.columns.toSet
    val tot5 = allcols5 ++ insert5

    PatientNoteTable_prod_Delta = PatientNoteTable_prod_Delta.select(FunctionUtility.addColumns(allcols5, tot5): _*)
      .union(InsertIntoUpdatPatientNote1.select(FunctionUtility.addColumns(insert5, tot5): _*))

    logger.warn("End PatientNotes Done..................")

    List(PatientNoteTable_prod_Delta, Individual_prod_Delta7, ServiceProvider_prod_Delta6, Institution_Prod_Delta3,
      ServiceLocation_Prod_Delta3)

  }
}
