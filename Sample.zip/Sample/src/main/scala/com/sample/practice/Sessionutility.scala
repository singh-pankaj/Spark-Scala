package com.sample.practice

import org.apache.spark.sql.SparkSession

class Sessionutility {

  def sparkSession() : SparkSession = {

    val spark = SparkSession.builder()
      .master("local[*]")
      //.master("yarn")
      .appName("MainClass")
      .getOrCreate()

    spark

  }

}
