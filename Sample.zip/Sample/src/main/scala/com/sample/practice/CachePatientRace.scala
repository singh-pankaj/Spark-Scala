package com.sample.practice

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

class CachePatientRace {

  def CachePatientRaceFunc(spark : SparkSession,CDRPatientCrosswalkTable : DataFrame
                           ,MergePracticeMap : DataFrame,MasterRace_Prod : DataFrame
                           ,IndividualRace_Prod : DataFrame,Patient_Prod_Delta : DataFrame
                           ,Individual_prod_Delta : DataFrame,MappingPracticeCommonData_Delta : DataFrame) : List[DataFrame] = {


    import spark.implicits._

    //Start CachePatientRace
    val logger = LoggerFactory.getLogger("")

    var CachePatientRaceTable = spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/52ddf45c-6d51-418f-be58-eb8ce57fa2a1_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")

    val lookup3 = Map("_c0" -> "PatientId", "_c1" -> "PatientRaceCode", "_c2" -> "PatientRaceText"
      , "_c3" -> "PatientRaceKey", "_c4" -> "PracticeUid"
      , "_c5" -> "BatchUid", "_c6" -> "dummy1", "_c7" -> "dummy2")

    CachePatientRaceTable = CachePatientRaceTable.select(CachePatientRaceTable.columns.map(c => col(c).as(lookup3.getOrElse(c, c))): _*)

    val tempEthRaceallCols = spark.read.option("header", "true")
      .csv("/home/gajanan.doifode/AAO_DATA/Schema/CachePatientRace.txt")

    val EthRaceAllColls = tempEthRaceallCols.columns.toSet
    val viewERacecolls = CachePatientRaceTable.columns.toSet
    val total_viewR_CdrR = EthRaceAllColls ++ viewERacecolls

    CachePatientRaceTable = tempEthRaceallCols.select(FunctionUtility.addColumns(EthRaceAllColls, total_viewR_CdrR): _*)
      .union(CachePatientRaceTable.select(FunctionUtility.addColumns(viewERacecolls, total_viewR_CdrR): _*))
      .drop("dummy1", "dummy2")

    CachePatientRaceTable = CachePatientRaceTable.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))


    //Update PracticeUid = OriginalPracticeuid

    val dist_Prac_Uid_PateintEthRace = CachePatientRaceTable.filter($"StatusId".isNull).select("PracticeUid").distinct()


    val tempMergePracticeMapRace = MergePracticeMap.as("df1").join(dist_Prac_Uid_PateintEthRace.as("df2")
      , $"df1.NewPracticeUid" === $"df2.PracticeUid").select($"df1.*")

    //Update PracticeUid == OriginalPracticeuid of patientRaceTable
    CachePatientRaceTable = CachePatientRaceTable.as("df1").join(tempMergePracticeMapRace.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeUid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeUid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid == OriginalPracticeUid of patientRaceTable is Done............")

    CachePatientRaceTable = CachePatientRaceTable.withColumn("StatusId", lit(1))

    //Update Multiple Columns of Race
    CachePatientRaceTable = CachePatientRaceTable.filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"PracticeUid")
      .withColumn("PatientRaceCode", rtrim(ltrim($"PatientRaceCode")))
      .withColumn("PatientRaceText", rtrim(ltrim($"PatientRaceText")))
      .withColumn("PatientId", rtrim(ltrim($"PatientId")))

    logger.warn("Update Multiple Columns of Race Table is Done............")

    //Find RaceCode/Text is Null update statusid = 3
    val updateStatusRace = CachePatientRaceTable.as("df1").filter($"PatientRaceCode".isNull
      && $"PatientRaceText".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("RaceCode/Text is Null"))

    val whereclauseRace = CachePatientRaceTable.as("df1").filter($"PatientRaceCode".isNull
      && $"PatientRaceText".isNull)

    if (whereclauseRace.count > 0) {
      val ex = CachePatientRaceTable.except(whereclauseRace)
      CachePatientRaceTable = ex.union(updateStatusRace)
    }

    logger.warn("Find RaceCode/Text is Null update statusid = 3 is Done............")

    //PatientId is Missing of race table
    val updateStatusRace2 = CachePatientRaceTable.filter($"PatientId".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val whereclauseRace2 = CachePatientRaceTable.filter($"PatientId".isNull && $"StatusId" === 1)

    if (whereclauseRace2.count > 0) {
      val ex = CachePatientRaceTable.except(whereclauseRace2)
      CachePatientRaceTable = ex.union(updateStatusRace2)
    }

    logger.warn("Find PatientId is Missing update statusid = 3 of Race table is Done............")

    // Update cpd set cpd.PatientId=dpc.Old_PatientId

    val updatePatientIdRace = CachePatientRaceTable.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val wherePatientIdRace = CachePatientRaceTable.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")


    if (wherePatientIdRace.count > 0) {
      val ex = CachePatientRaceTable.except(wherePatientIdRace)
      CachePatientRaceTable = ex.union(updatePatientIdRace)
    }

    logger.warn("Update patientID = Old_PatientId using CDRPatient Table of Race Table is Done............")

    //Update PatientUid of Race Table using Multiple Tables
    val updatePatientUidRace = CachePatientRaceTable.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val wherePatientUidRace = CachePatientRaceTable.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.IndividualUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")


    if (wherePatientUidRace.count > 0) {
      val ex = CachePatientRaceTable.except(wherePatientUidRace)
      CachePatientRaceTable = ex.union(updatePatientUidRace)
    }

    logger.warn("Update PatientUid From PatientId using Multiple Tables of Race Table is Done............")

    //Patient Not Found of Race Table
    val updateStatusRace3 = CachePatientRaceTable.filter($"PatientUid".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val whereclauseRace3 = CachePatientRaceTable.filter($"PatientUid".isNull && $"StatusId" === 1)

    if (whereclauseRace3.count > 0) {
      val ex = CachePatientRaceTable.except(whereclauseRace3)
      CachePatientRaceTable = ex.union(updateStatusRace3)
    }

    logger.warn("Patient Not Found of Race Table is Done............")

    //update cpd set RaceUid  = mpc.MappedUid

    val updateRaceUidUid = CachePatientRaceTable.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PatientRaceCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "ABD35AA4-DEF5-44F6-B515-5E7A5DE1E9AA")
      .filter($"df1.StatusId" === 1 && $"df1.RaceUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("RaceUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val whereRaceUidUid = CachePatientRaceTable.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PatientRaceCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "ABD35AA4-DEF5-44F6-B515-5E7A5DE1E9AA")
      .filter($"df1.StatusId" === 1 && $"df1.RaceUid".isNull)
      .select($"df1.*")

    if (whereRaceUidUid.count > 0) {
      val ex = CachePatientRaceTable.except(whereRaceUidUid)
      CachePatientRaceTable = ex.union(updateRaceUidUid)
    }

    logger.warn("Update RaceUid from MappingPracticeCommonData  is Done............")


    //update cpd set RaceUid  = mpc.MappedUid

    val updateRaceUidUid2 = CachePatientRaceTable.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PatientRaceText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "ABD35AA4-DEF5-44F6-B515-5E7A5DE1E9AA")
      .filter($"df1.StatusId" === 1 && $"df1.RaceUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("RaceUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val whereRaceUidUid2 = CachePatientRaceTable.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.PatientRaceText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "ABD35AA4-DEF5-44F6-B515-5E7A5DE1E9AA")
      .filter($"df1.StatusId" === 1 && $"df1.RaceUid".isNull)
      .select($"df1.*")

    if (whereRaceUidUid2.count > 0) {
      val ex = CachePatientRaceTable.except(whereRaceUidUid2)
      CachePatientRaceTable = ex.union(updateRaceUidUid2)
    }

    logger.warn("Update RaceUid from MappingPracticeCommonData  is Done............")

    //Update RaceUid using MasterTable on PatientRaceCode


    val updateraceUid4 = CachePatientRaceTable.as("df1").join(MasterRace_Prod.as("df2")
      , $"df1.PatientRaceCode" === $"df2.ExternalID")
      .filter($"df1.StatusId" === 1 && $"df1.RaceUid".isNull)
      .select($"df1.*", $"df2.RaceUid".as("aliasRaceUid"))
      .withColumn("RaceUid", $"aliasRaceUid")
      .drop("aliasRaceUid")

    val whereraceUid4 = CachePatientRaceTable.as("df1").join(MasterRace_Prod.as("df2")
      , $"df1.PatientRaceCode" === $"df2.ExternalID")
      .filter($"df1.StatusId" === 1 && $"df1.RaceUid".isNull)
      .select($"df1.*")

    if (whereraceUid4.count > 0) {
      val ex = CachePatientRaceTable.except(whereraceUid4)
      CachePatientRaceTable = ex.union(updateraceUid4)
    }
    logger.warn("Update Raceid from MasterRace table on PatientRaceCode is Done............")

    //Update Raceid from MasterRace table on PatientRaceText
    val updateraceUid5 = CachePatientRaceTable.as("df1").join(MasterRace_Prod.as("df2")
      , $"df1.PatientRaceText" === $"df2.Description")
      .filter($"df1.StatusId" === 1 && $"df1.RaceUid".isNull)
      .select($"df1.*", $"df2.RaceUid".as("aliasRaceUid"))
      .withColumn("RaceUid", $"aliasRaceUid")
      .drop("aliasRaceUid")

    val whereraceUid5 = CachePatientRaceTable.as("df1").join(MasterRace_Prod.as("df2")
      , $"df1.PatientRaceText" === $"df2.Description")
      .filter($"df1.StatusId" === 1 && $"df1.RaceUid".isNull)
      .select($"df1.*")

    if (whereraceUid5.count > 0) {
      val ex = CachePatientRaceTable.except(whereraceUid5)
      CachePatientRaceTable = ex.union(updateraceUid5)
    }
    logger.warn("Update Raceid from MasterRace table on PatientRaceText is Done............")


    //Remove Duplicates Of Race Table

    var cleanedCachePatientRaceTable = CachePatientRaceTable.dropDuplicates(Seq("PatientUid", "RaceUid"))
    val dropDuplicatesRace1 = CachePatientRaceTable.dropDuplicates(Seq("PatientUid", "PatientRaceText"))
    cleanedCachePatientRaceTable = cleanedCachePatientRaceTable.union(dropDuplicatesRace1)

    var duplicatesRecordsRace1 = CachePatientRaceTable.except(cleanedCachePatientRaceTable)
    val duplicaterecordsRace2 = CachePatientRaceTable.except(dropDuplicatesRace1)
    duplicatesRecordsRace1 = duplicatesRecordsRace1.union(duplicaterecordsRace2)

    logger.warn("Remove Duplicates of Race Table is Done............")


    //Not Implement
    /*delete from  IE  from #chPatientRace CPD
      inner join IndividualRace IE on IE.IndividualUid=CPD.PatientUid
    Where CPD.StatusID=1 and CPD.RaceUid is not null*/


    val insert_IndividualRace_Prod = cleanedCachePatientRaceTable.as("df2").join(IndividualRace_Prod.as("df1")
      , $"df2.PatientUid" === $"df1.IndividualUid" && $"df2.PatientRaceText" === $"df1.PracticeRaceText", "left_outer")
      .filter($"df1.PracticeRaceText".isNull && $"df1.IndividualUid".isNull && $"df2.StatusId" === 1)
      .select($"df2.PatientUid".as("IndividualUid"), $"df2.RaceUid".as("RaceUid"),
        $"df2.PatientRaceText".as("PracticeRaceText"))
      .withColumn("IndividualRaceUid", FunctionUtility.getNewUid())
      .withColumn("CreatedDate", current_timestamp())

    val RaceCols = IndividualRace_Prod.columns.toSet
    val insert_racecols = insert_IndividualRace_Prod.columns.toSet
    val tot_cols1 = RaceCols ++ insert_racecols

    val IndividualRace_Prod1 = IndividualRace_Prod.select(FunctionUtility.addColumns(RaceCols, tot_cols1): _*)
      .union(insert_IndividualRace_Prod.select(FunctionUtility.addColumns(insert_racecols, tot_cols1): _*))

    logger.warn("PatientRace Sp is Done............")


    List(IndividualRace_Prod1)
  }

}
