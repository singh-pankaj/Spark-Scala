package com.sample.practice

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

class CacheAdvanceDirective {

  def CacheAdvanceDirectiveFunc(spark : SparkSession,MergePracticeMap : DataFrame,
                                CDRPatientCrosswalkTable : DataFrame,Master_prod : DataFrame,
                                PatientAdvanceDirectiveObservation_Prod : DataFrame
                                ,MappingPracticeCommonData_Delta : DataFrame
                                ,Patient_Prod_Delta : DataFrame,Individual_prod_Delta3 : DataFrame) : List[DataFrame] = {
    val logger = LoggerFactory.getLogger("")

    import spark.implicits._

    //Start CacheAdvanceDirective
    var CacheAdvanceDirective = spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9")

    val lookup7 = Map("_c0" -> "PatientId", "_c1" -> "AdvanceDirectiveTypeCode", "_c2" -> "AdvanceDirectiveTypeDetails"
      , "_c3" -> "AdvanceDirectiveStatusCode", "_c4" -> "AdvanceDirectiveStatusText", "_c5" -> "EffectiveStartDate"
      , "_c6" -> "EffectiveEndDate", "_c7" -> "AgentName"
      , "_c8" -> "ExternalDocumentLink", "_c9" -> "GroupName", "_c10" -> "AdvanceDirectiveTypeText"
      , "_c11" -> "AdvanceDirectiveKey", "_c12" -> "PracticeUid", "_c13" -> "BatchUid"
      , "_c14" -> "dummy1", "_c15" -> "dummy2")

    CacheAdvanceDirective = CacheAdvanceDirective.select(CacheAdvanceDirective.columns.map(c => col(c).as(lookup7.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    val tempCacheAdvanceDirective = spark.read.option("header", "true")
      .csv("/home/gajanan.doifode/AAO_DATA/Schema/CacheAdvanceDirective.txt")

    val CacheAdvanceDirectiveallcols = tempCacheAdvanceDirective.columns.toSet
    val CacheAdvanceDirectiveViewcols = CacheAdvanceDirective.columns.toSet
    val tot_viewCAD_cacheAdvDir = CacheAdvanceDirectiveallcols ++ CacheAdvanceDirectiveViewcols

    CacheAdvanceDirective = tempCacheAdvanceDirective.select(FunctionUtility.addColumns(CacheAdvanceDirectiveallcols, tot_viewCAD_cacheAdvDir): _*)
      .union(CacheAdvanceDirective.select(FunctionUtility.addColumns(CacheAdvanceDirectiveViewcols, tot_viewCAD_cacheAdvDir): _*))

    CacheAdvanceDirective = CacheAdvanceDirective.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    val dist_PUID_CAdvDirect = CacheAdvanceDirective.filter($"StatusId".isNull).select("PracticeUid").distinct()

    val tempMergePracticeMap_CAdvDirect = MergePracticeMap.as("df1").join(dist_PUID_CAdvDirect.as("df2")
      , $"df1.NewPracticeUid" === $"df2.PracticeUid").select($"df1.*")

    //Update PracticeUid with OriginalPracticeUid of CacheAdvanceDirective
    CacheAdvanceDirective = CacheAdvanceDirective.as("df1").join(tempMergePracticeMap_CAdvDirect.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeUid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeUid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeUid of CacheAdvanceDirective is Done.................")

    CacheAdvanceDirective = CacheAdvanceDirective.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CacheAdvanceDirective
    CacheAdvanceDirective = CacheAdvanceDirective.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PatientId", rtrim(ltrim($"df1.PatientId")))
      .withColumn("AdvanceDirectiveTypeUid", rtrim(ltrim($"df1.AdvanceDirectiveTypeUid")))

    logger.warn("Update Multiple Columns of CacheAdvanceDirective is Done............")

    //update status if PatientId is null Of CacheAdvanceDirectives
    val update_status_CAdvDir = CacheAdvanceDirective.filter($"StatusId" === 1 && $"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val where_status_CAdvDir = CacheAdvanceDirective.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_status_CAdvDir.count > 0) {
      val ex = CacheAdvanceDirective.except(where_status_CAdvDir)
      CacheAdvanceDirective = ex.union(update_status_CAdvDir)
    }

    logger.warn("update status if PatientId is null Of CacheAdvanceDirectives is Done............")

    //Update PatientId using CDRPatientCrosswalk In CacheAdvanceDirective Table
    val updatePatientId_CacheAdvanceDirective = CacheAdvanceDirective.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientId_CacheAdvanceDirective = CacheAdvanceDirective.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientId_CacheAdvanceDirective.count > 0) {
      val ex = CacheAdvanceDirective.except(where_PatientId_CacheAdvanceDirective)
      CacheAdvanceDirective = ex.union(updatePatientId_CacheAdvanceDirective)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk In CacheAdvanceDirective Table is Done............")


    //update status if AdvanceDirectiveTypeUid is null and so on Of CacheAdvanceDirectives
    val update_status_CAdvDir2 = CacheAdvanceDirective.filter($"StatusId" === 1 && $"AdvanceDirectiveTypeUid".isNull
      && ltrim(rtrim($"AdvanceDirectiveTypeCode")).isNull && ltrim(rtrim($"AdvanceDirectiveTypeDetails")).isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("AdvanceDirectiveTypeDetails AND AdvanceDirectiveTypeCode Is Missing Or Not Found"))

    val where_status_CAdvDir2 = CacheAdvanceDirective.filter($"StatusId" === 1 && $"AdvanceDirectiveTypeUid".isNull
      && ltrim(rtrim($"AdvanceDirectiveTypeCode")).isNull && ltrim(rtrim($"AdvanceDirectiveTypeDetails")).isNull)

    if (where_status_CAdvDir2.count > 0) {
      val ex = CacheAdvanceDirective.except(where_status_CAdvDir2)
      CacheAdvanceDirective = ex.union(update_status_CAdvDir2)
    }

    logger.warn("update status if PatientId is null Of CacheAdvanceDirectives is Done............")

    //Update PatientUid Using Patient and Individual table of CacheAdvanceDirective
    val updatePatientUid_AdvDir = CacheAdvanceDirective.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta3.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val where_PatientUid_AdvDir = CacheAdvanceDirective.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta3.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientUid_AdvDir.count > 0) {
      val ex = CacheAdvanceDirective.except(where_PatientUid_AdvDir)
      CacheAdvanceDirective = ex.union(updatePatientUid_AdvDir)
    }

    logger.warn("Update PatientUid Using Patient and Individual table of CacheAdvanceDirective is Done............")

    //update status if PatientUid is null Of CacheAdvanceDirective
    val update_status_CAdvDir22 = CacheAdvanceDirective.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_status_CAdvDir22 = CacheAdvanceDirective.filter($"StatusId" === 1 && $"PatientUid".isNull)

    if (where_status_CAdvDir22.count > 0) {
      val ex = CacheAdvanceDirective.except(where_status_CAdvDir22)
      CacheAdvanceDirective = ex.union(update_status_CAdvDir22)
    }

    logger.warn("update status if PatientUid is null Of CacheAdvanceDirective is Done............")


    //update AdvanceDirectiveTypeUid from MappingPracticeCommonData of CacheAdvanceDirective
    val update_AdvanceDirectiveTypeUid = CacheAdvanceDirective.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.AdvanceDirectiveTypeCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "5F515556-4B55-4BC9-B222-B5CB5176A03E" && $"df2.MappedUid".isNotNull)
      .where($"df1.StatusId" === 1 && $"df1.AdvanceDirectiveTypeUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("AdvanceDirectiveTypeUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_AdvanceDirectiveTypeUid = CacheAdvanceDirective.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.AdvanceDirectiveTypeCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "5F515556-4B55-4BC9-B222-B5CB5176A03E" && $"df2.MappedUid".isNotNull)
      .where($"df1.StatusId" === 1 && $"df1.AdvanceDirectiveTypeUid".isNull)
      .select($"df1.*")

    if (where_AdvanceDirectiveTypeUid.count > 0) {
      val ex = CacheAdvanceDirective.except(where_AdvanceDirectiveTypeUid)
      CacheAdvanceDirective = ex.union(update_AdvanceDirectiveTypeUid)
    }

    logger.warn("update AdvanceDirectiveTypeUid from MappingPracticeCommonData of CacheAdvanceDirective is Done............")

    //update AdvanceDirectiveTypeUid from MappingPracticeCommonData of CacheAdvanceDirective 2
    val update_AdvanceDirectiveTypeUid2 = CacheAdvanceDirective.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.AdvanceDirectiveTypeDetails" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "5F515556-4B55-4BC9-B222-B5CB5176A03E" && $"df2.MappedUid".isNotNull)
      .where($"df1.StatusId" === 1 && $"df1.AdvanceDirectiveTypeUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("AdvanceDirectiveTypeUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_AdvanceDirectiveTypeUid2 = CacheAdvanceDirective.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.AdvanceDirectiveTypeDetails" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "5F515556-4B55-4BC9-B222-B5CB5176A03E" && $"df2.MappedUid".isNotNull)
      .where($"df1.StatusId" === 1 && $"df1.AdvanceDirectiveTypeUid".isNull)
      .select($"df1.*")

    if (where_AdvanceDirectiveTypeUid2.count > 0) {
      val ex = CacheAdvanceDirective.except(where_AdvanceDirectiveTypeUid2)
      CacheAdvanceDirective = ex.union(update_AdvanceDirectiveTypeUid2)
    }

    logger.warn("update AdvanceDirectiveTypeUid from MappingPracticeCommonData of CacheAdvanceDirective 2 is Done........")

    //Update AdvanceDirectiveTypeUid from Master Table of CacheAdvanceDirective
    val update_AdvanceDirectiveTypeUid3 = CacheAdvanceDirective.as("df1").join(Master_prod.as("df2"),
      $"df1.AdvanceDirectiveTypeCode" === $"df2.Code" && $"df1.StatusId" === 1 && $"df1.AdvanceDirectiveTypeUid".isNull
        && $"df2.Type" === "AdvanceDirectiveType")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("AdvanceDirectiveTypeUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_AdvanceDirectiveTypeUid3 = CacheAdvanceDirective.as("df1").join(Master_prod.as("df2"),
      $"df1.AdvanceDirectiveTypeCode" === $"df2.Code" && $"df1.StatusId" === 1 && $"df1.AdvanceDirectiveTypeUid".isNull
        && $"df2.Type" === "AdvanceDirectiveType")
      .select($"df1.*")

    if (where_AdvanceDirectiveTypeUid3.count > 0) {
      val ex = CacheAdvanceDirective.except(where_AdvanceDirectiveTypeUid3)
      CacheAdvanceDirective = ex.union(update_AdvanceDirectiveTypeUid3)
    }

    logger.warn("Update AdvanceDirectiveTypeUid from Master Table of CacheAdvanceDirective is Done........")

    //Update AdvanceDirectiveTypeUid from Master Table of CacheAdvanceDirective 2
    val update_AdvanceDirectiveTypeUid4 = CacheAdvanceDirective.as("df1").join(Master_prod.as("df2"),
      $"df1.AdvanceDirectiveTypeDetails" === $"df2.Code" && $"df1.StatusId" === 1 && $"df1.AdvanceDirectiveTypeUid".isNull
        && $"df2.Type" === "AdvanceDirectiveType")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("AdvanceDirectiveTypeUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_AdvanceDirectiveTypeUid4 = CacheAdvanceDirective.as("df1").join(Master_prod.as("df2"),
      $"df1.AdvanceDirectiveTypeDetails" === $"df2.Code" && $"df1.StatusId" === 1 && $"df1.AdvanceDirectiveTypeUid".isNull
        && $"df2.Type" === "AdvanceDirectiveType")
      .select($"df1.*")

    if (where_AdvanceDirectiveTypeUid4.count > 0) {
      val ex = CacheAdvanceDirective.except(where_AdvanceDirectiveTypeUid4)
      CacheAdvanceDirective = ex.union(update_AdvanceDirectiveTypeUid4)
    }

    logger.warn("Update AdvanceDirectiveTypeUid from Master Table of CacheAdvanceDirective 2 is Done........")

    //if AdvanceDirective text or Code is not Null then mapped it to Other Directive
    val update_AdvanceDirectiveTypeUid5 = CacheAdvanceDirective.filter($"StatusId" === 1 &&
      $"AdvanceDirectiveTypeUid".isNull && rtrim(ltrim($"AdvanceDirectiveTypeCode")).isNotNull &&
      rtrim(ltrim($"AdvanceDirectiveTypeDetails")).isNotNull)
      .withColumn("AdvanceDirectiveTypeUid", lit("E7F9589F-C972-4DFD-B913-832E97A3EF0D"))

    val where_AdvanceDirectiveTypeUid5 = CacheAdvanceDirective.filter($"StatusId" === 1 &&
      $"AdvanceDirectiveTypeUid".isNull && rtrim(ltrim($"AdvanceDirectiveTypeCode")).isNotNull &&
      rtrim(ltrim($"AdvanceDirectiveTypeDetails")).isNotNull)

    if (where_AdvanceDirectiveTypeUid5.count > 0) {
      val ex = CacheAdvanceDirective.except(where_AdvanceDirectiveTypeUid5)
      CacheAdvanceDirective = ex.union(update_AdvanceDirectiveTypeUid5)
    }

    logger.warn("if AdvanceDirective text or Code is not Null then mapped it to Other Directive is Done........")

    //update AdvanceDirectiveStatusUid from MappingPracticeCommonData of CacheAdvanceDirective
    val update_AdvanceDirectiveStatusUid = CacheAdvanceDirective.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.AdvanceDirectiveStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "FF31826B-C9CA-441C-94E0-E8FD0815FDC7")
      .where($"df1.StatusId" === 1 && $"df1.AdvanceDirectiveStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("AdvanceDirectiveStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_AdvanceDirectiveStatusUid = CacheAdvanceDirective.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.AdvanceDirectiveStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "FF31826B-C9CA-441C-94E0-E8FD0815FDC7")
      .where($"df1.StatusId" === 1 && $"df1.AdvanceDirectiveStatusUid".isNull)
      .select($"df1.*")

    if (where_AdvanceDirectiveStatusUid.count > 0) {
      val ex = CacheAdvanceDirective.except(where_AdvanceDirectiveStatusUid)
      CacheAdvanceDirective = ex.union(update_AdvanceDirectiveStatusUid)
    }

    logger.warn("update AdvanceDirectiveStatusUid from MappingPracticeCommonData of CacheAdvanceDirective is Done......")

    //update AdvanceDirectiveStatusUid from MappingPracticeCommonData of CacheAdvanceDirective 2
    val update_AdvanceDirectiveStatusUid2 = CacheAdvanceDirective.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.AdvanceDirectiveStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "FF31826B-C9CA-441C-94E0-E8FD0815FDC7")
      .where($"df1.StatusId" === 1 && $"df1.AdvanceDirectiveStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("AdvanceDirectiveStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_AdvanceDirectiveStatusUid2 = CacheAdvanceDirective.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.AdvanceDirectiveStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "FF31826B-C9CA-441C-94E0-E8FD0815FDC7")
      .where($"df1.StatusId" === 1 && $"df1.AdvanceDirectiveStatusUid".isNull)
      .select($"df1.*")

    if (where_AdvanceDirectiveStatusUid2.count > 0) {
      val ex = CacheAdvanceDirective.except(where_AdvanceDirectiveStatusUid2)
      CacheAdvanceDirective = ex.union(update_AdvanceDirectiveStatusUid2)
    }

    logger.warn("update AdvanceDirectiveStatusUid from MappingPracticeCommonData of CacheAdvanceDirective 2 is Done......")

    //Update AdvanceDirectiveStatusUid from Master Table of CacheAdvanceDirective
    val update_AdvanceDirectiveStatusUid3 = CacheAdvanceDirective.as("df1").join(Master_prod.as("df2"),
      $"df1.AdvanceDirectiveStatusCode" === $"df2.Code" && $"df1.StatusId" === 1 && $"df1.AdvanceDirectiveStatusUid".isNull
        && $"df2.Type" === "AdvanceDirectiveStatus")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("AdvanceDirectiveStatusUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_AdvanceDirectiveStatusUid3 = CacheAdvanceDirective.as("df1").join(Master_prod.as("df2"),
      $"df1.AdvanceDirectiveStatusCode" === $"df2.Code" && $"df1.StatusId" === 1 && $"df1.AdvanceDirectiveStatusUid".isNull
        && $"df2.Type" === "AdvanceDirectiveStatus")
      .select($"df1.*")

    if (where_AdvanceDirectiveStatusUid3.count > 0) {
      val ex = CacheAdvanceDirective.except(where_AdvanceDirectiveStatusUid3)
      CacheAdvanceDirective = ex.union(update_AdvanceDirectiveStatusUid3)
    }

    logger.warn("Update AdvanceDirectiveStatusUid from Master Table of CacheAdvanceDirective is Done........")

    //Update AdvanceDirectiveStatusUid from Master Table of CacheAdvanceDirective 2
    val update_AdvanceDirectiveStatusUid4 = CacheAdvanceDirective.as("df1").join(Master_prod.as("df2"),
      $"df1.AdvanceDirectiveStatusText" === $"df2.Code" && $"df1.StatusId" === 1 && $"df1.AdvanceDirectiveStatusUid".isNull
        && $"df2.Type" === "AdvanceDirectiveStatus")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("AdvanceDirectiveStatusUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_AdvanceDirectiveStatusUid4 = CacheAdvanceDirective.as("df1").join(Master_prod.as("df2"),
      $"df1.AdvanceDirectiveStatusText" === $"df2.Code" && $"df1.StatusId" === 1 && $"df1.AdvanceDirectiveStatusUid".isNull
        && $"df2.Type" === "AdvanceDirectiveStatus")
      .select($"df1.*")

    if (where_AdvanceDirectiveStatusUid4.count > 0) {
      val ex = CacheAdvanceDirective.except(where_AdvanceDirectiveStatusUid4)
      CacheAdvanceDirective = ex.union(update_AdvanceDirectiveStatusUid4)
    }

    logger.warn("Update AdvanceDirectiveStatusUid from Master Table of CacheAdvanceDirective 2 is Done........")

    //update status if AdvanceDirectiveStatusUid is null Of CacheAdvanceDirective
    val update_status_CAdvDir222 = CacheAdvanceDirective.filter($"StatusId" === 1 && $"AdvanceDirectiveStatusUid".isNull
      && rtrim(ltrim($"AdvanceDirectiveStatusCode")).isNotNull && rtrim(ltrim($"AdvanceDirectiveStatusText")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("AdvanceDirectiveStatus Not Mapped"))

    val where_status_CAdvDir222 = CacheAdvanceDirective.filter($"StatusId" === 1 && $"AdvanceDirectiveStatusUid".isNull
      && rtrim(ltrim($"AdvanceDirectiveStatusCode")).isNotNull && rtrim(ltrim($"AdvanceDirectiveStatusText")).isNotNull)
      .withColumn("StatusId", lit(3))

    if (where_status_CAdvDir222.count > 0) {
      val ex = CacheAdvanceDirective.except(where_status_CAdvDir222)
      CacheAdvanceDirective = ex.union(update_status_CAdvDir222)
    }

    logger.warn("update status if AdvanceDirectiveStatusUid is null Of CacheAdvanceDirective is Done........")


    //Update PatientAdvanceDirectiveObservationUid of CacheAdvanceDirective using PatientAdvanceDirectiveObservation
    val update_CacheAdvanceDirective_PADOUid = CacheAdvanceDirective.as("df1").join(PatientAdvanceDirectiveObservation_Prod.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid" && $"df1.StatusId" === 1 &&
        $"df1.AdvanceDirectiveTypeUid" === $"df2.MasterAdvanceDirectiveTypeUid" &&
        $"df1.EffectiveStartDate" === $"df2.EffectiveStartDate" &&
        $"df1.AdvanceDirectiveTypeDetails" === $"df2.AdvanceDirectiveTypeDetails")
      .select($"df1.*", $"df2.PatientAdvanceDirectiveObservationUid".as("aliasPADOUID"))
      .withColumn("PatientAdvanceDirectiveObservationUid", $"aliasPADOUID")
      .drop("aliasPADOUID")

    val where_CacheAdvanceDirective_PADOUid = CacheAdvanceDirective.as("df1").join(PatientAdvanceDirectiveObservation_Prod.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid" && $"df1.StatusId" === 1 &&
        $"df1.AdvanceDirectiveTypeUid" === $"df2.MasterAdvanceDirectiveTypeUid" &&
        $"df1.EffectiveStartDate" === $"df2.EffectiveStartDate" &&
        $"df1.AdvanceDirectiveTypeDetails" === $"df2.AdvanceDirectiveTypeDetails")
      .select($"df1.*")

    if (where_CacheAdvanceDirective_PADOUid.count > 0) {
      val ex = CacheAdvanceDirective.except(where_CacheAdvanceDirective_PADOUid)
      CacheAdvanceDirective = ex.union(update_CacheAdvanceDirective_PADOUid)
    }

    logger.warn("Update PatientAdvanceDirectiveObservationUid of CacheAdvanceDirective using " +
      "PatientAdvanceDirectiveObservation is Done........")


    //Drop Duplicate records of CacheAdvanceDirective
    var cleanedCacheAdvanceDirective = CacheAdvanceDirective.dropDuplicates(Seq("PatientId", "AdvanceDirectiveTypeUid"
      , "AdvanceDirectiveTypeDetails", "EffectiveStartDate"))

    var duplicateRecords_CacheAdvanceDirective = CacheAdvanceDirective.except(cleanedCacheAdvanceDirective)

    logger.warn("Drop Duplicate records of CacheAdvanceDirective is Done............")

    //Create Table #AdvanceDirective
    val tempAdvanceDirective = cleanedCacheAdvanceDirective.filter($"StatusId" === 1 &&
      $"PatientAdvanceDirectiveObservationUid".isNull && $"EffectiveStartDate".isNotNull)
      .select("PatientUid", "AdvanceDirectiveTypeUid", "AdvanceDirectiveTypeDetails", "EffectiveStartDate").distinct()
      .withColumn("PatientAdvanceDirectiveObservationUid", FunctionUtility.getNewUid())

    //Update PatientAdvanceDirectiveObservationUid of CacheAdvanceDirective using #AdvanceDirective is Done
    val update_CacheAdvanceDirective_PADOUid2 = cleanedCacheAdvanceDirective.as("df1").join(tempAdvanceDirective.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid" && $"df1.StatusId" === 1 &&
        $"df1.AdvanceDirectiveTypeUid" === $"df2.AdvanceDirectiveTypeUid" &&
        $"df1.EffectiveStartDate" === $"df2.EffectiveStartDate" &&
        $"df1.AdvanceDirectiveTypeDetails" === $"df2.AdvanceDirectiveTypeDetails")
      .select($"df1.*", $"df2.PatientAdvanceDirectiveObservationUid".as("aliasPADOUID"))
      .withColumn("PatientAdvanceDirectiveObservationUid", $"aliasPADOUID")
      .drop("aliasPADOUID")

    val where_CacheAdvanceDirective_PADOUid2 = cleanedCacheAdvanceDirective.as("df1").join(tempAdvanceDirective.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid" && $"df1.StatusId" === 1 &&
        $"df1.AdvanceDirectiveTypeUid" === $"df2.AdvanceDirectiveTypeUid" &&
        $"df1.EffectiveStartDate" === $"df2.EffectiveStartDate" &&
        $"df1.AdvanceDirectiveTypeDetails" === $"df2.AdvanceDirectiveTypeDetails")
      .select($"df1.*")

    if (where_CacheAdvanceDirective_PADOUid2.count > 0) {
      val ex = cleanedCacheAdvanceDirective.except(where_CacheAdvanceDirective_PADOUid2)
      cleanedCacheAdvanceDirective = ex.union(update_CacheAdvanceDirective_PADOUid2)
    }

    logger.warn("Update PatientAdvanceDirectiveObservationUid of CacheAdvanceDirective using " +
      "#AdvanceDirective is Done........")

    //Update PatientAdvanceDirectiveObservationUid of CacheAdvanceDirective using PatientAdvanceDirectiveObservation 2
    val update_CacheAdvanceDirective_PADOUid3 = cleanedCacheAdvanceDirective.as("df1").join(PatientAdvanceDirectiveObservation_Prod.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid" && $"df1.StatusId" === 1 && $"df1.EffectiveStartDate".isNull &&
        $"df1.AdvanceDirectiveTypeUid" === $"df2.MasterAdvanceDirectiveTypeUid" && $"df2.EffectiveDate".isNull &&
        $"df1.AdvanceDirectiveTypeDetails" === $"df2.AdvanceDirectiveTypeDetails")
      .select($"df1.*", $"df2.PatientAdvanceDirectiveObservationUid".as("aliasPADOUID"))
      .withColumn("PatientAdvanceDirectiveObservationUid", $"aliasPADOUID")
      .drop("aliasPADOUID")

    val where_CacheAdvanceDirective_PADOUid3 = cleanedCacheAdvanceDirective.as("df1").join(PatientAdvanceDirectiveObservation_Prod.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid" && $"df1.StatusId" === 1 && $"df1.EffectiveStartDate".isNull &&
        $"df1.AdvanceDirectiveTypeUid" === $"df2.MasterAdvanceDirectiveTypeUid" && $"df2.EffectiveDate".isNull &&
        $"df1.AdvanceDirectiveTypeDetails" === $"df2.AdvanceDirectiveTypeDetails")
      .select($"df1.*")

    if (where_CacheAdvanceDirective_PADOUid3.count > 0) {
      val ex = cleanedCacheAdvanceDirective.except(where_CacheAdvanceDirective_PADOUid3)
      cleanedCacheAdvanceDirective = ex.union(update_CacheAdvanceDirective_PADOUid3)
    }

    logger.warn("Update PatientAdvanceDirectiveObservationUid of CacheAdvanceDirective using " +
      "PatientAdvanceDirectiveObservation 2 Done........")

    var cleanedCacheAdvanceDirective2 = cleanedCacheAdvanceDirective.dropDuplicates(Seq("PatientId", "AdvanceDirectiveTypeUid", "AdvanceDirectiveTypeDetails"))

    val duplicateRecords_CacheAdvanceDirective2 = cleanedCacheAdvanceDirective.except(cleanedCacheAdvanceDirective2)

    duplicateRecords_CacheAdvanceDirective = duplicateRecords_CacheAdvanceDirective.union(duplicateRecords_CacheAdvanceDirective2)

    logger.warn("Drop Duplicate records of CacheAdvanceDirective 2 is Done............")

    //Create Table #AdvanceDirective2
    val tempAdvanceDirective2 = cleanedCacheAdvanceDirective2.filter($"StatusId" === 1 &&
      $"PatientAdvanceDirectiveObservationUid".isNull)
      .select("PatientUid", "AdvanceDirectiveTypeUid", "AdvanceDirectiveTypeDetails").distinct()
      .withColumn("PatientAdvanceDirectiveObservationUid", FunctionUtility.getNewUid())

    //Update PatientAdvanceDirectiveObservationUid of CacheAdvanceDirective using #AdvanceDirective2 is Done
    val update_CacheAdvanceDirective_PADOUid4 = cleanedCacheAdvanceDirective2.as("df1").join(tempAdvanceDirective2.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid" && $"df1.StatusId" === 1 &&
        $"df1.AdvanceDirectiveTypeUid" === $"df2.AdvanceDirectiveTypeUid" &&
        $"df1.AdvanceDirectiveTypeDetails" === $"df2.AdvanceDirectiveTypeDetails" &&
        $"df1.PatientAdvanceDirectiveObservationUid".isNull)
      .select($"df1.*", $"df2.PatientAdvanceDirectiveObservationUid".as("aliasPADOUID"))
      .withColumn("PatientAdvanceDirectiveObservationUid", $"aliasPADOUID")
      .drop("aliasPADOUID")

    val where_CacheAdvanceDirective_PADOUid4 = cleanedCacheAdvanceDirective2.as("df1").join(tempAdvanceDirective2.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid" && $"df1.StatusId" === 1 &&
        $"df1.AdvanceDirectiveTypeUid" === $"df2.AdvanceDirectiveTypeUid" &&
        $"df1.AdvanceDirectiveTypeDetails" === $"df2.AdvanceDirectiveTypeDetails" &&
        $"df1.PatientAdvanceDirectiveObservationUid".isNull)
      .select($"df1.*")


    if (where_CacheAdvanceDirective_PADOUid4.count > 0) {
      val ex = cleanedCacheAdvanceDirective2.except(where_CacheAdvanceDirective_PADOUid4)
      cleanedCacheAdvanceDirective2 = ex.union(update_CacheAdvanceDirective_PADOUid4)
    }

    logger.warn("Update PatientAdvanceDirectiveObservationUid of CacheAdvanceDirective using #AdvanceDirective2 is Done......")


    var cleanedCacheAdvanceDirective3 = cleanedCacheAdvanceDirective2.dropDuplicates(Seq("PatientId", "AdvanceDirectiveTypeUid", "EffectiveStartDate"))

    val duplicateRecords_CacheAdvanceDirective3 = cleanedCacheAdvanceDirective2.except(cleanedCacheAdvanceDirective3)

    duplicateRecords_CacheAdvanceDirective = duplicateRecords_CacheAdvanceDirective.union(duplicateRecords_CacheAdvanceDirective3)

    logger.warn("Drop Duplicate records of CacheAdvanceDirective 3 is Done............")


    //Create Table #AdvanceDirective3
    val tempAdvanceDirective3 = cleanedCacheAdvanceDirective3.filter($"StatusId" === 1 &&
      $"PatientAdvanceDirectiveObservationUid".isNull && $"AdvanceDirectiveTypeDetails".isNull)
      .select("PatientUid", "AdvanceDirectiveTypeUid", "EffectiveStartDate").distinct()
      .withColumn("PatientAdvanceDirectiveObservationUid", FunctionUtility.getNewUid())

    //Update PatientAdvanceDirectiveObservationUid of CacheAdvanceDirective using #AdvanceDirective3 is Done
    val update_CacheAdvanceDirective_PADOUid5 = cleanedCacheAdvanceDirective3.as("df1").join(tempAdvanceDirective3.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid" && $"df1.StatusId" === 1 &&
        $"df1.AdvanceDirectiveTypeUid" === $"df2.AdvanceDirectiveTypeUid" &&
        $"df1.EffectiveStartDate" === $"df2.EffectiveStartDate" &&
        $"df1.PatientAdvanceDirectiveObservationUid".isNull && $"df1.AdvanceDirectiveTypeDetails".isNull)
      .select($"df1.*", $"df2.PatientAdvanceDirectiveObservationUid".as("aliasPADOUID"))
      .withColumn("PatientAdvanceDirectiveObservationUid", $"aliasPADOUID")
      .drop("aliasPADOUID")

    val where_CacheAdvanceDirective_PADOUid5 = cleanedCacheAdvanceDirective3.as("df1").join(tempAdvanceDirective3.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid" && $"df1.StatusId" === 1 &&
        $"df1.AdvanceDirectiveTypeUid" === $"df2.AdvanceDirectiveTypeUid" &&
        $"df1.EffectiveStartDate" === $"df2.EffectiveStartDate" &&
        $"df1.PatientAdvanceDirectiveObservationUid".isNull && $"df1.AdvanceDirectiveTypeDetails".isNull)
      .select($"df1.*")

    if (where_CacheAdvanceDirective_PADOUid5.count > 0) {
      val ex = cleanedCacheAdvanceDirective3.except(where_CacheAdvanceDirective_PADOUid5)
      cleanedCacheAdvanceDirective3 = ex.union(update_CacheAdvanceDirective_PADOUid5)
    }

    logger.warn("Update PatientAdvanceDirectiveObservationUid of CacheAdvanceDirective using #AdvanceDirective3 is Done......")

    //Find Duplicate Records
    var cleanedCacheAdvanceDirective4 = cleanedCacheAdvanceDirective3.dropDuplicates(Seq("PatientId", "AdvanceDirectiveTypeUid"))

    val duplicateRecords_CacheAdvanceDirective4 = cleanedCacheAdvanceDirective3.except(cleanedCacheAdvanceDirective4)

    duplicateRecords_CacheAdvanceDirective = duplicateRecords_CacheAdvanceDirective.union(duplicateRecords_CacheAdvanceDirective4)

    logger.warn("Drop Duplicate records of CacheAdvanceDirective 4 is Done............")


    //Create Table #AdvanceDirective4
    val tempAdvanceDirective4 = cleanedCacheAdvanceDirective4.filter($"StatusId" === 1 &&
      $"PatientAdvanceDirectiveObservationUid".isNull && $"AdvanceDirectiveTypeDetails".isNull
      && $"EffectiveStartDate".isNull)
      .select("PatientUid", "AdvanceDirectiveTypeUid").distinct()
      .withColumn("PatientAdvanceDirectiveObservationUid", FunctionUtility.getNewUid())

    //Update PatientAdvanceDirectiveObservationUid of CacheAdvanceDirective using #AdvanceDirective3 is Done
    val update_CacheAdvanceDirective_PADOUid6 = cleanedCacheAdvanceDirective4.as("df1").join(tempAdvanceDirective4.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid" && $"df1.StatusId" === 1 &&
        $"df1.AdvanceDirectiveTypeUid" === $"df2.AdvanceDirectiveTypeUid" &&
        $"df1.EffectiveStartDate".isNull &&
        $"df1.PatientAdvanceDirectiveObservationUid".isNull && $"df1.AdvanceDirectiveTypeDetails".isNull)
      .select($"df1.*", $"df2.PatientAdvanceDirectiveObservationUid".as("aliasPADOUID"))
      .withColumn("PatientAdvanceDirectiveObservationUid", $"aliasPADOUID")
      .drop("aliasPADOUID")

    val where_CacheAdvanceDirective_PADOUid6 = cleanedCacheAdvanceDirective4.as("df1").join(tempAdvanceDirective4.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid" && $"df1.StatusId" === 1 &&
        $"df1.AdvanceDirectiveTypeUid" === $"df2.AdvanceDirectiveTypeUid" &&
        $"df1.EffectiveStartDate".isNull &&
        $"df1.PatientAdvanceDirectiveObservationUid".isNull && $"df1.AdvanceDirectiveTypeDetails".isNull)
      .select($"df1.*")

    if (where_CacheAdvanceDirective_PADOUid6.count > 0) {
      val ex = cleanedCacheAdvanceDirective4.except(where_CacheAdvanceDirective_PADOUid6)
      cleanedCacheAdvanceDirective4 = ex.union(update_CacheAdvanceDirective_PADOUid6)
    }

    logger.warn("Update PatientAdvanceDirectiveObservationUid of CacheAdvanceDirective using #AdvanceDirective4 is Done......")

    //Update Columns Of PatientAdvanceDirectiveObservation_ Table
    val Update_PatientAdvanceDirectiveObservation = PatientAdvanceDirectiveObservation_Prod.as("df1")
      .join(cleanedCacheAdvanceDirective4.as("df2"), $"df1.PatientAdvanceDirectiveObservationUid" === $"df2.PatientAdvanceDirectiveObservationUid"
        && $"df2.StatusId" === 1)
      .select($"df1.*", $"df2.AgentName".as("aliasAgentName"), $"df2.AdvanceDirectiveStatusUid".as("aliasADSUid")
        , $"df2.GroupName".as("aliasGroupName"))
      .withColumn("AgentName", $"aliasAgentName")
      .withColumn("MasterAdvanceDirectiveStatusUid", $"aliasADSUid")
      .withColumn("GroupName", $"aliasGroupName")
      .withColumn("ModifiedDate", current_timestamp())

    logger.warn("Update Columns Of PatientAdvanceDirectiveObservation_ Table is Done......")

    val where_PatAdvDirc = PatientAdvanceDirectiveObservation_Prod.as("df1")
      .join(cleanedCacheAdvanceDirective4.as("df2"), $"df1.PatientAdvanceDirectiveObservationUid" === $"df2.PatientAdvanceDirectiveObservationUid"
        && $"df2.StatusId" === 1)
      .select($"df1.*")

    val ex_PatAdvDirc = PatientAdvanceDirectiveObservation_Prod.except(where_PatAdvDirc)
    var PatientAdvanceDirectiveObservation_Prod_Delta = ex_PatAdvDirc.union(Update_PatientAdvanceDirectiveObservation)

    //Where And Union

    //Insert Data Into PatientAdvanceDirectiveObservation
    val insert_PatientAdvanceDirectiveObservation = PatientAdvanceDirectiveObservation_Prod_Delta.as("df1")
      .join(cleanedCacheAdvanceDirective4.as("df2")
        , $"df1.PatientAdvanceDirectiveObservationUid" === $"df2.PatientAdvanceDirectiveObservationUid"
          && $"df2.StatusId" === 1 && $"df1.PatientAdvanceDirectiveObservationUid".isNull, "left_outer")
      .select($"df2.PatientAdvanceDirectiveObservationUid", $"df2.PatientUid", $"df2.AdvanceDirectiveTypeUid".as
      ("MasterAdvanceDirectiveTypeUid"), $"df2.EffectiveStartDate".as("EffectiveDate"), $"df2.AgentName"
        , $"df2.EffectiveEndDate".as("EffectiveDateTo"), $"df2.AdvanceDirectiveStatusUid".as("MasterAdvanceDirectiveStatusUid")
        , $"df2.AdvanceDirectiveTypeDetails", $"df2.AdvanceDirectiveTypeText", $"df2.GroupName")
      .withColumn("CreatedDate", current_timestamp())

    val allcols = PatientAdvanceDirectiveObservation_Prod_Delta.columns.toSet
    val insert_cols = insert_PatientAdvanceDirectiveObservation.columns.toSet
    val tot = allcols ++ insert_cols

    PatientAdvanceDirectiveObservation_Prod_Delta = PatientAdvanceDirectiveObservation_Prod_Delta.select(FunctionUtility.addColumns(allcols, tot): _*)
      .union(insert_PatientAdvanceDirectiveObservation.select(FunctionUtility.addColumns(insert_cols, tot): _*))

    logger.warn("Insert Data Into PatientAdvanceDirectiveObservation is Done......")

    logger.warn(" end CacheAdvanceDirective ......................")


    List(PatientAdvanceDirectiveObservation_Prod_Delta)
  }

}
