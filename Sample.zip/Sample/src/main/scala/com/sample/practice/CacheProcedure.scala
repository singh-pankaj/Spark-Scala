package com.sample.practice

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

class CacheProcedure {

  def CacheProcedureFunc(spark : SparkSession,MergePracticeMap : DataFrame
                         ,CDRPatientCrosswalkTable : DataFrame
                         ,MultiTableExtendTable : DataFrame
                         ,ProviderNPIChangeTable : DataFrame
                         ,Individual : DataFrame
                         ,distIndUid : DataFrame
                         ,distspUID : DataFrame
                         ,ViewServiceProvider_prod : DataFrame
                         ,ViewFacility_Prod : DataFrame
                         ,PatientProcedure_prod : DataFrame
                         ,MasterCode_Prod : DataFrame
                         ,Patient_Prod_Delta : DataFrame
                         ,Individual_prod_Delta2 : DataFrame
                         ,ServiceProvider_Prod_Delta1 : DataFrame
                         ,MappingPracticeCommonData_Delta : DataFrame
                         ,MappingPracticeProcedure_Delta : DataFrame
                         ,Institution_Prod_Delta : DataFrame
                         ,ServiceLocation_Prod_Delta : DataFrame) : List[DataFrame] = {

    val logger = LoggerFactory.getLogger("")

    import spark.implicits._

    val CacheProceduresDataFile = spark.read.option("delimiter", "\u0017")
      .csv("")

    val CacheProceduresDatalookup=Map("_c0" -> "CodeUid","_c1" -> "UID","_c2" -> "Code","_c3" -> "Name",
      "_c4" -> "Id","_c5" -> "Inactive","_c6" -> "CodeSystem","_c7" -> "CreatedDate","_c8" -> "CreatedByUid",
      "_c9" -> "ModifiedDate","_c10" -> "ModifiedByUid")

    val tempCacheProceduresData = spark.read.option("header", "true").csv("s3n://bd-dev/aao_test/Schema/CDRSchema.txt")
    var tempCacheProceduresData1 = CacheProceduresDataFile.select(CacheProceduresDataFile.columns.map(c => col(c).as(CacheProceduresDatalookup.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")
    val allcols = tempCacheProceduresData1.columns.toSet
    val viewcols = tempCacheProceduresData1.columns.toSet
    val total = allcols ++ viewcols

    tempCacheProceduresData1 = tempCacheProceduresData.select(FunctionUtility.addColumns(allcols, total): _*)
      .union(tempCacheProceduresData1.select(FunctionUtility.addColumns(viewcols, total): _*))

    val cacheFile = spark.read.option("delimiter", "\u0017")
      .csv("")


    //Code Before Index

    val TempMergePracticeMapDf = tempCacheProceduresData1.filter($"StatusId".isNull)
      .select("practiceuid").distinct()

    val MergePracticeMapDF = MergePracticeMap.as("df1")
      .join(TempMergePracticeMapDf.as("df2"), $"df1.NewPracticeUid" === $"df2.practiceuid", "left")
      .select("df1.*")


    val UpdateCacheProcedure1 =  tempCacheProceduresData1.filter($"StatusId".isNull)
      .join(MergePracticeMapDF, $"CacheProcedures.PracticeUid" === $"MergePracticeMapDF.NewPracticeUid")
      .select($"UpdatedCacheProcedure.*",$"MergePracticeMap.OriginalPracticeuid".as("AliasOriginalPracticeuid"))
      .withColumn("PracticeUid", $"AliasOriginalPracticeuid")

    val cachewhereclause1 =  tempCacheProceduresData1.filter($"StatusId".isNull)
      .join(MergePracticeMapDF, $"CacheProcedures.PracticeUid" === $"MergePracticeMapDF.NewPracticeUid")
      .select($"UpdatedCacheProcedure.*")

    val ExceptUpdatedCacheProcedure = tempCacheProceduresData1.except(cachewhereclause1)
    var CacheProcedure1 = UpdateCacheProcedure1.union(ExceptUpdatedCacheProcedure)

    var ChProcedures = CacheProcedure1.withColumn("StatusId", lit(1))
    // Updates Started

    val UpdateChProcedure1 = ChProcedures.filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", col("PracticeUid"))
      .withColumn("PatientId", rtrim(ltrim(col("PatientId"))))
      .withColumn("ServiceProviderNPI", rtrim(ltrim(col("ServiceProviderNPI"))))
      .withColumn("ServiceLocationid", rtrim(ltrim(col("ServiceLocationid"))))
      .withColumn("ProcedureCode", rtrim(ltrim(col("ProcedureCode"))))
      .withColumn("PracticeSideNPI", rtrim(ltrim(col("PracticeSideNPI"))))


    val whereclause1 = ChProcedures.filter($"StatusId" === 1)
    val ExceptUpdateChProcedure1 = ChProcedures.except(whereclause1)
    ChProcedures = UpdateChProcedure1.union(ExceptUpdateChProcedure1)

    //Update Status From PatientId
    val UpdateChProcedure2 = ChProcedures.filter($"StatusId" === 1 && $"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val whereclause2 = ChProcedures.filter($"StatusId" === 1 && $"PatientId".isNull)
    val ExceptUpdateChProcedure2 = ChProcedures.except(whereclause2)
    ChProcedures = UpdateChProcedure2.union(ExceptUpdateChProcedure2)

    //    val cacheProcedures1 = CacheProcedures.union(cacheProcedures1).union(UpdateStatusFromPatientId)

    //Update PatientId from PatientId Crosswalk
    val UpdateChProcedure3 = ChProcedures.filter($"StatusId" === 1).as("df1")
      .join(CDRPatientCrosswalkTable.as("df2"), $"df1.PatientId" === $"df2.New_PatientId")
      .select($"df1.*",$"df2.Old_PatientId".as("AliasOld_PatientId"))
      .withColumn("PatientId", $"AliasOld_PatientId")
      .drop("AliasOld_PatientId")
    val whereclause3 = ChProcedures.filter($"StatusId" === 1).as("df1")
      .join(CDRPatientCrosswalkTable.as("df2"), $"df1.PatientId" === $"df2.New_PatientId")
      .select($"df1.*")

    val ExceptUpdateChProcedure3 = ChProcedures.except(whereclause3)
    ChProcedures = UpdateChProcedure3.union(ExceptUpdateChProcedure3)

    //Update Procedure where Procedure Date is null
    val UpdateChProcedure4 = ChProcedures.filter($"StatusId" === 1 && $"ProcedureDate".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Procedure Date is null"))

    val whereclause4 = ChProcedures.filter($"StatusId" === 1 && $"ProcedureDate".isNull)
    val ExceptUpdateChProcedure4 = ChProcedures.except(whereclause4)
    // ChProcedure3 Updated to ChProcedure4
    ChProcedures = UpdateChProcedure4.union(ExceptUpdateChProcedure4)

    //Update Procedure where ProcedureCode and ProcedureText is missing
    val UpdateChProcedure5 = ChProcedures.filter($"StatusId" === 1 && $"ProcedureCode".isNull && $"ProcedureText".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ProcedureCode and ProcedureText is missing"))
    val whereclause5 = ChProcedures.filter($"StatusId" === 1 && $"ProcedureCode".isNull && $"ProcedureText".isNull)

    val exceptwhereclause5 = ChProcedures.except(whereclause5)
    ChProcedures = UpdateChProcedure5.union(exceptwhereclause5)



    //Update Procedure where Procedure Category Not Found
    val UpdateChProcedure6 = ChProcedures.filter($"StatusId" === 1 && $"ProcedureCode".isNotNull && $"ProcedureCategory".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Procedure Category Not Found"))

    val whereclause6 = ChProcedures.filter($"StatusId" === 1 && $"ProcedureCode".isNotNull && $"ProcedureCategory".isNull)

    val ExceptUpdateChProcedure6 = ChProcedures.except(whereclause6)
    // ChProcedure5 Updated to ChProcedure6
    ChProcedures = UpdateChProcedure6.union(ExceptUpdateChProcedure6)

    // Update ServiceProviderNPI
    val UpdateChProcedure7 = ChProcedures.filter($"StatusId" === 1).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ServiceProviderNPI" === $"df2.Element1")
      .select($"df1.*", $"df2.value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"df2.AliasValue")
      .drop("AliasValue")

    val whereclause7 = ChProcedures.filter($"StatusId" === 1).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI").as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ServiceProviderNPI" === $"df2.Element1")
      .select($"df1.*")

    val ExceptUpdateChProcedure7 = ChProcedures.except(whereclause7)
    // ChProcedure6 Updated to ChProcedure7
    ChProcedures = UpdateChProcedure7.union(ExceptUpdateChProcedure7)


    val UpdateChProcedure8 = ProviderNPIChangeTable.as("df1")
      .join(Individual.as("df2"),
        $"df1.ServiceProviderUid" === $"df2.IndividualUid")
      .join(ChProcedures.filter($"StatusId" === 1).as("df3"),
        $"df2.PracticeUid" === $"df3.PracticeUid"
          && $"df1.OldNPI" === $"df3.ServiceProviderNPI")
      .select($"df3.*", $"df1.NewNPI".as("AliasNewNPI"))
      .withColumn("ServiceProviderNPI", $"AliasNewNPI")
      .drop($"AliasNewNPI")
    val whereclause8 =ProviderNPIChangeTable.as("df1")
      .join(Individual.as("df2"),
        $"df1.ServiceProviderUid" === $"df2.IndividualUid")
      .join(ChProcedures.filter($"StatusId" === 1).as("df3"),
        $"df2.PracticeUid" === $"df3.PracticeUid"
          && $"df1.OldNPI" === $"df3.ServiceProviderNPI")
      .select($"df3.*")

    val ExceptUpdateChProcedure8 = ChProcedures.except(whereclause8)
    // ChProcedure7 Updated to ChProcedure8
    ChProcedures = UpdateChProcedure8.union(ExceptUpdateChProcedure8)

    val UpdateChProcedure9 = ChProcedures
      .filter($"StatusId" === 1 && $"ServiceProviderNPI".isNull).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI" && $"element2".isNotNull).as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ServiceProviderLastName" === $"df2.element2")
      .select($"df1.*" , $"df2.value".as("Aliasvalue"))
      .withColumn("ServiceProviderNPI", $"df2.Aliasvalue")
      .drop("Aliasvalue")
    val whereclause9 = ChProcedures
      .filter($"StatusId" === 1 && $"ServiceProviderNPI".isNull).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI" && $"element2".isNotNull).as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid"
          && $"df1.ServiceProviderLastName" === $"df2.element2")
      .select($"df1.*")

    val ExceptUpdateChProcedure9 = ChProcedures.except(whereclause9)
    // ChProcedure8 Updated to ChProcedure9
    ChProcedures = UpdateChProcedure9.union(ExceptUpdateChProcedure9)


    val UpdateChProcedure10 = ChProcedures.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid NPI Found,Length should be 10"))

    val whereclause10 = ChProcedures.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)
    val ExceptUpdateChProcedure10 = ChProcedures.except(whereclause10)
    // ChProcedure9 Updated to ChProcedure10
    ChProcedures = UpdateChProcedure10.union(ExceptUpdateChProcedure10)

    //join with MappingPracticeProcedureDF
    val UpdateChProcedure11 = ChProcedures.as("df1").filter($"StatusId" === 1 && $"df1.CodeUid".isNull)
      .join(MappingPracticeProcedure_Delta.as("df2"), $"df1.ProcedureCode" === $"df2.PracticeValue")
      .select($"df1.*", $"df2.CodeUid".as("new_code_uid"))
      .withColumn("CodeUid", $"new_code_uid")
      .drop("new_code_uid")

    val whereclause11 = ChProcedures.as("df1").filter($"StatusId" === 1 && $"df1.CodeUid".isNull)
      .join(MappingPracticeProcedure_Delta.as("df2"), $"df1.ProcedureCode" === $"df2.PracticeValue")
      .select($"df1.*")

    val ExceptUpdateChProcedure11 = ChProcedures.except(whereclause11)
    // ChProcedure10 Updated to ChProcedure11
    ChProcedures = UpdateChProcedure11.union(ExceptUpdateChProcedure11)


    //join with MasterCodeDF
    val UpdateChProcedure12 = ChProcedures.as("df1").filter($"StatusId" === 1 && $"df1.CodeUid".isNull)
      .join(MasterCode_Prod.as("df2"), $"df1.ProcedureCode" === $"df2.Code")
      .select($"df1.*", $"df2.CodeUid".as("new_code_uid"))
      .withColumn("CodeUid", $"new_code_uid")
      .drop($"new_code_uid")
    val whereclause12 = ChProcedures.as("df1").filter($"StatusId" === 1 && $"df1.CodeUid".isNull)
      .join(MasterCode_Prod.as("df2"), $"df1.ProcedureCode" === $"df2.Code")
      .select($"df1.*")

    val ExceptUpdateChProcedure12 = ChProcedures.except(whereclause12)
    // ChProcedure11 Updated to ChProcedure12
    ChProcedures = UpdateChProcedure12.union(ExceptUpdateChProcedure12)


    //ProcedMappingPracticeProcedureDFureText Is missing/Code Not Found/Mapped
    val UpdateChProcedure13 = ChProcedures.filter($"StatusId" === 1 && $"CodeUid".isNull && $"proceduretext".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ProcedMappingPracticeProcedureDFureText Is missing/Code Not Found/Mapped"))
    val whereclause13 =  ChProcedures.filter($"StatusId" === 1 && $"CodeUid".isNull && $"proceduretext".isNull)

    val ExceptUpdateChProcedure13 = ChProcedures.except(whereclause13)
    // ChProcedure12 Updated to ChProcedure13
    ChProcedures = UpdateChProcedure13.union(ExceptUpdateChProcedure13)


    val UpdateChProcedure14 = ChProcedures
      .filter($"StatusId" === 1 && $"PracticeUid".isNull).as("df1")
      .join(Patient_Prod_Delta.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod_Delta2.as("df3"), $"df2.PatientUid" === $"df3.IndividualUid"
        && $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*", $"df2.PatientUid".as("new_PatientUid"))
      .withColumn("PatientUid", $"new_PatientUid")
      .drop("new_PatientUid")

    val whereclause14 = ChProcedures
      .filter($"StatusId" === 1 && $"PracticeUid".isNull).as("df1")
      .join(Patient_Prod_Delta.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod_Delta2.as("df3"), $"df2.PatientUid" === $"df3.IndividualUid"
        && $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*")

    val ExceptUpdateChProcedure14 = ChProcedures.except(whereclause14)
    // ChProcedure13 Updated to ChProcedure14
    ChProcedures = UpdateChProcedure14.union(ExceptUpdateChProcedure14)


    val UpdateChProcedure15 = ChProcedures.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val whereclause15 = ChProcedures.filter($"StatusId" === 1 && $"PatientUid".isNull)

    val ExceptUpdateChProcedure15 = ChProcedures.except(whereclause15)
    // ChProcedure14 Updated to ChProcedure15
    ChProcedures = UpdateChProcedure15.union(ExceptUpdateChProcedure15)

    val CleanData1 = ChProcedures.dropDuplicates("PatientUid","ProcedureCode","ProcedureDate","ServiceProviderNPI")
    var DropDuplicates1 = ChProcedures.except(CleanData1)
    val CleanData2 = CleanData1.dropDuplicates("PatientUid","ProcedureCode","ProcedureDate")
    val DropDuplicates2 = CleanData1.except(CleanData2)
    val CleanData3 = CleanData2.dropDuplicates("PatientUid","ProcedureText","ProcedureDate","ServiceProviderNPI")
    val DropDuplicates3 = CleanData2.except(CleanData3)
    var CleanData4 = CleanData3.dropDuplicates("PatientUid","ProcedureText","ProcedureDate")
    val DropDuplicates4 = CleanData3.except(CleanData4)


    DropDuplicates1 = DropDuplicates1
      .union(DropDuplicates2)
      .union(DropDuplicates3)

    val UpdateChProcedure20 = CleanData4.filter($"StatusId" === 1).as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.ServiceProviderUid".as("new_ServiceProviderUid"))
      .filter($"new_ServiceProviderUid".isNull)
      .withColumn("ServiceProviderUid", $"new_ServiceProviderUid")
      .drop("new_ServiceProviderUid")

    val whereclause20 = CleanData4.filter($"StatusId" === 1).as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")
    val ExceptUpdateChProcedure20 = CleanData4.except(whereclause20)
    // ChProcedure19 Updated to ChProcedure20
    CleanData4 = UpdateChProcedure20.union(ExceptUpdateChProcedure20)

    val UpdateChProcedure21 = CleanData4.filter($"StatusId" === 1).as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationUid" === $"df2.id" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.ServiceProviderUid".as("new_ServiceLocationUid"))
      .filter($"new_ServiceProviderUid".isNull)
      .withColumn("ServiceLocationUid", $"new_ServiceLocationUid")
      .drop("new_ServiceLocationUid")

    val whereclause21  = CleanData4.filter($"StatusId" === 1).as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationUid" === $"df2.id" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")
    val ExceptUpdateChProcedure21 = CleanData4.except(whereclause21)
    // ChProcedure20 Updated to ChProcedure21
    CleanData4 = UpdateChProcedure21.union(ExceptUpdateChProcedure21)


    // New Providers

    val newServiceProvider = CleanData4
      .filter($"StatusId" === 1 &&$"ServiceProviderUid".isNull && $"ServiceProviderNPI".isNotNull).as("df1")
      .select("ServiceProviderNPI", "ServiceProviderFirstName", "ServiceProviderLastName", "PracticeUid")
      .groupBy($"ServiceProviderNPI", $"PracticeUid")
      .agg(max("ServiceProviderFirstName").as("ServiceProviderFirstName"),
        max("ServiceProviderLastName").as("ServiceProviderLastName"))
      .withColumn("Physician_MidName", lit("null"))

    val newServiceProvider1 = newServiceProvider.withColumn("ServiceProviderUid", FunctionUtility.getNewUid())

    val updateSPUid = CleanData4.filter($"StatusId" === 1).as("df1")
      .join(newServiceProvider1.as("df2"), $"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderUid".isNotNull
        && $"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceProviderUid".as("aliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"aliasServiceProviderUid")
      .drop("aliasServiceProviderUid")

    //22
    val whereclauseSPUID =  CleanData4.filter($"StatusId" === 1).as("df1")
      .join(newServiceProvider1.as("df2"), $"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderUid".isNotNull
        && $"df1.StatusId" === 1)
      .select($"df1.*")
    val ExceptupdateSPUid = CleanData4.except(whereclauseSPUID)
    CleanData4 = updateSPUid.union(ExceptupdateSPUid)

    val insertIndividual = newServiceProvider1.as("df1")
      .join(distIndUid.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.IndividualUid"))
      .select($"df1.ServiceProviderUid".as("IndividualUid"), $"df1.ServiceProviderFirstName".as("First")
        , $"df1.Physician_MidName".as("Middle"), $"ServiceProviderLastName".as("Last"),
        $"df1.PracticeUid".as("PracticeUid")).distinct()

    val indicols = Individual_prod_Delta2.columns.toSet
    val insertIndividualcols = insertIndividual.columns.toSet
    val tot = indicols ++ insertIndividualcols

    val Individual_prod_Delta3 = Individual_prod_Delta2.select(FunctionUtility.addColumns(indicols, tot): _*)
      .union(insertIndividual.select(FunctionUtility.addColumns(insertIndividualcols, tot): _*))

    logger.warn("Insert Data into Individual table is Done............")


    val insertdataServiceProv = newServiceProvider1.as("df1")
      .join(
        distspUID.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.ServiceProviderUid"))
      .withColumn("ListName", when($"df1.Physician_MidName".isNotNull, concat_ws(" "
        , $"ServiceProviderLastName", $"ServiceProviderFirstName", $"Physician_MidName"))
        .otherwise(concat_ws(" ", $"ServiceProviderLastName", $"ServiceProviderFirstName")))
      .select($"df1.ServiceProviderUid", $"ListName", $"df1.ServiceProviderNPI".as("NPI"))
      .withColumn("ExternalID", lit(null))
      .withColumn("Type", lit(4))

    val servicePcols = ServiceProvider_Prod_Delta1.columns.toSet
    val insertdataServiceProvcols = insertdataServiceProv.columns.toSet
    val tot1 = servicePcols ++ insertdataServiceProvcols

    val ServiceProvider_prod_Delta2 = ServiceProvider_Prod_Delta1.select(FunctionUtility.addColumns(servicePcols, tot1): _*)
      .union(insertdataServiceProv.select(FunctionUtility.addColumns(insertdataServiceProvcols, tot1): _*))

    logger.warn("Insert Data into ServiceProvider is Done............")


    val LocDF = CleanData4
      .filter($"StatusId" === 1 && $"ServiceLocationUid".isNull && rtrim(ltrim($"ServiceLocationId")).isNotNull)
      .select($"ServiceLocationId", when($"ServiceLocationName".isNull ,$"ServiceLocationId").otherwise($"ServiceLocationName").as("ServiceLocationName"), $"PracticeUid")
      .distinct().withColumn("ServiceLocationUid",FunctionUtility.getNewUid())


    val UpdateChProcedure22 = CleanData4.filter($"StatusId" === 1).as("df1")
      .join(LocDF.as("df2"), $"df1.ServiceLocationId" === $"df2.ServiceLocationId"
        && $"df1.ServiceLocationId" === $"df2.ServiceLocationId"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*",$"df2.ServiceLocationUid".as("AliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"AliasServiceLocationUid")
      .drop("ServiceLocationUid")


    val whereclause22 = CleanData4.filter($"StatusId" === 1).as("df1")
      .join(LocDF.as("df2"), $"df1.ServiceLocationId" === $"df2.ServiceLocationId"
        && $"df1.ServiceLocationId" === $"df2.ServiceLocationId"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdateChProcedure22 = CleanData4.except(whereclause22)
    // updatedSPUid Updated to ChProcedure22
    CleanData4 = UpdateChProcedure22.union(ExceptUpdateChProcedure22)


    val InstitutionDF = LocDF
      .withColumnRenamed("ServiceLocationUid", "InstitutionUid")
      .withColumnRenamed("ServiceLocationName", "Name")
      .withColumn("Type", lit(5))
      .select("InstitutionUid", "Name", "Type", "PracticeUid")

    val Insti_allcols = Institution_Prod_Delta.columns.toSet
    val insert_cols = InstitutionDF.columns.toSet
    val tot3 = Insti_allcols ++ insert_cols

    val Institution_Prod_Delta2 = Institution_Prod_Delta.select(FunctionUtility.addColumns(Insti_allcols, tot3): _*)
      .union(InstitutionDF.select(FunctionUtility.addColumns(insert_cols, tot3): _*))

    // insert into Institution table

    val ServiceLocationDF = LocDF
      .withColumnRenamed("ServiceLocationId", "ExternalID")
      .select("ServiceLocationUid", "ExternalID")

    val ServiceLoc_allcols = ServiceLocation_Prod_Delta.columns.toSet
    val insert_cols2 = ServiceLocationDF.columns.toSet
    val tot4 = ServiceLoc_allcols ++ insert_cols2

    val ServiceLocation_Prod_Delta2 = ServiceLocation_Prod_Delta.select(FunctionUtility.addColumns(ServiceLoc_allcols, tot4): _*)
      .union(ServiceLocationDF.select(FunctionUtility.addColumns(insert_cols2, tot4): _*))

    // insert into ServiceLocation

    val UpdateChProcedure23 = CleanData4.filter($"StatusId"===1).as("df1")
      .join(PatientProcedure_prod.filter($"PatientProcedureUid".isNull).as("df2"),
        $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ProcedureDate" === $"df2.EffectiveDate"
          && $"df1.CodeUid" === $"df2.ProcedureCodeUid")
      .select($"df1.*", $"df2.PatientProcedureUid".as("AliasPatientProcedureUid"))
      .withColumn("PatientProcedureUid", $"AliasPatientProcedureUid")
      .drop($"AliasPatientProcedureUid")
    //   Update Chprocedures


    val whereclause23 = CleanData4.filter($"StatusId"===1).as("df1")
      .join(PatientProcedure_prod.filter($"PatientProcedureUid".isNull).as("df2"),
        $"df1.PatientUid" === $"df2.PatientUid" && $"df1.ProcedureDate" === $"df2.EffectiveDate"
          && $"df1.CodeUid" === $"df2.ProcedureCodeUid")
      .select($"df1.*")

    val ExceptUpdateChProcedure23 = CleanData4.except(whereclause23)
    // ChProcedure22 Updated to ChProcedure23
    CleanData4 = UpdateChProcedure23.union(ExceptUpdateChProcedure23)

    val UpdateChProcedure24 = CleanData4.filter($"StatusId"===1 && $"PatientProcedureUid".isNull).as("df1")
      .join(PatientProcedure_prod.as("df2"),
        $"df1.PatientUid" === $"df2.PatientUid"
          && $"df1.ProcedureDate" === $"df2.EffectiveDate"
          && $"df1.ProcedureCode" === $"df2.PracticeCode")
      .select($"df1.*", $"df2.PatientProcedureUid".as("AliasPatientProcedureUid"))
      .withColumn("PatientProcedureUid", $"AliasPatientProcedureUid")
      .drop($"AliasPatientProcedureUid")

    val whereclause24 = CleanData4.filter($"StatusId"===1 && $"PatientProcedureUid".isNull).as("df1")
      .join(PatientProcedure_prod.as("df2"),
        $"df1.PatientUid" === $"df2.PatientUid"
          && $"df1.ProcedureDate" === $"df2.EffectiveDate"
          && $"df1.ProcedureCode" === $"df2.PracticeCode")
      .select($"df1.*")

    //  // Update Chprocedures
    val ExceptUpdateChProcedure24 = CleanData4.except(whereclause24)
    // ChProcedure23 Updated to ChProcedure24
    CleanData4 = UpdateChProcedure24.union(ExceptUpdateChProcedure24)

    val UpdateChProcedure25 = CleanData4.filter($"StatusId"===1 && $"PatientProcedureUid".isNull && $"ProcedureCode".isNull).as("df1")
      .join(PatientProcedure_prod.filter($"PracticeCode".isNull).as("df2"),
        $"df1.PatientUid" === $"df2.PatientUid"
          && $"df1.ProcedureDate" === $"df2.EffectiveDate"
          && $"df1.ProcedureText" === $"df2.ProcedureNote")
      .select($"df1.*", $"df2.PatientProcedureUid".as("AliasPatientProcedureUid"))
      .withColumn("PatientProcedureUid", $"AliasPatientProcedureUid")
      .drop($"AliasPatientProcedureUid")
    //  // Update Chprocedures


    val whereclause25 = CleanData4.filter($"StatusId"===1 && $"PatientProcedureUid".isNull && $"ProcedureCode".isNull).as("df1")
      .join(PatientProcedure_prod.filter($"PracticeCode".isNull).as("df2"),
        $"df1.PatientUid" === $"df2.PatientUid"
          && $"df1.ProcedureDate" === $"df2.EffectiveDate"
          && $"df1.ProcedureText" === $"df2.ProcedureNote")
      .select($"df1.*")
    val ExceptUpdateChProcedure25 = CleanData4.except(whereclause25)
    // ChProcedure24 Updated to ChProcedure25
    CleanData4 = UpdateChProcedure25.union(ExceptUpdateChProcedure25)


    var CleanData5 = CleanData4.dropDuplicates("PatientUid", "PracticePatientNoteKey")

    val DropDuplicates5 = CleanData4.except(CleanData1)

    DropDuplicates1 = DropDuplicates1.union(DropDuplicates5)

    val dedupDF = CleanData5.filter($"StatusId"===1 && $"SSN".isNotNull)
      .select("PatientUid", "CodeUid", "ProcedureDate")
      .groupBy($"PatientUid", $"CodeUid", $"ProcedureDate")
      .count().filter("count > 1")

    val UpdateChProcedure26 = CleanData5.filter($"StatusId"===1).as("df1").join(dedupDF.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.CodeUid" === $"df2.CodeUid"
        && $"df1.RowId" =!= $"df2.RowId")
      .select("df1.*")
      .withColumn("StatusId", lit(4))
      .withColumn("ErrorNote", lit("Duplicate Record"))
    //  // Update Chprocedures for Removing Duplicate Records


    val whereclause26 = CleanData5.filter($"StatusId"===1).as("df1").join(dedupDF.as("df2"),
      $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.CodeUid" === $"df2.CodeUid"
        && $"df1.RowId" =!= $"df2.RowId")
      .select("df1.*")

    val ExceptUpdateChProcedure26 = CleanData5.except(whereclause26)
    // ChProcedure25 Updated to ChProcedure26
    CleanData5 = UpdateChProcedure26.union(ExceptUpdateChProcedure26)

    // CASE 1 : Generating PatientProcedureUid for new Patient  whose ServiceProviderUid is null
    val UpdatePatientProcedure1 = CleanData5.filter($"StatusId"===1 && $"PatientProcedureUid".isNull && $"CodeUid".isNotNull)
      .select("PatientUid", "CodeUid", "ProcedureDate").distinct()

    val AlterPatientProcedureDF1 = UpdatePatientProcedure1
      .withColumn("PatientProcedureUid", FunctionUtility.getNewUid())

    val UpdateChProcedure27 = CleanData5
      .filter($"StatusId"===1 && $"PatientProcedureUid".isNull).as("df1")
      .join(AlterPatientProcedureDF1.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.CodeUid" === $"df2.CodeUid"
        && $"df1.ProcedureDate" === $"df2.ProcedureDate")
      .select($"df1.*", $"df2.PatientProcedureUid".as("AliasPatientProcedureUid"))
      .withColumn("PatientProcedureUid", $"AliasPatientProcedureUid")
      .drop($"AliasPatientProcedureUid")

    val whereclause238 = CleanData5
      .filter($"StatusId"===1 && $"PatientProcedureUid".isNull).as("df1")
      .join(AlterPatientProcedureDF1.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.CodeUid" === $"df2.CodeUid"
        && $"df1.ProcedureDate" === $"df2.ProcedureDate")
      .select($"df1.*")

    val ExceptUpdateChProcedure27 = CleanData5.except(whereclause238)
    // ChProcedure26 Updated to ChProcedure27
    CleanData5 = UpdateChProcedure27.union(ExceptUpdateChProcedure27)
    // CASE 2 : Generating PatientProcedureUid for new Patient  whose ServiceProviderUid is not null

    val updatePatientProcedure2 = CleanData5.filter($"StatusId"===1 && $"PatientProcedureUid".isNull && $"ProcedureCode".isNull)
      .select("PatientUid", "ProcedureCode", "ProcedureDate").distinct()

    val AlterPatientProcedureDF2 = updatePatientProcedure2
      .withColumn("PatientProcedureUid", FunctionUtility.getNewUid())

    val UpdateChProcedure28 = CleanData5.filter($"PatientProcedureUid".isNull && $"Codeuid".isNull).as("df1")
      .join(AlterPatientProcedureDF2.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.ProcedureCode" === $"df2.ProcedureCode"
        && $"df1.ProcedureDate" === $"df2.ProcedureDate")
      .select($"df1.*", $"df2.PatientProcedureUid".as("AliasPatientProcedureUid"))
      .withColumn("PatientProcedureUid", $"AliasPatientProcedureUid")
      .drop($"AliasPatientProcedureUid")


    val whereclause288 = CleanData5.filter($"PatientProcedureUid".isNull && $"Codeuid".isNull).as("df1")
      .join(AlterPatientProcedureDF2.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.ProcedureCode" === $"df2.ProcedureCode"
        && $"df1.ProcedureDate" === $"df2.ProcedureDate")
      .select($"df1.*")
    val ExceptUpdateChProcedure28 = CleanData5.except(whereclause288)
    // ChProcedure27 Updated to ChProcedure28
    CleanData5 = UpdateChProcedure28.union(ExceptUpdateChProcedure28)
    // CASE 3 : Generating PatientProcedureUid for new Patient  whose ServiceProviderUid is null

    val UpdatePatientProcedure3 = CleanData5.filter($"StatusId"===1 && $"PatientProcedureUid".isNull && $"ProcedureCode".isNull && $"ProcedureText".isNotNull)
      .select("PatientUid", "ProcedureText", "ProcedureDate").distinct()

    val AlterPatientProcedureDF3 = UpdatePatientProcedure3
      .withColumn("PatientProcedureUid", FunctionUtility.getNewUid())

    val UpdateChProcedure29 = CleanData5.filter($"PatientProcedureUid".isNull && $"ProcedureCode".isNull).as("df1")
      .join(AlterPatientProcedureDF3.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.ProcedureText" === $"df2.ProcedureText"
        && $"df1.ProcedureDate" === $"df2.ProcedureDate")
      .select($"df1.*", $"df2.PatientProcedureUid".as("AliasPatientProcedureUid"))
      .withColumn("PatientProcedureUid", $"AliasPatientProcedureUid")
      .drop($"AliasPatientProcedureUid")

    val whereclause29 = CleanData5.filter($"PatientProcedureUid".isNull && $"ProcedureCode".isNull).as("df1")
      .join(AlterPatientProcedureDF3.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.ProcedureText" === $"df2.ProcedureText"
        && $"df1.ProcedureDate" === $"df2.ProcedureDate")
      .select($"df1.*")

    val ExceptUpdateChProcedure29 = CleanData5.except(whereclause29)
    // ChProcedure28 Updated to ChProcedure29
    CleanData5 = UpdateChProcedure29.union(ExceptUpdateChProcedure29)


    // update ProcedureStatusUid from  MappingPracticeCommonData

    val UpdateChProcedure30 = CleanData5.filter($"StatusId" ===1 && $"ProcedureStatusUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2"), $"df1.ProcedureStatusCode" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "690634BB-40DA-451F-A117-601C177A6BCA")
      .select($"df1.*", $"df2.MappedUid")
      .withColumn("PatientProcedureUid", $"MappedUid")
      .drop($"MappedUid")


    val whereclause30 = CleanData5.filter($"StatusId" ===1 && $"ProcedureStatusUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2"), $"df1.ProcedureStatusCode" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "690634BB-40DA-451F-A117-601C177A6BCA")
      .select($"df1.*")

    val ExceptUpdateChProcedure30 = CleanData5.except(whereclause30)
    // ChProcedure29 Updated to ChProcedure30
    CleanData5 = UpdateChProcedure30.union(ExceptUpdateChProcedure30)

    val UpdateChProcedure31 = CleanData5.filter($"StatusId" ===1 && $"ProcedureStatusUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2"), $"df1.ProcedureStatusText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "690634BB-40DA-451F-A117-601C177A6BCA")
      .select($"df1.*", $"df2.MappedUid")
      .withColumn("ProcedureStatusUid", $"MappedUid")
      .drop($"MappedUid")

    val whereclause31 = CleanData5.filter($"StatusId" ===1 && $"ProcedureStatusUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2"), $"df1.ProcedureStatusText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "690634BB-40DA-451F-A117-601C177A6BCA")
      .select($"df1.*")

    val ExceptUpdateChProcedure31 = CleanData5.except(whereclause31)
    // ChProcedure30 Updated to ChProcedure31
    CleanData5 = UpdateChProcedure31.union(ExceptUpdateChProcedure31)


    val UpdateChProcedure32 = CleanData5.filter($"StatusId" ===1 && $"ProcedureStatusUid".isNull)
      .join(MappingPracticeCommonData_Delta.filter($"Type" === "ProcedureStatus").as("df2"),
        $"df1.ProcedureStatusCode" === $"df2.Code")
      .select($"df1.*", $"df2.MappedUid")
      .withColumn("ProcedureStatusUid", $"MappedUid")
      .drop($"MappedUid")

    val whereclause32 = CleanData5.filter($"StatusId" ===1 && $"ProcedureStatusUid".isNull)
      .join(MappingPracticeCommonData_Delta.filter($"Type" === "ProcedureStatus").as("df2"),
        $"df1.ProcedureStatusCode" === $"df2.Code")
      .select($"df1.*")
    val ExceptUpdateChProcedure32 = CleanData5.except(whereclause32)
    // ChProcedure31 Updated to ChProcedure32
    CleanData5 = UpdateChProcedure32.union(ExceptUpdateChProcedure32)

    val UpdateChProcedure33 = CleanData5.filter($"ProcedureStatusUid".isNull)
      .join(MappingPracticeCommonData_Delta.filter($"Type" === "ProcedureStatus").as("df2"),
        $"df1.ProcedureStatusText" === $"df2.Name")
      .select($"df1.*", $"df2.MappedUid")
      .withColumn("ProcedureStatusUid", $"MappedUid")
      .drop($"MappedUid")
    val whereclause33 = CleanData5.filter($"ProcedureStatusUid".isNull)
      .join(MappingPracticeCommonData_Delta.filter($"Type" === "ProcedureStatus").as("df2"),
        $"df1.ProcedureStatusText" === $"df2.Name")
      .select($"df1.*")

    val ExceptUpdateChProcedure33 = CleanData5.except(whereclause33)
    // ChProcedure32 Updated to ChProcedure33
    CleanData5 = UpdateChProcedure33.union(ExceptUpdateChProcedure33)
    // update TargetSiteUid from  MappingPracticeCommonData

    val UpdateChProcedure34 = CleanData5.filter($"StatusId" ===1 && $"TargetSiteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2"), $"df1.TargetSiteCode" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .select($"df1.*", $"df2.MappedUid")
      .withColumn("TargetSiteUid", $"MappedUid")
      .drop($"MappedUid")

    val whereclause34 = CleanData5.filter($"StatusId" ===1 && $"TargetSiteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2"), $"df1.TargetSiteCode" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .select($"df1.*")
    val ExceptUpdateChProcedure34 = CleanData5.except(whereclause34)
    // ChProcedure33 Updated to ChProcedure34
    CleanData5 = UpdateChProcedure34.union(ExceptUpdateChProcedure34)

    val UpdateChProcedure35 = CleanData5.filter($"StatusId" ===1 && $"TargetSiteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2"), $"df1.TargetSiteText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .select($"df1.*", $"df2.MappedUid")
      .withColumn("TargetSiteUid", $"MappedUid")
      .drop($"MappedUid")

    val whereclause35 = CleanData5.filter($"StatusId" ===1 && $"TargetSiteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2"), $"df1.TargetSiteText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df2.MapperMasterCollectionUid" === "BBCD1F49-85CF-4955-8996-6F55E64B5B57")
      .select($"df1.*")

    val ExceptUpdateChProcedure35 = CleanData5.except(whereclause35)
    // ChProcedure34 Updated to ChProcedure35
    CleanData5 = UpdateChProcedure35.union(ExceptUpdateChProcedure35)

    // update TargetSiteUid from  master

    val UpdateChProcedure36 = CleanData5.filter($"StatusId" ===1 && $"TargetSiteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.filter($"Type" === "TargetSite").as("df2"),
        $"df1.TargetSiteCode" === $"df2.Code")
      .select($"df1.*", $"df2.MasterUid")
      .withColumn("TargetSiteUid", $"MasterUid")
      .drop($"MasterUid")
    val whereclause36 = CleanData5.filter($"StatusId" ===1 && $"TargetSiteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.filter($"Type" === "TargetSite").as("df2"),
        $"df1.TargetSiteCode" === $"df2.Code")
      .select($"df1.*")

    val ExceptUpdateChProcedure36 = CleanData5.except(whereclause36)
    // ChProcedure35 Updated to ChProcedure36
    CleanData5 = UpdateChProcedure36.union(ExceptUpdateChProcedure36)

    val UpdateChProcedure37 = CleanData5.filter($"StatusId" ===1 && $"TargetSiteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.filter($"Type" === "TargetSite").as("df2"),
        $"df1.TargetSiteText" === $"df2.Name")
      .select($"df1.*", $"df2.MasterUid")
      .withColumn("TargetSiteUid", $"MasterUid")
      .drop($"MasterUid")

    val whereclause37 = CleanData5.filter($"StatusId" ===1 && $"TargetSiteUid".isNull).as("df1")
      .join(MappingPracticeCommonData_Delta.filter($"Type" === "TargetSite").as("df2"),
        $"df1.TargetSiteText" === $"df2.Name")
      .select($"df1.*")

    val ExceptUpdateChProcedure37 = CleanData5.except(whereclause37)
    // ChProcedure36 Updated to ChProcedure37
    CleanData5 = UpdateChProcedure37.union(ExceptUpdateChProcedure37)


    // iF CodeUId is Null then take 5 digit procedureCode

    val UpdateChProcedure38 = CleanData5.filter($"StatusId" ===1 && $"CodeUid".isNull
      && length($"df1.ProcedureCode" > 5
      && $"df2.CodeSystem" === 6)).as("df1")
      .join(MasterCode_Prod.as("df2"), substring($"df1.ProcedureCode", 0, 4) === $"df2.Code"
        && $"df1.ProcedureCategory" === $"CodeSystem")
      .select($"df1.*", $"df2.CodeUid".as("AliasCodeUid"))
      .withColumn("ErrorNote", lit(null))
      .withColumn("CodeUid", $"AliasCodeUid")
      .drop($"AliasCodeUid")

    val whereclause38 = CleanData5.filter($"StatusId" ===1 && $"CodeUid".isNull
      && length($"df1.ProcedureCode" > 5
      && $"df2.CodeSystem" === 6)).as("df1")
      .join(MasterCode_Prod.as("df2"), substring($"df1.ProcedureCode", 0, 4) === $"df2.Code"
        && $"df1.ProcedureCategory" === $"CodeSystem")
      .select($"df1.*")

    val ExceptUpdateChProcedure38 = CleanData5.except(whereclause38)
    // ChProcedure37 Updated to ChProcedure38
    CleanData5 = UpdateChProcedure38.union(ExceptUpdateChProcedure38)


    // Update old records from PatientProcedure
    val updatePatientProcedure4 = PatientProcedure_prod.as("df1")
      .join(CleanData5.filter($"StatusId" ===1).as("df2"), Seq("PatientProcedureUid"))
      .select($"df1.*",$"df2.ProcedureCode".as("AliasProcedureCode"),$"df2.ProcedureText".as("AliasProcedureText"),
        $"df2.ProcedureStatusUid".as("AliasProcedureStatusUid"),$"df2.TargetSiteUid".as("AliasTargetSiteUid"),
        $"df2.ServiceLocationUid".as("AliasServiceLocationUid"),$"df2.ProcedureComment".as("AliasProcedureComment"),
        $"df2.ProcedureText".as("AliasProcedureText"),$"df2.TargetSiteText".as("AliasTargetSiteText"),
        $"df2.Modifier1".as("AliasModifier1"),$"df2.Modifier2".as("AliasModifier2"),$"df2.Modifier3".as("AliasModifier3"),
        $"df2.Modifier4".as("AliasModifier4"),$"df2.Insurance".as("AliasInsurance"),
        $"df2.ProcedureCategory".as("AliasProcedureCategory"),$"df2.NegationInd".as("AliasNegationInd"))
      .withColumn("PracticeCode",$"AliasProcedureCode")
      .withColumn("PracticeDescription",$"AliasProcedureText")
      .withColumn("MasterProcedureStatusUid",$"AliasProcedureStatusUid")
      .withColumn("MasterTargetSiteUid",$"AliasTargetSiteUid")
      .withColumn("ServiceLocationUid",$"AliasServiceLocationUid")
      .withColumn("ServiceProviderUid",$"AliasServiceProviderUid")
      .withColumn("ProcedureComment",$"AliasProcedureComment")
      .withColumn("ProcedureNote",$"AliasProcedureText")
      .withColumn("PracticeTargetSiteText",$"AliasTargetSiteText ")
      .withColumn("Modifier1",$"AliasModifier1")
      .withColumn("Modifier2",$"AliasModifier2")
      .withColumn("Modifier3",$"AliasModifier3")
      .withColumn("Modifier4",$"AliasModifier4")
      .withColumn("Insurance",$"AliasInsurance")
      .withColumn("CodeSystem",$"AliasProcedureCategory")
      .withColumn("NegationInd",$"AliasNegationInd")
      .withColumn("ModifiedDate", lit(current_timestamp))
      .drop("AliasProcedureCode", "AliasProcedureText", "AliasProcedureStatusUid",
        "AliasTargetSiteUid", "AliasServiceLocationUid", "AliasServiceProviderUid",
        "AliasProcedureComment", "AliasProcedureText", "AliasTargetSiteText",
        "AliasModifier1", "AliasModifier2", "AliasModifier3", "AliasModifier4",
        "AliasInsurance", "AliasProcedureCategory", "AliasNegationInd")


    val whereclausePatientProcedure =  PatientProcedure_prod.as("df1")
      .join(CleanData5.filter($"StatusId" ===1).as("df2"), Seq("PatientProcedureUid"))
      .select($"df1.*")

    val ExceptupdatePatientProcedure4 = PatientProcedure_prod.except(whereclausePatientProcedure)
    var PatientProcedure_prod_Delta = updatePatientProcedure4.union(ExceptupdatePatientProcedure4)

    // Insert New Patient Procedure
    val insertPatientProcedure = CleanData5.as("df1")
      .join(PatientProcedure_prod_Delta.as("df2"), $"df1.PatientProcedureUid" === $"df2.PatientProcedureUid", "left_outer")
      .filter($"df2.PatientProcedureUid".isNull)
      .select($"df1.PatientProcedureUid", $"df1.PatientUid", $"df1.CodeUid", $"df1.ProcedureCode",
        $"df1.ProcedureDate", $"df1.ProcedureStatusUid", $"df1.TargetSiteUid", $"df1.ServiceLocationUid",
        $"df1.ServiceProviderUid", $"df1.Modifier1", $"df1.Modifier2", $"df1.Modifier3", $"df1.Modifier4",
        $"df1.Insurance", $"df1.ProcedureCategory", $"df1.NegationInd")
      .groupBy($"df1.PatientProcedureUid", $"df1.PatientUid", $"df1.CodeUid", $"df1.ProcedureCode",
        $"df1.ProcedureDate", $"df1.ProcedureStatusUid", $"df1.TargetSiteUid", $"df1.ServiceLocationUid",
        $"df1.ServiceProviderUid", $"df1.Modifier1", $"df1.Modifier2", $"df1.Modifier3", $"df1.Modifier4",
        $"df1.Insurance", $"df1.ProcedureCategory", $"df1.NegationInd")
      .agg(max($"ProcedureText").as("PracticeCode"), max($"ProcedureComment").as("PracticeDescription")
        , max($"ProcedureText").as("Description"), max($"TargetSiteText").as("CodeSystem"))


    val PatientPro_allcols = PatientProcedure_prod_Delta.columns.toSet
    val insert_cols3 = insertPatientProcedure.columns.toSet
    val tot5 = PatientPro_allcols ++ insert_cols3

    PatientProcedure_prod_Delta = PatientProcedure_prod_Delta.select(FunctionUtility.addColumns(PatientPro_allcols, tot5): _*)
      .union(insertPatientProcedure.select(FunctionUtility.addColumns(insert_cols3, tot5): _*))



    List(PatientProcedure_prod_Delta,Individual_prod_Delta3,ServiceProvider_prod_Delta2,Institution_Prod_Delta2
    ,ServiceLocation_Prod_Delta2)
  }

}
