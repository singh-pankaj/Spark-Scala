package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


class CachePatientNotesResultObservation {

  def CachePatientNotesResultObservationFunc(spark : SparkSession,MergePracticeMap : DataFrame
                                             ,CDRPatientCrosswalkTable : DataFrame
                                             ,ClinicalInformationModelSection : DataFrame
                                             ,MultiTableExtendTable : DataFrame
                                             ,Individual : DataFrame
                                             ,ProviderNPIChangeTable : DataFrame
                                             ,ViewServiceProvider_prod : DataFrame
                                             ,ViewFacility_Prod : DataFrame
                                             ,distIndUid : DataFrame
                                             ,distspUID : DataFrame
                                             ,Patient_Prod_Delta : DataFrame
                                             ,Individual_prod_Delta10 : DataFrame
                                             ,ServiceProvider_prod_Delta9 : DataFrame
                                             ,Institution_Prod_Delta6 : DataFrame
                                             ,ServiceLocation_Prod_Delta6 : DataFrame
                                             ,PatientNoteResultObservation_Prod : DataFrame) : List[DataFrame] = {
    val logger = LoggerFactory.getLogger("")
    import spark.implicits._

    //Start CachePatientNotesResultObservation
    var CachePatientNotesResultObservation = spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9")

    val lookup13 = Map("_c0" -> "PatientId", "_c1" -> "EncounterDate", "_c2" -> "SectionName"
      , "_c3" -> "Note", "_c4" -> "ServiceProviderNPI", "_c5" -> "ServiceProviderLastName"
      , "_c6" -> "ServiceProviderFirstName", "_c7" -> "ServiceLocationId", "_c8" -> "ServiceLocationName"
      , "_c9" -> "Group1", "_c10" -> "Group2", "_c11" -> "Group3", "_c12" -> "Group4"
      , "_c13" -> "PracticePatientNoteKey", "_c14" -> "PracticeUid", "_c15" -> "BatchUid", "_c16" -> "dummy1"
      , "_c17" -> "dummy2")

    CachePatientNotesResultObservation = CachePatientNotesResultObservation
      .select(CachePatientNotesResultObservation.columns.map(c => col(c).as(lookup13.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    val tempCachePatientNotesResultObservation = spark.read.option("header", "true")
      .csv("/home/gajanan.doifode/AAO_DATA/Schema/CachePatientNotesResultObservation.txt")

    val CachePNResObsAllcols = tempCachePatientNotesResultObservation.columns.toSet
    val CachePNResObsViewcols = CachePatientNotesResultObservation.columns.toSet
    val tot_viewPNRO_PNResObs = CachePNResObsAllcols ++ CachePNResObsViewcols

    CachePatientNotesResultObservation = tempCachePatientNotesResultObservation.select(FunctionUtility.addColumns(CachePNResObsAllcols, tot_viewPNRO_PNResObs): _*)
      .union(CachePatientNotesResultObservation.select(FunctionUtility.addColumns(CachePNResObsViewcols, tot_viewPNRO_PNResObs): _*))

    CachePatientNotesResultObservation = CachePatientNotesResultObservation.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    val dist_PUID_CPNRObs = CachePatientNotesResultObservation.filter($"StatusId".isNull).select("PracticeUid").distinct()
    val MergePracticeMap_CPNRObs = MergePracticeMap.as("df1").join(dist_PUID_CPNRObs.as("df2")
      , $"df1.NewPracticeUid" === $"df2.PracticeUid").select($"df1.*")

    logger.warn("MergePracticeMap_CPNRObs is Created ......")

    //Update PracticeUid with OriginalPracticeUid of CachePatientNotesResultObservation
    CachePatientNotesResultObservation = CachePatientNotesResultObservation.as("df1").join(MergePracticeMap_CPNRObs.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeUid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeUid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeUid of CachePatientNotesResultObservation is Done.................")

    CachePatientNotesResultObservation = CachePatientNotesResultObservation.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CachePatientNotesResultObservation
    CachePatientNotesResultObservation = CachePatientNotesResultObservation.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PatientId", ltrim(rtrim($"df1.PatientId")))
      .withColumn("ServiceProviderNPI", ltrim(rtrim($"df1.ServiceProviderNPI")))
      .withColumn("ServiceLocationId", ltrim(rtrim($"df1.ServiceLocationId")))
      .withColumn("SectionName", ltrim(rtrim($"df1.SectionName")))
      .withColumn("PracticePatientNoteKey", ltrim(rtrim($"df1.PracticePatientNoteKey")))
      .withColumn("PracticeSideNPI", ltrim(rtrim($"df1.ServiceProviderNPI")))

    logger.warn("Update Multiple Columns of CachePatientNotesResultObservation is Done............")

    //update status if PatientId is null Of CachePatientNotesResultObservation
    val update_status_CPNRObs = CachePatientNotesResultObservation.filter($"StatusId" === 1 && $"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val where_status_CPNRObs = CachePatientNotesResultObservation.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_status_CPNRObs.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_status_CPNRObs)
      CachePatientNotesResultObservation = ex.union(update_status_CPNRObs)
    }

    logger.warn("update status if PatientId is null Of CachePatientNotesResultObservation is Done........")

    //Update PatientId using CDRPatientCrosswalk Of CachePatientNotesResultObservation
    val update_PatientId_CPNRObs = CachePatientNotesResultObservation.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientId_CPNRObs = CachePatientNotesResultObservation.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientId_CPNRObs.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_PatientId_CPNRObs)
      CachePatientNotesResultObservation = ex.union(update_PatientId_CPNRObs)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk Of CachePatientNotesResultObservation  is Done........")

    //Update Multiple Status Of CachePatientNotesResultObservation
    val abc2 = CachePatientNotesResultObservation.filter($"StatusId" === 1 && $"PracticePatientNoteKey".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PracticePatientNoteKey is Not Found or Missing"))

    val jkl2 = CachePatientNotesResultObservation.filter($"StatusId" === 1 && $"SectionName".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("SectionName is null"))

    val mno2 = CachePatientNotesResultObservation.filter($"StatusId" === 1 && $"Note".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Note is null"))

    val update_status_CPNRObs2 = abc2.union(jkl2).union(mno2)

    val where_status_CPNRObs2 = CachePatientNotesResultObservation.filter($"StatusId" === 1 && $"PracticePatientNoteKey".isNull
      || $"SectionName".isNull || $"Note".isNull)

    if (where_status_CPNRObs2.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_status_CPNRObs2)
      CachePatientNotesResultObservation = ex.union(update_status_CPNRObs2)
    }

    logger.warn("Update Multiple Status Of CachePatientNotesResultObservation is Done........")

    //Update ClinicalInformationModelSectionUid of CachePatientNotesResultObservation
    val update_CInfoModelSecUid_CPNRObs = CachePatientNotesResultObservation.as("df1")
      .join(ClinicalInformationModelSection.as("df2")
      , $"df1.SectionName" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ClinicalInformationModelSectionUid".isNull)
      .select($"df1.*", $"df2.ClinicalInformationModelSectionUid".as("aliasCIMSUID"))
      .withColumn("ClinicalInformationModelSectionUid", $"aliasCIMSUID")
      .drop("aliasCIMSUID")

    val where_CInfoModelSecUid_CPNRObs = CachePatientNotesResultObservation.as("df1")
      .join(ClinicalInformationModelSection.as("df2")
      , $"df1.SectionName" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ClinicalInformationModelSectionUid".isNull)
      .select($"df1.*")

    if (where_CInfoModelSecUid_CPNRObs.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_CInfoModelSecUid_CPNRObs)
      CachePatientNotesResultObservation = ex.union(update_CInfoModelSecUid_CPNRObs)
    }

    logger.warn("Update ClinicalInformationModelSectionUid of CachePatientNotesResultObservation is Done........")

    //Update  Status ClinicalInformationModelSectionUid is Null Of CachePatientNotesResultObservation
    val update_status_CPNRObs3 = CachePatientNotesResultObservation.filter($"StatusId" === 1
      && $"ClinicalInformationModelSectionUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Section Name Invalid or Missing"))

    val where_status_CPNRObs3 = CachePatientNotesResultObservation.filter($"StatusId" === 1
      && $"ClinicalInformationModelSectionUid".isNull)

    if (where_status_CPNRObs3.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_status_CPNRObs3)
      CachePatientNotesResultObservation = ex.union(update_status_CPNRObs3)
    }

    logger.warn("Update Status ClinicalInformationModelSectionUid is Null Of CachePatientNotesResultObservation is Done........")

    //Update ServiceProvideNPI Of CachePatientNotesResultObservation
    val update_SPNPI_CPNRObs = CachePatientNotesResultObservation.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderNPI" === $"df2.Element1" && $"df2.GroupName" === "ProviderNPI")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue").drop($"AliasValue")

    val where_SPNPI_CPNRObs = CachePatientNotesResultObservation.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderNPI" === $"df2.Element1" && $"df2.GroupName" === "ProviderNPI")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_SPNPI_CPNRObs.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_SPNPI_CPNRObs)
      CachePatientNotesResultObservation = ex.union(update_SPNPI_CPNRObs)
    }

    logger.warn("update ServiceProviderNPI Of CachePatientNotesResultObservation is Done........")


    //update ServiceProviderNPI  Of CachePatientNotesResultObservation 2
    val update_SPNPI_CPNRObs2 = Individual.as("df1")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid")
      .join(CachePatientNotesResultObservation.as("df3"), $"df3.PracticeUid" === $"df1.PracticeUid" &&
        $"df3.ServiceProviderNPI" === $"df2.OldNPI")
      .filter($"StatusId" === 1)
      .select($"df3.*", $"df2.NewNPI".as("AliasNewNPI"))
      .withColumn("ServiceProviderNPI", $"AliasNewNPI").drop($"AliasNewNPI")

    val where_SPNPI_CPNRObs2 = Individual.as("df1")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid")
      .join(CachePatientNotesResultObservation.as("df3"), $"df3.PracticeUid" === $"df1.PracticeUid" &&
        $"df3.ServiceProviderNPI" === $"df2.OldNPI")
      .filter($"StatusId" === 1)
      .select($"df3.*")

    if (where_SPNPI_CPNRObs2.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_SPNPI_CPNRObs2)
      CachePatientNotesResultObservation = ex.union(update_SPNPI_CPNRObs2)
    }

    logger.warn("update ServiceProviderNPI Of CachePatientNotesResultObservation 2 is Done........")


    //Update ServiceProviderNPI of CachePatientNotesResultObservation 3
    val update_SPNPI_CPNRObs3 = CachePatientNotesResultObservation.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element1" && $"df1.ServiceProviderLastName" === $"df2.Element2"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"df1.StatusId" === 1 && $"df2.Element2".isNotNull && $"df1.ServiceProviderNPI".isNull)
      .select($"df1.*", $"df2.Value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue").drop($"AliasValue")

    val where_SPNPI_CPNRObs3 = CachePatientNotesResultObservation.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element1" && $"df1.ServiceProviderLastName" === $"df2.Element2"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"df1.StatusId" === 1 && $"df2.Element2".isNotNull && $"df1.ServiceProviderNPI".isNull)
      .select($"df1.*")

    if (where_SPNPI_CPNRObs3.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_SPNPI_CPNRObs3)
      CachePatientNotesResultObservation = ex.union(update_SPNPI_CPNRObs3)
    }

    logger.warn("update ServiceProviderNPI  Of CachePatientNotesResultObservation 3 is Done........")

    //update status if ServiceProviderNPI is Null Of CachePatientNotesResultObservation
    val update_status_CPNRObs4 = CachePatientNotesResultObservation.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid NPI Found,Length should be 10"))

    val where_status_CPNRObs4 = CachePatientNotesResultObservation.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)

    if (where_status_CPNRObs4.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_status_CPNRObs4)
      CachePatientNotesResultObservation = ex.union(update_status_CPNRObs4)
    }

    logger.warn("update status if ServiceProviderNPI is Null Of CachePatientNotesResultObservation is Done........")

    //update PatientUid Using Patient_prod && Individual_prod of CachePatientNotesResultObservation
    val update_PatientUid_CPNRObs = CachePatientNotesResultObservation.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta10.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val where_PatientUid_CPNRObs = CachePatientNotesResultObservation.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta10.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientUid_CPNRObs.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_PatientUid_CPNRObs)
      CachePatientNotesResultObservation = ex.union(update_PatientUid_CPNRObs)
    }

    logger.warn("update PatientUid Using Patient_prod && Individual_prod of CachePatientNotesResultObservation is Done........")

    //Update ServiceProviderUid of CachePatientNotesResultObservation
    val update_SPUID_CPNRObs = CachePatientNotesResultObservation.as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceProviderUid".as("aliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"aliasServiceProviderUid")
      .drop("aliasServiceProviderUid")

    val where_SPUID_CPNRObs = CachePatientNotesResultObservation.as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1)
      .select($"df1.*")


    if (where_SPUID_CPNRObs.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_SPUID_CPNRObs)
      CachePatientNotesResultObservation = ex.union(update_SPUID_CPNRObs)
    }

    logger.warn("Update ServiceProviderUid of CachePatientNotesResultObservation is Done........")

    //Update ServiceLocationUid of CachePatientNotesResultObservation using ViewFacility
    val update_SLUID_CPNRObs = CachePatientNotesResultObservation.as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationId" === $"df2.ID"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceLocationUid".as("aliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"aliasServiceLocationUid")
      .drop("aliasServiceLocationUid")

    val where_SLUID_CPNRObs = CachePatientNotesResultObservation.as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationId" === $"df2.ID"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_SLUID_CPNRObs.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_SLUID_CPNRObs)
      CachePatientNotesResultObservation = ex.union(update_SLUID_CPNRObs)
    }

    logger.warn("Update ServiceLocationUid of CachePatientNotesResultObservation using ViewFacility is Done........")


    //update status if PatientUid is null Of CachePatientNotesResultObservation
    val update_status_CPNRObs5 = CachePatientNotesResultObservation.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_status_CPNRObs5 = CachePatientNotesResultObservation.filter($"StatusId" === 1 && $"PatientUid".isNull)

    if (where_status_CPNRObs5.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_status_CPNRObs5)
      CachePatientNotesResultObservation = ex.union(update_status_CPNRObs5)
    }

    logger.warn("update status if PatientUid is null Of CachePatientNotesResultObservation is Done........")

    //Create Table Phy of CachePatientNotesResultObservation
    val Phy_PNResObs = CachePatientNotesResultObservation.as("df1")
      .select("ServiceProviderUid", "ServiceProviderNPI", "ServiceProviderFirstName", "ServiceProviderLastName"
        , "PracticeUid", "StatusId")
      .where($"ServiceProviderNPI".isNotNull && $"ServiceProviderUid".isNull && $"StatusId" === 1)
      .groupBy($"ServiceProviderNPI", $"PracticeUid")
      .agg(max("ServiceProviderFirstName").as("ServiceProviderFirstName")
        , max("ServiceProviderLastName").as("ServiceProviderLastName"))
      .withColumn("Physician_MidName", lit("null"))
      .withColumn("ServiceProviderUid", FunctionUtility.getNewUid())

    //Update ServiceProviderUid Using PHY of CachePatientNotesResultObservation
    val update_SPUID_CPNRObs2 = CachePatientNotesResultObservation.as("df1.").join(Phy_PNResObs.as("df2")
      , $"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderUid".isNull && $"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceProviderUid".as("aliasSPUID"))
      .withColumn("ServiceProviderUid", $"aliasSPUID")
      .drop("aliasSPUID")

    val where_SPUID_CPNRObs2 = CachePatientNotesResultObservation.as("df1.").join(Phy_PNResObs.as("df2")
      , $"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderUid".isNull && $"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_SPUID_CPNRObs2.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_SPUID_CPNRObs2)
      CachePatientNotesResultObservation = ex.union(update_SPUID_CPNRObs2)
    }

    logger.warn("Update ServiceProviderUid Using PHY of CachePatientNotesResultObservation is Done........")

    //Insert data Into Individual Table using CachePatientNotesResultObservation
    val insert_Individual = Phy_PNResObs.as("df1")
      .join(distIndUid.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.IndividualUid"))
      .select($"df1.ServiceProviderUid".as("IndividualUid"), $"df1.ServiceProviderFirstName".as("First")
        , $"df1.Physician_MidName".as("Middle"), $"ServiceProviderLastName".as("Last"),
        $"df1.PracticeUid".as("PracticeUid")).distinct()

    val indicols = Individual_prod_Delta10.columns.toSet
    val insertIndividualcols = insert_Individual.columns.toSet
    val tot = indicols ++ insertIndividualcols

    val Individual_prod_Delta11 = Individual_prod_Delta10.select(FunctionUtility.addColumns(indicols, tot): _*)
      .union(insert_Individual.select(FunctionUtility.addColumns(insertIndividualcols, tot): _*))


    logger.warn("Insert data Into Individual Table using CachePatientNotesResultObservation is Done............")

    //Insert data Into ServiceProvider Table using CachePatientNotesResultObservation
    val insert_ServiceProv_PNResObs = Phy_PNResObs.as("df1").join(distspUID.as("df2")
      , !$"df1.ServiceProviderUid".isin($"df2.ServiceProviderUid"))
      .select($"df1.ServiceProviderUid", when($"df1.Physician_MidName".isNotNull, concat_ws(" "
        , $"ServiceProviderLastName", $"ServiceProviderFirstName", $"Physician_MidName"))
        .otherwise(concat_ws(" ", $"ServiceProviderLastName", $"ServiceProviderFirstName")).as("ListName")
        , $"df1.ServiceProviderNPI".as("NPI"))
      .withColumn("ExternalID", lit(null))
      .withColumn("Type", lit(4))

    val servicePcols = ServiceProvider_prod_Delta9.columns.toSet
    val insertdataServiceProvcols = insert_ServiceProv_PNResObs.columns.toSet
    val tot1 = servicePcols ++ insertdataServiceProvcols

    val ServiceProvider_prod_Delta10 = ServiceProvider_prod_Delta9.select(FunctionUtility.addColumns(servicePcols, tot1): _*)
      .union(insert_ServiceProv_PNResObs.select(FunctionUtility.addColumns(insertdataServiceProvcols, tot1): _*))

    logger.warn("Insert data Into ServiceProvider Table using CachePatientNotesResultObservation is Done............")


    //Create #tempLoc_PNResObs
    val tempLoc_PNResObs = CachePatientNotesResultObservation.filter($"StatusId" === 1 && $"ServiceLocationUid".isNull
      && ltrim(rtrim($"ServiceLocationId")).isNotNull)
      .select($"ServiceLocationId", when($"ServiceLocationName".isNull, $"ServiceLocationId").otherwise($"ServiceLocationName")
        .as("ServiceLocationName"), $"PracticeUid")
      .withColumn("ServiceLocationUid", FunctionUtility.getNewUid())


    //Update ServiceLocationUid of CachePatientNotesResultObservation Using tempLoc_PNResObs
    val update_ServiceLUID_PNResObs = CachePatientNotesResultObservation.as("df1").join(tempLoc_PNResObs.as("df2")
      , $"df1.ServiceLocationId" === $"df2.ServiceLocationId" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceLocationName" === $"df2.ServiceLocationName")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceLocationUid".as("aliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"aliasServiceLocationUid")
      .drop("aliasServiceLocationUid")

    val where_ServiceLUID_PNResObs = CachePatientNotesResultObservation.as("df1").join(tempLoc_PNResObs.as("df2")
      , $"df1.ServiceLocationId" === $"df2.ServiceLocationId" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceLocationName" === $"df2.ServiceLocationName")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_ServiceLUID_PNResObs.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_ServiceLUID_PNResObs)
      CachePatientNotesResultObservation = ex.union(update_ServiceLUID_PNResObs)
    }

    logger.warn("Update ServiceLocationUid of CachePatientNotesResultObservation Using tempLoc_PNResObs is Done........")

    //Insert data Into Institution_Prod Using CachePatientNotesResultObservation
    val Insert_Institution = tempLoc_PNResObs.select($"ServiceLocationUid".as("InstitutionUid")
      , $"ServiceLocationName".as("Name"), $"PracticeUid")
      .withColumn("Type", lit(5))

    val allcols2 = Institution_Prod_Delta6.columns.toSet
    val insertcols2 = Insert_Institution.columns.toSet
    val tot4 = allcols2 ++ insertcols2

    val Institution_Prod_Delta7 =  Institution_Prod_Delta6.select(FunctionUtility.addColumns(allcols2, tot4): _*)
      .union(Insert_Institution.select(FunctionUtility.addColumns(insertcols2, tot4): _*))

    logger.warn("Insert into Institution Using tempLoc_PNResObs of CachePatientNotesProblem is Done............")

    //Insert data into ServiceLocation Using CachePatientNotesResultObservation
    val Insert_ServiceLocation = tempLoc_PNResObs.select($"ServiceLocationUid"
      , $"ServiceLocationId".as("ExternalID"))

    val allcols3 = ServiceLocation_Prod_Delta6.columns.toSet
    val insert3 = Insert_ServiceLocation.columns.toSet
    val tot5 = allcols3 ++ insert3

    val ServiceLocation_Prod_Delta7 = ServiceLocation_Prod_Delta6.select(FunctionUtility.addColumns(allcols3, tot5): _*)
      .union(Insert_ServiceLocation.select(FunctionUtility.addColumns(insert3, tot5): _*))
    logger.warn("Insert data into ServiceLocation Using CachePatientNotesResultObservation is Done............")


    //Update PatientNoteResultObservationUid of CachePatientNotesResultObservation
    val update_PatientNoteResultObservationUid = CachePatientNotesResultObservation.as("df1").join(PatientNoteResultObservation_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientNoteResultObservationUid".as("aliasPNPUid"))
      .withColumn("PatientNoteResultObservationUid", $"aliasPNPUid")
      .drop("aliasPNPUid")

    val where_PatientNoteResultObservationUid = CachePatientNotesResultObservation.as("df1").join(PatientNoteResultObservation_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientNoteResultObservationUid.count > 0) {
      val ex = CachePatientNotesResultObservation.except(where_PatientNoteResultObservationUid)
      CachePatientNotesResultObservation = ex.union(update_PatientNoteResultObservationUid)
    }

    logger.warn("Update PatientNoteResultObservationUid of CachePatientNotesResultObservation is Done........")

    //Drop Duplicates From CachePatientNotesResultObservation
    var cleanedCachePatientNotesResultObservation = CachePatientNotesResultObservation.dropDuplicates(Seq("PatientUid"
      , "PracticePatientNoteKey"))
    val duplicateRecords_CachePatientNotesResultObservation = CachePatientNotesResultObservation.except(cleanedCachePatientNotesResultObservation)
    logger.warn("Drop Duplicates From CachePatientNotesResultObservation is Done........")

    //Create Table PatientNoteResultObservation_PNRO
    val PatientNoteResultObservation_PNRO = cleanedCachePatientNotesResultObservation.filter($"StatusId" === 1 &&
      $"PatientNoteResultObservationUid".isNull && $"PracticePatientNoteKey".isNotNull)
      .select($"PatientUid", $"PracticePatientNoteKey").distinct()
      .withColumn("PatientNoteResultObservationUid",FunctionUtility.getNewUid())

    //Update PatientNoteResultObservationUid of CachePatientNotesResultObservation 2
    val update_PatientNoteResultObservationUid2 = cleanedCachePatientNotesResultObservation.as("df1").join(PatientNoteResultObservation_PNRO.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey"
        && $"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientNoteResultObservationUid".as("aliasPNPUid"))
      .withColumn("PatientNoteResultObservationUid", $"aliasPNPUid")
      .drop("aliasPNPUid")

    val where_PatientNoteResultObservationUid2 = cleanedCachePatientNotesResultObservation.as("df1").join(PatientNoteResultObservation_PNRO.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey"
        && $"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientNoteResultObservationUid2.count > 0) {
      val ex = cleanedCachePatientNotesResultObservation.except(where_PatientNoteResultObservationUid2)
      cleanedCachePatientNotesResultObservation = ex.union(update_PatientNoteResultObservationUid2)
    }

    logger.warn("Update PatientNoteResultObservationUid of CachePatientNotesResultObservation 2 is Done........")

    //Update PatientNoteResultObservation_Prod Using CachePatientNotesResultObservation
    val update_PatientNoteResultObservation = PatientNoteResultObservation_Prod.as("df1").join(cleanedCachePatientNotesResultObservation.as("df2")
      , $"df1.PatientNoteResultObservationUid" === $"df2.PatientNoteResultObservationUid")
      .where($"df2.StatusId" === 1)
      .select($"df1.*", $"df2.Note".as("aliasNote"), $"df2.Group1".as("aliasGroup1"), $"df2.Group2".as("aliasG2")
        , $"df2.Group3".as("aliasG3"), $"df2.Group4".as("aliasG4"), $"df2.PracticePatientNoteKey".as("aliasPNkey"))
      .withColumn("Note", $"aliasNote")
      .withColumn("ModifiedDate", current_timestamp())
      .withColumn("Group1", $"aliasGroup1")
      .withColumn("Group2", $"aliasG2")
      .withColumn("Group3", $"aliasG3")
      .withColumn("Group4", $"aliasG4")
      .withColumn("PracticePatientNoteKey", $"aliasPNkey")
      .drop("aliasNote", "aliasGroup1", "aliasG2", "aliasG3", "aliasG4", "aliasPNkey")

    val where_PatientNoteResultObservation = PatientNoteResultObservation_Prod.as("df1").join(cleanedCachePatientNotesResultObservation.as("df2")
      , $"df1.PatientNoteResultObservationUid" === $"df2.PatientNoteResultObservationUid")
      .where($"df2.StatusId" === 1)
      .select($"df1.*")

    val ex_PatientNoteResultObservation = PatientNoteResultObservation_Prod.except(where_PatientNoteResultObservation)

    var PatientNoteResultObservation_Prod_Delta = ex_PatientNoteResultObservation.union(update_PatientNoteResultObservation)
    logger.warn("Update PatientNoteResultObservation_Prod Using CachePatientNotesResultObservation is Done........")

    //Insert Data Into PatientNoteResultObservation_Prod Using cleanedCachePatientNotesResultObservation
    val insert_PatientNoteResultObservation= cleanedCachePatientNotesResultObservation.as("df1")
      .join(PatientNoteResultObservation_Prod_Delta.as("df2")
      , $"df1.PatientNoteResultObservationUid" === $"df2.PatientNoteResultObservationUid", "left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.PatientNoteResultObservationUid".isNull)
      .select($"df1.PatientNoteResultObservationUid", $"df1.PatientUid", $"df1.ClinicalInformationModelSectionUid"
        , $"df1.Note", $"df1.EncounterDate".as("ReferenceDate"), $"df1.ServiceProviderUid"
        , $"df1.ServiceLocationUid", $"df1.Group1", $"df1.Group2", $"df1.Group3", $"df1.Group4"
        , $"df1.PracticePatientNoteKey")
      .withColumn("CreatedDate", current_timestamp())
      .withColumn("CreatedByUid", lit("null"))
      .withColumn("ModifiedDate", current_timestamp())
      .withColumn("ModifiedByUid", lit("null"))

    val allcols5 = PatientNoteResultObservation_Prod_Delta.columns.toSet
    val insert5 = insert_PatientNoteResultObservation.columns.toSet
    val tot6 = allcols5 ++ insert5

    PatientNoteResultObservation_Prod_Delta = PatientNoteResultObservation_Prod_Delta.select(FunctionUtility.addColumns(allcols5, tot6): _*)
      .union(insert_PatientNoteResultObservation.select(FunctionUtility.addColumns(insert5, tot6): _*))

    logger.warn("Insert Data Into PatientNoteResultObservation_Prod Using cleanedCachePatientNotesResultObservation Done........")
    logger.warn("End CachePatientNotesResultObservation ....................")

    List(PatientNoteResultObservation_Prod_Delta,Individual_prod_Delta11,ServiceProvider_prod_Delta10,Institution_Prod_Delta7
    ,ServiceLocation_Prod_Delta7)
  }

}
