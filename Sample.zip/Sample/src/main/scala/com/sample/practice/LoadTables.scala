package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}

class LoadTables {

def readTable(spark : SparkSession): List[DataFrame] = {



  val ProviderNPIChangeTable = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "ProviderNPIChange")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  val MappingPracticeInsuranceData = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeInsuranceData")
    .option("user", "mapping")
    .option("password", "mp3245")

  val MappingPracticeInsuranceData_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeInsuranceData")
    .option("user", "mapping").option("password", "mp3245").load()

  val clinicaldatarepository = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "clinicaldatarepository")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()


  val ClinicalInformationModelSection = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "ClinicalInformationModelSection")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()


  val MultiTableExtendTable = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MultiTableExtend")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()


  val MappingPracticeProcedureTable = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeProcedure")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  //*************************//

  val practice = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "practice")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  //MappingPracticeProblem

  val MappingPracticeProblem = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeProblem")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  //MappingPracticeMedication

  val MappingPracticeMedication = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeMedication")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  //MappingPracticeResult

  val MappingPracticeLabResult = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeLabResult")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  val PracticeImportDetails = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PracticeImportDetails")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()


  val Individual = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "Individual")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()


  val MergePracticeMap = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MergePracticeMap")
    .option("user", "mapping").option("password", "mp3245").load()


  val ViewServiceProvider = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "ViewServiceProvider")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()


  //************************** PROD TABLES ****************************//

  var MappingPracticeLabResult_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeLabResult")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  val PatientFamilyHistoryDF = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientFamilyHistory")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()


  val PatientImmunizationTable = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientImmunization")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  val MappingPracticeProcedure_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeProcedure")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()


  //CDRPatientCrosswalk
  val CDRPatientCrosswalkTable = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "CDRPatientCrosswalk")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  val IndivisualProdTable = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "Individual")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  val PatientTable_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "Patient")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()


  //Create PatientNoteMedication_Prod table
  val PatientNoteMedication_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientNoteMedication")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  //PatientNoteTable
  val PatientNoteTable_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientNote")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  //Create MasterState_prod Table
  val MasterStatePostalCode_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterState")
    .option("user", "mapping").option("password", "mp3245").load()

  //Create masterRelationship_prod Table
  val MasterRelationship_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterRelationship")
    .option("user", "mapping").option("password", "mp3245").load()

  //Create PatientGuardian_Prod table
  val PatientGuardian_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientGuardian")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  val ViewFacility_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "ViewFacility")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  var Institution_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "Institution")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  var ServiceLocation_Prod = spark.read.format("jdbc").
    option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "ServiceLocation")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  var Visit_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "Visit")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  val PatientInsuranceInfo_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientInsuranceInfo")
    .option("user", "mapping").option("password", "mp3245").load()

  val MasterCode_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterCode")
    .option("user", "mapping").option("password", "mp3245").load()

  val PatientProblem_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientProblem")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  var PatientProblemHistory_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientProblemHistory")
    .option("user", "mapping").option("password", "mp3245").load()

  var VisitDiagnosis_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "VisitDiagnosis")
    .option("user", "mapping").option("password", "mp3245").load()


  //load Table PatientAdvanceDirectiveObservation
  val PatientAdvanceDirectiveObservation_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientAdvanceDirectiveObservation")
    .option("user", "mapping").option("password", "mp3245").load()

  //Load Table MappingPracticeAllergy
  val MappingPracticeAllergy_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeAllergy")
    .option("user", "mapping").option("password", "mp3245").load()

  val MappingPracticeAllergy = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database= FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeAllergy")
    .option("user", "mapping").option("password", "mp3245").load()


  //Load Table MasterAllergy
  val MasterAllergy_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterAllergy")
    .option("user", "mapping").option("password", "mp3245").load()


  //Load MasterDispensableDrug Table
  val MasterDispensableDrug_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterDispensableDrug")
    .option("user", "mapping").option("password", "mp3245").load()

  //Load PatientMedication_Prod Table
  var PatientMedication_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientMedication")
    .option("user", "mapping").option("password", "mp3245").load()

  //Load MasterMedicationRoute Table
  val MasterMedicationRoute_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterMedicationRoute")
    .option("user", "mapping").option("password", "mp3245").load()

  //Load PatientResultObservation_Prod
  val PatientResultObservation_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientResultObservation")
    .option("user", "mapping").option("password", "mp3245").load()

  //Load PatientLanguage_Prod
  val PatientLanguage_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientLanguage")
    .option("user", "mapping").option("password", "mp3245").load()

  //Load PatientNoteProblem
  val PatientNoteProblem_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientNoteProblem")
    .option("user", "mapping").option("password", "mp3245").load()

  //Load PatientNoteResultObservation
  var PatientNoteResultObservation_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientNoteResultObservation")
    .option("user", "mapping").option("password", "mp3245").load()

  //Update PatientSocialHistoryObservationUid From PatientSocialHistoryObservation
  val PatientSocialHistoryObservation_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientSocialHistoryObservation")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  var Individualidentifier_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "IndividualIdentifier")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  var Patient_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "Patient")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  var Individual_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "Individual")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  var ViewServiceProvider_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "ViewServiceProvider")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  //Insert Data into ServiceProvider
  var ServiceProvider_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "ServiceProvider")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  //Update Gender From MasterGender cheking ExternalID
  val MasterGender_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterGender")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  //Update MaritalStatusUid using MasterMaritalTable
  val MasterMaritalStatus_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterMaritalStatus")
    .option("user", "mapping").option("password", "mp3245").load()

  //Update CityUid using Multiple Master tables
  val MasterCity_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterCity")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  val MasterPostalCode_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterPostalCode")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  val MasterCityPostalCode_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterCityPostalCode")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  //Update SateUid using MasterSate Table
  val MasterState_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterState")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  //Update CountryUid From MasterCountry Table
  val MasterCountry_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterCountry")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  //Update Phone1TypeUid  on Description
  val MasterPhoneType_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterPhoneType")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  val Master_prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "Master")
    .option("user", "mapping").option("password", "mp3245").load()

  //Update Address Records
  var Address_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "Address")
    .option("user", "mapping").option("password", "mp3245").load()

  var Phone_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "Phone")
    .option("user", "mapping").option("password", "mp3245").load()


  val PatientVitalSignObservation_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientVitalSignObservation")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()



  val PatientNoteProcedure = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientNoteProcedure")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  var MappingPracticeCommonData = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeCommonData")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  //PatientProcedure
  val PatientProcedureDF = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientProcedure")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()


  var MappingPracticeProcedure_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeProcedure")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  var MappingPracticeMedication_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeMedication")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  var MappingPracticeCommonData_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeCommonData")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  var MappingPracticeProblem_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MappingPracticeProblem")
    .option("user", "mapping")
    .option("password", "mp3245")
    .load()

  val MasterEthnicity_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterEthnicity")
    .option("user", "mapping").option("password", "mp3245").load()

  val IndividualEthnicity_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "IndividualEthnicity")
    .option("user", "mapping").option("password", "mp3245").load()

  val MasterRace_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "MasterRace")
    .option("user", "mapping").option("password", "mp3245").load()

  val IndividualRace_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "IndividualRace")
    .option("user", "mapping").option("password", "mp3245").load()

  val PatientNoteVitalObservation_Prod = spark.read.format("jdbc")
    .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    .option("dbtable", "PatientNoteVitalObservation")
    .option("user", "mapping").option("password", "mp3245").load()



  val distIndUid = Individual_prod.select("IndividualUid").distinct()

  val distspUID = ServiceProvider_prod.select("ServiceProviderUid").distinct()

  List(ProviderNPIChangeTable,clinicaldatarepository,ClinicalInformationModelSection,MultiTableExtendTable
    ,MappingPracticeProcedureTable,practice,MappingPracticeProblem,MappingPracticeMedication,
    MappingPracticeLabResult,PracticeImportDetails,Individual,MergePracticeMap,ViewServiceProvider
    ,MappingPracticeLabResult_Prod,PatientFamilyHistoryDF,PatientImmunizationTable,MappingPracticeProcedure_prod,
    CDRPatientCrosswalkTable,IndivisualProdTable,PatientTable_prod,PatientNoteMedication_Prod,PatientNoteTable_prod
    ,MasterStatePostalCode_Prod,MasterRelationship_Prod,PatientGuardian_Prod,
    ViewFacility_Prod,Institution_Prod,ServiceLocation_Prod,Visit_Prod,PatientInsuranceInfo_Prod,MasterCode_Prod
    ,PatientProblem_Prod,PatientProblemHistory_Prod,VisitDiagnosis_Prod,
    PatientAdvanceDirectiveObservation_Prod,MappingPracticeAllergy_Prod,MasterAllergy_Prod,MasterDispensableDrug_Prod
    ,PatientMedication_Prod,MasterMedicationRoute_Prod,PatientResultObservation_Prod,
    PatientLanguage_Prod,PatientNoteProblem_Prod,PatientNoteResultObservation_Prod,PatientSocialHistoryObservation_Prod
    ,Individualidentifier_prod,Patient_prod,Individual_prod,ViewServiceProvider_prod,
    ServiceProvider_prod,MasterGender_Prod,MasterMaritalStatus_prod,MasterCity_prod,MasterPostalCode_prod
    ,MasterCityPostalCode_prod,MasterState_Prod,MasterCountry_Prod,MasterPhoneType_prod,
    Master_prod,Address_Prod,Phone_Prod,PatientVitalSignObservation_Prod
    ,PatientNoteProcedure,MappingPracticeProcedure_Prod,
    MappingPracticeMedication_Prod,MappingPracticeCommonData_Prod,MappingPracticeProblem_Prod,MasterEthnicity_Prod
    ,IndividualEthnicity_Prod,MasterRace_Prod,IndividualRace_Prod,distIndUid,distspUID,MappingPracticeCommonData
  ,PatientProcedureDF,MappingPracticeAllergy,PatientNoteVitalObservation_Prod)
}

}
