package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory


class CachePatientNotesProcedure {

  def PatientNotesProcedureFunc(spark : SparkSession,MergePracticeMap : DataFrame
                                ,CDRPatientCrosswalkTable : DataFrame
                                ,ClinicalInformationModelSection : DataFrame
                                ,MultiTableExtendTable : DataFrame
                                ,ProviderNPIChangeTable : DataFrame
                                ,Individual : DataFrame
                                ,ViewServiceProvider_prod : DataFrame
                                ,ViewFacility_Prod : DataFrame
                                ,distIndUid : DataFrame
                                ,distspUID : DataFrame
                                ,Patient_Prod_Delta : DataFrame
                                ,Individual_prod_Delta9 : DataFrame
                                ,ServiceProvider_prod_Delta8 : DataFrame
                                ,Institution_Prod_Delta5 : DataFrame
                                ,ServiceLocation_Prod_Delta5 : DataFrame
                               ,PatientNoteProcedure : DataFrame) : List[DataFrame] = {

    val logger = LoggerFactory.getLogger("")

    import spark.implicits._

    val CachePatientNotesProcedureFile = spark.read.option("delimiter", "\u0017")
      .csv("")

    val CachePatientNotesProcedurelookup = Map("_c0" -> "PatientId", "_c1" -> "EncounterDate", "_c2" -> "SectionName",
      "_c3" -> "Note", "_c4" -> "ServiceProviderNPI", "_c5" -> "ServiceProviderLastName",
      "_c6" -> "ServiceProviderFirstName", "_c7" -> "ServiceLocationId", "_c8" -> "ServiceLocationName", "_c9" -> "Group1",
      "_c10" -> "Group2", "_c11" -> "Group3", "_c12" -> "Group4", "_c13" -> "PracticePatientNoteKey",
      "_c14" -> "PracticeUid", "_c15" -> "BatchUid")

    val tempCachePatientNotesProcedure = spark.read.option("header", "true").csv("s3n://bd-dev/aao_test/Schema/CDRSchema.txt")
    var tempCachePatientNotesProcedure1 = CachePatientNotesProcedureFile.select(CachePatientNotesProcedureFile.columns.map(c => col(c).as(CachePatientNotesProcedurelookup.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")
    val allcols = tempCachePatientNotesProcedure1.columns.toSet
    val viewcols = tempCachePatientNotesProcedure1.columns.toSet
    val total = allcols ++ viewcols

    tempCachePatientNotesProcedure1 = tempCachePatientNotesProcedure.select(FunctionUtility.addColumns(allcols, total): _*)
      .union(tempCachePatientNotesProcedure1.select(FunctionUtility.addColumns(viewcols, total): _*))


    //Create MergePracticeMapDF
    val TempMergePracticeMapDf = tempCachePatientNotesProcedure1.filter($"StatusId".isNull)
      .select("practiceuid").distinct()

    val MergePracticeMapDF = MergePracticeMap.as("df1")
      .join(TempMergePracticeMapDf.as("df2"), $"df1.NewPracticeUid" === $"df2.practiceuid", "left")
      .select("df1.*")

    val UpdateCachePatientNotesProcedure1 = tempCachePatientNotesProcedure1.filter($"StatusId".isNull).as("df1")
      .join(MergePracticeMapDF.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.OriginalPracticeuid".as("AliasOriginalPracticeuid"))
      .withColumn("Practiceuid", $"AliasOriginalPracticeuid")
      .drop("AliasOriginalPracticeuid")

    val whereclauseCachePatientNotesProcedure = tempCachePatientNotesProcedure1.filter($"StatusId".isNull).as("df1")
      .join(MergePracticeMapDF.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")
    val ExceptUpdateCachePatientNotesProcedure1 = tempCachePatientNotesProcedure1.except(whereclauseCachePatientNotesProcedure)
    // Updated CachePatientNotesProcedureTable into CachePatientNotesProcedure1
    var CachePatientNotesProcedure1 = UpdateCachePatientNotesProcedure1.union(ExceptUpdateCachePatientNotesProcedure1)

    var ChPatientNotesProcedure = CachePatientNotesProcedure1.withColumn("StatusId", lit(1))

    ChPatientNotesProcedure = ChPatientNotesProcedure.filter($"StatusID" === 1)
      .withColumn("OldPracticeUid", $"PracticeUid")
      .withColumn("PatientId", ltrim(rtrim($"PatientId")))
      .withColumn("ServiceProviderNPI", ltrim(rtrim($"ServiceProviderNPI")))
      .withColumn("ServiceLocationid", ltrim(rtrim($"ServiceLocationid")))
      .withColumn("SectionName", ltrim(rtrim($"SectionName")))
      .withColumn("PracticePatientNoteKey", ltrim(rtrim($"PracticePatientNoteKey")))
      .withColumn("PracticeSideNPI", ltrim(rtrim($"ServiceProviderNPI")))

    val UpdateChPatientNotesProcedure1 = ChPatientNotesProcedure.filter($"PatientId".isNull).as("df1")
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val whereclause1 = ChPatientNotesProcedure.filter($"PatientId".isNull).as("df1")
    val ExceptUpdateChPatientNotesProcedure1 = ChPatientNotesProcedure.except(whereclause1)
    // Updated ChPatientNotesProcedure into ChPatientNotesProcedure1
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure1.union(ExceptUpdateChPatientNotesProcedure1)

    val UpdateChPatientNotesProcedure2 = ChPatientNotesProcedure.filter($"StatusId" === 1).as("df1")
      .join(CDRPatientCrosswalkTable.as("df2"), $"df1.PatientId" === $"df2.New_PatientId"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.Old_PatientId".as("AliasOld_PatientId"))
      .withColumn("PatientId", $"AliasOld_PatientId")
      .drop("AliasOld_PatientId")

    val whereclause2 = ChPatientNotesProcedure.filter($"StatusId" === 1).as("df1")
      .join(CDRPatientCrosswalkTable.as("df2"), $"df1.PatientId" === $"df2.New_PatientId"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")
    val ExceptUpdateChPatientNotesProcedure2 = ChPatientNotesProcedure.except(whereclause2)
    // Updated ChPatientNotesProcedure1 into ChPatientNotesProcedure2
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure2.union(ExceptUpdateChPatientNotesProcedure2)

    val UpdateChPatientNotesProcedure3 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && ltrim(rtrim($"PracticePatientNoteKey")).isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PracticePatientNoteKey is Not Found or Missing"))

    val whereclause3 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && ltrim(rtrim($"PracticePatientNoteKey")).isNull)

    val ExceptUpdateChPatientNotesProcedure3 = ChPatientNotesProcedure.except(whereclause3)
    // Updated ChPatientNotesProcedure2 into ChPatientNotesProcedure3
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure3.union(ExceptUpdateChPatientNotesProcedure3)

    val UpdateProcedureSectionNameNull = ChPatientNotesProcedure.filter($"StatusId" === 1
      && $"SectionName".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("SectionName is null"))

    val whereclause4_1 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && $"SectionName".isNull)
    val ExceptChPatientNotesProcedureSectionNameNull = ChPatientNotesProcedure.except(whereclause4_1)
    ChPatientNotesProcedure = UpdateProcedureSectionNameNull.union(ExceptChPatientNotesProcedureSectionNameNull)

    val UpdateChPatientNotesProcedureNoteNull = ChPatientNotesProcedure.filter($"StatusId" === 1
      && $"Note".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Note is null"))

    val whereclause4 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && $"Note".isNull)

    val ExceptUpdateChPatientNotesProcedure4 = ChPatientNotesProcedure.except(whereclause4)
    // Updated ChPatientNotesProcedure3 into ChPatientNotesProcedure4
    ChPatientNotesProcedure = UpdateChPatientNotesProcedureNoteNull.union(ExceptUpdateChPatientNotesProcedure4)

    //Update ClinicalInformationModelSectionUid from  ClinicalInformationModelSection
    val UpdateChPatientNotesProcedure5 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && $"ClinicalInformationModelSectionUid".isNull).as("df1")
      .join(ClinicalInformationModelSection.as("df2"), $"df1.SectionName" === $"df2.Name")
      .select($"df1.*", $"df2.ClinicalInformationModelSectionUid".as("AliasClinicalInformationModelSectionUid"))
      .withColumn("ClinicalInformationModelSectionUid", $"AliasClinicalInformationModelSectionUid")
      .drop("AliasClinicalInformationModelSectionUid")

    val whereclause5 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && $"ClinicalInformationModelSectionUid".isNull).as("df1")
      .join(ClinicalInformationModelSection.as("df2"), $"df1.SectionName" === $"df2.Name")
      .select($"df1.*")

    val ExceptUpdateChPatientNotesProcedure5 = ChPatientNotesProcedure.except(whereclause5)
    // Updated ChPatientNotesProcedure4 into ChPatientNotesProcedure5
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure5.union(ExceptUpdateChPatientNotesProcedure5)

    val UpdateChPatientNotesProcedure6 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && $"ClinicalInformationModelSectionUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Section Name Invalid or Missing"))

    val whereclause6 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && $"ClinicalInformationModelSectionUid".isNull)

    val ExceptUpdateChPatientNotesProcedure6 = ChPatientNotesProcedure.except(whereclause6)
    // Updated ChPatientNotesProcedure5 into ChPatientNotesProcedure6
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure6.union(ExceptUpdateChPatientNotesProcedure6)

    val UpdateChPatientNotesProcedure7 = ChPatientNotesProcedure.filter($"StatusId" === 1).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI").as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderNPI" === $"df2.Element1")
      .select($"df1", $"df2.value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue")
      .drop("AliasValue")

    val whereclause7 = ChPatientNotesProcedure.filter($"StatusId" === 1).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI").as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderNPI" === $"df2.Element1")
      .select($"df1")

    val ExceptUpdateChPatientNotesProcedure7 = ChPatientNotesProcedure.except(whereclause7)
    // Updated ChPatientNotesProcedure6 into ChPatientNotesProcedure7
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure7.union(ExceptUpdateChPatientNotesProcedure7)

    val UpdateChPatientNotesProcedure8 = ProviderNPIChangeTable.as("df1")
      .join(Individual.as("df2"), $"df1.ServiceProviderUid" === $"df2.IndividualUid")
      .join(ChPatientNotesProcedure.filter($"StatusId" === 1).as("df3"), $"df2.PracticeUid" === $"df3.PracticeUid"
        && $"df3.ServiceProviderNPI" === $"df1.OldNPI")
      .select($"df3.*", $"df1.NewNPI".as("AliasNewNPI"))
      .withColumn("ServiceProviderNPI", $"AliasNewNPI")
      .drop("AliasNewNPI")

    val whereclause8 = ProviderNPIChangeTable.as("df1")
      .join(Individual.as("df2"), $"df1.ServiceProviderUid" === $"df2.IndividualUid")
      .join(ChPatientNotesProcedure.filter($"StatusId" === 1).as("df3"), $"df2.PracticeUid" === $"df3.PracticeUid"
        && $"df3.ServiceProviderNPI" === $"df1.OldNPI")
      .select($"df3.*")

    val ExceptUpdateChPatientNotesProcedure8 = ChPatientNotesProcedure.except(whereclause8)
    // Updated ChPatientNotesProcedure7 into ChPatientNotesProcedure8
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure8.union(ExceptUpdateChPatientNotesProcedure8)

    val UpdateChPatientNotesProcedure9 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && $"ServiceProviderNPI".isNull).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI" && $"element2".isNotNull)
        .as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element1"
        && $"df1.ServiceProviderLastName" === $"df2.Element1")
      .select($"df1", $"df2.value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue")
      .drop("AliasValue")

    val whereclause9 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && $"ServiceProviderNPI".isNull).as("df1")
      .join(MultiTableExtendTable.filter($"GroupName" === "ProviderNPI" && $"element2".isNotNull)
        .as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element1"
        && $"df1.ServiceProviderLastName" === $"df2.Element1")
      .select($"df1")

    val ExceptUpdateChPatientNotesProcedure9 = ChPatientNotesProcedure.except(whereclause9)
    // Updated ChPatientNotesProcedure8 into ChPatientNotesProcedure9
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure9.union(ExceptUpdateChPatientNotesProcedure9)

    val UpdateChPatientNotesProcedure10 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && length($"ServiceProviderNPI") =!= 10)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid NPI Found,Length should be 10"))

    val whereclause10 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && length($"ServiceProviderNPI") =!= 10)

    val ExceptUpdateChPatientNotesProcedure10 = ChPatientNotesProcedure.except(whereclause10)
    // Updated ChPatientNotesProcedure9 into ChPatientNotesProcedure10
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure10.union(ExceptUpdateChPatientNotesProcedure10)

    //Update PatientUid  from PatientId & MedicalRecordNumber
    val UpdateChPatientNotesProcedure11 = ChPatientNotesProcedure.filter($"StatusId" === 1).as("df1")
      .join(Patient_Prod_Delta.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod_Delta9.as("df3"), $"df3.IndividualUid" === $"df2.PatientUid"
        && $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*", $"df2.PatientUid".as("AliasPatientUid"))
      .withColumn("PatientUid", $"AliasPatientUid")
      .drop("AliasPatientUid")

    val whereclause11 = ChPatientNotesProcedure.filter($"StatusId" === 1).as("df1")
      .join(Patient_Prod_Delta.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod_Delta9.as("df3"), $"df3.IndividualUid" === $"df2.PatientUid"
        && $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*")

    //Update  ServiceProviderUid
    val ExceptUpdateChPatientNotesProcedure11 = ChPatientNotesProcedure.except(whereclause11)
    // Updated ChPatientNotesProcedure10 into ChPatientNotesProcedure11
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure11.union(ExceptUpdateChPatientNotesProcedure11)

    val UpdateChPatientNotesProcedure12 = ChPatientNotesProcedure.filter($"StatusId" === 1).as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.ServiceProviderUid".as("AliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"AliasServiceProviderUid")
      .drop("AliasServiceProviderUid")

    val whereclause12 = ChPatientNotesProcedure.filter($"StatusId" === 1).as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdateChPatientNotesProcedure12 = ChPatientNotesProcedure.except(whereclause12)
    // Updated ChPatientNotesProcedure11 into ChPatientNotesProcedure12
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure12.union(ExceptUpdateChPatientNotesProcedure12)

    val UpdateChPatientNotesProcedure13 = ChPatientNotesProcedure.filter($"StatusId" === 1).as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationid" === $"df2.id"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.ServiceLocationUid".as("AliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"AliasServiceLocationUid")
      .drop("AliasServiceLocationUid")

    val whereclause13 = ChPatientNotesProcedure.filter($"StatusId" === 1).as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationid" === $"df2.id"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdateChPatientNotesProcedure13 = ChPatientNotesProcedure.except(whereclause13)
    // Updated ChPatientNotesProcedure12 into ChPatientNotesProcedure13
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure13.union(ExceptUpdateChPatientNotesProcedure13)

    val UpdateChPatientNotesProcedure14 = ChPatientNotesProcedure.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("modifieddate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val whereclause14 = ChPatientNotesProcedure.filter($"StatusId" === 1 && $"PatientUid".isNull)

    val ExceptUpdateChPatientNotesProcedure14 = ChPatientNotesProcedure.except(whereclause14)
    // Updated ChPatientNotesProcedure13 into ChPatientNotesProcedure14
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure14.union(ExceptUpdateChPatientNotesProcedure14)

    val InsertIntoPHY = ChPatientNotesProcedure.filter($"ServiceProviderNPI".isNotNull
      && $"ServiceProviderUid".isNull && $"StatusId" === 1)
      .groupBy($"ServiceProviderNPI", $"PracticeUid")
      .agg(max(ltrim(rtrim($"ServiceProviderFirstName"))).as("ServiceProviderFirstName"),
        max(ltrim(rtrim($"ServiceProviderLastName"))).as("ServiceProviderLastName"))
      .withColumn("Physician_MidName", lit(null))
      .withColumn("ServiceProviderUid", FunctionUtility.getNewUid())

    val UpdateChPatientNotesProcedure15 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && $"ServiceProviderUid".isNull)
      .join(InsertIntoPHY, Seq("ServiceProviderNPI", "PracticeUid"))
      .select($"ChPatientNotesProcedure14.*", $"InsertIntoPHY.ServiceProviderUid".as("AliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"AliasServiceProviderUid")
      .drop("AliasServiceProviderUid")

    val whereclause15 = ChPatientNotesProcedure.filter($"StatusId" === 1
      && $"ServiceProviderUid".isNull)
      .join(InsertIntoPHY, Seq("ServiceProviderNPI", "PracticeUid"))
      .select($"ChPatientNotesProcedure14.*")

    val ExceptUpdateChPatientNotesProcedure15 = ChPatientNotesProcedure.except(whereclause15)
    // Updated ChPatientNotesProcedure14 into ChPatientNotesProcedure15
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure15.union(ExceptUpdateChPatientNotesProcedure15)

    val InsertIntoIndividual = InsertIntoPHY.as("df1")
      .join(distIndUid.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.IndividualUid"))
      .select($"df1.ServiceProviderUid".as("IndividualUid"), $"df1.ServiceProviderFirstName".as("First"),
        $"df1.Physician_MidName".as("Middle"), $"df1.ServiceProviderLastName".as("Last"), $"df1.PracticeUid")
      .distinct()

    val indicols = Individual_prod_Delta9.columns.toSet
    val insertIndividualcols = InsertIntoIndividual.columns.toSet
    val tot = indicols ++ insertIndividualcols

    val Individual_prod_Delta10 = Individual_prod_Delta9.select(FunctionUtility.addColumns(indicols, tot): _*)
      .union(InsertIntoIndividual.select(FunctionUtility.addColumns(insertIndividualcols, tot): _*))


    val InsertIntoServiceProvider = InsertIntoPHY.as("df1")
      .join(distspUID.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.ServiceProviderUid"))
      .filter($"df2.new_ServiceProviderUid".isNull)
      .withColumn("ListName", when(ltrim(rtrim($"Physician_MidName")).isNotNull,
        concat(ltrim(rtrim($"ServiceProviderLastName")),
          ltrim(rtrim($"ServiceProviderFirstName")),
          ltrim(rtrim($"Physician_MidName"))))
        .otherwise(concat(ltrim(rtrim($"ServiceProviderLastName")), ltrim(rtrim($"ServiceProviderFirstName")))))
      .select($"df1.ServiceProviderUid", $"df1.ServiceProviderNPI".as("NPI"))
      .withColumn("ExternalID", lit(null))
      .withColumn("Type", lit(4))

    val servicePcols = ServiceProvider_prod_Delta8.columns.toSet
    val insertdataServiceProvcols = InsertIntoServiceProvider.columns.toSet
    val tot1 = servicePcols ++ insertdataServiceProvcols

    val ServiceProvider_prod_Delta9 = ServiceProvider_prod_Delta8.select(FunctionUtility.addColumns(servicePcols, tot1): _*)
      .union(InsertIntoServiceProvider.select(FunctionUtility.addColumns(insertdataServiceProvcols, tot1): _*))

    val InsertIntoLoc = ChPatientNotesProcedure.filter($"StatusId" === 1
      && $"ServiceLocationUid".isNull && ltrim(rtrim($"ServiceLocationId")).isNotNull)
      .select("ServiceLocationId", "ServiceLocationName", "PracticeUid").distinct()
      .withColumn("ServiceLocationName", when(ltrim(rtrim($"ServiceLocationName")).isNull, $"ServiceLocationId")
        .otherwise($"ServiceLocationName"))
      .withColumn("ServiceLocationUid", FunctionUtility.getNewUid())

    val UpdateChPatientNotesProcedure16 = ChPatientNotesProcedure.filter($"StatusId" === 1).as("df1")
      .join(InsertIntoLoc.as("df2"), $"df1.ServiceLocationId" === $"df2.ServiceLocationId"
        && $"df1.ServiceLocationName" === $"df2.ServiceLocationName"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*", $"df2.ServiceLocationUid".as("AliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"AliasServiceLocationUid")
      .drop("AliasServiceLocationUid")

    val whereclause16 = ChPatientNotesProcedure.filter($"StatusId" === 1).as("df1")
      .join(InsertIntoLoc.as("df2"), $"df1.ServiceLocationId" === $"df2.ServiceLocationId"
        && $"df1.ServiceLocationName" === $"df2.ServiceLocationName"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .select($"df1.*")

    val ExceptUpdateChPatientNotesProcedure16 = ChPatientNotesProcedure.except(whereclause16)
    // Updated ChPatientNotesProcedure15 into ChPatientNotesProcedure16
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure16.union(ExceptUpdateChPatientNotesProcedure16)

    val InstitutionDF = InsertIntoLoc
      .select($"ServiceLocationUid".as("InstitutionUid"), $"ServiceLocationName".as("Name"), $"PracticeUid").distinct()
      .withColumn("Type", lit(5))

    val allcols2 = Institution_Prod_Delta5.columns.toSet
    val insertcols2 = InstitutionDF.columns.toSet
    val tot4 = allcols2 ++ insertcols2

    val Institution_Prod_Delta6 =  Institution_Prod_Delta5.select(FunctionUtility.addColumns(allcols2, tot4): _*)
      .union(InstitutionDF.select(FunctionUtility.addColumns(insertcols2, tot4): _*))

    val InsertIntoServiceLocation = InsertIntoLoc
      .select($"ServiceLocationUid", $"ServiceLocationId".as("ExternalID"))


    val allcols3 = ServiceLocation_Prod_Delta5.columns.toSet
    val insert3 = InsertIntoServiceLocation.columns.toSet
    val tot5 = allcols3 ++ insert3

    val ServiceLocation_Prod_Delta6 = ServiceLocation_Prod_Delta5.select(FunctionUtility.addColumns(allcols3, tot5): _*)
      .union(InsertIntoServiceLocation.select(FunctionUtility.addColumns(insert3, tot5): _*))

    //drop table loc
    //confirm

    //CachePatientNotes as Patientnote

    val UpdateChPatientNotesProcedure17 = ChPatientNotesProcedure.filter($"StatusId" === 1)
      .join(PatientNoteProcedure, Seq("PatientUid", "PracticePatientNoteKey"))
      .select($"ChPatientNotes15.*", $"CachePatientNotes2.PatientNoteProcedureUid".as("AliasPatientNoteProcedureUid"))
      .withColumn("PatientNoteProcedureUid", $"AliasPatientNoteProcedureUid")
      .drop("AliasPatientNoteProcedureUid")

    val whereclause17 = ChPatientNotesProcedure.filter($"StatusId" === 1)
      .join(PatientNoteProcedure, Seq("PatientUid", "PracticePatientNoteKey"))
      .select($"ChPatientNotes15.*")

    val ExceptUpdateChPatientNotesProcedure17 = ChPatientNotesProcedure.except(whereclause17)
    // Updated ChPatientNotesProcedure16 into ChPatientNotesProcedure17
    ChPatientNotesProcedure = UpdateChPatientNotesProcedure17.union(ExceptUpdateChPatientNotesProcedure17)

    var CleanData1 = ChPatientNotesProcedure.dropDuplicates("PatientUid", "PracticePatientNoteKey")
    val DropDuplicates1 = ChPatientNotesProcedure.except(CleanData1)

    //Generating PatientMedicationUId for New Record Having DispensableDrugUid

    val TempPatientNoteProcedure = CleanData1.filter($"StatusId" === 1
      && $"PatientNoteProcedureUid".isNull
      && $"PracticePatientNoteKey".isNotNull)
      .select("PatientUid", "PracticePatientNoteKey").distinct()
      .withColumn("PatientNoteProcedureUid", FunctionUtility.getNewUid())

    val UpdateChPatientNotesProcedure19 = CleanData1.as("df1")
      .join(TempPatientNoteProcedure.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey")
      .select($"df1.*", $"df2.PatientNoteProcedureUid".as("AliasPatientNoteProcedureUid"))
      .withColumn("PatientNoteProcedureUid", $"AliasPatientNoteProcedureUid")
      .drop("AliasPatientNoteProcedureUid")

    val whereclause19 = CleanData1.as("df1")
      .join(TempPatientNoteProcedure.as("df2"), $"df1.PatientUid" === $"df2.PatientUid"
        && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey")
      .select($"df1.*")

    val ExceptUpdateChPatientNotesProcedure19 = CleanData1.except(whereclause19)
    // Updated ChPatientNotesProcedure18 into ChPatientNotesProcedure19
    CleanData1 = UpdateChPatientNotesProcedure19.union(ExceptUpdateChPatientNotesProcedure19)

    //drop table #PatientNoteProcedure
    //confirm

    val UpdatePatientNoteProcedure = CleanData1.filter($"StatusId" === 1).as("df1")
      .join(PatientNoteProcedure.as("df2"), $"df1.PatientNoteProcedureUid" === $"df2.PatientNoteProcedureUid")
      .select($"df2.*", $"df1.Note".as("AliasNote"), $"df1.Group1".as("AliasGroup1"),
        $"df1.Group2".as("AliasGroup2"), $"df1.Group3".as("AliasGroup3"), $"df1.Group4".as("AliasGroup4"),
        $"df1.PracticePatientNoteKey".as("AliasPracticePatientNoteKey"))
      .withColumn("Note", $"AliasNote")
      .withColumn("Group1", $"AliasGroup1")
      .withColumn("Group2", $"AliasGroup2")
      .withColumn("Group3", $"AliasGroup3")
      .withColumn("Group4", $"AliasGroup4")
      .withColumn("PracticePatientNoteKey", $"AliasPracticePatientNoteKey")
      .withColumn("ModifiedDate", lit(current_timestamp))
      .drop("AliasNote", "AliasGroup1", "AliasGroup2", "AliasGroup3", "AliasGroup4", "AliasPracticePatientNoteKey")


    val whereclausePatientNoteProcedure = CleanData1.filter($"StatusId" === 1).as("df1")
      .join(PatientNoteProcedure.as("df2"), $"df1.PatientNoteProcedureUid" === $"df2.PatientNoteProcedureUid")
      .select($"df2.*")

    val ExceptUpdatePatientNoteProcedure = PatientNoteProcedure.except(whereclausePatientNoteProcedure)
    var PatientNoteProcedure_Delta = UpdatePatientNoteProcedure.union(ExceptUpdatePatientNoteProcedure)

    val InsertintoPatientNoteProcedure1 = CleanData1.filter($"StatusId" === 1).as("df1")
      .join(PatientNoteProcedure_Delta.filter($"PatientNoteProcedureUid".isNull).as("df2"),
        $"df1.PatientNoteProcedureUid" === $"df2.PatientNoteProcedureUid", "left")
      .select($"df1.PatientNoteUid", $"df1.PatientUid", $"df1.ClinicalInformationModelSectionUid", $"df1.Note",
        $"df1.EncounterDate".as("ReferenceDate"), $"df1.ServiceProviderUid", $"df1.ServiceLocationUid", $"df1.Group1",
        $"df1.Group2", $"df1.Group3", $"df1.Group4", $"df1.PracticePatientNoteKey")
      .withColumn("CreatedDate", lit(current_timestamp))
      .withColumn("CreatedByUid", lit(null))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ModifiedByUid", lit(null))

    val allcols5 = PatientNoteProcedure_Delta.columns.toSet
    val insert5 = InsertintoPatientNoteProcedure1.columns.toSet
    val tot6 = allcols5 ++ insert5

    PatientNoteProcedure_Delta = PatientNoteProcedure_Delta.select(FunctionUtility.addColumns(allcols5, tot6): _*)
      .union(InsertintoPatientNoteProcedure1.select(FunctionUtility.addColumns(insert5, tot6): _*))


    List(PatientNoteProcedure_Delta,Individual_prod_Delta10,ServiceProvider_prod_Delta9,Institution_Prod_Delta6
    ,ServiceLocation_Prod_Delta6)
  }

}
