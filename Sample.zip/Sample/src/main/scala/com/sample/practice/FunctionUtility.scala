package com.sample.practice

import java.util.UUID
import org.apache.spark.sql.functions._
import org.apache.spark.sql.Column

object FunctionUtility {

  def addColumns(myCols: Set[String], allCols: Set[String]) = {
    allCols.toList.map(x => x match {
      case x if myCols.contains(x) => col(x)
      case _ => lit(null).as(x)
    })
  }


  val getNewUid = udf[String](() => {
    UUID.randomUUID.toString
  })

  def checkColumns(col1 : Column, col2 : Column) : Column  = {
    if (col1.!= ("") && col2.!=(""))
    {
      val col3 =concat_ws("_",col1,col2)
      col3
    }
    else{
      null
    }
  }


  val updateWithJoin = udf[String,String,String]((column1: String, column2: String) => {
    if (column1 == null) column2
    else column1
  })
}
