package com.sample.practice

import org.apache.log4j.{Level, Logger}
object MainClass {

  def main(args: Array[String]): Unit = {

    println("Hello World")

    Logger.getLogger("org").setLevel(Level.WARN)
    Logger.getLogger("akka").setLevel(Level.WARN)

    val SessionObj = new Sessionutility
    val spark = SessionObj.sparkSession()
    val loadTablesObj = new LoadTables
    val listtable = loadTablesObj.readTable(spark)

    val ProviderNPIChangeTable = listtable(0)
    val clinicaldatarepository = listtable(1)
    val ClinicalInformationModelSection = listtable(2)
    val MultiTableExtendTable = listtable(3)
    val MappingPracticeProcedureTable = listtable(4)
    val practice = listtable(5)
    val MappingPracticeProblem = listtable(6)
    val MappingPracticeMedication = listtable(7)
    val MappingPracticeLabResult = listtable(8)
    val PracticeImportDetails = listtable(9)
    val Individual = listtable(10)
    val MergePracticeMap = listtable(11)
    val ViewServiceProvider = listtable(12)
    val MappingPracticeLabResult_Prod = listtable(13)
    val PatientFamilyHistoryDF = listtable(14)
    val PatientImmunizationTable = listtable(15)
    val MappingPracticeProcedure_prod = listtable(16)
    val CDRPatientCrosswalkTable = listtable(17)
    val IndivisualProdTable = listtable(18)
    val PatientTable_prod = listtable(19)
    val PatientNoteMedication_Prod = listtable(20)
    val PatientNoteTable_prod = listtable(21)
    val MasterStatePostalCode_Prod = listtable(22)
    val MasterRelationship_Prod = listtable(23)
    val PatientGuardian_Prod = listtable(24)
    val ViewFacility_Prod = listtable(25)
    val Institution_Prod = listtable(26)
    val ServiceLocation_Prod = listtable(27)
    val Visit_Prod = listtable(28)
    val PatientInsuranceInfo_Prod = listtable(29)
    val MasterCode_Prod = listtable(30)
    val PatientProblem_Prod = listtable(31)
    val PatientProblemHistory_Prod = listtable(32)
    val VisitDiagnosis_Prod = listtable(33)
    val PatientAdvanceDirectiveObservation_Prod = listtable(34)
    val MappingPracticeAllergy_Prod = listtable(35)
    val MasterAllergy_Prod = listtable(36)
    val MasterDispensableDrug_Prod = listtable(37)
    val PatientMedication_Prod = listtable(38)
    val MasterMedicationRoute_Prod = listtable(39)
    val PatientResultObservation_Prod = listtable(40)
    val PatientLanguage_Prod = listtable(41)
    val PatientNoteProblem_Prod = listtable(42)
    val PatientNoteResultObservation_Prod = listtable(43)
    val PatientSocialHistoryObservation_Prod = listtable(44)
    val Individualidentifier_prod = listtable(45)
    val Patient_prod = listtable(46)
    val Individual_prod = listtable(47)
    val ViewServiceProvider_prod = listtable(48)
    val ServiceProvider_prod = listtable(49)
    val MasterGender_Prod = listtable(50)
    val MasterMaritalStatus_prod = listtable(51)
    val MasterCity_prod = listtable(52)
    val MasterPostalCode_prod = listtable(53)
    val MasterCityPostalCode_prod = listtable(54)
    val MasterState_Prod = listtable(55)
    val MasterCountry_Prod = listtable(56)
    val MasterPhoneType_prod = listtable(57)
    val Master_prod = listtable(58)
    val Address_Prod = listtable(59)
    val Phone_Prod = listtable(60)
    val PatientVitalSignObservation_Prod = listtable(61)
    val PatientNoteProcedure = listtable(62)
    val MappingPracticeProcedure_Prod = listtable(63)
    val MappingPracticeMedication_Prod = listtable(64)
    val MappingPracticeCommonData_Prod = listtable(65)
    val MappingPracticeProblem_Prod = listtable(66)
    val MasterEthnicity_Prod = listtable(67)
    val IndividualEthnicity_Prod = listtable(68)
    val MasterRace_Prod = listtable(69)
    val IndividualRace_Prod = listtable(70)
    val distIndUid = listtable(71)
    val distspUID = listtable(72)
    val MappingPracticeCommonData = listtable(73)
    val PatientProcedure_prod = listtable(74)
    val MappingPracticeAllergy = listtable(75)
    val PatientNoteVitalObservation_Prod = listtable(76)


    val loadCrossWalkObj = new LoadCrossWalk
    val listCrosswalk = loadCrossWalkObj.LoadUpdateCrossWalkFunc(spark, clinicaldatarepository, practice
      , MappingPracticeCommonData_Prod, MappingPracticeProblem_Prod, MappingPracticeProblem
      ,MappingPracticeMedication_Prod,MappingPracticeMedication
      ,MappingPracticeProcedure_Prod,MappingPracticeProcedureTable
      ,MappingPracticeLabResult_Prod ,MappingPracticeLabResult,MappingPracticeCommonData
      ,MappingPracticeAllergy,MappingPracticeAllergy_Prod)

    val MappingPracticeCommonData_Delta = listCrosswalk(0)
    val MappingPracticeProblem_Delta = listCrosswalk(1)
    val MappingPracticeMedication_Delta = listCrosswalk(2)
    val MappingPracticeProcedure_Delta = listCrosswalk(3)
    val MappingPracticeLabResult_Delta = listCrosswalk(4)
    val MappingPracticeAllergy_Delta = listCrosswalk(5)

    val CachePatientDemoObj = new CachePatientDemoGraphics
    val listPatientDemo = CachePatientDemoObj.CachePatientDemoFunc(spark,PracticeImportDetails,MultiTableExtendTable,
      Individual,ProviderNPIChangeTable,Individual_prod,Patient_prod,Individualidentifier_prod,ViewServiceProvider_prod,
      distIndUid,distspUID,ServiceProvider_prod, MappingPracticeCommonData_Delta,MasterGender_Prod,MasterMaritalStatus_prod,
      MasterCity_prod,MasterPostalCode_prod, MasterState_Prod,MasterCountry_Prod,MasterPhoneType_prod, Master_prod,
      Address_Prod,Phone_Prod,MasterCityPostalCode_prod)

    /*val Patient_Prod_Delta = listPatientDemo(0)
    val Individual_prod_Delta = listPatientDemo(1)
    val Address_Prod_Delta = listPatientDemo(2)
    val ServiceProvider_prod_Delta = listPatientDemo(3)
    val Individualidentifier_Prod_delta = listPatientDemo(4)

    val cachePatientEthnicityObj = new CachePatientEthnicity
    val listEthnicity = cachePatientEthnicityObj.CachePatientEthnicityFun(spark,Patient_Prod_Delta
      ,Individual_prod_Delta,IndividualEthnicity_Prod,MappingPracticeCommonData_Delta
      ,MergePracticeMap,CDRPatientCrosswalkTable,MasterEthnicity_Prod)

    val IndividualEthnicity_Prod_Delta = listEthnicity(0)

    val cachePatientRaceObj = new CachePatientRace
    val listRace = cachePatientRaceObj.CachePatientRaceFunc(spark,CDRPatientCrosswalkTable
      ,MergePracticeMap,MasterRace_Prod,IndividualRace_Prod,Patient_Prod_Delta
      ,Individual_prod_Delta,MappingPracticeCommonData_Delta)

    val IndividualRace_Prod_Delta = listRace(0)

    val cacheEncounterObj = new CacheEncounter
    val listEncounter = cacheEncounterObj.CacheEncounterFunc(spark,Patient_Prod_Delta,Individual_prod_Delta
      ,Address_Prod_Delta,MappingPracticeCommonData_Delta,MergePracticeMap
      ,ViewServiceProvider,CDRPatientCrosswalkTable,MultiTableExtendTable
      ,Individual,ProviderNPIChangeTable,Institution_Prod
      ,ViewFacility_Prod,distIndUid,distspUID,MasterCity_prod
      ,MasterCityPostalCode_prod,MasterPostalCode_prod
      ,MasterState_Prod,Visit_Prod,Master_prod,ServiceLocation_Prod,ServiceProvider_prod_Delta)

    val Address_Prod_Delta2 = listEncounter(0)
    val Institution_Prod_Delta = listEncounter(1)
    val ServiceLocation_Prod_Delta = listEncounter(2)
    val Visit_Prod_Delta = listEncounter(3)
    val Individual_prod_Delta2 = listEncounter(4)
    val ServiceProvider_Prod_Delta1 = listEncounter(5)

    val CacheInsuranceObj = new CacheInsurance
    val listInsurance = CacheInsuranceObj.CacheInsuranceFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,Patient_Prod_Delta
      ,Individual_prod_Delta2,PatientInsuranceInfo_Prod
      ,MappingPracticeCommonData_Delta,Master_prod)

    val PatientInsuranceInfo_Prod_Delta = listInsurance(0)

    val CacheEncounterDiagObj = new CacheEncounterDiagnosis
    val listEncounterDiag = CacheEncounterDiagObj.CacheEncounterDiagnosisFunc(spark,MergePracticeMap,
      CDRPatientCrosswalkTable, Individual
      ,ProviderNPIChangeTable, MultiTableExtendTable
      ,Master_prod,MasterCode_Prod,ViewFacility_Prod
      ,PatientProblem_Prod,PatientProblemHistory_Prod
      ,VisitDiagnosis_Prod,Patient_Prod_Delta
      ,Individual_prod_Delta2,ServiceProvider_Prod_Delta1
      ,MappingPracticeProblem_Delta,Visit_Prod_Delta
      ,MappingPracticeCommonData_Delta)

    val PatientProblemHistory_Prod_Delta = listEncounterDiag(0)
    val VisitDiagnosis_Prod_Delta = listEncounterDiag(1)

    val CacheProblemObj = new CacheProblem
    val listProblem = CacheProblemObj.CacheProblemFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,MasterCode_Prod
      ,PatientProblem_Prod,Master_prod
      ,Patient_Prod_Delta,Individual_prod_Delta2
      ,MappingPracticeProblem_Delta,PatientProblemHistory_Prod_Delta
      ,MappingPracticeCommonData_Delta)

    val PatientProblemHistory_Prod_Delta2 = listProblem(0)

    val cacheProcedureObj = new CacheProcedure
    val listProcedure = cacheProcedureObj.CacheProcedureFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,MultiTableExtendTable
      ,ProviderNPIChangeTable,Individual,distIndUid,distspUID,ViewServiceProvider_prod
      ,ViewFacility_Prod,PatientProcedure_prod,MasterCode_Prod
      ,Patient_Prod_Delta,Individual_prod_Delta2
      ,ServiceProvider_Prod_Delta1,MappingPracticeCommonData_Delta
      ,MappingPracticeProcedure_Delta,Institution_Prod_Delta,ServiceLocation_Prod_Delta)

    val PatientProcedure_prod_Delta = listProcedure(0)
    val Individual_prod_Delta3 = listProcedure(1)
    val ServiceProvider_prod_Delta2 = listProcedure(2)
    val Institution_Prod_Delta2 = listProcedure(3)
    val ServiceLocation_Prod_Delta2 = listProcedure(4)

    val cacheAdvanceDirectiveObj = new CacheAdvanceDirective
    val listAdvDorective = cacheAdvanceDirectiveObj.CacheAdvanceDirectiveFunc(spark,MergePracticeMap,
      CDRPatientCrosswalkTable,Master_prod,
      PatientAdvanceDirectiveObservation_Prod,MappingPracticeCommonData_Delta
     ,Patient_Prod_Delta,Individual_prod_Delta3)

    val PatientAdvanceDirectiveObservation_Prod_Delta = listAdvDorective(0)

    val cacheAllergiesObj = new CacheAllergies
    val listAllergies = cacheAllergiesObj.CacheAllergiesFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,Master_prod
      ,MasterAllergy_Prod,Patient_Prod_Delta,Individual_prod_Delta3
      ,MappingPracticeCommonData_Delta,MappingPracticeAllergy_Delta)

    val MasterAllergy_Prod_Delta = listAllergies(0)

    val cacheMedicationsObj = new CacheMedications
    val listMedication = cacheMedicationsObj.CacheMedicationsFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,MultiTableExtendTable
      ,Individual,ProviderNPIChangeTable
      ,MasterDispensableDrug_Prod,distIndUid
      ,distspUID,PatientMedication_Prod
      ,Master_prod,MasterCode_Prod
      ,MasterMedicationRoute_Prod,MappingPracticeMedication_Delta
      ,Patient_Prod_Delta,Individual_prod_Delta3
      ,ServiceProvider_prod_Delta2,MappingPracticeCommonData_Delta
      ,MappingPracticeProcedure_Delta,MappingPracticeProblem_Delta)


    val PatientMedication_Prod_Delta = listMedication(0)
    val Individual_prod_Delta4 = listMedication(1)
    val ServiceProvider_prod_Delta3 = listMedication(2)

    val cacheImmunizationObj = new CacheImmunization
    val listImmunization = cacheImmunizationObj.ImmunizationFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,MultiTableExtendTable
      ,Master_prod,distIndUid
      ,distspUID,ViewFacility_Prod
      ,PatientImmunizationTable,MasterMedicationRoute_Prod
      ,MasterCode_Prod
      ,Patient_Prod_Delta,Individual_prod_Delta4
      ,ViewServiceProvider_prod,MappingPracticeCommonData_Delta
      ,MappingPracticeProcedure_Delta,MappingPracticeProblem_Delta
        ,ServiceProvider_prod_Delta3)

    val PatientImmunizationTable_Delta = listImmunization(0)
    val Individual_prod_Delta5 = listImmunization(1)
    val ServiceProvider_prod_Delta4 = listImmunization(2)

    val cachePlanOfCareObj = new CachePlanOfCare
    val listPlan = cachePlanOfCareObj.CachePlanOfCareFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,Master_prod
      ,Patient_Prod_Delta,Individual_prod_Delta5,MappingPracticeCommonData_Delta,PatientProblem_Prod)

    val PatientProblem_Prod_Delta = listPlan(0)

    val cacheResultObj = new CacheResultObservation
    val listResult  = cacheResultObj.CacheResultObservationFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,MasterCode_Prod,MultiTableExtendTable
      ,Individual,ProviderNPIChangeTable,ViewServiceProvider_prod
      ,distIndUid,distspUID,Master_prod
      ,MappingPracticeLabResult_Delta,Patient_Prod_Delta,Individual_prod_Delta5
      ,ServiceProvider_prod_Delta4,PatientResultObservation_Prod,MappingPracticeCommonData_Delta
      ,MappingPracticeProcedure_Delta)

    val PatientResultObservation_Prod_Delta = listResult(0)
    val Individual_prod_Delta6 = listResult(1)
    val ServiceProvider_prod_Delta5  = listResult(2)

    val CacheSocialObj = new CacheSocialHistory
    val listSocial = CacheSocialObj.CacheSocialHistoryFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,Master_prod,Patient_Prod_Delta,Individual_prod_Delta6
      ,MappingPracticeCommonData_Delta,PatientSocialHistoryObservation_Prod)

    val PatientSocialHistoryObservation_Prod_Delta = listSocial(0)

    val CacheVitalSignObj = new ImportVitalSignsData
    val listVital = CacheVitalSignObj.ImportVitalSignsDataFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable
      ,Master_prod
      ,MasterCode_Prod
      ,MappingPracticeCommonData_Delta
      ,Patient_Prod_Delta
      ,Individual_prod_Delta6
      ,PatientVitalSignObservation_Prod)

    val PatientVitalSignObservation_Prod_Delta = listVital(0)

    val CacheFamilyHistoryObj = new PatientFamilyHistory
    val listFamHist = CacheFamilyHistoryObj.PatientFamilyHistoryFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,MasterGender_Prod,MasterRelationship_Prod,MasterCode_Prod
      ,Master_prod,MappingPracticeCommonData_Delta,Patient_Prod_Delta,Individual_prod_Delta6,PatientFamilyHistoryDF
    ,MappingPracticeProblem_Delta)

    val PatientFamilyHistory_Prod_Delta = listFamHist(0)


    val cachePatientGuardianObj = new CachePatientGuardian
    val listGuardian = cachePatientGuardianObj.CachePatientGuardianFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,PatientGuardian_Prod,MasterCity_prod,MasterPostalCode_prod
      ,MasterCityPostalCode_prod,MasterStatePostalCode_Prod,MasterRelationship_Prod,Patient_Prod_Delta
      ,Individual_prod_Delta6,MappingPracticeCommonData_Delta,Address_Prod_Delta2,Phone_Prod
      ,PatientProblem_Prod_Delta,MasterPhoneType_prod)

    val PatientGuardian_Prod_Delta = listGuardian(0)
    val Address_Prod_Delta3 = listGuardian(0)
    val Phone_Prod_Delta = listGuardian(2)

    val CachePatientLangObj = new PatientLanguageData
    val listLang = CachePatientLangObj.PatientLanguageDataFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,Master_prod,PatientLanguage_Prod,MappingPracticeCommonData_Delta
      ,Patient_Prod_Delta,Individual_prod_Delta6)

    val PatientLanguage_Prod_Delta = listLang(0)

    val cachePatientNoteObj = new CachePatientNoteData
    val listNotes  = cachePatientNoteObj.CachePatientNoteDataFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,ClinicalInformationModelSection,MultiTableExtendTable,ProviderNPIChangeTable
      ,Individual,distIndUid,distspUID,PatientNoteTable_prod,Patient_Prod_Delta,Individual_prod_Delta6
      ,ViewServiceProvider_prod,ViewFacility_Prod,ServiceProvider_prod_Delta5,Institution_Prod_Delta2
      ,ServiceLocation_Prod_Delta2)

    val PatientNoteTable_prod_Delta = listNotes(0)
    val Individual_prod_Delta7 = listNotes(1)
    val ServiceProvider_prod_Delta6 = listNotes(2)
    val Institution_Prod_Delta3 = listNotes(3)
    val ServiceLocation_Prod_Delta3 = listNotes(4)

    val cachePatientNotesMedicationObj  = new CachePatientNotesMedication
    val listpatientNoteMedication = cachePatientNotesMedicationObj.CachePatientNotesMedicationFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,ClinicalInformationModelSection,MultiTableExtendTable
      ,Individual,ProviderNPIChangeTable,PatientNoteMedication_Prod,Patient_Prod_Delta,Individual_prod_Delta7
      ,ViewServiceProvider_prod,ViewFacility_Prod,ServiceProvider_prod_Delta6,Institution_Prod_Delta3
      ,ServiceLocation_Prod_Delta3,distIndUid,distspUID)


    val PatientNoteMedication_Prod_Delta = listpatientNoteMedication(0)
    val Individual_prod_Delta8 = listpatientNoteMedication(1)
    val ServiceProvider_prod_Delta7 = listpatientNoteMedication(2)
    val Institution_Prod_Delta4 = listpatientNoteMedication(3)
    val ServiceLocation_Prod_Delta4 = listpatientNoteMedication(4)

    val cachePatNoteProbObj = new CachePatientNotesProblem
    val listPatNoteProb = cachePatNoteProbObj.CachePatientNotesProblemFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,ClinicalInformationModelSection,MultiTableExtendTable
      ,Individual,ProviderNPIChangeTable,distIndUid,distspUID,Patient_Prod_Delta,Individual_prod_Delta8
      ,ViewServiceProvider_prod,ViewFacility_Prod,ServiceProvider_prod_Delta7,Institution_Prod_Delta4
      ,ServiceLocation_Prod_Delta4,PatientNoteProblem_Prod)

    val PatientNoteProblem_Prod_Delta = listPatNoteProb(0)
    val Individual_prod_Delta9 = listPatNoteProb(1)
    val ServiceProvider_prod_Delta8 = listPatNoteProb(2)
    val Institution_Prod_Delta5 = listPatNoteProb(3)
    val ServiceLocation_Prod_Delta5 = listPatNoteProb(4)

    val cachePatNoteprocedureObj  = new CachePatientNotesProcedure
    val listPatNoteprocedureObj = cachePatNoteprocedureObj.PatientNotesProcedureFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,ClinicalInformationModelSection,MultiTableExtendTable,ProviderNPIChangeTable,Individual
      ,ViewServiceProvider_prod,ViewFacility_Prod,distIndUid,distspUID,Patient_Prod_Delta,Individual_prod_Delta9
      ,ServiceProvider_prod_Delta8,Institution_Prod_Delta5,ServiceLocation_Prod_Delta5,PatientNoteProcedure)

    val PatientNoteProcedure_Delta = listPatNoteprocedureObj(0)
    val Individual_prod_Delta10 = listPatNoteprocedureObj(1)
    val ServiceProvider_prod_Delta9 = listPatNoteprocedureObj(2)
    val Institution_Prod_Delta6 = listPatNoteprocedureObj(3)
    val ServiceLocation_Prod_Delta6 = listPatNoteprocedureObj(4)

    val cachePatientNotesResultObservationObj = new CachePatientNotesResultObservation
    val  listCPNRObs = cachePatientNotesResultObservationObj.CachePatientNotesResultObservationFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,ClinicalInformationModelSection,MultiTableExtendTable,Individual,ProviderNPIChangeTable
      ,ViewServiceProvider_prod,ViewFacility_Prod,distIndUid,distspUID,Patient_Prod_Delta,Individual_prod_Delta10
      ,ServiceProvider_prod_Delta9,Institution_Prod_Delta6,ServiceLocation_Prod_Delta6,PatientNoteResultObservation_Prod)

    val PatientNoteResultObservation_Prod_Delta = listCPNRObs(0)
    val Individual_prod_Delta11 = listCPNRObs(1)
    val ServiceProvider_prod_Delta10 = listCPNRObs(2)
    val Institution_Prod_Delta7 = listCPNRObs(3)
    val ServiceLocation_Prod_Delta7 = listCPNRObs(4)

    val CachePatientNotesVitalObsObj = new CachePatientNotesVitalObservation
    val listPNVObs = CachePatientNotesVitalObsObj.CachePatientNotesVitalObservationFunc(spark,MergePracticeMap
      ,CDRPatientCrosswalkTable,ClinicalInformationModelSection,MultiTableExtendTable,Individual
      ,ProviderNPIChangeTable,ViewServiceProvider_prod,ViewFacility_Prod,distIndUid,distspUID
      ,Patient_Prod_Delta,Individual_prod_Delta11,ServiceProvider_prod_Delta10,Institution_Prod_Delta7
      ,ServiceLocation_Prod_Delta7,PatientNoteVitalObservation_Prod)

*/


  }

}
