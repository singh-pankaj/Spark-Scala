package com.sample.practice

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

class CachePatientDemoGraphics {

  def CachePatientDemoFunc(spark : SparkSession,
                           PracticeImportDetails : DataFrame,MultiTableExtendTable : DataFrame,
                           Individual : DataFrame,ProviderNPIChangeTable : DataFrame,Individual_prod : DataFrame
                           ,Patient_prod :DataFrame,Individualidentifier_prod : DataFrame,ViewServiceProvider_prod : DataFrame
                           , distIndUid : DataFrame,distspUID : DataFrame,ServiceProvider_prod : DataFrame
                           , MappingPracticeCommonData_Delta : DataFrame,MasterGender_Prod : DataFrame
                           ,MasterMaritalStatus_prod : DataFrame, MasterCity_prod : DataFrame,MasterPostalCode_prod : DataFrame
                           , MasterState_Prod : DataFrame,MasterCountry_Prod : DataFrame,MasterPhoneType_prod : DataFrame
                           , Master_prod : DataFrame,Address_Prod : DataFrame,Phone_Prod : DataFrame
                          ,MasterCityPostalCode_prod : DataFrame): List[DataFrame] ={

    import spark.implicits._

    spark.conf.set("spark.sql.crossJoin.enabled", "true")

    val logger = LoggerFactory.getLogger("")

   /*val cacheFile = spark.read.option("delimiter", "\u0017")
      .csv("s3n://bd-dev/aao_test/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/edea6658-b815-466d-aeea-17a9dd575dd1_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")
*/
    val cacheFile = spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/edea6658-b815-466d-aeea-17a9dd575dd1_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")

    val lookup = Map("_c0" -> "PatientId", "_c1" -> "LastName", "_c2" -> "FirstName", "_c3" -> "MiddleName", "_c4" -> "StreetLineAddress1"
      , "_c5" -> "StreetLineAddress2", "_c6" -> "StreetLineAddress3", "_c7" -> "StreetLineAddress4", "_c8" -> "City", "_c9" -> "StateCode"
      , "_c10" -> "State", "_c11" -> "ZipCode", "_c12" -> "CountryCode", "_c13" -> "Country", "_c14" -> "TelecomTypeText1"
      , "_c15" -> "TelecomValue1", "_c16" -> "TelecomTypeText2", "_c17" -> "TelecomValue2", "_c18" -> "Gender", "_c19" -> "DOB"
      , "_c20" -> "DeathDate", "_c21" -> "MaritalStatusCode", "_c22" -> "MaritalStatusText", "_c23" -> "ReligiousAffiliationCode"
      , "_c24" -> "ReligiousAffiliationText", "_c25" -> "BirthStateCode", "_c26" -> "BirthState", "_c27" -> "BirthZipCode"
      , "_c28" -> "BirthCountryCode", "_c29" -> "BirthCountry", "_c30" -> "ServiceProviderNPI", "_c31" -> "ServiceProviderLastName"
      , "_c32" -> "ServiceProviderFirstName", "_c33" -> "SSN", "_c34" -> "DeathReason", "_c35" -> "IsDeceased", "_c36" -> "Patient_EMR_ID"
      , "_c37" -> "EmailID", "_c38" -> "LocationOfDeath", "_c39" -> "BirthOrder", "_c40" -> "MultipleBirthPlaceIndicator"
      , "_c41" -> "PatientDemographicsKey", "_c42" -> "PracticeUid", "_c43" -> "BatchUid", "_c44" -> "dummy1", "_c45" -> "dummy2")

    var CachepatientDemo = cacheFile.select(cacheFile.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*) .drop("dummy1", "dummy2")

    /*val tempCachedemo = spark.read.option("header", "true").csv("s3n://bd-dev/aao_test/Schema/CDRSchema.txt")*/
    val tempCachedemo = spark.read.option("header", "true").csv("/home/gajanan.doifode/AAO_DATA/Schema/CDRSchema.txt")

    val allcols = tempCachedemo.columns.toSet
    val viewcols = CachepatientDemo.columns.toSet
    val total = allcols ++ viewcols

    println("Files are reading")

    CachepatientDemo = tempCachedemo.select(FunctionUtility.addColumns(allcols, total): _*)
      .union(CachepatientDemo.select(FunctionUtility.addColumns(viewcols, total): _*))

    CachepatientDemo = CachepatientDemo.withColumn("PracticeUid", upper($"PracticeUid"))
      .withColumn("ServiceProviderNPI", lit("1053428771"))

    CachepatientDemo = CachepatientDemo.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    CachepatientDemo.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/CachepatientDemo.csv")

    val temp_prac1 = CachepatientDemo.withColumn("PracticeUid", upper($"PracticeUid"))
      .select($"PracticeUid").distinct()

    //ImportPatientData

    logger.warn("Start ImportPatientData ..........")
    println("Start ImportPatientData ..........")

    //Create CachePractice table
    val cachepractice = PracticeImportDetails.as("df1")
      .join(temp_prac1.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.PracticeUid".isin($"df2.PracticeUid"))
      .select($"df1.*")

    //Add StatusId = 1
    val CachepatientDemo1 = CachepatientDemo.withColumn("StatusID", lit(1))
      .withColumn("ModifiedDate", lit("null"))
      .withColumn("ErrorNote", lit("null"))

    println("Added StatusId = 1 is Done............")

    //Update oldPracticeuid Column and Other Imp columns
    val CachepatientDemo2 = CachepatientDemo1.as("df1")
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PracticeSideNPI", $"df1.ServiceProviderNPI")
      .withColumn("FirstName", rtrim(ltrim($"df1.FirstName")))
      .withColumn("LastName", rtrim(ltrim($"df1.LastName")))
      .withColumn("Gender", rtrim(ltrim($"df1.Gender")))
      .withColumn("PatientId", rtrim(ltrim($"df1.PatientId")))
      .withColumn("ServiceProviderNPI", rtrim(ltrim($"df1.ServiceProviderNPI")))

    logger.warn("Update oldPracticeuid Column and Other Imp columns............")
    println("Update oldPracticeuid Column and Other Imp columns............")

    //Find Practiceuid null then update StatusId = 3
    val updateStatus = CachepatientDemo2.as("df1").filter( $"PracticeUid".isNull && $"PatientId".isNull)
      .withColumn("StatusID", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PracticeUid is Null OR Patient Not Found "))

    val where1 = CachepatientDemo2.as("df1").filter( $"PracticeUid".isNull && $"PatientId".isNull)

    val CachepatientDemo3 = CachepatientDemo2.except(where1)
    println("Find Practiceuid null then update StatusId = 3 is Done............")

    val updatespNPI_Demo = CachepatientDemo3.as("df1")
      .join(MultiTableExtendTable.as("df2"),
        $"df1.PracticeUid" === "df2.PracticeUid" &&  $"df1.ServiceProviderNPI" === $"df2.Element1"
        && $"df2.GroupName" === "ProviderNPI", "left_outer")
      .select($"df1.*", $"df2.Value".as("AliasValue"))
      .withColumn("ServiceProviderNPI",FunctionUtility.updateWithJoin($"ServiceProviderNPI",$"AliasValue"))
      .drop($"AliasValue")

    println("Update ServiceProviderNPI is Done............")

    val updatespNPI2_Demo = updatespNPI_Demo.as("df3")
      .join(Individual.as("df1"),$"df3.PracticeUid" === $"df1.PracticeUid","left_outer")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid"
        && $"df3.ServiceProviderNPI" === $"df2.OldNPI","left_outer")
      .select($"df3.*", $"df2.NewNPI".as("AliasNewNPI"))
      .withColumn("ServiceProviderNPI",FunctionUtility.updateWithJoin($"ServiceProviderNPI",$"AliasNewNPI"))
      .drop($"AliasNewNPI")

    println("Update ServiceProviderNPI with difference condition is Done............")

    //Update StatusId = 3 if ServiceProviderNPI length is less than 10
    val updateStatusNPI = updatespNPI2_Demo.filter(length($"ServiceProviderNPI") =!= 10 && $"DOB".isNull)
      .withColumn("StatusID", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid NPI Found,Length should be 10 OR Patient Birth Date Not Found"))

    var AllStatusvalue  = updateStatus.union(updateStatusNPI)
    val where2 = updatespNPI2_Demo.filter(length($"ServiceProviderNPI") =!= 10 && $"DOB".isNull)
    val cleanedDemo1 = updatespNPI2_Demo.except(where2)

    logger.warn("Update StatusId = 3 if DOB not found is Done............")
    println("Update StatusId = 3 if DOB not found is Done............")

    //Drop Duplicate records and store in in-memory not update status = 4
    val duplicates =  cleanedDemo1.withColumn("rank", row_number().over(Window.partitionBy($"PatientId",$"PracticeUid").orderBy($"PatientId".asc)))
      .filter("rank > 1")
      .withColumn("StatusID",lit(4))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote",lit("Duplicate Record"))
      .drop("rank")

    AllStatusvalue = AllStatusvalue.union(duplicates)
    println("Drop Duplicate records and store in in-memory not update status = 4 is Done............")

    //Different MRN Found For Same FirstName,LastName,dob,SSN,PracticeUid with SSN
    val dup = cleanedDemo1.filter($"SSN".isNotNull)
      .select("FirstName", "LastName", "DOB", "PracticeUid", "SSN", "PatientId").distinct()

    val finddiffMRN = cleanedDemo1.as("df1").join(dup.as("df2"),
      $"df1.FirstName" === $"df2.FirstName" &&
        $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df1.LastName" === $"df2.LastName" &&
        $"df1.SSN" === $"df2.SSN" &&
        $"df1.PatientId" =!= $"df2.PatientId")
      .join(cachepractice.as("df3")
        , $"df1.PracticeUid" === $"df3.PracticeUid" && $"df3.IsDuplicatePatient" === 0)
      .select($"df1.*")
      .withColumn("StatusID", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Different MRN Found For Same FirstName,LastName,dob,SSN,PracticeUid"))

    val finddiff1 = cleanedDemo1.as("df1").join(dup.as("df2"),
      $"df1.FirstName" === $"df2.FirstName" &&
        $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df1.LastName" === $"df2.LastName" &&
        $"df1.SSN" === $"df2.SSN" &&
        $"df1.PatientId" =!= $"df2.PatientId")
      .join(cachepractice.filter($"IsDuplicatePatient" === 0).as("df3")
        , $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*")

    AllStatusvalue = AllStatusvalue.union(finddiffMRN)

    val k1 = cleanedDemo1.rdd
    val m1 = finddiff1.rdd
    val sub1 = k1.subtract(m1)
    val cleanedDemo2 = spark.createDataFrame(sub1,StructType(Schema_CDR.someSchema))

    println("Different MRN Found For Same FirstName,LastName,dob,SSN,PracticeUid with SSN")
    //Different MRN Found For Same FirstName,LastName,dob,SSN,PracticeUid without SSN
    cleanedDemo2.persist()

    val dup2 = cleanedDemo2.filter($"SSN".isNull)
      .select("FirstName", "LastName", "DOB", "PracticeUid", "PatientId").distinct()

    val finddiffMRN2 = cleanedDemo2.as("df1").join(dup2.as("df2"),
      $"df1.FirstName" === $"df2.FirstName" &&
        $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df1.LastName" === $"df2.LastName" &&
        $"df1.DOB" === $"df2.DOB" &&
        $"df1.PatientId" =!= $"df2.PatientId")
      .join(cachepractice.as("df3")
        , $"df1.PracticeUid" === $"df3.PracticeUid" && $"df3.IsDuplicatePatient" === 0)
      .select($"df1.*")
      .withColumn("StatusID", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Different MRN Found For Same FirstName,LastName,dob,PracticeUid"))


    val finddiffMRN123 = cleanedDemo2.as("df1").join(dup2.as("df2"),
      $"df1.FirstName" === $"df2.FirstName" &&
        $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df1.LastName" === $"df2.LastName" &&
        $"df1.DOB" === $"df2.DOB" &&
        $"df1.PatientId" =!= $"df2.PatientId")
      .join(cachepractice.as("df3")
        , $"df1.PracticeUid" === $"df3.PracticeUid" && $"df3.IsDuplicatePatient" === 0)
      .select($"df1.*")

    AllStatusvalue = AllStatusvalue.union(finddiffMRN2)
    val k2 = cleanedDemo2.rdd
    val m2 = finddiffMRN123.rdd
    val sub2 = k2.subtract(m2)
    val cleanedDemo3 = spark.createDataFrame(sub2,StructType(Schema_CDR.someSchema))

    cleanedDemo2.unpersist()

    logger.warn("Different MRN Found For Same FirstName,LastName,dob,SSN,PracticeUid without SSN is Done............")
    println("Different MRN Found For Same FirstName,LastName,dob,SSN,PracticeUid without SSN is Done............")

    cleanedDemo3.persist()

    val updateexistmrn = cleanedDemo3.as("df1")
      .join(Individual_prod.as("df2")
        , $"df1.FirstName" === $"df2.First" &&
          $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df1.DOB" === $"df2.BirthDate" &&
          $"df1.LastName" === $"df2.Last")
      .join(Patient_prod.as("df3")
        , $"df3.PatientUid" === $"df2.IndividualUid")
      .join(Individualidentifier_prod.as("df4")
        , $"df1.SSN" === $"df4.Identifier" &&
          $"df4.IndividualUid" === $"df1.PatientUid") //Doubt
      .join(cachepractice.as("df5")
      , $"df5.PracticeUid" === $"df1.PracticeUid" && $"df5.IsDuplicatePatient" === 0)
      .where($"df3.MedicalRecordNumber" =!= $"df1.PatientId")
      .select($"df1.*")
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Already Exists With Different MedicalRecordNumber"))

    val whereexistmrn = cleanedDemo3.as("df1")
      .join(Individual_prod.as("df2")
        , $"df1.FirstName" === $"df2.First" &&
          $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df1.DOB" === $"df2.BirthDate" &&
          $"df1.LastName" === $"df2.Last")
      .join(Patient_prod.as("df3")
        , $"df3.PatientUid" === $"df2.IndividualUid")
      .join(Individualidentifier_prod.as("df4")
        , $"df1.SSN" === $"df4.Identifier" &&
          $"df4.IndividualUid" === $"df1.PatientUid") //Doubt
      .join(cachepractice.as("df5")
      , $"df5.PracticeUid" === $"df1.PracticeUid" && $"df5.IsDuplicatePatient" === 0)
      .where($"df3.MedicalRecordNumber" =!= $"df1.PatientId")
      .select($"df1.*")

    AllStatusvalue = AllStatusvalue.union(updateexistmrn)
    val cleanedDemo4 = cleanedDemo3.except(whereexistmrn)
    logger.warn("Patient Already Exists With Different MedicalRecordNumber is Done............")
    println("Patient Already Exists With Different MedicalRecordNumber is Done............")

    cleanedDemo3.unpersist()

    //Update Patient Details From MedicalRecordNumber

    val cleanedDemo51 = cleanedDemo4.as("df1")
      .join(Patient_prod.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod.as("df3"), $"df3.IndividualUid" === $"df2.PatientUid"
        && $"df3.PracticeUid" === $"df1.PracticeUid")
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"), $"df2.BirthPlaceUid".as("aliasBirthPlaceUid"),
        $"df3.Address1Uid".as("aliasAddress1Uid"), $"df3.Phone1Uid".as("aliasPhone1Uid")
        , $"df3.Phone2Uid".as("aliasPhone2Uid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .withColumn("AddressUid", $"aliasAddress1Uid")
      .withColumn("Phone1Uid", $"aliasPhone1Uid")
      .withColumn("Phone2Uid", $"aliasPhone2Uid")
      .withColumn("BirthPlaceUid", $"aliasBirthPlaceUid")
      .drop("aliasPatientUid", "aliasAddress1Uid", "aliasPhone1Uid", "aliasPhone2Uid", "aliasBirthPlaceUid")

    val where = cleanedDemo4.as("df1")
      .join(Patient_prod.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod.as("df3"), $"df3.IndividualUid" === $"df2.PatientUid"
        && $"df3.PracticeUid" === $"df1.PracticeUid")
      .select($"df1.*")

    val except = cleanedDemo4.except(where)
    val cleanedDemo5 = except.union(cleanedDemo51)

    println("Update Patient Details From MedicalRecordNumber is Done............")
    logger.warn("Update Patient Details From MedicalRecordNumber is Done............")

    val cleanedDemo6 = cleanedDemo5.as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid","left_outer")
      .select($"df1.*", $"df2.ServiceProviderUid".as("aliasServiceProviderUid"))
      .withColumn("ServiceProviderUid",FunctionUtility.updateWithJoin($"ServiceProviderUid",$"aliasServiceProviderUid"))
      .drop("aliasServiceProviderUid")

    println("update ServiceProvider Details From ServiceProviderNPI is Done............")
    cleanedDemo3.unpersist()
    cleanedDemo6.persist()
    //cleanedDemo6.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/cleanedDemo6.csv")

    //Generate ServiceProviderUid (#phy = newServiceProvider)
    var newServiceProvider = cleanedDemo6.where($"ServiceProviderNPI".isNotNull)
      .select("ServiceProviderNPI", "ServiceProviderFirstName", "ServiceProviderLastName", "PracticeUid")
      .groupBy($"ServiceProviderNPI", $"PracticeUid")
      .agg(max("ServiceProviderFirstName").as("ServiceProviderFirstName")
        , max("ServiceProviderLastName").as("ServiceProviderLastName"))
      .withColumn("Physician_MidName", lit("null"))

    println("create Table #phy Table")

    newServiceProvider = cleanedDemo6.filter($"ServiceProviderUid".isNull).as("df1")
      .join(newServiceProvider.as("df2")
        , $"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI")
      .select($"df2.*")
      .withColumn("ServiceProviderUid", FunctionUtility.getNewUid())

    logger.warn("Generate ServiceProviderUid (#phy = newServiceProvider) is Done............")
    println("Generate ServiceProviderUid (#phy = newServiceProvider) is Done............")

    //Update ServiceProviderUid
    val cleanedDemo7 = cleanedDemo6.as("df1")
      .join(newServiceProvider.as("df2"), $"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" &&
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ServiceProviderUid".isNull,"left_outer")
      .select($"df1.*", $"df2.ServiceProviderUid".as("aliasServiceProviderUid"))
      .withColumn("ServiceProviderUid",FunctionUtility.updateWithJoin($"ServiceProviderUid",$"aliasServiceProviderUid"))
      .drop("aliasServiceProviderUid")

    println("Update ServiceProviderUid using newServiceProvider table")

   // cleanedDemo7.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/cleanedDemo7.csv")

    //Insert Data into Individual table
    println("Individual_prod count :..." + Individual_prod.count())
    val insertIndividual = newServiceProvider.as("df1")
      .join(distIndUid.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.IndividualUid"),"left_outer")
      .select($"df1.ServiceProviderUid".as("IndividualUid"), $"df1.ServiceProviderFirstName".as("First")
        , $"df1.Physician_MidName".as("Middle"), $"ServiceProviderLastName".as("Last"),
        $"df1.PracticeUid".as("PracticeUid")).distinct()

    val indicols = Individual_prod.columns.toSet
    val insertIndividualcols = insertIndividual.columns.toSet
    val tot = indicols ++ insertIndividualcols

    var Individual_prod1 = Individual_prod.select(FunctionUtility.addColumns(indicols, tot): _*)
      .union(insertIndividual.select(FunctionUtility.addColumns(insertIndividualcols, tot): _*))

    Individual_prod1  = Individual_prod1.withColumn("Photo", $"Photo".cast(StringType))

    println("Insert Data into Individual table is Done............")

    println("ServiceProvider_prod count :..." + ServiceProvider_prod.count())
    val insertdataServiceProv = newServiceProvider.as("df1")
      .join(distspUID.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.ServiceProviderUid"))
      .withColumn("ListName", when($"df1.Physician_MidName".isNotNull, concat_ws(" "
        , $"ServiceProviderLastName", $"ServiceProviderFirstName", $"Physician_MidName"))
        .otherwise(concat_ws(" ", $"ServiceProviderLastName", $"ServiceProviderFirstName")))
      .select($"df1.ServiceProviderUid", $"ListName", $"df1.ServiceProviderNPI".as("NPI"))
      .withColumn("ExternalID", lit(null))
      .withColumn("Type", lit(4))

    val servicePcols = ServiceProvider_prod.columns.toSet
    val insertdataServiceProvcols = insertdataServiceProv.columns.toSet
    val tot1 = servicePcols ++ insertdataServiceProvcols

    var ServiceProvider_prod1 = ServiceProvider_prod.select(FunctionUtility.addColumns(servicePcols, tot1): _*)
      .union(insertdataServiceProv.select(FunctionUtility.addColumns(insertdataServiceProvcols, tot1): _*))

    println("Insert Data into ServiceProvider is Done............")

    //Generating AddressUid
    val tempPataddressUid = cleanedDemo7.filter($"PatientUid".isNotNull &&
      $"AddressUid".isNull && rtrim(ltrim($"StreetLineAddress1")).isNotNull &&
      rtrim(ltrim($"StreetLineAddress2")).isNotNull && rtrim(ltrim($"StreetLineAddress3")).isNotNull &&
      rtrim(ltrim($"StreetLineAddress4")).isNotNull && rtrim(ltrim($"ZipCode")).isNotNull && rtrim(ltrim($"City")).isNotNull)
      .select("PatientId", "PracticeUid", "PatientUid")
      .withColumn("AddressUid", FunctionUtility.getNewUid())
      .withColumn("BirthPlaceUid",FunctionUtility.getNewUid())
      .withColumn("Phone1Uid", FunctionUtility.getNewUid())
      .withColumn("Phone2Uid",FunctionUtility.getNewUid())

    //tempPataddressUid.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/tempPataddressUid.csv")
    println("create table tempPataddressUid........................")

    val cleanedDemo8 = cleanedDemo7.as("df1")
      .join(tempPataddressUid.as("df2")
        , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df2.PracticeUid","left_outer")
      .select($"df1.*", $"df2.AddressUid".as("aliasAddressUid"), $"df2.BirthPlaceUid".as("aliasBirthPlaceUid")
        , $"df2.Phone1Uid".as("aliasPhone1Uid"), $"df2.Phone2Uid".as("aliasPhone2Uid"))
      .withColumn("AddressUid",FunctionUtility.updateWithJoin($"AddressUid",$"aliasAddressUid"))
      .withColumn("BirthPlaceUid",FunctionUtility.updateWithJoin($"BirthPlaceUid",$"aliasBirthPlaceUid"))
      .withColumn("Phone1Uid",when($"TelecomValue1".isNotNull,FunctionUtility.updateWithJoin($"Phone1Uid",$"aliasPhone1Uid")).otherwise(null))
      .withColumn("Phone2Uid",when($"TelecomValue2".isNotNull,FunctionUtility.updateWithJoin($"Phone2Uid",$"aliasPhone2Uid")).otherwise(null))
      .drop("aliasAddressUid", "aliasBirthPlaceUid", "aliasPhone1Uid", "aliasPhone2Uid")

   // cleanedDemo8.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/cleanedDemo8.csv")
    println("Generate Uid's Uisng table tempPataddressUid")

    //Generating New PatientUid from PatientId,PracticeUid for New Patient
    val tempPatUid = cleanedDemo8.filter($"PatientUid".isNull)
      .select("PatientId", "PracticeUid").distinct()
      .withColumn("PatientUid", FunctionUtility.getNewUid())
      .withColumn("AddressUid", FunctionUtility.getNewUid())
      .withColumn("BirthPlaceUid", FunctionUtility.getNewUid())
      .withColumn("Phone1Uid", FunctionUtility.getNewUid())
      .withColumn("Phone2Uid", FunctionUtility.getNewUid())

    //tempPatUid.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/tempPatUid.csv")

    val cleanedDemo9 = cleanedDemo8.as("df1").join(tempPatUid.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df2.PracticeUid","left_outer")
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"), $"df2.AddressUid".as("aliasAddressUid"), $"df2.BirthPlaceUid".as("aliasBirthPlaceUid")
        , $"df2.Phone1Uid".as("aliasPhone1Uid"), $"df2.Phone2Uid".as("aliasPhone2Uid"))
      .withColumn("PatientUid",FunctionUtility.updateWithJoin($"PatientUid",$"aliasPatientUid"))
      .withColumn("AddressUid",FunctionUtility.updateWithJoin($"AddressUid",$"aliasAddressUid"))
      .withColumn("BirthPlaceUid",FunctionUtility.updateWithJoin($"BirthPlaceUid",$"aliasBirthPlaceUid"))
      .withColumn("Phone1Uid",when($"TelecomValue1".isNotNull,FunctionUtility.updateWithJoin($"Phone1Uid",$"aliasPhone1Uid")).otherwise(null))
      .withColumn("Phone2Uid",when($"TelecomValue2".isNotNull,FunctionUtility.updateWithJoin($"Phone2Uid",$"aliasPhone2Uid")).otherwise(null))
      .drop("aliasPatientUid", "aliasAddressUid", "aliasBirthPlaceUid", "aliasPhone1Uid", "aliasPhone2Uid")

    //cleanedDemo9.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/cleanedDemo9.csv")
    println("Generate Uid's Uisng table tempPatUid")

    val tempPat1 = cleanedDemo9.filter($"PatientUid".isNotNull && rtrim(ltrim($"TelecomValue1")).isNotNull)
      .select($"PatientUid", $"PracticeUid")
      .withColumn("Phone1Uid", FunctionUtility.getNewUid())

    val cleanedDemo10 = cleanedDemo9.as("df1").join(tempPat1.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df2.PracticeUid","left_outer")
      .select($"df1.*", $"df2.Phone1Uid".alias("aliasPhone1Uid"))
      .withColumn("Phone1Uid",when($"TelecomValue1".isNotNull,FunctionUtility.updateWithJoin($"Phone1Uid",$"aliasPhone1Uid")).otherwise(null))
      .drop("aliasPhone1Uid")

   // cleanedDemo10.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/cleanedDemo10.csv")
    println("generate Uid using tempPat1")

    //Update Phone2Uid
    val tempPatUid2 = cleanedDemo10.filter($"PatientUid".isNotNull && $"Phone2Uid".isNotNull && rtrim(ltrim($"TelecomValue2")).isNotNull)
      .select("PatientUid", "PracticeUid")
      .withColumn("Phone2Uid",FunctionUtility.getNewUid())

    val cleanedDemo11 = cleanedDemo10.as("df1").join(tempPatUid2.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df2.PracticeUid","left_outer")
      .select($"df1.*", $"df2.Phone2Uid".alias("aliasPhone2Uid"))
      .withColumn("Phone2Uid",when($"TelecomValue2".isNotNull,FunctionUtility.updateWithJoin($"Phone2Uid",$"aliasPhone2Uid")).otherwise(null))
      .drop("aliasPhone2Uid")
   // cleanedDemo11.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/cleanedDemo11.csv")
    println("generate Uid using tempPat2")

    //Update Gender From MappingPracticeCommonData i.e cross walk

    val cleanedDemo12 = cleanedDemo11.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.Gender" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df2.MapperMasterCollectionUid" === "18D5C957-AC54-49A8-8609-E8DDC8F6C721"
        && $"df1.GenderUid".isNull,"left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("Gender",FunctionUtility.updateWithJoin($"Gender",$"aliasMappedUid"))
      .drop("aliasMappedUid")

   println("Update Gender From MasterGender checking ExternalID is Done............")

    //Update Gender From MasterGender checking Discription

    val cleanedDemo13 = cleanedDemo12.as("df1")
      .join(MasterGender_Prod.as("df2")
        , $"df1.Gender" === "df2.Description","left_outer")
      .select($"df1.*", $"df2.GenderUid".as("aliasGenderUid"))
      .withColumn("GenderUid",FunctionUtility.updateWithJoin($"GenderUid",$"aliasGenderUid"))
      .drop("aliasGenderUid")

    println("Update Gender From MasterGender checking Description is Done............")
    cleanedDemo12.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/cleanedDemo12.csv")
    MasterGender_Prod.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/MasterGender_Prod.csv")

    //Gender Not mapped
    val Genderresult = cleanedDemo13.where( $"GenderUid".isNull && rtrim(ltrim($"Gender")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Gender Not Mapped"))
    println("Gender result is done............")

    val Genderwher = cleanedDemo13.where($"GenderUid".isNull && rtrim(ltrim($"Gender")).isNotNull)

    /*println("...................................")
    AllStatusvalue = AllStatusvalue.union(Genderresult)
    val cleanedDemo14 = cleanedDemo13.except(Genderwher)
    println("...................................")
    cleanedDemo14.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/cleanedDemo14.csv")
*/


    println("Genderwher  is done............")
    AllStatusvalue = AllStatusvalue.union(Genderresult)
    println("AllStatusvalue  is done............")
    val k4 = cleanedDemo13.rdd
    k4.collect.foreach(println)
    println("k4 rdd is done............")
    val s4 = Genderwher.rdd
    s4.collect.foreach(println)
    println("s4 rdd is done............")
    val sub7 = k4.subtract(s4)
    sub7.collect.foreach(println)
    println("sub4 rdd is done............")
    val cleanedDemo14 = spark.createDataFrame(sub7,StructType(Schema_CDR.someSchema))
    println("Gender Not mapped is Done............")

    cleanedDemo14.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/cleanedDemo14.csv")


    //Update MaritalStatusUid using crosswalk
    val cleanedDemo15 = cleanedDemo14.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.MaritalStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.MaritalStatusUid".isNull && $"df2.MapperMasterCollectionUid" === "E1F52182-230C-4C61-99DA-DBD7C6736A26"
          ,"left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("MaritalStatusUid",FunctionUtility.updateWithJoin($"MaritalStatusUid",$"aliasMappedUid"))
      .drop("aliasMappedUid")

   println("Update MaritalStatusUid using crosswalk is Done............")

    //Update MaritalStatusUid using MaritalStatusText

    val cleanedDemo16 = cleanedDemo15.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.MaritalStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df2.MapperMasterCollectionUid" === "E1F52182-230C-4C61-99DA-DBD7C6736A26"
        && $"df1.MaritalStatusUid".isNull,"left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("MaritalStatusUid",FunctionUtility.updateWithJoin($"MaritalStatusUid",$"aliasMappedUid"))
      .drop("aliasMappedUid")

    println("Update MaritalStatusUid using MaritalStatusText is Done............")

    val cleanedDemo17 = cleanedDemo16.as("df1")
      .join(MasterMaritalStatus_prod.as("df2"),
        $"df1.MaritalStatusText" === $"df2.Description"
        && $"df1.MaritalStatusUid".isNull,"left_outer")
      .select($"df1.*", $"df2.MaritalStatusUid".as("aliasMaritalStatusUid"))
      .withColumn("MaritalStatusUid",FunctionUtility.updateWithJoin($"MaritalStatusUid",$"aliasMaritalStatusUid"))
      .withColumn("ErrorNote", lit("null"))
      .drop("aliasMaritalStatusUid")

    println("Update MaritalStatusUid using MasterMaritalTable is Done............")

    val cleanedDemo18 = cleanedDemo17.as("df1")
      .join(MasterCity_prod.as("df2"), $"df1.CityUid".isNull &&
        $"df1.City" === $"df2.Name", "left_outer").join(MasterPostalCode_prod.as("df3"),
      ltrim(rtrim($"df1.ZipCode")).substr(0, 5) === $"df3.Code", "left_outer")
      .join(MasterCityPostalCode_prod.as("df4"), $"df3.PostalCodeUid" === $"df4.PostalCodeUid","left_outer")
      .select($"df1.*", $"df2.CityUid".as("aliasCityUid1"), $"df4.CityUid".as("aliasCityUid2"))
      .withColumn("CityUid", when($"aliasCityUid1".isNull, FunctionUtility.updateWithJoin($"CityUid",$"aliasCityUid2")).otherwise($"aliasCityUid1"))
      .drop("aliasCityUid1", "aliasCityUid2")

    println("Update CityUid using Multiple Master tables is Done............")

    //Update CityUid From MasterCity Table
    val cleanedDemo19 = cleanedDemo18.as("df1")
      .join(MasterCity_prod.as("df2"), $"df1.City" === $"df2.Name"
        && $"df1.CityUid".isNull,"left_outer")
      .select($"df1.*", $"df2.CityUid".as("aliasCityUid"))
      .withColumn("CityUid",FunctionUtility.updateWithJoin($"CityUid",$"aliasCityUid"))
      .drop("aliasCityUid")

    println("Update CityUid From MasterCity Table is Done............")

    //Update PostalCode From MasterPostalCode

    val cleanedDemo20 = cleanedDemo19.as("df1")
      .join(MasterPostalCode_prod.as("df2"),
        ltrim(rtrim($"df1.ZipCode")).substr(0, 5) === $"df2.Code","left_outer")
      .select($"df1.*", $"df2.PostalCodeUid".as("aliasPostalCodeUid"))
      .withColumn("PostalCodeUid",FunctionUtility.updateWithJoin($"PostalCodeUid",$"aliasPostalCodeUid"))
     .drop("aliasPostalCodeUid")

    println("Update PostalCode From MasterPostalCode is Done............")

    //Update State From MappingPracticeCommonData i.e cross walk On StateCode
    val cleanedDemo21 = cleanedDemo20.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.StateCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df2.MapperMasterCollectionUid" === "154025B1-8903-4F3D-832C-7C2CF429C52C" &&
        $"df1.StateUid".isNull,"left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("StateUid",FunctionUtility.updateWithJoin($"StateUid",$"aliasMappedUid"))
      .withColumn("ErrorNote", when(rtrim(ltrim($"df1.StateCode")).isNotNull ||
        rtrim(ltrim($"df1.State")).isNotNull && $"aliasMappedUid".isNull, "State Not Mapped").otherwise("null"))
      .drop("aliasMappedUid")

    println("Update State From MappingPracticeCommonData i.e cross walk on StateCode is Done............")

    //Update State From MappingPracticeCommonData i.e cross walk On State
    val cleanedDemo22 = cleanedDemo21.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.State" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df2.MapperMasterCollectionUid" === "154025B1-8903-4F3D-832C-7C2CF429C52C" &&
          $"df1.StateUid".isNull,"left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("StateUid",FunctionUtility.updateWithJoin($"StateUid",$"aliasMappedUid"))
      .withColumn("ErrorNote", when(rtrim(ltrim($"df1.StateCode")).isNotNull ||
        rtrim(ltrim($"df1.State")).isNotNull && $"aliasMappedUid".isNull, "State Not Mapped").otherwise("null"))
      .drop("aliasMappedUid")

    println("Update State From MappingPracticeCommonData i.e cross walk On State is Done............")

    val cleanedDemo23 = cleanedDemo22.as("df1")
      .join(MasterState_Prod.as("df2"), $"df1.State" === $"df2.Name"
        && $"df1.StateUid".isNull ,"left_outer")
      .select($"df1.*", $"df2.StateUid".as("aliasStateUid"))
      .withColumn("StateUid",FunctionUtility.updateWithJoin($"StateUid",$"aliasStateUid"))
      .withColumn("ErrorNote", lit("null")).drop("aliasStateUid")

    println("Update SateUid using MasterSate Table is Done............")

    //Update CountryUid From MappingPracticeCommonData i.e cross walk on CountryCode
    val cleanedDemo24 = cleanedDemo23.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.CountryCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df2.MapperMasterCollectionUid" === "7FEB9A0B-CD52-4B9A-881B-6946D5A7F486"
        && $"df1.CountryUid".isNull,"left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("CountryUid",FunctionUtility.updateWithJoin($"CountryUid",$"aliasMappedUid"))
      .withColumn("ErrorNote", when(rtrim(ltrim($"df1.CountryCode")).isNotNull ||
        rtrim(ltrim($"df1.Country")).isNotNull && $"aliasMappedUid".isNull, "Country Not Mapped").otherwise("null"))
      .drop("aliasMappedUid")

    println("Update CountryUid From MappingPracticeCommonData i.e cross walk on CountryCode is Done............")

    //Update CountryUid on Country
    val cleanedDemo25 = cleanedDemo24.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.Country" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df2.MapperMasterCollectionUid" === "7FEB9A0B-CD52-4B9A-881B-6946D5A7F486"
        && $"df1.CountryUid".isNull,"left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("CountryUid",FunctionUtility.updateWithJoin($"CountryUid",$"aliasMappedUid"))
      .withColumn("ErrorNote", when(rtrim(ltrim($"df1.CountryCode")).isNotNull ||
        rtrim(ltrim($"df1.Country")).isNotNull && $"aliasMappedUid".isNull, "Country Not Mapped").otherwise("null"))
      .drop("aliasMappedUid")

    println("Update CountryUid on Country is Done............")

    val cleanedDemo26 = cleanedDemo25.as("df1")
      .join(MasterCountry_Prod.as("df2"), $"df1.Country" === $"df2.Description"
        && $"df1.CountryUid".isNull,"left_outer")
      .select($"df1.*", $"df2.CountryUid".as("aliasCountryUid"))
      .withColumn("CountryUid",FunctionUtility.updateWithJoin($"CountryUid",$"aliasCountryUid"))
      .withColumn("ErrorNote", lit("null")).drop("aliasCountryUid")

     println("Update CountryUid From MasterCountry Table is Done............")

    //Update BirthPlaceCodeUid from masterPostalCode
    val cleanedDemo27 = cleanedDemo26.as("df1")
      .join(MasterPostalCode_prod.as("df2"),
        ltrim(rtrim($"df1.BirthZipCode")).substr(0, 5) === $"df2.Code","left_outer")
      .select($"df1.*", $"df2.PostalCodeUid".as("aliasPostalCodeUid"))
      .withColumn("BirthPostalCodeUid",FunctionUtility.updateWithJoin($"BirthPostalCodeUid",$"aliasPostalCodeUid"))
      .drop("aliasPostalCodeUid")

    println("Update BirthPlaceCodeUid from masterPostalCode is Done............")

    //Update BirthStateUid from crosswalk on BirthStateCode
    val cleanedDemo28 = cleanedDemo27.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.BirthStateCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df2.MapperMasterCollectionUid" === "154025B1-8903-4F3D-832C-7C2CF429C52C"
        && $"df1.BirthStateUid".isNull,"left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("BirthStateUid",FunctionUtility.updateWithJoin($"BirthStateUid",$"aliasMappedUid"))
      .withColumn("ErrorNote", when(rtrim(ltrim($"df1.BirthStateCode")).isNotNull ||
        rtrim(ltrim($"df1.BirthState")).isNotNull && $"aliasMappedUid".isNull, "Birth State Not Mapped").otherwise("null"))
      .drop("aliasMappedUid")

    println("Update BirthStateUid from crosswalk on BirthStateCode is Done............")

    //update cpd set BirthStateUid  = mpc.MappedUid,

    val cleanedDemo29 = cleanedDemo28.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.BirthState" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df2.MapperMasterCollectionUid" === "154025B1-8903-4F3D-832C-7C2CF429C52C"
        && $"df1.BirthStateUid".isNull,"left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("BirthStateUid",FunctionUtility.updateWithJoin($"BirthStateUid",$"aliasMappedUid"))
      .withColumn("ErrorNote", when(rtrim(ltrim($"df1.BirthStateCode")).isNotNull ||
        rtrim(ltrim($"df1.BirthState")).isNotNull && $"aliasMappedUid".isNull, "Birth State Not Mapped").otherwise("null"))
      .drop("aliasMappedUid")

    println("update cpd set BirthStateUid  = mpc.MappedUid is Done............")

    //Update BirthStateUid From MasterState
    val cleanedDemo30 = cleanedDemo29.as("df1")
      .join(MasterState_Prod.as("df2"),
        $"df1.BirthState" === $"df2.Name"
        && $"df1.BirthStateUid".isNull,"left_outer")
      .select($"df1.*", $"df2.StateUid".as("aliasStateUid"))
      .withColumn("BirthStateUid",FunctionUtility.updateWithJoin($"BirthStateUid",$"aliasStateUid"))
      .withColumn("ErrorNote", lit("null")).drop("aliasStateUid")

    println("Update BirthStateUid From MasterState is Done............")

    //Update BirthState From MappingPracticeCommonData i.e cross walk on BirthCountryCode

    val cleanedDemo31 = cleanedDemo30.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.BirthCountryCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df2.MapperMasterCollectionUid" === "7FEB9A0B-CD52-4B9A-881B-6946D5A7F486"
        && $"df1.BirthCountryUid".isNull,"left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("BirthCountryUid",FunctionUtility.updateWithJoin($"BirthCountryUid",$"aliasMappedUid"))
      .withColumn("ErrorNote", when(rtrim(ltrim($"df1.BirthCountryCode")).isNotNull ||
        rtrim(ltrim($"df1.BirthCountry")).isNotNull && $"aliasMappedUid".isNull, "Birth Country Not Mapped").otherwise("null"))
      .drop("aliasMappedUid")

    println("Update BirthState From MappingPracticeCommonData i.e cross walk On BirthCountryCode is Done............")

    //Update BirthState From MappingPracticeCommonData i.e cross walk on BirthCountry
    val cleanedDemo32 = cleanedDemo31.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.BirthCountry" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df2.MapperMasterCollectionUid" === "7FEB9A0B-CD52-4B9A-881B-6946D5A7F486"
        && $"df1.BirthCountryUid".isNull,"left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("BirthCountryUid",FunctionUtility.updateWithJoin($"BirthCountryUid",$"aliasMappedUid"))
      .withColumn("ErrorNote", when(rtrim(ltrim($"df1.BirthCountryCode")).isNotNull ||
        rtrim(ltrim($"df1.BirthCountry")).isNotNull && $"aliasMappedUid".isNull, "Birth Country Not Mapped").otherwise("null"))
      .drop("aliasMappedUid")

    println("Update BirthState From MappingPracticeCommonData i.e cross walk On BirthCountry is Done............")

    // Update BirthCountry from MasterCountry
    val cleanedDemo33 = cleanedDemo32.as("df1")
      .join(MasterCountry_Prod.as("df2"),
        $"df1.BirthCountry" === $"df2.Description"
        && $"df1.CountryUid".isNull,"left_outer")
      .select($"df1.*", $"df2.CountryUid".as("aliasCountryUid"))
      .withColumn("BirthCountryUid",FunctionUtility.updateWithJoin($"BirthCountryUid",$"aliasCountryUid"))
      .withColumn("ErrorNote", lit("null")).drop("aliasCountryUid")

    println("Update BirthCountry from MasterCountry is Done............")

    //Update Phone1TypeUid Using Crosswalk on PracticeValue

    val cleanedDemo34 = cleanedDemo33.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.TelecomTypeText1" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df2.MapperMasterCollectionUid" === "F00492A3-0372-4925-B0B8-7E11D3D2E340","left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("Phone1TypeUid",FunctionUtility.updateWithJoin($"Phone1TypeUid",$"aliasMappedUid"))
     .drop("aliasMappedUid")

    println("Update Phone1TypeUid Using Crosswalk on PracticeValue is Done............")


    val cleanedDemo35 = cleanedDemo34.as("df1")
      .join(MasterPhoneType_prod.as("df2"), $"df1.TelecomTypeText1" === $"df2.Description"
        && $"df1.Phone1TypeUid".isNull,"left_outer")
      .select($"df1.*", $"df2.PhoneTypeUid".as("aliasPhoneTypeUid"))
      .withColumn("Phone1TypeUid",FunctionUtility.updateWithJoin($"Phone1TypeUid",$"aliasPhoneTypeUid"))
      .drop("aliasPhoneTypeUid")

    println("Update Phone1TypeUid  on Description is Done............")

    //Phone Type 1 Not Mapped
    val updatestausPhone = cleanedDemo35.filter($"Phone1TypeUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Telecom Type 1 Not Mapped"))

    val whereclausePhone = cleanedDemo35.as("df1").filter($"Phone1TypeUid".isNull)

    AllStatusvalue = AllStatusvalue.union(updatestausPhone)
    val cleanedDemo36 = cleanedDemo35.except(whereclausePhone)
    println("Phone Type 1 Not Mapped is Done............")

    // update cpd set Phone2TypeUid  =mpc.MappedUid
    val cleanedDemo37 = cleanedDemo36.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.TelecomTypeText2" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "F00492A3-0372-4925-B0B8-7E11D3D2E340","left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("Phone2TypeUid",FunctionUtility.updateWithJoin($"Phone2TypeUid",$"aliasMappedUid"))
      .drop("aliasMappedUid")

    println("update cpd set Phone2TypeUid  =mpc.MappedUid is Done............")

    //update cpd set Phone2TypeUid  using MasterTable

    val cleanedDemo38 = cleanedDemo37.as("df1")
      .join(MasterPhoneType_prod.as("df2"), $"df1.TelecomTypeText2" === $"df2.Description"
        && $"df1.Phone2TypeUid".isNull,"left_outer")
      .select($"df1.*", $"df2.PhoneTypeUid".as("aliasPhoneTypeUid"))
      .withColumn("Phone2TypeUid",FunctionUtility.updateWithJoin($"Phone2TypeUid",$"aliasPhoneTypeUid"))
      .drop("aliasPhoneTypeUid")

    println("Update Phone2TypeUid  using MasterTable is Done............")

    //Phone Type 2 Not Mapped
    val updatestausPhone2 = cleanedDemo38.as("df1").filter($"Phone2TypeUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Telecom Type 2 Not Mapped"))

    val whereclausePhone2 = cleanedDemo38.as("df1").filter($"Phone2TypeUid".isNull)

    AllStatusvalue = AllStatusvalue.union(updatestausPhone2)
    val cleanedDemo39 = cleanedDemo38.except(whereclausePhone2)

    logger.warn("Phone Type 2 Not Mapped is Done............")

    //Update ReligiousAffiliation From MappingPracticeCommonData i.e cross walk
    val cleanedDemo40 = cleanedDemo39.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.ReligiousAffiliationCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df2.MapperMasterCollectionUid" === "64D5E3F2-5C91-481C-8C1C-D4545AD959C6"
        && $"df1.ReligiousAffiliationUid".isNull,"left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ReligiousAffiliationUid",FunctionUtility.updateWithJoin($"ReligiousAffiliationUid",$"aliasMappedUid"))
      .withColumn("StatusId", when(rtrim(ltrim($"df1.ReligiousAffiliationText")).isNotNull ||
        rtrim(ltrim($"df1.ReligiousAffiliationCode")).isNotNull && $"aliasMappedUid".isNull, 3).otherwise(1))
      .withColumn("ErrorNote", when(rtrim(ltrim($"df1.ReligiousAffiliationText")).isNotNull ||
        rtrim(ltrim($"df1.ReligiousAffiliationCode")).isNotNull && $"aliasMappedUid".isNull, "'Religious Affiliation Not Mapped").otherwise("null"))
      .drop("aliasMappedUid")

    println("Update ReligiousAffiliation From MappingPracticeCommonData i.e cross walk is Done............")

    //Update ReligiousAffiliation From MappingPracticeCommonData i.e cross walk on
    val cleanedDemo41 = cleanedDemo40.as("df1")
      .join(MappingPracticeCommonData_Delta.as("df2")
        , $"df1.ReligiousAffiliationText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df2.MapperMasterCollectionUid" === "64D5E3F2-5C91-481C-8C1C-D4545AD959C6"
        && $"df1.ReligiousAffiliationUid".isNull,"left_outer")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("ReligiousAffiliationUid",FunctionUtility.updateWithJoin($"ReligiousAffiliationUid",$"aliasMappedUid"))
      .withColumn("StatusId", when(rtrim(ltrim($"df1.ReligiousAffiliationText")).isNotNull ||
        rtrim(ltrim($"df1.ReligiousAffiliationCode")).isNotNull && $"aliasMappedUid".isNull, 3).otherwise(1))
      .withColumn("ErrorNote", when(rtrim(ltrim($"df1.ReligiousAffiliationText")).isNotNull ||
        rtrim(ltrim($"df1.ReligiousAffiliationCode")).isNotNull && $"aliasMappedUid".isNull, "'Religious Affiliation Not Mapped").otherwise("null"))
      .drop("aliasMappedUid")

    println("Update ReligiousAffiliation From MappingPracticeCommonData i.e cross walk is Done. 2...........")

    val cleanedDemo42 = cleanedDemo41.as("df1")
      .join(Master_prod.as("df2"),
        $"df1.ReligiousAffiliationText" === $"df2.Name"
        && $"df1.ReligiousAffiliationUid".isNull && $"df2.type" === "ReligiousAffiliation","left_outer")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("ReligiousAffiliationUid",FunctionUtility.updateWithJoin($"ReligiousAffiliationUid",$"aliasMasterUid"))
      .drop("aliasMasterUid")

    println("Update ReligiousAffiliation From Master_prod i.e cross walk is Done. 2...........")

    val update_Address_Prod = Address_Prod.as("df1").join(cleanedDemo42.as("df2"),
      $"df1.AddressUid" === $"df2.AddressUid","left_outer")
      .select($"df1.*", $"df2.StreetLineAddress1".as("aliasSLA1"), $"df2.StreetLineAddress2".as("aliasSLA2"),
        $"df2.StreetLineAddress3".as("aliasSLA3"), $"df2.StreetLineAddress4".as("aliasSLA4"),
        $"df2.CityUid".as("aliasCityUid"), $"df2.StateUid".as("aliasStateUid"),
        $"df2.PostalCodeUid".as("aliasPostalCodeUid"),
        $"df2.CountryUid".as('aliasCountryUid))
      .withColumn("Line1",FunctionUtility.updateWithJoin($"Line1",$"aliasSLA1"))
      .withColumn("Line2",FunctionUtility.updateWithJoin($"Line2",$"aliasSLA2"))
      .withColumn("Line3",FunctionUtility.updateWithJoin($"Line3",$"aliasSLA3"))
      .withColumn("Line4",FunctionUtility.updateWithJoin($"Line4",$"aliasSLA4"))
      .withColumn("CityUid",FunctionUtility.updateWithJoin($"CityUid",$"aliasCityUid"))
      .withColumn("StateUid",FunctionUtility.updateWithJoin($"StateUid",$"aliasStateUid"))
      .withColumn("PostalCodeUid",FunctionUtility.updateWithJoin($"PostalCodeUid",$"aliasPostalCodeUid"))
      .withColumn("CountryUid",FunctionUtility.updateWithJoin($"CountryUid",$"aliasCountryUid"))
      .withColumn("ModifiedDate", current_timestamp())
      .drop("aliasSLA1", "aliasSLA2", "aliasSLA3", "aliasSLA4", "aliasCityUid", "aliasStateUid", "aliasPostalCodeUid"
        , "aliasCountryUid")


    println("Update Address Records  is Done............")

    //Insert New Address Into  Address Table
    val Insert_Address_Prod = cleanedDemo42.as("df2").join(update_Address_Prod.as("df1"),
      $"df1.AddressUid" === $"df2.AddressUid" && $"df1.AddressUid".isNull, "left_outer")
      .select($"df2.AddressUid".as("AddressUid"), $"df2.StreetLineAddress1".as("Line1")
        , $"df2.StreetLineAddress2".as("Line2"),
        $"df2.StreetLineAddress3".as("Line3"), $"df2.StreetLineAddress4".as("Line4"), $"df2.CityUid".as("CityUid"),
        $"df2.StateUid".as("StateUid"), $"df2.PostalCodeUid".as("PostalCodeUid")
        , $"df2.CountryUid".as("CountryUid"))
      .withColumn("CreatedDate", current_timestamp())

    val address_Prod_cols = update_Address_Prod.columns.toSet
    val insert_address_prod = Insert_Address_Prod.columns.toSet
    val tot_of_both = address_Prod_cols ++ insert_address_prod

     var Address_Prod1 = update_Address_Prod.select(FunctionUtility.addColumns(address_Prod_cols, tot_of_both): _*)
      .union(Insert_Address_Prod.select(FunctionUtility.addColumns(insert_address_prod, tot_of_both): _*))
    println("Insert New Address Into  Address Table is Done............")

    //Update Address 2
    val update_Address_Prod2 = Address_Prod1.as("df1").join(cleanedDemo42.as("df2"),
      $"df2.BirthPlaceUid" === $"df1.AddressUid" && $"df2.AddressUid".isNotNull,"left_outer")
      .select($"df1.*", $"df2.BirthStateUid".as("aliasBirthStateUid"), $"df2.BirthPostalCodeUid".as("aliasBirthPostalCodeUid"),
        $"df2.BirthCountryUid".as("aliasBirthCountryUid"))
      .withColumn("StateUid",FunctionUtility.updateWithJoin($"StateUid",$"aliasBirthStateUid"))
      .withColumn("PostalCodeUid",FunctionUtility.updateWithJoin($"PostalCodeUid",$"aliasBirthPostalCodeUid"))
      .withColumn("CountryUid",FunctionUtility.updateWithJoin($"CountryUid",$"aliasBirthCountryUid"))
      .withColumn("ModifiedDate", current_timestamp())
      .drop("aliasBirthStateUid", "aliasBirthPostalCodeUid", "aliasBirthCountryUid")

    println("Update Address 2 is Done............")

    val insert_address_prod2 = cleanedDemo42.as("df2").join(update_Address_Prod2.as("df1"),
      $"df2.BirthPlaceUid" === $"df1.AddressUid" && $"df2.BirthPlaceUid".isNotNull, "left_outer")
      .select($"df2.BirthPlaceUid".as("AddressUid"), $"df2.BirthStateUid".as("StateUid"),
        $"df2.BirthPostalCodeUid".as("PostalCodeUid"), $"df2.BirthCountryUid".as("CountryUid"))
      .withColumn("CreatedDate", current_timestamp())

    val updatecols = update_Address_Prod2.columns.toSet
    val insert_address_prod2_col = insert_address_prod2.columns.toSet
    val totscols = updatecols ++ insert_address_prod2_col

    val Address_Prod2 = update_Address_Prod2.select(FunctionUtility.addColumns(updatecols, totscols): _*)
      .union(insert_address_prod2.select(FunctionUtility.addColumns(insert_address_prod2_col, totscols): _*))

    Address_Prod1 = Address_Prod1.union(Address_Prod2)

    //Address_Prod1.coalesce(1).write.option("header","true").csv("s3://bd-dev/aao_test/Address_prod1.csv")

    println("Insert Address 2 is Done............")
    //Update Phone

    val update_Phone = Phone_Prod.as("df1").join(cleanedDemo42.as("df2"),
      $"df2.Phone1Uid" === $"df1.PhoneUid","left_outer")
      .select($"df1.*", $"df2.TelecomValue1".as("aliasTelecomValue1"), $"df2.Phone1TypeUid".as("aliasPhone1TypeUid"))
      .withColumn("PhoneNo",FunctionUtility.updateWithJoin($"PhoneNo",$"aliasTelecomValue1"))
      .withColumn("PhoneTypeUid",FunctionUtility.updateWithJoin($"PhoneTypeUid",$"aliasPhone1TypeUid"))
      .withColumn("ModifiedDate", current_timestamp())
      .drop("aliasTelecomValue1", "aliasPhone1TypeUid")


    val update_Phone2 = update_Phone.as("df1").join(cleanedDemo42.as("df2"),
      $"df2.Phone2Uid" === $"df1.PhoneUid","left_outer")
      .select($"df1.*", $"df2.TelecomValue2".as("aliasTelecomValue2"), $"df2.Phone2TypeUid".as("aliasPhone2TypeUid"))
      .withColumn("PhoneNo",FunctionUtility.updateWithJoin($"PhoneNo",$"aliasTelecomValue2"))
      .withColumn("PhoneTypeUid",FunctionUtility.updateWithJoin($"PhoneTypeUid",$"aliasPhone2TypeUid"))
      .withColumn("ModifiedDate", current_timestamp())
      .drop("aliasTelecomValue2", "aliasPhone2TypeUid")

    println("Update Phone 1 & 2 is Done............")


    //Insert Phone
    val insert_Phone = cleanedDemo42.as("df2").join(update_Phone2.as("df1"),
      $"df1.PhoneUid" === $"df2.Phone1Uid" && $"df1.PhoneUid".isNull && $"df2.Phone1Uid".isNotNull
      , "left_outer")
      .select($"df2.Phone1Uid".as("PhoneUid"), $"df2.TelecomValue1".as("PhoneNo"), $"df2.Phone1TypeUid".as("PhoneTypeUid"))
      .withColumn("CreatedDate", current_timestamp())

    val PhoneAllCols = update_Phone2.columns.toSet
    val insert_Phonecols = insert_Phone.columns.toSet
    val tot_Phone_Insert = PhoneAllCols ++ insert_Phonecols

    var Phone_Prod1 = update_Phone2.select(FunctionUtility.addColumns(PhoneAllCols, tot_Phone_Insert): _*)
      .union(insert_Phone.select(FunctionUtility.addColumns(insert_Phonecols, tot_Phone_Insert): _*))


    val insert_Phone2 = cleanedDemo42.as("df2").join(Phone_Prod1.as("df1"),
      $"df1.PhoneUid" === $"df2.Phone2Uid" && $"df1.PhoneUid".isNull &&  $"df2.Phone2Uid".isNotNull
      ,"left_outer")
      .select($"df2.Phone2Uid".as("PhoneUid"), $"df2.TelecomValue2".as("PhoneNo"), $"df2.Phone2TypeUid".as("PhoneTypeUid"))
      .withColumn("CreatedDate", current_timestamp())

    val allcols1 =  Phone_Prod1.columns.toSet
    val insert_Phonecols2 = insert_Phone2.columns.toSet
    val tot_Phone_Insert2 = allcols1 ++ insert_Phonecols2

    Phone_Prod1 = Phone_Prod1.select(FunctionUtility.addColumns(allcols1, tot_Phone_Insert2): _*)
      .union(insert_Phone2.select(FunctionUtility.addColumns(insert_Phonecols2, tot_Phone_Insert2): _*))

    /*Phone_Prod1.coalesce(1).write.option("header","true")
      .csv("s3://bd-dev/aao_test/Phone)Prod1.csv")*/
    println("Insert Phone 1 & 2 is Done............")

    //reaming ColumntoSet and insert Data Into Phone table

    //Update Individual Prod Table
    val update_Individual_prod = Individual_prod1.as("df1").join(cleanedDemo42.as("df2"),
      $"df1.IndividualUid" === $"df2.PatientUid","left_outer")
      .select($"df1.*", $"df2.FirstName".as("aliasFirstName"), $"df2.MiddleName".as("aliasMiddleName")
        , $"df2.LastName".as("aliasLastName"), $"df2.DOB".as("aliasDOB"), $"df2.GenderUid".as("aliasGenderUid")
        , $"df2.MaritalStatusUid".as("aliasMaritalStatusUid"), $"df2.DeathDate".as("aliasDeathDate")
        , $"df2.AddressUid".as("aliasAddressUid"), $"df2.Phone1Uid".as("aliasPhone1Uid"), $"df2.Phone2Uid".as("aliasPhone2Uid")
        , $"df2.EmailID".as("aliasEmailID"))
      .withColumn("First",when(ltrim(rtrim($"aliasFirstName")).isNull, "null").otherwise(FunctionUtility.updateWithJoin($"First",$"aliasFirstName")))
      .withColumn("Middle",when(ltrim(rtrim($"aliasMiddleName")).isNull, "null").otherwise(FunctionUtility.updateWithJoin($"Middle",$"aliasMiddleName")))
      .withColumn("Last",when(ltrim(rtrim($"aliasLastName")).isNull, "null").otherwise(FunctionUtility.updateWithJoin($"Last",$"aliasLastName")))
      .withColumn("GenderUid",when(ltrim(rtrim($"aliasGenderUid")).isNull, "null").otherwise(FunctionUtility.updateWithJoin($"GenderUid",$"aliasGenderUid")))
      .withColumn("BirthDate",FunctionUtility.updateWithJoin($"BirthDate",$"aliasDOB"))
      .withColumn("MaritalStatusUid",FunctionUtility.updateWithJoin($"MaritalStatusUid",$"aliasMaritalStatusUid"))
      .withColumn("DeathDate",FunctionUtility.updateWithJoin($"DeathDate",$"aliasDeathDate"))
      .withColumn("Address1Uid",FunctionUtility.updateWithJoin($"Address1Uid",$"aliasAddressUid"))
      .withColumn("Phone1Uid",FunctionUtility.updateWithJoin($"Phone1Uid",$"aliasPhone1Uid"))
      .withColumn("Phone2Uid",FunctionUtility.updateWithJoin($"Phone2Uid",$"aliasPhone2Uid"))
      .withColumn("Emailaddress",FunctionUtility.updateWithJoin($"Emailaddress",$"aliasEmailID"))
      .withColumn("ModifiedDate", current_timestamp())
      .drop("aliasFirstName", "aliasMiddleName", "aliasLastName", "aliasDOB", "aliasGenderUid", "aliasMaritalStatusUid"
        , "aliasDeathDate", "aliasAddressUid", "aliasPhone1Uid", "aliasPhone2Uid", "aliasEmailID")

    println("Update Individual Prod Table is Done............")

    //Update Individualidentifier_prod table

    val update_Individualidentifier_prod = Individualidentifier_prod.as("df1")
      .join(cleanedDemo42.as("df2")
      , $"df1.IndividualUid" === $"df2.PatientUid" && $"df1.IdentifierTypeUid" === "E209B42B-0039-4958-83DE-D15845FA64BA"
        && ltrim(rtrim($"df2.SSN")).isNotNull,"left_outer")
      .select($"df1.*", $"df2.SSN".as("aliasSSN"))
      .withColumn("Identifier",FunctionUtility.updateWithJoin($"Identifier",$"aliasSSN"))
      .withColumn("ModifiedDate", current_timestamp())
      .drop("aliasSSN")

    //Use where And then Join
    println("Update Individualidentifier_prod table is Done............")

    //Insert Data into Individual Prod Table
    val insert_Individual_Prod = cleanedDemo42.as("df1").join(update_Individual_prod.as("df2")
      , $"df1.PatientUid" === $"df2.IndividualUid", "left_outer")
      .where($"df2.IndividualUid".isNull)
      .select($"df1.PatientUid".as("IndividualUid"), when(ltrim(rtrim($"df1.FirstName")).isNull, "null").otherwise($"df1.FirstName").as("First")
        , when(ltrim(rtrim($"df1.MiddleName")).isNull, "null").otherwise($"df1.MiddleName").as("Middle")
        , when(ltrim(rtrim($"df1.LastName")).isNull, "null").otherwise($"df1.LastName").as("Last")
        , $"df1.DOB".as("BirthDate"), $"df1.GenderUid".as("GenderUid"), $"df1.PracticeUid".as("PracticeUid")
        , $"df1.DeathDate".as("DeathDate"), $"df1.MaritalStatusUid".as("MaritalStatusUid")
        , $"df1.AddressUid".as("Address1Uid"), $"df1.Phone1Uid".as("Phone1Uid")
        , $"df1.Phone2Uid".as("Phone2Uid"), $"df1.EmailID".as("EmailAddress"))

    val allcolumns22 = update_Individual_prod.columns.toSet
    val insertIndividualcols2 = insert_Individual_Prod.columns.toSet
    val tot2 = allcolumns22 ++ insertIndividualcols2

    Individual_prod1 = update_Individual_prod.select(FunctionUtility.addColumns(allcolumns22, tot2): _*)
      .union(insert_Individual_Prod.select(FunctionUtility.addColumns(insertIndividualcols2, tot2): _*))

    /*Individual_prod1.coalesce(1).write.option("header","true")
      .csv("s3://bd-dev/aao_test/Individual_Prod1.csv")*/
    println("Insert Data into Individual Prod Table is Done............")

    //Insert New Patient Into individualidentifier

    val insert_Individualidentifier_prod = cleanedDemo42.as("df1").join(update_Individualidentifier_prod.as("df2")
      , $"df1.PatientUid" === $"df2.IndividualUid", "left_outer")
      .where(ltrim(rtrim($"df1.SSN")).isNotNull && $"df2.IndividualUid".isNull && $"df1.StatusId" === 1)
      .select($"df1.PatientUid".as("IndividualUid"), regexp_replace($"df1.SSN", "-", "").as("Identifier"))
      .withColumn("IndividualIdentifierUid", FunctionUtility.getNewUid())
      .withColumn("IdentifierTypeUid", lit("E209B42B-0039-4958-83DE-D15845FA64BA"))

    val IndiIdentifierAllCols =  update_Individualidentifier_prod.columns.toSet
    val insertAllCols = insert_Individualidentifier_prod.columns.toSet
    val tot_IndiIde_Insrt = IndiIdentifierAllCols ++ insertAllCols

    val Individualidentifier_Prod1 = update_Individualidentifier_prod.select(FunctionUtility.addColumns(IndiIdentifierAllCols, tot_IndiIde_Insrt): _*)
      .union(insert_Individualidentifier_prod.select(FunctionUtility.addColumns(insertAllCols, tot_IndiIde_Insrt): _*))

   /* Individualidentifier_Prod1.coalesce(1).write.option("header","true")
      .csv("s3://bd-dev/aao_test/IndividualIdentifier_Prod1.csv")*/

    println("Insert New Patient Into individualidentifier is Done............")

    cleanedDemo42.persist()

    val update_cleanedCachepatientDemo = cleanedDemo42.as("df1").join(Individual_prod1.as("df2")
      , $"df1.PatientUid" === $"df2.IndividualUid").join(Patient_prod.as('df3)
      , $"df3.PatientUid" === $"df2.IndividualUid")
      .select($"df1.*", $"df2.DeathDate".as("aliasDeathDate"))
      .withColumn("IsDeceased", when($"aliasDeathDate".isNull, 1).otherwise(0))
        .drop("aliasDeathDate")

    println("update_cleanedCachepatientDemo is Done............")

    val where111 = cleanedDemo42.as("df1").join(Individual_prod1.as("df2")
      , $"df1.PatientUid" === $"df2.IndividualUid").join(Patient_prod.as('df3)
      , $"df3.PatientUid" === $"df2.IndividualUid")
      .select($"df1.*")

    println("where111 is Done............")

    var cleanedDemo43 = cleanedDemo42.except(where111)
    cleanedDemo43 =  cleanedDemo43.union(update_cleanedCachepatientDemo)

    println("..........................................................................................................")
    cleanedDemo43 =  cleanedDemo43.union(update_cleanedCachepatientDemo)
    println("..........................................................................................................")
    cleanedDemo42.unpersist()
    println("..........................................................................................................")

    println("..........................................................................................................")
/*
    val where111 = cleanedDemo42.as("df1").join(Individual_prod1.as("df2")
      , $"df1.PatientUid" === $"df2.IndividualUid").join(Patient_prod.as('df3)
      , $"df3.PatientUid" === $"df2.IndividualUid")
      .select($"df1.*")
    println("where111 is Done............")

    val k5 = cleanedDemo42.rdd
    println("k5 rdd is create")
    val m5 = where111.rdd
    println("m5 rdd is create")
    cleanedDemo42.unpersist()
    val sub6 = k5.subtract(m5)
    println("sub6 rdd is created")

    var cleanedDemo43 = spark.createDataFrame(sub6,StructType(Schema_CDR.someSchema))
    println("..........................................................................................................")
    cleanedDemo43 =  cleanedDemo43.union(update_cleanedCachepatientDemo)*/
    println("Update CachepatientDemographics Table is Done............")

    //Update Patient table field from Patient Table
    val update_Patient_prod = Patient_prod.as("df1")
      .join(cleanedDemo43.as("df2")
        , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PatientUid".isNotNull,"left_outer")
      .select($"df1.*", $"df2.BirthPlaceUid".as("aliasBirthPlaceUid"), $"df2.ReligiousAffiliationUid".as("aliasReligiousAffiliationUid")
        , $"df2.ServiceProviderUid".as("aliasServiceProviderUid"), $"df2.DeathReason".as("aliasDeathReason")
        , $"df2.IsDeceased".as("aliasIsDeceased"), $"df2.Patient_EMR_ID".as("aliasPatient_EMR_ID"))
      .withColumn("BirthPlaceUid",FunctionUtility.updateWithJoin($"BirthPlaceUid",$"aliasBirthPlaceUid"))
      .withColumn("MasterReligiousAffiliationUid",FunctionUtility.updateWithJoin($"MasterReligiousAffiliationUid",$"aliasReligiousAffiliationUid"))
      .withColumn("PrimaryCarePhysicianUid",FunctionUtility.updateWithJoin($"PrimaryCarePhysicianUid",$"aliasServiceProviderUid"))
      .withColumn("DeathReason",FunctionUtility.updateWithJoin($"DeathReason",$"aliasDeathReason"))
      .withColumn("IsDeceased",FunctionUtility.updateWithJoin($"IsDeceased",$"aliasIsDeceased"))
      .withColumn("Patient_EMR_ID",FunctionUtility.updateWithJoin($"Patient_EMR_ID",$"aliasPatient_EMR_ID"))
      .drop("aliasBirthPlaceUid", "aliasReligiousAffiliationUid", "aliasServiceProviderUid", "aliasDeathReason"
        , "aliasIsDeceased", "aliasPatient_EMR_ID")

    println("Update Patient table field from Patient Table is Done............")


    cleanedDemo43.persist()
    //Insert All Records From #chPatientData to Patient whose PatientUid  is null and StatusId=1
    val insert_Patient_Prod = cleanedDemo43.as("df1")
      .join(update_Patient_prod.where($"PatientUid".isNull).as("df2")
        , $"df1.PatientUid" === $"df2.PatientUid", "left_outer")
      .select($"df1.PatientUid".as("PatientUid"), $"df1.PatientId".as("MedicalRecordNumber")
        , $"df1.PatientId".as("PatientID"), $"df1.BirthPlaceUid".as("BirthPlaceUid"), $"df1.ReligiousAffiliationUid".as("MasterReligiousAffiliationUid")
        , $"df1.ServiceProviderUid".as("PrimaryCarePhysicianUid"), $"df1.DeathReason".as("DeathReason")
        , $"df1.IsDeceased".as("IsDeceased"), $"df1.Patient_EMR_ID".as("Patient_EMR_ID"))

    val Patient_Columns = update_Patient_prod.columns.toSet
    val insert_patient_cols = insert_Patient_Prod.columns.toSet
    val tot_insert_patient = Patient_Columns ++ insert_patient_cols

    val Patient_Prod1 = update_Patient_prod.select(FunctionUtility.addColumns(Patient_Columns, tot_insert_patient): _*)
      .union(insert_Patient_Prod.select(FunctionUtility.addColumns(insert_patient_cols, tot_insert_patient): _*))
    println(Patient_Prod1.count())
    Patient_Prod1.show(10)
    println("CachepatientDemo Done........................")

   // Patient_Prod1.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/Patient_Prod1.csv")
    List(Patient_Prod1,Individual_prod1,Address_Prod1,ServiceProvider_prod1,Individualidentifier_Prod1)

  }

}
