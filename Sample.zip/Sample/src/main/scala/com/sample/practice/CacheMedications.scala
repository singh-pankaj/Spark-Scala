package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory

class CacheMedications {

  def CacheMedicationsFunc(spark : SparkSession,MergePracticeMap : DataFrame
                           ,CDRPatientCrosswalkTable : DataFrame
                           ,MultiTableExtendTable : DataFrame
                           ,Individual : DataFrame
                           ,ProviderNPIChangeTable : DataFrame
                           ,MasterDispensableDrug_Prod : DataFrame
                           ,distIndUid : DataFrame
                           ,distspUID : DataFrame
                           ,PatientMedication_Prod : DataFrame
                           ,Master_prod : DataFrame
                           ,MasterCode_Prod : DataFrame
                           ,MasterMedicationRoute_Prod : DataFrame
                           ,MappingPracticeMedication_Delta : DataFrame
                           ,Patient_Prod_Delta : DataFrame
                           ,Individual_prod_Delta3 : DataFrame
                           ,ServiceProvider_prod_Delta2 : DataFrame
                           ,MappingPracticeCommonData_Delta : DataFrame
                           ,MappingPracticeProcedure_Delta : DataFrame
                           ,MappingPracticeProblem_Delta : DataFrame) : List[DataFrame] = {

    val logger = LoggerFactory.getLogger("")

    import spark.implicits._
    //Start CacheMedications
    var CacheMedications =  spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9")

    val lookup9 = Map("_c0" -> "PatientId", "_c1" -> "MedicationCode", "_c2" -> "MedicationName"
      , "_c3" -> "MedicationCategory", "_c4" -> "MedStartDate", "_c5" -> "MedStopDate"
      , "_c6" -> "AdministeredEffectiveDate", "_c7" -> "RepeatNumber", "_c8" -> "MedicationRouteCode"
      , "_c9" -> "MedicationRouteText", "_c10" -> "DoseQuantity", "_c11" -> "DoseQuantityUnitCode"
      , "_c12" -> "DoseQuantityUnitText", "_c13" -> "MedicationProductFormCode","_c14" -> "MedicationProductFormText"
      ,"_c15" -> "ProcedureCode", "_c16" -> "ProcedureText", "_c17" -> "ProcedureCategory"
      , "_c18" -> "PrescribeElectronically", "_c19" -> "NegationInd", "_c20" -> "MedicationBrandName"
      , "_c21" -> "MedicationGenericName", "_c22" -> "MaxDoseQuantity", "_c23" -> "ServiceProviderNPI"
      , "_c24" -> "ServiceProviderLastName", "_c25" -> "ServiceProviderFirstName", "_c26" -> "DispensingTimeOfSupply"
      , "_c27" -> "DispensingDoseQuantity", "_c28" -> "SupplyPrescriberLastName", "_c29" -> "SupplyPrescriberFirstName"
      , "_c30" -> "SupplyPerformerLastName", "_c31" -> "SupplyPerformerFirstName", "_c32" -> "ServiceLocationId"
      , "_c33" -> "ServiceLocationName", "_c34" -> "MedicationIndicationCriteria"
      , "_c35" -> "MedicationIndicationProblemCode", "_c36" -> "MedicationIndicationProblemText"
      , "_c37" -> "MedicationIndicationProblemCategory", "_c38" -> "MedicationSeriesNumber"
      , "_c39" -> "MedicationReactionProblemCode", "_c40" -> "MedicationReactionProblemText"
      , "_c41" -> "MedicationReactionProblemCategory", "_c42" -> "MedicationReactionProblemSeverityCode"
      , "_c43" -> "MedicationReactionProblemSeverityText", "_c44" -> "MedicationStatusCode"
      ,"_c45" -> "MedicationStatusText","_c46" -> "MedicineManufacturer", "_c47" -> "MedicineId"
      , "_c48" -> "ProductInstanceScopingEntityId", "_c49" -> "PracticePatientMedicationKey"
      , "_c50" -> "DocumentationDate", "_c51" -> "PracticeUid", "_c52" -> "BatchUid", "_c53" -> "dummy1"
      , "_c54" -> "dummy2")

    CacheMedications = CacheMedications.select(CacheMedications.columns.map(c => col(c).as(lookup9.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    val tempCacheMedications = spark.read.option("header", "true")
      .csv("/home/gajanan.doifode/AAO_DATA/Schema/Cachemedication.txt")

    val CacheMedicationsallcols = tempCacheMedications.columns.toSet
    val CacheMedicationsViewcols = CacheMedications.columns.toSet
    val tot_viewCM_cacheMed = CacheMedicationsallcols ++ CacheMedicationsViewcols

    CacheMedications = tempCacheMedications.select(FunctionUtility.addColumns(CacheMedicationsallcols, tot_viewCM_cacheMed): _*)
      .union(CacheMedications.select(FunctionUtility.addColumns(CacheMedicationsViewcols, tot_viewCM_cacheMed): _*))

    CacheMedications = CacheMedications.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    val dist_PUID_CMedic = CacheMedications.filter($"StatusId".isNull).select("PracticeUid").distinct()

    val MergePracticeMap_CMedic = MergePracticeMap.as("df1").join(dist_PUID_CMedic.as("df2")
      , $"df1.NewPracticeUid" === $"df2.PracticeUid").select($"df1.*")

    //Update PracticeUid with OriginalPracticeUid of CacheMedications
    CacheMedications = CacheMedications.as("df1").join(MergePracticeMap_CMedic.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeUid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeUid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeUid of CacheMedications is Done.................")
    CacheMedications = CacheMedications.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CacheMedications
    CacheMedications = CacheMedications.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PatientId", ltrim(rtrim($"df1.PatientId")))
      .withColumn("MedicationCode", ltrim(rtrim($"df1.MedicationCode")))
      .withColumn("PracticePatientMedicationKey", ltrim(rtrim($"df1.PracticePatientMedicationKey")))
      .withColumn("PracticeSideNPI", ltrim(rtrim($"df1.ServiceProviderNPI")))
      .withColumn("ServiceProviderNPI", ltrim(rtrim($"df1.ServiceProviderNPI")))


    logger.warn("Update Multiple Columns of CacheMedications is Done............")

    //update status if PatientId is null Of CacheMedications
    val update_status_CMedic = CacheMedications.filter($"StatusId" === 1 && $"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val where_status_CMedic = CacheMedications.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_status_CMedic.count > 0) {
      val ex = CacheMedications.except(where_status_CMedic)
      CacheMedications = ex.union(update_status_CMedic)
    }

    logger.warn("update status if PatientId is null Of CacheMedications is Done........")

    //Update PatientId using CDRPatientCrosswalk In CacheMedications Table
    val update_PatientId_CMedic = CacheMedications.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientId_CMedic = CacheMedications.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientId_CMedic.count > 0) {
      val ex = CacheMedications.except(where_PatientId_CMedic)
      CacheMedications = ex.union(update_PatientId_CMedic)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk In CacheMedications Table is Done........")

    //update status if MedicationCode is null && $"MedicationName".isNull Of CacheMedications
    val update_status_CMedic22 = CacheMedications.filter($"StatusId" === 1 && $"MedicationCode".isNull
      && $"MedicationName".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("MedicationCode\\Name Missing"))

    val where_status_CMedic22 = CacheMedications.filter($"StatusId" === 1 && $"MedicationCode".isNull
      && $"MedicationName".isNull)

    if (where_status_CMedic22.count > 0) {
      val ex = CacheMedications.except(where_status_CMedic22)
      CacheMedications = ex.union(update_status_CMedic22)
    }

    logger.warn("update status if MedicationCode is null && MedicationName is Null Of CacheMedications is Done........")

    //update status if PracticePatientMedicationKey is Null Of CacheMedications
    val update_status_CMedic222 = CacheMedications.filter($"StatusId" === 1 && $"PracticePatientMedicationKey".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PracticePatientMedicationKey is Not Found or Missing"))

    val where_status_CMedic222 = CacheMedications.filter($"StatusId" === 1 && $"PracticePatientMedicationKey".isNull)

    if (where_status_CMedic222.count > 0) {
      val ex = CacheMedications.except(where_status_CMedic222)
      CacheMedications = ex.union(update_status_CMedic222)
    }

    logger.warn("update status if PracticePatientMedicationKey is Null Of CacheMedications is Done........")

    //Update ServiceProvideNPI Of CacheMedications
    val Update_SPNPI_CMedic = CacheMedications.as("df1").join(MultiTableExtendTable.as("df2")
      , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ServiceProviderNPI" === $"df2.Element1"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"StatusId" === 1)
      .select($"df1.*", $"df2.Value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue").drop($"AliasValue")

    val where_SPNPI_CMedic = CacheMedications.as("df1").join(MultiTableExtendTable.as("df2")
      , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ServiceProviderNPI" === $"df2.Element1"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"StatusId" === 1)
      .select($"df1.*")

    if (where_SPNPI_CMedic.count > 0) {
      val ex = CacheMedications.except(where_SPNPI_CMedic)
      CacheMedications = ex.union(Update_SPNPI_CMedic)
    }

    logger.warn("Update ServiceProvideNPI Of CacheMedications is Done........")

    //update ServiceProviderNPI 2 Of CacheMedications
    val update_SPNPI_CMedic2 = Individual.as("df1")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid")
      .join(CacheMedications.as("df3"), $"df3.PracticeUid" === $"df1.PracticeUid" &&
        $"df3.ServiceProviderNPI" === $"df2.OldNPI")
      .filter($"StatusId" === 1)
      .select($"df3.*", $"df2.NewNPI".as("AliasNewNPI"))
      .withColumn("ServiceProviderNPI", $"AliasNewNPI").drop($"AliasNewNPI")

    val where_SPNPI_CMedic2 = Individual.as("df1")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid")
      .join(CacheMedications.as("df3"), $"df3.PracticeUid" === $"df1.PracticeUid" &&
        $"df3.ServiceProviderNPI" === $"df2.OldNPI")
      .filter($"StatusId" === 1)
      .select($"df3.*")

    if (where_SPNPI_CMedic2.count > 0) {
      val ex = CacheMedications.except(where_SPNPI_CMedic2)
      CacheMedications = ex.union(update_SPNPI_CMedic2)
    }

    logger.warn("update ServiceProviderNPI 2 Of CacheMedications is Done........")

    //Update ServiceProvideNPI 3 Of CacheMedications
    val update_SPNPI_CMedic3 = CacheMedications.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element1" && $"df1.ServiceProviderLastName" === $"df2.Element2"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"StatusId" === 1)
      .select($"df1.*", $"df2.Value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue").drop($"AliasValue")

    val where_SPNPI_CMedic3 = CacheMedications.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element1" && $"df1.ServiceProviderLastName" === $"df2.Element2"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"StatusId" === 1)
      .select($"df1.*")

    if (where_SPNPI_CMedic3.count > 0) {
      val ex = CacheMedications.except(where_SPNPI_CMedic3)
      CacheMedications = ex.union(update_SPNPI_CMedic3)
    }

    logger.warn("update ServiceProviderNPI 3 Of CacheMedications is Done........")

    //update status if ServiceProviderNPI is Null Of CacheMedications
    val update_status_CMedic33 = CacheMedications.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid NPI Found,Length should be 10"))

    val where_status_CMedic33 = CacheMedications.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)

    if (where_status_CMedic33.count > 0) {
      val ex = CacheMedications.except(where_status_CMedic33)
      CacheMedications = ex.union(update_status_CMedic33)
    }

    logger.warn("update status if ServiceProviderNPI is Null Of CacheMedications is Done........")

    //update DispensableDrugUid Using MappingPracticeMedication_Prod of CacheMedications
    val update_DDrugUid_CMedic = CacheMedications.as("df1").join(MappingPracticeMedication_Delta.as("df2")
      , $"df1.MedicationCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.DispensableDrugUid".isNull)
      .select($"df1.*", $"df2.DispensableDrugUid".as("aliasDispensableDrugUid"))
      .withColumn("DispensableDrugUid", $"aliasDispensableDrugUid")
      .drop("aliasDispensableDrugUid")

    val where_DDrugUid_CMedic = CacheMedications.as("df1").join(MappingPracticeMedication_Delta.as("df2")
      , $"df1.MedicationCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.DispensableDrugUid".isNull)
      .select($"df1.*")

    if (where_DDrugUid_CMedic.count > 0) {
      val ex = CacheMedications.except(where_DDrugUid_CMedic)
      CacheMedications = ex.union(update_DDrugUid_CMedic)
    }

    logger.warn("update DispensableDrugUid Using MappingPracticeMedication_Prod of CacheMedications is Done........")

    //update DispensableDrugUid Using MappingPracticeMedication_Prod of CacheMedications 2
    val update_DDrugUid_CMedic2 = CacheMedications.as("df1").join(MappingPracticeMedication_Delta.as("df2")
      , when(rtrim(ltrim($"df1.MedicationName")).isNull,null).otherwise($"df1.MedicationName") === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.DispensableDrugUid".isNull)
      .select($"df1.*", $"df2.DispensableDrugUid".as("aliasDispensableDrugUid"))
      .withColumn("DispensableDrugUid", $"aliasDispensableDrugUid")
      .drop("aliasDispensableDrugUid")

    val where__DDrugUid_CMedic2 = CacheMedications.as("df1").join(MappingPracticeMedication_Delta.as("df2")
      , when(rtrim(ltrim($"df1.MedicationName")).isNull,null).otherwise($"df1.MedicationName") === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.DispensableDrugUid".isNull)
      .select($"df1.*")

    if (where__DDrugUid_CMedic2.count > 0) {
      val ex = CacheMedications.except(where__DDrugUid_CMedic2)
      CacheMedications = ex.union(update_DDrugUid_CMedic2)
    }

    logger.warn("update DispensableDrugUid Using MappingPracticeMedication_Prod of CacheMedications 2 is Done........")

    //update DispensableDrugUid Using MasterDispensableDrug of CacheMedications
    val update_DDrugUid_CMedic3 = CacheMedications.as("df1").join(MasterDispensableDrug_Prod.as("df2")
      , $"df1.MedicationCode" === $"df2.Code" && $"df1.MedicationCategory" === $"df2.DrugSource")
      .where($"df1.StatusId" === 1 && $"df1.DispensableDrugUid".isNull)
      .select($"df1.*", $"df2.DispensableDrugUid".as("aliasDispensableDrugUid"))
      .withColumn("DispensableDrugUid", $"aliasDispensableDrugUid")
      .drop("aliasDispensableDrugUid")

    val where_DDrugUid_CMedic3 = CacheMedications.as("df1").join(MasterDispensableDrug_Prod.as("df2")
      , $"df1.MedicationCode" === $"df2.Code" && $"df1.MedicationCategory" === $"df2.DrugSource")
      .where($"df1.StatusId" === 1 && $"df1.DispensableDrugUid".isNull)
      .select($"df1.*")

    if (where_DDrugUid_CMedic3.count > 0) {
      val ex = CacheMedications.except(where_DDrugUid_CMedic3)
      CacheMedications = ex.union(update_DDrugUid_CMedic3)
    }

    logger.warn("update DispensableDrugUid Using MasterDispensableDrug of CacheMedications 2 is Done........")

    //update DispensableDrugUid Using MasterDispensableDrug of CacheMedications 2
    val update_DDrugUid_CMedic4 = CacheMedications.as("df1").join(MasterDispensableDrug_Prod.as("df2")
      , when(rtrim(ltrim($"df1.MedicationName")).isNull,null).otherwise($"df1.MedicationName") === $"df2.SearchDescription")
      .where($"df1.StatusId" === 1 && $"df1.DispensableDrugUid".isNull && $"df1.MedicationCode".isNull)
      .select($"df1.*", $"df2.DispensableDrugUid".as("aliasDispensableDrugUid"))
      .withColumn("DispensableDrugUid", $"aliasDispensableDrugUid")
      .drop("aliasDispensableDrugUid")

    val where_DDrugUid_CMedic4 = CacheMedications.as("df1").join(MasterDispensableDrug_Prod.as("df2")
      , when(rtrim(ltrim($"df1.MedicationName")).isNull,null).otherwise($"df1.MedicationName") === $"df2.SearchDescription")
      .where($"df1.StatusId" === 1 && $"df1.DispensableDrugUid".isNull && $"df1.MedicationCode".isNull)
      .select($"df1.*")

    if (where_DDrugUid_CMedic4.count > 0) {
      val ex = CacheMedications.except(where_DDrugUid_CMedic4)
      CacheMedications = ex.union(update_DDrugUid_CMedic4)
    }

    logger.warn("update DispensableDrugUid Using Patient_prod of CacheMedications2  is Done........")

    //update PatientUid Using Patient_prod && Individual_prod of CacheMedications
    val update_PatientUid_CMedic = CacheMedications.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta3.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val where_PatientUid_CMedic = CacheMedications.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta3.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientUid_CMedic.count > 0) {
      val ex = CacheMedications.except(where_PatientUid_CMedic)
      CacheMedications = ex.union(update_PatientUid_CMedic)
    }

    logger.warn("update PatientUid Using Patient_prod && Individual_prod of CacheMedications is Done........")

    val update_ServiceProviderUid_CMedic = CacheMedications.as("df1").join(ServiceProvider_prod_Delta2.as("df2")
      ,$"df1.ServiceProviderNPI" === $"df2.NPI" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*",$"df2.ServiceProviderUid".as("aliasSPUID"))
      .withColumn("ServiceProviderUid",$"aliasSPUID")
      .drop("aliasSPUID")

    val where_ServiceProviderUid_CMedic = CacheMedications.as("df1").join(ServiceProvider_prod_Delta2.as("df2")
      ,$"df1.ServiceProviderNPI" === $"df2.NPI" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_ServiceProviderUid_CMedic.count > 0) {
      val ex = CacheMedications.except(where_ServiceProviderUid_CMedic)
      CacheMedications = ex.union(update_ServiceProviderUid_CMedic)
    }

    logger.warn("Update ServiceProviderUid using ViewServiceProvider_prod of CacheMedications is Done........")

    //Create Table Phy
    val Phy_Medic = CacheMedications.as("df1")
      .select("ServiceProviderUid", "ServiceProviderNPI", "ServiceProviderFirstName", "ServiceProviderLastName"
        , "PracticeUid", "StatusId")
      .where($"ServiceProviderNPI".isNotNull && $"ServiceProviderUid".isNull && $"StatusId" === 1)
      .groupBy($"ServiceProviderNPI", $"PracticeUid")
      .agg(max("ServiceProviderFirstName").as("ServiceProviderFirstName")
        , max("ServiceProviderLastName").as("ServiceProviderLastName"))
      .withColumn("Physician_MidName", lit("null"))
      .withColumn("ServiceProviderUid",FunctionUtility.getNewUid())

    //Update ServiceProviderUid Using PHY of CacheMedications
    val update_SPUID_CMedic2 = CacheMedications.as("df1.").join(Phy_Medic.as("df2")
      ,$"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderUid".isNull && $"df1.StatusId" === 1)
      .select($"df1.*",$"df2.ServiceProviderUid".as("aliasSPUID"))
      .withColumn("ServiceProviderUid",$"aliasSPUID")
      .drop("aliasSPUID")

    val where_SPUID_CMedic2 = CacheMedications.as("df1.").join(Phy_Medic.as("df2")
      ,$"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderUid".isNull && $"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_SPUID_CMedic2.count > 0) {
      val ex = CacheMedications.except(where_SPUID_CMedic2)
      CacheMedications = ex.union(update_SPUID_CMedic2)
    }

    logger.warn("Update ServiceProviderUid Using PHY of CacheMedications is Done........")

    //Insert data Into Individual Table using CacheMedications
    val insert_Individual_Prod_CMedic = Phy_Medic.as("df1")
      .join(distIndUid.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.IndividualUid"))
      .select($"df1.ServiceProviderUid".as("IndividualUid"), $"df1.ServiceProviderFirstName".as("First")
        , $"df1.Physician_MidName".as("Middle"), $"ServiceProviderLastName".as("Last"),
        $"df1.PracticeUid".as("PracticeUid")).distinct()

    val indicols = Individual_prod_Delta3.columns.toSet
    val insert_indi = insert_Individual_Prod_CMedic.columns.toSet
    val tot_allcols = indicols ++ insert_indi

    val Individual_prod_Delta4 = Individual_prod_Delta3.select(FunctionUtility.addColumns(indicols, tot_allcols): _*)
      .union(insert_Individual_Prod_CMedic.select(FunctionUtility.addColumns(insert_indi, tot_allcols): _*))
    //Use toSet and union and insert data into individual table

    logger.warn("Insert data Into Individual Table using CacheMedications is Done............")

    //Insert data Into ServiceProvider Table using CacheMedications
    val insert_ServiceProv2_CMedic = Phy_Medic.as("df1").join(distspUID.as("df2")
      , !$"df1.ServiceProviderUid".isin($"df2.ServiceProviderUid"))
      .select($"df1.ServiceProviderUid", when($"df1.Physician_MidName".isNotNull, concat_ws(" "
        , $"ServiceProviderLastName", $"ServiceProviderFirstName", $"Physician_MidName"))
        .otherwise(concat_ws(" ", $"ServiceProviderLastName", $"ServiceProviderFirstName")).as("ListName")
        , $"df1.ServiceProviderNPI".as("NPI"))
      .withColumn("ExternalID", lit(null))
      .withColumn("Type", lit(4))

    val Service_cols = ServiceProvider_prod_Delta2.columns.toSet
    val insert_Service = insert_ServiceProv2_CMedic.columns.toSet
    val tot_cols2 = Service_cols ++ insert_Service

    val ServiceProvider_prod_Delta3 = ServiceProvider_prod_Delta2.select(FunctionUtility.addColumns(Service_cols, tot_cols2): _*)
      .union(insert_ServiceProv2_CMedic.select(FunctionUtility.addColumns(insert_Service, tot_cols2): _*))

    //Use toSet and union and insert data into ServiceProvider
    logger.warn("Insert data Into ServiceProvider Table using CacheMedications is Done............")

    //Update Status iF PatientUid Is null Of Cachemedication
    val update_status_CMedic44 = CacheMedications.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_status_CMedic44 = CacheMedications.filter($"StatusId" === 1 && $"PatientUid".isNull)

    if (where_status_CMedic44.count > 0) {
      val ex = CacheMedications.except(where_status_CMedic44)
      CacheMedications = ex.union(update_status_CMedic44)
    }

    logger.warn("Update Status iF PatientUid Is null Of Cachemedication is Done........")

    //Drop Duplicate records of CacheMedications
    var cleanedCacheMedications= CacheMedications.dropDuplicates(Seq("PatientUid", "PracticePatientMedicationKey"))
    val duplicateRecords_CacheMedications = CacheMedications.except(cleanedCacheMedications)

    logger.warn("Drop Duplicate records of CacheMedications is Done............")


    //Update PatientMedicationUid of CacheMedications using PatientMedication_Prod
    val update_PatientMedicationUid_CMedic = cleanedCacheMedications.as("df1.").join(PatientMedication_Prod.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientMedicationKey" === $"df2.PracticePatientMedicationKey")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*",$"df2.PatientMedicationUid".as("aliasPatientMedicationUid"))
      .withColumn("PatientMedicationUid",$"aliasPatientMedicationUid")
      .drop("aliasPatientMedicationUid")

    val where_PatientMedicationUid_CMedic =  cleanedCacheMedications.as("df1.").join(PatientMedication_Prod.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientMedicationKey" === $"df2.PracticePatientMedicationKey")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientMedicationUid_CMedic.count > 0) {
      val ex = cleanedCacheMedications.except(where_PatientMedicationUid_CMedic)
      cleanedCacheMedications = ex.union(update_PatientMedicationUid_CMedic)
    }

    logger.warn("Update PatientMedicationUid of CacheMedications using PatientMedication_Prod is Done........")

    val tempPatientMedication = cleanedCacheMedications.filter($"StatusId" === 1 && $"PatientMedicationUid".isNull
      && $"PracticePatientMedicationKey".isNotNull)
      .select($"PatientUid",$"PracticePatientMedicationKey")
      .withColumn("PatientMedicationUid",FunctionUtility.getNewUid())

    //Update PatientMedicationUid of CacheMedications using tempPatientMedication
    val update_PatientMedicationUid_CMedic2 = cleanedCacheMedications.as("df1.").join(tempPatientMedication.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientMedicationKey" === $"df2.PracticePatientMedicationKey")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*",$"df2.PatientMedicationUid".as("aliasPatientMedicationUid"))
      .withColumn("PatientMedicationUid",$"aliasPatientMedicationUid")
      .drop("aliasPatientMedicationUid")

    val where_PatientMedicationUid_CMedic2 = cleanedCacheMedications.as("df1.").join(tempPatientMedication.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientMedicationKey" === $"df2.PracticePatientMedicationKey")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientMedicationUid_CMedic2.count > 0) {
      val ex = cleanedCacheMedications.except(where_PatientMedicationUid_CMedic2)
      cleanedCacheMedications = ex.union(update_PatientMedicationUid_CMedic2)
    }

    logger.warn("Update PatientMedicationUid of CacheMedications using tempPatientMedication is Done........")

    //update MasterMedicationProductFormUid from MappingPracticeCommonData of CacheMedications
    val update_MasterMedicationProductFormUid = cleanedCacheMedications.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.MedicationProductFormCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "86810E77-9A6F-4022-AC6E-FBCE80D8E566")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationProductFormUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("MasterMedicationProductFormUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_MasterMedicationProductFormUid = cleanedCacheMedications.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.MedicationProductFormCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "86810E77-9A6F-4022-AC6E-FBCE80D8E566")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationProductFormUid".isNull)
      .select($"df1.*")

    if (where_MasterMedicationProductFormUid.count > 0) {
      val ex = cleanedCacheMedications.except(where_MasterMedicationProductFormUid)
      cleanedCacheMedications = ex.union(update_MasterMedicationProductFormUid)
    }

    logger.warn("update MasterMedicationProductFormUid from MappingPracticeCommonData of CacheMedications is Done........")

    //update MasterMedicationProductFormUid from MappingPracticeCommonData of CacheMedications 2
    val update_MasterMedicationProductFormUid2 = cleanedCacheMedications.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.MedicationProductFormText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "86810E77-9A6F-4022-AC6E-FBCE80D8E566")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationProductFormUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("MasterMedicationProductFormUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_MasterMedicationProductFormUid2 = cleanedCacheMedications.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.MedicationProductFormText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "86810E77-9A6F-4022-AC6E-FBCE80D8E566")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationProductFormUid".isNull)
      .select($"df1.*")

    if (where_MasterMedicationProductFormUid2.count > 0) {
      val ex = cleanedCacheMedications.except(where_MasterMedicationProductFormUid2)
      cleanedCacheMedications = ex.union(update_MasterMedicationProductFormUid2)
    }

    logger.warn("update MasterMedicationProductFormUid from MappingPracticeCommonData of CacheMedications 2 is Done........")

    //Update MasterMedicationProductFormUid from Master Table of CacheMedications
    val update_MasterMedicationProductFormUid3 = cleanedCacheMedications.as("df1").join(Master_prod.as("df2"),
      $"df1.MedicationProductFormCode" === $"df2.Code")
      .filter( $"df1.StatusId" === 1 && $"df1.MasterMedicationProductFormUid".isNull && $"df2.Type" === "MedicationProductForm")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("MasterMedicationProductFormUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_MasterMedicationProductFormUid3 = cleanedCacheMedications.as("df1").join(Master_prod.as("df2"),
      $"df1.MedicationProductFormCode" === $"df2.Code")
      .filter( $"df1.StatusId" === 1 && $"df1.MasterMedicationProductFormUid".isNull && $"df2.Type" === "MedicationProductForm")
      .select($"df1.*")

    if (where_MasterMedicationProductFormUid3.count > 0) {
      val ex = cleanedCacheMedications.except(where_MasterMedicationProductFormUid3)
      cleanedCacheMedications = ex.union(update_MasterMedicationProductFormUid3)
    }

    logger.warn("Update MasterMedicationProductFormUid from Master Table of CacheMedications is Done........")

    //Update MasterMedicationProductFormUid from Master Table of CacheMedications 2
    val update_MasterMedicationProductFormUid4 = cleanedCacheMedications.as("df1").join(Master_prod.as("df2"),
      $"df1.MedicationProductFormText" === $"df2.Name")
      .filter( $"df1.StatusId" === 1 && $"df1.MasterMedicationProductFormUid".isNull && $"df2.Type" === "MedicationProductForm")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("MasterMedicationProductFormUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_MasterMedicationProductFormUid4 = cleanedCacheMedications.as("df1").join(Master_prod.as("df2"),
      $"df1.MedicationProductFormText" === $"df2.Name")
      .filter( $"df1.StatusId" === 1 && $"df1.MasterMedicationProductFormUid".isNull && $"df2.Type" === "MedicationProductForm")
      .select($"df1.*")

    if (where_MasterMedicationProductFormUid4.count > 0) {
      val ex = cleanedCacheMedications.except(where_MasterMedicationProductFormUid4)
      cleanedCacheMedications = ex.union(update_MasterMedicationProductFormUid4)
    }

    logger.warn("Update MasterMedicationProductFormUid from Master Table of CacheMedications 2 is Done........")

    //update ProcedureUid Using MappingPracticeProcedure_Prod of CacheMedications
    val update_ProcedureUid_CMedic = cleanedCacheMedications.as("df1").join(MappingPracticeProcedure_Delta.as("df2")
      , $"df1.ProcedureCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.ProcedureUid".isNull)
      .select($"df1.*", $"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("ProcedureUid", $"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_ProcedureUid_CMedic = cleanedCacheMedications.as("df1").join(MappingPracticeProcedure_Delta.as("df2")
      , $"df1.ProcedureCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.ProcedureUid".isNull)
      .select($"df1.*")

    if (where_ProcedureUid_CMedic.count > 0) {
      val ex = cleanedCacheMedications.except(where_ProcedureUid_CMedic)
      cleanedCacheMedications = ex.union(update_ProcedureUid_CMedic)
    }

    logger.warn("update ProcedureUid Using MappingPracticeProcedure_Prod of CacheMedications is Done........")

    //update ProcedureUid Using MasterCode_Prod of CacheMedications
    val update_ProcedureUid_CMedic2 = cleanedCacheMedications.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.ProcedureCode" === $"df2.Code" && $"df1.ProcedureCategory" === $"df2.CodeSystem")
      .where($"df1.StatusId" === 1 && $"df1.ProcedureUid".isNull)
      .select($"df1.*", $"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("ProcedureUid", $"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_ProcedureUid_CMedic2 = cleanedCacheMedications.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.ProcedureCode" === $"df2.Code" && $"df1.ProcedureCategory" === $"df2.CodeSystem")
      .where($"df1.StatusId" === 1 && $"df1.ProcedureUid".isNull)
      .select($"df1.*")

    if (where_ProcedureUid_CMedic2.count > 0) {
      val ex = cleanedCacheMedications.except(where_ProcedureUid_CMedic2)
      cleanedCacheMedications = ex.union(update_ProcedureUid_CMedic2)
    }

    logger.warn("update ProcedureUid Using MasterCode_Prod of CacheMedications is Done........")

    //Update Status iF ProcedureUid Is null Of Cachemedication
    val update_status_CMedic444 = cleanedCacheMedications.filter($"StatusId" === 1 && $"ProcedureUid".isNull
      && rtrim(ltrim($"ProcedureCode")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("ProcedureCode Not Mapped"))

    val where_status_CMedic444 = cleanedCacheMedications.filter($"StatusId" === 1 && $"ProcedureUid".isNull
      && rtrim(ltrim($"ProcedureCode")).isNotNull)

    if (where_status_CMedic444.count > 0) {
      val ex = cleanedCacheMedications.except(where_status_CMedic444)
      cleanedCacheMedications = ex.union(update_status_CMedic444)
    }

    logger.warn("Update Status iF PatientUid Is null Of Cachemedication is Done........")


    //update MedicationIndicationProblemCodeUid Using MappingPracticeProblem of CacheMedications
    val update_MedIPUID_CMedic = cleanedCacheMedications.as("df1").join(MappingPracticeProblem_Delta.as("df2")
      , $"df1.MedicationIndicationProblemCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.MedicationIndicationProblemCodeUid".isNull)
      .select($"df1.*", $"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("MedicationIndicationProblemCodeUid", $"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_MedIPUID_CMedic = cleanedCacheMedications.as("df1").join(MappingPracticeProblem_Delta.as("df2")
      , $"df1.MedicationIndicationProblemCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.MedicationIndicationProblemCodeUid".isNull)
      .select($"df1.*")

    if (where_MedIPUID_CMedic.count > 0) {
      val ex = cleanedCacheMedications.except(where_MedIPUID_CMedic)
      cleanedCacheMedications = ex.union(update_MedIPUID_CMedic)
    }

    logger.warn("update MedicationIndicationProblemCodeUid Using MappingPracticeProblem of CacheMedications is Done........")

    //update MedicationIndicationProblemCode Using MasterCode_Prod of CacheMedications
    val update_MedIPUID_CMedic2 = cleanedCacheMedications.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.MedicationIndicationProblemCode" === $"df2.Code" && $"df1.MedicationIndicationProblemCategory" === $"df2.CodeSystem")
      .where($"df1.StatusId" === 1 && $"df1.MedicationIndicationProblemCodeUid".isNull)
      .select($"df1.*", $"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("MedicationIndicationProblemCodeUid", $"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_MedIPUID_CMedic2 = cleanedCacheMedications.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.MedicationIndicationProblemCode" === $"df2.Code" && $"df1.MedicationIndicationProblemCategory" === $"df2.CodeSystem")
      .where($"df1.StatusId" === 1 && $"df1.MedicationIndicationProblemCodeUid".isNull)
      .select($"df1.*")

    if (where_MedIPUID_CMedic2.count > 0) {
      val ex = cleanedCacheMedications.except(where_MedIPUID_CMedic2)
      cleanedCacheMedications = ex.union(update_MedIPUID_CMedic2)
    }

    logger.warn("update MedicationIndicationProblemCode Using MasterCode_Prod of CacheMedications is Done........")

    //Update Status iF MedicationIndicationProblemCodeUid Is null Of Cachemedication
    val update_status_CMedic555 = cleanedCacheMedications.filter($"StatusId" === 1 && $"MedicationIndicationProblemCodeUid".isNull
      && rtrim(ltrim($"ProcedureCode")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("MedicationIndicationProblemCode Not Mapped"))

    val where_status_CMedic555 = cleanedCacheMedications.filter($"StatusId" === 1 && $"MedicationIndicationProblemCodeUid".isNull
      && rtrim(ltrim($"ProcedureCode")).isNotNull)

    if (where_status_CMedic555.count > 0) {
      val ex = cleanedCacheMedications.except(where_status_CMedic555)
      cleanedCacheMedications = ex.union(update_status_CMedic555)
    }

    logger.warn("Update Status iF MedicationIndicationProblemCodeUid Is null Of Cachemedication is Done........")

    //update MasterMedicationStatusUid from MappingPracticeCommonData of CacheMedications
    val update_MasterMedicationStatusUid = cleanedCacheMedications.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.MedicationStatusCode" === $"df2.PracticeValue" || $"df1.MedicationStatusText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "E3BE332C-0E43-4602-8B10-0344BAD2989F")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("MasterMedicationStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_MasterMedicationStatusUid = cleanedCacheMedications.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.MedicationStatusCode" === $"df2.PracticeValue" || $"df1.MedicationStatusText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "E3BE332C-0E43-4602-8B10-0344BAD2989F")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationStatusUid".isNull)
      .select($"df1.*")

    if (where_MasterMedicationStatusUid.count > 0) {
      val ex = cleanedCacheMedications.except(where_MasterMedicationStatusUid)
      cleanedCacheMedications = ex.union(update_MasterMedicationStatusUid)
    }

    logger.warn("Update Status iF MedicationIndicationProblemCodeUid Is null Of CacheMedication is Done........")

    //update MasterMedicationStatusUid Using Master_prod of CacheMedications
    val update_MasterMedicationStatusUid2 = cleanedCacheMedications.as("df1").join(Master_prod.as("df2")
      , $"df1.MedicationStatusCode" === $"df2.Code")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationStatusUid".isNull && $"df2.Type" === "MedicationStatus")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("MasterMedicationStatusUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_MasterMedicationStatusUid2 = cleanedCacheMedications.as("df1").join(Master_prod.as("df2")
      , $"df1.MedicationStatusCode" === $"df2.Code")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationStatusUid".isNull && $"df2.Type" === "MedicationStatus")
      .select($"df1.*")

    if (where_MasterMedicationStatusUid2.count > 0) {
      val ex = cleanedCacheMedications.except(where_MasterMedicationStatusUid2)
      cleanedCacheMedications = ex.union(update_MasterMedicationStatusUid2)
    }

    logger.warn("update MasterMedicationStatusUid Using Master_prod of CacheMedications is Done........")

    //update MasterMedicationStatusUid Using Master_prod of CacheMedications 2
    val update_MasterMedicationStatusUid3 = cleanedCacheMedications.as("df1").join(Master_prod.as("df2")
      , $"df1.MedicationStatusText" === $"df2.Name")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationStatusUid".isNull && $"df2.Type" === "MedicationStatus")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("MasterMedicationStatusUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_MasterMedicationStatusUid3 = cleanedCacheMedications.as("df1").join(Master_prod.as("df2")
      , $"df1.MedicationStatusText" === $"df2.Name")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationStatusUid".isNull && $"df2.Type" === "MedicationStatus")
      .select($"df1.*")

    if (where_MasterMedicationStatusUid3.count > 0) {
      val ex = cleanedCacheMedications.except(where_MasterMedicationStatusUid3)
      cleanedCacheMedications = ex.union(update_MasterMedicationStatusUid3)
    }

    logger.warn("update MasterMedicationStatusUid Using Master_prod of CacheMedications 2 is Done........")

    //Update Status iF MedicationIndicationProblemCodeUid Is null Of Cachemedication
    val update_status_CMedic666 = cleanedCacheMedications.filter($"StatusId" === 1 && $"MasterMedicationStatusUid".isNull
      && rtrim(ltrim($"MedicationStatusText")).isNotNull && rtrim(ltrim($"MedicationStatusCode")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("MedicationStatusText/Code Not Mapped"))

    val where_status_CMedic666 = cleanedCacheMedications.filter($"StatusId" === 1 && $"MasterMedicationStatusUid".isNull
      && rtrim(ltrim($"MedicationStatusText")).isNotNull && rtrim(ltrim($"MedicationStatusCode")).isNotNull)

    if (where_status_CMedic666.count > 0) {
      val ex = cleanedCacheMedications.except(where_status_CMedic666)
      cleanedCacheMedications = ex.union(update_status_CMedic666)
    }

    logger.warn("Update Status iF MedicationIndicationProblemCodeUid Is null Of Cachemedication is Done........")

    //update MedicationReactionProblemCodeUid of CacheMedications Using MappingPracticeProblem
    val update_MedicationReactionProblemCodeUid = cleanedCacheMedications.as("df1").join(MappingPracticeProblem_Delta.as("df2")
      , $"df1.MedicationReactionProblemCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.MedicationReactionProblemCodeUid".isNull)
      .select($"df1.*", $"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("MedicationReactionProblemCodeUid", $"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_MedicationReactionProblemCodeUid = cleanedCacheMedications.as("df1").join(MappingPracticeProblem_Delta.as("df2")
      , $"df1.MedicationReactionProblemCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.MedicationReactionProblemCodeUid".isNull)
      .select($"df1.*")

    if (where_MedicationReactionProblemCodeUid.count > 0) {
      val ex = cleanedCacheMedications.except(where_MedicationReactionProblemCodeUid)
      cleanedCacheMedications = ex.union(update_MedicationReactionProblemCodeUid)
    }

    logger.warn("update MedicationReactionProblemCodeUid of CacheMedications Using MappingPracticeProblem is Done........")

    //update MedicationReactionProblemCodeUid Using MasterCode_Prod of CacheMedications
    val update_MedicationReactionProblemCodeUid2 = cleanedCacheMedications.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.MedicationReactionProblemCode" === $"df2.Code" && $"df1.MedicationReactionProblemCategory" === $"df2.CodeSystem")
      .where($"df1.StatusId" === 1 && $"df1.MedicationReactionProblemCodeUid".isNull)
      .select($"df1.*", $"df2.CodeUid".as("aliasCodeUid"))
      .withColumn("MedicationReactionProblemCodeUid", $"aliasCodeUid")
      .drop("aliasCodeUid")

    val where_MedicationReactionProblemCodeUid2 = cleanedCacheMedications.as("df1").join(MasterCode_Prod.as("df2")
      , $"df1.MedicationReactionProblemCode" === $"df2.Code" && $"df1.MedicationReactionProblemCategory" === $"df2.CodeSystem")
      .where($"df1.StatusId" === 1 && $"df1.MedicationReactionProblemCodeUid".isNull)
      .select($"df1.*")

    if (where_MedicationReactionProblemCodeUid2.count > 0) {
      val ex = cleanedCacheMedications.except(where_MedicationReactionProblemCodeUid2)
      cleanedCacheMedications = ex.union(update_MedicationReactionProblemCodeUid2)
    }

    logger.warn("update MedicationReactionProblemCodeUid Using MasterCode_Prod of CacheMedications is Done........")

    //update MasterMedicationReactionProblemServerityUid Using Master_prod of CacheMedications
    val update_MasterMedicationReactionProblemServerityUid = cleanedCacheMedications.as("df1")
      .join(Master_prod.as("df2"), $"df1.MedicationReactionProblemSeverityCode" === $"df2.Code")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationReactionProblemServerityUid".isNull && $"df2.Type" === "ProblemSeverity")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("MasterMedicationReactionProblemServerityUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_MasterMedicationReactionProblemServerityUid = cleanedCacheMedications.as("df1")
      .join(Master_prod.as("df2"), $"df1.MedicationReactionProblemSeverityCode" === $"df2.Code")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationReactionProblemServerityUid".isNull && $"df2.Type" === "ProblemSeverity")
      .select($"df1.*")

    if (where_MasterMedicationReactionProblemServerityUid.count > 0) {
      val ex = cleanedCacheMedications.except(where_MasterMedicationReactionProblemServerityUid)
      cleanedCacheMedications = ex.union(update_MasterMedicationReactionProblemServerityUid)
    }

    logger.warn("update MasterMedicationReactionProblemServerityUid Using Master_prod of CacheMedications is Done........")

    //update MasterMedicationReactionProblemServerityUid Using Master_prod of CacheMedications 2
    val update_MasterMedicationReactionProblemServerityUid2 = cleanedCacheMedications.as("df1")
      .join(Master_prod.as("df2"), $"df1.MedicationReactionProblemSeverityText" === $"df2.Name")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationReactionProblemServerityUid".isNull && $"df2.Type" === "ProblemSeverity")
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("MasterMedicationReactionProblemServerityUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_MasterMedicationReactionProblemServerityUid2 = cleanedCacheMedications.as("df1")
      .join(Master_prod.as("df2"), $"df1.MedicationReactionProblemSeverityText" === $"df2.Name")
      .where($"df1.StatusId" === 1 && $"df1.MasterMedicationReactionProblemServerityUid".isNull && $"df2.Type" === "ProblemSeverity")
      .select($"df1.*")

    if (where_MasterMedicationReactionProblemServerityUid2.count > 0) {
      val ex = cleanedCacheMedications.except(where_MasterMedicationReactionProblemServerityUid2)
      cleanedCacheMedications = ex.union(update_MasterMedicationReactionProblemServerityUid2)
    }

    logger.warn("update MasterMedicationReactionProblemServerityUid Using Master_prod of CacheMedications 2 is Done........")

    //update RouteUid from MappingPracticeCommonData of CacheMedications
    val update_RouteUid = cleanedCacheMedications.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.MedicationRouteCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "78003645-6400-4814-8272-1E3EA58E51C1")
      .where($"df1.StatusId" === 1 && $"df1.RouteUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("RouteUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_RouteUid = cleanedCacheMedications.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.MedicationRouteCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "78003645-6400-4814-8272-1E3EA58E51C1")
      .where($"df1.StatusId" === 1 && $"df1.RouteUid".isNull)
      .select($"df1.*")

    if (where_RouteUid.count > 0) {
      val ex = cleanedCacheMedications.except(where_RouteUid)
      cleanedCacheMedications = ex.union(update_RouteUid)
    }

    logger.warn("update RouteUid from MappingPracticeCommonData of CacheMedications is Done........")

    //update RouteUid from MappingPracticeCommonData of CacheMedications 2
    val update_RouteUid2 = cleanedCacheMedications.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.MedicationRouteText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "78003645-6400-4814-8272-1E3EA58E51C1")
      .where($"df1.StatusId" === 1 && $"df1.RouteUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("RouteUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_RouteUid2 = cleanedCacheMedications.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.MedicationRouteText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "78003645-6400-4814-8272-1E3EA58E51C1")
      .where($"df1.StatusId" === 1 && $"df1.RouteUid".isNull)
      .select($"df1.*")

    if (where_RouteUid2.count > 0) {
      val ex = cleanedCacheMedications.except(where_RouteUid2)
      cleanedCacheMedications = ex.union(update_RouteUid2)
    }

    logger.warn("update RouteUid from MappingPracticeCommonData of CacheMedications 2 is Done........")


    //update RouteUid using MasterMedicationRoute_Prod of CacheMedications
    val update_RouteUid3 = cleanedCacheMedications.as("df1").join(MasterMedicationRoute_Prod.as("df2")
      ,$"df1.MedicationRouteCode" === $"df2.ExternalID")
      .where($"df1.StatusId" === 1 && $"df1.RouteUid".isNull)
      .select($"df1.*", $"df2.MedicationRouteUid".as("aliasMedicationRouteUid"))
      .withColumn("RouteUid", $"aliasMedicationRouteUid")
      .drop("aliasMedicationRouteUid")

    val where_RouteUid3 = cleanedCacheMedications.as("df1").join(MasterMedicationRoute_Prod.as("df2")
      ,$"df1.MedicationRouteCode" === $"df2.ExternalID")
      .where($"df1.StatusId" === 1 && $"df1.RouteUid".isNull)
      .select($"df1.*")

    if (where_RouteUid3.count > 0) {
      val ex = cleanedCacheMedications.except(where_RouteUid3)
      cleanedCacheMedications = ex.union(update_RouteUid3)
    }

    logger.warn("update RouteUid using MasterMedicationRoute_Prod of CacheMedications is Done........")

    //update RouteUid using MasterMedicationRoute_Prod of CacheMedications 2
    val update_RouteUid4 = cleanedCacheMedications.as("df1").join(MasterMedicationRoute_Prod.as("df2")
      ,$"df1.MedicationRouteText" === $"df2.Description")
      .where($"df1.StatusId" === 1 && $"df1.RouteUid".isNull)
      .select($"df1.*", $"df2.MedicationRouteUid".as("aliasMedicationRouteUid"))
      .withColumn("RouteUid", $"aliasMedicationRouteUid")
      .drop("aliasMedicationRouteUid")

    val where_RouteUid4 = cleanedCacheMedications.as("df1").join(MasterMedicationRoute_Prod.as("df2")
      ,$"df1.MedicationRouteText" === $"df2.Description")
      .where($"df1.StatusId" === 1 && $"df1.RouteUid".isNull)
      .select($"df1.*")

    if (where_RouteUid4.count > 0) {
      val ex = cleanedCacheMedications.except(where_RouteUid4)
      cleanedCacheMedications = ex.union(update_RouteUid4)
    }

    logger.warn("update RouteUid using MasterMedicationRoute_Prod of CacheMedications 2 is Done........")

    //Update PatientMedication_Prod using CacheMedication
    val update_PatientMedication_Prod = PatientMedication_Prod.as("df1").join(cleanedCacheMedications.as("df2")
      ,$"df1.PatientMedicationUid" === $"df2.PatientMedicationUid")
      .filter($"df2.StatusId" === 1)
      .select($"df1.*",$"df2.ServiceProviderUid".as("aliasSPUID"),$"df2.ProcedureUid".as("aliasPUID")
        ,$"df2.DiscontinueReasonUid".as("aliasDRUID"),$"df2.PharmacyUid".as("aliasPhrUID")
        ,$"df2.QuantityUnitOfMeasureUid".as("aliasQUMUID"),$"df2.DispensableDrugUid".as("aliasDDUID")
        ,$"df2.RepeatNumber".as("aliasRNumber"),$"df2.MedicationName".as("aliasMName"),$"df2.MedicationBrandName"
          .as("aliasMBName"),$"df2.MedicationRouteText".as("aliasMRT"),$"df2.MedStartDate".as("aliasMSDate")
        ,$"df2.MedStopDate".as("aliasMStopDate")
        ,$"df2.AdministeredEffectiveDate".as("aliasAEDate"),$"df2.PatientUid".as("aliasPatientUid")
        ,$"df2.PrescribeElectronically".as("aliasPElctro"),$"df2.MasterMedicationProductFormUid".as("aliasMMPFUID")
        ,$"df2.NegationInd".as("aliasNegationInd"),$"df2.MedicationGenericName".as("aliasMedGName")
        ,$"df2.MaxDoseQuantity".as("aliasMaxDQ"),$"df2.DispensingTimeOfSupply".as("aliasDTOS")
        ,$"df2.DispensingDoseQuantity".as("aliasDDQ"),$"df2.SupplyPrescriberLastName".as("aliasSPLName")
        ,$"df2.SupplyPrescriberFirstName".as("aliasSPFName"),$"df2.SupplyPerformerLastName".as("aliasSPLastN")
        ,$"df2.SupplyPerformerFirstName".as("aliasSPFirstN"),$"df2.ServiceLocationId".as("aliasSLID")
        ,$"df2.ServiceLocationName".as("aliasSLName"),$"df2.MedicationIndicationCriteria".as("aliasMIC")
        ,$"df2.MedicationIndicationProblemCodeUid".as("alisMIPCodeU"),$"df2.MedicationSeriesNumber".as("aliasMSNum")
        ,$"df2.MedicationReactionProblemCodeUid".as("aliasMRPCU"),$"df2.MasterMedicationReactionProblemServerityUid"
          .as("aliasMMRPSU"),$"df2.MasterMedicationStatusUid".as("aliasMMStatusU")
        ,$"df2.MedicineManufacturer".as("aliasMMFrac"),$"df2.MedicineId".as("aliasMedicineId")
        ,$"df2.ProductInstanceScopingEntityId".as("aliasPISEID"),$"df2.DoseQuantity".as("aliasDoseQuantity")
        ,$"df2.DoseQuantityUnitCode".as("aliasDQUC"),$"df2.DoseQuantityUnitText".as("aliasDQUT")
        ,$"df2.RouteUid".as("aliasRouteUid"),$"df2.MedicationProductFormText".as("aliasMPFtext")
        ,$"df2.MedicationCode".as("aliasMedicationCode"),$"df2.PracticePatientMedicationKey".as("aliasPPMKey")
        ,$"df2.MedicationCategory".as("aliasMCat"),$"df2.MedicationRouteCode".as("aliasMRCode")
        ,$"df2.MedicationProductFormCode".as("aliasMPFormCode"),$"df2.MedicationIndicationProblemCode".as("aliasMIPCode")
        ,$"df2.MedicationReactionProblemCode".as("aliasMRProCode"),$"df2.MedicationReactionProblemSeverityCode"
          .as("aliasMRpSCode"),$"df2.DocumentationDate".as("aliasDocumentationDate"))
      .withColumn("ServiceProviderUid",$"aliasSPUID")
      .withColumn("ProcedureUid",$"aliasPUID")
      .withColumn("DiscontinueReasonUid",$"aliasDRUID")
      .withColumn("PharmacyUid",$"aliasPhrUID")
      .withColumn("QuantityUnitOfMeasureUid",$"aliasQUMUID")
      .withColumn("DispensableDrugUid",$"aliasDDUID")
      .withColumn("RefillQuantity",$"aliasRNumber")
      .withColumn("Name",when($"aliasMName".isNull,$"aliasMBName").otherwise($"aliasMName"))
      .withColumn("DrugName",when($"aliasMName".isNull,$"aliasMBName").otherwise($"aliasMName"))
      .withColumn("Route",$"aliasMRT")
      .withColumn("StartDate",$"aliasMSDate")
      .withColumn("StopDate",$"aliasMStopDate")
      .withColumn("FullName",$"aliasMName")
      .withColumn("AdministeredEffectiveDate",$"aliasAEDate")
      .withColumn("PatientUid",$"aliasPatientUid")
      .withColumn("PrescribeElectronically",when($"aliasPElctro".isNull,0).otherwise($"aliasPElctro"))
      .withColumn("MasterMedicationProductFormUid",$"aliasMMPFUID")
      .withColumn("NegationInd",$"aliasNegationInd")
      .withColumn("MedicationBrandName",$"aliasMBName")
      .withColumn("MedicationGenericName",$"aliasMedGName")
      .withColumn("MaxDoseQuantity",$"aliasMaxDQ")
      .withColumn("DispensingTimeOfSupply",$"aliasDTOS")
      .withColumn("DispensingDoseQuantity",$"aliasDDQ")
      .withColumn("SupplyPrescriberLastName",$"aliasSPLName")
      .withColumn("SupplyPrescriberFirstName",$"aliasSPFName")
      .withColumn("SupplyPerformerLastName",$"aliasSPLastN")
      .withColumn("SupplyPerformerFirstName",$"aliasSPFirstN")
      .withColumn("ServiceLocationId",$"aliasSLID")
      .withColumn("ServiceLocationName",$"aliasSLName")
      .withColumn("MedicationIndicationCriteria",$"aliasMIC")
      .withColumn("MedicationIndicationProblemCodeUid",$"alisMIPCodeU")
      .withColumn("MedicationSeriesNumber",$"aliasMSNum")
      .withColumn("MedicationReactionProblemCodeUid",$"aliasMRPCU")
      .withColumn("MasterMedicationReactionProblemServerityUid",$"aliasMMRPSU")
      .withColumn("MasterMedicationStatusUid",$"aliasMMStatusU")
      .withColumn("MedicineManufacturer",$"aliasMMFrac")
      .withColumn("MedicineId",$"aliasMedicineId")
      .withColumn("ProductInstanceScopingEntityId",$"aliasPISEID")
      .withColumn("DoseQuantity",$"aliasDoseQuantity")
      .withColumn("DoseQuantityUnitCode",$"aliasDQUC")
      .withColumn("DoseQuantityUnitText",$"aliasDQUT")
      .withColumn("RouteUid",$"aliasRouteUid")
      .withColumn("ModifiedDate",current_timestamp())
      .withColumn("productForm",$"aliasMPFtext")
      .withColumn("MedicationCode",$"aliasMedicationCode")
      .withColumn("PracticePatientMedicationKey",$"aliasPPMKey")
      .withColumn("DrugSource",$"aliasMCat")
      .withColumn("MedicationRouteCode",$"aliasMRCode")
      .withColumn("MedicationProductFormCode",$"aliasMPFormCode")
      .withColumn("MedicationIndicationProblemCode",$"aliasMIPCode")
      .withColumn("MedicationReactionProblemCode",$"aliasMRProCode")
      .withColumn("MedicationReactionProblemSeverityCode",$"aliasMRpSCode")
      .withColumn("DocumentationDate",$"aliasDocumentationDate")
      .withColumn("CodeSystem",$"aliasMCat")
      .drop("aliasSPUID","aliasPUID","aliasDRUID","aliasPhrUID","aliasQUMUID","aliasDDUID","aliasRNumber"
        ,"aliasMBName","aliasMName","aliasMRT","aliasMSDate","aliasMStopDate","aliasAEDate","aliasPatientUid"
        ,"aliasPElctro","aliasMMPFUID","aliasNegationInd","aliasMedGName","aliasMaxDQ","aliasDTOS","aliasDDQ"
        ,"aliasSPLName","aliasSPFName","aliasSPLastN","aliasSPFirstN","aliasSLID","aliasSLName","aliasMIC"
        ,"alisMIPCodeU","aliasMSNum","aliasMRPCU"
        ,"aliasMMRPSU","aliasMMStatusU","aliasMMFrac","aliasMedicineId","aliasPISEID","aliasDoseQuantity"
        ,"aliasDQUC","aliasDQUT","aliasRouteUid","aliasMPFtext","aliasMedicationCode","aliasPPMKey","aliasMCat"
        ,"aliasMRCode","aliasMPFormCode","aliasMIPCode","aliasMRProCode","aliasMRpSCode","aliasDocumentationDate")

    val where_Medication = PatientMedication_Prod.as("df1").join(cleanedCacheMedications.as("df2")
      ,$"df1.PatientMedicationUid" === $"df2.PatientMedicationUid")
      .filter($"df2.StatusId" === 1)
      .select($"df1.*")

    val ex_Medication = PatientMedication_Prod.except(where_Medication)
    var PatientMedication_Prod_Delta = ex_Medication.union(update_PatientMedication_Prod)

    logger.warn("Update PatientMedication_Prod using CacheMedication is Done........")

    //Insert Data Into PatientMedication_prod
    val Insert_Data_PatientMedication_Prod = cleanedCacheMedications.as("df1").join(PatientMedication_Prod_Delta.as("df2")
      ,$"df1.PatientMedicationUid" === $"df2.PatientMedicationUid","left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.PatientMedicationUid".isNull)
      .select($"df1.PatientMedicationUid",$"df1.ServiceProviderUid",$"df1.ProcedureUid",$"df1.DiscontinueReasonUid"
        ,$"df1.PharmacyUid",$"df1.QuantityUnitOfMeasureUid",$"df1.DispensableDrugUid",$"df1.RepeatNumber".as("RefillQuantity")
        ,when($"df1.MedicationName".isNull,$"df1.MedicationBrandName").otherwise($"df1.MedicationName").as("Name")
        ,when($"df1.MedicationName".isNull,$"df1.MedicationBrandName").otherwise($"df1.MedicationName").as("DrugName")
        ,$"df1.MedicationRouteText".as("Route"),$"df1.MedStartDate".as("StartDate"),$"df1.MedStopDate".as("StopDate")
        ,$"df1.MedicationName".as("FullName"),$"df1.AdministeredEffectiveDate", $"df1.PatientUid"
        ,when($"df1.PrescribeElectronically".isNull,0).otherwise($"df1.PrescribeElectronically").as("PrescribeElectronically")
        ,$"df1.MasterMedicationProductFormUid",$"df1.NegationInd",$"df1.MedicationBrandName"
        , $"df1.MedicationGenericName",$"df1.MaxDoseQuantity",$"df1.DispensingTimeOfSupply"
        ,$"df1.DispensingDoseQuantity",$"df1.SupplyPrescriberLastName",$"df1.SupplyPrescriberFirstName"
        ,$"df1.SupplyPerformerLastName",$"df1.SupplyPerformerFirstName",$"df1.ServiceLocationId"
        ,$"df1.ServiceLocationName",$"df1.MedicationIndicationCriteria",$"df1.MedicationIndicationProblemCodeUid"
        ,$"df1.MedicationSeriesNumber",$"df1.MedicationReactionProblemCodeUid",
        $"df1.MasterMedicationReactionProblemServerityUid",$"df1.MasterMedicationStatusUid"
        ,$"df1.MedicineManufacturer",$"df1.MedicineId",$"df1.ProductInstanceScopingEntityId",$"df1.DoseQuantity"
        ,$"df1.DoseQuantityUnitCode",$"df1.DoseQuantityUnitText",$"df1.RouteUid"
        ,$"df1.MedicationProductFormText".as("ProductForm"),$"df1.MedicationCode"
        ,$"df1.PracticePatientMedicationKey",$"df1.MedicationCategory".as("DrugSource")
        ,$"df1.MedicationRouteCode",$"df1.MedicationProductFormCode",$"df1.MedicationIndicationProblemCode"
        ,$"df1.MedicationReactionProblemCode",$"df1.MedicationReactionProblemSeverityCode",$"df1.DocumentationDate"
        ,$"df1.MedicationCategory".as("CodeSystem"))
      .withColumn("Strength",lit("null"))
      .withColumn("StrengthUnits",lit("null"))
      .withColumn("DispenseAsPrescribed",lit("null"))
      .withColumn("IsSampleGiven",lit("null"))
      .withColumn("IsMaintenanceDrug",lit("null"))
      .withColumn("IsAdministered",lit("null"))
      .withColumn("AuthorizationCode",lit("null"))
      .withColumn("Type",lit("null"))
      .withColumn("ReasonForDiscontinuation",lit("null"))

    val MedicationCol = PatientMedication_Prod_Delta.columns.toSet
    val insert_Med = Insert_Data_PatientMedication_Prod.columns.toSet
    val tot_cols3 = MedicationCol ++ insert_Med

    PatientMedication_Prod_Delta = PatientMedication_Prod_Delta.select(FunctionUtility.addColumns(MedicationCol, tot_cols3): _*)
      .union(Insert_Data_PatientMedication_Prod.select(FunctionUtility.addColumns(insert_Med, tot_cols3): _*))


    logger.warn("End CacheMedications...................")
    //End CacheMedications


    List(PatientMedication_Prod_Delta,Individual_prod_Delta4,ServiceProvider_prod_Delta3)
  }

}
