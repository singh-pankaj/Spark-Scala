package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


class CacheSocialHistory {

  def CacheSocialHistoryFunc(spark : SparkSession,MergePracticeMap : DataFrame
                             ,CDRPatientCrosswalkTable : DataFrame
                             ,Master_prod : DataFrame
                             ,Patient_Prod_Delta : DataFrame
                             ,Individual_prod_Delta6 : DataFrame
                             ,MappingPracticeCommonData_Delta : DataFrame
                             ,PatientSocialHistoryObservation_Prod : DataFrame) : List[DataFrame] = {
    val logger = LoggerFactory.getLogger("")

    import spark.implicits._

    //Start SocialHistory

    var CacheSocialHistory = spark.read.option("delieter", "\u0017").csv("/home/ravikant.petkar/Downloads/AAO_Projects/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/c02a8880-be91-4479-add2-02fe91f48db0_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")

    //cacheFile.collect.foreach(println)

    val lookup_ImportSocialHistory = Map("_c0" -> "PatientId", "_c1" -> "SocialHistoryTypeCode", "_c2" -> "SocialHistoryTypeText", "_c3" -> "SocialHistoryObservedValue",
      "_c4" -> "DocumentationDate", "_c5" -> "EffectiveStopDate","_c6" -> "SocialHistoryStatusCode",
      "_c7" -> "SocialHistoryStatusText","_c8" -> "YearsSmoked","_c9" -> "QuitYear","_c10" -> "SocialHxGroup",
      "_c11" -> "EffectiveStartDate","_c12" -> "SocialHistoryObservationKey","_c13" -> "PracticeUid","_c14" -> "BatchUid", "_c15" -> "dummy1", "_c16" -> "dummy2")


    CacheSocialHistory = CacheSocialHistory.select(CacheSocialHistory.columns.map(c => col(c).as(lookup_ImportSocialHistory.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    val tempCacheSocialHistory = spark.read.option("header", "true")
      .csv("/home/gajanan.doifode/AAO_DATA/Schema/CacheSocialHistoryObservation")

    val CacheSocialHistorycols = tempCacheSocialHistory.columns.toSet
    val CacheSocialHistoryViewcols = CacheSocialHistory.columns.toSet
    val tot_viewEnDiag_CacheSocialHistoryViewcols = CacheSocialHistorycols ++ CacheSocialHistoryViewcols


    logger.warn("Files are reading")

    CacheSocialHistory = CacheSocialHistory.select(FunctionUtility.addColumns(CacheSocialHistorycols, tot_viewEnDiag_CacheSocialHistoryViewcols): _*)
      .union(tempCacheSocialHistory.select(FunctionUtility.addColumns(CacheSocialHistoryViewcols, tot_viewEnDiag_CacheSocialHistoryViewcols): _*))

    CacheSocialHistory = CacheSocialHistory.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    //Distinct PracticeUid of CacheProblem

    val dist_PrctUid_ImportSocialHistory = CacheSocialHistory.filter($"StatusId" === 9).select("PracticeUid").distinct()

    val tempMergePracticeMap_ImportSocialHistory = MergePracticeMap.as("df1").join(dist_PrctUid_ImportSocialHistory.as("df2")
      , $"df1.NewPracticeuid" === $"df2.PracticeUid").select($"df1.*")

    //Update PracticeUid with OriginalPracticeuid of CacheSocialHistoryObservation

    CacheSocialHistory = CacheSocialHistory.as("df1").join(tempMergePracticeMap_ImportSocialHistory.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeuid", "inner").filter($"df1.StatusId" === 9)
      .select($"df1.*", $"df2.OriginalPracticeuid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeuid of CacheSocialHistoryObservation is Done.............................")

    CacheSocialHistory = CacheSocialHistory.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CacheSocialHistoryObservation
    CacheSocialHistory = CacheSocialHistory.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PatientId", rtrim(ltrim($"df1.PatientId")))
      .withColumn("SocialHistoryTypeCode", rtrim(ltrim($"df1.SocialHistoryTypeCode")))

    logger.warn("Update Multiple Columns of CacheSocialHistoryObservation is Done............")

    //Update Multiple Status Of CacheSocialHistoryObservation
    val update_Status_importSocialHistory = CacheSocialHistory.filter($"StatusId" === 1 && $"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val where_Status_importSocialHistory = CacheSocialHistory.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_Status_importSocialHistory.count > 0) {
      val ex = CacheSocialHistory.except(where_Status_importSocialHistory)
      CacheSocialHistory = ex.union(update_Status_importSocialHistory)
    }

    logger.warn("Update Multiple Status Of CacheSocialHistoryObservation is Done............")

    //Update PatientId using CDRPatientCrosswalk In CacheSocialHistoryObservation Table

    val updatePatientIdImportSocialHistory = CacheSocialHistory.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientIdImportSocialHistory = CacheSocialHistory.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientIdImportSocialHistory.count > 0) {
      val ex = CacheSocialHistory.except(where_PatientIdImportSocialHistory)
      CacheSocialHistory = ex.union(updatePatientIdImportSocialHistory)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk In CacheSocialHistoryObservation Table is Done............")

    //Update PatientUid Of CacheSocialHistoryObservation using Individual and Patient table

    val update_PatientUid_CacheSocialHistoryObservation = CacheSocialHistory.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta6.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val where_CacheHO = CacheSocialHistory.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta6.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    val ex_HO = CacheSocialHistory.except(where_CacheHO)
    CacheSocialHistory = ex_HO.union(update_PatientUid_CacheSocialHistoryObservation)

    val update_Status_CacheSocialHistoryObservation = CacheSocialHistory.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_Status_CacheSocialHistoryObservation = CacheSocialHistory.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_Status_CacheSocialHistoryObservation.count > 0) {
      val ex = CacheSocialHistory.except(where_Status_CacheSocialHistoryObservation)
      CacheSocialHistory = ex.union(update_Status_CacheSocialHistoryObservation)
    }

    logger.warn("Update PatientUid Of CacheSocialHistoryObservation using Individual and Patient table is Done............")

    //Update Status if PatientUid is Null Of CacheSocialHistoryObservation
    val update_Status_CacheSocialHistoryObservation2 = CacheSocialHistory.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_Status_CacheSocialHistoryObservation2 = CacheSocialHistory.filter($"StatusId" === 1 && $"PatientUid".isNull)

    if (where_Status_CacheSocialHistoryObservation2.count > 0) {
      val ex = CacheSocialHistory.except(where_Status_CacheSocialHistoryObservation2)
      CacheSocialHistory = ex.union(update_Status_CacheSocialHistoryObservation2)
    }

    logger.warn("Update Status if PatientUid is Null Of CacheSocialHistoryObservation is Done............")

    //update SocialHistoryTypeUid of CacheSocialHistoryObservation using MappingPracticeCommon
    val update_SocialHistoryTypeUid = CacheSocialHistory.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.SocialHistoryTypeCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "CDECB858-DFD4-4DEE-8E0A-BB41B2D8CA08")
      .where($"df1.StatusId" === 1 && $"df1.SocialHistoryTypeUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("SocialHistoryTypeUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_SocialHistoryTypeUid = CacheSocialHistory.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.SocialHistoryTypeCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "CDECB858-DFD4-4DEE-8E0A-BB41B2D8CA08")
      .where($"df1.StatusId" === 1 && $"df1.SocialHistoryTypeUid".isNull)
      .select($"df1.*")

    if (where_SocialHistoryTypeUid.count > 0) {
      val ex = CacheSocialHistory.except(where_SocialHistoryTypeUid)
      CacheSocialHistory = ex.union(update_SocialHistoryTypeUid)
    }
    logger.warn("update SocialHistoryTypeUid of CacheSocialHistoryObservation using MappingPracticeCommon is Done....")

    //update SocialHistoryTypeUid of CacheSocialHistoryObservation using MappingPracticeCommon 2
    val update_SocialHistoryTypeUid2 = CacheSocialHistory.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.SocialHistoryTypeText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "CDECB858-DFD4-4DEE-8E0A-BB41B2D8CA08")
      .where($"df1.StatusId" === 1 && $"df1.SocialHistoryTypeUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("SocialHistoryTypeUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_SocialHistoryTypeUid2 = CacheSocialHistory.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.SocialHistoryTypeText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "CDECB858-DFD4-4DEE-8E0A-BB41B2D8CA08")
      .where($"df1.StatusId" === 1 && $"df1.SocialHistoryTypeUid".isNull)
      .select($"df1.*")

    if (where_SocialHistoryTypeUid2.count > 0) {
      val ex = CacheSocialHistory.except(where_SocialHistoryTypeUid2)
      CacheSocialHistory = ex.union(update_SocialHistoryTypeUid2)
    }
    logger.warn("update SocialHistoryTypeUid of CacheSocialHistoryObservation using MappingPracticeCommon 2 is Done....")

    //update SocialHistoryTypeUid of CacheSocialHistoryObservation using Master table
    val update_CacheSocialHistoryObservation2 = CacheSocialHistory.as("df1").join(Master_prod.as("df2"),
      $"df1.SocialHistoryTypeCode" === $"df2.Code" && $"df2.Type" === "SocialHistoryType")
      .filter($"df1.StatusId" === 1 && $"df1.SocialHistoryTypeUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("SocialHistoryTypeUid", $"aliasMasterUid")
      .withColumn("ErrorNote", lit("null"))
      .drop("aliasMasterUid")

    val where_CacheSocialHistoryObservation2 = CacheSocialHistory.as("df1").join(Master_prod.as("df2"),
      $"df1.SocialHistoryTypeCode" === $"df2.Code" && $"df2.Type" === "SocialHistoryType")
      .filter($"df1.StatusId" === 1 && $"df1.SocialHistoryTypeUid".isNull)
      .select($"df1.*")

    if (where_CacheSocialHistoryObservation2.count > 0) {
      val ex = CacheSocialHistory.except(where_CacheSocialHistoryObservation2)
      CacheSocialHistory = ex.union(update_CacheSocialHistoryObservation2)
    }
    logger.warn("update SocialHistoryTypeUid of CacheSocialHistoryObservation using Master table is Done....")

    //update SocialHistoryTypeUid of CacheSocialHistoryObservation using Master 2 table
    val update_CacheSocialHistoryObservation3 = CacheSocialHistory.as("df1").join(Master_prod.as("df2"),
      $"df1.SocialHistoryTypeText" === $"df2.Code" && $"df2.Type" === "SocialHistoryType")
      .filter($"df1.StatusId" === 1 && $"df1.SocialHistoryTypeUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("SocialHistoryTypeUid", $"aliasMasterUid")
      .withColumn("ErrorNote", lit("null"))
      .drop("aliasMasterUid")

    val where_CacheSocialHistoryObservation3 = CacheSocialHistory.as("df1").join(Master_prod.as("df2"),
      $"df1.SocialHistoryTypeText" === $"df2.Code" && $"df2.Type" === "SocialHistoryType")
      .filter($"df1.StatusId" === 1 && $"df1.SocialHistoryTypeUid".isNull)
      .select($"df1.*")

    if (where_CacheSocialHistoryObservation3.count > 0) {
      val ex = CacheSocialHistory.except(where_CacheSocialHistoryObservation3)
      CacheSocialHistory = ex.union(update_CacheSocialHistoryObservation3)
    }
    logger.warn("update SocialHistoryTypeUid of CacheSocialHistoryObservation using Master table 2 is Done....")

    //Update Status if SocialHistoryTypeUid is not Null Of CacheSocialHistoryObservation table
    val update_Status_CacheSocialHistoryObservation3 = CacheSocialHistory.filter($"StatusId" === 1
      && $"SocialHistoryTypeUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("SocialHistoryType Not Mapped"))

    val whereStatus_CacheSocialHistoryObservation3 = CacheSocialHistory.filter($"StatusId" === 1
      && $"SocialHistoryTypeUid".isNull)

    if (whereStatus_CacheSocialHistoryObservation3.count > 0) {
      val ex = CacheSocialHistory.except(whereStatus_CacheSocialHistoryObservation3)
      CacheSocialHistory = ex.union(update_Status_CacheSocialHistoryObservation3)
    }
    logger.warn("Update Status if SocialHistoryTypeUid is not Null CacheSocialHistoryObservation table is Done......")

    //update SocialHistoryTypeUid of CacheSocialHistoryObservation using MappingPracticeCommon 3
    val update_SocialHistoryTypeUid3 = CacheSocialHistory.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.SocialHistoryStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "E676CEF7-EF95-4D81-98BF-19E5ACC793FE")
      .where($"df1.StatusId" === 1 && $"df1.SocialHistoryStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("SocialHistoryTypeUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_SocialHistoryTypeUid3 = CacheSocialHistory.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.SocialHistoryStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "E676CEF7-EF95-4D81-98BF-19E5ACC793FE")
      .where($"df1.StatusId" === 1 && $"df1.SocialHistoryStatusUid".isNull)
      .select($"df1.*")

    if (where_SocialHistoryTypeUid3.count > 0) {
      val ex = CacheSocialHistory.except(where_SocialHistoryTypeUid3)
      CacheSocialHistory = ex.union(update_SocialHistoryTypeUid3)
    }
    logger.warn("update SocialHistoryTypeUid of CacheSocialHistoryObservation using MappingPracticeCommon 3 is Done....")

    //update SocialHistoryTypeUid of CacheSocialHistoryObservation using MappingPracticeCommon 4
    val update_SocialHistoryTypeUid4 = CacheSocialHistory.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.SocialHistoryStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "E676CEF7-EF95-4D81-98BF-19E5ACC793FE")
      .where($"df1.StatusId" === 1 && $"df1.SocialHistoryStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("SocialHistoryTypeUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_SocialHistoryTypeUid4 = CacheSocialHistory.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.SocialHistoryTypeText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "E676CEF7-EF95-4D81-98BF-19E5ACC793FE")
      .where($"df1.StatusId" === 1 && $"df1.SocialHistoryStatusUid".isNull)
      .select($"df1.*")

    if (where_SocialHistoryTypeUid4.count > 0) {
      val ex = CacheSocialHistory.except(where_SocialHistoryTypeUid4)
      CacheSocialHistory = ex.union(update_SocialHistoryTypeUid4)
    }
    logger.warn("update SocialHistoryTypeUid of CacheSocialHistoryObservation using MappingPracticeCommon 4 is Done....")

    //update SocialHistoryTypeUid of CacheSocialHistoryObservation using Master 3 table
    val update_CacheSocialHistoryObservation4 = CacheSocialHistory.as("df1").join(Master_prod.as("df2"),
      $"df1.SocialHistoryStatusCode" === $"df2.Code" && $"df2.Type" === "SocialHistoryStatus")
      .filter($"df1.StatusId" === 1 && $"df1.SocialHistoryStatusUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("SocialHistoryStatusUid", $"aliasMasterUid")
      .withColumn("ErrorNote", lit("null"))
      .drop("aliasMasterUid")

    val where_CacheSocialHistoryObservation4 = CacheSocialHistory.as("df1").join(Master_prod.as("df2"),
      $"df1.SocialHistoryStatusCode" === $"df2.Code" && $"df2.Type" === "SocialHistoryStatus")
      .filter($"df1.StatusId" === 1 && $"df1.SocialHistoryStatusUid".isNull)
      .select($"df1.*")

    if (where_CacheSocialHistoryObservation4.count > 0) {
      val ex = CacheSocialHistory.except(where_CacheSocialHistoryObservation4)
      CacheSocialHistory = ex.union(update_CacheSocialHistoryObservation4)
    }
    logger.warn("update SocialHistoryTypeUid of CacheSocialHistoryObservation using Master table 3 is Done....")

    //update SocialHistoryTypeUid of CacheSocialHistoryObservation using Master 4 table
    val update_CacheSocialHistoryObservation5 = CacheSocialHistory.as("df1").join(Master_prod.as("df2"),
      $"df1.SocialHistoryStatusText" === $"df2.Code" && $"df2.Type" === "SocialHistoryStatus")
      .filter($"df1.StatusId" === 1 && $"df1.SocialHistoryStatusUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("SocialHistoryStatusUid", $"aliasMasterUid")
      .withColumn("ErrorNote", lit("null"))
      .drop("aliasMasterUid")

    val where_CacheSocialHistoryObservation5 = CacheSocialHistory.as("df1").join(Master_prod.as("df2"),
      $"df1.SocialHistoryStatusText" === $"df2.Code" && $"df2.Type" === "SocialHistoryStatus")
      .filter($"df1.StatusId" === 1 && $"df1.SocialHistoryStatusUid".isNull)
      .select($"df1.*")

    if (where_CacheSocialHistoryObservation5.count > 0) {
      val ex = CacheSocialHistory.except(where_CacheSocialHistoryObservation5)
      CacheSocialHistory = ex.union(update_CacheSocialHistoryObservation5)
    }
    logger.warn("update SocialHistoryTypeUid of CacheSocialHistoryObservation using Master table 4 is Done....")

    //Update Status if SocialHistoryStatusUid is not Null  Of CacheSocialHistoryObservation table
    val update_Status_CacheSocialHistoryObservation4 = CacheSocialHistory.filter($"StatusId" === 1
      && rtrim(ltrim($"SocialHistoryStatusCode")).isNotNull || rtrim(ltrim($"SocialHistoryStatusText")).isNotNull
      && $"SocialHistoryStatusUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("SocialHistoryStatus Not Mapped"))

    val whereStatus_CacheSocialHistoryObservation4 = CacheSocialHistory.filter($"StatusId" === 1
      && rtrim(ltrim($"SocialHistoryStatusCode")).isNotNull || rtrim(ltrim($"SocialHistoryStatusText")).isNotNull
      && $"SocialHistoryStatusUid".isNull)

    if (whereStatus_CacheSocialHistoryObservation4.count > 0) {
      val ex = CacheSocialHistory.except(whereStatus_CacheSocialHistoryObservation4)
      CacheSocialHistory = ex.union(update_Status_CacheSocialHistoryObservation4)
    }
    logger.warn("Update Status if SocialHistoryStatusUid is not Null Of CacheSocialHistoryObservation table is Done......")

    //Update Status if SocialHistoryTypeCode is not Null Of CacheSocialHistoryObservation table 2
    val update_Status_CacheSocialHistoryObservation5 = CacheSocialHistory.filter($"StatusId" === 1
      && $"SocialHistoryStatusUid".isNull && $"SocialHistoryTypeText".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("SocialHistoryTypeCode\\Text Missing"))

    val whereStatus_CacheSocialHistoryObservation5 = CacheSocialHistory.filter($"StatusId" === 1
      && $"SocialHistoryStatusUid".isNull && $"SocialHistoryTypeText".isNull)

    if (whereStatus_CacheSocialHistoryObservation5.count > 0) {
      val ex = CacheSocialHistory.except(whereStatus_CacheSocialHistoryObservation5)
      CacheSocialHistory = ex.union(update_Status_CacheSocialHistoryObservation5)
    }
    logger.warn("Update Status if SocialHistoryTypeCode is not Null Of CacheSocialHistoryObservation table 2 is Done......")

    //Update Status if Documentationdate is not Null Of CacheSocialHistoryObservation table 3
    val update_Status_CacheSocialHistoryObservation6 = CacheSocialHistory.filter($"StatusId" === 1
      && $"Documentationdate".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Documentationdate Missing"))

    val whereStatus_CacheSocialHistoryObservation6 = CacheSocialHistory.filter($"StatusId" === 1
      && $"Documentationdate".isNull)

    if (whereStatus_CacheSocialHistoryObservation6.count > 0) {
      val ex = CacheSocialHistory.except(whereStatus_CacheSocialHistoryObservation6)
      CacheSocialHistory = ex.union(update_Status_CacheSocialHistoryObservation6)
    }
    logger.warn("Update Status if SocialHistoryTypeText is not Null Of CacheSocialHistoryObservation table 3 is Done......")

    //Update Status if SocialHistoryTypeText is not Null Of CacheSocialHistoryObservation table 4
    val update_Status_CacheSocialHistoryObservation7 = CacheSocialHistory.filter($"StatusId" === 1
      && $"SocialHistoryTypeText".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("SocialHistoryTypeText Missing"))

    val whereStatus_CacheSocialHistoryObservation7 = CacheSocialHistory.filter($"StatusId" === 1
      && $"SocialHistoryTypeText".isNull)

    if (whereStatus_CacheSocialHistoryObservation7.count > 0) {
      val ex = CacheSocialHistory.except(whereStatus_CacheSocialHistoryObservation7)
      CacheSocialHistory = ex.union(update_Status_CacheSocialHistoryObservation7)
    }
    logger.warn("Update Status if SocialHistoryTypeText is not Null Of CacheSocialHistoryObservation table 4 is Done......")

    //update PatientSocialHistoryObservationUid of CacheSocialHistoryObservation using PatientSocialHistoryObservation_Prod table
    val update_CacheSocialHistoryObservation6 = CacheSocialHistory.as("df1").join(PatientSocialHistoryObservation_Prod.as("df2"),
      $"df1.PatientUid" === $"df2.Code" && $"df1.SocialHistoryTypeUid" === $"df2.MasterSocialHistoryTypeUid" && $"df1.Documentationdate" === $"df2.Documentationdate")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientSocialHistoryObservationUid".as("aliasObservationUid"))
      .withColumn("PatientSocialHistoryObservationUid", $"aliasObservationUid")
      .drop("aliasObservationUid")

    val where_CacheSocialHistoryObservation6 = CacheSocialHistory.as("df1").join(Master_prod.as("df2"),
      $"df1.PatientUid" === $"df2.Code" && $"df1.SocialHistoryTypeUid" === $"df2.MasterSocialHistoryTypeUid" && $"df1.Documentationdate" === $"df2.Documentationdate")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_CacheSocialHistoryObservation6.count > 0) {
      val ex = CacheSocialHistory.except(where_CacheSocialHistoryObservation6)
      CacheSocialHistory = ex.union(update_CacheSocialHistoryObservation6)
    }
    logger.warn("update SocialHistoryTypeUid of CacheSocialHistoryObservation using Master table 3 is Done....")

    //Remove Duplicates of CacheSocialHistoryObservation

    var cleanedCacheSocialHistory = CacheSocialHistory.filter($"StatusId" === 1)
      .dropDuplicates(Seq("PatientUid", "SocialHistoryTypeUid", "Documentationdate", "SocialHistoryTypeText"))

    val dropDuplicatesCacheSocialHistoryObservation = CacheSocialHistory.filter($"StatusId" === 1)
      .dropDuplicates(Seq("PatientUid", "SocialHistoryTypeUid", "Documentationdate", "SocialHistoryTypeText"))

    cleanedCacheSocialHistory = cleanedCacheSocialHistory.union(dropDuplicatesCacheSocialHistoryObservation)

    var duplicatesRecordsCacheSocialHistoryObservation1 = CacheSocialHistory.except(cleanedCacheSocialHistory)
    val duplicaterecordsCacheSocialHistoryObservation2 = CacheSocialHistory.except(dropDuplicatesCacheSocialHistoryObservation)

    duplicatesRecordsCacheSocialHistoryObservation1 = duplicatesRecordsCacheSocialHistoryObservation1.union(duplicaterecordsCacheSocialHistoryObservation2)

    logger.warn("Remove Duplicates of CacheSocialHistoryObservation is Done............")

    //create #SocialHistory
    val tempSocialHistory = cleanedCacheSocialHistory.filter($"StatusId" === 1 && $"PatientSocialHistoryObservationUid".isNull)
      .select("PatientUid", "SocialHistoryTypeUid", "Documentationdate", "SocialHistoryTypeText").distinct()
      .withColumn("PatientSocialHistoryObservationUid", FunctionUtility.getNewUid())

    //Update CacheSocialHistoryObservation Table Using #SocialHistory Table
    val update_CacheSocialHistoryObservation22 = cleanedCacheSocialHistory.as("df1").join(tempSocialHistory.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.SocialHistoryTypeUid" === $"df2.SocialHistoryTypeUid"
        && $"df1.Documentationdate" === $"df2.Documentationdate" && $"df1.SocialHistoryTypeText" === $"df2.SocialHistoryTypeText")
      .filter($"df1.StatusId" === 1 )
      .select($"df1.*", $"df2.PatientSocialHistoryObservationUid".as("aliasPatientProblemUid"))
      .withColumn("PatientSocialHistoryObservationUid", $"aliasPatientProblemUid")
      .drop("aliasPatientProblemUid")

    val where_CacheSocialHistoryObservation22 = cleanedCacheSocialHistory.as("df1").join(tempSocialHistory.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.SocialHistoryTypeUid" === $"df2.SocialHistoryTypeUid"
        && $"df1.Documentationdate" === $"df2.Documentationdate" && $"df1.SocialHistoryTypeText" === $"df2.SocialHistoryTypeText")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_CacheSocialHistoryObservation22.count > 0) {
      val ex = cleanedCacheSocialHistory.except(where_CacheSocialHistoryObservation22)
      cleanedCacheSocialHistory = ex.union(update_CacheSocialHistoryObservation22)
    }
    logger.warn("Update CacheSocialHistoryObservation Table Using #SocialHistory Table is Done............")

    //Update PatientSocialHistoryObservationMappingPracticeCommonData_Prod
    val update_CacheSocialHistory = PatientSocialHistoryObservation_Prod.as("df1").join(cleanedCacheSocialHistory.as("df2")
      ,$"df1.PatientSocialHistoryObservationUid" === $"df2.PatientSocialHistoryObservationUid").filter($"df2.StatusId" === 1)
      .select($"df1.*",$"df2.SocialHistoryObservedValue".as("aliasobValue"),$"df2.SocialHistoryStatusUid"
        .as("aliasSTSUid"),$"df2.EffectiveStopDate".as("aliasPHSUid") ,$"df2.SocialHistoryTypecode".as("aliasPHSUid"),$"df2.EffectiveStartDate".as("aliasPHSUid"),$"df2.Documentationdate".as("aliasPHSUid"))
      .withColumn("SocialHistoryObservedValue",$"aliasobValue")
      .withColumn("MasterSocialHistoryStatusUid",$"aliasEPTCUid")
      .withColumn("EffectiveEndDate",$"aliasEPTSCUid")
      .withColumn("SocialHistoryTypecode",$"aliasobValue")
      .withColumn("EffectiveStartDate",$"aliasEPTCUid")
      .withColumn("Documentationdate",$"aliasEPTSCUid")
      .withColumn("ModifiedDate",current_timestamp())
      .drop("aliasobValue","aliasEPTCUid","aliasEPTSCUid","aliasobValue","aliasEPTCUid","aliasEPTSCUid")

    val where_social = PatientSocialHistoryObservation_Prod.as("df1").join(cleanedCacheSocialHistory.as("df2")
      ,$"df1.PatientSocialHistoryObservationUid" === $"df2.PatientSocialHistoryObservationUid").filter($"df2.StatusId" === 1)
      .select($"df1.*")

    val ex_Social = PatientSocialHistoryObservation_Prod.except(where_social)
    var PatientSocialHistoryObservation_Prod_Delta = ex_Social.union(update_CacheSocialHistory)


    logger.warn("Update PatientSocialHistoryObservation Table is Done......")

    //Insert Data Into PatientSocialHistoryObservation
    val insert_CacheSocialHistory = cleanedCacheSocialHistory.as("df1").join(PatientSocialHistoryObservation_Prod_Delta.as("df2")
      ,$"df1.PatientSocialHistoryObservationUid" === $"df2.PatientSocialHistoryObservationUid","left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.PatientSocialHistoryObservationUid".isNull)
      .select($"df1.PatientSocialHistoryObservationUid",$"df1.SocialHistoryTypeText",$"df1.PatientUid"
        ,$"df1.SocialHistoryTypeUid",$"df1.Documentationdate"
        ,$"df1.EffectiveStopDate",$"df1.SocialHistoryStatusUid",$"df1.YearsSmoked",$"df1.QuitYear",$"df1.SocialHxGroup",$"df1.SocialHistoryTypecode", $"df1.EffectiveStartDate")

    val allcols = PatientSocialHistoryObservation_Prod_Delta.columns.toSet
    val insertcols = insert_CacheSocialHistory.columns.toSet
    val tot3 = allcols ++ insertcols

    PatientSocialHistoryObservation_Prod_Delta = PatientSocialHistoryObservation_Prod_Delta.select(FunctionUtility.addColumns(allcols, tot3): _*)
      .union(insert_CacheSocialHistory.select(FunctionUtility.addColumns(insertcols, tot3): _*))
    logger.warn("Insert Data Into PatientSocialHistoryObservation is Done......")

    //End CacheSocialHistoryObservation Sp..........................................



    List(PatientSocialHistoryObservation_Prod_Delta)
  }

}
