package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions.{col, current_date, date_add, upper}
class LoadCrossWalk {

  def LoadUpdateCrossWalkFunc(spark : SparkSession, clinicaldatarepository : DataFrame, practice : DataFrame
                              , MappingPracticeCommonData_Prod : DataFrame
                              , MappingPracticeProblem_Prod : DataFrame, MappingPracticeProblem : DataFrame
                              ,MappingPracticeMedication_Prod : DataFrame,MappingPracticeMedication : DataFrame
                              ,MappingPracticeProcedure_Prod : DataFrame,MappingPracticeProcedureTable : DataFrame
                              ,MappingPracticeLabResult_Prod : DataFrame,MappingPracticeLabResult : DataFrame
                              ,MappingPracticeCommonData : DataFrame
                              ,MappingPracticeAllergy : DataFrame,MappingPracticeAllergy_Prod : DataFrame) :List[DataFrame] = {

    //LoadUpdatedCrosswalkCdrWise

    val logger = LoggerFactory.getLogger("")

    import spark.implicits._

   /* val cacheFile = spark.read.option("delimiter", "\u0017")
      .csv("s3n://bd-dev/aao_test/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/edea6658-b815-466d-aeea-17a9dd575dd1_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")
*/
    val cacheFile = spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/edea6658-b815-466d-aeea-17a9dd575dd1_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")
    val lookup = Map("_c0" -> "PatientId", "_c1" -> "LastName", "_c2" -> "FirstName", "_c3" -> "MiddleName", "_c4" -> "StreetLineAddress1"
      , "_c5" -> "StreetLineAddress2", "_c6" -> "StreetLineAddress3", "_c7" -> "StreetLineAddress4", "_c8" -> "City", "_c9" -> "StateCode"
      , "_c10" -> "State", "_c11" -> "ZipCode", "_c12" -> "CountryCode", "_c13" -> "Country", "_c14" -> "TelecomTypeText1"
      , "_c15" -> "TelecomValue1", "_c16" -> "TelecomTypeText2", "_c17" -> "TelecomValue2", "_c18" -> "Gender", "_c19" -> "DOB"
      , "_c20" -> "DeathDate", "_c21" -> "MaritalStatusCode", "_c22" -> "MaritalStatusText", "_c23" -> "ReligiousAffiliationCode"
      , "_c24" -> "ReligiousAffiliationText", "_c25" -> "BirthStateCode", "_c26" -> "BirthState", "_c27" -> "BirthZipCode"
      , "_c28" -> "BirthCountryCode", "_c29" -> "BirthCountry", "_c30" -> "ServiceProviderNPI", "_c31" -> "ServiceProviderLastName"
      , "_c32" -> "ServiceProviderFirstName", "_c33" -> "SSN", "_c34" -> "DeathReason", "_c35" -> "IsDeceased", "_c36" -> "Patient_EMR_ID"
      , "_c37" -> "EmailID", "_c38" -> "LocationOfDeath", "_c39" -> "BirthOrder", "_c40" -> "MultipleBirthPlaceIndicator"
      , "_c41" -> "PatientDemographicsKey", "_c42" -> "PracticeUid", "_c43" -> "BatchUid", "_c44" -> "dummy1", "_c45" -> "dummy2")

    var CachepatientDemo = cacheFile.select(cacheFile.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)
    val temp_prac = CachepatientDemo.withColumn("PracticeUid", upper($"PracticeUid")).select($"PracticeUid").distinct()

    val dbname = "FIGMDHQICDR_81"

    val temp1 = clinicaldatarepository.filter(clinicaldatarepository("DatabaseName").equalTo(dbname))
      .join(practice, clinicaldatarepository("clinicaldatarepositoryuid") ===
        practice("clinicaldatarepositoryuid"))
      .join(temp_prac, temp_prac("PracticeUid") === practice("PracticeUid"))
      .distinct
      .select(practice("PracticeUid"))

    //MappingPracticeCommonData
    val mapping_uniq_id = MappingPracticeCommonData_Prod.select("PracticeUid").distinct

    val modified = MappingPracticeCommonData.as("df1")
      .join(temp1, MappingPracticeCommonData("PracticeUid") === temp1("PracticeUid")
      , "inner")
      .select(MappingPracticeCommonData("*"))
      .join(mapping_uniq_id, MappingPracticeCommonData("PracticeUid") === mapping_uniq_id("PracticeUid"), "left_outer")
      .filter(mapping_uniq_id("PracticeUid").isNull || ($"CreatedDate" >= date_add(current_date(), -14)
        || $"ModifiedDate" >= date_add(current_date(), -14)))
      .select(MappingPracticeCommonData("PracticeUid")).distinct()

    //delete from m from  dbo.[MappingPracticeCommonData] m inner join  #Modified t
    //        on m.practiceuid=t.practiceuid  (NOT Implement)

    val insert_data = MappingPracticeCommonData.alias("df1")
      .join(modified, MappingPracticeCommonData("PracticeUid") === modified("PracticeUid"))
      .select("df1.*")

    val MappingPracticeCommonData_Prod1 = MappingPracticeCommonData_Prod.unionAll(insert_data)

    //MappingPracticeProblem
    val mapping_uniq_id_Prob = MappingPracticeProblem_Prod.select("PracticeUid").distinct

    val tempProblem = MappingPracticeProblem.as("df1").join(temp1.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
      , "inner").select($"df1.*")
      .join(mapping_uniq_id_Prob.as("df3"), $"df1.PracticeUid" === $"df3.PracticeUid", "left_outer")
      .filter($"df3.PracticeUid".isNull || ($"CreatedDate" >= date_add(current_date(), -14)
        || $"ModifiedDate" >= date_add(current_date(), -14)))
      .select($"df1.PracticeUid").distinct()

    //delete from m  from dbo.[MappingPracticeProblem] m inner join  #Problem t
    // on m.practiceuid=t.practiceuid

    val insert_data_MappingProblem = MappingPracticeProblem.alias("df1")
      .join(tempProblem.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid")
      .select("df1.*")

    val MappingPracticeProblem_Prod1 = MappingPracticeProblem_Prod.union(insert_data_MappingProblem)

    logger.warn("MappingPracticeProblem is create............")

    //MappingPracticeMedication
    val mapping_uniq_id_Medic = MappingPracticeMedication_Prod.select("PracticeUid").distinct

    val tempMedications = MappingPracticeMedication.as("df1").join(temp1.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
      , "inner").select($"df1.*")
      .join(mapping_uniq_id_Medic.as("df3"), $"df1.PracticeUid" === $"df3.PracticeUid", "left_outer")
      .filter($"df3.PracticeUid".isNull || ($"CreatedDate" >= date_add(current_date(), -14)
        || $"ModifiedDate" >= date_add(current_date(), -14)))
      .select($"df1.PracticeUid").distinct()

    // delete from m  from  dbo.[MappingPracticeMedication] m inner join #medication t
    //on m.practiceuid=t.practiceuid
    val insert_data_MappingMedications = MappingPracticeMedication.alias("df1")
      .join(tempMedications.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid")
      .select("df1.*")

    val MappingPracticeMedication_Prod1 = MappingPracticeMedication_Prod.union(insert_data_MappingMedications)

    logger.warn("MappingPracticeMedication is create............")

    //MappingPracticeProcedure
    val mapping_uniq_id_PracPro = MappingPracticeProcedure_Prod.select("PracticeUid").distinct

    val tempProcedure = MappingPracticeProcedureTable.as("df1").join(temp1.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
      , "inner").select($"df1.*")
      .join(mapping_uniq_id_PracPro.as("df3"), $"df1.PracticeUid" === $"df3.PracticeUid", "left_outer")
      .filter($"df3.PracticeUid".isNull || ($"CreatedDate" >= date_add(current_date(), -14)
        || $"ModifiedDate" >= date_add(current_date(), -14)))
      .select($"df1.PracticeUid").distinct()

    //delete from m  from dbo.[MappingPracticeProcedure] m  inner join  #Procedure t
    //on m.practiceuid=t.practiceuid

    val insert_data_MappingProcedure = MappingPracticeProcedureTable.alias("df1")
      .join(tempProcedure.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid")
      .select("df1.*")

    val MappingPracticeProcedure_Prod1 = MappingPracticeProcedure_Prod.union(insert_data_MappingProcedure)

    logger.warn("MappingPracticeProcedure is create............")

    //MappingPracticeLabResult
    val mapping_uniq_id_Result = MappingPracticeLabResult_Prod.select("PracticeUid").distinct

    val tempMResult = MappingPracticeLabResult.as("df1").join(temp1.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
      , "inner").select($"df1.*")
      .join(mapping_uniq_id_Result.as("df3"), $"df1.PracticeUid" === $"df3.PracticeUid", "left_outer")
      .filter($"df3.PracticeUid".isNull || ($"CreatedDate" >= date_add(current_date(), -14)
        || $"ModifiedDate" >= date_add(current_date(), -14)))
      .select($"df1.PracticeUid").distinct()

    //delete from m from  dbo.[MappingPracticeLabResult] m  inner join  #ModifiedLabResult t
    //on m.practiceuid=t.practiceuid

    val insert_data_MappingResult = MappingPracticeLabResult.alias("df1")
      .join(tempMResult.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid")
      .select("df1.*")


    val MappingPracticeLabResult_Prod1 = MappingPracticeLabResult_Prod.union(insert_data_MappingResult)

    logger.warn("MappingPracticeLabResult is create............")


    val Mapping_Aller_Id = MappingPracticeAllergy_Prod.select("PracticeUid").distinct

    val tempAResult = MappingPracticeAllergy.as("df1").join(temp1.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
      , "inner").select($"df1.*")
      .join(Mapping_Aller_Id.as("df3"), $"df1.PracticeUid" === $"df3.PracticeUid", "left_outer")
      .filter($"df3.PracticeUid".isNull || ($"CreatedDate" >= date_add(current_date(), -14)
        || $"ModifiedDate" >= date_add(current_date(), -14)))
      .select($"df1.PracticeUid").distinct()

    val insert_data_MappingAllergy = MappingPracticeAllergy.alias("df1")
      .join(tempAResult.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid")
      .select("df1.*")

    val MappingPracticeAllergy_Prod1 = MappingPracticeAllergy_Prod.union(insert_data_MappingAllergy)

    println("Load CrossWalk Is Done...........................")

    List(MappingPracticeCommonData_Prod1,MappingPracticeProblem_Prod1,MappingPracticeMedication_Prod1
      ,MappingPracticeProcedure_Prod1,MappingPracticeLabResult_Prod1,MappingPracticeAllergy_Prod1)

  }


}
