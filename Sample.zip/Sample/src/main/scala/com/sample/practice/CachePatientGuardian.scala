package com.sample.practice

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

class CachePatientGuardian {

  def CachePatientGuardianFunc(spark : SparkSession,MergePracticeMap : DataFrame
                               ,CDRPatientCrosswalkTable : DataFrame
                               ,PatientGuardian_Prod : DataFrame
                               ,MasterCity_prod : DataFrame
                               ,MasterPostalCode_prod : DataFrame
                               ,MasterCityPostalCode_prod : DataFrame
                               ,MasterStatePostalCode_Prod : DataFrame
                               ,MasterRelationship_Prod : DataFrame
                               ,Patient_Prod_Delta : DataFrame
                               ,Individual_prod_Delta6 : DataFrame
                               ,MappingPracticeCommonData_Delta : DataFrame
                               ,Address_Prod_Delta2 : DataFrame
                               ,Phone_Prod : DataFrame
                               ,PatientProblem_Prod_Delta : DataFrame
                               , MasterPhoneType_prod : DataFrame) : List[DataFrame] = {
    val logger = LoggerFactory.getLogger("")

    import spark.implicits._
    //Start CachePatientGuardian
    var CachePatientGuardian = spark.read.option("delimiter", "\u0017")
      .csv("/home/ravikant.petkar/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/608cdee4-97d1-42a2-849d-9d9a95bc5131_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")

    val lookupCachePatientGuardian = Map("_c0" -> "PatientId", "_c1" -> "GuardianLastName", "_c2" -> "GuardianFirstName"
      , "_c3" -> "StreetLineAddress1", "_c4" -> "StreetLineAddress2", "_c5" -> "StreetLineAddress3"
      , "_c6" -> "StreetLineAddress4", "_c7" -> "City"
      , "_c8" -> "StateCode", "_c9" -> "State", "_c10" -> "ZipCode"
      , "_c11" -> "CountryCode", "_c12" -> "Country", "_c13" -> "TelecomTypeText"
      , "_c14" -> "TelecomValue", "_c15" -> "RelationshipToPatientCode", "_c16" -> "RelationshipToPatientText"
      , "_c17" -> "PatientGuardianKey", "_c18" -> "PracticeUid", "_c19" -> "BatchUid"
      , "_c20" -> "BatchUid", "_c21" -> "dummy1"
      , "_c22" -> "dummy2")

    CachePatientGuardian = CachePatientGuardian.select(CachePatientGuardian.columns.map(c => col(c).as(lookupCachePatientGuardian.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    val tempCachePatientGuardian = spark.read.option("header", "true")
      .csv("/home/ravikant.petkar/AAO_DATA/Schema/CachePatientGuardian")

    val CachePatientGuardiancols = tempCachePatientGuardian.columns.toSet
    val CachePatientGuardianViewcols = CachePatientGuardian.columns.toSet
    val tot_viewCachePatientGuardian = CachePatientGuardiancols ++ CachePatientGuardianViewcols

    CachePatientGuardian = tempCachePatientGuardian.select(FunctionUtility.addColumns(CachePatientGuardiancols, tot_viewCachePatientGuardian): _*)
      .union(CachePatientGuardian.select(FunctionUtility.addColumns(CachePatientGuardianViewcols, tot_viewCachePatientGuardian): _*))

    CachePatientGuardian = CachePatientGuardian.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    //Distinct PracticeUid of CacheEncounterDiagnosis
    val dist_PrctUid_CachePatientGuardian = CachePatientGuardian.filter($"StatusId".isNull).select("PracticeUid").distinct()

    val tempMergePracticeMap_CachePatientGuardian = MergePracticeMap.as("df1").join(dist_PrctUid_CachePatientGuardian.as("df2")
      , $"df1.NewPracticeuid" === $"df2.PracticeUid").select($"df1.*")

    //Update PracticeUid with OriginalPracticeuid of CachePatientGuardian
    CachePatientGuardian = CachePatientGuardian.as("df1").join(tempMergePracticeMap_CachePatientGuardian.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeuid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeuid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeuid of CachePatientGuardian is Done.............................")

    CachePatientGuardian = CachePatientGuardian.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CachePatientGuardian
    CachePatientGuardian = CachePatientGuardian.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PatientId", rtrim(ltrim($"df1.PatientId")))
      .withColumn("ZipCode", rtrim(ltrim($"df1.ZipCode")))

    logger.warn("Update Multiple Columns of CachePatientGuardian is Done............")

    //Update Multiple Status Of CachePatientGuardian
    val update_Status_CachePatientGuardian = CachePatientGuardian.filter($"StatusId" === 1 && $"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val where_Status_CachePatientGuardian = CachePatientGuardian.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_Status_CachePatientGuardian.count > 0) {
      val ex = CachePatientGuardian.except(where_Status_CachePatientGuardian)
      CachePatientGuardian = ex.union(update_Status_CachePatientGuardian)
    }

    logger.warn("Update Multiple Status Of CachePatientGuardian is Done............")

    //Update PatientId using CDRPatientCrosswalk In CachePatientGuardian Table
    val updatePatientIdCachePatientGuardian = CachePatientGuardian.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientIdCachePatientGuardian = CachePatientGuardian.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientIdCachePatientGuardian.count > 0) {
      val ex = CachePatientGuardian.except(where_PatientIdCachePatientGuardian)
      CachePatientGuardian = ex.union(updatePatientIdCachePatientGuardian)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk In CachePatientGuardian Table is Done............")

    //Update PatientUid Of CachePatientGuardian using Individual and Patient table

    val update_Status_CachePatientGuardian1 = CachePatientGuardian.filter($"StatusId" === 1 && $"GuardianFirstName".isNull || $"GuardianLastName".isNull )
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("GuardianName Not Found"))

    val where_Status_CachePatientGuardian1 = CachePatientGuardian.filter($"StatusId" === 1 && $"GuardianFirstName".isNull || $"GuardianLastName".isNull)

    if (where_Status_CachePatientGuardian1.count > 0) {
      val ex = CachePatientGuardian.except(where_Status_CachePatientGuardian1)
      CachePatientGuardian = ex.union(update_Status_CachePatientGuardian1)
    }

    val update_PatientUid_CachePatientGuardian = CachePatientGuardian.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta6.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1 && $"df1.PatientUid"isNull)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val update_Status_CachePatientGuardian2 = CachePatientGuardian.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_Status_CachePatientGuardian2 = CachePatientGuardian.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_Status_CachePatientGuardian2.count > 0) {
      val ex = CachePatientGuardian.except(where_Status_CachePatientGuardian2)
      CachePatientGuardian = ex.union(update_Status_CachePatientGuardian2)
    }

    logger.warn("Update PatientUid Of CachePatientGuardian using Individual and Patient table is Done............")

    //Remove Duplicates of CachePatientGuardian

    var cleanedCachePatientGuardian = CachePatientGuardian.filter($"StatusId" === 1)
      .dropDuplicates(Seq("PatientUid", "PracticeUid", "GuardianFirstName", "GuardianLastName"))

    var duplicatesRecordsCachePatientGuardian1 = CachePatientGuardian.except(cleanedCachePatientGuardian)

    logger.warn("Remove Duplicates of CachePatientGuardian is Done............")

    //Update PatientGuardianUid of CachePatientGuardian using PatientGuardian_Prod table
    val update_PatientGuardianUid_CachePatientGuardian = cleanedCachePatientGuardian.as("df1").join(PatientGuardian_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.GuardianFirstName" === $"df2.GuardianFirstName" && $"df1.GuardianLastName" === $"df2.GuardianLastName")
      .filter($"df1.StatusId" === 1 && $"df1.PatientGuardianUid".isNull)
      .select($"df1.*", $"df2.PatientGuardianUid".as("aliasPatientProblemUid"), $"df2.addressuid".as("aliasPatientAddressUid"), $"df2.PhoneUid".as("aliasPatientPhoneUid"))
      .withColumn("PatientGuardianUid", $"aliasPatientProblemUid").withColumn("AddressUid", $"aliasPatientAddressUid").withColumn("Phone1Uid", $"aliasPatientPhoneUid")
      .drop("aliasPatientProblemUid").drop("aliasPatientAddressUid").drop("aliasPatientPhoneUid")

    val where_PatientGuardianUid_CachePatientGuardian = cleanedCachePatientGuardian.as("df1").join(PatientProblem_Prod_Delta.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.GuardianFirstName" === $"df2.GuardianFirstName" && $"df1.GuardianLastName" === $"df2.GuardianLastName")
      .filter($"df1.StatusId" === 1 && $"df1.PatientGuardianUid".isNull)
      .select($"df1.*")

    if (where_PatientGuardianUid_CachePatientGuardian.count > 0) {
      val ex = cleanedCachePatientGuardian.except(where_PatientGuardianUid_CachePatientGuardian)
      cleanedCachePatientGuardian = ex.union(update_PatientGuardianUid_CachePatientGuardian)
    }

    logger.warn("Update PatientGuardianUid of CachePatientGuardian using PatientProblem_Prod table is Done............")

    //create #PatientPatientGuardian

    val tempPatientPatientGuardian = cleanedCachePatientGuardian.filter($"StatusId" === 1 && $"PatientGuardianUid".isNull && $"GuardianFirstName".isNull && $"GuardianLastName".isNull)
      .select("PatientUid", "PracticeUid", "GuardianFirstName", "GuardianLastName").distinct()
      .withColumn("PatientGuardianUid", FunctionUtility.getNewUid())

    //Update New PatientGuardianUid of CachePatientGuardian Table Using #PatientPatientGuardian Table

    val update_PatientGUid_CachePatientGuardian = cleanedCachePatientGuardian.as("df1").join(tempPatientPatientGuardian.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.GuardianFirstName" === $"df2.GuardianFirstName"
        && $"df1.GuardianLastName" === $"df2.GuardianLastName")
      .filter($"df1.StatusId" === 1 && $"df1.PatientGuardianUid".isNull)
      .select($"df1.*", $"df2.PatientGuardianUid".as("aliasPatientGuardianUid"), $"df2.AddressUid".as("aliasAddressUid"), $"df2.Phone1Uid".as("aliasPhone1Uid"))
      .withColumn("PatientGuardianUid", $"aliasPatientGuardianUid")
      .withColumn("AddressUid", $"aliasAddressUid")
      .withColumn("Phone1Uid", $"aliasPhone1Uid")
      .drop("aliasPatientGuardianUid")
      .drop("aliasAddressUid")
      .drop("aliasPhone1Uid")

    val where_PatientGUid_CachePatientGuardian = cleanedCachePatientGuardian.as("df1").join(tempPatientPatientGuardian.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.GuardianFirstName" === $"df2.GuardianFirstName"
        && $"df1.GuardianLastName" === $"df2.GuardianLastName")
      .filter($"df1.StatusId" === 1 && $"df1.PatientGuardianUid".isNull)
      .select($"df1.*")

    if (where_PatientGUid_CachePatientGuardian.count > 0) {
      val ex = cleanedCachePatientGuardian.except(where_PatientGUid_CachePatientGuardian)
      cleanedCachePatientGuardian = ex.union(update_PatientGUid_CachePatientGuardian)
    }
    logger.warn("Update New PatientGuardianUid of CachePatientGuardian Table Using #PatientPatientGuardian Table is Done............")

    //update City from MappingPracticeCommonData of CachePatientGuardian
    val update_City = cleanedCachePatientGuardian.as("df1").join(MasterCity_prod.as("df2")
      , $"df1.City" === $"df2.Name").join(MasterPostalCode_prod.as("df3"),
      (rtrim(ltrim($"df1.ZipCode"))) === $"df3.Code").join(MasterCityPostalCode_prod.as("df4"), $"df4.PostalCodeUid" === $"df1.PostalCodeUid")
      .where($"df1.StatusId" === 1 && $"df1.CityUid".isNull)
      .select($"df1.*", $"df2.CityUid".as("aliasCityUid"), $"df3.CityUid".as("aliasCityUid"))
      .withColumn("CityUid", $"aliasCityUid")
      .drop("aliasCityUid")

    val where_City = cleanedCachePatientGuardian.as("df1").join(MasterCity_prod.as("df2")
      , $"df1.City" === $"df2.Name").join(MasterPostalCode_prod.as("df3"),
      (rtrim(ltrim($"df1.ZipCode"))) === $"df3.Code").join(MasterCityPostalCode_prod.as("df4"), $"df4.PostalCodeUid" === $"df1.PostalCodeUid")
      .where($"df1.StatusId" === 1 && $"df1.CityUid".isNull)
      .select($"df1.*")

    if (where_City.count > 0) {
      val ex = cleanedCachePatientGuardian.except(where_City)
      cleanedCachePatientGuardian = ex.union(update_City)
    }
    logger.warn("update City from MappingPracticeCommonData of CachePatientGuardian is Done......")

    //update PostalCode from MappingPracticeCommonData of CachePatientGuardian
    val update_PostalCode = cleanedCachePatientGuardian.as("df1").join(MasterPostalCode_prod.as("df2")
      , (rtrim(ltrim($"df1.ZipCode"))) === $"df2.Code")
      .where($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PostalCodeUid".as("aliasPostalCodeUid"))
      .withColumn("PostalCodeUid", $"aliasPostalCodeUid")
      .drop("aliasPostalCodeUid")

    val where_PostalCode = cleanedCachePatientGuardian.as("df1").join(MasterPostalCode_prod.as("df2")
      , (rtrim(ltrim($"df1.ZipCode"))) === $"df2.Code")
      .where($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PostalCode.count > 0) {
      val ex = cleanedCachePatientGuardian.except(where_PostalCode)
      cleanedCachePatientGuardian = ex.union(update_PostalCode)
    }
    logger.warn("update PostalCode from MappingPracticeCommonData of CachePatientGuardian is Done......")

    //update State from MappingPracticeCommonData of CachePatientGuardian
    val update_State = cleanedCachePatientGuardian.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.StateCode" === $"df2.PracticeValue" || $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "154025B1-8903-4F3D-832C-7C2CF429C52C")
      .where($"df1.StatusId" === 1 && $"df1.StateUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("StateUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_State = cleanedCachePatientGuardian.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.StateCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "154025B1-8903-4F3D-832C-7C2CF429C52C")
      .where($"df1.StatusId" === 1 && $"df1.StateUid".isNull)
      .select($"df1.*")

    if (where_State.count > 0) {
      val ex = cleanedCachePatientGuardian.except(where_State)
      cleanedCachePatientGuardian = ex.union(update_State)
    }
    logger.warn("update State from MappingPracticeCommonData of CachePatientGuardian is Done......")

    //update State from MappingPracticeCommonData of CachePatientGuardian 2
    val update_State2 = cleanedCachePatientGuardian.as("df1").join(MasterStatePostalCode_Prod.as("df2")
      , $"df1.State" === $"df2.Name")
      .where($"df1.StatusId" === 1 && $"df1.StateUid".isNull)
      .select($"df1.*", $"df2.StateUid".as("aliasStateUid"))
      .withColumn("StateUid", $"aliasStateUid")
      .drop("aliasStateUid")

    val where_State2 = cleanedCachePatientGuardian.as("df1").join(MasterStatePostalCode_Prod.as("df2")
      , $"df1.State" === $"df2.Name")
      .where($"df1.StatusId" === 1 && $"df1.StateUid".isNull)
      .select($"df1.*")

    if (where_State2.count > 0) {
      val ex = cleanedCachePatientGuardian.except(where_State2)
      cleanedCachePatientGuardian = ex.union(update_State2)
    }
    logger.warn("update State from MappingPracticeCommonData of CachePatientGuardian 2 is Done......")

    //update Country from MappingPracticeCommonData of CachePatientGuardian
    val update_Country = cleanedCachePatientGuardian.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.CountryCode" === $"df2.PracticeValue" || $"df1.Country" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.MapperMasterCollectionUid" === "7FEB9A0B-CD52-4B9A-881B-6946D5A7F486")
      .where($"df1.StatusId" === 1 && $"df1.CountryUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("CountryUid", $"aliasCountryUid")
      .drop("aliasCountryUid")

    val where_Country = cleanedCachePatientGuardian.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.CountryCode" === $"df2.PracticeValue" || $"df1.Country" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.MapperMasterCollectionUid" === "7FEB9A0B-CD52-4B9A-881B-6946D5A7F486")
      .where($"df1.StatusId" === 1 && $"df1.CountryUid".isNull)
      .select($"df1.*")

    if (where_Country.count > 0) {
      val ex = cleanedCachePatientGuardian.except(where_Country)
      cleanedCachePatientGuardian = ex.union(update_Country)
    }
    logger.warn("update Country from MappingPracticeCommonData of CachePatientGuardian is Done......")

    //update PhoneTypeUid from MappingPracticeCommonData of CachePatientGuardian
    val update_PhoneTypeUid = cleanedCachePatientGuardian.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.TelecomTypeText" === $"df2.PracticeValue" || $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.MapperMasterCollectionUid" === "F00492A3-0372-4925-B0B8-7E11D3D2E340")
      .where($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("PhoneTypeUid", $"aliasPhoneTypeUid")
      .drop("aliasPhoneTypeUid")

    val where_PhoneTypeUid = cleanedCachePatientGuardian.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.TelecomTypeText" === $"df2.PracticeValue" || $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.MapperMasterCollectionUid" === "F00492A3-0372-4925-B0B8-7E11D3D2E340")
      .where($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PhoneTypeUid.count > 0) {
      val ex = cleanedCachePatientGuardian.except(where_PhoneTypeUid)
      cleanedCachePatientGuardian = ex.union(update_PhoneTypeUid)
    }
    logger.warn("update PhoneTypeUid from MappingPracticeCommonData of CachePatientGuardian is Done......")

    //update PhoneTypeUid from MasterPhoneType of CachePatientGuardian
    val update_PhoneTypeUid2 = cleanedCachePatientGuardian.as("df1").join(MasterPhoneType_prod .as("df2")
      ,$"df1.TelecomTypeText" === $"df2.Description")
      .where($"df1.StatusId" === 1 && $"df1.PhoneTypeUid".isNull)
      .select($"df1.*", $"df2.PhoneTypeUid".as("aliasPhoneTypeUid"))
      .withColumn("PhoneTypeUid", $"aliasPhoneTypeUid")
      .drop("aliasPhoneTypeUid")

    val where_PhoneTypeUid2 = cleanedCachePatientGuardian.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.TelecomTypeText" === $"df2.Description")
      .where($"df1.StatusId" === 1 && $"df1.PhoneTypeUid".isNull)
      .select($"df1.*")

    if (where_PhoneTypeUid2.count > 0) {
      val ex = cleanedCachePatientGuardian.except(where_PhoneTypeUid2)
      cleanedCachePatientGuardian = ex.union(update_PhoneTypeUid2)
    }
    logger.warn("update PhoneTypeUid from MasterPhoneType of CachePatientGuardian is Done......")

    //Update Status if PhoneTypeUid is not Null  Of CachePatientGuardian table
    val update_Status_CachePatientGuardian3234 = cleanedCachePatientGuardian.filter($"StatusId" === 1
      && rtrim(ltrim($"TelecomTypeText")) && $"df1.PhoneTypeUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ErrorNote", lit("Telecom Type 1 Not Mapped"))

    val whereStatus_CachePatientGuardian3234 = cleanedCachePatientGuardian.filter($"StatusId" === 1
      && rtrim(ltrim($"TelecomTypeText")) && $"df1.PhoneTypeUid".isNull)

    if (whereStatus_CachePatientGuardian3234.count > 0) {
      val ex = cleanedCachePatientGuardian.except(whereStatus_CachePatientGuardian3234)
      cleanedCachePatientGuardian = ex.union(update_Status_CachePatientGuardian3234)
    }
    logger.warn("Update Status if PhoneTypeUid is not Null Of CachePatientGuardian table is Done............")

    //Update Address Table CachePatientGuardian
    val update_Address_Table_CachePatientGuardian = Address_Prod_Delta2.as("df2").join(cleanedCachePatientGuardian.as("df1")
      ,$"df1.AddressUid" === $"df2.AddressUid").filter($"df2.StatusId" === 1)
      .select($"df2.*",$"df1.Line1".as("aliasLine1"),$"df1.ProblemTypeCodeUid"
        .as("aliasEPTCUid"),$"df1.ProblemHealthStatusUid".as("aliasPHSUid"),$"df1.Line2".as("aliasLine2"),
        $"df1.Line3".as("aliasLine3"),$"df1.Line4".as("aliasLine4"), $"df1.CityUid".as("aliasCityUid"),
        $"df1.StateUid".as("aliasStateUid"),$"df1.PostalCodeUid".as("aliasPostalCodeUid"), $"df1.CountryUid".as("aliasCountryUid"))
      .withColumn("StreetLineAddress1",$"aliasStreetLineAddress1")
      .withColumn("StreetLineAddress2",$"aliasStreetLineAddress2")
      .withColumn("StreetLineAddress3",$"aliasStreetLineAddress3")
      .withColumn("StreetLineAddress4",$"aliasStreetLineAddress4")
      .withColumn("CityUid",$"aliasCityUid")
      .withColumn("StateUid",$"aliasStateUid")
      .withColumn("PostalCodeUid",$"aliasPostalCodeUid")
      .withColumn("CountryUid",$"aliasCountryUid")
      .withColumn("ModifiedDate",current_timestamp())

    val where_Address = Address_Prod_Delta2.as("df2").join(cleanedCachePatientGuardian.as("df1")
      ,$"df1.AddressUid" === $"df2.AddressUid").filter($"df2.StatusId" === 1)
      .select($"df2.*")

    val ex_Address = Address_Prod_Delta2.except(where_Address)
    var Address_Prod_Delta3 = ex_Address.union(update_Address_Table_CachePatientGuardian)

    //Where and union

    logger.warn("Update Address Table CachePatientGuardian Table 2 is Done......")

    //Insert Data into Address Table using CachePatientGuardian
    val insert_Data_Address_Table = cleanedCachePatientGuardian.as("df1").join(Address_Prod_Delta3.as("df2")
      ,$"df1.AddressUid" === $"df2.AddressUid","left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.AddressUid".isNull)
      .select($"df1.AddressUid",$"df1.CityUid",$"df1.StateUid"
        ,$"df1.PostalCodeUid",$"df1.CountryUid".as("MasterProblemTypeUid"))

    val allcols1 = Address_Prod_Delta3.columns.toSet
    val insertcols1 = insert_Data_Address_Table.columns.toSet
    val tot1 = allcols1 ++ insertcols1

    Address_Prod_Delta3 = Address_Prod_Delta3.select(FunctionUtility.addColumns(allcols1, tot1): _*)
      .union(insert_Data_Address_Table.select(FunctionUtility.addColumns(insertcols1, tot1): _*))

    logger.warn("Insert Data into Address Table using CachePatientGuardian......")


    //Update Phone Table CachePatientGuardian
    val update_Phone_Table_CachePatientGuardian = Phone_Prod.as("df2").join(cleanedCachePatientGuardian.as("df1")
      ,$"df2.Phone1Uid" === $"df1.Phone1Uid").filter($"df2.StatusId" === 1)
      .select($"df2.*",$"df1.PhoneNo".as("aliasPhoneNo"),$"df1.PhoneTypeUid"
        .as("aliasPhoneTypeUid"))
      .withColumn("TelecomValue",$"aliasTelecomValue")
      .withColumn("PhoneTypeUid",$"aliasPhoneTypeUid")
      .withColumn("ModifiedDate",current_timestamp())

    val where_phone = Phone_Prod.as("df2").join(cleanedCachePatientGuardian.as("df1")
      ,$"df2.Phone1Uid" === $"df1.Phone1Uid").filter($"df2.StatusId" === 1)
      .select($"df2.*")

    val ex_Phone = Phone_Prod.except(where_phone)
    var Phone_Prod_Delta = ex_Phone.union(update_Phone_Table_CachePatientGuardian)

    logger.warn("Update Phone Table CachePatientGuardian Table 2 is Done......")


    //update CachePatientGuardian using Phone table
    val update_CachePatientGuardian_Phone = cleanedCachePatientGuardian.as("df1").join(Phone_Prod_Delta.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.Practiceuid" === $"df2.Practiceuid"
        && $"df1.TelecomValue" === $"df2.TelecomValue" && $"df1.PhoneTypeUid" === $"df2.PhoneTypeUid")
      .where($"df1.StatusId" === 1 && $"df1Phone1Uid".isNull)
      .select($"df1.*", $"df2.Phone1Uid".as("aliasPhone1Uid"))
      .withColumn("Phone1Uid", $"aliasPhone1Uid")
      .drop("aliasPhone1Uid")

    val where_CachePatientGuardian_Phone = cleanedCachePatientGuardian.as("df1").join(Phone_Prod_Delta.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.Practiceuid" === $"df2.Practiceuid"
        && $"df1.TelecomValue" === $"df2.TelecomValue" && $"df1.PhoneTypeUid" === $"df2.PhoneTypeUid")
      .where($"df1.StatusId" === 1 && $"df1Phone1Uid".isNull)
      .select($"df1.*")

    if (where_CachePatientGuardian_Phone.count > 0) {
      val ex = cleanedCachePatientGuardian.except(where_CachePatientGuardian_Phone)
      cleanedCachePatientGuardian = ex.union(update_CachePatientGuardian_Phone)
    }
    logger.warn("update CachePatientGuardian using Phone table is Done......")

    //Insert Data into Phone Table using CachePatientGuardian
    val insert_Data_Phone_Table = cleanedCachePatientGuardian.as("df1").join(Phone_Prod_Delta.as("df2")
      ,$"df1.Phone1Uid" === $"df2.PhoneUid","left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.PhoneUid".isNull && $"df1.Phone1Uid".isNotNull)
      .select($"df1.Phone1Uid",$"df1.TelecomValue",$"df1.PhoneTypeUid").distinct()
    val allcols2 = Phone_Prod_Delta.columns.toSet
    val insertcols2 = insert_Data_Phone_Table.columns.toSet
    val tot2 = allcols2 ++ insertcols2

    Phone_Prod_Delta = Phone_Prod_Delta.select(FunctionUtility.addColumns(allcols2, tot2): _*)
      .union(insert_Data_Phone_Table.select(FunctionUtility.addColumns(insertcols2, tot2): _*))

    logger.warn("Insert Data into Phone Table using CachePatientGuardian......")

    //update PatientRelationshipToFamilyMemberUid from MappingPracticeProblem table
    val update_PatientRelationshipToFamilyMemberUid = cleanedCachePatientGuardian.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.RelationshipToPatientCode" === $"df2.PracticeValue" && $"df1.RelationshipToPatientText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"RelationshipUid".isNull && $"df1.MapperMasterCollectionUid" === "02603092-7A9C-4ADD-990B-E446B72BD76C")
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("RelationshipUid", $"aliasRelationshipUid")
      .drop("aliasRelationshipUid")

    val where_PatientRelationshipToFamilyMemberUid = cleanedCachePatientGuardian.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      ,$"df1.RelationshipToPatientCode" === $"df2.PracticeValue" && $"df1.RelationshipToPatientText" === $"df2.PracticeValue"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"RelationshipUid".isNull && $"df1.MapperMasterCollectionUid" === "02603092-7A9C-4ADD-990B-E446B72BD76C")
      .select($"df1.*")

    if (where_PatientRelationshipToFamilyMemberUid.count > 0) {
      val ex = cleanedCachePatientGuardian.except(where_PatientRelationshipToFamilyMemberUid)
      cleanedCachePatientGuardian = ex.union(update_CachePatientGuardian_Phone)
    }
    logger.warn("update PatientRelationshipToFamilyMemberUid using MappingPracticeProblem table is Done......")


    //update PatientRelationshipToFamilyMemberUid from MasterRelationship table
    val update_PatientRelationshipToFamilyMemberUid2 = cleanedCachePatientGuardian.as("df1").join(MasterRelationship_Prod.as("df2")
      ,$"df1.RelationshipToPatientCode" === $"df2.Externalid" || $"df1.RelationshipToPatientCode" === $"df2.Description")
      .where($"df1.StatusId" === 1 && $"df2.RelationshipUid".isNull)
      .select($"df1.*", $"df2.RelationshipUid".as("aliasRelationshipUid"))
      .withColumn("RelationshipUid", $"aliasRelationshipUid")
      .drop("aliasRelationshipUid")

    val where_PatientRelationshipToFamilyMemberUid2 = cleanedCachePatientGuardian.as("df1").join(Phone_Prod.as("df2")
      ,$"df1.RelationshipToPatientCode" === $"df2.Externalid" || $"df1.RelationshipToPatientCode" === $"df2.Description")
      .where($"df1.StatusId" === 1 && $"RelationshipUid".isNull)
      .select($"df1.*")

    if (where_PatientRelationshipToFamilyMemberUid2.count > 0) {
      val ex = cleanedCachePatientGuardian.except(where_PatientRelationshipToFamilyMemberUid2)
      cleanedCachePatientGuardian = ex.union(update_PatientRelationshipToFamilyMemberUid2)
    }
    logger.warn("update PatientRelationshipToFamilyMemberUid from MasterRelationship table is Done......")

    //update PatientGuardian from MasterRelationship table from CachePatientGuardian
    val update_PatientGuardian = cleanedCachePatientGuardian.as("df2").join(PatientGuardian_Prod.as("df1")
      ,$"df1.PatientGuardianuid" === $"df2.PatientGuardianuid")
      .where($"df2.StatusId" === 1 && $"df2.PatientGuardianuid".isNotNull)
      .select($"df1.*", $"df2.GuardianLastName".as("aliasGuardianLastName"), $"df2.GuardianFirstName".as("aliasGuardianFirstName"), $"df2.PatientRelationshipToGuardianUid".as("aliasPatientRelationshipToGuardianUid"),
        $"df2.AddressUid".as("aliasAddressUid"), $"df2.PhoneUid".as("aliasPhoneUid"))
      .withColumn("GuardianLastName", $"aliasGuardianLastName").withColumn( "GuardianFirstName", $"aliasGuardianFirstName").withColumn("RelationshipUid", $"aliasRelationshipUid")
      .withColumn("addressuid", $"aliasAddressUid").withColumn("phone1uid", $"aliasPhoneUid")
      .drop("aliasGuardianLastName").drop("aliasGuardianFirstName").drop("aliasRelationshipUid").drop("aliasAddressUid").drop("aliasPhoneUid")

    val where_PatientGuardian = cleanedCachePatientGuardian.as("df2").join(PatientGuardian_Prod.as("df1")
      ,$"df1.PatientGuardianuid" === $"df2.PatientGuardianuid")
      .where($"df2.StatusId" === 1 && $"df2.PatientGuardianuid".isNull)
      .select($"df1.*")

    val ex = cleanedCachePatientGuardian.except(where_PatientGuardian)
     var  PatientGuardian_Prod_Delta = ex.union(update_PatientGuardian)

    logger.warn("update PatientGuardian from MasterRelationship table is Done......")

    //Insert Data Into PatientGuardian using CachePatientGuardian table
    val insert_Data_PatientGuardian = cleanedCachePatientGuardian.as("df1").join(PatientGuardian_Prod_Delta.as("df2")
      ,$"df1.PatientGuardianuid" === $"df2.PatientGuardianuid","left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.PatientGuardianuid".isNull)
      .select($"df1.PatientGuardianuid",$"df1.PatientUid",$"df1.GuardianLastName"
        ,$"df1.GuardianFirstName",$"df1.relationshipuid".as("PatientRelationshipToGuardianUid")
        ,$"df1.addressuid",$"df1.phone1uid".as("PhoneUid"))

    logger.warn("Update Status Of CachePatientGuardian table is Done............")

    val allcols3 = PatientGuardian_Prod_Delta.columns.toSet
    val insertcols3 = insert_Data_PatientGuardian.columns.toSet
    val tot3 = allcols3 ++ insertcols3

    PatientGuardian_Prod_Delta = PatientGuardian_Prod_Delta.select(FunctionUtility.addColumns(allcols3, tot3): _*)
      .union(insert_Data_PatientGuardian.select(FunctionUtility.addColumns(insertcols3, tot3): _*))

    //End CachePatientGuardian Sp..........................................


    List(PatientGuardian_Prod_Delta,Address_Prod_Delta3,Phone_Prod_Delta)
  }

}
