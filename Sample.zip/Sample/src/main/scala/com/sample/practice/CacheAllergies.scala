package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory

class CacheAllergies {

  def CacheAllergiesFunc(spark : SparkSession,MergePracticeMap : DataFrame
                         ,CDRPatientCrosswalkTable : DataFrame
                         ,Master_prod : DataFrame
                         ,MasterAllergy_Prod : DataFrame
                         ,Patient_Prod_Delta : DataFrame
                         ,Individual_prod_Delta3 : DataFrame
                         ,MappingPracticeCommonData_Delta : DataFrame
                         ,MappingPracticeAllergy_Delta : DataFrame) : List[DataFrame] = {

    val logger = LoggerFactory.getLogger("")
    import spark.implicits._
    //Start CacheAllergies
    var CacheAllergies =  spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9")

    val lookup8 = Map("_c0" -> "PatientId", "_c1" -> "EffectiveStartDate", "_c2" -> "EffectiveEndDate"
      , "_c3" -> "AllergyTypeCode", "_c4" -> "AllergyEventType", "_c5" -> "AllergicToCode"
      , "_c6" -> "AllergicToDescription", "_c7" -> "AllergyStatusCode"
      , "_c8" -> "AllergyStatusText", "_c9" -> "AllergyReaction", "_c10" -> "AllergiesKey"
      , "_c11" -> "PracticeUid", "_c12" -> "BatchUid", "_c13" -> "dummy1", "_c14" -> "dummy2")

    CacheAllergies = CacheAllergies.select(CacheAllergies.columns.map(c => col(c).as(lookup8.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    val tempCacheAllergies = spark.read.option("header", "true")
      .csv("/home/gajanan.doifode/AAO_DATA/Schema/CacheAllergies.txt")

    val CacheAllergiesallcols = tempCacheAllergies.columns.toSet
    val CacheAllergiesViewcols = CacheAllergies.columns.toSet
    val tot_viewCA_cacheAllergies = CacheAllergiesallcols ++ CacheAllergiesViewcols

    CacheAllergies = tempCacheAllergies.select(FunctionUtility.addColumns(CacheAllergiesallcols, tot_viewCA_cacheAllergies): _*)
      .union(CacheAllergies.select(FunctionUtility.addColumns(CacheAllergiesViewcols, tot_viewCA_cacheAllergies): _*))

    CacheAllergies = CacheAllergies.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    val dist_PUID_CAllergy = CacheAllergies.filter($"StatusId".isNull).select("PracticeUid").distinct()

    val MergePracticeMap_CAllergy = MergePracticeMap.as("df1").join(dist_PUID_CAllergy.as("df2")
      , $"df1.NewPracticeUid" === $"df2.PracticeUid").select($"df1.*")

    //Update PracticeUid with OriginalPracticeUid of CacheAllergies
    CacheAllergies = CacheAllergies.as("df1").join(MergePracticeMap_CAllergy.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeUid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeUid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeUid of CacheAllergies is Done.................")
    CacheAllergies = CacheAllergies.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CacheAllergies
    CacheAllergies = CacheAllergies.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PatientId", rtrim(ltrim($"df1.PatientId")))
      .withColumn("AllergyTypeCode", rtrim(ltrim($"df1.AllergyTypeCode")))
      .withColumn("AllergicToCode", rtrim(ltrim($"df1.AllergicToCode")))

    logger.warn("Update Multiple Columns of CacheAllergies is Done............")

    //update status if PatientId is null Of CacheAllergies
    val update_status_CAllergy = CacheAllergies.filter($"StatusId" === 1 && $"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val where_status_CAllergy = CacheAllergies.filter($"StatusId" === 1 && $"PatientId".isNull)

    if (where_status_CAllergy.count > 0) {
      val ex = CacheAllergies.except(where_status_CAllergy)
      CacheAllergies = ex.union(update_status_CAllergy)
    }
    logger.warn("update status if PatientId is null Of CacheAllergies is Done............")

    //Update PatientId using CDRPatientCrosswalk In CacheAllergies Table
    val updatePatientId_CacheAllergy = CacheAllergies.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientId_CacheAllergy = CacheAllergies.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientId_CacheAllergy.count > 0) {
      val ex = CacheAllergies.except(where_PatientId_CacheAllergy)
      CacheAllergies = ex.union(updatePatientId_CacheAllergy)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk In CacheAllergies Table is Done............")


    //Update PatientUid Using Patient and Individual table of CacheAllergies
    val update_PatientUid_CAllergy = CacheAllergies.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta3.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val where_PatientUid_CAllergy = CacheAllergies.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta3.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientUid_CAllergy.count > 0) {
      val ex = CacheAllergies.except(where_PatientUid_CAllergy)
      CacheAllergies = ex.union(update_PatientUid_CAllergy)
    }

    logger.warn("Update PatientUid Using Patient and Individual table of CacheAllergies is Done............")


    //update status if PatientUid is null Of CacheAllergies
    val update_status_CAllergy22 = CacheAllergies.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_status_CAllergy22 = CacheAllergies.filter($"StatusId" === 1 && $"PatientUid".isNull)

    if (where_status_CAllergy22.count > 0) {
      val ex = CacheAllergies.except(where_status_CAllergy22)
      CacheAllergies = ex.union(update_status_CAllergy22)
    }

    logger.warn("update status if PatientUid is null Of CacheAllergies is Done............")

    //update AllergyStatusUid from MappingPracticeCommonData of CacheAllergies
    val update_AllergyStatusUid = CacheAllergies.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.AllergyStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "AA1884F1-7F97-4A6E-ABBC-1CA638F27981")
      .where($"df1.StatusId" === 1 && $"df1.AllergyStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("AllergyStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_AllergyStatusUid = CacheAllergies.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.AllergyStatusCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "AA1884F1-7F97-4A6E-ABBC-1CA638F27981")
      .where($"df1.StatusId" === 1 && $"df1.AllergyStatusUid".isNull)
      .select($"df1.*")

    if (where_AllergyStatusUid.count > 0) {
      val ex = CacheAllergies.except(where_AllergyStatusUid)
      CacheAllergies = ex.union(update_AllergyStatusUid)
    }

    logger.warn("update AllergyStatusUid from MappingPracticeCommonData of CacheAllergies is Done............")


    //update AllergyStatusUid from MappingPracticeCommonData of CacheAllergies 2
    val update_AllergyStatusUid2 = CacheAllergies.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.AllergyStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "AA1884F1-7F97-4A6E-ABBC-1CA638F27981")
      .where($"df1.StatusId" === 1 && $"df1.AllergyStatusUid".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("AllergyStatusUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_AllergyStatusUid2 = CacheAllergies.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.AllergyStatusText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "AA1884F1-7F97-4A6E-ABBC-1CA638F27981")
      .where($"df1.StatusId" === 1 && $"df1.AllergyStatusUid".isNull)
      .select($"df1.*")

    if (where_AllergyStatusUid2.count > 0) {
      val ex = CacheAllergies.except(where_AllergyStatusUid2)
      CacheAllergies = ex.union(update_AllergyStatusUid2)
    }

    logger.warn("update AllergyStatusUid from MappingPracticeCommonData of CacheAllergies 2 is Done............")


    //Update AllergyStatusUid from Master Table of CacheAllergies
    val update_AllergyStatusUid3 = CacheAllergies.as("df1").join(Master_prod.as("df2"),
      $"df1.AllergyStatusCode" === $"df2.Code" && $"df2.Type" === "AllergyStatus")
      .filter( $"df1.StatusId" === 1 && $"df1.AllergyStatusUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("AllergyStatusUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_AllergyStatusUid3 =CacheAllergies.as("df1").join(Master_prod.as("df2"),
      $"df1.AllergyStatusCode" === $"df2.Code" && $"df2.Type" === "AllergyStatus")
      .filter( $"df1.StatusId" === 1 && $"df1.AllergyStatusUid".isNull)
      .select($"df1.*")

    if (where_AllergyStatusUid3.count > 0) {
      val ex = CacheAllergies.except(where_AllergyStatusUid3)
      CacheAllergies = ex.union(update_AllergyStatusUid3)
    }

    logger.warn("Update AllergyStatusUid from Master Table of CacheAllergies is Done........")


    //Update AllergyStatusUid from Master Table of CacheAllergies 2
    val update_AllergyStatusUid4 = CacheAllergies.as("df1").join(Master_prod.as("df2"),
      $"df1.AllergyStatusText" === $"df2.Name" && $"df2.Type" === "AllergyStatus")
      .filter( $"df1.StatusId" === 1 && $"df1.AllergyStatusUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("AllergyStatusUid", $"aliasMasterUid")
      .drop("aliasMasterUid")

    val where_AllergyStatusUid4 =CacheAllergies.as("df1").join(Master_prod.as("df2"),
      $"df1.AllergyStatusText" === $"df2.Name" && $"df2.Type" === "AllergyStatus")
      .filter( $"df1.StatusId" === 1 && $"df1.AllergyStatusUid".isNull)
      .select($"df1.*")

    if (where_AllergyStatusUid4.count > 0) {
      val ex = CacheAllergies.except(where_AllergyStatusUid4)
      CacheAllergies = ex.union(update_AllergyStatusUid4)
    }

    logger.warn("Update AllergyStatusUid from Master Table of CacheAllergies 2 is Done........")

    //update status if AllergyStatusUid is null Of CacheAllergies
    val update_status_CAllergy222 = CacheAllergies.filter($"StatusId" === 1 && $"AllergyStatusUid".isNull
      && rtrim(ltrim($"AllergyStatusCode")).isNotNull && rtrim(ltrim($"AllergyStatusText")).isNotNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("AllergyStatusCode Not Mapped"))

    val where_status_CAllergy222 =  CacheAllergies.filter($"StatusId" === 1 && $"AllergyStatusUid".isNull
      && rtrim(ltrim($"AllergyStatusCode")).isNotNull && rtrim(ltrim($"AllergyStatusText")).isNotNull)

    if (where_status_CAllergy222.count > 0) {
      val ex = CacheAllergies.except(where_status_CAllergy222)
      CacheAllergies = ex.union(update_status_CAllergy222)
    }

    logger.warn("update status if AllergyStatusUid is null Of CacheAllergies is Done........")

    //update status if AllergicToDescription is null Of CacheAllergies
    val update_status_CAllergy2222 = CacheAllergies.filter($"StatusId" === 1 && $"AllergicToDescription".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Allergies Not Found"))

    val where_status_CAllergy2222 = CacheAllergies.filter($"StatusId" === 1 && $"AllergicToDescription".isNull)

    if (where_status_CAllergy2222.count > 0) {
      val ex = CacheAllergies.except(where_status_CAllergy2222)
      CacheAllergies = ex.union(update_status_CAllergy2222)
    }

    logger.warn("update status if AllergicToDescription is null Of CacheAllergies is Done........")


    //Update AllergyUid of CacheAllergies using MappingPracticeAllergy_Prod
    val update_AllergyUid = CacheAllergies.as("df1").join(MappingPracticeAllergy_Delta.as("df2")
      , $"df1.AllergicToCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*", $"df2.AllergyUid".as("aliasAllergyUid"))
      .withColumn("AllergyUid", $"aliasAllergyUid")
      .drop("aliasAllergyUid")

    val where_AllergyUid =  CacheAllergies.as("df1").join(MappingPracticeAllergy_Delta.as("df2")
      , $"df1.AllergicToCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*")

    if (where_AllergyUid.count > 0) {
      val ex = CacheAllergies.except(where_AllergyUid)
      CacheAllergies = ex.union(update_AllergyUid)
    }

    logger.warn("Update AllergyUid of CacheAllergies using MappingPracticeAllergy_Prod is Done........")


    //Update AllergyUid of CacheAllergies using MappingPracticeAllergy_Prod 2
    val update_AllergyUid2 = CacheAllergies.as("df1").join(MappingPracticeAllergy_Delta.as("df2")
      , $"df1.AllergicToDescription" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*", $"df2.AllergyUid".as("aliasAllergyUid"))
      .withColumn("AllergyUid", $"aliasAllergyUid")
      .drop("aliasAllergyUid")

    val where_AllergyUid2 =  CacheAllergies.as("df1").join(MappingPracticeAllergy_Delta.as("df2")
      , $"df1.AllergicToDescription" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*")

    if (where_AllergyUid2.count > 0) {
      val ex = CacheAllergies.except(where_AllergyUid2)
      CacheAllergies = ex.union(update_AllergyUid2)
    }

    logger.warn("Update AllergyUid of CacheAllergies using MappingPracticeAllergy_Prod 2 is Done........")


    //Update AllergyUid of CacheAllergies using MasterAllergy_Prod
    val update_AllergyUid3 = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.AllergicToCode" === $"df2.Code")
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*", $"df2.AllergyUid".as("aliasAllergyUid"))
      .withColumn("AllergyUid", $"aliasAllergyUid")
      .drop("aliasAllergyUid")

    val where_AllergyUid3 = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.AllergicToCode" === $"df2.Code")
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*")

    if (where_AllergyUid3.count > 0) {
      val ex = CacheAllergies.except(where_AllergyUid3)
      CacheAllergies = ex.union(update_AllergyUid3)
    }

    logger.warn("Update AllergyUid of CacheAllergies using MasterAllergy_Prod is Done........")

    //Update AllergyUid of CacheAllergies using MasterAllergy_Prod 2
    val update_AllergyUid4 = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.AllergicToDescription" === $"df2.Description")
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*", $"df2.AllergyUid".as("aliasAllergyUid"))
      .withColumn("AllergyUid", $"aliasAllergyUid")
      .drop("aliasAllergyUid")

    val where_AllergyUid4 = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      ,  $"df1.AllergicToDescription" === $"df2.Description")
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*")

    if (where_AllergyUid4.count > 0) {
      val ex = CacheAllergies.except(where_AllergyUid4)
      CacheAllergies = ex.union(update_AllergyUid4)
    }

    logger.warn("Update AllergyUid of CacheAllergies using MasterAllergy_Prod 2 is Done........")

    //Update PatientAllergyUid of CacheAllergies using PatientAllergy_Prod
    val update_PatientAllergyUid = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergyUid" === $"df2.AllergyUid" &&
        $"df1.EffectiveStartDate" === $"df2.DateFirstEncountered")
      .where($"df1.StatusId" === 1 && $"df1.PatientAllergyUid".isNull)
      .select($"df1.*", $"df2.PatientAllergyUid".as("aliasPatientAllergyUid"))
      .withColumn("PatientAllergyUid", $"aliasPatientAllergyUid")
      .drop("aliasPatientAllergyUid")

    val where_PatientAllergyUid = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergyUid" === $"df2.AllergyUid" &&
        $"df1.EffectiveStartDate" === $"df2.DateFirstEncountered")
      .where($"df1.StatusId" === 1 && $"df1.PatientAllergyUid".isNull)
      .select($"df1.*")

    if (where_PatientAllergyUid.count > 0) {
      val ex = CacheAllergies.except(where_PatientAllergyUid)
      CacheAllergies = ex.union(update_PatientAllergyUid)
    }

    logger.warn("Update PatientAllergyUid of CacheAllergies using PatientAllergy_Prod is Done........")

    //Update PatientAllergyUid of CacheAllergies using PatientAllergy_Prod 2
    val update_PatientAllergyUid2 = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergicToDescription" === $"df2.Description" &&
        $"df1.EffectiveStartDate" === $"df2.DateFirstEncountered")
      .where($"df1.StatusId" === 1 && $"df1.PatientAllergyUid".isNull && $"df1.AllergyUid".isNull)
      .select($"df1.*", $"df2.PatientAllergyUid".as("aliasPatientAllergyUid"))
      .withColumn("PatientAllergyUid", $"aliasPatientAllergyUid")
      .drop("aliasPatientAllergyUid")

    val where_PatientAllergyUid2 = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergicToDescription" === $"df2.Description" &&
        $"df1.EffectiveStartDate" === $"df2.DateFirstEncountered")
      .where($"df1.StatusId" === 1 && $"df1.PatientAllergyUid".isNull && $"df1.AllergyUid".isNull)
      .select($"df1.*")

    if (where_PatientAllergyUid2.count > 0) {
      val ex = CacheAllergies.except(where_PatientAllergyUid2)
      CacheAllergies = ex.union(update_PatientAllergyUid2)
    }

    logger.warn("Update PatientAllergyUid of CacheAllergies using PatientAllergy_Prod 2 is Done........")

    //Update PatientAllergyUid of CacheAllergies using PatientAllergy_Prod 3
    val update_PatientAllergyUid3 = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergyUid" === $"df2.AllergyUid" &&
        $"df1.EffectiveEndDate" === $"df2.DateOfResolution" && $"df1.EffectiveStartDate".isNull)
      .where($"df1.StatusId" === 1 && $"df1.PatientAllergyUid".isNull)
      .select($"df1.*", $"df2.PatientAllergyUid".as("aliasPatientAllergyUid"))
      .withColumn("PatientAllergyUid", $"aliasPatientAllergyUid")
      .drop("aliasPatientAllergyUid")

    val where_PatientAllergyUid3 = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergyUid" === $"df2.AllergyUid" &&
        $"df1.EffectiveEndDate" === $"df2.DateOfResolution" && $"df1.EffectiveStartDate".isNull)
      .where($"df1.StatusId" === 1 && $"df1.PatientAllergyUid".isNull)
      .select($"df1.*")

    if (where_PatientAllergyUid3.count > 0) {
      val ex = CacheAllergies.except(where_PatientAllergyUid3)
      CacheAllergies = ex.union(update_PatientAllergyUid3)
    }

    logger.warn("Update PatientAllergyUid of CacheAllergies using PatientAllergy_Prod 3 is Done........")

    //Update PatientAllergyUid of CacheAllergies using PatientAllergy_Prod 4
    val update_PatientAllergyUid4 = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergicToDescription" === $"df2.Description" &&
        $"df1.EffectiveEndDate" === $"df2.DateOfResolution" && $"df1.EffectiveStartDate".isNull)
      .where($"df1.StatusId" === 1 && $"df1.PatientAllergyUid".isNull && $"df1.AllergyUid".isNull)
      .select($"df1.*", $"df2.PatientAllergyUid".as("aliasPatientAllergyUid"))
      .withColumn("PatientAllergyUid", $"aliasPatientAllergyUid")
      .drop("aliasPatientAllergyUid")

    val where_PatientAllergyUid4 = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergicToDescription" === $"df2.Description" &&
        $"df1.EffectiveEndDate" === $"df2.DateOfResolution" && $"df1.EffectiveStartDate".isNull)
      .where($"df1.StatusId" === 1 && $"df1.PatientAllergyUid".isNull && $"df1.AllergyUid".isNull)
      .select($"df1.*")

    if (where_PatientAllergyUid4.count > 0) {
      val ex = CacheAllergies.except(where_PatientAllergyUid4)
      CacheAllergies = ex.union(update_PatientAllergyUid4)
    }

    logger.warn("Update PatientAllergyUid of CacheAllergies using PatientAllergy_Prod 4 is Done........")

    //Update PatientAllergyUid of CacheAllergies using PatientAllergy_Prod 5
    val update_PatientAllergyUid5 = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergyUid" === $"df2.AllergyUid" &&
        $"df1.EffectiveEndDate".isNull && $"df1.EffectiveStartDate".isNull)
      .where($"df1.StatusId" === 1 && $"df1.PatientAllergyUid".isNull)
      .select($"df1.*", $"df2.PatientAllergyUid".as("aliasPatientAllergyUid"))
      .withColumn("PatientAllergyUid", $"aliasPatientAllergyUid")
      .drop("aliasPatientAllergyUid")

    val where_PatientAllergyUid5 =  CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergyUid" === $"df2.AllergyUid" &&
        $"df1.EffectiveEndDate".isNull && $"df1.EffectiveStartDate".isNull)
      .where($"df1.StatusId" === 1 && $"df1.PatientAllergyUid".isNull)
      .select($"df1.*")

    if (where_PatientAllergyUid5.count > 0) {
      val ex = CacheAllergies.except(where_PatientAllergyUid5)
      CacheAllergies = ex.union(update_PatientAllergyUid5)
    }

    logger.warn("Update PatientAllergyUid of CacheAllergies using PatientAllergy_Prod 5 is Done........")

    //Update PatientAllergyUid of CacheAllergies using PatientAllergy_Prod 6
    val update_PatientAllergyUid6 = CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergicToDescription" === $"df2.Description" &&
        $"df1.EffectiveEndDate".isNull && $"df1.EffectiveStartDate".isNull)
      .where($"df1.StatusId" === 1 && $"df1.PatientAllergyUid".isNull && $"df1.AllergyUid".isNull)
      .select($"df1.*", $"df2.PatientAllergyUid".as("aliasPatientAllergyUid"))
      .withColumn("PatientAllergyUid", $"aliasPatientAllergyUid")
      .drop("aliasPatientAllergyUid")

    val where_PatientAllergyUid6 =  CacheAllergies.as("df1").join(MasterAllergy_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergicToDescription" === $"df2.Description" &&
        $"df1.EffectiveEndDate".isNull && $"df1.EffectiveStartDate".isNull)
      .where($"df1.StatusId" === 1 && $"df1.PatientAllergyUid".isNull && $"df1.AllergyUid".isNull)
      .select($"df1.*")

    if (where_PatientAllergyUid6.count > 0) {
      val ex = CacheAllergies.except(where_PatientAllergyUid6)
      CacheAllergies = ex.union(update_PatientAllergyUid6)
    }

    logger.warn("Update PatientAllergyUid of CacheAllergies using PatientAllergy_Prod 6 is Done........")


    //Find Duplicates From CacheAllergies
    val cleanedCacheAllergies = CacheAllergies.dropDuplicates(Seq("PatientUid", "AllergyUid","EffectiveStartDate"))
    var duplicateRecords_CacheAllergies = CacheAllergies.except(cleanedCacheAllergies)

    val cleanedCacheAllergies2 = cleanedCacheAllergies.dropDuplicates(Seq("PatientUid", "AllergyUid","EffectiveEndDate"))
    val duplicateRecords_CacheAllergies2 = cleanedCacheAllergies.except(cleanedCacheAllergies2)


    val cleanedCacheAllergies3 = cleanedCacheAllergies2.dropDuplicates(Seq("PatientUid", "AllergyUid"))
    val duplicateRecords_CacheAllergies3 = cleanedCacheAllergies2.except(cleanedCacheAllergies3)

    val cleanedCacheAllergies4 = cleanedCacheAllergies3.dropDuplicates(Seq("PatientUid", "AllergicToDescription"
      ,"EffectiveStartDate"))
    val duplicateRecords_CacheAllergies4 = cleanedCacheAllergies3.except(cleanedCacheAllergies4)

    val cleanedCacheAllergies5 = cleanedCacheAllergies4.dropDuplicates(Seq("PatientUid", "AllergicToDescription"
      ,"EffectiveEndDate"))
    val duplicateRecords_CacheAllergies5 = cleanedCacheAllergies4.except(cleanedCacheAllergies5)

    var cleanedCacheAllergies6 = cleanedCacheAllergies5.dropDuplicates(Seq("PatientUid", "AllergicToDescription"))
    val duplicateRecords_CacheAllergies6 = cleanedCacheAllergies5.except(cleanedCacheAllergies6)

    duplicateRecords_CacheAllergies = duplicateRecords_CacheAllergies.union(duplicateRecords_CacheAllergies2)
      .union(duplicateRecords_CacheAllergies3).union(duplicateRecords_CacheAllergies4)
      .union(duplicateRecords_CacheAllergies5).union(duplicateRecords_CacheAllergies6)

    logger.warn("Drop Duplicate records From CacheAllergies Table is Done............")

    //Create Table #Allergy
    val tempAllergy = cleanedCacheAllergies6.filter($"StatusId" === 1 && $"PatientAllergyUid".isNull &&
      $"EffectiveStartDate".isNotNull && $"AllergyUid".isNotNull)
      .select("PatientUid","AllergyUid","EffectiveStartDate").distinct()
      .withColumn("PatientAllergyUid",FunctionUtility.getNewUid())

    //Update PatientAllergyUid of CacheAllergies using tempAllergy
    val update_PatientAllergyUid7 = cleanedCacheAllergies6.as("df1").join(tempAllergy.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergyUid" === $"df2.AllergyUid" &&
        $"df1.EffectiveStartDate" === $"df2.EffectiveStartDate" && $"df1.PatientAllergyUid".isNull)
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNotNull)
      .select($"df1.*", $"df2.PatientAllergyUid".as("aliasPatientAllergyUid"))
      .withColumn("PatientAllergyUid", $"aliasPatientAllergyUid")
      .drop("aliasPatientAllergyUid")

    val where_PatientAllergyUid7 = cleanedCacheAllergies6.as("df1").join(tempAllergy.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergyUid" === $"df2.AllergyUid" &&
        $"df1.EffectiveStartDate" === $"df2.EffectiveStartDate" && $"df1.PatientAllergyUid".isNull)
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNotNull)
      .select($"df1.*")

    if (where_PatientAllergyUid7.count > 0) {
      val ex = cleanedCacheAllergies6.except(where_PatientAllergyUid7)
      cleanedCacheAllergies6 = ex.union(update_PatientAllergyUid7)
    }

    logger.warn("Update PatientAllergyUid of CacheAllergies using tempAllergy is Done........")

    //Create Table #Allergy1
    val tempAllergy1 = cleanedCacheAllergies6.filter($"StatusId" === 1 && $"PatientAllergyUid".isNull &&
      $"EffectiveStartDate".isNull && $"EffectiveEndDate".isNotNull && $"AllergyUid".isNotNull)
      .select("PatientUid","AllergyUid","EffectiveEndDate").distinct()
      .withColumn("PatientAllergyUid",FunctionUtility.getNewUid())

    //Update PatientAllergyUid of CacheAllergies using tempAllergy1
    val update_PatientAllergyUid8 = cleanedCacheAllergies6.as("df1").join(tempAllergy1.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergyUid" === $"df2.AllergyUid" &&
        $"df1.EffectiveEndDate" === $"df2.EffectiveEndDate" && $"df1.EffectiveStartDate".isNull
        && $"df1.PatientAllergyUid".isNull)
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNotNull)
      .select($"df1.*", $"df2.PatientAllergyUid".as("aliasPatientAllergyUid"))
      .withColumn("PatientAllergyUid", $"aliasPatientAllergyUid")
      .drop("aliasPatientAllergyUid")

    val where_PatientAllergyUid8 = cleanedCacheAllergies6.as("df1").join(tempAllergy1.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergyUid" === $"df2.AllergyUid" &&
        $"df1.EffectiveEndDate" === $"df2.EffectiveEndDate" && $"df1.EffectiveStartDate".isNull
        && $"df1.PatientAllergyUid".isNull)
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNotNull)
      .select($"df1.*")

    if (where_PatientAllergyUid8.count > 0) {
      val ex = cleanedCacheAllergies6.except(where_PatientAllergyUid8)
      cleanedCacheAllergies6 = ex.union(update_PatientAllergyUid8)
    }

    logger.warn("Update PatientAllergyUid of CacheAllergies using tempAllergy1 is Done........")

    //Create Table #Allergy2
    val tempAllergy2 = cleanedCacheAllergies6.filter($"StatusId" === 1 && $"PatientAllergyUid".isNull &&
      $"EffectiveStartDate".isNull && $"EffectiveEndDate".isNull && $"AllergyUid".isNotNull)
      .select("PatientUid","AllergyUid").distinct()
      .withColumn("PatientAllergyUid",FunctionUtility.getNewUid())

    //Update PatientAllergyUid of CacheAllergies using tempAllergy2
    val update_PatientAllergyUid9 = cleanedCacheAllergies6.as("df1").join(tempAllergy2.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergyUid" === $"df2.AllergyUid" &&
        $"df1.EffectiveEndDate".isNull && $"df1.EffectiveStartDate".isNull && $"df1.PatientAllergyUid".isNull)
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNotNull)
      .select($"df1.*", $"df2.PatientAllergyUid".as("aliasPatientAllergyUid"))
      .withColumn("PatientAllergyUid", $"aliasPatientAllergyUid")
      .drop("aliasPatientAllergyUid")

    val where_PatientAllergyUid9 = cleanedCacheAllergies6.as("df1").join(tempAllergy2.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergyUid" === $"df2.AllergyUid" &&
        $"df1.EffectiveEndDate".isNull && $"df1.EffectiveStartDate".isNull && $"df1.PatientAllergyUid".isNull)
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNotNull)
      .select($"df1.*")

    if (where_PatientAllergyUid9.count > 0) {
      val ex = cleanedCacheAllergies6.except(where_PatientAllergyUid9)
      cleanedCacheAllergies6 = ex.union(update_PatientAllergyUid9)
    }

    logger.warn("Update PatientAllergyUid of CacheAllergies using tempAllergy2 is Done........")

    //Create Table tempAllergy3
    val tempAllergy3 = cleanedCacheAllergies6.filter($"StatusId" === 1 && $"PatientAllergyUid".isNull &&
      $"EffectiveStartDate".isNotNull  && $"AllergyUid".isNull)
      .select("PatientUid","AllergicToDescription","EffectiveStartDate").distinct()
      .withColumn("PatientAllergyUid",FunctionUtility.getNewUid())

    //Update PatientAllergyUid of CacheAllergies using tempAllergy3
    val update_PatientAllergyUid10 = cleanedCacheAllergies6.as("df1").join(tempAllergy3.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergicToDescription" === $"df2.AllergicToDescription" &&
        $"df1.EffectiveStartDate" === $"df2.EffectiveStartDate" && $"df1.PatientAllergyUid".isNull)
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*", $"df2.PatientAllergyUid".as("aliasPatientAllergyUid"))
      .withColumn("PatientAllergyUid", $"aliasPatientAllergyUid")
      .drop("aliasPatientAllergyUid")

    val where_PatientAllergyUid10 = cleanedCacheAllergies6.as("df1").join(tempAllergy3.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergicToDescription" === $"df2.AllergicToDescription" &&
        $"df1.EffectiveStartDate" === $"df2.EffectiveStartDate" && $"df1.PatientAllergyUid".isNull)
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*")

    if (where_PatientAllergyUid10.count > 0) {
      val ex = cleanedCacheAllergies6.except(where_PatientAllergyUid10)
      cleanedCacheAllergies6 = ex.union(update_PatientAllergyUid10)
    }

    logger.warn("Update PatientAllergyUid of CacheAllergies using tempAllergy3  is Done........")

    //Create Table tempAllergy4
    val tempAllergy4 = cleanedCacheAllergies6.filter($"StatusId" === 1 && $"PatientAllergyUid".isNull &&
      $"EffectiveStartDate".isNull && $"EffectiveEndDate".isNotNull && $"AllergyUid".isNull)
      .select("PatientUid","AllergicToDescription","EffectiveEndDate").distinct()
      .withColumn("PatientAllergyUid",FunctionUtility.getNewUid())

    //Update PatientAllergyUid of CacheAllergies using tempAllergy4
    val update_PatientAllergyUid11 = cleanedCacheAllergies6.as("df1").join(tempAllergy4.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergicToDescription" === $"df2.AllergicToDescription" &&
        $"df1.EffectiveEndDate" === $"df2.EffectiveEndDate" && $"df1.EffectiveStartDate".isNull && $"df1.PatientAllergyUid".isNull)
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*", $"df2.PatientAllergyUid".as("aliasPatientAllergyUid"))
      .withColumn("PatientAllergyUid", $"aliasPatientAllergyUid")
      .drop("aliasPatientAllergyUid")

    val where_PatientAllergyUid11 = cleanedCacheAllergies6.as("df1").join(tempAllergy4.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergicToDescription" === $"df2.AllergicToDescription" &&
        $"df1.EffectiveEndDate" === $"df2.EffectiveEndDate" && $"df1.EffectiveStartDate".isNull && $"df1.PatientAllergyUid".isNull)
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*")

    if (where_PatientAllergyUid11.count > 0) {
      val ex = cleanedCacheAllergies6.except(where_PatientAllergyUid11)
      cleanedCacheAllergies6 = ex.union(update_PatientAllergyUid11)
    }

    logger.warn("Update PatientAllergyUid of CacheAllergies using tempAllergy4 is Done........")

    //Create Table tempAllergy5
    val tempAllergy5 = cleanedCacheAllergies6.filter($"StatusId" === 1 && $"PatientAllergyUid".isNull &&
      $"EffectiveStartDate".isNull && $"EffectiveEndDate".isNull && $"AllergyUid".isNull)
      .select("PatientUid","AllergicToDescription")
      .withColumn("PatientAllergyUid",FunctionUtility.getNewUid())

    //Update PatientAllergyUid of CacheAllergies using tempAllergy5
    val update_PatientAllergyUid12 = cleanedCacheAllergies6.as("df1").join(tempAllergy5.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergicToDescription" === $"df2.AllergicToDescription" &&
        $"df1.EffectiveEndDate".isNull && $"df1.EffectiveStartDate".isNull && $"df1.PatientAllergyUid".isNull)
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*", $"df2.PatientAllergyUid".as("aliasPatientAllergyUid"))
      .withColumn("PatientAllergyUid", $"aliasPatientAllergyUid")
      .drop("aliasPatientAllergyUid")

    val where_PatientAllergyUid12 = cleanedCacheAllergies6.as("df1").join(tempAllergy5.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.AllergicToDescription" === $"df2.AllergicToDescription" &&
        $"df1.EffectiveEndDate".isNull && $"df1.EffectiveStartDate".isNull && $"df1.PatientAllergyUid".isNull)
      .where($"df1.StatusId" === 1 && $"df1.AllergyUid".isNull)
      .select($"df1.*")

    if (where_PatientAllergyUid12.count > 0) {
      val ex = cleanedCacheAllergies6.except(where_PatientAllergyUid12)
      cleanedCacheAllergies6 = ex.union(update_PatientAllergyUid12)
    }

    logger.warn("Update PatientAllergyUid of CacheAllergies using tempAllergy5 is Done........")

    //Update Columns Of PatientAllergy Table
    val update_PatientAllergy_Prod = cleanedCacheAllergies6.as("df1").join(MasterAllergy_Prod.as("df2")
      ,$"df1.AllergyUid" === $"df2.AllergyUid").join(MasterAllergy_Prod.as("df3")
      ,$"df1.PatientAllergyUid" === $"df3.PatientAllergyUid").filter($"df1.StatusId" === 1)
      .select($"df3.*",$"df1.AllergicToDescription".as("aliasATD"),$"df1.AllergyEventType".as("aliasAET")
        ,$"df1.AllergicToCode".as("aliasATC"),$"df1.EffectiveStartDate".as("aliasESD"),$"df1.EffectiveEndDate".as("aliasEEd")
        ,$"df1.AllergyStatusUid".as("aliasAllSUid"),$"df1.AllergyReaction".as("aliasAR"))
      .withColumn("Description",$"aliasATD")
      .withColumn("AllergyEventType",$"aliasAET")
      .withColumn("AllergicTo",when($"aliasATC".isNull,$"aliasATD").otherwise($"aliasATC"))
      .withColumn("DateFirstEncountered",$"aliasESD")
      .withColumn("DateOfResolution",$"aliasEEd")
      .withColumn("MasterAllergyStatusUid",$"aliasAllSUid")
      .withColumn("AllergyReaction",$"AllergyReaction")
      .withColumn("ModifiedDate",current_timestamp())
      .drop("aliasATD","aliasAET","aliasATC","aliasESD","aliasEEd","aliasAllSUid","AllergyReaction")

    val where_Allergy = cleanedCacheAllergies6.as("df1").join(MasterAllergy_Prod.as("df2")
      ,$"df1.AllergyUid" === $"df2.AllergyUid").join(MasterAllergy_Prod.as("df3")
      ,$"df1.PatientAllergyUid" === $"df3.PatientAllergyUid").filter($"df1.StatusId" === 1)
      .select($"df3.*")

    val ex_Allergy = cleanedCacheAllergies6.except(where_Allergy)
    var MasterAllergy_Prod_Delta = ex_Allergy.union(update_PatientAllergy_Prod)

    logger.warn("Update Columns Of PatientAllergy Table is Done........")

    //Insert Data Into PatientAllergy Table
    val insert_PatientAllergy_Prod = cleanedCacheAllergies6.as("df1").join(MasterAllergy_Prod_Delta.as("df2")
      ,$"df1.PatientAllergyUid" === $"df2.PatientAllergyUid","left_outer").filter($"df1.StatusId" === 1
      && $"df2.PatientAllergyUid".isNull)
      .select($"df1.PatientAllergyUid",$"df1.PatientUid",$"df1.AllergicToDescription".as("Description")
        ,$"df1.AllergyEventType",when($"df1.AllergicToCode".isNull,$"df1.AllergicToDescription").otherwise($"df1.AllergicToCode")
          .as("AllergicTo"),$"df1.EffectiveStartDate".as("DateFirstEncountered"),$"df1.EffectiveEndDate"
          .as("DateOfResolution"),$"df1.AllergyUid",$"df1.AllergyTypeCode",$"df1.AllergyStatusUid"
          .as("MasterAllergyStatusUid"),$"df1.AllergyReaction")
      .withColumn("CreatedDate",current_timestamp())

    val allcols = MasterAllergy_Prod_Delta.columns.toSet
    val insert_cols  = insert_PatientAllergy_Prod.columns.toSet
    val tot = allcols ++ insert_cols

    MasterAllergy_Prod_Delta = MasterAllergy_Prod_Delta.select(FunctionUtility.addColumns(allcols, tot): _*)
      .union(insert_PatientAllergy_Prod.select(FunctionUtility.addColumns(insert_cols, tot): _*))

    logger.warn("Insert Data Into PatientAllergy Table is Done........")

    logger.warn("End CacheAllergies..................")


    List(MasterAllergy_Prod_Delta)
  }

}
