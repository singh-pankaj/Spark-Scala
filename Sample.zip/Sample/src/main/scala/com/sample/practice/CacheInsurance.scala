package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory

class CacheInsurance {

  def CacheInsuranceFunc(spark : SparkSession,MergePracticeMap : DataFrame
                         ,CDRPatientCrosswalkTable : DataFrame,Patient_Prod_Delta : DataFrame
                         ,Individual_prod_Delta2 : DataFrame,PatientInsuranceInfo_Prod : DataFrame
                         ,MappingPracticeCommonData_Delta : DataFrame,Master_prod : DataFrame) : List[DataFrame] = {

    import spark.implicits._
    val logger = LoggerFactory.getLogger("")

    //Start CachePayer

    var CachePayer = spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/a70ed65f-6cca-4808-82b4-fb2bcc5e737a_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")

    val lookup5 = Map("_c0" -> "PatientId", "_c1" -> "InsuredPersonId", "_c2" -> "InsuranceCompany", "_c3" -> "InsurancePlan"
      , "_c4" -> "InsuranceGroup", "_c5" -> "InsuranceOrder", "_c6" -> "InsuredRelationToPatientCode"
      , "_c7" -> "InsuredRelationToPatientText", "_c8" -> "DocumentationDate", "_c9" -> "EndDateOfInsurance"
      , "_c10" -> "IsInsuredSameAsGuarantor", "_c11" -> "PayerID", "_c12" -> "PolicyID", "_c13" -> "PayerCity"
      , "_c14" -> "PayerState", "_c15" -> "PayerZip", "_c16" -> "Insurance_Active"
      , "_c17" -> "StartDateOfInsurance", "_c18" -> "BillingInsurance", "_c19" -> "PayerKey"
      , "_c20" -> "PracticeUid", "_c21" -> "BatchUid", "_c22" -> "dummy1", "_c23" -> "dummy2")

    CachePayer = CachePayer.select(CachePayer.columns.map(c => col(c).as(lookup5.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    val tempCachePayer = spark.read.option("header", "true")
      .csv("/home/gajanan.doifode/AAO_DATA/Schema/CachePayer.txt")

    val CachePayerAllcols = tempCachePayer.columns.toSet
    val CachePayerViewcols = CachePayer.columns.toSet
    val tot_viewCP_AllCP = CachePayerAllcols ++ CachePayerViewcols

    CachePayer = tempCachePayer.select(FunctionUtility.addColumns(CachePayerAllcols, tot_viewCP_AllCP): _*)
      .union(CachePayer.select(FunctionUtility.addColumns(CachePayerViewcols, tot_viewCP_AllCP): _*))

    CachePayer = CachePayer.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    val dist_PrctUid_Payer = CachePayer.filter($"StatusId".isNull).select("PracticeUid").distinct()

    val tempMergePracticeMap_Payer = MergePracticeMap.as("df1").join(dist_PrctUid_Payer.as("df2")
      , $"df1.NewPracticeUid" === $"df2.PracticeUid").select($"df1.*")

    //Update PracticeUid with OriginalPracticeUid of CachePayer
    CachePayer = CachePayer.as("df1").join(tempMergePracticeMap_Payer.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeUid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeUid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeUid of CachePayer is Done.............................")

    CachePayer = CachePayer.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CachePayer
    CachePayer = CachePayer.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("InsuredRelationToPatientText", rtrim(ltrim($"df1.InsuredRelationToPatientText")))
      .withColumn("InsuredRelationToPatientCode", rtrim(ltrim($"df1.InsuredRelationToPatientCode")))
      .withColumn("PatientId", rtrim(ltrim($"df1.PatientId")))

    logger.warn("Update Multiple Columns of CachePayer is Done............")

    //Update InsuerancePlan Of CachePayer
    val update_InsuPlan = CachePayer.as("df1").filter($"StatusId" === 1 && $"InsurancePlan".isNull)
      .withColumn("InsurancePlan", trim(ltrim($"df1.InsuranceCompany")))

    val where_InsuPlan = CachePayer.as("df1").filter($"StatusId" === 1 && $"InsurancePlan".isNull)

    if (where_InsuPlan.count > 0) {
      val ex = CachePayer.except(where_InsuPlan)
      CachePayer = ex.union(update_InsuPlan)
    }

    logger.warn("Update InsuerancePlan Of CachePayer is Done............")

    //Update InsuranceCompany Of CachePayer
    val update_InsuCompany = CachePayer.as("df1").filter($"StatusId" === 1 && $"InsurancePlan".isNotNull &&
      $"InsuranceCompany".isNull)
      .withColumn("InsuranceCompany", trim(ltrim($"df1.InsurancePlan")))

    val where_InsuCompany = CachePayer.as("df1").filter($"StatusId" === 1 && $"InsurancePlan".isNotNull &&
      $"InsuranceCompany".isNull)

    if (where_InsuCompany.count > 0) {
      val ex = CachePayer.except(where_InsuCompany)
      CachePayer = ex.union(update_InsuCompany)
    }

    logger.warn("Update InsuranceCompany Of CachePayer is Done............")

    //Update Status When Find PatientId is null, policyId length is greater than 50 and PayerId length is greater than 50
    //of cache Payer
    val l = CachePayer.filter(length($"PolicyID") > 50 && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid PolicyId"))

    val m = CachePayer.filter(length($"PayerID") > 50 && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid PayerId"))

    val n = CachePayer.filter($"PatientId".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val updateAllPayer = l.union(m).union(n)

    val whereAllpayer = CachePayer.filter($"StatusId" === 1 && (length($"PolicyID") > 50 || length($"PayerID") > 50
      || $"PatientId".isNull))

    if (whereAllpayer.count > 0) {
      val ex = CachePayer.except(whereAllpayer)
      CachePayer = ex.union(updateAllPayer)
    }

    //Update PatientId using CDRPatientCrosswalk In Payer Table
    val updatePatientIdPayer = CachePayer.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientIdPayer = CachePayer.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientIdPayer.count > 0) {
      val ex = CachePayer.except(where_PatientIdPayer)
      CachePayer = ex.union(updatePatientIdPayer)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk In Payer Table is Done............")

    //Update PatientUid Of CachePayer using Individual and patient table
    val update_PatientUid_Payer = CachePayer.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta2.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val where_PatientUid_Payer = CachePayer.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta2.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientUid_Payer.count > 0) {
      val ex = CachePayer.except(where_PatientUid_Payer)
      CachePayer = ex.union(update_PatientUid_Payer)
    }

    logger.warn("Update PatientUid Of CachePayer using Individual and patient table is Done............")

    //Update Status If Found PatientUid is null and Insurancepaln is null of payer
    val p = CachePayer.filter($"PatientUid".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val q = CachePayer.filter($"InsurancePlan".isNull && $"StatusId" === 1)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("InsurancePlan Not Found"))

    val update_PUID_InsPlan = p.union(q)

    val where_PUID_InsPlan = CachePayer.filter($"StatusId" === 1 && ($"InsurancePlan".isNull || $"PatientUid".isNull))

    if (where_PUID_InsPlan.count > 0) {
      val ex = CachePayer.except(where_PUID_InsPlan)
      CachePayer = ex.union(update_PUID_InsPlan)
    }

    logger.warn("Update Status If Found PatientUid is null and Insurancepaln is null of CachePayer is Done............")

    //Update InsuredRelationToPatientText of CachePayer
    val update_InsuRTPText = CachePayer.filter($"StatusId" === 1 && rtrim(ltrim($"InsuredRelationToPatientText")).isNull
      && rtrim(ltrim($"InsuredRelationToPatientCode")).isNull)
      .withColumn("InsuredRelationToPatientText", $"InsuredRelationToPatientCode")

    val where_InsuRTPText = CachePayer.filter($"StatusId" === 1 && rtrim(ltrim($"InsuredRelationToPatientText")).isNull
      && rtrim(ltrim($"InsuredRelationToPatientCode")).isNull)

    if (where_InsuRTPText.count > 0) {
      val ex = CachePayer.except(where_InsuRTPText)
      CachePayer = ex.union(update_InsuRTPText)
    }

    logger.warn("Update InsuredRelationToPatientText of CachePayer is Done............")

    //Drop Duplicates of CachePayer
    var CleanedCachePayer = CachePayer.dropDuplicates(Seq("PatientUid", "InsurancePlan", "InsuranceCompany"
      , "Documentationdate", "PolicyID"))

    val CleanedCachePayer2 = CachePayer.dropDuplicates(Seq("PatientUid", "InsurancePlan", "InsuranceCompany"
      , "Documentationdate"))

    val CleanedCachePayer3 = CachePayer.dropDuplicates(Seq("PatientUid", "InsurancePlan", "InsuranceCompany", "PolicyID"))

    val CleanedCachePayer4 = CachePayer.dropDuplicates(Seq("PatientUid", "InsurancePlan", "InsuranceCompany"))

    CleanedCachePayer = CleanedCachePayer.union(CleanedCachePayer2).union(CleanedCachePayer3).union(CleanedCachePayer4)

    var DropDuplicates_Payer = CachePayer.except(CleanedCachePayer)
    val DropDuplicates_Payer2 = CachePayer.except(CleanedCachePayer2)
    val DropDuplicates_Payer3 = CachePayer.except(CleanedCachePayer3)
    val DropDuplicates_Payer4 = CachePayer.except(CleanedCachePayer4)

    DropDuplicates_Payer = DropDuplicates_Payer.union(DropDuplicates_Payer2).union(DropDuplicates_Payer3).union(DropDuplicates_Payer4)
    logger.warn("Drop Duplicates of CachePayer is Done............")

    //Update PatientInsuranceInfoUid from  PatientInsuranceInfo when policy id & date present of payer

    val update_PatientInsuranceInfoUid = CleanedCachePayer.as("df1").join(PatientInsuranceInfo_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany" && $"df1.PolicyID" === $"df2.PolicyID" &&
        $"df1.Documentationdate" === $"df2.Documentationdate" && $"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientInsuranceInfoUid".as("aliasPatientInsuranceInfoUid"))
      .withColumn("PatientInsuranceInfoUid", $"aliasPatientInsuranceInfoUid")
      .drop("aliasPatientInsuranceInfoUid")

    val where_PatientInsuranceInfoUid = CleanedCachePayer.as("df1").join(PatientInsuranceInfo_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany" && $"df1.PolicyID" === $"df2.PolicyID" &&
        $"df1.Documentationdate" === $"df2.Documentationdate" && $"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientInsuranceInfoUid.count > 0) {
      val ex = CleanedCachePayer.except(where_PatientInsuranceInfoUid)
      CleanedCachePayer = ex.union(update_PatientInsuranceInfoUid)
    }

    logger.warn("Update PatientInsuranceInfoUid from  PatientInsuranceInfo when policy id & date present of payer is Done............")

    // Update PatientInsuranceInfoUid from  PatientInsuranceInfo when only date present of Payer
    val update_PatientInsuranceInfoUid2 = CleanedCachePayer.as("df1").join(PatientInsuranceInfo_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany" && $"df1.Documentationdate" === $"df2.Documentationdate")
      .filter($"df1.StatusId" === 1 && $"PolicyID".isNull && $"df1.PatientInsuranceInfoUid".isNull)
      .select($"df1.*", $"df2.PatientInsuranceInfoUid".as("aliasPatientInsuranceInfoUid"))
      .withColumn("PatientInsuranceInfoUid", $"aliasPatientInsuranceInfoUid")
      .drop("aliasPatientInsuranceInfoUid")

    val where_PatientInsuranceInfoUid2 = CleanedCachePayer.as("df1").join(PatientInsuranceInfo_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany" && $"df1.Documentationdate" === $"df2.Documentationdate")
      .filter($"df1.StatusId" === 1 && $"PolicyID".isNull && $"df1.PatientInsuranceInfoUid".isNull)
      .select($"df1.*")

    if (where_PatientInsuranceInfoUid2.count > 0) {
      val ex = CleanedCachePayer.except(where_PatientInsuranceInfoUid2)
      CleanedCachePayer = ex.union(update_PatientInsuranceInfoUid2)
    }

    logger.warn("Update PatientInsuranceInfoUid from  PatientInsuranceInfo when only date present of Payer is Done............")

    //Update PatientInsuranceInfoUid from  PatientInsuranceInfo in case Documentationdate is null & PolicyID is not  null
    val update_PatientInsuranceInfoUid3 = CleanedCachePayer.as("df1").join(PatientInsuranceInfo_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany" && $"df1.PolicyID" === $"df2.PolicyID")
      .filter($"df1.StatusId" === 1 && $"Documentationdate".isNull && $"df1.PatientInsuranceInfoUid".isNull)
      .select($"df1.*", $"df2.PatientInsuranceInfoUid".as("aliasPatientInsuranceInfoUid"))
      .withColumn("PatientInsuranceInfoUid", $"aliasPatientInsuranceInfoUid")
      .drop("aliasPatientInsuranceInfoUid")

    val where_PatientInsuranceInfoUid3 = CleanedCachePayer.as("df1").join(PatientInsuranceInfo_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany" && $"df1.PolicyID" === $"df2.PolicyID")
      .filter($"df1.StatusId" === 1 && $"Documentationdate".isNull && $"df1.PatientInsuranceInfoUid".isNull)
      .select($"df1.*")

    if (where_PatientInsuranceInfoUid3.count > 0) {
      val ex = CleanedCachePayer.except(where_PatientInsuranceInfoUid3)
      CleanedCachePayer = ex.union(update_PatientInsuranceInfoUid3)
    }

    logger.warn("Update PatientInsuranceInfoUid from  PatientInsuranceInfo in case Documentationdate is null & PolicyID is not  null is Done............")

    //Update PatientInsuranceInfoUid from  PatientInsuranceInfo in case Documentationdate is null & PolicyID Null
    val update_PatientInsuranceInfoUid4 = CleanedCachePayer.as("df1").join(PatientInsuranceInfo_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany")
      .filter($"df1.StatusId" === 1 && $"Documentationdate".isNull && $"df1.PatientInsuranceInfoUid".isNull
        && $"df1.PolicyID".isNull)
      .select($"df1.*", $"df2.PatientInsuranceInfoUid".as("aliasPatientInsuranceInfoUid"))
      .withColumn("PatientInsuranceInfoUid", $"aliasPatientInsuranceInfoUid")
      .drop("aliasPatientInsuranceInfoUid")

    val where_PatientInsuranceInfoUid4 = CleanedCachePayer.as("df1").join(PatientInsuranceInfo_Prod.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany")
      .filter($"df1.StatusId" === 1 && $"Documentationdate".isNull && $"df1.PatientInsuranceInfoUid".isNull
        && $"df1.PolicyID".isNull)
      .select($"df1.*")

    if (where_PatientInsuranceInfoUid4.count > 0) {
      val ex = CleanedCachePayer.except(where_PatientInsuranceInfoUid4)
      CleanedCachePayer = ex.union(update_PatientInsuranceInfoUid4)
    }

    logger.warn("Update PatientInsuranceInfoUid from  PatientInsuranceInfo in case Documentationdate is null & PolicyID Null is Done............")

    //Create tempIns table
    val tempIns = CleanedCachePayer.filter($"StatusId" === 1 && $"Documentationdate".isNotNull
      && $"PolicyID".isNotNull && $"PatientInsuranceInfoUid".isNull)
      .select("PatientUid", "InsurancePlan", "InsuranceCompany", "Documentationdate", "PolicyID")
      .withColumn("PatientInsuranceInfoUid", FunctionUtility.getNewUid())

    //Update PatientInsuranceInfoUid for new Patient
    val update_PatientInsuranceInfoUid5 = CleanedCachePayer.as("df1").join(tempIns.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany" && $"df1.PolicyID" === $"df2.PolicyID"
        && $"df1.Documentationdate" === $"df2.Documentationdate")
      .filter($"df1.StatusId" === 1 && $"df1.PatientInsuranceInfoUid".isNull)
      .select($"df1.*", $"df2.PatientInsuranceInfoUid".as("aliasPatientInsuranceInfoUid"))
      .withColumn("PatientInsuranceInfoUid", $"aliasPatientInsuranceInfoUid")
      .drop("aliasPatientInsuranceInfoUid")

    val where_PatientInsuranceInfoUid5 = CleanedCachePayer.as("df1").join(tempIns.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany" && $"df1.PolicyID" === $"df2.PolicyID"
        && $"df1.Documentationdate" === $"df2.Documentationdate")
      .filter($"df1.StatusId" === 1 && $"df1.PatientInsuranceInfoUid".isNull)
      .select($"df1.*")

    if (where_PatientInsuranceInfoUid5.count > 0) {
      val ex = CleanedCachePayer.except(where_PatientInsuranceInfoUid5)
      CleanedCachePayer = ex.union(update_PatientInsuranceInfoUid5)
    }

    logger.warn("Update PatientInsuranceInfoUid for new patient in Payer is Done............")

    //Create Table tempIns2
    val tempIns2 = CleanedCachePayer.filter($"StatusId" === 1 && $"Documentationdate".isNotNull
      && $"PolicyID".isNull && $"PatientInsuranceInfoUid".isNull)
      .select("PatientUid", "InsurancePlan", "InsuranceCompany", "Documentationdate")
      .withColumn("PatientInsuranceInfoUid", FunctionUtility.getNewUid())

    //Update PatientInsuranceInfoUid using tempIns2
    val update_PatientInsuranceInfoUid6 = CleanedCachePayer.as("df1").join(tempIns2.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany" && $"df1.Documentationdate" === $"df2.Documentationdate")
      .filter($"df1.StatusId" === 1 && $"df1.PatientInsuranceInfoUid".isNull && $"df1.PolicyID".isNull)
      .select($"df1.*", $"df2.PatientInsuranceInfoUid".as("aliasPatientInsuranceInfoUid"))
      .withColumn("PatientInsuranceInfoUid", $"aliasPatientInsuranceInfoUid")
      .drop("aliasPatientInsuranceInfoUid")

    val where_PatientInsuranceInfoUid6 = CleanedCachePayer.as("df1").join(tempIns2.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany" && $"df1.Documentationdate" === $"df2.Documentationdate")
      .filter($"df1.StatusId" === 1 && $"df1.PatientInsuranceInfoUid".isNull && $"df1.PolicyID".isNull)
      .select($"df1.*")

    if (where_PatientInsuranceInfoUid6.count > 0) {
      val ex = CleanedCachePayer.except(where_PatientInsuranceInfoUid6)
      CleanedCachePayer = ex.union(update_PatientInsuranceInfoUid6)
    }

    logger.warn("Update PatientInsuranceInfoUid using tempIns2 is Done............")

    //Create Table tempIns3
    val tempIns3 = CleanedCachePayer.filter($"StatusId" === 1 && $"Documentationdate".isNull
      && $"PolicyID".isNotNull && $"PatientInsuranceInfoUid".isNull)
      .select("PatientUid", "InsurancePlan", "InsuranceCompany", "PolicyID")
      .withColumn("PatientInsuranceInfoUid", FunctionUtility.getNewUid())

    //Update PatientInsuranceInfoUid using tempIns3
    val update_PatientInsuranceInfoUid7 = CleanedCachePayer.as("df1").join(tempIns3.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany" && $"df1.PolicyID" === $"df2.PolicyID")
      .filter($"df1.StatusId" === 1 && $"df1.PatientInsuranceInfoUid".isNull && $"df1.Documentationdate".isNull)
      .select($"df1.*", $"df2.PatientInsuranceInfoUid".as("aliasPatientInsuranceInfoUid"))
      .withColumn("PatientInsuranceInfoUid", $"aliasPatientInsuranceInfoUid")
      .drop("aliasPatientInsuranceInfoUid")

    val where_PatientInsuranceInfoUid7 = CleanedCachePayer.as("df1").join(tempIns3.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany" && $"df1.PolicyID" === $"df2.PolicyID")
      .filter($"df1.StatusId" === 1 && $"df1.PatientInsuranceInfoUid".isNull && $"df1.Documentationdate".isNull)
      .select($"df1.*")

    if (where_PatientInsuranceInfoUid7.count > 0) {
      val ex = CleanedCachePayer.except(where_PatientInsuranceInfoUid7)
      CleanedCachePayer = ex.union(update_PatientInsuranceInfoUid7)
    }

    logger.warn("Update PatientInsuranceInfoUid using tempIns3 is Done............")
    //Create Table tempIns4
    val tempIns4 = CleanedCachePayer.filter($"StatusId" === 1 && $"Documentationdate".isNull
      && $"PolicyID".isNull && $"PatientInsuranceInfoUid".isNull)
      .select("PatientUid", "InsurancePlan", "InsuranceCompany")
      .withColumn("PatientInsuranceInfoUid", FunctionUtility.getNewUid())

    //Update PatientInsuranceInfoUid using tempIns4
    val update_PatientInsuranceInfoUid8 = CleanedCachePayer.as("df1").join(tempIns4.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany")
      .filter($"df1.StatusId" === 1 && $"df1.PatientInsuranceInfoUid".isNull && $"df1.Documentationdate".isNull
        && $"df1.PolicyID".isNull)
      .select($"df1.*", $"df2.PatientInsuranceInfoUid".as("aliasPatientInsuranceInfoUid"))
      .withColumn("PatientInsuranceInfoUid", $"aliasPatientInsuranceInfoUid")
      .drop("aliasPatientInsuranceInfoUid")

    val where_PatientInsuranceInfoUid8 = CleanedCachePayer.as("df1").join(tempIns4.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.InsurancePlan" === $"df2.InsurancePlan"
        && $"df1.InsuranceCompany" === $"df2.InsuranceCompany")
      .filter($"df1.StatusId" === 1 && $"df1.PatientInsuranceInfoUid".isNull && $"df1.Documentationdate".isNull
        && $"df1.PolicyID".isNull)
      .select($"df1.*")

    if (where_PatientInsuranceInfoUid8.count > 0) {
      val ex = CleanedCachePayer.except(where_PatientInsuranceInfoUid8)
      CleanedCachePayer = ex.union(update_PatientInsuranceInfoUid8)
    }

    logger.warn("Update PatientInsuranceInfoUid using tempIns4 is Done............")

    //Update InsuredRelationshipUid from MappingPracticeCommonData & MasterRelationship
    val update_InsuredRelationshipUid = CleanedCachePayer.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.InsuredRelationToPatientCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "182F46DC-3DBC-4C6D-8C50-1DB4C2C0BB85")
      .where($"df1.StatusId" === 1 && $"df1.InsuredRelationshipUid".isNull && $"df1.InsuredRelationToPatientText".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("InsuredRelationshipUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    val where_InsuredRelationshipUid = CleanedCachePayer.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.InsuredRelationToPatientCode" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "182F46DC-3DBC-4C6D-8C50-1DB4C2C0BB85")
      .where($"df1.StatusId" === 1 && $"df1.InsuredRelationshipUid".isNull && $"df1.InsuredRelationToPatientText".isNull)
      .select($"df1.*")

    if (where_InsuredRelationshipUid.count > 0) {
      val ex = CleanedCachePayer.except(where_InsuredRelationshipUid)
      CleanedCachePayer = ex.union(update_InsuredRelationshipUid)
    }

    logger.warn("Update InsuredRelationshipUid from MappingPracticeCommonData  is Done............")

    val update_InsuredRelationshipUid2 = CleanedCachePayer.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.InsuredRelationToPatientText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "182F46DC-3DBC-4C6D-8C50-1DB4C2C0BB85")
      .where($"df1.StatusId" === 1 && $"df1.InsuredRelationshipUid".isNull && $"df1.InsuredRelationToPatientText".isNull)
      .select($"df1.*", $"df2.MappedUid".as("aliasMappedUid"))
      .withColumn("InsuredRelationshipUid", $"aliasMappedUid")
      .drop("aliasMappedUid")

    //I think here InsuredRelationToPatientCode.isNull

    val where_InsuredRelationshipUid2 = CleanedCachePayer.as("df1").join(MappingPracticeCommonData_Delta.as("df2")
      , $"df1.InsuredRelationToPatientText" === $"df2.PracticeValue" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df2.MapperMasterCollectionUid" === "182F46DC-3DBC-4C6D-8C50-1DB4C2C0BB85")
      .where($"df1.StatusId" === 1 && $"df1.InsuredRelationshipUid".isNull && $"df1.InsuredRelationToPatientText".isNull)
      .select($"df1.*")

    if (where_InsuredRelationshipUid2.count > 0) {
      val ex = CleanedCachePayer.except(where_InsuredRelationshipUid2)
      CleanedCachePayer = ex.union(update_InsuredRelationshipUid2)
    }

    logger.warn("Update InsuredRelationshipUid from MappingPracticeCommonData 2 is Done............")

    //Update InsuredRelationshipUid using master table
    val update_InsuredRelationshipUid3 = CleanedCachePayer.as("df1").join(Master_prod.as("df2"),
      $"df1.InsuredRelationToPatientCode" === $"df2.Code" && $"df2.Type" === "CoverageRoleType")
      .filter($"df1.StatusId" === 1 && $"df1.InsuredRelationshipUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("InsuredRelationshipUid", $"aliasMasterUid").drop("aliasMasterUid")

    val where_InsuredRelationshipUid3 = CleanedCachePayer.as("df1").join(Master_prod.as("df2"),
      $"df1.InsuredRelationToPatientCode" === $"df2.Code" && $"df2.Type" === "CoverageRoleType")
      .filter($"df1.StatusId" === 1 && $"df1.InsuredRelationshipUid".isNull)
      .select($"df1.*")

    if (where_InsuredRelationshipUid3.count > 0) {
      val ex = CleanedCachePayer.except(where_InsuredRelationshipUid3)
      CleanedCachePayer = ex.union(update_InsuredRelationshipUid3)
    }
    logger.warn("Update InsuredRelationshipUid using master table is Done............")

    //Update InsuredRelationshipUid using master table
    val update_InsuredRelationshipUid4 = CleanedCachePayer.as("df1").join(Master_prod.as("df2"),
      $"df1.InsuredRelationToPatientText" === $"df2.Name" && $"df2.Type" === "CoverageRoleType")
      .filter($"df1.StatusId" === 1 && $"df1.InsuredRelationshipUid".isNull)
      .select($"df1.*", $"df2.MasterUid".as("aliasMasterUid"))
      .withColumn("InsuredRelationshipUid", $"aliasMasterUid").drop("aliasMasterUid")

    val where_InsuredRelationshipUid4 = CleanedCachePayer.as("df1").join(Master_prod.as("df2"),
      $"df1.InsuredRelationToPatientText" === $"df2.Name" && $"df2.Type" === "CoverageRoleType")
      .filter($"df1.StatusId" === 1 && $"df1.InsuredRelationshipUid".isNull)
      .select($"df1.*")

    if (where_InsuredRelationshipUid4.count > 0) {
      val ex = CleanedCachePayer.except(where_InsuredRelationshipUid4)
      CleanedCachePayer = ex.union(update_InsuredRelationshipUid4)
    }
    logger.warn("Update InsuredRelationshipUid using master table 2 is Done............")

    //Update PatientInsuranceInfo_Prod table
    val Update_PatientInsuranceInfo_Prod = PatientInsuranceInfo_Prod.as("df1").join(CleanedCachePayer.as("df2")
      , $"df1.PatientInsuranceInfoUid" === $"df2.PatientInsuranceInfoUid").filter($"df2.StatusId" === 1)
      .select($"df1.*", $"df2.InsuranceOrder".as("aliasINOrder"), $"df2.InsuredPersonId".as("aliasIPId")
        , $"df2.InsuredRelationshipUid".as("aliasIRUID"), $"df2.StartDateOfInsurance".as("aliasSDOInsurance")
        , $"df2.EndDateOfInsurance".as("aliasEDOInsurance"), $"df2.IsInsuredSameAsGuarantor".as("aliasIISAGuarantor")
        , $"df2.PayerID".as("aliasPayerId"), $"df2.PolicyID".as("aliasPolicyID"), $"df2.InsuranceCompany".as("aliasICompany")
        , $"df2.InsuranceGroup".as("aliasIGroup"), $"df2.PayerCity".as("aliasPayerCity"), $"df2.PayerState".as("aliasPayerState")
        , $"df2.PayerZip".as("aliasPayerZip"), $"df2.Insurance_Active".as("aliasIActive"), $"df2.BillingInsurance".as("aliasBInsurance")
        , $"df2.Documentationdate".as("aliasDDate"), $"df2.InsuredRelationToPatientText".as("aliasIRTPText"))
      .withColumn("ListOrder", $"aliasINOrder")
      .withColumn("PlanMemberID", $"aliasIPId")
      .withColumn("MasterCoverageRoleTypeUid", $"aliasIRUID")
      .withColumn("StartDateOfInsurance", $"aliasSDOInsurance")
      .withColumn("ExpirationDate", $"aliasEDOInsurance")
      .withColumn("InsuredSameAsGuarantor", when($"aliasIISAGuarantor".isNull, 0).otherwise($"aliasIISAGuarantor"))
      .withColumn("PayerId", $"aliasPayerId")
      .withColumn("PolicyId", $"aliasPolicyID")
      .withColumn("InsuranceCompany", $"aliasICompany")
      .withColumn("InsuranceGroup", $"aliasIGroup")
      .withColumn("PayerCity", $"aliasPayerCity")
      .withColumn("PayerState", $"aliasPayerState")
      .withColumn("PayerZip", $"aliasPayerZip")
      .withColumn("Inactive", when($"aliasIActive" === 1, 0).otherwise(1))
      .withColumn("BillingInsurance", $"aliasBInsurance")
      .withColumn("Documentationdate", $"aliasDDate")
      .withColumn("CoverageRoleTypeText", $"aliasIRTPText")
      .withColumn("ModifiedDate", current_timestamp())
      .drop("aliasINOrder", "aliasIPId", "aliasIRUID", "aliasSDOInsurance", "aliasEDOInsurance", "aliasIISAGuarantor"
        , "aliasPayerId", "aliasPolicyID", "aliasICompany", "aliasIGroup", "aliasPayerCity", "aliasPayerState", "aliasPayerZip"
        , "aliasIActive", "aliasBInsurance", "aliasDDate", "aliasIRTPText")

    val where_PatientInsuranceInfo =  PatientInsuranceInfo_Prod.as("df1").join(CleanedCachePayer.as("df2")
      , $"df1.PatientInsuranceInfoUid" === $"df2.PatientInsuranceInfoUid").filter($"df2.StatusId" === 1)
      .select($"df1.*")

    val ex_PatientInsuranceInfo = PatientInsuranceInfo_Prod.except(where_PatientInsuranceInfo)

    var PatientInsuranceInfo_Prod1 = ex_PatientInsuranceInfo.union(Update_PatientInsuranceInfo_Prod)

    //Insert New record to PatientInsuranceInfo
    val Insert_PatientInsuranceInfo_Prod = CleanedCachePayer.as("df1").join(PatientInsuranceInfo_Prod1.as("df2")
      , $"df1.PatientInsuranceInfoUid" === $"df2.PatientInsuranceInfoUid", "left_outer")
      .filter($"df1.StatusId" === 1)
      .select($"df1.PatientInsuranceInfoUid", $"df1.PatientUid", $"df1.InsuranceOrder".as("ListOrder"),
        $"df1.InsuredPersonId".as("PlanMemberID"), $"df1.InsuredRelationshipUid".as("MasterCoverageRoleTypeUid")
        , $"df1.StartDateOfInsurance", $"df1.EndDateOfInsurance".as("ExpirationDate")
        , when($"df1.IsInsuredSameAsGuarantor".isNull, 0).otherwise($"df1.IsInsuredSameAsGuarantor")
          .as("InsuredSameAsGuarantor"), $"df1.PayerID".as("PayerId"), $"df1.PolicyID".as("PolicyId")
        , $"df1.InsuranceCompany", $"df1.InsurancePlan", $"df1.InsuranceGroup", $"df1.PayerCity", $"df1.PayerState"
        , $"df1.PayerZip", when($"df1.Insurance_Active" === 1, 0).otherwise(1).as("Inactive")
        , $"df1.InsuredRelationToPatientText".as("CoverageRoleTypeText"), $"df1.BillingInsurance"
        , $"df1.Documentationdate")

    val PatientInsuranceInfo_allcols = PatientInsuranceInfo_Prod1.columns.toSet
    val insert_PatientIns_cols = Insert_PatientInsuranceInfo_Prod.columns.toSet
    val tot_cols = PatientInsuranceInfo_allcols ++ insert_PatientIns_cols

    PatientInsuranceInfo_Prod1 = PatientInsuranceInfo_Prod1.select(FunctionUtility.addColumns(PatientInsuranceInfo_allcols, tot_cols): _*)
      .union(Insert_PatientInsuranceInfo_Prod.select(FunctionUtility.addColumns(insert_PatientIns_cols, tot_cols): _*))

    logger.warn("End CachePayer.......................................................................................")
    //End CachePayer.......

    List(PatientInsuranceInfo_Prod1)
  }

}
