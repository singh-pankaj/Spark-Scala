package com.sample.practice

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory


class CachePatientNotesProblem {

  def CachePatientNotesProblemFunc(spark : SparkSession,MergePracticeMap : DataFrame
                                   ,CDRPatientCrosswalkTable : DataFrame
                                   ,ClinicalInformationModelSection : DataFrame
                                   ,MultiTableExtendTable : DataFrame
                                   ,Individual : DataFrame
                                   ,ProviderNPIChangeTable : DataFrame
                                   ,distIndUid : DataFrame
                                   ,distspUID : DataFrame
                                   ,Patient_Prod_Delta : DataFrame
                                   ,Individual_prod_Delta8 : DataFrame
                                   ,ViewServiceProvider_prod : DataFrame
                                   ,ViewFacility_Prod : DataFrame
                                   ,ServiceProvider_prod_Delta7 : DataFrame
                                   ,Institution_Prod_Delta4 : DataFrame
                                   ,ServiceLocation_Prod_Delta4 : DataFrame
                                   ,PatientNoteProblem_Prod : DataFrame) : List[DataFrame] = {

    val logger = LoggerFactory.getLogger("")
    import spark.implicits._
    //Start CachePatientNotesProblem
    var CachePatientNotesProblem =  spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9")

    val lookup12 = Map("_c0" -> "PatientId", "_c1" -> "EncounterDate", "_c2" -> "SectionName"
      , "_c3" -> "Note", "_c4" -> "ServiceProviderNPI", "_c5" -> "ServiceProviderLastName"
      , "_c6" -> "ServiceProviderFirstName", "_c7" -> "ServiceLocationId", "_c8" -> "ServiceLocationName"
      , "_c9" -> "Group1", "_c10" -> "Group2", "_c11" -> "Group3", "_c12" -> "Group4"
      , "_c13" -> "PracticePatientNoteKey", "_c14" -> "PracticeUid", "_c15" -> "BatchUid", "_c16" -> "dummy1"
      , "_c17" -> "dummy2")


    CachePatientNotesProblem = CachePatientNotesProblem.select(CachePatientNotesProblem.columns.map(c => col(c).as(lookup12.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2")

    val tempCachePatientNotesProblem = spark.read.option("header", "true")
      .csv("/home/gajanan.doifode/AAO_DATA/Schema/CachePatientNotesProblem.txt")

    val CachePNProblemAllcols = tempCachePatientNotesProblem.columns.toSet
    val CachePNProblemViewcols = CachePatientNotesProblem.columns.toSet
    val tot_viewPNP_PNProblem = CachePNProblemAllcols ++ CachePNProblemViewcols

    CachePatientNotesProblem = tempCachePatientNotesProblem.select(FunctionUtility.addColumns(CachePNProblemAllcols, tot_viewPNP_PNProblem): _*)
      .union(CachePatientNotesProblem.select(FunctionUtility.addColumns(CachePNProblemViewcols, tot_viewPNP_PNProblem): _*))

    CachePatientNotesProblem = CachePatientNotesProblem.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))

    val dist_PUID_PNProblem = CachePatientNotesProblem.filter($"StatusId".isNull).select("PracticeUid").distinct()
    val MergePracticeMap_PNProblem = MergePracticeMap.as("df1").join(dist_PUID_PNProblem.as("df2")
      , $"df1.NewPracticeUid" === $"df2.PracticeUid").select($"df1.*")

    logger.warn("MergePracticeMap_PNProblem is Created ......")

    //Update PracticeUid with OriginalPracticeUid of CachePatientNotesProblem
    CachePatientNotesProblem = CachePatientNotesProblem.as("df1").join(MergePracticeMap_PNProblem.as("df2")
      , $"df1.PracticeUid" === $"df2.NewPracticeUid", "inner").filter($"df1.StatusId".isNull)
      .select($"df1.*", $"df2.OriginalPracticeUid".as("AliasPracticeuid"))
      .withColumn("PracticeUid", $"AliasPracticeuid")
      .drop($"AliasPracticeuid")

    logger.warn("Update PracticeUid with OriginalPracticeUid of CachePatientNotesProblem is Done.................")

    CachePatientNotesProblem = CachePatientNotesProblem.withColumn("StatusId", lit(1))

    //Update Multiple Columns of CachePatientNotesProblem
    CachePatientNotesProblem = CachePatientNotesProblem.as("df1").filter($"StatusId" === 1)
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PatientId", ltrim(rtrim($"df1.PatientId")))
      .withColumn("ServiceProviderNPI", ltrim(rtrim($"df1.ServiceProviderNPI")))
      .withColumn("ServiceLocationId", ltrim(rtrim($"df1.ServiceLocationId")))
      .withColumn("SectionName", ltrim(rtrim($"df1.SectionName")))
      .withColumn("PracticePatientNoteKey", ltrim(rtrim($"df1.PracticePatientNoteKey")))
      .withColumn("PracticeSideNPI", ltrim(rtrim($"df1.ServiceProviderNPI")))

    logger.warn("Update Multiple Columns of CachePatientNotesProblem is Done............")

    //update status if PatientId is null Of CachePatientNotesProblem
    val update_status_PNProblem = CachePatientNotesProblem.filter($"StatusId" === 1 && $"PatientId".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PatientId is Missing"))

    val where_status_PNProblem = CachePatientNotesProblem.filter($"StatusId" === 1 && $"PatientId".isNull)

    if(where_status_PNProblem.count > 0) {
      val ex = CachePatientNotesProblem.except(where_status_PNProblem)
      CachePatientNotesProblem = ex.union(update_status_PNProblem)
    }

    logger.warn("update status if PatientId is null Of CachePatientNotesProblem is Done........")

    //Update PatientId using CDRPatientCrosswalk Of CachePatientNotesProblem Table
    val update_PatientId_PNProb = CachePatientNotesProblem.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Old_PatientId".as("aliasOld_PatientId"))
      .withColumn("PatientId", $"aliasOld_PatientId")
      .drop("aliasOld_PatientId")

    val where_PatientId_PNProb = CachePatientNotesProblem.as("df1").join(CDRPatientCrosswalkTable.as("df2")
      , $"df1.PatientId" === $"df2.New_PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientId_PNProb.count > 0) {
      val ex = CachePatientNotesProblem.except(where_PatientId_PNProb)
      CachePatientNotesProblem = ex.union(update_PatientId_PNProb)
    }

    logger.warn("Update PatientId using CDRPatientCrosswalk Of CachePatientNotesProblem  is Done........")

    //Update Multiple Status Of CachePatientNotesProblem
    val abc = CachePatientNotesProblem.filter($"StatusId" === 1 && $"PracticePatientNoteKey".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PracticePatientNoteKey is Not Found or Missing"))

    val jkl = CachePatientNotesProblem.filter($"StatusId" === 1 && $"SectionName".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("SectionName is null"))

    val mno = CachePatientNotesProblem.filter($"StatusId" === 1 && $"Note".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Note is null"))

    val update_status_PNProblem2 = abc.union(jkl).union(mno)

    val where_status_PNProblem2 = CachePatientNotesProblem.filter($"StatusId" === 1 && $"PracticePatientNoteKey".isNull
      || $"SectionName".isNull || $"Note".isNull)

    if (update_status_PNProblem2.count > 0) {
      val ex = CachePatientNotesProblem.except(update_status_PNProblem2)
      CachePatientNotesProblem = ex.union(update_status_PNProblem2)
    }

    logger.warn("Update Multiple Status Of CachePatientNotesProblem is Done........")


    //Update ClinicalInformationModelSectionUid of CachePatientNotesProblem
    val update_CInfoModelSecUid = CachePatientNotesProblem.as("df1").join(ClinicalInformationModelSection.as("df2")
      ,$"df1.SectionName" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ClinicalInformationModelSectionUid".isNull)
      .select($"df1.*",$"df2.ClinicalInformationModelSectionUid".as("aliasCIMSUID"))
      .withColumn("ClinicalInformationModelSectionUid",$"aliasCIMSUID")
      .drop("aliasCIMSUID")

    val where_CInfoModelSecUid = CachePatientNotesProblem.as("df1").join(ClinicalInformationModelSection.as("df2")
      ,$"df1.SectionName" === $"df2.Name")
      .filter($"df1.StatusId" === 1 && $"df1.ClinicalInformationModelSectionUid".isNull)
      .select($"df1.*")

    if (where_CInfoModelSecUid.count > 0) {
      val ex = CachePatientNotesProblem.except(where_CInfoModelSecUid)
      CachePatientNotesProblem = ex.union(update_CInfoModelSecUid)
    }

    logger.warn("Update ClinicalInformationModelSectionUid of CachePatientNotesProblem is Done........")

    //Update  Status ClinicalInformationModelSectionUid is Null Of CachePatientNotesProblem
    val update_status_PNProblem3 = CachePatientNotesProblem.filter($"StatusId" === 1
      && $"ClinicalInformationModelSectionUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Section Name Invalid or Missing"))

    val where_status_PNProblem3 = CachePatientNotesProblem.filter($"StatusId" === 1
      && $"ClinicalInformationModelSectionUid".isNull)

    if (where_status_PNProblem3.count > 0) {
      val ex = CachePatientNotesProblem.except(where_status_PNProblem3)
      CachePatientNotesProblem = ex.union(update_status_PNProblem3)
    }

    logger.warn("Update Status ClinicalInformationModelSectionUid is Null Of CachePatientNotesProblem is Done........")

    //Update ServiceProvideNPI Of CachePatientNotesProblem
    val update_SPNPI_PNProblem = CachePatientNotesProblem.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderNPI" === $"df2.Element1" && $"df2.GroupName" === "ProviderNPI")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.Value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue").drop($"AliasValue")

    val where_SPNPI_PNProblem = CachePatientNotesProblem.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderNPI" === $"df2.Element1" && $"df2.GroupName" === "ProviderNPI")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_SPNPI_PNProblem.count > 0) {
      val ex = CachePatientNotesProblem.except(where_SPNPI_PNProblem)
      CachePatientNotesProblem = ex.union(update_SPNPI_PNProblem)
    }

    logger.warn("update ServiceProviderNPI Of CachePatientNotesProblem is Done........")

    //update ServiceProviderNPI  Of CachePatientNotesProblem 2
    val update_SPNPI_PNProblem2 = Individual.as("df1")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid")
      .join(CachePatientNotesProblem.as("df3"), $"df3.PracticeUid" === $"df1.PracticeUid" &&
        $"df3.ServiceProviderNPI" === $"df2.OldNPI")
      .filter($"StatusId" === 1)
      .select($"df3.*", $"df2.NewNPI".as("AliasNewNPI"))
      .withColumn("ServiceProviderNPI", $"AliasNewNPI").drop($"AliasNewNPI")

    val where_SPNPI_PNProblem2 = Individual.as("df1")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid")
      .join(CachePatientNotesProblem.as("df3"), $"df3.PracticeUid" === $"df1.PracticeUid" &&
        $"df3.ServiceProviderNPI" === $"df2.OldNPI")
      .filter($"StatusId" === 1)
      .select($"df3.*")

    if (where_SPNPI_PNProblem2.count > 0) {
      val ex = CachePatientNotesProblem.except(where_SPNPI_PNProblem2)
      CachePatientNotesProblem = ex.union(update_SPNPI_PNProblem2)
    }

    logger.warn("update ServiceProviderNPI  Of CachePatientNotesProblem 2 is Done........")

    //Update ServiceProviderNPI of CachePatientNotesProblem 3
    val update_SPNPI_PNProblem3 = CachePatientNotesProblem.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element1" && $"df1.ServiceProviderLastName" === $"df2.Element2"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"df1.StatusId" === 1 && $"df2.Element2".isNotNull && $"df1.ServiceProviderNPI".isNull)
      .select($"df1.*", $"df2.Value".as("AliasValue"))
      .withColumn("ServiceProviderNPI", $"AliasValue").drop($"AliasValue")

    val where_SPNPI_PNProblem3 = CachePatientNotesProblem.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderFirstName" === $"df2.Element1" && $"df1.ServiceProviderLastName" === $"df2.Element2"
        && $"df2.GroupName" === "ProviderNPI")
      .filter($"df1.StatusId" === 1 && $"df2.Element2".isNotNull && $"df1.ServiceProviderNPI".isNull)
      .select($"df1.*")

    if (where_SPNPI_PNProblem3.count > 0) {
      val ex = CachePatientNotesProblem.except(where_SPNPI_PNProblem3)
      CachePatientNotesProblem = ex.union(update_SPNPI_PNProblem3)
    }

    logger.warn("update ServiceProviderNPI  Of CachePatientNotesProblem 3 is Done........")

    //update status if ServiceProviderNPI is Null Of CachePatientNotesProblem
    val update_status_PNProblem4 = CachePatientNotesProblem.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid NPI Found,Length should be 10"))

    val where_status_PNProblem4 = CachePatientNotesProblem.filter($"StatusId" === 1 && length($"ServiceProviderNPI") =!= 10)

    if (where_status_PNProblem4.count > 0) {
      val ex = CachePatientNotesProblem.except(where_status_PNProblem4)
      CachePatientNotesProblem = ex.union(update_status_PNProblem4)
    }

    logger.warn("update status if ServiceProviderNPI is Null Of CachePatientNotesProblem is Done........")

    //update PatientUid Using Patient_prod && Individual_prod of CachePatientNotesProblem
    val update_PatientUid_PNProb = CachePatientNotesProblem.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta8.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .drop("aliasPatientUid")

    val where_PatientUid_PNProb = CachePatientNotesProblem.as("df1").join(Patient_Prod_Delta.as("df2")
      , $"df1.PatientId" === $"df2.MedicalRecordNumber").join(Individual_prod_Delta8.as("df3")
      , $"df3.IndividualUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df3.PracticeUid")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientUid_PNProb.count > 0) {
      val ex = CachePatientNotesProblem.except(where_PatientUid_PNProb)
      CachePatientNotesProblem = ex.union(update_PatientUid_PNProb)
    }

    logger.warn("update PatientUid Using Patient_prod && Individual_prod of CachePatientNotesProblem is Done........")

    //Update ServiceProviderUid of CachePatientNotesProblem table
    val update_SPUID_PNProb = CachePatientNotesProblem.as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceProviderUid".as("aliasServiceProviderUid"))
      .withColumn("ServiceProviderUid", $"aliasServiceProviderUid")
      .drop("aliasServiceProviderUid")

    val where_SPUID_PNProb = CachePatientNotesProblem.as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1)
      .select($"df1.*")


    if (where_SPUID_PNProb.count > 0) {
      val ex = CachePatientNotesProblem.except(update_SPUID_PNProb)
      CachePatientNotesProblem = ex.union(update_SPUID_PNProb)
    }

    logger.warn("Update ServiceProviderUid of CachePatientNotesProblem table is Done........")

    //Update ServiceLocationUid of CachePatientNotesProblem table using ViewFacility
    val update_SLUID_PNProb = CachePatientNotesProblem.as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationId" === $"df2.ID"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceLocationUid".as("aliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"aliasServiceLocationUid")
      .drop("aliasServiceLocationUid")

    val where_SLUID_PNProb = CachePatientNotesProblem.as("df1")
      .join(ViewFacility_Prod.as("df2"), $"df1.ServiceLocationId" === $"df2.ID"
        && $"df1.PracticeUid" === $"df2.PracticeUid")
      .where($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_SLUID_PNProb.count > 0) {
      val ex = CachePatientNotesProblem.except(where_SLUID_PNProb)
      CachePatientNotesProblem = ex.union(update_SLUID_PNProb)
    }

    logger.warn("Update ServiceLocationUid of CachePatientNotesProblem table using ViewFacility is Done........")

    //update status if PatientUid is null Of CachePatientLanguage
    val update_status_PNProblem5 = CachePatientNotesProblem.filter($"StatusId" === 1 && $"PatientUid".isNull)
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Not Found"))

    val where_status_PNProblem5 = CachePatientNotesProblem.filter($"StatusId" === 1 && $"PatientUid".isNull)

    if (where_status_PNProblem5.count > 0) {
      val ex = CachePatientNotesProblem.except(where_status_PNProblem5)
      CachePatientNotesProblem = ex.union(update_status_PNProblem5)
    }

    logger.warn("update status if PatientUid is null Of CachePatientNotesProblem is Done........")

    //Create Table Phy of CachePatientNotesProblem

    val Phy_PNoteProb = CachePatientNotesProblem.as("df1")
      .select("ServiceProviderUid", "ServiceProviderNPI", "ServiceProviderFirstName", "ServiceProviderLastName"
        , "PracticeUid", "StatusId")
      .where($"ServiceProviderNPI".isNotNull && $"ServiceProviderUid".isNull && $"StatusId" === 1)
      .groupBy($"ServiceProviderNPI", $"PracticeUid")
      .agg(max("ServiceProviderFirstName").as("ServiceProviderFirstName")
        , max("ServiceProviderLastName").as("ServiceProviderLastName"))
      .withColumn("Physician_MidName", lit("null"))
      .withColumn("ServiceProviderUid",FunctionUtility.getNewUid())

    //Update ServiceProviderUid Using PHY of CachePatientNotesProblem
    val update_SPUID_PNProb2 = CachePatientNotesProblem.as("df1.").join(Phy_PNoteProb.as("df2")
      ,$"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderUid".isNull && $"df1.StatusId" === 1)
      .select($"df1.*",$"df2.ServiceProviderUid".as("aliasSPUID"))
      .withColumn("ServiceProviderUid",$"aliasSPUID")
      .drop("aliasSPUID")

    val where_SPUID_PNProb2 = CachePatientNotesProblem.as("df1.").join(Phy_PNoteProb.as("df2")
      ,$"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceProviderUid".isNull && $"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_SPUID_PNProb2.count > 0) {
      val ex = CachePatientNotesProblem.except(where_SPUID_PNProb2)
      CachePatientNotesProblem = ex.union(update_SPUID_PNProb2)
    }

    logger.warn("Update ServiceProviderUid Using PHY of CachePatientNotesProblem is Done........")

    //Insert data Into Individual Table using CachePatientNotesProblem
    val insert_Individual = Phy_PNoteProb.as("df1")
      .join(distIndUid.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.IndividualUid"))
      .select($"df1.ServiceProviderUid".as("IndividualUid"), $"df1.ServiceProviderFirstName".as("First")
        , $"df1.Physician_MidName".as("Middle"), $"ServiceProviderLastName".as("Last"),
        $"df1.PracticeUid".as("PracticeUid")).distinct()

    val indicols = Individual_prod_Delta8.columns.toSet
    val insertIndividualcols = insert_Individual.columns.toSet
    val tot = indicols ++ insertIndividualcols

    val Individual_prod_Delta9 = Individual_prod_Delta8.select(FunctionUtility.addColumns(indicols, tot): _*)
      .union(insert_Individual.select(FunctionUtility.addColumns(insertIndividualcols, tot): _*))

    logger.warn("Insert data Into Individual Table using CachePatientNotesProblem is Done............")

    //Insert data Into ServiceProvider Table using CachePatientNotesProblem
    val insert_ServiceProv = Phy_PNoteProb.as("df1").join(distspUID.as("df2")
      , !$"df1.ServiceProviderUid".isin($"df2.ServiceProviderUid"))
      .select($"df1.ServiceProviderUid", when($"df1.Physician_MidName".isNotNull, concat_ws(" "
        , $"ServiceProviderLastName", $"ServiceProviderFirstName", $"Physician_MidName"))
        .otherwise(concat_ws(" ", $"ServiceProviderLastName", $"ServiceProviderFirstName")).as("ListName")
        , $"df1.ServiceProviderNPI".as("NPI"))
      .withColumn("ExternalID", lit(null))
      .withColumn("Type", lit(4))

    val servicePcols = ServiceProvider_prod_Delta7.columns.toSet
    val insertdataServiceProvcols = insert_ServiceProv.columns.toSet
    val tot1 = servicePcols ++ insertdataServiceProvcols

    val ServiceProvider_prod_Delta8 = ServiceProvider_prod_Delta7.select(FunctionUtility.addColumns(servicePcols, tot1): _*)
      .union(insert_ServiceProv.select(FunctionUtility.addColumns(insertdataServiceProvcols, tot1): _*))
    logger.warn("Insert data Into ServiceProvider Table using CachePatientNotesProblem is Done............")

    //Create #Loc
    val tempLoc_PNProb = CachePatientNotesProblem.filter($"StatusId" === 1 && $"ServiceLocationUid".isNull
      && ltrim(rtrim($"ServiceLocationId")).isNotNull)
      .select($"ServiceLocationId",when($"ServiceLocationName".isNull,$"ServiceLocationId").otherwise($"ServiceLocationName")
        .as("ServiceLocationName"),$"PracticeUid")
      .withColumn("ServiceLocationUid",FunctionUtility.getNewUid())

    //Update ServiceLocationUid of CachePatientNotesProblem Using tempLoc
    val update_ServiceLUID_PNProb = CachePatientNotesProblem.as("df1").join(tempLoc_PNProb.as("df2")
      , $"df1.ServiceLocationId" === $"df2.ServiceLocationId" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceLocationName" === $"df2.ServiceLocationName")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*", $"df2.ServiceLocationUid".as("aliasServiceLocationUid"))
      .withColumn("ServiceLocationUid", $"aliasServiceLocationUid")
      .drop("aliasServiceLocationUid")

    val where_ServiceLUID_PNProb = CachePatientNotesProblem.as("df1").join(tempLoc_PNProb.as("df2")
      , $"df1.ServiceLocationId" === $"df2.ServiceLocationId" && $"df1.PracticeUid" === $"df2.PracticeUid"
        && $"df1.ServiceLocationName" === $"df2.ServiceLocationName")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_ServiceLUID_PNProb.count > 0) {
      val ex = CachePatientNotesProblem.except(where_ServiceLUID_PNProb)
      CachePatientNotesProblem = ex.union(update_ServiceLUID_PNProb)
    }

    logger.warn("Update ServiceLocationUid of CachePatientNotesProblem Using tempLoc is Done........")

    //Insert data Into Institution_Prod Using CachePatientNotesProblem
    val Insert_Institution_Prod = tempLoc_PNProb.select($"ServiceLocationUid".as("InstitutionUid")
      ,$"ServiceLocationName".as("Name"),$"PracticeUid")
      .withColumn("Type",lit(5))

    val allcols2 = Institution_Prod_Delta4.columns.toSet
    val insertcols2 = Insert_Institution_Prod.columns.toSet
    val tot4 = allcols2 ++ insertcols2

    val Institution_Prod_Delta5 =  Institution_Prod_Delta4.select(FunctionUtility.addColumns(allcols2, tot4): _*)
      .union(Insert_Institution_Prod.select(FunctionUtility.addColumns(insertcols2, tot4): _*))

    logger.warn("Insert into Institution Using tempLoc of CachePatientNotesProblem is Done............")

    //Insert data into ServiceLocation Using CachePatientNotesProblem
    val Insert_ServiceLocation = tempLoc_PNProb.select($"ServiceLocationUid"
      ,$"ServiceLocationId".as("ExternalID"))

    val allcols3 = ServiceLocation_Prod_Delta4.columns.toSet
    val insert3 = Insert_ServiceLocation.columns.toSet
    val tot5 = allcols3 ++ insert3

    val ServiceLocation_Prod_Delta5 = ServiceLocation_Prod_Delta4.select(FunctionUtility.addColumns(allcols3, tot5): _*)
      .union(Insert_ServiceLocation.select(FunctionUtility.addColumns(insert3, tot5): _*))

    //where and Union
    logger.warn("Insert data into ServiceLocation Using CachePatientNotesProblem is Done............")


    //Update PatientNoteProblemUid of CachePatientNotesProblem
    val update_PatientNoteProblemUid_PNP = CachePatientNotesProblem.as("df1").join(PatientNoteProblem_Prod.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*",$"df2.PatientNoteProblemUid".as("aliasPNPUid"))
      .withColumn("PatientNoteProblemUid",$"aliasPNPUid")
      .drop("aliasPNPUid")

    val where_PatientNoteProblemUid_PNP = CachePatientNotesProblem.as("df1").join(PatientNoteProblem_Prod.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey")
      .filter($"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientNoteProblemUid_PNP.count > 0) {
      val ex = CachePatientNotesProblem.except(where_PatientNoteProblemUid_PNP)
      CachePatientNotesProblem = ex.union(update_PatientNoteProblemUid_PNP)
    }

    logger.warn("Update PatientNoteProblemUid of CachePatientNotesProblem is Done........")

    //Drop Duplicates From CachePatientNotesProblem
    var cleanedCachePatientNotesProblem = CachePatientNotesProblem.dropDuplicates(Seq("PatientUid"
      , "PracticePatientNoteKey"))
    val duplicateRecords_CachePatientNotesProblem = CachePatientNotesProblem.except(cleanedCachePatientNotesProblem)
    logger.warn("Drop Duplicates From CachePatientNotesProblem is Done........")

    //Create Table PatientNoteProblem_PNProb
    val PatientNoteProblem_PNProb = cleanedCachePatientNotesProblem.filter($"StatusId" === 1 &&
      $"PatientNoteProblemUid".isNull && $"PracticePatientNoteKey".isNotNull)
      .select($"PatientUid",$"PracticePatientNoteKey").distinct()
      .withColumn("PatientNoteProblemUid",FunctionUtility.getNewUid())

    //Update PatientNoteProblemUid of CachePatientNotesProblem 2
    val update_PatientNoteProblemUid_PNP2 = cleanedCachePatientNotesProblem.as("df1").join(PatientNoteProblem_PNProb.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey"
        && $"df1.StatusId" === 1)
      .select($"df1.*",$"df2.PatientNoteProblemUid".as("aliasPNPUid"))
      .withColumn("PatientNoteProblemUid",$"aliasPNPUid")
      .drop("aliasPNPUid")

    val where_PatientNoteProblemUid_PNP2 = cleanedCachePatientNotesProblem.as("df1").join(PatientNoteProblem_PNProb.as("df2")
      ,$"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticePatientNoteKey" === $"df2.PracticePatientNoteKey"
        && $"df1.StatusId" === 1)
      .select($"df1.*")

    if (where_PatientNoteProblemUid_PNP2.count > 0) {
      val ex = cleanedCachePatientNotesProblem.except(where_PatientNoteProblemUid_PNP2)
      cleanedCachePatientNotesProblem = ex.union(update_PatientNoteProblemUid_PNP2)
    }

    logger.warn("Update PatientNoteProblemUid of CachePatientNotesProblem 2 is Done........")

    //Update PatientNoteProblem_Prod Using CachePatientNotesProblem
    val update_PatientNoteProblem_Prod_PNP = PatientNoteProblem_Prod.as("df1").join(cleanedCachePatientNotesProblem.as("df2")
      ,$"df1.PatientNoteProblemUid" === $"df2.PatientNoteProblemUid")
      .where($"df2.StatusId" === 1)
      .select($"df1.*",$"df2.Note".as("aliasNote"),$"df2.Group1".as("aliasGroup1"),$"df2.Group2".as("aliasG2")
        ,$"df2.Group3".as("aliasG3"),$"df2.Group4".as("aliasG4"),$"df2.PracticePatientNoteKey".as("aliasPPNoteKey"))
      .withColumn("Note",$"aliasNote")
      .withColumn("ModifiedDate",current_timestamp())
      .withColumn("Group1",$"aliasGroup1")
      .withColumn("Group2",$"aliasG2")
      .withColumn("Group3",$"aliasG3")
      .withColumn("Group4",$"aliasG4")
      .withColumn("PracticePatientNoteKey",$"aliasPPNoteKey")
      .drop("aliasNote","aliasGroup1","aliasG2","aliasG3","aliasG4","aliasPPNoteKey")

    val where_PNP = PatientNoteProblem_Prod.as("df1").join(cleanedCachePatientNotesProblem.as("df2")
      ,$"df1.PatientNoteProblemUid" === $"df2.PatientNoteProblemUid")
      .where($"df2.StatusId" === 1)
      .select($"df1.*")

    val ex_PNP = PatientNoteProblem_Prod.except(where_PNP)

    var PatientNoteProblem_Prod_Delta = ex_PNP.union(update_PatientNoteProblem_Prod_PNP)
    logger.warn("Update PatientNoteProblem_Prod Using CachePatientNotesProblem is Done........")

    //Insert Data Into PatientNoteProblem_Prod Using CachePatientNotesProblem
    val insert_PatientNoteProblem = cleanedCachePatientNotesProblem.as("df1").join(PatientNoteProblem_Prod_Delta.as("df2")
      ,$"df1.PatientNoteProblemUid" === $"df2.PatientNoteProblemUid","left_outer")
      .filter($"df1.StatusId" === 1 && $"df2.PatientNoteProblemUid".isNull)
      .select($"df1.PatientNoteProblemUid",$"df1.PatientUid",$"df1.ClinicalInformationModelSectionUid"
        ,$"df1.Note",$"df1.EncounterDate".as("ReferenceDate"),$"df1.ServiceProviderUid"
        ,$"df1.ServiceLocationUid",$"df1.Group1",$"df1.Group2",$"df1.Group3",$"df1.Group4"
        ,$"df1.PracticePatientNoteKey")
      .withColumn("CreatedDate",current_timestamp())
      .withColumn("CreatedByUid",lit("null"))
      .withColumn("ModifiedDate",current_timestamp())
      .withColumn("ModifiedByUid",lit("null"))

    val allcols5 = PatientNoteProblem_Prod_Delta.columns.toSet
    val insert5 = insert_PatientNoteProblem.columns.toSet
    val tot6 = allcols5 ++ insert5

    PatientNoteProblem_Prod_Delta = PatientNoteProblem_Prod_Delta.select(FunctionUtility.addColumns(allcols5, tot6): _*)
      .union(insert_PatientNoteProblem.select(FunctionUtility.addColumns(insert5, tot6): _*))

    logger.warn("Insert Data Into PatientNoteProblem_Prod Using CachePatientNotesProblem Done........")
    logger.warn("End CachePatientNotesProblem ....................")



    List(PatientNoteProblem_Prod_Delta,Individual_prod_Delta9,ServiceProvider_prod_Delta8,Institution_Prod_Delta5
    ,ServiceLocation_Prod_Delta5)
  }

}
