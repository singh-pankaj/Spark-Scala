package com.com.test.Demo

import java.util.UUID

import com.sample.practice.FunctionUtility
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{Column, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.slf4j.LoggerFactory

object Demo {



  def addColumns(myCols: Set[String], allCols: Set[String]) = {
    allCols.toList.map(x => x match {
      case x if myCols.contains(x) => col(x)
      case _ => lit(null).as(x)
    })
  }


  val getNewUid = udf[String](() => {
    UUID.randomUUID.toString
  })

  def checkColumns(col1 : Column, col2 : Column) : Column  = {
    if (col1.!= ("") && col2.!=(""))
    {
      val col3 =concat_ws("_",col1,col2)
      col3
    }
    else{
      null
    }
  }

  val updateWithJoin = udf[String,String,String]((column1: String, column2: String) => {
    if (column1 == null) column2
    else column1
  })

  def main(args: Array[String]): Unit = {


    val spark = SparkSession.builder()
      .master("local[*]")
      .appName("CachePatientDemographics")
      .getOrCreate()

    import spark.implicits._

    val logger = LoggerFactory.getLogger("")

    val cacheFile = spark.read.option("delimiter", "\u0017")
      .csv("/home/gajanan.doifode/AAO_DATA/0b333e7c-54fe-48d7-9c61-ec3a6c3de8a9/edea6658-b815-466d-aeea-17a9dd575dd1_22a060ac-69b9-4625-844e-b62aa39f11e8_ba74b4c7.txt")

    val lookup = Map("_c0" -> "PatientId", "_c1" -> "LastName", "_c2" -> "FirstName", "_c3" -> "MiddleName", "_c4" -> "StreetLineAddress1"
      , "_c5" -> "StreetLineAddress2", "_c6" -> "StreetLineAddress3", "_c7" -> "StreetLineAddress4", "_c8" -> "City", "_c9" -> "StateCode"
      , "_c10" -> "State", "_c11" -> "ZipCode", "_c12" -> "CountryCode", "_c13" -> "Country", "_c14" -> "TelecomTypeText1"
      , "_c15" -> "TelecomValue1", "_c16" -> "TelecomTypeText2", "_c17" -> "TelecomValue2", "_c18" -> "Gender", "_c19" -> "DOB"
      , "_c20" -> "DeathDate", "_c21" -> "MaritalStatusCode", "_c22" -> "MaritalStatusText", "_c23" -> "ReligiousAffiliationCode"
      , "_c24" -> "ReligiousAffiliationText", "_c25" -> "BirthStateCode", "_c26" -> "BirthState", "_c27" -> "BirthZipCode"
      , "_c28" -> "BirthCountryCode", "_c29" -> "BirthCountry", "_c30" -> "ServiceProviderNPI", "_c31" -> "ServiceProviderLastName"
      , "_c32" -> "ServiceProviderFirstName", "_c33" -> "SSN", "_c34" -> "DeathReason", "_c35" -> "IsDeceased", "_c36" -> "Patient_EMR_ID"
      , "_c37" -> "EmailID", "_c38" -> "LocationOfDeath", "_c39" -> "BirthOrder", "_c40" -> "MultipleBirthPlaceIndicator"
      , "_c41" -> "PatientDemographicsKey", "_c42" -> "PracticeUid", "_c43" -> "BatchUid", "_c44" -> "dummy1", "_c45" -> "dummy2")

    var CachepatientDemo = cacheFile.select(cacheFile.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*) .drop("dummy1", "dummy2")

    val tempCachedemo = spark.read.option("header", "true").csv("/home/gajanan.doifode/AAO_DATA/Schema/CDRSchema.txt")


    val allcols = tempCachedemo.columns.toSet
    val viewcols = CachepatientDemo.columns.toSet
    val total = allcols ++ viewcols

    logger.warn("Files are reading")

    CachepatientDemo = tempCachedemo.select(addColumns(allcols, total): _*)
      .union(CachepatientDemo.select(addColumns(viewcols, total): _*))

    CachepatientDemo = CachepatientDemo.withColumn("PracticeUid", upper($"PracticeUid"))
      .withColumn("ServiceProviderNPI", lit("1053428771"))

    CachepatientDemo = CachepatientDemo.withColumn("RowId", row_number.over(Window.orderBy("PatientId")))


    val temp_prac1 = CachepatientDemo.withColumn("PracticeUid", upper($"PracticeUid"))
      .select($"PracticeUid").distinct()

    //ImportPatientData

    logger.warn("Start ImportPatientData ..........")
    println("Start ImportPatientData ..........")


    val PracticeImportDetails = spark.read.format("jdbc")
      .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
      .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
      .option("dbtable", "PracticeImportDetails")
      .option("user", "mapping")
      .option("password", "mp3245")
      .load()

    //Create CachePractice table
    val cachepractice = PracticeImportDetails.as("df1")
      .join(temp_prac1.as("df2"), $"df1.PracticeUid" === $"df2.PracticeUid")
      .filter($"df1.PracticeUid".isin($"df2.PracticeUid"))
      .select($"df1.*")

    //Add StatusId = 1
    val CachepatientDemo1 = CachepatientDemo.withColumn("StatusID", lit(1))
      .withColumn("ModifiedDate", lit("null"))
      .withColumn("ErrorNote", lit("null"))

    logger.warn("Added StatusId = 1 is Done............")

    println("Added StatusId = 1 is Done............")

    //Update oldPracticeuid Column and Other Imp columns
    val CachepatientDemo2 = CachepatientDemo1.as("df1")
      .withColumn("OldPracticeUid", $"df1.PracticeUid")
      .withColumn("PracticeSideNPI", $"df1.ServiceProviderNPI")
      .withColumn("FirstName", rtrim(ltrim($"df1.FirstName")))
      .withColumn("LastName", rtrim(ltrim($"df1.LastName")))
      .withColumn("Gender", rtrim(ltrim($"df1.Gender")))
      .withColumn("PatientId", rtrim(ltrim($"df1.PatientId")))
      .withColumn("ServiceProviderNPI", rtrim(ltrim($"df1.ServiceProviderNPI")))

    logger.warn("Update oldPracticeuid Column and Other Imp columns............")
    println("Update oldPracticeuid Column and Other Imp columns............")

    //Find Practiceuid null then update StatusId = 3
    val updateStatus = CachepatientDemo2.as("df1").filter( $"PracticeUid".isNull && $"PatientId".isNull)
      .withColumn("StatusID", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("PracticeUid is Null OR Patient Not Found is"))

    val where1 = CachepatientDemo2.as("df1").filter( $"PracticeUid".isNull && $"PatientId".isNull)

    val CachepatientDemo3 = CachepatientDemo2.except(where1)

    logger.warn("Find Practiceuid null then update StatusId = 3 is Done............")
    println("Find Practiceuid null then update StatusId = 3 is Done............")

    val MultiTableExtendTable = spark.read.format("jdbc")
      .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
      .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
      .option("dbtable", "MultiTableExtend")
      .option("user", "mapping")
      .option("password", "mp3245")
      .load()

    val updatespNPI_Demo = CachepatientDemo3.as("df1")
      .join(MultiTableExtendTable.as("df2"), $"df1.PracticeUid" === "df2.PracticeUid"
        && $"df2.GroupName" === "ProviderNPI" && $"df1.ServiceProviderNPI" === $"df2.Element1", "left_outer")
      .select($"df1.*", $"df2.Value".as("AliasValue"))
      .withColumn("ServiceProviderNPI",updateWithJoin($"ServiceProviderNPI",$"AliasValue"))
       .drop($"AliasValue")


    logger.warn("Update ServiceProviderNPI is Done............")
    println("Update ServiceProviderNPI is Done............")


    val Individual = spark.read.format("jdbc")
      .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
      .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
      .option("dbtable", "Individual")
      .option("user", "mapping")
      .option("password", "mp3245")
      .load()


    val ProviderNPIChangeTable = spark.read.format("jdbc")
      .option("url", "jdbc:sqlserver://10.20.201.116:1433;database=FIGMDHQIManagement")
      .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
      .option("dbtable", "ProviderNPIChange")
      .option("user", "mapping")
      .option("password", "mp3245")
      .load()


    val updatespNPI2_Demo = updatespNPI_Demo.as("df3")
      .join(Individual.as("df1"),$"df3.PracticeUid" === $"df1.PracticeUid","left_outer")
      .join(ProviderNPIChangeTable.as("df2"), $"df1.IndividualUid" === $"df2.ServiceProviderUid"
      && $"df3.ServiceProviderNPI" === $"df2.OldNPI","left_outer")
      .select($"df3.*", $"df2.NewNPI".as("AliasNewNPI"))
      .withColumn("ServiceProviderNPI",updateWithJoin($"ServiceProviderNPI",$"AliasNewNPI"))
      .drop($"AliasNewNPI")

    logger.warn("Update ServiceProviderNPI with difference condition is Done............")

    //Update StatusId = 3 if ServiceProviderNPI length is less than 10
    val updateStatusNPI = updatespNPI2_Demo.filter(length($"ServiceProviderNPI") =!= 10 && $"DOB".isNull)
      .withColumn("StatusID", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Invalid NPI Found,Length should be 10 OR Patient Birth Date Not Found"))

    var AllStatusvalue  = updateStatus.union(updateStatusNPI)
    val where2 = updatespNPI2_Demo.filter(length($"ServiceProviderNPI") =!= 10 && $"DOB".isNull)
    val cleanedDemo1 = updatespNPI2_Demo.except(where2)

    logger.warn("Update StatusId = 3 if DOB not found is Done............")
    println("Update StatusId = 3 if DOB not found is Done............")


    //Drop Duplicate records and store in in-memory not update status = 4
    val duplicates =  cleanedDemo1.withColumn("rank", row_number().over(Window.partitionBy($"PatientId",$"PracticeUid").orderBy($"PatientId".asc)))
      .filter("rank > 1")
      .withColumn("StatusID",lit(4))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote",lit("Duplicate Record"))
      .drop("rank")

    AllStatusvalue = AllStatusvalue.union(duplicates)
    logger.warn("Drop Duplicate records and store in in-memory not update status = 4 is Done............")
    println("Drop Duplicate records and store in in-memory not update status = 4 is Done............")

    //Different MRN Found For Same FirstName,LastName,dob,SSN,PracticeUid with SSN

    val dup = cleanedDemo1.filter($"SSN".isNotNull)
      .select("FirstName", "LastName", "DOB", "PracticeUid", "SSN", "PatientId").distinct()

    val finddiffMRN = cleanedDemo1.as("df1").join(dup.as("df2"),
      $"df1.FirstName" === $"df2.FirstName" &&
        $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df1.LastName" === $"df2.LastName" &&
        $"df1.SSN" === $"df2.SSN" &&
        $"df1.PatientId" =!= $"df2.PatientId")
      .join(cachepractice.filter($"IsDuplicatePatient" === 0).as("df3")
      , $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*")
      .withColumn("StatusID", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Different MRN Found For Same FirstName,LastName,dob,SSN,PracticeUid"))

    val finddiff1 = cleanedDemo1.as("df1").join(dup.as("df2"),
      $"df1.FirstName" === $"df2.FirstName" &&
        $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df1.LastName" === $"df2.LastName" &&
        $"df1.SSN" === $"df2.SSN" &&
        $"df1.PatientId" =!= $"df2.PatientId")
      .join(cachepractice.filter($"IsDuplicatePatient" === 0).as("df3")
        , $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*")

     AllStatusvalue = AllStatusvalue.union(finddiffMRN)

    val k1 = cleanedDemo1.rdd
    val m1 = finddiff1.rdd
    val sub1 = k1.subtract(m1)
    val cleanedDemo2 = spark.createDataFrame(sub1,StructType(Schema.someSchema))
    println("Different MRN Found For Same FirstName,LastName,dob,SSN,PracticeUid with SSN")

    //Different MRN Found For Same FirstName,LastName,dob,SSN,PracticeUid without SSN

    cleanedDemo2.persist()

    val dup2 = cleanedDemo2.filter($"SSN".isNull)
      .select("FirstName", "LastName", "DOB", "PracticeUid", "PatientId").distinct()

    val finddiffMRN2 = cleanedDemo2.as("df1").join(dup2.as("df2"),
      $"df1.FirstName" === $"df2.FirstName" &&
        $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df1.LastName" === $"df2.LastName" &&
        $"df1.DOB" === $"df2.DOB" &&
        $"df1.PatientId" =!= $"df2.PatientId")
      .join(cachepractice.filter($"IsDuplicatePatient" === 0).as("df3")
        , $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*")
      .withColumn("StatusID", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Different MRN Found For Same FirstName,LastName,dob,PracticeUid"))


    val finddiffMRN123 = cleanedDemo2.as("df1").join(dup2.as("df2"),
      $"df1.FirstName" === $"df2.FirstName" &&
        $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df1.LastName" === $"df2.LastName" &&
        $"df1.DOB" === $"df2.DOB" &&
        $"df1.PatientId" =!= $"df2.PatientId")
      .join(cachepractice.filter($"IsDuplicatePatient" === 0).as("df3")
        , $"df1.PracticeUid" === $"df3.PracticeUid")
      .select($"df1.*")

    AllStatusvalue = AllStatusvalue.union(finddiffMRN2)
    val k2 = cleanedDemo2.rdd
    val m2 = finddiffMRN123.rdd
    val sub2 = k2.subtract(m2)
   val cleanedDemo3 = spark.createDataFrame(sub2,StructType(Schema.someSchema))

    cleanedDemo2.unpersist()

    logger.warn("Different MRN Found For Same FirstName,LastName,dob,SSN,PracticeUid without SSN is Done............")
    println("Different MRN Found For Same FirstName,LastName,dob,SSN,PracticeUid without SSN is Done............")

    val Individual_prod = spark.read.format("jdbc")
      .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
      .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
      .option("dbtable", "Individual")
      .option("user", "mapping")
      .option("password", "mp3245")
      .load()

    val Patient_prod = spark.read.format("jdbc")
      .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
      .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
      .option("dbtable", "Patient")
      .option("user", "mapping")
      .option("password", "mp3245")
      .load()

    val Individualidentifier_prod = spark.read.format("jdbc")
      .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
      .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
      .option("dbtable", "IndividualIdentifier")
      .option("user", "mapping")
      .option("password", "mp3245")
      .load()



    cleanedDemo3.persist()
    Patient_prod.persist()
    Individual_prod.persist()

    val updateexistmrn = cleanedDemo3.filter($"StatusId" === 1).as("df1")
      .join(Individual_prod.as("df2")
        , $"df1.FirstName" === $"df2.First" &&
          $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df1.DOB" === $"df2.BirthDate" &&
          $"df1.LastName" === $"df2.Last")
      .join(Patient_prod.as("df3")
        , $"df3.PatientUid" === $"df2.IndividualUid")
      .join(Individualidentifier_prod.as("df4")
        , $"df1.SSN" === $"df4.Identifier" &&
          $"df4.IndividualUid" === $"df1.PatientUid") //Doubt
      .join(cachepractice.filter($"IsDuplicatePatient" === 0).as("df5"), $"df5.PracticeUid" === $"df1.PracticeUid")
      .where($"df3.MedicalRecordNumber" =!= $"df1.PatientId")
      .select($"df1.*")
      .withColumn("StatusId", lit(3))
      .withColumn("ModifiedDate", lit(current_timestamp))
      .withColumn("ErrorNote", lit("Patient Already Exists With Different MedicalRecordNumber"))

    val whereexistmrn = cleanedDemo3.filter($"StatusId" === 1).as("df1")
      .join(Individual_prod.as("df2")
        , $"df1.FirstName" === $"df2.First" &&
          $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df1.DOB" === $"df2.BirthDate" &&
          $"df1.LastName" === $"df2.Last")
      .join(Patient_prod.as("df3")
        , $"df3.PatientUid" === $"df2.IndividualUid")
      .join(Individualidentifier_prod.as("df4")
        , $"df1.SSN" === $"df4.Identifier" &&
          $"df4.IndividualUid" === $"df1.PatientUid") //Doubt
      .join(cachepractice.filter($"IsDuplicatePatient" === 0).as("df5"), $"df5.PracticeUid" === $"df1.PracticeUid")
      .where($"df3.MedicalRecordNumber" =!= $"df1.PatientId")
      .select($"df1.*")

    AllStatusvalue = AllStatusvalue.union(updateexistmrn)
    val cleanedDemo4 = cleanedDemo3.except(whereexistmrn)
    logger.warn("Patient Already Exists With Different MedicalRecordNumber is Done............")
    println("Patient Already Exists With Different MedicalRecordNumber is Done............")

    cleanedDemo3.unpersist()

    //Update Patient Details From MedicalRecordNumber
   /* val cleanedDemo5 = cleanedDemo4.as("df1")
      .join(Patient_prod.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber","left_outer")
      .join(Individual_prod.as("df3"), $"df3.IndividualUid" === $"df2.PatientUid"
        && $"df3.PracticeUid" === $"df1.PracticeUid","left_outer")
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"), $"df2.BirthPlaceUid".as("aliasBirthPlaceUid"),
        $"df3.Address1Uid".as("aliasAddress1Uid"), $"df3.Phone1Uid".as("aliasPhone1Uid")
        , $"df3.Phone2Uid".as("aliasPhone2Uid"))
      .withColumn("PatientUid",updateWithJoin($"PatientUid",$"aliasPatientUid"))
      .withColumn("AddressUid",updateWithJoin($"AddressUid",$"aliasAddress1Uid"))
      .withColumn("Phone1Uid",updateWithJoin($"Phone1Uid",$"aliasPhone1Uid"))
      .withColumn("Phone2Uid",updateWithJoin($"Phone2Uid",$"aliasPhone2Uid"))
      .withColumn("BirthPlaceUid",updateWithJoin($"BirthPlaceUid",$"aliasBirthPlaceUid"))
      .drop("aliasPatientUid", "aliasAddress1Uid", "aliasPhone1Uid", "aliasPhone2Uid", "aliasBirthPlaceUid")
        .distinct()*/



 val cleanedDemo51 = cleanedDemo4.as("df1")
     .join(Patient_prod.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod.as("df3"), $"df3.IndividualUid" === $"df2.PatientUid"
        && $"df3.PracticeUid" === $"df1.PracticeUid")
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"), $"df2.BirthPlaceUid".as("aliasBirthPlaceUid"),
        $"df3.Address1Uid".as("aliasAddress1Uid"), $"df3.Phone1Uid".as("aliasPhone1Uid")
        , $"df3.Phone2Uid".as("aliasPhone2Uid"))
      .withColumn("PatientUid", $"aliasPatientUid")
      .withColumn("AddressUid", $"aliasAddress1Uid")
      .withColumn("Phone1Uid", $"aliasPhone1Uid")
      .withColumn("Phone2Uid", $"aliasPhone2Uid")
      .withColumn("BirthPlaceUid", $"aliasBirthPlaceUid")
      .drop("aliasPatientUid", "aliasAddress1Uid", "aliasPhone1Uid", "aliasPhone2Uid", "aliasBirthPlaceUid")

    val where = cleanedDemo4.as("df1")
     .join(Patient_prod.as("df2"), $"df1.PatientId" === $"df2.MedicalRecordNumber")
      .join(Individual_prod.as("df3"), $"df3.IndividualUid" === $"df2.PatientUid"
        && $"df3.PracticeUid" === $"df1.PracticeUid")
      .select($"df1.*")

    val except = cleanedDemo4.except(where)
    val cleanedDemo5 = except.union(cleanedDemo51)

    println("Update Patient Details From MedicalRecordNumber is Done............")
    logger.warn("Update Patient Details From MedicalRecordNumber is Done............")


    val ViewServiceProvider_prod = spark.read.format("jdbc")
      .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
      .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
      .option("dbtable", "ViewServiceProvider")
      .option("user", "mapping")
      .option("password", "mp3245")
      .load()

    val cleanedDemo6 = cleanedDemo5.as("df1")
      .join(ViewServiceProvider_prod.as("df2"), $"df1.ServiceProviderNPI" === $"df2.NPI"
        && $"df1.PracticeUid" === $"df2.PracticeUid","left_outer")
      .select($"df1.*", $"df2.ServiceProviderUid".as("aliasServiceProviderUid"))
      .withColumn("ServiceProviderUid",updateWithJoin($"ServiceProviderUid",$"aliasServiceProviderUid"))
      .drop("aliasServiceProviderUid")

    println("update ServiceProvider Details From ServiceProviderNPI is Done............")
    cleanedDemo3.unpersist()
    cleanedDemo6.persist()
    //cleanedDemo6.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/cleanedDemo6.csv")

    //Generate ServiceProviderUid (#phy = newServiceProvider)
    var newServiceProvider = cleanedDemo6.where($"ServiceProviderNPI".isNotNull)
      .select("ServiceProviderNPI", "ServiceProviderFirstName", "ServiceProviderLastName", "PracticeUid")
      .groupBy($"ServiceProviderNPI", $"PracticeUid")
      .agg(max("ServiceProviderFirstName").as("ServiceProviderFirstName")
        , max("ServiceProviderLastName").as("ServiceProviderLastName"))
      .withColumn("Physician_MidName", lit("null"))

    println("create Table #phy Table")

    newServiceProvider = cleanedDemo6.filter($"ServiceProviderUid".isNull).as("df1")
      .join(newServiceProvider.as("df2")
        , $"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI")
      .select($"df2.*")
      .withColumn("ServiceProviderUid", getNewUid())

    logger.warn("Generate ServiceProviderUid (#phy = newServiceProvider) is Done............")
    println("Generate ServiceProviderUid (#phy = newServiceProvider) is Done............")

    //Update ServiceProviderUid
    val cleanedDemo7 = cleanedDemo6.as("df1")
      .join(newServiceProvider.as("df2"), $"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" &&
        $"df1.PracticeUid" === $"df2.PracticeUid" &&
        $"df1.ServiceProviderUid".isNull,"left_outer")
      .select($"df1.*", $"df2.ServiceProviderUid".as("aliasServiceProviderUid"))
      .withColumn("ServiceProviderUid",updateWithJoin($"ServiceProviderUid",$"aliasServiceProviderUid"))
      .drop("aliasServiceProviderUid")

    println("Update ServiceProviderUid using newServiceProvider table")

   // cleanedDemo7.coalesce(1).write.option("header","true").csv("/home/gajanan.doifode/AAO_DATA/cleanedDemo7.csv")

    println("write a csv")

    val distIndUid = Individual_prod.select("IndividualUid").distinct()



    //Insert Data into Individual table
    val insertIndividual = newServiceProvider.as("df1")
      .join(distIndUid.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.IndividualUid"),"left_outer")
      .select($"df1.ServiceProviderUid".as("IndividualUid"), $"df1.ServiceProviderFirstName".as("First")
        , $"df1.Physician_MidName".as("Middle"), $"ServiceProviderLastName".as("Last"),
        $"df1.PracticeUid".as("PracticeUid")).distinct()

    val indicols = Individual_prod.columns.toSet
    val insertIndividualcols = insertIndividual.columns.toSet
    val tot = indicols ++ insertIndividualcols

    var Individual_prod1 = Individual_prod.select(FunctionUtility.addColumns(indicols, tot): _*)
      .union(insertIndividual.select(FunctionUtility.addColumns(insertIndividualcols, tot): _*))

    //Individual_prod1.coalesce(1).write.option("header","true")
      //.csv("s3://bd-dev/aao_test/Individual_prod1.csv")

    logger.warn("Insert Data into Individual table is Done............")
    println("Insert Data into Individual table is Done............")

    var ServiceProvider_prod = spark.read.format("jdbc")
      .option("url", "jdbc:sqlserver://10.20.201.89:1433;database=FIGMDHQICDR_81")
      .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
      .option("dbtable", "ServiceProvider")
      .option("user", "mapping")
      .option("password", "mp3245")
      .load()

    val distspUID = ServiceProvider_prod.select("ServiceProviderUid").distinct()

    val insertdataServiceProv = newServiceProvider.as("df1")
      .join(distspUID.as("df2"), !$"df1.ServiceProviderUid".isin($"df2.ServiceProviderUid"))
      .withColumn("ListName", when($"df1.Physician_MidName".isNotNull, concat_ws(" "
        , $"ServiceProviderLastName", $"ServiceProviderFirstName", $"Physician_MidName"))
        .otherwise(concat_ws(" ", $"ServiceProviderLastName", $"ServiceProviderFirstName")))
      .select($"df1.ServiceProviderUid", $"ListName", $"df1.ServiceProviderNPI".as("NPI"))
      .withColumn("ExternalID", lit(null))
      .withColumn("Type", lit(4))

    val servicePcols = ServiceProvider_prod.columns.toSet
    val insertdataServiceProvcols = insertdataServiceProv.columns.toSet
    val tot1 = servicePcols ++ insertdataServiceProvcols

    var ServiceProvider_prod1 = ServiceProvider_prod.select(FunctionUtility.addColumns(servicePcols, tot1): _*)
      .union(insertdataServiceProv.select(FunctionUtility.addColumns(insertdataServiceProvcols, tot1): _*))

    /*ServiceProvider_prod1.coalesce(1).write.option("header","true")
      .csv("s3://bd-dev/aao_test/ServiceProvider_prod1.csv")*/

    logger.warn("Insert Data into ServiceProvider is Done............")
    println("Insert Data into ServiceProvider is Done............")


    //Generating AddressUid
    val tempPataddressUid = cleanedDemo7.filter($"PatientUid".isNotNull &&
      $"AddressUid".isNull && rtrim(ltrim($"StreetLineAddress1")).isNotNull &&
      rtrim(ltrim($"StreetLineAddress2")).isNotNull && rtrim(ltrim($"StreetLineAddress3")).isNotNull &&
      rtrim(ltrim($"StreetLineAddress4")).isNotNull && rtrim(ltrim($"ZipCode")).isNotNull && rtrim(ltrim($"City")).isNotNull)
      .select("PatientId", "PracticeUid", "PatientUid")
      .withColumn("AddressUid", getNewUid())
      .withColumn("BirthPlaceUid",getNewUid())
      .withColumn("Phone1Uid", getNewUid())
      .withColumn("Phone2Uid",getNewUid())
    println("create table tempPataddressUid........................")

    val cleanedDemo8 = cleanedDemo7.as("df1")
      .join(tempPataddressUid.as("df2")
        , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df2.PracticeUid","left_outer")
      .select($"df1.*", $"df2.AddressUid".as("aliasAddressUid"), $"df2.BirthPlaceUid".as("aliasBirthPlaceUid")
        , $"df2.Phone1Uid".as("aliasPhone1Uid"), $"df2.Phone2Uid".as("aliasPhone2Uid"))
      .withColumn("AddressUid",updateWithJoin($"AddressUid",$"aliasAddressUid"))
      .withColumn("BirthPlaceUid",updateWithJoin($"BirthPlaceUid",$"aliasBirthPlaceUid"))
      .withColumn("Phone1Uid",when($"TelecomValue1".isNotNull,updateWithJoin($"Phone1Uid",$"aliasPhone1Uid")).otherwise(null))
      .withColumn("Phone2Uid",when($"TelecomValue2".isNotNull,updateWithJoin($"Phone2Uid",$"aliasPhone2Uid")).otherwise(null))
      .drop("aliasAddressUid", "aliasBirthPlaceUid", "aliasPhone1Uid", "aliasPhone2Uid")

    println("Generate Uid's Uisng table tempPataddressUid")

    //Generating New PatientUid from PatientId,PracticeUid for New Patient
    val tempPatUid = cleanedDemo8.filter($"PatientUid".isNull)
      .select("PatientId", "PracticeUid").distinct()
      .withColumn("PatientUid", getNewUid())
      .withColumn("AddressUid", getNewUid())
      .withColumn("BirthPlaceUid", getNewUid())
      .withColumn("Phone1Uid", getNewUid())
      .withColumn("Phone2Uid", getNewUid())

    val cleanedDemo9 = cleanedDemo8.as("df1").join(tempPatUid.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df2.PracticeUid","left_outer")
      .select($"df1.*", $"df2.PatientUid".as("aliasPatientUid"), $"df2.AddressUid".as("aliasAddressUid"), $"df2.BirthPlaceUid".as("aliasBirthPlaceUid")
        , $"df2.Phone1Uid".as("aliasPhone1Uid"), $"df2.Phone2Uid".as("aliasPhone2Uid"))
      .withColumn("PatientUid",updateWithJoin($"PatientUid",$"aliasPatientUid"))
      .withColumn("AddressUid",updateWithJoin($"AddressUid",$"aliasAddressUid"))
      .withColumn("BirthPlaceUid",updateWithJoin($"BirthPlaceUid",$"aliasBirthPlaceUid"))
      .withColumn("Phone1Uid",when($"TelecomValue1".isNotNull,updateWithJoin($"Phone1Uid",$"aliasPhone1Uid")).otherwise(null))
      .withColumn("Phone2Uid",when($"TelecomValue2".isNotNull,updateWithJoin($"Phone2Uid",$"aliasPhone2Uid")).otherwise(null))
      .drop("aliasPatientUid", "aliasAddressUid", "aliasBirthPlaceUid", "aliasPhone1Uid", "aliasPhone2Uid")

    println("Generate Uid's Uisng table tempPatUid")

    val tempPat1 = cleanedDemo9.filter($"PatientUid".isNotNull && rtrim(ltrim($"TelecomValue1")).isNotNull)
      .select($"PatientUid", $"PracticeUid")
      .withColumn("Phone1Uid", getNewUid())

    val cleanedDemo10 = cleanedDemo9.as("df1").join(tempPat1.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df2.PracticeUid","left_outer")
      .select($"df1.*", $"df2.Phone1Uid".alias("aliasPhone1Uid"))
      .withColumn("Phone1Uid",when($"TelecomValue1".isNotNull,updateWithJoin($"Phone1Uid",$"aliasPhone1Uid")).otherwise(null))
      .drop("aliasPhone1Uid")

    println("generate Uid using tempPat1")

    //Update Phone2Uid
    val tempPatUid2 = cleanedDemo10.filter($"PatientUid".isNotNull && $"Phone2Uid".isNotNull && rtrim(ltrim($"TelecomValue2")).isNotNull)
      .select("PatientUid", "PracticeUid")
      .withColumn("Phone2Uid",getNewUid())

    val cleanedDemo11 = cleanedDemo10.as("df1").join(tempPatUid2.as("df2")
      , $"df1.PatientUid" === $"df2.PatientUid" && $"df1.PracticeUid" === $"df2.PracticeUid","left_outer")
      .select($"df1.*", $"df2.Phone2Uid".alias("aliasPhone2Uid"))
      .withColumn("Phone2Uid",when($"TelecomValue2".isNotNull,updateWithJoin($"Phone2Uid",$"aliasPhone2Uid")).otherwise(null))
      .drop("aliasPhone2Uid")
    println("generate Uid using tempPat2")





  }
}
