class TestDataframe {
  /*
//Create map of file indices and column names
val cachePatientVitalSignObservationMapDF: Dataset[Row] = rt.joinedDf
  .filter($"CacheTableViewName"==="ViewCachePatientVitalSignObservation")
val lookup: collection.Map[String, String] = getLookupMap(cachePatientVitalSignObservationMapDF)
*/


}
