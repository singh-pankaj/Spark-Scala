package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.EthnicityTransformFunction
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientEthnicity(EthinicityPath: String, selectedIds: DataFrame)  extends  LookupMaps {


  def EthinicityProccessing(spark: SparkSession, MasterEthnicity: DataFrame) = {

    val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientEthnicity")
    val stagetableName = ApplicationConfig.prop.getProperty("StagePatientEthnicity")
    val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientEthnicity")
    val errPath = ApplicationConfig.prop.getProperty("PatientEthnicityErrPath")
    val validations = new ValidationCriteria(spark)

    import spark.implicits._
    try {


      var file = CommonFunc.readFile(EthinicityPath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientEthnicitylookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")

      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)

      val CachePatientEthnicityValidations = file1
        .transform(validations.removeDuplicateRecords("PatientId", "PatientEthnicityText"))

      val CleanedRecords = CachePatientEthnicityValidations.filter(row => validations.checkNull(row, broadcastRows, "PatientId", "PatientEthnicityCode", "PatientEthnicityText"))


      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")

      val tf1 = new EthnicityTransformFunction(spark, MasterEthnicity)
      val cacheAllergy3 = addPatientUid
        .transform(tf1.PatientEthnicityText)
        .transform(tf1.PatientEthnicityCode)

      HiveUtility.dfwritetohive(cacheAllergy3, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(rows, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")



      /*val distinctPUid = cacheAllergy3.select("PracticeUid").distinct()

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val ethinicityData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val fileJoinids = cacheAllergy3.select("PracticeUid","PatientId").distinct()
      //broadcast(fileJoinids)

     val OtherData =  ethinicityData.as("df1").join(fileJoinids.as("df2")
        ,  $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId","left_anti")
        .select($"df1.*")

      val newstructure = cacheAllergy3.select(OtherData.columns.head,OtherData.columns.tail:_*)

     val AllEthinicityData = newstructure.union(OtherData)
      HiveUtility.dfwritetohive(AllEthinicityData,mainTableName,sparkSess,stagetableName,s3Path)*/

    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }

  }

}
