package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.MedicationTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions.{col, to_timestamp}
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientMedications(MedicationPath: String, selectedIds: DataFrame)  extends  LookupMaps  {


  def CacheMedicationsProcessing(spark: SparkSession, MappingPracticeProcedure: DataFrame, MappingPracticeMedication: DataFrame,
                                 MappingPracticeCommonDataMaster: DataFrame) {
    import spark.implicits._


    try {
      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientMedications")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientMedications")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientMedications")
      val errPath = ApplicationConfig.prop.getProperty("PatientMedicationsErrPath")

      val validations = new ValidationCriteria(spark)


      val file: DataFrame = CommonFunc.readFile(MedicationPath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientMedicationslookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("MedStartDate", to_timestamp($"MedStartDate", "MM/dd/yyyy HH:mm:ss"))

      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)

      val cachePatientMedicationValidations = file1
        .transform(validations.removeDuplicateRecords("PatientId", "PracticePatientMedicationKey"))


      val CleanedRecords = cachePatientMedicationValidations.filter(row => validations.checkNull(row, broadcastRows, "PatientId", "MedicationCode", "MedicationName"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")


      //Get required functions for CacheMedications
      val medications = new MedicationTransformFunctions(spark, MappingPracticeProcedure, MappingPracticeMedication, MappingPracticeCommonDataMaster)

      val transformMedicationsDF = addPatientUid
        .transform(medications.ProcedureText)
        .transform(medications.ProcedureCode)
        .transform(medications.MedicationName)
        .transform(medications.MedicationCode)
        .transform(medications.MedicationProductFormText)
        .transform(medications.MedicationProductFormCode)
        .transform(medications.MedicationIndicationProblemText)
        .transform(medications.MedicationIndicationProblemCode)
        .transform(medications.MedicationReactionProblemText)
        .transform(medications.MedicationReactionProblemCode)
        .transform(medications.MedicationReactionProblemSeverityText)
        .transform(medications.MedicationReactionProblemSeverityCode)
        .transform(medications.MedicationStatusText)
        .transform(medications.MedicationStatusCode)
        .transform(medications.MedicationRouteText)
        .transform(medications.MedicationRouteCode)

      HiveUtility.dfwritetohive(transformMedicationsDF, mainTableName, spark, stagetableName, s3Path)
      val errList = validations.errorList += spark.createDataFrame(rows, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")

      /*val distinctPUid = transformMedicationsDF.select("PracticeUid").distinct()

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val MedicationData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = transformMedicationsDF.select("PracticeUid","PatientId","PatientUid").distinct()
      //broadcast(FiletoJoin)

      val otherData = MedicationData.as("df1").join(FiletoJoin.as("df2")
        ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid","left_anti")
        .select($"df1.*")

      val newstructure = transformMedicationsDF.select(otherData.columns.head,otherData.columns.tail:_*)

      val AllMedicationData = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllMedicationData,mainTableName,spark,stagetableName,s3Path)*/


    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
      }
    }
  }


}
