package com.figmd.janus.filetocdr.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig.prop
import org.apache.spark.sql.SparkSession

class SparkUtility {


  var num_executors = prop.getProperty("num_executors")
  var executor_cores = prop.getProperty("executor_cores")
  var executor_memory = prop.getProperty("executor_memory")
  var sparkMasterUrl = prop.getProperty("spark_master_url")
  var mode = prop.getProperty("mode")
  var awsAccessKeyId = prop.getProperty("awsAccessKeyId")
  var awsSecretAccessKey = prop.getProperty("awsSecretAccessKey")
  var hiveLocation = prop.getProperty("warehouse")


  def getSparkSession(): SparkSession = {


    val spark = SparkSession.builder.master(sparkMasterUrl).appName("FileToCDR")
      .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      //.config("spark.scheduler.mode","FAIR")
      .config("spark.speculation", "false")
      .config("spark.sql.warehouse.dir", hiveLocation)
      .config("executor-memory", executor_memory)
      .config("spark.submit.deployMode", mode)
      .config("executor-cores", executor_cores)
      .config("num-executors", num_executors)
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .config("fs.s3n.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem")
      .config("fs.s3n.awsAccessKeyId", awsAccessKeyId)
      .config("fs.s3n.awsSecretAccessKey", awsSecretAccessKey)
      .config("spark.yarn.maxAppAttempts", "1")
      .enableHiveSupport()
      .getOrCreate()

    spark
  }
}

/*//.config("spark.dynamicAllocation.enabled","true")
.config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
.config("spark.scheduler.mode","FAIR")
.config("spark.speculation","false")
.config("spark.sql.warehouse.dir",hiveLocation)
// .config("executor-memory",executor_memory)
.config("spark.submit.deployMode", mode)
.config("orc.compress","snappy")
//.config("executor-cores", executor_cores)
//.config("num-executors",num_executors)
.config("hive.exec.dynamic.partition", "true")
.config("hive.exec.dynamic.partition.mode", "nonstrict")
//.config("hive.exec.compresuce.output.fileoutputformat.compress","true")
//.config("mapreduce.output.fileoutputformat.compress.codec","org.apache.hadoop.io.compress.SnappyCodec")
//.config("hive.enforce.bucketing", "true")
.config("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
.config("fs.s3a.access.key", awsAccessKeyId)
.config("fs.s3a.secret.key",awsSecretAccessKey)
//.config("fs.s3n.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem")
//.config("fs.s3n.awsAccessKeyId", awsAccessKeyId)
//.config("fs.s3n.awsSecretAccessKey",awsSecretAccessKey)
.config("spark.yarn.maxAppAttempts", "1")
.enableHiveSupport()
.getOrCreate()*/


