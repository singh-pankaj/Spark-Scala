package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.ResultObsTransformFunction
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientresultObservation(ResultObservationPath: String, selectedIds: DataFrame)  extends  LookupMaps {

  def cacheresultObsProcessing(spark: SparkSession, mappingpracticecommondatamaster: DataFrame
                               , mappingpracticeprocedure: DataFrame): Unit = {

    import spark.implicits._
    try {


      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientResultObservation")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientResultObservation")
      val errPath = ApplicationConfig.prop.getProperty("PatientResultObservationErrPath")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientResultObservation")
      //Start CacheResultObservation
      val validations = new ValidationCriteria(spark)
      var file = CommonFunc.readFile(ResultObservationPath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientResultObservationlookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("ObservationDate", to_timestamp($"ObservationDate", "MM/dd/yyyy HH:mm:ss"))


      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)

      val cachePatientResultObservationValidations = file1
        .transform(validations.removeDuplicateRecords("PatientId", "ObservationName", "ObservationDate"))


      val CleanedRecords = cachePatientResultObservationValidations.filter(row => validations.checkNull(row, broadcastRows, "PatientId", "ObservationValue", "ObservationDate", "ObservationCode", "ObservationName"))


      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")

      //Some column is remaining
      val resultObsObj = new ResultObsTransformFunction(spark, mappingpracticecommondatamaster, mappingpracticeprocedure)

      val CacheResultObservation2 = addPatientUid
        .transform(resultObsObj.PracticeCode)
        .transform(resultObsObj.PracticeDescription)
        .transform(resultObsObj.TargetSiteCode)
        .transform(resultObsObj.TargetSiteText)
        .transform(resultObsObj.ObsInterpretationCode)
        .transform(resultObsObj.ObsInterpretationText)
        .transform(resultObsObj.ProcedureCode)
        .transform(resultObsObj.ProcedureText)
        .transform(resultObsObj.MethodCode)
        .transform(resultObsObj.MethodCodeText)

      HiveUtility.dfwritetohive(CacheResultObservation2, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(rows, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")

      /* val distinctPUid = CacheResultObservation2.select("PracticeUid").distinct()

       val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
       val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

       val ResultObsData = sparkSess.sql(s"select * from $mainTableName where" +
         s" practiceuid in $PartitionPUID")

       val FiletoJoin = CacheResultObservation2.select("PracticeUid","PatientId","PatientUid").distinct()
      // broadcast(FiletoJoin)

       val otherData = ResultObsData.as("df1").join(FiletoJoin.as("df2")
         ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
           $"df1.PatientUid" === $"df2.PatientUid","left_anti")
         .select($"df1.*")

       val newstructure = CacheResultObservation2.select(otherData.columns.head,otherData.columns.tail:_*)
       val AllResultObsData = newstructure.union(otherData)
       HiveUtility.dfwritetohive(AllResultObsData,mainTableName,sparkSess,stagetableName,s3Path)*/


    }
    catch {
      case ex: FileNotFoundException => {
        println("File Not found" + ex)
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }
  }
}
