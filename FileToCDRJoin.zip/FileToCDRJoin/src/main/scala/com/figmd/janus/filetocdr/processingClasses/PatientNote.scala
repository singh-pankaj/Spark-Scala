package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientNote(PatientNotesPath: String, selectedIds: DataFrame)  extends  LookupMaps {


  def PatientNoteProcessing(spark: SparkSession) {


    try {

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientNote")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientNote")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientNote")
      val errPath = ApplicationConfig.prop.getProperty("PatientNoteErrPath")

      val validations = new ValidationCriteria(spark)

      import spark.implicits._
      val file = CommonFunc.readFile(PatientNotesPath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientNoteslookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
      // .withColumn("referencedDate", to_timestamp($"referencedDate", "MM/dd/yyyy HH:mm:ss"))


      val addPatientUid = file1.as("df1").join(selectedIds.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")

      HiveUtility.dfwritetohive(addPatientUid, mainTableName, spark, stagetableName, s3Path)

      /*val distinctPUid = addPatientUid.select("PracticeUid").distinct()

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val NotesData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = addPatientUid.select("PracticeUid","PatientId","PatientUid")
     // broadcast(FiletoJoin)

      val otherData = NotesData.as("df1").join(FiletoJoin.as("df2")
        ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid","left_anti")
        .select($"df1.*")

      val newstructure = addPatientUid.select(otherData.columns.head,otherData.columns.tail:_*)
      val AllNotesData = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllNotesData,mainTableName,sparkSess,stagetableName,s3Path)*/

    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        unknown.printStackTrace()

      }
    }
  }
}
