package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}

class EthnicityTransformFunction(sparkSess: SparkSession, MasterEthnicity: DataFrame) {


  import sparkSess.implicits._

  def PatientEthnicityText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(MasterEthnicity.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientEthnicityText" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedValue1")
        , $"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterPatientEthnicityCode", $"MappedValue1")
      .withColumn("MasterPatientEthnicityText", $"MappedValue2")
      .drop("MappedValue1", "MappedValue2")
  }

  def PatientEthnicityCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(MasterEthnicity.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientEthnicityCode" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedValue1")
        , $"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterPatientEthnicityCode", when($"MappedValue1".isNull, $"MasterPatientEthnicityCode")
        .otherwise($"MappedValue1"))
      .withColumn("MasterPatientEthnicityText", when($"MappedValue2".isNull, $"MasterPatientEthnicityText")
        .otherwise($"MappedValue2"))
      .drop("MappedValue1", "MappedValue2")
  }

}
