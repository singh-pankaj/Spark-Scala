package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.ProcedureTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientProcedure(ProcedurePath: String, selectedIds: DataFrame)  extends  LookupMaps {


  def cachePatientProcedureProceesing(spark: SparkSession, mappingPracticeProcedure: DataFrame
                                      , mappingpracticecommondatamaster: DataFrame) {

    import spark.implicits._

    try {

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientProcedures")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientProcedures")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientProcedures")
      val errPath = ApplicationConfig.prop.getProperty("PatientProceduresErrPath")
      val validations = new ValidationCriteria(spark)

      val file = CommonFunc.readFile(ProcedurePath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientProcedurelookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("ProcedureDate", to_timestamp($"ProcedureDate", "MM/dd/yyyy HH:mm:ss"))

      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)
      val schema = file1.schema.add(StructField("ErrorMessage", StringType))

      val cachePatientProcedureValidations = file1
        .transform(validations.removeDuplicateRecords("PatientId", "ProcedureCode", "ProcedureDate"))
        .transform(validations.removeDuplicateRecords("PatientId", "ProcedureText", "ProcedureDate"))
        .transform(validations.removeDuplicateRecords("PatientId", "ProcedureCode", "ProcedureDate", "ServiceProviderNPI"))
        .transform(validations.removeDuplicateRecords("PatientId", "ProcedureText", "ProcedureDate", "ServiceProviderNPI"))


      val CleanedRecords = cachePatientProcedureValidations.filter(row => validations.checkNull(row, broadcastRows, "PatientId", "ProcedureDate", "ProcedureCode", "ProcedureText"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")

      val ProcedureObj = new ProcedureTransformFunctions(spark, mappingPracticeProcedure, mappingpracticecommondatamaster)

      val cachePatientProcedure3 = addPatientUid
        .transform(ProcedureObj.PracticeCode)
        .transform(ProcedureObj.PracticeDescription)
        .transform(ProcedureObj.ProcedureStatusCode)
        .transform(ProcedureObj.ProcedureStatusText)
        .transform(ProcedureObj.TargetSiteCode)
        .transform(ProcedureObj.TargetSiteText)

      HiveUtility.dfwritetohive(cachePatientProcedure3, mainTableName, spark, stagetableName, s3Path)
      val errList = validations.errorList += spark.createDataFrame(rows, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")


      /*val distinctPUid = cachePatientProcedure3.select("PracticeUid").distinct()

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val ProcedureData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

     val FiletoJoin = cachePatientProcedure3.select("PracticeUid","PatientId","PatientUid").distinct()
     //broadcast(FiletoJoin)

      val otherData = ProcedureData.as("df1").join(FiletoJoin.as("df2")
        ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid","left_anti")
        .select($"df1.*")

     val newstructure = cachePatientProcedure3.select(otherData.columns.head,otherData.columns.tail:_*)

      val allProcedureData = newstructure.union(otherData)
     HiveUtility.dfwritetohive(allProcedureData,mainTableName,sparkSess,stagetableName,s3Path)*/


    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }
  }

}
