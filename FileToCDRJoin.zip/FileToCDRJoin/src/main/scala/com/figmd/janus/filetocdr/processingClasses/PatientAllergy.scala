package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.AllergyTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions.{col, to_timestamp}
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientAllergy(AllergiesPath: String, selectedIds: DataFrame)  extends  LookupMaps  {


  def cacheAllergyProcessing(spark: SparkSession, masterAllergy: DataFrame, mappingpracticecommondatamaster: DataFrame
                            ) {

    try {
      import spark.implicits._

      val validations = new ValidationCriteria(spark)

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientAllergies")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientAllergies")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientAllergies")
      val errPath = ApplicationConfig.prop.getProperty("PatientAllergiesErrPath")

      val file = CommonFunc.readFile(AllergiesPath, spark)

      val file1 = file.select(file.columns.map(c => col(c).as(PatientAllergieslookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("EffectiveStartDate", to_timestamp($"EffectiveStartDate", "MM/dd/yyyy HH:mm:ss"))
        .withColumn("EffectiveEndDate", to_timestamp($"EffectiveEndDate", "MM/dd/yyyy HH:mm:ss"))


      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)

      val cachePatientAllergyValidations = file1
        .transform(validations.removeDuplicateRecords("PatientId"))
        .transform(validations.removeDuplicateRecords("PatientId", "EffectiveStartDate"))
        .transform(validations.removeDuplicateRecords("PatientId", "EffectiveEndDate"))
        .transform(validations.removeDuplicateRecords("PatientId", "AllergicToDescription"))
        .transform(validations.removeDuplicateRecords("PatientId", "AllergicToDescription", "EffectiveStartDate"))
        .transform(validations.removeDuplicateRecords("PatientId", "AllergicToDescription", "EffectiveEndDate"))


      val CleanedRecords = cachePatientAllergyValidations.filter(row => validations.checkNull(row, broadcastRows, "PatientId", "AllergyStatusCode", "AllergyStatusText"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")

      val tf = new AllergyTransformFunctions(spark, masterAllergy, mappingpracticecommondatamaster)

      val cacheAllergy3 = addPatientUid
        .transform(tf.AllergicToCode)
        .transform(tf.AllergicToDescription)
        .transform(tf.AllergyStatusCode)
        .transform(tf.AllergyStatusText)

      HiveUtility.dfwritetohive(cacheAllergy3, mainTableName, spark, stagetableName, s3Path)
      val errList = validations.errorList += spark.createDataFrame(rows, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")

      /*val distinctPUid = cacheAllergy3.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val AllergyData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cacheAllergy3.select("PracticeUid","PatientId","PatientUid").distinct()
      //broadcast(FiletoJoin)

      val otherData = AllergyData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

      val newstructure = cacheAllergy3.select(otherData.columns.head,otherData.columns.tail:_*)
      val AllAllergy = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllAllergy,mainTableName,sparkSess,stagetableName,s3Path)*/

    }


    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }

}
