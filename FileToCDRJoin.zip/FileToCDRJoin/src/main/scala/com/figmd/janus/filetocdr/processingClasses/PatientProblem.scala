package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.ProblemTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientProblem(ProblemPath: String, selectedIds: DataFrame)  extends  LookupMaps  {

  def cachePatientProblemProcessing(spark: SparkSession, mappingpracticeproblem: DataFrame) = {

    val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientProblem")
    val stagetableName = ApplicationConfig.prop.getProperty("StagePatientProblem")
    val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientProblem")
    val errPath = ApplicationConfig.prop.getProperty("PatientProblemErrPath")
    val validations = new ValidationCriteria(spark)

    import spark.implicits._

    try {
      val file = CommonFunc.readFile(ProblemPath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientProblemlookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("DocumentationDate", to_timestamp($"DocumentationDate", "MM/dd/yyyy HH:mm:ss"))

      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)
      val schema = file1.schema.add(StructField("ErrorMessage", StringType))

      val cachePatientProblemValidations = file1
        .transform(validations.removeDuplicateRecords("ProblemCode", "DocumentationDate"))
        .transform(validations.removeDuplicateRecords("problemtext", "DocumentationDate"))

      val CleanedRecords = cachePatientProblemValidations.filter(row => validations.checkNull(row, broadcastRows, "PatientId", "DocumentationDate", "ProblemCode", "ProblemText"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")

      val problemObj = new ProblemTransformFunctions(spark, mappingpracticeproblem)

      val cachePatientProblem3 = addPatientUid
        .transform(problemObj.ProblemCode)
        .transform(problemObj.ProblemText)
        .transform(problemObj.ProblemStatusCode)
        .transform(problemObj.ProblemStatusText)
        .transform(problemObj.ProblemHealthStatusCode)
        .transform(problemObj.ProblemHealthStatusText)
        .transform(problemObj.TargetSiteCode)
        .transform(problemObj.TargetSiteText)

      HiveUtility.dfwritetohive(cachePatientProblem3, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(rows, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")

      /*val distinctPUid = cachePatientProblem3.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val ProblemData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cachePatientProblem3.select("PracticeUid","PatientId","PatientUid").distinct()
     //broadcast(FiletoJoin)

      val otherData = ProblemData.as("df1").join(FiletoJoin.as("df2")
        ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
        $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

      val newstructure = cachePatientProblem3.select(otherData.columns.head,otherData.columns.tail:_*)

      val AllProblemData = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllProblemData,mainTableName,sparkSess,stagetableName,s3Path)*/
    }

    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
      }
    }
  }

}
