package com.figmd.janus.filetocdr.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import org.apache.spark.sql.{DataFrame, SparkSession}

class Postgressutility {


  def getPostgresTable(spark: SparkSession, tableName: String): DataFrame = {
    spark.read
      .format("jdbc")
      .option("url", "jdbc:postgresql://" + ApplicationConfig.prop.getProperty("postgresHostName") + ":" + ApplicationConfig.prop.getProperty("postgresHostPort") + "/" + ApplicationConfig.prop.getProperty("postgresManagementDatabaseName"))
      .option("dbtable", tableName)
      .option("user", ApplicationConfig.prop.getProperty("postgresHostUserName"))
      .option("password", ApplicationConfig.prop.getProperty("postgresUserPass"))
      .load()
  }
}
