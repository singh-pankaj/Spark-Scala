package com.figmd.janus.filetocdr.validationFunctions

import java.util

import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}


class ValidationCriteria(spark: SparkSession) extends Serializable {

  import spark.implicits._

  var errorList: ListBuffer[DataFrame] = ListBuffer[DataFrame]()

  def errorRecords(df: List[DataFrame]): DataFrame = {

    val errorDF = df.reduce(_ union _)
    errorDF

  }

  def checkNull(row: Row, rows1: Broadcast[util.ArrayList[Row]], columns: String*): Boolean = {
    var flag = false
    var ErrorMessage: String = null

    breakable {
      for (col <- columns) {
        print(col)
        if (row.isNullAt(row.fieldIndex(col)) || row.get(row.fieldIndex(col)).toString.replaceAll("\\s", "") == "") {
          ErrorMessage = s"$col not found"
          rows1.value.add(Row.merge(row, Row(ErrorMessage)))
          flag = false
          break()
        }
        else
          flag = true
      }
    }

    flag
  }

  def removeDuplicateRecords(list: String*)(df: DataFrame): DataFrame = {
    val RankDf = df
      .withColumn("rank", row_number().over(Window.partitionBy(list.head, list.tail: _*).orderBy(list.head, list.tail: _*)))

    val goodDF = RankDf.filter(col("rank") === 1).drop("rank")

    val errorDF = RankDf.filter(col("rank") > 1).drop("rank")
      .withColumn("ErrorMessage", lit("Duplicate record"))

    errorList += errorDF

    goodDF
  }

  def invalidNPIFound(df: DataFrame): DataFrame = {
    val errorDF = df.filter(length(col("ServiceProviderNPI")) =!= 10)
      .withColumn("ErrorMessage", lit("Invalid NPI Found,Length should be 10"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def invalidObservationCodeFound(df: DataFrame): DataFrame = {
    val errorDF = df.filter(col("ObservationName") === "")
      .withColumn("ErrorMessage", lit("Invalid ObservationCode Found without ObservationName"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def invalidPayerIdFound(df: DataFrame): DataFrame = {
    val errorDF = df.filter(length(col("payerid")) =!= 50)
      .withColumn("ErrorMessage", lit("Invalid PayerId"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def invalidPolicyIdFound(df: DataFrame): DataFrame = {
    val errorDF = df.filter(length(col("policyid")) =!= 50)
      .withColumn("ErrorMessage", lit(" Invalid policyid"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


  def differentMRNForSamePatientWithSSN(df: DataFrame): DataFrame = {

    val errorDF = df.as("df1").join(df.as("df2"), $"df1.FirstName" === $"df2.FirstName"
      && $"df1.PracticeUid" === $"df2.PracticeUid"
      && $"df1.DOB" === $"df2.DOB"
      && $"df1.LastName" === $"df2.LastName"
      && $"df1.SSN" === $"df2.SSN").where($"df1.PatientId" =!= $"df2.PatientId")
      .select($"df1.*")
      .withColumn("ErrorMessage", lit("Different MRN Found For Same firstname,lastname,dob,SSN,PracticeUid"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def differentMRNForSamePatientWithoutSSN(df: DataFrame): DataFrame = {

    val errorDF = df.as("df1").join(df.as("df2"), $"df1.FirstName" === $"df2.FirstName"
      && $"df1.PracticeUid" === $"df2.PracticeUid"
      && $"df1.DOB" === $"df2.DOB"
      && $"df1.LastName" === $"df2.LastName").where($"df1.PatientId" =!= $"df2.PatientId")
      .select($"df1.*")
      .withColumn("ErrorMessage", lit("Different MRN Found For Same firstname,lastname,dob,PracticeUid"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

}
