package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}

class ResultObsTransformFunction(sparkSess: SparkSession
                                 , mappingpracticecommondatamaster: DataFrame
                                 , mappingpracticeprocedure: DataFrame) {


  import sparkSess.implicits._

  def PracticeCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterObservationCode")
        , $"df2.CodeDescription".as("MasterObservationName"))
  }

  def PracticeDescription(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("Mappedvalue1")
        , $"df2.CodeDescription".as("Mappedvalue2"))
      .withColumn("MasterObservationCode", when($"Mappedvalue1".isNull, $"MasterObservationCode")
        .otherwise($"Mappedvalue1"))
      .withColumn("MasterObservationName", when($"Mappedvalue2".isNull, $"MasterObservationName")
        .otherwise($"Mappedvalue2"))
      .drop("Mappedvalue1", "Mappedvalue2")
  }

  def TargetSiteCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterTargetSiteCode")
        , $"df2.CodeDescription".as("MasterTargetSiteText"))
  }

  def TargetSiteText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("Mappedvalue1")
        , $"df2.CodeDescription".as("Mappedvalue2"))
      .withColumn("MasterTargetSiteCode", when($"Mappedvalue1".isNull, $"MasterTargetSiteCode")
        .otherwise($"Mappedvalue1"))
      .withColumn("MasterTargetSiteText", when($"Mappedvalue2".isNull, $"MasterTargetSiteText")
        .otherwise($"Mappedvalue2"))
      .drop("Mappedvalue1", "Mappedvalue2")
  }

  def ObsInterpretationCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterObsInterpretationCode")
        , $"df2.CodeDescription".as("MasterObsInterpretationText"))
  }

  def ObsInterpretationText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("Mappedvalue1")
        , $"df2.CodeDescription".as("Mappedvalue2"))
      .withColumn("MasterObsInterpretationCode", when($"Mappedvalue1".isNull, $"MasterObsInterpretationCode")
        .otherwise($"Mappedvalue1"))
      .withColumn("MasterObsInterpretationText", when($"Mappedvalue2".isNull, $"MasterObsInterpretationText")
        .otherwise($"Mappedvalue2"))
      .drop("Mappedvalue1", "Mappedvalue2")
  }

  def ProcedureCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticeprocedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterProcedureCode")
        , $"df2.CodeDescription".as("MasterProcedureText"))
  }

  def ProcedureText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticeprocedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("Mappedvalue1")
        , $"df2.CodeDescription".as("Mappedvalue2"))
      .withColumn("MasterProcedureCode", when($"Mappedvalue1".isNull, $"MasterProcedureCode")
        .otherwise($"Mappedvalue1"))
      .withColumn("MasterProcedureText", when($"Mappedvalue2".isNull, $"MasterProcedureText")
        .otherwise($"Mappedvalue2"))
      .drop("Mappedvalue1", "Mappedvalue2")
  }

  def MethodCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MethodCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterMethodCode")
        , $"df2.CodeDescription".as("MasterMethodCodeText"))
  }

  def MethodCodeText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MethodCodeText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("Mappedvalue1")
        , $"df2.CodeDescription".as("Mappedvalue2"))
      .withColumn("MasterMethodCode", when($"Mappedvalue1".isNull, $"MasterMethodCode")
        .otherwise($"Mappedvalue1"))
      .withColumn("MasterMethodCodeText", when($"Mappedvalue2".isNull, $"MasterMethodCodeText")
        .otherwise($"Mappedvalue2"))
      .drop("Mappedvalue1", "Mappedvalue2")
  }


}
