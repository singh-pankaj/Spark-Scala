package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions.{col, to_timestamp}
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientDemographics(DemoPath: String)  extends  LookupMaps {


  def demoProcessing(spark: SparkSession): Option[DataFrame] = {

    import spark.implicits._


    try {
      val file = CommonFunc.readFile(DemoPath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientDemographicslookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatient")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatient")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatient")
      val errPath = ApplicationConfig.prop.getProperty("PatientErrPath")

      val validations = new ValidationCriteria(spark)

      println("file path..." + DemoPath)

      val CachepatientDemo1 = file1.withColumn("DOB", to_timestamp($"DOB", "MM/dd/yyyy HH:mm:ss"))

      val schema = CachepatientDemo1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)

      val cachePatientDemoValidations = CachepatientDemo1
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid"))

      val CleanedRecords = cachePatientDemoValidations.filter(row => validations.checkNull(row, broadcastRows, "PatientId", "PracticeUid", "FirstName", "LastName", "DOB", "Gender"))


      //      val CleanedRecords = CachepatientDemo1.dropDuplicates("PatientId","PracticeUid")

      val tempPatUid = CleanedRecords.select("PatientId", "PracticeUid").distinct()
        .withColumn("PatientUid", CommonFunc.getNewUid())

      val PatUid = tempPatUid.persist()
      //broadcast(PatUid)

      val CachepatientDemo2 = CleanedRecords.as("df1").join(PatUid.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid").drop("dummy1", "dummy2")

      HiveUtility.dfwritetohive(CachepatientDemo2, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(rows, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")

      val send3uids = CachepatientDemo2.select($"PracticeUid", $"PatientId", $"PatientUid")

      Some(send3uids)

      //val distinctPUid = CleanedRecords.select("PracticeUid").distinct()
      /*val fileJoinids = CleanedRecords.select("PracticeUid","PatientId")
     // broadcast(fileJoinids)

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"


      val RequiredData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      //println("RequiredData Demo Data.....  "+RequiredData.count())

      val UUIDs = RequiredData.select("PracticeUid","PatientId","PatientUid").distinct()
     // broadcast(UUIDs)

      val PreviousPatient = CleanedRecords.as("df1").join(UUIDs.as("df2"),
        Seq("PracticeUid","PatientId"),"inner").select($"df1.*",$"df2.PatientUid")
        .drop("dummy1","dummy2")

     // println("PreviousPatient Demo Data.....  "+PreviousPatient.count())

      val newPatient =  CleanedRecords.as("df1").join(UUIDs.as("df2"),
        Seq("PracticeUid","PatientId"),"left_anti").select($"df1.*")

     // println("newPatient Demo Data.....  "+newPatient.count())

      val tempPatUid = newPatient.select("PatientId", "PracticeUid").distinct()
        .withColumn("PatientUid",CommonFunc.getNewUid())

      val PatUid = tempPatUid.persist()
      //broadcast(PatUid)

      val CachepatientDemo2 = newPatient.as("df1").join(PatUid.as("df2")
        ,  $"df1.PracticeUid" === $"df2.PracticeUid"  && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid").drop("dummy1","dummy2")

      val OtherPatient =  RequiredData.as("df1").join(fileJoinids.as("df2"),
        Seq("PracticeUid","PatientId"),"left_anti").select($"df1.*")

     /* PreviousPatient.printSchema()
      CachepatientDemo2.printSchema()
      OtherPatient.printSchema()*/

      val allRecords = PreviousPatient.union(CachepatientDemo2).union(OtherPatient)

      //println("Processing End time for Demo.. "+Calendar.getInstance.getTime)
      HiveUtility.dfwritetohive(allRecords,mainTableName,sparkSess,stagetableName,s3Path)
      val send3uids  = allRecords.select("PracticeUid","PatientId","PatientUid")
      Some(send3uids)*/

    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }

  }


}
