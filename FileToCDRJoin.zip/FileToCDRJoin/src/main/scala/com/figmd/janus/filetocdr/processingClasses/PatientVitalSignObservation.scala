package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.VitalSignObsTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientVitalSignObservation(VitalSignPath: String, selectedIds: DataFrame)  extends  LookupMaps {

  def VitalSignObservationProcessing(spark: SparkSession, mappingpracticecommondatamaster: DataFrame
                                    ) = {
    import spark.implicits._

    try {
      println("Vital Sign start...........")
      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientVitalSigns")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientVitalSigns")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientVitalSigns")
      val errPath = ApplicationConfig.prop.getProperty("PatientVitalSignsErrPath")
      val validations = new ValidationCriteria(spark)

      //Read file for CachePatientVitalSignObservation
      val file: DataFrame = CommonFunc.readFile(VitalSignPath, spark)

      val file1 = file.select(file.columns.map(c => col(c).as(PatientVitalSignslookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("ObservationDate", to_timestamp($"ObservationDate", "MM/dd/yyyy HH:mm:ss"))


      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)

      val cachePatientVitalSignsObservationValidations = file1
        .transform(validations.removeDuplicateRecords("PatientId", "ObservationName", "ObservationDate"))

      val CleanedRecords = cachePatientVitalSignsObservationValidations.filter(row => validations.checkNull(row, broadcastRows, "PatientId", "ObservationValue", "ObservationDate", "ObservationName"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")

      val patientVitalSignObservationDF = new VitalSignObsTransformFunctions(spark, mappingpracticecommondatamaster)

      println("Vital Sign goes to lookup...........")
      val transformPatientVitalSignObservationDF = addPatientUid
        .transform(patientVitalSignObservationDF.PracticeDescription)
        .transform(patientVitalSignObservationDF.PracticeCode)
        .transform(patientVitalSignObservationDF.TargetSiteText)
        .transform(patientVitalSignObservationDF.TargetSiteCode)
        .transform(patientVitalSignObservationDF.ObsInterpretationText)
        .transform(patientVitalSignObservationDF.ObsInterpretationCode)

      HiveUtility.dfwritetohive(transformPatientVitalSignObservationDF, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(rows, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")

      /* println("Vital Sign goes to lookup end...........")
       val distinctPUid = transformPatientVitalSignObservationDF.select("PracticeUid").distinct()

       val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
       val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

       val vitalsignData = spark.sql(s"select * from $mainTableName where" +
         s" practiceuid in $PartitionPUID")

       val FiletoJoin = transformPatientVitalSignObservationDF.select("PracticeUid","PatientId","PatientUid")
           .distinct()
       //broadcast(FiletoJoin)

       val otherData = vitalsignData.as("df1").join(FiletoJoin.as("df2")
         ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
           $"df1.PatientUid" === $"df2.PatientUid","left_anti")
         .select($"df1.*")

       val newstructure = transformPatientVitalSignObservationDF.select(otherData.columns.head,otherData.columns.tail:_*)
       val AllVitalSignData = newstructure.union(otherData)
       HiveUtility.dfwritetohive(AllVitalSignData,mainTableName,spark,stagetableName,s3Path)

 */
    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }

}
