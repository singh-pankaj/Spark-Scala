package com.figmd.janus.filetocdr.util

trait LookupMaps {

  val PatientDemographicslookup = Map("_c0" -> "PatientId", "_c1" -> "LastName", "_c2" -> "FirstName", "_c3" -> "MiddleName", "_c4" -> "StreetLineAddress1"
    , "_c5" -> "StreetLineAddress2", "_c6" -> "StreetLineAddress3", "_c7" -> "StreetLineAddress4", "_c8" -> "City", "_c9" -> "StateCode"
    , "_c10" -> "State", "_c11" -> "ZipCode", "_c12" -> "CountryCode", "_c13" -> "Country", "_c14" -> "TelecomTypeText1"
    , "_c15" -> "TelecomValue1", "_c16" -> "TelecomTypeText2", "_c17" -> "TelecomValue2", "_c18" -> "Gender", "_c19" -> "DOB"
    , "_c20" -> "DeathDate", "_c21" -> "MaritalStatusCode", "_c22" -> "MaritalStatusText", "_c23" -> "ReligiousAffiliationCode"
    , "_c24" -> "ReligiousAffiliationText", "_c25" -> "BirthStateCode", "_c26" -> "BirthState", "_c27" -> "BirthZipCode"
    , "_c28" -> "BirthCountryCode", "_c29" -> "BirthCountry", "_c30" -> "ServiceProviderNPI", "_c31" -> "ServiceProviderLastName"
    , "_c32" -> "ServiceProviderFirstName", "_c33" -> "SSN", "_c34" -> "DeathReason", "_c35" -> "IsDeceased", "_c36" -> "Patient_EMR_ID"
    , "_c37" -> "EmailID", "_c38" -> "LocationOfDeath", "_c39" -> "BirthOrder", "_c40" -> "MultipleBirthPlaceIndicator"
    , "_c41" -> "PatientDemographicsKey", "_c42" -> "PracticeUid","_c43" -> "BatchUid","_c44" -> "dummy1","_c45" -> "dummy2")

  val PatientMedicationslookup = Map("_c0" -> "PatientId", "_c1" -> "MedicationCode", "_c2" -> "MedicationName"
    , "_c3" -> "MedicationCategory", "_c4" -> "MedStartDate", "_c5" -> "MedStopDate"
    , "_c6" -> "AdministeredEffectiveDate", "_c7" -> "RepeatNumber", "_c8" -> "MedicationRouteCode"
    , "_c9" -> "MedicationRouteText", "_c10" -> "DoseQuantity", "_c11" -> "DoseQuantityUnitCode"
    , "_c12" -> "DoseQuantityUnitText", "_c13" -> "MedicationProductFormCode", "_c14" -> "MedicationProductFormText"
    , "_c15" -> "ProcedureCode", "_c16" -> "ProcedureText", "_c17" -> "ProcedureCategory"
    , "_c18" -> "PrescribeElectronically", "_c19" -> "NegationInd", "_c20" -> "MedicationBrandName"
    , "_c21" -> "MedicationGenericName", "_c22" -> "MaxDoseQuantity", "_c23" -> "ServiceProviderNPI"
    , "_c24" -> "ServiceProviderLastName", "_c25" -> "ServiceProviderFirstName", "_c26" -> "DispensingTimeOfSupply"
    , "_c27" -> "DispensingDoseQuantity", "_c28" -> "SupplyPrescriberLastName", "_c29" -> "SupplyPrescriberFirstName"
    , "_c30" -> "SupplyPerformerLastName", "_c31" -> "SupplyPerformerFirstName", "_c32" -> "ServiceLocationId"
    , "_c33" -> "ServiceLocationName", "_c34" -> "MedicationIndicationCriteria"
    , "_c35" -> "MedicationIndicationProblemCode", "_c36" -> "MedicationIndicationProblemText"
    , "_c37" -> "MedicationIndicationProblemCategory", "_c38" -> "MedicationSeriesNumber"
    , "_c39" -> "MedicationReactionProblemCode", "_c40" -> "MedicationReactionProblemText"
    , "_c41" -> "MedicationReactionProblemCategory", "_c42" -> "MedicationReactionProblemSeverityCode"
    , "_c43" -> "MedicationReactionProblemSeverityText", "_c44" -> "MedicationStatusCode"
    , "_c45" -> "MedicationStatusText", "_c46" -> "MedicineManufacturer", "_c47" -> "MedicineId"
    , "_c48" -> "ProductInstanceScopingEntityId", "_c49" -> "PracticePatientMedicationKey"
    , "_c50" -> "DocumentationDate", "_c51" -> "PracticeUid", "_c52" -> "BatchUid", "_c53" -> "dummy1"
    , "_c54" -> "dummy2")

  val PatientAdvanceDirectiveslookup = Map("_c0" -> "PatientId", "_c1" -> "AdvanceDirectiveTypeCode", "_c2" -> "AdvanceDirectiveTypeDetails"
    , "_c3" -> "AdvanceDirectiveStatusCode", "_c4" -> "AdvanceDirectiveStatusText", "_c5" -> "EffectiveStartDate"
    , "_c6" -> "EffectiveEndDate", "_c7" -> "AgentName", "_c8" -> "ExternalDocumentLink", "_c9" -> "GroupName"
    , "_c10" -> "AdvanceDirectiveTypeText"
    , "_c11" -> "AdvanceDirectiveKey", "_c12" -> "PracticeUid", "_c13" -> "BatchUid"
    , "_c14" -> "dummy1", "_c15" -> "dummy2")

  val PatientAllergieslookup = Map("_c0" -> "PatientId", "_c1" -> "EffectiveStartDate", "_c2" -> "EffectiveEndDate"
    , "_c3" -> "AllergyTypeCode", "_c4" -> "AllergyEventType", "_c5" -> "AllergicToCode"
    , "_c6" -> "AllergicToDescription", "_c7" -> "AllergyStatusCode"
    , "_c8" -> "AllergyStatusText", "_c9" -> "AllergyReaction", "_c10" -> "AllergiesKey"
    ,"_c11" -> "PracticeUid","_c12" -> "BatchUid","_c13" -> "dummy1","_c14" -> "dummy2")


  val PatientEncounterlookup = Map("_c0" -> "PatientId", "_c1" -> "EncounterTypeCode", "_c2" -> "EncounterTypeText", "_c3" -> "EncounterStartDate"
    , "_c4" -> "EncounterEndDate", "_c5" -> "ServiceProviderNPI", "_c6" -> "ServiceProviderLastName", "_c7" -> "ServiceProviderFirstName"
    , "_c8" -> "ServiceProviderRoleCode", "_c9" -> "ServiceProviderRoleText", "_c10" -> "ServiceLocationId"
    , "_c11" -> "ServiceLocationName", "_c12" -> "ServiceLocationRoleTypeCode", "_c13" -> "ServiceLocationRoleTypeText"
    , "_c14" -> "ReasonForVisit", "_c15" -> "Service_Location_AddressLine", "_c16" -> "Service_Location_City"
    , "_c17" -> "Service_Location_State", "_c18" -> "Service_Location_PostalCode", "_c19" -> "Encounter_Status"
    , "_c20" -> "EncounterTIN", "_c21" -> "EncounterKey", "_c22" -> "PracticeUid", "_c23" -> "BatchUid", "_c24" -> "dummy1", "_c25" -> "dummy2")

  val PatientEthnicitylookup = Map("_c0" -> "PatientId", "_c1" -> "PatientEthnicityCode", "_c2" -> "PatientEthnicityText"
    , "_c3" -> "PatientEthnicityKey", "_c4" -> "PracticeUid"
    , "_c5" -> "BatchUid", "_c6" -> "dummy1", "_c7" -> "dummy2")

  val PatientFamilyHistorylookup = Map("_c0" -> "PatientId", "_c1" -> "FamilyMemberLastName", "_c2" -> "FamilyMemberFirstName",
    "_c3" -> "RelationshipToPatientCode", "_c4" -> "RelationshipToPatientText", "_c5" -> "FamilyMemberGender",
    "_c6" -> "FamilyMemberDOB", "_c7" -> "EffectiveDate", "_c8" -> "ProblemCode", "_c9" -> "ProblemText",
    "_c10" -> "ProblemCategory", "_c11" -> "ProblemTypeCode", "_c12" -> "ProblemTypeText", "_c13" -> "FamilyMemberAge",
    "_c14" -> "IsFamilyMemberAlive", "_c15" -> "FamilyHistoryKey", "_c16" -> "PracticeUid", "_c17" -> "BatchUid"
    , "_c18" -> "dummy1", "_c19" -> "dummy2")

  val PatientLanguagelookup = Map("_c0" -> "PatientId", "_c1" -> "LanguageCode", "_c2" -> "LanguageText"
    , "_c3" -> "LangaugeAbilityModeCode", "_c4" -> "LangaugeAbilityModeText", "_c5" -> "LanguageProficiencyLevelCode"
    , "_c6" -> "LanguageProficiencyLevelText", "_c7" -> "PreferenceInd", "_c8" -> "PatientLanguageKey"
    , "_c9" -> "PracticeUid", "_c10" -> "BatchUid", "_c11" -> "dummy1"
    , "_c12" -> "dummy2")

  val PatientNoteslookup = Map("_c0" -> "PatientId", "_c1" -> "referencedDate", "_c2" -> "SectionName", "_c3" -> "Note",
    "_c4" -> "ServiceProviderNPI", "_c5" -> "ServiceProviderLastName", "_c6" -> "ServiceProviderFirstName",
    "_c7" -> "ServiceLocationId", "_c8" -> "ServiceLocationName", "_c9" -> "Group1", "_c10" -> "Group2", "_c11" -> "Group3",
    "_c12" -> "Group4", "_c13" -> "PracticePatientNoteKey", "_c14" -> "PracticeUid", "_c15" -> "BatchUid"
    , "_c16" -> "dummy1", "_c17" -> "dummy2")

  val PatientPlanOfCarelookup = Map("_c0" -> "PatientID", "_c1" -> "Instructions", "_c2" -> "PracticeCode"
    , "_c3" -> "PracticeDescription",
    "_c4" -> "Effective_Date", "_c5" -> "PlanOfCareStatusCode", "_c6" -> "PlanOfCareStatusText",
    "_c7" -> "PlanOfCareGroup", "_c8" -> "PlanOfCareKey", "_c9" -> "PracticeUid", "_c10" -> "BatchUid"
    , "_c11" -> "dummy1", "_c12" -> "dummy2")

  val PatientProblemlookup = Map("_c0" -> "PatientId", "_c1" -> "ProblemCode", "_c2" -> "ProblemText", "_c3" -> "ProblemCategory"
    , "_c4" -> "ProblemTypeCode", "_c5" -> "ProblemTypeText", "_c6" -> "DocumentationDate",
    "_c7" -> "ProblemResolutionDate", "_c8" -> "ProblemStatusCode", "_c9" -> "ProblemStatusText"
    , "_c10" -> "ProblemHealthStatusCode", "_c11" -> "ProblemHealthStatusText", "_c12" -> "NegationInd",
    "_c13" -> "ProblemComment", "_c14" -> "ProblemOnsetDate", "_c15" -> "TargetSiteCode", "_c16" -> "TargetSiteText"
    , "_c17" -> "ProblemKey", "_c18" -> "PracticeUid", "_c19" -> "BatchUid",
    "_c20" -> "dummy1", "_c21" -> "dummy2")

  val PatientProcedurelookup = Map("_c0" -> "PatientId", "_c1" -> "ProcedureCode", "_c2" -> "ProcedureText", "_c3" -> "ProcedureCategory",
    "_c4" -> "ProcedureDate", "_c5" -> "TargetSiteCode", "_c6" -> "TargetSiteText", "_c7" -> "ServiceProviderNPI", "_c8" -> "ServiceProviderLastName",
    "_c9" -> "ServiceProviderFirstName", "_c10" -> "ServiceLocationId", "_c11" -> "ServiceLocationName", "_c12" -> "ProcedureStatusCode", "_c13" -> "ProcedureStatusText",
    "_c14" -> "NegationInd", "_c15" -> "ProcedureComment", "_c16" -> "Modifier1", "_c17" -> "Modifier2", "_c18" -> "Modifier3", "_c19" -> "Modifier4",
    "_c20" -> "Insurance", "_c21" -> "ProceduresKey", "_c22" -> "PracticeUid", "_c23" -> "BatchUid", "_c24" -> "dummy1", "_c25" -> "dummy2")

  val PatientRacelookup = Map("_c0" -> "PatientId", "_c1" -> "PatientRaceCode", "_c2" -> "PatientRaceText"
    , "_c3" -> "PatientRaceKey", "_c4" -> "PracticeUid"
    , "_c5" -> "BatchUid", "_c6" -> "dummy1", "_c7" -> "dummy2")


  val PatientResultObservationlookup = Map("_c0" -> "PatientId", "_c1" -> "ObservationCode", "_c2" -> "ObservationName"
    , "_c3" -> "ObservationCategory", "_c4" -> "ObservationDate", "_c5" -> "ObservationValue"
    , "_c6" -> "ObsInterpretationCode", "_c7" -> "ObsInterpretationText", "_c8" -> "TargetSiteCode"
    , "_c9" -> "TargetSiteText", "_c10" -> "ServiceProviderNPI", "_c11" -> "ServiceProviderLastName"
    , "_c12" -> "ServiceProviderFirstName", "_c13" -> "NegationInd", "_c14" -> "ReferenceLowerRange"
    , "_c15" -> "ReferenceUpperRange", "_c16" -> "MethodCode", "_c17" -> "MethodCodeText"
    , "_c18" -> "SpecimenId", "_c19" -> "ProcedureCode", "_c20" -> "ProcedureText"
    , "_c21" -> "ProcedureCategory", "_c22" -> "ResultObservationStatus", "_c23" -> "ResultOrderDescription"
    , "_c24" -> "ResultOrderDate", "_c25" -> "ResultOBSUnit", "_c26" -> "LaboratoryID"
    , "_c27" -> "LaboratoryName", "_c28" -> "ResultOrderCode", "_c29" -> "Obssubid"
    , "_c30" -> "ResultObservationKey", "_c31" -> "PracticeUid", "_c32" -> "BatchUid"
    , "_c33" -> "dummy1", "_c34" -> "dummy2")

  val PatientsocialHistorylookup = Map("_c0" -> "PatientId", "_c1" -> "SocialHistoryTypeCode", "_c2" -> "SocialHistoryTypeText", "_c3" -> "SocialHistoryObservedValue",
    "_c4" -> "DocumentationDate", "_c5" -> "EffectiveStopDate", "_c6" -> "SocialHistoryStatusCode",
    "_c7" -> "SocialHistoryStatusText", "_c8" -> "YearsSmoked", "_c9" -> "QuitYear", "_c10" -> "SocialHxGroup",
    "_c11" -> "EffectiveStartDate", "_c12" -> "SocialHistoryObservationKey", "_c13" -> "PracticeUid", "_c14" -> "BatchUid", "_c15" -> "dummy1", "_c16" -> "dummy2")

  val PatientVitalSignslookup = Map("_c0" -> "PatientId", "_c1" -> "ObservationCode", "_c2" -> "ObservationName",
    "_c3" -> "ObservationCategory", "_c4" -> "ObservationDate", "_c5" -> "ObservationValue"
    , "_c6" -> "ObsInterpretationCode", "_c7" -> "ObsInterpretationText"
    , "_c8" -> "TargetSiteCode", "_c9" -> "TargetSiteText", "_c10" -> "NegationInd",
    "_c11" -> "ReferenceLowerRange", "_c12" -> "ReferenceUpperRange", "_c13" -> "MethodCode"
    , "_c14" -> "MethodCodeText", "_c15" -> "ResultOBSUnit", "_c16" -> "VitalSignsKey"
    , "_c17" -> "PracticeUid", "_c18" -> "BatchUid","_c19" -> "dummy1", "_c20" -> "dummy2")


}
