package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.RaceTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientRace(RacePath: String, selectedIds: DataFrame)  extends  LookupMaps  {


  def cacheRaceProcessing(spark: SparkSession, MasterRace: DataFrame) = {


    val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientRace")
    val stagetableName = ApplicationConfig.prop.getProperty("StagePatientRace")
    val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientRace")
    val errPath = ApplicationConfig.prop.getProperty("PatientRaceErrPath")
    val validations = new ValidationCriteria(spark)

    import spark.implicits._

    try {
      val file = CommonFunc.readFile(RacePath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientRacelookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")

      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)
      val schema = file1.schema.add(StructField("ErrorMessage", StringType))

      val cachePatientRaceValidations = file1
        .transform(validations.removeDuplicateRecords("PatientId", "PatientRaceText"))

      val CleanedRecords = cachePatientRaceValidations.filter(row => validations.checkNull(row, broadcastRows, "PatientId", "PatientRaceCode", "PatientRaceText"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")

      val raceObj = new RaceTransformFunctions(spark, MasterRace)

      val CachePatientRace = addPatientUid
        .transform(raceObj.PatientRaceText)
        .transform(raceObj.PatientRaceCode)

      HiveUtility.dfwritetohive(CachePatientRace, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(rows, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")


      /*val distinctPUid = CachePatientRace.select("PracticeUid").distinct()
      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val RaceData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val fileJoinids = CachePatientRace.select("PracticeUid","PatientUid","PatientId").distinct()
      //broadcast(fileJoinids)

      val OtherData =  RaceData.as("df1").join(fileJoinids.as("df2")
        ,  $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId","left_anti")
        .select($"df1.*")

      val newstructure = CachePatientRace.select(OtherData.columns.head,OtherData.columns.tail:_*)

     val AllRaceData = newstructure.union(OtherData)

      HiveUtility.dfwritetohive(AllRaceData,mainTableName,sparkSess,stagetableName,s3Path)*/


    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }

  }

}
