package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.FamilyHistoryTransformFunc
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions.col

class PatientFamilyHistory(FamilyHistoryPath: String, selectedIds: DataFrame)  extends  LookupMaps {


  def FamilyHistoryProcessing(spark: SparkSession, mappingpractivecommondatamasterrelationship: DataFrame
                              , mappingpracticecommondatamaster: DataFrame, mappingpracticeproblem: DataFrame) {

    try {

      println("start familyhistory.............................")

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientFamilyHistory")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientFamilyHistory")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientFamilyHistory")
      val errPath = ApplicationConfig.prop.getProperty("PatientFamilyHistoryErrPath")
      val validations = new ValidationCriteria(spark)

      import spark.implicits._
      val file = CommonFunc.readFile(FamilyHistoryPath, spark)

      val file1 = file.select(file.columns.map(c => col(c).as(PatientFamilyHistorylookup.getOrElse(c, c))): _*)
        .drop("dummy1","dummy2")


      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)

      val cachePatientFamilyHistoryValidations = file1
        .transform(validations.removeDuplicateRecords("PatientId", "problemCode", "effectivedate", "RelationshipToPatientText"))
        .transform(validations.removeDuplicateRecords("PatientId", "problemtext", "effectivedate", "RelationshipToPatientText"))
        .transform(validations.removeDuplicateRecords("PatientId,PracticeUid,problemCode,RelationshipToPatientText"))

      val CleanedRecords = cachePatientFamilyHistoryValidations.filter(row => validations.checkNull(row, broadcastRows, "PatientId", "RelationshipToPatientText", "RelationshipToPatientText"))


      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")

      val tf = new FamilyHistoryTransformFunc(spark, mappingpractivecommondatamasterrelationship
        , mappingpracticecommondatamaster, mappingpracticeproblem)

      println("start familyhistory goes to lookup.............................")
      val cacheFamilyHistory3 = addPatientUid
        .transform(tf.RelationshipToPatientCode)
        .transform(tf.RelationshipToPatientText)
        .transform(tf.ProblemTypeCode)
        .transform(tf.ProblemTypeText)
        .transform(tf.ProblemCode)
        .transform(tf.ProblemDescription)


      HiveUtility.dfwritetohive(cacheFamilyHistory3, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(rows, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")

      /*println("start familyhistory goes to lookup  end. ............................")
      val distinctPUid = cacheFamilyHistory3.select("PracticeUid").distinct()

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val FamilyHistoryData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cacheFamilyHistory3.select("PracticeUid","PatientId","PatientUid").distinct()
      //broadcast(FiletoJoin)

      val otherData = FamilyHistoryData.as("df1").join(FiletoJoin.as("df2")
        ,Seq("PatientId","PracticeUid","PatientUid"),"left_anti")
        .select($"df1.*")

      val newstructure = cacheFamilyHistory3.select(otherData.columns.head,otherData.columns.tail:_*)
      val AllFamilyHistoryData = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllFamilyHistoryData,mainTableName,sparkSess,stagetableName,s3Path)
*/
    }

    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }


}
