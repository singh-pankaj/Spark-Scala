package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientLanguage(LanguagePath: String, selectedIds: DataFrame)  extends  LookupMaps {


  def cachepatientLangProcessing(spark: SparkSession) {


    //Start ImportPatientLanguageData

    try {

      import spark.implicits._
      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientLanguage")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientLanguage")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientLanguage")
      val errPath = ApplicationConfig.prop.getProperty("PatientLanguageErrPath")

      val validations = new ValidationCriteria(spark)

      val file = CommonFunc.readFile(LanguagePath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientLanguagelookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")


      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastRows = spark.sparkContext.broadcast(rows)

      val cachePatientLanguageValidations = file1
        .transform(validations.removeDuplicateRecords("PatientId", "LanguageCode", "LanguageText"))

      val CleanedRecords = cachePatientLanguageValidations.filter(row => validations.checkNull(row, broadcastRows, "PatientId", "LanguageCode", "LanguageText"))


      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")


      HiveUtility.dfwritetohive(addPatientUid, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(rows, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")

      /* val distinctPUid = addPatientUid.select("PracticeUid").distinct()
       val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
       val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

       val LanguageData = sparkSess.sql(s"select * from $mainTableName where" +
         s" practiceuid in $PartitionPUID")

       val FiletoJoin = addPatientUid.select("PracticeUid","PatientId","PatientUid").distinct()
       //broadcast(FiletoJoin)

       val otherData = LanguageData.as("df1").join(FiletoJoin.as("df2")
         ,$"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
           $"df1.PatientUid" === $"df2.PatientUid","left_anti")
         .select($"df1.*")


       val newstructure = addPatientUid.select(otherData.columns.head,otherData.columns.tail:_*)
       val AllLanguageData = newstructure.union(otherData)
       HiveUtility.dfwritetohive(AllLanguageData,mainTableName,sparkSess,stagetableName,s3Path)*/

    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }
}
