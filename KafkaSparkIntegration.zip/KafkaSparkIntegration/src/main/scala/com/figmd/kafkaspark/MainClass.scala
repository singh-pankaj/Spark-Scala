/*
@run_command : spark-submit --class com.figmd.kafkaspark.MainClass --packages com.databricks:spark-xml_2.10:0.4.1 /home/ec2-user/Akshay/KafkaSparkIntegration-assembly-0.3.jar
spark-submit --class com.figmd.kafkaspark.MainClass --packages com.databricks:spark-xml_2.10:0.4.1 /home/dev/Akshay/kafkasparkintegration_2.11-0.3.jar
*/
package com.figmd.kafkaspark

import org.apache.spark.SparkContext
import org.apache.spark.sql.{SQLContext, SparkSession}
import org.apache.spark.streaming.{Seconds, StreamingContext}

import scala.collection.mutable

object MainClass extends Serializable {
  def main(args: Array[String]): Unit = {

    //SparkSession
    val sparkSess : SparkSession= SparkSession
      .builder()
//      .master("yarn")
      .master("local[*]")
      .appName("My App")
      .getOrCreate()

    // SparkContext
    val sc : SparkContext = sparkSess.sparkContext

    // SqlContext
    val sparksql : SQLContext= sparkSess.sqlContext

    // StreamingContext
    val ssc : StreamingContext= new StreamingContext(sc, Seconds(10))


//    // Call Kafka Producer Class
//    val producerclass = new SimpleKafkaProducer(sc,sparkSess,sparksql)
//    println("Started Kafka Producer")
//    // Call Kafka Consumer Class
//    val consumerclass = new SimpleKafkaConsumer(sc,sparkSess,sparksql,ssc)
//    println("Started Kafka Consumer")
//
//    ssc.start()
//    println("Started Streaming")
//    ssc.awaitTermination()

    val xml = new XmlParser(sparkSess)
    xml.evaluateXml
  }
}
