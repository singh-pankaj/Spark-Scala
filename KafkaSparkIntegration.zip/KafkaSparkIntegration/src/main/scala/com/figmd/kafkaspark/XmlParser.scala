package com.figmd.kafkaspark

import com.figmd.commons.DataFrameUtils._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

import scala.collection.mutable
import scala.io.Source

class XmlParser (sparkSess : SparkSession) {

  import sparkSess.sqlContext.implicits._

  def readxml: List[DataFrame] = {

    val DF1 = sparkSess
      .read
      .format("com.databricks.spark.xml")
      .option("rowTag","ClinicalDocument")
      .option("excludeAttribute", "false")
      .option("valueTag", "anyname")
      .load("/user/dev/temp_test/test.xml")

    val DF2 = sparkSess
      .read
      .format("com.databricks.spark.xml")
      .option("rootTag", "ClinicalDocument")
      .option("rowTag", "component")
      .option("excludeAttribute", "false")
      .option("valueTag", "anyname")
      .load("/user/dev/temp_test/test.xml")

    List(DF1, DF2)
  }

  def getConfig(inputfile: String,regex:String) : Map[String,String] = {
    val file = Source.fromFile(inputfile).getLines()
    var invMap = new mutable.LinkedHashMap[String, String]()
    for (i <- file){
      val temp = i.split("""\=""")
      if(temp(0).mkString.equalsIgnoreCase(regex)){
      invMap += temp(1) -> temp(2)}
    }
    invMap.toMap
    //if (keysplit.equalsIgnoreCase("cachePatientDemographics"))
  }

  def getFileContentsWithoutCommentLines(filename: String,regex: String): List[String] = {
    (for (line <- Source.fromFile(filename).getLines
          if !line.trim.matches(regex)) yield line
      ).toList
  }

  def evaluateXml : List[String] = {

    //evaluate recordTarget Tag
    val readXmlDf = readxml.head
        .drop("component")
    val recordTargetDF =  readXmlDf.select($"recordTarget")
    val flattenRecordTarget = makeItFlat(recordTargetDF).na.drop("all")





    val combinedDF = readXmlDf.select($"author",$"id",$"componentOf",$"recordTarget")
        .select($"author.*",$"id.*",$"componentOf.*",$"recordTarget.patientRole.id._root".as("recordTarget_patientRole_id__root"))
    val flattenauthor = makeItFlat(combinedDF).na.drop("all")

    val patienId = readXmlDf.select("recordTarget_patientRole_id__root").toString()

    val PatientDemographicsMap = getConfig("/home/dev/Akshay/configfile","cachePatientDemographics")
    val renamedPatientDemographicsTarget = SelectAndRenameColumns(flattenauthor,PatientDemographicsMap)
    val PatientDemographicsjson = renamedPatientDemographicsTarget.toJSON.collectAsList().toString

    val entryDF = readxml(1)
      .select($"section")
      .withColumn("entry", explode($"section.entry"))
      .withColumn("patienId", lit(patienId))

    val jDf = combinedDF.join(entryDF, Seq("patienId"))

    val colName = List("entry.act","entry.encounter","entry.observation","entry.substanceAdministration")

    val extractDFFromList = convertListToDF(entryDF, colName)
    val flattenEncounterDF = extractDFFromList(1)
    val EncounterMap = getConfig("/home/dev/Akshay/configfile","cachePatientEncounters")
    val renamedEncounter = SelectAndRenameColumns(flattenEncounterDF,EncounterMap)
    val encounterJson = renamedEncounter.toJSON.collectAsList().toString

    val flattenMedicationDF = extractDFFromList(3)
    val MedicationMap = getConfig("/home/dev/Akshay/configfile","cachePatientMedication")
    val renamedMedication = SelectAndRenameColumns(flattenMedicationDF,MedicationMap)
    val MedicationJson = renamedMedication.toJSON.collectAsList().toString


    List( encounterJson , MedicationJson)

    }
}

