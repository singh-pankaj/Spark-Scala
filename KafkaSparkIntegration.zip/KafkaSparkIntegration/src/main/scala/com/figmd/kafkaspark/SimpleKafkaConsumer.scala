package com.figmd.kafkaspark

import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkContext
import org.apache.spark.sql.{SQLContext, SparkSession}
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.kafka._


//object com.figmd.kafkaspark.SimpleKafkaConsumer extends Serializable {
  class SimpleKafkaConsumer(sc:SparkContext,sparkSess:SparkSession, sparksql:SQLContext, ssc:StreamingContext)
  extends Serializable {

  Logger.getLogger("org").setLevel(Level.WARN)
  Logger.getLogger("akka").setLevel(Level.WARN)

  //createKafkaStream (streamingContext,[ZK quorum],[consumer group id],[per-topic number of Kafka partitions to consume])
  val kafkaStream = KafkaUtils.createStream(ssc, "localhost:2181","xml-group", Map("xml-test-topic" -> 2))

  //Read KafkaStream
  kafkaStream.foreachRDD { rdd =>
    val data = rdd.map(record => record._2)
    val json = sparksql.read.json(data)
    json.show(false)
    println("Write to kafka topic")
  }
}