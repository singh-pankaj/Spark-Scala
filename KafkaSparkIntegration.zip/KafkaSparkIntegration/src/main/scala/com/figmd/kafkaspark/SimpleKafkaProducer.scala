package com.figmd.kafkaspark

import java.util.Properties

import com.fasterxml.jackson.databind.{JsonNode, ObjectMapper}
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import org.apache.spark.SparkContext
import org.apache.spark.sql.{SQLContext, SparkSession}

import scala.collection.mutable

class SimpleKafkaProducer(sc : SparkContext,sparkSess : SparkSession , sparksql : SQLContext) extends Serializable {

  val xp = new XmlParser(sparkSess)
  val xpp = xp.evaluateXml

  //Configuration Settings of Producer
  val props: Properties = new Properties()
  props.put("bootstrap.servers", "localhost:9095")
  props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
  props.put("value.serializer","org.apache.kafka.connect.json.JsonSerializer")

  //Create kafkaProducer Object
  val producer  = new KafkaProducer[String, JsonNode](props)
  val objectMapper: ObjectMapper = new ObjectMapper()

  val xcs = mutable.ListBuffer[String]()
  for (j <- xpp.indices){
    val df1 = xpp(j)
    xcs += df1
  }
  val jsonList = xcs.toList
  for (i <- jsonList.indices) {
    val jsonstring = jsonList(i)
    val jsonNode: JsonNode = objectMapper.readTree(jsonstring)
    val rec: ProducerRecord[String, JsonNode] = new ProducerRecord[String, JsonNode]("xml-test-topic", jsonNode)
    producer.send(rec)
  }


}