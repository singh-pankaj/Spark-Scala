package com.figmd.commons

import org.apache.spark.sql.functions.{col, explode}
import org.apache.spark.sql.types.{ArrayType, MapType, MetadataBuilder, StructType}
import org.apache.spark.sql.{Column, DataFrame, Row}
import scala.collection.mutable
import scala.util.parsing.json.JSONObject

object DataFrameUtils extends Serializable {

  def renameColumns(schema: StructType, perifix: String = null): Array[Column] = {
    schema.fields.flatMap(field => {
      val colname = if (perifix == null) field.name else perifix + "." + field.name
      field.dataType match {
        case st: StructType => {
          renameColumns(st, colname)
        }
        case _ => {
          val columnNameWithUnderscores = colname.replace(".", "_")
          Array(col(colname).as(columnNameWithUnderscores))
        }
      }
    })
  }

  def writeFile(df: DataFrame, path: String): Unit = {

    df.coalesce(1).write.option("header", "true").csv(path)
  }

  def flattenSchema(schema: StructType, prefix: String = null): Array[Column] = {
    schema.fields.flatMap(field => {
      val columnName = if (prefix == null) field.name else prefix + "." + field.name

      field.dataType match {
        case arrayType: ArrayType => {
          //Array(col(colName)
          Array[Column](explode(col(columnName)).as(columnName.replace(".", "_")))
        }
        case mapType: MapType => {
          None
        }
        case structType: StructType => {

          flattenSchema(structType, columnName)
        }
        case _ => {
          val columnNameWithUnderscores = columnName.replace(".", "_")

          val metadata = new MetadataBuilder().putString("encoding", "ZSTD").build()

          Array(col(columnName).as(columnNameWithUnderscores, metadata))
        }
      }
    }).filter(field => field != null)
  }

  def isSchemaNested(df: DataFrame): Boolean = {
    df.schema.fields.flatMap(field => {

      field.dataType match {
        case arrayType: ArrayType => {
          Array(true)
        }
        case mapType: MapType => {
          Array(true)
        }
        case structType: StructType => {
          Array(true)
        }
        case _ => {
          Array(false)
        }
      }
    }).exists(b => b)
  }

  def makeItFlat(df: DataFrame): DataFrame = {
    if (isSchemaNested(df)) {
      val flattenedSchema = flattenSchema(df.schema)
      makeItFlat(df.select(flattenedSchema: _*))
    }
    else {
      df
    }
  }

    def convertListToDF(dataFrame: DataFrame,colName: List[String]): List[DataFrame]={
      val dfs = mutable.ArrayBuffer[DataFrame]()
      for( i <- colName.indices){
        val df1 = dataFrame.select(colName(i))
        val df2 = makeItFlat(df1).na.drop("all")
        dfs += df2
      }
      dfs.toList
    }

  def convertRowToJSON(row: Row): String = {
    val m = row.getValuesMap(row.schema.fieldNames)
    JSONObject(m).toString()
  }

  def SelectAndRenameColumns(dataFrame: DataFrame,invMap : Map[String,String]):DataFrame={
    val columnNamestemp  = mutable.ArrayBuffer[String]()
    val ColumnAliastemp = mutable.ArrayBuffer[String]()
    for (j <- invMap){
      val keys = j._1
      columnNamestemp += keys
      val values = j._2
      ColumnAliastemp += values
    }
    val columnNames = columnNamestemp.toList
    //val columnAlias = columnNamestemp.toList
    val df1 = dataFrame.select(columnNames.head,columnNames.tail:_*)
    val dfRenamed = df1.select(df1.columns.map(c => col(c).as(invMap.getOrElse(c, c))): _*)
    dfRenamed
  }

}



