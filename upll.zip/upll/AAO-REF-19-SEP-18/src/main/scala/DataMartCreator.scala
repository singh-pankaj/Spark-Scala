package com.figmd.janus


import java.text.SimpleDateFormat
import java.util.{Calendar, Properties}

import com.datastax.spark.connector.ColumnName
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.util._
import com.google.common.base.Throwables
import org.apache.hadoop.fs.FileSystem
import org.apache.log4j.{Level, Logger, PropertyConfigurator}


import scala.reflect.io.{File, Path}

object DataMartCreator extends Serializable {


  val prop = new Properties
  final lazy val randNum:Int = scala.util.Random.nextInt(500)
  var wf_id=""
  var quarter_end_date=""
  val debugMode=1
  var equal_measure_list=""
  var qpp_measure_list=""
  var nonqpp_measure_list=""
  var cms_measure_list=""
  var median_measure_list=""
  var measure_list=""
  var global_measure_name=""
  var practiceListCondition=""
  var action_name="Measure_Computation"
  @transient lazy val postgresUtility=new PostgreUtility()


  def main(args: Array[String]) {

/*
    prop.setProperty("wf_id", args(0))
    prop.setProperty("postgresHostName",args(1))
    prop.setProperty("postgresHostPort",args(2))
    prop.setProperty("postgresConfigDatabaseName",args(3))
    prop.setProperty("postgresHostUserName",args(4))
    prop.setProperty("postgresUserPass",args(5))
    prop.setProperty("equal_measure_list",args(6))
    prop.setProperty("num_executors",args(7))
    prop.setProperty("executor_cores",args(8))
    prop.setProperty("executor_memory",args(9))
    prop.setProperty("keyspace_datamart",args(10))
    prop.setProperty("keyspace_datamart_table_name",args(11))
    prop.setProperty("keyspace_webdatamart",args(12))
    prop.setProperty("cassandra_host",args(13))
    prop.setProperty("cassandra_port",args(14))
    prop.setProperty("spark_master_url",args(15))
    prop.setProperty("measure_computation_output_path",args(16))
    prop.setProperty("mode",args(17))
    prop.setProperty("postgresManagementDatabaseName",args(18))
    prop.setProperty("wfType",args(19))
    prop.setProperty("DateRange",args(20))
    prop.setProperty("cms_measure_list",args(21))
    prop.setProperty("qpp_measure_list",args(22))
    prop.setProperty("nonqpp_measure_list",args(23))
    prop.setProperty("practice_id_list",args(24))
    prop.setProperty("median_measure_list",args(25))
*/


    prop.setProperty("quarterStartDate1", "2016-01-01")
    prop.setProperty("quarterEndDate1", "2018-03-31")
    prop.setProperty("wf_id", "WF_TEST")
    prop.setProperty("postgresHostName","10.20.201.103")
    prop.setProperty("postgresHostPort","5432")
    prop.setProperty("postgresConfigDatabaseName","config_db")
    prop.setProperty("postgresManagementDatabaseName","acepmgt")
    prop.setProperty("postgresHostUserName","postgres")
    prop.setProperty("postgresUserPass","Janus@123")
    prop.setProperty("num_executors","2")
    prop.setProperty("executor_cores","2")
    prop.setProperty("executor_memory","2G")
    prop.setProperty("keyspace_datamart","acep2018")//acepnonqpp1718
    prop.setProperty("keyspace_datamart_table_name","tblencounter_mat")//tblencounter_nonqpp
    prop.setProperty("keyspace_webdatamart","webdatamart2018")

    //*******************************************Backtracking Table
    //keyspace_datamart_history
    //patientHistory

    prop.setProperty("keyspace_datamart_history","acep2018")//acepnonqpp1718
    prop.setProperty("patientHistory","tblencounter_mat")//tblencounter_nonqpp


    prop.setProperty("cassandra_port","9042")

    prop.setProperty("measure_computation_output_path","hdfs://ip-10-20-201-103.us-gov-west-1.compute.internal:8020/tmp/ACEP1")
    prop.setProperty("mode","cluster")
    prop.setProperty("cassandra_host","10.20.201.152") //10.20.201.152
    prop.setProperty("spark_master_url","yarn")//local[8]

//    prop.setProperty("spark_master_url","local[8]")
//    prop.setProperty("cassandra_host","10.20.201.152")
//    prop.setProperty("mode","client")

    prop.setProperty("wfType","QR")
    prop.setProperty("DateRange","[2018-01-01~2018-01-02]")//, 2017-04-01~2018-03-31, 2017-01-01~2017-12-31, 2016-10-01~2017-09-30
    prop.setProperty("equal_measure_list","NA")//,M6,M11a,M3,M12f,M12a,M11c,M11b,M2,M7,M12c,M1,M4,M10,M12d,M11d,M12b,M8,M9,M5
    prop.setProperty("cms_measure_list","NA")
    prop.setProperty("qpp_measure_list","M76")
    prop.setProperty("nonqpp_measure_list","NA")
    prop.setProperty("practice_id_list","NA")//31f659ea-994b-4570-9180-f302c7ce5fae,6fab4a70-6e66-4676-a507-3562c5b7cd39
    prop.setProperty("median_measure_list","NA")
    prop.setProperty("log_file","/tmp/ACEP/logger")




    //#############################################################################################################################################


    prop.setProperty("keyspace_datamart_table_name_emergencydept_master","emergencydept_master")

    if(prop.getProperty("wfType").isEmpty){
      postgresUtility.insertIntoProcessDetails(measure_list, "W0001", "CRITICAL", "Argument workflow type should not null, Values may be QR,QNR,MR,MNR,QCNR.", "FAIL")
      System.exit(-1)
    }

    val start_date = Calendar.getInstance.getTime

    val wfType=prop.getProperty("wfType")
    wf_id=prop.getProperty("wf_id")


    println("Start Time : "+start_date)

    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)
    Logger.getLogger("myLogger").setLevel(Level.OFF)

    try {
      var sparkUtility = new SparkUtility()
      var spark = sparkUtility.getSparkContext()
      spark.sparkContext.setLogLevel("ERROR")
      //spark.sparkContext.setLogLevel("OFF")

      val dateUtility = new DateUtility()
      val postgreUtility = new PostgreUtility()
      val fileUtility = new FileUtility()
      var cassandraUtility = new CassandraUtility()
      var measureUtilityObj=new MeasureUtility()

      //practice list for measure computation
      var practiceListCondition=""
      if(prop.getProperty("practice_id_list")!="NA" && prop.getProperty("practice_id_list")!="")
        prop.setProperty("practiceListCondition","and practiceuid in("+prop.getProperty("practice_id_list")+")")
      else
        prop.setProperty("practiceListCondition","")


/*      //    var logfilename =""
      lazy val logfilename=prop.getProperty("log_file") //fileUtility.getPropertyLog()
      println(randNum+"::::::::::::wfType:::::::::GANESH::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"+logfilename)
      lazy val propobj: Properties = new Properties()
      propobj.setProperty("log4j.rootLogger","WARN,file")
      propobj.setProperty("log4j.appender.file","org.apache.log4j.FileAppender")//.FileAppender
      propobj.setProperty("log4j.additivity.file","false")
      propobj.setProperty("log4j.appender.file.File",logfilename)
      propobj.setProperty("log4j.appender.file.ImmediateFlush","true")
      propobj.setProperty("log4j.appender.file.Threshold","WARN")
      propobj.setProperty("log4j.appender.file.Append","false")
      propobj.setProperty("log4j.appender.file.layout","org.apache.log4j.PatternLayout")
      propobj.setProperty("log4j.appender.file.layout.ConversionPattern","%m%n")
      PropertyConfigurator.configure(propobj)
      println("GANESH::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"+logfilename)*/

      var dateFormat = fileUtility.getProperty("date.format")
      var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)

      //var quarterStartDate = prop.getProperty("quarterStartDate")
      //var quarterEndDate = prop.getProperty("quarterEndDate")
      // ACEP EQUAL Measures
      equal_measure_list = prop.getProperty("equal_measure_list")
      qpp_measure_list = prop.getProperty("qpp_measure_list")
      nonqpp_measure_list = prop.getProperty("nonqpp_measure_list")
      cms_measure_list = prop.getProperty("cms_measure_list")
      median_measure_list = prop.getProperty("median_measure_list")

      if (!equal_measure_list.equalsIgnoreCase("NA")) {
        if (measure_list.isEmpty) {
          measure_list = equal_measure_list
        } else {
          measure_list += "," + equal_measure_list
        }
      }
      if (!qpp_measure_list.equalsIgnoreCase("NA")) {
        if (measure_list.isEmpty) {
          measure_list = qpp_measure_list
        } else {
          measure_list += "," + qpp_measure_list
        }
      }
      {
        if (!nonqpp_measure_list.equalsIgnoreCase("NA")) {
          if (measure_list.isEmpty) {
            measure_list = nonqpp_measure_list
          } else {
            measure_list += "," + nonqpp_measure_list
          }
        }
        if (!cms_measure_list.equalsIgnoreCase("NA")) {
          if (measure_list.isEmpty) {
            measure_list = cms_measure_list
          } else {
            measure_list += "," + cms_measure_list
          }
        }
        if (!median_measure_list.equalsIgnoreCase("NA")) {
          if (measure_list.isEmpty) {
            measure_list = median_measure_list
          } else {
            measure_list += "," + median_measure_list
          }
        }

        println("Measure List:::"+measure_list)

        var date_str = prop.getProperty("DateRange")
        var month_end_date_list = ""
        if (!date_str.isEmpty) {

          val rdd = new CassandraUtility().getCassandraRDD(spark)

          var date_range_arr = date_str.trim.substring(1, date_str.length - 1).split(",")
          //loop for rolling non rolling
          for (date_range <- date_range_arr) {
            println("prop:1::::::::::::::" + date_range)

            var date_arr = date_range.split("~")
            var quarterStartDate = date_arr(0).trim
            var quarterEndDate = date_arr(1).trim
            var quarterStartDateFormatted = SIMPLE_DATE_FORMAT.parse(date_arr(0).trim)
            var quarterEndDateFormatted = SIMPLE_DATE_FORMAT.parse(date_arr(1).trim)


            prop.setProperty("quarterStartDate", quarterStartDate.toString)
            prop.setProperty("quarterEndDate", quarterEndDate.toString)


            println("quarterStartDate:::::::::::::::" + prop.getProperty("quarterStartDate"))
            println("quarterEndDate:::::::::::::::" + prop.getProperty("quarterEndDate"))
            println("equal_measure_list:::::::::::::::" + prop.getProperty("equal_measure_list"))
            println("qpp_measure_list:::::::::::::::" + prop.getProperty("qpp_measure_list"))
            println("nonqpp_measure_list:::::::::::::::" + prop.getProperty("nonqpp_measure_list"))
            println("cms_measure_list:::::::::::::::" + prop.getProperty("cms_measure_list"))
            println("median_measure_list:::::::::::::::" + prop.getProperty("median_measure_list"))


            if (!equal_measure_list.equalsIgnoreCase("NA") && !equal_measure_list.equalsIgnoreCase("")) {
              var equal_measures = equal_measure_list.split(",");
              equal_measures.foreach(measure => {
                global_measure_name=measure

                val fullname = "com.figmd.janus.measureComputation.equalMeasures.ACEP" + measure.substring(1) + "$"
                println(fullname)

                val clazz = Class.forName(fullname);
                val myObj = clazz.getField("MODULE$").get(classOf[Measure]).asInstanceOf[Measure]
                //val myObj = clazz.getField("MODULE$").get(classOf[MeasureTrait]).asInstanceOf[MeasureTrait]
                var columnRef = measureUtilityObj.getFiledList(measure)
                val newRdd=rdd.select(columnRef.map(ColumnName(_)):_*).where(s"encounterdate>=? and encounterdate<=? "+prop.getProperty("practiceListCondition"),quarterStartDateFormatted, quarterEndDateFormatted)
                myObj.refresh(spark,newRdd,measure,quarterStartDateFormatted,quarterEndDateFormatted)
              })
            }

            if (!qpp_measure_list.equalsIgnoreCase("NA") && !qpp_measure_list.equalsIgnoreCase("")) {
              var qpp_measures = qpp_measure_list.split(",");
              qpp_measures.foreach(measure => {
                global_measure_name=measure
                val fullname = "com.figmd.janus.measureComputation.qppMeasures.ACEP" + measure.substring(1) + "$"
                println(fullname)

                val clazz = Class.forName(fullname);
                val myObj = clazz.getField("MODULE$").get(classOf[Measure]).asInstanceOf[Measure]
                var columnRef = measureUtilityObj.getFiledList(measure)
                val newRdd=rdd.select(columnRef.map(ColumnName(_)):_*).where(s"encounterdate>=? and encounterdate<=? "+prop.getProperty("practiceListCondition"),quarterStartDateFormatted, quarterEndDateFormatted)
                myObj.refresh(spark,newRdd,measure,quarterStartDateFormatted,quarterEndDateFormatted)
              })

            }

            if (!nonqpp_measure_list.equalsIgnoreCase("NA") && !nonqpp_measure_list.equalsIgnoreCase("")) {
              var nonqpp_measures = nonqpp_measure_list.split(",");
              nonqpp_measures.foreach(measure => {
                global_measure_name=measure
                val fullname = "com.figmd.janus.measureComputation.nonQppMeasures.ACEP" + measure.substring(1) + "$"
                println(fullname)

                val clazz = Class.forName(fullname);
                val myObj = clazz.getField("MODULE$").get(classOf[Measure]).asInstanceOf[Measure]
                var columnRef = measureUtilityObj.getFiledList(measure)
                val newRdd=rdd.select(columnRef.map(ColumnName(_)):_*).where(s"encounterdate>=? and encounterdate<=? "+prop.getProperty("practiceListCondition"),quarterStartDateFormatted, quarterEndDateFormatted)
                myObj.refresh(spark,newRdd,measure,quarterStartDateFormatted,quarterEndDateFormatted)

              })

            }

            if (!cms_measure_list.equalsIgnoreCase("NA") && !cms_measure_list.equalsIgnoreCase("")) {
              var cms_measures = cms_measure_list.split(",");
              cms_measures.foreach(measure => {
                global_measure_name=measure
                val fullname = "com.figmd.janus.measureComputation.cmsMeasures.ACEP" + measure.substring(1) + "$"
                println(fullname)

                val clazz = Class.forName(fullname);
                val myObj = clazz.getField("MODULE$").get(classOf[Measure]).asInstanceOf[Measure]
                var columnRef = measureUtilityObj.getFiledList(measure)
                val newRdd=rdd.select(columnRef.map(ColumnName(_)):_*).where(s"encounterdate>=? and encounterdate<=? "+prop.getProperty("practiceListCondition"),quarterStartDateFormatted, quarterEndDateFormatted)
                myObj.refresh(spark,newRdd,measure,quarterStartDateFormatted,quarterEndDateFormatted)
              })

            }

            if (!median_measure_list.equalsIgnoreCase("NA") && !median_measure_list.equalsIgnoreCase("")) {
//                val fullnames = "com.figmd.janus.measureComputation.nonQppMeasures.ACEPmedian_1$~com.figmd.janus.measureComputation.nonQppMeasures.ACEPmedian_2$~com.figmd.janus.measureComputation.nonQppMeasures.ACEPmedian_3$~com.figmd.janus.measureComputation.nonQppMeasures.ACEPmedian_4$"
                val fullnames = "com.figmd.janus.measureComputation.nonQppMeasures.ACEPmedian_1_2$~com.figmd.janus.measureComputation.nonQppMeasures.ACEPmedian_3_4$"
                var fullname_list = fullnames.split("~");
                fullname_list.foreach(fullname => {
                  global_measure_name=fullname
                println(fullname)
                val clazz = Class.forName(fullname);
                val myObj = clazz.getField("MODULE$").get(classOf[MeasureTrait]).asInstanceOf[MeasureTrait]
                myObj.refresh(spark,quarterStartDateFormatted,quarterEndDateFormatted)
                })

//              var median_measures = median_measure_list.split(",");
//              median_measures.foreach(measure => {
//                val fullname = "com.figmd.janus.measureComputation.nonQppMeasures.ACEP" + measure.substring(1) + "$"
//                println(fullname)
//
//                val clazz = Class.forName(fullname);
//                val myObj = clazz.getField("MODULE$").get(classOf[MeasureTrait]).asInstanceOf[MeasureTrait]
//                myObj.refresh(spark, SIMPLE_DATE_FORMAT.parse(quarterStartDate), SIMPLE_DATE_FORMAT.parse(quarterEndDate))
//              })
            }




            println(wfType + " Measure refresh Start Time : " + start_date)
            println(wfType + " Measure refresh End Time  : " + Calendar.getInstance.getTime)
          }

          var log_file=measureUtilityObj.logfilename
          println("1.GANESH::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"+log_file)
          var s3_file_path=fileUtility.getProperty("file.output.path")+"/"+wf_id+"_"+wfType
          import java.net.URI
          val file = File(log_file)
          val path_src=new org.apache.hadoop.fs.Path(log_file)
          val path_dst=new org.apache.hadoop.fs.Path(s3_file_path)
          if (file.exists) {
            import sys.process._
            val exitCode2 = (s"wc -l $path_src").!!
            println(exitCode2)
            println(path_src+"::::::::::::::::::::::::GANESH:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"+path_dst)
            val exitCode = (s"sed -i '/~/!d' $path_src").!
            val exitCode3 = (s"wc -l $path_src").!!
            println(exitCode3)
            //code to copy from local to hdfs
            //measureUtilityObj.hdfsConf.moveFromLocalFile(path_src,path_dst)
            //code to copy from local to s3
//            val fs = FileSystem.get(URI.create(s3_file_path), new SparkUtility().getSparkContext().sparkContext.hadoopConfiguration)
//            if(fs.exists(path_dst))
//              fs.delete(path_dst,true)
//            fs.moveFromLocalFile(path_src, path_dst)

            //fs.copyFromLocalFile(true, true, path_src, path_dst)
          }


//          if (!median_measure_list.equalsIgnoreCase("NA") && !median_measure_list.equalsIgnoreCase("")) {
//            cassandraUtility.deleteFromWebdatamartMedian(spark, measure_list,date_str)
//          }
//          else{
//            cassandraUtility.deleteFromWebdatamart(spark, measure_list,date_str)
//          }
        }

        //      postgresUtility.tinPracticeMapping(spark)
        //      postgresUtility.practiceSubPracticeMapping(spark)
        println("Measure refresh Start Time : " + start_date)
        println("Measure refresh End Time  : " + Calendar.getInstance.getTime)
        //var emailUtility  = new EmailUtility("sagar.kulkarni2007@gmail.com","","","sagar.kulkarni2007@gmail.com","Test","Hi","smtp.gmail.com")
        //emailUtility.sendMessage
      }
    }
    catch {
      case e: Exception => {
        println(e.printStackTrace())
        postgresUtility.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
        System.exit(-1)
      }
    }

  }
}

