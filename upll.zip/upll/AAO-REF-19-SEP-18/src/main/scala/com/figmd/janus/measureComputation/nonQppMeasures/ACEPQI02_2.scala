package com.figmd.janus.measureComputation.nonQppMeasures

  import java.util.Date

  import com.datastax.spark.connector.CassandraRow
  import com.datastax.spark.connector.rdd.CassandraTableScanRDD
  import com.figmd.janus.DataMartCreator.prop
  import com.figmd.janus.{DataMartCreator, Measure}
  import com.figmd.janus.util._
  import com.google.common.base.Throwables
  import org.apache.spark.sql.SparkSession
  import com.google.common.base.Throwables
  import org.apache.spark.broadcast.Broadcast
  import org.apache.spark.rdd.RDD

  object ACEPQI02_2 extends MeasureUtility with Serializable with Measure {

    //final var MEASURE_NAME = "MQI02_2"


    def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

      // Filter IPP
      val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
      ippRDD.cache()
      //NotEligiable
      val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Exclusions
      //BAcktracking RDD
      val CRA = getBackTrackingList(rdd, ippRDD, "urolgysurg", "urolgysurg_date","flnkpain","flnkpain_date");
      val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)

      val exclusionRDD = getExclusionRdd(ippRDD,CRA_list ,MEASURE_NAME)
      exclusionRDD.cache()
      // Filter Intermediate
      val intermediateA =  getinterRDD(ippRDD,exclusionRDD)
      intermediateA.cache()
      // Filter Met


      val metRDD = getMet(intermediateA,MEASURE_NAME)
      metRDD.cache()
      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter not meate
      val notMetRDD =  getinterRDD(intermediateA,metRDD)
      notMetRDD.cache()

      saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


    }
          //var ippRDD
          def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
            rdd.filter(r =>
              isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&
                (
                  isAgeBetween(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18, 51)
                    &&
                    (checkElementPresent(r, IPP, MEASURE_NAME, "edv") || checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem"))
                    &&
                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "flnkpain")
                        &&
                        (
                          isDuringEncounterEDvisit(r, IPP, MEASURE_NAME, "flnkpain_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                            ||
                            isDateEqual(r, IPP, MEASURE_NAME, "flnkpain_date", "crtclcrem_date")
                          )
                      )
                    && (
                    checkElementPresent(r, IPP, MEASURE_NAME, "kidneystone")
                      &&
                      (
                        isDuringEncounterEDvisit(r, IPP, MEASURE_NAME, "kidneystone_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                          ||
                          isDateEqual(r, IPP, MEASURE_NAME, "kidneystone_date", "crtclcrem_date")
                        )
                    )
                  )

            )
          }



    def getExclusionRdd(ippRDD:RDD[CassandraRow],CRA_list:Broadcast[List[String]],MEASURE_NAME:String): RDD[CassandraRow] = {

      ippRDD.filter(r =>
        (
          (
            checkElementValueGreaterDouble(r, EXCLUSION, MEASURE_NAME, "creatnine", 1.5)
              &&
              (
                isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "creatnine_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, EXCLUSION, MEASURE_NAME, "creatnine_date", "crtclcrem_date")
                )
            )
            ||
            (chkValueRangeLess(r, EXCLUSION, MEASURE_NAME, "glomfiltrate", 60)
              &&
              (
                isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "glomfiltrate_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, EXCLUSION, MEASURE_NAME, "glomfiltrate_date", "crtclcrem_date")
                ))
            ||
            (checkElementValueGreaterOrEqualDouble(r, EXCLUSION, MEASURE_NAME, "bodytemp", 37.5)
              &&
              (
                isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "bodytemp_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, EXCLUSION, MEASURE_NAME, "bodytemp_date", "crtclcrem_date")
                ))
            ||
            (chkValueRangeGreater(r, EXCLUSION, MEASURE_NAME, "leukurine", 11000)
              &&
              (
                isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "leukurine_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, EXCLUSION, MEASURE_NAME, "leukurine_date", "crtclcrem_date")
                )
              )
            ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "nitrurine")
              &&
              (
                isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "nitrurine_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, EXCLUSION, MEASURE_NAME, "nitrurine_date", "crtclcrem_date")
                )
              && checkElementPresent(r, EXCLUSION, MEASURE_NAME, "positive")
              )
            ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "leukesturn")
              &&
              (
                isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "leukesturn_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, EXCLUSION, MEASURE_NAME, "leukesturn_date", "crtclcrem_date")
                )
              && checkElementPresent(r, EXCLUSION, MEASURE_NAME, "positive"))
            ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "uncntrpain")
              &&
              (
                isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "uncntrpain_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, EXCLUSION, MEASURE_NAME, "uncntrpain_date", "crtclcrem_date")
                )
              )
            ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "alca")
              && isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "alca_date", "ed_visit_departure_date")
              )
            ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "anticoag")
              && isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "anticoag_date", "ed_visit_departure_date")
              )
            ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "kidcon")
              && isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "kidcon_date", "ed_visit_departure_date")
              )
            ||
            (checkElementValue(r, EXCLUSION, MEASURE_NAME, "sex", 2)
              && checkElementPresent(r, EXCLUSION, MEASURE_NAME, "preg")
              && isDateEqual(r, EXCLUSION, MEASURE_NAME, "preg_date", "encounterdate")
              )
            ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "trau")
              && isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "trau_date", "ed_visit_departure_date")
              )
            ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "kitr")
              &&
              (isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "kitr_date", "ed_visit_arrival_date")
                ||
                isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "kitr_date", "crtclcrem_date")
                )
              )
            ||
            BackTracking48(r, EXCLUSION, MEASURE_NAME, CRA_list)
            ||
            BackTracking72(r, EXCLUSION, MEASURE_NAME, CRA_list)
          )

      )
    }
        // Filter Met
        def getMet(intermediateA:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
          intermediateA.filter(r =>
            (checkElementPresent(r, MET, MEASURE_NAME, "kub_xray_ap")
              &&
              (
                isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "kub_xray_ap_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, MET, MEASURE_NAME, "kub_xray_ap_date", "crtclcrem_date")

                )
              &&
              (
                checknull(r, MET, MEASURE_NAME, "ultra_apf")
                  &&
                  checknull(r, MET, MEASURE_NAME, "ct_abd_pel")
                  &&
                  checknull(r, MET, MEASURE_NAME, "mri_apf")
                )
              )
              ||
              (
                (
                  checkElementPresent(r, MET, MEASURE_NAME, "ultra_apf")
                    &&
                    (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "ultra_apf_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                      ||
                      isDateEqual(r, MET, MEASURE_NAME, "ultra_apf_date", "crtclcrem_date")
                      )
                  )
                  &&
                  (
                    checknull(r, MET, MEASURE_NAME, "kub_xray_ap")
                      &&
                      checknull(r, MET, MEASURE_NAME, "ct_abd_pel")
                      &&
                      checknull(r, MET, MEASURE_NAME, "mri_apf")
                    )
                )
          )
        }





    def BackTracking48(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {


      for (x <- CRA.value) {
        if (x != "") {
          val back_data = x.split("~")
          val patientid = back_data(0);
          val element = back_data(1);
          val element_date = dateUtility.dateTimeParse(back_data(2));

          if ( !r.isNullAt("ed_visit_arrival_date") && !r.isNullAt("crtclcrem_date") &&
            element == "1"
            &&
            (
              r.getDateTime("ed_visit_arrival_date").equals(element_date)
                ||
                r.getDateTime("ed_visit_arrival_date").minusHours(48).equals(element_date)
                ||
                (
                  element_date.isBefore(r.getDateTime("ed_visit_arrival_date"))
                    &&
                    element_date.isAfter(r.getDateTime("ed_visit_arrival_date").minusHours(48))

                  )
              )
            ||
            (
              r.getDateTime("crtclcrem_date").equals(element_date)
                ||
                r.getDateTime("crtclcrem_date").minusHours(48).equals(element_date)
                ||
                (
                  element_date.isBefore(r.getDateTime("crtclcrem_date"))
                    &&
                    element_date.isAfter(r.getDateTime("crtclcrem_date").minusHours(48))

                  )

              )
          )
          {
            return true;
          }
        }

      }

      return false;

    }

    def BackTracking72(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {


      for (x <- CRA.value) {
        if (x != "") {
          val back_data = x.split("~")
          val patientid = back_data(0);
          val element = back_data(3);
          val element_date = dateUtility.dateTimeParse(back_data(4));

          if ( !r.isNullAt("ed_visit_arrival_date") && !r.isNullAt("crtclcrem_date") &&
            element == "1"
            &&
            (
              (
                (r.getDateTime("ed_visit_arrival_date").isAfter(element_date) || r.getDateTime("ed_visit_arrival_date").equals(element_date))
                  &&
                  (r.getDateTime("ed_visit_arrival_date").minusHours(72).isBefore(element_date) || r.getDateTime("ed_visit_arrival_date").minusHours(72).equals(element_date))
                )
                ||
                (
                  (r.getDateTime("crtclcrem_date").isAfter(element_date) || r.getDateTime("crtclcrem_date").equals(element_date))
                    &&
                    (r.getDateTime("crtclcrem_date").minusHours(72).isBefore(element_date) || r.getDateTime("crtclcrem_date").minusHours(72).equals(element_date))
                  )
              )
          )
          {
            return true;
          }
        }

      }

      return false;

    }


    def getBackTrackingList(rdd: CassandraTableScanRDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement_date1: String,backtrackelement2: String, backtrackelement_date2: String): List[String] = {

      val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).distinct().collect().toList

      val IPPFilterExclusionRDD = rdd.filter(x => (ipp_patient_list.contains(x.columnValues(2))))

      var CRA = IPPFilterExclusionRDD.map(x =>
        if (!x.isNullAt("patientuid")
          && !x.isNullAt(backtrackelement1) && (!x.isNullAt(backtrackelement_date1)) && !x.isNullAt(backtrackelement2) && !x.isNullAt(backtrackelement_date2)) {
          x.getString("patientuid") + "~" + x.getString(backtrackelement1) + "~" + x.getString(backtrackelement_date2) + "~" + x.getString(backtrackelement2) + "~" + x.getString(backtrackelement_date2)
        }
        else ""
      )
        .collect()
        .toList

      return CRA;
    }

  }
