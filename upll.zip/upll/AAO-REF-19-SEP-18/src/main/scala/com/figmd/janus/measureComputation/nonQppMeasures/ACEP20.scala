package com.figmd.janus.measureComputation.nonQppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import org.apache.spark.rdd.RDD

object ACEP20 extends MeasureUtility with Measure {

  //var MEASURE_NAME = "M20"


  // Logic for measure refresh
  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    // Eligible IPP
    val eligibleRdd = getEligibleIpp(ippRDD,MEASURE_NAME)
    // Filter Exclusions
    val notEligibleRDD =ippRDD.subtract(eligibleRdd)
    eligibleRdd.cache()
    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(eligibleRdd,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getSubtractRDD(eligibleRdd,exclusionRDD)
    intermediateA.cache()
    // Filter Met
    val metRDD = getMet(intermediateA,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not meate
    val notMetRDD =  getSubtractRDD(intermediateA,metRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }

      // Filter IPP
      def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
        rdd
          .filter(r =>
            (
              isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate)
                && (
                isAgeBetween(r, IPP, MEASURE_NAME, "dob", "encounterdate", 2, 18)
                  &&
                  (checkElementPresent(r, IPP, MEASURE_NAME, "edv")
                    || checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem"))

                  &&
                  (
                    checkElementPresent(r, IPP, MEASURE_NAME, "npneheadtrm")
                      &&
                      isDateEqual(r, IPP, MEASURE_NAME, "npneheadtrm_date", "encounterdate")
                    )

                )
              )
          )
      }

  def getEligibleIpp(ippRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
     ippRDD.filter(r =>
      checkElementPresent(r, ELIGIBLE, MEASURE_NAME, "hdct") &&
        (isDuringEncounterEDvisit(r, ELIGIBLE, MEASURE_NAME, "hdct_date", "ed_visit_arrival_date", "ed_visit_departure_date")
          ||
          isDateEqual(r, ELIGIBLE, MEASURE_NAME, "hdct_date", "crtclcrem_date")
          )
    )
  }
  def getExclusionRdd(eligibleRdd:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {

    eligibleRdd.filter(r => (
      (
        checkElementPresent(r, EXCLUSION, MEASURE_NAME, "brntumr")
          &&
          isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "brntumr_date", "ed_visit_departure_date")
        )
        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "coglpths")
            &&
            isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "coglpths_date", "ed_visit_departure_date"))
        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "thrmcytopn")
            &&
            isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "thrmcytopn_date", "ed_visit_departure_date"))
        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "vntrishnt")
            &&
            isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "vntrishnt_date", "ed_visit_departure_date"))
      )
    )
  }

     def getMet(intermediateA:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {

       intermediateA.filter(r => (

         !(chkValueRangeLess(r, MET, MEASURE_NAME, "gcs", 15)
           &&
           (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "gcs_date", "ed_visit_arrival_date", "ed_visit_departure_date")
             ||
             isDateEqual(r, MET, MEASURE_NAME, "gcs_date", "crtclcrem_date")
             )
           )
           &&
           (
             checknull(r, MET, MEASURE_NAME, "loss_concusnes")
               &&
               r.isNullAt("loss_concusnes_date")
             )
           &&
           (checknull(r, MET, MEASURE_NAME, "phylsignbslesklfrctr") && r.isNullAt("phylsignbslesklfrctr_date"))
           &&
           (checknull(r, MET, MEASURE_NAME, "hdache") && checknull(r, MET, MEASURE_NAME, "severe") && r.isNullAt("hdache_date"))
           &&
           (checknull(r, MET, MEASURE_NAME, "signaltmenstats") && r.isNullAt("signaltmenstats_date"))
           &&
           (checknull(r, MET, MEASURE_NAME, "vomit") && r.isNullAt("vomit_date"))
           &&
           (checknull(r, MET, MEASURE_NAME, "dngrsmechinjry") && r.isNullAt("dngrsmechinjry_date"))
         )
       )
     }


}