package com.figmd.janus.measureComputation.equalMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP4 extends MeasureUtility  with Measure{

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit =
  {
    // Filter IPP
    var ippRDD = getIpp(rdd,MEASURE_NAME)
    ippRDD.cache();
    // Filter Exclusions
    var notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    var exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Met
    var metRDD = getMet(ippRDD,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    var exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //exceptionRDD.persist()
    var notMetRDD = getNotMet(ippRDD, metRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
  }


    // Filter IPP
    def getIpp(rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow]= {
      rdd
        .filter(r =>
          (
            isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "ed_visit_arrival_date", 18)
              &&
              checkElementPresent(r, IPP, MEASURE_NAME, "ed_crtcl")
              &&
              checkElementPresent(r, IPP, MEASURE_NAME, "discharge")
              &&
              isElementDateStartsAfterStartOf(r, IPP, MEASURE_NAME, "discharge_date", "ed_visit_arrival_date")
              &&
              checkElementPresent(r, IPP, MEASURE_NAME, "mnrhdinjry")
              &&
              isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "mnrhdinjry_date", "ed_visit_departure_date")
            )
        )
    }

    // Filter Met
    def getMet(rdd:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow]= {
      rdd.filter(r =>
        checkElementPresent(r, MET, MEASURE_NAME, "cthd")
          &&
          isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "cthd_date", "ed_visit_arrival_date", "ed_visit_departure_date")
      )
    }

}
