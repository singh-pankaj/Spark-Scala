package com.figmd.janus.measureComputation.nonQppMeasures

import java.util.Date

import com.figmd.janus.DataMartCreator.prop

import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession

object ACEPmedian_1_2 extends MeasureUtility with MeasureTrait {

  @transient lazy val postgresUtility = new PostgreUtility()
  final var MEASURE_NAME = "M32_1"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {
    var measure_list:List[String] = List()
    val mlist = prop.getProperty("median_measure_list")
    try {
      if (!mlist.isEmpty) {
        var median_measures = mlist.split(",");
        for (m <- median_measures) {
          measure_list =measure_list:+ m
          //println("measure_name:::::::::::::"+m)
        }

        println("measure_list:::::::::::::"+measure_list)
        var columnRef = getFiledList(MEASURE_NAME)
        val rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0), columnRef(1), columnRef(2), columnRef(3), columnRef(4), columnRef(5), columnRef(6), columnRef(7), columnRef(8), columnRef(9), columnRef(10), columnRef(11), columnRef(12), columnRef(13), columnRef(14), columnRef(15), columnRef(16), columnRef(17), columnRef(18), columnRef(19), columnRef(20), columnRef(21), columnRef(22), columnRef(23), columnRef(24), columnRef(25), columnRef(26))
          .where(s"encounterdate>=? and encounterdate<=? "+prop.getProperty("practiceListCondition"), startDate, endDate)
        val dateUtil = new DateUtility()
        val list80k = chkValueRangeGreaterOrEqualMedian1(sparkSession, "edannualvisitvolumn", 80000)
        val list60k = chkValueRangeGreaterOrLesserOrEqualMedian1(sparkSession, "edannualvisitvolumn", 60000, 79999)
        val list40k = chkValueRangeGreaterOrLesserOrEqualMedian1(sparkSession, "edannualvisitvolumn", 40000, 59999)
        val list20k = chkValueRangeGreaterOrLesserOrEqualMedian1(sparkSession, "edannualvisitvolumn", 20000, 39999)
        val list19k = chkValueRangeLessorEqualMedian1(sparkSession, "edannualvisitvolumn", 19999)
        val listFree = chkValueFreestanding_EDMedian1(sparkSession, "name", "Freestanding ED")

        val CRA_list80k: Broadcast[Set[String]] = sparkSession.sparkContext.broadcast(list80k)
        val CRA_list60k: Broadcast[Set[String]] = sparkSession.sparkContext.broadcast(list60k)
        val CRA_list40k: Broadcast[Set[String]] = sparkSession.sparkContext.broadcast(list40k)
        val CRA_list20k: Broadcast[Set[String]] = sparkSession.sparkContext.broadcast(list20k)
        val CRA_list19k: Broadcast[Set[String]] = sparkSession.sparkContext.broadcast(list19k)
        val CRA_listFree: Broadcast[Set[String]] = sparkSession.sparkContext.broadcast(listFree)

        // Filter IPP
        val ippRDD = rdd.filter(r =>
          (
            checkElementPresent(r, IPP, MEASURE_NAME, "edv")
              ||
              checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem")
            )
            &&
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "disch_emrgncydept")
                &&
                isDateEqual(r, IPP, MEASURE_NAME, "disch_emrgncydept_date", "ed_visit_departure_date")
                &&
                (
                  isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "ed_visit_arrival_date", "disch_emrgncydept_date")
                    ||
                    isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "crtclcrem_date", "disch_emrgncydept_date")
                  )
              )
           /* &&
            checknull(r, IPP, MEASURE_NAME, "pshepa")
            &&
            !(checkElementPresent(r, IPP, MEASURE_NAME, "acutcrhosptl") &&
              isDateStartsAfterOrConcurrentWithStartOf(r, EXCLUSION, MEASURE_NAME, "acutcrhosptl_date", "ed_visit_departure_date")
              )*/
        )
        ippRDD.cache()

        // Common Age greater than 18
        val ippRDDGreater18 = ippRDD.filter(r =>
          isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "edv_date", 18) ||
            isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "crtclcrem_date", 18)
        )
        //ippRDDgt18.cache()
        ippRDDGreater18.cache()


        // Common Age Less than 18
        val ippRDDLess18 = ippRDD.filter(r =>
          isAgeLess(r, IPP, MEASURE_NAME, "dob", "edv_date", 18) ||
            isAgeLess(r, IPP, MEASURE_NAME, "dob", "crtclcrem_date", 18)
        )
        //ippRDDls18.cache()
        ippRDDLess18.cache()


        //**********************************************Exclusion* Greater**************************************

        val exclusionRDDGt18 = ippRDDGreater18.filter(r =>
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "paex")
              &&
              (
                isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "paex_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, EXCLUSION, MEASURE_NAME, "paex_date", "crtclcrem_date")
                )
            )
        )
        exclusionRDDGt18.cache()
        val ippRDDgt18 = ippRDDGreater18.subtract(exclusionRDDGt18)



        //**********************************************Exclusion Less***************************************

        val exclusionRDDLs18 = ippRDDLess18.filter(r =>
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "paex")
              &&
              (
                isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "paex_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, EXCLUSION, MEASURE_NAME, "paex_date", "crtclcrem_date")
                )
            )
        )
        exclusionRDDLs18.cache()
        val ippRDDls18 = ippRDDLess18.subtract(exclusionRDDLs18)

         //******************************************Ipp_1 filter*************************

        val ippRDDgt18_1 = ippRDDgt18.filter(r=>

            checknull(r, IPP, MEASURE_NAME, "pshepa")
            &&
            !(checkElementPresent(r, IPP, MEASURE_NAME, "acutcrhosptl") &&
              isDateStartsAfterOrConcurrentWithStartOf(r, EXCLUSION, MEASURE_NAME, "acutcrhosptl_date", "ed_visit_departure_date")
             )

        )
        ippRDDgt18_1.cache()

        val ippRDDls18_1 = ippRDDls18.filter(r=>

          checknull(r, IPP, MEASURE_NAME, "pshepa")
            &&
            !(checkElementPresent(r, IPP, MEASURE_NAME, "acutcrhosptl") &&
              isDateStartsAfterOrConcurrentWithStartOf(r, EXCLUSION, MEASURE_NAME, "acutcrhosptl_date", "ed_visit_departure_date")
              )

        )
        ippRDDls18_1.cache()

        //******************************************Ipp_2 filter*************************

        val ippRDDgt18_2 = ippRDDgt18.filter(r=>

          checkElementPresent(r, IPP, MEASURE_NAME, "pshepa")

        )
        ippRDDgt18_2.cache()

        val ippRDDls18_2 = ippRDDls18.filter(r=>

          checkElementPresent(r, IPP, MEASURE_NAME, "pshepa")

        )
        ippRDDls18_2.cache()


        //*************************************Median_1*****************************************************
        MEASURE_NAME="M32_1" // age gt 18
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD32_1 = ippRDDgt18_1.map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2),dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd32_1 = ippRDD32_1.groupBy(x=>x._1).map(k=>(k._1,median(k._2.toList.sortBy(x=>x._4).map(x=>x._4)),k._2.size))
          //location
          val locationRDD32_1 = ippRDD32_1.map(x=>((x._1,x._3),x)).groupByKey().map(x=>(x._1,median(x._2.toList.sortBy(x=>x._4).map(x=>x._4)),x._2.map(x=>x._2).size)).map(x=>(x._1._1,x._1._2,x._2,x._3))
          //provider
          val providerRDD32_1 = ippRDD32_1.map(x=>((x._1,x._2),x)).groupByKey().map(x=>(x._1,median(x._2.toList.sortBy(x=>x._4).map(x=>x._4)),x._2.map(x=>x._2).size)).map(x=>(x._1._1,x._1._2,x._2,x._3))
          //provider + location
          val providerLocationRDD32_1 = ippRDD32_1.map(x=>((x._1,x._3,x._2),x)).groupByKey().map(x=>(x._1,median(x._2.toList.sortBy(x=>x._4).map(x=>x._4)),x._2.map(x=>x._2).size)).map(x=>(x._1._1,x._1._2,x._1._3,x._2,x._3))

          saveRDD(MEASURE_NAME,ippRDD32_1,practicerdd32_1,locationRDD32_1,providerRDD32_1,providerLocationRDD32_1)
        }
        MEASURE_NAME="M33_1"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD33_1 = ippRDDgt18_1.filter(r =>CRA_list80k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd33_1 = ippRDD33_1.groupBy(x=>x._1).map(k=>(k._1,median(k._2.toList.sortBy(x=>x._4).map(x=>x._4)),k._2.size))
          //location
          val locationRDD33_1 = ippRDD33_1.map(x=>((x._1,x._3),x)).groupByKey().map(x=>(x._1,median(x._2.toList.sortBy(x=>x._4).map(x=>x._4)),x._2.map(x=>x._2).size)).map(x=>(x._1._1,x._1._2,x._2,x._3))
          //provider
          val providerRDD33_1 = ippRDD33_1.map(x=>((x._1,x._2),x)).groupByKey().map(x=>(x._1,median(x._2.toList.sortBy(x=>x._4).map(x=>x._4)),x._2.map(x=>x._2).size)).map(x=>(x._1._1,x._1._2,x._2,x._3))
          //provider + location
          val providerLocationRDD33_1 = ippRDD33_1.map(x=>((x._1,x._3,x._2),x)).groupByKey().map(x=>(x._1,median(x._2.toList.sortBy(x=>x._4).map(x=>x._4)),x._2.map(x=>x._2).size)).map(x=>(x._1._1,x._1._2,x._1._3,x._2,x._3))

          saveRDD(MEASURE_NAME,ippRDD33_1,practicerdd33_1,locationRDD33_1,providerRDD33_1,providerLocationRDD33_1)

          }
        MEASURE_NAME="M35_1"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD35_1 = ippRDDgt18_1.filter(r => CRA_list60k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd35_1 = ippRDD35_1.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD35_1 = ippRDD35_1.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD35_1 = ippRDD35_1.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD35_1 = ippRDD35_1.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD35_1, practicerdd35_1, locationRDD35_1, providerRDD35_1, providerLocationRDD35_1)
        }
          MEASURE_NAME="M36_1"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD36_1 = ippRDDgt18_1.filter(r => CRA_list40k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd36_1 = ippRDD36_1.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD36_1 = ippRDD36_1.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD36_1 = ippRDD36_1.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD36_1 = ippRDD36_1.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD36_1, practicerdd36_1, locationRDD36_1, providerRDD36_1, providerLocationRDD36_1)
        }
          MEASURE_NAME="M37_1"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD37_1 = ippRDDgt18_1.filter(r => CRA_list20k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd37_1 = ippRDD37_1.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD37_1 = ippRDD37_1.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD37_1 = ippRDD37_1.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD37_1 = ippRDD37_1.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD37_1, practicerdd37_1, locationRDD37_1, providerRDD37_1, providerLocationRDD37_1)
        }
        MEASURE_NAME="M38_1"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD38_1 = ippRDDgt18_1.filter(r => CRA_list19k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd38_1 = ippRDD38_1.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD38_1 = ippRDD38_1.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD38_1 = ippRDD38_1.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD38_1 = ippRDD38_1.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD38_1, practicerdd38_1, locationRDD38_1, providerRDD38_1, providerLocationRDD38_1)
        }
        MEASURE_NAME="M39_1"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD39_1 = ippRDDgt18_1.filter(r => CRA_listFree.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd39_1 = ippRDD39_1.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD39_1 = ippRDD39_1.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD39_1 = ippRDD39_1.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD39_1 = ippRDD39_1.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD39_1, practicerdd39_1, locationRDD39_1, providerRDD39_1, providerLocationRDD39_1)
        }

        MEASURE_NAME="M40_1" // age ls 18
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD40_1 = ippRDDls18_1.map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd40_1 = ippRDD40_1.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD40_1 = ippRDD40_1.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD40_1 = ippRDD40_1.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD40_1 = ippRDD40_1.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD40_1, practicerdd40_1, locationRDD40_1, providerRDD40_1, providerLocationRDD40_1)
        }

        MEASURE_NAME="M41_1"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD41_1 = ippRDDls18_1.filter(r => CRA_list80k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd41_1 = ippRDD41_1.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD41_1 = ippRDD41_1.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD41_1 = ippRDD41_1.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD41_1 = ippRDD41_1.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD41_1, practicerdd41_1, locationRDD41_1, providerRDD41_1, providerLocationRDD41_1)
        }
        MEASURE_NAME="M43_1"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD43_1 = ippRDDls18_1.filter(r => CRA_list60k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd43_1 = ippRDD43_1.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD43_1 = ippRDD43_1.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD43_1 = ippRDD43_1.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD43_1 = ippRDD43_1.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD43_1, practicerdd43_1, locationRDD43_1, providerRDD43_1, providerLocationRDD43_1)
        }

        MEASURE_NAME="M44_1"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD44_1 = ippRDDls18_1.filter(r => CRA_list40k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd44_1 = ippRDD44_1.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD44_1 = ippRDD44_1.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD44_1 = ippRDD44_1.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD44_1 = ippRDD44_1.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD44_1, practicerdd44_1, locationRDD44_1, providerRDD44_1, providerLocationRDD44_1)
        }

        MEASURE_NAME="M45_1"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD45_1 = ippRDDls18_1.filter(r => CRA_list20k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd45_1 = ippRDD45_1.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD45_1 = ippRDD45_1.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD45_1 = ippRDD45_1.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD45_1 = ippRDD45_1.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD45_1, practicerdd45_1, locationRDD45_1, providerRDD45_1, providerLocationRDD45_1)
        }

        MEASURE_NAME="M46_1"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD46_1 = ippRDDls18_1.filter(r => CRA_list19k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd46_1 = ippRDD46_1.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD46_1 = ippRDD46_1.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD46_1 = ippRDD46_1.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD46_1 = ippRDD46_1.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD46_1, practicerdd46_1, locationRDD46_1, providerRDD46_1, providerLocationRDD46_1)
        }

        MEASURE_NAME="M47_1"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD47_1 = ippRDDls18_1.filter(r => CRA_listFree.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))
          //practice
          val practicerdd47_1 = ippRDD47_1.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD47_1 = ippRDD47_1.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD47_1 = ippRDD47_1.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD47_1 = ippRDD47_1.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD47_1, practicerdd47_1, locationRDD47_1, providerRDD47_1, providerLocationRDD47_1)
        }


        //*************************************Median_2*****************************************************

        MEASURE_NAME="M32_2" // age gt 18
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD32_2 = ippRDDgt18_2.map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))
          //practice
          val practicerdd32_2 = ippRDD32_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD32_2 = ippRDD32_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD32_2 = ippRDD32_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD32_2 = ippRDD32_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD32_2, practicerdd32_2, locationRDD32_2, providerRDD32_2, providerLocationRDD32_2)
        }
        MEASURE_NAME="M33_2"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD33_2 = ippRDDgt18_2.filter(r =>CRA_list80k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd33_2 = ippRDD33_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD33_2 = ippRDD33_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD33_2 = ippRDD33_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD33_2 = ippRDD33_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD33_2, practicerdd33_2, locationRDD33_2, providerRDD33_2, providerLocationRDD33_2)
        }
        MEASURE_NAME="M35_2"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD35_2 = ippRDDgt18_2.filter(r => CRA_list60k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd35_2 = ippRDD35_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD35_2 = ippRDD35_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD35_2 = ippRDD35_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD35_2 = ippRDD35_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD35_2, practicerdd35_2, locationRDD35_2, providerRDD35_2, providerLocationRDD35_2)
        }
        MEASURE_NAME="M36_2"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD36_2 = ippRDDgt18_2.filter(r => CRA_list40k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd36_2 = ippRDD36_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD36_2 = ippRDD36_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD36_2 = ippRDD36_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD36_2 = ippRDD36_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD36_2, practicerdd36_2, locationRDD36_2, providerRDD36_2, providerLocationRDD36_2)
        }
        MEASURE_NAME="M37_2"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD37_2 = ippRDDgt18_2.filter(r => CRA_list20k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd37_2 = ippRDD37_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD37_2 = ippRDD37_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD37_2 = ippRDD37_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD37_2 = ippRDD37_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD37_2, practicerdd37_2, locationRDD37_2, providerRDD37_2, providerLocationRDD37_2)
        }
        MEASURE_NAME="M38_2"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD38_2 = ippRDDgt18_2.filter(r => CRA_list19k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd38_2 = ippRDD38_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD38_2 = ippRDD38_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD38_2 = ippRDD38_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD38_2 = ippRDD38_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD38_2, practicerdd38_2, locationRDD38_2, providerRDD38_2, providerLocationRDD38_2)

       }
        MEASURE_NAME="M39_2"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD39_2 = ippRDDgt18_2.filter(r => CRA_listFree.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd39_2 = ippRDD39_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD39_2 = ippRDD39_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD39_2 = ippRDD39_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD39_2 = ippRDD39_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD39_2, practicerdd39_2, locationRDD39_2, providerRDD39_2, providerLocationRDD39_2)

        }
        MEASURE_NAME="M40_2" // age gt 18
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD40_2 = ippRDDls18_2.map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))
          //practice
          val practicerdd40_2 = ippRDD40_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD40_2 = ippRDD40_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD40_2 = ippRDD40_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD40_2 = ippRDD40_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD40_2, practicerdd40_2, locationRDD40_2, providerRDD40_2, providerLocationRDD40_2)
        }
        MEASURE_NAME="M41_2"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD41_2 = ippRDDls18_2.filter(r => CRA_list80k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd41_2 = ippRDD41_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD41_2 = ippRDD41_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD41_2 = ippRDD41_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD41_2 = ippRDD41_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD41_2, practicerdd41_2, locationRDD41_2, providerRDD41_2, providerLocationRDD41_2)

        }
        MEASURE_NAME="M43_2"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD43_2 = ippRDDls18_2.filter(r => CRA_list60k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd43_2 = ippRDD43_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD43_2 = ippRDD43_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD43_2 = ippRDD43_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD43_2 = ippRDD43_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD43_2, practicerdd43_2, locationRDD43_2, providerRDD43_2, providerLocationRDD43_2)

        }
        MEASURE_NAME="M44_2"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD44_2 = ippRDDls18_2.filter(r => CRA_list40k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd44_2 = ippRDD44_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD44_2 = ippRDD44_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD44_2 = ippRDD44_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD44_2 = ippRDD44_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD44_2, practicerdd44_2, locationRDD44_2, providerRDD44_2, providerLocationRDD44_2)
        }
        MEASURE_NAME="M45_2"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD45_2 = ippRDDls18_2.filter(r => CRA_list20k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd45_2 = ippRDD45_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD45_2 = ippRDD45_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD45_2 = ippRDD45_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD45_2 = ippRDD45_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD45_2, practicerdd45_2, locationRDD45_2, providerRDD45_2, providerLocationRDD45_2)

        }
        MEASURE_NAME="M46_2"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD46_2 = ippRDDls18_2.filter(r => CRA_list19k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd46_2 = ippRDD46_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD46_2 = ippRDD46_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD46_2 = ippRDD46_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD46_2 = ippRDD46_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD46_2, practicerdd46_2, locationRDD46_2, providerRDD46_2, providerLocationRDD46_2)

        }
        MEASURE_NAME="M47_2"

        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD47_2 = ippRDDls18_2.filter(r => CRA_listFree.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd47_2 = ippRDD47_2.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD47_2 = ippRDD47_2.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD47_2 = ippRDD47_2.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD47_2 = ippRDD47_2.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD47_2, practicerdd47_2, locationRDD47_2, providerRDD47_2, providerLocationRDD47_2)


        }
        exclusionRDDGt18.unpersist(true)
        ippRDDgt18.unpersist(true)
        ippRDDgt18_1.unpersist(true)
        ippRDDgt18_2.unpersist(true)
        ippRDDls18_1.unpersist(true);
        ippRDDls18_2.unpersist(true)
        ippRDDGreater18.unpersist(true)
        ippRDDLess18.unpersist(true)
        ippRDD.unpersist(true)

      }
    }
    catch {
      case e: Exception => {
        postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "W0001", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
        println(e.printStackTrace())
        System.exit(-1)

      }
    }
  }
  /*def saveRDD(MEASURE_NAME:String,ippRDD:RDD[CassandraRow],locationRDD:RDD[(AnyRef,Double,Int)]): Unit ={
    println("ACEP " + MEASURE_NAME)
    if (DataMartCreator.debugMode == 1) {
      println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
      println("ACEP " + MEASURE_NAME + " *** locationRdd    ***" + locationRDD.count())
    }
    else {
      saveToWebDM_median(locationRDD, MEASURE_NAME)
      postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "", "", "Measure computation done successfully", "PASS")
    }
    ippRDD.unpersist(true);
    locationRDD.unpersist(true);
  }*/
}
