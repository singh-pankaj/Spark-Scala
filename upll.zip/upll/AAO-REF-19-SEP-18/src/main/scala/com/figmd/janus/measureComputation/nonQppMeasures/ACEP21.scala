package com.figmd.janus.measureComputation.nonQppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import org.apache.spark.rdd.RDD

object ACEP21 extends MeasureUtility with Measure {


  //var MEASURE_NAME = "M21"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,MEASURE_NAME)
    ippRDD.cache()
   //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,startDate,endDate,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getSubtractRDD(ippRDD,exclusionRDD)
    intermediateA.cache()
    // Filter Met
    val metRDD = getMet(intermediateA,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not meate
    val notMetRDD =  getSubtractRDD(intermediateA,metRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }
      // Filter IPP
      def getIpp(rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
        rdd
          .filter(r =>
            (

              isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)
                &&
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "edv")
                    ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem")
                  )

                &&

                (checkElementPresent(r, IPP, MEASURE_NAME, "nontrumtcchstpn")
                  &&
                  isDateEqual(r, IPP, MEASURE_NAME, "nontrumtcchstpn_date", "encounterdate")
                  )
                &&
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "dis_ed_hm")
                    &&
                    (isDateStartsAfterOrConcurrentWithStartOf(r, IPP, MEASURE_NAME, "dis_ed_hm_date", "ed_visit_arrival_date")
                      ||
                      isDateStartsAfterOrConcurrentWithStartOf(r, IPP, MEASURE_NAME, "dis_ed_hm_date", "crtclcrem_date")

                      )
                  )
              )
          )
      }


      def getExclusionRdd(ippRDD:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {

        ippRDD.filter(r =>
          (
            (
              (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "esld") &&
                isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "esld_date", "ed_visit_departure_date"))
                ||
                (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "coglpths")
                  &&
                  isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "coglpths_date", "ed_visit_departure_date")
                  )
                ||
                (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "thrmcytopn")
                  &&
                  isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "thrmcytopn_date", "ed_visit_departure_date")
                  )
                ||
                (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "anticoag") &&
                  isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "anticoag_date", "ed_visit_departure_date")
                  )
              )
              ||
              (

                checkElementValue(r, EXCLUSION, MEASURE_NAME, "sex", 2)

                  &&
                  checkElementPresent(r, EXCLUSION, MEASURE_NAME, "preg")
                  &&
                  isDateEqual(r, EXCLUSION, MEASURE_NAME, "preg_date", "encounterdate")
                )
              ||

              (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "pulgestnlhemrg")
                &&
                isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "pulgestnlhemrg_date", "ed_visit_departure_date")
                )
              ||
              (
                checkElementPresent(r, EXCLUSION, MEASURE_NAME, "arlfiblt") &&
                  isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "arlfiblt_date", "ed_visit_departure_date")
                )

              ||
              (
                checkElementPresent(r, EXCLUSION, MEASURE_NAME, "anticoag")
                  &&
                  (
                    isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "anticoag_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                      ||
                      isDateEqual(r, EXCLUSION, MEASURE_NAME, "anticoag_date", "crtclcrem_date")
                    )
                )
              ||
              (
                //checkElementPresent(r, EXCLUSION, MEASURE_NAME, "lftbeftrtmcom")
                (
                  checkElementPresent(r, EXCLUSION, MEASURE_NAME, "edv")
                    &&
                    chkDateRangeBetweenMinusSecondsFromQuarterEndDate(r, EXCLUSION, MEASURE_NAME, "edv_date", startDate, endDate, 1)
                    &&
                    checkElementPresent(r, EXCLUSION, MEASURE_NAME, "lftbeftrtmcom")
                  )
                  ||

                  (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "crtclcrem")
                    &&
                    chkDateRangeBetweenMinusSecondsFromQuarterEndDate(r, EXCLUSION, MEASURE_NAME, "crtclcrem_date", startDate, endDate, 1)
                    &&
                    checkElementPresent(r, EXCLUSION, MEASURE_NAME, "lftbeftrtmcom")
                    )
                )
              ||
              (
                checkElementPresent(r, EXCLUSION, MEASURE_NAME, "trau")
                  &&
                  (
                    isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "trau_date", "ed_visit_arrival_date", "ed_visit_arrival_date")
                      &&
                      isDateEqual(r, EXCLUSION, MEASURE_NAME, "trau_date", "crtclcrem_date")
                    )
                )
            ))
      }


      def getMet(intermediateA:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {

        intermediateA.filter(r => (
          (
            checkElementPresent(r, MET, MEASURE_NAME, "prtrmtme")
              &&
              (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "prtrmtme_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                ||
                isDateEqual(r, MET, MEASURE_NAME, "prtrmtme_date", "crtclcrem_date")
                )
            )
            ||
            (
              checkElementPresent(r, MET, MEASURE_NAME, "actparthrmplstntme")
                &&
                (
                  isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "actparthrmplstntme_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                    ||
                    isDateEqual(r, MET, MEASURE_NAME, "actparthrmplstntme_date", "crtclcrem_date")
                  )
              )
            ||
            (
              checkElementPresent(r, MET, MEASURE_NAME, "inr") &&
                (
                  isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "inr_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                    ||
                    isDateEqual(r, MET, MEASURE_NAME, "inr_date", "crtclcrem_date")
                  )
              )
          )
        )
      }



}