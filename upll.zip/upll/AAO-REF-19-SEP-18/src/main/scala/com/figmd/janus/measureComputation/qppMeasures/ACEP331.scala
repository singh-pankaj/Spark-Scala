package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.measureComputation.qppMeasures.ACEP331.{checknull, chkDaysDiffGreaterOrEqual}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP331 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD=sparkSession.sparkContext.emptyRDD[CassandraRow]
    //met
    val metRDD = getMet(ippRDD,startDate: Date, endDate: Date,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    val intermediate = getinterRDD(ippRDD,metRDD)
    val exceptionRDD =getexceptionRDD(intermediate,startDate: Date, endDate: Date,MEASURE_NAME)
    exceptionRDD.cache()
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediate,exceptionRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }

  // Filter IPP
  def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {

    rdd.filter(r =>
      (
        isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)
          &&
          (
            checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "hohese") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "nursfacvst") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "caseinlorefa")
            )
          &&
          (
            checkElementPresent(r, IPP, MEASURE_NAME, "acutsnts") &&
              isDateEqual(r, IPP, MEASURE_NAME, "acutsnts_date", "encounterdate")
            )
          &&
          (
            checknull(r, IPP, MEASURE_NAME, "eddeptvist_tm") ||
              checknull(r, IPP, MEASURE_NAME, "ov_thmdmod95") ||
              checknull(r, IPP, MEASURE_NAME, "hmhlthsrvc_tm") ||
              checknull(r, IPP, MEASURE_NAME, "nrsnfcltvst_tm") ||
              checknull(r, IPP, MEASURE_NAME, "csltrf_tm")
            ) &&
          (
            checknull(r, IPP, MEASURE_NAME, "telehealth")
            )

        )

    )
  }

            //met

  def getMet(ippRDD:RDD[CassandraRow],startDate: Date, endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    ippRDD.filter(r => (
      (
        checkElementPresent(r, MET, MEASURE_NAME, "antibtc") &&
          isMinutesDiffGreater(r, MET, MEASURE_NAME, "acutsnts_date", "antibtc_date", 0) &&
          isDaysDiffLessOrEqual(r, MET, MEASURE_NAME, "acutsnts_date", "antibtc_date", 10)
        )
        ||
        (
          checkElementPresent(r, MET, MEASURE_NAME, "antprsc") &&
            isDuringMeasurementPeriod(r, MET, MEASURE_NAME, "antprsc_date", startDate, endDate)
          )
      )
      &&
      (
        !(
          checkElementPresent(r, MET, MEASURE_NAME, "antibtc") &&
            isMinutesDiffGreater(r, MET, MEASURE_NAME, "acutsnts_date", "antibtc_date", 0) &&
            isDaysDiffLessOrEqual(r, MET, MEASURE_NAME, "acutsnts_date", "antibtc_date", 10)
          )
          &&
          !(
            (
              checkElementPresent(r, MET, MEASURE_NAME, "perorbtlabcs") &&
                isMinutesDiffGreater(r, MET, MEASURE_NAME, "acutsnts_date", "perorbtlabcs_date", 0) &&
                isDaysDiffLessOrEqual(r, MET, MEASURE_NAME, "acutsnts_date", "perorbtlabcs_date", 10)
              )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "vsinchge") &&
                  isMinutesDiffGreater(r, MET, MEASURE_NAME, "acutsnts_date", "vsinchge_date", 0) &&
                  isDaysDiffLessOrEqual(r, MET, MEASURE_NAME, "acutsnts_date", "vsinchge_date", 10)
                )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "brnabcs") &&
                  isMinutesDiffGreater(r, MET, MEASURE_NAME, "acutsnts_date", "brnabcs_date", 0) &&
                  isDaysDiffLessOrEqual(r, MET, MEASURE_NAME, "acutsnts_date", "brnabcs_date", 10)
                )

            )
        )

    )

  }


      //ExceptionSourceCode

  def getexceptionRDD(intermediateRDD:RDD[CassandraRow],startDate: Date, endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateRDD.filter(r =>

      (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "antbtc_medrsn") &&
        isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "antbtc_medrsn_date", startDate, endDate)
        )
        ||
        (
          (
            checkElementPresent(r, MET, MEASURE_NAME, "antibtc") &&
              isMinutesDiffGreater(r, MET, MEASURE_NAME, "acutsnts_date", "antibtc_date", 0) &&
              isDaysDiffLessOrEqual(r, MET, MEASURE_NAME, "acutsnts_date", "antibtc_date", 10)
            )
            &&
            (
              (
                checkElementPresent(r, EXCEPTION, MEASURE_NAME, "perorbtlabcs") &&
                  isMinutesDiffGreater(r, MET, MEASURE_NAME, "acutsnts_date", "perorbtlabcs_date", 0) &&
                  isDaysDiffLessOrEqual(r, MET, MEASURE_NAME, "acutsnts_date", "perorbtlabcs_date", 10)
                )
                ||
                (
                  checkElementPresent(r, EXCEPTION, MEASURE_NAME, "vsinchge") &&
                    isMinutesDiffGreater(r, MET, MEASURE_NAME, "acutsnts_date", "perorbtlabcs_date", 0) &&
                    isDaysDiffLessOrEqual(r, MET, MEASURE_NAME, "acutsnts_date", "perorbtlabcs_date", 10)
                  )
                ||
                (
                  checkElementPresent(r, EXCEPTION, MEASURE_NAME, "brnabcs") &&
                    isMinutesDiffGreater(r, MET, MEASURE_NAME, "acutsnts_date", "brnabcs_date", 0) &&
                    isDaysDiffLessOrEqual(r, MET, MEASURE_NAME, "acutsnts_date", "brnabcs_date", 10)
                  )
              )

          )
    )
  }

}
