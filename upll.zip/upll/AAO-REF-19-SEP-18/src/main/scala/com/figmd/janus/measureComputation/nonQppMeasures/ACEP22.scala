package com.figmd.janus.measureComputation.nonQppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD

import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.util._
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP22 extends MeasureUtility with Measure {

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {
     // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,startDate,endDate,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getinterRDD(ippRDD,exclusionRDD)
    intermediateA.cache()
    //Met Backtracking
    val CRA = getBackTrackingList(rdd, ippRDD, "ptestcliprobpulembol", "ptestcliprobpulembol_date","d_dimr","d_dimr_date");
    val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)
    //Filter Met
    val metRDD = getMet(intermediateA,CRA_list,MEASURE_NAME)
    metRDD.cache()
    //for Exception B required
    val intermediateB =  getinterRDD(intermediateA,metRDD)
    // Filter Exceptions
    val exceptionRDD = getException(intermediateB,MEASURE_NAME)
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediateB,exceptionRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }

      // Filter IPP
      def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
        rdd
          .filter(r =>
            (
              isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate)
                &&
                (

                  isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)

                    &&
                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "edv")
                        ||
                        checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem")
                      )

                    &&
                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "ctpulangioctpa")
                        &&
                        (isDuringEncounterEDvisit(r, IPP, MEASURE_NAME, "ctpulangioctpa_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                          ||
                          isDateEqual(r, IPP, MEASURE_NAME, "ctpulangioctpa_date", "crtclcrem_date")
                          )
                      )
                  )
              )
          )
      }


  def getExclusionRdd(ippRDD:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {

    ippRDD.filter(r =>
      (
        checkElementValue(r, EXCLUSION, MEASURE_NAME, "sex", 2)
          &&
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "preg")
              &&
              isDateEqual(r, EXCLUSION, MEASURE_NAME, "preg_date", "encounterdate")
            )
        )
    )
  }

  def getMet(intermediateA:RDD[CassandraRow],CRA_list:Broadcast[List[String]] ,MEASURE_NAME:String): RDD[CassandraRow] = {

    intermediateA.filter(r =>

        BackTracking(r, MET, MEASURE_NAME, CRA_list)

        ||
        BackTracking2(r, MET, MEASURE_NAME, CRA_list)


    )
  }

  def getException(intermediateB:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {

    intermediateB.filter(r => (

      (
        checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mere_1")
          &&
          isDateOverlapsLessOrEqual(r, EXCEPTION, MEASURE_NAME, "mere_1_date", "ed_visit_departure_date")
        )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "aortdisct")
            &&
            (
              isDuringEncounterEDvisit(r, EXCEPTION, MEASURE_NAME, "aortdisct_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                ||

                isDateEqual(r, EXCEPTION, MEASURE_NAME, "aortdisct_date", "crtclcrem_date")
              )

          )

      )
    )
  }


  def BackTracking(r: CassandraRow, conditionType: String, MEASURE_NAME: String, CRA: Broadcast[List[String]]): Boolean = {


    for (x <- CRA.value) {
      if (x != "") {
        val back_data = x.split("~")
        val patientid = back_data(0);
        val element = back_data(1);
        val element_date = dateUtility.dateTimeParse(back_data(2));

        if ( !r.isNullAt("ctpulangioctpa_date") && element == "1"
          &&

          (
          r.getDateTime("ctpulangioctpa_date").equals(element_date)
          ||
          r.getDateTime("ctpulangioctpa_date").minusHours(24).equals(element_date)
          ||
          (
          element_date.isBefore(r.getDateTime("ctpulangioctpa_date"))
            &&
          element_date.isAfter(r.getDateTime("ctpulangioctpa_date").minusHours(24))

          )

          )
          &&
          (
            checkElementPresent(r, MET, MEASURE_NAME, "pofi")
              ||
              checkElementPresent(r, MET, MEASURE_NAME, "eled_dmr")
            )

        )
        {
          return true;
        }
      }

    }

    return false

  }

  def BackTracking2(r: CassandraRow, conditionType: String, MEASURE_NAME: String, CRA: Broadcast[List[String]]): Boolean = {


    for (x <- CRA.value) {
      if (x != "") {
        val back_data = x.split("~")
        val patientid = back_data(0);
        val element = back_data(3);
        val element_date = dateUtility.dateTimeParse(back_data(4));

        if (!r.isNullAt("ctpulangioctpa_date") && element == "1"
          &&

          (
            r.getDateTime("ctpulangioctpa_date").equals(element_date)
            ||
            r.getDateTime("ctpulangioctpa_date").minusHours(24).equals(element_date)
            ||
            (
              r.getDateTime("ctpulangioctpa_date").isBefore(element_date)
                &&
              r.getDateTime("ctpulangioctpa_date").minusHours(24).isAfter(element_date)
              )
            )
          &&

          (
            checkElementPresent(r, MET, MEASURE_NAME, "moderate")
              ||
              checkElementPresent(r, MET, MEASURE_NAME, "high")
            )

        )
          {
          return true;
        }
      }

    }
    return false
  }


  def getBackTrackingList(rdd: CassandraTableScanRDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement_date1: String,backtrackelement2: String, backtrackelement_date2: String): List[String] = {

    val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).distinct().collect().toList

    val IPPFilterExclusionRDD = rdd.filter(x => (ipp_patient_list.contains(x.columnValues(2))))

    var CRA = IPPFilterExclusionRDD.map(x =>
      if (!x.isNullAt("patientuid")
        && !x.isNullAt(backtrackelement1) && (!x.isNullAt(backtrackelement_date1)) && !x.isNullAt(backtrackelement2) && !x.isNullAt(backtrackelement_date2)) {
        x.getString("patientuid") + "~" + x.getString(backtrackelement1) + "~" + x.getString(backtrackelement_date1) + "~" + x.getString(backtrackelement2) + "~" + x.getString(backtrackelement_date2)
      }
      else ""
    )
      .collect()
      .toList

    return CRA;
  }

}
