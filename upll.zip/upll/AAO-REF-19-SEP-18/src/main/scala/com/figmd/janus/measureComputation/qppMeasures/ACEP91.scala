package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP91 extends MeasureUtility with Measure {


  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD=sparkSession.sparkContext.emptyRDD[CassandraRow]
    //met
    val metRDD = getMet(ippRDD,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    val intermediate = getinterRDD(ippRDD,metRDD)
    val exceptionRDD =getexceptionRDD(intermediate,MEASURE_NAME)
    exceptionRDD.cache()
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediate,exceptionRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }

    // Filter IPP
    def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
      rdd
        .filter(r =>
          //isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&
          (

            isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 2)
              &&
              (
                checkElementPresent(r, IPP, MEASURE_NAME, "domrsthmvst") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "hohese") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "nufavi") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1")
                )
              &&
              (
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "aoen") &&
                    isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "aoen_date", startDate, endDate)
                  )
                  &&
                  (
                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "aoe_re") &&
                        isDateEqual(r, IPP, MEASURE_NAME, "aoe_re_date", "encounterdate")
                      )
                      ||
                      (
                        checkElementPresent(r, IPP, MEASURE_NAME, "aoe_le") &&
                          isDateEqual(r, IPP, MEASURE_NAME, "aoe_le_date", "encounterdate")
                        )
                    )
                ) &&
              (
                checkNullOrZero(r, IPP, MEASURE_NAME, "eddeptvist_tm") ||
                  checkNullOrZero(r, IPP, MEASURE_NAME, "domrsthmvst_tm") ||
                  checkNullOrZero(r, IPP, MEASURE_NAME, "ov_thmdmod95") ||
                  checkNullOrZero(r, IPP, MEASURE_NAME, "hmhlthsrvc_tm") ||
                  checkNullOrZero(r, IPP, MEASURE_NAME, "nrsnfcltvst_tm")
                )
              &&
              (
                  checkNullOrZero(r, IPP, MEASURE_NAME, "telehealth")
              )
            )
        )
    }
    //met
    def getMet(ippRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {

      ippRDD.filter(r =>
        (
          (
            checkElementPresent(r, MET, MEASURE_NAME, "topprepr") &&
              isElementDateStartAfterStartOfWithInDays(r, MET, MEASURE_NAME, "topprepr_date", "aoen_date", 30)
            )
            ||
            (
              checkElementPresent(r, MET, MEASURE_NAME, "topant") &&
                isElementDateStartAfterStartOfWithInDays(r, MET, MEASURE_NAME, "topant_date", "aoen_date", 30)
              )
            ||
            (
              isDateEqual(r, MET, MEASURE_NAME, "topprepr_date", "encounterdate") ||
                isDateEqual(r, MET, MEASURE_NAME, "topant_date", "encounterdate")
              )
          )
          ||
          (
            (
                checkElementPresent(r, MET, MEASURE_NAME, "topprep")
                  ||
                isDateEqual(r, MET, MEASURE_NAME, "topprep_date", "encounterdate")
              )

            ))
    }




    //ExceptionSourceCode
    def getexceptionRDD(intermediateRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
      intermediateRDD.filter(r => (
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "de_hns") ||
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "aotim") ||
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "tympmemperftn")
          )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "toppreptn_medrsn") &&
              isDateEqual(r, EXCEPTION, MEASURE_NAME, "toppreptn_medrsn_date", "encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "toppreptn_patrsn") &&
              isDateEqual(r, EXCEPTION, MEASURE_NAME, "toppreptn_patrsn_date", "encounterdate")
            )


        ))
    }





/*

    if (DataMartCreator.debugMode == 1) {
      println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
      println("ACEP " + MEASURE_NAME + " *** notEligibleRDD          ***" + notEligibleRDD.count())
      println("ACEP " + MEASURE_NAME + " *** exclusionRDD          ***" + exclusionRDD.count())
      println("ACEP " + MEASURE_NAME + " *** exceptionRDD ***" + exceptionRDD.count())
      println("ACEP " + MEASURE_NAME + " *** metRDD       ***" + metRDD.count())
      println("ACEP " + MEASURE_NAME + " *** notMetRDD    ***" + notMetRDD.count())
      println("*********************************************************")
    }

    else
    { saveToWebDM(notEligibleRDD,exclusionRDD,metRDD, exceptionRDD, notMetRDD, MEASURE_NAME) }

    ippRDD.unpersist(true);
    metRDD.unpersist(true);
    notMetRDD.unpersist(true);
    exceptionRDD.unpersist(true);
    notEligibleRDD.unpersist(true);
    exclusionRDD.unpersist(true);

  postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"","","Measure computation done successfully","PASS")
}

catch {
  case e: Exception => {
    println(e.printStackTrace())
    postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "W0001", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
    System.exit(-1)

  }
}
  }*/
}