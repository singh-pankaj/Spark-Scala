package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}
import org.apache.spark.rdd.RDD

import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession

object ACEP187 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD=sparkSession.sparkContext.emptyRDD[CassandraRow]
    //met
    val metRDD = getMet(ippRDD,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    val intermediate = getinterRDD(ippRDD,metRDD)
    intermediate.cache()
    val exceptionRDD =getexceptionRDD(intermediate,MEASURE_NAME)
    exceptionRDD.cache()
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediate,exceptionRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }
      // Filter IPP
      def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
        rdd.filter(r =>
          (
            isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18) &&

              (
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "ihopsobs") &&
                    isDateEqual(r, IPP, MEASURE_NAME, "ihopsobs_date", "encounterdate")

                  )
                  ||
                  (
                    checkElementPresent(r, IPP, MEASURE_NAME, "hoinviin") &&
                      isDateEqual(r, IPP, MEASURE_NAME, "hoinviin_date", "encounterdate")

                    )
                  ||
                  (
                    checkElementPresent(r, IPP, MEASURE_NAME, "suobca") &&
                      isDateEqual(r, IPP, MEASURE_NAME, "suobca_date", "encounterdate")

                    )
                  ||
                  (
                    checkElementPresent(r, IPP, MEASURE_NAME, "subhospcare") &&
                      isDateEqual(r, IPP, MEASURE_NAME, "subhospcare_date", "encounterdate")

                    )
                  ||
                  (
                    checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") &&
                      isDateEqual(r, IPP, MEASURE_NAME, "emdevi_1_date", "encounterdate")

                    )
                  ||
                  (
                    checkElementPresent(r, IPP, MEASURE_NAME, "critclcre") &&
                    isDateEqual(r, IPP, MEASURE_NAME, "critclcre_date", "encounterdate")
                  )
                )
              &&
              (
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "isst_1") &&
                    isDateEqual(r, IPP, MEASURE_NAME, "isst_1_date", "encounterdate")
                  )
                  ||
                  (
                    checkElementPresent(r, IPP, MEASURE_NAME, "acisst") &&
                      isDateEqual(r, IPP, MEASURE_NAME, "acisst_date", "encounterdate")
                    )

                )
              && (

              isDateStartsAfterOrConcurrentWithStartOfInMinutes(r, IPP, MEASURE_NAME, "encounterdate", "laknwe_date", 120)
              )
              &&
              (
                checknull(r, IPP, MEASURE_NAME, "ihopsobs_672") ||
                  checknull(r, IPP, MEASURE_NAME, "hospinpvini_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "subobscr_258") ||
                  checknull(r, IPP, MEASURE_NAME, "subhospcare_copy_505") ||
                  checknull(r, IPP, MEASURE_NAME, "eddeptvist_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "ccm_tm")
                ) &&
              (
                checknull(r, IPP, MEASURE_NAME, "pos02")
                )
            )
        )
      }


  def getMet(ippRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    ippRDD.filter(r =>
      (
        checkElementPresent(r, MET, MEASURE_NAME, "ivthth") &&
          isDateEqual(r, MET, MEASURE_NAME, "ivthth_date", "encounterdate")
        )
        ||
        (
          checkElementPresent(r, MET, MEASURE_NAME, "ivtpa") &&
            isDateStartsAfterOrConcurrentWithStartOfInMinutes(r, MET, MEASURE_NAME, "ivtpa_date", "laknwe_date", 180)
          )

    )
  }

  def getexceptionRDD(intermediateRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateRDD.filter(r =>

      (
        checkElementPresent(r, EXCEPTION, MEASURE_NAME, "thth") &&
          isDateEqual(r, EXCEPTION, MEASURE_NAME, "thth_date", "encounterdate")
        )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "elccrtdint") &&
            isDateStartsAfterOrConcurrentWithStartOfInMinutes(r, EXCEPTION, MEASURE_NAME, "elccrtdint_date", "laknwe_date", 120)
          )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "critclcre") &&
            isDateStartsAfterOrConcurrentWithStartOfInMinutes(r, EXCEPTION, MEASURE_NAME, "critclcre_date", "laknwe_date", 120)
          )
    )
  }

}