package com.figmd.janus.measureComputation.nonQppMeasures

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.DataMartCreator.prop

import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


object ACEPmedian_3_4 extends MeasureUtility with MeasureTrait {

  @transient lazy val postgresUtility = new PostgreUtility()
  final var MEASURE_NAME = "M32_3"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {
    var measure_list:List[String] = List()
    val mlist = prop.getProperty("median_measure_list")
    try {
      if (!mlist.isEmpty) {
        var median_measures = mlist.split(",");
        for (m <- median_measures) {
          measure_list =measure_list:+ m
          //println("measure_name:::::::::::::"+m)
        }

        println("measure_list:::::::::::::"+measure_list)
        var columnRef = getFiledList(MEASURE_NAME)
        val rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0), columnRef(1), columnRef(2), columnRef(3), columnRef(4), columnRef(5), columnRef(6), columnRef(7), columnRef(8), columnRef(9), columnRef(10), columnRef(11), columnRef(12), columnRef(13), columnRef(14), columnRef(15), columnRef(16), columnRef(17), columnRef(18), columnRef(19), columnRef(20), columnRef(21), columnRef(22), columnRef(23), columnRef(24), columnRef(25), columnRef(26))
          .where(s"encounterdate>=? and encounterdate<=? "+prop.getProperty("practiceListCondition"), startDate, endDate)
        val dateUtil = new DateUtility()
        val list80k = chkValueRangeGreaterOrEqualMedian1(sparkSession, "edannualvisitvolumn", 80000)
        val list60k = chkValueRangeGreaterOrLesserOrEqualMedian1(sparkSession, "edannualvisitvolumn", 60000, 79999)
        val list40k = chkValueRangeGreaterOrLesserOrEqualMedian1(sparkSession, "edannualvisitvolumn", 40000, 59999)
        val list20k = chkValueRangeGreaterOrLesserOrEqualMedian1(sparkSession, "edannualvisitvolumn", 20000, 39999)
        val list19k = chkValueRangeLessorEqualMedian1(sparkSession, "edannualvisitvolumn", 19999)
        val listFree = chkValueFreestanding_EDMedian1(sparkSession, "name", "Freestanding ED")

        val CRA_list80k: Broadcast[Set[String]] = sparkSession.sparkContext.broadcast(list80k)
        val CRA_list60k: Broadcast[Set[String]] = sparkSession.sparkContext.broadcast(list60k)
        val CRA_list40k: Broadcast[Set[String]] = sparkSession.sparkContext.broadcast(list40k)
        val CRA_list20k: Broadcast[Set[String]] = sparkSession.sparkContext.broadcast(list20k)
        val CRA_list19k: Broadcast[Set[String]] = sparkSession.sparkContext.broadcast(list19k)
        val CRA_listFree: Broadcast[Set[String]] = sparkSession.sparkContext.broadcast(listFree)

        // Filter IPP
        val ippRDD = rdd.filter(r =>
          (
            checkElementPresent(r, IPP, MEASURE_NAME, "edv")
              ||
              checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem")
            )
            &&
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "disch_emrgncydept")
                &&
                isDateEqual(r, IPP, MEASURE_NAME, "disch_emrgncydept_date", "ed_visit_departure_date")
                &&
                (
                  isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "ed_visit_arrival_date", "disch_emrgncydept_date")
                    ||
                    isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "crtclcrem_date", "disch_emrgncydept_date")
                  )
              )/*&&
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "acutcrhosptl")
                &&
                isDateStartsAfterOrConcurrentWithStartOf(r, IPP, MEASURE_NAME, "acutcrhosptl_date",  "ed_visit_departure_date")
              )*/

        )
        ippRDD.cache()

        // Common Age greater than 18
        val ippRDDGreater18 = ippRDD.filter(r =>
          isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "edv_date", 18) ||
            isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "crtclcrem_date", 18)
        )
        ippRDDGreater18.cache()


        // Common Age Less than 18
        val ippRDDLess18 = ippRDD.filter(r =>
          isAgeLess(r, IPP, MEASURE_NAME, "dob", "edv_date", 18) ||
            isAgeLess(r, IPP, MEASURE_NAME, "dob", "crtclcrem_date", 18)
        )
        ippRDDLess18.cache()


        //**********************************************Exclusion* Greater**************************************

        val exclusionRDDGt18 = ippRDDGreater18.filter(r =>
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "paex")
              &&
              (
                isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "paex_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, EXCLUSION, MEASURE_NAME, "paex_date", "crtclcrem_date")
                )
            )
        )
        exclusionRDDGt18.cache()
        val ippRDDgt18 = ippRDDGreater18.subtract(exclusionRDDGt18)

        ippRDDgt18.cache()



        //**********************************************Exclusion Less***************************************

        val exclusionRDDLs18 = ippRDDLess18.filter(r =>
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "paex")
              &&
              (
                isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "paex_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, EXCLUSION, MEASURE_NAME, "paex_date", "crtclcrem_date")
                )
            )
        )
        exclusionRDDLs18.cache()
        val ippRDDls18 = ippRDDLess18.subtract(exclusionRDDLs18)

        ippRDDls18.cache()

         //******************************************Ipp_3 filter*************************

        val ippRDDgt18_3 = ippRDDgt18.filter(r=>
          (
            checkElementPresent(r, IPP, MEASURE_NAME, "acutcrhosptl")
              &&
              isDateStartsAfterOrConcurrentWithStartOf(r, IPP, MEASURE_NAME, "acutcrhosptl_date",  "ed_visit_departure_date")
            )
        )
        ippRDDgt18_3.cache()

        val ippRDDls18_3 = ippRDDls18.filter(r=>

          (
            checkElementPresent(r, IPP, MEASURE_NAME, "acutcrhosptl")
              &&
              isDateStartsAfterOrConcurrentWithStartOf(r, IPP, MEASURE_NAME, "acutcrhosptl_date",  "ed_visit_departure_date")
            )

        )
        ippRDDls18_3.cache()

        //******************************************Ipp_4 filter*************************

        val ippRDDgt18_4 = ippRDDgt18

        ippRDDgt18_4.cache()

        val ippRDDls18_4 = ippRDDls18

        ippRDDls18_4.cache()



        //*************************************Median_3*****************************************************
        MEASURE_NAME="M32_3" // age gt 18
        if (measure_list.contains(MEASURE_NAME)) {
          //practiceuid,serviceprovideruid,locationid
          val ippRDD32_3 = ippRDDgt18_3.map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd32_3 = ippRDD32_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD32_3 = ippRDD32_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD32_3 = ippRDD32_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD32_3 = ippRDD32_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD32_3, practicerdd32_3, locationRDD32_3, providerRDD32_3, providerLocationRDD32_3)

        }
        MEASURE_NAME="M33_3"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD33_3 = ippRDDgt18_3.filter(r =>CRA_list80k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd33_3 = ippRDD33_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD33_3 = ippRDD33_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD33_3 = ippRDD33_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD33_3 = ippRDD33_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD33_3, practicerdd33_3, locationRDD33_3, providerRDD33_3, providerLocationRDD33_3)
        }
        MEASURE_NAME="M35_3"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD35_3 = ippRDDgt18_3.filter(r => CRA_list60k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd35_3 = ippRDD35_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD35_3 = ippRDD35_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD35_3 = ippRDD35_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD35_3 = ippRDD35_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD35_3, practicerdd35_3, locationRDD35_3, providerRDD35_3, providerLocationRDD35_3)
        }
        MEASURE_NAME="M36_3"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD36_3 = ippRDDgt18_3.filter(r => CRA_list40k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd36_3 = ippRDD36_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD36_3 = ippRDD36_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD36_3 = ippRDD36_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD36_3 = ippRDD36_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD36_3, practicerdd36_3, locationRDD36_3, providerRDD36_3, providerLocationRDD36_3)
        }
        MEASURE_NAME="M37_3"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD37_3 = ippRDDgt18_3.filter(r => CRA_list20k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd37_3 = ippRDD37_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD37_3 = ippRDD37_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD37_3 = ippRDD37_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD37_3 = ippRDD37_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD37_3, practicerdd37_3, locationRDD37_3, providerRDD37_3, providerLocationRDD37_3)

        }
        MEASURE_NAME="M38_3"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD38_3 = ippRDDgt18_3.filter(r => CRA_list19k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd38_3 = ippRDD38_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD38_3 = ippRDD38_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD38_3 = ippRDD38_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD38_3 = ippRDD38_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD38_3, practicerdd38_3, locationRDD38_3, providerRDD38_3, providerLocationRDD38_3)

        }
        MEASURE_NAME="M39_3"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD39_3 = ippRDDgt18_3.filter(r => CRA_listFree.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd39_3 = ippRDD39_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD39_3 = ippRDD39_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD39_3 = ippRDD39_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD39_3 = ippRDD39_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD39_3, practicerdd39_3, locationRDD39_3, providerRDD39_3, providerLocationRDD39_3)

        }
        MEASURE_NAME="M40_3" // age ls 18
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD40_3 = ippRDDls18_3.map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd40_3 = ippRDD40_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD40_3 = ippRDD40_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD40_3 = ippRDD40_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD40_3 = ippRDD40_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD40_3, practicerdd40_3, locationRDD40_3, providerRDD40_3, providerLocationRDD40_3)

        }
        MEASURE_NAME="M41_3"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD41_3 = ippRDDls18_3.filter(r => CRA_list80k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd41_3 = ippRDD41_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD41_3 = ippRDD41_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD41_3 = ippRDD41_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD41_3 = ippRDD41_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD41_3, practicerdd41_3, locationRDD41_3, providerRDD41_3, providerLocationRDD41_3)
        }
        MEASURE_NAME="M43_3"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD43_3 = ippRDDls18_3.filter(r => CRA_list60k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd43_3 = ippRDD43_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD43_3 = ippRDD43_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD43_3 = ippRDD43_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD43_3 = ippRDD43_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD43_3, practicerdd43_3, locationRDD43_3, providerRDD43_3, providerLocationRDD43_3)
        }
        MEASURE_NAME="M44_3"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD44_3 = ippRDDls18_3.filter(r => CRA_list40k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd44_3 = ippRDD44_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD44_3 = ippRDD44_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD44_3 = ippRDD44_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD44_3 = ippRDD44_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD44_3, practicerdd44_3, locationRDD44_3, providerRDD44_3, providerLocationRDD44_3)
        }
        MEASURE_NAME="M45_3"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD45_3 = ippRDDls18_3.filter(r => CRA_list20k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd45_3 = ippRDD45_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD45_3 = ippRDD45_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD45_3 = ippRDD45_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD45_3 = ippRDD45_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD45_3, practicerdd45_3, locationRDD45_3, providerRDD45_3, providerLocationRDD45_3)
        }
        MEASURE_NAME="M46_3"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD46_3 = ippRDDls18_3.filter(r => CRA_list19k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd46_3 = ippRDD46_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD46_3 = ippRDD46_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD46_3 = ippRDD46_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD46_3 = ippRDD46_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD46_3, practicerdd46_3, locationRDD46_3, providerRDD46_3, providerLocationRDD46_3)
        }
        MEASURE_NAME="M47_3"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD47_3 = ippRDDls18_3.filter(r => CRA_listFree.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd47_3 = ippRDD47_3.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD47_3 = ippRDD47_3.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD47_3 = ippRDD47_3.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD47_3 = ippRDD47_3.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD47_3, practicerdd47_3, locationRDD47_3, providerRDD47_3, providerLocationRDD47_3)

        }



        //*************************************Median_4*****************************************************
        MEASURE_NAME="M32_4" // age gt 18
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD32_4 = ippRDDgt18_4.map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd32_4 = ippRDD32_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD32_4 = ippRDD32_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD32_4 = ippRDD32_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD32_4 = ippRDD32_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD32_4, practicerdd32_4, locationRDD32_4, providerRDD32_4, providerLocationRDD32_4)

        }
        MEASURE_NAME="M33_4"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD33_4 = ippRDDgt18_4.filter(r =>CRA_list80k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd33_4 = ippRDD33_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD33_4 = ippRDD33_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD33_4 = ippRDD33_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD33_4 = ippRDD33_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD33_4, practicerdd33_4, locationRDD33_4, providerRDD33_4, providerLocationRDD33_4)

        }
        MEASURE_NAME="M35_4"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD35_4 = ippRDDgt18_4.filter(r => CRA_list60k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd35_4 = ippRDD35_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD35_4 = ippRDD35_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD35_4 = ippRDD35_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD35_4 = ippRDD35_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD35_4, practicerdd35_4, locationRDD35_4, providerRDD35_4, providerLocationRDD35_4)
        }
        MEASURE_NAME="M36_4"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD36_4 = ippRDDgt18_4.filter(r => CRA_list40k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd36_4 = ippRDD36_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD36_4 = ippRDD36_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD36_4 = ippRDD36_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD36_4 = ippRDD36_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD36_4, practicerdd36_4, locationRDD36_4, providerRDD36_4, providerLocationRDD36_4)
        }
        MEASURE_NAME="M37_4"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD37_4 = ippRDDgt18_4.filter(r => CRA_list20k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd37_4 = ippRDD37_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD37_4 = ippRDD37_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD37_4 = ippRDD37_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD37_4 = ippRDD37_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD37_4, practicerdd37_4, locationRDD37_4, providerRDD37_4, providerLocationRDD37_4)
        }
        MEASURE_NAME="M38_4"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD38_4 = ippRDDgt18_4.filter(r => CRA_list19k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd38_4 = ippRDD38_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD38_4 = ippRDD38_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD38_4 = ippRDD38_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD38_4 = ippRDD38_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD38_4, practicerdd38_4, locationRDD38_4, providerRDD38_4, providerLocationRDD38_4)
        }
        MEASURE_NAME="M39_4"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD39_4 = ippRDDgt18_4.filter(r => CRA_listFree.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd39_4 = ippRDD39_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD39_4 = ippRDD39_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD39_4 = ippRDD39_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD39_4 = ippRDD39_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD39_4, practicerdd39_4, locationRDD39_4, providerRDD39_4, providerLocationRDD39_4)
        }
        MEASURE_NAME="M40_4" // age ls 18
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD40_4 = ippRDDls18_4.map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd40_4 = ippRDD40_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD40_4 = ippRDD40_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD40_4 = ippRDD40_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD40_4 = ippRDD40_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD40_4, practicerdd40_4, locationRDD40_4, providerRDD40_4, providerLocationRDD40_4)
        }
        MEASURE_NAME="M41_4"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD41_4 = ippRDDls18_4.filter(r => CRA_list80k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd41_4 = ippRDD41_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD41_4 = ippRDD41_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD41_4 = ippRDD41_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD41_4 = ippRDD41_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD41_4, practicerdd41_4, locationRDD41_4, providerRDD41_4, providerLocationRDD41_4)
        }
        MEASURE_NAME="M43_4"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD43_4 = ippRDDls18_4.filter(r => CRA_list60k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd43_4 = ippRDD43_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD43_4 = ippRDD43_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD43_4 = ippRDD43_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD43_4 = ippRDD43_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD43_4, practicerdd43_4, locationRDD43_4, providerRDD43_4, providerLocationRDD43_4)
        }
        MEASURE_NAME="M44_4"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD44_4 = ippRDDls18_4.filter(r => CRA_list40k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd44_4 = ippRDD44_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD44_4 = ippRDD44_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD44_4 = ippRDD44_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD44_4 = ippRDD44_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD44_4, practicerdd44_4, locationRDD44_4, providerRDD44_4, providerLocationRDD44_4)
        }
        MEASURE_NAME="M45_4"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD45_4 = ippRDDls18_4.filter(r => CRA_list20k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd45_4 = ippRDD45_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD45_4 = ippRDD45_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD45_4 = ippRDD45_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD45_4 = ippRDD45_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD45_4, practicerdd45_4, locationRDD45_4, providerRDD45_4, providerLocationRDD45_4)
        }
        MEASURE_NAME="M46_4"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD46_4 = ippRDDls18_4.filter(r => CRA_list19k.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))
          //practice
          val practicerdd46_4 = ippRDD46_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD46_4 = ippRDD46_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD46_4 = ippRDD46_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD46_4 = ippRDD46_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD46_4, practicerdd46_4, locationRDD46_4, providerRDD46_4, providerLocationRDD46_4)
        }
        MEASURE_NAME="M47_4"
        if (measure_list.contains(MEASURE_NAME)) {
          val ippRDD47_4 = ippRDDls18_4.filter(r => CRA_listFree.value.contains(r.getString("servicelocationuid"))).map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getDateMinutesDiff(l)))

          //practice
          val practicerdd47_4 = ippRDD47_4.groupBy(x => x._1).map(k => (k._1, median(k._2.toList.sortBy(x => x._4).map(x => x._4)), k._2.size))
          //location
          val locationRDD47_4 = ippRDD47_4.map(x => ((x._1, x._3), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider
          val providerRDD47_4 = ippRDD47_4.map(x => ((x._1, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._2, x._3))
          //provider + location
          val providerLocationRDD47_4 = ippRDD47_4.map(x => ((x._1, x._3, x._2), x)).groupByKey().map(x => (x._1, median(x._2.toList.sortBy(x => x._4).map(x => x._4)), x._2.map(x => x._2).size)).map(x => (x._1._1, x._1._2, x._1._3, x._2, x._3))

          saveRDD(MEASURE_NAME, ippRDD47_4, practicerdd47_4, locationRDD47_4, providerRDD47_4, providerLocationRDD47_4)
        }

        exclusionRDDGt18.unpersist(true)
        ippRDDgt18.unpersist(true)
        ippRDDgt18_3.unpersist(true)
        ippRDDls18_3.unpersist(true)
        ippRDDgt18_4.unpersist(true)
        ippRDDls18_4.unpersist(true)
        ippRDDGreater18.unpersist(true)
        ippRDDLess18.unpersist(true)
        ippRDD.unpersist(true)

      }
    }
    catch {
      case e: Exception => {
        postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "W0001", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
        println(e.printStackTrace())
        System.exit(-1)

      }
    }
  }

}
