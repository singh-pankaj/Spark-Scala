package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}

import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP332 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD=sparkSession.sparkContext.emptyRDD[CassandraRow]
    //met
    val metRDD = getMet(ippRDD,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    val intermediate = getinterRDD(ippRDD,metRDD)
    val exceptionRDD =getexceptionRDD(intermediate,MEASURE_NAME)
    exceptionRDD.cache()
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediate,exceptionRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }

      // Filter IPP
      def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
        rdd
          .filter(r =>
            (
              isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)
                &&
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1") ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "nufavi") ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "caseinlorefa") ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "hohese")
                  )
                &&
                (
                  (

                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "actsnts_copy_867") &&
                        isDateEqual(r, IPP, MEASURE_NAME, "actsnts_copy_867_date", "encounterdate")
                      )
                      &&
                      (
                        checkElementPresent(r, IPP, MEASURE_NAME, "bactsinusitis") &&
                          isDateEqual(r, IPP, MEASURE_NAME, "bactsinusitis_date", "encounterdate")
                        )

                      &&
                      (
                        checkElementPresent(r, IPP, MEASURE_NAME, "antbtcrgmn1") &&
                          isDuringMeasurementPeriod(r, MET, MEASURE_NAME, "antbtcrgmn1_date", startDate, endDate)

                        )
                    )
                    ||
                    (
                      (
                        checkElementPresent(r, IPP, MEASURE_NAME, "actsnts_copy_867") &&
                          isDateEqual(r, IPP, MEASURE_NAME, "actsnts_copy_867_date", "encounterdate")
                        )
                        &&
                        (
                          checkElementPresent(r, IPP, MEASURE_NAME, "acubctsin") &&
                            isDateEqual(r, IPP, MEASURE_NAME, "acubctsin_date", "encounterdate")
                          )
                        && //
                        (
                          checkElementPresent(r, IPP, MEASURE_NAME, "abx_rxed1") &&
                            chkDateRangeBetweenMinusSecondsFromQuarterEndDate(r, IPP, MEASURE_NAME, "abx_rxed1_date", startDate, endDate, 1)
                          )

                      )
                  )
                &&
                (
                  checknull(r, IPP, MEASURE_NAME, "eddeptvist_tm") ||
                    checknull(r, IPP, MEASURE_NAME, "ov_thmdmod95") ||
                    checknull(r, IPP, MEASURE_NAME, "hmhlthsrvc_tm") ||
                    checknull(r, IPP, MEASURE_NAME, "nrsnfcltvst_tm") ||
                    checknull(r, IPP, MEASURE_NAME, "csltrf_tm")
                  )
                && (
                checknull(r, IPP, MEASURE_NAME, "telehealth")
                )


              )

          )

      }

      //met

  def getMet(ippRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    ippRDD.filter(r => (
      checkElementPresent(r, MET, MEASURE_NAME, "amoxwwo1") &&
        isDateEqual(r, MET, MEASURE_NAME, "amoxwwo1_date", "encounterdate")
        ||
        (
          checkElementPresent(r, MET, MEASURE_NAME, "amoclau20") &&
            isDateEqual(r, MET, MEASURE_NAME, "amoclau20_date", "encounterdate")
          )
      )
    )

  }

      //ExceptionSourceCode




  def getexceptionRDD(intermediateRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateRDD.filter(r => (
      (
        checkElementPresent(r, EXCEPTION, MEASURE_NAME, "amx4_mdrsn") &&
          isDateEqual(r, EXCEPTION, MEASURE_NAME, "amx4_mdrsn_date", "encounterdate")
        )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "amclv23") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "amclv23_date", "encounterdate")
          ) ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "chrsnsts") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "chrsnsts_date", "encounterdate")
          )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "cysfibrosis") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "cysfibrosis_date", "encounterdate")
          )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "immndefcncy") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "immndefcncy_date", "encounterdate")
          )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "clrydys") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "clrydys_date", "encounterdate")
          )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "dvnslsptm") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "dvnslsptm_date", "encounterdate")
          )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "recsnsts") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "recsnsts_date", "encounterdate")
          )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "prsnrsmicorg") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "prsnrsmicorg_date", "encounterdate")
          )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "immciliadis") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "immciliadis_date", "encounterdate")
          )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "snssurg") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "snssurg_date", "encounterdate")
          )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "alrgmed") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "alrgmed_date", "encounterdate")
          )
      ))
  }

}
