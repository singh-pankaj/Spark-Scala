package com.figmd.janus.measureComputation.cmsMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.util._
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.DataMartCreator.prop

object ACEP22cms extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    var columnRef = getFiledList(MEASURE_NAME)

    var patientHistoryRDD =  sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart_history"),
      prop.getProperty("patientHistory")).select(columnRef(3),columnRef(32),columnRef(33),columnRef(34),columnRef(35))

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


    val CRA = getBackTrackingList(rdd, ippRDD, "syblpr", "syblpr_date","diblpr","diblpr_date");

    var BackTrackingMost = rdd.map(l => ((l.isNullAt(3)),( (l.isNullAt(35) , l.isNullAt(36),l.isNullAt(68)))))
      .reduceByKey((x, y)=> ((if((x._1)>y._1) {x._1} else {y._1},if((x._2)>y._2) {x._2} else {y._2},if((x._3)>y._3){x._3} else {y._3})))

    val BackTrackingMostList: Broadcast[List[String]] =sparkSession.sparkContext.broadcast(CRA)


    /*val CRA = getBackTrackingList(rdd, ippRDD, "anmefoph", "anmefoph_date");
    val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)
*/
    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getinterRDD(ippRDD,exclusionRDD)
    intermediateA.cache()
    // Filter Met
    //met
    val metRDD = getMet(intermediateA,MEASURE_NAME,startDate: Date, endDate: Date,BackTrackingMostList: Broadcast[List[String]])
    metRDD.cache()

    // Filter Exceptions
    val IntermediateB = getinterRDD(intermediateA,metRDD)
    IntermediateB.cache()
    val exceptionRDD =getexceptionRDD(IntermediateB,MEASURE_NAME,startDate, endDate)
    exceptionRDD.cache()
    // Filter not meate
    val notMetRDD =  getinterRDD(IntermediateB,exceptionRDD)
    notMetRDD.cache()



    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }
      // Filter IPP
      def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
        rdd
          .filter(r =>
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&
              isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18) &&
              (
                checkElementPresent(r, IPP, MEASURE_NAME, "bpscenco") &&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "bpscenco_date", startDate, endDate)

                )
          )
      }
      /*
      val CRA = getBackTrackingList(rdd, ippRDD, "syblpr", "syblpr_date","diblpr","diblpr_date");

      var BackTrackingMost = rdd.map(l => ((l.isNullAt(3)),( (l.isNullAt(35) , l.isNullAt(36),l.isNullAt(68)))))
        .reduceByKey((x, y)=> ((if((x._1)>y._1) {x._1} else {y._1},if((x._2)>y._2) {x._2} else {y._2},if((x._3)>y._3){x._3} else {y._3})))

     val BackTrackingMostList: Broadcast[List[String]] =sparkSession.sparkContext.broadcast(CRA)*/



/* MostRecent element Rename  ****************** DO NOt REMOVED***********

      MostRecentBP_QPP=DiBlPr,
      MostRecentSP_QPP=SyBlPr,
      MostRecentSP_QPP_Date=syblpr_date,
      MostRecentBP_QPP_Date=diblpr_date
      LastYearMostRecentBP_QPP=DiBlPr,
      LastYearMostRecentSP_QPP=SyBlPr,
      LastYearMostRecentSP_QPP_Date=syblpr_date,
      LastYearMostRecentBP_QPP_Date=diblpr_date

      */

/* syblpr_date -- 35
diblpr_date ---36
bpscenco_date--68      */




//exclusion

  def getExclusionRdd(ippRDD: RDD[CassandraRow], MEASURE_NAME: String): RDD[CassandraRow] = {
    ippRDD.filter(r => checkElementPresent(r, EXCLUSION, MEASURE_NAME, "diofhy"))
  }






  def getMet(intermediateA:RDD[CassandraRow],MEASURE_NAME:String,startDate: Date, endDate: Date,BackTrackingMostList: Broadcast[List[String]]): RDD[CassandraRow] = {
    intermediateA.filter(r => //bpscenco_date
      (
        ((!r.isNullAt("syblpr") && isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "bpscenco_date", "syblpr_date"))
          && (!r.isNullAt("diblpr") && isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "bpscenco_date", "diblpr_date"))
          )
          &&
          (
            (
              (isDateEqual(r, MET, MEASURE_NAME, "syblpr_date", "bpscenco_date") &&
                chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr", 120))
                &&
                (isDateEqual(r, MET, MEASURE_NAME, "diblpr_date", "bpscenco_date") &&
                  chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr", 80))
              )
              ||
              (
                (
                  (
                    (chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "syblpr", 120) &&
                      chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr", 140)
                      ) &&
                      (
                        chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr", 90)
                        )
                    ) ||
                    (
                      (chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "diblpr", 80) &&
                        chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr", 90)
                        ) &&
                        (
                          chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr", 140)
                          )
                      )
                  ) &&
                  (
                    (// Most Recent NOt Required
                      checkElementPresent(r, MET, MEASURE_NAME, "retoalprprcapr") &&
                        checkElementPresent(r, MET, MEASURE_NAME, "fiofhy") &&
                        chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "retoalprprcapr_date", "bpscenco_date", 1)
                      )
                      ||
                      (
                        (
                          (
                            checkElementPresent(r, MET, MEASURE_NAME, "lire") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "lire_date", "bpscenco_date", 1)
                            ) ||
                            (checkElementPresent(r, MET, MEASURE_NAME, "werere") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "werere_date", "bpscenco_date", 1)
                              ) ||
                            (checkElementPresent(r, MET, MEASURE_NAME, "dire_1") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "dire_1_date", "bpscenco_date", 1)
                              ) ||
                            (checkElementPresent(r, MET, MEASURE_NAME, "phacre") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "phacre_date", "bpscenco_date", 1)
                              ) ||
                            (checkElementPresent(r, MET, MEASURE_NAME, "moofetcore") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "moofetcore_date", "bpscenco_date", 1)
                              )

                          ) &&
                          (
                            checkElementPresent(r, MET, MEASURE_NAME, "fowionye") &&
                              checkElementPresent(r, MET, MEASURE_NAME, "fiofhy") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "fowionye_date", "bpscenco_date", 1)
                            )
                        )
                    )) ||
              (
                (/*(!(chkYearRangeLessThanSecondsArg(r,IPP,MEASURE_NAME,"syblpr_date","bpscenco_date",1) &&
            chkYearRangeLessThanSecondsArg(r,IPP,MEASURE_NAME,"diblpr_date","bpscenco_date",1)))
            // most recent not Required
              ||
            ((chkYearRangeLessThanSecondsArg(r,IPP,MEASURE_NAME,"syblpr_date","bpscenco_date",1) &&
              (chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr_element",140)) )&&
               (chkYearRangeLessThanSecondsArg(r,IPP,MEASURE_NAME,"diblpr_date","bpscenco_date",1)&&
              chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr_element",90))
              )*/
                  //||
                  (BackTracking(r, EXCLUSION, MEASURE_NAME, BackTrackingMostList)
                    )

                  )
                  &&

                  ((isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "bpscenco_date", "syblpr_date") &&
                    chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "syblpr", 140))
                    ||
                    (isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "bpscenco_date", "diblpr_date") &&
                      chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "diblpr", 90))
                    ) &&
                  (
                    (
                      checkElementPresent(r, MET, MEASURE_NAME, "retoalprprcapr") &&
                        checkElementPresent(r, MET, MEASURE_NAME, "fiofhy") &&
                        chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "retoalprprcapr_date", "bpscenco_date", 1)
                      ) ||
                      (
                        (
                          (
                            checkElementPresent(r, MET, MEASURE_NAME, "lire") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "lire_date", "bpscenco_date", 1)
                            ) ||
                            (checkElementPresent(r, MET, MEASURE_NAME, "werere") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "werere_date", "bpscenco_date", 1)
                              ) ||
                            (checkElementPresent(r, MET, MEASURE_NAME, "dire_1") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "dire_1_date", "bpscenco_date", 1)
                              ) ||
                            (checkElementPresent(r, MET, MEASURE_NAME, "phacre") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "phacre_date", "bpscenco_date", 1)
                              ) ||
                            (checkElementPresent(r, MET, MEASURE_NAME, "moofetcore") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "moofetcore_date", "bpscenco_date", 1)
                              )

                          ) &&
                          (
                            checkElementPresent(r, MET, MEASURE_NAME, "fowi4we") &&
                              checkElementPresent(r, MET, MEASURE_NAME, "fiofhy") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "fowionye_date", "bpscenco_date", 1)
                            )
                        )
                    )
                ) ||
              (

                (
                  (isAgeLess(r, MET, MEASURE_NAME, "syblpr_date", "bpscenco_date", 1) &&
                    chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "syblpr", 140))
                    ||
                    (isAgeLess(r, MET, MEASURE_NAME, "diblpr_date", "bpscenco_date", 1) &&
                      chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "diblpr", 90))
                  ) &&
                  (
                    (isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "syblpr_date", "bpscenco_date") &&
                      chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "syblpr", 140))
                      ||
                      (isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "diblpr_date", "bpscenco_date") &&
                        chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "diblpr", 90))
                    ) &&
                  (
                    (
                      checkElementPresent(r, MET, MEASURE_NAME, "retoalprprcapr") &&
                        checkElementPresent(r, MET, MEASURE_NAME, "fiofhy") &&
                        chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "retoalprprcapr_date", "bpscenco_date", 1)
                      ) ||
                      (
                        (
                          (
                            checkElementPresent(r, MET, MEASURE_NAME, "lire") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "lire_date", "bpscenco_date", 1)
                            ) ||
                            (checkElementPresent(r, MET, MEASURE_NAME, "werere") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "werere_date", "bpscenco_date", 1)
                              ) ||
                            (checkElementPresent(r, MET, MEASURE_NAME, "dire_1") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "dire_1_date", "bpscenco_date", 1)
                              ) ||
                            (checkElementPresent(r, MET, MEASURE_NAME, "phacre") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "phacre_date", "bpscenco_date", 1)
                              ) ||
                            (checkElementPresent(r, MET, MEASURE_NAME, "moofetcore") &&
                              chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "moofetcore_date", "bpscenco_date", 1)
                              )
                          ) &&
                          (
                            (
                              checkElementPresent(r, MET, MEASURE_NAME, "anphth") &&
                                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "anphth_date", "bpscenco_date", 1)
                              ) ||
                              (
                                checkElementPresent(r, MET, MEASURE_NAME, "latefohy") &&
                                  chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "latefohy_date", "bpscenco_date", 1)
                                ) ||
                              (
                                checkElementPresent(r, MET, MEASURE_NAME, "ec12leorstor") &&
                                  chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "ec12leorstor_date", "bpscenco_date", 1)
                                )
                            )

                        )

                    )

                )


            )

        )


    )
  }




  def getexceptionRDD(IntermediateB:RDD[CassandraRow],MEASURE_NAME:String,startDate: Date, endDate: Date): RDD[CassandraRow] = {
    IntermediateB.filter(r =>
      (checkElementPresent(r, IPP, MEASURE_NAME, "meorotrenodo") &&
        isDateEqual(r, EXCEPTION, MEASURE_NAME, "meorotrenodo_date", "encounterdate"))
        || checkElementPresent(r, IPP, MEASURE_NAME, "parere_1") &&
        isDateStartsAfterOrConcurrentWithStartOf(r, IPP, MEASURE_NAME, "parere_1_date", "encounterdate") &&
        chkDateRangeLessOrEqualAndSecoundDatePlusDays(r, MET, MEASURE_NAME, "parere_1_date", "encounterdate", 1)

    )
  }




def BackTracking(r: CassandraRow, conditionType: String, MEASURE_NAME: String, BackTrackingMostList: Broadcast[List[String]]): Boolean = {
val flag = false;

for (x <- BackTrackingMostList.value) {
if (x != "") {
  //println(r.getString("visituid") + ">>>" + x)
  val back_data = x.split("~")
  val patientid = back_data(0);
  val syblpr_element = back_data(1);
  val diblpr_element = back_data(2);
  val syblpr_date =dateUtility.dateTimeParse(back_data(3));
  val diblpr_date =dateUtility.dateTimeParse(back_data(4));





  if ((!r.isNullAt("bpscenco_date") && !r.isNullAt("bpscenco"))
    && ((r.getString("patientuid").equals(patientid) || r.getString("patientuid") == patientid)
    &&(
    (
      !(

        (
          (
            r.getDateTime("bpscenco_date").minusYears(1).equals(syblpr_date)
              &&
              r.getDateTime("bpscenco_date").minusYears(1).equals((diblpr_date))
            )
            &&
            (
              chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr_element",140)
                &&
                chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr_element",90)
              )
          ) ||
          (
            (
              r.getDateTime("bpscenco_date").isBefore(syblpr_date)
                &&
                r.getDateTime("bpscenco_date").isBefore((diblpr_date))
              )
              &&
              (
                r.getDateTime("bpscenco_date").minusYears(1).isAfter(diblpr_date)
                  &&
                  r.getDateTime("bpscenco_date").minusYears(1).isAfter(syblpr_date)
                )
              &&
              (
                chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr_element",140)
                  &&
                  chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr_element",90)
                )

            )
      )
      )
      ||
      (
        ((r.getDateTime("bpscenco_date").minusYears(1).isBefore(syblpr_date) || r.getDateTime("bpscenco_date").minusYears(1).equals(syblpr_date)) && (chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr_element",140)))
          &&
          ((r.getDateTime("bpscenco_date").minusYears(1).isAfter(diblpr_date) || r.getDateTime("bpscenco_date").minusYears(1).equals(diblpr_date)) && (chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr_element",90)))
        )


    )
    )
  ) {
    //println("match")
    return true;
  }

}

}

return flag;

}

def getBackTrackingList(patientHistoryRDD: CassandraTableScanRDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement2: String, backtrackelement3: String, backtrackelement4: String): List[String] = {

val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).collect().toSet

val IPPFilterExclusionRDD = patientHistoryRDD.select("patientuid",backtrackelement1,backtrackelement2,backtrackelement3,backtrackelement4).filter(x => (ipp_patient_list.contains(x.columnValues(2))))

var CRA = IPPFilterExclusionRDD.map(x =>
if (!x.isNullAt("patientuid")
  && !x.isNullAt(backtrackelement1) && !x.isNullAt(backtrackelement2) && !x.isNullAt(backtrackelement3) && !x.isNullAt(backtrackelement4)) {
  x.getString("patientuid") + "~" + x.getString(backtrackelement1) + "~" + x.getString(backtrackelement2) + "~" + x.getString(backtrackelement3)+ "~" + x.getString(backtrackelement4)
}
else ""
)
.collect()
.toList

return CRA;
}
}

