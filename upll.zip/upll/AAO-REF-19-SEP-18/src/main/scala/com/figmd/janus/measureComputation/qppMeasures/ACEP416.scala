package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.Measure
import com.figmd.janus.util.MeasureUtility
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP416 extends MeasureUtility with Measure {

  /*var MEASURE_NAME= "M416"
  @transient lazy val postgresUtility=new PostgreUtility()*/
  // Logic for measure refresh
  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {



    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,startDate,endDate,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateRDDA =  getSubtractRDD(ippRDD,exclusionRDD)
    intermediateRDDA.cache()
    // Filter Met
    //met
    val metRDD = getMet(intermediateRDDA,startDate,endDate,MEASURE_NAME)
    metRDD.cache()
    val intermediateRDDB =  getSubtractRDD(intermediateRDDA,metRDD)
    intermediateRDDB.cache()

    // Filter Exceptions
    val exceptionRDD = getExceptionRDD(intermediateRDDB,MEASURE_NAME)
    // Filter not meate
    val notMetRDD =  getSubtractRDD(intermediateRDDB,exceptionRDD)
    notMetRDD.cache()


    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }

  // Filter IPP
  def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    rdd
      .filter(r =>
        //isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&
        (
          isAgeBetween(r, IPP, MEASURE_NAME, "dob", "edv_date", 2, 18) &&
            checkElementPresent(r, IPP, MEASURE_NAME, "edv")
            &&
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "paprwi24ho") &&
                isDateEqual(r, IPP, MEASURE_NAME, "paprwi24ho_date", "edv_date")
                ||
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "doumn_nphdtrm_wthn24hrs") &&
                    isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "doumn_nphdtrm_wthn24hrs_date", "edv_date") &&
                    checkElementPresent(r, IPP, MEASURE_NAME, "npneheadtrm") &&
                    isDateEqual(r, IPP, MEASURE_NAME, "npneheadtrm_date", "edv_date")
                  )
                  &&
                  (
                    checkElementValue(r, IPP, MEASURE_NAME, "gcs", 15) &&
                      isDateEqual(r, IPP, MEASURE_NAME, "gcs_date", "edv_date")
                    )
                  &&
                  (
                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "hdct") &&
                        isDateEqual(r, IPP, MEASURE_NAME, "hdct_date", "edv_date")
                      )
                      ||
                      (
                        checkElementPresent(r, IPP, MEASURE_NAME, "hdctprfrmd") &&
                          isDateEqual(r, IPP, MEASURE_NAME, "hdctprfrmd_date", "edv_date")
                        )

                    )

              )

          )
      )
  }

  // ippRDD.cache()

  def getExclusionRdd(ippRDD:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    ippRDD
      .filter(r =>
        (
          checkElementPresent(r, IPP, MEASURE_NAME, "brntumr") ||
            checkElementPresent(r, IPP, MEASURE_NAME, "coglpths") ||
            checkElementPresent(r, IPP, MEASURE_NAME, "thrmcytopn") ||
            //checkElementPresent(r, IPP, MEASURE_NAME, "vntrishtn") || // element not found
            checkElementPresent(r, IPP, MEASURE_NAME, "mudi")
          )
      )
  }
  //exclusionRDD.cache()

  def getMet(intermediateRDDA:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateRDDA
      .filter(r =>
        (
          !(
            (
              (
                checkElementPresent(r, MET, MEASURE_NAME, "loss_concusnes") &&
                  isDateEqual(r, MET, MEASURE_NAME, "loss_concusnes_date","edv_date")
                )
                &&
                (
                  checkElementPresent(r, MET, MEASURE_NAME,"phylsignbslesklfrctr") &&
                    isDateEqual(r, MET, MEASURE_NAME,"phylsignbslesklfrctr_date","edv_date")
                  )
                &&
                (
                  checkElementPresent(r, MET, MEASURE_NAME,"hdac") &&
                    isDateEqual(r, MET, MEASURE_NAME,"hdac_date","edv_date")
                  )
                &&
                (
                  checkElementPresent(r, MET, MEASURE_NAME,"signaltmenstats") &&
                    isDateEqual(r, MET, MEASURE_NAME,"signaltmenstats_date","edv_date")
                  )&&
                (
                  checkElementPresent(r, MET, MEASURE_NAME,"vomit") &&
                    isDateEqual(r, MET, MEASURE_NAME,"vomit_date","edv_date")
                  )
                &&
                (
                  checkElementPresent(r, MET, MEASURE_NAME,"dngmechinj_grp") &&
                    isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "dngmechinj_grp_date", startDate, endDate)
                  )
                &&
                (
                  checkElementPresent(r, MET, MEASURE_NAME,"seve") &&
                    isDateEqual(r, MET, MEASURE_NAME,"seve_date","edv_date")
                  )
              )
            )||
            (
              checkElementPresent(r, MET, MEASURE_NAME,"peprru") &&
                isDateEqual(r, MET, MEASURE_NAME,"peprru_date","edv_date")
              )
          )
      )
  }
  //metRDD.cache()

  def getExceptionRDD(intermediateRDDB:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateRDDB
      .filter(r =>(
        /*(
          checkElementPresent(r, IPP, MEASURE_NAME, "signsltmenstats") &&
            isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "signsltmenstats_date","edv_date")
          )*/
        //  &&
        (
          checkElementPresent(r, IPP, MEASURE_NAME,"vomit") &&
            isDateEqual(r, MET, MEASURE_NAME,"vomit_date","edv_date")
          )
          &&
          (
            checkElementPresent(r, IPP, MEASURE_NAME,"edv") &&
              checkElementPresent(r, IPP, MEASURE_NAME,"dngmechinj_grp") &&
              isDateEqual(r, MET, MEASURE_NAME,"dngmechinj_grp_date","edv_date")
            )
          ||
          (
            checkElementPresent(r, IPP, MEASURE_NAME,"peprru")&&
              isDateEqual(r, MET, MEASURE_NAME,"peprru_date","edv_date")
            )

        ))
  }
  //exceptionRDD.cache()
}