package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP254 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD=sparkSession.sparkContext.emptyRDD[CassandraRow]
    //met
    val metRDD = getMet(ippRDD,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    val intermediate = getinterRDD(ippRDD,metRDD)
    val exceptionRDD =getexceptionRDD(intermediate,MEASURE_NAME)
    exceptionRDD.cache()
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediate,exceptionRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }

      // Filter IPP
      def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
        rdd.filter(r =>
          (
            (
              checkElementValue(r, IPP, MEASURE_NAME, "sex", 2)
              )
              &&
              (
                isAgeBetween(r, IPP, MEASURE_NAME, "dob", "encounterdate", 14, 51)
                )
              &&
              (
                checkElementPresent(r, IPP, MEASURE_NAME, "condtnscomplctngprgnancy") &&
                  isDateEqual(r, IPP, MEASURE_NAME, "condtnscomplctngprgnancy_date", "encounterdate")
                )
              &&
              (
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") &&
                    isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "emdevi_1_date", startDate, endDate)
                  )
                  ||
                  (
                    checkElementPresent(r, IPP, MEASURE_NAME, "ccv") &&
                      isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ccv_date", startDate, endDate)
                    )
                    &&
                    (
                      (
                        checkElementPresent(r, IPP, MEASURE_NAME, "pos2") &&
                          isDateEqual(r, IPP, MEASURE_NAME, "pos2_date", "emdevi_1_date")
                        )
                        ||
                        (
                          checkElementPresent(r, IPP, MEASURE_NAME, "pos2") &&
                            isDateEqual(r, IPP, MEASURE_NAME, "pos2_date", "ccv_date")
                          )
                      )
                )
              &&
              (
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "vagbldg") &&
                    isDateEqual(r, IPP, MEASURE_NAME, "vagbldg_date", "encounterdate")
                  )
                  ||
                  (
                    checkElementPresent(r, IPP, MEASURE_NAME, "abd_pain") &&
                      isDateEqual(r, IPP, MEASURE_NAME, "abd_pain_date", "encounterdate")
                    )
                )
            )
        )
      }

      //met

  def getMet(ippRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    ippRDD.filter(r =>
      (
        checkElementPresent(r, MET, MEASURE_NAME, "ultrtransab") &&
          isDateEqual(r, MET, MEASURE_NAME, "ultrtransab_date", "encounterdate")
        )
        ||
        (
          checkElementPresent(r, MET, MEASURE_NAME, "tatv_prformd") &&
            isDateEqual(r, MET, MEASURE_NAME, "tatv_prformd_date", "encounterdate")
          )
        ||
        (
          checkElementPresent(r, MET, MEASURE_NAME, "trnsvgus") &&
            isDateEqual(r, MET, MEASURE_NAME, "trnsvgus_date", "encounterdate")
          )
    )
  }



      def getexceptionRDD(intermediateRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
        intermediateRDD.filter(r => (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "intrutnprg") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "intrutnprg_date", "encounterdate")
          )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "tatv_performd_medrsn") &&
              isDateEqual(r, EXCEPTION, MEASURE_NAME, "tatv_performd_medrsn_date", "encounterdate")

            )

          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "multvisit1") &&
              isElementStartsBeforeEndOfWithinHours(r, EXCEPTION, MEASURE_NAME, "multvisit1_date", "encounterdate", 72, 0)
            )

        )
      }

}