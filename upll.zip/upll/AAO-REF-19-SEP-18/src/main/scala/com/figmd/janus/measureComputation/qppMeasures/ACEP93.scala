package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}

import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP93 extends MeasureUtility with Measure {

 /* var MEASURE_NAME= "M93"
  @transient lazy val postgresUtility=new PostgreUtility()
*/
 def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

   // Filter IPP
   val ippRDD = getIpp(rdd,MEASURE_NAME)
   ippRDD.cache()
   //NotEligiable
   val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
   // Filter Exclusions
   val exclusionRDD=sparkSession.sparkContext.emptyRDD[CassandraRow]
   //met
   val metRDD = getMet(ippRDD,MEASURE_NAME)
   metRDD.cache()
   // Filter Exceptions
   val intermediate = getinterRDD(ippRDD,metRDD)
   val exceptionRDD =getexceptionRDD(intermediate,MEASURE_NAME)
   exceptionRDD.cache()
   // Filter not meate
   val notMetRDD =  getinterRDD(intermediate,exceptionRDD)
   notMetRDD.cache()

   saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
 }


  // Filter IPP
    def getIpp(rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
      rdd
        .filter(r =>
          //        isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&
          (
            isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 2)
              &&
              (
                checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "nufavi") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "hohese") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "domrsthmvst")
                )
              &&
              (
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "aoen") &&
                    isDateEqual(r, IPP, MEASURE_NAME, "aoen_date", "encounterdate")
                  )
                  &&
                  (
                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "aoe_re") &&
                        isDateEqual(r, IPP, MEASURE_NAME, "aoe_re_date", "encounterdate")

                      )
                      ||
                      (
                        checkElementPresent(r, IPP, MEASURE_NAME, "aoe_le") &&
                          isDateEqual(r, MET, MEASURE_NAME, "aoe_le_date", "encounterdate")

                        )
                    )
                ) &&

              (
                checknull(r, IPP, MEASURE_NAME, "eddeptvist_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "domrsthmvst_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "ov_thmdmod95") ||
                  checknull(r, IPP, MEASURE_NAME, "hmhlthsrvc_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "nrsnfcltvst_tm")
                ) &&
              (checknull(r, IPP, MEASURE_NAME, "telehealth"))
            )
        )
    }
    //met
    def getMet(ippRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    ippRDD.filter(r =>
      (
        (
          checkElementPresent(r, MET, MEASURE_NAME, "antimcthrp_met")&&
           isDateEqual(r, MET, MEASURE_NAME,"antimcthrp_met_date","encounterdate")

        )
          ||
          !(
              checkElementPresent(r, MET, MEASURE_NAME, "antimcthrp_medc")&&
              isElementDateStartAfterStartOfWithInDays(r, MET, MEASURE_NAME,"antimcthrp_medc_date","aoen_date",30)
            )

        )

      )}

     //ExceptionSourceCode
     def getexceptionRDD(intermediateRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
     intermediateRDD.filter(r => (
         (
           (
             checkElementPresent(r, EXCEPTION, MEASURE_NAME, "antimcrblthrpy_medrsn") &&
               isDateEqual(r, EXCEPTION, MEASURE_NAME, "antimcrblthrpy_medrsn_date", "encounterdate")
             )
             ||
             checkElementPresent(r, EXCEPTION, MEASURE_NAME, "immndefcncy") ||
             checkElementPresent(r, EXCEPTION, MEASURE_NAME, "coexdiab") ||
             checkElementPresent(r, EXCEPTION, MEASURE_NAME, "denexc_hns")
           )
         ))
     }

  }