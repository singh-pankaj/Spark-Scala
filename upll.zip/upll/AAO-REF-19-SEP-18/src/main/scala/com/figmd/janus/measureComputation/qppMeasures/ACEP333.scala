package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}

import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP333 extends MeasureUtility with Measure{

  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD=sparkSession.sparkContext.emptyRDD[CassandraRow]
    //met
    val metRDD = getMet(ippRDD,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    val intermediate = getinterRDD(ippRDD,metRDD)
    val exceptionRDD =getexceptionRDD(intermediate,MEASURE_NAME)
    exceptionRDD.cache()
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediate,exceptionRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }
    // Filter IPP
    def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
      rdd
        .filter(r =>

          // isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&

          (

            isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18) &&
              checkElementPresent(r, MET, MEASURE_NAME, "actsints") &&
              isElementStartsBeforeEndOfWithinDays(r, MET, MEASURE_NAME, "actsints_date", startDate, endDate, 28)
              &&
              (
                checkElementPresent(r, MET, MEASURE_NAME, "ofvi_1") ||
                  checkElementPresent(r, MET, MEASURE_NAME, "emdevi_1") ||
                  checkElementPresent(r, MET, MEASURE_NAME, "nufavi") ||
                  checkElementPresent(r, MET, MEASURE_NAME, "caseinlorefa") ||
                  checkElementPresent(r, MET, MEASURE_NAME, "hohese")
                )
              &&
              (
                checkNullOrZero(r, IPP, MEASURE_NAME, "encounter_tm") &&
                  checkNullOrZero(r, IPP, MEASURE_NAME, "telehealth")
                )

            )

        )
    }


    //met

  def getMet(ippRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    ippRDD.filter(r => (

      checkElementPresent(r, MET, MEASURE_NAME, "ctscnprnslsinsus") &&
        isElementDateStartAfterStartOfWithInDays(r, MET, MEASURE_NAME, "ctscnprnslsinsus_date", "actsints_date", 28)
        ||
        (
          checkElementPresent(r, MET, MEASURE_NAME, "ctparnsn") &&
            isDateEqual(r, MET, MEASURE_NAME, "ctparnsn_date", "encounterdate")
          )
      ))

  }


    //ExceptionSourceCode



  def getexceptionRDD(intermediateRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateRDD.filter(r => (
      (
        checkElementPresent(r, MET, MEASURE_NAME, "ctprn_medrsn") &&
          isDateEqual(r, EXCEPTION, MEASURE_NAME, "ctprn_medrsn_date", "encounterdate")
        )
        ||
        (
          checkElementPresent(r, MET, MEASURE_NAME, "acsphndsnsts") &&
            checkElementPresent(r, MET, MEASURE_NAME, "acfrntlsnsts") &&
            checkElementPresent(r, MET, MEASURE_NAME, "reccsnsts") &&
            checkElementPresent(r, MET, MEASURE_NAME, "anbtcrestnc") &&
            checkElementPresent(r, MET, MEASURE_NAME, "cmpimnty") &&
            checkElementPresent(r, MET, MEASURE_NAME, "perabs")
          //checkElementPresent(r, MET, MEASURE_NAME, "snustssymptm")
          )

      ))
  }


}