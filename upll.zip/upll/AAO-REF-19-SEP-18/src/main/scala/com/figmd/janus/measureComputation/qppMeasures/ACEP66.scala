package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.util._
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession

import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.DataMartCreator.prop


object ACEP66 extends MeasureUtility with Measure {


  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    var columnRef = getFiledList(MEASURE_NAME)
    var patientHistoryRDD =  sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart_history"),
     prop.getProperty("patientHistory")).select(columnRef(3),columnRef(25),columnRef(26))

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    val CRA = getBackTrackingList(rdd, ippRDD, "anmefoph", "anmefoph_date");
    val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)

    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,startDate:Date,endDate:Date,MEASURE_NAME,CRA_list: Broadcast[List[String]])
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getinterRDD(ippRDD,exclusionRDD)
    intermediateA.cache()
    // Filter Met
    //met
    val metRDD = getMet(intermediateA,MEASURE_NAME)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediateA,metRDD)
    notMetRDD.cache()


    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }
  def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    rdd
      .filter(r =>
        isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&
          (
            (
              isAgeBetween(r, IPP, MEASURE_NAME, "dob", "encounterdate", 3, 19) &&
                checkElementPresent(r, IPP, MEASURE_NAME, "amvi_copy_951")
                &&
                (
                  (
                    checkElementPresent(r, IPP, MEASURE_NAME, "acph") &&
                      isDateEqual(r, IPP, MEASURE_NAME, "acph_date", "encounterdate")
                    )
                    ||
                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "acto")
                        && isDateEqual(r, IPP, MEASURE_NAME, "acto_date", "encounterdate")
                      )
                  )
              )
              &&
              (
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "anmefoph") &&
                    (
                      isDateStartsBeforeOrConcurrentWithStartOf(r, IPP, MEASURE_NAME, "amvi_copy_951_date", "anmefoph_date", 3)
                      )
                    ||
                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "atbt") &&
                        isElementDateStartAfterStartOfWithInDays(r, IPP, MEASURE_NAME, "atbt_date", "amvi_copy_951_date", 3)
                      )
                  )

                )
            )
      )
  }


   /*   val CRA = getBackTrackingList(rdd, ippRDD, "anmefoph", "anmefoph_date");

      val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)*/


      //exclusion

  def getExclusionRdd(ippRDD:RDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String,CRA_list: Broadcast[List[String]]): RDD[CassandraRow] = {
    ippRDD.filter(r =>
      (
        checkElementPresent(r, EXCLUSION, MEASURE_NAME, "enin_1")
          &&
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohofohoca") ||
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohecafafohoca")
            )
        )
        || (
        checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hocaam")
        )
        ||
        (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hspsv") &&
          isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hspsv_date", startDate, endDate)

          ) ||
        (
          (
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "anmefoph") &&
                isDateBetweenStartBeforeStartAndEndBeforeStart(r, EXCLUSION, MEASURE_NAME, "anmefoph_date", "acph_date", 30, 1)
              )
              ||
              (
                isDateBetweenStartBeforeStartAndEndBeforeStart(r, EXCLUSION, MEASURE_NAME, "anmefoph_date", "acto_date", 30, 1)
                )
            )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "antpharyn") &&
                isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "antpharyn_date", startDate, endDate)
              ) ||
            (
              BackTracking(r, EXCLUSION, MEASURE_NAME, CRA_list)
              )
          )
    )
  }


  def getMet(intermediateA:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateA.filter(r =>
      (
        (
          checkElementPresent(r, MET, MEASURE_NAME, "grastte") &&
            isDateBetweenStartBeforeEndAndStartAfterEnd(r, MET, MEASURE_NAME, "amvi_copy_951_date", "grastte_date", 3, 3)
          )
          ||
          (

            checkElementPresent(r, MET, MEASURE_NAME, "grpastp") &&
              isDateBetweenStartBeforeEndAndStartAfterEnd(r, MET, MEASURE_NAME, "grpastp_date", "acph_date", 3, 3)
            )
          ||
          (
            checkElementPresent(r, MET, MEASURE_NAME, "grpastp") &&
              isDateBetweenStartBeforeEndAndStartAfterEnd(r, MET, MEASURE_NAME, "grpastp_date", "acto_date", 3, 3)
            )

        )
    )
  }


  def BackTracking(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {
    val flag = false;

    for (x <- CRA.value) {
      if (x != "") {
        //println(r.getString("visituid") + ">>>" + x) // Backtracking element
        val back_data = x.split("~")
        val patientid = back_data(0);
        val anmefoph_element = back_data(1);
        val anmefoph_date = dateUtility.dateTimeParse(back_data(2));


        if ((!r.isNullAt("acph_date") && !r.isNullAt("acto_date"))
          && ((r.getString("patientuid").equals(patientid) || r.getString("patientuid") == patientid)
          &&(
          (anmefoph_element == "1"
          &&
              (r.getDateTime("acph_date").minusDays(30).equals(anmefoph_date)) ||
               r.getDateTime("acph_date").minusDays(1).equals((anmefoph_date)) ||
              (r.getDateTime("acph_date").minusDays(30).isAfter(anmefoph_date)
                && r.getDateTime("acph_date").minusDays(1).isBefore(anmefoph_date))
            )
            )
            ||
              (
                (r.getDateTime("acto_date").minusDays(30).equals(anmefoph_date))||
                (r.getDateTime("acto_date").minusDays(1).equals(anmefoph_date)) ||
                (r.getDateTime("acto_date").minusDays(30).isBefore(anmefoph_date) &&
                   r.getDateTime("acto_date").minusDays(1).isAfter(anmefoph_date))
                )

          )
          //)
        ) {

          return true;
        }

      }

    }

    return flag;

  }

  def getBackTrackingList(patientHistoryRDD: CassandraTableScanRDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement2: String): List[String] = {

    val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).collect().toSet


    val IPPFilterExclusionRDD = patientHistoryRDD.select("patientuid",backtrackelement1,backtrackelement2).filter(x => (ipp_patient_list.contains(x.columnValues(3))))

    var CRA = IPPFilterExclusionRDD.map(x =>
      if (!x.isNullAt("patientuid")
        && !x.isNullAt(backtrackelement1) && !x.isNullAt(backtrackelement2)) {
        x.getString("patientuid") + "~" + x.getString(backtrackelement1) + "~" + x.getString(backtrackelement2)
      }
      else ""
    )
      .collect()
      .toList

    return CRA;
  }
}
