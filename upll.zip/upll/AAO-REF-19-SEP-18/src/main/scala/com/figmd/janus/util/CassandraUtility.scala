package com.figmd.janus.util



import java.text.SimpleDateFormat
import java.time.{LocalDate, LocalDateTime}
import java.time.format.DateTimeFormatter
import java.util.{Date, UUID}

import com.datastax.spark.connector._
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator
import com.figmd.janus.DataMartCreator.prop
import com.google.common.base.Throwables
import org.apache.log4j.{Level, LogManager}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable.ListBuffer


class CassandraUtility extends Serializable {



  @transient lazy val fileUtility = new FileUtility();
  //var keyspace = fileUtility.getProperty("cassandra.keyspace.name");
  //var CASHOSTNAME = fileUtility.getProperty("cassandra.host.name");
  var location = fileUtility.getProperty("cassandra.wdm.table.name.location");
  var practice = fileUtility.getProperty("cassandra.wdm.table.name.practice");
  var provider = fileUtility.getProperty("cassandra.wdm.table.name.provider");

  var table_location_monthly = fileUtility.getProperty("cassandra.wdm.table.name.location.monthly")
  var table_practice_monthly = fileUtility.getProperty("cassandra.wdm.table.name.practice.monthly")
  var table_provider_monthly = fileUtility.getProperty("cassandra.wdm.table.name.provider.monthly")

  var table_practice_rolling_monthly = fileUtility.getProperty("cassandra.wdm.table.name.practice.rolling.monthly")
  var table_location_rolling_monthly = fileUtility.getProperty("cassandra.wdm.table.name.location.rolling.monthly")
  var table_provider_rolling_monthly = fileUtility.getProperty("cassandra.wdm.table.name.provider.rolling.monthly")

  var table_location_quarterly = fileUtility.getProperty("cassandra.wdm.table.name.location.quarterly")
  var table_practice_quarterly = fileUtility.getProperty("cassandra.wdm.table.name.practice.quarterly")
  var table_provider_quarterly = fileUtility.getProperty("cassandra.wdm.table.name.provider.quarterly")

  var table_location_rolling_quarterly = fileUtility.getProperty("cassandra.wdm.table.name.location.rolling.quarterly")
  var table_practice_rolling_quarterly = fileUtility.getProperty("cassandra.wdm.table.name.practice.rolling.quarterly")
  var table_provider_rolling_quarterly = fileUtility.getProperty("cassandra.wdm.table.name.provider.rolling.quarterly")

  var table_practice_quarterly_qcnr = fileUtility.getProperty("cassandra.wdm.table.name.practice.quarterly.qcnr")
  var table_provider_quarterly_qcnr = fileUtility.getProperty("cassandra.wdm.table.name.provider.quarterly.qcnr")
  var table_location_quarterly_qcnr = fileUtility.getProperty("cassandra.wdm.table.name.location.quarterly.qcnr")

  var table_location_median=fileUtility.getProperty("cassandra.wdm.table.name.location.median")
  var table_practice_median=fileUtility.getProperty("cassandra.wdm.table.name.practice.median")
  var table_provider_median=fileUtility.getProperty("cassandra.wdm.table.name.provider.median")
  var table_provider_location_median=fileUtility.getProperty("cassandra.wdm.table.name.provider.location.median")

  var webdatamart_keyspace = prop.getProperty("keyspace_webdatamart")
  var sub_practice_mapping = fileUtility.getProperty("cassandra.wdm.mapping.table.name.practice")
  var tin_practice_mapping = fileUtility.getProperty("cassandra.wdm.mapping.table.name.practice.tin")

  val SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd")
  @transient lazy val postgresUtility=new PostgreUtility()


  var wfType=prop.get("wfType")

  def deleteFromWebdatamartMedian(spark:SparkSession, measure_list:String,date_str:String): Unit =
  {
    try{

      var SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd")
      println("CASSANDRA DELETION MEASURE LIST:::"+measure_list)
      println("CASSANDRA DELETION MONTH END DATE LIST:::"+date_str)
      var measures = measure_list.split(",");
      var mlist = new ListBuffer[String]()
      var quarterEndDate = new ListBuffer[String]()
      for (measure <- measures) {mlist += measure    }

      var date_range_arr = date_str.trim.substring(1, date_str.length - 1).split(",")
      for (date_range1 <- date_range_arr) {
        var date_arr1 = date_range1.split("~")
        quarterEndDate+=date_arr1(1).trim
      }
      var quarterStartDate=DataMartCreator.prop.getProperty("quarterStartDate")
      DataMartCreator.prop.setProperty("quarterStartDate","")
      DataMartCreator.prop.setProperty("quarterEndDate","")
      println("quarterStartDate::"+quarterStartDate+":::::::::::::::quarterEndDate::"+quarterEndDate)
      if (wfType.equals("MR") || wfType.equals("MNR")||wfType.equals("QNR")||wfType.equals("QR")||wfType.equals("QR")||wfType.equals("QCNR")) {
        delFromMedianTables(spark,quarterEndDate,mlist,measure_list)
      }

    }
    catch {
      case e: Exception => {
        println(e.printStackTrace())
        postgresUtility.insertIntoProcessDetails(measure_list, "W0001", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
        System.exit(-1)
      }
    }
  }

  def delFromMedianTables(spark:SparkSession,quarterEndDate:ListBuffer[String],mlist:ListBuffer[String],measure_list:String): Unit =
  {
    var quarterEndDateList :String=""
    for(d<-quarterEndDate)
      if (quarterEndDateList.isEmpty()){ quarterEndDateList=""+d }else{ quarterEndDateList=quarterEndDateList+","+d}

    if(!prop.getProperty("practice_id_list").equalsIgnoreCase("NA") && !prop.getProperty("practice_id_list").equals("")) {
      var practiceUIdList = prop.getProperty("practice_id_list").split(",")
      var practicelist = new ListBuffer[String]()
      for (practiceUId <- practiceUIdList) {
        //practicelist += UUID.fromString(practiceUId.toString)
        practicelist += practiceUId.toString
      }

      val rdd1 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_location_median")
      rdd1.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && r.getString("flag") == wfType && practicelist.contains(r.getString("practice_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_location_median")
      postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_location_median for month end dates ( $quarterEndDateList ) for practices "+prop.getProperty("practice_id_list"), "PASS")

      val rdd2 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_practice_median")
      rdd2.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && r.getString("flag") == wfType && practicelist.contains(r.getString("practice_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_practice_median")
      postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_practice_median for month end dates ( $quarterEndDateList ) for practices "+prop.getProperty("practice_id_list"), "PASS")

      val rdd3 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_provider_median")
      rdd3.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && r.getString("flag") == wfType && practicelist.contains(r.getString("practice_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_provider_median")
      postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_provider_median for month end dates ( $quarterEndDateList ) for practices "+prop.getProperty("practice_id_list"), "PASS")

      val rdd4 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_provider_location_median")
      rdd4.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && r.getString("flag") == wfType && practicelist.contains(r.getString("practice_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_provider_location_median")
      postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_provider_location_median for month end dates ( $quarterEndDateList ) for practices "+prop.getProperty("practice_id_list"), "PASS")
    }
    else
      {
        val rdd1 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_location_median")
        rdd1.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && r.getString("flag") == wfType).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_location_median")
        postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_location_median for month end dates ( $quarterEndDateList )", "PASS")

        val rdd2 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_practice_median")
        rdd2.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && r.getString("flag") == wfType).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_practice_median")
        postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_practice_median for month end dates ( $quarterEndDateList )", "PASS")

        val rdd3 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_provider_median")
        rdd3.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && r.getString("flag") == wfType).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_provider_median")
        postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_provider_median for month end dates ( $quarterEndDateList )", "PASS")

        val rdd4 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_provider_location_median")
        rdd4.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && r.getString("flag") == wfType).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_provider_location_median")
        postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_provider_location_median for month end dates ( $quarterEndDateList )", "PASS")

      }
  }

  def deleteFromWebdatamart(spark:SparkSession, measure_list:String,date_str:String): Unit =
  {
//    var quarterStartDate = SIMPLE_DATE_FORMAT.parse(prop.getProperty("quarterStartDate"))
//    var quarterEndDate = SIMPLE_DATE_FORMAT.parse(prop.getProperty("quarterEndDate"))
    try{

    var SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd")

    println("CASSANDRA DELETION MEASURE LIST:::"+measure_list)
    println("CASSANDRA DELETION MONTH END DATE LIST:::"+date_str)
    var measures = measure_list.split(",");


    var mlist = new ListBuffer[String]()
    var quarterEndDate = new ListBuffer[String]()
    for (measure <- measures) {mlist += measure    }

    var date_range_arr = date_str.trim.substring(1, date_str.length - 1).split(",")
    for (date_range1 <- date_range_arr) {
      var date_arr1 = date_range1.split("~")
      quarterEndDate+=date_arr1(1).trim
    }

      var quarterStartDate=DataMartCreator.prop.getProperty("quarterStartDate")
      DataMartCreator.prop.setProperty("quarterStartDate","")
      DataMartCreator.prop.setProperty("quarterEndDate","")

    if(!prop.getProperty("practice_id_list").equalsIgnoreCase("NA") && !prop.getProperty("practice_id_list").equals("")) {
    var practiceUIdList = prop.getProperty("practice_id_list").split(",")
    var practicelist = new ListBuffer[String]()
      for (practiceUId <- practiceUIdList) {
        practicelist += practiceUId.toString
      }
      if (wfType.equals("MR")) {
        delFromTablesPracticeWise(spark, quarterEndDate, mlist,practicelist, measure_list, s"$table_location_rolling_monthly", s"$table_practice_rolling_monthly", s"$table_provider_rolling_monthly")
      }

      if (wfType.equals("MNR")) {
        delFromTablesPracticeWise(spark, quarterEndDate, mlist,practicelist, measure_list, s"$table_location_monthly", s"$table_practice_monthly", s"$table_provider_monthly")
      }

      if (wfType.equals("QNR")) {
        delFromTablesPracticeWise(spark, quarterEndDate, mlist,practicelist, measure_list, s"$table_location_quarterly", s"$table_practice_quarterly", s"$table_provider_quarterly")
      }

      if (wfType.equals("QR")) {
        delFromTablesPracticeWise(spark, quarterEndDate, mlist,practicelist, measure_list, s"$table_location_rolling_quarterly", s"$table_practice_rolling_quarterly", s"$table_provider_rolling_quarterly")
      }

      if (wfType.equals("QCNR")) {
        val rdd1 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_practice_quarterly_qcnr")
        rdd1.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && practicelist.contains(r.getString("practice_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_practice_quarterly_qcnr")
        postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_practice_quarterly_qcnr for month end dates ( $quarterEndDate ) for practices "+prop.getProperty("practice_id_list"), "PASS")

        val rdd2 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_location_quarterly_qcnr")
        rdd2.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && practicelist.contains(r.getString("practice_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_location_quarterly_qcnr")
        postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_location_quarterly_qcnr for month end dates ( $quarterEndDate ) for practices "+prop.getProperty("practice_id_list"), "PASS")

        val rdd3 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_provider_quarterly_qcnr")
        rdd3.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && practicelist.contains(r.getString("practice_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_provider_quarterly_qcnr")
        postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_provider_quarterly_qcnr for month end dates ( $quarterEndDate ) for practices "+prop.getProperty("practice_id_list"), "PASS")
      }
    }
    else {
      if (wfType.equals("MR")) {
        delFromTables(spark, quarterEndDate, mlist, measure_list, s"$table_location_rolling_monthly", s"$table_practice_rolling_monthly", s"$table_provider_rolling_monthly")
      }

      if (wfType.equals("MNR")) {
        delFromTables(spark, quarterEndDate, mlist, measure_list, s"$table_location_monthly", s"$table_practice_monthly", s"$table_provider_monthly")
      }

      if (wfType.equals("QNR")) {
        delFromTables(spark, quarterEndDate, mlist, measure_list, s"$table_location_quarterly", s"$table_practice_quarterly", s"$table_provider_quarterly")
      }

      if (wfType.equals("QR")) {
        delFromTables(spark, quarterEndDate, mlist, measure_list, s"$table_location_rolling_quarterly", s"$table_practice_rolling_quarterly", s"$table_provider_rolling_quarterly")
      }

      if (wfType.equals("QCNR")) {
        val rdd1 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_practice_quarterly_qcnr")
        rdd1.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_practice_quarterly_qcnr")
        postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_practice_quarterly_qcnr for month end dates ( $quarterEndDate )", "PASS")

        val rdd2 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_location_quarterly_qcnr")
        rdd2.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_location_quarterly_qcnr")
        postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_location_quarterly_qcnr for month end dates ( $quarterEndDate )", "PASS")

        val rdd3 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$table_provider_quarterly_qcnr")
        rdd3.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$table_provider_quarterly_qcnr")
        postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $table_provider_quarterly_qcnr for month end dates ( $quarterEndDate )", "PASS")
      }
    }
    }
    catch {
      case e: Exception => {
        println(e.printStackTrace())
        postgresUtility.insertIntoProcessDetails(measure_list, "W0001", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
        System.exit(-1)
      }
    }
  }

  def delFromTables(spark:SparkSession,quarterEndDate:ListBuffer[String],mlist:ListBuffer[String],measure_list:String,tbl_location:String,tbl_practice:String,tbl_provider:String): Unit =
  {
    var quarterEndDateList:String=""
    for(d<-quarterEndDate)
      if (quarterEndDateList.isEmpty()){ quarterEndDateList=""+d }else{ quarterEndDateList=quarterEndDateList+","+d}

    val rdd1 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$tbl_location")
    rdd1.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$tbl_location")

    postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $tbl_location for month end dates ( $quarterEndDateList )", "PASS")

    val rdd2 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$tbl_practice")
    rdd2.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$tbl_practice")

    postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $tbl_practice for month end dates ( $quarterEndDateList )", "PASS")

    val rdd3 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$tbl_provider")
    rdd3.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$tbl_provider")

    postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $tbl_provider for month end dates ( $quarterEndDateList )", "PASS")

  }

  def delFromTablesPracticeWise(spark:SparkSession,quarterEndDate:ListBuffer[String],mlist:ListBuffer[String],practicelist:ListBuffer[String],measure_list:String,tbl_location:String,tbl_practice:String,tbl_provider:String): Unit =
  {
    var quarterEndDateList:String=""
    var pracStr:String=""
    for(d<-quarterEndDate)
      if (quarterEndDateList.isEmpty()){ quarterEndDateList=""+d }else{ quarterEndDateList=quarterEndDateList+","+d}
    for (plist<-practicelist)
      if (pracStr.isEmpty()){ pracStr=""+plist }else{ pracStr=pracStr+","+plist}


    val rdd1 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$tbl_location")
    rdd1.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && practicelist.contains(r.getString("practice_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$tbl_location")

    postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $tbl_location for month end dates ( $quarterEndDateList ) for practice $pracStr", "PASS")

    val rdd2 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$tbl_practice")
    rdd2.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && practicelist.contains(r.getString("practice_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$tbl_practice")

    postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $tbl_practice for month end dates ( $quarterEndDateList ) for practice $pracStr", "PASS")

    val rdd3 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$tbl_provider")
    rdd3.filter(r => chkDateEqual(r, "month_end_date", quarterEndDate) && mlist.contains(r.getString("measure_id")) && practicelist.contains(r.getString("practice_id"))).deleteFromCassandra(s"$webdatamart_keyspace", s"$tbl_provider")

    postgresUtility.insertIntoProcessDetails(measure_list, "", "", s"Data deletion From Cassandra table $tbl_provider for month end dates ( $quarterEndDateList ) for practice $pracStr", "PASS")

  }

  def chkDateEqual(r: CassandraRow,firstDate:String, compareDate:ListBuffer[String]): Boolean = {
    val isExist = !r.isNullAt(firstDate) && (compareDate.contains(r.getString(firstDate)))
    //    val isExist = !r.isNullAt(firstDate) && (r.getDate(firstDate).getDay.equals(compareDate.getDay) && r.getDate(firstDate).getMonth.equals(compareDate.getMonth) && r.getDate(firstDate).getYear.equals(compareDate.getYear))
    return isExist;
  }

  def deleteMasterFromWebdatamart(spark:SparkSession,MEASURE_NAME:String): Unit =
  {
    val rdd4 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$sub_practice_mapping")
    rdd4.deleteFromCassandra(s"$webdatamart_keyspace",s"$sub_practice_mapping")

    postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"","","Data deletion From Cassandra table "+sub_practice_mapping,"PASS")

    val rdd5 = spark.sparkContext.cassandraTable(s"$webdatamart_keyspace", s"$tin_practice_mapping")
    rdd5.deleteFromCassandra(s"$webdatamart_keyspace",s"$tin_practice_mapping")

    postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"","","Data deletion From Cassandra table "+tin_practice_mapping,"PASS")
  }


  def getCassandraRDD(sparkSession: SparkSession): CassandraTableScanRDD[CassandraRow] = {
    var rdd = sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"), prop.getProperty("keyspace_datamart_table_name"))
    return rdd
  }

  def getCassandraDF(sparkSession: SparkSession):DataFrame  = {
    val df = sparkSession
      .read
      .format("org.apache.spark.sql.cassandra")
      .options(Map( "table" -> prop.getProperty("keyspace_datamart_table_name"), "keyspace" -> prop.getProperty("keyspace_datamart")))
      .load()
    return df
  }




}
