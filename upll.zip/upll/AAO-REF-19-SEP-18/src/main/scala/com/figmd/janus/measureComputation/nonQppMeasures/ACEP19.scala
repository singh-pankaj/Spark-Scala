package com.figmd.janus.measureComputation.nonQppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import org.apache.spark.sql.SparkSession
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import org.apache.spark.rdd.RDD

object ACEP19 extends MeasureUtility with Measure {

  //var MEASURE_NAME = "M19"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,MEASURE_NAME)
    ippRDD.cache()
    // Eligible IPP
   val eligibleRdd = getEligibleIpp(ippRDD,MEASURE_NAME)
    // Filter Exclusions
    val notEligibleRDD =ippRDD.subtract(eligibleRdd)
    eligibleRdd.cache()
    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(eligibleRdd,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getSubtractRDD(eligibleRdd,exclusionRDD)
    intermediateA.cache()
    // Filter Met
    val metRDD = getMet(intermediateA,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not meate
    val notMetRDD =  getSubtractRDD(intermediateA,metRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }



   // Filter IPP
  def getIpp(rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
   rdd
    .filter(r =>
      (isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)
        &&
        (checkElementPresent(r, IPP, MEASURE_NAME, "edv") || checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem"))
        &&
        checkElementPresent(r, IPP, MEASURE_NAME, "npneheadtrm")
        &&
        isDateEqual(r, IPP, MEASURE_NAME, "npneheadtrm_date", "encounterdate")

        )
    )

}
     // Eligiable IPP
    def getEligibleIpp(ippRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {

      ippRDD.filter(r =>

        (
          checkElementPresent(r, ELIGIBLE, MEASURE_NAME, "hdct")
            &&
            (isDuringEncounterEDvisit(r, ELIGIBLE, MEASURE_NAME, "hdct_date", "ed_visit_arrival_date", "ed_visit_departure_date")
              ||
              isDateEqual(r, ELIGIBLE, MEASURE_NAME, "hdct_date", "crtclcrem_date")
              )
          )
      )

    }

  def getExclusionRdd(eligibleRdd:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {

    eligibleRdd.filter(r =>
      (
        (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "vntrishnt")
          &&
          isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "vntrishnt_date", "ed_visit_departure_date")
          )
          ||
          (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "brntumr")
            &&
            isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "brntumr_date", "ed_visit_departure_date")
            )
          ||
          (
            checkElementValue(r, EXCLUSION, MEASURE_NAME, "sex", 2)
              &&
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "preg")
              &&

              isDateEqual(r, EXCLUSION, MEASURE_NAME, "preg_date", "encounterdate")
            )
          ||
          (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "antiplatthrp")
            &&
            isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "antiplatthrp_date", "ed_visit_departure_date")
            )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "trmaexcluhd")
              &&
              (isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "trmaexcluhd_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                ||
                isDateEqual(r, EXCLUSION, MEASURE_NAME, "trmaexcluhd_date", "crtclcrem_date")
                )
            )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "cttorso")
              &&
              (isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "cttorso_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                ||

                isDateEqual(r, EXCLUSION, MEASURE_NAME, "cttorso_date", "crtclcrem_date")
                ))
        )
    )

  }


  def getMet(intermediateA:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {

    intermediateA.filter(r =>
      (
        isAgeGreaterOrEqual(r, MET, MEASURE_NAME, "dob", "encounterdate", 65)
          ||
          (

            chkValueRangeLess(r, MET, MEASURE_NAME, "gcs", 15)
              &&
              (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "gcs_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                ||
                isDateEqual(r, MET, MEASURE_NAME, "gcs_date", "crtclcrem_date")
                )


              ||

              (
                checkElementPresent(r, MET, MEASURE_NAME, "hdache")
                  &&
                  checkElementPresent(r, MET, MEASURE_NAME, "severe")
                  &&
                  (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "hdache_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                    ||

                    isDateEqual(r, MET, MEASURE_NAME, "hdache_date", "crtclcrem_date")
                    )
                )


              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "vomit")
                  &&
                  (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "vomit_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                    ||
                    isDateEqual(r, MET, MEASURE_NAME, "vomit_date", "crtclcrem_date")
                    )
                )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "phylsignbslesklfrctr")
                  &&
                  (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "phylsignbslesklfrctr_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                    ||

                    isDateEqual(r, MET, MEASURE_NAME, "phylsignbslesklfrctr_date", "crtclcrem_date")

                    )
                )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "fclneurodefct")
                  &&
                  (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "fclneurodefct_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                    ||

                    isDateEqual(r, MET, MEASURE_NAME, "fclneurodefct_date", "crtclcrem_date")

                    )
                )
            )
          ||
          (
            (checkElementPresent(r, MET, MEASURE_NAME, "coglpths") &&
              isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "coglpths_date", "ed_visit_departure_date"))
              ||
              (checkElementPresent(r, MET, MEASURE_NAME, "thrmcytopn") &&
                isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "thrmcytopn_date", "ed_visit_departure_date"))
              ||
              (checkElementPresent(r, MET, MEASURE_NAME, "anticoag") &&
                isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "anticoag_date", "ed_visit_departure_date")
                )
            )
          ||

          checkElementPresent(r, MET, MEASURE_NAME, "dngrsmechinjry")

          ||
          (
            (
              (checkElementPresent(r, MET, MEASURE_NAME, "loss_concusnes")
                &&
                (
                  isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "loss_concusnes_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                    ||
                    isDateEqual(r, MET, MEASURE_NAME, "loss_concusnes_date", "crtclcrem_date")
                  )
                )
                ||
                (checkElementPresent(r, MET, MEASURE_NAME, "psttrmtcamnsa")
                  &&
                  (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "psttrmtcamnsa_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                    ||
                    isDateEqual(r, MET, MEASURE_NAME, "psttrmtcamnsa_date", "crtclcrem_date")
                    )
                  )
              )
              &&
              (
                isAgeGreaterOrEqual(r, MET, MEASURE_NAME, "dob", "encounterdate", 60)
                  &&
                  isAgeLess(r, MET, MEASURE_NAME, "dob", "encounterdate", 65)
                  ||
                  (chkValueRangeLess(r, MET, MEASURE_NAME, "gcs", 15)
                    &&
                    (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "gcs_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                      ||

                      isDateEqual(r, MET, MEASURE_NAME, "gcs_date", "crtclcrem_date")

                      )
                    )
                  ||
                  (checkElementPresent(r, MET, MEASURE_NAME, "hdache")
                    &&
                    (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "hdache_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                      ||

                      isDateEqual(r, MET, MEASURE_NAME, "hdache_date", "crtclcrem_date")
                      )
                    )
                  ||
                  (checkElementPresent(r, MET, MEASURE_NAME, "shrttrmmemdef")
                    &&
                    (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "shrttrmmemdef_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                      ||

                      isDateEqual(r, MET, MEASURE_NAME, "shrttrmmemdef_date", "crtclcrem_date")
                      ))
                  ||
                  (checkElementPresent(r, MET, MEASURE_NAME, "seizafthdinju")
                    &&
                    (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "seizafthdinju_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                      ||

                      isDateEqual(r, MET, MEASURE_NAME, "seizafthdinju_date", "crtclcrem_date")
                      ))
                  ||
                  (checkElementPresent(r, MET, MEASURE_NAME, "hed_nktrma")
                    &&
                    (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "hed_nktrma_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                      ||

                      isDateEqual(r, MET, MEASURE_NAME, "hed_nktrma_date", "crtclcrem_date")
                      ))

                  ||
                  (
                    checkElementPresent(r, MET, MEASURE_NAME, "drgalintoxi")
                      &&
                      isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "drgalintoxi_date", "ed_visit_departure_date")

                    )

                )
            )
        ))

  }



}