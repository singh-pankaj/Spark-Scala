package com.figmd.janus.measureComputation.nonQppMeasures

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Date
import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession
object ACEP46_2 extends MeasureUtility with MeasureTrait{

  final var MEASURE_NAME = "M46_2"
  @transient lazy val postgresUtility=new PostgreUtility()

  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {

    try {
      //var rdd = new CassandraUtility().getCassandraRDD(sparkSession)
      val dateUtil = new DateUtility()
      var columnRef = getFiledList(MEASURE_NAME)
      val list=  chkValueRangeLessorEqualMedian1(sparkSession, "edannualvisitvolumn", 19999)
      val rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0), columnRef(1), columnRef(2), columnRef(3), columnRef(4), columnRef(5), columnRef(6), columnRef(7), columnRef(8), columnRef(9), columnRef(10), columnRef(11), columnRef(12), columnRef(13), columnRef(14), columnRef(15), columnRef(16), columnRef(17),columnRef(18), columnRef(19), columnRef(20), columnRef(21),columnRef(22),columnRef(23),columnRef(24),columnRef(25),columnRef(26)).where("encounterdate>=? and encounterdate<=?",startDate, endDate)
      val ippRDD =rdd.filter(r =>
        (
          (
            isAgeLess(r,IPP,MEASURE_NAME,"dob","edv_date",18)
              ||
              isAgeLess(r,IPP,MEASURE_NAME,"dob","crtclcrem_date",18)
            )
            &&
            (checkElementPresent(r, IPP, MEASURE_NAME, "edv") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem")
              )
            &&
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "disch_emrgncydept")
                &&
                isDateEqual(r, IPP, MEASURE_NAME, "disch_emrgncydept_date", "ed_visit_departure_date")
                &&
                (isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "ed_visit_arrival_date", "disch_emrgncydept_date")
                  ||
                  isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "crtclcrem_date", "disch_emrgncydept_date")
                  )
              )
            &&
            checkElementPresent(r, IPP, MEASURE_NAME, "pshepa")
            &&
            list.contains(r.getString("servicelocationuid"))
          )
      )
      ippRDD.cache()

      val exclusionRDD = ippRDD
        .filter(r =>(
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "paex")
            &&

            (
              isDuringEncounterEDvisit(r,EXCLUSION,MEASURE_NAME,"paex_date","ed_visit_arrival_date","ed_visit_departure_date")
                ||
                isDateEqual(r, EXCLUSION, MEASURE_NAME, "paex_date", "crtclcrem_date")

              ))
        )
      exclusionRDD.cache()
      val intermediateRDD = ippRDD.subtract(exclusionRDD)
      //intermediateRDD.cache()

      val Rdd1 = intermediateRDD.map( l =>(l.columnValues(0),l.columnValues(1),l.columnValues(2),dateUtil.getMinutesDiff_1(if(l.isNullAt(13) ) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(13).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),if(l.isNullAt(15) ) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(15).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))).toDouble))
      //Rdd1.cache()

      //location
      val locationRdd=Rdd1.groupBy(x=>x._3).map(k=>(k._1,median(k._2.toList.sortBy(x=>x._4).map(x=>x._4)),k._2.size))
      locationRdd.cache()

      if (DataMartCreator.debugMode == 1) {
        println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
        println("ACEP " + MEASURE_NAME + " *** Exclusion          ***" + exclusionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** locationRdd    ***" + locationRdd.count())
        println("*********************************************************")
      }
      else
      { saveToWebDM_median(locationRdd, MEASURE_NAME)}

      //   rdd.unpersist(true);
      ippRDD.unpersist(true);
      exclusionRDD.unpersist(true);
      locationRdd.unpersist(true);

      postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"","","Measure computation done successfully","PASS")
    }
    catch {
      case e: Exception => {
        postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"W0001","CRITICAL",Throwables.getStackTraceAsString(e),"FAIL")
        println(e.printStackTrace())
        System.exit(-1)


      }
    }
  }
}