package com.figmd.janus.util

import java.sql.{Connection, DriverManager}
import java.text.SimpleDateFormat
import java.util.{Calendar, Properties}

import com.figmd.janus.DataMartCreator
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SaveMode, SparkSession}
import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector._
import com.datastax.spark.connector.rdd.CassandraTableScanRDD

import scala.collection.mutable.ListBuffer

class PostgreUtility extends Serializable {

  val url = "jdbc:postgresql://" + DataMartCreator.prop.getProperty("postgresHostName") + ":" + DataMartCreator.prop.getProperty("postgresHostPort")
  val driver = "org.postgresql.Driver"
  val username = DataMartCreator.prop.getProperty("postgresHostUserName")
  val password = DataMartCreator.prop.getProperty("postgresUserPass")
  var properties = new Properties()
  var wf_id = DataMartCreator.prop.getProperty("wf_id")
  var connection: Connection = _

  def getPostgresConnection(): Object = {
    return null;
  }

  def clinicalDataElement(spark: SparkSession, RDD: CassandraTableScanRDD[CassandraRow]): RDD[CassandraRow] = {

    Class.forName(driver)
    connection = DriverManager.getConnection(url + "/"+DataMartCreator.prop.getProperty("postgresManagementDatabaseName"), username, password)

    val statement1 = connection.createStatement
    val rs1 = statement1.executeQuery("SELECT practiceuid FROM practice")
    val statement2 = connection.createStatement
    val rs2 = statement2.executeQuery("SELECT servicelocationuid FROM servicelocation where inactive=false")
    val statement3 = connection.createStatement
    val rs3 = statement3.executeQuery("SELECT serviceprovideruid FROM serviceprovider where inactive=false")

    var list1 = new ListBuffer[String]()
    while (rs1.next()) {
      list1 += rs1.getString(1)
    }

    var list2 = new ListBuffer[String]()
    while (rs2.next()) {
      list2 += rs2.getString(1)
    }

    var list3 = new ListBuffer[String]()
    while (rs3.next()) {
      list3 += rs3.getString(1)
    }


    //val rdd1 = spark.sparkContext.cassandraTable("acep","tblencounter_mat")
    //println("1:::::::" + RDD.count())
    val rdd = RDD.filter(f => list1.contains(f.getString("practiceuid")) &&
      list2.contains(f.getString("servicelocationuid")) &&
      list3.contains(f.getString("serviceprovideruid")))
    //println("2:::::::" + rdd2.count())

    connection.close();
    return rdd

  }

  //function for clinicalDataElement postgresManagementDatabaseName
  /*  def clinicalDataElement(spark:SparkSession):RDD[CassandraRow]=
    {

      val practiceDF = spark.read
        .format("jdbc")
        .option("url", url+"/"+DataMartCreator.prop.getProperty("postgresConfigDatabaseName"))
        .option("dbtable", "practice")
        .option("user", username)
        .option("password", password)
        .load()

      val serviceLocationDF = spark.read
        .format("jdbc")
        .option("url", url+"/"+DataMartCreator.prop.getProperty("postgresConfigDatabaseName"))
        .option("dbtable", "ServiceLocation")
        .option("user", username)
        .option("password", password)
        .load().filter("inactive==0")

      val serviceProviderDF = spark.read
        .format("jdbc")
        .option("url", url+"/"+DataMartCreator.prop.getProperty("postgresConfigDatabaseName"))
        .option("dbtable", "ServiceProvider")
        .option("user", username)
        .option("password", password)
        .load().filter("inactive==0")

      val tblEncounteDF=new CassandraUtility().getCassandraDF(spark)

      val rsltDF1=tblEncounteDF.join(practiceDF,tblEncounteDF("practiceuid")===practiceDF("practiceuid"))
      val rsltDF2=rsltDF1.join(serviceLocationDF,rsltDF1("ServiceLocationUID")===serviceLocationDF("ServiceLocationUID"))
      val rsltDF3=rsltDF2.join(serviceProviderDF,rsltDF2("serviceProviderUID")===serviceProviderDF("serviceProviderUID"))
  //    println("1:::::::::"+rsltDF1.count())
  //    println("2:::::::::"+rsltDF2.count())
  //    println("3:::::::::"+rsltDF3.count())
      import  com.datastax.spark.connector._

      val rows:RDD[CassandraRow] = rsltDF3.rdd[CassandraRow]
      return rows


      //println(":::::::::::RDD::"+rows.count())
    }*/

  def tinPracticeMapping(spark: SparkSession): Unit = {
    val practiceDF = spark.read
      .format("jdbc")
      .option("url", url + "/" + DataMartCreator.prop.getProperty("postgresManagementDatabaseName"))
      .option("dbtable", s"(select distinct parentpracticeuid,practiceuid from practice where parentpracticeuid is not null) as mqm")
      .option("user", username)
      .option("password", password)
      .load()
    practiceDF.select("parentpracticeuid","practiceuid").write.option("delimiter", "~").mode(SaveMode.Overwrite).csv(DataMartCreator.prop.getProperty("measure_computation_output_path") + "/practice")
  }

  def practiceSubPracticeMapping(spark: SparkSession): Unit = {

    val practiceDF = spark.read
      .format("jdbc")
      .option("url", url + "/" + DataMartCreator.prop.getProperty("postgresManagementDatabaseName"))
      .option("dbtable", s"(select distinct tin,practiceuid from practicetinsplitinfo  where tin is not null) as mqm")
      .option("user", username)
      .option("password", password)
      .load()
    practiceDF.select("tin","practiceuid").write.option("delimiter", "~").mode(SaveMode.Overwrite).csv(DataMartCreator.prop.getProperty("measure_computation_output_path") + "/practicetinsplitinfo")
  }
  //CREATE TABLE IF NOT EXISTS process_details(id serial primary key,wf_id varchar(50) NOT NULL,measure_name varchar(200),action_name varchar(200),date_time timestamp NOT NULL DEFAULT 'now'::timestamp,
  // error_code  varchar(50),error_type  varchar(50),error_message text,status varchar(50))
  // Auding table for detailed worflow action
  def insertIntoProcessDetails(measure_name: String, error_code: String, error_type: String, error_message: String, status: String): Unit = {
    connection = postgresConnect();
    try {


      val pstatement = connection.prepareStatement("Insert into process_details(wf_id,wftype, quarter_start_date,quarter_end_date,measure_name,action_name,error_code,error_type,error_message," +
        "status)values(?,?,?,?,?,?,?,?,?,?)");
      pstatement.setString(1, wf_id)
      pstatement.setString(2, DataMartCreator.prop.getProperty("wfType"))
      pstatement.setString(3, DataMartCreator.prop.getProperty("quarterStartDate"))
      pstatement.setString(4, DataMartCreator.prop.getProperty("quarterEndDate"))
      pstatement.setString(5, measure_name)
      pstatement.setString(6, com.figmd.janus.DataMartCreator.action_name)
      pstatement.setString(7, error_code)
      pstatement.setString(8, error_type)
      pstatement.setString(9, error_message)
      pstatement.setString(10, status)

      pstatement.executeUpdate()
    }
    catch {
      case e: Exception => print("ERROR..." + e.printStackTrace())
        System.exit(-1)
    }
    finally {
      connection.close()
    }
  }

  //function for postgresConnect
  def postgresConnect(): Connection = {
    Class.forName(driver)
    connection = DriverManager.getConnection(url + "/" + DataMartCreator.prop.getProperty("postgresConfigDatabaseName"), username, password)
    return connection

  }

  //CREATE TABLE IF NOT EXISTS central_log(id serial primary key,wf_id varchar(50) NOT NULL,action_name varchar(150),date_time timestamp NOT NULL DEFAULT 'now'::timestamp,
  // error_code varchar(50),error_message text,status varchar(100))
  // Auding table for each worflow action
  def insertIntoCentralLog(measure_name: String, error_code: String, error_type: String, error_message: String, status: String): Unit = {
    //var wf_id=DataMartCreator.prop.getProperty("wf_id")
    connection = postgresConnect();
    try {

      val pstatement = connection.prepareStatement("Insert into central_log(wf_id ,action_name,status,error_code,error_message)values(?,?,?,?,?)");
      pstatement.setString(1, wf_id)
      pstatement.setString(2, com.figmd.janus.DataMartCreator.action_name)
      pstatement.setString(3, status)
      pstatement.setString(4, error_code)
      pstatement.setString(5, error_message)

      pstatement.executeUpdate()
    }
    catch {
      case e: Exception => print("ERROR..." + e.printStackTrace())
    }
    finally {
      connection.close()
    }
  }
}
