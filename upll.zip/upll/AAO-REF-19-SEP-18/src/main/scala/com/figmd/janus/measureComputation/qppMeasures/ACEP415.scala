package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import org.apache.spark.sql.SparkSession
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD

object ACEP415 extends MeasureUtility with Serializable with Measure {


  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {


    //      val CRA = getBackTrackingList(rdd, "anmefoph", "encounterdate");
    //      val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)
    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD=getExclusionRDD(ippRDD,MEASURE_NAME)
    exclusionRDD.cache()

    val intermediateA = getinterRDD(ippRDD,exclusionRDD)
    intermediateA.cache()
    //met
    val metRDD = getMet(intermediateA,startDate:Date,endDate:Date,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    val exceptionRDD =sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Not Met
    val notMetRDD =  getNotMet(intermediateA,metRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }
     // Filter IPP
      def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
        rdd
          .filter(r =>
            (
              isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate)
                &&
                isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "edv_date", 18) &&
                checkElementPresent(r, IPP, MEASURE_NAME, "edv") &&
                isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "edv_date", startDate, endDate) &&
                (
                  (
                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "hectpe") &&
                        isDateEqual(r, IPP, MEASURE_NAME, "hectpe_date", "edv_date")
                      )
                      ||
                      (
                        checkElementPresent(r, IPP, MEASURE_NAME, "hdct") &&
                          isDateEqual(r, IPP, MEASURE_NAME, "hdct_date", "edv_date")
                        )
                    )
                    &&
                    (
                      checkElementValue(r, IPP, MEASURE_NAME, "gcs", 15) &&
                        isDateEqual(r, IPP, MEASURE_NAME, "gcs_date", "edv_date")
                      )
                    &&
                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "npneheadtrm") &&
                        isDateEqual(r, IPP, MEASURE_NAME, "npneheadtrm_date", "edv_date")
                      )
                  //
                  /* && // element not found in DB
                 (

                   checkElementPresent(r, IPP, MEASURE_NAME, "doumn_nphdtrm_wthn24hrs_element") //&&
                     isDateEqual(r, IPP, MEASURE_NAME, "doumn_nphdtrm_wthn24hrs_date", "edv_date")

                   )*/
                  )

                ||
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "paprwi24ho_1") &&
                    isDateEqual(r, IPP, MEASURE_NAME, "paprwi24ho_1_date", "npneheadtrm_date")
                  )
              )
          )

      }




  def getExclusionRDD(ippRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    ippRDD.filter(r =>
      (
        checkElementPresent(r, EXCLUSION, MEASURE_NAME, "brntumr") &&
          isDateEqual(r, EXCLUSION, MEASURE_NAME, "brntumr_date", "edv_date")
        ) ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "preg") &&
            isDateEqual(r, EXCLUSION, MEASURE_NAME, "preg_date", "edv_date")
          )
        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "antiplatthrp") &&
            isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "antiplatthrp_date", "edv_date")
          ) ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "vntrishnt") &&
            isDateEqual(r, EXCLUSION, MEASURE_NAME, "vntrishnt_date", "edv_date")
          )
        ||
        (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "cofohect") &&
          isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "cofohect_date", "npneheadtrm_date")
          )
        ||
        (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "trmaexcluhd") &&
          isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "trmaexcluhd_date", "edv_date")
          )
    )
  }


  def getMet(intermediateA:RDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateA.filter(r =>
      (
        isAgeGreaterOrEqual(r, MET, MEASURE_NAME, "dob", "edv_date", 65)
          ||
          (
            (
              checkElementPresent(r, MET, MEASURE_NAME, "hdac") &&
                isDateEqual(r, MET, MEASURE_NAME, "hdac_date", "edv_date") &&
                checkElementPresent(r, MET, MEASURE_NAME, "seve")
              )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "vomit") &&
                  isDateEqual(r, MET, MEASURE_NAME, "vomit_date", "edv_date")
                )
              ||
              (

                checkElementPresent(r, MET, MEASURE_NAME, "phylsignbslesklfrctr") &&
                  isDateEqual(r, MET, MEASURE_NAME, "phylsignbslesklfrctr_date", "edv_date")
                )
              ||
              (

                checkElementPresent(r, MET, MEASURE_NAME, "fclneurodefct") &&
                  isDateEqual(r, MET, MEASURE_NAME, "fclneurodefct_date", "edv_date")
                )
            )
          ||
          (
            (
              checkElementPresent(r, MET, MEASURE_NAME, "coglpths") && // coglpths_date,thrmcytopn_date
                isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "coglpths_date", "edv_date")
              )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "thrmcytopn") &&
                  isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "thrmcytopn_date", "edv_date")
                )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "anticoag") &&
                  isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "anticoag_date", "edv_date")
                )
            )
          ||
          (
            checkElementPresent(r, MET, MEASURE_NAME, "edv") &&
              checkElementPresent(r, MET, MEASURE_NAME, "dngmechinj_grp") &&
              isDuringMeasurementPeriod(r, MET, MEASURE_NAME, "edv_date", startDate, endDate)
            )
          ||

          (
            (
              (checkElementPresent(r, MET, MEASURE_NAME, "loss_concusnes") &&
                isDateEqual(r, MET, MEASURE_NAME, "loss_concusnes_date", "edv_date")
                ) ||
                (checkElementPresent(r, MET, MEASURE_NAME, "potram") &&
                  isDateEqual(r, MET, MEASURE_NAME, "potram_date", "edv_date"))
              )
              && (
              (isAgeBetween(r, MET, MEASURE_NAME, "dob", "encounterdate", 60, 65))
                ||
                (
                  (
                    checkElementPresent(r, MET, MEASURE_NAME, "hdac") &&
                      isDateEqual(r, MET, MEASURE_NAME, "hdac_date", "edv_date")) ||
                    (
                      checkElementPresent(r, MET, MEASURE_NAME, "shtemede") &&
                        isDateEqual(r, MET, MEASURE_NAME, "shtemede_date", "edv_date")) ||
                    (
                      checkElementPresent(r, MET, MEASURE_NAME, "szr_inj_") &&
                        isDateEqual(r, MET, MEASURE_NAME, "szr_inj__date", "edv_date")) ||
                    (
                      checkElementPresent(r, MET, MEASURE_NAME, "evtrmhdnck") &&
                        isDateEqual(r, MET, MEASURE_NAME, "evtrmhdnck_date", "edv_date"))
                  )
                ||
                checkElementPresent(r, MET, MEASURE_NAME, "drgalintoxi")
              )
            )
          ||
          (
            checkElementPresent(r, MET, MEASURE_NAME, "infoahect") &&
              isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "infoahect_date", "npneheadtrm_date"))
        )
    )
  }





   // IPP RDD content Backtracking
/*
  def BackTracking(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {


    for (x <- CRA.value) {
      if (x != "") {
        //println(r.getString("visituid") + ">>>" + x)
        val back_data = x.split("~")
        val patientid = back_data(0);
        val doumn_nphdtrm_wthn24hrs_element = back_data(1);
        val doumn_nphdtrm_wthn24hrs_date = dateUitilityObj.dateTimeParse(back_data(2));


        if ((!r.isNullAt("edv_date") )
          && ((r.getString("patientuid").equals(patientid) || r.getString("patientuid") == patientid)
          &&(
          doumn_nphdtrm_wthn24hrs_element == "1"
          && (r.getDateTime("edv_date").minusHours(24).isBefore(doumn_nphdtrm_wthn24hrs_date) || (r.getDateTime("edv_date").minusHours(30).equals(doumn_nphdtrm_wthn24hrs_date)))
          )
          )
        ) {

          return true;
        }

      }

    }

    return false;

  }

  def getBackTrackingList(rdd: CassandraTableScanRDD[CassandraRow], backtrackelement1: String, backtrackelement2: String): List[String] = {

   // val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).distinct().collect().toList

   // val IPPFilterExclusionRDD = rdd.filter(x => (ipp_patient_list.contains(x.columnValues(2))))

    var CRA = rdd.select("patientuid",backtrackelement1,backtrackelement2).map(x =>
      if (!x.isNullAt("patientuid")
        && !x.isNullAt(backtrackelement1) && !x.isNullAt(backtrackelement2)) {
        x.getString("patientuid") + "~" + x.getString(backtrackelement1) + "~" + x.getString(backtrackelement2)
      }
      else ""
    )
      .collect()
      .toList

    return CRA;
  }*/
}

