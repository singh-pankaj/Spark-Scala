package com.figmd.janus.measureComputation.nonQppMeasures

import java.util.{Date, Properties}

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.{DataMartCreator, Measure}
import org.apache.spark.sql.{Row, SparkSession}
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.catalyst.expressions.aggregate.Max

object ACEP25 extends MeasureUtility with Measure{

  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,MEASURE_NAME)
    ippRDD.cache()
        //NotEligiable
    val notEligibleRDD =sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Calculation of Tobacco user or non-user.
    val MR_ToUsSc = getMRToUsSc(ippRDD,MEASURE_NAME)
    MR_ToUsSc.cache()

    // Calculation of Most Recent Element
    var MR_Inter1 = (MR_ToUsSc.map(l => (l.columnValues(3),l.columnValues(32))).reduceByKey((x, y) => Ordering[Date].max(dateUtility.dateParse(convertDateToYYYYDDMM(x.toString)), dateUtility.dateParse(convertDateToYYYYDDMM(y.toString)))))
    var MR_InterMediate = MR_Inter1.keyBy(l => (l._1, l._2))
    var MR_IPPRDD = ippRDD.keyBy(l => (l.columnValues(3), l.columnValues(7)))
    var MR_ToUsSc_Enct_EQ_MRDate = MR_IPPRDD.join(MR_InterMediate).map(l => l._2).map(l => l._1)
    MR_ToUsSc_Enct_EQ_MRDate.cache()
    // Exclusion Clacultion
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //met
    val metRDD = getMet(MR_ToUsSc_Enct_EQ_MRDate,endDate,MEASURE_NAME)
    metRDD.cache()
    val met_visit_list = metRDD.map(x=>x.columnValues(4)).collect().toList
    val intermediateRDD = ippRDD.filter(r=> !met_visit_list.contains(r.columnValues(4)))
    intermediateRDD.cache()
    // Filter Exceptions
    val exceptionRDD = getexception(intermediateRDD,MEASURE_NAME)
        exceptionRDD.cache()
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediateRDD,exceptionRDD)
        notMetRDD.cache()


    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }

    // Filter IPP
    def getIpp(rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
      rdd.filter(r =>
            (
              isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)

                &&
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "edv")
                    ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem")
                  )
                &&
                (
                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "asth_2")
                      &&
                      isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "asth_2_date", "ed_visit_departure_date")
                    )
                    ||
                    (checkElementPresent(r, IPP, MEASURE_NAME, "copd")
                      &&
                      isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "copd_date", "ed_visit_departure_date")
                      )
                  )
              )

      )
    }

   def getMRToUsSc(ippRDD:RDD[CassandraRow],MEASURE_NAME:String):RDD[CassandraRow] = {
     ippRDD.filter(r =>
       (
         (
           checkElementPresent(r, IPP, MEASURE_NAME, "toussc")
             &&
             (
               isDuringEncounterEDvisit(r, IPP, MEASURE_NAME, "toussc_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                 ||
                 isDateEqual(r, IPP, MEASURE_NAME, "toussc_date", "crtclcrem_date")
               )

           )
           &&
           (
             checkElementPresent(r, IPP, MEASURE_NAME, "tobnu")
               ||
               checkElementPresent(r, IPP, MEASURE_NAME, "tous_1")
             )
         )
     )
   }

/*
  var MR_Inter1 = (MR_ToUsSc.map(l => (l.columnValues(3),l.columnValues(32))).reduceByKey((x, y) => Ordering[Date].max(dateUtility.dateParse(convertDateToYYYYDDMM(x.toString)), dateUtility.dateParse(convertDateToYYYYDDMM(y.toString)))))

    var MR_InterMediate = MR_Inter1.keyBy(l => (l._1, l._2))

    var MR_IPPRDD = ippRDD.keyBy(l => (l.columnValues(3), l.columnValues(7)))

    var MR_ToUsSc_Enct_EQ_MRDate = MR_IPPRDD.join(MR_InterMediate).map(l => l._2).map(l => l._1)*/



  def getMet(MR_ToUsSc_Enct_EQ_MRDate:RDD[CassandraRow],endDate: Date,MEASURE_NAME:String):RDD[CassandraRow] = {
    MR_ToUsSc_Enct_EQ_MRDate.filter(r =>

      (MR_checkElementStatus(r, MET, MEASURE_NAME, MR_chk_TBusr_NonTbusr(r, MET, MEASURE_NAME, "tobnu_date", "tous_1_date", "tobnu", "tous_1"), true)
        ||
        (
          MR_checkElementStatus(r, MET, MEASURE_NAME, MR_chk_TBusr_NonTbusr(r, MET, MEASURE_NAME, "tobnu_date", "tous_1_date", "tobnu", "tous_1"), false)
            &&
            (
              (checkElementPresent(r, MET, MEASURE_NAME, "tousceco")
                &&
                isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "tousceco_date", "encounterdate")
                &&
                chkDateRangeLessThanQuarterEndDate(r, MET, MEASURE_NAME, "tousceco_date", endDate))

                &&
                (checkElementPresent(r, MET, MEASURE_NAME, "tousceph")
                  &&
                  isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "tousceph_date", "encounterdate")
                  &&
                  chkDateRangeLessThanQuarterEndDate(r, MET, MEASURE_NAME, "tousceph_date", endDate))
              )

          )
        )
    )
  }

 /*   val met_visit_list = metRDD.map(x=>x.columnValues(4)).collect().toList
    val intermediateRDD = ippRDD.filter(r=> !met_visit_list.contains(r.columnValues(4)))*/


  def getexception(intermediateRDD:RDD[CassandraRow],MEASURE_NAME:String):RDD[CassandraRow] = {
    intermediateRDD.filter(r =>
      (
        checkElementPresent(r, EXCEPTION, MEASURE_NAME, "liliex")
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mere_1")
              &&
              (
                isDuringEncounterEDvisit(r, EXCEPTION, MEASURE_NAME, "mere_1_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, EXCEPTION, MEASURE_NAME, "mere_1_date", "crtclcrem_date")
                )

            )
        )

    )
  }
}
