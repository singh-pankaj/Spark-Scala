package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.Measure
import com.figmd.janus.util.MeasureUtility
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP419 extends MeasureUtility with Measure {

  /*var MEASURE_NAME = "M419"
  @transient lazy val postgresUtility=new PostgreUtility()*/
  // Logic for measure refresh
  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {



    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //met
    val metRDD = getMet(ippRDD,MEASURE_NAME)
    metRDD.cache()
    // Filter Intermediate
    var intermediateRDD = getSubtractRDD(ippRDD,metRDD)
    intermediateRDD.cache()

    // Filter Exceptions
    val exceptionRDD = getException(intermediateRDD,MEASURE_NAME)
    // Filter not meate
    val notMetRDD =  getSubtractRDD(intermediateRDD,exceptionRDD)
    // notMetRDD.cache()


    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }
  // Filter IPP
  def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    rdd
      .filter(r =>
        (
          (
            checkElementPresent(r, IPP, MEASURE_NAME, "primaryhead") &&
              isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "primaryhead_date", "encounterdate")
            )
            &&
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1") ||
                checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") ||
                checkElementPresent(r, IPP, MEASURE_NAME, "nufavi") ||
                checkElementPresent(r, IPP, MEASURE_NAME, "caseinlorefa") ||
                checkElementPresent(r, IPP, MEASURE_NAME, "hohese")
              )
            &&
            ((
              checkElementPresent(r, IPP, MEASURE_NAME, "norneuexmntn") &&
                isDateEqual(r, IPP, MEASURE_NAME, "norneuexmntn_date", "encounterdate")
              )
              ||
              !(
                checkElementPresent(r, IPP, MEASURE_NAME, "neuroexam") &&
                  isDateEqual(r, IPP, MEASURE_NAME, "neuroexam_date", "encounterdate")
                )
              )
            && (

            checknull(r, IPP, MEASURE_NAME, "ov_thmdmod95") ||
              checknull(r, IPP, MEASURE_NAME, "nrsnfcltvst_tm") ||
              checknull(r, IPP, MEASURE_NAME, "hmhlthsrvc_tm") ||
              checknull(r, IPP, MEASURE_NAME, "eddeptvist_tm") ||
              checknull(r, IPP, MEASURE_NAME, "csltrf_tm")
            ) && (
            checknull(r, IPP, MEASURE_NAME, "pos02")
            )

          )
      )
  }

  def getMet(ippRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    ippRDD.filter(r => (

      (
        checkElementPresent(r, MET, MEASURE_NAME, "advbrainimgmet") &&
          isDateEqual(r, MET, MEASURE_NAME, "advbrainimgmet_date", "encounterdate")
        )
        || !(
        (
          checkElementPresent(r, MET, MEASURE_NAME, "advbrnimgnmet") &&
            isDateEqual(r, MET, MEASURE_NAME, "advbrainimgmet_date", "encounterdate")
          ) || (
          checkElementPresent(r, MET, MEASURE_NAME, "advbrnimging") &&
            isDateEqual(r, MET, MEASURE_NAME, "advbrnimging_date", "encounterdate")
          )
        )

      ))
  }

  def getException(intermediateRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateRDD.filter(r => (
      (
        checkElementPresent(r, EXCEPTION, MEASURE_NAME, "advbrimgmedrsn") &&
          isDateEqual(r, EXCEPTION, MEASURE_NAME, "advbrimgmedrsn_date", "encounterdate")
        )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "advbrimgsysrsn") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "advbrimgsysrsn_date", "encounterdate")
          )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "abnrmlneuroexm") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "abnrmlneuroexm_date", "encounterdate")
          )

      ))
  }
}