package com.figmd.janus.measureComputation.nonQppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.util._
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP29 extends MeasureUtility with Measure {

  //var MEASURE_NAME = "M29"
  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    val eligibleRdd = getEligibleIpp(ippRDD,MEASURE_NAME)
    eligibleRdd.cache()
    //NotEligiable
    val notEligibleRDD =ippRDD.subtract(eligibleRdd)
    // Filter Exclusions
    // BAcktracking RDD for Exclusion
    val CRA = getBackTrackingList(rdd, eligibleRdd, "acutecifacility", "acutecifacility_date");
    val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)


    val exclusionRDD = getExclusionRdd(eligibleRdd,CRA_list,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getinterRDD(eligibleRdd,exclusionRDD)
    intermediateA.cache()
    // Filter Met
    //met
    val metRDD = getMet(intermediateA,MEASURE_NAME)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediateA,metRDD)
    notMetRDD.cache()


    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }
      // Filter IPP
      def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
        rdd
          .filter(r =>
            (
              isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate)
                && (
                isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)

                  &&
                  (checkElementPresent(r, IPP, MEASURE_NAME, "edv")
                    ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem"))
                  &&
                  (

                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "septshck")
                        &&
                        (isDuringEncounterEDvisit(r, IPP, MEASURE_NAME, "septshck_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                          ||
                          isDateEqual(r, IPP, MEASURE_NAME, "septshck_date", "crtclcrem_date")
                          )
                      )
                      ||
                      (
                        (
                          (checkElementPresent(r, IPP, MEASURE_NAME, "sepsis") &&

                            (isDuringEncounterEDvisit(r, IPP, MEASURE_NAME, "sepsis_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                              ||

                              isDateEqual(r, IPP, MEASURE_NAME, "sepsis_date", "crtclcrem_date")

                              )

                            )
                            ||
                            (
                              checkElementPresent(r, IPP, MEASURE_NAME, "infec") &&
                                isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "infec_date", "ed_visit_departure_date")
                              )
                          )
                          &&
                          (
                            checkElementPresent(r, IPP, MEASURE_NAME, "acutehypo") &&
                              (
                                isDuringEncounterEDvisit(r, IPP, MEASURE_NAME, "acutehypo_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                                  ||
                                  isDateEqual(r, IPP, MEASURE_NAME, "acutehypo_date", "crtclcrem_date")

                                )
                            )

                        )
                    )
                )
              )
          )
      }
      //ippRDD.cache()

  def getEligibleIpp(ippRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {

    ippRDD.filter(r =>

      (chkValueRangeGreater(r, ELIGIBLE, MEASURE_NAME, "serlact", 2)
        &&
        (
          isDuringEncounterEDvisit(r, ELIGIBLE, MEASURE_NAME, "serlact_date", "ed_visit_arrival_date", "ed_visit_departure_date")
            ||

            isDateEqual(r, ELIGIBLE, MEASURE_NAME, "serlact_date", "crtclcrem_date")

          )
        )
    )
  }


     def getExclusionRdd(eligibleRdd:RDD[CassandraRow],CRA_list:Broadcast[List[String]],MEASURE_NAME:String): RDD[CassandraRow] = {

       eligibleRdd.filter(r =>
         (
           checkElementPresent(r, EXCLUSION, MEASURE_NAME, "lftbeftrtmcom")
             &&
             (
               isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "lftbeftrtmcom_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                 ||
                 isDateEqual(r, EXCLUSION, MEASURE_NAME, "lftbeftrtmcom_date", "crtclcrem_date")


               )
           )
           ||
           (
             checkElementPresent(r, EXCLUSION, MEASURE_NAME, "death_ind")
               && (
               isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "death_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                 ||

                 isDateEqual(r, EXCLUSION, MEASURE_NAME, "death_date", "crtclcrem_date")

               )
             )
           ||
           (

             isElementStartsAfterStartOfWithinHours(r, EXCLUSION, MEASURE_NAME, "serlact_date", "ed_visit_departure_date", 2)

               &&

               isDateDiffHourGreaterOrEqual(r, EXCLUSION, MEASURE_NAME, "serlact_date", "ed_visit_departure_date", 0)
             )
           ||
           (
             checkElementPresent(r, EXCLUSION, MEASURE_NAME, "come")
               &&
               (isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "come_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                 ||

                 isDateEqual(r, EXCLUSION, MEASURE_NAME, "come_date", "crtclcrem_date")

                 )
             )
           ||
           (
             checkElementPresent(r, EXCLUSION, MEASURE_NAME, "decsepcare")
               &&
               (isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "decsepcare_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||

                 isDateEqual(r, EXCLUSION, MEASURE_NAME, "decsepcare_date", "crtclcrem_date")

                 )
             )
           ||
           (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "cardarrst") &&
             (isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "cardarrst_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||

               isDateEqual(r, EXCLUSION, MEASURE_NAME, "cardarrst_date", "crtclcrem_date")

               ))
           ||
           (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "scndthrddgreeburn") &&
             (isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "scndthrddgreeburn_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||

               isDateEqual(r, EXCLUSION, MEASURE_NAME, "scndthrddgreeburn_date", "crtclcrem_date")

               ))
           ||
           (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "szure") &&
             (isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "szure_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||

               isDateEqual(r, EXCLUSION, MEASURE_NAME, "szure_date", "crtclcrem_date")


               ))

           ||
           (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "acutegasthem") &&
             (isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "acutegasthem_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||


               isDateEqual(r, EXCLUSION, MEASURE_NAME, "acutegasthem_date", "crtclcrem_date")


               )

             )
           ||
           (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hest")
             &&
             (isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "hest_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||

               isDateEqual(r, EXCLUSION, MEASURE_NAME, "hest_date", "crtclcrem_date")


               )

             )
           ||
           (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "isst")
             &&
             (isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "isst_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||

               isDateEqual(r, EXCLUSION, MEASURE_NAME, "isst_date", "crtclcrem_date")
               )

             )
           ||
           (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "myin")
             &&
             (isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "myin_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||

               isDateEqual(r, EXCLUSION, MEASURE_NAME, "myin_date", "crtclcrem_date")


               ))

           ||
           (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "toxemrg")
             &&
             (isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "toxemrg_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||

               isDateEqual(r, EXCLUSION, MEASURE_NAME, "toxemrg_date", "crtclcrem_date")

               ))
           ||
           (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "trau") &&
             (isDuringEncounterEDvisit(r, EXCLUSION, MEASURE_NAME, "trau_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||

               isDateEqual(r, EXCLUSION, MEASURE_NAME, "trau_date", "crtclcrem_date")

               )

             )
           ||
           BackTracking(r, EXCLUSION, MEASURE_NAME, CRA_list)
       )
     }


  def getMet(intermediateA:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {

    intermediateA.filter(r =>
      (

        !r.isNullAt("rptsrmlc")
          &&
          (
            (isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "rptsrmlc_date", "ed_visit_arrival_date", "ed_visit_departure_date")
              ||

              isDateEqual(r, MET, MEASURE_NAME, "rptsrmlc_date", "crtclcrem_date")
              )
              &&
              isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "rptsrmlc_date", "serlact_date")
            )
        )
    )
  }



  def BackTracking(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {


    for (x <- CRA.value) {
      if (x != "") {
        val back_data = x.split("~")
        val patientid = back_data(0);
        val element = back_data(1);
        val element_date = dateUtility.dateTimeParse(back_data(2));


        if (
          element == "1"
            &&
            (
              (
                !r.isNullAt("ed_visit_arrival_date") &&
                  (
                    r.getDateTime("ed_visit_arrival_date").equals(element_date)
                      ||
                      r.getDateTime("ed_visit_arrival_date").minusHours(6).equals(element_date)
                      ||
                      (
                        element_date.isBefore(r.getDateTime("ed_visit_arrival_date"))
                          &&
                          element_date.isAfter(r.getDateTime("ed_visit_arrival_date").minusHours(6))

                        )
                    )
                )
                ||
                (
                  !r.isNullAt("crtclcrem_date") &&
                    (
                    r.getDateTime("crtclcrem_date").equals(element_date)
                      ||
                      r.getDateTime("crtclcrem_date").minusHours(6).equals(element_date)
                      ||
                      (
                        element_date.isBefore(r.getDateTime("crtclcrem_date"))
                          &&
                          element_date.isAfter(r.getDateTime("crtclcrem_date").minusHours(6))

                        )
                    )
                  )
              )
        )
        {
          return true;
        }
      }

    }
    return false

  }

  def getBackTrackingList(rdd: CassandraTableScanRDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement: String, backtrackelement_date: String): List[String] = {

    val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).distinct().collect().toList

    val IPPFilterExclusionRDD = rdd.filter(x => (ipp_patient_list.contains(x.columnValues(2))))

    var CRA = IPPFilterExclusionRDD.map(x =>
      if (!x.isNullAt("patientuid")
        && !x.isNullAt(backtrackelement) && !x.isNullAt(backtrackelement_date)) {
        x.getString("patientuid") + "~" + x.getString(backtrackelement) + "~" + x.getString(backtrackelement_date)
      }
      else ""
    )
      .collect()
      .toList

    return CRA;
  }
}