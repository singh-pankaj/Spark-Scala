package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.measureComputation.qppMeasures.ACEP116._


import com.figmd.janus.util._
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP65 extends MeasureUtility with Measure{

  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    val CRA = getBackTrackingList(rdd, ippRDD, "anmefoph", "anmefoph_date");
    val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)

    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,startDate:Date,endDate:Date,CRA_list: Broadcast[List[String]],MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getinterRDD(ippRDD,exclusionRDD)
    intermediateA.cache()
    // Filter Met
    //met
    val metRDD = getMet(intermediateA,MEASURE_NAME)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediateA,metRDD)
    notMetRDD.cache()


    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }
      // Filter IPP
      def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
        rdd
          .filter(r =>

            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&
              (
                isAgeBetween(r, IPP, MEASURE_NAME, "dob", "encounterdate", 3, 19) &&
                  (
                    checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1") ||
                      // checkElementPresent(r, IPP, MEASURE_NAME, "hoobcain")|| //Element NOt Found
                      checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") ||
                      //checkElementPresent(r, IPP, MEASURE_NAME, "prcaesofvi0to17")||
                      checkElementPresent(r, IPP, MEASURE_NAME, "fain") ||
                        checkElementPresent(r, IPP, MEASURE_NAME, "diseobca") ||
                      checkElementPresent(r, IPP, MEASURE_NAME, "ippexm")
                    )
                  &&
                  // checkElementPresent(r, IPP, MEASURE_NAME, "uprein")&&
                  isDateEqual(r, IPP, MEASURE_NAME, "acph_date", "encounterdate")

                )

          )
      }


      /*val CRA = getBackTrackingList(rdd, ippRDD, "anmefoph", "anmefoph_date");

      val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)*/

      //exclusion

      //exclusion

  def getExclusionRdd(ippRDD:RDD[CassandraRow],startDate:Date,endDate:Date,CRA_list: Broadcast[List[String]],MEASURE_NAME:String): RDD[CassandraRow] = {
    ippRDD.filter(r =>
      checkElementPresent(r, EXCLUSION, MEASURE_NAME, "anmefoph")
        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohofohoca") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohecafafohoca")
          ) /*|| //Element not Found IN Cassendra
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "cocoforeco")&&
                isElementDateStartAfterStartOfWithInDays(r, EXCLUSION, MEASURE_NAME, "cocoforeco_date", "encounterdate", 3)
              )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ant_medrsn") &&
                isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "ant_medrsn_date", startDate, endDate)
             )*/
        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hocaam")
          )
        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hspsv") &&
            isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hspsv_date", startDate, endDate)
          )
        /*||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "abiotcs") && //abiotcs //abiotcs_date
            isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "abiotcs_date", startDate, endDate)
          )*/
        ||
        (
          BackTracking(r, EXCLUSION, MEASURE_NAME, CRA_list)
          )
    )
  }


  def getMet(intermediateA:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateA.filter(r =>
      (
        (
          checkElementPresent(r, MET, MEASURE_NAME, "grastte") &&
            isDateBetweenStartBeforeEndAndStartAfterEnd(r, MET, MEASURE_NAME, "amvi_copy_951_date", "grastte_date", 3, 3)
          )
          ||
          (
            checkElementPresent(r, MET, MEASURE_NAME, "grpastp") &&
              isDateBetweenStartBeforeEndAndStartAfterEnd(r, MET, MEASURE_NAME, "grpastp_date", "acph_date", 3, 3)
            )
          ||
          (
            checkElementPresent(r, MET, MEASURE_NAME, "grpastp") &&
              isDateBetweenStartBeforeEndAndStartAfterEnd(r, MET, MEASURE_NAME, "acto_date", "acph_date", 3, 3)
            )

        )
    )
  }


  def BackTracking(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {
    val flag = false;

    for (x <- CRA.value) {
      if (x != "") {
        //println(r.getString("visituid") + ">>>" + x)
        val back_data = x.split("~")
        val patientid = back_data(0);
        val anmefoph_element = back_data(1);
        val anmefoph_date =dateUtility.dateTimeParse(back_data(2));



        if ((!r.isNullAt("encounterdate") )
          && ((r.getString("patientuid").equals(patientid) || r.getString("patientuid") == patientid)
          &&
          ( anmefoph_element == "1" )


          )
        )
        {
          return true;
        }

      }

    }

    return flag;

  }

  def getBackTrackingList(rdd: CassandraTableScanRDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement2: String): List[String] = {

    val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).distinct().collect().toList

    val IPPFilterExclusionRDD = rdd.select("patientuid",backtrackelement1,backtrackelement2).filter(x => (ipp_patient_list.contains(x.columnValues(2))))

    var CRA = IPPFilterExclusionRDD.map(x =>
      if (!x.isNullAt("patientuid")
        && !x.isNullAt(backtrackelement1) && !x.isNullAt(backtrackelement2)) {
        x.getString("patientuid") + "~" + x.getString(backtrackelement1) + "~" + x.getString(backtrackelement2)
      }
      else ""
    )
      .collect()
      .toList

    return CRA;
  }
}

