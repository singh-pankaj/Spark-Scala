package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP326 extends MeasureUtility with Measure {

   // Logic for measure refresh
  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {
    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,startDate,endDate,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getinterRDD(ippRDD,exclusionRDD)
    intermediateA.cache()

      //Filter Met
    val metRDD = getMet(intermediateA,MEASURE_NAME)
    metRDD.cache()
    //for Exception B required
    val intermediateB =  getinterRDD(intermediateA,metRDD)
    // Filter Exceptions
    val exceptionRDD = getException(intermediateB,MEASURE_NAME)
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediateB,exceptionRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }
      // Filter IPP
      def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
        rdd
          .filter(r =>
            (
              isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18) &&

                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "homehealthser") ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "caseinlorefa") ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "infv") ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "nursefacvisit") ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1")
                  )
              )
              &&
              (
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "nonval_af") &&
                    isDateEqual(r, IPP, MEASURE_NAME, "nonval_af_date", "encounterdate")
                  ) &&
                  (
                    checknull(r, IPP, MEASURE_NAME, "eddeptvist_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "inf_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "domrsthmvst_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "ov_thmdmod95") ||
                      checknull(r, IPP, MEASURE_NAME, "hmhlthsrvc_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "nrsnfcltvst_tm")
                    ) &&
                  (
                    checknull(r, IPP, MEASURE_NAME, "telehealth")
                    )


                )

          )

      }

      //Exclusion

  def getExclusionRdd(ippRDD:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    ippRDD.filter(r =>

      (
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "pneumonia") &&
            isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "pneumonia_date", "encounterdate")
          )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hyprthyrodsm") &&
              isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "hyprthyrodsm_date", "encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "preg") &&
              isDateEqual(r, EXCLUSION, MEASURE_NAME, "preg_date", "encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "casu_1") &&
              isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "casu_1_date", "encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "trns_rev_af") &&
              isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "trns_rev_af_date", "encounterdate")
            )
        )
        ||
        (
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hoorpaca") &&
              isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hoorpaca_date", startDate, endDate)
            )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "cmrt_cr_g") &&
                isDateEqual(r, EXCLUSION, MEASURE_NAME, "cmrt_cr_g_date", "encounterdate")
              )
          )
        ||
        (
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "cha2ds2_vasc_hcpcs") &&
              isDateEqual(r, EXCLUSION, MEASURE_NAME, "cha2ds2_vasc_hcpcs_date", "encounterdate")

            )
            ||
            (
              chkValueRangeLessorEqual(r, EXCLUSION, MEASURE_NAME, "cha2ds2_vasc_score", 1) &&
                isDateEqual(r, EXCLUSION, MEASURE_NAME, "cha2ds2_vasc_score_date", "encounterdate")
              )
          /*|| //Do Not REMOVED ***********
              (
              ChkElementChadscore326(r, IPP, MEASURE_NAME,"dob","encounterdate","hefa","hyper","dibtmelts","prirstrk","vsclr_disease","sex")<=1

               )*/

          )
    )

  }


  def getMet(intermediateA:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateA.filter(r => (

      (
        checkElementPresent(r, MET, MEASURE_NAME, "prs_war_med") &&
          isDateEqual(r, IPP, MEASURE_NAME, "prs_war_med_date", "encounterdate")
        )
        ||
        (
          checkElementPresent(r, MET, MEASURE_NAME, "prs_war_antcog_med") &&
            isDateEqual(r, IPP, MEASURE_NAME, "prs_war_antcog_med_date", "encounterdate")

          )
      ))
  }





  def getException(intermediateB:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateB.filter(r => (

      (
        checkElementPresent(r, MET, MEASURE_NAME, "prs_war_medrsn") &&
          isDateEqual(r, IPP, MEASURE_NAME, "prs_war_medrsn_date", "encounterdate")
        )
        ||
        (
          checkElementPresent(r, MET, MEASURE_NAME, "prs_war_patrsn") &&
            isDateEqual(r, IPP, MEASURE_NAME, "prs_war_patrsn_date", "encounterdate")
          )
        ||
        (
          checkElementPresent(r, MET, MEASURE_NAME, "af_sys_rsn") &&
            isDateEqual(r, IPP, MEASURE_NAME, "af_sys_rsn_date", "encounterdate")
          )


      ))
  }

}