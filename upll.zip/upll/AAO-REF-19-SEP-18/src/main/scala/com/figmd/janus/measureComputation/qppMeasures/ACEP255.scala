package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}
import org.apache.spark.rdd.RDD
//import com.figmd.janus.measureComputation.qppMeasures.ACEP146.{MEASURE_NAME, saveToWebDM}

import com.figmd.janus.measureComputation.qppMeasures.ACEP255.isDuringMeasurementPeriod
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession

object ACEP255 extends MeasureUtility with Measure {

  var MEASURE_NAME = "M255"
  @transient lazy val postgresUtility=new PostgreUtility()
  // Logic for measure refresh
  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD=sparkSession.sparkContext.emptyRDD[CassandraRow]
    //met
    val metRDD = getMet(ippRDD, startDate: Date, endDate: Date,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    val intermediate = getinterRDD(ippRDD,metRDD)
    val exceptionRDD =getexceptionRDD(intermediate,startDate: Date, endDate: Date,MEASURE_NAME)
    exceptionRDD.cache()
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediate,exceptionRDD)
    notMetRDD.cache()

    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }

  // Filter IPP
  def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    rdd
      .filter(r =>

        (
          isAgeBetween(r, IPP, MEASURE_NAME, "dob", "encounterdate", 14, 51)

          )
          &&
          (
            checkElementValue(r, IPP, MEASURE_NAME, "sex", 2)
              &&
              (
                checkElementPresent(r, IPP, MEASURE_NAME, "prgncompl") &&
                  isDateEqual(r, IPP, MEASURE_NAME, "prgncompl_date", "encounterdate")
                )
              &&
              (
                checkElementPresent(r, IPP, MEASURE_NAME, "rh_negtv") &&
                  isDateEqual(r, IPP, MEASURE_NAME, "rh_negtv_date", "encounterdate")
                )
            )
          &&
          (
            checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "ccv")
            ) &&
          (
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "pos2") &&
                isDateEqual(r, IPP, MEASURE_NAME, "pos2_date", "emdevi_1_date")
              )
              ||
              (
                checkElementPresent(r, IPP, MEASURE_NAME, "pos2") &&
                  isDateEqual(r, IPP, MEASURE_NAME, "pos2_date", "ccv_date")
                )
            )

      )

  }

      //met

  def getMet(ippRDD:RDD[CassandraRow], startDate: Date, endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    ippRDD.filter(r =>
      (
        checkElementPresent(r, MET, MEASURE_NAME, "rh_immuneordr") &&
          isDuringMeasurementPeriod(r, MET, MEASURE_NAME, "rh_immuneordr_date", startDate, endDate)
        )
        ||
        (
          (
            checkElementPresent(r, MET, MEASURE_NAME, "rh_immuneodrd") &&
              ((isDateEqual(r, MET, MEASURE_NAME, "rh_immuneodrd_date", "edv_date") ||
                isDateEqual(r, MET, MEASURE_NAME, "rh_immuneodrd_date", "ccv_date")) &&
                isDateEqual(r, MET, MEASURE_NAME, "rh_immuneodrd_date", "pos2_date"))
            )
          )
    )
  }

  def getexceptionRDD(intermediateRDD:RDD[CassandraRow],startDate: Date, endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateRDD.filter(r =>
      (
        checkElementPresent(r, EXCEPTION, MEASURE_NAME, "rh_patrsn") &&
          isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "rh_patrsn_date", startDate, endDate)
        ) ||
        (
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "rhogam_patrsn") &&

              (isDateEqual(r, MET, MEASURE_NAME, "rhogam_patrsn_date", "edv_date") ||
                isDateEqual(r, MET, MEASURE_NAME, "rhogam_patrsn_date", "ccv_date"))
            )
            &&
            (
              checkElementPresent(r, EXCEPTION, MEASURE_NAME, "rhogam_patrsn") &&
                isDateEqual(r, EXCEPTION, MEASURE_NAME, "rhogam_patrsn_date", "pos2_date")
              )
          ) ||
        (
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "rho12wk") &&
              (isDateEqual(r, MET, MEASURE_NAME, "rho12wk_date", "edv_date") ||
                isDateEqual(r, MET, MEASURE_NAME, "rho12wk_date", "ccv_date"))
            ) &&
            (
              checkElementPresent(r, EXCEPTION, MEASURE_NAME, "rho12wk") &&
                isDateEqual(r, EXCEPTION, MEASURE_NAME, "rho12wk_date", "pos2_date")
              )
          )

    )
  }

}
