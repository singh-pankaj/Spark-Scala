package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.Measure
import com.figmd.janus.util.MeasureUtility
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP76 extends MeasureUtility with Measure {

  /* var MEASURE_NAME= "M76"
   @transient lazy val postgresUtility=new PostgreUtility()*/
  // Logic for measure refresh
  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {



    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //met
    val metRDD = getMet(ippRDD,MEASURE_NAME)
    metRDD.cache()
    // Filter Intermediate
    var intermediateRDD = getSubtractRDD(ippRDD,metRDD)
    intermediateRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not meate
    val notMetRDD =  getSubtractRDD(intermediateRDD,metRDD)
    // notMetRDD.cache()


    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }
  // Filter IPP
  def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    rdd
      .filter(r =>

        //isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&
        (
          checkElementPresent(r, MET, MEASURE_NAME, "cevecain") &&
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "cevecain_date", startDate, endDate)
          )
      )
  }

  def getMet(ippRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    ippRDD.filter(r => (
      (
        checkElementPresent(r, MET, MEASURE_NAME, "mastbate") &&
          isDateEqual(r, IPP, MEASURE_NAME, "mastbate_date", "cevecain_date")
        )
        ||
        (
          checkElementPresent(r, MET, MEASURE_NAME, "max_strlbarr_tech") &&
            isDateEqual(r, IPP, MEASURE_NAME, "max_strlbarr_tech_date", "cevecain_date")
          )

      ))
  }


  def getException(intermediateRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateRDD.filter(r => (
      (
        checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mastbate") &&
          isDateEqual(r, IPP, MEASURE_NAME, "mastbate_date", "cevecain_date") &&
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "maxsterile_medrsn") &&
          isDateEqual(r, IPP, MEASURE_NAME, "maxsterile_medrsn_date", "cevecain_date")
        )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "max_strlbarr_tech") &&
            isDateEqual(r, IPP, MEASURE_NAME, "max_strlbarr_tech_date", "cevecain_date") &&
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "doc_max_rsnnot") &&
            isDateEqual(r, IPP, MEASURE_NAME, "doc_max_rsnnot_date", "cevecain_date")
          )
      ))
  }


}