package com.figmd.janus.measureComputation.nonQppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, Measure}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import org.apache.spark.rdd.RDD


object ACEP31 extends MeasureUtility with Measure {

  //var MEASURE_NAME = "M31"


  def refresh(sparkSession: SparkSession,rdd:CassandraTableScanRDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getinterRDD(ippRDD,exclusionRDD)
    intermediateA.cache()
    // Filter Met
    //met
    val metRDD = getMet(intermediateA,MEASURE_NAME)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not meate
    val notMetRDD =  getinterRDD(intermediateA,metRDD)
    notMetRDD.cache()


    saveToWebDM1(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }

  // Filter IPP
  def getIpp(rdd:CassandraTableScanRDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    rdd
      .filter(r =>
        (
          isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)
            &&
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "edv") ||
                checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem")
              )
            &&
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "inserifc") &&
                (
                  isDuringEncounterEDvisit(r, IPP, MEASURE_NAME, "inserifc_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                    ||
                    isDateEqual(r, IPP, MEASURE_NAME, firstDate = "inserifc_date", compareDate = "crtclcrem_date")

                  )

              )
            &&
            (checkElementPresent(r, IPP, MEASURE_NAME, "hosadmobs") &&
              (
                isDuringEncounterEDvisit(r, IPP, MEASURE_NAME, "hosadmobs_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  isDateEqual(r, IPP, MEASURE_NAME, firstDate = "hosadmobs_date", compareDate = "crtclcrem_date")
                )

              )
          )
      )
  }


      //exclusion
      def getExclusionRdd(ippRDD:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {

        ippRDD.filter(r =>

          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "inserifc") &&
            (
              isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "inserifc_date", "ed_visit_arrival_date")
                ||
                isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "inserifc_date", "crtclcrem_date")

              )

            ||

            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ifc") &&
              (
                isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "ifc_date", "ed_visit_arrival_date")
                  ||
                  isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "ifc_date", "crtclcrem_date")
                )

        )
      }


     def getMet(intermediateA:RDD[CassandraRow],MEASURE_NAME:String): RDD[CassandraRow] = {

       intermediateA.filter(r => (
         (
           checkElementPresent(r, MET, MEASURE_NAME, "uriret_obst") &&
             (
               isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "uriret_obst_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                 ||
                 isDateEqual(r, MET, MEASURE_NAME, firstDate = "uriret_obst_date", compareDate = "crtclcrem_date")

               )

           )
           ||
           (
             checkElementPresent(r, MET, MEASURE_NAME, "measuriout") &&
               (
                 isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "measuriout_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                   ||
                   isDateEqual(r, MET, MEASURE_NAME, firstDate = "measuriout_date", compareDate = "crtclcrem_date")

                 )

             )
           ||
           (
             checkElementPresent(r, MET, MEASURE_NAME, "preusessp") &&
               (
                 isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "preusessp_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                   ||
                   isDateEqual(r, MET, MEASURE_NAME, firstDate = "preusessp_date", compareDate = "crtclcrem_date")

                 )

             )
           ||
           (
             checkElementPresent(r, MET, MEASURE_NAME, "opnsacperi_wounds")
               &&
               (
                 isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "opnsacperi_wounds_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                   ||
                   isDateEqual(r, MET, MEASURE_NAME, firstDate = "opnsacperi_wounds_date", compareDate = "crtclcrem_date")

                 )

             )
           ||

           (
             checkElementPresent(r, MET, MEASURE_NAME, "immob")
               &&
               (
                 isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "immob_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                   ||
                   isDateEqual(r, MET, MEASURE_NAME, firstDate = "immob_date", compareDate = "crtclcrem_date")

                 )

             )
           ||
           (
             checkElementPresent(r, MET, MEASURE_NAME, "comfrtm") &&
               (
                 isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "comfrtm_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                   ||
                   isDateEqual(r, MET, MEASURE_NAME, firstDate = "comfrtm_date", compareDate = "crtclcrem_date")

                 )

             )
           ||
           (
             checkElementPresent(r, MET, MEASURE_NAME, "insspeind") &&
               (
                 isDuringEncounterEDvisit(r, MET, MEASURE_NAME, "insspeind_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                   ||
                   isDateEqual(r, MET, MEASURE_NAME, firstDate = "insspeind_date", compareDate = "crtclcrem_date")

                 )
             )
         )
       )
     }



}