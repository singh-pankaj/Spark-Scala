package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.measureComputation.cmsMeasures.ACEP146.{BackTracking, EXCLUSION, MEASURE_NAME}
import com.figmd.janus.measureComputation.qppMeasures.ACEP116.isDateStartsBeforeOrConcurrentWithStartOf
import com.figmd.janus.{DataMartCreator, Measure}


import com.figmd.janus.util._
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import com.datastax.spark.connector.{CassandraRow, _}

object ACEP116 extends MeasureUtility with Serializable with Measure {


  def refresh(sparkSession: SparkSession, rdd: CassandraTableScanRDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

    var columnRef = getFiledList(MEASURE_NAME)
    var patientHistoryRDD =  sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart_history"),
      prop.getProperty("patientHistory")).select(columnRef(3),columnRef(71),columnRef(72))

    // Filter IPP
    val ippRDD = getIpp(rdd, startDate, endDate, MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    // BAcktracking RDD for Exclusion
    val CRA = getBackTrackingList(rdd, ippRDD, "antibiotics_dis", "antibiotics_dis_date");
    val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)


    val exclusionRDD = getExclusionRdd(ippRDD, CRA_list, startDate: Date, endDate: Date,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA = getinterRDD(ippRDD,exclusionRDD)
    intermediateA.cache()
    // Filter Met
    //met
    val metRDD = getMet(intermediateA, MEASURE_NAME)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not meate
    val notMetRDD = getinterRDD(intermediateA, metRDD)
    notMetRDD.cache()


    saveToWebDM1(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }

  // Filter IPP
  def getIpp(rdd: CassandraTableScanRDD[CassandraRow], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {
    rdd.filter(r =>
      (

        isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&
          (

            (
              isAgeBetween(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18, 65)
              )
              &&
              (
                checkElementPresent(r, IPP, MEASURE_NAME, "diseobca") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "ihopsobs") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "hoouclvi") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "hohese") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "anwevi_1") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "ippexm") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "clvi") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "wrk_mntdis") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "prvmed_em") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "hm_vst") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "obs_cr_dis") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "offvstg")
                )
              &&
              (

                checkElementPresent(r, IPP, MEASURE_NAME, "actbr")
                  &&
                  isDateEqual(r, IPP, MEASURE_NAME, "actbr_date", "encounterdate")
                )
            )
        )
    )
  }
/*

  val CRA = getBackTrackingList(rdd, ippRDD, "antibiotics_dis", "antibiotics_dis_date");

  val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)
*/


  // Filter Exclusions
 def getExclusionRdd(ippRDD: RDD[CassandraRow],CRA_list:Broadcast[List[String]], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {
   ippRDD.filter(r =>
     (
       checkElementPresent(r, EXCLUSION, MEASURE_NAME, "bctinf") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "otitsmda") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "actsin") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "acph") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "acto") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "chrsin") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "infctn_phrnx_lrynx_tnsls_adnds") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "imptgo") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "pneumonia") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "goinanvedi") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "infctn_kdny") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "asymphiv") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "cysfib") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "immndefcncy") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "mlgnancyneoplsm") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "chrncbrnchts") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "emphy") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "bronchiectasis") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "extrnsallrgcalvlts") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "chrobstrctvasthma") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "chrarwyobstrctn") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "pneomconosis") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "tubrclosis") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "infctn_sknstph") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "cycts_uti") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "acnee") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "actlymphdnts") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "infctn_cllts_mstcts_bone") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "intstnlinfctn") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "prtusis") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "lymdses") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "utinfc23") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "indioffereor") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "syph_1") ||
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "chla")
       )
       ||
       (
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "meex") &&
           isDateEqual(r, EXCLUSION, MEASURE_NAME, "meex_date", "encounterdate")
         )
       ||
       (
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hose_1") &&
           isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hose_1_date", startDate, endDate)
         )
       ||
       (
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hospiceservices")
         )
       ||
       (
         checkElementPresent(r, EXCLUSION, MEASURE_NAME, "detoadtohoin") &&
           isElementDateStartAfterStartOfWithInDays(r, EXCLUSION, MEASURE_NAME, "detoadtohoin_date", "encounterdate", 1)
         )
       ||
       (
         BackTracking(r, EXCLUSION, MEASURE_NAME, CRA_list)
         )
   )
 }



  // Filter Met

  def getMet(intermediateA: RDD[CassandraRow],MEASURE_NAME: String): RDD[CassandraRow] = {
    intermediateA.filter(
      r => (
        (
          (
            checkElementPresent(r, MET, MEASURE_NAME, "antbtcmt") &&
              isElementDateStartAfterStartOfWithInDays(r, MET, MEASURE_NAME, "antbtcmt_date", "actbr_date", 3)
            )
            ||
            !(
              checkElementPresent(r, MET, MEASURE_NAME, "antibiotics_dis") &&
                isElementDateStartAfterStartOfWithInDays(r, MET, MEASURE_NAME, "antibiotics_dis_date", "actbr_date", 3)
              )
          )
          &&
          !(
            checkElementPresent(r, MET, MEASURE_NAME, "anme_2") &&
              isElementDateStartAfterStartOfWithInDays(r, MET, MEASURE_NAME, "anme_2_date", "actbr_date", 3)
            )

        )

    )
  }



  def BackTracking (r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]] ): Boolean = {
  val flag = false;

  for (x <- CRA.value) {
  if (x != "") {
  //println(r.getString("visituid") + ">>>" + x)
  val back_data = x.split ("~")
  val patientid = back_data (0);
  val antibiotics_dis_element = back_data (1);
  val antibiotics_dis_date = dateUtility.dateTimeParse (back_data (2) );


  if ((! r.isNullAt ("encounterdate") )
  && ((r.getString ("patientuid").equals (patientid) || r.getString ("patientuid") == patientid)
  && (
  (antibiotics_dis_element == "1"
  && (
  (r.getDateTime ("encounterdate").equals (antibiotics_dis_date) ) ||
  (r.getDateTime ("encounterdate").minusDays (30).equals (antibiotics_dis_date) ) ||
  (r.getDateTime ("encounterdate").minusDays (30).isAfter (antibiotics_dis_date) ) &&
  (r.getDateTime ("encounterdate").isBefore (antibiotics_dis_date) )
  )
  )

  )

  )

  ) {

  return true;
}

}

}

  return flag;

}

  def getBackTrackingList (patientHistoryRDD: CassandraTableScanRDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement2: String): List[String] = {

  val ipp_patient_list = ippRDD.map (x => x.columnValues (3) ).distinct ().collect ().toList

  val IPPFilterExclusionRDD = patientHistoryRDD.select ("patientuid", backtrackelement1, backtrackelement2).filter (x => (ipp_patient_list.contains (x.columnValues (2) ) ) )

  var CRA = IPPFilterExclusionRDD.map (x =>
  if (! x.isNullAt ("patientuid")
  && ! x.isNullAt (backtrackelement1) && ! x.isNullAt (backtrackelement2) ) {
  x.getString ("patientuid") + "~" + x.getString (backtrackelement1) + "~" + x.getString (backtrackelement2)
}
  else ""
  )
  .collect ()
  .toList

  return CRA;
}
}


