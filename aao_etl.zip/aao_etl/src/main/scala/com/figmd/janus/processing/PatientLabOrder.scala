package com.figmd.janus.processing

import com.figmd.janus.criteria.{ProcessingCriteria, ValidationCriteria}
import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
class PatientLabOrder (LabOrderPath : String){

  def CachePatientLabOrder(spark: SparkSession): DataFrame = {

      import spark.implicits._
      val processing = new ProcessingCriteria(spark)
      val validations = new ValidationCriteria(spark)

      CommonFunc.loggert("Reading files and applying headers")

      //temp_path = "file:///home/dev/Akshay/PatientLabOrder_testfile_bckup.csv"
      val CachePatientLabOrderDF = CommonFunc.readFile(LabOrderPath,spark)

      val CachePatientLabOrderValidations = CachePatientLabOrderDF
        .transform(validations.removeDuplicateRecords(List("PatientUid","OrderCodeUid","OrderName","OrderDate")))
        .transform(validations.removeDuplicateRecords(List("PatientUid","OrderName","OrderDate")))
/*
        .transform(validations.orderCategoryNotFound)
        .transform(validations.orderCodeNameNotFound)
        .transform(validations.orderDateNotFound)
        .transform(validations.patientNotFound)
        .transform(validations.resultInterpretationCodeOrTextNotFound)
        .transform(validations.targetSiteCodeAndTextNotFound)
*/

      val CleanedRecords = CachePatientLabOrderDF.filter(row=>validations.checkNull(row,"patientid","OrderDate"))


      CachePatientLabOrderValidations
        .groupBy("PatientId")
        .agg(collect_list(struct("Description","OrderDate","RangeUnits","CustomName","RangeFrom",
          "RangeTo","ListOrder","Units","OrderGroupId","PracticeCode","ReferenceObservationRange","ResultValue",
          "ResultObservationStatus","SpecimenId","LaboratoryID","PatientLabOrderKey" )).as("allcols")).toJSON
        .select(get_json_object($"value", "$.PatientId").as("PatientId"),
          get_json_object($"value", "$.allcols").as("LabOrder"))

    }

}
