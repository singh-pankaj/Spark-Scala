package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{ValidationCriteria, cachePatientInsurancefunctions}
import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientInsurance(InsurancePath : String) {

def cachePatientinsuranceprocessing(spark : SparkSession,
                                    MasterInsurance : DataFrame) : Option[DataFrame] ={
  try {

    val validations = new ValidationCriteria(spark)
    val InsuranceObj = new cachePatientInsurancefunctions(spark, MasterInsurance)

    CommonFunc.loggert("Reading files and applying headers")
    var CachePayer = CommonFunc.readFile(InsurancePath,spark)

    CommonFunc.loggert("applying validations on PatientInsurance files")

    val CachePayerValidations = CachePayer
      .transform(validations.invalidPayerIdFound)
      .transform(validations.invalidPolicyIdFound)
/*
      .transform(validations.patientNotFound)
      //.transform(validations.effectiveDateNotFound)
*/
      val CleanedRecords = CachePayerValidations.filter(row=>validations.checkNull(row,"patientid","InsurancePlan"))

    CommonFunc.loggert("applying validations on PatientInsurance files successful")

    val CachePayerTransformations = CachePayerValidations
      .transform(InsuranceObj.InsuredRelationToPatientCode)

    val CachePayer2 = CachePayerTransformations.groupBy("PatientId","PracticeUid")
      .agg(collect_list(struct("PayerState", "Insurance_Active", "EndDateOfInsurance", "InsurancePlan"
        , "PayerID", "IsInsuredSameAsGuarantor", "BillingInsurance", "InsuredPersonId", "PatientId", "PayerCity"
        , "MasterInsuredRelationToPatientText", "InsuranceOrder", "StartDateOfInsurance", "MasterInsuredRelationToPatientCode"
        , "PayerZip", "InsuranceCompany", "DocumentationDate", "InsuredRelationToPatientCode", "InsuredRelationToPatientText"
        , "PracticeUid", "PayerKey", "PolicyID", "InsuranceGroup")).as("Insurance"))

    Some(CachePayer2)
  }
  catch {
    case ex: FileNotFoundException => {
      println(s"File not found")
      None
    }
    case unknown: Exception => {
      println(s"Unknown exception: $unknown")
      None
    }
  }
}
}
