package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{CacheImmunizationFunctions, ValidationCriteria}
import com.figmd.janus.util.{CommonFunc, DataFrameUtils, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientImmunization(ImmunizationPath: String) {

  def ImmunizationProcessing(spark: SparkSession,
                             mappingpracticecommondatamaster: DataFrame,
                             MappingPracticeCommonDataMasterMedicationRoute: DataFrame,
                             MappingPracticeProcedure: DataFrame,
                             MappingPracticeProblem: DataFrame,
                             MappingPracticeCommonDataMaster: DataFrame,
                             DemoGraphicsDF: DataFrame,
                             conf: Config) {
    import spark.implicits._

    try {

      val patientImmunization = new CacheImmunizationFunctions(spark, mappingpracticecommondatamaster, MappingPracticeCommonDataMasterMedicationRoute, MappingPracticeProcedure, MappingPracticeProblem, MappingPracticeCommonDataMaster)
      val dfu = new DataFrameUtils(spark, conf)
      val validations = new ValidationCriteria(spark)

      val tableName = conf.getString("db_tb_Immunization")
      val tempTableName = conf.getString("db_temp_immunization")

      CommonFunc.loggert("Reading files and applying headers")

      //Read file for CachePatientImmunization
      val CachePatientImmunization = CommonFunc.readFile(ImmunizationPath, spark)
        .withColumn("ImmuStartDate", to_timestamp($"ImmuStartDate", "MM/dd/yyyy HH:mm:ss"))

      val addPatientUid = CachePatientImmunization.as("df1").join(DemoGraphicsDF.as("df2")
        , Seq("PatientId", "PracticeUid"))
        .select($"df1.*", $"df2.PatientUid")

      CommonFunc.loggert("applying validations on PatientImmunization files")

      val cacheImmunizationValidations = addPatientUid
        .transform(validations.removeDuplicateRecords(List("Patientuid", "ImmunizationCodeUid", "ImmunizationName", "ImmuStartDate")))
        .transform(validations.removeDuplicateRecords(List("PatientUid", "ImmunizationCode", "ImmunizationCategory", "ImmuStartDate")))
        .transform(validations.removeDuplicateRecords(List("PatientUid", "ImmunizationName", "ImmuStartDate")))
        .transform(validations.invalidNPIFound)

      /*
        .transform(validations.immunizationCodeAndImmunizationNameNotFound)
        .transform(validations.immunizationNameAndImmunizationCategoryNotFound)
        .transform(validations.immuStartDateNotFound)
        .transform(validations.immunizationCodeNotFound)
        .transform(validations.medicationIndicationProblemCodeNotFound)
        .transform(validations.medicationStatusTextOrMedicationStatusCodeNotMapped)
        .transform(validations.patientNotFound)
        */

      val CleanedRecords = cacheImmunizationValidations.filter(row=>validations.checkNull(row,"patientid","ImmunizationCode","ImmunizationName","ImmuStartDate"))

      CommonFunc.loggert("applying validations on PatientImmunization files successful")

      val transformImmunization = cacheImmunizationValidations
        .transform(patientImmunization.ImmunizationName)
        .transform(patientImmunization.ImmunizationCode)
        .transform(patientImmunization.MedicationRouteText)
        .transform(patientImmunization.MedicationRouteCode)
        .transform(patientImmunization.ProcedureText)
        .transform(patientImmunization.ProcedureCode)
        .transform(patientImmunization.MedicationIndicationProblemText)
        .transform(patientImmunization.MedicationIndicationProblemCode)
        .transform(patientImmunization.MedicationReactionProblemText)
        .transform(patientImmunization.MedicationReactionProblemCode)
        .transform(patientImmunization.MedicationReactionProblemSeverityText)
        .transform(patientImmunization.MedicationReactionProblemSeverityCode)
        .transform(patientImmunization.MedicationStatusText)
        .transform(patientImmunization.MedicationStatusCode)

      val getImmunizationPartitionsDF = dfu.getPatrtitions(transformImmunization, "ImmuStartDate", tableName)

      val allImmunizationData = dfu.getInsertUpdateAndNCDData(transformImmunization, getImmunizationPartitionsDF)
        .withColumn("Year", year($"ImmuStartDate"))
        .withColumn("Month", month($"ImmuStartDate"))

      HiveUtility.dfwritrtohiveVisit(allImmunizationData, tableName, spark, tempTableName)

    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
      }
    }

  }
}

