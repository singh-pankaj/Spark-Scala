package com.figmd.janus.criteria

import org.apache.spark.sql.functions.{broadcast,when}
import org.apache.spark.sql.{DataFrame, SparkSession}

class ProcessingCriteria(spark:SparkSession) {

  import spark.implicits._
  /**
    * Get MasterText and MasterCode from Lookup Table
    * @param TextColumn string
    * @param CodeColumn string
    * @param table Master lookup table
    */
  def getTextAndCode(TextColumn: String, CodeColumn:String,table: DataFrame)(df: DataFrame): DataFrame = {

    val masterText = "Master" + TextColumn
    val masterCode = "Master" + CodeColumn

    println("text : " + TextColumn)
    println("master text : " + masterText)
    println("code : " + CodeColumn)
    println("master code : " + masterCode)

    val getCode = broadcast(df)
      .as("df1").join(broadcast(table).as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.$TextColumn" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn(s"$masterCode",$"MappedValue1")
      .withColumn(s"$masterText",$"MappedValue2")
      .drop("MappedValue1","MappedValue2")

    println("join 1 complete")

    val getTextAndCode = broadcast(getCode)
      .as("df1").join(broadcast(table).as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.$CodeColumn" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn(s"$masterCode",when($"MappedValue1".isNull,$"$masterCode")
        .otherwise($"MappedValue1"))
      .withColumn(s"$masterText",when($"MappedValue2".isNull,$"$masterText")
        .otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")

    println("join 2 complete")

    getTextAndCode
  }

  def InsuredRelationToPatientCode(MasterInsurance: DataFrame)(df:DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(broadcast(MasterInsurance).as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.InsuredRelationToPatientCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.PayerId".as("MasterInsuredRelationToPatientCode")
        , $"df2.PayerId".as("MasterInsuredRelationToPatientText"))

  }




}

class CachePatientFamilyHistory(sparkSess : SparkSession, mappingpractivecommondatamasterrelationship : DataFrame, mappingpracticecommondatamaster :DataFrame, mappingpracticeproblem : DataFrame) {

  import sparkSess.implicits._

  def RelationshipToPatientCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpractivecommondatamasterrelationship.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.RelationshipToPatientCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterRelationshipToPatientCode")
        , $"df2.CodeDescription".as("MasterRelationshipToPatientText"))
  }


  def RelationshipToPatientText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.RelationshipToPatientText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedMasterRelationshipToPatientCode")
        , $"df2.CodeDescription".as("MappedMasterRelationshipToPatientText"))
      .withColumn("MasterRelationshipToPatientCode", when($"MappedMasterRelationshipToPatientCode".isNull, $"MasterRelationshipToPatientCode")
        .otherwise($"MappedMasterRelationshipToPatientCode"))
      .withColumn("MasterRelationshipToPatientText", when($"MappedMasterRelationshipToPatientText".isNull, $"MasterRelationshipToPatientText")
        .otherwise($"MappedMasterRelationshipToPatientText"))
      .drop("MappedMasterRelationshipToPatientCode", "MappedMasterRelationshipToPatientText")

  }

  def ProblemTypeCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemTypeCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterProblemTypeCode")
        , $"df2.CodeDescription".as("MasterProblemTypeText"))

  }

  def ProblemTypeText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemTypeText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedMasterProblemTypeCode")
        , $"df2.CodeDescription".as("MappedMasterProblemTypeText"))
      .withColumn("MasterProblemTypeCode", when($"MappedMasterProblemTypeCode".isNull, $"MasterProblemTypeCode")
        .otherwise($"MappedMasterProblemTypeCode"))
      .withColumn("MasterProblemTypeText", when($"MappedMasterProblemTypeText".isNull, $"MasterProblemTypeText")
        .otherwise($"MappedMasterProblemTypeText"))
      .drop("MappedMasterProblemTypeCode", "MappedMasterProblemTypeText")

  }

  def ProblemCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterProblemCode")
        , $"df2.CodeDescription".as("MasterProblemDescription"))

  }

  def ProblemDescription(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedMasterProblemCode")
        , $"df2.CodeDescription".as("MappedMasterProblemDescription"))
      .withColumn("MasterProblemCode", when($"MappedMasterProblemCode".isNull, $"MasterProblemCode")
        .otherwise($"MappedMasterProblemCode"))
      .withColumn("MasterProblemDescription", when($"MappedMasterProblemDescription".isNull, $"MasterProblemDescription")
        .otherwise($"MappedMasterProblemDescription"))
      .drop("MappedMasterProblemCode", "MappedMasterProblemDescription")

  }
}