package com.figmd.janus.util

import com.typesafe.config.Config
import org.apache.spark.sql.functions.{ltrim, month, rtrim, year}
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.Map
import scala.collection.immutable.ListMap

class DataFrameUtils(sparkSess: SparkSession, conf : Config) {

  import sparkSess.implicits._

  def sendPatientToHive(dfList: List[DataFrame]): Unit = {

    val PatientDF = dfList.tail.foldLeft(dfList.head)((accDF, newDF) => accDF.join(newDF
      , Seq("PatientId", "PracticeUid"))).withColumn("Year", year($"DOB"))
    val tempTableName = "figmdcdr_temp.patient"
    val TableName = conf.getString("db_tb_patient")
    HiveUtility.dfwritrtohivePatient(PatientDF, TableName, sparkSess, tempTableName)
  }

  def getlookupMap(tableName: String,section_header : DataFrame):Map[String,String]={

    //val ListTables = ReadTables.readtablesFromPostgres(spark)


    val invMap = section_header.filter(ltrim(rtrim($"sectionname")) === tableName).rdd
      .map(row => "_c" + row.getInt(2).toString -> row.getString(1).trim).collectAsMap()

    ListMap(invMap.toSeq.sortBy(_._1):_*)

  }

  def getInsertUpdateAndNCDData(df1: DataFrame,df2: DataFrame):DataFrame={

    val UpdateData = df1.as("df1").join(df2.as("df2")
      ,Seq("PatientId","PracticeUid","PatientUid"),"inner")
      .select($"df1.*")

    val NCDData = df2.as("df1").join(df1.as("df2")
      ,Seq("PatientId","PracticeUid","PatientUid"),"left_anti")
      .select($"df1.*")

    val InsertData = df1.as("df1").join(df2.as("df2")
      ,Seq("PatientId","PracticeUid","PatientUid"),"left_anti")
      .select($"df1.*")

    val AllData = UpdateData.union(NCDData).union(InsertData)

    AllData
  }

  def getVisitInsertUpdateAndNCDData(df1: DataFrame,df2: DataFrame):DataFrame={

    val PreviousPatient = df1.as("df1").join(df2.as("df2"),
      Seq("PatientId","PracticeUid","PatientUid"),"inner").select($"df1.*",$"df2.VisitUid")

    val newVisit = df1.as("df1").join(df2.as("df2"),
      Seq("PatientId","PracticeUid","PatientUid"),"left_anti").select($"df1.*")

    val tempData = newVisit.select("PatientId", "ServiceProviderNPI", "ServiceLocationName"
      , "EncounterStartDate").distinct()
      .withColumn("visitUid",CommonFunc.getNewUid())

    val tempVisitUid = tempData.persist()

    val CacheEncounter2 = newVisit.as("df1").join(tempVisitUid.as("df2"),$"df1.PatientId" === $"df2.PatientId"
      &&  $"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" && $"df1.ServiceLocationName" === $"df2.ServiceLocationName"
      && $"df1.EncounterStartDate" === $"df2.EncounterStartDate")
      .select($"df1.*",$"df2.VisitUid")
      .drop("dummy1","dummy2")

    val otherData = df2.as("df1").join(df1.as("df2"),
      Seq("PatientId","PracticeUid","PatientUid"),"left_anti").select($"df1.*")

    val AllData = PreviousPatient.union(CacheEncounter2).union(otherData)

    AllData
  }

  def getPatientDemoInsertUpdateAndNCDData(df1: DataFrame,df2: DataFrame):DataFrame={

    val UpdateData = df1.as("df1").join(df2.as("df2"),
      Seq("PatientId","PracticeUid","PatientUid"),"inner").select($"df1.*",$"df2.PatientUid")
      .drop("Year")

    val InsertData =  df1.as("df1").join(df2.as("df2"),
      Seq("PatientId","PracticeUid","PatientUid"),"left_anti").select($"df1.*")


    val tempPatUid = InsertData.select("PatientId","PracticeUid","PatientUid").distinct()
      .withColumn("PatientUid",CommonFunc.getNewUid())

    val PatUid = tempPatUid.persist()

    val CachepatientDemo2 = InsertData.as("df1").join(PatUid.as("df2")
      , $"df1.PatientId" === $"df2.PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientUid"===$"df2.PatientUid")
      .select($"df1.*", $"df2.PatientUid")

    val NoChangeRecords =  df2.as("df1").join(df1.as("df2"),
      Seq("PatientId","PracticeUid","PatientUid"),"left_anti").select($"df1.*")
      .drop("Year")

    val AllData = UpdateData.union(CachepatientDemo2).union(NoChangeRecords)

    AllData
  }


  def getPatrtitions(dataFrame: DataFrame,colName:String,cdrTable:String):DataFrame={
    val distinctYear = dataFrame.withColumn("Year",year($"$colName")).select("Year").distinct()
    val distinctMonth = dataFrame.withColumn("Month",month($"$colName")).select("Month").distinct()
    val distinctPUid = dataFrame.select("PracticeUid").distinct()

    val PartitionYear = CommonFunc.mkInString(distinctYear)
    val PartitionMonth = CommonFunc.mkInString(distinctMonth)
    val PartitionPUID = CommonFunc.mkInString(distinctPUid)

    val selecttedPartitionData = sparkSess.sql(s"select * from figmdcdr.$cdrTable where" +
      s" practiceuid in $PartitionPUID and year in $PartitionYear and month in $PartitionMonth")
    selecttedPartitionData

  }


  def getPatrtitionsPatient(dataFrame: DataFrame,colName:String,cdrTable:String):DataFrame={
    val distinctYear = dataFrame.withColumn("Year",year($"$colName")).select("Year").distinct()
    val distinctPUid = dataFrame.select("PracticeUid").distinct()

    val PartitionYear = CommonFunc.mkInString(distinctYear)
    println(PartitionYear)
    val PartitionPUID = CommonFunc.mkInString(distinctPUid)
    println(PartitionPUID)
    val selectedPartitionData = sparkSess.sql(s"select * from $cdrTable where" +
      s" practiceuid in $PartitionPUID and year in $PartitionYear ")

    println("RequiredData Demo Data.....  "+selectedPartitionData.count())

    selectedPartitionData

  }

  /*def sendVisitToHive(dflist : List[DataFrame]): Unit ={

  val df = dflist.tail.foldLeft(dflist.head)((accDF, newDF) => accDF.join(newDF, Seq("PatientId")))
    .withColumn("Year",year($"EncounterStartDate"))
    .withColumn("Month",month($"EncounterStartDate"))
  val tempTableName = "figmdcdr_temp.visit"
  val TableName = conf.getString("db_tb_Visit")
  HiveUtility.dfwritrtohiveVisit(df,TableName,sparkSess,tempTableName)
}*/
}