package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{CachePatientProblemFunctions, ValidationCriteria}
import com.figmd.janus.util.{CommonFunc, DataFrameUtils, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientProblem(ProblemPath : String) {

  def cachePatientProblemProcessing(spark : SparkSession, mappingpracticeproblem : DataFrame
                          ,conf : Config,DemoGraphicsDF : DataFrame) = {

    import spark.implicits._

    try {
      val dfu =  new DataFrameUtils(spark,conf)
      val problemObj = new CachePatientProblemFunctions(spark, mappingpracticeproblem)
      val validations = new ValidationCriteria(spark)
      val tableName = conf.getString("db_tb_Prob")
      val tempTableName = conf.getString("db_temp_problem")


      CommonFunc.loggert("Reading files and applying headers")

      val cachePatientProblem1 = CommonFunc.readFile(ProblemPath,spark)
        .withColumn("DocumentationDate", to_timestamp($"DocumentationDate", "MM/dd/yyyy HH:mm:ss"))

      val addPatientUid = cachePatientProblem1.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PatientId","PracticeUid"))
        .select($"df1.*",$"df2.PatientUid")

      CommonFunc.loggert("applying validations on PatientProblem files")

      val CacheProblemValidations = addPatientUid
        .transform(validations.removeDuplicateRecords(List("PatientUid","ProblemCode","DocumentationDate")))
        .transform(validations.removeDuplicateRecords(List("PatientUid","ProblemText","DocumentationDate")))
        .transform(validations.patientNotFound)
        .transform(validations.documentationDateNotFound)
        .transform(validations.problemCategoryNotFound)
        .transform(validations.problemTextAndProblemCodeNotFound)
        .transform(validations.problemHealthStatusCodeNotFound)
        .transform(validations.problemStatusCodeNotFound)
        .transform(validations.problemTypeCodeNotFound)
        //Doubt [not there in validations sheet but was applied in previous code]

      CommonFunc.loggert("applying validations on PatientProblem files successful")

      val cachePatientProblemTransformed = CacheProblemValidations
        .transform(problemObj.ProblemCode)
        .transform(problemObj.ProblemText)
        .transform(problemObj.ProblemStatusCode)
        .transform(problemObj.ProblemStatusText)
        .transform(problemObj.ProblemHealthStatusCode)
        .transform(problemObj.ProblemHealthStatusText)
        .transform(problemObj.TargetSiteCode)
        .transform(problemObj.TargetSiteText)

      val getPatientProblemPartitions = dfu.getPatrtitions(cachePatientProblemTransformed,"DocumentationDate",tableName)

      val allProblemData = dfu.getInsertUpdateAndNCDData(cachePatientProblemTransformed,getPatientProblemPartitions)
        .withColumn("Month",month($"DocumentationDate"))

      HiveUtility.dfwritrtohiveVisit(allProblemData,tableName,spark,tempTableName)
    }

    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
      }
    }
  }


}
