package com.figmd.janus.util

import org.apache.spark.sql.{DataFrame, SparkSession}

object HiveUtility {



  def dfwritrtohivePatient(df : DataFrame, tablename : String,spark : SparkSession, tempTableName : String)
  : Unit = {
    spark.sql(s"drop table if exists $tempTableName")
    df.write.partitionBy("PracticeUid","Year").saveAsTable(tempTableName)
    spark.sql(s"insert overwrite table $tablename partition(PracticeUid,year) select * from $tempTableName")

  }

  def dfwritrtohiveVisit(df : DataFrame, tablename : String,spark : SparkSession,tempTableName : String): Unit =
  {

    spark.sql(s"drop table if exists $tempTableName")
    df.write.partitionBy("PracticeUid","Year","Month").saveAsTable(tempTableName)
    spark.sql(s"insert overwrite table $tablename partition(PracticeUid,year,month) select * from $tempTableName")

  }

  /*def commonHiveFunction(df : DataFrame,tableName : String, tempTableName : String
                         , PracticeUid : String, Year : Column, Month : Column): Unit = {

    sparkSess.sql(s"drop table if exists $tempTableName")
    println("temp table delete.......................")
    df.write.partitionBy(s"$PracticeUid",s"$Year",s"$Month").saveAsTable(tempTableName)
    println("data insert into temp table.......................")
    sparkSess.sql(s"insert overwrite table $tableName partition($PracticeUid,$Year,$Month) select  * from $tempTableName")
    println("end...............................................................")

  }*/


}
