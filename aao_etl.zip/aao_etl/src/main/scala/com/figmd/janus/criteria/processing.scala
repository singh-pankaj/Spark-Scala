package com.figmd.janus.criteria

import org.apache.spark.sql.functions.{broadcast,when}
import org.apache.spark.sql.{DataFrame, SparkSession}

class CacheAllergyFunctions(sparkSess : SparkSession, masterAllergy : DataFrame
                            ,mappingpracticecommondatamaster : DataFrame) {
  import sparkSess.implicits._
  def AllergicToCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(masterAllergy.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AllergicToCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterAllergicToCode")
        ,$"df2.CodeDescription".as("MasterAllergyDescription"))
  }


  def AllergicToDescription(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(masterAllergy.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AllergicToDescription" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterAllergicToCode")
        ,$"df2.CodeDescription".as("MappedMasterAllergyDescription"))
      .withColumn("MasterAllergicToCode",when($"MappedMasterAllergicToCode".isNull,$"MasterAllergicToCode")
        .otherwise($"MappedMasterAllergicToCode"))
      .withColumn("MasterAllergyDescription",when($"MappedMasterAllergyDescription".isNull,$"MasterAllergyDescription")
        .otherwise($"MappedMasterAllergyDescription"))
      .drop("MappedMasterAllergicToCode","MappedMasterAllergyDescription")
  }


  def AllergyStatusCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AllergyStatusCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterAllergyStatusCode")
        ,$"df2.CodeDescription".as("MasterAllergyStatusText"))
  }

  def AllergyStatusText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AllergyStatusText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterAllergyStatusCode",when($"MappedValue1".isNull,$"MasterAllergyStatusCode")
        .otherwise($"MappedValue1"))
      .withColumn("MasterAllergyStatusText",when($"MappedValue2".isNull,$"MasterAllergyStatusText")
        .otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }


}


class CacheEthnicityFunction(sparkSess : SparkSession,MasterEthnicity : DataFrame)
{

  import sparkSess.implicits._
  def PatientEthnicityText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(MasterEthnicity.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientEthnicityText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterPatientEthnicityCode",$"MappedValue1")
      .withColumn("MasterPatientEthnicityText",$"MappedValue2")
      .drop("MappedValue1","MappedValue2")
  }

  def PatientEthnicityCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(MasterEthnicity.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientEthnicityCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterPatientEthnicityCode",when($"MappedValue1".isNull,$"MasterPatientEthnicityCode")
        .otherwise($"MappedValue1"))
      .withColumn("MasterPatientEthnicityText",when($"MappedValue2".isNull,$"MasterPatientEthnicityText")
        .otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

}
class CachePatientAdvObservationFunctions (sparkSess : SparkSession,mappingpracticecommondatamaster : DataFrame) {

  import sparkSess.implicits._

  def DirectiveTypeCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AdvanceDirectiveTypeCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterAdvanceDirectiveTypeCode")
        , $"df2.CodeDescription".as("MasterAdvanceDirectiveTypeDetails"))
  }


  def DirectiveTypeDetails(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AdvanceDirectiveTypeDetails" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedMasterAdvanceDirectiveTypeCode")
        , $"df2.CodeDescription".as("MappedMasterAdvanceDirectiveTypeDetails"))
      .withColumn("MasterAdvanceDirectiveTypeCode", when($"MappedMasterAdvanceDirectiveTypeCode".isNull, $"MasterAdvanceDirectiveTypeCode")
        .otherwise($"MappedMasterAdvanceDirectiveTypeCode"))
      .withColumn("MasterAdvanceDirectiveTypeDetails", when($"MappedMasterAdvanceDirectiveTypeDetails".isNull, $"MasterAdvanceDirectiveTypeDetails")
        .otherwise($"MappedMasterAdvanceDirectiveTypeDetails"))
      .drop("MappedMasterAdvanceDirectiveTypeCode", "MappedMasterAdvanceDirectiveTypeDetails")
  }


  def DirectiveStatusCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AdvanceDirectiveStatusCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterAdvanceDirectiveStatusCode")
        , $"df2.CodeDescription".as("MasterAdvanceDirectiveStatusText"))
  }

  def DirectiveStatusText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AdvanceDirectiveStatusText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedMasterAdvanceDirectiveStatusCode")
        , $"df2.CodeDescription".as("MappedMasterAdvanceDirectiveStatusText"))
      .withColumn("MasterAdvanceDirectiveStatusCode", when($"MappedMasterAdvanceDirectiveStatusCode".isNull, $"MasterAdvanceDirectiveStatusCode")
        .otherwise($"MappedMasterAdvanceDirectiveStatusCode"))
      .withColumn("MasterAdvanceDirectiveStatusText", when($"MappedMasterAdvanceDirectiveStatusText".isNull, $"MasterAdvanceDirectiveStatusText")
        .otherwise($"MappedMasterAdvanceDirectiveStatusText"))
      .drop("MappedMasterAdvanceDirectiveStatusCode", "MappedMasterAdvanceDirectiveStatusText")

  }

}

class cachePatientInsurancefunctions(sparkSess : SparkSession, MasterInsurance : DataFrame) {

  import sparkSess.implicits._


  //Master Insurance not contain Code and CodeDescription column
  def InsuredRelationToPatientCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(MasterInsurance.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.InsuredRelationToPatientCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.PayerId".as("MasterInsuredRelationToPatientCode")
        , $"df2.PayerId".as("MasterInsuredRelationToPatientText"))

  }
}

class CachePatientProblemFunctions (sparkSess : SparkSession, mappingpracticeproblem : DataFrame){

  import sparkSess.implicits._

  def ProblemCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterProblemCode")
        ,$"df2.CodeDescription".as("MasterProblemText"))
  }

  def ProblemText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterProblemCode")
        ,$"df2.CodeDescription".as("MappedMasterProblemText"))
      .withColumn("MasterProblemCode",when($"MappedMasterProblemCode".isNull,$"MasterProblemCode")
        .otherwise($"MappedMasterProblemCode"))
      .withColumn("MasterProblemText",when($"MappedMasterProblemText".isNull,$"MasterProblemText")
        .otherwise($"MappedMasterProblemText"))
      .drop("MappedMasterProblemCode","MappedMasterProblemText")
  }

  def ProblemStatusCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemStatusCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterProblemStatusCode")
        ,$"df2.CodeDescription".as("MasterProblemStatusText"))
  }

  def ProblemStatusText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemStatusText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterProblemStatusCode")
        ,$"df2.CodeDescription".as("MappedMasterProblemStatusText"))
      .withColumn("MasterProblemStatusCode",when($"MappedMasterProblemStatusCode".isNull,$"MasterProblemStatusCode")
        .otherwise($"MappedMasterProblemStatusCode"))
      .withColumn("MasterProblemStatusText",when($"MappedMasterProblemStatusText".isNull,$"MasterProblemStatusText")
        .otherwise($"MappedMasterProblemStatusText"))
      .drop("MappedMasterProblemStatusCode","MappedMasterProblemStatusText")
  }

  def ProblemHealthStatusCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemHealthStatusCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterProblemHealthStatusCode")
        ,$"df2.CodeDescription".as("MasterProblemHealthStatusText"))
  }

  def ProblemHealthStatusText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemHealthStatusText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedProblemHealthStatusCode")
        ,$"df2.CodeDescription".as("MappedMasterProblemHealthStatusText"))
      .withColumn("MasterProblemHealthStatusCode",when($"MappedProblemHealthStatusCode".isNull,$"MasterProblemHealthStatusCode")
        .otherwise($"MappedProblemHealthStatusCode"))
      .withColumn("MasterProblemHealthStatusText",when($"MappedMasterProblemHealthStatusText".isNull,$"MasterProblemHealthStatusText")
        .otherwise($"MappedMasterProblemHealthStatusText"))
      .drop("MappedProblemHealthStatusCode","MappedMasterProblemHealthStatusText")
  }

  def TargetSiteCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterTargetSiteCode")
        ,$"df2.CodeDescription".as("MasterTargetSiteText"))
  }

  def TargetSiteText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterTargetSiteCode")
        ,$"df2.CodeDescription".as("MappedMasterTargetSiteText"))
      .withColumn("MasterTargetSiteCode",when($"MappedMasterTargetSiteCode".isNull,$"MasterTargetSiteCode")
        .otherwise($"MappedMasterTargetSiteCode"))
      .withColumn("MasterTargetSiteText",when($"MappedMasterTargetSiteText".isNull,$"MasterTargetSiteText")
        .otherwise($"MappedMasterTargetSiteText"))
      .drop("MappedMasterTargetSiteCode","MappedMasterTargetSiteText")
  }

}


class CachePatientProcedureFunctions (sparkSess : SparkSession, mappingPracticeProcedure : DataFrame, mappingpracticecommondatamaster : DataFrame){

  import sparkSess.implicits._

  def PracticeCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterProcedureCode")
        ,$"df2.CodeDescription".as("MasterProcedureText"))
  }

  def PracticeDescription(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterProcedureCode")
        ,$"df2.CodeDescription".as("MappedMasterProcedureText"))
      .withColumn("MasterProcedureCode",when($"MappedMasterProcedureCode".isNull,$"MasterProcedureCode")
        .otherwise($"MappedMasterProcedureCode"))
      .withColumn("MasterProcedureText",when($"MappedMasterProcedureText".isNull,$"MasterProcedureText")
        .otherwise($"MappedMasterProcedureText"))
      .drop("MappedMasterProcedureCode","MappedMasterProcedureText")
  }

  def ProcedureStatusCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureStatusCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterProcedureStatusCode")
        ,$"df2.CodeDescription".as("MasterProcedureStatusText"))
  }

  def ProcedureStatusText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureStatusText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterProcedureStatusCode")
        ,$"df2.CodeDescription".as("MappedMasterProcedureStatusText"))
      .withColumn("MasterProcedureStatusCode",when($"MappedMasterProcedureStatusCode".isNull,$"MasterProcedureStatusCode")
        .otherwise($"MappedMasterProcedureStatusCode"))
      .withColumn("MasterProcedureStatusText",when($"MappedMasterProcedureStatusText".isNull,$"MasterProcedureStatusText")
        .otherwise($"MappedMasterProcedureStatusText"))
      .drop("MappedMasterProcedureStatusCode","MappedMasterProcedureStatusText")
  }

  def TargetSiteCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterTargetSiteCode")
        ,$"df2.CodeDescription".as("MasterTargetSiteText"))
  }

  def TargetSiteText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterTargetSiteCode")
        ,$"df2.CodeDescription".as("MappedMasterTargetSiteText"))
      .withColumn("MasterTargetSiteCode",when($"MappedMasterTargetSiteCode".isNull,$"MasterTargetSiteCode")
        .otherwise($"MappedMasterTargetSiteCode"))
      .withColumn("MasterTargetSiteText",when($"MappedMasterTargetSiteText".isNull,$"MasterTargetSiteText")
        .otherwise($"MappedMasterTargetSiteText"))
      .drop("MappedMasterTargetSiteCode","MappedMasterTargetSiteText")
  }

}


class CachePatientSocialHistoryObs(sparkSess : SparkSession,mappingpracticecommondatamaster : DataFrame) {

  import sparkSess.implicits._

  def SocialHistoryTypeCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.SocialHistoryTypeCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterSocialHistoryTypeCode")
        ,$"df2.CodeDescription".as("MasterSocialHistoryTypeText"))
  }

  def SocialHistoryTypeText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.SocialHistoryTypeText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterSocialHistoryTypeCode")
        ,$"df2.CodeDescription".as("MappedMasterSocialHistoryTypeText"))
      .withColumn("MasterSocialHistoryTypeCode",when($"MappedMasterSocialHistoryTypeCode".isNull,$"MasterSocialHistoryTypeCode")
        .otherwise($"MappedMasterSocialHistoryTypeCode"))
      .withColumn("MasterSocialHistoryTypeText",when($"MappedMasterSocialHistoryTypeText".isNull,$"MasterSocialHistoryTypeText")
        .otherwise($"MappedMasterSocialHistoryTypeText"))
      .drop("MappedMasterSocialHistoryTypeCode","MappedMasterSocialHistoryTypeText")
  }

  def SocialHistoryStatusCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.SocialHistoryStatusCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterSocialHistoryStatusCode")
        ,$"df2.CodeDescription".as("MasterSocialHistoryStatusText"))
  }

  def SocialHistoryStatusText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.SocialHistoryStatusText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterSocialHistoryStatusCode")
        ,$"df2.CodeDescription".as("MappedMasterSocialHistoryStatusText"))
      .withColumn("MasterSocialHistoryStatusCode",when($"MappedMasterSocialHistoryStatusCode".isNull,$"MasterSocialHistoryStatusCode")
        .otherwise($"MappedMasterSocialHistoryStatusCode"))
      .withColumn("MasterSocialHistoryStatusText",when($"MappedMasterSocialHistoryStatusText".isNull,$"MasterSocialHistoryStatusText")
        .otherwise($"MappedMasterSocialHistoryStatusText"))
      .drop("MappedMasterSocialHistoryStatusCode","MappedMasterSocialHistoryStatusText")
  }

}


class CachePatientVitalSignObservationFunctions(spark: SparkSession,mappingpracticecommondatamaster:DataFrame){
  import spark.implicits._

  def PracticeDescription(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterObservationCode")
        ,$"df2.CodeDescription".as("MasterObservationName"))
  }

  def PracticeCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterObservationCode",when($"MappedValue1".isNull
        , $"MasterObservationCode").otherwise($"MappedValue1"))
      .withColumn("MasterObservationName",when($"MappedValue2".isNull
        , $"MasterObservationName").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def TargetSiteText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterTargetSiteCode")
        ,$"df2.CodeDescription".as("MasterTargetSiteText"))
  }

  def TargetSiteCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterTargetSiteCode",when($"MappedValue1".isNull
        , $"MasterTargetSiteCode").otherwise($"MappedValue1"))
      .withColumn("MasterTargetSiteText",when($"MappedValue2".isNull
        , $"MasterTargetSiteText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def ObsInterpretationText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterObsInterpretationCode")
        ,$"df2.CodeDescription".as("MasterObsInterpretationText"))
  }

  def ObsInterpretationCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterObsInterpretationCode",when($"MappedValue1".isNull
        , $"MasterObsInterpretationCode").otherwise($"MappedValue1"))
      .withColumn("MasterObsInterpretationText",when($"MappedValue2".isNull
        , $"MasterObsInterpretationText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }



}

class CacheImmunizationFunctions(spaek : SparkSession,mappingpracticecommondatamaster:DataFrame,
                                 MappingPracticeCommonDataMasterMedicationRoute:DataFrame,MappingPracticeProcedure:DataFrame,
                                 MappingPracticeProblem:DataFrame,MappingPracticeCommonDataMaster:DataFrame)
{
  import spaek.implicits._

  def ImmunizationName(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ImmunizationName" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterImmunizationCode")
        ,$"df2.CodeDescription".as("MasterImmunizationName"))
  }

  def ImmunizationCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ImmunizationCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterImmunizationCode",when($"MappedValue1".isNull , $"MasterImmunizationCode").otherwise($"MappedValue1"))
      .withColumn("MasterImmunizationName",when($"MappedValue2".isNull , $"MasterImmunizationName").otherwise($"MappedValue2"))
  }

  def MedicationRouteText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMasterMedicationRoute.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationRouteText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationRouteCode")
        ,$"df2.CodeDescription".as("MasterMedicationRouteText"))
  }

  def MedicationRouteCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMasterMedicationRoute.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationRouteCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationRouteCode",when($"MappedValue1".isNull , $"MasterMedicationRouteCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationRouteText",when($"MappedValue2".isNull , $"MasterMedicationRouteText").otherwise($"MappedValue2"))
  }

  def ProcedureText(df:DataFrame): DataFrame= {
    broadcast(df).as("df1").join(MappingPracticeCommonDataMasterMedicationRoute.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureText" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MasterProcedureText"))
  }

  def ProcedureCode(df:DataFrame):DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMasterMedicationRoute.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.CodeDescription".as("MappedValue1"))
      .withColumn("MasterProcedureText",when($"MappedValue1".isNull , $"MasterProcedureText").otherwise($"MappedValue1"))
  }

  def MedicationIndicationProblemText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeProblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationIndicationProblemCode")
        ,$"df2.CodeDescription".as("MasterMedicationIndicationProblemText"))
  }

  def MedicationIndicationProblemCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeProblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationIndicationProblemCode",when($"MappedValue1".isNull , $"MasterMedicationIndicationProblemCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationIndicationProblemText",when($"MappedValue2".isNull , $"MasterMedicationIndicationProblemText").otherwise($"MappedValue2"))
  }

  def MedicationReactionProblemText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeProblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationReactionProblemText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationReactionProblemCode")
        ,$"df2.CodeDescription".as("MasterMedicationReactionProblemText"))
  }

  def MedicationReactionProblemCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeProblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationReactionProblemCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationReactionProblemCode",when($"MappedValue1".isNull , $"MasterMedicationReactionProblemCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationReactionProblemText",when($"MappedValue2".isNull , $"MasterMedicationReactionProblemText").otherwise($"MappedValue2"))
  }

  def MedicationReactionProblemSeverityText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationReactionProblemSeverityText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationReactionProblemSeverityCode")
        ,$"df2.CodeDescription".as("MasterMedicationReactionProblemSeverityText"))
  }

  def MedicationReactionProblemSeverityCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationReactionProblemSeverityCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationReactionProblemSeverityCode",when($"MappedValue1".isNull , $"MasterMedicationReactionProblemSeverityCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationReactionProblemSeverityText",when($"MappedValue2".isNull , $"MasterMedicationReactionProblemSeverityText").otherwise($"MappedValue2"))
  }

  def MedicationStatusText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationStatusText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationStatusCode")
        ,$"df2.CodeDescription".as("MasterMedicationStatusText"))
  }

  def MedicationStatusCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationStatusCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationStatusCode",when($"MappedValue1".isNull , $"MasterMedicationStatusCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationStatusText",when($"MappedValue2".isNull , $"MasterMedicationStatusText").otherwise($"MappedValue2"))
  }

}

class cacheRaceFunctions (sparkSess : SparkSession ,MasterRace : DataFrame) {




  import sparkSess.implicits._
  def PatientRaceText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(MasterRace.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientRaceText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterPatientRaceCode")
        ,$"df2.CodeDescription".as("MasterPatientRaceText"))
  }

  def PatientRaceCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(MasterRace.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientRaceCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterPatientRaceCode",when($"MappedValue2".isNull,$"MasterPatientRaceCode")
        .otherwise($"MappedValue2"))
      .withColumn("MasterPatientRaceText",when($"MappedValue1".isNull,$"MasterPatientRaceText")
        .otherwise($"MappedValue1"))
      .drop("MappedValue1","MappedValue2")
  }
}


class ResultObsFunction(sparkSess: SparkSession , mappingpracticecommondatamaster : DataFrame
                        ,mappingpracticeprocedure : DataFrame) {


  import sparkSess.implicits._

  def PracticeCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterObservationCode")
        ,$"df2.CodeDescription".as("MasterObservationName"))
  }

  def PracticeDescription(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("Mappedvalue1")
        ,$"df2.CodeDescription".as("Mappedvalue2"))
      .withColumn("MasterObservationCode",when($"Mappedvalue1".isNull,$"MasterObservationCode")
        .otherwise($"Mappedvalue1"))
      .withColumn("MasterObservationName",when($"Mappedvalue2".isNull,$"MasterObservationName")
        .otherwise($"Mappedvalue2"))
      .drop("Mappedvalue1","Mappedvalue2")
  }

  def TargetSiteCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterTargetSiteCode")
        ,$"df2.CodeDescription".as("MasterTargetSiteText"))
  }

  def TargetSiteText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("Mappedvalue1")
        ,$"df2.CodeDescription".as("Mappedvalue2"))
      .withColumn("MasterTargetSiteCode",when($"Mappedvalue1".isNull,$"MasterTargetSiteCode")
        .otherwise($"Mappedvalue1"))
      .withColumn("MasterTargetSiteText",when($"Mappedvalue2".isNull,$"MasterTargetSiteText")
        .otherwise($"Mappedvalue2"))
      .drop("Mappedvalue1","Mappedvalue2")
  }

  def ObsInterpretationCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterObsInterpretationCode")
        ,$"df2.CodeDescription".as("MasterObsInterpretationText"))
  }

  def ObsInterpretationText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ObsInterpretationText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("Mappedvalue1")
        ,$"df2.CodeDescription".as("Mappedvalue2"))
      .withColumn("MasterObsInterpretationCode",when($"Mappedvalue1".isNull,$"MasterObsInterpretationCode")
        .otherwise($"Mappedvalue1"))
      .withColumn("MasterObsInterpretationText",when($"Mappedvalue2".isNull,$"MasterObsInterpretationText")
        .otherwise($"Mappedvalue2"))
      .drop("Mappedvalue1","Mappedvalue2")
  }

  def ProcedureCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticeprocedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterProcedureCode")
        ,$"df2.CodeDescription".as("MasterProcedureText"))
  }

  def ProcedureText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticeprocedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("Mappedvalue1")
        ,$"df2.CodeDescription".as("Mappedvalue2"))
      .withColumn("MasterProcedureCode",when($"Mappedvalue1".isNull,$"MasterProcedureCode")
        .otherwise($"Mappedvalue1"))
      .withColumn("MasterProcedureText",when($"Mappedvalue2".isNull,$"MasterProcedureText")
        .otherwise($"Mappedvalue2"))
      .drop("Mappedvalue1","Mappedvalue2")
  }

  def MethodCode(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MethodCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMethodCode")
        ,$"df2.CodeDescription".as("MasterMethodCodeText"))
  }

  def MethodCodeText(df: DataFrame): DataFrame = {
    broadcast(df)
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MethodCodeText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("Mappedvalue1")
        ,$"df2.CodeDescription".as("Mappedvalue2"))
      .withColumn("MasterMethodCode",when($"Mappedvalue1".isNull,$"MasterMethodCode")
        .otherwise($"Mappedvalue1"))
      .withColumn("MasterMethodCodeText",when($"Mappedvalue2".isNull,$"MasterMethodCodeText")
        .otherwise($"Mappedvalue2"))
      .drop("Mappedvalue1","Mappedvalue2")
  }



}


class CacheMedicationsFunctions(spark: SparkSession,MappingPracticeProcedure:DataFrame,MappingPracticeMedication:DataFrame,
                                MappingPracticeCommonDataMaster:DataFrame){
  import spark.implicits._
  def ProcedureText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterProcedureCode")
        ,$"df2.CodeDescription".as("MasterProcedureText"))
  }

  def ProcedureCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterProcedureCode",when($"MappedValue1".isNull , $"MasterProcedureCode")
        .otherwise($"MappedValue1"))
      .withColumn("MasterProcedureText",when($"MappedValue2".isNull , $"MasterProcedureText")
        .otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationName(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeMedication.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationName" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationCode")
        ,$"df2.CodeDescription".as("MasterMedicationName"))
  }

  def MedicationCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeMedication.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationCode",when($"MappedValue1".isNull , $"MasterMedicationCode")
        .otherwise($"MappedValue1"))
      .withColumn("MasterMedicationName",when($"MappedValue2".isNull , $"MasterMedicationName")
        .otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationProductFormText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationProductFormText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationProductFormCode")
        ,$"df2.CodeDescription".as("MasterMedicationProductFormText"))
  }

  def MedicationProductFormCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationProductFormCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationProductFormCode",when($"MappedValue1".isNull
        , $"MasterMedicationProductFormCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationProductFormText",when($"MappedValue2".isNull
        , $"MasterMedicationProductFormText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationIndicationProblemText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationIndicationProblemCode")
        ,$"df2.CodeDescription".as("MasterMedicationIndicationProblemText"))
  }

  def MedicationIndicationProblemCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationIndicationProblemCode",when($"MappedValue1".isNull
        , $"MasterMedicationIndicationProblemCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationIndicationProblemText",when($"MappedValue2".isNull
        , $"MasterMedicationIndicationProblemText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationReactionProblemText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationReactionProblemText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationReactionProblemCode")
        ,$"df2.CodeDescription".as("MasterMedicationReactionProblemText"))
  }

  def MedicationReactionProblemCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationReactionProblemCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationReactionProblemCode",when($"MappedValue1".isNull
        , $"MasterMedicationReactionProblemCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationReactionProblemText",when($"MappedValue2".isNull
        , $"MasterMedicationReactionProblemText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationReactionProblemSeverityText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationReactionProblemSeverityCode")
        ,$"df2.CodeDescription".as("MasterMedicationReactionProblemSeverityText"))
  }

  def MedicationReactionProblemSeverityCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationReactionProblemSeverityCode",when($"MappedValue1".isNull
        , $"MasterMedicationReactionProblemSeverityCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationReactionProblemSeverityText",when($"MappedValue2".isNull
        , $"MasterMedicationReactionProblemSeverityText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationStatusText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationStatusCode")
        ,$"df2.CodeDescription".as("MasterMedicationStatusText"))
  }

  def MedicationStatusCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationIndicationProblemCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationStatusCode",when($"MappedValue1".isNull
        , $"MasterMedicationStatusCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationStatusText",when($"MappedValue2".isNull
        , $"MasterMedicationStatusText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def MedicationRouteText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationRouteText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterMedicationRouteCode")
        ,$"df2.CodeDescription".as("MasterMedicationRouteText"))
  }

  def MedicationRouteCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(MappingPracticeCommonDataMaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MedicationRouteCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterMedicationRouteCode",when($"MappedValue1".isNull
        , $"MasterMedicationRouteCode").otherwise($"MappedValue1"))
      .withColumn("MasterMedicationRouteText",when($"MappedValue2".isNull
        , $"MasterMedicationRouteText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

}

class CachePlanOfCareFunctions(spark:SparkSession, mappingpracticecommondatamaster:DataFrame) {

  import spark.implicits._

  def PlanOfCareStatusText(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PlanOfCareStatusText" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterPlanOfCareStatusCode")
        ,$"df2.CodeDescription".as("MasterPlanOfCareStatusText"))
  }

  def PlanOfCareStatusCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PlanOfCareStatusCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterPlanOfCareStatusCode",when($"MappedValue1".isNull
        , $"MasterPlanOfCareStatusCode").otherwise($"MappedValue1"))
      .withColumn("MasterPlanOfCareStatusText",when($"MappedValue2".isNull
        , $"MasterPlanOfCareStatusText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

  def PracticeDescription(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PracticeDescription" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterPlanOfCareCode")
        ,$"df2.CodeDescription".as("MasterPlanOfCareText"))
  }

  def PracticeCode(df:DataFrame): DataFrame={
    broadcast(df).as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PracticeCode" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedValue1")
        ,$"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterPlanOfCareCode",when($"MappedValue1".isNull
        , $"MasterPlanOfCareCode").otherwise($"MappedValue1"))
      .withColumn("MasterPlanOfCareText",when($"MappedValue2".isNull
        , $"MasterPlanOfCareText").otherwise($"MappedValue2"))
      .drop("MappedValue1","MappedValue2")
  }

}
	

