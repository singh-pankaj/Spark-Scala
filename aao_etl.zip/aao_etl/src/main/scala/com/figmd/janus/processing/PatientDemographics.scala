package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.ValidationCriteria
import com.figmd.janus.util.{CommonFunc, DataFrameUtils}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientDemographics(DemoPath : String,conf:Config) {

  def CachePatientDemographicsProcessing(spark : SparkSession) : Option[DataFrame] = {

    import spark.implicits._

    try{

      val validations = new ValidationCriteria(spark)
      val tableName = conf.getString("db_tb_patient")
      val dfu = new DataFrameUtils(spark,conf)

      CommonFunc.loggert("reading CachePatientDemographics files..")

      val CachepatientDemo = CommonFunc.readFile(DemoPath,spark)
        .withColumn("DOB", to_timestamp($"DOB", "MM/dd/yyyy HH:mm:ss"))


      //      println(lookup)
      //      val CachepatientDemo = CommonFunc.readFileWithLookup(DemoPath,lookup,spark)

      // .withColumn("PracticeUid",upper($"PracticeUid"))

      CommonFunc.loggert("applying validations on CachePatientDemographics files")

    /*  val CleanedRecords = CachepatientDemo
        .transform(validations.removeDuplicateRecords(List("PatientId","PracticeUid")))
        .transform(validations.differentMRNForSamePatientWithoutSSN)
        .transform(validations.differentMRNForSamePatientWithSSN)
        .transform(validations.invalidNPIFound)
        .transform(validations.birthCountryNotFound)
        .transform(validations.birthStateNotFound)
        .transform(validations.countryNotFound)
        //.transform(validations.)
        .transform(validations.patientDOBNotFound)
        .transform(validations.practiceUidNotFound)
        .transform(validations.stateNotFound)
        .transform(validations.telecomType1tNotFound)
        .transform(validations.telecomType2tNotFound)

      CommonFunc.loggert("DemoGraphics validations success" + CleanedRecords.count())
*/
      val CleanedRecords = CachepatientDemo.filter(row=>validations.checkNull(row,"patientid","practiceuid","firstname","lastname","dob","gender"))


      val tempPatUid = CleanedRecords
        .withColumn("PatientUid",CommonFunc.getNewUid())

      /*
            val distinctYear = CleanedRecords.withColumn("Year",year($"DOB")).select("Year").distinct()
            val distinctPUid = CleanedRecords.select("PracticeUid").distinct()

            val ListVal:Array[Any] = distinctYear.rdd.map(r => r(0)).collect()
            val PartitionYear = "(\"" + ListVal.mkString("\",\"") + "\")"

            val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
            val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"


            val RequiredData = spark.sql(s"select * from figmdaaocdr.patient where" +
              s" practiceuid in $PartitionPUID and year in $PartitionYear")
              .drop("ethnicity","race","language","socialhistoryobservation"
                ,"insurance","advancedirectives","allergy","planofcare","patientfamilyhistory"
                ,"patientguardian","Year")

        CommonFunc.loggert("gathered RequiredData Demo Data.....  ")

            val PreviousPatient = CleanedRecords.as("df1").join(RequiredData.as("df2"),
              Seq("PatientId","PracticeUid"),"inner").select($"df1.*",$"df2.PatientUid")
              .drop("Year")

            CommonFunc.loggert("PreviousPatient Demo Data.....  ")

            val newPatient =  CleanedRecords.as("df1").join(RequiredData.as("df2"),
              Seq("PatientId","PracticeUid"),"left_anti").select($"df1.*")

            CommonFunc.loggert("newPatient Demo Data.....  "+newPatient.count())

            val tempPatUid = newPatient.select("PatientId", "PracticeUid").distinct()
              .withColumn("PatientUid",CommonFunc.getNewUid())

            val PatUid = tempPatUid.persist()

            val CachepatientDemo2 = newPatient.as("df1").join(PatUid.as("df2")
              , $"df1.PatientId" === $"df2.PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid")
              .select($"df1.*", $"df2.PatientUid")

            val OtherPatient =  RequiredData.as("df1").join(CleanedRecords.as("df2"),
              Seq("PatientId","PracticeUid"),"left_anti").select($"df1.*")
              .drop("Year")

            //println("OtherPatient Demo Data.....  "+OtherPatient.count())

            val allRecords = PreviousPatient.union(CachepatientDemo2).union(OtherPatient)
            CommonFunc.loggert("union done")
      */

      Some(tempPatUid)


    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
        ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }

  }
}
