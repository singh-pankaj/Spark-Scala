package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{ResultObsFunction, ValidationCriteria}
import com.figmd.janus.util.{CommonFunc, DataFrameUtils, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientResultObservation(ResultObsPath : String) {


  def cacheresultObsProcessing(spark : SparkSession,
                               mappingpracticecommondatamaster : DataFrame,
                               Mappingpracticeprocedure : DataFrame,
                               conf : Config,DemoGraphicsDF : DataFrame): Unit = {

    import spark.implicits._
    try {

      val dfu =  new DataFrameUtils(spark,conf)
      val resultObsObj = new ResultObsFunction(spark, mappingpracticecommondatamaster, Mappingpracticeprocedure)
      val validations = new ValidationCriteria(spark)
      val tableName = conf.getString("db_tb_ResObs")
      val tempTableName = "figmdcdr_temp.reultobservation"

      CommonFunc.loggert("Reading files and applying headers")

      val CacheResultObservation = CommonFunc.readFile(ResultObsPath,spark)
        .withColumn("ObservationDate", to_timestamp($"ObservationDate", "MM/dd/yyyy HH:mm:ss"))

      val addPatientUid =  CacheResultObservation.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PatientId","PracticeUid"))
        .select($"df1.*",$"df2.PatientUid")

      CommonFunc.loggert("applying validations on PatientResultObservation files")

      val CacheResultObservationValidations = addPatientUid
        .transform(validations.invalidObservationCodeFound)
        .transform(validations.obsValueLonger)
        .transform(validations.observationCategoryNotFound)
        .transform(validations.observationNameAndObservationCodeNotFound)
        .transform(validations.observationdateNotFound)
        .transform(validations.observationNameNotFound)
        .transform(validations.observationValueNotFound)
        .transform(validations.patientNotFound)
        .transform(validations.procedureCodeCodeNotFound)
        .transform(validations.resultInterpretationCodeOrTextNotFound)
        .transform(validations.targetSiteCodeAndTextNotFound)

      CommonFunc.loggert("applying validations on PatientResultObservation files successful")

      val CacheResultObservationTransformed = CacheResultObservationValidations
        .transform(resultObsObj.PracticeCode)
        .transform(resultObsObj.PracticeDescription)
        .transform(resultObsObj.TargetSiteCode)
        .transform(resultObsObj.TargetSiteText)
        .transform(resultObsObj.ObsInterpretationCode)
        .transform(resultObsObj.ObsInterpretationText)
        .transform(resultObsObj.ProcedureCode)
        .transform(resultObsObj.ProcedureText)
        .transform(resultObsObj.MethodCode)
        .transform(resultObsObj.MethodCodeText)

      val getResultObservationPartitions = dfu.getPatrtitions(CacheResultObservationTransformed,"ObservationDate", tableName)

      val allResObsnData = dfu.getInsertUpdateAndNCDData(CacheResultObservationTransformed,getResultObservationPartitions)
        .withColumn("Month",month($"df1.ObservationDate"))

      HiveUtility.dfwritrtohiveVisit(allResObsnData,tableName,spark,tempTableName)

    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }
  }
}
