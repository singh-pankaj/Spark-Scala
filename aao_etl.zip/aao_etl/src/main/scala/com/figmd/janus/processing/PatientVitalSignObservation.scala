package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{ProcessingCriteria, ValidationCriteria}
import com.figmd.janus.util.{CommonFunc, DataFrameUtils, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientVitalSignObservation(VitalSignPath : String) {

  def VitalSignObservationProcessing(spark: SparkSession,
                                     conf : Config,
                                     mappingpracticecommondatamaster : DataFrame,
                                     DemoGraphicsDF : DataFrame) = {
    import spark.implicits._


    try {

      val dfu =  new DataFrameUtils(spark,conf)
      val processing = new ProcessingCriteria(spark)
      val validations = new ValidationCriteria(spark)

      val tableName = conf.getString("db_tb_VitSign")
      val tempTableName = "figmdcdr_temp.vitalsignobservation"

      CommonFunc.loggert("Reading files and applying headers")

      //Apply lookup to generate file Header
      val CachePatientVitalSignObservationDF: DataFrame = CommonFunc.readFile(VitalSignPath,spark)
        .withColumn("ObservationDate", to_timestamp($"ObservationDate", "MM/dd/yyyy HH:mm:ss"))

      val addPatientUid =  CachePatientVitalSignObservationDF.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PatientId","PracticeUid"))
        .select($"df1.*",$"df2.PatientUid")

      CommonFunc.loggert("applying validations on PatientVitalSignObservation files")

      val CacheVitalSignsValidations = addPatientUid
          .transform(validations.observationCategoryNotFound)
          .transform(validations.observationNameAndObservationCodeNotFound)
          .transform(validations.observationdateNotFound)
          .transform(validations.observationValueNotFound)
          .transform(validations.patientNotFound)

      CommonFunc.loggert("applying validations on PatientVitalSignObservation files successful")

      val transformPatientVitalSignObservationDF = CacheVitalSignsValidations
        .transform(processing.getTextAndCode("PracticeDescription","PracticeCode", mappingpracticecommondatamaster))
        .transform(processing.getTextAndCode("TargetSiteText","TargetSiteCode", mappingpracticecommondatamaster))
        .transform(processing.getTextAndCode("ObsInterpretationText","ObsInterpretationCode", mappingpracticecommondatamaster))

      val getVitalSignsobsPartitions = dfu.getPatrtitions(transformPatientVitalSignObservationDF,"ObservationDate", tableName)

      val allVitalSignData = dfu.getInsertUpdateAndNCDData(transformPatientVitalSignObservationDF,getVitalSignsobsPartitions)
        .withColumn("Year",year($"df1.ObservationDate"))
        .withColumn("Month",month($"df1.ObservationDate"))

      HiveUtility.dfwritrtohiveVisit(allVitalSignData,tableName,spark,tempTableName)
    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }
}
