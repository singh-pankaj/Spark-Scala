package com.figmd.janus.util

import java.util.{Date, UUID}

import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.{DataFrame, SparkSession}

object CommonFunc {


  val getNewUid = udf[String](() => {
    UUID.randomUUID.toString
  })

  val updateWithJoin = udf[String,String,String]((column1: String, column2: String) => {
    if (column1 == null) column2
    else column1
  })


  def readFile(path : String,sparkSess : SparkSession) : DataFrame ={
    val file = sparkSess.read.option("inferschema","true").parquet(path)

    file
  }

  def mkInString(dataFrame: DataFrame):String={
    val ListVal:Array[Any] = dataFrame.rdd.map(r => r(0)).collect()
    val createString = "(\"" + ListVal.mkString("\",\"") + "\")"
    createString
  }

  def loggert(string: String):Unit={
    val time = System.currentTimeMillis()
    val date = new Date(time)
  println(s"APPLOG : $date : " + string)
  }
}
