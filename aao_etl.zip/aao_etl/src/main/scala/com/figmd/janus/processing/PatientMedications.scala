
package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{CacheMedicationsFunctions, ValidationCriteria}
import com.figmd.janus.util.{CommonFunc, DataFrameUtils, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientMedications(MedicationPath : String) {

  def CacheMedicationsProcessing(spark: SparkSession,
                                 MappingPracticeProcedure: DataFrame,
                                 MappingPracticeMedication: DataFrame,
                                 MappingPracticeCommonDataMaster: DataFrame,
                                 conf : Config,
                                 DemoGraphicsDF : DataFrame)  {

    import spark.implicits._

    try {

      val dfu =  new DataFrameUtils(spark,conf)

      val validations = new ValidationCriteria(spark)

      CommonFunc.loggert("Reading files and applying headers")

      //Read file for CacheMedications and Apply lookup to generate file Header
      val CacheMedicationsDF: DataFrame = CommonFunc.readFile(MedicationPath,spark)
        .withColumn("MedStartDate", to_timestamp($"MedStartDate", "MM/dd/yyyy HH:mm:ss"))

      val addPatientUid =  CacheMedicationsDF.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PatientId","PracticeUid"))
        .select($"df1.*",$"df2.PatientUid")

      //val CleanedData = addPatientUid.dropDuplicates(Seq("PatientUid", "PracticePatientMedicationKey"))

      CommonFunc.loggert("applying validations on PatientMedications files")

      //Apply validations on CacheMedications file
      val CacheMedicationsValidations =addPatientUid
        .transform(validations.removeDuplicateRecords(List("PatientUid","PracticePatientMedicationKey")))
        .transform(validations.invalidNPIFound)
        .transform(validations.medicationIndicationProblemCodeNotFound)
        .transform(validations.medicationCodeNameNotFound)
        .transform(validations.patientNotFound)
        .transform(validations.practicePatientMedicationKeyNotFound)
        .transform(validations.procedureCodeNotFound)

      CommonFunc.loggert("applying validations on PatientMedications files successful")

      val medications = new CacheMedicationsFunctions(spark, MappingPracticeProcedure, MappingPracticeMedication, MappingPracticeCommonDataMaster)

      //apply transformation functions on CacheMedications and get lookup columns
      val transformMedicationsDF = CacheMedicationsValidations
        .transform(medications.ProcedureText)
        .transform(medications.ProcedureCode)
        .transform(medications.MedicationName)
        .transform(medications.MedicationCode)
        .transform(medications.MedicationProductFormText)
        .transform(medications.MedicationProductFormCode)
        .transform(medications.MedicationIndicationProblemText)
        .transform(medications.MedicationIndicationProblemCode)
        .transform(medications.MedicationReactionProblemText)
        .transform(medications.MedicationReactionProblemCode)
        .transform(medications.MedicationReactionProblemSeverityText)
        .transform(medications.MedicationReactionProblemSeverityCode)
        .transform(medications.MedicationStatusText)
        .transform(medications.MedicationStatusCode)
        .transform(medications.MedicationRouteText)
        .transform(medications.MedicationRouteCode)

      //get CDR table
      val tableName = conf.getString("db_tb_Medication")

      //Get selected partitions from Patient Medication table
      val MedicationData = dfu.getPatrtitions(transformMedicationsDF,"MedStartDate",tableName)

      //Get Insert Update and No change Records
      val allMedicationData = dfu.getInsertUpdateAndNCDData(transformMedicationsDF,MedicationData)


      val CombineData = allMedicationData.as("df1").withColumn("Year",year($"df1.MedStartDate"))
        .withColumn("Month",month($"df1.MedStartDate"))

      //get temp table
      val tempTableName = conf.getString("db_temp_medications")

      //write Medication data to Hive
      HiveUtility.dfwritrtohiveVisit(CombineData,tableName,spark,tempTableName)

    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
      }
    }
  }
}