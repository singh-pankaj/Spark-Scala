package com.figmd.janus.util

// Logger utilities

object ParserOne {
/*

  def main(args: Array[String])= {

    // Set Logger levels
    //Logger.getLogger("akka").setLevel(Level.WARN)
    Logger.getLogger("org").setLevel(Level.WARN)

    // Initialize Spark context
    //
    val spark = SparkSession.builder().master("local[*]").getOrCreate()
    //import spark.implicits._
    //val patdatdf = spark.read.option("header", "true").option("inferSchema", "true").csv("/home/hardfig/datafiles/patdat.csv")
    //patdatdf.printSchema()
    //patdatdf.show(30, truncate = false)

    val emitRecords: () => Seq[RawData] = Source.emit(Config.current)
    //...

    //emitRecords.for

    spark.stop()
    //sys.exit(0)
  }


  //private def go(emit: () => Seq[RawData]): Result = {}

  private def transform(r: RawData): TransformError \/ DomainData = {
    val maybePerson: TransformError \/ Person = r.person
    val maybePhone: TransformError \/ PhoneNumbers = PhoneNumber.from(r.phone)

    (maybePerson |@| maybePhone)(DomainData)    // Have also added TransformError for the DomainData return type

  }

  //private def toResult(v: DomainData): Result = {}


  object Source {
    def emit(conf: Config)(): Seq[RawData] = {
      // Extract values from config
      RawData.generateRawData
    }
  }

  trait Config
  case class FileConfig() extends Config

  object Config {
    def current: Config = FileConfig()
  }

  case class Result(successes: Int, failures: Int)

  case class TransformError(error: String)

  case class DomainData(
                         person: Person,
                         phoneNumber: PhoneNumbers
                       )

  case class PhoneNumber(
                          countryCode: Int,
                          areaCode: Int,
                          prefix: Int,
                          number: Int
                        ) {
    override def toString = s"$countryCode ($areaCode) $prefix-$number"
  }

  case class PhoneNumbers(
                           countryCode: Int,
                           areaCode: Int,
                           prefix: Int,
                           number: Int
                         )

  object PhoneNumber {
    //private val toInt(s: String): TransformError \/ Int = {  // original line
    private def toInt(s: String): TransformError \/ Int = {  // original line

      //private val to_Int = (s: String): TransformError \/ Int = {
      //private val to_Int: (s: String => (TransformError \/ Int)) = {
      //private def to_Int(s: String): TransformError \/ Int = {
      Try(s.toInt).toDisjunction.leftMap(e => TransformError(e.getMessage))
      //\/-(1234)
    }
    private val pattern: Regex = """(\d{1})-(\d{3})-(\d{3})-(\d{4})""".r

    //def from(phoneString: String): PhoneNumber = {}             // Does not indicate that parsing could fail
    //def from(phoneString: String): Option[PhoneNumber] = {}     // Returns None, but does not indicate what kind of failure occurred
    def from(phoneString: String): TransformError \/ PhoneNumbers = {
      phoneString match {
        case pattern(code, area, prefix, num) => {
          //PhoneNumber(code.toInt, area.toInt, prefix.toInt, num.toInt)      // toInt could fail (in case of alphanumerics, so added the Try above. Then below we can use Applicative-Disjunction
          //(toInt(code) |@| toInt(area) |@| toInt(prefix) |@| toInt(num))(PhoneNumber)
          (toInt("12") |@| toInt("34") |@| toInt("56") |@| toInt("78"))(PhoneNumbers)
        }
        case _ => -\/(TransformError(s"Failure in parsing phone - $phoneString"))
      }
    }
  }

  case class Person(fname: String, lname: String)

  case class RawData(
                      name: String,
                      email: String,
                      phone: String,
                      city: String
                    ) {
    lazy val person: TransformError \/ Person = {
      name.split(" ").toList match {
        case fname :: lname :: Nil => \/-(Person(fname, lname))             // return right disjunction
        case _ => -\/(TransformError(s"Failure in parsing name - $name"))   // return left disjunction
      }
    }
  }

  object RawData {
    def generateRawData: Seq[RawData] = Seq(
      RawData("Jack Jones", "jjones@data.net", "1-234-567-8901", "Kansas"),
      RawData("Mark Williams", "mwilliams@data.net", "1-987-567-8902", "Texas"),
      RawData("Aaron James", "ajames@data.net", "1-875-567-8903", "Chicago")
    )
  }

*/

}
