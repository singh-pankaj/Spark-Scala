package com.figmd.janus.util

//spark-submit --class com.figmd.janus.util.testApplyValidations /home/dev/Akshay/aao_etl_2.11-0.1.jar

import java.util

import com.figmd.janus.criteria.ValidationCriteria
import org.apache.log4j.{Level, Logger}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{Column, DataFrame, Row, SparkSession}

import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks._

object testApplyValidations {

  def main(args: Array[String]): Unit = {
    Logger.getLogger("org").setLevel(Level.WARN)
    Logger.getLogger("akka").setLevel(Level.WARN)

    val spark = SparkSession.builder().master("local[*]").getOrCreate()


    import spark.implicits._

    val animalDF = mutable.Seq(
      (8, 1, "bat"),
      (8, 1, "cat")).toDF("id", "Number", "new_animal")

    val animaltempDf = animalDF.withColumn("new_animal", when($"new_animal" === "bat", lit(null)).otherwise(lit("")))
    val numberDF = mutable.Seq(
      (12, 1, "bee"),
      (13, 1, "cat")).toDF("id", "Number", "new_animal")
    val numbertempDf = numberDF.withColumn("Number", lit(null))

    val idDF = mutable.Seq(
      (14, 1, "elephant"),
      (15, 1, "goat")).toDF("id", "Number", "new_animal")
    val idtempDf = idDF.withColumn("id", lit(null))

    val appendDF = Seq(
      (8, 1, "bat"),
      (8, 1, "bat"),
      (8, 2, "horse"),
      (64, 2, "mouse"),
      (64, 2, "mouse"),
      (-27, 3, "horse"),
      (9, 9, "rhino")).toDF("id", "Number", "new_animal")

    val input = idtempDf.union(numbertempDf).union(animaltempDf).union(appendDF)


    val schema = input.schema.add(StructField("errorMsg",StringType))

    val validations = new ValidationCriteria(spark)
    val rows = new util.ArrayList[Row]()
    val rows1 = spark.sparkContext.broadcast(rows)

    val applyValidations = input
      .transform(validations.removeDuplicateRecords(List("id","Number","new_animal")))

    applyValidations.show()
    val cleanData = applyValidations.filter(row => validations.checkNull10(row,rows1,"Number"))

    cleanData.show()

    val errList = validations.errorList += spark.createDataFrame(rows,schema)

    val errRec = validations.errorRecords(errList.toList)



    errRec.show()
  }
}
