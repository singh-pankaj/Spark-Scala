package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{ValidationCriteria, cacheRaceFunctions}
import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientRace(RacePath : String) {

  def cacheRaceProcessing(spark : SparkSession,
                          DemoGraphicsDF:DataFrame,
                          MasterRace : DataFrame) : Option[DataFrame] = {

    import spark.implicits._
    try {

      val raceObj = new cacheRaceFunctions(spark, MasterRace)


      val CachePatientRaceTable = CommonFunc.readFile(RacePath,spark)


        val CachePatientRaceDF = CachePatientRaceTable.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PatientId","PracticeUid")).select($"df1.*",$"df2.PatientUid")
      CachePatientRaceTable.printSchema()

      CommonFunc.loggert("applying validations on PatientRace files")
      val validations = new ValidationCriteria(spark)

      val CachePatientRaceValidations =  CachePatientRaceDF
        .transform(validations.patientNotFound)
        .transform(validations.raceCodeAndTextNotFound)
        //Doubt [not there in validations sheet but was applied in previous code]
        .transform(validations.removeDuplicateRecords(List("PatientUid","PatientRaceText")))

      CommonFunc.loggert("applying validations on PatientRace files successful")

      val CachePatientRaceTransformed = CachePatientRaceValidations
        .transform(raceObj.PatientRaceText)
        .transform(raceObj.PatientRaceCode)

      val CachePatientRace = CachePatientRaceTransformed.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("PatientRaceCode", "PatientRaceText", "MasterPatientRaceCode"
          , "MasterPatientRaceText")).as("Race"))

      Some(CachePatientRace)
    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }

  }
}