package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{CachePatientProcedureFunctions, ValidationCriteria}
import com.figmd.janus.util.{CommonFunc, DataFrameUtils, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientProcedure(ProcedurePath : String) {

  def cachePatientProcedureProceesing(spark : SparkSession,
                                      conf : Config,
                                      mappingPracticeProcedure : DataFrame,
                                      mappingpracticecommondatamaster : DataFrame,
                                      DemoGraphicsDF : DataFrame)  {
    import spark.implicits._

    try {

      val dfu =  new DataFrameUtils(spark,conf)
      val ProcedureObj = new CachePatientProcedureFunctions(spark, mappingPracticeProcedure, mappingpracticecommondatamaster)
      val validations = new ValidationCriteria(spark)
      val tableName = conf.getString("db_tb_procedure")
      val tempTableName = conf.getString("db_temp_procedure")

      CommonFunc.loggert("Reading files and applying headers")

      val cachePatientProcedure1 = CommonFunc.readFile(ProcedurePath,spark)
        .withColumn("ProcedureDate", to_timestamp($"ProcedureDate", "MM/dd/yyyy HH:mm:ss"))

      val addPatientUid =  cachePatientProcedure1.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PatientId","PracticeUid"))
        .select($"df1.*",$"df2.PatientUid")

      CommonFunc.loggert("applying validations on PatientProcedure files")

      val CacheProceduresValidations = addPatientUid
        .transform(validations.patientNotFound)
        .transform(validations.procedureCategoryNotFound)
        .transform(validations.procedureDateNotFound)
        .transform(validations.procedureCodeNotFound)
        //Doubt [not there in validations sheet but was applied in previous code]
        .transform(validations.removeDuplicateRecords(List("PatientUid","ProcedureCode","ProcedureDate","ServiceProviderNPI")))
        .transform(validations.removeDuplicateRecords(List("PatientUid","ProcedureText","ProcedureDate","ServiceProviderNPI")))

      CommonFunc.loggert("applying validations on PatientProcedure files successful")

      val cachePatientProcedureTransformed = CacheProceduresValidations
        .transform(ProcedureObj.PracticeCode)
        .transform(ProcedureObj.PracticeDescription)
        .transform(ProcedureObj.ProcedureStatusCode)
        .transform(ProcedureObj.ProcedureStatusText)
        .transform(ProcedureObj.TargetSiteCode)
        .transform(ProcedureObj.TargetSiteText)

      val getProcedurePartitions = dfu.getPatrtitions(cachePatientProcedureTransformed,"ProcedureDate",tableName)

      val allProceduremData = dfu.getInsertUpdateAndNCDData(cachePatientProcedureTransformed,getProcedurePartitions)
        .withColumn("Month",month($"df1.ProcedureDate"))

      HiveUtility.dfwritrtohiveVisit(allProceduremData,tableName,spark,tempTableName)
    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }
  }
}
