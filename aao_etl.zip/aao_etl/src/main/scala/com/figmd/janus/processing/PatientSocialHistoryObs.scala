package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{CachePatientVitalSignObservationFunctions, ValidationCriteria}
import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientSocialHistoryObs(SocialHistoryPath : String) {


  def cacheSocialHistoryObsProcessing(spark : SparkSession,
                                      mappingpracticecommondatamaster : DataFrame): Option[DataFrame] = {

    try {
      val patientVitalSignObservationDF = new CachePatientVitalSignObservationFunctions(spark, mappingpracticecommondatamaster)
      val validations = new ValidationCriteria(spark)

      CommonFunc.loggert("Reading files and applying headers")

      val cachePatientSocialHistoryObs = CommonFunc.readFile(SocialHistoryPath,spark)

      CommonFunc.loggert("applying validations on PatientSocialHistoryObs files")

      val CacheSocialHistoryObservationValidations = cachePatientSocialHistoryObs
          .transform(validations.documentationDateNotFound)
          .transform(validations.patientNotFound)
          .transform(validations.socialHistoryStatusNotFound)
          .transform(validations.socialHistoryTypeTextNotFound)

      CommonFunc.loggert("applying validations on PatientSocialHistoryObs files successful")

      val cacheSocialHistoryObsTransformed = CacheSocialHistoryObservationValidations
        .transform(patientVitalSignObservationDF.PracticeDescription)
        .transform(patientVitalSignObservationDF.PracticeCode)
        .transform(patientVitalSignObservationDF.TargetSiteText)
        .transform(patientVitalSignObservationDF.TargetSiteCode)
        .transform(patientVitalSignObservationDF.ObsInterpretationText)
        .transform(patientVitalSignObservationDF.ObsInterpretationCode)

      val cacheSocialHistoryObsStruct = cacheSocialHistoryObsTransformed.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("SocialHistoryStatusCode", "SocialHistoryStatusText"
          , "SocialHistoryTypeText", "EffectiveStopDate", "MasterSocialHistoryTypeCode", "MasterSocialHistoryStatusCode"
          , "MasterSocialHistoryStatusText", "SocialHistoryTypeCode", "QuitYear", "EffectiveStartDate", "SocialHxGroup"
          , "DocumentationDate", "MasterSocialHistoryTypeText", "SocialHistoryObservationKey", "YearsSmoked", "PracticeUid"
          , "SocialHistoryObservedValue")).as("SocialHistoryObservation"))

      Some(cacheSocialHistoryObsStruct)
    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }

}
