package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{CachePatientAdvObservationFunctions, ValidationCriteria}
import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientAdvanceDirectiveObservation(AdvanceDirPath : String) {

  def cacheAdvObsProcessing(spark : SparkSession,
                            mappingpracticecommondatamaster : DataFrame): Option[DataFrame] = {

    import spark.implicits._

    try {
      val tf = new CachePatientAdvObservationFunctions(spark,mappingpracticecommondatamaster)
      val validations = new ValidationCriteria(spark)


      CommonFunc.loggert("Reading  files and applying headers")

      val cachePatientAdvDirObservation = CommonFunc.readFile(AdvanceDirPath,spark)
        .withColumn("EffectiveStartDate", to_timestamp($"EffectiveStartDate", "MM/dd/yyyy HH:mm:ss"))
        .withColumn("EffectiveEndDate", to_timestamp($"EffectiveEndDate", "MM/dd/yyyy HH:mm:ss"))

      CommonFunc.loggert("applying validations on PatientAdvanceDirectiveObservation files")

      val cacheAdvanceDirectiveValidations = cachePatientAdvDirObservation
        .transform(validations.removeDuplicateRecords(List("PatientUid", "AdvanceDirectiveTypeUid", "AdvanceDirectiveTypeDetails", "EffectiveStartDate")))
        .transform(validations.AdvanceDirectiveStatusNotFound)

      val validatedRec = cacheAdvanceDirectiveValidations.filter(row => validations.checkNull(row,"AdvanceDirectiveTypeDetails","AdvanceDirectiveTypeCode","Patientid"))

      CommonFunc.loggert("applying validations on PatientAdvanceDirectiveObservation files successful")

      val cachePatientAdvObservation3 = validatedRec
        .transform(tf.DirectiveTypeCode)
        .transform(tf.DirectiveTypeDetails)
        .transform(tf.DirectiveStatusCode)
        .transform(tf.DirectiveStatusText)

      val cachePatientAdvObservation4 = cachePatientAdvObservation3.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("AdvanceDirectiveTypeCode", "AdvanceDirectiveTypeDetails", "AdvanceDirectiveStatusCode"
          , "AdvanceDirectiveStatusText", "EffectiveDate", "EffectiveDateTo", "AgentName"
          , "ExternalDocumentLink", "GroupName", "AdvanceDirectiveTypeText", "MasterAdvanceDirectiveStatusCode"
          , "MasterAdvanceDirectiveStatusText", "MasterAdvanceDirectiveTypeCode", "MasterAdvanceDirectiveTypeDetails"))
          .as("AdvanceDirectives"))

      Some(cachePatientAdvObservation4)
    }

    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }

}
