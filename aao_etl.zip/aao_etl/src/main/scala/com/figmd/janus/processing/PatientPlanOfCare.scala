package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{CachePlanOfCareFunctions, ValidationCriteria}
import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
class PatientPlanOfCare (PlanOfCarePath : String){

  def PlanOfCareProcessing(spark: SparkSession ,
                           mappingpracticecommondatamaster : DataFrame): Option[DataFrame] = {

try {
  val validations = new ValidationCriteria(spark)
  val patientPlanOfCare = new CachePlanOfCareFunctions(spark, mappingpracticecommondatamaster)

  CommonFunc.loggert("Reading  files and applying headers")

  //Read file for CachePatientPlanOfCare
  val CachePatientPlanOfCareDF = CommonFunc.readFile(PlanOfCarePath,spark)

  CommonFunc.loggert("applying validations on PatientPlanOfCare files")

  val CachePlanOfCareValidations = CachePatientPlanOfCareDF
    .transform(validations.patientNotFound)
    .transform(validations.planOfCareCodeAndPlanOfCareTextNotFound)
    .transform(validations.planOfCareCodeOrTextNotFound)
    .transform(validations.planOfCareStatusCodeOrTextNotFound)

  CommonFunc.loggert("applying validations on PatientPlanOfCare files successful")

  val transformPatientPlanOfCareDF = CachePlanOfCareValidations
    .transform(patientPlanOfCare.PlanOfCareStatusText)
    .transform(patientPlanOfCare.PlanOfCareStatusCode)
    .transform(patientPlanOfCare.PracticeDescription)
    .transform(patientPlanOfCare.PracticeCode)

  val PanOfCareDf = transformPatientPlanOfCareDF
    .groupBy("PatientId","PracticeUid")
    .agg(collect_list(struct("EffectiveDate", "Instructions", "PlanOfCareStatusCode",
      "PlanOfCareStatusText", "MasterPlanOfCareStatusCode", "MasterPlanOfCareStatusText", "PlanOfCareGroup",
      "PracticeCode", "PracticeDescription", "MasterPlanOfCareCode", "MasterPlanOfCareText"))
      .as("PlanOfCare"))

  Some(PanOfCareDf)
}
catch {
  case ex: FileNotFoundException => {
    println(s"File not found")
    None
  }
  case unknown: Exception => {
    println(s"Unknown exception: $unknown")
    None
  }
}
  }
}
