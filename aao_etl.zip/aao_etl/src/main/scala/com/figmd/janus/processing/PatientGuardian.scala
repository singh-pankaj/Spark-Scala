package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.ValidationCriteria
import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientGuardian(GuardianPath : String) {


  def PatientGuardianProcessing(spark: SparkSession): Option[DataFrame] = {

    try {

      val validations = new ValidationCriteria(spark)

      CommonFunc.loggert("Reading files and applying headers")

      val CachePatientGuardianDF: DataFrame = CommonFunc.readFile(GuardianPath,spark)

      CommonFunc.loggert("applying validations on PatientGuardian files")

      val CachePatientGuardianValidations = CachePatientGuardianDF
        .transform(validations.removeDuplicateRecords(List("PatientUid","PracticeUid","GuardianFirstName","GuardianLastName")))
/*
        .transform(validations.countryNotFound)
        .transform(validations.guardianNameNotFound)
        .transform(validations.patientNotFound)
        .transform(validations.stateNotFound)
        .transform(validations.telecomType1tNotFound)
*/

      val CleanedRecords = CachePatientGuardianValidations.filter(row=>validations.checkNull(row,"patientid","GuardianFirstName","GuardianLastName"))

      CommonFunc.loggert("applying validations on PatientGuardian files successful")

      val GuardianDF = CachePatientGuardianValidations
        .groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("RelationshipToPatientCode", "RelationshipToPatientText",
          "City", "CountryCode", "Country", "StateCode",
          "State", "GuardianFirstName", "GuardianLastName", "StreetLineAddress1",
          "StreetLineAddress2", "StreetLineAddress3", "StreetLineAddress4", "TelecomTypeText",
          "TelecomValue", "ZipCode")).as("PatientGuardian"))
      Some(GuardianDF)
    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }
}
