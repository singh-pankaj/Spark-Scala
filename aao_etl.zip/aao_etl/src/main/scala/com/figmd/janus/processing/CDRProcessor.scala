package com.figmd.janus.processing

//spark-submit --class com.figmd.janus.processing.CDRProcessor /home/dev/Akshay/justtest_2.11-0.1.jar
//spark-submit --driver-memory 10G --deploy-mode cluster --master yarn --executor-memory 3G --num-executors 3 --executor-cores 3 --conf spark.yarn.maxAppAttempts=1 --class com.figmd.janus_validation_test.CDRProcessor /home/dev/Akshay/test_validations_2.11-0.1.jar
//spark-submit --driver-memory 10G --deploy-mode cluster --master yarn --executor-memory 3G --num-executors 3 --executor-cores 3 --conf spark.yarn.maxAppAttempts=1 --class com.figmd.janus.processing.CDRProcessor --jars /home/dev/Akshay/config-1.2.1.jar /home/dev/Akshay/aao_etl_2.11-0.1.jar

import java.io.FileNotFoundException

import com.figmd.janus.resources.ApplicationConfig
import com.figmd.janus.util.{CommonFunc, DataFrameUtils, ReadTables, SparkUtility}
import com.typesafe.config.ConfigFactory
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.functions._


object CDRProcessor {
  val logger: Logger = Logger.getLogger(this.getClass.getName)

  def main(args: Array[String]): Unit = {

    try{
      Logger.getLogger("org").setLevel(Level.WARN)
      Logger.getLogger("akka").setLevel(Level.WARN)

      ApplicationConfig.setApplicationConfig(args)

      val conf = ConfigFactory.load("application.conf")

      val sparkUtility = new SparkUtility()
      val spark = sparkUtility.getSparkSession()
      val ReadTBL = new ReadTables
      val dfu = new DataFrameUtils(spark, conf)

      logger.info("reading tables and broadcasting")
      val masterAllergy = ReadTBL.getPostgresTable(spark, ApplicationConfig.prop.getProperty("Allergy"))
      broadcast(masterAllergy)

      val mappingPracticeProcedure = ReadTBL.getPostgresTable(spark, ApplicationConfig.prop.getProperty("Procedure")).cache()
      broadcast(mappingPracticeProcedure)

      val mappingpracticecommondatamaster = ReadTBL.getPostgresTable(spark, ApplicationConfig.prop.getProperty("Procedure")).cache()
      broadcast(mappingpracticecommondatamaster)

      val mappingpracticecommondatamasterethnicity = ReadTBL.getPostgresTable(spark, ApplicationConfig.prop.getProperty("Ethinicity")).cache()
      broadcast(mappingpracticecommondatamasterethnicity)

      val mappingpracticecommondatamasterrace = ReadTBL.getPostgresTable(spark, ApplicationConfig.prop.getProperty("Race")).cache()
      broadcast(mappingpracticecommondatamasterrace)

      val mappingpracticeinsurancedata = ReadTBL.getPostgresTable(spark, ApplicationConfig.prop.getProperty("Insurance")).cache()
      broadcast(mappingpracticeinsurancedata)

      val MappingPracticeProblem = ReadTBL.getPostgresTable(spark, ApplicationConfig.prop.getProperty("Problem")).cache()
      broadcast(MappingPracticeProblem)

      val MappingPracticeMedication = ReadTBL.getPostgresTable(spark, ApplicationConfig.prop.getProperty("Medication")).cache()
      broadcast(MappingPracticeMedication)

      val MappingPracticeCommonDataMasterMedicationRoute = ReadTBL.getPostgresTable(spark, ApplicationConfig.prop.getProperty("Route")).cache()
      broadcast(MappingPracticeCommonDataMasterMedicationRoute)

      val mappingracticecommondatamasterrelationship = ReadTBL.getPostgresTable(spark, ApplicationConfig.prop.getProperty("RelationShip")).cache()
      broadcast(mappingracticecommondatamasterrelationship)

      val section_headers = ReadTBL.getPostgresTable(spark, ApplicationConfig.prop.getProperty("section_headers")).cache()



      val PatientEthnicity_lookup= dfu.getlookupMap("PatientEthnicity",section_headers)
      val PatientImmunization_lookup= dfu.getlookupMap("PatientImmunization",section_headers)
      val PatientDemographics_lookup= dfu.getlookupMap("PatientDemographics",section_headers)
      val PatientresultObservation_lookup= dfu.getlookupMap("PatientresultObservation",section_headers)
      val PatientAllergy_lookup= dfu.getlookupMap("PatientAllergy",section_headers)
      val PatientProblem_lookup= dfu.getlookupMap("PatientProblem",section_headers)
      val PatientFamilyHistory_lookup= dfu.getlookupMap("PatientFamilyHistory	",section_headers)
      val PatientNote_lookup= dfu.getlookupMap("PatientNote",section_headers)
      val PatientEncounter_lookup= dfu.getlookupMap("PatientEncounter",section_headers)
      val PatientGuardian_lookup= dfu.getlookupMap("PatientGuardian",section_headers)
      val PatientInsurance_lookup= dfu.getlookupMap("PatientInsurance",section_headers)
      val PatientLabOrder_lookup= dfu.getlookupMap("PatientLabOrder	",section_headers)
      val PatientSocialHistoryObs_lookup= dfu.getlookupMap("PatientSocialHistoryObs	",section_headers)
      val PatientMedications_lookup= dfu.getlookupMap("PatientMedications",section_headers)
      val PatientLanguage_lookup= dfu.getlookupMap("PatientLanguage",section_headers)
      val PatientRace_lookup= dfu.getlookupMap("PatientRace",section_headers)
      val PatientProcedure_lookup= dfu.getlookupMap("PatientProcedure",section_headers)
      val PatientAdvanceDirectiveObservation_lookup= dfu.getlookupMap("PatientAdvanceDirectiveObservation",section_headers)
      val PatientPlanOfCare_lookup= dfu.getlookupMap("PatientPlanOfCare",section_headers)
      val PatientEncounterDiagnosis_lookup= dfu.getlookupMap("PatientEncounterDiagnosis",section_headers)
      val PatientVitalSignObservation_lookup= dfu.getlookupMap("PatientVitalSignObservation",section_headers)


      val PatientAdvanceDirectivePath = ApplicationConfig.prop.getProperty("PatientAdvanceDirectivePath")
      val PatientAllergiesPath = ApplicationConfig.prop.getProperty("PatientAllergiesPath")
      val PatientDemographicsPath = ApplicationConfig.prop.getProperty("PatientDemographicsPath")
      val PatientEncounterPath = ApplicationConfig.prop.getProperty("PatientEncounterPath")
      val PatientEncounterDiagnosisPath = ApplicationConfig.prop.getProperty("PatientEncounterDiagnosisPath")
      val PatientEthnicityPath = ApplicationConfig.prop.getProperty("PatientEthnicityPath")
      val PatientFamilyHistoryPath = ApplicationConfig.prop.getProperty("PatientFamilyHistoryPath")
      val PatientInsurancePath = ApplicationConfig.prop.getProperty("PatientInsurancePath")
      val PatientLanguagePath = ApplicationConfig.prop.getProperty("PatientLanguagePath")
      val PatientMedicationsPath = ApplicationConfig.prop.getProperty("PatientMedicationsPath")
      val PatientNotesPath = ApplicationConfig.prop.getProperty("PatientNotesPath")
      val PatientResultObservationPath = ApplicationConfig.prop.getProperty("PatientResultObservationPath")
      val PatientPlanOfCarePath = ApplicationConfig.prop.getProperty("PatientPlanOfCarePath")
      val PatientProblemPath = ApplicationConfig.prop.getProperty("PatientProblemPath")
      val PatientProceduresPath = ApplicationConfig.prop.getProperty("PatientProceduresPath")
      val PatientRacePath = ApplicationConfig.prop.getProperty("PatientRacePath")
      val PatientSocialHistoryObservationPath = ApplicationConfig.prop.getProperty("PatientSocialHistoryObservationPath")
      val PatientVitalSignsPath = ApplicationConfig.prop.getProperty("PatientVitalSignsPath")

      val PatientImmunizationPath = ApplicationConfig.prop.getProperty("PatientImmunizationPath")
      val PatientGuardianPath = ApplicationConfig.prop.getProperty("PatientGuardianPath")
      val PatientLabOrderPath = ApplicationConfig.prop.getProperty("PatientLabOrderPath")

      CommonFunc.loggert(" starting PatientDemo")

      val PatientDemoDF = new PatientDemographics(PatientDemographicsPath,conf)
        .CachePatientDemographicsProcessing(spark).toList

      CommonFunc.loggert("PatientDemo completed")

      val DemoGraphicsDF = PatientDemoDF.head.select("PatientId", "PracticeUid", "PatientUid")//.cache()

/*
      CommonFunc.loggert("starting PatientEthnicity")

      val PatientEthnicityDF = new PatientEthnicity(PatientEthnicityPath)
        .EthinicityProccessing(spark,
          DemoGraphicsDF,
          mappingpracticecommondatamasterethnicity).toList

      CommonFunc.loggert("PatientEthnicity completed")
      CommonFunc.loggert("starting cacheRaceProcessing")

      val PatientraceDF = new PatientRace(PatientRacePath)
        .cacheRaceProcessing(spark,
          DemoGraphicsDF,
          mappingpracticecommondatamasterrace).toList

      CommonFunc.loggert("cacheRaceProcessing completed")
*/
      CommonFunc.loggert("starting cachePatientEncounterProcessing")

      val CacheEncounterDF: Unit = new PatientEncounter(PatientEncounterPath)
        .cachePatientEncounterProcessing(spark,
          DemoGraphicsDF,
          conf)

      CommonFunc.loggert("cachePatientEncounterProcessing completed")
      CommonFunc.loggert("starting cachePatientinsuranceprocessing")

      val CachepatientInsuranceDF = new PatientInsurance(PatientInsurancePath)
        .cachePatientinsuranceprocessing(spark,
          mappingpracticeinsurancedata).toList

      CommonFunc.loggert("cachePatientinsuranceprocessing completed")
      CommonFunc.loggert("starting cachePatientProblemProcessing")

      val PatientProblemDF: Unit = new PatientProblem(PatientProblemPath)
        .cachePatientProblemProcessing(spark,
          MappingPracticeProblem,
          conf,
          DemoGraphicsDF)

      CommonFunc.loggert("cachePatientProblemProcessing completed")
      CommonFunc.loggert("starting cachePatientProcedureProceesing")


      val PatientProcedureDF: Unit = new PatientProcedure(PatientProceduresPath)
        .cachePatientProcedureProceesing(spark,conf,
          mappingPracticeProcedure,
          mappingpracticecommondatamaster,
          DemoGraphicsDF)

      CommonFunc.loggert("cachePatientProcedureProceesing completed")
      CommonFunc.loggert("starting cacheAdvObsProcessing")

      val PatientAdvanceDirectiveDF = new PatientAdvanceDirectiveObservation(PatientAdvanceDirectivePath)
        .cacheAdvObsProcessing(spark,
          mappingpracticecommondatamaster).toList

      CommonFunc.loggert("cacheAdvObsProcessing completed")
      CommonFunc.loggert("starting cacheAllergyProcessing")

      val PatientAllergyDF = new PatientAllergy(PatientAllergiesPath)
        .cacheAllergyProcessing(spark, masterAllergy, mappingpracticecommondatamaster).toList

      CommonFunc.loggert("cacheAllergyProcessing completed")
      CommonFunc.loggert("starting CacheMedicationsProcessing")

      val PatientMedicationDF: Unit = new PatientMedications(PatientMedicationsPath)
        .CacheMedicationsProcessing(spark, mappingPracticeProcedure, MappingPracticeMedication, mappingpracticecommondatamaster
          , conf, DemoGraphicsDF)

      CommonFunc.loggert("CacheMedicationsProcessing completed")
      CommonFunc.loggert("starting ImmunizationProcessing")

      val PatientImmunizationDF: Unit = new PatientImmunization(PatientImmunizationPath)
        .ImmunizationProcessing(spark, mappingpracticecommondatamaster,
          MappingPracticeCommonDataMasterMedicationRoute, mappingPracticeProcedure,
          MappingPracticeProblem, mappingpracticecommondatamaster, DemoGraphicsDF, conf)

      CommonFunc.loggert("ImmunizationProcessing completed")
      CommonFunc.loggert("starting PlanOfCareProcessing")

      val PatientPlanOfCareDF = new PatientPlanOfCare(PatientPlanOfCarePath)
        .PlanOfCareProcessing(spark, mappingpracticecommondatamaster).toList

      CommonFunc.loggert("PlanOfCareProcessing completed")
      CommonFunc.loggert("starting cacheresultObsProcessing")

      val PatientresultObservationbDF: Unit = new PatientResultObservation(PatientResultObservationPath)
        .cacheresultObsProcessing(spark, mappingpracticecommondatamaster,
          mappingPracticeProcedure, conf,
          DemoGraphicsDF)

      CommonFunc.loggert("cacheresultObsProcessing completed")
      CommonFunc.loggert("starting cacheSocialHistoryObsProcessing")

      val PatientSocialHistoryObsDF = new PatientSocialHistoryObs(PatientSocialHistoryObservationPath)
        .cacheSocialHistoryObsProcessing(spark, mappingpracticecommondatamaster).toList

      CommonFunc.loggert("cacheSocialHistoryObsProcessing completed")
      CommonFunc.loggert("starting VitalSignObservationProcessing")

      val PatientVitalSignDF: Unit = new PatientVitalSignObservation(PatientVitalSignsPath)
        .VitalSignObservationProcessing(spark,conf, mappingpracticecommondatamaster, DemoGraphicsDF)

      CommonFunc.loggert("VitalSignObservationProcessing completed")
      CommonFunc.loggert("starting FamilyHistoryProcessing")

      val PatientFamilyHistoryDF = new PatientFamilyHistory(PatientFamilyHistoryPath)
        .FamilyHistoryProcessing(spark, mappingracticecommondatamasterrelationship, mappingpracticecommondatamaster
          , MappingPracticeProblem)

      CommonFunc.loggert("FamilyHistoryProcessing completed")
      CommonFunc.loggert("starting PatientGuardianProcessing")


      val PatientGuardianDF = new PatientGuardian(PatientGuardianPath)
        .PatientGuardianProcessing(spark).toList


      CommonFunc.loggert("PatientGuardianProcessing completed")
      CommonFunc.loggert("starting cachepatientLangProcessing")

      val PatientLanguageDF = new PatientLanguage(PatientLanguagePath)
        .cachepatientLangProcessing(spark).toList


      CommonFunc.loggert("cachepatientLangProcessing completed")
      CommonFunc.loggert("starting PatientNoteProcessing")

      val PatientNotesDF: Unit = new PatientNote(PatientNotesPath)
        .PatientNoteProcessing(spark, DemoGraphicsDF, conf)

      CommonFunc.loggert("PatientNoteProcessing completed")

      val dflist = PatientDemoDF ++/* PatientEthnicityDF ++ PatientraceDF ++*/ PatientLanguageDF ++ PatientSocialHistoryObsDF ++ CachepatientInsuranceDF ++ PatientPlanOfCareDF ++ PatientAdvanceDirectiveDF ++ PatientAllergyDF ++ PatientFamilyHistoryDF ++ PatientGuardianDF

      dfu.sendPatientToHive(dflist)
    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }

//    val PatientLabOrderDF = (new PatientLabOrder(PatientLabOrderPath))
//     .CachePatientLabOrder(spark,conf,PatientLabOrder_lookup)

    //val EncounterDiagnosisDF = (new PatientEncounterDiagnosis(ApplicationConfig.prop.getProperty("EncounterDiagnosisPath")))
    // .CachePatientEncounterDiagnosis(spark)
  }


}

