package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{CacheAllergyFunctions, ValidationCriteria}
import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientAllergy(AllergyPath : String) {


  def cacheAllergyProcessing(spark : SparkSession,
                             masterAllergy : DataFrame,
                             mappingpracticecommondatamaster : DataFrame) : Option[DataFrame] = {
    try {

      import spark.implicits._
      val tf = new CacheAllergyFunctions(spark, masterAllergy, mappingpracticecommondatamaster)
      val validations = new ValidationCriteria(spark)

      CommonFunc.loggert("Reading  files and applying headers")

      val cacheAllergy = CommonFunc.readFile(AllergyPath,spark)
        .withColumn("EffectiveStartDate", to_timestamp($"EffectiveStartDate", "MM/dd/yyyy HH:mm:ss"))
        .withColumn("EffectiveEndDate", to_timestamp($"EffectiveEndDate", "MM/dd/yyyy HH:mm:ss"))

      CommonFunc.loggert("applying validations on PatientAllergy files")

      val cacheAllergiesValidations = cacheAllergy
        .transform(validations.removeDuplicateRecords(List("PatientUid", "AllergyUid", "EffectiveEndDate")))
        .transform(validations.allergiesNotFound)
        .transform(validations.allergyStatusCodeNotFound)
        .transform(validations.patientNotFound)

      val validatedRec = cacheAllergiesValidations.filter(row => validations.checkNull(row,"Patientid","AllergyStatusCode","AllergyStatusText"))


      CommonFunc.loggert("applying validations on PatientAllergy files successful")

      val cacheAllergy3 = cacheAllergiesValidations
        .transform(tf.AllergicToCode)
        .transform(tf.AllergicToDescription)
        .transform(tf.AllergyStatusCode)
        .transform(tf.AllergyStatusText)

      val cacheAllergy4 = cacheAllergy3.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("EffectiveStartDate", "EffectiveEndDate", "AllergyTypeCode"
          , "AllergyEventType", "AllergicToCode", "AllergicToDescription", "AllergyStatusCode"
          , "AllergyStatusText", "AllergyReaction", "MasterAllergyStatusCode", "MasterAllergyStatusText"
          , "MasterAllergicToCode", "MasterAllergyDescription")).as("Allergy"))

      Some(cacheAllergy4)
    }

    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }

}
