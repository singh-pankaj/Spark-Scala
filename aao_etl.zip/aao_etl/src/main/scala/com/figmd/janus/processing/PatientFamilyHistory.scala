package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{CachePatientFamilyHistory, ValidationCriteria}
import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientFamilyHistory(FamilyHistoryPath : String) {

  def FamilyHistoryProcessing(spark : SparkSession,
                              mappingpractivecommondatamasterrelationship : DataFrame,
                              mappingpracticecommondatamaster : DataFrame,
                              mappingpracticeproblem : DataFrame): Option[DataFrame] = {

    try {
      val validations = new ValidationCriteria(spark)
      val tf = new CachePatientFamilyHistory(spark, mappingpractivecommondatamasterrelationship, mappingpracticecommondatamaster, mappingpracticeproblem)


      CommonFunc.loggert("Reading  files and applying headers")

      val cachePatientFamilyHistory1 = CommonFunc.readFile(FamilyHistoryPath,spark)

      CommonFunc.loggert("applying validations on PatientFamilyHistory files")

      val cacheFamilyHistoryValidations = cachePatientFamilyHistory1
        .transform(validations.removeDuplicateRecords(List("PatientId","PracticeUid","problemCode","effectivedate","RelationshipToPatientText")))
        .transform(validations.removeDuplicateRecords(List("PatientId","PracticeUid","problemtext","effectivedate","RelationshipToPatientText")))
        .transform(validations.relationshipToPatientTextInvalid)
      /*
        .transform(validations.genderUidNotFound)
        .transform(validations.patientNotFound)
        .transform(validations.problemTextAndProblemCodeNotFound)
        .transform(validations.problemTypeCodeNotFound)
        .transform(validations.relationshipToPatientTextNotFound)
        */

      val CleanedRecords = cacheFamilyHistoryValidations.filter(row=>validations.checkNull(row,"patientid"))


      CommonFunc.loggert("applying validations on PatientFamilyHistory files successful")

      val cacheFamilyHistoryTransformations = cacheFamilyHistoryValidations
        .transform(tf.RelationshipToPatientCode)
        .transform(tf.RelationshipToPatientText)
        .transform(tf.ProblemTypeCode)
        .transform(tf.ProblemTypeText)
        .transform(tf.ProblemCode)
        .transform(tf.ProblemDescription)


      val cacheFamilyHistory4 = cacheFamilyHistoryTransformations.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("RelationshipToPatientCode", "MasterRelationshipToPatientCode", "MasterRelationshipToPatientText"
          , "ProblemTypeCode", "ProblemTypeText", "MasterProblemTypeCode", "MasterProblemTypeText"
          , "ProblemCode", "ProblemDescription", "MasterProblemCode", "MasterProblemDescription"
          , "FamilyMemberAge", "IsAlive", "FamilyMemberLastName", "FamilyMemberFirstName", "ObservationDate"
          , "PatientRelationshipToFamilyMemberText", "CodeSystem")).as("PatientFamilyHistory"))

      Some(cacheFamilyHistory4)
    }

    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }
}
