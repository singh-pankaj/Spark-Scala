package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.ValidationCriteria
import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientLanguage(LanguagePath : String) {


  def cachepatientLangProcessing(spark : SparkSession) : Option[DataFrame] = {

    try {
      val validations = new ValidationCriteria(spark)

      CommonFunc.loggert("Reading files and applying headers")

      val CachePatientLanguage = CommonFunc.readFile(LanguagePath,spark)

      CommonFunc.loggert("applying validations on PatientLanguage files")

      val CachePatientLanguageValidations = CachePatientLanguage
        .transform(validations.languageCodeAndLanguageTextNotFound)
        .transform(validations.patientNotFound)

      CommonFunc.loggert("applying validations on PatientLanguage files successful")

      val CachePatientLanguageStruct = CachePatientLanguageValidations.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("LanguageCode", "LanguageText", "LangaugeAbilityModeCode"
          , "LangaugeAbilityModeText", "LanguageProficiencyLevelCode"
          , "LanguageProficiencyLevelText", "PreferenceInd")).as("Language"))

      Some(CachePatientLanguageStruct)
    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }

}
