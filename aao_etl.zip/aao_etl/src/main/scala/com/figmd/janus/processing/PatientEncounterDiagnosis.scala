package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.ValidationCriteria
import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientEncounterDiagnosis {


  def CachePatientEncounterDiagnosis(spark:SparkSession,
                                     EncounterPath:String): Option[DataFrame] = {

    try{

      val validations = new ValidationCriteria(spark)

      //val EncounterPath = "temp_test/AllFiles/608CDEE4_*"

      CommonFunc.loggert("Reading  files and applying headers")
      //Read file for CacheMedications and Apply lookup to generate file Header
      val CacheEncounterDiagnosis: DataFrame = CommonFunc.readFile(EncounterPath,spark)

      val cacheEncounterDiagnosisValidations = CacheEncounterDiagnosis
        .transform(validations.removeDuplicateRecords(List("PatientUid","EncounterDiagnosisCode","DocumentationDate")))
        .transform(validations.removeDuplicateRecords(List("VisitUid","CodeUid","DocumentationDate")))
        .transform(validations.invalidNPIFound)
      /*
        .transform(validations.encounterDiagnosisCodeAndTextNotFound)
        .transform(validations.documentationDateNotFound)
        .transform(validations.encounterDiagnosisCategoryNotFound)
        .transform(validations.visitUidNotFound)
        .transform(validations.patientNotFound)
        .transform(validations.problemHealthStatusCodeNotFound)
        .transform(validations.problemStatusCodeNotFound)
        .transform(validations.serviceLocationIdNotFound)
*/


      val CleanedRecords = cacheEncounterDiagnosisValidations.filter(row=>validations.checkNull(row,"EncounterDiagnosisCode","EncounterDiagnosisText","ServiceProviderNPI"))

      val EncounterDiagnosis: DataFrame = cacheEncounterDiagnosisValidations.groupBy("PatientId")
        .agg(collect_list(struct("EncounterDate","ServiceProviderNPI","ServiceProviderLastName",
      "ServiceProviderFirstName","ServiceLocationId","ServiceLocationName","EncounterDiagnosisCode","EncounterDiagnosisText",
      "EncounterDiagnosisCategory","EncounterProblemTypeCode","EncounterProblemTypeText","DocumentationDate",
      "ProblemResolutionDate","ProblemStatusCode","ProblemStatusText","ProblemHealthStatusCode","ProblemHealthStatusText",
      "NegationInd","ProblemComment","ProblemOnsetDate","TargetSiteCode","TargetSiteText","ListOrder","EncounterDiagnosisKey",
      "PracticeUid","BatchUid")).as("EncounterDiagnosis"))

      Some(EncounterDiagnosis)

}
catch {
  case ex: FileNotFoundException => {
    println(s"File not found")
    None
  }
  case unknown: Exception => {
    println(s"Unknown exception: $unknown")
    None
  }
}

  }
}
