package com.figmd.janus.resources

import java.util.Properties
import org.apache.log4j.{Level, Logger}
object ApplicationConfig {
  var prop = new Properties

  def setApplicationConfig(args: Array[String]): Unit =
  {
    prop.setProperty("warehouse", "/user/hive/warehouse")
    prop.setProperty("awsAccessKeyId", "AKIAL35LZ5DVCIC4JZRQ")
    prop.setProperty("awsSecretAccessKey", "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")
    prop.setProperty("postgresHostName", "10.20.201.36")
    prop.setProperty("postgresHostPort", "5432")
    prop.setProperty("postgresManagementDatabaseName", "figmdhqimanagementaao")
    prop.setProperty("postgresHostUserName", "postgres")
    prop.setProperty("postgresUserPass", "Janus@123")
    prop.setProperty("num_executors", "2")
    prop.setProperty("executor_cores", "2")
    prop.setProperty("executor_memory", "3G")
    prop.setProperty("spark_master_url", "yarn")
    prop.setProperty("mode", "cluster")
    prop.setProperty("Allergy", "mappingpracticeallergy")
    prop.setProperty("Procedure", "mappingpracticeprocedure")
    prop.setProperty("PracticeCommonDta", "mappingpracticecommondatamaster")
    prop.setProperty("Ethinicity", "mappingpracticecommondatamasterethnicity")
    prop.setProperty("Race", "mappingpracticecommondatamasterrace")
    prop.setProperty("Insurance", "mappingpracticeinsurancedata")
    prop.setProperty("Problem", "MappingPracticeProblem")
    prop.setProperty("Medication", "MappingPracticeMedication")
    prop.setProperty("Route", "MappingPracticeCommonDataMasterMedicationRoute")
    prop.setProperty("RelationShip", "MappingPracticeCommonDataMasterMedicationRoute")
    prop.setProperty("section_headers", "section_headers")
    prop.setProperty("RootPath", "temp_test/aao_parquet_data")
    val rootPath = prop.getProperty("RootPath")


    prop.setProperty("PatientAdvanceDirectivePath", s"$rootPath/PatientAdvanceDirective/")
    prop.setProperty("PatientAllergiesPath", s"$rootPath/PatientAllergies/")
    prop.setProperty("PatientDemographicsPath", s"$rootPath/PatientDemographics/")
    prop.setProperty("PatientEncounterPath", s"$rootPath/PatientEncounter/")
    prop.setProperty("PatientEncounterDiagnosisPath", s"$rootPath/PatientEncounterDiagnosis/")
    prop.setProperty("PatientEthnicityPath", s"$rootPath/PatientEthnicity/")
    prop.setProperty("PatientFamilyHistoryPath", s"$rootPath/PatientFamilyHistory/")
    prop.setProperty("PatientInsurancePath", s"$rootPath/PatientInsurance/")
    prop.setProperty("PatientLanguagePath", s"$rootPath/PatientLanguage/")
    prop.setProperty("PatientMedicationsPath", s"$rootPath/PatientMedications/")
    prop.setProperty("PatientNotesPath", s"$rootPath/PatientNotes/")
    prop.setProperty("PatientResultObservationPath", s"$rootPath/PatientResultObservation/")
    prop.setProperty("PatientPlanOfCarePath", s"$rootPath/PatientPlanOfCare/")
    prop.setProperty("PatientProblemPath", s"$rootPath/PatientProblem/")
    prop.setProperty("PatientProceduresPath", s"$rootPath/PatientProcedures/")
    prop.setProperty("PatientRacePath", s"$rootPath/PatientRace/")
    prop.setProperty("PatientSocialHistoryObservationPath", s"$rootPath/PatientSocialHistoryObservation/")
    prop.setProperty("PatientVitalSignsPath", s"$rootPath/PatientVitalSigns/")
//
    prop.setProperty("PatientImmunizationPath", s"$rootPath/PatientImmunization/")
    prop.setProperty("PatientGuardianPath", s"$rootPath/PatientGuardian/")
    prop.setProperty("PatientLabOrderPath", s"$rootPath/PatientLabOrder/")


    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)
    Logger.getLogger("myLogger").setLevel(Level.OFF)


  }
}

