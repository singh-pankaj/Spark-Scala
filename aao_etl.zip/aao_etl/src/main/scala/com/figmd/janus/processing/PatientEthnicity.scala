package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.{CacheEthnicityFunction, ValidationCriteria}
import com.figmd.janus.util.CommonFunc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientEthnicity(EthnicityPath : String) {


  def EthinicityProccessing(spark : SparkSession,
                            DemoGraphicsDF:DataFrame,
                            MasterEthnicity : DataFrame) : Option[DataFrame] = {


    try {

      import spark.implicits._
      CommonFunc.loggert( "CachePatientEthnicity section started")

      val tf1 = new CacheEthnicityFunction(spark, MasterEthnicity)
      val validations = new ValidationCriteria(spark)



      //val ReadS3File = CommonFunc.readFile(EthnicityPath,spark)

      //ReadS3File.write.mode(saveMode = "overwrite").csv("./temp_test/Test_repartition/CachePatientEthnicity")


      CommonFunc.loggert("Reading  files ")

      val CacheEthnicityTable = CommonFunc.readFile(EthnicityPath,spark)

      CacheEthnicityTable.cache()
      val CacheEthnicityDF = CacheEthnicityTable.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PatientId","PracticeUid")).select($"df1.*",$"df2.PatientUid")

      CommonFunc.loggert("applying validations on PatientEthnicity files")

      val CachePatientEthnicityValidations = CacheEthnicityDF
        .transform(validations.removeDuplicateRecords(List("PatientUid","PatientEthnicityText")))
/*
        .transform(validations.ethnicityCodeOrTextNotFound)
        .transform(validations.patientNotFound)
*/


        val validatedRec = CachePatientEthnicityValidations.filter(row => validations.checkNull(row,"PatientEthnicityCode","PatientEthnicityText","Patientid"))


      val targetTable = spark.table("").columns

      CachePatientEthnicityValidations
          .select(targetTable.head, targetTable.tail:_*)

      CommonFunc.loggert("applying validations on PatientEthnicity files successful")


      CommonFunc.loggert("applying Transformations on PatientEthnicity files")

      val cacheAllergy3 = CachePatientEthnicityValidations
        .transform(tf1.PatientEthnicityText)
        .transform(tf1.PatientEthnicityCode)

      CommonFunc.loggert("applying Transformations on PatientEthnicity files successful")

      CommonFunc.loggert("creating PatientEthnicity struct")

      val CacheEthnicity = cacheAllergy3.groupBy("PatientId","PracticeUid")
        .agg(collect_list(struct("PatientEthnicityText", "PatientEthnicityCode", "MasterPatientEthnicityText"
          , "MasterPatientEthnicityCode")).as("Ethnicity"))

      CommonFunc.loggert("creating PatientEthnicity struct successful")

      Some(CacheEthnicity)
    }
      catch {
        case ex: FileNotFoundException => {
          println(s"File not found")
          None
        }
        case unknown: Exception => {
          println(s"Unknown exception: $unknown")
          None
        }
      }

    }
}
