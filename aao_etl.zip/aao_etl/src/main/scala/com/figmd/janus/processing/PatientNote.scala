package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.ValidationCriteria
import com.figmd.janus.util.{CommonFunc, DataFrameUtils, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientNote(PatientNotePath : String) {


  def PatientNoteProcessing(spark : SparkSession, DemoGraphicsDF : DataFrame, conf : Config) {

    import spark.implicits._

    try {
      val dfu =  new DataFrameUtils(spark,conf)
      val validations = new ValidationCriteria(spark)

      val tableName = conf.getString("db_tb_PatientNote")

      CommonFunc.loggert("Reading  files and applying headers")

      val CachePatientNotes = CommonFunc.readFile(PatientNotePath,spark)
        .withColumn("referencedDate", to_timestamp($"referencedDate", "MM/dd/yyyy HH:mm:ss"))

      CommonFunc.loggert("applying validations on PatientNote files")

      val CachePatientNotesValidations = CachePatientNotes
        .transform(validations.noteNotFound)
        .transform(validations.patientNotFound)
        .transform(validations.practicePatientNoteKeyNotFound)
        .transform(validations.sectionNameNotFound)

      CommonFunc.loggert("applying validations on PatientNote files successful")

      val addPatientUid = CachePatientNotesValidations.as("df1").join(DemoGraphicsDF.as("df2")
        , Seq("PatientId", "PracticeUid"))
        .select($"df1.*", $"df2.PatientUid")

      val getPatientNotePartitions = dfu.getPatrtitions(addPatientUid,"referencedDate",tableName)

      val allPatientNoteData = dfu.getInsertUpdateAndNCDData(addPatientUid,getPatientNotePartitions)
        .withColumn("Year", year($"referencedDate"))
        .withColumn("Month", month($"referencedDate"))

      val tempTableName = "figmdcdr_temp.patientnotes"
      HiveUtility.dfwritrtohiveVisit(allPatientNoteData, tableName, spark, tempTableName)
    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }
  }
}
