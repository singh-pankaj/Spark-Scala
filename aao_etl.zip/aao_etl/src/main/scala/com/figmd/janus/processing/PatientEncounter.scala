package com.figmd.janus.processing

import java.io.FileNotFoundException

import com.figmd.janus.criteria.ValidationCriteria
import com.figmd.janus.util.{CommonFunc, DataFrameUtils, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}


class PatientEncounter(EncounterPath : String) {


  def cachePatientEncounterProcessing(spark : SparkSession,
                                      DemoGraphicsDF : DataFrame,
                                      conf : Config): Unit = {

    //Start Encounter

    //Its Required
    // val df2 =CacheEncounter.withColumn("_c3", to_timestamp($"_c3", "MM/dd/yyyy HH:mm:ss")).select("_c3")

    import spark.implicits._
    try {

      val dfu =  new DataFrameUtils(spark,conf)
      val validations = new ValidationCriteria(spark)

      val tableName = conf.getString("db_tb_Visit")
      val tempTableName = conf.getString("db_temp_encounter")


      val CacheEncounter = CommonFunc.readFile(EncounterPath,spark)
        .withColumn("EncounterStartDate", to_timestamp($"EncounterStartDate", "MM/dd/yyyy HH:mm:ss"))

      CommonFunc.loggert("applying validations on PatientEncounter files")

      val cacheEncounterValidations = CacheEncounter
        .transform(validations.encouterDateNotFound)
        //.transform(validations.removeDuplicateRecords(List("Visituid")))
        .transform(validations.removeDuplicateRecords(List("ServiceLocationid", "PracticeUid")))
        .transform(validations.removeDuplicateRecords(List("PatientId", "PracticeUid", "EncounterStartDate", "ServiceProviderNPI", "ServiceLocationId")))
        .transform(validations.invalidNPIFound)
/*
        .transform(validations.futureVisitFound)
        .transform(validations.patientNotFound)
        .transform(validations.serviceLocationIdNotFound)
        .transform(validations.serviceProviderNPINotFound)
*/


      val CleanedRecords = cacheEncounterValidations.filter(row=>validations.checkNull(row,"patientid","EncounterStartDate","ServiceLocationId","ServiceProviderNPI"))



      CommonFunc.loggert("applying validations on PatientEncounter files successful")

      //      val dropDuplicates = CacheEncounter.dropDuplicates("PatientId", "ServiceProviderNPI", "ServiceLocationName"
      //        , "EncounterStartDate")

      val addPatientUid =  cacheEncounterValidations.as("df1").join(DemoGraphicsDF.as("df2")
        ,Seq("PatientId","PracticeUid")).select($"df1.*",$"df2.PatientUid")

      val EncounterData = dfu.getPatrtitions(cacheEncounterValidations,"EncounterStartDate",tableName)

      //Get Insert Update and No change Records

      val VisitAllRecords = dfu.getVisitInsertUpdateAndNCDData(addPatientUid,EncounterData)
        .withColumn("Year",year($"EncounterStartDate"))
        .withColumn("Month",month($"EncounterStartDate"))


      CommonFunc.loggert("writing encounter/visit file to hive" )

      HiveUtility.dfwritrtohiveVisit(VisitAllRecords,tableName,spark,tempTableName)
    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File not found")

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }
  }
}
