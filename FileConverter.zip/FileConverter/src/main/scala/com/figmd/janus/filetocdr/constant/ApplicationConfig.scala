package com.figmd.janus.filetocdr.constant

import java.util.Properties

import org.apache.log4j.{Level, Logger}

object ApplicationConfig {

  var prop = new Properties

  def setApplicationConfig(args: Array[String]): Unit =
  {

    prop.setProperty("awsAccessKeyId", "AKIALH6XLTJCI6I3N5RQ")
    prop.setProperty("awsSecretAccessKey", "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")
    prop.setProperty("postgresHostName", "10.20.201.36")
    prop.setProperty("warehouse", "/user/hive/warehouse")
    prop.setProperty("postgresHostPort", "5432")
    prop.setProperty("postgresManagementDatabaseName", "figmdhqimanagementaao")
    prop.setProperty("postgresHostUserName", "postgres")
    prop.setProperty("postgresUserPass", "Janus@123")
    prop.setProperty("num_executors", "7")
    prop.setProperty("executor_cores", "5")
    prop.setProperty("executor_memory", "8G")
    prop.setProperty("spark_master_url", "local[*]")
    prop.setProperty("mode", "cluster")
    prop.setProperty("Allergy", "mappingpracticeallergy")
    prop.setProperty("Procedure", "mappingpracticeprocedure")
    prop.setProperty("PracticeCommonData", "mappingpracticecommondatamaster")
    prop.setProperty("Ethinicity", "mappingpracticecommondatamasterethnicity")
    prop.setProperty("Race", "mappingpracticecommondatamasterrace")
    prop.setProperty("Insurance", "mappingpracticeinsurancedata")
    prop.setProperty("Problem", "MappingPracticeProblem")
    prop.setProperty("Medication", "MappingPracticeMedication")
    prop.setProperty("Route", "MappingPracticeCommonDataMasterMedicationRoute")
    prop.setProperty("RelationShip", "MappingPracticeCommonDataMasterMedicationRoute")

    //prop.setProperty("RootPath", "temp_test/aao_parquet_data")
    prop.setProperty("RootPath","/home/akshay.rochwani/IdeaProjects/FileConverter/target/scala-2.11/aao_test_parquet_data/")
    val rootPath = prop.getProperty("RootPath")


    prop.setProperty("PatientAdvanceDirectivePath", s"$rootPath/PatientAdvanceDirective/")
    prop.setProperty("PatientAllergiesPath", s"$rootPath/PatientAllergies/")
    prop.setProperty("PatientDemographicsPath", s"$rootPath/PatientDemographics/")
    prop.setProperty("PatientEncounterPath", s"$rootPath/PatientEncounter/")
    prop.setProperty("PatientEncounterDiagnosisPath", s"$rootPath/PatientEncounterDiagnosis/")
    prop.setProperty("PatientEthnicityPath", s"$rootPath/PatientEthnicity/")
    prop.setProperty("PatientFamilyHistoryPath", s"$rootPath/PatientFamilyHistory/")
    prop.setProperty("PatientInsurancePath", s"$rootPath/PatientInsurance/")
    prop.setProperty("PatientLanguagePath", s"$rootPath/PatientLanguage/")
    prop.setProperty("PatientMedicationsPath", s"$rootPath/PatientMedications/")
    prop.setProperty("PatientNotesPath", s"$rootPath/PatientNotes/")
    prop.setProperty("PatientResultObservationPath", s"$rootPath/PatientResultObservation/")
    prop.setProperty("PatientPlanOfCarePath", s"$rootPath/PatientPlanOfCare/")
    prop.setProperty("PatientProblemPath", s"$rootPath/PatientProblem/")
    prop.setProperty("PatientProceduresPath", s"$rootPath/PatientProcedures/")
    prop.setProperty("PatientRacePath", s"$rootPath/PatientRace/")
    prop.setProperty("PatientSocialHistoryObservationPath", s"$rootPath/PatientSocialHistoryObservation/")
    prop.setProperty("PatientVitalSignsPath", s"$rootPath/PatientVitalSigns/")
    //
    prop.setProperty("PatientImmunizationPath", s"$rootPath/PatientImmunization/")
    prop.setProperty("PatientGuardianPath", s"$rootPath/PatientGuardian/")
    prop.setProperty("PatientLabOrderPath", s"$rootPath/PatientLabOrder/")

    prop.setProperty("CDRPatient","hdfsmaindb.patient123456")
    prop.setProperty("CDREthinicity","hdfsmaindb.patient123456")
    prop.setProperty("CDRRace","hdfsmaindb.patient123456")
    prop.setProperty("CDRVisit","newfigmdaaocdr.visit")
    prop.setProperty("CDRProblem","newfigmdaaocdr.patientproblem")
    prop.setProperty("CDRProcedure","newfigmdaaocdr.patientprocedure")
    prop.setProperty("CDRMedication","newfigmdaaocdr.patientmedication")
    prop.setProperty("CDRResultObservation","newfigmdaaocdr.patientresultobservation")
    prop.setProperty("CDRVitalSigns","newfigmdaaocdr.patientvitalsignobservation")
    prop.setProperty("CDRPatientNotes","newfigmdaaocdr.patientnotes")



    //prop.setProperty("s3LocationPatient","hdfs://ip-10-20-201-191.us-gov-west-1.compute.internal:8020/user/dev/aaoData/patient_stage12/")
    //prop.setProperty("s3LocationPatient","hdfs://ip-10-20-201-191.us-gov-west-1.compute.internal:8020/user/dev/aaoData/patient_stage12345/")

    prop.setProperty("StagePatient","hdfsmaindb.patient_stage123456")
    prop.setProperty("s3LocationPatient","s3://bd-dev/AAODATA/Statgging/PHI/AAO/patient_stage123456/")

    prop.setProperty("StageEthinicity","hdfsmaindb.patient_stage123456")
    prop.setProperty("s3LocationRace","s3://bd-dev/AAODATA/Statgging/PHI/AAO/patient_stage123456/")

    prop.setProperty("StageRace","hdfsmaindb.patient_stage123456")
    prop.setProperty("s3LocationEthinicity","s3://bd-dev/AAODATA/Statgging/PHI/AAO/patient_stage123456/")

    prop.setProperty("StageVisit","newstructure.visit")
    prop.setProperty("s3LocationVisit","s3://bd-dev/AAODATA/NewStructure/PHI/AAO/PatientVisit/")

    prop.setProperty("HiveProblemTableName","newstructure.patientproblem")
    prop.setProperty("s3LocationProblem","s3://bd-dev/AAODATA/NewStructure/PHI/AAO/PatientProblem/")

    prop.setProperty("HiveProcedureTableName","newstructure.patientprocedure")
    prop.setProperty("s3LocationProcedure","s3://bd-dev/AAODATA/NewStructure/PHI/AAO/PatientProcedure/")

    prop.setProperty("HiveMedicationTableName","newstructure.patientmedication")
    prop.setProperty("s3LocationMedication","s3://bd-dev/AAODATA/NewStructure/PHI/AAO/PatientMedication/")

    prop.setProperty("HiveImmunizationTableName","")
    prop.setProperty("s3LocationImmunization","")

    prop.setProperty("HiveResultObsTableName","newstructure.patientresultobservation")
    prop.setProperty("s3LocationResObs","s3://bd-dev/AAODATA/NewStructure/PHI/AAO/PatientResultObservation/")

    prop.setProperty("HiveVitalSignTableName","newstructure.patientvitalsignobservation")
    prop.setProperty("s3LocationVitalsign","s3://bd-dev/AAODATA/NewStructure/PHI/AAO/PatientVitalSignObservation/")

    prop.setProperty("HivePatientNotesTableName","newstructure.patientnotes")
    prop.setProperty("s3LocationPatientNotes","s3://bd-dev/AAODATA/NewStructure/PHI/AAO/PatientNotes/")

    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)
    Logger.getLogger("myLogger").setLevel(Level.OFF)


  }
}
