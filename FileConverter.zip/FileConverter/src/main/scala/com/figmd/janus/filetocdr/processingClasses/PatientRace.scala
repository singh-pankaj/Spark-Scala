package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.RaceTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{broadcast, col, collect_list, struct}

class PatientRace(RacePath : String,selectedIds : DataFrame) {

  def cacheRaceProcessing(sparkSess : SparkSession, MasterRace : DataFrame)  = {


    val mainTableName = ApplicationConfig.prop.getProperty("CDRRace")
    val stagetableName = ApplicationConfig.prop.getProperty("StageRace")
    val s3Path = ApplicationConfig.prop.getProperty("s3LocationRace")

    import sparkSess.implicits._

    try {
      var CachePatientRaceTable = CommonFunc.readFile(RacePath,sparkSess).drop("dummy1", "dummy2")

      val lookup3 = Map("_c0" -> "PatientId", "_c1" -> "PatientRaceCode", "_c2" -> "PatientRaceText"
        , "_c3" -> "PatientRaceKey", "_c4" -> "PracticeUid"
        , "_c5" -> "BatchUid", "_c6" -> "dummy1", "_c7" -> "dummy2")

      CachePatientRaceTable = CachePatientRaceTable.select(CachePatientRaceTable.columns.map(c => col(c).as(lookup3.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")


      CommonFunc.loggert("applying validations on PatientRace files")
      val validations = new ValidationCriteria(sparkSess)

      val CleanedData =  CachePatientRaceTable
        .transform(validations.patientNotFound)
        .transform(validations.raceCodeAndTextNotFound)
        //Doubt [not there in validations sheet but was applied in previous code]
        .transform(validations.removeDuplicateRecords(List("PatientUid","PatientRaceText")))

      CommonFunc.loggert("applying validations on PatientRace files successful")


      val addPatientUid =  CleanedData.as("df1").join(selectedIds.as("df2")
        ,Seq("PracticeUid","PatientId")).select($"df1.*",$"df2.PatientUid")

      val raceObj = new RaceTransformFunctions(sparkSess, MasterRace)

      val CachePatientRace = addPatientUid
        .transform(raceObj.PatientRaceText)
        .transform(raceObj.PatientRaceCode)

      val distinctPUid = CachePatientRace.select("PracticeUid").distinct()

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val RaceData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val fileJoinids = CachePatientRace.select("PracticeUid","PatientId")
      broadcast(fileJoinids)

      val OtherData =  RaceData.as("df1").join(fileJoinids.as("df2")
        ,  $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId","left_anti")
        .select($"df1.*")

      val AllData = CachePatientRace.union(OtherData)

      //HiveUtility.dfwritrtohivePatient(AllData,mainTableName,sparkSess,stagetableName,s3Path)


    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }

  }

}
