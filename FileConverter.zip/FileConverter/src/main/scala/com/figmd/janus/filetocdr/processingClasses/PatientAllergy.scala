package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.AllergyTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import org.apache.spark.sql.functions.{collect_list, struct, to_timestamp}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

class PatientAllergy(AllergiesPath : String,selectedIds : DataFrame) {


  def cacheAllergyProcessing(sparkSess : SparkSession, masterAllergy : DataFrame,mappingpracticecommondatamaster : DataFrame
                            ) {



    try {
      import sparkSess.implicits._

      val mainTableName = ApplicationConfig.prop.getProperty("CDRAdvanceDirectives")
      val stagetableName = ApplicationConfig.prop.getProperty("StageAdvanceDirectives")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationAdvanceDirectives")
      val file = CommonFunc.readFile(AllergiesPath,sparkSess)

      val lookup1 = Map("_c0" -> "PatientId", "_c1" -> "EffectiveStartDate", "_c2" -> "EffectiveEndDate"
        , "_c3" -> "AllergyTypeCode", "_c4" -> "AllergyEventType", "_c5" -> "AllergicToCode"
        , "_c6" -> "AllergicToDescription", "_c7" -> "AllergyStatusCode"
        , "_c8" -> "AllergyStatusText", "_c9" -> "AllergyReaction", "_c10" -> "AllergiesKey"
        ,"_c11" -> "PracticeUid","_c12" -> "BatchUid","_c13" -> "dummy1","_c14" -> "dummy2")

      val cacheAllergy = file.select(file.columns.map(c => col(c).as(lookup1.getOrElse(c, c))): _*)
          .drop("dummy1","dummy2")
        .withColumn("EffectiveStartDate", to_timestamp($"EffectiveStartDate", "MM/dd/yyyy HH:mm:ss"))
        .withColumn("EffectiveEndDate", to_timestamp($"EffectiveEndDate", "MM/dd/yyyy HH:mm:ss"))

      val addPatientUid =  cacheAllergy.as("df1").join(selectedIds.as("df2")
        ,Seq("PracticeUid","PatientId")).select($"df1.*",$"df2.PatientUid")

      val tf = new AllergyTransformFunctions(sparkSess, masterAllergy, mappingpracticecommondatamaster)

      val cacheAllergy3 = addPatientUid
        .transform(tf.AllergicToCode)
        .transform(tf.AllergicToDescription)
        .transform(tf.AllergyStatusCode)
        .transform(tf.AllergyStatusText)

      val distinctPUid = cacheAllergy3.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val AllergyData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cacheAllergy3.select("PracticeUid","PatientId","PatientUid")
      broadcast(FiletoJoin)

      val otherData = AllergyData.as("df1").join(FiletoJoin.as("df2")
        , Seq("PracticeUid","PatientId","PatientUid"), "left_anti")
        .select($"df1.*")

      val AllProblemData = cacheAllergy3.union(otherData)

      HiveUtility.dfwritrtohivePatient(AllProblemData,mainTableName,sparkSess,stagetableName,s3Path)

    }


    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }

}
