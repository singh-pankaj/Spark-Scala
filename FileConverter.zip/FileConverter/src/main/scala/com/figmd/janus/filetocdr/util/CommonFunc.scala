package com.figmd.janus.filetocdr.util

import java.util.{Date, UUID}

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.udf

object CommonFunc {


  val getNewUid = udf[String](() => {
    UUID.randomUUID.toString
  })

  val updateWithJoin = udf[String,String,String]((column1: String, column2: String) => {
    if (column1 == null) column2
    else column1
  })

  def readFile(path : String,sparkSess : SparkSession) : DataFrame ={
    //sparkSess.read.option("delimiter", "\u0017").parquet(path)
    sparkSess.read.parquet(path)
  }

  def loggert(string: String):Unit={
    val time = System.currentTimeMillis()
    val date = new Date(time)
    println(s"APPLOG : $date : " + string)
  }
}
