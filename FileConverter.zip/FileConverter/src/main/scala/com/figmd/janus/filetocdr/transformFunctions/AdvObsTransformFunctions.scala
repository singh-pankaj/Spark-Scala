package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}

class AdvObsTransformFunctions(sparkSess : SparkSession, mappingpracticecommondatamaster : DataFrame) {

  import sparkSess.implicits._

  def DirectiveTypeCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AdvanceDirectiveTypeCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterAdvanceDirectiveTypeCode")
        , $"df2.CodeDescription".as("MasterAdvanceDirectiveTypeDetails"))
  }


  def DirectiveTypeDetails(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AdvanceDirectiveTypeDetails" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedMasterAdvanceDirectiveTypeCode")
        , $"df2.CodeDescription".as("MappedMasterAdvanceDirectiveTypeDetails"))
      .withColumn("MasterAdvanceDirectiveTypeCode", when($"MappedMasterAdvanceDirectiveTypeCode".isNull, $"MasterAdvanceDirectiveTypeCode")
        .otherwise($"MappedMasterAdvanceDirectiveTypeCode"))
      .withColumn("MasterAdvanceDirectiveTypeDetails", when($"MappedMasterAdvanceDirectiveTypeDetails".isNull, $"MasterAdvanceDirectiveTypeDetails")
        .otherwise($"MappedMasterAdvanceDirectiveTypeDetails"))
      .drop("MappedMasterAdvanceDirectiveTypeCode", "MappedMasterAdvanceDirectiveTypeDetails")
  }


  def DirectiveStatusCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AdvanceDirectiveStatusCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterAdvanceDirectiveStatusCode")
        , $"df2.CodeDescription".as("MasterAdvanceDirectiveStatusText"))
  }

  def DirectiveStatusText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AdvanceDirectiveStatusText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedMasterAdvanceDirectiveStatusCode")
        , $"df2.CodeDescription".as("MappedMasterAdvanceDirectiveStatusText"))
      .withColumn("MasterAdvanceDirectiveStatusCode", when($"MappedMasterAdvanceDirectiveStatusCode".isNull, $"MasterAdvanceDirectiveStatusCode")
        .otherwise($"MappedMasterAdvanceDirectiveStatusCode"))
      .withColumn("MasterAdvanceDirectiveStatusText", when($"MappedMasterAdvanceDirectiveStatusText".isNull, $"MasterAdvanceDirectiveStatusText")
        .otherwise($"MappedMasterAdvanceDirectiveStatusText"))
      .drop("MappedMasterAdvanceDirectiveStatusCode", "MappedMasterAdvanceDirectiveStatusText")

  }

}
