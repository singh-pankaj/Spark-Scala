package com.figmd.janus.filetocdr.util

import java.util.Calendar

import org.apache.spark.sql.{DataFrame, SparkSession}

object HiveUtility {


  def dfwritrtohivePatient(df : DataFrame, mainTableName : String,spark : SparkSession, stageTableName : String,s3Path : String)
  : Unit = {

    println("Patient Data Write to hive tables.........")
    println("start time for data write into stageTable.. "+Calendar.getInstance.getTime)

    df.coalesce(1).write
       .mode("overwrite")
      .partitionBy("PracticeUid")
      .option("path",s3Path)
      .saveAsTable(stageTableName)

    println("End time for data write into stageTable.. "+Calendar.getInstance.getTime)

    println("Start time for data write into mainTable.. "+Calendar.getInstance.getTime)
    spark.sql(s"insert overwrite table $mainTableName partition(PracticeUid) select * from $stageTableName")
    println("End time for data write into mainTable.. "+Calendar.getInstance.getTime)

  }
}
