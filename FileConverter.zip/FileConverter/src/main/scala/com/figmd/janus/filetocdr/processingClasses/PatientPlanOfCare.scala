package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.PlanOfCareTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import org.apache.spark.sql.functions.{broadcast, col, collect_list, struct}
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientPlanOfCare(PlanOfCarePath : String,selectedIds : DataFrame) {

  def PlanOfCareProcessing(spark: SparkSession ,mappingpracticecommondatamaster : DataFrame) {

    /*
  //Create map of file indices and column names
  val cachePatientPlanOfCareMapDF: Dataset[Row] = rt.joinedDf
    .filter($"CacheTableViewName"==="ViewCachePatientPlanOfCare")
  val lookup: collection.Map[String, String] = getLookupMap(cachePatientPlanOfCareMapDF)
  */

    try {

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPlanOfCare")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePlanOfCare")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPlanOfCare")

      val lookup = Map("_c0" -> "PatientID", "_c1" -> "Instructions", "_c2" -> "PracticeCode"
        , "_c3" -> "PracticeDescription",
        "_c4" -> "EffectiveDate", "_c5" -> "PlanOfCareStatusCode", "_c6" -> "PlanOfCareStatusText",
        "_c7" -> "PlanOfCareGroup", "_c8" -> "PlanOfCareKey", "_c9" -> "PracticeUid", "_c10" -> "BatchUid"
        , "_c11" -> "dummy1", "_c12" -> "dummy2")

      //Read file for CachePatientPlanOfCare
      import spark.implicits._
      val file: DataFrame = CommonFunc.readFile(PlanOfCarePath,spark)

      //Apply lookup to generate file Header
      val CachePatientPlanOfCareDF: DataFrame = file.select(file.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")

      val addPatientUid =  CachePatientPlanOfCareDF.as("df1").join(selectedIds.as("df2")
        ,Seq("PracticeUid","PatientId"))
        .select($"df1.*",$"df2.PatientUid")
      //Get required functions for CachePatientPlanOfCare
      val patientPlanOfCare = new PlanOfCareTransformFunctions(spark, mappingpracticecommondatamaster)

      val transformPatientPlanOfCareDF = addPatientUid
        .transform(patientPlanOfCare.PlanOfCareStatusText)
        .transform(patientPlanOfCare.PlanOfCareStatusCode)
        .transform(patientPlanOfCare.PracticeDescription)
        .transform(patientPlanOfCare.PracticeCode)

      val distinctPUid = transformPatientPlanOfCareDF.select("PracticeUid").distinct()

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val PalnOfCareData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = transformPatientPlanOfCareDF.select("PracticeUid","PatientId","PatientUid")
      broadcast(FiletoJoin)

      val otherData = PalnOfCareData.as("df1").join(FiletoJoin.as("df2")
        ,Seq("PatientId","PracticeUid","PatientUid"),"left_anti")
        .select($"df1.*")

      val AllProblemData = transformPatientPlanOfCareDF.union(otherData)

      HiveUtility.dfwritrtohivePatient(AllProblemData,mainTableName,spark,stagetableName,s3Path)


    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }
  }
}
