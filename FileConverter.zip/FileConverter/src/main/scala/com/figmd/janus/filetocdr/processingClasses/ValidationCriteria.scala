package com.figmd.janus.filetocdr.processingClasses

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._

import scala.collection.mutable.ListBuffer

class ValidationCriteria (spark:SparkSession){
  import spark.implicits._

  def errorRecords(df:List[DataFrame]):DataFrame={

    val errorDF = df.reduce(_ union _)
    errorDF

  }

  val validationUDF: UserDefinedFunction = udf((column:String) => if (column == null || column == "") true else false)
  def removeDuplicateRecords1(list: List[String])(df:DataFrame):DataFrame={
    val RankDf = df
      .withColumn("rank", row_number().over(Window.partitionBy(list.head, list.tail: _*).orderBy(list.head, list.tail: _*)))
    val dff = RankDf
      .withColumn("ErrorMessage", when($"rank">1,lit("Duplicate record")).otherwise(lit(null)))
    dff
  }


  var errorList: ListBuffer[DataFrame] = ListBuffer[DataFrame]()


  def AdvanceDirectiveStatusNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"AdvanceDirectiveStatusCode") === "" || trim($"AdvanceDirectiveStatusText") === "" )
      .withColumn("ErrorMessage" , lit("AdvanceDirectiveStatus Not Mapped"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def allergyStatusCodeNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"AllergyStatusCode") === "" || trim($"AllergyStatusText") === "")
      .withColumn("ErrorMessage" , lit("AllergyStatusCode Not Mapped"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


  def allergiesNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"AllergicToDescription" === "")
      .withColumn("ErrorMessage" , lit("Allergies Not Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def birthCountryNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"BirthCountryCode") === "" || trim($"BirthCountry") === "")
      .withColumn("ErrorMessage" , lit("Birth Country Not Mapped"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def birthStateNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"BirthStateCode") =!= "" || trim($"BirthState") =!= "")
      .withColumn("ErrorMessage" , lit("Birth State Not Mapped"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def countryNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"CountryCode") === "" || trim($"Country") =!= "")
      .withColumn("ErrorMessage" , lit("Country Not Mapped"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def differentMRNForSamePatientWithSSN(df:DataFrame) : DataFrame={

    val errorDF =  df.as("df1").join(df.as("df2"),$"df1.firstname" === $"df2.firstname"
      && $"df1.PracticeUid" === $"df2.PracticeUid"
      && $"df1.dob" === $"df2.dob"
      && $"df1.lastname" === $"df2.lastname"
      && $"df1.SSN" === $"df2.SSN").where($"df1.patientid" =!= $"df2.patientid")
      .select($"df1.*")
      .withColumn("ErrorMessage" , lit("Different MRN Found For Same firstname,lastname,dob,SSN,PracticeUid"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def differentMRNForSamePatientWithoutSSN(df:DataFrame) : DataFrame={

    val errorDF =  df.as("df1").join(df.as("df2"),$"df1.firstname" === $"df2.firstname"
      && $"df1.PracticeUid" === $"df2.PracticeUid"
      && $"df1.dob" === $"df2.dob"
      && $"df1.lastname" === $"df2.lastname").where($"df1.patientid" =!= $"df2.patientid")
      .select($"df1.*")
      .withColumn("ErrorMessage" , lit("Different MRN Found For Same firstname,lastname,dob,PracticeUid"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def documentationDateNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"Documentationdate" === "" || $"Documentationdate".isNull)
      .withColumn("ErrorMessage" , lit("Documentation date Not Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


  def duplicateEncounterFound(df:DataFrame):DataFrame={
    val errorDF = df.groupBy("Visituid").count()
      .filter($"count" > 1)
      .withColumn("ErrorMessage" , lit(" Duplicate Encounter Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF

  }

  //Effective Date Is Null/Blank
  def effectiveDateNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"EffectiveDate" === "")
      .withColumn("ErrorMessage" , lit("Effective Date Is Null/Blank"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def encounterStartDateNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"EncounterStartDate".isNull)
      .withColumn("ErrorMessage" , lit("Encouter Date  not found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def encounterDiagnosisCodeAndTextNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"EncounterDiagnosisCode" === "" && $"EncounterDiagnosisText" === "" )
      .withColumn("ErrorMessage" , lit("DiagnosisText AND Code Is Not Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


  def encounterDiagnosisCategoryNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"EncounterDiagnosisCategory ".isNull && $"EncounterDiagnosisCode" === "")
      .withColumn("ErrorMessage" , lit("EncounterDiagnosisCategory Not Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def encouterDateNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"EncounterStartDate".isNull)
      .withColumn("ErrorMessage" , lit("Encouter Date not found"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


  def ethnicityCodeOrTextNotFound(df:DataFrame):DataFrame={
    val errorDF = df.filter($"PatientEthnicityCode"==="" && $"PatientEthnicityText" === "")
      .withColumn("ErrorMessage" , lit("EthnicityCode/Text is Null"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def familyMemberGenderUidNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"FamilyMemberGender") === "")
      .withColumn("ErrorMessage" , lit("Gender Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def futureVisitFound(df:DataFrame):DataFrame={

    val errorDF = df.filter($"EncounterStartDate" > date_add(current_date(), 5))
      .withColumn("ErrorMessage" , lit("Future Visit Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }
  def genderUidNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"Gender") =!= "")
      .withColumn("ErrorMessage" , lit("Gender Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def guardianNameNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"GuardianFirstName" === ""|| $"GuardianFirstName" === "" )
      .withColumn("ErrorMessage" , lit("GuardianName Not Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def immunizationCodeNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"ImmunizationCode") === "" || trim($"ImmunizationName") === "")
      .withColumn("ErrorMessage" , lit("ImmunizationCode Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def immunizationCodeAndImmunizationNameNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"ImmunizationCode" === "" && $"ImmunizationName" === "" )
      .withColumn("ErrorMessage" , lit("Immunization Code And  Immunization Name Is Missing"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def immunizationNameAndImmunizationCategoryNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"ImmunizationName" === "" && $"ImmunizationCategory" === "" )
      .withColumn("ErrorMessage" , lit("PImmunization name And  Immunization Category Is Missing"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def immuStartDateNotFound(df:DataFrame):DataFrame={
    val errorDF = df.filter($"ImmuStartDate" === "")
      .withColumn("ErrorMessage" , lit("ImmuStartDate Not Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def invalidNPIFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(length($"ServiceProviderNPI") =!= 10)
      .withColumn("ErrorMessage" , lit("Invalid NPI Found,Length should be 10"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def invalidObservationCodeFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"ObservationName" === "")
      .withColumn("ErrorMessage" , lit("Invalid ObservationCode Found without ObservationName"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def invalidPayerIdFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(length($"payerid") =!= 50)
      .withColumn("ErrorMessage" , lit("Invalid PayerId"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def invalidPolicyIdFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(length($"policyid") =!= 50)
      .withColumn("ErrorMessage" , lit(" Invalid policyid"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def insurancePlanNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"InsurancePlan" === "" )
      .withColumn("ErrorMessage" , lit("InsurancePlan Not Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def languageCodeAndLanguageTextNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"LanguageCode".isNull && $"LanguageText".isNull)
      .withColumn("ErrorMessage" , lit("LanguageCode/LanguageText is Null"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def languageAbilityModeNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"LangaugeAbilityModeCode") === "" || trim($"LangaugeAbilityModeText") === "" )
      .withColumn("ErrorMessage" , lit("Language Ability Mode Is Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def languageAbilityProficiencyNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter( trim($"LanguageProficiencyLevelCode") === "" || trim($"LanguageProficiencyLevelText") === "" )
      .withColumn("ErrorMessage" , lit("Language Ability Proficiency Is Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


  def medicationStatusTextOrMedicationStatusCodeNotMapped(df:DataFrame) : DataFrame={
    val errorDF = df.filter( $"MedicationStatusText".isNull || $"MedicationStatusCode".isNull)
      .withColumn("ErrorMessage" , lit("MedicationStatusText/Code Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def medicationIndicationProblemCodeNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"ProcedureCode") =!= "")
      .withColumn("ErrorMessage" , lit("MedicationIndicationProblemCode Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def medicationCodeNameNotFound(df:DataFrame):DataFrame={
    val errorDF = df.filter($"MedicationCode" === "" && $"MedicationName"=== "")
      .withColumn("ErrorMessage" , lit("MedicationCode/Name Missing"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF

  }

  def noteNotFound(df:DataFrame):DataFrame={
    val errorDF = df.filter($"Note" === "")
      .withColumn("ErrorMessage" , lit("Note is Null"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF

  }

  def obsValueLonger(df:DataFrame) : DataFrame={
    val errorDF = df.filter(length($"ObservationValue") > 1000)
      .withColumn("ErrorMessage" , lit(" Invalid policyid"))
    val goodDF = df.except(errorDF.drop("Obs value longer than 1000"))

    errorList += errorDF

    goodDF
  }

  def observationCategoryNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"ObservationCategory".isNull && $"Observationcode".isNull)
      .withColumn("ErrorMessage" , lit("ObservationCategory Not Found"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }



  def observationNameAndObservationCodeNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(($"ObservationName" === "" || $"ObservationName".isNull) && ($"ObservationCode"=== "" || $"ObservationCode".isNull))
      .withColumn("ErrorMessage" , lit("ObservationCode and ObservationText Not Found"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def observationdateNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"Observationdate" === "" || $"Observationdate".isNull )
      .withColumn("ErrorMessage" , lit("Observationdate Not Found"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def observationNameNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"ObservationName" === "" )
      .withColumn("ErrorMessage" , lit("ObservationName Not Found"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def observationValueNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"ObservationValue" === "" )
      .withColumn("ErrorMessage" , lit("ObservationValue Not Found"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def orderCategoryNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"OrderCategory".isNull && $"OrderCode".isNull)
      .withColumn("ErrorMessage" , lit("OrderCategory Not Found"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


  def orderCodeNameNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(($"OrderCode".isNull || $"OrderCode"==="NULL")  && ($"OrderName".isNull || $"OrderName"==="NULL"))
      .withColumn("ErrorMessage" , lit("OrderCode,Name Not Found/Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF

  }

  def orderNameNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"OrderName".isNull)
      .withColumn("ErrorMessage" , lit("OrderName Not Found"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def orderNameAndObservationCodeNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(($"OrderCode" === "NULL" || $"OrderCode".isNull) && ($"OrderName"=== "NULL" || $"OrderName".isNull))
      .withColumn("ErrorMessage" , lit("OrderCode,Name Not Found/Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def orderDateNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"OrderDate" === "" )
      .withColumn("ErrorMessage" , lit("OrderDate Not Found"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


  def  patientNotFound(df: DataFrame): DataFrame ={

    val errorDF = df.filter($"Patientid".isNull)
      .withColumn("ErrorMessage" , lit("Patient Not Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }



  def  patientDOBNotFound(df: DataFrame): DataFrame ={

    val errorDF = df.filter($"DOB" === "" || $"DOB".isNull)
      .withColumn("ErrorMessage" , lit("Patient Birth Date Not Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


  def  PatientAlreadyExistsWithDifferentMedicalRecordNumber(df: DataFrame): DataFrame ={

    val errorDF = df.filter($"DOB" === "" || $"DOB".isNull)
      .withColumn("ErrorMessage" , lit("Patient Birth Date Not Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


  def planOfCareCodeAndPlanOfCareTextNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"PlanOfCareCode" === "" && $"PlanOfCareText" === "")
      .withColumn("ErrorMessage" , lit("PlanOfCareCode,PlanOfCareText  Not Found"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def planOfCareCodeOrTextNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"PlanOfCareCode").isNull || trim($"PlanOfCareText").isNull)
      .withColumn("ErrorMessage" , lit("PlanOfCareCode/Text Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def planOfCareStatusCodeOrTextNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"PlanOfCareStatusCode").isNull || trim($"PlanOfCareStatusText").isNull)
      .withColumn("ErrorMessage" , lit("PlanOfCareStatusCode/Text Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def practicePatientMedicationKeyNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"PracticePatientMedicationKey" === "" )
      .withColumn("ErrorMessage" , lit("PracticePatientMedicationKey is Not Found or Missing"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def practicePatientNoteKeyNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"PracticePatientNoteKey" === "" )
      .withColumn("ErrorMessage" , lit("PracticePatientNoteKey is Not Found or Missing"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def practiceUidNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"PracticeUid".isNull )
      .withColumn("ErrorMessage" , lit("PracticeUid is Null"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def pregnancyObservationDateNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"PregnancyObservationDate"==="")
      .withColumn("ErrorMessage" , lit("PregnancyObservationDate Not Found"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def problemCategoryNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"ProblemCategory".isNull && $"ProblemCode" .isNull )
      .withColumn("ErrorMessage" , lit("Problem Category Not Found"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def problemTextAndProblemCodeNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(($"ProblemCode".isNull || trim($"ProblemCode") === "" )&& ($"ProblemText".isNull || trim($"Problemtext") =!= "") )
      .withColumn("ErrorMessage" , lit("Problem Text And Problem Code Missing"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def problemHealthStatusCodeNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"ProblemHealthStatusCode") === "" || $"ProblemHealthStatusCode".isNull || $"ProblemHealthStatusText".isNull || trim($"ProblemHealthStatusText") === "")
      .withColumn("ErrorMessage" , lit("ProblemHealthStatusCode Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def problemStatusCodeNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"ProblemStatusCode") === "" || $"ProblemStatusCode".isNull || $"ProblemStatusText".isNull || trim($"ProblemStatusText") === "")
      .withColumn("ErrorMessage" , lit("ProblemStatusCode Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def problemTypeCodeNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"EncounterProblemTypeCode").isNull)
      .withColumn("ErrorMessage" , lit("ProblemTypeCode Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def procedureCategoryNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"ProcedureCategory".isNull && $"ProcedureCode" === "" )
      .withColumn("ErrorMessage" , lit("Procedure Category Not Found"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def procedureDateNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"ProcedureDate".isNull)
      .withColumn("ErrorMessage" , lit("Procedure Date is null"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def procedureCodeAndTextNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"ProcedureCode" === "" && $"ProcedureText" === "" )
      .withColumn("ErrorMessage" , lit("ProcedureCode and ProcedureText is missing"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def procedureCodeNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"ProcedureCode").isNull )
      .withColumn("ErrorMessage" , lit("ProcedureCode Code Is Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def procedureCodeCodeNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"ProcedureCode") ==="")
      .withColumn("ErrorMessage" , lit("ProcedureCode Code Is Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


  def raceCodeAndTextNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"PatientRaceCode" === "" && $"PatientRaceText" === "")
      .withColumn("ErrorMessage" , lit("RaceCode/Text is Null"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def relationshipToPatientTextNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"RelationshipToPatientText")=== "" && trim($"RelationshipToPatientCode")=== "")
      .withColumn("ErrorMessage" , lit("RelationshipToPatientText Not Found/Missing"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def relationshipToPatientTextInvalid(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"RelationshipToPatientText") === ""  && length($"RelationshipToPatientText")>100)
      .withColumn("ErrorMessage" , lit("Relationship To PatientText should not be Greater than 100 character"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


  def removeDuplicateRecords(list: List[String])(df:DataFrame):DataFrame={
    val RankDf = df
      .withColumn("rank", row_number().over(Window.partitionBy(list.head, list.tail: _*).orderBy(list.head, list.tail: _*)))

    val goodDF = RankDf.filter($"rank" === 1).drop("rank")

    val errorDF = RankDf.filter($"rank">1).drop("rank")
      .withColumn("ErrorMessage",lit("Duplicate record"))

    errorList += errorDF

    goodDF
  }

  def resultInterpretationCodeOrTextNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"MethodCode") === "" || $"MethodCode".isNull || $"MethodText".isNull || trim($"MethodText") === ""  )
      .withColumn("ErrorMessage" , lit("ResultInterpretationCode/Text Is Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def serviceProviderNPINotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"ServiceProviderNPI" === "")
      .withColumn("ErrorMessage" , lit("Service Provider NPI not found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def serviceLocationIdNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"ServiceLocationId" === "")
      .withColumn("ErrorMessage" , lit("ServiceLocationID Not Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def sectionNameNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"SectionName" === "")
      .withColumn("ErrorMessage" , lit("Section Name Invalid or Missing"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def socialHistoryStatusNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"SocialHistoryStatusCode") === "" || trim($"SocialHistoryStatusText") === "")
      .withColumn("ErrorMessage" , lit("SocialHistoryStatus Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def socialHistoryTypeTextNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"SocialHistoryTypeCode".isNull || $"SocialHistoryTypeText".isNull)
      .withColumn("ErrorMessage" , lit("SocialHistoryTypeCode/Text Missing"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }



  def stateNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"StateCode") === "" || trim($"State") === "")
      .withColumn("ErrorMessage" , lit("State Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def targetSiteCodeAndTextNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"TargetSiteCode") === "" || trim($"TargetSiteText") === "")
      .withColumn("ErrorMessage" , lit("TargetSite Code/Text Is Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def telecomType1tNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"TelecomTypeText1") === "")
      .withColumn("ErrorMessage" , lit("Telecom Type 1 Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def telecomType2tNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter(trim($"TelecomTypeText2") === "")
      .withColumn("ErrorMessage" , lit("Telecom Type 2 Not Mapped"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def visitUidNotFound(df:DataFrame) : DataFrame={
    val errorDF = df.filter($"VisitUid".isNull)
      .withColumn("ErrorMessage" , lit("Visit Not Generated yet"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


}
