//

package com.figmd.janus.filetocdr

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.processingClasses._
import com.figmd.janus.filetocdr.util.{Postgressutility, SparkUtility}
import org.apache.spark.sql.functions._
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, SparkSession}

object CDRProcessing {

  def main(args: Array[String]): Unit = {


    ApplicationConfig.setApplicationConfig(args)

    //    val sparkUtility = new SparkUtility()
    //    val sparkSess = sparkUtility.getSparkSession()
    val sparkSess = SparkSession.builder().master("local[*]").getOrCreate()
    val ReadTBL = new Postgressutility

    Logger.getLogger("org").setLevel(Level.WARN)
    Logger.getLogger("akka").setLevel(Level.WARN)


    println("Start programme............................")
    val tbl1 = ApplicationConfig.prop.getProperty("Allergy")
    val tbl2 = ApplicationConfig.prop.getProperty("Procedure")
    val tbl3 = ApplicationConfig.prop.getProperty("PracticeCommonData")
    val tbl4 = ApplicationConfig.prop.getProperty("Ethinicity")
    val tbl5 = ApplicationConfig.prop.getProperty("Race")
    val tbl6 = ApplicationConfig.prop.getProperty("Insurance")
    val tbl7 = ApplicationConfig.prop.getProperty("Problem")
    val tbl8 = ApplicationConfig.prop.getProperty("Medication")
    val tbl9 = ApplicationConfig.prop.getProperty("Route")
    val tbl10 = ApplicationConfig.prop.getProperty("RelationShip")

    val masterAllergy = ReadTBL.getPostgresTable(sparkSess, tbl1)
    broadcast(masterAllergy)

    val mappingPracticeProcedure = ReadTBL.getPostgresTable(sparkSess, tbl2)
    broadcast(mappingPracticeProcedure)

    val mappingpracticecommondatamaster = ReadTBL.getPostgresTable(sparkSess, tbl3)
    broadcast(mappingpracticecommondatamaster)

    val mappingpracticecommondatamasterethnicity = ReadTBL.getPostgresTable(sparkSess, tbl4)
    broadcast(mappingpracticecommondatamasterethnicity)

    val mappingpracticecommondatamasterrace = ReadTBL.getPostgresTable(sparkSess, tbl5)
    broadcast(mappingpracticecommondatamasterrace)

    val mappingpracticeinsurancedata = ReadTBL.getPostgresTable(sparkSess, tbl6)
    broadcast(mappingpracticeinsurancedata)

    val MappingPracticeProblem = ReadTBL.getPostgresTable(sparkSess, tbl7)
    broadcast(MappingPracticeProblem)

    val MappingPracticeMedication = ReadTBL.getPostgresTable(sparkSess, tbl8)
    broadcast(MappingPracticeMedication)

    val MappingPracticeCommonDataMasterMedicationRoute = ReadTBL.getPostgresTable(sparkSess, tbl9)
    broadcast(MappingPracticeCommonDataMasterMedicationRoute)

    val mappingracticecommondatamasterrelationship = ReadTBL.getPostgresTable(sparkSess, tbl10)
    broadcast(mappingracticecommondatamasterrelationship)


    val PatientAdvanceDirectivePath = ApplicationConfig.prop.getProperty("PatientAdvanceDirectivePath")
    val PatientAllergiesPath = ApplicationConfig.prop.getProperty("PatientAllergiesPath")
    val PatientDemographicsPath = ApplicationConfig.prop.getProperty("PatientDemographicsPath")
    val PatientEncounterPath = ApplicationConfig.prop.getProperty("PatientEncounterPath")
    val PatientEncounterDiagnosisPath = ApplicationConfig.prop.getProperty("PatientEncounterDiagnosisPath")
    val PatientEthnicityPath = ApplicationConfig.prop.getProperty("PatientEthnicityPath")
    val PatientFamilyHistoryPath = ApplicationConfig.prop.getProperty("PatientFamilyHistoryPath")
    val PatientInsurancePath = ApplicationConfig.prop.getProperty("PatientInsurancePath")
    val PatientLanguagePath = ApplicationConfig.prop.getProperty("PatientLanguagePath")
    val PatientMedicationsPath = ApplicationConfig.prop.getProperty("PatientMedicationsPath")
    val PatientNotesPath = ApplicationConfig.prop.getProperty("PatientNotesPath")
    val PatientResultObservationPath = ApplicationConfig.prop.getProperty("PatientResultObservationPath")
    val PatientPlanOfCarePath = ApplicationConfig.prop.getProperty("PatientPlanOfCarePath")
    val PatientProblemPath = ApplicationConfig.prop.getProperty("PatientProblemPath")
    val PatientProceduresPath = ApplicationConfig.prop.getProperty("PatientProceduresPath")
    val PatientRacePath = ApplicationConfig.prop.getProperty("PatientRacePath")
    val PatientSocialHistoryObservationPath = ApplicationConfig.prop.getProperty("PatientSocialHistoryObservationPath")
    val PatientVitalSignsPath = ApplicationConfig.prop.getProperty("PatientVitalSignsPath")

    val PatientImmunizationPath = ApplicationConfig.prop.getProperty("PatientImmunizationPath")
    val PatientGuardianPath = ApplicationConfig.prop.getProperty("PatientGuardianPath")
    val PatientLabOrderPath = ApplicationConfig.prop.getProperty("PatientLabOrderPath")


    var selectedIds:DataFrame = null
    val DemographicsDF = new DemographicsClass(PatientDemographicsPath).demoProcessing(sparkSess)

    if (DemographicsDF.isEmpty) {
      println("no valid data present in PatientDemographics")
      sys.exit(1)
    }
    else
      selectedIds = DemographicsDF.head

    broadcast(selectedIds)

    val PatientEthnicityDF = new PatientEthnicity(PatientEthnicityPath,selectedIds)
      .EthinicityProccessing(sparkSess,mappingpracticecommondatamasterethnicity)

    val PatientraceDF = new PatientRace(PatientRacePath,selectedIds)
      .cacheRaceProcessing(sparkSess, mappingpracticecommondatamasterrace)

    val CacheEncounterDF = new PatientEncounter(PatientEncounterPath,selectedIds)
      .cachePatientEncounterProcessing(sparkSess)

    val PatientProblemDF = new PatientProblem(PatientProblemPath,selectedIds)
      .cachePatientProblemProcessing(sparkSess, MappingPracticeProblem)

    val PatientProcedureDF = new PatientProcedure(PatientProceduresPath,selectedIds)
      .cachePatientProcedureProceesing(sparkSess, mappingPracticeProcedure, mappingpracticecommondatamaster)

    val PatientAdvanceDirectiveDF = new PatientAdvanceDirectiveObservation(PatientAdvanceDirectivePath,selectedIds)
      .cacheAdvObsProcessing(sparkSess, mappingpracticecommondatamaster)


    val PatientAllergyDF = new PatientAllergy(PatientAllergiesPath,selectedIds)
      .cacheAllergyProcessing(sparkSess, masterAllergy, mappingpracticecommondatamaster)

    val PatientMedicationDF = new Medications(PatientMedicationsPath,selectedIds)
      .CacheMedicationsProcessing(sparkSess, mappingPracticeProcedure, MappingPracticeMedication, mappingpracticecommondatamaster)


    val PatientPlanOfCareDF = new PatientPlanOfCare(PatientPlanOfCarePath,selectedIds)
      .PlanOfCareProcessing(sparkSess, mappingpracticecommondatamaster)



/*
    val PatientresultObservationbDF = new PatientresultObservation(ResultObservationPath,selectedIds)
      .cacheresultObsProcessing(sparkSess, mappingpracticecommondatamaster, mappingPracticeProcedure)
*/
    println("end..........................................")



  }


}
