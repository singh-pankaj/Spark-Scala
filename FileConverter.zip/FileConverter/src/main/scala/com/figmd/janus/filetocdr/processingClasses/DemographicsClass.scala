package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util.Calendar
import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import org.apache.commons.compress.archivers.zip.UnsupportedZipFeatureException.Feature
import org.apache.spark.sql.{Column, DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions.{col, to_timestamp}
import org.apache.spark.sql.functions._

import scala.collection.mutable
import scala.collection.mutable._

class DemographicsClass(DemoPath : String){



  def demoProcessing(sparkSess : SparkSession) : Option[DataFrame] = {



    import sparkSess.implicits._

    try{

      val file = CommonFunc.readFile(DemoPath,sparkSess)

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatient")
/*
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatient")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatient")
*/

      println("file path..." +DemoPath)

      println("Processing start time for Demo.. "+Calendar.getInstance.getTime)

      val lookup = Map("_c0" -> "PatientId", "_c1" -> "LastName", "_c2" -> "FirstName", "_c3" -> "MiddleName", "_c4" -> "StreetLineAddress1"
        , "_c5" -> "StreetLineAddress2", "_c6" -> "StreetLineAddress3", "_c7" -> "StreetLineAddress4", "_c8" -> "City", "_c9" -> "StateCode"
        , "_c10" -> "State", "_c11" -> "ZipCode", "_c12" -> "CountryCode", "_c13" -> "Country", "_c14" -> "TelecomTypeText1"
        , "_c15" -> "TelecomValue1", "_c16" -> "TelecomTypeText2", "_c17" -> "TelecomValue2", "_c18" -> "Gender", "_c19" -> "DOB"
        , "_c20" -> "DeathDate", "_c21" -> "MaritalStatusCode", "_c22" -> "MaritalStatusText", "_c23" -> "ReligiousAffiliationCode"
        , "_c24" -> "ReligiousAffiliationText", "_c25" -> "BirthStateCode", "_c26" -> "BirthState", "_c27" -> "BirthZipCode"
        , "_c28" -> "BirthCountryCode", "_c29" -> "BirthCountry", "_c30" -> "ServiceProviderNPI", "_c31" -> "ServiceProviderLastName"
        , "_c32" -> "ServiceProviderFirstName", "_c33" -> "SSN", "_c34" -> "DeathReason", "_c35" -> "IsDeceased", "_c36" -> "Patient_EMR_ID"
        , "_c37" -> "EmailID", "_c38" -> "LocationOfDeath", "_c39" -> "BirthOrder", "_c40" -> "MultipleBirthPlaceIndicator"
        , "_c41" -> "PatientDemographicsKey", "_c42" -> "PracticeUid","_c43" -> "BatchUid")


      val CachepatientDemo = file.select(file.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)
        .drop("_c44","_c45")


      val CachepatientDemo1 =  file.withColumn("DOB", to_timestamp($"DOB", "MM/dd/yyyy HH:mm:ss"))

      CommonFunc.loggert("applying validations on CachePatientDemographics files")

      val validations = new ValidationCriteria(sparkSess)

/*
      val CleanedRecords = CachepatientDemo
        .transform(validations.removeDuplicateRecords(List("PatientId","PracticeUid")))
        .transform(validations.birthCountryNotFound)
        .transform(validations.birthStateNotFound)
        .transform(validations.countryNotFound)
        .transform(validations.differentMRNForSamePatientWithoutSSN)
        .transform(validations.differentMRNForSamePatientWithSSN)
        .transform(validations.invalidNPIFound)
        //.transform(validations.)
        .transform(validations.patientDOBNotFound)
        .transform(validations.practiceUidNotFound)
        .transform(validations.stateNotFound)
        .transform(validations.telecomType1tNotFound)
        .transform(validations.telecomType2tNotFound)
*/



      def nullCheck(row:Row,columns:String*):Boolean={

        if (row.getAs[String](columns(0)) == null || row.getAs[String](columns(1)) == "") true else false

      }

      val badDF = CachepatientDemo1.filter(row => nullCheck(row,"patientid","practiceuid","firstname","lastname","dob","gender"))
      val CleanedRecords = CachepatientDemo1.except(badDF)
      CleanedRecords.show()

      CommonFunc.loggert("DemoGraphics validations success")

      val distinctPUid = CleanedRecords.select("PracticeUid").distinct()

      val fileJoinids = CleanedRecords.select("PracticeUid","PatientId")
      broadcast(fileJoinids)

      val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"


      val RequiredData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      println("RequiredData Demo Data.....  "+RequiredData.count())

      val UUIDs = RequiredData.select("PracticeUid","PatientId","PatientUid")
      broadcast(UUIDs)

      val PreviousPatient = CleanedRecords.as("df1").join(UUIDs.as("df2"),
        Seq("PracticeUid","PatientId"),"inner").select($"df1.*",$"df2.PatientUid")
        .drop("dummy1","dummy2")

      println("PreviousPatient Demo Data.....  "+PreviousPatient.count())

      val newPatient =  CleanedRecords.as("df1").join(UUIDs.as("df2"),
        Seq("PracticeUid","PatientId"),"left_anti").select($"df1.*")

      println("newPatient Demo Data.....  "+newPatient.count())

      val tempPatUid = newPatient.select("PatientId", "PracticeUid").distinct()
        .withColumn("PatientUid",CommonFunc.getNewUid())

      val PatUid = tempPatUid.persist()
      broadcast(PatUid)

      val CachepatientDemo2 = newPatient.as("df1").join(PatUid.as("df2")
        ,  $"df1.PracticeUid" === $"df2.PracticeUid"  && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid").drop("dummy1","dummy2")

      val OtherPatient =  RequiredData.as("df1").join(fileJoinids.as("df2"),
        Seq("PracticeUid","PatientId"),"left_anti").select($"df1.*")


      val allRecords = PreviousPatient.union(CachepatientDemo2).union(OtherPatient)

      println("Processing End time for Demo.. "+Calendar.getInstance.getTime)

      val send3uids  = allRecords.select("PracticeUid","PatientId","PatientUid")

      //HiveUtility.dfwritrtohivePatient(allRecords,mainTableName,sparkSess,stagetableName,s3Path)

      println("done both table data writing.................................")
      Some(send3uids)
    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }

  }

}
