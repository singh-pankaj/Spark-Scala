package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{to_timestamp, year}
import org.apache.spark.sql.functions._

class PatientEncounter(EncounterPath : String,selectedIds : DataFrame) {

  def cachePatientEncounterProcessing(sparkSess : SparkSession) = {

    val mainTableName = ApplicationConfig.prop.getProperty("CDRVisit")
    val stagetableName = ApplicationConfig.prop.getProperty("StageVisit")
    val s3Path = ApplicationConfig.prop.getProperty("s3LocationVisit")

    //Start Encounter

    //Its Required
    // val df2 =CacheEncounter.withColumn("_c3", to_timestamp($"_c3", "MM/dd/yyyy HH:mm:ss")).select("_c3")

    import sparkSess.implicits._
    try {
      var CacheEncounter = CommonFunc.readFile(EncounterPath,sparkSess)

            val lookup4 = Map("_c0" -> "PatientId", "_c1" -> "EncounterTypeCode", "_c2" -> "EncounterTypeText", "_c3" -> "EncounterStartDate"
              , "_c4" -> "EncounterEndDate", "_c5" -> "ServiceProviderNPI", "_c6" -> "ServiceProviderLastName", "_c7" -> "ServiceProviderFirstName"
              , "_c8" -> "ServiceProviderRoleCode", "_c9" -> "ServiceProviderRoleText", "_c10" -> "ServiceLocationId"
              , "_c11" -> "ServiceLocationName", "_c12" -> "ServiceLocationRoleTypeCode", "_c13" -> "ServiceLocationRoleTypeText"
              , "_c14" -> "ReasonForVisit", "_c15" -> "Service_Location_AddressLine", "_c16" -> "Service_Location_City"
              , "_c17" -> "Service_Location_State", "_c18" -> "Service_Location_PostalCode", "_c19" -> "Encounter_Status"
              , "_c20" -> "EncounterTIN", "_c21" -> "EncounterKey", "_c22" -> "PracticeUid", "_c23" -> "BatchUid", "_c24" -> "dummy1", "_c25" -> "dummy2")

             CacheEncounter = CacheEncounter.select(CacheEncounter.columns.map(c => col(c).as(lookup4.getOrElse(c, c))): _*)
              .drop("dummy1", "dummy2")
              .withColumn("EncounterStartDate", to_timestamp($"EncounterStartDate", "MM/dd/yyyy HH:mm:ss"))

      val dropDuplicates = CacheEncounter.dropDuplicates("PatientId", "ServiceProviderNPI", "ServiceLocationName"
        , "EncounterStartDate")

      val addPatientUid =  dropDuplicates.as("df1").join(selectedIds.as("df2")
        ,Seq("PracticeUid","PatientId")).select($"df1.*",$"df2.PatientUid")


            val distinctPUid = addPatientUid.select("PracticeUid").distinct()

            val ListVal2:Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
            val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

            val VisitData = sparkSess.sql(s"select * from $mainTableName where" +
              s" practiceuid in $PartitionPUID")


             val PreviousPatient = addPatientUid.as("df1").join(VisitData.as("df2"),
              Seq("PracticeUid","PatientUid","PatientId"),"inner").select($"df1.*",$"df2.VisitUid")


            val newVisit = addPatientUid.as("df1").join(VisitData.as("df2"),
              Seq("PatientId","PracticeUid","PatientUid"),"left_anti").select($"df1.*")


            val tempData = newVisit.select("PatientId", "ServiceProviderNPI", "ServiceLocationName"
              , "EncounterStartDate").distinct()
              .withColumn("visitUid",CommonFunc.getNewUid())

               val tempVisitUid = tempData.persist()

            val CacheEncounter2 = newVisit.as("df1").join(tempVisitUid.as("df2"),$"df1.PatientId" === $"df2.PatientId"
              &&  $"df1.ServiceProviderNPI" === $"df2.ServiceProviderNPI" && $"df1.ServiceLocationName" === $"df2.ServiceLocationName"
              && $"df1.EncounterStartDate" === $"df2.EncounterStartDate")
              .select($"df1.*",$"df2.VisitUid")

            val otherData = VisitData.as("df1").join(addPatientUid.as("df2"),
              Seq("PatientId","PracticeUid","PatientUid"),"left_anti").select($"df1.*")

            val VisitAllRecords = PreviousPatient.union(CacheEncounter2).union(otherData)

      HiveUtility.dfwritrtohivePatient(VisitAllRecords,mainTableName,sparkSess,stagetableName,s3Path)
    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }
  }

}
