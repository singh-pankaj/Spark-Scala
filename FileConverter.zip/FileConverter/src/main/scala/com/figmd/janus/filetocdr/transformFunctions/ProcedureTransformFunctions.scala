package com.figmd.janus.filetocdr.transformFunctions


import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}
class ProcedureTransformFunctions(sparkSess : SparkSession
                                  , mappingPracticeProcedure : DataFrame
                                  , mappingpracticecommondatamaster : DataFrame) {


  import sparkSess.implicits._

  def PracticeCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterProcedureCode")
        ,$"df2.CodeDescription".as("MasterProcedureText"))
  }

  def PracticeDescription(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterProcedureCode")
        ,$"df2.CodeDescription".as("MappedMasterProcedureText"))
      .withColumn("MasterProcedureCode",when($"MappedMasterProcedureCode".isNull,$"MasterProcedureCode")
        .otherwise($"MappedMasterProcedureCode"))
      .withColumn("MasterProcedureText",when($"MappedMasterProcedureText".isNull,$"MasterProcedureText")
        .otherwise($"MappedMasterProcedureText"))
      .drop("MappedMasterProcedureCode","MappedMasterProcedureText")
  }

  def ProcedureStatusCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureStatusCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterProcedureStatusCode")
        ,$"df2.CodeDescription".as("MasterProcedureStatusText"))
  }

  def ProcedureStatusText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureStatusText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterProcedureStatusCode")
        ,$"df2.CodeDescription".as("MappedMasterProcedureStatusText"))
      .withColumn("MasterProcedureStatusCode",when($"MappedMasterProcedureStatusCode".isNull,$"MasterProcedureStatusCode")
        .otherwise($"MappedMasterProcedureStatusCode"))
      .withColumn("MasterProcedureStatusText",when($"MappedMasterProcedureStatusText".isNull,$"MasterProcedureStatusText")
        .otherwise($"MappedMasterProcedureStatusText"))
      .drop("MappedMasterProcedureStatusCode","MappedMasterProcedureStatusText")
  }

  def TargetSiteCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteCode" === $"df2.PracticeValue"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MasterTargetSiteCode")
        ,$"df2.CodeDescription".as("MasterTargetSiteText"))
  }

  def TargetSiteText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteText" === $"df2.PracticeDescription"
      ,"left_outer")
      .select($"df1.*",$"df2.Code".as("MappedMasterTargetSiteCode")
        ,$"df2.CodeDescription".as("MappedMasterTargetSiteText"))
      .withColumn("MasterTargetSiteCode",when($"MappedMasterTargetSiteCode".isNull,$"MasterTargetSiteCode")
        .otherwise($"MappedMasterTargetSiteCode"))
      .withColumn("MasterTargetSiteText",when($"MappedMasterTargetSiteText".isNull,$"MasterTargetSiteText")
        .otherwise($"MappedMasterTargetSiteText"))
      .drop("MappedMasterTargetSiteCode","MappedMasterTargetSiteText")
  }


}
