package com.figmd.janus.filetocdr.processingClasses

trait validationMap {

  val patientDemographicsvalidation = Map("BirthCountryCode"->"BirthCountryCode not found",
    "CountryCode"->"CountryCode not found",
    "BirthCountry"->"BirthCountry not found",
    "BirthState"->"BirthState not found",
    "BirthStateCode"->"BirthStateCode not found",
    "DOB"->"DOB not found",
    "PracticeUid"->"PracticeUid not found",
    "StateCode"->"StateCode not found",
    "State"->"State not found",
    "TelecomTypeText1"->"TelecomTypeText1 not found",
    "TelecomTypeText1"->"TelecomTypeText1 not found"
  )


}
