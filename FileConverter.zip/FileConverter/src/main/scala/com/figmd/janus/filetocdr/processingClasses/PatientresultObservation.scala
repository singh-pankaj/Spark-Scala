package com.figmd.janus.filetocdr.processingClasses

class PatientresultObservation {

}
