package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.AdvObsTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

class PatientAdvanceDirectiveObservation(AdvanceDirectivePath : String,selectedIds : DataFrame) {


  def cacheAdvObsProcessing(sparkSess : SparkSession, mappingpracticecommondatamaster : DataFrame) {


    val mainTableName = ApplicationConfig.prop.getProperty("CDRAdvanceDirectives")
    val stagetableName = ApplicationConfig.prop.getProperty("StageAdvanceDirectives")
    val s3Path = ApplicationConfig.prop.getProperty("s3LocationAdvanceDirectives")
    import sparkSess.implicits._

    try {
      val file = CommonFunc.readFile(AdvanceDirectivePath,sparkSess)


      val lookup1 = Map("_c0" -> "PatientId", "_c1" -> "AdvanceDirectiveTypeCode", "_c2" -> "AdvanceDirectiveTypeDetails"
        , "_c3" -> "AdvanceDirectiveStatusCode", "_c4" -> "AdvanceDirectiveStatusText", "_c5" -> "EffectiveStartDate"
        , "_c6" -> "EffectiveEndDate", "_c7" -> "AgentName", "_c8" -> "ExternalDocumentLink", "_c9" -> "GroupName"
        , "_c10" -> "AdvanceDirectiveTypeText"
        , "_c11" -> "AdvanceDirectiveKey", "_c12" -> "PracticeUid", "_c13" -> "BatchUid"
        , "_c14" -> "dummy1", "_c15" -> "dummy2")

      val cachePatientAdvDirObservation = file.select(file.columns.map(c => col(c).as(lookup1.getOrElse(c, c))): _*)
        .drop("dummy1","dummy2")
        .withColumn("EffectiveStartDate", to_timestamp($"EffectiveStartDate", "MM/dd/yyyy HH:mm:ss"))
        .withColumn("EffectiveEndDate", to_timestamp($"EffectiveEndDate", "MM/dd/yyyy HH:mm:ss"))

      val addPatientUid = cachePatientAdvDirObservation.as("df1").join(selectedIds.as("df2")
        , Seq("PracticeUid", "PatientId"))
        .select($"df1.*", $"df2.PatientUid")

      val tf = new AdvObsTransformFunctions(sparkSess, mappingpracticecommondatamaster)

      val cachePatientAdvObservation3 = addPatientUid
        .transform(tf.DirectiveTypeCode)
        .transform(tf.DirectiveTypeDetails)
        .transform(tf.DirectiveStatusCode)
        .transform(tf.DirectiveStatusText)


      val distinctPUid = cachePatientAdvObservation3.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val AdvanceDirData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cachePatientAdvObservation3.select("PracticeUid","PatientId","PatientUid")
      broadcast(FiletoJoin)

      val otherData = AdvanceDirData.as("df1").join(FiletoJoin.as("df2")
        , Seq("PracticeUid","PatientId","PatientUid"), "left_anti")
        .select($"df1.*")

      val AllProblemData = cachePatientAdvObservation3.union(otherData)

      HiveUtility.dfwritrtohivePatient(AllProblemData,mainTableName,sparkSess,stagetableName,s3Path)

    }

    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }

}
