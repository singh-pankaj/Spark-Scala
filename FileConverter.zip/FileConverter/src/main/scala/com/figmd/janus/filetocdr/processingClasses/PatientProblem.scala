package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.ProblemTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility}
import org.apache.spark.sql.functions.{broadcast, col, to_timestamp}
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientProblem(ProblemPath : String,selectedIds : DataFrame) {


  def cachePatientProblemProcessing(sparkSess: SparkSession, mappingpracticeproblem: DataFrame) = {

    val mainTableName = ApplicationConfig.prop.getProperty("CDRProblem")
    val stagetableName = ApplicationConfig.prop.getProperty("StageProblem")
    val s3Path = ApplicationConfig.prop.getProperty("s3LocationProblem")

    import sparkSess.implicits._

    try {
      val file = CommonFunc.readFile(ProblemPath, sparkSess).drop("dummy1", "dummy2")
        .withColumn("DocumentationDate", to_timestamp($"DocumentationDate", "MM/dd/yyyy HH:mm:ss"))

      val lookup1 = Map("_c0" -> "PatientId", "_c1" -> "ProblemCode", "_c2" -> "ProblemText", "_c3" -> "ProblemCategory"
        , "_c4" -> "ProblemTypeCode", "_c5" -> "ProblemTypeText", "_c6" -> "DocumentationDate",
        "_c7" -> "ProblemResolutionDate", "_c8" -> "ProblemStatusCode", "_c9" -> "ProblemStatusText"
        , "_c10" -> "ProblemHealthStatusCode", "_c11" -> "ProblemHealthStatusText", "_c12" -> "NegationInd",
        "_c13" -> "ProblemComment", "_c14" -> "ProblemOnsetDate", "_c15" -> "TargetSiteCode", "_c16" -> "TargetSiteText"
        , "_c17" -> "ProblemKey", "_c18" -> "PracticeUid", "_c19" -> "BatchUid",
        "_c20" -> "dummy1", "_c21" -> "dummy2")

      val cachePatientProblem = file.select(file.columns.map(c => col(c).as(lookup1.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2")
        .withColumn("DocumentationDate", to_timestamp($"DocumentationDate", "MM/dd/yyyy HH:mm:ss"))

      val addPatientUid = cachePatientProblem.as("df1").join(selectedIds.as("df2")
        , Seq("PracticeUid", "PatientId"))
        .select($"df1.*", $"df2.PatientUid")

      val CleanedRecords1 = addPatientUid.dropDuplicates(Seq("PatientUid", "ProblemCode"
        , "DocumentationDate"))

      val CleanedRecords = CleanedRecords1.dropDuplicates(Seq("PatientUid", "ProblemText"
        , "DocumentationDate"))


      val problemObj = new ProblemTransformFunctions(sparkSess, mappingpracticeproblem)

      val cachePatientProblem3 = CleanedRecords
        .transform(problemObj.ProblemCode)
        .transform(problemObj.ProblemText)
        .transform(problemObj.ProblemStatusCode)
        .transform(problemObj.ProblemStatusText)
        .transform(problemObj.ProblemHealthStatusCode)
        .transform(problemObj.ProblemHealthStatusText)
        .transform(problemObj.TargetSiteCode)
        .transform(problemObj.TargetSiteText)


      val distinctPUid = cachePatientProblem3.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val ProblemData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cachePatientProblem3.select("PracticeUid","PatientId","PatientUid")
      broadcast(FiletoJoin)

      val otherData = ProblemData.as("df1").join(FiletoJoin.as("df2")
        , Seq("PracticeUid","PatientId","PatientUid"), "left_anti")
        .select($"df1.*")

      val AllProblemData = cachePatientProblem3.union(otherData)

      HiveUtility.dfwritrtohivePatient(AllProblemData,mainTableName,sparkSess,stagetableName,s3Path)
    }

    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
      }
    }
  }

}
