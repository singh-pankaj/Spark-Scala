package com.figmd.janus.measureComputation.nonQppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.Measure
import com.figmd.janus.util.MeasureUtility
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}

object AAO1  extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession, rdd: CassandraTableScanRDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

 //myopiaeye,cortieye




/**
    val myrdd1= my_method(rdd,MEASURE_NAME,startDate,endDate,"patient_mrn")

    val myrdd2= my_method(rdd,MEASURE_NAME,startDate,endDate,"myopiaeye")

    val myrdd3= my_method(rdd,MEASURE_NAME,startDate,endDate,"cortieye")


    val myrdd4= myrdd1.union(myrdd2).union(myrdd3)


    println(myrdd4.count())
    println("!!!!!!!!!!!!myrdd4!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    myrdd4.foreach(println)
    println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    println("myrdd1 count  "+myrdd1.count())
    println("myrdd2 count  "+myrdd2.count())
    println("myrdd3 count  "+myrdd3.count())
    println("sum of my rdd count  "+myrdd4.count())


**/
    println("*****#########*********************************################")

    val myrdd = countElement(rdd,MEASURE_NAME,startDate,endDate,"patient_mrn","myopiaeye","cortieye").collect()

    val zrdd : Broadcast[Array[(String,String,Int)]]= sparkSession.sparkContext.broadcast(myrdd)

    val mybroadcast: Broadcast[Array[(String,String,Int)]]  = sparkSession.sparkContext.broadcast(myrdd)

 //  zrdd.value.foreach(println)

    val checkrdd = getMet(rdd,zrdd,MEASURE_NAME,startDate,endDate)

    checkrdd.foreach(println)
    println("checkrdd count"+ checkrdd.count())



  //  println("there mymeth "+myrdd.count())
  //  myrdd.foreach(println)
    //println("sum of my rdd count  "+myrdd4.count())



/*
    var myelementname : String= "patient_mrn"

    val rdd1 = getMet(rdd,MEASURE_NAME,startDate,endDate)

        println("refresh count is  "+rdd1.count())

    rdd1.foreach(println)


    val rdd2 = rdd1.map(r => ((r.getString("patientuid"),
      r.getString(myelementname)), if(checkElementPresent(r,IPP,MEASURE_NAME,myelementname)) 1  else 0

    )).reduceByKey(_+_).map( r => (r._1._1,r._1._2,r._2))

    println("rdd2 count "+rdd2.count())

    rdd2.foreach(println)

    println("rdd2 count"+ rdd2.count())

*/

/**
    val initialCount = 0;
    val addToCounts = (n: Int, v: Int) => n + 1
    val sumPartitionCounts = (p1: Int, p2: Int) => p1 + p2


    println("****rdd4***")
    val rdd_4 = rdd2.aggregateByKey(initialCount)(addToCounts, sumPartitionCounts)
    for (elem <- rdd_4.collect()) {
      println(elem)

    }

**/


    /**
    val rdd3 = rdd2.groupByKey()

    println("******************")

    rdd3.foreach(println)

    println("rdd3 count "+rdd3.count())

      **/


  }

    def getMet(intermediateA: RDD[CassandraRow], rdd:Broadcast[Array[(String,String,Int)]], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {



     return intermediateA.filter(r =>

        isAgeGreaterOrEqual(r,IPP,MEASURE_NAME,"dob","encounterdate",18)

      // && countElementRowWise(r,rdd,MEASURE_NAME,startDate,endDate,"patient_mrn")

      //  && countElementRowWise(r,rdd,MEASURE_NAME,startDate,endDate,"myopiaeye")

       && countElementRowWiseForMultipleElement(r,rdd,MEASURE_NAME,startDate,endDate,"myopiaeye","patient_mrn","cortieye")
      )

  }

/*
  def mycheck(r: CassandraRow, conditionType: String, MEASURE_NAME: String, ElementName:String,count:Int ): Boolean = {

   var ini_count=0

    var isExist= false

      if (!r.isNullAt(ElementName) && checkElementPresent(r,IPP,MEASURE_NAME,ElementName)){

        ini_count = count+1
        isExist= true
     }

    if()
    return isExist;
  }

*/



  def my_method(rdd:RDD[CassandraRow],MEASURE_NAME: String,startDate: Date,endDate: Date,Element_Name:String):RDD[(String,String,Int)] ={

    val rdd2 = rdd.map(r => ((r.getString("patientuid"),
      Element_Name), if(checkElementPresent(r,IPP,MEASURE_NAME,Element_Name)) 1  else 0

    )).reduceByKey(_+_).map( r => (r._1._1,r._1._2,r._2))

  //  val rdd3 =rdd2.reduceByKey(_+_).map( r => (r._1._1,r._1._2,r._2))
    return rdd2

  }


  def countElement(rdd:RDD[CassandraRow],MEASURE_NAME: String,startDate: Date,endDate: Date,Element_Name:String*):RDD[(String,String,Int)] ={

    var rdd3 = rdd.map(r => ((r.getString("patientuid"),
      Element_Name(0)), if(checkElementNotNull(r,IPP,MEASURE_NAME,Element_Name(0))) 1  else 0
    )).reduceByKey(_+_).map( r => (r._1._1,r._1._2,r._2))

    for(x<- 1 to (Element_Name.size-1)){

      var rdd2 = rdd.map(r => ((r.getString("patientuid"),
        Element_Name(x)), if(checkElementPresent(r,IPP,MEASURE_NAME,Element_Name(x))) 1  else 0
      )).reduceByKey(_+_).map( r => (r._1._1,r._1._2,r._2))

   //   println("rdd3 before count "+rdd3.count())
   //   println("rdd2 count"+rdd2.count())
       rdd3 = rdd3.union(rdd2)
   //   println("rdd3 after union"+rdd2.count())
    }


      return rdd3
  }


  def countElementRowWiseForMultipleElement(r: CassandraRow,rdd1:Broadcast[Array[(String,String,Int)]],MEASURE_NAME: String,startDate: Date,endDate: Date,Element_Name:String*): Boolean = {

    var count:Int=0


    for(x <-Element_Name) {


      val pid: String = r.getString("patientuid")
      val pid_ele: String = x

      val rdd4 = rdd1.value.filter(x => x._1.equals(pid)

        && x._2.equals(pid_ele)

        && x._3 >= 2
      )


      //println(rdd1.value.toString)
      println("################")
      rdd4.foreach(println)
      println("################")

      if (rdd4.size >= 1) count=count+1

    }

    if(Element_Name.size==count)
      return true
    else
      false

  }


  def countElementRowWise(r: CassandraRow,rdd1:Broadcast[Array[(String,String,Int)]],MEASURE_NAME: String,startDate: Date,endDate: Date,Element_Name:String): Boolean = {

    val pid :String= r.getString("patientuid")
    val pid_ele :String= Element_Name

    // println("pid and pid_ele "+ pid + pid_ele)


    //  println("******take4*********")
    //  println(rdd1.value.take(4))
    //  println("******take4*********")


    val rdd4 = rdd1.value.filter(x => x._1.equals(pid)

      && x._2.equals(pid_ele)

      && x._3 >=2
    )


    //println(rdd1.value.toString)
    println("################")
    rdd4.foreach(println)
    println("################")
    //println(rdd1.value._2.take(2))

    //println(rdd1.value._3)

    //for(x<- rdd1.value){




    // }

    // val rddx = rdd1.value.filter(x => pid.equals(x._1)

    // && pid_ele.equals(pid_ele)

    //  && (x._3 >= 2)
    // )






    val xc = rdd4.size
    if(xc >=1)
      return true
    else
      false
    // if(r.getString("patientuid").equals(rdd1.foreach(x => x._1))

    // && r.getString(Element_Name).equals(rdd1.foreach(x => x._2))


    //)




    // if( r.getString("patientuid").equals(zr)




  }



  def checkCountOfElement(rdd:RDD[CassandraRow],MEASURE_NAME: String,startDate: Date,endDate: Date,Element_Name:String*):RDD[(String,String,Int)] ={

    var rdd3 = rdd.map(r => ((r.getString("patientuid"),
      Element_Name(0)), if(checkElementNotNull(r,IPP,MEASURE_NAME,Element_Name(0))) 1  else 0
    )).reduceByKey(_+_).map( r => (r._1._1,r._1._2,r._2))

    for(x<- 1 to (Element_Name.size-1)){

      var rdd2 = rdd.map(r => ((r.getString("patientuid"),
        Element_Name(x)), if(checkElementPresent(r,IPP,MEASURE_NAME,Element_Name(x))) 1  else 0
      )).reduceByKey(_+_).map( r => (r._1._1,r._1._2,r._2))

      //   println("rdd3 before count "+rdd3.count())
      //   println("rdd2 count"+rdd2.count())
      rdd3 = rdd3.union(rdd2)
      //   println("rdd3 after union"+rdd2.count())
    }

    return rdd3
  }

  def isEleme(r: CassandraRow, conditionType: String, measureName: String, checkDate:String, startDate: String): Unit = {

   // if(r.getString("patientuid") == rdd. )

  }


  def my_method2(rdd:RDD[CassandraRow],MEASURE_NAME: String,startDate: Date,endDate: Date,Element_Name:String*):RDD[(String,String,Int)] ={

      var e = Element_Name.size
      println("size is "+e)
    // Element_Name.foreach( elename => my_method(rdd,MEASURE_NAME,startDate,endDate,elename).union())



    val myrdd1= my_method(rdd,MEASURE_NAME,startDate,endDate,"patient_mrn")

    val myrdd2= my_method(rdd,MEASURE_NAME,startDate,endDate,"myopiaeye")

    val myrdd3= my_method(rdd,MEASURE_NAME,startDate,endDate,"cortieye")


    //val myrdd4= myrdd1.union(myrdd2).union(myrdd3)

    return myrdd3
  }


}
