package Practice_Flow

class Substract {


  val sub_var = "Substarct varibale"


  def sub(x:Int, y:Int) : Int ={

val z = x-y

    if(z>0) {
      return z
    }
       else return -(z)

    }

  def getvar : Unit ={
    println(sub_var)
  }
}
