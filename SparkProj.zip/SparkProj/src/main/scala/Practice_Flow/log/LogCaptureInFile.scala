package Practice_Flow.log

import java.util.Properties

import org.apache.log4j.{BasicConfigurator, Logger, PropertyConfigurator}

object LogCaptureInFile {


  val mylog = Logger.getLogger(this.getClass.getName)

  def main(args: Array[String]): Unit = {

    println(this.getClass.getName)

    var propobj: Properties = new Properties()

    propobj.setProperty("log4j.reset","true")
    propobj.setProperty("log4j.rootLogger","WARN,file")
    propobj.setProperty("log4j.appender.file","org.apache.log4j.FileAppender")
    propobj.setProperty("log4j.appender.file.File","/home/pankaj.singh/mylogger.out")
    propobj.setProperty("log4j.appender.file.ImmediateFlush","true")
    propobj.setProperty("log4j.appender.file.Threshold","WARN")
    propobj.setProperty("log4j.appender.file.layout","org.apache.log4j.PatternLayout")
    propobj.setProperty("log4j.appender.file.layout.ConversionPattern","%m%n")
    // propobj.setProperty("log4j.appender.file.File", "home/pankaj.singh/mylogger.txt")

    PropertyConfigurator.configure(propobj)
   // BasicConfigurator.configure()



    mylog.warn("This is debug message//")
    mylog.error("This is error message")
  }

}
