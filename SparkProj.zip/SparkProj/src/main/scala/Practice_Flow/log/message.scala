package Practice_Flow.log

import scala.collection.immutable.HashMap
import scala.collection.mutable

object message {

  val messagemap = HashMap("message1"->"%s value1 %s",
  "message2"->"value2"
  )

}
