package Practice_Flow.log

import org.apache.avro.generic.GenericData.StringType
import org.apache.log4j.{Level, Logger}

import org.apache.spark.sql.{Encoder, Encoders, Row, SparkSession}

import scala.collection.mutable.ListBuffer

import org.apache.spark.sql.types.{StringType, StructField, StructType}


object lineQues {
  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  val spark = SparkSession.builder().master("local[*]").appName("hh").getOrCreate()
  import spark.implicits._
  case class test( patientid:String, patientid2:String)

  case class EncounterDiagnosis(  patientid:String
                                  ,encounterdate:String
                                  ,serviceprovidernpi:String
                                  ,serviceproviderlastname:String
                                  ,serviceproviderfirstname:String
                                  ,servicelocationid:String
                                  ,servicelocationname:String
                                  ,encounterdiagnosiscode:String
                                  ,encounterdiagnosistext:String
                                  ,encounterdiagnosiscategory:String
                                  ,encounterproblemtypecode:String
                                  ,encounterproblemtypetext:String
                                  ,documentationdate:String
                                  ,problemresolutiondate:String
                                  ,problemstatuscode:String
                                  ,problemstatustext:String
                                  , problemhealthstatuscode:String
                                  ,problemhealthstatustext:String
                                  ,negationind:String
                                  ,problemcomment:String
                                  ,problemonsetdate:String
                                  ,targetsitecode:String
                                  ,targetsitetext:String
                                  ,listorder:String
                                   ,encounterdiagnosiskey:String
                                    ,practiceuid:String
                                  //  ,batchuid:String
                               )
  import org.apache.spark.sql.types.{StringType, StructField, StructType}
  val schema = StructType(
    List(
      StructField("patientid", StringType, true),
      StructField("encounterdate", StringType, true),
      StructField("serviceprovidernpi", StringType, true),
      StructField("serviceproviderlastname", StringType, true),
      StructField("serviceproviderfirstname", StringType, true),
      StructField("servicelocationid", StringType, true),
      StructField("servicelocationname", StringType, true),
      StructField("encounterdiagnosiscode", StringType, true),
      StructField("encounterdiagnosistext", StringType, true),
      StructField("encounterdiagnosiscategory", StringType, true),
      StructField("encounterproblemtypecode", StringType, true),
      StructField("encounterproblemtypetext", StringType, true),
      StructField("documentationdate", StringType, true),
      StructField("problemresolutiondate", StringType, true),
      StructField("problemstatuscode", StringType, true),
      StructField("problemstatustext", StringType, true),
      StructField("problemhealthstatuscode", StringType, true),
      StructField("problemhealthstatustext", StringType, true),
      StructField("negationind", StringType, true),
      StructField("problemcomment", StringType, true),
      StructField("problemonsetdate", StringType, true),
      StructField("targetsitecode", StringType, true),
      StructField("targetsitetext", StringType, true),
      StructField("listorder", StringType, true),
      StructField("encounterdiagnosiskey", StringType, true),
      StructField("practiceuid", StringType, true),
      StructField("batchuid", StringType, true)
    ))

 // import spark.implicits._
  def main(args: Array[String]): Unit = {



  /*  val df2 = spark.sparkContext.wholeTextFiles("/home/pankaj.singh/DataSet/Encounter Section files/Clinical_Automatic_a11132be-9be6-41ac-bb51-57c4cad11c71_167be332-0a88-4ebd-8fb9-7f1ef03e9b68_8ff9928e-7288-4491-8aa0-c7e0da5bbba8_a11132be-9be6-41ac-bb51-57c4cad11c71_cb27e6c5-9860-4987-808c-c316d51f6c5 (1).txt")
    df2.map(x => x._2).collect*/
    val df1 = spark.read.text("/home/pankaj.singh/DataSet/Encounter Section files/Clinical_Automatic_a11132be-9be6-41ac-bb51-57c4cad11c71_167be332-0a88-4ebd-8fb9-7f1ef03e9b68_8ff9928e-7288-4491-8aa0-c7e0da5bbba8_a11132be-9be6-41ac-bb51-57c4cad11c71_cb27e6c5-9860-4987-808c-c316d51f6c5 (1).txt")

  //  df1.rdd.collect.foreach(println)

  //  df1.printSchema()

println("+++++++++++++++++++++++++++++++++++++++++++++++++")



      df1.map(f => f.toString()./*.mkString(",").*/replace("\u0017",",")
      .replaceAll(",,",",null,").replace(",]",",null")
      .replace("[","").replace("]",""))
      .map(r => r.split(",").grouped(26).toList).flatMap(p => p).filter(f => f.size == 26)
      .map(p => EncounterDiagnosis(p(0), p(1), p(2), p(3), p(4), p(5), p(6), p(7), p(8), p(9)
      , p(10)
      , p(11), p(12), p(13), p(14), p(15)
      , p(16), p(17), p(18), p(19), p(20), p(21), p(22) , p(23), p(24), p(25)/*, p(26)*/)).show(125,false)


    println("===========")



    val wrongformatdata11 = df1.map(f => f.toString()./*.mkString(",").*/replace("\u0017",",")
      .replaceAll(",,",",null,").replace(",]",",null")
      .replace("[","").replace("]",""))
      .map(r => r.split(",").grouped(26).toList).flatMap(p => p).filter(f => f.size != 26)

  //  wrongformatdata11.show(12,false)


    val c = wrongformatdata11.rdd.map(r => (1,r.mkString(","))).reduceByKey((a,b) =>  {
    if(a.split(",").length%26 == 0) a+","+b
    else a+b }).map(r => r._2)

  //  c.collect.foreach(x => x.foreach(print))


 //   c.map(r => r.toString.trim.split(",").grouped(26).toList).flatMap(x => x).toDF().show(60,false)

    c.map(r => r.toString.trim.split(",").grouped(26).toList).flatMap(p=> p).map(x => x).map(p => EncounterDiagnosis(p(0), p(1), p(2), p(3), p(4), p(5), p(6), p(7), p(8), p(9)
      , p(10)
      , p(11), p(12), p(13), p(14), p(15)
      , p(16), p(17), p(18), p(19), p(20), p(21), p(22) , p(23), p(24), p(25)/*, p(26)*/)).toDF().show(5,false)




    println("************************************************************************************************************************")

    System.exit(0)








    df1.map(f => f.mkString(",").replace("\u0017",",").replaceAll(",,",",null,").replaceAll(",\r\n",",null\r\n"))
      .map(l => l.substring(0,l.lastIndexOf(",")))
      .map(r => r.split(",").grouped(25).toList).flatMap(p => p).filter(f => f.size == 25)
      .map(p => EncounterDiagnosis(p(0), p(1), p(2), p(3), p(4), p(5), p(6), p(7), p(8), p(9)
        , p(10)
        , p(11), p(12), p(13), p(14), p(15)
        , p(16), p(17), p(18), p(19), p(20), p(21), p(22) , p(23), p(24), p(25)/*, p(26)*/)).show(125)
      /*.flatMap(p => p).map(p => if(p.trim.equals("") || p.isEmpty) "Empty" else p)*//*.map(r => if(r.equals("") ) "null" else r).*/
    //  .collect.foreach(x => x.foreach(println))
    println("+++++++++++++++++++++++++++++++++++++++++++++++++")

    val rddf = df1.map(f => f.mkString(",").split("\u0017").grouped(26).toList).flatMap(p => p).filter(f => f.size == 26).map(p => EncounterDiagnosis(p(0), p(1), p(2), p(3), p(4), p(5), p(6), p(7), p(8), p(9)
      , p(10)
      , p(11), p(12), p(13), p(14), p(15)
      , p(16), p(17), p(18), p(19), p(20), p(21), p(22) , p(23), p(24), p(25)/*,p(26)*/))


    rddf.show(125)




    println("====================================================================")
    val wrongformatdata1 = df1.map(f => f.mkString(",").split("\u0017").grouped(24).toList).flatMap(p => p).filter(f => f.size != 24)
    val flatdata1= wrongformatdata1.rdd.map(r => (1,r.mkString(","))).reduceByKey((a,b) =>  if(a.split(",").length + b.split(",").length < 24) a+b else a+","+b).map(r => r._2)
    val cor =flatdata1.map(r => r.toString.trim.split(",").grouped(25).toList).flatMap(x => x)
      cor.toDF().show(3,false)
    flatdata1.foreach(println)

    wrongformatdata1.map(x => x).collect.foreach(x => x.foreach(print))

 /* val correcteddf=  cor.map(f => f.mkString(",")./*toString.*/split(",").grouped(24).toList).flatMap(p => p).filter(f => f.size == 24).map(p => EncounterDiagnosis(p(0), p(1), p(2), p(3), p(4), p(5), p(6), p(7), p(8), p(9)
      , p(10)
      , p(11), p(12), p(13), p(14), p(15)
      , p(16), p(17), p(18), p(19), p(20), p(21), p(22) , p(23), p(24)/*, p(25)*/))

    correcteddf.toDF().show(3)*/
   /* val rddf12 = df1.map(f => f.mkString(",").split("\u0017").grouped(25).toList).flatMap(p => Seq(p)).filter(f => f.size == 25)

    import spark.implicits._
    rddf12.map(x => x).collect.foreach(println)*/
  /*  val xc = rddf12.map(x => Row(x(0))).rdd.toJavaRDD()


    val myrdd12 = spark.createDataFrame(xc,schema)

    myrdd12.show(2,false)
*/
    println("====================================================================")

    rddf.show()


    System.exit(0)




println("DF01 ==========")
 df1.map(f => f.mkString(",").split("\u0017").grouped(24).toList)
//   .flatMap(p => p).filter(f => f.size == 24)
   .show(35, false)


  //  val df2 = spark.read.text("/home/pankaj.singh/DataSet/Encounter Section files/Clinical_Automatic_a11132be-9be6-41ac-bb51-57c4cad11c71_167be332-0a88-4ebd-8fb9-7f1ef03e9b68_8ff9928e-7288-4491-8aa0-c7e0da5bbba8_a11132be-9be6-41ac-bb51-57c4cad11c71_cb27e6c5-9860-4987-808c-c316d51f6c5 (1).txt")

    val df2 = spark.read.format("text").option("mode","DROPMALFORMED").option("escape","\n").load("/home/pankaj.singh/DataSet/Encounter Section files/Clinical_Automatic_a11132be-9be6-41ac-bb51-57c4cad11c71_167be332-0a88-4ebd-8fb9-7f1ef03e9b68_8ff9928e-7288-4491-8aa0-c7e0da5bbba8_a11132be-9be6-41ac-bb51-57c4cad11c71_cb27e6c5-9860-4987-808c-c316d51f6c5 (1).txt")

    //.show(35,false)
   val wrongformatdata = df2.map(f => f.mkString(",").split("\u0017").grouped(24).toList).flatMap(p => p).filter(f => f.size != 24)/*.show(35, false)*/


    var myarray : ListBuffer[String] = ListBuffer()

    wrongformatdata.show(35,false)

    val flatdata= wrongformatdata.rdd.map(r => (1,r.mkString(","))).reduceByKey((a,b) =>  if(a.split(",").length + b.split(",").length < 25) a+b else a+","+b).map(r => r._2)

    flatdata.foreach(println)



    val arrangedata = flatdata.map(r => r.toString.trim.split(",").grouped(24).toList).flatMap(p => p).filter(f => f.size == 24)
println("==arrangdata")
   // arrangedata.foreach(x => x.foreach(println))


    println("wrong data")
    flatdata.map(r => r.toString.trim.split(",").grouped(25).toList).flatMap(x => x).toDF().show(45,false)/*.filter(f => f.size != 25)*//*.collect.foreach(x=> x.foreach(println))*/
  }

}
