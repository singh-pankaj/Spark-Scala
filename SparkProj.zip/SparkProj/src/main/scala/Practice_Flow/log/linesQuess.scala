package Practice_Flow.log

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

object linesQuess {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  val spark = SparkSession.builder().master("local[*]").appName("hh").getOrCreate()

  import spark.implicits._


  case class EncounterDiagnosis(   patientid:String
                                  ,encounterdate:String
                                  ,serviceprovidernpi:String
                                  ,serviceproviderlastname:String
                                  ,serviceproviderfirstname:String
                                  ,servicelocationid:String
                                  ,servicelocationname:String
                                  ,encounterdiagnosiscode:String
                                  ,encounterdiagnosistext:String
                                  ,encounterdiagnosiscategory:String
                                  ,encounterproblemtypecode:String
                                  ,encounterproblemtypetext:String
                                  ,documentationdate:String
                                  ,problemresolutiondate:String
                                  ,problemstatuscode:String
                                  ,problemstatustext:String
                                  , problemhealthstatuscode:String
                                  ,problemhealthstatustext:String
                                  ,negationind:String
                                  ,problemcomment:String
                                  ,problemonsetdate:String
                                  ,targetsitecode:String
                                  ,targetsitetext:String
                                  ,listorder:String
                                  ,encounterdiagnosiskey:String
                                  ,practiceuid:String
                                 //   ,batchuid:String
                               )




  // import spark.implicits._
  def main(args: Array[String]): Unit = {



    val df1 = spark.read.text("/home/pankaj.singh/DataSet/visit Section files1/")  //b,d


    /**********************************************************************************/

    val myString : Array[String] = Array("34","43","","","","","","","","","","","","","","","","","","","","","","","","")



    println(myString.toSeq.length)

    val z = myString.toString().split(" ").map(x => x).toSeq

    println(z)
   // df2.withColumn("Concat",concat(z:_*)).show(false)


    def maper( row:String) :Iterator[Array[String]] ={


    val cv = row.split(",").grouped(26)

     // EncounterDiagnosis(z:_*)

      cv
    }

   /* val lineDFtest= df1.map(f => f.toString()/*.replace("\u0017", ",")*/
      .replaceAll("\u0017\u0017", "\u0017null\u0017").replace("\u0017]", "\u0017null")
      .replace("[", "").replace("]", ""))
      .map(r => r.split("\u0017").grouped(26).toList).flatMap(p => p).filter(f => f.size == 26)
    //  .map(EncounterDiagnosis(z(0)))
    /*  .map(p => EncounterDiagnosis(p(0), p(1), p(2), p(3), p(4), p(5), p(6), p(7), p(8), p(9)
        , p(10)
        , p(11), p(12), p(13), p(14), p(15)
        , p(16), p(17), p(18), p(19), p(20), p(21), p(22), p(23), p(24), p(25)))
      .show(12)*/*/

    System.exit(0)

     /*************************************************************************/

    val GroupDF = df1.map(f => f.toString()/*.replace("\u0017", ",")*/
      .replaceAll("\u0017\u0017", "\u0017null\u0017").replace("\u0017]", "\u0017null")
      .replace("[", "").replace("]", ""))
      .map(r => r.split("\u0017").grouped(26).toList).flatMap(p => p)



    val lineDF= GroupDF.filter(f => f.size == 26)
      .map(p => EncounterDiagnosis(p(0), p(1), p(2), p(3), p(4), p(5), p(6), p(7), p(8), p(9)
        , p(10)
        , p(11), p(12), p(13), p(14), p(15)
        , p(16), p(17), p(18), p(19), p(20), p(21), p(22), p(23), p(24), p(25)))

    lineDF.show(125, false)


    val correctedDF = GroupDF.filter(f => f.size != 26).rdd.map(r => (1, r.mkString(","))).reduceByKey((a, b) => {
      if (a.split(",").length % 26 == 0) a + "," + b
      else a + b
    }).map(r => r._2)


    println("+++++++++++++++++")
    correctedDF.collect.foreach(print)

    println("+++++++++++++++++")
  val corDF =  correctedDF.map(r => r.toString.trim.split(",").grouped(26).toList).flatMap(p => p).map(x => x).map(p => EncounterDiagnosis(p(0), p(1), p(2), p(3), p(4), p(5), p(6), p(7), p(8), p(9)
      , p(10)
      , p(11), p(12), p(13), p(14), p(15)
      , p(16), p(17), p(18), p(19), p(20), p(21), p(22), p(23), p(24), p(25))).toDS()


    corDF.show(125,false)

    lineDF.union(corDF).show(125,false)

    println(corDF.count())
    println(lineDF.count())
    println(lineDF.union(corDF).count())

    System.exit(0)


  }

  def parser(spark:SparkSession , path:String ) : DataFrame = {

    val df1 = spark.read.text(path)
    val columncount=26

    val lineDF= df1.map(f => f.toString()
      .replaceAll("\u0017\u0017", "\u0017null\u0017").replace("\u0017]", "\u0017null")
      .replace("[", "").replace("]", ""))
      .map(r => r.split("\u0017").grouped(columncount).toList).flatMap(p => p).filter(f => f.size == columncount)
      .map(p => EncounterDiagnosis(p(0), p(1), p(2), p(3), p(4), p(5), p(6), p(7), p(8), p(9)
        , p(10)
        , p(11), p(12), p(13), p(14), p(15)
        , p(16), p(17), p(18), p(19), p(20), p(21), p(22), p(23), p(24), p(25)))



    val wrongformatdata11 = df1.map(f => f.toString()/*.replace("\u0017", ",")*/
      .replaceAll("\u0017\u0017", "\u0017null\u0017").replace("\u0017]", "\u0017null")
      .replace("[", "").replace("]", ""))
      .map(r => r.split("\u0017").grouped(columncount).toList).flatMap(p => p).filter(f => f.size != columncount)

    val correctedDF = wrongformatdata11.rdd.map(r => (1, r.mkString(","))).reduceByKey((a, b) => {
      if (a.split(",").length % columncount == 0) a + "," + b
      else a + b
    }).map(r => r._2)


    val corDF =  correctedDF.map(r => r.toString.trim.split(",").grouped(columncount).toList).flatMap(p => p).map(x => x).map(p => EncounterDiagnosis(p(0), p(1), p(2), p(3), p(4), p(5), p(6), p(7), p(8), p(9)
      , p(10)
      , p(11), p(12), p(13), p(14), p(15)
      , p(16), p(17), p(18), p(19), p(20), p(21), p(22), p(23), p(24), p(25))).toDS()



   lineDF.union(corDF).toDF()




  }

}
