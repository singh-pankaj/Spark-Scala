package Practice_Flow.log
import message.messagemap

object loggerCapture {

  def main(args: Array[String]): Unit = {


    val arr: Array[String]= Array("Pankaj","Singh")

    val x =messagemap("message1").format(arr: _*)



    /*val message="message1"
    val x = message.messagemap.get(message)*/
    println(x)

     val str = "GeeksforGeeks.";

    // Concatenation of two strings
    val gfg1 = String.format("My Company name is %s", str)

    val xc = "My Company name is "
    val gfg2 = xc.format(str)

    println(gfg1)
    println(gfg2)
  }

}
