package Practice_Flow

import DataFrame_Practice.Parquet_schema_merge.spark
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

object Json_Practice {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  val spark = SparkSession.builder().master("local[*]").appName("DF_Practice").getOrCreate()

  /*
  val otherPeopleDataset = spark.createDataset(
  """{"name":"Yin","address":{"city":"Columbus","state":"Ohio"}}""" :: Nil)
val otherPeople = spark.read.json(otherPeopleDataset)
otherPeople.show()
   */


  def main(args: Array[String]): Unit = {

    import spark.implicits._

    val otherPeopleDataset = spark.createDataset(
      """{"name":"Yin","address":{"city":"Columbus","state":"Ohio"}}""" :: Nil)

    val otherPeople = spark.read.json(otherPeopleDataset)
    otherPeople.show()

  }
}
