package Practice_Flow

//import Divide.my_divide

object My_Main_Class extends  SubTrait {




  def main(args: Array[String]): Unit = {

    println(add(1,3))
    println(add(1,3,2))

    val x = new Substract()
    println("Substract is "+ x.sub(4,2))

    println(x.sub_var)

   // my_divide

  }


  def add(x:Int,y:Int) :Int = {

    val z= x+y

    return z

  }

  def add(x:Int, y:Int, z:Int): Int = {

    val a= x+y+z
return a


  }

}
