package Practice_Flow

class SubTrait extends Divide {

def int_div(x:Int , y: Int): Unit ={

  //usage is not clear

  println("This is subtrait")

}



}
