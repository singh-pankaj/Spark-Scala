package Practice_Flow

trait Divide {

  var my_divide = "This is divide variable"

  def int_div(x:Int , y:Int)

}
