package CDR_Practice.util

object Cassendra_Utility {

}
