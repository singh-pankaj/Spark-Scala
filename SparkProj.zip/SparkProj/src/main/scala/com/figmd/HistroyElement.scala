package com.figmd

import com.figmd.Dataset_Practice.spark
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

object HistroyElement {

  Logger.getLogger("org").setLevel(Level.OFF) //all, debug, error, fatal, info, off, trace, trace_int, warn
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("myLogger").setLevel(Level.OFF)
  val spark = SparkSession.builder().appName("Dataframe Practice").master("local[*]").getOrCreate()

  def main(args: Array[String]): Unit = {
    import spark.implicits._

    val MeasureRDD = spark.read.textFile("/home/pankaj.singh/Downloads/NewHistoryElements.txt").rdd

    //AAO measurelist
      val aao_measurelist = Array("IRIS1","IRIS2","IRIS44","IRIS43","IRIS5","IRIS6","IRIS7","IRIS8","IRIS9","IRIS10","IRIS13","IRIS16","IRIS18","IRIS21","IRIS22","IRIS23","IRIS24","IRIS27","IRIS40","IRIS41","IRIS42","IRIS46","IRIS47","QIM2","QIM2","IRIS38","IRIS39","IRIS37","IRIS48","IRIS35","Ecqm143","Ecqm142","Ecqm147","Ecqm127","Ecqm131","Ecqm69","Ecqm133","Ecqm132","Ecqm138","Ecqm165","Ecqm156","Ecqm139","Ecqm50","Qpp14","Qpp141","Qpp384","Qpp385","Qpp388","Qpp389")

    // ABFM measurelist
    val abfm_measurelist = Array("Ecqm117", "Ecqm122", "Ecqm124", "Ecqm125", "Ecqm127", "Ecqm130", "Ecqm131", "Ecqm134", "Ecqm135", "Ecqm136", "Ecqm137", "Ecqm138", "Ecqm139", "Ecqm144", "Ecqm145", "Ecqm146", "Ecqm147", "Ecqm149", "Ecqm153", "Ecqm154", "Ecqm155", "Ecqm156", "Ecqm159", "Ecqm160", "Ecqm165", "Ecqm2", "Ecqm22", "Ecqm347", "Ecqm50", "ECQM69", "ECQM74", "ECQM90", "PRIME100", "PRIME106", "PRIME108", "PRIME109", "PRIME44", "PRIME54", "PRIME72", "PRIME80", "PRIME93", "PRIME95", "PRIME96", "QPP109", "QPP131", "QPP23", "QPP24", "QPP39", "QPP434", "QPP394", "QPP402", "QPP418", "QPP431", "QPP433", "QPP432", "QPP435", "QPP436", "QPP437", "QPP438", "QPP439", "QPP440", "QPP441", "QPP442", "QPP443", "QPP444", "QPP445", "QPP446", "QPP448", "QPP449", "QPP450", "QPP451", "QPP452", "QPP453", "QPP454", "QPP455", "QPP456", "QPP457", "QPP459", "QPP460", "QPP461", "QPP463", "QPP464", "QPP465", "QPP467", "QPP468", "QPP469", "QPP470", "QPP471", "QPP473", "QPP474", "QPP475")

    //AUA
    val aua_measurelist = Array("MUSIC4", "AQUA8", "AQUA3", "AQUA30", "AQUA29", "AQUA26", "AQUA21", "AQUA20", "AQUA18", "AQUA17", "AQUA16", "AQUA15", "AQUA14", "AQUA13", "AQUA12", "AQUA01", "AQUA02", "QPP1", "QPP23", "QPP46", "QPP47", "QPP48", "QPP50", "QPP102", "QPP104", "QPP110", "QPP111", "QPP113", "QPP117", "QPP119", "QPP128", "QPP130", "QPP131", "QPP134", "QPP226", "QPP236", "QPP265", "QPP317", "QPP357", "QPP358", "QPP370", "QPP431", "QPP438", "Ecqm122", "Ecqm129", "Ecqm147", "Ecqm127", "Ecqm125", "Ecqm130", "Ecqm131", "Ecqm134", "Ecqm69", "Ecqm68", "Ecqm2", "Ecqm138", "Ecqm165", "Ecqm22", "Ecqm139", "Ecqm159", "Ecqm347", "QPP112")

    // AAN
    val aan_measurelist = Array("Axon03", "Axon05", "Axon06", "Axon07", "Axon11", "Axon13", "Axon23", "Axon25", "Axon28", "Axon41", "QPP47", "QPP130", "QPP154", "QPP155", "QPP268", "QPP282", "QPP283", "QPP286", "QPP288", "QPP290", "QPP291", "QPP293", "QPP370", "QPP374", "QPP386", "QPP408", "QPP412", "QPP414", "QPP419", "QPP431", "QPP435", "Ecqm139")

    // ACR
    val acr_measurelist = Array("ACR01", "ACR02", "ACR03", "ACR04", "ACR05", "ACR08", "ACR09", "ACR07", "GIOP01", "QPP24", "QPP39", "QPP47", "QPP109", "QPP110", "QPP111", "QPP128", "QPP130", "QPP131", "QPP176", "QPP177", "QPP178", "QPP179", "QPP180", "QPP226", "QPP236", "QPP238", "Ecqm122", "Ecqm135", "Ecqm145", "Ecqm144", "Ecqm128", "Ecqm143", "Ecqm142", "Ecqm129", "Ecqm161", "Ecqm147", "Ecqm127", "Ecqm125", "Ecqm130", "Ecqm131", "Ecqm134", "Ecqm69", "Ecqm68", "Ecqm2", "Ecqm157", "Ecqm52", "Ecqm133", "Ecqm132", "Ecqm138", "Ecqm165", "Ecqm156", "Ecqm137", "Ecqm124", "Ecqm22", "Ecqm139", "Ecqm159", "Ecqm160", "Ecqm82", "Ecqm50", "Ecqm66", "Ecqm56", "Ecqm90")

    // AAD
    val aad_measurelist = Array("AAD1", "AAD5", "AAD09", "AAD27", "AAD28", "AAD29", "AAD33", "AAD34", "AAD35", "Qpp46", "Qpp47", "Qpp110", "Qpp111", "Qpp128", "Qpp130", "Qpp131", "Qpp137", "Qpp138", "Qpp205", "Qpp226", "Qpp265", "Qpp317", "Qpp337", "Qpp358", "Qpp374", "Qpp397", "Qpp402", "Qpp410", "Qpp431", "Qpp440", "Ecqm50")

    val allregistry_measure = Array(aao_measurelist,abfm_measurelist, aua_measurelist, aan_measurelist, acr_measurelist, aad_measurelist)

    val registry_measure = Array("aao","abfm", "aua", "aan", "acr", "aad")

    var i :Int=0
    allregistry_measure.foreach(measurelist => {

      val filteredData = MeasureRDD.filter(z => measurelist.exists(me => z.split("=")(0).split("_")(0).split("V")(0).toUpperCase.equals(me.toUpperCase)))
        .map(x => if (x.contains("V") && x.split("=").length == 2) (x.split("=")(0).split("V")(0), x.split("=")(1))

      else if (x.split("=").length == 2) {
        (x.split("=")(0).split("_")(0), x.split("=")(1))
      } else {
        (x.split("=")(0).split("_")(0), "NA")
      })


       val filterdata2 = filteredData.filter(z => !z._2.equals("NA"))

        val finalfilter= filterdata2.reduceByKey((a, b) => a + b).map(x => x._1 + "=" + x._2.substring(0, x._2.length - 1)

      )


      filterdata2.saveAsTextFile("home/pankaj.singh/History_Element_Table/"+registry_measure(i))

      println("**************written successfully**************************************"+registry_measure(i))

      i = i+1

      val zeroelement = filteredData.map(r=> r._1).subtract(filterdata2.map(x => x._1))

      println(measurelist.size +"****"+ filteredData.count()+"***"+filterdata2.count()+"***"+zeroelement.collect.foreach(println))

    }
    )

  }



}
