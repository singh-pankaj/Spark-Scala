package com.figmd

import java.io.{File, FileOutputStream, PrintWriter}

import scala.io.Source

object File_Handling {

  def main(args: Array[String]): Unit = {

    Source.fromFile("/home/pankaj.singh/mysample.txt").foreach(print)
    val writer = new PrintWriter(new FileOutputStream(new File("/home/pankaj.singh/mysample.txt"),true))
    writer.write("\nfile wirtten successfully")
    writer.close()
    println()
    Console.print("congrats file written sucessfully")



  }


}
