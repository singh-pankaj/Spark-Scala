package com.figmd

object Test_11 {

  def main(args: Array[String]): Unit = {


    val mylist = List(("Pankaj","Kumar","Singh"),("Gopal","yadav","sin"))

    for(x<-mylist){

      println(x)

     println(x._1)
      println(x._2)
      println(x._3)
          }

  }

}
