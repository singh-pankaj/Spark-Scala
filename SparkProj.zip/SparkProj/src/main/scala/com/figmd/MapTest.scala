package com.figmd

object MapTest {

  def main(args: Array[String]): Unit = {
    var mymap : Map[String,String]= Map()

    mymap += "cvb" -> "fdff"

  //  mymap.foreach(println)
    val cv = mymap.get("cvb").toString
    println(cv)
    println(mymap.get("cvb").toString)
  }
}
