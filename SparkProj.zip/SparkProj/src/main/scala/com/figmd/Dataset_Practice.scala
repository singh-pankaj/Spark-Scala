package com.figmd

import org.apache.spark.sql.SparkSession
import org.apache.log4j.{Level, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory
import org.apache.spark.sql._

object Dataset_Practice {

  val spark = SparkSession.builder().appName("Dataframe Practice").master("local[*]").getOrCreate()

  /* add column */

  def addColumns(myCols: Set[String], allCols: Set[String]) = {
    allCols.toList.map(x => x match {
      case x if myCols.contains(x) => col(x)
      case _ => lit(null).as(x)
    })
  }


  def checkColumns(col1: Column, col2: Column): Column = {
    if (col1 != ("") && col2 != ("")) {
      val col3 = concat_ws("_", col1, col2)
      col3
    }
    else {
      null
    }
  }


  def main(args: Array[String]): Unit = {

    import spark.implicits._

    val EmployeeRDD = spark.read.option("header", "true").csv("/home/pankaj.singh/Downloads/Data Sample/Employee_Details.csv")
    val Employee_Details = spark.read.option("header", "true").csv("/home/pankaj.singh/Downloads/Data Sample/Employee.csv")

    /** *****Broadcast Variable *****/
    val mybroadcast = spark.sparkContext.broadcast(Employee_Details)

   // Employee_Details.where(col("id").startsWith("1")).show()

    mybroadcast.value.show()
    println("Above is brodcast variable ")


    /** Map column with header option false
      * val lookup = Map("_c0" -> "Id", "_c1" -> "Timestamp", "_c2" -> "Id_id" , "_c3" -> "Price")
      * var Orderrddmapcol = Employee_Details.select(Employee_Details.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*)
      * *
      *Orderrddmapcol.show()
      * */

    /** To get all the column of dataset Return type will be set **/
    val allcols = EmployeeRDD.columns.toSet
    val viewcols = Employee_Details.columns.toSet
    val total = allcols ++ viewcols


    val my = EmployeeRDD.select(addColumns(allcols, total): _*)
      .union(Employee_Details.select(addColumns(viewcols, total): _*))


    val myrdd = my.withColumn("id", upper($"id"))
    //   .withColumn("ServiceProviderNPI", lit("1053428771"))


    myrdd.foreach(r => println(r))

    for (x <- myrdd) {
      println("myrdd ")
      println(x)
    }


    for (x <- my) {
      println(x)
    }

    for (x <- total) {
      print(x + " ")
      println("total column")
    }


    EmployeeRDD.show() // id city Company
    Employee_Details.show() //  id, name age


    val xs = EmployeeRDD.join(Employee_Details, "id")
    xs.show() //id city company name age
    println("Above is InnerJoin")

    val fullouterjoin = EmployeeRDD.join(Employee_Details, Seq("id"), "full_outer")

    fullouterjoin.show() //id name age city Company
    println("FUll Outer Join")


    val unionEmployeeRDD = EmployeeRDD.union(Employee_Details)
    unionEmployeeRDD.show() // id city Company
    println("Union") //Data will get append irrespective of column data value


    /** *********************************************************************************************/

    //  xs is inner join
    /** with column usage like column rename and value change operation **/

    val checkcol = xs.withColumn("add", ($"id" + $"id"))
      .withColumn("Service provider", col = lit("125"))
      .withColumn("check column", lit(""))
      .withColumnRenamed("name", "new name")
    checkcol.show()
    println("check col")


    /** map function with Dataset checkcol **/
    val withColIndex = checkcol.map(r => (r.getString(0), r.getString(1)))
    println("with Col index")
    withColIndex.show()


    /** **********************************************************************************************/

    //update check coloumn=4

    //val updatecheck =
    /** add column in dataset using with column **/
    val updatecol = checkcol.filter(checkcol("id") === "1").withColumn("check column", lit(3))

    updatecol.show()

    /*update not visible due to old dataset checkcol because new dataset got created from checkcol to uppdatecom*/
    checkcol.show()
    println("check col ends")


    /** column select from Dataset **/

    val xc = EmployeeRDD.join(Employee_Details, "id").select("id", "name", "city")

    xc.show()

    /** join and select column using alias **/

    val xf = EmployeeRDD.as("df1").join(Employee_Details.as("df2"), $"df1.id" === $"df2.id").select("df1.*")

    xf.show()

    //  xf.drop("Company").show()

    /** Register dataset as Temp table **/

    xf.registerTempTable("sample")

    val sample_table = spark.sql("SELECT city,id from sample")

    sample_table.show()
    sample_table.printSchema()
    // sample_table.schema


    /** Apply function in Dataset **/
    val xxx = max_1(sample_table, "id")
    xxx.show()
    println("sddd")

    //   case class empclass(id:String)
    val EmployeeRDD_DataSet = EmployeeRDD.as[empclass]

    val xd = max_Dataset(EmployeeRDD_DataSet, "id")

    xd.show()
    println("Dataset function applied successfully")

  }


  def max_1(df: DataFrame, dfcol: String): DataFrame = {

    return df.filter(df(dfcol) === 2)

  }

  case class empclass(id: String, city: String, Company: String)

  def max_Dataset(df: Dataset[empclass], dfcol: String): Dataset[empclass] = {
    return df.filter(df(dfcol) === 1 || df(dfcol) === 2)
  }

}
