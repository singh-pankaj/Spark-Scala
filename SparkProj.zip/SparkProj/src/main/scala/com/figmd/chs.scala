package com.figmd

object chs {

  def main(args: Array[String]): Unit = {

    var myarray : Array[String] = null

    myarray = Array("2019-01-01", "2019-01-21")

    myarray.foreach(println)

  }

}
