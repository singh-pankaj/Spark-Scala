package com.figmd

//import com.figmd.File_Utility

object Check_Test {

  def main(args: Array[String]): Unit = {

    val s = File_Utility.getproperty("name")

    println("value of s "+s)


    println(File_Utility.getproperty())


  }





}
