package com.figmd

object ClassCall {

  def main(args: Array[String]): Unit = {


   // com.figmd.myclass

val fullname ="com.figmd.myclass"+"$"


    val clazz = Class.forName(fullname)

    val myObj = clazz.getField("MODULE$").get(classOf[refresh]).asInstanceOf[refresh]

    myObj.writee("Pankaj")

   // val x = clazz.getField("MODULE$")


   /* val fullname1 ="com.figmd.myclass"


    val claz = Class.forName(fullname1)

    val obj = claz.newInstance()*/




  }

}
