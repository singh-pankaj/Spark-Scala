package com.figmd

import java.util.UUID

import org.apache.spark.sql.functions._

object Test_Scala {


  def main(args: Array[String]): Unit = {


    val getNewUid = udf[String](() => {
      UUID.randomUUID.toString
    })

    // println(UUID.randomUUID().toString)
    val c = UUID.randomUUID().toString
    for (x <- c) {
      println(c)
    }

    println()
    //println(getNewUid)

    val donutType = "dsdsDonut"

    val tasteLevel2 = donutType match {
      case "Glazed Donut" => "Very tasty"
      case "Plain Donut" => "Tasty"
      case _ => "Tasty"
    }
    println(s"Taste level of $donutType = $tasteLevel2")


    val mycol = Set("name", "id", "sex", "age")
    val allcol = Set("name", "age", "school")
    val total = mycol ++ allcol

    println(total.toList.map(x => x match {
      case x if mycol.contains(x) => x //if mycol.contains(x) => x
      case _ => lit(null).as(x)
    }))

    def addColumns(myCols: Set[String], allCols: Set[String]) = {
      allCols.toList.map(x => x match {
        case x if myCols.contains(x) => col(x)
        case _ => lit(null).as(x)
      })
    }

    val x = addColumns(mycol, total)

    for (x1 <- x)
      println(x1)

  }

}