package com.figmd

import java.util.logging.{Level, Logger}

object Mylogger {


  def main(args: Array[String]): Unit = {

    val logger = Logger.getLogger(classOf[Nothing].getName)

    println("selec")


    logger.info("This is log 1")


    Logger.getLogger("con.figmd.Mylogger").setLevel(Level.WARNING)

    Logger.getLogger("org").setLevel(Level.INFO)
    Logger.getLogger("akka").setLevel(Level.OFF)
    //  Logger.getLogger("myLogger").setLevel(Level.OFF)

    //  Thread.sleep(2000)

    logger.info("This is info")
    logger.warning("This is warning")


    logger.getLevel

    println(logger.getLevel)

  }


}
