package com.figmd

import com.datastax.spark.connector.CassandraRow
import org.apache.log4j.{Level, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SparkSession}
import org.joda.time.DateTimeZone


object Dosage {
  Logger.getLogger("org").setLevel(Level.OFF) //all, debug, error, fatal, info, off, trace, trace_int, warn
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("myLogger").setLevel(Level.OFF)

  val spark = SparkSession.builder().appName("Dosage").master("local[*]").getOrCreate()

  def main(args: Array[String]): Unit = {


     val patientHistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "dosage", "element_date" -> "2018-01-01 00:03:00.000+00:00",  "element_date1" -> "2018-01-01 00:00:00.000+00:00" ,"elementvalue1" -> "5"))
     /* CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "dosage", "element_date" -> "2018-01-05 00:00:00.000+00:00",  "elementvalue" -> "10","elementvalue1" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "dosage", "element_date" -> "2018-01-07 00:00:00.000+00:00",  "elementvalue" -> "12","elementvalue1" -> "12")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "dosage", "element_date" -> "2018-05-10 00:00:00.000+00:00",  "elementvalue" -> "2","elementvalue1" -> "2")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "dosage", "element_date" -> "2018-05-13 00:00:00.000+00:00",   "elementvalue" -> "4","elementvalue1" -> "4"))*/
     /* CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "ele", "e_start" -> "2018-05-01 00:00:00.000+00:00", "e_end" -> "2018-05-10 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "ele", "e_start" -> "2017-03-04 00:00:00.000+00:00", "e_end" -> "2018-03-05 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "ele", "e_start" -> "2018-03-07 00:00:00.000+00:00", "e_end" -> "2019-03-10 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "ele", "e_start" -> "2018-03-11 00:00:00.000+00:00", "e_end" -> "2019-03-14 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "ele", "e_start" -> "2019-03-20 00:00:00.000+00:00", "e_end" -> "2019-03-22 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "ele", "e_start" -> "2018-01-01 00:00:00.000+00:00", "e_end" -> "2018-01-02 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "ele", "e_start" -> "2019-03-16 00:00:00.000+00:00", "e_end" -> "2019-03-18 00:00:00.000+00:00", "elementvalue" -> "5"))*/

    ))


    patientHistoryRDD.map(x => (x.getDateTime("element_date"),x.getDateTime("element_date1"))).foreach(println)

    patientHistoryRDD.map(x => (x.getDateTime("element_date").toLocalDate().toDateTimeAtMidnight,x.getDateTime("element_date1").withZone(DateTimeZone.UTC))).foreach(println)


   val c = patientHistoryRDD.collect.exists(x => x.getDateTime("element_date").withZone(DateTimeZone.UTC).equals(x.getDateTime("element_date1").withZone(DateTimeZone.UTC)))

    println(c)


    val d = patientHistoryRDD.collect.exists(x => x.getDateTime("element_date").toLocalDate().toDateTimeAtMidnight.equals(x.getDateTime("element_date1").toLocalDate().toDateTimeAtMidnight))
    println(d)
    //patientHistoryRDD.map(x => (x.getDateTime(2).getMonthOfYear,x.getDateTime(2).getYear,x.getDateTime(2))).foreach(println)


//    spark.createDataFrame(patientHistoryRDD,patientHistoryRDD.++())
    /*difference(spark,patientHistoryRDD,"elementvalue","elementvalue1").foreach(println)


    def difference(sparkSession: SparkSession,rdd: RDD[CassandraRow], col1:String, col2:String):RDD[CassandraRow]={

     val cv =  rdd.map(r => (r,r.getDouble(col1)-r.getDouble(col2)))

     // cv.wi
      import com.datastax.spark.connector
      val withappendedColumnsRdd = rdd.map( row => {

        val originalcol = row

        val FirstColValue = originalcol.asInstanceOf[Double]
*/

     // val xcv =  sparkSession.sparkContext.parallelize(Seq(originalcol,"result"->(row.getDouble("elementvalue")-row.getDouble("elementvalue1"))))

       // val xcv =  Map(originalcol,"result"->(row.getDouble("elementvalue")-row.getDouble("elementvalue1")))
      //  xcv
     // val cv =  xcv.map(r => CassandraRow.fromMap(Map(r->"")))
      //  cv
       // Row.fromSeq(originalcol + originalcol)

      //  originalcol

        import com.datastax.driver.core.Row

   //      val c = CassandraRow.fromMap(Map("result"->(row.getDouble("elementvalue")-row.getDouble("elementvalue1")))) /*:++ originalcol*/


     //   CassandraRow.fromMap(originalcol)


        /*
        spark.sparkContext.parallelize(Seq(
        CassandraRow.fromMap(Map("patientuid" -> "P1",
         */

        /*
           val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
        CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-03-01 00:00:00.00", "elementvalue" -> "10"))
         */
     /* })
      withappendedColumnsRdd
    }*/

     /*val xc = patientHistoryRDD.filter(x => x.getString("element").equals("dosage")).map(r => (r.getString("patientuid"),r.getDate("element_date").getTime
       ,r.getString("elementvalue"))).groupBy(_._1).sortBy(c => c._2).map(x => (x._1,x._2))

    xc.foreach( r => {
      r._2.foreach( println)

    })*/

    /*
      val rdd = ...
    val withAppendedColumnsRdd = rdd.map(row => {
      val originalColumns = row.toSeq.toList
      val secondColValue = originalColumns(1).asInstanceOf[Int]
      val thirdColValue = originalColumns(2).asInstanceOf[Int]
      val newColumnValue = secondColValue + thirdColValue
      Row.fromSeq(originalColumns :+ newColumnValue)
      // Row.fromSeq(originalColumns ++ List(newColumnValue1, newColumnValue2, ...)) // or add several new columns
    })
       */
  }

}
