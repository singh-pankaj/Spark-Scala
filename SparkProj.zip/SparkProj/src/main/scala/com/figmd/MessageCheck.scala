package com.figmd
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

object MessageCheck {

  Logger.getLogger("org").setLevel(Level.OFF) //all, debug, error, fatal, info, off, trace, trace_int, warn
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("myLogger").setLevel(Level.OFF)

  val spark = SparkSession.builder()
              .master("local[*]")
              .appName("Message log check ")
              .getOrCreate()


  def main(args: Array[String]): Unit = {


    /************************************* Get History function list and count ****************************************************/

    val historyRDD = spark.read.textFile("/home/pankaj.singh/IdeaProjects/Top_40/src/main/scala/com/figmd/janus/util/measure/HistoryLookUpUtility.scala").rdd

  //  historyRDD.filter( r => r.contains("episode")).foreach(println)
//System.exit(0)

    val historyFunctionList =  historyRDD.filter(r => r.contains("def") && !r.contains("/*") && !r.contains("*/")  && !r.contains("@param") && r.contains("Boolean"))

    .map(_.replace("def","").trim).map(_.split("\\(")(0).trim)

  //  println("Total function in history lookup utility" -> historyFunctionList.count())

    //Print historyFunctionList
    historyFunctionList.foreach(println)

    /************************************* Get Measure function list and count ****************************************************/

    val MeasureRDD = spark.read.textFile("/home/pankaj.singh/IdeaProjects/Top_40/src/main/scala/com/figmd/janus/util/measure/MeasureUtility.scala").rdd

    val MeasureUtilityFunctionList =  MeasureRDD.filter(r => r.contains("def") && !r.contains("/*") && !r.contains("*/")  && !r.contains("@param") && r.contains("Boolean"))

      .map(_.replace("def","").trim).map(_.split("\\(")(0).trim)

    println("Total function in Measure utility" -> MeasureUtilityFunctionList.count())

    //   println("Total function in history lookup utility" -> MeasureUtilityFunctionList.count())
    // MeasureUtilityFunctionList.foreach(println)


    /************************************* *Get Message list and count***********************************************************************/

    val messageRDD = spark.read.textFile("/home/pankaj.singh/IdeaProjects/Top_40/src/main/scala/com/figmd/janus/util/measure/messages.scala").rdd

    val message = messageRDD.filter( r => (r.contains("_true")|| r.contains("_false")) && !r.contains("val")).map(x => x.split("->")(0))
      .map(z => z.replace("\"","") ).map(c => c.replace("_true","")).map(_.replace("_false","")).map(_.trim).distinct()

    println("Total message in message utility" -> message.count())

    //  message.foreach(println)


    /******************************Add history message to message.scala **************************************************************/

    val diff = historyFunctionList.subtract(message).distinct()

    diff.saveAsTextFile("/home/pankaj.singh/Message/AddMessage")
    diff.map(c=> "\""+c+"_true\""+"->"+"\""+" %s "+c+"\""    +",\n"+"\""+c+"_false\""+"->"+"\""+" %s "+c+"\",").saveAsTextFile("/home/pankaj.singh/Message/AddMessage_true")


   //  diff.foreach(println)


    /******************************Add Measure Utility message to message.scala **************************************************************/

    val xc = historyFunctionList.subtract(message).distinct()

    xc.saveAsTextFile("/home/pankaj.singh/Message/AddMessage_Measureutility")
    xc.map(c=> "\""+c+"_true\""+"->"+"\""+" %s "+c+"\""    +",\n"+"\""+c+"_false\""+"->"+"\""+" %s "+c+"\",").saveAsTextFile("/home/pankaj.singh/Message/AddMessage_Measureutility_true")


    xc.foreach(println)



    /******************* Message that does not contain both true and false*********************************************************/


    val messageValid = messageRDD.filter( r => (r.contains("_true")|| r.contains("_false")) && !r.contains("val")).map(_.trim)

    val messagev = messageValid.collect()

    val recheckMessage  = message.filter(x => !(messagev.exists(y => y.contains(x+"_true")) && messagev.exists(z => z.contains(x+"_false"))))

    recheckMessage.saveAsTextFile("/home/pankaj.singh/Message/RecheckMessage")
    //  recheckMessage.foreach(println)



    /*****************************************Get unwanted Message *****************************************************/

    val diff2 = message.subtract(historyFunctionList)
    val UnwantedMessage = diff2.subtract(MeasureUtilityFunctionList)

    UnwantedMessage.saveAsTextFile("/home/pankaj.singh/Message/RemoveUnWantedMessage")


  }


}
