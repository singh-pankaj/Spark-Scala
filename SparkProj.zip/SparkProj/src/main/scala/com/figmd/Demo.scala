package com.figmd

import java.io.{File, FileOutputStream, PrintWriter}

import scala.io.Source

object Demo {

  def main(args: Array[String]): Unit = {

    println(addInt(5, 8))


    for (a <- 1 to 10) {
      print(" " + a)
    }
    println()

    println("*******************************")

    var x = 0;

    // for loop execution with a range
    for (x <- 5 until 10) {
      println("Value of a: " + x);
    }

    println("*************************************")
    var a = 0;
    var b = 0;

    // for loop execution with a range
    for (a <- 1 to 3; b <- 1 to 3) {
      println("Value of a & b is : " + a+" "+b)
    //  println("Value of b: " + b)
    }

    println("*************************************")

    a = 0;
    val numList = List(1, 2, 3, 4, 5, 6, 7, 8, 9)
    for (a <- numList) {
      println("Value of xxx: " + a)
    }

    println()
    println("*************************************")

    a = 0;
    // for loop execution with multiple filters
    var xx = for (a <- numList if a != 3; if a < 8) yield a

    for (x <- xx) {
      println("dd " + x)
    }

    println("*************************************")

/*
       print("Please enter your input")
       val line = Console.readLine()
       println("You have read" + line)

*/


      Source.fromFile("/home/pankaj.singh/mysample.txt").foreach(print)
      val writer = new PrintWriter(new FileOutputStream(new File("/home/pankaj.singh/mysample.txt"),true))
      writer.write("\nfile wirtten successfully")
      writer.close()
    println()
    Console.print("congrats file written sucessfully")


  }

  def addInt(a: Int, b: Int): Int = {

    var sum: Int = 0

    sum = a + b;
    return sum

  }

}
