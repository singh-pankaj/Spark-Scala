package com.figmd
import com.datastax.spark.connector.CassandraRow
import org.apache.log4j.{Level, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.joda.time.DateTime

object checkFunctionLogger {

  Logger.getLogger("org").setLevel(Level.OFF) //all, debug, error, fatal, info, off, trace, trace_int, warn
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("myLogger").setLevel(Level.OFF)





  val spark = SparkSession.builder()
                          .appName("function checklist")
                            .master("local[*]")
                            .getOrCreate()

  def main(args: Array[String]): Unit = {


    val messageRDD = spark.read.textFile("/home/pankaj.singh/IdeaProjects/Top_40/src/main/scala/com/figmd/janus/util/measure/messages.scala").rdd

  /*  val historyFunctionList =  messageRDD.filter(r => r.contains("def") && !r.contains("/*") && !r.contains("*/")  && !r.contains("@param") && r.contains("Boolean"))

      .map(_.replace("def","").trim).map(_.split("\\(")(0).trim)*/
   // messageRDD.foreach(println)




    val UnwantedmessageRDD = spark.read.textFile("/home/pankaj.singh/Message/unwanted").rdd

    /*  val historyFunctionList =  messageRDD.filter(r => r.contains("def") && !r.contains("/*") && !r.contains("*/")  && !r.contains("@param") && r.contains("Boolean"))

        .map(_.replace("def","").trim).map(_.split("\\(")(0).trim)*/
   val xcv =  UnwantedmessageRDD.collect()


    messageRDD.filter(r => xcv.exists(z => !r.contains(z))).saveAsTextFile("home/pankaj.singh/FinalMessage")


    val historyRDD = spark.read.textFile("/home/pankaj.singh/IdeaProjects/Top_40/src/main/scala/com/figmd/janus/util/measure/HistoryLookUpUtility.scala").rdd

    val historyFunctionList =  historyRDD.filter(r => r.contains("def") && !r.contains("/*") && !r.contains("*/")  && !r.contains("@param") && r.contains("Boolean"))

      .map(_.replace("def","").trim).map(_.split("\\(")(0).trim)

   // historyFunctionList.foreach(println)

   // println(historyFunctionList.count())

    // ===============================================================================================

    val FunctionRDD = spark.read.textFile("/home/pankaj.singh/IdeaProjects/Top_40/src/main/scala/com/figmd/janus/util/measure/HistoryLookUpUtility.scala").rdd

   // FunctionRDD.foreach(println)

    val xc = FunctionRDD.filter(r => r.contains("measureLogger")) //&& !r.contains("/*") && !r.contains(""))

    //   .map(_.split(",")(2).replace("\"",""))

  //  xc.foreach(println)




// /home/pankaj.singh/IdeaProjects/Top_40/src/main/scala/com/figmd/janus/util/measure/HistoryLookUpUtility.scala

 //   val rdd1 = spark.read.textFile("/home/pankaj.singh/IdeaProjects/Top_40/src/main/scala/com/figmd/janus/util/measure/HistoryLookUpUtility.scala").rdd //home/pankaj.singh/HistoryLookUpUtility.scala


    //rdd2.map(_.split("\\{").length).foreach(println)


 //  val xc =  rdd1.filter(r => r.contains("def") && !r.contains("/*") && !r.contains("*/")  && !r.contains("@param") && r.contains("Boolean"))

  //    .map(_.replace("def","").trim).map(_.split("\\(")(0).trim)


  //  rdd1.filter(r => !r.contains("def") || !r.contains("import") || !r.contains("class") ).map(_.split("\\{")(0)).take(1).foreach(println)


   //   xc.foreach(println)

  //  println(xc.count())


  //  val x =  rdd1.filter(r => r.contains("measureLogger") && !r.contains("/*") && !r.contains("") )

   //   .map(_.split(",")(2).replace("\"",""))

    /*var p : Int =0
    var q : Int =0

    var functionname =""
    var loggername =""


    var function = ""

    rdd1.foreach( r =>

      if(r.contains("def") && !r.contains("") && !r.contains("")  && !r.contains("@param") && r.contains("Boolean")) {

        functionname = r.replace("def","").trim.split("\\(")(0).trim

        println(functionname)

      println(r.split("\\{").reduce(_+_).toInt )

      }


      else if( r.contains("measureLogger") && !r.contains("") && !r.contains("")){

        loggername = r.split(",")(2).replace("\"","")
        println(loggername)
      }

      else if( p == q){
        functionname=""
        loggername=""
        p=0
      q==0
      }
    )*/

  }

  def check (r: String):Boolean={

    r.contains(r) && !r.contains("/*") && !r.contains("*/")  && !r.contains("@param") && r.contains("Boolean")  }

}
