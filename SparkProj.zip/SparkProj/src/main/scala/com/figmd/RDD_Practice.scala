package com.figmd

import com.esotericsoftware.minlog.Log.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.rdd
import org.apache.spark.rdd.RDD

object Practicee {
  val spark = SparkSession.builder().appName("My practice").master("local[*]").getOrCreate()


  def readRDD(Mylist: RDD[String]): Unit = {
    println("This prints RDD")
    for (e <- Mylist) {
      println(e)
    }

    println("Printed RDD")
  }


  def main(args: Array[String]): Unit = {


   // my_method1("Pankaj","Sgar")





    val OrderRDD = spark.read.textFile("/home/pankaj.singh/Downloads/Sample_Data/order.txt").rdd

    val OrderItemsRDD = spark.read.textFile("/home/pankaj.singh/Downloads/Sample_Data/orderItem.txt").rdd


    val rdd_1 = spark.read.textFile("/home/pankaj.singh/Downloads/Sample_Data/Count.txt").rdd
    val rdd_xx = spark.read.textFile("/home/pankaj.singh/Downloads/Sample_Data/Count.txt").rdd
      //.map( r => (r.split(",")(0),r.split(",")(0),r.split(",")(0))).collect()




    //BroadCastRDD: Broadcast[Array[(String, String, Int)]]
    //val zrdd: Broadcast[Array[(String, String, Int)]] = sparkSession.sparkContext.broadcast(myrdd)

    //val rdx: Broadcast[Array[(String, String, String)]]= spark.sparkContext.broadcast(rdd_xx)

    println("****rdd1***")
    for (elem <- rdd_1.collect()) {
      println(elem)

    }

    //val rdd_2 = rdd_1
val rddxxx= rdd_xx.collect()

    val checkrdd = rdd_1.filter( r => myrddfunction_1(rddxxx,Row(r)))


    checkrdd.foreach(println)
    println("$$$$checkrdd")

    val rdd_2 = rdd_1.map(r => ((r.split(",")(0),r.split(",")(1)),r.split(",")(2)))


    val rdd = rdd_1.map(r => ((r.split(",")(0),r.split(",")(1)),r.split(",")(2), if (1==1)  0 else 2))

    println("****rdd***")
    for (elem <- rdd.collect()) {
      println(elem)

    }


    println("****rdd2***")
    for (elem <- rdd_2.collect()) {
      println(elem)

    }


    val rdd_3 = rdd_2.groupByKey()

    println("****rdd3***")
    for (elem <- rdd_3.collect()) {
      println(elem)

    }


    val initialCount = 0;
    val addToCounts = (n: Int, v: String) => n + 1
    val sumPartitionCounts = (p1: Int, p2: Int) => p1 + p2


    println("****rdd4***")
    val rdd_4 = rdd_2.aggregateByKey(initialCount)(addToCounts, sumPartitionCounts)
    for (elem <- rdd_4.collect()) {
      println(elem)


    }


/*
    var spl = "Pankaj,singh,yadav"

    var x: Array[String] = spl.split(",")

    println(x(0) + " " + x(1) + " " + x(2))

    /*Print Object class followed by hash code*/
    /*
    val myrdd = OrderRDD.map(s => s.split(",")
    myrdd.collect().foreach(println)
    */


    readRDD(OrderRDD)
    println("******orderRDD read by function************")

    for (elem <- OrderRDD.collect()) {
      println(elem)

    }

    println("******orderRDD read by for loop************")


    for (elem <- OrderItemsRDD.collect()) {
      println(elem)

    }


    println("******orderItemsRDD read by function************")


    val OrderRDDMap = OrderRDD.map(p => (p.split(",")(0), (p.split(",")(3))))

    val OrderItemsRDDMap = OrderItemsRDD.map(p => (p.split(",")(0), (p.split(",")(1), p.split(",")(2))))


    for (elem <- OrderRDDMap.collect()) {
      println(elem)

    }

    println("******orderRDDMap read by for loop ************")


    for (elem <- OrderItemsRDDMap.collect()) {
      println(elem)

    }

    println("******orderItemsRDDMap read by for loop ************")

    val joinRDD = OrderRDDMap.join(OrderItemsRDDMap).sortByKey(true)


    for (elem <- joinRDD.collect()) {
      println(elem)
    }
    println("joinRDD by sorted order")
    println("************************************************************")


    val filterjoin = joinRDD.map(e => (e._1, e._2._1, e._2._2._1, e._2._2._2))

  //  filterjoin.saveAsTextFile("/home/pankaj.singh/Downloads/Sample_Data/Result")

    for (elem <- filterjoin.collect()) {
      println(elem)
    }
    print("*****FilterJoin read*********")



    println("Job Run successfully")





    /** If else in RDD and filter in RDD */
       val orderfilter = OrderRDD.map(x => if (x.split(",")(3) == "CLOSED") "NULL" else "Open not closed")

       for(elem <- orderfilter.collect()){
       println(elem)
       }

       val orderf = OrderRDD.filter(p => List("CLOSED","OPEN").contains(p.split(",")(3)))
       for(elem <- orderf.collect()){
       println("CLOSED status")
       println(elem)
       }
*/

  }


  def my_method1(Element_Name:String*): Unit ={


    var e = Element_Name.size
    println("size is "+e)
    Element_Name.foreach(println)

    println(Element_Name(1))
    println(Element_Name(0))


    for(x<- 0 to (Element_Name.size-1)){

      println(Element_Name(x))

    }

println("ssd")

    for(x<- 1 to 4) {
      println(x)
    }
  }


  def myrddfunction(rdd :RDD[String],mystr:String):Boolean ={

    val rdd2 = rdd.filter( r => r.split(",")(0).equals("P1")).map( r=> r.split(",")(0))//.take(1))

    //val rdd2 = new

     rdd2.foreach(println)
    println("#$#$#")
    var flag= false

    for(x<- rdd2.collect()){
        println("xxx"+x)
      if(x.contains("P1"))
        flag = true
      else flag= false
    }

    return flag
      //rdd.filter(r => r.split(",").equals(mystr)))

  //  return true

   // else false



  }

  def myrddfunction_1(rdd :Array[String],mystr:Row):Boolean ={

   // val rdd2 = rdd.filter( r => r.split(",")(0).equals("P1")).map( r=> r.split(",")(0)).take(1)

   // val rdd2 = rdd.filter( r => r._1)

println( "reo elemet "+mystr.getString(0)+" ! "+mystr.getString(0)(0-1))
    var flag= false

    for(x<- rdd){
      println("xxx"+x)
      if(//x.equals("P1") &&
        mystr.getString(0)=="P1")
        flag = true
      else flag= false
    }

    return flag
    //rdd.filter(r => r.split(",").equals(mystr)))

    //  return true

    // else false



  }

}
