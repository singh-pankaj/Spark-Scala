package com.figmd

object Varible_Length_Arg {

  def main(args: Array[String]): Unit = {

    var s = List("Pankaj", "Singh")

    s.foreach(println(_))

    println("****************************")

    echo("Pankaj", "sdd", "dsd")

  }

  def echo(s: String*): Unit = {

    s.foreach(println(_))
  }


}
