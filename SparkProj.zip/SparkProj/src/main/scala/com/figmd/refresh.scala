package com.figmd

trait refresh {

  def writee(x:String)
}
