package com.figmd

import org.apache.log4j.{Level, Logger}

import scala.collection.mutable

object Customer {
  import java.util.logging.{Level, Logger}

  import org.apache.spark.sql.SparkSession
  import scala.collection.mutable.ListBuffer

  Logger.getLogger("org").setLevel(Level.OFF) //all, debug, error, fatal, info, off, trace, trace_int, warn
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("myLogger").setLevel(Level.OFF)

  val spark = SparkSession.builder().appName("Dataframe Practice").master("local[*]").getOrCreate()


    def main(args: Array[String]): Unit = {


    //  val RawRDD = spark.read.text("C:\\Users\\Pankaj Singh\\Desktop\\test1.txt").rdd

      val RawRDD =  spark.read.textFile("/home/pankaj.singh/Downloads/test1.txt").rdd

        .map(x => x.toString.replace("[","")).map(y => y.replace("]",""))

      //  RawRDD.collect().foreach(println)

      //  RawRDD.map(z => z.toString().split(",")(0)).collect.foreach(println)




      val cust = Array("V","C")

      val webmap : Map[String,String]= Map()



      val webRDD= RawRDD.filter(z => z.split(",")(0).equalsIgnoreCase("A") && !z.isEmpty)
        .map( a => (a.split(",")(1).toInt,a.split(",")(3),a.split(",")(4)))



    /*  webmap += ("1038"->"abd")
      println("***** "+webmap.get("1038"))
*/
      val  customerRDD = RawRDD.filter(z => cust.contains(z.split(",")(0)))

      RawRDD.take(30).foreach(println)
      webRDD.collect.take(5).foreach(println)
      customerRDD.collect.take(5).foreach(println)




      val xc= customerRDD.collect.toList

      var customerList = new ListBuffer[(String, String)]()

      var customerid: String = null

      for(List(x,y) <- xc.sliding(2)){

        if(!y.toString.split(",")(0).equals("C")) {

          if (x.toString.split(",")(0).equals("C")) {
            customerid = x.toString.split(",")(2)
          }

          if (x.toString.split(",")(0).equals("C") || y.toString.split(",")(0).equals("V") || x.toString.split(",")(0).equals("V")) {
            customerList.append((customerid, y.toString.split(",")(1)))
          }
          if (y.toString.split(",")(0).equals("C")) {
            customerid = null
          }

        }

      }

      customerList.toList.foreach(println)


    }

}
