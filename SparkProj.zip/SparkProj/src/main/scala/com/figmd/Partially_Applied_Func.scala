package com.figmd

object Partially_Applied_Func {

  def main(args: Array[String]): Unit = {


    def div(x:Double, y:Double):Double  = x/y
    //div: (x: Double, y: Double)Double

    div(1, _:Double)
    //res2: Double => Double = <function1>

    div(2,_:Double)

    val inverse = div(1, _:Int)
    val inverse2 = div(2,_:Int)

    println(inverse(10))
    println(inverse2(10))



    def sumofx(f: Int => Int , a:Int, b:Int): Int = {
      if (a > b) 0 else f(a) + sumofx(f, a + 3, b)
    }


    val sumx =sumofx(x=>x, _:Int,_:Int)
    val multix = sumofx(x=>x*x, _:Int,_:Int)
    val cubex =sumofx(x=>x*x*x, _:Int,_:Int)

    def sumapply(f: (Int,Int) => Int) ={
      f(1,5)
    }


    println(sumx(1,5))
    println(cubex(1,4))


    /** Currying Function **/


      }

}
