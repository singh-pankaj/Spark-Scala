package com.figmd

import java.util.Properties

//import com.figmd.File_Utility

object Properties_Test {

  val prop = new Properties
  def main(args: Array[String]): Unit = {


    val xc =123

  //  println(xc.padTo(10,"0"))

    // f"${num}%02d

    val sd= f"${xc}%10d"

    println("as "+sd)


    val xd ="123"


    val s = new File_Utility() //.getproperty("name")

    println("value of s "+s.getproperty("name"))

    prop.setProperty("name","Gopalji")

    println("value of namr "+ prop.getProperty("name"))

    prop.setProperty("name","Saha")

    println("value of reset "+ prop.getProperty("name"))


  }





}
