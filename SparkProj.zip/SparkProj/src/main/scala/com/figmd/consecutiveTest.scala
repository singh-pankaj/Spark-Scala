package com.figmd

import java.text.{DateFormat, SimpleDateFormat}
import java.util.Date

import com.datastax.spark.connector.CassandraRow
import org.apache.log4j.{Level, Logger}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.joda.time._

import scala.collection.mutable.ListBuffer

object consecutiveTest {

  Logger.getLogger("org").setLevel(Level.OFF) //all, debug, error, fatal, info, off, trace, trace_int, warn
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("myLogger").setLevel(Level.OFF)

  val spark = SparkSession.builder()
    .master("local[*]")
    .appName("Message log check ")
    .getOrCreate()


  def main(args: Array[String]): Unit = {
    val startdate: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("element_date" -> "2019-01-01 00:00:00.000+00:00"))))

   /* val op = getdate(startdate.map(x => x.getDateTime("element_date")).collect.head.toString)
    println(op)
*/
    val ensdate: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("element_date" -> "2019-12-31 00:00:00.000+00:00"))))

    val HistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "289F0BFD-C26D-46F1-9AA6-AE70FEC341A5", "element" -> "ult", "element_date" -> "2007-08-23 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "289F0BFD-C26D-46F1-9AA6-AE70FEC341A5", "element" -> "ult", "element_date" -> "2007-08-23 12:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "289F0BFD-C26D-46F1-9AA6-AE70FEC341A5", "element" -> "ult", "element_date" -> "2007-10-25 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "289F0BFD-C26D-46F1-9AA6-AE70FEC341A5", "element" -> "ult", "element_date" -> "2007-10-25 12:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "289F0BFD-C26D-46F1-9AA6-AE70FEC341A5", "element" -> "ult", "element_date" -> "2007-12-28 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "289F0BFD-C26D-46F1-9AA6-AE70FEC341A5", "element" -> "ult", "element_date" -> "2007-12-28 12:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "289F0BFD-C26D-46F1-9AA6-AE70FEC341A5", "element" -> "ult", "element_date" -> "2008-08-06 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "289F0BFD-C26D-46F1-9AA6-AE70FEC341A5", "element" -> "ult", "element_date" -> "2008-08-06 12:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "289F0BFD-C26D-46F1-9AA6-AE70FEC341A5", "element" -> "ult", "element_date" -> "2009-09-25 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "289F0BFD-C26D-46F1-9AA6-AE70FEC341A5", "element" -> "ult", "element_date" -> "2009-09-25 12:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "289F0BFD-C26D-46F1-9AA6-AE70FEC341A5", "element" -> "ult", "element_date" -> "2010-04-30 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "289F0BFD-C26D-46F1-9AA6-AE70FEC341A5", "element" -> "ult", "element_date" -> "2010-04-30 12:00:00.000+00:00", "elementvalue" -> "5"))
    ))

    HistoryRDD.collect.foreach(println)

val startdt = startdate.map(x => x.getDateTime("element_date")).collect.head
val ensdt = ensdate.map(x => x.getDateTime("element_date")).collect.head



val m= MeasureProperty("ss","s", startdt,ensdt)

    println(m.quarterStartDate+" "+m.quarterEndDate)
    val MedicationList:List[(String,String)] = List(("ult","ult_stop"))
    val MedicationResult=consecutiveBeforeStart(HistoryRDD, m ,MedicationList,CalenderUnit.DAY,CalenderUnit.DAY,90)

    MedicationResult.foreach(println)


    val visit = CassandraRow.fromMap(Map("patientuid" -> "289F0BFD-C26D-46F1-9AA6-AE70FEC341A5" ))

    val MedicationResultBroadcastList = spark.sparkContext.broadcast(MedicationResult)

   val conresult =  getConsecutiveResult(visit, m, "ult",365,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)


    println("My result "+conresult)

  }
  case class MeasureProperty(MeasureName: String, ConditionType: String,quarterStartDate:DateTime,quarterEndDate:DateTime){

  }

  object CompareOperator extends Enumeration{
    type CompareOperator = Value
    val GREATER =Value("gt")
    val LESS=Value("lt")
    val GREATER_EQUAL=Value("ge")
    val LESS_EQUAL=Value("le")
    val EQUAL=Value("eq")
    val GREATER_EQUAL_And_LESS_EQUAL=Value("ge&le")
    val GREATER_EQUAL_And_LESS=Value("ge&lt")
    val GREATER_And_LESS_EQUAL=Value("gt&le")
    val GREATER_And_LESS=Value("gt&lt")
    val LESS_WITH_NO_BOUNDARY=Value("lt")
    val LESS_EQUAL_WITH_NO_BOUNDARY=Value("le")
  }

  def getConsecutiveResult(visit: CassandraRow, m: MeasureProperty, medicationElement: String, result: Double, resultFlag: CompareOperator.Value, CommulativeList: Broadcast[List[(String, String, Double)]]): Boolean = {

    CommulativeList.value.exists(x => x._1.equals(visit.getString("patientuid")) && x._2.equals(medicationElement) && compareValueStatus(x._3, resultFlag, result))

  }

  def compareValueStatus(elementValue: Double, flag: CompareOperator.Value, compareValue: Double): Boolean = {
    //var elementValue = visit.getDouble("elementvalue")
    var status: Boolean = flag match {
      case CompareOperator.GREATER_EQUAL => elementValue >= compareValue
      case CompareOperator.GREATER => elementValue > compareValue
      case CompareOperator.LESS => elementValue < compareValue
      case CompareOperator.LESS_EQUAL => elementValue <= compareValue
      case CompareOperator.EQUAL => elementValue == compareValue
    }
    status
  }

  def lowerCalenderDate(elementDate: DateTime, unit: CalenderUnit.Value, interval: Int): DateTime = {
    //val elementdate= if (elementDate.equalsIgnoreCase("encounterdate")) "encounterdate" else elementDate
    val lowerDate: DateTime = unit match {
      case CalenderUnit.MINUTE => elementDate.minusMinutes(interval)
      case CalenderUnit.HOUR => elementDate.minusHours(interval)
      case CalenderUnit.DAY => elementDate.minusDays(interval)
      case CalenderUnit.WEEK => elementDate.minusWeeks(interval)
      case CalenderUnit.MONTH => elementDate.minusMonths(interval)
      case CalenderUnit.YEAR => elementDate.minusYears(interval)

    }

    lowerDate
  }

  def higherCalenderDate(elementDate: DateTime, unit: CalenderUnit.Value, interval: Int): DateTime = {

    //val elementdate= if (elementDate.equalsIgnoreCase("encounterdate")) "encounterdate" else elementDate
    val higherDate: DateTime = unit match {
      case CalenderUnit.MINUTE => elementDate.plusMinutes(interval)
      case CalenderUnit.HOUR => elementDate.plusHours(interval)
      case CalenderUnit.DAY => elementDate.plusDays(interval)
      case CalenderUnit.WEEK => elementDate.plusWeeks(interval)
      case CalenderUnit.MONTH => elementDate.plusMonths(interval)
      case CalenderUnit.YEAR => elementDate.plusYears(interval)
    }

    higherDate
  }

  object CalenderUnit  extends Enumeration{
    type CalenderUnit = Value
    val MINUTE =Value("MINUTE")
    val HOUR=Value("HOUR")
    val DAY=Value("DAY")
    val WEEK=Value("WEEK")
    val MONTH=Value("MONTH")
    val YEAR=Value("YEAR")

  }
  def consecutiveBeforeStart(patientHistoryRDD: RDD[CassandraRow], m: MeasureProperty, MedicationList: List[(String, String)], MedicationDuration: CalenderUnit.Value, gapUnit: CalenderUnit.Value, gap: Int): List[(String, String, Double)] = {
    consecutive(patientHistoryRDD: RDD[CassandraRow], m: MeasureProperty, MedicationList: List[(String, String)], MedicationDuration: CalenderUnit.Value, CalenderUnit.DAY, 0, gapUnit: CalenderUnit.Value, gap: Int, TimeOperator.BEFORE_START_OF_MEASUREMENT_PERIOD): List[(String, String, Double)]
  }
  object TimeOperator{

    val AFTER ="AFTER"
    val AFTERorEQUAL="AFTERorEQUAL"
    val BEFORE="BEFORE"
    val BEFOREorEQUAL="BEFOREorEQUAL"
    val EQUAL="EQUAL"
    val DURING= "DURING"
    val START_OF_MEASUREMENT_PERIOD="START_OF_MEASUREMENT_PERIOD"
    val END_OF_MEASUREMENT_PERIOD="END_OF_MEASUREMENT_PERIOD"
    val BEFORE_START_OF_MEASUREMENT_PERIOD="BEFORE_START_OF_MEASUREMENT_PERIOD"

  }

  def isDateBetween(comparisonDate: DateTime, lowerDate: DateTime, higherDate: DateTime): Boolean = {

    (comparisonDate.isAfter(lowerDate) && comparisonDate.isBefore(higherDate)) || isDateEqual(comparisonDate,lowerDate) /*comparisonDate.isEqual(lowerDate)*/ || isDateEqual(comparisonDate,higherDate) /*comparisonDate.isEqual(higherDate)*/
  }
  def isDateEqual(firstDate: DateTime, compareDate: DateTime): Boolean = {
    firstDate.getYear == compareDate.getYear && firstDate.getMonthOfYear == compareDate.getMonthOfYear && firstDate.getDayOfMonth == compareDate.getDayOfMonth
  }
  def consecutive(patientHistoryRDD: RDD[CassandraRow], m: MeasureProperty, MedicationList: List[(String, String)], MedicationDuration: CalenderUnit.Value, CalendarUnit: CalenderUnit.Value, interval: Int, gapUnit: CalenderUnit.Value, gap: Int, timeOperator: String): List[(String, String, Double)] = {

    var FinalEndDate: DateTime = null

    def filterDate(visit: CassandraRow, elementDate: String, timeOperator: String): Boolean = {
      var time = false
      if (timeOperator.equalsIgnoreCase(TimeOperator.BEFORE)) {
        time = isDateBetween(visit.getDateTime(elementDate), lowerCalenderDate(m.quarterStartDate, CalendarUnit, interval), m.quarterStartDate)
      }
      if (timeOperator.equalsIgnoreCase(TimeOperator.AFTER)) {
        time = isDateBetween(visit.getDateTime(elementDate), m.quarterStartDate, higherCalenderDate(m.quarterStartDate, CalendarUnit, interval))
      }
      if (timeOperator.equalsIgnoreCase(TimeOperator.DURING)) {
        time = isDateBetween(visit.getDateTime(elementDate), m.quarterStartDate, m.quarterEndDate)
      }
      if (timeOperator.equalsIgnoreCase(TimeOperator.BEFORE_START_OF_MEASUREMENT_PERIOD)) {
        time = visit.getDateTime(elementDate).isBefore(m.quarterStartDate)
      }

      time
    }

    if (timeOperator.equalsIgnoreCase(TimeOperator.BEFORE)) {
      FinalEndDate = m.quarterStartDate
    }
    if (timeOperator.equalsIgnoreCase(TimeOperator.AFTER)) {
      FinalEndDate = higherCalenderDate(m.quarterStartDate, CalendarUnit, interval)
    }
    if (timeOperator.equalsIgnoreCase(TimeOperator.DURING)) {
      FinalEndDate = m.quarterEndDate
    }
    if (timeOperator.equalsIgnoreCase(TimeOperator.BEFORE_START_OF_MEASUREMENT_PERIOD)) {
      FinalEndDate = m.quarterStartDate.minusDays(1)
    }


    var consecutiveList = new ListBuffer[(String, (DateTime, DateTime))]()
    var con = new ListBuffer[List[(String, String, Double)]]()
    var finallist = new ListBuffer[(String, String, Double)]()

    MedicationList.foreach(m => {
      var MedicationStartName = m._1
      var MedicationEndName = m._2


      val xc = patientHistoryRDD.filter(x => x.getString(1).equals(MedicationStartName) || x.getString(1).equals(MedicationEndName))
        .filter(a => filterDate(a, "element_date", timeOperator))
        .map(r => (r.getString("patientuid"), (r.getString(1), r.getDate(2).getTime))).groupByKey()
        .map(x => (x._1, x._2.toArray.sortBy(r => r._2))).collect()




/*      patientHistoryRDD.filter(x => x.getString(1).equals(MedicationStartName) || x.getString(1).equals(MedicationEndName))
        .filter(a => filterDate(a, "element_date", timeOperator))
        .map(r => (r.getString("patientuid"), (r.getString(1), r.getDate(2).))).collect.foreach(println)*/

      xc.foreach(r => {
        var startdate: DateTime = null
        var startdate2: DateTime = null
        var enddate: DateTime = null

        var last = r._2.toList.tail
        var lastelementType: String = null
        var lastelementdate: DateTime = null
        r._2.toList.reverse.take(1).foreach(r => {
          lastelementType = r._1
          lastelementdate = new DateTime(r._2)
        })

        r._2.foreach(x => {

          if (x._1.contains(MedicationStartName) && startdate == null) {
            startdate = new DateTime(x._2)
          }

          else if (x._1.contains(MedicationStartName) && startdate != null && startdate2 == null) {
            enddate = new DateTime(x._2)
            consecutiveList.append((r._1, (startdate, enddate)))
            startdate = new DateTime(x._2)
            startdate2 = null
            enddate = null
          }

          else if (x._1.contains(MedicationEndName) && enddate == null) {
            enddate = new DateTime(x._2)
            consecutiveList.append((r._1, (startdate, enddate)))
            startdate = null
            enddate = null

          }

          if (x._1.equals(lastelementType) && lastelementType.equals(MedicationStartName) && lastelementdate.equals(new DateTime(x._2))) {
            startdate = new DateTime(x._2)
            consecutiveList.append((r._1, (startdate, FinalEndDate)))
          }

        })
      })

      con.append(getgap(consecutiveList, gapUnit, gap, MedicationDuration, MedicationStartName))
    }
    )

    con.toList.foreach(x => x.foreach(r => finallist.append((r._1, r._2, r._3))))

    finallist.toList

  }


  def getgap(gapList: ListBuffer[(String, (DateTime, DateTime))], gapUnit: CalenderUnit.Value, gap: Int, elementUnit: CalenderUnit.Value, elementStart: String): List[(String, String, Double)] = {


    gapList.toList.foreach(println)
    var cummulativeList = new ListBuffer[(String, (DateTime, DateTime))]()

    val xc = gapList.toList.groupBy(_._1).map(r => (r._1, r._2))

    xc.foreach(z => {
      val xs = z._2.toList
      val length = z._2.toList.length
      var last = z._2.toList.tail
      var lastelement2: DateTime = null
      z._2.toList.reverse.take(1).foreach(r => {
        lastelement2 = new DateTime(r._2._2)
      })

      val indexed = xs.zipWithIndex

      var startdate: DateTime = null
      var enddate: DateTime = null
      var count: Int = 0

      z._2.toList.take(1).foreach(r => {
        startdate = new DateTime(r._2._1)
        enddate = new DateTime(r._2._2)
        count = 1
      }
      )

      for (xa <- indexed) {

        if (length == 1) {
          cummulativeList.append((z._1, (new DateTime(startdate), new DateTime(enddate))))
        }
        if (length > 1) {
          if (count != 1) {

            if (getDatesDifferenceInXUnit(enddate, new DateTime(xa._1._2._1), gapUnit) > gap) {
              cummulativeList.append((z._1, (new DateTime(startdate), new DateTime(enddate))))
              startdate = new DateTime(xa._1._2._1)
              enddate = new DateTime(xa._1._2._2)
            }

            if (getDatesDifferenceInXUnit(enddate, new DateTime(xa._1._2._1), gapUnit) < (gap + 1)) {
              enddate = new DateTime(xa._1._2._2)
            }

            if (getDatesDifferenceInXUnit(enddate, new DateTime(xa._1._2._1), gapUnit) < (gap + 1) && enddate.equals(lastelement2)) {
              cummulativeList.append((z._1, (new DateTime(startdate), new DateTime(enddate))))
            }
          }
          count = count + 1
        }
      }
    })

    cummulativeList.toList.map(r => (r._1, elementStart, r._2._1, r._2._2, elementUnit)).foreach(println)
    cummulativeList.toList.map(r => (r._1, elementStart, getDatesDifferenceInXUnit(r._2._1, r._2._2, elementUnit)))

  }

  def getDatesDifferenceInXUnit(lowerElementDate: DateTime, higherElementDate: DateTime, unit: CalenderUnit.Value): Double = {

    val lowerDate: Double = unit match {
      case CalenderUnit.MINUTE => Minutes.minutesBetween(lowerElementDate, higherElementDate).getMinutes
      case CalenderUnit.HOUR => Hours.hoursBetween(lowerElementDate, higherElementDate).getHours
      case CalenderUnit.DAY => Days.daysBetween(lowerElementDate, higherElementDate).getDays
      case CalenderUnit.WEEK => Weeks.weeksBetween(lowerElementDate, higherElementDate).getWeeks
      case CalenderUnit.MONTH => Months.monthsBetween(lowerElementDate, higherElementDate).getMonths
      case CalenderUnit.YEAR => Years.yearsBetween(lowerElementDate, higherElementDate).getYears

    }

    lowerDate

  }


    def getdate(input: String):Date = {
      print(input)
    //  val input = "2012/01/20 12:05:10.321" //2008-08-06 12:00:00.000  yyyy/MM/dd HH:mm:ss.SSS
      val inputFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      val date = inputFormatter.parse(input)
      /*val outputFormatter = new SimpleDateFormat("MM/dd/yyyy")
      val output = outputFormatter.format(date) // Output : 01/20/2012
      */
      date
    }
}
