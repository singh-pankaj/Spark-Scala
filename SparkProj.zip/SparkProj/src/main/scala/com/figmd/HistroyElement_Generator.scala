package com.figmd


import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession


object HistroyElement_Generator {


  Logger.getLogger("org").setLevel(Level.OFF) //all, debug, error, fatal, info, off, trace, trace_int, warn
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("myLogger").setLevel(Level.OFF)

  val spark = SparkSession.builder().appName("Dataframe Practice").master("local[*]").getOrCreate()

  def main(args: Array[String]): Unit = {

    val MeasureRDD = spark.read.textFile("/home/pankaj.singh/Downloads/NewHistoryElements_new.txt").rdd

    val strata = Array("V","_")

   // val strata_measure = MeasureRDD.filter(r => strata.exists( z => r.split("=")(0).contains(z)))

    val strata_measure = MeasureRDD.map(x => if (x.contains("V") && x.split("=").length == 2) (x.split("=")(0).split("V")(0), x.split("=")(1))
    else if (x.split("=").length == 2) {
      (x.split("=")(0).split("_")(0), x.split("=")(1))
    } else {
      (x.split("=")(0).split("_")(0), "NA")
    }).filter(z => !z._2.equals("NA")).reduceByKey((a, b) => a + b).map(x => x._1 + "=" + x._2.substring(0, x._2.length - 1))


    println(strata_measure.count())
    strata_measure.collect.foreach(println)
    strata_measure.saveAsTextFile("home/pankaj.singh/AllMeasure_HistoryElement_new")

  }

}
