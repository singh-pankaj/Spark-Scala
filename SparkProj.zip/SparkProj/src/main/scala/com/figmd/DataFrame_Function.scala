package com.figmd


import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.{Column, SparkSession}
import org.joda.time.DateTime

object DataFrame_Function {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)

  val spark = SparkSession.builder().master("local[*]").appName("DataFrame Function").getOrCreate()

  def main(args: Array[String]): Unit = {
    import spark.implicits._

    val patientHistory = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load("/home/pankaj.singh/Downloads/Data Sample/patienthistory.csv")

    patientHistory.show()

// To get column name and dataType
    patientHistory.dtypes.foreach(println)
  
/*
    case class history(patientuid: String, element: String, element_date: String)

    val patientDataset = patientHistory.as[history].groupBy($"patientuid")
    patientDataset.count().show()*/


    val myudf = udf { myString: String =>
      myString.substring(1, myString.length).toInt + 1
    }

    val upper = udf { myString: String =>
      myString.toUpperCase
    }


    import spark.implicits._

    val patientDF = patientHistory.withColumn("added", ($"element_date")).withColumn("num", myudf($"patientuid")).withColumn("upper", upper($"patientuid"))
    patientDF.show()
    patientDF.groupBy($"patientuid").min("num").show()

    val w = Window.partitionBy($"patientuid")



   /* case class historyRecord(patientuid:String,element:String,element_date:String,elementvalue:String,added:String,num:String,upper:String)

    val topdf = patientDF.as[historyRecord]*/

  }


}
