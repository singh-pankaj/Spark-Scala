package com.figmd

import java.util.Properties

import scala.io.Source

object File_Utility {


  def main(args: Array[String]): Unit = {

  val x = getproperty("name")

    println("value of x "+x)

    println(getproperty())

  }




  def getproperty(property : String): String ={
    var properties : Properties = null


    val url = getClass.getResource("application.properties")

    var source = Source.fromURL(url)

    properties = new Properties()

    properties.load(source.bufferedReader())

 //   println(properties.getProperty("name"))
 //   println(properties.getProperty("surname"))

    return  properties.getProperty(property)
  }


  def getproperty() :Properties = {

    var properties : Properties = null

    val url = getClass.getResource("application.properties")

    var source = Source.fromURL(url)

    properties = new Properties()

   properties.load(source.bufferedReader())

    return properties

    //   println(properties.getProperty("name"))
    //   println(properties.getProperty("surname"))

  }


}
