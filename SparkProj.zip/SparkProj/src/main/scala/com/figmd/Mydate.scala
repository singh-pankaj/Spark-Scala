package com.figmd

import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.time._
import java.util.{Calendar, Date, GregorianCalendar}
import java.util.concurrent.TimeUnit


object Mydate {

  @transient lazy val DATE_TIME_FORMAT_EEE = DateTimeFormatter.ofPattern("yyyy-MM-dd")
  @transient lazy val DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy")
  def main(args: Array[String]): Unit = {

    var dateFormat = "yyyy-MM-dd"

    // 2006-04-06 00:30:00.000000+0000
    //  yyyy-MM-dd


    /*  var noofyear =18

    val dob = "1993/05/25"
    val encounter = "2018/05/25"
   // val endDate_1:Date = new SimpleDateFormat("dd/MM/yyyy").parse(dob)
    var dt: Date = new SimpleDateFormat("dd/MM/yyyy").parse(dob)

    var dtx  = new SimpleDateFormat("dd/MM/yyyy")

   val cv= Integer.parseInt(dtx.formatted(encounter))

    var dtx2  = new SimpleDateFormat("dd/MM/yyyy")

    val cv2= Integer.parseInt(dtx2.formatted("encounter"))

    println("cv and cv1 "+ cv +" "+cv2)

    println("differenec age "+(cv2-cv)/10000)
*/


    /*var c_1 = Calendar.getInstance
    c_1.setTime(dt)
    c_1.add(Calendar.YEAR, -noofyear)

    println(c_1)*/


    // Sun Oct 22 00:30:00 UTC 2017

    //  var x = Date

    var dt: Date = new SimpleDateFormat("dd/MM/yyyy").parse("10/01/2000")
    var dt1: Date = new SimpleDateFormat("dd/MM/yyyy").parse("10/03/2019")


    val yesrdiff = getYearDifference(dt, dt1)
    println("years dff " + yesrdiff)


    val ageinmonth = isAgeGreaterOrEqualInMonths(dt, dt1)
    println("age in month" + ageinmonth)


  /*  val ageinmonthold = getMonthDiff(dt, dt1)
    println("age in month old " + ageinmonthold)



    agemonthlatest(dt, dt1)
*/
    /*
 var mdiff = getMonthDiff(dt,dt1)
println("mdiff is "+mdiff)


    var mdiffnew = getMonthDiffNew(dt,dt1,4)
    println("mdiff is "+mdiffnew)

*/

    var localedate = dt.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
    var localedate1 = dt1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()

    val localdiff = Period.between(localedate, localedate1).getYears
    println("*************")
    println("local diff -> " + localdiff)
    println("*************")


    import java.text.SimpleDateFormat


    import java.text.SimpleDateFormat
    import java.util.Calendar
    import java.util.Date
    import java.util.GregorianCalendar
    /*
    val sDate1 = " Wed Jan 03 00:30:00 UTC"
    val formatter1 = new SimpleDateFormat("dd/MM/yyyy")
    val Startdate = new SimpleDateFormat("dd/MM/yyyy").parse(sDate1)
    System.out.println(sDate1 + "\t" + Startdate)

    val sDate2 = " Wed Jan 03 00:30:00 UTC"
    var endDate_1 = new SimpleDateFormat("dd/MM/yyyy").parse(sDate2)
    println(sDate2+" "+endDate_1)

    val startCalendar = new GregorianCalendar
    startCalendar.setTime(Startdate)
    val endCalendar = new GregorianCalendar
    endCalendar.setTime(endDate_1)

    val diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR)
    val diffMonth = diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH)

    System.out.println("diffrence is " + diffMonth)
*/


    import java.util.Date
    /*
    val date1 = new SimpleDateFormat("yyyy-MM-dd").parse("2006-04-06 00:30:00.000000+0000")
println("date 1 is "+date1)

    val dateXX = new SimpleDateFormat("DDMMYY").parse("2006-04-06 00:30:00.000000+0000")
    println("date xx "+ dateXX)
    val startDate="2006-04-08"
*/
    // val endDate="2006-04-06 00:30:00.000000+0000"


    /*


    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    val s1 = SIMPLE_DATE_FORMAT.parse(startDate);
   // val s2 = SIMPLE_DATE_FORMAT.parse(endDate)
    println(s1)
    println(date1)

    import java.util.concurrent.TimeUnit
    val diffInMillies = Math.abs(s1.getTime - date1.getTime)
    val c= TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS)
    println(c)


    var endDate = "2006-04-06 00:30:00.000000+0000"

    var eDate = convertDateToDDMMYYYY(endDate)

println(eDate)
  }

  def convertDateToDDMMYYYY(dateString:String): String ={
    //println("::::::::::::::::::::::::::::::::"+dateString)
    return LocalDateTime.parse(dateString, DATE_TIME_FORMAT_EEE).format(DATE_FORMAT)
  }

*/

  }

 def getMonthDiff(startDate:String,endDate:String):Int={
   import java.text.SimpleDateFormat
   import java.util.Calendar
   import java.util.Date
   import java.util.GregorianCalendar
  // val startDate = "01/03/2018"
  // val formatter1 = new SimpleDateFormat("dd/MM/yyyy")
   val Startdate = new SimpleDateFormat("dd-M-yyyy hh:mm:ss").parse(startDate)
   System.out.println(startDate + " " + Startdate)

 //  val endDate = "01/11/2017"
   var endDate_1 = new SimpleDateFormat("dd-M-yyyy hh:mm:ss").parse(endDate)
   println(endDate+" "+endDate_1)

   val startCalendar = new GregorianCalendar
   startCalendar.setTime(Startdate)
   val endCalendar = new GregorianCalendar
   endCalendar.setTime(endDate_1)

   val diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR)
   val diffMonth = diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH)

   println("diffrence is " + diffMonth)
   return diffMonth




 }
  def getMonthDiff(startDate:Date,endDate:Date):Int={
    import java.text.SimpleDateFormat
    import java.util.Calendar
    import java.util.Date
    import java.util.GregorianCalendar
    // val startDate = "01/03/2018"
    // val formatter1 = new SimpleDateFormat("dd/MM/yyyy")
    //   val Startdate = new SimpleDateFormat("dateFormat").parse(startDate)
    //  System.out.println(startDate + "\t" + Startdate)

    //  val endDate = "01/11/2017"
    //   var endDate_1 = new SimpleDateFormat("dateFormat").parse(endDate)
    //  println(endDate+" "+endDate_1)

    val startCalendar = new GregorianCalendar
    startCalendar.setTime(startDate)
    val endCalendar = new GregorianCalendar
    endCalendar.setTime(endDate)

    val diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR)
    val diffMonth = diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH)

    println("diffrence is " + diffMonth)
    return Math.abs(diffMonth)




  }

  def getMonthDiffNew(startDate:Date,endDate:Date):Int={
    import java.text.SimpleDateFormat
    import java.util.Calendar
    import java.util.Date
    import java.util.GregorianCalendar
    // val startDate = "01/03/2018"
    // val formatter1 = new SimpleDateFormat("dd/MM/yyyy")
    //   val Startdate = new SimpleDateFormat("dateFormat").parse(startDate)
    //  System.out.println(startDate + "\t" + Startdate)

    //  val endDate = "01/11/2017"
    //   var endDate_1 = new SimpleDateFormat("dateFormat").parse(endDate)
    //  println(endDate+" "+endDate_1)

    val startCalendar = new GregorianCalendar
    startCalendar.setTime(startDate)
    val endCalendar = new GregorianCalendar
    endCalendar.setTime(endDate)

    val diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR)
    val diffMonth = diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH)

    println("diffrence is " + diffMonth)
    return Math.abs(diffMonth)




  }


  //Pankaj
  def IsAgeGreaterThanOrEqual(startDate:Date,endDate:Date,AgeCount:Int):Boolean={


    var localedate = startDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
    var localedate1 = endDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()

    val AgeInYears  = Period.between(localedate,localedate1).getYears

   /* println("*************")
    println("local diff -> "+ localdiff)
    println("*************")
*/
    if (AgeCount >= AgeInYears) return true else return false

  }


  //Pankaj
  def isAgeGreaterOrEqualInMonths(startDate:Date,endDate:Date):Int={
    var localedate = startDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
    var localedate1 = endDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()

    val AgeInYears  = Period.between(localedate,localedate1).getYears
    val AgeInMonth  = Period.between(localedate,localedate1).getMonths

    val ageinmon = AgeInYears*12 + AgeInMonth

    println("########################")
    println("age in years+age in monts "+AgeInYears+" "+AgeInMonth)
    println("age in months "+ageinmon)
    println("########################")

    return ageinmon

  }

  def agemonthlatest(startDate:Date,endDate:Date): Unit ={

    var endDate_1 = new GregorianCalendar()
    endDate_1.setTime(endDate)

    var startDate_1 = new GregorianCalendar();

    startDate_1.setTime(startDate)

    var yearsInBetween = startDate_1.get(Calendar.YEAR) - endDate_1.get(Calendar.YEAR)

    var monthsDiff = startDate_1.get(Calendar.MONTH) - endDate_1.get(Calendar.MONTH)

    var ageInMonths =  monthsDiff

    var age = yearsInBetween

    System.out.println("Number of months since James gosling born : " + ageInMonths)

    System.out.println("Sir James Gosling's age : " + age)


  }

/**
  def ElementInBackRange(r: CassandraRow, conditionType: String, measureName: String, endDate: Date, ElementDate: String, NoOfMonths: Int): Boolean = {
    var dt: Date = endDate
    val c = Calendar.getInstance
    c.setTime(dt)
    c.add(Calendar.MONTH, -NoOfMonths)
    val PreviousDate = c.getTime
    val isExist = !r.isNullAt(ElementDate) && ((r.getDate(ElementDate).before(endDate) &&
      r.getDate(ElementDate).after(PreviousDate) || r.getDate(ElementDate).equals(endDate) || r.getDate(ElementDate).equals(PreviousDate)))
    val argsArray:Array[String]=Array(endDate.toString,PreviousDate.toString,NoOfMonths.toString)
    measureLoggerPatientHistory(r, measureName, conditionType, "ElementInBackRange", endDate.toString, isExist,argsArray)

    return isExist
  }

  **/

/*
  def getAgeInMonths(dob: String,arrival_date :String): Double ={
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    val s1 = SIMPLE_DATE_FORMAT.parse(dob);
    val s2 = SIMPLE_DATE_FORMAT.parse(arrival_date)
    import java.util.concurrent.TimeUnit
    val diffInMillies = Math.abs(s1.getTime - s2.getTime)
    return TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS)/30.4167

  }
*/

def getYearDifference(fromDate: Date, toDate: Date): Integer = {
  val firstDate = LocalDateTime.ofInstant(fromDate.toInstant, ZoneId.systemDefault)
  val secondDate = LocalDateTime.ofInstant(toDate.toInstant, ZoneId.systemDefault)
  val years = Math.abs(ChronoUnit.YEARS.between(firstDate, secondDate))
  years.toLong.toInt
}




}
