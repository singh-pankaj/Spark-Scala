package com.figmd

import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}
import org.apache.spark._
import scala.collection.JavaConverters._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.functions._


object runClass {
  val spark = SparkSession.builder()
    .master("local[*]")
    .appName("CacheProcedure")
    .getOrCreate()


  def main(args: Array[String]): Unit = {


    // Reading CSV with schema and header

    val file = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load("/home/pankaj.singh/Downloads/Sample.csv")

    file.show()

    /** *******************************************************************************************************/

    val file_1 = spark.read.format("csv").option("header", "false").option("inferSchema", "false").load("/home/pankaj.singh/Downloads/Sample_1.csv")

    file_1.show()

    file_1.printSchema()


    val columnsRenamed = Seq("Id", "Name", "age")

    val df = file_1.toDF(columnsRenamed: _*)

    df.show()

    /* import org.apache.spark.sql.functions._ to get col*/

    val lookup = Map("_c0" -> "Id", "_c1" -> "Name", "_c2" -> "Age")

    file_1.select(file_1.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*).show()

    println("**********column map via lookup*******************")


    /********* Operation On df **********/

    df.select(df("Name"), df("Id")).show()

    df.filter(df("Id") > 1).show()

    df.select(df("age")).groupBy("age").count().show()

    df.registerTempTable("people")

    val myresults = spark.sql("SELECT age from people")

    myresults.show()


    /********* Operation end on df ******/



    /** Creating Data Frame **/

    val data = Seq(
      Row(30, "happy"),
      Row(13, "sad"),
      Row(18, "glad")
    )

    val schema = StructType(
      List(
        StructField("age", IntegerType, true),
        StructField("mood", StringType, true)
      )
    )

    //val df =
    spark.createDataFrame(spark.sparkContext.parallelize(data), schema).show()


  }

}
