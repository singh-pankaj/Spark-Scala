package com.figmd

import java.util.Properties

import org.apache.log4j.{Level, Logger, PropertyConfigurator}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}
import org.apache.spark._

import scala.collection.JavaConverters._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.functions._


object Create_Data_Frame {

  Logger.getLogger("org").setLevel(Level.OFF) //all, debug, error, fatal, info, off, trace, trace_int, warn
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("myLogger").setLevel(Level.OFF)

  val spark = SparkSession.builder()
    .master("local[*]")
    .appName("CacheProcedure")
    .getOrCreate()


  def main(args: Array[String]): Unit = {

    val mylog = Logger.getLogger(this.getClass.getName)

    var propobj: Properties = new Properties()

    propobj.setProperty("log4j.reset","true")
    propobj.setProperty("log4j.rootLogger","WARN,file")
    propobj.setProperty("log4j.appender.file","org.apache.log4j.FileAppender")
    propobj.setProperty("log4j.appender.file.File","/home/pankaj.singh/mylogger.out")
    propobj.setProperty("log4j.appender.file.ImmediateFlush","true")
    propobj.setProperty("log4j.appender.file.Threshold","WARN")
    propobj.setProperty("log4j.appender.file.layout","org.apache.log4j.PatternLayout")
    propobj.setProperty("log4j.appender.file.layout.ConversionPattern","%m%n")
    propobj.setProperty("log4j.rootCategory", "ERROR, console")

    PropertyConfigurator.configure(propobj)

    mylog.warn("this is warn message-----")

    // Reading CSV with schema and header



    val file = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load("/home/pankaj.singh/Downloads/Sample.csv")

    file.columns.foreach(println)

    file.show()


    /** *******************************************************************************************************/
    mylog.warn("this is warn message-----")

    val file_1 = spark.read.format("csv").option("header", "false").option("inferSchema", "false").load("/home/pankaj.singh/Downloads/Data Sample/Sample_1.csv")

    file_1.show()

    file_1.printSchema()


    val columnsRenamed = Seq("Id", "Name", "age")

    val df = file_1.toDF(columnsRenamed: _*)

    df.show()

    /* import org.apache.spark.sql.functions._ to get col*/

    val lookup = Map("_c0" -> "Id", "_c1" -> "Name", "_c2" -> "Age")

    file_1.select(file_1.columns.map(c => col(c).as(lookup.getOrElse(c, c))): _*).show()

    println("**********column map via lookup*******************")


    /********* Operation On df **********/

    df.select(df("Name"), df("Id")).show()

    df.filter(df("Id") > 1).show()

    df.select(df("age")).groupBy("age").count().show()

    df.registerTempTable("people")

    val myresults = spark.sql("SELECT age from people")

    myresults.show()


    /********* Operation end on df ******/



    /** Creating Data Frame **/

    val data = Seq(
      Row(30, "happy"),
      Row(13, "sad"),
      Row(18, "glad"),
      Row(20, "sadsadsa")
    )

    val schema = StructType(
      List(
        StructField("age", IntegerType, true),
        StructField("mood", StringType, true)
      )
    )

    //val df =
    val mydf= spark.createDataFrame(spark.sparkContext.parallelize(data), schema)

   //  mydf.select("age","mood").withColumn("row",lpad(mydf.col("mood"),7,"0")).show()

    mydf.withColumn("row",concat_ws("|",lpad(mydf.col("mood"),7,"0"),lpad(mydf.col("age"),7,"0"))).withColumn("row2",lit(1)).show()

    mydf.withColumn("row2",concat_ws("|",lpad(mydf.col("age"),7,"0"),lpad(mydf.col("mood"),7,"0"))).show()

  }

}
