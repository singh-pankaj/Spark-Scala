package com.figmd

object myclass extends refresh {


  def writee(x:String):Unit={
  println("This is String "+x)
  }

  def writee():Unit={
    println("This is String")
  }

}
