package com.figmd

import java.io.File

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

object HistoryElement_Extract {

  Logger.getLogger("org").setLevel(Level.OFF) //all, debug, error, fatal, info, off, trace, trace_int, warn
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("myLogger").setLevel(Level.OFF)



  val spark = SparkSession.builder().appName("Dataframe Practice").master("local[*]").getOrCreate()

  def main(args: Array[String]): Unit = {

val files = getListOfFiles("/home/pankaj.singh/IdeaProjects/Top40_Cassandra/src/main/scala/com/figmd/janus/measureComputation/qpp")

 //   files.foreach(println)

  //  files.foreach(x => println(x.toString.substring(x.toString.lastIndexOf("/")+1,x.toString.length).replace(".scala","")))

    val MeasureRDD = spark.read.textFile("/home/pankaj.singh/IdeaProjects/Top40_Cassandra/src/main/scala/com/figmd/janus/measureComputation/qpp/Qpp111.scala").rdd




    var i =0

    def extractHistoryElement(line : String): Boolean={


     // val functionidentify = line.contains("getPatientHistory")

      if(i==0) {
        if (line.contains("getPatientHistory")){
          i=1
        }
      }

      if(i==1){

        while(line.contains(")")){
          println(line)
        }

      }

      true
    }

    MeasureRDD.map(r => extractHistoryElement(r)).collect()

  //  MeasureRDD.foreach(println)

  }

  def getListOfFiles(dir: String):List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
      d.listFiles.filter(_.isFile).toList
    } else {
      List[File]()
    }
  }



}
