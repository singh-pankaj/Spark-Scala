package Orilley.shape

object Separator {

  def joiner(string: List[String], sepa: String=" ") = {

    string.mkString(sepa)

  }

  def main(args: Array[String]): Unit = {

    val x = joiner(List("Pankaj", "Singh"),": ")

    println(x)

    val y = joiner(List("Pankaj", "Singh"))

    println(y)



  }

}
