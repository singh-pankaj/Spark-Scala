package Orilley.shape

object Nested_Func {


  def func1(x:Int)={


    println("func1")

    func2()

    def func2()={

      println("func2")

    }


  }

  def main(args: Array[String]): Unit = {

    func1(2)

  }

  }
