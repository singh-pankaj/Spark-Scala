package Orilley.shape

object Student {

  def displayResult(s:Student): Unit ={
    println("Student Details "+s.Id+" "+s.name)



  }

  def main(args: Array[String]): Unit = {

    val s = new Student(1,"Pankaj")
    displayResult(s)


    val s2 = new Student(1,"Pankaj")
    s2.display()

  }
}



class Student(Sid:Int,SName:String){

  val Id = Sid
  val name = SName

  def display(): Unit ={
    println("Student Details "+Id+" "+name)
  }

  override def toString() =
    this.Id+" "+" , "+this.name
}


class Student1(val m5:Int,val m2:Int) {
  var total:Int = m5 + m2
  var ma1:Int = m5
  var ma2:Int = m2
  def calculateTotal(ma1:Int,ma2:Int) {
    total = ma1 + ma2
    println("Total is :"+total)
  }
  override def toString(): String = "(" + total + ")";
}


class CollegeStudent(override val m5:Int,override val m2:Int,val m3:Int,val m4:Int) extends Student1(m5,m2) {
  var ma3:Int = m3
  var ma4:Int = m4
  var tot:Int = 0
  def calculateTotal( ma1:Int, ma2:Int, ma3:Int,  ma4:Int) {
    tot = ma1 + ma2 + ma3+ ma4
    println("Total is :"+tot)
  }
  override def toString():String = "(" + tot + ")"
}


