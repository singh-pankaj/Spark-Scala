package Orilley.shape

import com.datastax.spark.connector.CassandraRow
import org.apache.log4j.{Level, Logger}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object historyCheck {

  Logger.getLogger("org").setLevel(Level.OFF) //all, debug, error, fatal, info, off, trace, trace_int, warn
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("myLogger").setLevel(Level.OFF)

  val spark = SparkSession.builder().appName("function checklist").master("local[*]").getOrCreate()

  def main(args: Array[String]): Unit = {

    val HistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2017-12-31 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-02 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-02 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "hype", "element_date" -> "2018-02-02 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "chk", "element_date" -> "2018-02-02 00:00:00.00", "elementvalue" -> "5"))
    ))

    val iPPRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2017-12-31 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-02 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-02 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "hype", "element_date" -> "2018-02-02 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "chk", "element_date" -> "2018-02-02 00:00:00.00", "elementvalue" -> "5"))
    ))


   val hits = HistoryRDD.map(x => x.getString(0)).collect()


    //val patientHistoryBroadcastList: Broadcast[RDD[String]] = spark.sparkContext.broadcast(hits)

  //  patientHistoryBroadcastList.value.foreach()


   // iPPRDD.collect().filter( x =>  z => x.getString(0).equals(z)))



  }


}
