package Orilley.shape

object Tuple {

  def main(args: Array[String]): Unit = {

    val x= 1 -> 2
    println(x)

    val y= Tuple2(1, 2)
    println(y)

    val z= Pair(1, 2)
    println(z)



    //The convenient -> syntax for defining name-value pairs to initialize a Map

    val stateCapitals = Map("Alabama" -> "Montgomery")

    println(stateCapitals.get("Alabama"))

    val c= stateCapitals.get("Alabama")+" "+stateCapitals.get("Unknown")
    println(c)

    println(stateCapitals.get("Unknown").getOrElse("Oops2!") )

  }






  /*
    res0: (Int, Int) = (1,2)
    scala> Tuple2(1, 2)
    res1: (Int, Int) = (1,2)
    scala> Pair(1, 2)
    res2: (Int, Int) = (1,2)

  */



}
