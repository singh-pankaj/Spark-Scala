package Orilley.shape

object OptionalUserProfileInfo {
  val UnknownLocation = ""
  val UnknownAge = -1
  val UnknownWebSite = ""


  def main(args: Array[String]): Unit = {
   
    new OptionalUserProfileInfoClass
  new OptionalUserProfileInfoClass(age = 29)
  new OptionalUserProfileInfoClass(age = 29, location="Earth")
  }


}


class OptionalUserProfileInfoClass(
                               location: String = OptionalUserProfileInfo.UnknownLocation,
                               age: Int
                               = OptionalUserProfileInfo.UnknownAge,
                               webSite: String = OptionalUserProfileInfo.UnknownWebSite){

  println("class value "+location+" "+age+" "+webSite  )

}
