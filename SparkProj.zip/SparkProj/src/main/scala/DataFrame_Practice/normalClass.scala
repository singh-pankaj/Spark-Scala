package DataFrame_Practice

class normalClass(a:Int,B:Int) {


  def check:Unit = {
    if (a == 1) {
      println("a is 1")
    }
    else print(" In else ")
  }
  }
