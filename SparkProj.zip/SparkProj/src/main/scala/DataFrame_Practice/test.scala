package DataFrame_Practice

import DataFrame_Practice.DF_Practice.spark
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, SparkSession}

object test {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  val spark = SparkSession.builder().master("local[*]").appName("DF_Practice").getOrCreate()

  def main(args: Array[String]): Unit = {

    val df = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load("/home/pankaj.singh/DataSet/data/mycsv.csv")
    val df_1 = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load("/home/pankaj.singh/DataSet/data/mycsv.csv").rdd

    val c = df_1.map(r => r.mkString(",").toString)/*.collect.foreach(println)*/


    c.filter(r => !r.split(",").forall(z => (z.equals("null") || z.equals(" ")) )).foreach(println)


    /** d.columns.map(x=> col(x).isNull || col(x) === "").reduce(_||_) **/

   // c.filter(r => r.split(",").exists(r => (!r.equals("") || !r.equals(" ") ))).collect.foreach(println)

    import spark.implicits._

   // df_1.show(false)



    getDF(df).show()

  }

  // This Function will filter all row from DataFrame which contains data other than null or space
  def getDF(inputDataFrame: DataFrame): DataFrame = {

    val allcolumns = inputDataFrame.columns

    inputDataFrame.filter( r => !allcolumns.forall(z => r.isNullAt(r.fieldIndex(z)) || r.getAs[String](z).trim.isEmpty ))
  }

}
