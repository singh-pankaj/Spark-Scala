package DataFrame_Practice

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

object UserDF_Practice {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)

  val spark = SparkSession.builder().master("local[*]").appName("Create user DF ").getOrCreate()
  def main(args: Array[String]): Unit = {

    import spark.implicits._

    val historyDF= Seq(("P1","mere","2018-08-01 00:00:00.00","5"),
      ("P1","mere","2019-01-01 00:00:00.00","5"),
      ("P2","mere","2017-08-01 00:00:00.00","8"),
        ("P2","mere","2015-08-01 00:00:00.00","8"))
      .toDF("patientuid","element","element_date","elementvalue")

    historyDF.show(5,false)

    historyDF.orderBy("element_date").show(5,false)


    /*val tblencounterDF= Seq(("P1","1","2018-08-01 00:00:00.00"),
      ("P2","1","2017-08-01 00:00:00.00","8"),
      ("P2","1","2015-08-01 00:00:00.00","8"))
      .toDF("patientuid","mere","mere_date")*/


    val tblencounterDF= Seq(("P1","1","2018-08-02 00:00:00.00"),
      ("P2","1","2018-08-01 00:00:00.00")
    ).toDF("patientuid","mere","mere_date")

    tblencounterDF.show(3,false)

   // tblencounterDF.join(historyDF,tblencounterDF("patientuid") === historyDF("patientuid")).show(45,false)

    tblencounterDF.filter(x => x.get(0).equals("P1")).show()
  }

}
