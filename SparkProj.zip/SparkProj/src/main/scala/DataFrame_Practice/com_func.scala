package DataFrame_Practice


import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Calendar

import com.google.cloud.storage.Storage.BlobListOption
import com.google.cloud.storage.{Blob, BlobId, Storage, StorageException}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.mutable.ListBuffer
import scala.collection.JavaConversions._
object com_func {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)



  def Createsparksession(): SparkSession = {
    val spark: SparkSession = SparkSession
      .builder()
      // .master("local")
      .master("yarn")
      .appName("preProcessingUtility")
      .config("fs.gs.impl", "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem")
      .config("fs.AbstractFileSystem.gs.impl", "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFS")
      .getOrCreate()
    spark
  }
  val spark = Createsparksession()

  val header_map = Map("PatientDemographics" -> List("PatientId", "LastName", "FirstName", "MiddleName", "StreetLineAddress1", "StreetLineAddress2", "StreetLineAddress3", "StreetLineAddress4", "City", "StateCode", "State", "ZipCode", "CountryCode", "Country", "TelecomTypeText1", "TelecomValue1", "TelecomTypeText2", "TelecomValue2", "Gender", "DateOfBirth", "DeathDate", "MaritalStatusCode", "MaritalStatusText", "ReligiousAffiliationCode", "ReligiousAffiliationText", "BirthStateCode", "BirthState", "BirthZipCode", "BirthCountryCode", "BirthCountry", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "SSN", "DeathReason", "IsDeceased", "Patient_EMR_ID", "EmailID", "LocationOfDeath", "BirthOrder", "MultipleBirthPlaceIndicator", "PatientDemographicsKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "sourceidentifier", "sourcetype", "practicesideidentifier"),
    "PatientAllergies" -> List("PatientId", "EffectiveStartDate", "EffectiveEndDate", "AllergyTypeCode", "AllergyEventType", "AllergicToCode", "AllergicToDescription", "AllergyStatusCode", "AllergyStatusText", "AllergyReaction", "AllergiesKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientProblem" -> List("PatientId", "ProblemCode", "ProblemText", "ProblemCategory", "ProblemTypeCode", "ProblemTypeText", "DocumentationDate", "ProblemResolutionDate", "ProblemStatusCode", "ProblemStatusText", "ProblemHealthStatusCode", "ProblemHealthStatusText", "NegationInd", "ProblemComment", "ProblemOnsetDate", "TargetSiteCode", "TargetSiteText", "ProblemKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientEthnicity" -> List("PatientId", "PatientEthnicityCode", "PatientEthnicityText", "PatientEthnicityKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "sourceidentifier", "sourcetype", "practicesideidentifier"),
    "PatientRace" -> List("PatientId", "PatientRaceCode", "PatientRaceText", "PatientRaceKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "sourceidentifier", "sourcetype", "practicesideidentifier"),
    "PatientFamilyHistory" -> List("PatientId", "FamilyMemberLastName", "FamilyMemberFirstName", "RelationshipToPatientCode", "RelationshipToPatientText", "FamilyMemberGender", "FamilyMemberDOB", "EffectiveDate", "ProblemCode", "ProblemText", "ProblemCategory", "ProblemTypeCode", "ProblemTypeText", "FamilyMemberAge", "IsFamilyMemberAlive", "FamilyHistoryKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "sourceidentifier", "sourcetype", "practicesideidentifier"),
    "PatientVitalSigns" -> List("PatientId", "ObservationCode", "ObservationName", "ObservationCategory", "ObservationDate", "ObservationValue", "ObsInterpretationCode", "ObsInterpretationText", "TargetSiteCode", "TargetSiteText", "NegationInd", "ReferenceLowerRange", "ReferenceUpperRange", "MethodCode", "MethodCodeText", "ResultOBSUnit", "VitalSignsKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientImmunization" -> List("PatientId", "ImmunizationCode", "ImmunizationName", "ImmunizationCategory", "ImmuStartDate", "ImmuStopDate", "AdministeredEffectiveDate", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "RepeatNumber", "MedicationRouteCode", "MedicationRouteText", "DoseQuantity", "DoseQuantityUnitCode", "DoseQuantityUnitText", "MedicationProductFormCode", "MedicationProductFormText", "ProcedureCode", "ProcedureText", "ProcedureCategory", "NegationInd", "MedicationBrandName", "MedicationGenericName", "MaxDoseQuantity", "DispensingTimeOfSupply", "DispensingDoseQuantity", "SupplyPrescriberLastName", "SupplyPrescriberFirstName", "SupplyPerformerLastName", "SupplyPerformerFirstName", "ServiceLocationId", "ServiceLocationName", "MedicationIndicationCriteria", "MedicationIndicationProblemCode", "MedicationIndicationProblemText", "MedicationIndicationProblemCategory", "MedicationSeriesNumber", "MedicationReactionProblemCode", "MedicationReactionProblemText", "MedicationReactionProblemCategory", "MedicationReactionProblemSeverityCode", "MedicationReactionProblemSeverityText", "MedicationStatusCode", "MedicationStatusText", "MedicineManufacturer", "MedicineId", "ProductInstanceScopingEntityId", "SubstanceLotNumber", "SubstanceExpirationDate", "ActionCode", "AdministrationSite", "ImmunizationKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientResultObservation" -> List("PatientId", "ObservationCode", "ObservationName", "ObservationCategory", "ObservationDate", "ObservationValue", "ObsInterpretationCode", "ObsInterpretationText", "TargetSiteCode", "TargetSiteText", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "NegationInd", "ReferenceLowerRange", "ReferenceUpperRange", "MethodCode", "MethodCodeText", "SpecimenId", "ProcedureCode", "ProcedureText", "ProcedureCategory", "ResultObservationStatus", "ResultOrderDescription", "ResultOrderDate", "ResultOBSUnit", "LaboratoryID", "LaboratoryName", "ResultOrderCode", "Obssubid", "ResultObservationKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "orderid", "administrationsite", "observationmethod", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientSocialHistoryObservation" -> List("PatientId", "SocialHistoryTypeCode", "SocialHistoryTypeText", "SocialHistoryObservedValue", "DocumentationDate", "EffectiveStopDate", "SocialHistoryStatusCode", "SocialHistoryStatusText", "YearsSmoked", "QuitYear", "SocialHxGroup", "EffectiveStartDate", "SocialHistoryObservationKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientEncounterDiagnosis" -> List("PatientId", "EncounterDate", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "ServiceLocationId", "ServiceLocationName", "EncounterDiagnosisCode", "EncounterDiagnosisText", "EncounterDiagnosisCategory", "EncounterProblemTypeCode", "EncounterProblemTypeText", "DocumentationDate", "ProblemResolutionDate", "ProblemStatusCode", "ProblemStatusText", "ProblemHealthStatusCode", "ProblemHealthStatusText", "NegationInd", "ProblemComment", "ProblemOnsetDate", "TargetSiteCode", "TargetSiteText", "ListOrder", "EncounterDiagnosisKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientEncounter" -> List("PatientId", "EncounterTypeCode", "EncounterTypeText", "EncounterStartDate", "EncounterEndDate", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "ServiceProviderRoleCode", "ServiceProviderRoleText", "ServiceLocationId", "ServiceLocationName", "ServiceLocationRoleTypeCode", "ServiceLocationRoleTypeText", "ReasonForVisit", "Service_Location_AddressLine", "Service_Location_City", "Service_Location_State", "Service_Location_PostalCode", "Encounter_Status", "EncounterTIN", "EncounterKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "patientdischargestatustext", "patientdischargestatuscode", "admissiontype", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber", "episodeofcarestartdate", "episodeofcareenddate", "episodekey"),
    "PatientMedications" -> List("PatientId", "MedicationCode", "MedicationName", "MedicationCategory", "MedStartDate", "MedStopDate", "AdministeredEffectiveDate", "RepeatNumber", "MedicationRouteCode", "MedicationRouteText", "DoseQuantity", "DoseQuantityUnitCode", "DoseQuantityUnitText", "MedicationProductFormCode", "MedicationProductFormText", "ProcedureCode", "ProcedureText", "ProcedureCategory", "PrescribeElectronically", "NegationInd", "MedicationBrandName", "MedicationGenericName", "MaxDoseQuantity", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "DispensingTimeOfSupply", "DispensingDoseQuantity", "SupplyPrescriberLastName", "SupplyPrescriberFirstName", "SupplyPerformerLastName", "SupplyPerformerFirstName", "ServiceLocationId", "ServiceLocationName", "MedicationIndicationCriteria", "MedicationIndicationProblemCode", "MedicationIndicationProblemText", "MedicationIndicationProblemCategory", "MedicationSeriesNumber", "MedicationReactionProblemCode", "MedicationReactionProblemText", "MedicationReactionProblemCategory", "MedicationReactionProblemSeverityCode", "MedicationReactionProblemSeverityText", "MedicationStatusCode", "MedicationStatusText", "MedicineManufacturer", "MedicineId", "ProductInstanceScopingEntityId", "PracticePatientMedicationKey", "DocumentationDate", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "medicationsource", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientProcedures" -> List("PatientId", "ProcedureCode", "ProcedureText", "ProcedureCategory", "ProcedureDate", "TargetSiteCode", "TargetSiteText", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "ServiceLocationId", "ServiceLocationName", "ProcedureStatusCode", "ProcedureStatusText", "NegationInd", "ProcedureComment", "Modifier1", "Modifier2", "Modifier3", "Modifier4", "Insurance", "ProceduresKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientPayer" -> List("PatientId", "InsuredPersonId", "InsuranceCompany", "InsurancePlan", "InsuranceGroup", "InsuranceOrder", "InsuredRelationToPatientCode", "InsuredRelationToPatientText", "DocumentationDate", "EndDateOfInsurance", "IsInsuredSameAsGuarantor", "PayerID", "PolicyID", "PayerCity", "PayerState", "PayerZip", "Insurance_Active", "StartDateOfInsurance", "BillingInsurance", "PayerKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "payerstreetlineaddress", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientLanguage" -> List("PatientId", "LanguageCode", "LanguageText", "LangaugeAbilityModeCode", "LangaugeAbilityModeText", "LanguageProficiencyLevelCode", "LanguageProficiencyLevelText", "IsPreferred", "PatientLanguageKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "sourceidentifier", "sourcetype", "practicesideidentifier"),
    "PatientGuardian" -> List("PatientId", "GuardianLastName", "GuardianFirstName", "StreetLineAddress1", "StreetLineAddress2", "StreetLineAddress3", "StreetLineAddress4", "City", "StateCode", "State", "ZipCode", "CountryCode", "Country", "TelecomTypeText", "TelecomValue", "RelationshipToPatientCode", "RelationshipToPatientText", "PatientGuardianKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "sourceidentifier", "sourcetype", "practicesideidentifier"),
    "PatientLabOrder" -> List("PatientId", "OrderCode", "OrderName", "OrderCategory", "OrderDate", "TargetSiteCode", "TargetSiteText", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "ReferenceLowerRange", "ReferenceHigherRange", "MethodCode", "MethodText", "SpecimenID", "OrderStatus", "LaboratoryID", "LaboratoryName", "PatientLabOrderKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientPlanOfCare" -> List("PatientId", "Instructions", "PlanOfCareCode", "PlanOfCareText", "EffectiveDate", "PlanOfCareStatusCode", "PlanOfCareStatusText", "PlanOfCareGroup", "PlanOfCareKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientAdvanceDirective" -> List("PatientId", "AdvanceDirectiveTypeCode", "AdvanceDirectiveTypeDetails", "AdvanceDirectiveStatusCode", "AdvanceDirectiveStatusText", "EffectiveStartDate", "EffectiveEndDate", "AgentName", "ExternalDocumentLink", "GroupName", "AdvanceDirectiveTypeText", "AdvanceDirectiveKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientNotesMedication" -> List("PatientId", "EncounterDate", "SectionName", "Note", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "ServiceLocationId", "ServiceLocationName", "Group1", "Group2", "Group3", "Group4", "PracticePatientNoteKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientNotesProblem" -> List("PatientId", "EncounterDate", "SectionName", "Note", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "ServiceLocationId", "ServiceLocationName", "Group1", "Group2", "Group3", "Group4", "PracticePatientNoteKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientNotesProcedure" -> List("PatientId", "EncounterDate", "SectionName", "Note", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "ServiceLocationId", "ServiceLocationName", "Group1", "Group2", "Group3", "Group4", "PracticePatientNoteKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientNotesResultObservation" -> List("PatientId", "EncounterDate", "SectionName", "Note", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "ServiceLocationId", "ServiceLocationName", "Group1", "Group2", "Group3", "Group4", "PracticePatientNoteKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientNotes" -> List("PatientId", "EncounterDate", "SectionName", "Note", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "ServiceLocationId", "ServiceLocationName", "Group1", "Group2", "Group3", "Group4", "PracticePatientNoteKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientNotesVitalObservation" -> List("PatientId", "EncounterDate", "SectionName", "Note", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "ServiceLocationId", "ServiceLocationName", "Group1", "Group2", "Group3", "Group4", "PracticePatientNoteKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber"),
    "PatientFunctionalStatus" -> List("PatientId", "EncounterDate", "SectionName", "Note", "ServiceProviderNPI", "ServiceProviderLastName", "ServiceProviderFirstName", "ServiceLocationId", "ServiceLocationName", "Group1", "Group2", "Group3", "Group4", "PracticePatientNoteKey", "PracticeUid", "BatchUid", "Dummy1", "Dummy2", "visitkey", "sourceidentifier", "maxdate", "sourcetype", "practicesideidentifier", "labaccessionnumber")
  )


  val section_uid_map = Map("c02a8880-be91-4479-add2-02fe91f48db0" -> "PatientProblem", "e9746c91-6a44-4b65-b398-06706d075422" -> "PatientMedications",
    "12190785-27cf-42fb-8cec-0a252312f2f1" -> "PatientNotesVitalObservation", "0fd165fd-99a8-4ee8-9148-13f9e848ca73" -> "PatientNotesProcedure",
    "129e36f5-51dd-412c-8a83-15f50cc6563e" -> "PatientNotes", "a06375b5-51cc-4028-88ea-1690c4e7b2e7" -> "PatientEthnicity", "edea6658-b815-466d-aeea-17a9dd575dd1" -> "PatientDemographics",
    "ed4eba3a-8fda-4cf8-a0a0-204c08258599" -> "PatientAllergies", "28a98c02-378c-44a7-9761-2dc30ce4454a" -> "PatientNotesResultObservation",
    "feadd9f3-6078-4274-9275-421ce9e9384a" -> "PatientClinicalEvent", "e30d97b0-9d14-46b5-97c6-532c64de0f8d" -> "PregnanacyObservation", "750b0376-496d-4f3e-a061-5ea7f630b343" -> "PatientLanguage",
    "41318672-877d-4c04-b2cb-61cd7db55864" -> "PatientProcedures", "cf7aec77-db5a-4929-90fb-7c1cfbb7af21" -> "PatientImmunization", "4a188a2b-0e27-40d5-8a58-875e1113b4fa" -> "PatientPlanOfCare",
    "7b5b1bad-4a4d-454e-a9a7-942340314884" -> "PatientFamilyHistory", "40eb7512-26ea-4eec-b05f-966fb63e1aa4" -> "PatientVitalSigns", "02f73e07-21ad-4d57-a8a2-975666cd08ba" -> "PatientLabOrder",
    "608cdee4-97d1-42a2-849d-9d9a95bc5131" -> "PatientEncounterDiagnosis", "f967c591-1460-4731-b6be-a620238630d2" -> "PatientResultObservation",
    "f21e7e3c-127d-4b05-b8f3-b9367c76ce4e" -> "PatientGuardian", "813ee7ca-89da-4a2a-9b78-bbc710595fcc" -> "PatientSocialHistoryObservation",
    "8ff9928e-7288-4491-8aa0-c7e0da5bbba8" -> "PatientEncounter", "570d4cf7-7d50-4179-9421-da363fba7a43" -> "PatientNotesProblem", "fa089e80-9064-41aa-9052-dbe36a15cb66" -> "PatientAdvanceDirective",
    "52ddf45c-6d51-418f-be58-eb8ce57fa2a1" -> "PatientRace", "2fe58c3e-f5da-464f-a9f7-ec9351743a3c" -> "PatientNotesMedication", "a70ed65f-6cca-4808-82b4-fb2bcc5e737a" -> "PatientPayer")

  val TypeCodeList: List[String] = List("99304", "99305", "99306", "99307", "99308", "99309", "99310", "99324", "99325", "99326", "99327", "99328", "99334",
    "99335", "99336", "99341", "99342", "99343", "99344", "99345", "99347", "99348", "99349", "99350", "99354", "99355", "97004", "92002", "92004", "92012",
    "92014", "99395", "99396", "99397", "99411", "99412", "99420", "99429", "99401", "99402", "99403", "99404", "99385", "99386", "99387", "92521", "92522",
    "92523", "92524", "92540", "92557", "92625", "99406", "99407", "96118", "97532", "99218", "99219", "99220", "99224", "99225", "99226", "99234", "99235",
    "99236", "99318", "99340", "99391", "99392", "99393", "99394", "99381", "99382", "99383", "99384", "99241", "99242", "99243", "99244", "99245", "99315",
    "99316", "99512", "92541", "92542", "92548", "90801", "90802", "90804", "90805", "90806", "90807", "90808", "90809", "90810", "90811", "90812", "90813",
    "90814", "90815", "90816", "90817", "90818", "90819", "90821", "90822", "90823", "90824", "90826", "90827", "90828", "90829", "90845", "90847", "90849",
    "90853", "90857", "90862", "90875", "90876", "92003", "92005", "92006", "92007", "92008", "92009", "92010", "92011", "92013", "96150", "96151", "96152",
    "97001", "97002", "97003", "97802", "97803", "97804", "98925", "98926", "98927", "98928", "98929", "98940", "98941", "98942", "98960", "98961", "98962",
    "99078", "99201", "99202", "99203", "99204", "99205", "99211", "99212", "99213", "99214", "99215", "99217", "99221", "99222", "99223", "99231", "99232",
    "99233", "99238", "99239", "99251", "99252", "99253", "99254", "99255", "99281", "99282", "99283", "99284", "99285", "99291", "99337", "99408", "99409",
    "99455", "99456", "99510", "99024", "90791", "90792", "90832", "90834", "90837", "90839", "90957", "90958", "90959", "90960", "90961", "90962", "90965",
    "90966", "90969", "90970", "90989", "90993", "90997", "90999", "92507", "92508", "92526", "92543", "92544", "92545", "92547", "92567", "92568", "92570",
    "92585", "92588", "92626", "96116", "97110", "97140", "99495", "99496", "90880")


  var section_uid_rev_map = Map[String, String]()
  for (i <- 0 until section_uid_map.size) {
    val section = section_uid_map.toList(i)._2
    val section_id = section_uid_map.toList(i)._1
    section_uid_rev_map += section -> section_id
  }

  var errorString: String = ""

  var write_time = LocalDateTime.now.format(DateTimeFormatter.ofPattern("YYYYMMddHHmmss.SSS"))
  val logWriter : StringBuilder = StringBuilder.newBuilder

  def buildLogger(message_type : String,message_content : String):String={
    val current_time = LocalDateTime.now.format(DateTimeFormatter.ofPattern("YYYY-MM-dd HH:mm:ss.SSS"))
    logWriter.append(message_type+": "+current_time+" : "+message_content+"\n")
    logWriter.toString()
  }

  def errorlogString(error: String): String = {
    error + ","
  }

  def errorlogging(batchId: String, error: String, status: String = ""): String = {
    batchId + "|" + error.dropRight(1) + "|" + status +"\n"
  }

  /*def errorlog(current: String, section: String, errorString: String): String = {
    errorString + "=>Exception in File:" + section + "\n" + "===>Exception Found:" + current + "\n\n"
  }*/


  def nameSplit(df:DataFrame,ServiceProviderLastName:String,ServiceProviderFirstName:String):DataFrame= {
    val newdf=df.filter(col(ServiceProviderLastName)==="" || col(ServiceProviderLastName).isNull).withColumn(ServiceProviderLastName, regexp_replace(col(ServiceProviderFirstName), "([a-z]*[A-Z]*)(\\s)(.*)", "$3"))
      .withColumn(ServiceProviderFirstName, split(col(ServiceProviderFirstName), " ").getItem(0)) //handling condition of space and ',' after first name
    df.filter(col(ServiceProviderLastName).isNotNull && col(ServiceProviderLastName)=!= "").union(newdf.select(header_map("PatientEncounter").head,header_map("PatientEncounter").tail:_*))
  }

  def writeDF(gsStorage: Storage, df: DataFrame, practice: String, sec: String,outputFilePath: String): Unit = {
    try {
      var write_time = LocalDateTime.now.format(DateTimeFormatter.ofPattern("YYYYMMddHHmmss.SSS"))
      df.coalesce(1).write.mode("overwrite").option("multiline", "true").option("header", "false").option("delimiter", "\u0017")
        .csv(outputFilePath.dropRight(1) + s"_stg/$sec/" + section_uid_rev_map(sec) + "_" + practice.toLowerCase + "_" + write_time + ".txt_temp")
    }
    catch{
      case ex=> errorString = errorlogString(s"couldn't Write $sec "+ex.toString)
        buildLogger("[WARN]","Exception Found while Writing in " +sec+ "-------------"+ex+"-----------")
    }
    cleanOutputLocation(gsStorage, outputFilePath + sec + "/")
    renameGSObjects(gsStorage, outputFilePath)
  }

  /*output_file_path will be the input path from where the files were taken to create the df*/
  def cleanOutputLocation(gsStorage: Storage, output_file_path: String): Unit = {
    val outputFilePath = output_file_path
    val pulldata_bucketName = outputFilePath.split("/")(2)
    val pulldata_path = outputFilePath.substring(outputFilePath.indexOf("/", outputFilePath.indexOf("/") + 2) + 1, outputFilePath.length)
    var obj_list = ListBuffer[Blob]()
    var rename_list = ListBuffer[Blob]()
    val delete_list = ListBuffer[BlobId]()
    val blobs = gsStorage.list(pulldata_bucketName, BlobListOption.prefix(pulldata_path))
    for (blob <- blobs.iterateAll) {
      val files = blob.getName
      obj_list.append(blob)
    }
    // obj_list.foreach( obj => println("--------------"+obj.getName))
    obj_list.foreach(obj => delete_list.append(BlobId.of(pulldata_bucketName, obj.getName)))
    gsStorage.delete(delete_list)
  }

  def renameGSObjects(gsStorage: Storage, output_file_path: String) {
    val outputFilePath = output_file_path.dropRight(1) + "_stg/"
    val pulldata_bucketName = outputFilePath.split("/")(2)
    val pulldata_path = outputFilePath.substring(outputFilePath.indexOf("/", outputFilePath.indexOf("/") + 2) + 1, outputFilePath.length)
    try {
      var output_blobs = gsStorage.list(pulldata_bucketName, BlobListOption.prefix(pulldata_path))
      val move_list = ListBuffer[Blob]()
      val rename_list = ListBuffer[Blob]()
      for (blob <- output_blobs.iterateAll()) {
        if (blob.getName.endsWith(".csv")) {
          rename_list.append(blob)
        }
      }
      rename_list.foreach(obj => obj.copyTo(pulldata_bucketName, obj.getName.substring(0, obj.getName.replace(obj.getName.reverse.split("/")(0).reverse, "").length - 6)))
      output_blobs = gsStorage.list(pulldata_bucketName, BlobListOption.prefix(pulldata_path))
      for (blob <- output_blobs.iterateAll()) {
        if (blob.getName.endsWith(".txt")) {
          move_list.append(blob)
        }
      }
      move_list.foreach(b => {
        val filename_splits = b.getName.split("/")
        val reqd_path = pulldata_path.dropRight(5) + "/" + filename_splits.slice(filename_splits.length - 2, +filename_splits.length).mkString("/")
        b.copyTo(pulldata_bucketName, s"$reqd_path")
      })
      output_blobs = gsStorage.list(pulldata_bucketName, BlobListOption.prefix(pulldata_path))
      val obj_list = ListBuffer[Blob]()
      val delete_list = ListBuffer[BlobId]()
      for (blob <- output_blobs.iterateAll()) {
        obj_list.append(blob)
      }
      obj_list.foreach(obj => delete_list.append(BlobId.of(pulldata_bucketName, obj.getName)))
      gsStorage.delete(delete_list)
    }
    catch {
      case ex: StorageException => println(s"The output folder path '$output_file_path' does not exist hence renaming the files doesn't apply")
    }
  }


  import spark.implicits._

  def minDateUpdateForOneColWithEncounterStartDate(dfencounter: DataFrame, dfPlanOfCAre: DataFrame): DataFrame = {
    val t2 = dfencounter.filter($"EncounterStartDate".geq("2017-01-01") && $"EncounterTypeCode".isin(TypeCodeList:_*)).groupBy($"PatientId").agg(min("EncounterStartDate").as("EncounterStartDate"))

    dfPlanOfCAre.as("df1").join(t2.as("df2"), $"df1.PatientId" === $"df2.PatientId", "left_outer")
      .withColumn("EffectiveDate", when($"EffectiveDate".isNull, $"EncounterStartDate").otherwise($"EffectiveDate")).drop($"df2.PatientId").drop($"df2.EncounterStartDate")

  }

  def updateSocailHistoryWithMinEncounterStartDate(dfencounter: DataFrame, dfPlanOfCAre: DataFrame): DataFrame = {
    val t2 = dfencounter.filter($"EncounterStartDate".geq("2017-01-01") && $"EncounterTypeCode".isin(TypeCodeList:_*)).groupBy($"PatientId").agg(min("EncounterStartDate").as("EncounterStartDate"))
    dfPlanOfCAre.as("df1").join(t2.as("df2"), $"df1.PatientId" === $"df2.PatientId", "left_outer")
      .withColumn("EffectiveStartDate", when($"EffectiveStartDate".isNull || $"EffectiveStartDate" === "", $"EncounterStartDate").otherwise($"EffectiveStartDate")).drop($"df2.PatientId").drop($"df2.EncounterStartDate")

  }


  def minDateUpdateForTwoColWithEncounterStartDate(dfencounter: DataFrame, dfProblem: DataFrame): DataFrame = {
    val t2 = dfencounter.filter($"EncounterStartDate".geq("2017-01-01") && $"Encountertypecode".isin(TypeCodeList:_*)).groupBy($"PatientId").agg(min("EncounterStartDate").as("EncounterStartDate"))
    val df = dfProblem.as("df1").join(t2.as("df2"), $"df1.PatientId" === $"df2.PatientId", "left_outer")
      .withColumn("DocumentationDate", when($"DocumentationDate".isNull || $"DocumentationDate" === "", $"EncounterStartDate").otherwise($"DocumentationDate"))
      .withColumn("ProblemOnsetDate", when($"ProblemOnsetDate".isNull || $"ProblemOnsetDate" === "", $"EncounterStartDate").otherwise($"ProblemOnsetDate"))
      .drop($"df2.PatientId").drop($"df2.EncounterStartDate")
    df
  }

  def updateOneColFromAnother(df: DataFrame, col2Update: String, col2Check1: String): DataFrame = {
    df.withColumn(col2Update, when((df(col2Update).isNull || df(col2Update) === "") && (df(col2Check1).isNotNull && df(col2Check1) =!= ""), df(col2Check1)).otherwise(df(col2Update)))
  }


  /* /** Integrity updateNPI when ServiceProviderNPI isNUll*/

   def updateFirstAndLastName(df:DataFrame,ServiceProviderNPI:String,ServiceProviderLastName:String,ServiceProviderFirstName:String,npivalue:String,lname:String,fName:String):DataFrame={
     df.withColumn("ServiceProviderLastName",when((df("ServiceProviderNPI")===npivalue) && (df("ServiceProviderLastName").isNull || df("ServiceProviderLastName")==="") && (df("ServiceProviderFirstName").isNull || df("ServiceProviderFirstName")===""),lname)
       .otherwise($"ServiceProviderLastName"))
       .withColumn("ServiceProviderFirstName",when((df("ServiceProviderNPI")==="1144428491") && (df("ServiceProviderFirstName").isNull || df("ServiceProviderFirstName")===""),fName)
         .otherwise(df("ServiceProviderFirstName")))
   }
 */

  /** Can be used to update two Column(Date) from one column(maxdate) */

  def maxdateUpdateTwoCol(df: DataFrame, col2Update1: String, col2Update2: String, val2Update: String): DataFrame = {
    // TODO: if filename has to be updated, do that
    df.withColumn(col2Update1, when((df(col2Update1).isNull || df(col2Update1) === "") && (df(col2Update2).isNull || df(col2Update2) === ""), df(val2Update)).otherwise(df(col2Update1)))
      .withColumn(col2Update2, when(df(col2Update2).isNull || df(col2Update2) === "", df(val2Update)).otherwise(df(col2Update2)))
  }

  /** Can be used to update one Column(Date) when other column(effectiveStartDate) isNull from one column(maxdate) also check  */

  def maxdateUpdateOneColOneCheck(df: DataFrame, col2Update1: String, col2check1: String, val2Update: String): DataFrame = {
    df.withColumn(col2Update1, when((df(col2Update1).isNull || df(col2Update1) ==="") && (df(col2check1).isNull || df(col2check1)===""),df(val2Update)).otherwise(df(col2Update1)))
  }

  /** used to update date with maxdate*/

  def maxdateUpdateOneCol(df: DataFrame, col2Check1: String, val2Update: String): DataFrame = {
    df.withColumn(col2Check1, when(df(col2Check1).isNull || df(col2Check1) === "", df(val2Update)).otherwise(df(col2Check1)))
  }

  /** Can be used to extract date*/

  def extractDate(df:DataFrame,Col4Extraction:String):DataFrame= {
    df.withColumn("EncounterDate",when(($"SectionName".contains("Procedures Section") || $"SectionName".contains("Encounters Section")) && ($"EncounterDate".isNull || $"EncounterDate"==="")
      , to_timestamp(regexp_replace(regexp_extract(df(Col4Extraction), "[0-9]{4}[/-]?[0-9]{2}[/-]?[0-9]{2}", 0)
        ,"([0-9]{4})([0-9]{2})([0-9]{2})", "$1-$2-$3"))).otherwise($"EncounterDate"))
  }

  /** update SocialHistoryTypeText */

  def updateSocialHistoryTypeText(df:DataFrame):DataFrame={
    df.withColumn("SocialHistoryTypeText",when($"labaccessionnumber"==="2.16.840.1.113883.10.20.22.4.78","Tobacco use and exposure (observable entity)").otherwise($"SocialHistoryTypeText"))
      .withColumn("labaccessionnumber",lit(""))
  }

  def updateEncounterdf(df:DataFrame):DataFrame={
    val updateEncounterTypeCodeWritedf = updateEncounterTypeCode(df)
    updateEncounterTypeCodeWritedf
  }

  def updateEncounterTypeCode(df:DataFrame)={
    df.withColumn("EncounterTypeCode",when($"EncounterTypeCode".isNull||$"EncounterTypeCode"==="","99212").otherwise($"EncounterTypeCode"))
  }

  def getValueTwoCols(df:DataFrame, col2Update:String, col2Check1:String, col2Check2:String): DataFrame = {
    df.withColumn(col2Update, when(df(col2Update).isNull || df(col2Update) === "" , when(df(col2Check1).isNotNull && df(col2Check1) =!= "", df(col2Check1))
      .otherwise(df(col2Check2))).otherwise(df(col2Update))) }

  def updateonecheckonecol(df: DataFrame, col2Update: String, col2Check1: String): DataFrame = {
    df.withColumn(col2Update, when((df(col2Update).isNull || df(col2Update) === "") && (df(col2Check1).isNotNull && df(col2Check1) =!= ""), df(col2Check1)).otherwise(df(col2Update)))
  }


  def updateonechecktwocol(df: DataFrame, col2Update: String, col2Check1: String, value2update: String): DataFrame = {
    df.withColumn(col2Update, when((df(col2Update).isNull || df(col2Update) === "") && (df(col2Check1).isNull && df(col2Check1) === ""), df(value2update)).otherwise(df(col2Update)))
  }

  /** index=67 Can be used to update one Column(Date) from one column(maxdate) isNotNull */

  def dateUpdateOneColOnecheck(df: DataFrame, col2Check1: String, val2Update: String): DataFrame = {
    df.withColumn(col2Check1, when(df(col2Check1).isNull || df(col2Check1) === "" && (df(val2Update).isNotNull || df(val2Update) =!= ""), df(val2Update)).otherwise(df(col2Check1)))
  }

  /** index=59 update CacheSocialHistoryObservation */

  def socialHistoryStatusTextUpdate_AUA(df: DataFrame): DataFrame = {
    df.withColumn("SocialHistoryStatusText", when($"SocialHistoryStatusText" === "completed", $"SocialHistoryObservedValue").otherwise($"SocialHistoryStatusText"))
  }


  //=============DataMovement for HNS-Webchart===========

  //TODO DATAMOVEMENT HNS Col For Webchart OR Athena OR Prognosis

  val col2selectFromEncounter:List[String]=List("PatientId","EncounterTypeCode","EncounterTypeText","EncounterStartDate","ServiceProviderLastName","ServiceProviderFirstName","ServiceProviderNPI",
    "ServiceLocationId","ServiceLocationName","PracticeUid")
  val colsNewNameAsPerProcedures:List[String]=List("PatientId","ProcedureCode","ProcedureText","ProcedureDate","ServiceProviderLastName","ServiceProviderFirstName","ServiceProviderNPI",
    "ServiceLocationId","ServiceLocationName","PracticeUid")
  val valueToPut=Map("ProcedureCategory" -> "CPT-4")


  /* //TODO DATAMOVEMENT HNS Col For Athena
   val col2select_HNS: List[String] = List("PatientId", "EncounterTypeCode", "EncounterStartDate", "ServiceProviderLastName", "ServiceProviderFirstName", "ServiceProviderNPI",
     "ServiceLocationId", "ServiceLocationName", "PracticeUid")
   val colsNewName_HNS: List[String] = List("PatientId", "ProcedureCode", "ProcedureDate", "ServiceProviderLastName", "ServiceProviderFirstName", "ServiceProviderNPI",
     "ServiceLocationId", "ServiceLocationName", "PracticeUid")
   val values_HNS = Map("ProcedureCategory" -> "6")*/

  //TODO DATAMOVEMENT ABFM Col For Athena

  val col2select: List[String] = List("PatientId", "EncounterTypeCode", "EncounterTypeText", "EncounterStartDate", "ServiceProviderNPI", "ServiceLocationId", "ServiceProviderLastName",
    "ServiceProviderFirstName", "maxdate", "PracticeUid") //CreatedDate,filename are missing
  val colsNewName: List[String] = List("PatientId", "ProcedureCode", "ProcedureText", "ProcedureDate", "ServiceProviderNPI", "ServiceLocationId", "ServiceProviderLastName",
    "ServiceProviderFirstName", "maxdate", "PracticeUid")
  //CreatedDate,filename are missing
  val values = Map("ProcedureCategory" -> "CPT-4", "ProcedureComment" -> ("EncounterToProcedureInsertedData" + Calendar.getInstance().getTime.toString))




  /** DATA MOVEMENT FUNCTION*/
  def selectAndRename(df: DataFrame, col2select: List[String], colsNewName: List[String]): DataFrame = {
    df.select(col2select.head, col2select.tail: _*).distinct().toDF(colsNewName: _*)
  }
  def hardCode(df: DataFrame, values: Map[String, String]): DataFrame = {
    values.foldLeft(df) { (df, cols) => df.withColumn(cols._1, lit(cols._2)) }
  }
  def oneDFtoAnother(df: DataFrame, df2Write: DataFrame): DataFrame = {
    val finalCols = df2Write.columns
    val cols2Add = finalCols.diff(df.columns)
    val dfFinal = cols2Add.foldLeft(df) { (df, name) => df.withColumn(name, lit(null)) }
    df2Write.union(dfFinal.select(finalCols.head, finalCols.tail: _*))
  }



}
