package DataFrame_Practice

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{current_date, current_timestamp, _}

object caseClass {
  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)

  case class Person(Name: String)


  val spark = SparkSession.builder().master("local[*]").getOrCreate()

  def main(args: Array[String]): Unit = {

    val c = new normalClass(1, 2)

    c.check

    val x = new Person("Pankajaa")
    println(x.Name)


    val simpleColors: Seq[String] = Seq("black", "white", "red", "green", "blue")
    val regexString = simpleColors.map(_.toUpperCase).mkString("(", "|", ")")

    println(regexString)


    val dateDF = spark.range(10)
      .withColumn("today", current_date())
      .withColumn("now", current_timestamp())


    dateDF.show(6, false)

    dateDF
      .select(date_sub(col("today"), 5),
        date_add(col("today"), 5),
        add_months(col("today"), 6),
        date_format(col("today"), format = "MM/dd/yy"),
        datediff(col("today"), date_add(col("today"), 5)),
        to_date(lit("2016-01-01")).alias("start"), //yyyy-month-day
        months_between(col("today"), col("today"))
      )
      .show(1)


    dateDF.select(to_date(lit("2016-20-12")), to_date(lit("2017-12-11"))).show(1)


    val dateFormat = "yyyy-dd-MM"
    val cleanDateDF = spark.range(1)
      .select(
        to_date(unix_timestamp(lit("2017-12-11"), dateFormat).cast("timestamp"))
          .alias("date"),
        to_date(unix_timestamp(lit("2017-20-12"), dateFormat).cast("timestamp"))
          .alias("date2"))

    cleanDateDF.show(3, false)

    cleanDateDF.select(unix_timestamp(col("date"), dateFormat).cast("timestamp")).show()

  }


}
