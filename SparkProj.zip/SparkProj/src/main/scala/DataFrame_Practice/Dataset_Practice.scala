package DataFrame_Practice

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

object Dataset_Practice {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)

  case class Person(name:String,age:Int) // It should be before main method
  val spark = SparkSession.builder().appName("DataSet_Pratice").master("local[*]").getOrCreate()

  def main(args: Array[String]): Unit = {

    import spark.implicits._

    val mydataset = Seq(Person("Pankaj",23),Person("Pankaj",21)).toDF()

    mydataset.repartition(12)
    mydataset.show()
//    mydataset.write.json("/home/pankaj.singh/DataSet/son")

    // DataFrames can be converted to a Dataset by providing a class. Mapping will be done by name
   // val peopleDS = spark.read.json(path).as[Person]

    // Not sure which row will be deleted
  //  mydataset.dropDuplicates("name").show()



    mydataset.filter($"age"===23).show()




  }

}
