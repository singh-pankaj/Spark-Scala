package DataFrame_Practice

import org.apache.log4j.{Level, Logger}
import org.apache.parquet.filter2.predicate.Operators.Column
import org.apache.spark.annotation.InterfaceStability
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.sql.functions._

import scala.reflect.internal.util.TableDef

object DF_Practice {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)

  /*
   val rawdata = spark.read.csv("gs://sparkmigrate/sunil/regexData").toDF("note","sr")
    val data=rawdata.select("note")

    val confData = spark.read.option("multiLine", true).option("mode", "PERMISSIVE")
      .json("gs://sparkmigrate/sunil/config.json")
   */

  /*
  import spark.implicits._
   val df1 = spark.read.format("parquet").option("header","true").load("/home/pankaj.singh/DataSet/userdata1.parquet")
df1.filter($"country"==="Canada").write.partitionBy("country").parquet("/home/pankaj.singh/DataSet/userdata1.parquet_Canada")
df1.withColumn("",$"country").write.partitionBy("").option("header","true").mode("overwrite").csv("/home/pankaj.singh/DataSet/userdata1.parquet_partition_6") //append


df1.withColumn("email",regexp_replace(df1.col("email"),"\\w","")).show()  //"@"


   */



val spark = SparkSession.builder().master("local[*]").appName("DF_Practice").getOrCreate()

  def main(args: Array[String]): Unit = {

/*    val df = spark.read.parquet("/home/pankaj.singh/DataSet/userdata1.parquet")

    df.show()

    //  df1.withColumn("email",regexp_replace(df1.col("email"),"\\w","")).show()

   // df1.withColumn("name",$"first_name").withColumn("name1",$"first_name").show()

    */

    val df1 = spark.read.format("parquet").option("header","true").option("inferSchema","true").load("/home/pankaj.singh/DataSet/userdata1.parquet")


    import spark.implicits._

    val myString = "first_name last_name ip_address"

    var df2 = df1

    val x = myString.split(" ")

    for(y <- x ) {
        df2 = df2.withColumn(y+"1", col(y))

    }

    df2.show()



    myString.toString.split(" ").foreach(x => {
      df2 = df2.withColumn(x+"2",col(x))
    } )

    df2.show()

    // static concat
   /* df2.select(concat($"ip_address2",lit(" "),$"last_name2")).show() */


    val z = myString.split(" ").map(x => col(x)).toSeq

    df2.withColumn("Concat",concat(z:_*)).show(false)











    /**   Parition By write data into directory  **/
/*
    val df_canada_text = spark.read.format("parquet").option("header","true").load("/home/pankaj.singh/DataSet/userdata1.parquet_Canada_text")

    df_canada_text.show()


    df1.withColumn("",$"country").write.partitionBy("").option("header","true").mode("Overwrite").text("/home/pankaj.singh/DataSet/userdata1.parquet_partition_6")

    df1.withColumn("id",$"id"-3).show()*/

    /**   Parition By write data into directory  **/




    /**  spark dataFame UDF **/
    /*
    val toupper = udf{ x :String =>

      x.toUpperCase
    }

    df1.withColumn("first_name",toupper($"first_name")).show()

*/


    def myfilter(df :DataFrame , id:String , value :Int): DataFrame ={

      val condition = List(("id",value))

      var  df2 = df

      //  condition.foreach( x => df= df.filter(col(x._1) < x._2))


      // df.filter(col(id) < value)
      df
    }

    myfilter(df2,"id",8 ).show()



  }

  def uppercase(x:String ):String = {

    x.toUpperCase
  }


  def myselect( df1:DataFrame, col1:String) :DataFrame ={
    df1.select(col1)
  }





}
