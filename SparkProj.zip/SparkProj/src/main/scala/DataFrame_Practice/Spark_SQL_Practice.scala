package DataFrame_Practice


import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

object Spark_SQL_Practice {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)

  val spark = SparkSession.builder().master("local[*]").appName("Spark_SQL_Practice").getOrCreate()

  def main(args: Array[String]): Unit = {

    val df1 = spark.read.format("parquet").option("header","true").option("inferSchema","true").load("/home/pankaj.singh/DataSet/userdata1.parquet")

    df1.show()

    df1.createOrReplaceTempView("mytable")

   val sparkSqlUdf = (x:String)=> {
      x.toUpperCase
    }


  spark.sqlContext.udf.register("myudf",sparkSqlUdf)

    spark.sql("select myudf(first_name) ,gender from mytable limit 4").show()
    

  }
}
