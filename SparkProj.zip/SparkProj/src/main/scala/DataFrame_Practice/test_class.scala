package DataFrame_Practice

import com.datastax.spark.connector.CassandraRow
import org.apache.log4j.{Level, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.joda.time.DateTimeZone
import org.joda.time.format.DateTimeFormat

object test_class {
  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)

  case class Person(birthyear:String,firstName:  String,sex:  String,lastName:  String,medium:  String)
  val spark = SparkSession.builder().master("local[*]").getOrCreate()


  def main(args: Array[String]): Unit = {

    val HistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2017-12-31 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2017-12-31 00:00:00.000+00:00", "elementvalue" -> "5"))
    ))

/*

    val fmt2 = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ssZZ")
    val x = fmt2.parseDateTime("2018-06-05 00:00:00.000+00:00").withZone(DateTimeZone.UTC)
    val fmt = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss")
    println(fmt)
*/



    HistoryRDD.map(r => (r.getDate("element_date")+" -> "+ r.getDateTime("element_date").toDateMidnight)).collect.foreach(println)
    HistoryRDD.map(r => (r.getDate("element_date")+" -> "+ r.getDateTime("element_date"))).collect.foreach(println)



    val df = spark.read.format("json").option("multiline", "true").load("/home/pankaj.singh/DataSet/test.json")
    import spark.implicits._
    df.show()

    df.select("id",   "father",   "mother",   "children").show(5,false)

    df.explain(true)
   /* val df2  =  df.
      explode[Seq[Person],  Person]("children",   "child")  {  v  =>  v.toList }

    df2.show()

    df2.select($"children.birthyear").show()*/
  }

}
