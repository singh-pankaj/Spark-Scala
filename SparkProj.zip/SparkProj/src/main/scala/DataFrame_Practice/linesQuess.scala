package DataFrame_Practice

import org.apache.avro.generic.GenericData.StringType
import org.apache.log4j.{Level, Logger}

import org.apache.spark.sql.{Encoder, Encoders, Row, SparkSession}

import scala.collection.mutable.ListBuffer

import org.apache.spark.sql.types.{StringType, StructField, StructType}


object lineQuess {
  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  val spark = SparkSession.builder().master("local[*]").appName("hh").getOrCreate()

  import spark.implicits._


  case class EncounterDiagnosis(  patientid:String
                                  ,encounterdate:String
                                  ,serviceprovidernpi:String
                                  ,serviceproviderlastname:String
                                  ,serviceproviderfirstname:String
                                  ,servicelocationid:String
                                  ,servicelocationname:String
                                  ,encounterdiagnosiscode:String
                                  ,encounterdiagnosistext:String
                                  ,encounterdiagnosiscategory:String
                                  ,encounterproblemtypecode:String
                                  ,encounterproblemtypetext:String
                                  ,documentationdate:String
                                  ,problemresolutiondate:String
                                  ,problemstatuscode:String
                                  ,problemstatustext:String
                                  , problemhealthstatuscode:String
                                  ,problemhealthstatustext:String
                                  ,negationind:String
                                  ,problemcomment:String
                                  ,problemonsetdate:String
                                  ,targetsitecode:String
                                  ,targetsitetext:String
                                  ,listorder:String
                                  ,encounterdiagnosiskey:String
                                  ,practiceuid:String
                                  //  ,batchuid:String
                               )


  // import spark.implicits._
  def main(args: Array[String]): Unit = {

    val df1 = spark.read.text("/home/pankaj.singh/DataSet/Encounter Section files/Clinical_Automatic_a11132be-9be6-41ac-bb51-57c4cad11c71_167be332-0a88-4ebd-8fb9-7f1ef03e9b68_8ff9928e-7288-4491-8aa0-c7e0da5bbba8_a11132be-9be6-41ac-bb51-57c4cad11c71_cb27e6c5-9860-4987-808c-c316d51f6c5 (1).txt")

    df1.map(f => f.toString().replace("\u0017", ",")
      .replaceAll(",,", ",null,").replace(",]", ",null")
      .replace("[", "").replace("]", ""))
      .map(r => r.split(",").grouped(26).toList).flatMap(p => p).filter(f => f.size == 26)
      .map(p => EncounterDiagnosis(p(0), p(1), p(2), p(3), p(4), p(5), p(6), p(7), p(8), p(9)
        , p(10)
        , p(11), p(12), p(13), p(14), p(15)
        , p(16), p(17), p(18), p(19), p(20), p(21), p(22), p(23), p(24), p(25))).show(125, false)


    val wrongformatdata11 = df1.map(f => f.toString().replace("\u0017", ",")
      .replaceAll(",,", ",null,").replace(",]", ",null")
      .replace("[", "").replace("]", ""))
      .map(r => r.split(",").grouped(26).toList).flatMap(p => p).filter(f => f.size != 26)


    val correctedDF = wrongformatdata11.rdd.map(r => (1, r.mkString(","))).reduceByKey((a, b) => {
      if (a.split(",").length % 26 == 0) a + "," + b
      else a + b
    }).map(r => r._2)


    correctedDF.map(r => r.toString.trim.split(",").grouped(26).toList).flatMap(p => p).map(x => x).map(p => EncounterDiagnosis(p(0), p(1), p(2), p(3), p(4), p(5), p(6), p(7), p(8), p(9)
      , p(10)
      , p(11), p(12), p(13), p(14), p(15)
      , p(16), p(17), p(18), p(19), p(20), p(21), p(22), p(23), p(24), p(25) /*, p(26)*/)).toDF().show(5, false)


    System.exit(0)


  }
}
