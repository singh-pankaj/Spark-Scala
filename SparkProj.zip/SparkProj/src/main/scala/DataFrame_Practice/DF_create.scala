package DataFrame_Practice

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.RDDInfo

import scala.collection.mutable.ArrayBuffer

object DF_create {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  val spark = SparkSession.builder().master("local[*]").appName("DF_Practice").getOrCreate()

  def main(args: Array[String]): Unit = {

    val data = Seq(("1","Pankja"),("2","SIngh"))

    val date = spark.sparkContext

    System.exit(0)
    val names = Array("Singh","Singh","Pankaj","Pankaj","Singh","Kumar","Kumar","Kamar")


 /*val cv = names.flatMap(r => r.split(",")).map(x =>(x,1))
   .reduce((z,b) => if(z._1.equals(b._1)) (z._1,(z._2+b._2)) else (z._1,z._2))*/

  val re=  names.groupBy(identity).mapValues(_.size)

    val c =re.toArray.sortBy(-_._2)
val arr: ArrayBuffer[Array[(String,Int)]]= ArrayBuffer()

    println("========")
    c.groupBy(_._2).foreach(x => {


      arr.append(x._2)
   /*   println(x._2)
      x._2.foreach(println)*/
    }
    )

    println("========")

    arr.foreach(println)

   // c.groupBy(_._2).toArray.sortBy(-_._1).foreach(x=> x._2.foreach(println))

   c.foreach(println)
  //  c.foreach(x => x._2.foreach(println))



   // println(cv)

    // ssabccdesa  s3a2bc2de

    System.exit(0)


    println(spark.sparkContext.startTime)

    println("PAn")
    println(spark.sparkContext.getExecutorMemoryStatus)
    val df1 = spark.read.format("parquet").option("header","true").option("inferSchema","true").load("/home/pankaj.singh/DataSet/userdata1.parquet")
    df1.show()
    df1.cache()
    println(spark.sparkContext.getExecutorMemoryStatus)
   /* val df12 = spark.read.format("parquet").option("header","true").option("inferSchema","true").load("/home/pankaj.singh/DataSet/userdata1.parquet")
    df12.show()
    df12.cache()*/
    println(spark.sparkContext.getExecutorMemoryStatus)
    println("PAn")

    println(spark.sparkContext.getExecutorMemoryStatus)
    //Map(192.168.104.123:40128 -> (16990076928,16990076928))

    val rddinfo : ArrayBuffer[RDDInfo]= ArrayBuffer()
    spark.sparkContext.getRDDStorageInfo.foreach(x => rddinfo.append(x))
    rddinfo.foreach(println)


  }

}
