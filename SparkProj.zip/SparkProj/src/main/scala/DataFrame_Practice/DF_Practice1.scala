package DataFrame_Practice

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

object DF_Practice1 {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  val spark = SparkSession.builder().master("local[*]").appName("sparkSql_Practice").getOrCreate()

  def main(args: Array[String]): Unit = {


/*    val df = spark.read.format("parquet").option("header","true").option("inferSchema","true").load("/home/pankaj.singh/DataSet/userdata1.parquet")

    import spark.implicits._

    df.show(3,false)

   // df.select("gender").distinct().show()

 //   df.select("title").distinct().show(100, false)

    val bycountry = Window.partitionBy("country")

  /*  df.withColumn("avg", max("salary").over(bycountry)).show(3,false)*/

    df.select(col = "first_name","last_name","salary","country").withColumn("avg", max("salary").over(bycountry)).show(3,false)

    val maxsal = Window.partitionBy("country").orderBy()/*orderBy("salary")*/

    df.select(col = "first_name","last_name","salary","country").withColumn("rank",dense_rank().over(maxsal)).show(3)*/


    val df_csv = spark.read.format("csv").option("header","true").option("inferSchema","true").load("/home/pankaj.singh/DataSet/mycsv.csv")

    df_csv.show(10,false)

   /* val ranking = Window.partitionBy("company").orderBy(desc("count"))

/*    val companyrank =*/

    df_csv.withColumn("maxcount", max("count").over(ranking)).show(100,false)*/

    // *****************************************************************************************************

    val w = Window.partitionBy("company")

    val w1 = Window.partitionBy("maxcount")

    df_csv.withColumn("maxcount", max("count").over(w)).orderBy(desc("maxcount"),desc("count"))
     .select("company","count")
     .show(100,false)

// **********************************************************************************************************




 val ranking = Window.partitionBy("company")/*.orderBy("count")*/

    df_csv.withColumn("maxcount", max("count").over(ranking)).orderBy(desc("maxcount")).show(100,false)


   val rank_company=  df_csv.groupBy("company").max("count").orderBy(desc("max(count)")).withColumnRenamed("max(count)","highestcount")


    /*.show(3,false)*/

    rank_company.show(5,false)



    val finaldf =rank_company.select("company").withColumnRenamed("company","company_old").join(df_csv.select("company","count"),rank_company("company_old") === df_csv("company"))/*.show(122,false)*/

    /*finaldf.show(100)
    finaldf.printSchema()
*/
  //  finaldf.select("company","count").show(122,false)

 //   finaldf.select("company","count").orderBy("count").show(100,false)

}

}
