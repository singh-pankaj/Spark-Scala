package DataFrame_Practice

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.catalyst.expressions.aggregate.Sum
import org.apache.spark.sql.functions._

object DF_Prac {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  val spark = SparkSession.builder().master("local[*]").getOrCreate()


  def main(args: Array[String]): Unit = {

    val patientHistory = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load("/home/pankaj.singh/DataSet/test1.csv").toDF()
    patientHistory.show(12)

import spark.implicits._
    patientHistory.groupBy("company").agg(avg("count").as("avg")).show(12)

    patientHistory.groupBy("company").count().show(12)


    val patientHistory2 = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load("/home/pankaj.singh/DataSet/test2.csv").toDF()

    patientHistory2.show()

    patientHistory.join(patientHistory2,Seq("company"),"Full_outer").show(12)

    patientHistory.join(patientHistory2,patientHistory.col("company").as("df1") === patientHistory2.col("company")).show(12)


    patientHistory.join(patientHistory2,patientHistory.col("company").as("df1") === patientHistory2.col("company"),"cross").show(100)


    patientHistory.as("df1").join(patientHistory2.as("df2"),$"df1.company" === $"df2.company","inner").select($"df1.company",$"df2.company")show(100)

println("***********************************8")
    patientHistory.join(patientHistory2,patientHistory.col("company").as("df1") === patientHistory2.col("company"),"left").show(100)
    patientHistory.join(patientHistory2,patientHistory.col("company").as("df1") === patientHistory2.col("company"),"left_outer").show(100)
    patientHistory.join(patientHistory2,patientHistory.col("company").as("df1") === patientHistory2.col("company"),"left_semi").show(100)
    patientHistory.join(patientHistory2,patientHistory.col("company").as("df1") === patientHistory2.col("company"),"leftanti").show(100)

    println("+++++++++++++++++++++++++++++++++++++++++++")
    patientHistory.join(patientHistory2,patientHistory.col("company").as("df1") =!= patientHistory2.col("company"),"inner").show(100)

    //'inner', 'outer', 'full', 'fullouter', 'full_outer', 'leftouter', 'left', 'left_outer', 'rightouter', 'right', 'right_outer', 'leftsemi', 'left_semi', 'leftanti', 'left_anti', 'cross'

  }

}
