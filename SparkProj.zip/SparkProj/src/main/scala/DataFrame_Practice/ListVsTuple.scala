package DataFrame_Practice

object ListVsTuple {

  def main(args: Array[String]): Unit = {

    case class Student(name: String, roll_no :Int)

    val myList = List(("a",23,Student("",2)))

    val mytuple = (23,"dd")

   // myList.foreach(x => x.)

  }

}
