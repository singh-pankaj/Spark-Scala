import com.datastax.spark.connector.{CassandraRow, CassandraRowMetadata}
import org.scalatest.FunSuite

class mytest extends  FunSuite{

  test("My Second test") {

    assert(add(2, 4) == 8)
    println("run 3")
    val x = ""

    //val zx:IndexedSeq[AnyRef] = [0,1,2]
    //assert(com.figmd.janus.measureComputation.qppMeasures.QPP226_5.mycheck(CassandraRow(x:CassandraRowMetadata,y: IndexedSeq[AnyRef]) ,"IPP",Seq("E1","E2")) == "P1 E1 0"  )

  }


  test("My first test") {

    assert(1 == 1)
    println("run")
    // assert(1==2)

    assert(add(2, 4) == 6)
    println("run 2")

    val x = ""

  //  assert(com.figmd.janus.measureComputation.qppMeasures.QPP226_5.mycheck(CassandraRow{} ,"IPP",Seq("E1","E2")) == "P1 E1 0")


  //  r.getString("patientuid") + " " + Element(x) + " " + element_value
    //  add(2,2) should be =1



  }




def add(x:Int,y:Int):Int={

  return x+y
}

}
