import java.text.SimpleDateFormat
import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraRDD
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.scalatest._

import scala.collection.mutable

class mytest2 extends FunSuite with Matchers {



  val spark = SparkSession.builder().appName("My practice").master("local[*]").getOrCreate()



test("test2_1"){

  def mostRecentElementList(historyRDD: RDD[CassandraRow], Element: String*): List[CassandraRow] = {

    println("xxxxxx")

    historyRDD.map( x => x.getDate("element_date")).foreach(println)

    val mostRecentElements = historyRDD.filter(l => !l.isNullAt("element") && !l.isNullAt("element_date")

      && Element.contains(l.getString("element").toLowerCase))

      .map(l => ((l.getString("patientuid"), l.getString("element")),l.getDate("element_date")))

      .reduceByKey((x, y) => if (x.after(y)) x else y)
      //.map(z => CassandraRow.fromMap(Map("patientuid" -> z._1._1, "element" -> z._1._2, "element_date" -> z._2, "elementvalue" -> z._2) ))
      .collect().toList


    println("mostRecentElements=========")
    //z => (z._1._1,z._1._2,z._2))

    mostRecentElements.foreach(println)

    val xc = historyRDD.filter( r => mostRecentElements.forall( x => x._1._1.equalsIgnoreCase(r.getString("patientuid")) && x._1._2.equalsIgnoreCase(r.getString("element"))

      && x._2.equals(r.getDate("element_date"))
    )).collect().toList

    println("xc=========")
    xc.foreach(println)

    xc
  }

  val HistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
    CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00", "elementvalue" -> "5")),
    CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-30 00:00:00.00", "elementvalue" -> "5")),
    CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hype", "element_date" -> "2018-02-30 00:00:00.00", "elementvalue" -> "5"))
  ))
 // val historyLookUp = new HistoryLookUpUtility()

 // val m = MeasureProperty(null, null)

  mostRecentElementList(HistoryRDD,"mere")









  val r: CassandraRow = CassandraRow.fromMap(Map("patientuid" -> "P1", "checkdate" -> "2018-05-01 00:00:00.00","Mere" -> "2015-09-09 00:00:00"))
  // : CassandraRow, conditionType: String, measureName: String, checkDate:String, startDate: Date, no_of_Days: Int)
println("sdsd")
  println(r.getDate("checkdate")+" "+r.getString("checkdate"))

  val xc= getMonthDiff(r.getDate("checkdate"),r.getDate("Mere"))
  println("xc "+ xc)

  var SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd")
  val startdate = SIMPLE_DATE_FORMAT.parse("2018-05-01 00:00:00.00")  //("2018-12-31")
  println("startdate "+startdate)

 /* val x1 = new  com.figmd.janus.util.application.DateUtility

  val xc= x1.checkDaysDiff_Less(r.getString("checkdate"),startdate,2)

  println("xc is "+xc)
*/
  val x = new  com.figmd.janus.util.measure.MeasureUtility()

  val result = x.isElementDateStartAfterStartOfWithInDaysWithStartDate(r,"IPP","MEASURE","checkdate",startdate,92)

println("resut "+ result)


  /*

  val row1:CassandraRow = CassandraRow.fromMap(Map("patientuid" -> "P1", "MeRe_1" -> "2018-05-02 00:00:00.00","MeRe_1" -> "2018-12-31 00:00:00"))


  var dob_1 = row1.getDate("dob")
//  var encounterdate = row1.getDate("encounterdate")
  println("dob encounterdate"+dob_1)


  val row:CassandraRow = CassandraRow.fromMap(Map("patientuid" -> "P1", "E1" -> "0","E2" ->"0" ))


  val a:String = "abc"



  val pan = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load("/home/pankaj.singh/Downloads/Sample.csv")

  pan.show()
*/
  //val pank = pan.asInstanceOf[CassandraRDD]
 // val x = row.asInstanceOf[CassandraRDD[CassandraRow]]

 // x.take(2).foreach(println)

 // pank.foreach(r => r.getS)

 // println(x)
 // println("df")



  //val  rdd: RDD[CassandraRow] = a.map(c => CassandraRow("patientuid" -> "sd"))

 // println(row.getString("patientuid"))
//  println(row.getString("E1"))
//  println(row.getString("E2"))

//  var cx: Seq[String] = Seq("E1","E2")

 // for(x1 <- cx){
 //   println(x1)
 // }

 /* var in = com.figmd.janus.measureComputation.qppMeasures.QPP226_5.mycheck(row,"IPP",Seq("E1","E2"))
  println(in)


  com.figmd.janus.measureComputation.qppMeasures.QPP226_5.mycheck(row,"IPP",Seq("E1","E2")) should be ("P1 E1 0,,P1 E2 1")
*/

}

/*

  test("test2_2"){

    val row1:CassandraRow = CassandraRow.fromMap(Map("patientuid" -> "P1", "E1" -> "1","E2" ->"1" ))

    var in = com.figmd.janus.measureComputation.qppMeasures.QPP226_5.mycheck(row1,"IPP",Seq("E1","E2"))
    println(in)

    com.figmd.janus.measureComputation.qppMeasures.QPP226_5.mycheck(row1,"IPP",Seq("E1","E2")) should be ("P1 E1 1,,P1 E2 0")


  }
*/



  def add(x:Int,y:Int):Int={

    return x+y
  }

  // Date Utility
  def getMonthDiff(startDate:Date,endDate:Date):Int={

    import java.util.Calendar
    import java.util.GregorianCalendar

    val startCalendar = new GregorianCalendar
    startCalendar.setTime(startDate)
    val endCalendar = new GregorianCalendar
    endCalendar.setTime(endDate)

    val diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR)
    val diffMonth = diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH)

  //  println("diffrence is " + diffMonth)
    return Math.abs(diffMonth)


  }


}
