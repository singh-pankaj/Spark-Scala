package com.figmd.janus.util.measure

import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.figmd.janus.WebDataMartCreator
import org.apache.spark.broadcast.Broadcast
import org.joda.time.DateTime
import java.time.format.DateTimeFormatter

import com.figmd.janus.util.application.FileUtility


object HistoryLookUpUtility {


  import java.util.Date

  import com.datastax.spark.connector.{CassandraRow, _}
  import com.figmd.janus.WebDataMartCreator.prop
  import org.apache.spark.rdd.RDD
  import org.apache.spark.sql.SparkSession


  //Seq[String]
  def getPatientHistory(sparkSession: SparkSession, rdd: RDD[CassandraRow], Element: String*): List[CassandraRow] = {

    var element: List[String] = Element.toList

   /* println("####Element###")
    element.foreach(println)
    println("####Element###")
*/
    // var ipp_patient_list:List[String]= List("A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD","A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD","D3C62DE3-F2D6-4DFA-9DE7-CC82BA4E834F","22C162BA-0986-4034-9312-D6EDCEAB8556")

    var IPP_Patient_List = rdd.map(l => l.getString("patientuid")).collect().toList

   /*
    println("####Patient List###")
    IPP_Patient_List.foreach(println)
    println("####Patient List###")
*/

    val historyRDD = sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart_history"),
      prop.getProperty("patientHistory")).select("patientuid", "element", "element_date", "elementvalue")
      .filter(r => IPP_Patient_List.contains(r.getString("patientuid")) && element.contains(r.getString("element").toLowerCase()) && !r.isNullAt("element_date")).collect().toList


    return historyRDD

  }


  def isDateOverlapsLessOrEqualHistory(r: CassandraRow, conditionType: String, measureName: String, elementDate:String, histroyElement: String): Boolean = {
    // val r:CassandraRow = CassandraRow.fromMap(Map("patientuid" -> "0E04D1A5-D34C-4000-9AF4-6A70AEA0429D", "MeRe_1" -> "1","MeRe_1_date" -> "2015-09-09 00:00:00.00"))
    val fileUtility = new FileUtility();
    var dateTimeFormat = fileUtility.getProperty("date.time.format");
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateTimeFormat)
    //val eledate = SIMPLE_DATE_FORMAT.parse(r.getString(elementDate));
    val eledate= LocalDateTime.parse(r.getDate(elementDate).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    var flag = false
    val query="select count(1) from "+prop.getProperty("keyspace_datamart")+".patient_history where patientuid='"+ r.getString("patientuid").toUpperCase +
      "' and element='"+histroyElement+"' and "+"element_date<='"+eledate+"'  ALLOW FILTERING ;"

  //  println(query+" "+WebDataMartCreator.sessionobj.execute(query).one().getLong(0))
    if (WebDataMartCreator.sessionobj.execute(query).one().getLong(0) > 0)
   //   if (!WebDataMartCreator.sessionobj.execute(query).all().isEmpty && !r.isNullAt(elementDate))
    {true;}
    else{false;}
  }


  def isDateOverlapsLessOrEqualHistory(r: CassandraRow, conditionType: String, measureName: String, elementDate: String, histroyElement: String, patientHisrtroyList: List[CassandraRow]): Boolean = {

    //  val r:CassandraRow = CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "mere_1" -> "1","mere_1_date" -> "2014-09-09 00:00:00.00"))

    var flag = false
    for (x <- patientHisrtroyList) {

      if (!r.isNullAt(elementDate) && !x.isNullAt("element_date")

        && r.getString("patientuid").equals(x.getString("patientuid"))

        && histroyElement.toLowerCase.equals(x.getString("element").toLowerCase) &&


        (x.getDateTime("element_date").isBefore(r.getDateTime(elementDate))
        || x.getDateTime("element_date").isEqual(r.getDateTime(elementDate)))
      )

        flag = true


    }

    return flag


  }


  def startAfterStartOfHistory(r: CassandraRow, conditionType: String, measureName: String, elementDate: String, histroyElement: String, patientHisrtroyList: List[CassandraRow]): Boolean = {

    var flag = false

    for (x <- patientHisrtroyList) {

      if (!r.isNullAt(elementDate) && !x.isNullAt("element_date")

        && r.getString("patientuid").equals(x.getString("patientuid"))

        && histroyElement.toLowerCase.equals(x.getString("element").toLowerCase) &&

        x.getDateTime("element_date").isAfter(r.getDateTime(elementDate))

      )
        flag = true


    }

    return flag
  }


  def startBeforeOrConcurrentStartOfMeasurementPeriodHistory(r: CassandraRow, conditionType: String, measureName: String, startDate: Date, histroyElement: String, month: Int, patientHisrtroyList: List[CassandraRow]): Boolean = {

    var flag = false

    val Start_Date = new DateTime(startDate)

    for (x <- patientHisrtroyList) {

      if (!x.isNullAt("element_date")

        && r.getString("patientuid").equals(x.getString("patientuid"))

        && histroyElement.toLowerCase.equals(x.getString("element").toLowerCase)

        && (Start_Date.minusMonths(month).isBefore(x.getDateTime("element_date"))
        || Start_Date.minusMonths(month).isEqual(x.getDateTime("element_date")))

      )

        flag = true

    }

    return flag
  }


  def startBeforeStartOfMeasurementPeriodHistory(r: CassandraRow, conditionType: String, measureName: String, startDate: Date, histroyElement: String, month: Int, patientHisrtroyList: List[CassandraRow]): Boolean = {

    var flag = false

    val Start_Date = new DateTime(startDate)

    for (x <- patientHisrtroyList) {

      if (!x.isNullAt("element_date")

        && r.getString("patientuid").equals(x.getString("patientuid"))

        && histroyElement.toLowerCase.equals(x.getString("element").toLowerCase)


        && Start_Date.minusMonths(month).isBefore(x.getDateTime("element_date"))

      )

        flag = true

    }

    return flag
  }


  def startAfterOrConcurrentWithStartOfMeasurementPeriodHistory(r: CassandraRow, conditionType: String, measureName: String, startDate: Date, histroyElement: String, month: Int, patientHisrtroyList: List[CassandraRow]): Boolean = {

    var flag = false

    val Start_Date = new DateTime(startDate)

    for (x <- patientHisrtroyList) {

      if (!x.isNullAt("element_date")

        && r.getString("patientuid").equals(x.getString("patientuid"))

        && histroyElement.toLowerCase.equals(x.getString("element").toLowerCase)


        && (Start_Date.minusMonths(month).isAfter(x.getDateTime("element_date"))
        || Start_Date.minusMonths(month).isEqual(x.getDateTime("element_date")))

      )

        flag = true

    }

    return flag
  }


  def startAfterStartOfMeasurementPeriodHistory(r: CassandraRow, conditionType: String, measureName: String, startDate: Date, histroyElement: String, month: Int, patientHisrtroyList: List[CassandraRow]): Boolean = {

    var flag = false

    val Start_Date = new DateTime(startDate)

    for (x <- patientHisrtroyList) {

      if (!x.isNullAt("element_date")

        && r.getString("patientuid").equals(x.getString("patientuid"))

        && histroyElement.toLowerCase.equals(x.getString("element").toLowerCase)

        && Start_Date.minusMonths(month).isAfter(x.getDateTime("element_date"))

      )

        flag = true

    }

    return flag
  }


  //Pankaj 26 Nov
  def startBeforeStartOfEncounterDateHistory(r: CassandraRow, conditionType: String, measureName: String, elementDate: String, histroyElement: String, patientHisrtroyList: Broadcast[List[CassandraRow]]): Boolean = {

    var flag = false

    // val Start_Date = new DateTime(startDate)

    for (x <- patientHisrtroyList.value ) {

      if (!x.isNullAt("element_date") &&  !r.isNullAt(elementDate)

        && r.getString("patientuid").equals(x.getString("patientuid"))

        && histroyElement.toLowerCase.equals(x.getString("element").toLowerCase)


        && (x.getDateTime("element_date").isBefore(r.getDateTime(elementDate))
        || x.getDateTime("element_date").isEqual(r.getDateTime(elementDate)))


      )

        flag = true

    }

    return flag
  }



  //Pankaj 26 Nov
  def startBeforeOrConcurrentStartOfMeasurementPeriodHistory(r: CassandraRow, conditionType: String, measureName: String, elementDate: String, histroyElement: String, month: Int, patientHisrtroyList: List[CassandraRow]): Boolean = {

    var flag = false

    val Start_Date = r.getDateTime("elementDate") //new DateTime(startDate)

    for (x <- patientHisrtroyList) {

      if (!x.isNullAt("element_date")

        && r.getString("patientuid").equals(x.getString("patientuid"))

        && histroyElement.toLowerCase.equals(x.getString("element").toLowerCase)

        && (Start_Date.minusMonths(month).isBefore(x.getDateTime("element_date"))
        || Start_Date.minusMonths(month).isEqual(x.getDateTime("element_date")))

      )

        flag = true

    }

    return flag
  }


  /**
    * def getpatientHistoryNewRDD(sparkSession: SparkSession,rdd: RDD[CassandraRow],Element:String*): RDD[CassandraRow]= {
    * *
    * var element:List[String] = Element.toList
    * println("####Element####")
    *element.foreach(println)
    * println("####Element####")
    * *
    * var ipp_patient_list:List[String]= List(" A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD","A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD","D3C62DE3-F2D6-4DFA-9DE7-CC82BA4E834F","22C162BA-0986-4034-9312-D6EDCEAB8556")
    * *
    *
    * var IPP_Patient_List=rdd.map(l=>l.getString("patientuid")).collect().toList
    *IPP.take(5).foreach(println)
    * *
    * val historyRDD = sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart_history"),
    *prop.getProperty("patientHistory")).select("patientuid", "element", "element_date","elementvalue")
    * .filter(r => ipp_patient_list.contains(r.getString("patientuid")) && element.contains((r.getString("element")).toLowerCase()))
    */
  /** .map(x => (x.getString("patientuid"),
    * /*   *//
    * if (!x.isNullAt("element")) x
    * .getString("element")
    * else ""
    * ,
    * /**
    * *
    * def getpatientHistoryNewList(sparkSession: SparkSession,rdd: RDD[CassandraRow],Element:String*): List[CassandraRow]= {
    * *
    * var element:List[String] = Element.toList
    * *
    */
    * println ("####Element####")
    * element.foreach (println)
    * println ("####Element####")
    * *
    * var ipp_patient_list: List[String] = List (" A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "D3C62DE3-F2D6-4DFA-9DE7-CC82BA4E834F", "22C162BA-0986-4034-9312-D6EDCEAB8556")
    */


}





