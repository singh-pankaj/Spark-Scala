package com.figmd.janus.measureComputation.qppMeasures

import java.util

import com.datastax.driver.core.Cluster
import org.joda.time.DateTime

import scala.util.control.Breaks
import scala.util.control.Breaks._

object mycheck {

  def main(args: Array[String]): Unit = {

    var req = new java.util.ArrayList[Int]()


    req.add(1)
    req.add(5)
    req.add(7)
    req.add(10)

/*
println("Ssss")
    println(req.toArray.toList.span( x => x.asInstanceOf[Integer] == 5))


    val mylist = req.toArray.toList

    println("MyList   "+ mylist)


  println(mylist.span(_.equals("5")))
*/

    val my_list : List[Int]= List(1, 2, 3, 4, 5, 6, 7, 8, 9)

    println("my lost   "+my_list)

   /* println(my_list.takeWhile(_ == 5))
*/

    //println(req)
 /*   println(req.toArray)
    println(req.toArray.contains(1))
    println(req.toArray.toList.contains(1))*/

    //loops.break
      var loops = new Breaks

    loops.breakable{

      for(x <- my_list){
        if(x == 5){
          println(x)
          loops.break
        }
println(x)
      }
    }

/*val z:Int = 1
    var next_value = ""
var flag= false


println(next_value)*/

    var my = 1

   // req.toArray.foreach(println)
    /*val x =req.toArray.map( r => r.asInstanceOf[Integer]).foreach(r => if(r > 5) return)
    println(x)*/
/*req.toArray.map(x => x.).takeWhile(r => 3 < r.t).foreach(println)*/
   // xc.foreach(println)

 /*   var zc = 4
    var c=""
    while(zc < req.toArray.asInstanceOf[Integer]){
      println(zc)
      c=req.toArray.asInstanceOf[Integer].toString
    }

    println(c)*/

  }



/*           val cluster = Cluster.builder()
          .addContactPoint("10.20.201.152")
          .withPort(9042)
          .build()

          val session = cluster.connect()

      //  def getValueFromCassandraTable() = {
            val ex = session.execute("SELECT * FROM aao_new_datamart.tblencounter limit 1")
        println(ex)
      //  }




    val c=List(2,2,3).forall(x => x < 3)
    println(c)

    val d=List(2,2,3).exists(x => x < 3)
    println(d)*/

/*
        val x:Any = new DateTime("")
    val x: Any = "start"
    def f[T](v: T) = x match {
        case _: Int    => "Int"
        case _: String => "String"
        case _         => "Unknown"
    }

       println(f())*/

 /* }*/


}
