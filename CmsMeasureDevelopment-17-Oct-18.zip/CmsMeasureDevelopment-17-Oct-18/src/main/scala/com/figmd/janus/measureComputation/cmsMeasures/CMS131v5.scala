package com.figmd.janus.measureComputation.cmsMeasures

import java.util.Date

import com.figmd.janus.Measure
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator.prop
import com.figmd.janus.util.measure.MeasureUtility

object CMS131v5 extends  MeasureUtility with Measure{

    // Logic for measure refresh
    def refresh(sparkSession: SparkSession,rdd:RDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

      var columnRef = getFiledList(MEASURE_NAME)
          var patientHistoryRDD = sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"),
            prop.getProperty("patientHistory")).select("patientuid","reordieyex","reordieyex_date")


      // Filter IPP
      val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
      ippRDD.cache()

      val CRA = getBackTrackingList(patientHistoryRDD, ippRDD, "reordieyex","reordieyex_date");
      val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)


      // Eligible IPP
      val eligibleRdd = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Exclusions
      val notEligibleRDD =ippRDD.subtract(ippRDD)
      eligibleRdd.cache()
      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD,startDate: Date,endDate: Date,MEASURE_NAME)
      exclusionRDD.cache()
      // Filter Intermediate
      val intermediateA =  getSubtractRDD(ippRDD,exclusionRDD)
      intermediateA.cache()
      // Filter Met
      val metRDD = getMet(intermediateA,startDate: Date,endDate: Date,MEASURE_NAME,CRA_list: Broadcast[List[String]])
      metRDD.cache()
      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter not meate
      val notMetRDD =  getSubtractRDD(intermediateA,metRDD)
      notMetRDD.cache()

      saveToWebDM(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

    }

    // Filter IPP
    def getIpp(rdd:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
      rdd
        .filter(r =>
          (
            checkElementPresent(r, IPP, MEASURE_NAME,"diab_1")&&
            isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME,"diab_1_date","encounterdate")
            &&
              isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)
            &&
              isAgeLess(r, IPP, MEASURE_NAME, "dob", "encounterdate", 75)

            &&
              (
                checkElementPresent(r, IPP, MEASURE_NAME,"ofvi_1")&&
                isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"ofvi_1_date",startDate,endDate)
                ||
                checkElementPresent(r, IPP, MEASURE_NAME,"fain")&&
                isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"fain_date",startDate,endDate)
                ||
                checkElementPresent(r, IPP, MEASURE_NAME,"prcaseesofvi18anup_1")&&
                isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"prcaseesofvi18anup_1_date",startDate,endDate)
                ||
                checkElementPresent(r, IPP, MEASURE_NAME,"prcaseofvi18anup_1")&&
                isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"prcaseofvi18anup_1_date",startDate,endDate)
                ||
                checkElementPresent(r, IPP, MEASURE_NAME,"hohese")&&
                isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"hohese_date",startDate,endDate)
                ||
                checkElementPresent(r, IPP, MEASURE_NAME,"anwevi_1")&&
                isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"anwevi_1_date",startDate,endDate)
                ||
                checkElementPresent(r, IPP, MEASURE_NAME,"opse")&&
                isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"opse_date",startDate,endDate)
              )

            )
        )
    }

    def getExclusionRdd(eligibleRdd:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {

      eligibleRdd.filter(r => (
        checkElementPresent(r, EXCLUSION, MEASURE_NAME, "enin_1")&&
        (
          isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME,"ditohofohoca_date",startDate,endDate)
          ||
          isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME,"ditohecafafohoca_date",startDate,endDate)
        )
        ||
        checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hocaam")
        )
      )
    }

    def getMet(intermediateA:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String,CRA_list: Broadcast[List[String]]): RDD[CassandraRow] = {

      intermediateA.filter(r => (
        checkElementPresent(r, MET, MEASURE_NAME, "reordieyex")
        &&
        BackTracking(r, MET, MEASURE_NAME, CRA_list,startDate)
        ||
        isDuringMeasurementPeriod(r, MET, MEASURE_NAME, "reordieyex_date",startDate,endDate)


      )
      )
    }

  def BackTracking(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]], startDate: Date): Boolean = {
    val flag = false;

    for (x <- CRA.value) {
      if (x != "") {

        val back_data = x.split("~")
        val patientid = back_data(0);
        val reordieyex_element = back_data(1);
        val reordieyex_date_element_date = dateUtility.dateTimeParse(back_data(2)); //nefi_date-74


        if ((!r.isNullAt("nefi"))
          && ((r.getString("patientuid").equals(patientid) || r.getString("patientuid") == patientid)
          && (
          reordieyex_element == "1"
            &&
            r.getDateTime("nefi_date").minusMonths(12).isBefore(reordieyex_date_element_date)
          )
          //)
          )
        ) {

          return true;

        }

      }

    }

    return flag;

  }

  def getBackTrackingList(patientHistoryRDD: RDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement2: String): List[String] = {
    if(!ippRDD.isEmpty && !patientHistoryRDD.isEmpty()) {
    val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).collect().toSet //patientuid

    val IPPFilterExclusionRDD = patientHistoryRDD.map(x=>(
      if(!x.isNullAt("patientuid"))x.getString("patientuid")else "",
      if(!x.isNullAt("reordieyex"))x.getString("reordieyex")else "",
      if(!x.isNullAt("reordieyex_date"))x.getString("reordieyex_date")else "")).filter(x => ipp_patient_list.contains(x._1))


        var CRA = IPPFilterExclusionRDD.map(x =>
          if (x._1.isEmpty && x._2.isEmpty && x._3.isEmpty) {
            x._1 + "~" + x._2 + "~" + x._3
          }
          else ""
        )
          .collect()
          .toList

         CRA;

  }

  else {
    val l=List[String]()
    l
  }
  }





}
