package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.figmd.janus.Measure
import com.figmd.janus.util._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator.prop
import com.figmd.janus.util.measure.MeasureUtility

object QPP1317 extends MeasureUtility with Measure {



  def refresh(sparkSession: SparkSession,rdd:RDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    //Backtracking from History Table
    var columnRef = getFiledList(MEASURE_NAME)
    var patientHistoryRDD =  sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"),
      prop.getProperty("patientHistory")).select("patientuid","syblpr", "syblpr_date","diblpr","diblpr_date")



    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()

    /*val test =ippRDD.map(l=>l.columnValues(34))

      test.foreach(println)*/

    //.collect().foreach(println)

  /*  test.collect().foreach(println)*/

    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

/*    //MostRecent Backtracking Element
    var notnullRDD =rdd.filter(r=>(!r.isNullAt("patientuid")&& !r.isNullAt("syblpr_date")&& !r.isNullAt("diblpr_date")))
    val syblprRdd = (notnullRDD.map(r =>((r.columnValues(3),r.getString("syblpr")),r.columnValues(34))).reduceByKey((x, y) => Ordering[Date].max(dateUtility.dateParse(convertDateToYYYYDDMM(x.toString)), dateUtility.dateParse(convertDateToYYYYDDMM(y.toString)))))
    val diblprRdd = (notnullRDD.map(l => ((l.columnValues(3),l.getString("diblpr")),l.columnValues(35))).reduceByKey((x, y) => Ordering[Date].max(dateUtility.dateParse(convertDateToYYYYDDMM(x.toString)), dateUtility.dateParse(convertDateToYYYYDDMM(y.toString)))))

    //Join MostRecent Backtracking
    val syblprMostRdd= syblprRdd.keyBy(l=>l._1._1)
    val diblprMostRdd= diblprRdd.keyBy(l=>l._1._1)
    val MostRecentRDD=syblprMostRdd.fullOuterJoin(diblprMostRdd)*/

    val mostRecentRDD = mostRecent317(patientHistoryRDD,ippRDD,MEASURE_NAME)

    //mostRecentRDD.collect().foreach(println)



    // Call BackTracking Function
    val CRA = getBackTrackingList(mostRecentRDD, ippRDD,"syblpr", "syblpr_date","diblpr","diblpr_date");
    val BackTrackingMostList: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)

    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getinterRDD(ippRDD,exclusionRDD)
    intermediateA.cache()
    // Filter Met
    //met
    val metRDD = getMet(intermediateA,MEASURE_NAME,startDate: Date, endDate: Date,BackTrackingMostList: Broadcast[List[String]])
    metRDD.cache()

    // Filter Exceptions
    val intermediateB = getinterRDD(intermediateA,metRDD)
    intermediateB.cache()

    val exceptionRDD =getexceptionRDD(intermediateB,MEASURE_NAME,startDate, endDate)
    exceptionRDD.cache()

    // Filter not meate
    val notMetRDD =  getinterRDD(intermediateB,exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }
  // Filter IPP
  def getIpp(rdd:RDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    rdd
      .filter(r =>

        isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&
          (
            (
              isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)
              )
              &&
              (checkElementPresent(r, IPP, MEASURE_NAME, "bpscenco") &&
                isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "bpscenco_date", startDate, endDate))
              &&
              (
                checknull(r, IPP, MEASURE_NAME, "eddeptvist_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "extreruptd_tm1") ||
                  checknull(r, IPP, MEASURE_NAME, "cerv1_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "initpv1_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "annlwelnsv_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "em_thmd") ||
                  checknull(r, IPP, MEASURE_NAME, "ov_thmdmod95") ||
                  checknull(r, IPP, MEASURE_NAME, "pci18_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "pcseov18_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "psyv_de_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "os_thmd") ||
                  checknull(r, IPP, MEASURE_NAME, "hmhlthsrvc_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "nrsnfcltvst_tm") ||
                  checknull(r, IPP, MEASURE_NAME, "csltrf_tm")
                ) &&
              (
                checknull(r, IPP, MEASURE_NAME, "telehealth")
                )
            )


      )
  }

  //Exclusion

  def getExclusionRdd(ippRDD: RDD[CassandraRow], MEASURE_NAME: String): RDD[CassandraRow] = {
    ippRDD.filter(r =>
      (
        checkElementPresent(r, MET, MEASURE_NAME, "diofhy") &&
          isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "diofhy_date", "bpscenco_date")
        )
        ||
        (
          checkElementPresent(r, MET, MEASURE_NAME, "scrnbp_patinelig") &&
            isDateEqual(r, MET, MEASURE_NAME, "scrnbp_patinelig_date", "bpscenco_date")
          )
    )
  }

  /* MostRecent element Rename  ****************** DO NOt REMOVED***********

        MostRecentBP_QPP=DiBlPr,
        MostRecentSP_QPP=SyBlPr,
        MostRecentSP_QPP_Date=syblpr_date,
        MostRecentBP_QPP_Date=diblpr_date
        LastYearMostRecentBP_QPP=DiBlPr,
        LastYearMostRecentSP_QPP=SyBlPr,
        LastYearMostRecentSP_QPP_Date=syblpr_date,
        LastYearMostRecentBP_QPP_Date=diblpr_date

        */



  def getMet(intermediateA:RDD[CassandraRow],MEASURE_NAME:String,startDate: Date, endDate: Date,BackTrackingMostList: Broadcast[List[String]]): RDD[CassandraRow] = {
    intermediateA.filter(r => (
      (
        (
          !r.isNullAt("syblpr") && isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "bpscenco_date", "syblpr_date"))
          && (!r.isNullAt("diblpr") && isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "bpscenco_date", "diblpr_date"))
        )
        &&
        (
          (
            (isDateEqual(r, MET, MEASURE_NAME, "syblpr_date", "bpscenco_date") &&
              chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr", 120))
              &&
              (isDateEqual(r, MET, MEASURE_NAME, "diblpr_date", "bpscenco_date") &&
                chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr", 80))
            )
            ||
            (
              (
                (
                  (chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "syblpr", 120) &&
                    chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr", 140)
                    ) &&
                    (
                      chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr", 90)
                      )
                  ) ||
                  (
                    (chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "diblpr", 80) &&
                      chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr", 90)
                      ) &&
                      (
                        chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr", 140)
                        )
                    )
                ) &&
                (
                  (// Most Recent NOt Required
                    checkElementPresent(r, MET, MEASURE_NAME, "retoalprprcapr") &&
                      checkElementPresent(r, MET, MEASURE_NAME, "fiofhy") &&
                      chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "retoalprprcapr_date", "bpscenco_date", 1)
                    )
                    ||
                    (
                      (
                        (
                          checkElementPresent(r, MET, MEASURE_NAME, "lire") &&
                            chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "lire_date", "bpscenco_date", 1)
                          ) ||
                          (checkElementPresent(r, MET, MEASURE_NAME, "werere") &&
                            chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "werere_date", "bpscenco_date", 1)
                            ) ||
                          (checkElementPresent(r, MET, MEASURE_NAME, "dire_1") &&
                            chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "dire_1_date", "bpscenco_date", 1)
                            ) ||
                          (checkElementPresent(r, MET, MEASURE_NAME, "phacre") &&
                            chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "phacre_date", "bpscenco_date", 1)
                            ) ||
                          (checkElementPresent(r, MET, MEASURE_NAME, "moofetcore") &&
                            chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "moofetcore_date", "bpscenco_date", 1)
                            )

                        ) &&
                        (
                          checkElementPresent(r, MET, MEASURE_NAME, "fowionye") &&
                            checkElementPresent(r, MET, MEASURE_NAME, "fiofhy") &&
                            chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "fowionye_date", "bpscenco_date", 1)
                          )
                      )
                  )) ||
            (
              (
                (
                  BackTracking(r, MET, MEASURE_NAME, BackTrackingMostList)

                  )


                )

    &&

    ((isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "bpscenco_date", "syblpr_date") &&
      chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "syblpr", 140))
      ||
      (isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "bpscenco_date", "diblpr_date") &&
        chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "diblpr", 90))
      ) &&
    (
      (
        checkElementPresent(r, MET, MEASURE_NAME, "retoalprprcapr") &&
          checkElementPresent(r, MET, MEASURE_NAME, "fiofhy") &&
          chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "retoalprprcapr_date", "bpscenco_date", 1)
        ) ||
        (
          (
            (
              checkElementPresent(r, MET, MEASURE_NAME, "lire") &&
                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "lire_date", "bpscenco_date", 1)
              ) ||
              (checkElementPresent(r, MET, MEASURE_NAME, "werere") &&
                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "werere_date", "bpscenco_date", 1)
                ) || //Close
              (checkElementPresent(r, MET, MEASURE_NAME, "dire_1") &&
                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "dire_1_date", "bpscenco_date", 1)
                ) ||
              (checkElementPresent(r, MET, MEASURE_NAME, "phacre") &&
                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "phacre_date", "bpscenco_date", 1)
                ) ||
              (checkElementPresent(r, MET, MEASURE_NAME, "moofetcore") &&
                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "moofetcore_date", "bpscenco_date", 1)
                )

            ) &&
            (
              checkElementPresent(r, MET, MEASURE_NAME, "fowi4we") &&
                checkElementPresent(r, MET, MEASURE_NAME, "fiofhy") &&
                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "fowionye_date", "bpscenco_date", 1)
              )
          )
      )
  ) ||
(

  (
      BackTracking1(r, MET, MEASURE_NAME, BackTrackingMostList)

    ) &&
    (
      (isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "syblpr_date", "bpscenco_date") &&
        chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "syblpr", 140))
        ||
        (isDateOverlapsLessOrEqual(r, MET, MEASURE_NAME, "diblpr_date", "bpscenco_date") &&
          chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "diblpr", 90))
      ) &&
    (
      (
        checkElementPresent(r, MET, MEASURE_NAME, "retoalprprcapr") &&
          checkElementPresent(r, MET, MEASURE_NAME, "fiofhy") &&
          chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "retoalprprcapr_date", "bpscenco_date", 1)
        ) ||
        (
          (
            (
              checkElementPresent(r, MET, MEASURE_NAME, "lire") &&
                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "lire_date", "bpscenco_date", 1)
              ) ||
              (checkElementPresent(r, MET, MEASURE_NAME, "werere") &&
                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "werere_date", "bpscenco_date", 1)
                ) ||
              (checkElementPresent(r, MET, MEASURE_NAME, "dire_1") &&
                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "dire_1_date", "bpscenco_date", 1)
                ) ||
              (checkElementPresent(r, MET, MEASURE_NAME, "phacre") &&
                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "phacre_date", "bpscenco_date", 1)
                ) ||
              (checkElementPresent(r, MET, MEASURE_NAME, "moofetcore") &&
                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "moofetcore_date", "bpscenco_date", 1)
                )
            ) &&
            (
              (
                checkElementPresent(r, MET, MEASURE_NAME, "anphth") &&
                  chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "anphth_date", "bpscenco_date", 1)
                ) ||
                (
                  checkElementPresent(r, MET, MEASURE_NAME, "latefohy") &&
                    chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "latefohy_date", "bpscenco_date", 1)
                  ) ||
                (
                  checkElementPresent(r, MET, MEASURE_NAME, "ec12leorstor") &&
                    chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME, "ec12leorstor_date", "bpscenco_date", 1)
                  )
              )

          )

      )
  )
)
)
||
(
(checkElementPresent(r, MET, MEASURE_NAME, "nbp") &&
isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "nbp_date", startDate, endDate)
) ||
(checkElementPresent(r, MET, MEASURE_NAME, "hyperbp") &&
isDuringMeasurementPeriod(r, MET, MEASURE_NAME, "hyperbp_date", startDate, endDate)
) ||
(checkElementPresent(r, MET, MEASURE_NAME, "bpdoc") &&
isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "bpdoc_date", startDate, endDate)
)
)
)
  }




  def getexceptionRDD(intermediateRDD:RDD[CassandraRow],MEASURE_NAME:String,startDate: Date, endDate: Date): RDD[CassandraRow] = {
    intermediateRDD.filter(r =>


      (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "meorotrenodo") &&
        isDateEqual(r, EXCEPTION, MEASURE_NAME, "meorotrenodo_date", "bpscenco_date")
        ) ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "parere_1") &&
            chkDateRangeLessOrEqualEncounterdateAddDays(r, EXCEPTION, MEASURE_NAME, "parere_1_date", "encounterdate", 1)
          )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "fllwupbp_rsn") &&
            isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fllwupbp_rsn_date", startDate, endDate)
          )
    )
  }



  def BackTracking(r: CassandraRow, conditionType: String, MEASURE_NAME: String, BackTrackingMostList: Broadcast[List[String]]): Boolean = {


    for (x <- BackTrackingMostList.value) {
      if (x != "") {
       // println(r.getString("visituid") + ">>>" + x)
        //println(r.getString("patientuid") + ">>>" + x)
        val back_data = x.split("~")
        val patientid = back_data(0);
        val syblpr_element = back_data(1);
        val syblpr_date =dateUtility.dateTimeParse317(convertDateToYYYYDDMM317(back_data(2)));
        val diblpr_element = back_data(3);
        val diblpr_date =dateUtility.dateTimeParse317(convertDateToYYYYDDMM317(back_data(4)));


        if ((!r.isNullAt("bpscenco_date") && !r.isNullAt("bpscenco"))
          && ((r.getString("patientuid").equals(patientid) || r.getString("patientuid") == patientid)
          &&(
          !(
            (
              r.getDateTime("bpscenco_date").minusYears(1).equals(syblpr_date)
                ||
                (
                  r.getDateTime("bpscenco_date").minusYears(1).isAfter(syblpr_date)

                    &&
                    r.getDateTime("bpscenco_date").isBefore(syblpr_date)
                  )
              )
              &&
              (
                r.getDateTime("bpscenco_date").minusYears(1).equals(diblpr_date)
                  ||
                  (
                    r.getDateTime("bpscenco_date").minusYears(1).isAfter(diblpr_date)
                      &&
                      r.getDateTime("bpscenco_date").isBefore(diblpr_date)
                    )
                )
            )
            ||
            (
              (
                r.getDateTime("bpscenco_date").minusYears(1).equals(syblpr_date)
                  &&
                  chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr_element",140)
                  ||
                  (
                    r.getDateTime("bpscenco_date").minusYears(1).isAfter(syblpr_date)
                      &&
                      r.getDateTime("bpscenco_date").isBefore(syblpr_date)
                      &&
                      chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr_element",140)
                    )
                )
                &&
                (
                  r.getDateTime("bpscenco_date").minusYears(1).equals(diblpr_date)
                    &&
                    chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr_element",90)
                    ||
                    (
                      r.getDateTime("bpscenco_date").minusYears(1).isAfter(diblpr_date)
                        &&
                        r.getDateTime("bpscenco_date").isBefore(diblpr_date)
                        &&
                        chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr_element",90)
                      )
                  )
              )
          )
          )
        // )
        ) {
          //println("match")
          return true;
        }

      }

    }

    return false;

  }

  def BackTracking1(r: CassandraRow, conditionType: String, MEASURE_NAME: String, BackTrackingMostList: Broadcast[List[String]]): Boolean = {
    val flag = false;

    for (x <- BackTrackingMostList.value) {
      if (x != "") {
        //println(r.getString("visituid") + ">>>" + x)
        val back_data = x.split("~")
        val patientid = back_data(0);
        val syblpr_element = back_data(1);
        val syblpr_date =dateUtility.dateTimeParse317(convertDateToYYYYDDMM317(back_data(2)));
        val diblpr_element = back_data(3);
        val diblpr_date =dateUtility.dateTimeParse317(convertDateToYYYYDDMM317(back_data(4)));


        if ((!r.isNullAt("bpscenco_date") && !r.isNullAt("bpscenco"))
          && ((r.getString("patientuid").equals(patientid) || r.getString("patientuid") == patientid)
          &&(
          (
            (
              r.getDateTime("bpscenco_date").minusYears(1).equals(syblpr_date)
                &&
                chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "syblpr_element", 140)
                ||
                (
                  r.getDateTime("bpscenco_date").minusYears(1).isAfter(syblpr_date)
                    &&
                    r.getDateTime("bpscenco_date").isBefore(syblpr_date)
                    &&
                    chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "syblpr_element", 140)

                  )
              )
              &&
              (
                r.getDateTime("bpscenco_date").minusYears(1).equals(diblpr_date)
                  &&
                  chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "diblpr_element", 90)
                  ||
                  (
                    r.getDateTime("bpscenco_date").minusYears(1).isAfter(diblpr_date)
                      &&
                      r.getDateTime("bpscenco_date").isBefore(diblpr_date)
                      &&
                      chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "diblpr_element", 90)
                    )
                )
            )
          )
          )
        // )
        ) {
          //println("match")
          return true;
        }

      }

    }

    return flag;

  }
/*
  def getBackTrackingList(rdd: RDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement: String, backtrackelement_date: String): List[String] = {

    val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).distinct().collect().toList

    val IPPFilterExclusionRDD = rdd.filter(x => (ipp_patient_list.contains(x.columnValues(3))))

    var CRA = IPPFilterExclusionRDD.map(x =>
      if (!x.isNullAt("patientuid")
        && !x.isNullAt(backtrackelement) && !x.isNullAt(backtrackelement_date)) {
        x.getString("patientuid") + "~" + x.getString(backtrackelement) + "~" + x.getString(backtrackelement_date)
      }
      else ""
    )
      .collect()
      .toList

    return CRA;*/

  def getBackTrackingList(MostRecentRDD:RDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement2: String, backtrackelement3: String, backtrackelement4: String): List[String] = {

    val ipp_patient_list = ippRDD.map(x => x.getString("patientuid")).collect().toList

    val BacktrackingRDD = MostRecentRDD.filter(x => (ipp_patient_list.contains(x.columnValues(3))))

    /*val BacktrackingRDD = MostRecentRDD.map(x=>(

    /*  !x.isNullAt("patientuid")
        && !x.isNullAt("syblpr") && !x.isNullAt("syblpr_date") &&
        !x.isNullAt("diblpr") && !x.isNullAt("diblpr_date")*/
      x.getString("patientuid"),
      if(!x.isNullAt("syblpr")) x.getString("syblpr") else 0,
      if(!x.isNullAt("syblpr_date")) x.getString("syblpr_date") else null ,
      if(!x.isNullAt("diblpr")) x.getString("diblpr") else 0,
      if(!x.isNullAt("diblpr_date")) x.getString("diblpr_date") else null
    )).filter(x => (ipp_patient_list.contains(x._1)))*/


    //BacktrackingRDD.collect().foreach(println)


    var CRA1 = BacktrackingRDD.map(x =>
        if (!x.isNullAt("patientuid")
          && !x.isNullAt(backtrackelement1) && !x.isNullAt(backtrackelement2) && !x.isNullAt(backtrackelement3) && !x.isNullAt(backtrackelement1))

      {
        x.getString("patientuid") + "~" + x.getString(backtrackelement1) + "~" + x.getString(backtrackelement2)  + "~" + x.getString(backtrackelement3) + "~" + x.getString(backtrackelement4)
        //x.getString("patientuid") + "~" + x.getString(backtrackelement1) + "~" + x.getString(backtrackelement2)
      }
      else ""
    )
      .collect()
      .toList

    return CRA1;

    //CRA.foreach(println)




    //val dm  = List[String]()
    //dm
    //return CRA

  }
}
