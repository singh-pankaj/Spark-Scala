package com.figmd.janus.measureComputation.cmsMeasures

import java.util.Date

import java.util.Date
import com.figmd.janus.Measure
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator.prop
import com.figmd.janus.util.measure.MeasureUtility

object CMS139 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession,rdd:RDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]



    // Eligible IPP
    val eligibleRdd = sparkSession.sparkContext.emptyRDD[CassandraRow]
    eligibleRdd.cache()
    // Filter Exclusions

    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,startDate: Date,endDate: Date,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getSubtractRDD(ippRDD,exclusionRDD)
    intermediateA.cache()
    // Filter Met
    val metRDD = getMet(intermediateA,startDate: Date,endDate: Date,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not meate
    val notMetRDD =  getSubtractRDD(intermediateA,metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }
  def getIpp(rdd:RDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    rdd
      .filter(r =>
        isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 65)

        &&
        (
            checkElementPresent(r, IPP, MEASURE_NAME, "fain")&&
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date",startDate,endDate)
            ||
            checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1")&&
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date",startDate,endDate)
            ||
            checkElementPresent(r, IPP, MEASURE_NAME, "prcaseco")&&
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "prcaseco_date",startDate,endDate)
            ||
            checkElementPresent(r, IPP, MEASURE_NAME, "nufavi")&&
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date",startDate,endDate)
            ||
            checkElementPresent(r, IPP, MEASURE_NAME, "caseinlorefa")&&
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date",startDate,endDate)
            ||
            checkElementPresent(r, IPP, MEASURE_NAME, "hohese")&&
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "hohese_date",startDate,endDate)
            ||
            checkElementPresent(r, IPP, MEASURE_NAME, "prcaseofvi18anup_1")&&
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "prcaseofvi18anup_1_date",startDate,endDate)
            ||
            checkElementPresent(r, IPP, MEASURE_NAME, "prcaseesofvi18anup_1")&&
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "prcaseesofvi18anup_1_date",startDate,endDate)
            ||
            checkElementPresent(r, IPP, MEASURE_NAME, "anwevi_1")&&
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "anwevi_1_date",startDate,endDate)
            ||
            checkElementPresent(r, IPP, MEASURE_NAME, "auvi")&&
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "auvi_date",startDate,endDate)
            ||
            checkElementPresent(r, IPP, MEASURE_NAME, "opse")&&
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date",startDate,endDate)
          )


      )
  }
  def getExclusionRdd(ippRDD: RDD[CassandraRow],startDate:Date,endDate:Date, MEASURE_NAME: String): RDD[CassandraRow] = {
    ippRDD.filter(r =>
      (
        checkElementPresent(r, EXCLUSION, MEASURE_NAME, "enin_1")&&
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohofohoca")&&
          isDateLessThan(r, EXCLUSION, MEASURE_NAME, "enin_1","ditohofohoca_date")
        )
        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "enin_1")&&
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohecafafohoca")&&
            isDateLessThan(r, EXCLUSION, MEASURE_NAME, "enin_1","ditohecafafohoca_date")
        )
        ||
        (
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hocaam")
             ||
             isDateOverlapsDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME,"hocaam_date",endDate)
            )
        )
      ||
      (
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "panoam")
            ||
            isDateOverlapsDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME,"panoam_date",endDate)
          )

      )

    )
  }

  def getMet(intermediateA:RDD[CassandraRow],startDate: Date, endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateA.filter(r =>
      (
        checkElementPresent(r, EXCLUSION, MEASURE_NAME, "fasc")&&
          isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "fasc_date",startDate,endDate)
      )

    )

  }


}

