package com.figmd.janus.measureComputation.qppMeasures

import java.util
import java.util.{Collections, Date}

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.Measure
import com.figmd.janus.util.measure.HistoryLookUpUtility._
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.joda.time.DateTime

object QPP100_2 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

 //rdd.filter( r => r.getString("patientuid").equals("45850458-5bf9-4b70-b721-8b6b5358721f")).map(r => (r.getString("patientuid"),r.getDateTime("encounterdate").toString)).foreach(println)

  val xc = getPatientgroupByandKeyOrderBy(rdd).collect()

 println("*********************###############*******************************************************************")

    xc.take(20).foreach(println)

println("**************************############***************************************************************")
/*val xc_1 = mostRecentElementList(rdd)

   xc_1.foreach(println)*/






/*
    val ippInitialRDD = getInitialIpp(rdd, MEASURE_NAME, startDate: Date, endDate: Date)
    ippInitialRDD.cache()
    println("initial ipp count "+ippInitialRDD.count())

    val ippRDD = getIpp(ippInitialRDD, MEASURE_NAME, startDate, endDate)
    ippRDD.cache()

    // Eligible IPP
    val ippRdd = getIpp(ippInitialRDD, MEASURE_NAME, startDate: Date, endDate: Date)
    ippRdd.collect()


    // Filter Exclusions
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    ippRdd.cache()

    // Filter Exclusions
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = ippRdd
    intermediateA.cache()

    // Filter Met
    val metRDD =  getMet(intermediateA, MEASURE_NAME, startDate: Date, endDate: Date)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA,metRDD)///sparkSession.sparkContext.emptyRDD[CassandraRow]
    notMetRDD.cache()

    saveToWebDM(rdd, ippRdd, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
*/

  }


  def getPatientgroupByandKeyOrderBy0ld(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val lockingRdd = rdd.filter(l => !l.isNullAt("patientuid") && !l.isNullAt("encounterdate")
        && l.getString("patientuid").equals("45850458-5bf9-4b70-b721-8b6b5358721f"))  // 24908e5b-df3f-4b69-bd58-0d4b900f07e3"
      .map(l => (l.getString("patientuid"), l.getDate("encounterdate").getTime)).groupByKey()//.collect()
      .map(r => (r._1,getlocking(r._2.toArray.sorted))).collect()


    lockingRdd.foreach(println)

    println("!!!!!!!!!!!!!!!")
    lockingRdd.map(r => r._2).filter(x => x.contains("2018-01-02T12:00:00.000Z")).foreach(println)
    println("@@@@@@@@")
    lockingRdd.map(c => c._2).filter( x => x.toArray.contains("2018-01-02T12:00:00.000Z")).foreach(println)
    println("!!!!!!!!!!!!!!!")

    lockingRdd.map(c => c._2.toArray.toList).foreach(println)
    println("sdsdsdsdsdsdsddddddddddd")
    rdd.map( r=> r.getDateTime("encounterdate")).take(2).foreach(println)

    val cv =rdd.filter(r => lockingRdd.map(c => (c._1,c._2.toArray)).forall( x => x._1.contains(r.getString("patientuid")) && x._2.contains(r.getDateTime("encounterdate").toString) ))


    cv.collect()
    println("========cv===========")
    cv.take(5).foreach(println)
    println("========cv===========")

     return cv

  }


  def getPatientgroupByandKeyOrderBy(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val lockingRdd = rdd.filter(l => !l.isNullAt("patientuid") && !l.isNullAt("encounterdate"))
     // &&  //l.getString("patientuid").equals("45850458-5bf9-4b70-b721-8b6b5358721f"))  // 24908e5b-df3f-4b69-bd58-0d4b900f07e3"
      .map(l => (l.getString("patientuid"), l.getDate("encounterdate").getTime)).groupByKey()//.collect()
      .map(r => (r._1,getlocking(r._2.toArray.sorted))).collect()


   lockingRdd.take(10).foreach(println)
    /*
       println("!!!!!!!!!!!!!!!")
       lockingRdd.map(r => r._2).filter(x => x.contains("2018-01-02T12:00:00.000Z")).foreach(println)
       println("@@@@@@@@")
       lockingRdd.map(c => c._2).filter( x => x.toArray.contains("2018-01-02T12:00:00.000Z")).foreach(println)
       println("!!!!!!!!!!!!!!!")

       lockingRdd.map(c => c._2.toArray.toList).foreach(println)
       println("sdsdsdsdsdsdsddddddddddd")
       rdd.map( r=> r.getDateTime("encounterdate")).take(2).foreach(println)*/

    val cv =rdd.filter(r => lockingRdd.map(c => (c._1,c._2.toArray)).exists( x => x._1.contains(r.getString("patientuid")) && x._2.contains(r.getDateTime("encounterdate").toString) ))


    cv.collect()
    println("========cv===========")
    cv.take(5).foreach(println)
    println("========cv===========")

    return cv

  }

  def getlocking(arr : Array[Long]): util.ArrayList[String] ={

    var min = new DateTime(arr(0))

    var req:util.ArrayList[String] = new util.ArrayList[String]()
          req.add(min.toString)

    for(dt <- arr) {

      if ( min.plusDays(29).isBefore(new DateTime(dt))){

        min = new DateTime(dt)
        req.add(min.toString)
        //   req += min.toString()
      }


    }


    return req
  }



  /*def getfromMet(rdd1 : RDD[CassandraRow], rdd2: RDD[CassandraRow]): RDD[CassandraRow] ={

    rdd1.filter(r => rdd2.map())

  }
*/

  def mostRecentElementList(historyRDD: RDD[CassandraRow]): Array[(String,Date)] = {

    val mostRecentElements = historyRDD.filter(l => !l.isNullAt("patientuid") && !l.isNullAt("encounterdate") && l.getString("patientuid").equals("45850458-5bf9-4b70-b721-8b6b5358721f"))
      .map(l => (l.getString("patientuid"), l.getDate("encounterdate")))
      .reduceByKey((x, y) => if (x.before(y)) x else y).collect()
   // historyRDD.filter(r => mostRecentElements.contains((r.getString("patientuid"), r.getDate("encounterdate")))).collect().toList\\


   /* for(y <-mostRecentElements){
      val dt = new DateTime(y._2)

    for(x <- historyRDD) {
      if (x.getString("patientuid").equals(y._1)){

       x.getDateTime("").plusDays(30).isBefore(dt)

      }

    }
    }*/
    mostRecentElements

  }




  def getInitialIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {


    rdd.filter(r =>

      isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18
      )
    )


  }

  def getIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    rdd.filter(r =>

      isDateOverlapsLessOrEqualHistory(r, IPP, MEASURE_NAME, "encounterdate", "MaEx")


    )

  }

  def getMet(intermediateA: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {


    intermediateA.filter(r =>

      isDateOverlapsLessOrEqualHistory(r, IPP, MEASURE_NAME, "encounterdate", "CoRe")

    )

  }

  def getDenominatorExclusionRDD(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    return rdd

  }

}