package com.figmd.janus.measureComputation.cmsMeasures

import java.util.Date

import com.figmd.janus.Measure
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator.prop
import org.joda.time.DateTime
import com.figmd.janus.util.measure.{HistoryLookUpUtility,MeasureUtility}

object CMS131v5_1 extends  MeasureUtility with Measure{


  def refresh(sparkSession: SparkSession,rdd:RDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    /*var columnRef = getFiledList(MEASURE_NAME)
    var patientHistoryRDD = sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart_history"),
      prop.getProperty("patientHistory")).select("patientuid","reordieyex","reordieyex_date","nefi","nefi_date")*/




       // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()

     ippRDD.collect()
   // ippRDD.collect().take(10).foreach(println)
    //println(getPatientUid(ippRDD))

      var mylist:List[String]= List(" A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD","A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD","D3C62DE3-F2D6-4DFA-9DE7-CC82BA4E834F","22C162BA-0986-4034-9312-D6EDCEAB8556")
  //  var patientHistoryRDD = Histroy.getPatientHistory(sparkSession,mylist)
   // var patientHistoryRDD = getpatientHistory(sparkSession,getPatientUid(ippRDD))

    println("########")
 //   patientHistoryRDD.collect().take(10).foreach(println)
// // MeRe_1 MeorOtrenodo  mere_1  meorotrenodo

//    val CRA = getBackTrackingList(patientHistoryRDD, ippRDD, "MeRe_1","MeorOtrenodo");

    //"reordieyex","reordieyex_date","nefi","nefi-date"

   // val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.cast(CRA)

  //  CRA_list.value.foreach(println)
  //  println("$$$$$$$$$")
  //  for(x<- CRA_list.value){
  //    println(x)
  //  }



    // Eligible IPP
    val eligibleRdd =  sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    eligibleRdd.cache()
    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,startDate: Date,endDate: Date,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getSubtractRDD(ippRDD,exclusionRDD)
    intermediateA.cache()
    // Filter Met
  //  val metRDD = getMet(intermediateA,startDate: Date,endDate: Date,MEASURE_NAME,CRA_list: Broadcast[List[String]])
  //  metRDD.cache()
    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not meate
 //   val notMetRDD =  getSubtractRDD(intermediateA,metRDD)
 //   notMetRDD.cache()

 //   saveToWebDM(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }

  // Filter IPP
  def getIpp(rdd:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    rdd
      .filter(r =>
        (
          checkElementPresent(r, IPP, MEASURE_NAME,"diab_1")&&
            isDateEqual(r, IPP, MEASURE_NAME,"diab_1_date","encounterdate")
            &&
            isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)
            &&
            isAgeLess(r, IPP, MEASURE_NAME, "dob", "encounterdate", 75)

            &&
            (
              checkElementPresent(r, IPP, MEASURE_NAME,"ofvi_1")&&
                isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"ofvi_1_date",startDate,endDate)
                ||
                checkElementPresent(r, IPP, MEASURE_NAME,"fain")&&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"fain_date",startDate,endDate)
                ||
                checkElementPresent(r, IPP, MEASURE_NAME,"prcaseesofvi18anup_1")&&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"prcaseesofvi18anup_1_date",startDate,endDate)
                ||
                checkElementPresent(r, IPP, MEASURE_NAME,"prcaseofvi18anup_1")&&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"prcaseofvi18anup_1_date",startDate,endDate)
                ||
                checkElementPresent(r, IPP, MEASURE_NAME,"hohese")&&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"hohese_date",startDate,endDate)
                ||
                checkElementPresent(r, IPP, MEASURE_NAME,"anwevi_1")&&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"anwevi_1_date",startDate,endDate)
                ||
                checkElementPresent(r, IPP, MEASURE_NAME,"opse")&&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"opse_date",startDate,endDate)
              )

          )
      )
  }

  def getExclusionRdd(eligibleRdd:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {

    eligibleRdd.filter(r => (
      (
        checkElementPresent(r, EXCLUSION, MEASURE_NAME, "enin_1")&&
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohofohoca")&&
          isDateStartsAfterOrConcurrentWithStartOf(r, EXCLUSION, MEASURE_NAME, "ditohofohoca_date","enin_1_date")
          &&
          isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "ditohofohoca",startDate,endDate)
          &&
          isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "enin_1",startDate,endDate)

        )
        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "enin_1")&&
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohecafafohoca")&&
            isDateStartsAfterOrConcurrentWithStartOf(r, EXCLUSION, MEASURE_NAME, "ditohecafafohoca_date","enin_1_date")
            &&
            isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "ditohecafafohoca",startDate,endDate)
            &&
            isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "enin_1",startDate,endDate)
          )
          ||
          (

            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hocaam")
              ||
              isDateOverlapsMeasurementPeriod(r, EXCLUSION, MEASURE_NAME,"hocaam_date",endDate)
          )
        )
    )
  }

  def getMet(intermediateA:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String,CRA_list: Broadcast[List[String]]): RDD[CassandraRow] = {

    intermediateA.filter(r => (

        BackTracking(r, MET, MEASURE_NAME, CRA_list,startDate)
      /*  ||
        (
           checkElementPresent(r, MET, MEASURE_NAME, "reordieyex")
            &&
            isDuringMeasurementPeriod(r, MET, MEASURE_NAME, "reordieyex_date",startDate,endDate)
        )
        */
      )
    )
  }
  def getPatientUid(ippRDD:RDD[CassandraRow]):List[String]={
    var IPP=ippRDD.map(l=>(l.getString("patientuid"))).collect().toList
    //var IPP=ippRDD.map(l=>(l.getString("patientuid"))).collect().toList

    return IPP
  }

  def BackTracking(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]], startDate: Date): Boolean = {
    val flag = false;
    ////"reordieyex","reordieyex_date","nefi","nefi-date"

    // MeRe_1 MeorOtrenodo
    //     var ipp_patient_list = List(" A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD","A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD","D3C62DE3-F2D6-4DFA-9DE7-CC82BA4E834F","22C162BA-0986-4034-9312-D6EDCEAB8556")

    for (x <- CRA.value) {
      if (x != "") {
        val back_data = x.split("~")
        val patientid = back_data(0)

        val element = back_data(1)
        val element_date = dateUtility.dateTimeParse(back_data(2))
        val element_value = back_data(3)
        var name1 = "MeRe_1"
        var name2 = "MeorOtrenodo"

        //
        val rpatientid = "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD"


        //


        /*val patientid = back_data(0);
        val reordieyex = back_data(1);
        val nefi_date=back_data(2)
        val reordieyex_date = dateUtility.dateTimeParse(back_data(2));
        */
        val Start_Date = new DateTime(startDate)
        //   println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",reordieyex_date);

        if (!r.isNullAt("patientuid")
          && name1.equals(element)
        //  &&
        //  (Start_Date.minusMonths(12).isAfter(element_date)
         //   && Start_Date.isBefore(element_date))
        )

         // println(Start_Date+" "+Start_Date.minusMonths(12)+" "+element_date)
          return true


      }

/*

        if ((!r.isNullAt("reordieyex"))
          && ((r.getString("patientuid").equals(patientid) || r.getString("patientuid") == patientid)
          &&
          (
             name1.equals(element)
          //reordieyex == "1"
          && r.getString("nefi").equals(1)
          &&
              (
              (
               Start_Date.minusMonths(12).isAfter(element_date)
              &&
              Start_Date.isBefore(element_date)
              )
            ||
            Start_Date.minusMonths(12).isEqual(element_date)
            ||
            Start_Date.isEqual(element_date)
              )
            )
          //)
          )
        ) {
*/




      }



    return flag;

  }

  def getBackTrackingList(patientHistoryRDD: RDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement2: String): List[String] = {

   // val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).collect().toList

    var BackTrackElementList = List(backtrackelement1,backtrackelement2)


    // A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD
    // MeRe_1 MeorOtrenodo

    var ipp_patient_list = List(" A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD","A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD","D3C62DE3-F2D6-4DFA-9DE7-CC82BA4E834F","22C162BA-0986-4034-9312-D6EDCEAB8556")


    // var BackTrackElementList = List(backtrackelement1,backtrackelement2)





    //val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).collect().toList

    val IPPFilterExclusionRDD = patientHistoryRDD.map(x => (
      x.getString("patientuid"),
      if (!x.isNullAt("element")) x.getString("element") else "",
      if (!x.isNullAt("element_date")) x.getString("element_date") else "",
      if (!x.isNullAt("elementvalue")) x.getString("elementvalue") else "null"
    )).filter(x=> ipp_patient_list.contains(x._1) && BackTrackElementList.contains(x._2))
     // .filter(x => ipp_patient_list.contains(x._1) && BackTrackElementList.contains(x._2))



   /* val IPPFilterExclusionRDD = patientHistoryRDD.map(x=>(if(!x.isNullAt("patientuid"))x.getString("patientuid")else "",
      if(!x.isNullAt("reordieyex"))x.getString("reordieyex")else "",
      if(!x.isNullAt("nefi"))x.getString("nefi_date")else "")).filter(x => (ipp_patient_list.contains(x._1)))
*/
    //if (!BacktrackingRDD.isEmpty) {
     /* var CRA = BacktrackingRDD.map(x => {
        x._1 + "~" + x._2 + "~" + x._3 + "~" + x._4 //+ "~" + x._5 + "~" + x._6 + "~" + x._7
      }*/

println("IPPFilter BackTrack")
    IPPFilterExclusionRDD.collect().take(10).foreach(println)
    println("IPPFilter BackTrack ")

    if (!IPPFilterExclusionRDD.isEmpty) {
      var CRA = IPPFilterExclusionRDD.map(x => {
        x._1 + "~" + x._2 + "~" + x._3 + "~" + x._4 //+ "~" + x._5 + "~" + x._6 + "~" + x._7
      }
      )
        .collect()
        .toList


      CRA.take(5).foreach(println)
      println("CRA List")

      return CRA


    }
    else {
      val l = List[String]()
      l
    }
  }

    /*  if (!IPPFilterExclusionRDD.isEmpty){
    var CRA = IPPFilterExclusionRDD.map(x =>
      {
        x._1 + "~" + x._2 + "~" + x._3 + "~" + x._4
      }
      else ""
    )
      .collect()
      .toList

    return CRA;
  }
*/
}

