package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.Measure
import com.figmd.janus.measureComputation.qppMeasures.QPP100_1.IPP
import com.figmd.janus.util.measure.HistoryLookUpUtility.{isDateOverlapsLessOrEqualHistory, _}
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object QPP100 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

    val ippInitialRDD = getInitialIpp(rdd, MEASURE_NAME, startDate: Date, endDate: Date)
    ippInitialRDD.cache()


    val patient_history_list = getPatientHistory(sparkSession, ippInitialRDD, "maex","core")

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

/*
    println("####patient Histroy####")
    patientHistoryList.value.take(5).foreach(println)
    println("####patient Histroy####")
*/

    val ippRDD = getIpp(ippInitialRDD, MEASURE_NAME,patientHistoryList, startDate, endDate)
    ippRDD.cache()
    println("initial ipp count "+ippInitialRDD.count())


    println("####Ipp RDD ####")
    ippRDD.take(5).foreach(println)
    println("####Ipp RDD ####")


    /*
    val patientHistoryList = getPatientHistory(sparkSession, ippInitialRDD, "maex","macexm_eye")

    patientHistoryList.take(10).foreach(println)
*/


    // Eligible IPP
    val ippRdd = getIpp(ippInitialRDD, MEASURE_NAME, patientHistoryList, startDate: Date, endDate: Date)
   /* ippRdd.collect()

    ippRdd.take(5).foreach(println)
*/
    // Filter Exclusions
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    ippRdd.cache()

    // Filter Exclusions
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = ippRdd
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA, MEASURE_NAME, patientHistoryList, startDate: Date, endDate: Date)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA,metRDD)//getnotmet(InterMediate,metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRdd, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }


  def getInitialIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {


    rdd.filter(r =>

      isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18
      )
    )

  }

  def getIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String, patient_list: Broadcast[List[CassandraRow]], startDate: Date, endDate: Date): RDD[CassandraRow] = {

    rdd.filter(r =>

        startBeforeStartOfEncounterDateHistory(r, IPP, MEASURE_NAME, "encounterdate", "maex", patient_list)


    )

  }

  def getMet(intermediateA: RDD[CassandraRow], MEASURE_NAME: String,patient_list: Broadcast[List[CassandraRow]], startDate: Date, endDate: Date): RDD[CassandraRow] = {

    intermediateA.filter(r =>

      startBeforeStartOfEncounterDateHistory(r, IPP, MEASURE_NAME, "encounterdate", "core", patient_list)


    )

  }

  def getDenominatorExclusionRDD(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    return rdd



  }

}