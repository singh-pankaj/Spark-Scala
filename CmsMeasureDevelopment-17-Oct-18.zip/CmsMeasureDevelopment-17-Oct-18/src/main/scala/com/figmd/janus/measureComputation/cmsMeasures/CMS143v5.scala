package com.figmd.janus.measureComputation.cmsMeasures


import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.Measure
import com.figmd.janus.util._
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object CMS143v5 extends MeasureUtility with Measure {


  def refresh(sparkSession: SparkSession, rdd:RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd, startDate, endDate, MEASURE_NAME)
    ippRDD.cache()

    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Exclusions

    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = getinterRDD(ippRDD, exclusionRDD)
    intermediateA.cache()
    // Filter Met
    //met
    val metRDD = getMet(intermediateA, MEASURE_NAME, startDate, endDate)
    metRDD.cache()


    val exceptionRDD = getexceptionRDD(intermediateA, MEASURE_NAME)
    exceptionRDD.cache()

    // Filter not met
    val notMetRDD = getinterRDD(intermediateA, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }


  def getIpp(rdd: RDD[CassandraRow], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {
    rdd
      .filter(r =>

        (
          isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)

          )

          &&

            (
              checkElementPresent(r, IPP, MEASURE_NAME, "propgl") && checkElementPresent(r, IPP, MEASURE_NAME, "opse")
                && isDateEqual(r, IPP, MEASURE_NAME, "propgl_date", "opse_date")
                &&
                (isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))
              )

          ||

          (
            checkElementPresent(r, IPP, MEASURE_NAME, "propgl") && checkElementPresent(r, IPP, MEASURE_NAME, "caseinlorefa")
              && isDateEqual(r, IPP, MEASURE_NAME, "propgl_date", "caseinlorefa_date")
              &&
              (isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))
            )
          ||

          (
            checkElementPresent(r, IPP, MEASURE_NAME, "propgl") && checkElementPresent(r, IPP, MEASURE_NAME, "nufavi")
              && isDateEqual(r, IPP, MEASURE_NAME, "propgl_date", "nufavi_date")
              &&
              (isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))
            )
          ||

          (
            checkElementPresent(r, IPP, MEASURE_NAME, "propgl") && checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1")
              && isDateEqual(r, IPP, MEASURE_NAME, "propgl_date", "ofvi_1_date")
              &&
              (isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))
            )
          ||

          (
            checkElementPresent(r, IPP, MEASURE_NAME, "propgl") && checkElementPresent(r, IPP, MEASURE_NAME, "ouco_1")
              && isDateEqual(r, IPP, MEASURE_NAME, "propgl_date", "ouco_1_date")
              &&
              (isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))
            )
          ||

          (
            checkElementPresent(r, IPP, MEASURE_NAME, "propgl") && checkElementPresent(r, IPP, MEASURE_NAME, "fain")
              && isDateEqual(r, IPP, MEASURE_NAME, "propgl_date", "fain_date")
              &&
              (isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))
            )

            &&
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "poageye") &&
                isDateEqual(r, IPP, MEASURE_NAME, "poageye_date", "propgl_date")

              )

      )

  }


  def getMet(intermediateA: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    intermediateA.filter(r =>
      (
        (
          (checkElementPresent(r, MET, MEASURE_NAME, "cutodira"))
         &&
            (
                  isDateEqual(r, MET, MEASURE_NAME, "cutodira_date", "opse_date")
                ||
                  isDateEqual(r, MET, MEASURE_NAME, "cutodira_date", "caseinlorefa_date")
                ||
                   isDateEqual(r, MET, MEASURE_NAME, "cutodira_date", "nufavi_date")
                ||
                    isDateEqual(r, MET, MEASURE_NAME, "cutodira_date", "ofvi_1_date")
                ||
                    isDateEqual(r, MET, MEASURE_NAME, "cutodira_date", "ouco_1_date")
                ||
                  isDateEqual(r, MET, MEASURE_NAME, "cutodira_date", "fain_date")
          )
          &&
          (
            checkElementPresent(r, MET, MEASURE_NAME, "cpdsert_eye")
              && isDateEqual(r, MET, MEASURE_NAME, "cpdsert_eye_date", "cutodira_date")
            )
        )
        &&
        (
          (
            (checkElementPresent(r, MET, MEASURE_NAME, "opdiexfostab") )
              &&
              (
                isDateEqual(r, MET, MEASURE_NAME, "opdiexfostab_date", "opse_date")
                  ||
                  isDateEqual(r, MET, MEASURE_NAME, "opdiexfostab_date", "caseinlorefa_date")
                  ||
                  isDateEqual(r, MET, MEASURE_NAME, "opdiexfostab_date", "nufavi_date")
                  ||
                  isDateEqual(r, MET, MEASURE_NAME, "opdiexfostab_date", "ofvi_1_date")
                  ||
                  isDateEqual(r, MET, MEASURE_NAME, "opdiexfostab_date", "ouco_1_date")
                  ||
                  isDateEqual(r, MET, MEASURE_NAME, "opdiexfostab_date", "fain_date")
                )
            )
           &&
            (
              checkElementPresent(r, MET, MEASURE_NAME, "odscexstrabn_eye")
                && isDateEqual(r, MET, MEASURE_NAME, "odscexstrabn_eye_date", "opdiexfostab_date")
              )
          )
        )
    )


  }

  def getexceptionRDD(intermediateA: RDD[CassandraRow], MEASURE_NAME: String): RDD[CassandraRow] = {
    intermediateA.filter(r =>

        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mere_1")
          /*)

          &&
          (
               checkElementPresent(r, EXCEPTION, MEASURE_NAME, "opdiexfostab")*/
               &&
               (
                 isDateEqual(r, MET, MEASURE_NAME, "mere_1_date", "opse_date")
                   ||
                   isDateEqual(r, MET, MEASURE_NAME, "mere_1_date", "caseinlorefa_date")
                   ||
                   isDateEqual(r, MET, MEASURE_NAME, "mere_1_date", "nufavi_date")
                   ||
                   isDateEqual(r, MET, MEASURE_NAME, "mere_1_date", "ofvi_1_date")
                   ||
                   isDateEqual(r, MET, MEASURE_NAME, "mere_1_date", "ouco_1_date")
                   ||
                   isDateEqual(r, MET, MEASURE_NAME, "mere_1_date", "fain_date")
                 )


          )
        /*||
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "cutodira")
            &&
            (
              isDateEqual(r, MET, MEASURE_NAME, "mere_1_date", "opse_date")
                ||
                isDateEqual(r, MET, MEASURE_NAME, "mere_1_date", "caseinlorefa_date")
                ||
                isDateEqual(r, MET, MEASURE_NAME, "mere_1_date", "nufavi_date")
                ||
                isDateEqual(r, MET, MEASURE_NAME, "mere_1_date", "ofvi_1_date")
                ||
                isDateEqual(r, MET, MEASURE_NAME, "mere_1_date", "ouco_1_date")
                ||
                isDateEqual(r, MET, MEASURE_NAME, "mere_1_date", "fain_date")
              )
        */

    )

    //adenoconjuc,adenoconjuc_date,adenoconjeye,adenoconjeye_date,antibioticseye,antibiotics,antibioticseye_date,antibiotics_date

  }
}


