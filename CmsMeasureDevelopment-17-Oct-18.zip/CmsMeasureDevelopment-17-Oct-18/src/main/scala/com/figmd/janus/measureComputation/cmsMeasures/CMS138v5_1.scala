package com.figmd.janus.measureComputation.cmsMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.Measure
import com.figmd.janus.util._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator.prop
import com.figmd.janus.util.measure.MeasureUtility

object CMS138v5_1 extends MeasureUtility with Measure {


  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

    // For Backtracking change the Back tracking element table name.
//    var patientHistoryRDD = getpatientHistory(sparkSession,"patientuid","encounterdate","tousceph_date","toussc","tono_date")
  //  var patientHistoryRDD = getpatientHistory(sparkSession)
   // patientHistoryRDD.cache()
    //  Ipp Calculation
    val ippRDD = getIpp(rdd, startDate, endDate, MEASURE_NAME)

    ippRDD.cache()

    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //  Back Tracking List
  //  val PreviousData = getBackTracking(patientHistoryRDD, ippRDD, MEASURE_NAME: String, endDate, 24, "encounterdate", "toussc", "toussc_date", "tous_1", "tono");
  //  PreviousData.cache()
    val MR_EncDate = mostRecent(ippRDD, "patientuid", "encounterdate", MEASURE_NAME)
    MR_EncDate.cache()
    // Filter Exclusions
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Met
    val metRDD = getMet(MR_EncDate, MEASURE_NAME)
    metRDD.cache()
    // Filter Intermediate
    var intermediateRDD = getintermediateRDD(ippRDD, metRDD)
    intermediateRDD.cache()
    // Filter Exceptions
    val exceptionRDD = getException(intermediateRDD, MEASURE_NAME, startDate: Date, endDate: Date)
    exceptionRDD.cache()
    // Filter NotMet
    val notMetRDD = getinterRDD(intermediateRDD, exceptionRDD)
    notMetRDD.cache()
    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
  }




  /*def getpatientHistory(sparkSession: SparkSession):RDD[CassandraRow] = {
    val historyRDD= sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"),
     prop.getProperty("patientHistory")).select("patientuid", "encounterdate", "tousceph_date", "toussc", "tono_date")

    return historyRDD
      }
*/


  def getIpp(rdd: RDD[CassandraRow], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {
    rdd.filter(r =>
      (
        isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)
          &&
          (
            checkElementCountGreaterOrEqualTwo_138(r, IPP, MEASURE_NAME, "fain", "fain_date", "hebeasin", "hebeasin_date", "heanbeasin", "heanbeasin_date",
              "heanbeasre", "heanbeasre_date", "hohese", "hohese_date", "octhev", "octhev_date", "ofvi_1", "ofvi_1_date", "opse", "opse_date", "psvidiev", "psvidiev_date",
              "psvips", "psvips_date", "psyc", "psyc_date", "spanheev", "spanheev_date", startDate, endDate)
              ||
              checkElementCountGreaterOrEqualOne_138(r, IPP, MEASURE_NAME, "anwevi_1", "anwevi_1_date", "prcaseesofvi18anup_1", "prcaseesofvi18anup_1_date", "prcasegrco", "prcasegrco_date",
                "prcaseot", "prcaseot_date", "prcaseco", "prcaseco_date", "prcaseofvi18anup_1", "prcaseofvi18anup_1_date", startDate, endDate)
            )

        )
    )
  }

  def getMet(MR_EncDate: RDD[CassandraRow], MEASURE_NAME: String): RDD[CassandraRow] = {
    MR_EncDate.filter(r =>
      (
        MR_checkElementStatus(r, MET, MEASURE_NAME, MR_chk_TBusr_NonTbusr(r, MET, MEASURE_NAME, "tono_date", "tous_1_date", "tono", "tous_1"), true)
          ||
          MR_checkElementStatus(r, MET, MEASURE_NAME, MR_chk_TBusr_NonTbusr(r, MET, MEASURE_NAME, "tono_date", "tous_1_date", "tono", "tous_1"), false)
      )
    )
  }

  def getintermediateRDD(ippRDD: RDD[CassandraRow], metRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val InterMediate = metRDD.map(r => r.getString("visituid")).collect().toList
    val InterMediateA = ippRDD.filter(r => !InterMediate.contains(r.getString("visituid")))
    return InterMediateA
  }


  def getException(metRDD: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {
    metRDD.filter(r => ((checkElementPresent(r, EXCEPTION, MEASURE_NAME, "liliex") &&
      isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "liliex_date", startDate: Date, endDate: Date)
      &&
      !(checkElementPresent(r, EXCEPTION, MEASURE_NAME, "liliex")
        &&
        isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "liliex_date", startDate: Date, endDate: Date)
        )
      )
      ||
      (
        checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mere_1")
          &&
          ElementDateInBackRange(r, EXCEPTION, MEASURE_NAME, endDate, "mere_1_date", 24)
        )
      )
    )
  }


  def getBackTracking(patientHistoryRDD: RDD[CassandraRow], ippRDD: RDD[CassandraRow], MEASURE_NAME: String, endDate: Date, NoOfMonths: Int, EncounterDate: String, backtrackelement1: String,
                      backtrackelement1_date: String, backtrackelement2: String, backtrakelement3: String): RDD[CassandraRow] = {

    val ipp_patient_list =
      ippRDD.map(x => x.getString("patientuid")).distinct().collect().toList
    val IPPFilterExclusionRDD = patientHistoryRDD.filter(x => (ipp_patient_list.contains(x.getString("patientuid")))).filter(r => ElementDateInBackRange(r, IPP, MEASURE_NAME, endDate, EncounterDate, NoOfMonths))
    val isExist = IPPFilterExclusionRDD.filter(r => (checkElementPresent(r, IPP, MEASURE_NAME, backtrackelement1) && ElementDateInBackRange(r, IPP, MEASURE_NAME, endDate, backtrackelement1_date, NoOfMonths) &&
      (checkElementPresent(r, IPP, MEASURE_NAME, backtrackelement2) || checkElementPresent(r, IPP, MEASURE_NAME, backtrakelement3))))
    return isExist
  }

}
