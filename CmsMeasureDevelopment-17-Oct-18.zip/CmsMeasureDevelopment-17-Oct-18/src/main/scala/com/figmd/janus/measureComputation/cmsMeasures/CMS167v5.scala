package com.figmd.janus.measureComputation.cmsMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.Measure
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object CMS167v5 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

    /** Issue with data use aao_2018, tblencounter_mat
      * diabret_eye_date is null for  diabret_eye=1
      * macexm_eye_date is null for macexm_eye =1
      * lvlsvrretf_eye is  null and vsevernprodr is also null
      * macedf_eye_date is null for macedf_eye = 1
      * pare_1 is null for every row
      */

    // Filter IPP
    val ippRDD = getIpp(rdd, MEASURE_NAME, startDate: Date, endDate: Date)
    ippRDD.cache()

    // Eligible IPP
    val eligibleRdd = ippRDD
    eligibleRdd.cache()

    // Filter Exclusion
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exclusionRDD.cache()

    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Intermediate

    val intermediateA = eligibleRdd.subtract(exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA, MEASURE_NAME: String, startDate: Date, endDate: Date)
    metRDD.cache()


    val intermediateB = intermediateA.subtract(metRDD)
    intermediateB.cache()


    // Filter Exceptions
    val exceptionRDD = getexceptionRDD(intermediateB, EXCEPTION, startDate, endDate)

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }


  def getIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    return rdd.filter(r =>

      isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)

        &&

        (
          checkElementPresent(r, IPP, MEASURE_NAME, "dire")
          &&
          (
            (isDateEqual(r, IPP, MEASURE_NAME, "dire_date", "opse_date")
             // && checkElementPresent(r, IPP, MEASURE_NAME, "dire")
              && checkElementPresent(r, IPP, MEASURE_NAME, "opse")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))

              ||
              (isDateEqual(r, IPP, MEASURE_NAME, "dire_date", "caseinlorefa_date")
             //   && checkElementPresent(r, IPP, MEASURE_NAME, "dire")
                && checkElementPresent(r, IPP, MEASURE_NAME, "caseinlorefa")
                && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))

              ||

              (isDateEqual(r, IPP, MEASURE_NAME, "dire_date", "nufavi_date")
               // && checkElementPresent(r, IPP, MEASURE_NAME, "dire")
                && checkElementPresent(r, IPP, MEASURE_NAME, "nufavi")
                && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))

              ||
              (
                isDateEqual(r, IPP, MEASURE_NAME, "dire_date", "ofvi_1_date")
                //  && checkElementPresent(r, IPP, MEASURE_NAME, "dire")
                  && checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1")
                  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))

              ||
              (
                isDateEqual(r, IPP, MEASURE_NAME, "dire_date", "ouco_1_date")
                //  && checkElementPresent(r, IPP, MEASURE_NAME, "dire")
                  && checkElementPresent(r, IPP, MEASURE_NAME, "ouco_1")
                  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))

              ||
              (isDateEqual(r, IPP, MEASURE_NAME, "dire_date", "fain_date")
               // && checkElementPresent(r, IPP, MEASURE_NAME, "dire")
                && checkElementPresent(r, IPP, MEASURE_NAME, "fain")
                && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))

            )

            &&

            (
              checkElementPresent(r, IPP, MEASURE_NAME, "diabret_eye")
                && checkElementPresent(r, IPP, MEASURE_NAME, "dire")

              /** diabret_eye_date is null for element diabret_eye = 1  **/
              // && isDateEqual(r, IPP, MEASURE_NAME, "diabret_eye_date", "dire_date")

              )

          )

    )
  }


  def getMet(intermediateA: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    return intermediateA.filter(r =>

      (

        (
          (checkElementValue(r, IPP, MEASURE_NAME, "maex", 1)
            //&& checkElementValueGreaterDouble(r, IPP, MEASURE_NAME, "mldnprfrtvdr", 0)
            && checkElementPresent(r, IPP, MEASURE_NAME, "mldnprfrtvdr")

            &&

            ((isDateEqual(r, MET, MEASURE_NAME, "mldnprfrtvdr_date", "opse_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "mldnprfrtvdr_date", "caseinlorefa_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))


              || (isDateEqual(r, MET, MEASURE_NAME, "mldnprfrtvdr_date", "nufavi_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))


              || (isDateEqual(r, MET, MEASURE_NAME, "mldnprfrtvdr_date", "ofvi_1_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "mldnprfrtvdr_date", "ouco_1_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "mldnprfrtvdr_date", "fain_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))

              )

            )

            || (checkElementValue(r, IPP, MEASURE_NAME, "maex", 1)
            // && checkElementValueGreaterDouble(r, IPP, MEASURE_NAME, "mdrtvedr", 0)
            && checkElementPresent(r, IPP, MEASURE_NAME, "mdrtvedr")

            &&

            ((isDateEqual(r, MET, MEASURE_NAME, "mdrtvedr_date", "opse_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "mdrtvedr_date", "caseinlorefa_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))


              || (isDateEqual(r, MET, MEASURE_NAME, "mdrtvedr_date", "nufavi_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))


              || (isDateEqual(r, MET, MEASURE_NAME, "mdrtvedr_date", "ofvi_1_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "mdrtvedr_date", "ouco_1_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "mdrtvedr_date", "fain_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))

              )

            )

            || (checkElementValue(r, IPP, MEASURE_NAME, "maex", 1)
            // && checkElementValueGreaterDouble(r, IPP, MEASURE_NAME, "prodiaretino", 0)
            && checkElementPresent(r, IPP, MEASURE_NAME, "prodiaretino")

            &&

            ((isDateEqual(r, MET, MEASURE_NAME, "prodiaretino_date", "opse_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "prodiaretino_date", "caseinlorefa_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))


              || (isDateEqual(r, MET, MEASURE_NAME, "prodiaretino_date", "nufavi_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))


              || (isDateEqual(r, MET, MEASURE_NAME, "prodiaretino_date", "ofvi_1_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "prodiaretino_date", "ouco_1_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "prodiaretino_date", "fain_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))

              )
            )


            || (checkElementValue(r, IPP, MEASURE_NAME, "maex", 1)
           // && checkElementValueGreaterDouble(r, IPP, MEASURE_NAME, "svrnonprlfrtvdr", 0)
            && checkElementPresent(r, IPP, MEASURE_NAME, "svrnonprlfrtvdr")

            &&

            ((isDateEqual(r, MET, MEASURE_NAME, "svrnonprlfrtvdr_date", "opse_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "svrnonprlfrtvdr_date", "caseinlorefa_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))


              || (isDateEqual(r, MET, MEASURE_NAME, "svrnonprlfrtvdr_date", "nufavi_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))


              || (isDateEqual(r, MET, MEASURE_NAME, "svrnonprlfrtvdr_date", "ofvi_1_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "svrnonprlfrtvdr_date", "ouco_1_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "svrnonprlfrtvdr_date", "fain_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))

              )
            )

            || (checkElementValue(r, IPP, MEASURE_NAME, "maex", 1)
            // && checkElementValueGreaterDouble(r, IPP, MEASURE_NAME, "vsevernprodr", 0)
               && checkElementPresent(r, IPP, MEASURE_NAME, "vsevernprodr")

            &&

            ((isDateEqual(r, MET, MEASURE_NAME, "vsevernprodr_date", "opse_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "vsevernprodr_date", "caseinlorefa_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))


              || (isDateEqual(r, MET, MEASURE_NAME, "vsevernprodr_date", "nufavi_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))


              || (isDateEqual(r, MET, MEASURE_NAME, "vsevernprodr_date", "ofvi_1_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "vsevernprodr_date", "ouco_1_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))

              || (isDateEqual(r, MET, MEASURE_NAME, "vsevernprodr_date", "fain_date")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))

              )
            )

          )

          ||

          (
            (checkElementValue(r, MET, MEASURE_NAME, "maex", 1)
              && checkElementValue(r, MET, MEASURE_NAME, "maedfiab", 1))
              ||
              (checkElementValue(r, MET, MEASURE_NAME, "maex", 1)
                && checkElementValue(r, MET, MEASURE_NAME, "maedfipr", 1))

            )
        )

      /*
              &&

               /**  macexm_eye_date is null for macexm_eye =1  **/

              isDateEqual(r, MET, MEASURE_NAME, "macexm_eye_date", "maex_date")

              &&


            /** lvlsvrretf_eye is  null and vsevernprodr is also null **/

              (

                isDateEqual(r, MET, MEASURE_NAME, "lvlsvrretf_eye_date", "prodiaretino_date")
                  ||

                  isDateEqual(r, MET, MEASURE_NAME, "lvlsvrretf_eye_date", "svrnonprlfrtvdr_date")
                  ||

                  isDateEqual(r, MET, MEASURE_NAME, "lvlsvrretf_eye_date", "mdrtvedr_date")
                  ||

                  isDateEqual(r, MET, MEASURE_NAME, "lvlsvrretf_eye_date", "mldnprfrtvdr_date")

                  || isDateEqual(r, MET, MEASURE_NAME, "lvlsvrretf_eye_date", "vsevernprodr_date")

                )

            &&

              (

                 /** macedf_eye_date is null for macedf_eye = 1 **/

                isDateEqual(r, MET, MEASURE_NAME, "macedf_eye_date", "maedfipr_date")
                  ||
                  isDateEqual(r, MET, MEASURE_NAME, "macedf_eye_date", "maedfiab_date")
                )
      */
    )

  }

  def getexceptionRDD(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    rdd.filter(r =>

      ( //checkElementPresent(r, IPP, MEASURE_NAME, "maex")
        // &&
          checkElementPresent(r, IPP, MEASURE_NAME, "mere_1")
        &&
        (
            checkElementPresent(r, IPP, MEASURE_NAME, "opse")
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate)
           // && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "maex_date", startDate, endDate)
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "mere_1_date", startDate, endDate)


            || (
                   //CaSeinLoReFa
            checkElementPresent(r, IPP, MEASURE_NAME, "caseinlorefa")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate)
             // && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "maex_date", startDate, endDate)
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "mere_1_date", startDate, endDate)

            )


            || (

              checkElementPresent(r, IPP, MEASURE_NAME, "nufavi")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate)
             // && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "maex_date", startDate, endDate)
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "mere_1_date", startDate, endDate)

            )


            || (

            checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate)
            //  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "maex_date", startDate, endDate)
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "mere_1_date", startDate, endDate)

            )


            || (

            checkElementPresent(r, IPP, MEASURE_NAME, "ouco_1")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate)
            //  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "maex_date", startDate, endDate)
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "mere_1_date", startDate, endDate)

            )


            || (

            checkElementPresent(r, IPP, MEASURE_NAME, "fain")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate)
            //  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "maex_date", startDate, endDate)
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "mere_1_date", startDate, endDate)

            )

          )

        )

        ||


        (
           //checkElementPresent(r, IPP, MEASURE_NAME, "maex")
           // &&
          /** pare_1 is null **/
              checkElementPresent(r, IPP, MEASURE_NAME, "pare_1")

            &&
            (

               checkElementPresent(r, IPP, MEASURE_NAME, "opse")
                && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate)
              //  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "maex_date", startDate, endDate)
                && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "pare_1_date", startDate, endDate)

                || (

                checkElementPresent(r, IPP, MEASURE_NAME, "caseinlorefa")
                  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate)
                //  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "maex_date", startDate, endDate)
                  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "pare_1_date", startDate, endDate)

                )

                || (

                checkElementPresent(r, IPP, MEASURE_NAME, "nufavi")
                  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate)
                //  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "maex_date", startDate, endDate)
                  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "pare_1_date", startDate, endDate)
                )

                || (
                checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1")
                  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate)
              //    && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "maex_date", startDate, endDate)
                  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "pare_1_date", startDate, endDate)


                )

                || (

                checkElementPresent(r, IPP, MEASURE_NAME, "ouco_1")
                  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate)
                //  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "maex_date", startDate, endDate)
                  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "pare_1_date", startDate, endDate)

                )


                || (

                checkElementPresent(r, IPP, MEASURE_NAME, "fain")
                  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate)
               //   && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "maex_date", startDate, endDate)
                  && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "pare_1_date", startDate, endDate)

                )

              )

          )

    )
  }

}
