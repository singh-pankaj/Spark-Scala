package com.figmd.janus.measureComputation.cmsMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.util.measure.MeasureUtility
import com.figmd.janus.{WebDataMartCreator, Measure}
import org.apache.spark.rdd.RDD

import org.apache.spark.sql.SparkSession

  object CMS155v5_C_2 extends MeasureUtility with Measure {

    def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

      // Filter IPP
      val ippRDD = getIpp(rdd, startDate, endDate, MEASURE_NAME)
      ippRDD.cache()
      //NotEligiable
      val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD,startDate,endDate,MEASURE_NAME)
      exclusionRDD.cache()
      // Filter Intermediate
      val intermediate =  getSubtractRDD(ippRDD,exclusionRDD)
      intermediate.cache()
      // Filter Met

      //met
      val metRDD = getMet(intermediate,startDate,endDate,MEASURE_NAME)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not meate
      val notMetRDD = getinterRDD(intermediate,metRDD)
      notMetRDD.cache()

      //measure.M155_31.element.select=practiceuid,serviceprovideruid,locationid,patientuid,visituid,genderuid,dob,encounterdate,firstname,midname,lastname,patient_mrn,fain,fain_date,ofvi_1,ofvi_1_date,prcaseco,prcaseco_date,prcaseinofvi0to17,prcaseinofvi0to17_date,prcaesofvi0to17,prcaesofvi0to17_date,prcasegrco,prcasegrco_date,hohese,hohese_date,enin_1,ditohofohoca,enin_1_date,ditohecafafohoca,hocaam,hocaam_date,prncy,prncy_date,cofophac,cofophac_date

      saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

    }

    // Filter IPP
    def getIpp(rdd: RDD[CassandraRow], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {
      rdd.filter(r =>
        (
          isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 11) &&
            isAgeLess(r, IPP, MEASURE_NAME, "dob", "encounterdate", 17) &&

            (
              (checkElementPresent(r, IPP, MEASURE_NAME, "fain") &&
                isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate)
                )
                ||
                (checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1") &&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate)
                  )
                ||
                (checkElementPresent(r, IPP, MEASURE_NAME, "prcaseco") &&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "prcaseco_date", startDate, endDate)
                  )
                ||
                (checkElementPresent(r, IPP, MEASURE_NAME, "prcaseinofvi0to17") &&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "prcaseinofvi0to17_date", startDate, endDate))
                ||

                (checkElementPresent(r, IPP, MEASURE_NAME, "prcaesofvi0to17") &&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "prcaesofvi0to17_date", startDate, endDate)
                  )
                ||
                (checkElementPresent(r, IPP, MEASURE_NAME, "prcasegrco") &&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "prcasegrco_date", startDate, endDate)
                  )
                ||
                (checkElementPresent(r, IPP, MEASURE_NAME, "hohese") &&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "hohese_date", startDate, endDate)
                  )


              )
          )
      )

    }

    def getExclusionRdd(ippRDD: RDD[CassandraRow], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {

      ippRDD.filter(r =>
        (
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "enin_1") &&
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohofohoca") &&
              isDateOverlapsMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "enin_1_date", endDate)
            )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "enin_1") &&
                checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohecafafohoca") &&
                isDateOverlapsMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "enin_1_date", endDate)
              )
          )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hocaam") &&
              isDateOverlapsMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hocaam_date", endDate)
            )

          /*//column not found in cassandra  ******* prncy, prncy_date **********
          ||

          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "prncy") &&
              isDateEqual(r, EXCLUSION, MEASURE_NAME, "prncy_date", "encounterdate")

            )*/
      )

    }

    def getMet(ippRDD: RDD[CassandraRow] ,startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {
      ippRDD.filter(r =>
        (
          (
            checkElementPresent(r, MET, MEASURE_NAME, "cofophac")&&
              checkElementPresent(r, MET, MEASURE_NAME, "fain") &&
              isDateEqual(r, MET, MEASURE_NAME, "cofophac_date", "fain_date")
            )
            ||
            (
              checkElementPresent(r, MET, MEASURE_NAME, "cofophac")&&
                checkElementPresent(r, MET, MEASURE_NAME, "ofvi_1") &&
                isDateEqual(r, MET, MEASURE_NAME, "cofophac_date", "ofvi_1_date")
              )
            ||
            (
              checkElementPresent(r, MET, MEASURE_NAME, "cofophac")&&
                checkElementPresent(r, MET, MEASURE_NAME, "prcaseco") &&
                isDateEqual(r, MET, MEASURE_NAME, "cofophac_date", "prcaseco_date")
              )
            ||
            (
              checkElementPresent(r, MET, MEASURE_NAME, "cofophac")&&
                checkElementPresent(r, MET, MEASURE_NAME, "prcaseinofvi0to17") &&
                isDateEqual(r, MET, MEASURE_NAME, "cofophac_date", "prcaseinofvi0to17_date")
              )
            ||
            (
              checkElementPresent(r, MET, MEASURE_NAME, "cofophac")&&
                checkElementPresent(r, MET, MEASURE_NAME, "prcaesofvi0to17") &&
                isDateEqual(r, MET, MEASURE_NAME, "cofophac_date", "prcaesofvi0to17_date")
              )
            ||
            (
              checkElementPresent(r, MET, MEASURE_NAME, "cofophac")&&
                checkElementPresent(r, MET, MEASURE_NAME, "prcasegrco") &&
                isDateEqual(r, MET, MEASURE_NAME, "cofophac_date", "prcasegrco_date")
              )
            ||
            (
              checkElementPresent(r, MET, MEASURE_NAME, "cofophac")&&
                checkElementPresent(r, MET, MEASURE_NAME, "hohese") &&
                isDateEqual(r, MET, MEASURE_NAME, "cofophac_date", "hohese_date")
              )
          )



      )

    }


  }


