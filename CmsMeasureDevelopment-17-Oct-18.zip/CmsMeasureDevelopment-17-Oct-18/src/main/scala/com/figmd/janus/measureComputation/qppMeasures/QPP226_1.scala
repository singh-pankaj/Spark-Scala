package com.figmd.janus.measureComputation.qppMeasures
import java.util.Date

import com.figmd.janus.Measure
import com.figmd.janus.util._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator.prop
import com.figmd.janus.util.measure.MeasureUtility

import scala.reflect.macros.whitebox




object QPP226_1 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession,rdd:RDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    //Backtracking from History Table
    var columnRef = getFiledList(MEASURE_NAME)
    var patientHistoryRDD =  sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"),
      prop.getProperty("patientHistory")).select("patientuid","mere_1","mere_1_date","scrn_tbcuser","scrn_tbcuser_date","toussc","toussc_date","scrn_tbconuser","scrn_tbconuser_date")


    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()

    //MostRecentFunction
    val mostRecentRDD = mostRecentRecord226(ippRDD:RDD[CassandraRow],MEASURE_NAME,"patientuid","encounterdate")


    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    //Backtracking List
    var CRA = getBackTrackingList(patientHistoryRDD, ippRDD, "mere_1","mere_1_date","scrn_tbcuser","scrn_tbcuser_date","toussc","toussc_date","scrn_tbconuser","scrn_tbconuser_date");
    val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)

    //Exclusion
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //exclusionRDD.cache()

    //MetRdd
    val metRDD = getMet(mostRecentRDD,MEASURE_NAME,CRA_list: Broadcast[List[String]])
    metRDD.cache()

    // Filter Exceptions
    val intermediate = getinterRDD(mostRecentRDD,metRDD)
    intermediate.cache()

    //Exception
    val exceptionRDD =getexceptionRDD(intermediate,MEASURE_NAME,CRA_list: Broadcast[List[String]])
    exceptionRDD.cache()

    // Filter not Met
    val notMetRDD1 =  getinterRDD(intermediate,exceptionRDD)
    notMetRDD1.cache()

    val notMetRDD= getInterMediate(ippRDD,notMetRDD1)


    saveToWebDM(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }

  // Filter IPP
  def getIpp(rdd:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    rdd
      .filter(r =>
          (
            (
              isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18) &&

              (
                checkElementCountGreaterOrEqual(r,IPP,MEASURE_NAME,2,"fain","hebeasin","heanbeasin","heanbeasre",
                    "hohese","octhev","ofvi_1","opse","psvidiev","psvips","psyc","spanheev")


              )||
                (
                    checkElementCountGreaterOrEqual(r,IPP,MEASURE_NAME,1,"anwevi_1","prcasegrco","prcaseesofvi18anup_1",
                    "prcaseot","prcaseco","prcaseofvi18anup_1","hlthrskasesmnt")
                )
                )&&
                  (
                      checknull(r, IPP, MEASURE_NAME, "ocptnthpyeval_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "pcsotm") ||
                      checknull(r, IPP, MEASURE_NAME, "spchhrngeval_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "annlwelnsv_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "ov_thmdmod95") ||
                      checknull(r, IPP, MEASURE_NAME, "hlthbehaasstindi_tm")||
                      checknull(r, IPP, MEASURE_NAME, "hlthbehaassti_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "hlthbehaasst_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "pci18_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "pcseov18_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "psyv_de_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "pcsgcouns_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "psycho_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "psyvp_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "os_thmd") ||
                      checknull(r, IPP, MEASURE_NAME, "hmhlthsrvc_tm") ||
                      checknull(r, IPP, MEASURE_NAME, "hra_tm")

                  )||
              (
                checknull(r, IPP, MEASURE_NAME, "telehealth")

              )

             )


      )
  }

  def getMet(intermediateA:RDD[CassandraRow],MEASURE_NAME:String,CRA_list: Broadcast[List[String]]): RDD[CassandraRow] = {
    intermediateA.filter(r =>
      (
        (
          BackTrackingMet(r, MET, MEASURE_NAME, CRA_list)

          )

        )
    )
  }
  def getexceptionRDD(intermediateRDD:RDD[CassandraRow],MEASURE_NAME:String,CRA_list: Broadcast[List[String]]): RDD[CassandraRow] = {
    intermediateRDD.filter(r =>

      (
        checkElementPresent(r, EXCEPTION, MEASURE_NAME, "liliex")
      )
      ||
        (
          BackTrackingException(r, EXCLUSION, MEASURE_NAME, CRA_list)
         )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "cesint_medrsn") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "mere_1_date", "encounterdate")

          )

    )
  }

  def getInterMediate(ippRDD: RDD[CassandraRow],metRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val InterMediate = metRDD.map(r => r.getString("visituid")).collect().toList
    val InterMediateA = ippRDD.filter(r => !InterMediate.contains(r.getString("visituid")))
    return InterMediateA
  }


  def BackTrackingException(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {
    val flag = false;

    for (x <- CRA.value) {
      if (x != "") {
        val back_data = x.split("~")
        val patientid = back_data(0);
        //val mere_1_element = back_data(1);
        val mere_1_date_back =dateUtility.dateTimeParse(back_data(2));



        if ((!r.isNullAt("encounterdate") )
          && ( (r.getString("patientuid").equals(patientid))
          &&
          (
           (r.getString("toussc").equals(1) && r.getString("tobacouser").equals(1)&&
             (
             (r.getDateTime("encounterdate").minusYears(2).isAfter(mere_1_date_back))||
              r.getDateTime("encounterdate").isBefore(mere_1_date_back)
              )
           )



            )

          )
        )
        {
          return true;
        }

      }

    }

    return flag;

  }

  def BackTrackingMet(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {
    val flag = false;

    for (x <- CRA.value) {
      if (x != "") {
        //println(r.getString("visituid") + ">>>" + x)
        val back_data = x.split("~")
        val patientid = back_data(0);
        val mere_1_element = back_data(1);
        val mere_1_date_back =dateUtility.dateTimeParse(back_data(2));
        val scrn_tbcuser_date_back =dateUtility.dateTimeParse(back_data(4));
        val toussc_date_back =dateUtility.dateTimeParse(back_data(6));
        val scrn_tbconuser_date_back =dateUtility.dateTimeParse(back_data(8));


        if ((!r.isNullAt("encounterdate") )
          && ( (r.getString("patientuid").equals(patientid))
          &&
          (
            (r.getString("toussc").equals(1) && r.getString("tobacouser").equals(1)&& r.getString("mera_1").equals(1) &&
              (
                (r.getDateTime("encounterdate").minusYears(2).isAfter(mere_1_date_back))||
                  r.getDateTime("encounterdate").isBefore(mere_1_date_back)
                )
              )
              ||
              ( r.getString("scrn_tbcuser").equals(1) &&
                (
                  (r.getDateTime("encounterdate").minusYears(2).isAfter(mere_1_date_back))||
                    r.getDateTime("encounterdate").isBefore(mere_1_date_back)
                  )
                )
              ||
              ( r.getString("toussc").equals("1") && r.getString("tobnonusr").equals("1") &&
              (
                (r.getDateTime("encounterdate").minusYears(2).isAfter(toussc_date_back))||
                  r.getDateTime("encounterdate").isBefore(toussc_date_back)
              )
                )
              ||
              ( r.getString("scrn_tbconuser").equals(1) &&
              (
                (r.getDateTime("encounterdate").minusYears(2).isAfter(scrn_tbconuser_date_back))||
                  r.getDateTime("encounterdate").isBefore(scrn_tbconuser_date_back)
              )
                )
            )

          )
        )
        {
          return true;
        }

      }

    }

    return flag;

  }

  def getBackTrackingList(rdd: RDD[CassandraRow],ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement2: String,backtrackelement3: String, backtrackelement4: String,
    backtrackelement5: String, backtrackelement6: String,backtrackelement7: String, backtrackelement8: String): List[String] = {
    if (!ippRDD.isEmpty && !rdd.isEmpty) {


      val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).collect().toList

      val BacktrackingRDD = rdd.filter(x => ipp_patient_list.contains(x.getString("patientuid")))

      val CRA = BacktrackingRDD.map(x =>
        //&& !x.isNullAt("mere_1") && !x.isNullAt("mere_1_date") && !x.isNullAt("scrn_tbcuser")
        //          && !x.isNullAt("scrn_tbcuser_date") && !x.isNullAt("toussc") && !x.isNullAt("toussc_date") && !x.isNullAt("scrn_tbconuser")
        //          && !x.isNullAt("scrn_tbconuser_date")
        if (!x.isNullAt("patientuid") ) {

          x.getString("patientuid") + "~" + x.getString("mere_1") + "~" + x.getString("mere_1_date") + "~" + x.getString("scrn_tbcuser") +
            "~" + x.getString("scrn_tbcuser_date") + "~" + x.getString("toussc") + "~" + x.getString("toussc_date") + "~" + x.getString("scrn_tbconuser") + "~" + x.getString("scrn_tbconuser_date")
        }
        else
          ""
        //        x.getString("patientuid"),
        //        if (!x.isNullAt("mere_1")) x.getString("mere_1") else "",
        //        if (!x.isNullAt("mere_1_date")) x.getString("mere_1_date") else "",
        //        if (!x.isNullAt("scrn_tbcuser")) x.getString("scrn_tbcuser") else "",
        //        if (!x.isNullAt("scrn_tbcuser_date")) x.getString("scrn_tbcuser_date") else "",
        //        if (!x.isNullAt("toussc")) x.getString("toussc") else "",
        //        if (!x.isNullAt("toussc_date")) x.getString("toussc_date") else "",
        //        if (!x.isNullAt("scrn_tbconuser")) x.getString("scrn_tbconuser") else "",
        //        if (!x.isNullAt("scrn_tbconuser_date")) x.getString("scrn_tbconuser_date") else ""

      )
      CRA.foreach(println)
      if (!CRA.isEmpty())
        CRA.collect().toList
      else{
        val l = List[String]()
        l
      }
      }
      else {
        val l = List[String]()
        l
      }
  }


}
