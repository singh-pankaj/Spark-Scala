package com.figmd.janus.util.measure

import com.figmd.janus.WebDataMartCreator.{measure_list, prop}

class SetPropertyArgs(args:Array[String]) {


  /*
  prop.setProperty("wf_id", args(0))
  prop.setProperty("postgresHostName",args(1))
  prop.setProperty("postgresHostPort",args(2))
  prop.setProperty("postgresConfigDatabaseName",args(3))
  prop.setProperty("postgresHostUserName",args(4))
  prop.setProperty("postgresUserPass",args(5))
  prop.setProperty("equal_measure_list",args(6))
  prop.setProperty("num_executors",args(7))
  prop.setProperty("executor_cores",args(8))
  prop.setProperty("executor_memory",args(9))
  prop.setProperty("keyspace_datamart",args(10))
  prop.setProperty("keyspace_datamart_table_name",args(11))
  prop.setProperty("keyspace_webdatamart",args(12))
  prop.setProperty("cassandra_host",args(13))
  prop.setProperty("cassandra_port",args(14))
  prop.setProperty("spark_master_url",args(15))
  prop.setProperty("measure_computation_output_path",args(16))
  prop.setProperty("mode",args(17))
  prop.setProperty("postgresManagementDatabaseName",args(18))
  prop.setProperty("wfType",args(19))
  prop.setProperty("DateRange",args(20))
  prop.setProperty("cms_measure_list",args(21))
  prop.setProperty("qpp_measure_list",args(22))
  prop.setProperty("nonqpp_measure_list",args(23))
  prop.setProperty("practice_id_list",args(24))
  prop.setProperty("median_measure_list",args(25))
*/
  prop.setProperty("quarterStartDate1", "2016-01-01")
  prop.setProperty("quarterEndDate1", "2018-03-31")
  prop.setProperty("wf_id", "WF_TEST")
  prop.setProperty("postgresHostName","10.20.201.103")
  prop.setProperty("postgresHostPort","5432")
  prop.setProperty("postgresConfigDatabaseName","config_db")
  prop.setProperty("postgresManagementDatabaseName","acepmgt")
  prop.setProperty("postgresHostUserName","postgres")
  prop.setProperty("postgresUserPass","Janus@123")
  prop.setProperty("num_executors","5")
  prop.setProperty("executor_cores","5")
  prop.setProperty("executor_memory","4G")
  prop.setProperty("keyspace_datamart","aao_new_datamart")//acepnonqpp1718 acep2018 acep_aug_2018, acc_2018 aao_2018 abfm_2018 aao_new_datamart
  prop.setProperty("keyspace_datamart_table_name","tblencounter")//tblencounter_nonqpp, tblencounter_qpp tblencounter_mat tblencounter
  prop.setProperty("keyspace_webdatamart","aao_new_datamart") //webdatamart2018 acc_2018
  prop.setProperty("keyspace_datamart_history","aao_new_datamart")//acepnonqpp1718 aao_datamart tblencounter_qpp
  prop.setProperty("patientHistory","patient_history")//tblencounter_nonqpp tblencounter_qpp204
  prop.setProperty("cassandra_port","9042")
  prop.setProperty("measure_computation_output_path","hdfs://ip-10-20-201-103.us-gov-west-1.compute.internal:8020/tmp/ACEP1")
/*  prop.setProperty("mode","cluster")
  prop.setProperty("cassandra_host","10.20.201.152") //10.20.201.152
  prop.setProperty("spark_master_url","yarn")*/

  //abfm_2018    155
  //tblencounter_mat

      prop.setProperty("spark_master_url","local[8]")
      prop.setProperty("cassandra_host","10.20.201.152")
      prop.setProperty("mode","client")

  prop.setProperty("wfType","QR")
  prop.setProperty("DateRange","[2018-01-01~2018-03-30]")
  prop.setProperty("equal_measure_list","NA")
  prop.setProperty("cms_measure_list","") // M138v5_1 M138v5_1 M167v5
  prop.setProperty("qpp_measure_list","M100_2") // M204_1 M204_3 M118_1,M118_2
  prop.setProperty("nonqpp_measure_list","NA")
  prop.setProperty("practice_id_list","NA")//31f659ea-994b-4570-9180-f302c7ce5fae,6fab4a70-6e66-4676-a507-3562c5b7cd39
  prop.setProperty("median_measure_list","NA")
  prop.setProperty("log_file","/tmp/CMS/logger")

  //#############################################################################################################################################

  prop.setProperty("keyspace_datamart_table_name_emergencydept_master","emergencydept_master")

  //practice list for measure computation
  if(prop.getProperty("practice_id_list")!="NA" && prop.getProperty("practice_id_list")!="")
    prop.setProperty("practiceListCondition","and practiceuid in("+prop.getProperty("practice_id_list")+")")
  else
    prop.setProperty("practiceListCondition","")
  var equal_measure_list=""
  var qpp_measure_list=""
  var nonqpp_measure_list=""
  var cms_measure_list=""
  var median_measure_list=""


  equal_measure_list = prop.getProperty("equal_measure_list")
  qpp_measure_list = prop.getProperty("qpp_measure_list")
  nonqpp_measure_list = prop.getProperty("nonqpp_measure_list")
  cms_measure_list = prop.getProperty("cms_measure_list")
  median_measure_list = prop.getProperty("median_measure_list")

  if (!equal_measure_list.equalsIgnoreCase("NA")) {
    if (measure_list.isEmpty) {
      measure_list = equal_measure_list
    } else {
      measure_list += "," + equal_measure_list
    }
  }
  if (!qpp_measure_list.equalsIgnoreCase("NA")) {
    if (measure_list.isEmpty) {
      measure_list = qpp_measure_list
    } else {
      measure_list += "," + qpp_measure_list
    }
  }

  if (!nonqpp_measure_list.equalsIgnoreCase("NA")) {
    if (measure_list.isEmpty) {
      measure_list = nonqpp_measure_list
    } else {
      measure_list += "," + nonqpp_measure_list
    }
  }
  if (!cms_measure_list.equalsIgnoreCase("NA")) {
    if (measure_list.isEmpty) {
      measure_list = cms_measure_list
    } else {
      measure_list += "," + cms_measure_list
    }
  }
  if (!median_measure_list.equalsIgnoreCase("NA")) {
    if (measure_list.isEmpty) {
      measure_list = median_measure_list
    } else {
      measure_list += "," + median_measure_list
    }
  }

  println("Measure List:::"+measure_list)

}
