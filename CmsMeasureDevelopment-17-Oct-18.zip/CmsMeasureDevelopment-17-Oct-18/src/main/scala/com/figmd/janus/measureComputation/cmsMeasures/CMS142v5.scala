package com.figmd.janus.measureComputation.cmsMeasures



  import java.util.Date

  import com.datastax.spark.connector.CassandraRow
  import com.figmd.janus.{WebDataMartCreator, Measure}

  import org.apache.spark.sql.SparkSession
  import com.datastax.spark.connector.rdd.CassandraTableScanRDD
  import com.figmd.janus.util.measure.MeasureUtility
  import org.apache.spark.rdd.RDD

  object CMS142v5 extends MeasureUtility with Measure {

    def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

      // Filter IPP
      val ippRDD = getIpp(rdd, startDate, endDate, MEASURE_NAME)
      ippRDD.cache()
      // Eligible IPP
      val eligibleRdd = getEligibleIpp(ippRDD,startDate, endDate,MEASURE_NAME)
      // Filter Exclusions
      val notEligibleRDD =ippRDD.subtract(eligibleRdd)
      eligibleRdd.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Intermediate
       val intermediateA = getSubtractRDD(eligibleRdd, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA,startDate, endDate, MEASURE_NAME)
      metRDD.cache()

      // Filter Exceptions
      val intermediateB =  getinterRDD(intermediateA,metRDD)
      intermediateB.cache()

      val exceptionRDD =getexceptionRDD(intermediateB,startDate, endDate,MEASURE_NAME)
      exceptionRDD.cache()

      // Filter not meate
      val notMetRDD =  getinterRDD(intermediateB,exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

    }



    // Filter IPP
   def getIpp(rdd:RDD[CassandraRow], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {
      rdd
        .filter(r =>

          isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)
            &&
                checkElementPresent(r, IPP, MEASURE_NAME, "dire") &&
                    (
                      (
                    checkElementPresent(r, IPP, MEASURE_NAME, "opse") &&
                    isDateEqual(r, IPP, MEASURE_NAME, "dire_date", "opse_date") &&
                    isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate)
                   ) ||
                  (
                      checkElementPresent(r, IPP, MEASURE_NAME, "caseinlorefa") &&
                      isDateEqual(r, IPP, MEASURE_NAME, "dire_date", "caseinlorefa_date") &&
                      isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate)
                    ) ||
                  (
                      checkElementPresent(r, IPP, MEASURE_NAME, "nufavi") &&
                      isDateEqual(r, IPP, MEASURE_NAME, "dire_date", "nufavi_date") &&
                      isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate)
                    ) ||
                  (
                      checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1") &&
                      isDateEqual(r, IPP, MEASURE_NAME, "dire_date", "ofvi_1_date") &&
                      isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate)
                    ) ||
                  (
                      checkElementPresent(r, IPP, MEASURE_NAME, "ouco_1") &&
                      isDateEqual(r, IPP, MEASURE_NAME, "dire_date", "ouco_1_date") &&
                      isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate)
                    ) ||
                  (
                      checkElementPresent(r, IPP, MEASURE_NAME, "fain") &&
                      isDateEqual(r, IPP, MEASURE_NAME, "dire_date", "fain_date") &&
                      isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate)
                    )
                  )
                &&
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "diabret_eye") &&
                    checkElementPresent(r, IPP, MEASURE_NAME, "dire")

                  /**** diabret_eye_date is null for element diabret_eye = 1  ****/
                  //&&isDateEqual(r, IPP, MEASURE_NAME, "diabret_eye_date", "dire_date")
                  )

        )

    }


   def getEligibleIpp(ippRDD: RDD[CassandraRow],startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {
      ippRDD.filter(r =>
        checkElementPresent(r, ELIGIBLE, MEASURE_NAME, "maex") &&
          (
            (checkElementPresent(r, IPP, MEASURE_NAME, "opse") &&
              isDateEqual(r, ELIGIBLE, MEASURE_NAME, "maex_date", "opse_date")
              )||

              (checkElementPresent(r, IPP, MEASURE_NAME, "caseinlorefa") &&
                isDateEqual(r, ELIGIBLE, MEASURE_NAME, "maex_date", "caseinlorefa_date")
                )||

              (checkElementPresent(r, IPP, MEASURE_NAME, "nufavi") &&
                isDateEqual(r, ELIGIBLE, MEASURE_NAME, "maex_date", "nufavi_date")
                )||

              (checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1") &&
                isDateEqual(r, ELIGIBLE, MEASURE_NAME, "maex_date", "ofvi_1_date")
                )||

              (checkElementPresent(r, IPP, MEASURE_NAME, "ouco_1") &&
                isDateEqual(r, ELIGIBLE, MEASURE_NAME, "maex_date", "ouco_1_date")
                )||

              (checkElementPresent(r, IPP, MEASURE_NAME, "fain") &&
                isDateEqual(r, ELIGIBLE, MEASURE_NAME, "maex_date", "fain_date")
                )
            )
          &&
          (
            checkElementPresent(r, ELIGIBLE, MEASURE_NAME, "macexm_eye")
            /**** macexm_eye_date is null for element macexm_eye = 1  ****/
             // && isDateEqual(r, ELIGIBLE, MEASURE_NAME, "macexm_eye_date", "maex_date")
            )
      )
    }

    def getMet(intermediateA:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {

      intermediateA.filter(r =>(
        (

      (
         (
            (
              checkElementPresent(r, MET, MEASURE_NAME, "prodiaretino") &&
                (
                  (  isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "prodiaretino_date","opse_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))||
                    (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "prodiaretino_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                    (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "prodiaretino_date","nufavi_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                    (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "prodiaretino_date","ofvi_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                    (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "prodiaretino_date","ouco_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                    (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "prodiaretino_date","fain_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))
                  )
              )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "svrnonprlfrtvdr") &&
                  (
                    (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "svrnonprlfrtvdr_date","opse_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "svrnonprlfrtvdr_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "svrnonprlfrtvdr_date","nufavi_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "svrnonprlfrtvdr_date","ofvi_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "svrnonprlfrtvdr_date","ouco_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "svrnonprlfrtvdr_date","fain_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))
                    )
                )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "mdrtvedr") &&
                  (
                    (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "mdrtvedr_date","opse_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "mdrtvedr_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "mdrtvedr_date","nufavi_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "mdrtvedr_date","ofvi_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "mdrtvedr_date","ouco_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "mdrtvedr_date","fain_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))
                    )
                )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "mldnprfrtvdr") &&
                  (
                    (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "mldnprfrtvdr_date","opse_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "mldnprfrtvdr_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "mldnprfrtvdr_date","nufavi_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "mldnprfrtvdr_date","ofvi_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "mldnprfrtvdr_date","ouco_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "mldnprfrtvdr_date","fain_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))
                    )
                )
            )
           ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "vsevernprodr") &&
                  (
                    (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "vsevernprodr_date","opse_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "vsevernprodr_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "vsevernprodr_date","nufavi_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "vsevernprodr_date","ofvi_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "vsevernprodr_date","ouco_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "vsevernprodr_date","fain_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))
                    )
                )
            )


            &&

            (
              checkElementPresent(r, MET, MEASURE_NAME, "lvlsvrretf_eye") &&
                (
                  isDateEqual(r, MET, MEASURE_NAME, "lvlsvrretf_eye_date","prodiaretino_date")||
                    isDateEqual(r, MET, MEASURE_NAME, "lvlsvrretf_eye_date","svrnonprlfrtvdr_date")||
                    isDateEqual(r, MET, MEASURE_NAME, "lvlsvrretf_eye_date","mdrtvedr_date")||
                    isDateEqual(r, MET, MEASURE_NAME, "lvlsvrretf_eye_date","mldnprfrtvdr_date")||
                    isDateEqual(r, MET, MEASURE_NAME, "lvlsvrretf_eye_date","vsevernprodr_date")

                  )


              )

          )
          &&
          (
            (

              (
                checkElementPresent(r, MET, MEASURE_NAME, "maedfipr") &&
                  (
                    (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "maedfipr_date","opse_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "maedfipr_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "maedfipr_date","nufavi_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "maedfipr_date","ofvi_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "maedfipr_date","ouco_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "maedfipr_date","fain_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))
                    )
                )
                ||

                (
                  checkElementPresent(r, MET, MEASURE_NAME, "maedfiab") &&
                    (
                      (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "maedfiab_date","opse_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "opse_date", startDate, endDate))||
                        (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "maedfiab_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                        (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "maedfiab_date","nufavi_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                        (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "maedfiab_date","ofvi_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                        (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "maedfiab_date","ouco_1_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                        (isDateStartsAfterOrConcurrentWithStartOf(r, MET, MEASURE_NAME, "maedfiab_date","fain_date") && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))
                      )
                  )
              )
              &&
              (
                (
                  checkElementPresent(r, MET, MEASURE_NAME, "macedf_eye") &&
                    checkElementPresent(r, MET, MEASURE_NAME, "maedfipr") &&
                    isDateEqual(r, MET, MEASURE_NAME, "macedf_eye_date","maedfipr_date")
                  )
                  ||
                  (
                    checkElementPresent(r, MET, MEASURE_NAME, "macedf_eye") &&
                      checkElementPresent(r, MET, MEASURE_NAME, "maedfiab") &&
                      isDateEqual(r, MET, MEASURE_NAME, "macedf_eye_date","maedfiab_date")
                    )
                )

            )
      )
      )
    }

    def getexceptionRDD(intermediateRDD: RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME: String): RDD[CassandraRow] = {
      intermediateRDD.filter(r =>

        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mere_1") && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "maedfiab") &&
            (
              (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
              )
          )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "pare_1") && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "maedfiab") &&
              (
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
                )
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mere_1") && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "maedfipr") &&
              (
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
                )
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "pare_1") && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "maedfipr") &&
              (
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
                )
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mere_1") &&  checkElementPresent(r, EXCEPTION, MEASURE_NAME, "prodiaretino") &&
              (
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
                )
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mere_1") &&  checkElementPresent(r, EXCEPTION, MEASURE_NAME, "svrnonprlfrtvdr") &&
              (
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
                )
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mere_1") &&  checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mdrtvedr") &&
              (
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
                )
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mere_1") &&  checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mldnprfrtvdr") &&
              (
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
                )
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mere_1") &&  checkElementPresent(r, EXCEPTION, MEASURE_NAME, "vsevernprodr") &&
              (
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "mere_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
                )
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "pare_1") && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "prodiaretino") &&
              (
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
                )
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "pare_1") && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "svrnonprlfrtvdr") &&
              (
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
                )
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "pare_1") && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mdrtvedr") &&
              (
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
                )
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "pare_1") && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mldnprfrtvdr") &&
              (
                (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
                )
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "pare_1") && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "vsevernprodr") &&
              (
                 (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","opse_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "opse_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","caseinlorefa_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "caseinlorefa_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","nufavi_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "nufavi_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ofvi_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ofvi_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","ouco_1_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "ouco_1_date", startDate, endDate))||
                  (isDateStartsAfterOrConcurrentWithStartOf(r, EXCEPTION, MEASURE_NAME, "pare_1_date","fain_date") && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "fain_date", startDate, endDate))
                )
            )
      )

    }



  }


