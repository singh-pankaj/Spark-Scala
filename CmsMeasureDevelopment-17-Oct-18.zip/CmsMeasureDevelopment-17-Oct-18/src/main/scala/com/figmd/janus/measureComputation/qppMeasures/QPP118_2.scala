package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.Measure
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object QPP118_2 extends MeasureUtility with Measure {

  /** column misising from cassandra echo2d,echo2d_date,lvefassmnt,lvefassmnt_date,acearbthrpallg,acearbthrpallg_date,aormitdis,aormitdis_date,lckdrgavlblty,lckdrgavlblty_date  **/

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

    val InitialRDD = getInitialIpp(rdd, startDate, endDate, MEASURE_NAME)


    val Count2_RDD = countElement(InitialRDD, MEASURE_NAME, startDate, endDate, "encounterdate").collect()


    val Count2Broadcast: Broadcast[Array[(String, String, Int)]] = sparkSession.sparkContext.broadcast(Count2_RDD)

    val ippRDD = getIpp(InitialRDD, Count2Broadcast: Broadcast[Array[(String, String, Int)]], startDate, endDate, MEASURE_NAME)
    ippRDD.cache()


    // Eligible IPP
    val eligibleRdd = ippRDD
    eligibleRdd.cache()

    // Filter Exclusion
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exclusionRDD.cache()

    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Intermediate

    val intermediateA = eligibleRdd.subtract(exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA, startDate, endDate, MEASURE_NAME)
    metRDD.cache()


    val intermediateB = intermediateA.subtract(metRDD)
    intermediateB.cache()


    // Filter Exceptions
    val exceptionRDD = getexceptionRDD(intermediateB, startDate, endDate, MEASURE_NAME)

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }


  // Filter IPP
  def getInitialIpp(rdd: RDD[CassandraRow], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {

    // ofvi_1  nufavi  caseinlorefa hohese

    rdd.filter(r =>

      isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)

        // coardi

        &&

        (
          (
        (checkElementPresent(r, IPP, MEASURE_NAME, "coardi")
        && isDateEqual(r, IPP, MEASURE_NAME, "encounterdate", "coardi_date"))

        /** diab_2,diab_2_date new element **/

        && (checkElementPresent(r, IPP, MEASURE_NAME, "diab_2")
            && isDateEqual(r, IPP, MEASURE_NAME, "encounterdate", "diab_2_date"))

          && (

          // Startbeforeendof  leveejfr_date
          (
            checkElementPresent(r, IPP, MEASURE_NAME, "leveejfr")
              && isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "leveejfr_date", "encounterdate")

            )

            ||
            (checkElementPresent(r, IPP, MEASURE_NAME, "lefvenejefra")
              && isDateEqual(r, IPP, MEASURE_NAME, "lefvenejefra_date", "encounterdate")
              )

            /** echo2d  lvefassmnt **/
            // echo2d lefvenejefra  echo2d leveejfr lvefassmnt

            ||

            (
              (
                /** echo2d echo2d_date**/
                /*        (checkElementPresent(r,IPP,MEASURE_NAME,"echo2d")
                       isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "echo2d_date", "encounterdate"))

                      &&   */

                (checkElementPresent(r,IPP,MEASURE_NAME,"lefvenejefra")
                  && isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "lefvenejefra_date", "encounterdate")
                  // )
                  )

                  ||

                  (

                    /**echo2d echo2d_date is missing **/

                    /*  (checkElementPresent(r,IPP,MEASURE_NAME,"echo2d")
                      && isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "echo2d_date", "encounterdate"))*/

                    // &&
                    (checkElementPresent(r, IPP, MEASURE_NAME, "leveejfr")
                      && isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "leveejfr_date", "encounterdate"))
                    )

                // ||

                /**lvefassmnt  lvefassmnt_date is missing **/
                /* (checkElementPresent(r,IPP,MEASURE_NAME,"lvefassmnt")
                 && isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME, "lvefassmnt_date", "encounterdate"))*/
                )

              )
          )


        ||

         (
           (checkElementPresent(r, IPP, MEASURE_NAME, "coardi")
            && isDateEqual(r, IPP, MEASURE_NAME, "encounterdate", "coardi_date"))

          &&
          (checkElementPresent(r, IPP, MEASURE_NAME, "diab_2")
          && isDateEqual(r, IPP, MEASURE_NAME, "encounterdate", "diab_2_date"))

        )


    )
          )
        && !(

            ( checkElementPresent(r, IPP, MEASURE_NAME, "hmhlthsrvc_tm")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "hmhlthsrvc_tm_date", startDate, endDate))

          ||  ( checkElementPresent(r, IPP, MEASURE_NAME, "csltrf_tm")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "csltrf_tm_date", startDate, endDate))

          ||  ( checkElementPresent(r, IPP, MEASURE_NAME, "nrsnfcltvst_tm")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "nrsnfcltvst_tm_date", startDate, endDate))

          ||  ( checkElementPresent(r, IPP, MEASURE_NAME, "ov_thmdmod95")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ov_thmdmod95_date", startDate, endDate))

        )


        && !(checkElementPresent(r, IPP, MEASURE_NAME, "telehealth")
            && isDateEqual(r, IPP, MEASURE_NAME, "telehealth_date", "encounterdate"))

    )


  }

  def getIpp(rdd1: RDD[CassandraRow], IppCountrdd2: Broadcast[Array[(String, String, Int)]], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {

    rdd1.filter(r => countElementRowWise(r, IppCountrdd2, MEASURE_NAME, 2, "encounterdate"))

  }


  def getMet(rdd: RDD[CassandraRow], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {

    //  aacinorarth acinorarth_date aceinhibarb aceinhibarb_date  aceinhibarb,aceinhibarb_date

    rdd.filter(r =>

      ( ( checkElementPresent(r, MET, MEASURE_NAME, "acinorarth")
        && isDateEqual(r, MET, MEASURE_NAME, "acinorarth_date", "encounterdate"))

        || ( checkElementPresent(r, MET, MEASURE_NAME, "aceinhibarb")
           && isDateEqual(r, MET, MEASURE_NAME, "aceinhibarb_date", "encounterdate"))


        || ( checkElementPresent(r, MET, MEASURE_NAME, "aceinhibarb")
           && isDateEqual(r, MET, MEASURE_NAME, "aceinhibarb_date", "encounterdate"))

        // acorarrenosp acinorar_1

        )

        // acorarthnosp acorarthnosp_date  acinorarth acinorarth_date


        && !(checkElementPresent(r, MET, MEASURE_NAME, "acorarthnosp")
             && checkElementPresent(r, MET, MEASURE_NAME, "acinorarth")
             && isDateEqual(r, MET, MEASURE_NAME, "acorarthnosp_date", "encounterdate")
             && isDateEqual(r, MET, MEASURE_NAME, "acinorarth_date", "encounterdate")
           )

    )

  }

  def getexceptionRDD(rdd: RDD[CassandraRow], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {

    // acorarre   acinorarth

    rdd.filter(r =>

      ( checkElementPresent(r, EXCEPTION, MEASURE_NAME, "acorarre")
        && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "acinorarth")
        && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "acorarre_date", startDate, endDate)
        && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "acinorarth_date", startDate, endDate)

        )

        ||

        // acearbthrpallg  intoacinorar   aormitdis    mere_1  acinorar_1   pare_1  acinorar_1   refadutoacin
        (
        (
          // ((checkElementPresent(r, EXCEPTION, MEASURE_NAME, "acearbthrpallg")
          // && isDateOverlapsLessOrEqual(r, EXCEPTION, MEASURE_NAME, "acearbthrpallg_date", "encounterdate"))

          //  ||
          ((checkElementPresent(r, EXCEPTION, MEASURE_NAME, "intoacinorar")
           && isDateOverlapsLessOrEqual(r, EXCEPTION, MEASURE_NAME, "intoacinorar_date", "encounterdate"))

            //  ||
            //  ((checkElementPresent(r, EXCEPTION, MEASURE_NAME, "aormitdis")
            // && isDateOverlapsLessOrEqual(r, EXCEPTION, MEASURE_NAME, "aormitdis_date", "encounterdate"))
         ||
             (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "mere_1")
              && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "acinorar_1")
              && isDateOverlapsLessOrEqual(r, EXCEPTION, MEASURE_NAME, "mere_1_date", "encounterdate")
              && isDateOverlapsLessOrEqual(r, EXCEPTION, MEASURE_NAME, "acinorar_1_date", "encounterdate"))

            ||
            (
              checkElementPresent(r, EXCEPTION, MEASURE_NAME, "pare_1_date")
              && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "acinorar_1")
              && isDateOverlapsLessOrEqual(r, EXCEPTION, MEASURE_NAME, "pare_1_date", "encounterdate")
              && isDateOverlapsLessOrEqual(r, EXCEPTION, MEASURE_NAME, "acinorar_1_date", "encounterdate"))

            || (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "refadutoacin")
               && isDateOverlapsLessOrEqual(r, EXCEPTION, MEASURE_NAME, "refadutoacin_date", "encounterdate"))

          )

        ||

        (
          // (checkElementPresent(r,EXCEPTION,MEASURE_NAME,"lckdrgavlblty")
          // && isDuringMeasurementPeriod(r,EXCEPTION,MEASURE_NAME,"lckdrgavlblty_date",startDate,endDate))
          // &&
          (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "acinorar_1")
          && isDuringMeasurementPeriod(r, EXCEPTION, MEASURE_NAME, "acinorar_1_date", startDate, endDate))
        )
          )

        ||

        ( checkElementPresent(r, EXCEPTION, MEASURE_NAME, "prgncy")
         && isDateOverlapsLessOrEqual(r, EXCEPTION, MEASURE_NAME, "prgncy_date", "encounterdate")
          )


      // acearbthrpallg  intoacinorar   aormitdis    mere_1 // acinorar_1   pare_1  // acinorar_1   refadutoacin  lckdrgavlblty  acinorar_1 prgncy

    )
    )

  }


  /** countElementRowWise will check whether the count of element is greaterOrEqual to 1 for a particular patientuid and its element **/
  def countElementRowWise(r: CassandraRow, BroadCastRDD: Broadcast[Array[(String, String, Int)]], MEASURE_NAME: String, My_Count: Int, Element_Name: String*): Boolean = {

    var count: Int = 0
    val patient_id: String = r.getString("patientuid")

    for (element_name <- Element_Name) {

      // val ele_name: String = element_name
      val rdd4 = BroadCastRDD.value.filter(x => x._1.equals(patient_id) && x._2.equals(element_name))

      if (rdd4.size >= 1) rdd4.foreach(r => count = count + r._3.toInt)
    }

    if (count >= My_Count) true else false

  }


  /** countElement_2 will return rdd in form of (patientid , elementname , totalcountofelement) where totalcountofelement > 0  **/
  def countElement(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date, Element_Name: String*): RDD[(String, String, Int)] = {

    val rd = rdd.map(r => mycheck(r, MEASURE_NAME, Element_Name))

    return rd.flatMap(r => r.split(",,")).map(r => ((r.split(" ")(0), r.split(" ")(1)), r.split(" ")(2).toInt))
      .filter(r => r._2 > 0)
      .reduceByKey(_ + _)
      // .filter(r => r._2 > 0)
      .map(r => (r._1._1, r._1._2, r._2))

  }

  /** this function will return string from cassandra row for selected column **/
  def mycheck(r: CassandraRow, MEASURE_NAME: String, Element: Seq[String]): String = {

    val ele_size = Element.size

    var row_data = ""

    for (x <- 0 to Element.size - 1) {
      // var element_value = if (checkElementNotNull(r, IPP, MEASURE_NAME, Element(x))) 1 else 0
      var element_value = 0
      if (checkElementPresent(r, IPP, MEASURE_NAME, Element(x))) element_value = 1 else element_value = 0
      var c = r.getString("patientuid") + " " + Element(x) + " " + element_value

      row_data = row_data + c

      if (ele_size > 1 && x + 1 < ele_size) {
        row_data = row_data + ",,"
      }


    }


    return row_data

  }

}
