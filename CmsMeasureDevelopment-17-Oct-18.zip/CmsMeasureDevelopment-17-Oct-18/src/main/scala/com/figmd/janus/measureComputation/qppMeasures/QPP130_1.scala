package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.Measure
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object QPP130_1 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {


    /** Below column are missing from cassandra acc_2018, tblencounter_qpp
      * meencodes
      * meencodes_date
      * phythrpevaltn_cpt
      * phythrpevaltn_cpt_date
      * revaphythrp_cpt
      * revaphythrp_cpt_date
      * occutherapy_go_copy_505
      * occutherapy_go_copy_505_date
      * occuthera_reevalution_cpt
      * occuthera_reevalution_cpt_date
      *
      */

    // Filter IPP
    val ippRDD = getIpp(rdd, MEASURE_NAME, startDate: Date, endDate: Date)
    ippRDD.cache()

    // Eligible IPP
    val eligibleRdd = ippRDD
    eligibleRdd.cache()

    // Filter Exclusion
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exclusionRDD.cache()

    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Intermediate

    val intermediateA = eligibleRdd.subtract(exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA, MEASURE_NAME: String, startDate: Date, endDate: Date)
    metRDD.cache()


    val intermediateB = intermediateA.subtract(metRDD)
    intermediateB.cache()


    // Filter Exceptions
    val exceptionRDD = getexceptionRDD(intermediateB, EXCEPTION, startDate, endDate)

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }


  // meencodes, meencodes_date, phythrpevaltn_cpt, phythrpevaltn_cpt_date, revaphythrp_cpt, revaphythrp_cpt_date, occutherapy_go_copy_505, occutherapy_go_copy_505_date, occuthera_reevalution_cpt, occuthera_reevalution_cpt_date

  def getIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    rdd.filter(r =>

      (
        isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)

        &&

         isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate)


        )

    )


  }


  def getMet(intermediateA: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    intermediateA.filter(r =>

      (
        (checkElementPresent(r, MET, MEASURE_NAME, "crntmeddocmn")
         && isDateEqual(r, MET, MEASURE_NAME, "crntmeddocmn_date", "encounterdate")
            )

           ||

         (checkElementPresent(r, MET, MEASURE_NAME, "crntmed")
           && isDateEqual(r, MET, MEASURE_NAME, "crntmed_date", "encounterdate"))

       )


    ||

          (checkElementPresent(r, MET, MEASURE_NAME, "cumedosn")
               && isDateEqual(r, MET, MEASURE_NAME, "cumedosn_date", "encounterdate"))
        )

  }

  def getexceptionRDD(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    rdd.filter(r =>


      (
        (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "crntmeddoc_patntelig")
         && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "encounterdate"))

        ||

          (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "crntmeddoc_patntelig")
           && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "encounterdate"))


          ||

          (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "medsit")
           && isDateEqual(r, MET, MEASURE_NAME, "medsit_date", "encounterdate"))

          ||

          (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "medsit")
           && isDateEqual(r, MET, MEASURE_NAME, "medsit_date", "encounterdate"))
        )


      ||

        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "meorotrenodo")
           && isDateEqual(r, MET, MEASURE_NAME, "meorotrenodo_date", "encounterdate")

          )
    )

  }


}
