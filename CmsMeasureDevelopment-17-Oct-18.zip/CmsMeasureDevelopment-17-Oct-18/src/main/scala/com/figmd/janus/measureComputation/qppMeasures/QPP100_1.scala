package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.Measure
import com.figmd.janus.util.measure.HistoryLookUpUtility._
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object QPP100_1 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

    val ippInitialRDD = getInitialIpp(rdd, MEASURE_NAME, startDate: Date, endDate: Date)
    ippInitialRDD.cache()
    println("initial ipp count "+ippInitialRDD.count())

    val ippRDD = getIpp(ippInitialRDD, MEASURE_NAME, startDate, endDate)
    ippRDD.cache()

     // Eligible IPP
     val ippRdd = getIpp(ippInitialRDD, MEASURE_NAME, startDate: Date, endDate: Date)
     ippRdd.collect()


    // Filter Exclusions
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    ippRdd.cache()

    // Filter Exclusions
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = ippRdd
    intermediateA.cache()

    // Filter Met
    val metRDD =  getMet(intermediateA, MEASURE_NAME, startDate: Date, endDate: Date)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
     val notMetRDD = getSubtractRDD(intermediateA,metRDD)///sparkSession.sparkContext.emptyRDD[CassandraRow]
    notMetRDD.cache()

    saveToWebDM(rdd, ippRdd, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }


  def getInitialIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {


    rdd.filter(r =>

      isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18
      )
    )


  }

  def getIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    rdd.filter(r =>

        isDateOverlapsLessOrEqualHistory(r, IPP, MEASURE_NAME, "encounterdate", "MaEx")


    )

  }

  def getMet(intermediateA: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {


    intermediateA.filter(r =>

      isDateOverlapsLessOrEqualHistory(r, IPP, MEASURE_NAME, "encounterdate", "CoRe")

    )

  }

  def getDenominatorExclusionRDD(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    return rdd

  }

}