package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.Measure
import com.figmd.janus.util.measure.HistoryLookUpUtility._
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object QPP204_4 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

    /** Missing column from cassandra acc_2018, tblencounter_qpp
      * asanotan_copy_704
      * asanotan_copy_704_date
      * ancomeds
      * ancomeds_date
      */

    // initial IPP 1
    val ippInitialRDD = getInitialIpp(rdd, MEASURE_NAME, startDate: Date, endDate: Date)
    ippInitialRDD.cache()


    val patientHistoryList = getPatientHistory(sparkSession, ippInitialRDD, "acmyin", "pecoin", "coarbygr")

    // Eligible IPP
    val ippRdd = getIpp(ippInitialRDD, MEASURE_NAME, patientHistoryList, startDate: Date, endDate: Date)

    // Filter Exclusions
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    ippRdd.cache()

    // Filter Exclusions
    val exclusionRDD = getDenominatorExclusionRDD(ippRdd, MEASURE_NAME, startDate, endDate)
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = ippRdd.subtract(exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA, MEASURE_NAME: String, startDate: Date, endDate: Date)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA, metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRdd, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }


  def getInitialIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {


    rdd.filter(r =>

      isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)

        &&

        (

          (checkElementPresent(r, IPP, MEASURE_NAME, "ippexm")
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ippexm_date", startDate, endDate))

            || (checkElementPresent(r, IPP, MEASURE_NAME, "prcaseofvi18anup_1")
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "prcaseofvi18anup_1_date", startDate, endDate))

            || (checkElementPresent(r, IPP, MEASURE_NAME, "prcaseesofvi18anup_1")
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "prcaseesofvi18anup_1_date", startDate, endDate))

            || (checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1")
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate))

            || (checkElementPresent(r, IPP, MEASURE_NAME, "hohese")
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "hohese_date", startDate, endDate))

            || (checkElementPresent(r, IPP, MEASURE_NAME, "fain")
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate))

            || (checkElementPresent(r, IPP, MEASURE_NAME, "anwevi_1")
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "anwevi_1_date", startDate, endDate))
          )
    )


  }

  def getIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String, patient_list: List[CassandraRow], startDate: Date, endDate: Date): RDD[CassandraRow] = {

    rdd.filter(r =>

        startBeforeOrConcurrentStartOfMeasurementPeriodHistory(r, IPP, MEASURE_NAME, startDate, "acmyin", 12, patient_list)

        || (checkElementPresent(r, IPP, MEASURE_NAME, "isvadi")
        && isDateEqual(r, IPP, MEASURE_NAME, "isvadi_date", "encounterdate"))

        || startBeforeOrConcurrentStartOfMeasurementPeriodHistory(r, IPP, MEASURE_NAME, startDate, "pecoin", 12, patient_list)

        || startBeforeOrConcurrentStartOfMeasurementPeriodHistory(r, IPP, MEASURE_NAME, startDate, "coarbygr", 12, patient_list)

    )

  }

  def getMet(intermediateA: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    //  asanotan_copy_704    aspantipltlt
    intermediateA.filter(r =>

      (
        // (checkElementPresent(r,MET,MEASURE_NAME,"asanotan_copy_704")
        // && isDateOverlapsMeasurementPeriod(r,MET,MEASURE_NAME,"asanotan_copy_704_date",endDate))

        //||
        (checkElementPresent(r, MET, MEASURE_NAME, "aspantipltlt")
          && isDuringMeasurementPeriod(r, MET, MEASURE_NAME, "aspantipltlt_date", startDate, endDate))


        )

        // aspantipltl_rsnns
        &&

        !(checkElementPresent(r, MET, MEASURE_NAME, "aspantipltl_rsnns")
          && !isDuringMeasurementPeriod(r, MET, MEASURE_NAME, "aspantipltl_rsnns_date", startDate, endDate))

    )

  }

  def getDenominatorExclusionRDD(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    // ancomeds_date  hospiceservcs  docanticoameds

    rdd.filter(r =>

      /** ancomeds & ancomeds column is not present **/
      /* (checkElementPresent(r,EXCLUSION,MEASURE_NAME,"ancomeds")
        && isDateOverlapsMeasurementPeriod(r,EXCLUSION,MEASURE_NAME,"ancomeds_date",endDate)
         )
       ||
      */

      (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hospiceservcs")
        && isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hospiceservcs_date", startDate, endDate)
        )

        || (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "docanticoameds")
        && isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "docanticoameds_date", startDate, endDate)
        )

        // hspccr hospiceservices

        ||

        (
          (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hspccr")
            && isDateOverlapsMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hspccr_date", endDate))

            ||

            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hospiceservices")
              && isDateOverlapsMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hospiceservices_date", endDate))

          )

    )

  }

}