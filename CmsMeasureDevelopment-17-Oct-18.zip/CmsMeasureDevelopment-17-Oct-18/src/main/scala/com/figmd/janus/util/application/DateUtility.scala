package com.figmd.janus.util.application

import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.time.{LocalDate, LocalDateTime}
import java.util.{Calendar, Date}
import java.util.concurrent.TimeUnit

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.WebDataMartCreator.prop
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat


class DateUtility extends Serializable {


  val fileUtility = new FileUtility();
  var startDate = prop.getProperty("quarterStartDate")
  var endDate = prop.getProperty("quarterEndDate")
  var dateFormat = fileUtility.getProperty("date.format");
  var dateTimeFormat = fileUtility.getProperty("date.time.format");


//  final var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
  @transient lazy val DATE_FORMAT = DateTimeFormatter.ofPattern(dateFormat)
  @transient lazy val DATE_TIME_FORMAT = DateTimeFormatter.ofPattern(dateTimeFormat)
  @transient lazy val DATE_TIME_FORMAT_EEE = DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")
  val now = LocalDateTime.now().format(DATE_TIME_FORMAT)
  val today = LocalDateTime.now().format(DATE_FORMAT)

  def getDaysDiffForDateType(startDate: String,endDate :Date): Long ={ //Pankaj
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    val s1 = SIMPLE_DATE_FORMAT.parse(startDate);
    //val s2 = SIMPLE_DATE_FORMAT.parse(endDate)
    // val s2 = new SimpleDateFormat("yyyy-MM-dd").parse("2006-04-06 00:30:00.000000+0000")
    import java.util.concurrent.TimeUnit
    val diffInMillies = Math.abs(s1.getTime - endDate.getTime)
    return TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS)

  }



// Pankaj backtract startdate - elemetdate diff
  def checkDaysDiff_LessThanEqual(Date_String :String, endDate :Date, days:Int):Boolean={
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    val s1 = SIMPLE_DATE_FORMAT.parse(Date_String)
    val diffInMillies = Math.abs(s1.getTime - endDate.getTime)
    if ((TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS) <= days) && (s1.getTime < endDate.getTime))
      return true else false

  }

  // Pankaj backtract startdate - elemetdate diff
  def checkDaysDiff_Less(Date_String :String, endDate :Date, days:Int):Boolean={
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    val s1 = SIMPLE_DATE_FORMAT.parse(Date_String)
    val diffInMillies = Math.abs(s1.getTime - endDate.getTime)
    if ((TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS) > days) && (s1.getTime < endDate.getTime))
      return true else false

  }



  // month diff pankaj
  def getMonthDiff(startDate:Date,endDate:Date):Int={
    import java.text.SimpleDateFormat
    import java.util.Calendar
    import java.util.Date
    import java.util.GregorianCalendar
   //  val startDate = "01/03/2018"
   //  val formatter1 = new SimpleDateFormat("dd/MM/yyyy")
  //  val Startdate = new SimpleDateFormat("dateFormat").parse(startDate)
  //  System.out.println(startDate + "\t" + Startdate)

    //  val endDate = "01/11/2017"
   // var endDate_1 = new SimpleDateFormat("dateFormat").parse(endDate)
  //  println(endDate+" "+endDate_1)

    val startCalendar = new GregorianCalendar
    startCalendar.setTime(startDate)
    val endCalendar = new GregorianCalendar
    endCalendar.setTime(endDate)

    val diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR)
    val diffMonth = diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH)

    println("diffrence is " + diffMonth)
    return Math.abs(diffMonth)


  }



  def getStart(): Date = {
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    var start_date = SIMPLE_DATE_FORMAT.parse(startDate);
    return start_date;
  }

  def dateParse(input : String): Date={
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    return SIMPLE_DATE_FORMAT.parse(input)
  }

  def getEndDate(): Date = {
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    var end_date = SIMPLE_DATE_FORMAT.parse(endDate);
    println(end_date)
    return end_date;
  }


  def getDateDiff(startDate: String, endDate: String): Boolean = {

    val s1 = LocalDate.parse(startDate);
    val s2 = LocalDate.parse(endDate)
    var dateDiff = ChronoUnit.DAYS.between(s1, s2)
    if (dateDiff >= 30) {
      return true;
    }
    else {
      return false;
    }
  }


  def getDateDiff1(startDate: String, endDate: String): Boolean = {
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    val s1 = SIMPLE_DATE_FORMAT.parse(startDate);
    val s2 = SIMPLE_DATE_FORMAT.parse(endDate)
    import java.util.concurrent.TimeUnit
    val diffInMillies = Math.abs(s1.getTime - s2.getTime)
    val dateDiff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS)
    if (dateDiff >= 30) {
      return true;
    }
    else {
      return false;
    }
  }




  def chkDateEqual(firstDate: String,compareDate :String): Boolean ={
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    val s1 = SIMPLE_DATE_FORMAT.parse(startDate);
    val s2 = SIMPLE_DATE_FORMAT.parse(endDate)
    if (s1.equals(s2)) {
      return true;
    }
    else {
      return false;
    }


  }


  def getAge(birthDt: String): Long = {

    val dateString = birthDt
    val formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")
    val date = LocalDate.parse(dateString, formatter)

    var birthDate = LocalDate.of(date.getYear, date.getMonth, date.getDayOfMonth)
    var todayDate = LocalDate.now()
    var age = ChronoUnit.YEARS.between(birthDate, todayDate)

    return age

  }


  def getAge(dob: String,arrival_date :String): Double ={
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    val s1 = SIMPLE_DATE_FORMAT.parse(dob);
    val s2 = SIMPLE_DATE_FORMAT.parse(arrival_date)
    import java.util.concurrent.TimeUnit
    val diffInMillies = Math.abs(s1.getTime - s2.getTime)
    return TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS)/365.23076923074

  }

  def getDaysDiff(startDate: String,endDate :String): Long ={
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    val s1 = SIMPLE_DATE_FORMAT.parse(startDate);
    val s2 = SIMPLE_DATE_FORMAT.parse(endDate)
    import java.util.concurrent.TimeUnit
    val diffInMillies = Math.abs(s1.getTime - s2.getTime)
    return TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS)

  }

  def getMinutesDiff(startDate: String,endDate :String): Long ={
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    val s1 = SIMPLE_DATE_FORMAT.parse(startDate);
    val s2 = SIMPLE_DATE_FORMAT.parse(endDate)
    import java.util.concurrent.TimeUnit
    val diffInMillies = Math.abs(s1.getTime - s2.getTime)
    return TimeUnit.MINUTES.convert(diffInMillies, TimeUnit.MILLISECONDS)

  }

  def getDateDiffGreaterOrEqualHours(startDate: String, endDate: String,hours :Int): Boolean = {

    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    val s1 = SIMPLE_DATE_FORMAT.parse(startDate);
    val s2 = SIMPLE_DATE_FORMAT.parse(endDate)
    import java.util.concurrent.TimeUnit
    val diffInMillies = Math.abs(s1.getTime - s2.getTime)
    val dateDiff = TimeUnit.HOURS.convert(diffInMillies, TimeUnit.MILLISECONDS)
    if (dateDiff >= hours) {
      return true;
    }
    else {
      return false;
    }
  }

    def getDateDiffHourslessthan(startDate: String, endDate: String,hours :Int): Boolean = {

      var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
      val s1 = SIMPLE_DATE_FORMAT.parse(startDate);
      val s2 = SIMPLE_DATE_FORMAT.parse(endDate)
      import java.util.concurrent.TimeUnit
      val diffInMillies = Math.abs(s1.getTime - s2.getTime)
      val dateDiff = TimeUnit.HOURS.convert(diffInMillies, TimeUnit.MILLISECONDS)
      if (dateDiff < hours) {
        return true;
      }
      else {
        return false;
      }
    }

  def getMinutesDiff_1(startDate: String,endDate :String): Double ={
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateTimeFormat)
    val s1 = SIMPLE_DATE_FORMAT.parse(startDate);
    val s2 = SIMPLE_DATE_FORMAT.parse(endDate)
    import java.util.concurrent.TimeUnit
    val diffInMillies = Math.abs(s1.getTime - s2.getTime)
    return TimeUnit.MINUTES.convert(diffInMillies, TimeUnit.MILLISECONDS)

  }

  def getDateMinutesDiff(l:CassandraRow): Double ={
    var startDate=""
    var endDate=""
    if (l.isNullAt(13))
      startDate="0000-00-00 00:00:00.000000+0000"
    else
      startDate=LocalDateTime.parse(l.columnValues(13).toString, DATE_TIME_FORMAT_EEE).format(DATE_TIME_FORMAT)

    if (l.isNullAt(15))
      endDate="0000-00-00 00:00:00.000000+0000"
    else
      endDate=LocalDateTime.parse(l.columnValues(15).toString, DATE_TIME_FORMAT_EEE).format(DATE_TIME_FORMAT)

    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateTimeFormat)
    var s1 = SIMPLE_DATE_FORMAT.parse(startDate);
    var s2 = SIMPLE_DATE_FORMAT.parse(endDate)

    var diffInMillies = Math.abs(s1.getTime - s2.getTime)
    return TimeUnit.MINUTES.convert(diffInMillies, TimeUnit.MILLISECONDS).toDouble
  }
  //val median32_1 = ippRDD32_1.map(l => (l.columnValues(0), l.columnValues(1), l.columnValues(2), dateUtil.getMinutesDiff_1(if (l.isNullAt(13)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(13).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")), if (l.isNullAt(15)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(15).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))).toDouble))

  def get_DateDiffGreater_Or_Equal_Hours(startDate: DateTime, endDate: DateTime,hours :Int): Boolean = {

    import java.util.concurrent.TimeUnit
    val diffinMill =   Math.abs(startDate.getMillis-endDate.getMillis)
    val dateDiff = TimeUnit.HOURS.convert(diffinMill, TimeUnit.MILLISECONDS)
    if (dateDiff >= hours) {
      return true;
    }
    else {
      return false;
    }

  }

  def get_DateDiffHours_lessthan(startDate: DateTime, endDate: DateTime,hours :Int): Boolean = {

    import java.util.concurrent.TimeUnit
    val diffinMill =   Math.abs(startDate.getMillis-endDate.getMillis)
    val dateDiff = TimeUnit.HOURS.convert(diffinMill, TimeUnit.MILLISECONDS)
    if (dateDiff < hours) {
      return true;
    }
    else {
      return false;
    }
  }

  def dateTimeParse(input : String): DateTime={
    val formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ssZ");
    val dateTime = formatter.parseDateTime(input);

    return dateTime
  }


  //EEE MMM d HH:mm:ss z dd/MM/YYYY"

  def dateTimeParse317(input : String): DateTime={
    val formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
    val dateTime = formatter.parseDateTime(input);

    return dateTime
  }

  def dateTimeParse1(input : String): DateTime={
    val formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
    val dateTime = formatter.parseDateTime(input);

    return dateTime
  }



}
