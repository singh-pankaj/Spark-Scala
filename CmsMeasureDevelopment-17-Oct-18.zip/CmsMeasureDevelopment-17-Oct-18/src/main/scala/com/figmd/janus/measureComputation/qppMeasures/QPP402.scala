
package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.Measure
import com.figmd.janus.util.measure.HistoryLookUpUtility.getPatientHistory
import com.figmd.janus.util.measure.HistoryLookUpUtility._
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object QPP402 extends MeasureUtility with Measure {


  //  final var MEASURE_NAME = "M2"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {
    // Filter IPP
    val ippRDD = getIpp(rdd, MEASURE_NAME)
    ippRDD.cache()

    // Filter Exclusions
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter Exclusions
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    val patientHistoryList = getPatientHistory(sparkSession, rdd, "tobcutc", "tobcousescrn", "tobacouser", "ccouns", "assistrcp", "enrlcp", "advqsmktobcu", "tbccescon", "tobnonusr", "curnttobcnusr")

    // Filter Met
    val metRDD = getMet(ippRDD, MEASURE_NAME, patientHistoryList, startDate, endDate)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //exceptionRDD.persist()

    val notMetRDD = getNotMet(ippRDD, metRDD)
    notMetRDD.cache()
    metRDD.collect().foreach(println)

    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
  }

  def getIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String): RDD[CassandraRow] = {

    rdd.filter(r =>
      (
        isAgeBetween(r, IPP, MEASURE_NAME, "dob", "encounterdate", 12, 21)
          &&
          (
            // checkElementPresent_1(r, IPP, MEASURE_NAME, "ofvi_1","hebeasin","heanbeasre","heanbeasin","opse","anwevi_1")
            checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1")
              ||
              checkElementPresent(r, IPP, MEASURE_NAME, "hebeasin")
              ||
              checkElementPresent(r, IPP, MEASURE_NAME, "heanbeasre")
              ||
              checkElementPresent(r, IPP, MEASURE_NAME, "heanbeasin")
              ||
              checkElementPresent(r, IPP, MEASURE_NAME, "opse")
              ||
              checkElementPresent(r, IPP, MEASURE_NAME, "anwevi_1")
              ||
              checkElementPresent(r, IPP, MEASURE_NAME, "psyc")
              ||
              checkElementPresent(r, IPP, MEASURE_NAME, "psvidiev")
              ||
              checkElementPresent(r, IPP, MEASURE_NAME, "smoktobacessv")
              ||
              checkElementPresent(r, IPP, MEASURE_NAME, "psythrpcrsis")
              ||
              checkElementPresent(r, IPP, MEASURE_NAME, "psvips")
              ||
              checkElementPresent(r, IPP, MEASURE_NAME, "octhev")
            )
        )

    )
  }

  def getMet(rdd: RDD[CassandraRow], MEASURE_NAME: String, patient_list: List[CassandraRow], startDate: Date, endDate: Date): RDD[CassandraRow] = {
    rdd.filter(r =>

      (
        checkElementPresent(r, MET, MEASURE_NAME, "tobcutc")
          &&
          //  isDateBetweenStartBeforeEndAndStartAfterEnd(r,MET,MEASURE_NAME,"tobcutc_date",compareDate = "tobcutc_date",18,0)
          startBeforeOrConcurrentStartOfMeasurementPeriodHistory(r, IPP, MEASURE_NAME, endDate, "tobcutc", 18, patient_list)
        )

      /*
      ||
      (
        checkElementPresent(r, MET, MEASURE_NAME, "tobcousescrn")
          &&
          checkElementPresent(r, MET, MEASURE_NAME, "tobacouser")
          &&
          isDateBetweenStartBeforeEndAndStartAfterEnd(r,MET,MEASURE_NAME,"tobcousescrn_date",compareDate = "tobcousescrn_date",18,0)
          &&
          (

            (
              checkElementPresent(r, MET, MEASURE_NAME, "ccouns")
                &&
                isDateBetweenStartBeforeEndAndStartAfterEnd(r,MET,MEASURE_NAME,"ccouns_date",compareDate = "ccouns_date",18,0)
              )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "assistrcp")
                  &&
                  isDateBetweenStartBeforeEndAndStartAfterEnd(r,MET,MEASURE_NAME,"assistrcp_date",compareDate = "assistrcp_date",18,0)
                )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "enrlcp")
                  &&
                  isDateBetweenStartBeforeEndAndStartAfterEnd(r,MET,MEASURE_NAME,"enrlcp_date",compareDate ="enrlcp_date",18,0)
                )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "advqsmktobcu")
                  &&
                  isDateBetweenStartBeforeEndAndStartAfterEnd(r,MET,MEASURE_NAME,"advqsmktobcu_date",compareDate = "advqsmktobcu_date",18,0)
                )
              ||
              (
                checkElementPresent(r, MET, MEASURE_NAME, "tbccescon")
                  &&
                  isDateBetweenStartBeforeEndAndStartAfterEnd(r,MET,MEASURE_NAME,"tbccescon_date",compareDate = "tbccescon_date",18,0)
                )


          )
        )
      ||
      (
        checkElementPresent(r, MET, MEASURE_NAME, "tobcousescrn")
          &&
          checkElementPresent(r, MET, MEASURE_NAME, "tobnonusr")
          &&
          isDateBetweenStartBeforeEndAndStartAfterEnd(r,MET,MEASURE_NAME,"tobcousescrn_date",compareDate = "tobcousescrn_date",18,0)
        )
      ||
      (
        checkElementPresent(r, MET, MEASURE_NAME, "curnttobcnusr")
          &&
          isDateBetweenStartBeforeEndAndStartAfterEnd(r,MET,MEASURE_NAME,"curnttobcnusr_date",compareDate = "curnttobcnusr_date",18,0)
        )*/

      //  BackTrackingMet1(r, MET, MEASURE_NAME, CRA_list,startDate, endDate)

    )
  }


}
