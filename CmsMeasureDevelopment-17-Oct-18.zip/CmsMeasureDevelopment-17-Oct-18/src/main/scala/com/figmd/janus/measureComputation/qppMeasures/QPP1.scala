package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.WebDataMartCreator.prop
import com.figmd.janus.{WebDataMartCreator, Measure}

import org.apache.spark.sql.SparkSession
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.rdd.RDD

object QPP1 extends MeasureUtility with Measure {

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd, MEASURE_NAME)
    ippRDD.cache()
       // Filter Exclusions
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,startDate: Date,endDate: Date,MEASURE_NAME)
    exclusionRDD.cache()

    val InterMediate= ippRDD.subtract(exclusionRDD)
    InterMediate.cache()
    val HbA1cLabTest= getLabTest(InterMediate,startDate: Date, endDate: Date,MEASURE_NAME)
    HbA1cLabTest.cache()

  val MR_Date_Result= mostRecent(HbA1cLabTest,"patientuid","encounterdate",MEASURE_NAME)
    MR_Date_Result.cache()
//     Filter Met
    val metRDD = getMet(MR_Date_Result,startDate: Date, endDate: Date,MEASURE_NAME)
     metRDD.cache()

    val notMetRDD= getnotmet(InterMediate,metRDD)
    notMetRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
  }

  def getIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String): RDD[CassandraRow] = {
    rdd
      .filter(r =>

        (
        checkElementPresent(r,IPP,MEASURE_NAME,"diab_1")
        &&
        isDateEqual(r,IPP,MEASURE_NAME,"diab_1_date","encounterdate")
        )
        &&
        (
          isAgeGreaterOrEqual(r,IPP,MEASURE_NAME,"dob","encounterdate",18)
          &&
          isAgeLess(r,IPP,MEASURE_NAME,"dob","encounterdate",76)
        )
          &&
          (
          checkElementPresent(r,IPP,MEASURE_NAME,"mednutthpy")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"ippexm")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"critclcre")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"subhospcare")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"anlnrsnfasst")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"offvstg")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"hohese")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"fain")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"anwevi_1")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"prcaseofvi18anup_1")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"prcaseesofvi18anup_1")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"hoobcain")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"disehoin")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"nufavi")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"disenufa")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"caseinlorefa")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"diseobca")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"hoinviin")
            ||
            checkElementPresent(r,IPP,MEASURE_NAME,"emergdv")
        )

      )

  }


  def getExclusionRdd(ippRDD:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {

    ippRDD.filter(r =>

           (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hosp_serv")
              &&
              isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME,"hosp_serv_date",startDate,endDate)
            )
              ||
            (
              (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hospiceservices")
              &&
              isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME,"hospiceservices_date",startDate,endDate))
               ||
              (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hspccr")
                 &&
               isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME,"hspccr_date",startDate,endDate)
              )
            )
    )
  }



  def getLabTest(exclusionRDD:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    exclusionRDD.filter(r =>
              checkElementPresent(r,EXCLUSION,MEASURE_NAME,"hblate")
      &&
                isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME,"hblate_date",startDate,endDate)
    )
  }


  def getMet(MR_Result_date:RDD[CassandraRow],startDate: Date,endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    MR_Result_date.filter(r=>

      (
        (checkElementPresent(r,MET,MEASURE_NAME,"hba1c")
        &&
        checkElementValueGreaterDouble(r,MET,MEASURE_NAME,"hba1c_rsult",.09)
        )
          ||
        (checkElementPresent(r,MET,MEASURE_NAME,"hblate")
          &&
          checknull(r,MET,MEASURE_NAME,"hba1c_rsult")
          )
          ||
          checknull(r,MET,MEASURE_NAME,"hblate")
          )

        ||
        (
          (checkElementPresent(r,MET,MEASURE_NAME,"heama1clvl")
            &&
          isDuringMeasurementPeriod(r, MET, MEASURE_NAME,"hosp_serv_date",startDate,endDate)
          )
          ||
          (checkElementPresent(r,MET,MEASURE_NAME,"hb_level")
            &&
            isDuringMeasurementPeriod(r, MET, MEASURE_NAME,"hb_level_date",startDate,endDate)
            )
          )
        &&
          (
            checknull(r,MET,MEASURE_NAME,"hemoga1c")
            &&
            checknull(r,MET,MEASURE_NAME,"hba1clvl")
          )
          )
  }

    def getnotmet(InterMediate: RDD[CassandraRow],metRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val Intr_MetRdd = metRDD.map(r=>r.getString("visituid")).collect().toList
    val notMetRDD = InterMediate.filter(r=>(!Intr_MetRdd.contains(r.getString("visituid"))))
      return notMetRDD
    }


}


