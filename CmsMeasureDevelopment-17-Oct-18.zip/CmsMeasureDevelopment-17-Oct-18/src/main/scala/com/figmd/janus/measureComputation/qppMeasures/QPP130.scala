package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.Measure
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object QPP130 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {


    /** Below column are missing from cassandra acc_2018, tblencounter_qpp
      * meencodes
      * meencodes_date
      * phythrpevaltn_cpt
      * phythrpevaltn_cpt_date
      * revaphythrp_cpt
      * revaphythrp_cpt_date
      * occutherapy_go_copy_505
      * occutherapy_go_copy_505_date
      * occuthera_reevalution_cpt
      * occuthera_reevalution_cpt_date
      *
      */

    // Filter IPP
    val ippRDD = getIpp(rdd, MEASURE_NAME, startDate: Date, endDate: Date)
    ippRDD.cache()

    // Eligible IPP
    val eligibleRdd = ippRDD
    eligibleRdd.cache()

    // Filter Exclusion
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exclusionRDD.cache()

    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter Intermediate

    val intermediateA = eligibleRdd.subtract(exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA, MEASURE_NAME: String, startDate: Date, endDate: Date)
    metRDD.cache()


    val intermediateB = intermediateA.subtract(metRDD)
    intermediateB.cache()


    // Filter Exceptions
    val exceptionRDD = getexceptionRDD(intermediateB, EXCEPTION, startDate, endDate)

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }


  // meencodes, meencodes_date, phythrpevaltn_cpt, phythrpevaltn_cpt_date, revaphythrp_cpt, revaphythrp_cpt_date, occutherapy_go_copy_505, occutherapy_go_copy_505_date, occuthera_reevalution_cpt, occuthera_reevalution_cpt_date

  def getIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    rdd.filter(r =>

      (
        /*
        (checkElementPresent(r, IPP, MEASURE_NAME, "meencodes")
          && isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "meencodes_date", 18))

          ||

          */

           (checkElementPresent(r, IPP, MEASURE_NAME, "thrpins")
            && isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "thrpins_date", 18))

          /*
          || (checkElementPresent(r, IPP, MEASURE_NAME, "phythrpevaltn_cpt")
             && isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "phythrpevaltn_cpt_date", 18))



          ||
          (checkElementPresent(r, IPP, MEASURE_NAME, "revaphythrp_cpt")
              && isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "revaphythrp_cpt_date", 18))


          || (checkElementPresent(r, IPP, MEASURE_NAME, "occutherapy_go_copy_505")
              && isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "occutherapy_go_copy_505_date", 18))


          || (checkElementPresent(r, IPP, MEASURE_NAME, "occuthera_reevalution_cpt")
              && isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "occuthera_reevalution_cpt_date", 18))
             */
        )

        &&

        (


          /*
           (checkElementPresent(r, IPP, MEASURE_NAME, "meencodes")
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "meencodes_date", startDate, endDate))

            ||
           */

            (checkElementPresent(r, IPP, MEASURE_NAME, "thrpins")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "thrpins_date", startDate, endDate))

             /*
            || (checkElementPresent(r, IPP, MEASURE_NAME, "phythrpevaltn_cpt")
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "phythrpevaltn_cpt_date", startDate, endDate))


            || (checkElementPresent(r, IPP, MEASURE_NAME, "revaphythrp_cpt")
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "revaphythrp_cpt_date", startDate, endDate))


            || (checkElementPresent(r, IPP, MEASURE_NAME, "occutherapy_go_copy_505")
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "occutherapy_go_copy_505_date", startDate, endDate))


            || (checkElementPresent(r, IPP, MEASURE_NAME, "occuthera_reevalution_cpt")
            && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "occuthera_reevalution_cpt_date", startDate, endDate))

              */


          )

    )


  }


  def getMet(intermediateA: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    intermediateA.filter(r =>

      (
        (

          (

            (checkElementPresent(r, MET, MEASURE_NAME, "crntmeddocmn")
            //  && checkElementPresent(r, MET, MEASURE_NAME, "meencodes")
             // && isDateEqual(r, MET, MEASURE_NAME, "crntmeddocmn_date", "meencodes_date")
              )

              ||


              (checkElementPresent(r, MET, MEASURE_NAME, "crntmeddocmn")
                && checkElementPresent(r, MET, MEASURE_NAME, "thrpins")
                && isDateEqual(r, MET, MEASURE_NAME, "crntmeddocmn_date", "thrpins_date"))

              || (checkElementPresent(r, MET, MEASURE_NAME, "crntmeddocmn")
              // && checkElementPresent(r, MET, MEASURE_NAME, "phythrpevaltn_cpt")
              // && isDateEqual(r, MET, MEASURE_NAME, "crntmeddocmn_date", "phythrpevaltn_cpt_date")

              )

              || (checkElementPresent(r, MET, MEASURE_NAME, "crntmeddocmn")
             // && checkElementPresent(r, MET, MEASURE_NAME, "revaphythrp_cpt")
             // && isDateEqual(r, MET, MEASURE_NAME, "crntmeddocmn_date", "revaphythrp_cpt_date")
               )

              || (checkElementPresent(r, MET, MEASURE_NAME, "crntmeddocmn")
              /*&& checkElementPresent(r, MET, MEASURE_NAME, "occutherapy_go_copy_505")
              && isDateEqual(r, MET, MEASURE_NAME, "crntmeddocmn_date", "occutherapy_go_copy_505_date")
             */ )

              || (checkElementPresent(r, MET, MEASURE_NAME, "crntmeddocmn")
              /*&& checkElementPresent(r, MET, MEASURE_NAME, "occuthera_reevalution_cpt")
              && isDateEqual(r, MET, MEASURE_NAME, "crntmeddocmn_date", "occuthera_reevalution_cpt_date")
              */)

            )

            ||

            (
              (checkElementPresent(r, MET, MEASURE_NAME, "crntmed")
                //&& checkElementPresent(r, MET, MEASURE_NAME, "meencodes")
                //&& isDateEqual(r, MET, MEASURE_NAME, "crntmed_date", "meencodes_date")
                )

                || (checkElementPresent(r, MET, MEASURE_NAME, "crntmed")
                && checkElementPresent(r, MET, MEASURE_NAME, "thrpins")
                && isDateEqual(r, MET, MEASURE_NAME, "crntmed_date", "thrpins_date"))

                || (checkElementPresent(r, MET, MEASURE_NAME, "crntmed")
               // && checkElementPresent(r, MET, MEASURE_NAME, "phythrpevaltn_cpt")
               // && isDateEqual(r, MET, MEASURE_NAME, "crntmed_date", "phythrpevaltn_cpt_date")
                )

                || (checkElementPresent(r, MET, MEASURE_NAME, "crntmed")
                // && checkElementPresent(r, MET, MEASURE_NAME, "revaphythrp_cpt")
               // && isDateEqual(r, MET, MEASURE_NAME, "crntmed_date", "revaphythrp_cpt_date")
                )

                || (checkElementPresent(r, MET, MEASURE_NAME, "crntmed")
                /*&& checkElementPresent(r, MET, MEASURE_NAME, "occutherapy_go_copy_505")
                && isDateEqual(r, MET, MEASURE_NAME, "crntmed_date", "occutherapy_go_copy_505_date")
                */)

                || (checkElementPresent(r, MET, MEASURE_NAME, "crntmed")
               /* && checkElementPresent(r, MET, MEASURE_NAME, "occuthera_reevalution_cpt")
                && isDateEqual(r, MET, MEASURE_NAME, "crntmed_date", "occuthera_reevalution_cpt_date")
                */)

              )
          )


          ||


          (
            (checkElementPresent(r, MET, MEASURE_NAME, "cumedosn")
             // && checkElementPresent(r, MET, MEASURE_NAME, "meencodes")
             // && isDateEqual(r, MET, MEASURE_NAME, "cumedosn_date", "meencodes_date")
              )

              || (checkElementPresent(r, MET, MEASURE_NAME, "cumedosn")
              && checkElementPresent(r, MET, MEASURE_NAME, "thrpins")
              && isDateEqual(r, MET, MEASURE_NAME, "cumedosn_date", "thrpins_date"))

              || (checkElementPresent(r, MET, MEASURE_NAME, "cumedosn")
              // && checkElementPresent(r, MET, MEASURE_NAME, "phythrpevaltn_cpt")
              // && isDateEqual(r, MET, MEASURE_NAME, "cumedosn_date", "phythrpevaltn_cpt_date")
              )

              || (checkElementPresent(r, MET, MEASURE_NAME, "cumedosn")
            /* && checkElementPresent(r, MET, MEASURE_NAME, "revaphythrp_cpt")
              && isDateEqual(r, MET, MEASURE_NAME, "cumedosn_date", "revaphythrp_cpt_date")
*/
              )
              || (checkElementPresent(r, MET, MEASURE_NAME, "cumedosn")
              /*&& checkElementPresent(r, MET, MEASURE_NAME, "occutherapy_go_copy_505")
              && isDateEqual(r, MET, MEASURE_NAME, "cumedosn_date", "occutherapy_go_copy_505_date")
              */)

              || (checkElementPresent(r, MET, MEASURE_NAME, "cumedosn")
              /*&& checkElementPresent(r, MET, MEASURE_NAME, "occuthera_reevalution_cpt")
              && isDateEqual(r, MET, MEASURE_NAME, "cumedosn_date", "occuthera_reevalution_cpt_date")
              */)

            )

        )


        && !(

        checkElementPresent(r, MET, MEASURE_NAME, "crntmeddoc_resns")

          && checkElementPresent(r, MET, MEASURE_NAME, "crntmeddocmn")

          &&
          (
            /*
             (checkElementPresent(r, MET, MEASURE_NAME, "meencodes")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "meencodes_date", startDate, endDate))

              ||
              */

              (checkElementPresent(r, MET, MEASURE_NAME, "thrpins")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "thrpins_date", startDate, endDate))

               /*
              || (checkElementPresent(r, MET, MEASURE_NAME, "phythrpevaltn_cpt")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "phythrpevaltn_cpt_date", startDate, endDate))




              || (checkElementPresent(r, MET, MEASURE_NAME, "revaphythrp_cpt")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "revaphythrp_cpt_date", startDate, endDate))



              || (checkElementPresent(r, MET, MEASURE_NAME, "occutherapy_go_copy_505")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "occutherapy_go_copy_505_date", startDate, endDate))

              || (checkElementPresent(r, MET, MEASURE_NAME, "occuthera_reevalution_cpt")
              && isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "occuthera_reevalution_cpt_date", startDate, endDate))
                */


            )


        )

    )


  }

  def getexceptionRDD(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    rdd.filter(r =>


      (
        (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "crntmeddoc_patntelig")
          && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "crntmeddocmn")

          && (

          /*
          (checkElementPresent(r, MET, MEASURE_NAME, "meencodes")
            && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "meencodes_date"))

            ||

            */
            (checkElementPresent(r, MET, MEASURE_NAME, "thrpins")
            && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "thrpins_date"))

            /*
            || (checkElementPresent(r, MET, MEASURE_NAME, "phythrpevaltn_cpt")
            && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "phythrpevaltn_cpt_date"))



            || (checkElementPresent(r, MET, MEASURE_NAME, "revaphythrp_cpt")
            && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "revaphythrp_cpt_date"))


            || (checkElementPresent(r, MET, MEASURE_NAME, "occutherapy_go_copy_505")
            && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "occutherapy_go_copy_505_date"))



            || (checkElementPresent(r, MET, MEASURE_NAME, "occuthera_reevalution_cpt")
            && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "occuthera_reevalution_cpt_date"))

              */

          )
          )

          ||

          (

            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "crntmeddoc_patntelig")
              && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "crntmed")
              &&
              (
                /*
                (checkElementPresent(r, MET, MEASURE_NAME, "meencodes")
                  && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "meencodes_date"))

                  ||

                  */
                  (checkElementPresent(r, MET, MEASURE_NAME, "thrpins")
                    && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "thrpins_date"))

                    /*
                  || (checkElementPresent(r, MET, MEASURE_NAME, "phythrpevaltn_cpt")
                  && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "phythrpevaltn_cpt_date"))


                  || (checkElementPresent(r, MET, MEASURE_NAME, "revaphythrp_cpt")
                  && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "revaphythrp_cpt_date"))



                  || (checkElementPresent(r, MET, MEASURE_NAME, "occutherapy_go_copy_505")
                  && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "occutherapy_go_copy_505_date"))



                  || (checkElementPresent(r, MET, MEASURE_NAME, "occuthera_reevalution_cpt")
                  && isDateEqual(r, MET, MEASURE_NAME, "crntmeddoc_patntelig_date", "occuthera_reevalution_cpt_date"))

                    */


                )

            )


          ||

          (

            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "medsit")
              && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "crntmeddocmn")
              &&
              (

                /*
                (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "meencodes")
                  && isDateEqual(r, MET, MEASURE_NAME, "medsit_date", "meencodes_date"))

                  ||

                  */
                (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "thrpins")
                  && isDateEqual(r, MET, MEASURE_NAME, "medsit_date", "thrpins_date"))

                  /*
                  || (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "phythrpevaltn_cpt")
                  && isDateEqual(r, MET, MEASURE_NAME, "medsit_date", "phythrpevaltn_cpt_date"))


                  || (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "revaphythrp_cpt")
                  && isDateEqual(r, MET, MEASURE_NAME, "medsit_date", "revaphythrp_cpt_date"))



                  || (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "occutherapy_go_copy_505")
                  && isDateEqual(r, MET, MEASURE_NAME, "medsit_date", "occutherapy_go_copy_505_date"))



                  || (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "occuthera_reevalution_cpt")
                  && isDateEqual(r, MET, MEASURE_NAME, "medsit_date", "occuthera_reevalution_cpt_date"))

                   */


                )
            )

          ||
          (

            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "medsit")
              && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "crntmed")
              &&

              (
               /*
                (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "meencodes")
                  && isDateEqual(r, MET, MEASURE_NAME, "medsit_date", "meencodes_date"))

                  ||
                  */
                  (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "thrpins")
                  && isDateEqual(r, MET, MEASURE_NAME, "medsit_date Situation", "thrpins_date"))

                  /*
                  || (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "phythrpevaltn_cpt")
                  && isDateEqual(r, MET, MEASURE_NAME, "medsit_date", "phythrpevaltn_cpt_date"))


                  || (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "revaphythrp_cpt")
                  && isDateEqual(r, MET, MEASURE_NAME, "medsit_date", "revaphythrp_cpt_date"))



                  || (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "occutherapy_go_copy_505")
                  && isDateEqual(r, MET, MEASURE_NAME, "medsit_date", "occutherapy_go_copy_505_date"))



                  || (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "occuthera_reevalution_cpt")
                  && isDateEqual(r, MET, MEASURE_NAME, "medsit_date", "occuthera_reevalution_cpt_date"))

                    */

                )
            )
        )


        ||

        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "meorotrenodo")
            && checkElementPresent(r, EXCEPTION, MEASURE_NAME, "cumedosn")
            &&
            (

              /*
              (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "meencodes")
                && isDateEqual(r, MET, MEASURE_NAME, "meorotrenodo_date", "meencodes_date")
                )

                ||
                */
                (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "thrpins")
                && isDateEqual(r, MET, MEASURE_NAME, "meorotrenodo_date", "thrpins_date"))


                /*
                || (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "phythrpevaltn_cpt")
                && isDateEqual(r, MET, MEASURE_NAME, "meorotrenodo_date", "phythrpevaltn_cpt_date"))


                || (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "revaphythrp_cpt")
                && isDateEqual(r, MET, MEASURE_NAME, "meorotrenodo_date", "revaphythrp_cpt_date"))


                || (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "occutherapy_go_copy_505")
                && isDateEqual(r, MET, MEASURE_NAME, "meorotrenodo_date", "occutherapy_go_copy_505_date"))



                || (checkElementPresent(r, EXCEPTION, MEASURE_NAME, "occuthera_reevalution_cpt")
                && isDateEqual(r, MET, MEASURE_NAME, "meorotrenodo_date", "occuthera_reevalution_cpt_date"))

                  */

              )
          )
    )

  }


}
