package com.figmd.janus.measureComputation.cmsMeasures

  import java.util.Date

  import com.datastax.spark.connector.CassandraRow
  import com.datastax.spark.connector.rdd.CassandraTableScanRDD
  import com.figmd.janus.{WebDataMartCreator, Measure}
  import org.apache.spark.rdd.RDD
import com.figmd.janus.util.measure.{MeasureUtility}
  import com.figmd.janus.util.application.{CassandraUtility, DateUtility,PostgreUtility}
  import org.apache.spark.sql.SparkSession

  object CMS127 extends MeasureUtility with Measure {

    def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

      // Filter IPP
      val ippRDD = getIpp(rdd, startDate, endDate, MEASURE_NAME)
      ippRDD.cache()
      //NotEligiable
      val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD,startDate,endDate,MEASURE_NAME)
      exclusionRDD.cache()
      // Filter Intermediate
      val intermediate =  getSubtractRDD(ippRDD,exclusionRDD)
      intermediate.cache()
      // Filter Met
      val metRDD = getMet(intermediate,startDate,endDate,MEASURE_NAME)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not meate
      val notMetRDD = getinterRDD(intermediate,metRDD)
      notMetRDD.cache()

      //measure.M127.element.select=practiceuid,serviceprovideruid,locationid,patientuid,visituid,genderuid,dob,encounterdate,firstname,midname,lastname,patient_mrn,ofvi_1,ofvi_1_date,fain,fain_date,anwevi_1,anwevi_1_date,hohese,hohese_date,prcaseesofvi18anup_1,prcaseesofvi18anup_1_date,prcaseofvi18anup_1,prcaseofvi18anup_1_date,enin_1,ditohofohoca,enin_1_date,ditohecafafohoca,hocaam,hocaam_date,pnvaad,pnvaad_date,hiofpnva,hiofpnva_date

      saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

    }

    // Filter IPP
    def getIpp(rdd: RDD[CassandraRow], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {
      rdd.filter(r =>
        (
          isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)&&

          (
              (checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1") &&
                isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate)
                )
                ||
                (checkElementPresent(r, IPP, MEASURE_NAME, "fain") &&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate)
                  )
                ||
                (checkElementPresent(r, IPP, MEASURE_NAME, "anwevi_1") &&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "anwevi_1_date", startDate, endDate)
                  )
                ||
                (checkElementPresent(r, IPP, MEASURE_NAME, "hohese") &&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "hohese_date", startDate, endDate))
                ||

                (checkElementPresent(r, IPP, MEASURE_NAME, "prcaseesofvi18anup_1") &&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "prcaseesofvi18anup_1_date", startDate, endDate)
                  )
                ||
                (checkElementPresent(r, IPP, MEASURE_NAME, "prcaseofvi18anup_1") &&
                  isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "prcaseofvi18anup_1_date", startDate, endDate)
                  )


              )
          )
      )

    }

    def getExclusionRdd(ippRDD: RDD[CassandraRow], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {

      ippRDD.filter(r =>
        (
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "enin_1") &&
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohofohoca") &&
              isDateOverlapsMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "enin_1_date", endDate)
            )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "enin_1") &&
                checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohecafafohoca") &&
                isDateOverlapsMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "enin_1_date", endDate)
              )
          )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hocaam") &&
              isDateOverlapsMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hocaam_date", endDate)
            )

      )

    }

    def getMet(ippRDD: RDD[CassandraRow] ,startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {
      ippRDD.filter(r =>

        (
          checkElementPresent(r, MET, MEASURE_NAME, "hocaam")&&
            isDateOverlapsMeasurementPeriod(r, MET, MEASURE_NAME, "hocaam_date",endDate)
          )
          ||
          (
            checkElementPresent(r, MET, MEASURE_NAME, "pnvaad")&&
            isDateOverlapsMeasurementPeriod(r, MET, MEASURE_NAME, "pnvaad_date",endDate)
            )
          ||
          (
            checkElementPresent(r, MET, MEASURE_NAME, "hiofpnva")&&
            isDateOverlapsMeasurementPeriod(r, MET, MEASURE_NAME, "hiofpnva_date",endDate)
            )
      )

    }


  }


