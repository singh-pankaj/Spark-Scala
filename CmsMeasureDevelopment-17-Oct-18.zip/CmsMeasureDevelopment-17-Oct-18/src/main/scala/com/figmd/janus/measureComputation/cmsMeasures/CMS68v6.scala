package com.figmd.janus.measureComputation.cmsMeasures

import java.util.Date
import com.figmd.janus.Measure
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator.prop
import com.figmd.janus.util.measure.MeasureUtility

  object CMS68v6 extends MeasureUtility with Measure {

    def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

      // Filter IPP
      val ippRDD = getIpp(rdd, startDate, endDate, MEASURE_NAME)
      ippRDD.cache()
      //NotEligiable
      val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      //met
      val metRDD = getMet(ippRDD, MEASURE_NAME)
      metRDD.cache()
      // Filter Exceptions
      val intermediate = getinterRDD(ippRDD, metRDD)
      intermediate.cache()
      val exceptionRDD = getexceptionRDD(intermediate, MEASURE_NAME)
      exceptionRDD.cache()
      // Filter not meate
      val notMetRDD = getinterRDD(intermediate, exceptionRDD)
      notMetRDD.cache()


      saveToWebDM(rdd, ippRDD, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      //measure.M68.element.select=practiceuid,serviceprovideruid,locationid,patientuid,visituid,genderuid,dob,encounterdate,firstname,midname,lastname,patient_mrn,meencose,meencose_date,cumedosn,cumedosn_date,meencose_date,meorotrenodo,meorotrenodo_date


    }

    // Filter IPP
    def getIpp(rdd:RDD[CassandraRow], startDate: Date, endDate: Date, MEASURE_NAME: String): RDD[CassandraRow] = {
      rdd.filter(r =>
        (
          isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)
            &&

            (
              checkElementPresent(r, IPP, MEASURE_NAME, "meencose") &&
                isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "meencose_date", startDate, endDate)
              )
          )
      )

    }


    def getMet(ippRDD: RDD[CassandraRow] , MEASURE_NAME: String): RDD[CassandraRow] = {
      ippRDD.filter(r =>
        (
          checkElementPresent(r, MET, MEASURE_NAME, "cumedosn")
            &&
            isDateEqual(r, MET, MEASURE_NAME, "cumedosn_date","meencose_date")

          )
      )

    }

    def getexceptionRDD(intermediateRDD: RDD[CassandraRow],MEASURE_NAME: String): RDD[CassandraRow] = {
      intermediateRDD.filter(r =>

          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "meorotrenodo") &&
            isDateEqual(r, EXCEPTION, MEASURE_NAME, "meorotrenodo_date","meencose_date")

      )




    }



  }



