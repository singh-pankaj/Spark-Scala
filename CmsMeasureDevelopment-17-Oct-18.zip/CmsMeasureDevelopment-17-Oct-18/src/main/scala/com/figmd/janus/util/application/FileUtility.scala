package com.figmd.janus.util.application

import java.util.Properties

import scala.io.Source
import scala.reflect.io.File

class FileUtility extends Serializable {

  def getPropertyLog(): String = {

    lazy val properties: Properties = new Properties()

    val url = getClass.getResource("/application.properties")

    if (url != null) {
      val source = Source.fromURL(url)
      properties.load(source.bufferedReader())
    }

/*    if (randNum == 1) {
       properties.getProperty("file.output.path.log1")
    }else if (randNum == 2) {
       properties.getProperty("file.output.path.log2")
    }else if (randNum == 3) {
       properties.getProperty("file.output.path.log3")
    }else if (randNum == 4) {
       properties.getProperty("file.output.path.log4")
    }else if (randNum == 5) {
       properties.getProperty("file.output.path.log5")
    }else {
       properties.getProperty("file.output.path.log")
    }*/
    ("/tmp/CMS/").trim
  }

  def getProperty(property: String): String = {

    var properties: Properties = null
    var logfilename=""
    val url = getClass.getResource("/application.properties")


    if (url != null) {
      val source = Source.fromURL(url)
      properties = new Properties()
      properties.load(source.bufferedReader())
    }
    return properties.getProperty(property);
  }

  def getProperty():Properties = {

    var properties: Properties = null
    val url = getClass.getResource("/application.properties")

    if (url != null) {
      val source = Source.fromURL(url)
      properties = new Properties()
      properties.load(source.bufferedReader())
    }

    return properties

  }

  def getPropertyLog4j():Properties = {

    var properties: Properties = null
    val url = getClass.getResource("/log4j.properties")

    if (url != null) {
      val source = Source.fromURL(url)
      properties = new Properties()
      properties.load(source.bufferedReader())
    }

    return properties

  }

  def loggerFileUtility(log_file:String,wf_id:String,wfType:String): Unit ={

    println("1.::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + log_file)
    var s3_file_path = getProperty("file.output.path") + "/" + wf_id + "_" + wfType
    val file = File(log_file)
    val path_src = new org.apache.hadoop.fs.Path(log_file)
    val path_dst = new org.apache.hadoop.fs.Path(s3_file_path)
    if (file.exists) {
      import sys.process._
      val exitCode2 = (s"wc -l $path_src").!!
      println(exitCode2)
      println(path_src + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + path_dst)
      val exitCode = (s"sed -i '/~/!d' $path_src").!
      val exitCode3 = (s"wc -l $path_src").!!
      println(exitCode3)
      //code to copy from local to hdfs
      //measureUtilityObj.hdfsConf.moveFromLocalFile(path_src,path_dst)
      //code to copy from local to s3
      //            val fs = FileSystem.get(URI.create(s3_file_path), new SparkUtility().getSparkContext().sparkContext.hadoopConfiguration)
      //            if(fs.exists(path_dst))
      //              fs.delete(path_dst,true)
      //            fs.moveFromLocalFile(path_src, path_dst)

      //fs.copyFromLocalFile(true, true, path_src, path_dst)
    }




  }


}
