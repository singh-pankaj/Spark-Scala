package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.Measure
import com.figmd.janus.util._
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object QPP119 extends MeasureUtility with Measure {
  def refresh(sparkSession: SparkSession,rdd:RDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd,startDate,endDate,MEASURE_NAME)
    ippRDD.cache()
    //NotEligiable
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Eligible IPP
    val eligibleRdd = sparkSession.sparkContext.emptyRDD[CassandraRow]
    eligibleRdd.cache()
    // Filter Exclusions

    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD,startDate: Date,endDate: Date,MEASURE_NAME)
    exclusionRDD.cache()
    // Filter Intermediate
    val intermediateA =  getSubtractRDD(ippRDD,exclusionRDD)
    intermediateA.cache()
    // Filter Met
    val metRDD = getMet(intermediateA,startDate: Date,endDate: Date,MEASURE_NAME)
    metRDD.cache()
    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not meate
    val notMetRDD =  getSubtractRDD(intermediateA,metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd,ippRDD,notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }
  def getIpp(rdd:RDD[CassandraRow],startDate:Date,endDate:Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    rdd
      .filter(r =>
        isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18) &&
          (
            checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1")||
              checkElementPresent(r, IPP, MEASURE_NAME, "prcaseesofvi18anup_1")||
              checkElementPresent(r, IPP, MEASURE_NAME, "prcaseofvi18anup_1")||
              checkElementPresent(r, IPP, MEASURE_NAME, "hohese")||
              checkElementPresent(r, IPP, MEASURE_NAME, "fain")||
              checkElementPresent(r, IPP, MEASURE_NAME, "anwevi_1")||
              checkElementPresent(r, IPP, MEASURE_NAME, "ippexam")

            )
          &&
          isAgeLess(r, IPP, MEASURE_NAME, "dob", "encounterdate", 76) &&
          (
            checkElementPresent(r, IPP, MEASURE_NAME, "diab_1")&&
            isDateOverlapsLessOrEqual(r, IPP, MEASURE_NAME,"diab_1_date","encounterdate")
          )
          &&
          (
            isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"ofvi_1_date",startDate,endDate)||
              isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"prcaseesofvi18anup_1_date",startDate,endDate)||
              isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"prcaseofvi18anup_1_date",startDate,endDate)||
              isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"fain_date",startDate,endDate)||
              isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"anwevi_1_date",startDate,endDate)||
              isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"ippexam_date",startDate,endDate)


            )

      )
  }

  def getExclusionRdd(ippRDD: RDD[CassandraRow],startDate:Date,endDate:Date, MEASURE_NAME: String): RDD[CassandraRow] = {
    ippRDD.filter(r => (
      checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hspser")&&
        isDuringMeasurementPeriod(r, IPP, MEASURE_NAME,"hspser_date",startDate,endDate)
      )
      ||
      (
        checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hospiceservices")&&
          isDateOverlapsDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hospiceservices_date",endDate)
          ||
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hspccr")&&
          isDateOverlapsDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hspccr_date",endDate)

        )

    )
  }

  def getMet(intermediateA:RDD[CassandraRow],startDate: Date, endDate: Date,MEASURE_NAME:String): RDD[CassandraRow] = {
    intermediateA.filter(r =>
      (
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "acinorar")&&
            isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "acinorar_date","encounterdate")
          )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hychkidi")&&
              isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "hychkidi_date","encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "kifa")&&
              isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "kifa_date","encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "glannesy")&&
              isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "glannesy_date","encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "dine")&&
              isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "dine_date","encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "prot")&&
              isDateOverlapsLessOrEqual(r, EXCLUSION, MEASURE_NAME, "prot_date","encounterdate")
            )
        )

        &&
        (
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "kitr")&&
              isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "kitr_date",startDate,endDate)
            )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "vaacfodi")&&
                isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "vaacfodi_date",startDate,endDate)
              )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "dise")&&
                isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "dise_date",startDate,endDate)
              )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "otseretodi")&&
                isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "otseretodi_date",startDate,endDate)
              )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "died")&&
                isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "died_date",startDate,endDate)
              )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "esmoouse")&&
                isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "esmoouse_date",startDate,endDate)
              )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "urprte")&&
                isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "urprte_date",startDate,endDate)
              )
          )
        &&
        (
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "posmicro")&&
              isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "posmicro_date",startDate,endDate)
            )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "posmacro")&&
                isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "posmacro_date",startDate,endDate)
              )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "negmicro")&&
                isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "negmicro_date",startDate,endDate)
              )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "trtneph")&&
                isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "trtneph_date",startDate,endDate)
              )
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "acearbthrpy")&&
                isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "acearbthrpy_date",startDate,endDate)
              )
          )
        &&
        !(

          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "macronmet")&&
              isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "macronmet_date",startDate,endDate)
            )
          /*
                      &&
                      (
                        checkElementPresent(r, EXCLUSION, MEASURE_NAME, "posmicro")&&
                          isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "posmicro_date",startDate,endDate)&&
                          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "posmacro")&&
                          isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "posmacro_date",startDate,endDate)&&
                          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "negmicro")&&
                          isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "negmicro_date",startDate,endDate)
                        )
          */




          )
    )

  }


}
