package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.figmd.janus.Measure
import com.figmd.janus.util._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator.prop
import com.figmd.janus.util.measure.MeasureUtility
import org.joda.time.DateTime

object QPP204 extends MeasureUtility with Measure {

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): Unit = {

    /** Missing column from cassandra acc_2018, tblencounter_qpp
      * asanotan_copy_704
      * asanotan_copy_704_date
      * ancomeds
      * ancomeds_date
      */

    // initial IPP 1
    val ippInitialRDD = getInitialIpp(rdd, MEASURE_NAME, startDate: Date, endDate: Date)
    ippInitialRDD.cache()


    var patientHistoryRDD = sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"),
      prop.getProperty("patientHistory")).select("patientuid", "acmyin", "acmyin_date", "pecoin", "pecoin_date", "coarbygr", "coarbygr_date")

    val CRA = getBackTrackingList(patientHistoryRDD, ippInitialRDD, "acmyin", "acmyin_date", "pecoin", "pecoin_date", "coarbygr", "coarbygr_date")

    val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)

    // Eligible IPP
    val ippRdd = getEligibleIpp(ippInitialRDD, MEASURE_NAME, CRA_list, startDate: Date, endDate: Date)

    // Filter Exclusions
    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    ippRdd.cache()

    // Filter Exclusions
    val exclusionRDD = getDenominatorExclusionRDD(ippRdd, MEASURE_NAME, startDate, endDate)
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = ippRdd.subtract(exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA, MEASURE_NAME: String, startDate: Date, endDate: Date)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA, metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRdd, notEligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }


  def getInitialIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {


     rdd.filter(r =>

      (checkElementPresent(r, IPP, MEASURE_NAME, "ippexm")
        && isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "ippexm_date", 18)

        || checkElementPresent(r, IPP, MEASURE_NAME, "prcaseofvi18anup_1")
        && isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "prcaseofvi18anup_1_date", 18)

        || checkElementPresent(r, IPP, MEASURE_NAME, "prcaseesofvi18anup_1")
        && isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "prcaseesofvi18anup_1_date", 18)

        || checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1")
        && isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "ofvi_1_date", 18)

        || checkElementPresent(r, IPP, MEASURE_NAME, "hohese")
        && isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "hohese_date", 18)

        || checkElementPresent(r, IPP, MEASURE_NAME, "fain")
        && isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "fain_date", 18)

        || checkElementPresent(r, IPP, MEASURE_NAME, "anwevi_1")
        && isAgeGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "anwevi_1_date", 18)

        )

        && (isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ippexm_date", startDate, endDate)

        || isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "prcaseofvi18anup_1_date", startDate, endDate)
        || isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "prcaseesofvi18anup_1_date", startDate, endDate)
        || isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "ofvi_1_date", startDate, endDate)
        || isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "hohese_date", startDate, endDate)
        || isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "fain_date", startDate, endDate)
        || isDuringMeasurementPeriod(r, IPP, MEASURE_NAME, "anwevi_1_date", startDate, endDate)
        )

    )


  }

  def getEligibleIpp(rdd: RDD[CassandraRow], MEASURE_NAME: String, CRA_list: Broadcast[List[String]], startDate: Date, endDate: Date): RDD[CassandraRow] = {

     rdd.filter(r => BackTrackingIPP_1(r, IPP, MEASURE_NAME, CRA_list, startDate, endDate)

      || (checkElementPresent(r, IPP, MEASURE_NAME, "isvadi")
      && isDateEqual(r, IPP, MEASURE_NAME, "isvadi_date", "encounterdate"))

      || BackTrackingIPP_2(r, IPP, MEASURE_NAME, CRA_list, startDate, endDate)

    )


  }

  def BackTrackingIPP_1(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]], startDate: Date, endDate: Date): Boolean = {
    var flag = false

    for (x <- CRA.value) {
      if (x != "") {
        val back_data = x.split("~")
        val patientid = back_data(0)
        val acmyin_element = back_data(1)
        val acmyin_date_back = dateUtility.dateTimeParse(back_data(2))
        val Start_Date = new DateTime(startDate)

        if (
          !r.isNullAt("encounterdate")
            && r.getString("patientuid").equals(patientid)
            && r.getString("acmyin").equals(1)
            && ((Start_Date.minusMonths(12).isBefore(acmyin_date_back)
            || Start_Date.minusMonths(12).isBefore(acmyin_date_back))

            && Start_Date.isAfter(acmyin_date_back)
            )
        )

          flag = true
      }

    }
    return flag

  }

  def BackTrackingIPP_2(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]], startDate: Date, endDate: Date): Boolean = {
    var flag = false

    for (x <- CRA.value) {
      if (x != "") {
        //println(r.getString("visituid") + ">>>" + x)
        val back_data = x.split("~")
        val patientid = back_data(0)
        val pecoin_elemet = back_data(3);
        val pecoin_date_back = dateUtility.dateTimeParse(back_data(4))
        val coarbygr_element = back_data(5)
        val coarbygr_date_back = dateUtility.dateTimeParse(back_data(6))
        val Start_Date = new DateTime(startDate)


        if (
          (!r.isNullAt("encounterdate")
            && r.getString("patientuid").equals(patientid)
            && r.getString("pecoin").equals(1)
            && (Start_Date.minusMonths(12).isBefore(pecoin_date_back)
            || Start_Date.minusMonths(12).isBefore(pecoin_date_back))

            && Start_Date.isAfter(coarbygr_date_back)
            )

            ||

            (
              !r.isNullAt("encounterdate")
                && r.getString("patientuid").equals(patientid)
                && r.getString("coarbygr").equals(1)
                && (Start_Date.minusMonths(12).isBefore(coarbygr_date_back)
                || Start_Date.minusMonths(12).isBefore(coarbygr_date_back))

                && Start_Date.isAfter(coarbygr_date_back)
              )
        )

          flag = true


      }

    }
    return flag

  }

  def getMet(intermediateA: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    //  asanotan_copy_704    aspantipltlt
     intermediateA.filter(r =>

      (
        // (checkElementPresent(r,MET,MEASURE_NAME,"asanotan_copy_704")
        // && isDateOverlapsMeasurementPeriod(r,MET,MEASURE_NAME,"asanotan_copy_704_date",endDate))

        //||
        (checkElementPresent(r, MET, MEASURE_NAME, "aspantipltlt")
          && isDuringMeasurementPeriod(r, MET, MEASURE_NAME, "aspantipltlt_date", startDate, endDate))


        )

        // aspantipltl_rsnns
        &&
        (!checkElementPresent(r, MET, MEASURE_NAME, "aspantipltl_rsnns")
          && !isDuringMeasurementPeriod(r, MET, MEASURE_NAME, "aspantipltl_rsnns_date", startDate, endDate))

    )

  }

  def getDenominatorExclusionRDD(rdd: RDD[CassandraRow], MEASURE_NAME: String, startDate: Date, endDate: Date): RDD[CassandraRow] = {

    // ancomeds_date  hospiceservcs  docanticoameds

    rdd.filter(r =>

      /** ancomeds & ancomeds column is not present **/
      /* (checkElementPresent(r,EXCLUSION,MEASURE_NAME,"ancomeds")
        && isDateOverlapsMeasurementPeriod(r,EXCLUSION,MEASURE_NAME,"ancomeds_date",endDate)
         )
       ||
      */

      (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hospiceservcs")
        && isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hospiceservcs_date", startDate, endDate)
        )

        || (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "docanticoameds")
        && isDuringMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "docanticoameds_date", startDate, endDate)
        )

        // hspccr hospiceservices

        || ((checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hspccr")
        && isDateOverlapsMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hspccr_date", endDate))

        || (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hospiceservices")
        && isDateOverlapsMeasurementPeriod(r, EXCLUSION, MEASURE_NAME, "hospiceservices_date", endDate))

        )

    )

  }

  def getBackTrackingList(rdd: RDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement2: String, backtrackelement3: String, backtrackelement4: String,
                          backtrackelement5: String, backtrackelement6: String): List[String] = {
    if (!ippRDD.isEmpty) {

      val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).collect().toList

      val BacktrackingRDD = rdd.map(x => (
        x.getString("patientuid"),
        if (!x.isNullAt("acmyin")) x.getString("acmyin") else "",
        if (!x.isNullAt("acmyin_date")) x.getString("acmyin_date") else "",
        if (!x.isNullAt("pecoin")) x.getString("pecoin") else "",
        if (!x.isNullAt("pecoin_date")) x.getString("pecoin_date") else "",
        if (!x.isNullAt("coarbygr")) x.getString("coarbygr") else "",
        if (!x.isNullAt("coarbygr_date")) x.getString("coarbygr_date") else ""

      )).filter(x => ipp_patient_list.contains(x._1))

      if (!BacktrackingRDD.isEmpty) {
        var CRA = BacktrackingRDD.map(x => {
          x._1 + "~" + x._2 + "~" + x._3 + "~" + x._4 + "~" + x._5 + "~" + x._6 + "~" + x._7
        }
        )
          .collect()
          .toList

        return CRA
      }
      else {
        val l = List[String]()
        l
      }
    }

    else {
      val l = List[String]()
      l
    }
  }


}