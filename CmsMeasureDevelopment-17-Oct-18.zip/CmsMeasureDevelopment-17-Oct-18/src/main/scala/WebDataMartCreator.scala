package com.figmd.janus

import java.text.SimpleDateFormat
import java.util.{Calendar, Date, Properties}

import com.datastax.spark.connector.{CassandraRow, ColumnName}
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.util._
import com.figmd.janus.util.application._
import com.figmd.janus.util.measure.{MeasureUtility, SetPropertyArgs}
import com.google.common.base.Throwables
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

object WebDataMartCreator extends Serializable {

  @transient lazy val postgresUtility = new PostgreUtility()
  val prop = new Properties
  val debugMode = 1
  val start_date = Calendar.getInstance.getTime
  var wf_id = ""
  var quarter_end_date = ""
  var measure_list = ""
  var global_measure_name = ""
  var practiceListCondition = ""
  var action_name = "Measure_Computation"

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  //Logger.getLogger("myLogger").setLevel(Level.OFF)
  val cassandraUtilityObj=new CassandraUtility
  val sessionobj=cassandraUtilityObj.jdbcconnect

  def main(args: Array[String]) {
    try {
      println("Start Time : " + start_date)

      // new comment
      // set all command line objectinto property object
      val setPropObj = new SetPropertyArgs(args)
      val wfType = prop.getProperty("wfType")
      wf_id = prop.getProperty("wf_id")

      // Workflow type validation
      chkValidWFType(measure_list)

      var sparkUtility = new SparkUtility()
      var spark = sparkUtility.getSparkContext()
      spark.sparkContext.setLogLevel("ERROR")
      val dateUtility = new DateUtility()

      //Execute each measure sequentially
      executeMeasure(spark, wfType)

      println("Measure refresh Start Time : " + start_date)
      println("Measure refresh End Time  : " + Calendar.getInstance.getTime)
      //var emailUtility  = new EmailUtility("sagar.kulkarni2007@gmail.com","","","sagar.kulkarni2007@gmail.com","Test","Hi","smtp.gmail.com")
      //emailUtility.sendMessage
    }
    catch {
      case e: Exception => {
        println(e.printStackTrace())
        postgresUtility.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
        System.exit(-1)
      }
    }
  }


  def executeMeasure(spark: SparkSession, wfType: String): Unit = {
    var measureUtilityObj = new MeasureUtility()
    val fileUtility = new FileUtility()

    var dateFormat = fileUtility.getProperty("date.format")
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)

    val equal_measure_list = prop.getProperty("equal_measure_list")
    val qpp_measure_list = prop.getProperty("qpp_measure_list")
    val nonqpp_measure_list = prop.getProperty("nonqpp_measure_list")
    val cms_measure_list = prop.getProperty("cms_measure_list")
    val median_measure_list = prop.getProperty("median_measure_list")
    var date_str = prop.getProperty("DateRange")
    var month_end_date_list = ""

    if (!date_str.isEmpty) {
      //Golbal RDD
      val rdd = new CassandraUtility().getCassandraRDD(spark)

      var date_range_arr = date_str.trim.substring(1, date_str.length - 1).split(",")
      //loop for rolling-non rolling
      for (date_range <- date_range_arr) {
        println("prop:1::::::::::::::" + date_range)
        val measure_start_time = Calendar.getInstance.getTime

        var date_arr = date_range.split("~")
        var quarterStartDate = date_arr(0).trim
        var quarterEndDate = date_arr(1).trim
        var quarterStartDateFormatted = SIMPLE_DATE_FORMAT.parse(date_arr(0).trim)
        var quarterEndDateFormatted = SIMPLE_DATE_FORMAT.parse(date_arr(1).trim)

        prop.setProperty("quarterStartDate", quarterStartDate.toString)
        prop.setProperty("quarterEndDate", quarterEndDate.toString)

        println("quarterStartDate:::::::::::::::" + prop.getProperty("quarterStartDate"))
        println("quarterEndDate:::::::::::::::" + prop.getProperty("quarterEndDate"))
        println("equal_measure_list:::::::::::::::" + prop.getProperty("equal_measure_list"))
        println("qpp_measure_list:::::::::::::::" + prop.getProperty("qpp_measure_list"))
        println("nonqpp_measure_list:::::::::::::::" + prop.getProperty("nonqpp_measure_list"))
        println("cms_measure_list:::::::::::::::" + prop.getProperty("cms_measure_list"))
        println("median_measure_list:::::::::::::::" + prop.getProperty("median_measure_list"))

        if (!equal_measure_list.equalsIgnoreCase("NA") && !equal_measure_list.equalsIgnoreCase("")) {
          var equal_measures = equal_measure_list.split(",");
          equal_measures.foreach(measure => {
            global_measure_name = measure
            val fullname = "com.figmd.janus.measureComputation.equalMeasures.cms" + measure.substring(1) + "$"
            measureCall(spark,rdd,measure,measureUtilityObj,quarterStartDateFormatted,quarterEndDateFormatted,fullname)

          })
        }

        if (!qpp_measure_list.equalsIgnoreCase("NA") && !qpp_measure_list.equalsIgnoreCase("")) {
          var qpp_measures = qpp_measure_list.split(",");
          qpp_measures.foreach(measure => {
            global_measure_name = measure
            val fullname = "com.figmd.janus.measureComputation.qppMeasures.QPP" + measure.substring(1) + "$"
            measureCall(spark,rdd,measure,measureUtilityObj,quarterStartDateFormatted,quarterEndDateFormatted,fullname)

          })

        }

        if (!nonqpp_measure_list.equalsIgnoreCase("NA") && !nonqpp_measure_list.equalsIgnoreCase("")) {
          var nonqpp_measures = nonqpp_measure_list.split(",");
          nonqpp_measures.foreach(measure => {
            global_measure_name = measure
            val fullname = "com.figmd.janus.measureComputation.nonQppMeasures.cms" + measure.substring(1) + "$"
            measureCall(spark,rdd,measure,measureUtilityObj,quarterStartDateFormatted,quarterEndDateFormatted,fullname)


          })

        }

        if (!cms_measure_list.equalsIgnoreCase("NA") && !cms_measure_list.equalsIgnoreCase("")) {
          var cms_measures = cms_measure_list.split(",");
          cms_measures.foreach(measure => {

            global_measure_name = measure
            val fullname = "com.figmd.janus.measureComputation.cmsMeasures.CMS" + measure.substring(1) + "$"
            measureCall(spark,rdd,measure,measureUtilityObj,quarterStartDateFormatted,quarterEndDateFormatted,fullname)

          }
        )

        }

        if (!median_measure_list.equalsIgnoreCase("NA") && !median_measure_list.equalsIgnoreCase("")) {
          val fullnames = "com.figmd.janus.measureComputation.nonQppMeasures.ACEPmedian_1_2$~com.figmd.janus.measureComputation.nonQppMeasures.ACEPmedian_3_4$"
          var fullname_list = fullnames.split("~");
          fullname_list.foreach(fullname => {
            global_measure_name = fullname
            println(fullname)
            val clazz = Class.forName(fullname);
            val measure="M32_1"
            var columnRef = measureUtilityObj.getFiledList(measure)
            val newRdd = rdd.select(columnRef.map(ColumnName(_)): _*).where(s"encounterdate>=? and encounterdate<=? " + prop.getProperty("practiceListCondition"), quarterStartDateFormatted, quarterEndDateFormatted)
            val myObj = clazz.getField("MODULE$").get(classOf[MedianTrait]).asInstanceOf[MedianTrait]
            myObj.refresh(spark,rdd,quarterStartDateFormatted, quarterEndDateFormatted)

          })
        }

        println(wfType + " Measure refresh Start Time : " + measure_start_time)
        println(wfType + " Measure refresh End Time  : " + Calendar.getInstance.getTime)
      }

      var log_file = measureUtilityObj.logfilename
      fileUtility.loggerFileUtility(log_file, wf_id, wfType)

      // CASANDRA DELETION
      //    deleteFromCassandra(spark,median_measure_list,date_str)
    }
  }

  def measureCall(spark:SparkSession,rdd:CassandraTableScanRDD[CassandraRow], measure:String,measureUtilityObj:MeasureUtility,quarterStartDateFormatted:Date,quarterEndDateFormatted:Date,fullname:String): Unit ={
    //  val fullname = "com.figmd.janus.measureComputation.equalMeasures.CMS" + measure.substring(1) + "$"
    println(fullname)

    val clazz = Class.forName(fullname);
    val myObj = clazz.getField("MODULE$").get(classOf[Measure]).asInstanceOf[Measure]

    var columnRef = measureUtilityObj.getFiledList(measure)
    val newRdd = rdd.select(columnRef.map(ColumnName(_)): _*).where(s"encounterdate>=? and encounterdate<=? " + prop.getProperty("practiceListCondition"), quarterStartDateFormatted, quarterEndDateFormatted)
    myObj.refresh(spark, newRdd, measure, quarterStartDateFormatted, quarterEndDateFormatted)

  }

  def chkValidWFType(measure_list: String): Unit = {
    if (prop.getProperty("wfType").isEmpty) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0001", "CRITICAL", "Argument workflow type should not null, Values may be QR,QNR,MR,MNR,QCNR.", "FAIL")
      System.exit(-1)
    }
  }

  def deleteFromCassandra(spark: SparkSession, median_measure_list: String, date_str: String): Unit = {
    val cassandraUtility = new CassandraUtility
    if (!median_measure_list.equalsIgnoreCase("NA") && !median_measure_list.equalsIgnoreCase("")) {
      cassandraUtility.deleteFromWebdatamartMedian(spark, measure_list, date_str)
    }
    else {
      cassandraUtility.deleteFromWebdatamart(spark, measure_list, date_str)
    }
    //      postgresUtility.tinPracticeMapping(spark)
    //      postgresUtility.practiceSubPracticeMapping(spark)
  }


}


//New Comment
