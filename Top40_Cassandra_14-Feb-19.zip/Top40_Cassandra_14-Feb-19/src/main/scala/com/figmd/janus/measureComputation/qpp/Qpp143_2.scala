package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP143Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.qpp.Qpp143_1.isVisitTypeIn

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 143_2
* Measure Title              :- Oncology: Medical and Radiation - Pain Intensity Quantified
* Measure Description        :- Percentage of patient visits, regardless of patient age, with a diagnosis of cancer currently receiving chemotherapy or radiation therapy in which pain intensity is quantified.
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp143_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp143_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP
   //  Patient history RDD.
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP143Elements.Office_Visit,
      QPP143Elements.Face_To_Face_Interaction,
      QPP143Elements.Radiation_Treatment_Management,
      QPP143Elements.Cancer,
      QPP143Elements.Chemotherapy_Administration,
      QPP143Elements.Office_Visit_Telehealth_Modifier,
      QPP143Elements.Pos_02,
      QPP143Elements.Pain_Severity_Positive,
      QPP143Elements.Pain_Quantified_No_Pain_Present,
      QPP143Elements.Pain_Qntfctn_Reason_Not_Specified)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
        metRDD.cache()
      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isDiagnosedWithInHistory(visit, m, QPP143Elements.Cancer, patientHistoryBroadcastList)
        && isProcedurePerformed(visit, m, QPP143Elements.Radiation_Treatment_Management, patientHistoryBroadcastList)
    )
  }


  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>

      (
        isAssessmentPerformedOnEncounter(visit, m, QPP143Elements.Standardized_Pain_Assessment_Tool)
          || isAssessmentPerformedOnEncounter(visit, m, QPP143Elements.Pain_Score)
          || (isAssessmentPerformed(visit, m, QPP143Elements.Pain_Severity_Positive, patientHistoryBroadcastList)
          || isAssessmentPerformed(visit, m, QPP143Elements.Pain_Quantified_No_Pain_Present, patientHistoryBroadcastList)
          )
        )
        && !isAssessmentPerformed(visit, m, QPP143Elements.Pain_Qntfctn_Reason_Not_Specified, patientHistoryBroadcastList)
    )
  }

}

