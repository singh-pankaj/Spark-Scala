package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, QPP176Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 176
* Measure Title              :- Rheumatoid Arthritis (RA): Tuberculosis Screening
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of rheumatoid arthritis
                               (RA) who have documentation of a tuberculosis (TB) screening performed and results
                               interpreted within 12 months prior to receiving a first course of therapy using
                               a biologic disease-modifying anti-rheumatic drug (DMARD)
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp176 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp176"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP176Elements.Active_Rheumatoid_Arthritis
      , QPP176Elements.Tb_Screening
      , QPP176Elements.Anti__Rheumatic_Drug
      , QPP176Elements.Screening_Of_Tuberculosis_Tb_
      , QPP176Elements.Tb_Screening_Reason_Not_Specified
      , QPP176Elements.Tb_Screening_Medical_Reason
      , QPP176Elements.Patient_Positive_For_Tb
      , QPP176Elements.Past_Treatment_For_Tb
      , QPP176Elements.Anti_Tb_Therapy_Course_Completed
      , QPP176Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_)
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val leastRecentPatientHistoryList: List[CassandraRow] = leastRecentPatientList(patientHistoryRDD
      , QPP176Elements.Active_Rheumatoid_Arthritis
      , QPP176Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_)
    val leastRecentPatientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastRecentPatientHistoryList)


    //Mostrecent Patient History List
    val mostRecentPatientHistoryBroadcastList: Broadcast[List[CassandraRow]] =
      sparkSession.sparkContext.broadcast(mostRecentPatientList(patientHistoryRDD, QPP176Elements.Anti_Tb_Therapy_Course_Completed))

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList, leastRecentPatientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList, leastRecentPatientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate RDD
      val intermediateException = getSubtractRDD(ippRDD, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateException, patientHistoryBroadcastList, leastRecentPatientHistoryBroadcastList, mostRecentPatientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      leastRecentPatientHistoryBroadcastList.destroy()
      mostRecentPatientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
   All patients aged 18 years and older with a diagnosis of RA who are receiving a
   first course of therapy using a biologic DMARD.
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], leastRecentPatientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m
        , QPP176Elements.Home_Healthcare_Services
        , QPP176Elements.Office_Visit
        , QPP176Elements.Initial_Preventive_Physical_Examination)
        && wasFirstDiagnosed(visit, m, QPP176Elements.Active_Rheumatoid_Arthritis, leastRecentPatientHistoryBroadcastList)
        && (
        isAssessmentPerformed(visit, m, QPP176Elements.Anti__Rheumatic_Drug, patientHistoryBroadcastList)
          || wasFirstMedicationOrderedAfterOrEqualDiagnosisAndBeforeOrEqualEnd(visit, m, QPP176Elements.Active_Rheumatoid_Arthritis, QPP176Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_, patientHistoryBroadcastList, leastRecentPatientHistoryBroadcastList)
          || wasFirstMedicationAdministeredAfterOrEqualDiagnosisAndBeforeOrEqualEnd(visit, m, QPP176Elements.Active_Rheumatoid_Arthritis, QPP176Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_, patientHistoryBroadcastList, leastRecentPatientHistoryBroadcastList)
        )
        && !isTeleHealthModifier(visit, m
        , QPP176Elements.Office_Visit_Telehealth_Modifier
        , QPP176Elements.Home_Healthcare_Services_Telehealth_Modifier
        , QPP176Elements.Initial_Preventive_Physical_Examination_Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP176Elements.Pos_02)
    )
  }

  /*------------------------------------------------------------------------------------------------
  Patients for whom a TB screening was performed and results interpreted within 12 months prior to
  receiving a first course of therapy using a biologic DMARD
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], leastRecentPatienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        isAssessmentPerformed(visit, m, QPP176Elements.Screening_Of_Tuberculosis_Tb_, patientHistoryList)
          || wasLaboratoryTestPerformedInXMonthBeforeAssessment(visit, m, QPP176Elements.Tb_Screening, QPP176Elements.Anti__Rheumatic_Drug, 6, CalenderUnit.MONTH, patientHistoryList)
          || wasLaboratoryTestPerformedInXMonthBeforeFirstMedication(visit, m, QPP176Elements.Tb_Screening, QPP176Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_, CalenderUnit.MONTH, 6, patientHistoryList, leastRecentPatienthistoryList)
        )
        && !isAssessmentPerformed(visit, m, QPP176Elements.Tb_Screening_Reason_Not_Specified, patientHistoryList)
    )

  }

  /*-----------------------------------------------------------------------------------------------------------------
    Documentation of medical reason for not screening for TB or interpreting results (i.e., patient positive for TB
    and documentation of past treatment; patient who has recently completed a course of anti-TB therapy)
   -----------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermediateException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], leastRecentPatientHistoryBroadcastList: Broadcast[List[CassandraRow]], mostRecentPatientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateException.filter(visit =>
      isAssessmentPerformed(visit, m, QPP176Elements.Tb_Screening_Medical_Reason, patientHistoryBroadcastList)
        || (
        (wasDiagnosedBeforeOrConcurrentWithCurrentAssessment(visit, m, QPP176Elements.Anti__Rheumatic_Drug, QPP176Elements.Patient_Positive_For_Tb, patientHistoryBroadcastList)
          || wasDiagnosedBeforeOrConcurrentWithFirstMedication(visit, m, QPP176Elements.Patient_Positive_For_Tb, QPP176Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_, patientHistoryBroadcastList, leastRecentPatientHistoryBroadcastList)
          )
          &&
          (wasAssessmentPerformedOrConcurrentWithFirstMedication(visit, m, QPP176Elements.Past_Treatment_For_Tb, QPP176Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_, patientHistoryBroadcastList, leastRecentPatientHistoryBroadcastList)
            || wasAssessmentPerformedBeforeOrConcurrentwithCurrentAssessment(visit, m, QPP176Elements.Anti__Rheumatic_Drug, QPP176Elements.Past_Treatment_For_Tb, patientHistoryBroadcastList)
            )
        )
        || wasMostRecentAssessmentPerformedBeforeOrConcurrentwithCurrentAssessment(visit, m, QPP176Elements.Anti__Rheumatic_Drug, QPP176Elements.Anti_Tb_Therapy_Course_Completed, mostRecentPatientHistoryBroadcastList)
        || wasMostRecentAssessmentPerformedBeforeOrConcurrentWithFirstMedication(visit, m, QPP176Elements.Anti_Tb_Therapy_Course_Completed, QPP176Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_, mostRecentPatientHistoryBroadcastList, leastRecentPatientHistoryBroadcastList)
    )

  }

}
