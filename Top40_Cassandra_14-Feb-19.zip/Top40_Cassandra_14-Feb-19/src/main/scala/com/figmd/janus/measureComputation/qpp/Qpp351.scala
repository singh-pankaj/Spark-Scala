package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP351Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 351
* Measure Title              :- Total Knee Replacement: Venous Thromboembolic and Cardiovascular Risk Evaluation
* Measure Description        :- Percentage of patients regardless of age undergoing a total knee replacement who are evaluated
                                for the presence or absence of venous thromboembolic and cardiovascular risk factors within 30 days
                                prior to the procedure (e.g. history of Deep Vein Thrombosis (DVT), Pulmonary Embolism (PE),
                                Myocardial Infarction (MI), Arrhythmia and Stroke).
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
* Initial GIT Version/Tag(CRA):-
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp351 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp351"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //getPatientHistoryList
      val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
        QPP351Elements.Total_Knee_Replacement,
        QPP351Elements.Stroke,
        QPP351Elements.Myocardial_Infarction,
        QPP351Elements.Arrhythmia,
        QPP351Elements.Pulmonary_Embolism,
        QPP351Elements.Deep_Venous_Thrombosis
      ).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(denominatorRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  /*-----------------------------------------------------------------------------------------------------------------------
    All patients regardless of age undergoing a total knee replacement
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isProcedurePerformedDuringEncounter(visit, m, QPP351Elements.Total_Knee_Replacement)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Patients who are evaluated for the presence or absence of venous thromboembolic and cardiovascular risk factors within 30 days prior to
    the procedure (e.g., history of DVT, PE, MI, arrhythmia and stroke)
   -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      (
        isInterventionPerformedOnEncounter(visit, m, QPP351Elements.Evaluation_Of_Risk_Factors)
          || wasDiagnosedBeforeProcedureInXDays(visit, m, QPP351Elements.Stroke, QPP351Elements.Total_Knee_Replacement, 30, patientHistoryBroadcastList)
          || wasDiagnosedBeforeProcedureInXDays(visit, m, QPP351Elements.Myocardial_Infarction,QPP351Elements.Total_Knee_Replacement, 30, patientHistoryBroadcastList)
          || wasDiagnosedBeforeProcedureInXDays(visit, m, QPP351Elements.Arrhythmia,QPP351Elements.Total_Knee_Replacement, 30, patientHistoryBroadcastList)
          || wasDiagnosedBeforeProcedureInXDays(visit, m, QPP351Elements.Pulmonary_Embolism,QPP351Elements.Total_Knee_Replacement, 30, patientHistoryBroadcastList)
          || wasDiagnosedBeforeProcedureInXDays(visit, m, QPP351Elements.Deep_Venous_Thrombosis,QPP351Elements.Total_Knee_Replacement, 30, patientHistoryBroadcastList)
          || wasInterventionPerformedBeforeProcedureInXDays(visit, m, QPP351Elements.Evaluation_Of_Risk_Factors, QPP351Elements.Total_Knee_Replacement, 30, patientHistoryBroadcastList)
        )
        && !isInterventionPerformed(visit, m, QPP351Elements.Evaluation_Of_Risk_Reason_Not_Specified, patientHistoryBroadcastList)
    )
  }


}
