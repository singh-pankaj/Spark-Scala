package com.figmd.janus

import java.util.Date

import com.datastax.spark.connector.CassandraRow

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

trait Measure {
  def refresh(sparkSession: SparkSession,rdd:RDD[CassandraRow],MEASURE_NAME:String, startDate: Date, endDate: Date): Unit
}
