package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AXON5Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Axon05
* Measure Title               :- Parkinson's: Querying About Sleep Disturbances
* Measure Description         :- All patients with a diagnosis of Parkinson's disease (or caregiver[s], as appropriate)
 *                               who were queried about sleep disturbances at least annually.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.6
----------------------------------------------------------------------------------------------------------------------------*/

object Axon5 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Axon5"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //This measure does not require Patient History

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }
  }


  /*-----------------------------------------------------------------------------------------------------------------------
    All patients with a diagnosis of Parkinson’s disease
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
          isVisitTypeIn(visit, m
            , AXON5Elements.Office_Visit
            , AXON5Elements.Outpatient_Consultation
            , AXON5Elements.Nursing_Facility_Visit
            , AXON5Elements.Home_Healthcare_Services
            , AXON5Elements.Care_Services_In_Long_Term_Residential_Facility
            , AXON5Elements.Evaluation_And_Management
          )
        &&
          isDiagnosedDuringEncounter(visit, m, AXON5Elements.Parkinson_s_Disease)

    )
  }



  /*-----------------------------------------------------------------------------------------------------------------------
  Patients (or caregiver(s), as appropriate) who were queried about sleep disturbances at least annually.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            (
                isAssessmentPerformedDuringEncounter(visit, m, AXON5Elements.Query_For_Sleep_Disturbances)
              ||
                isAssessmentPerformedDuringEncounter(visit, m, AXON5Elements.Querying_About_Sleep_Disturbances)
              ||
                isAssessmentPerformedDuringEncounter(visit, m, AXON5Elements.Sleep_Disturbances_Query)
            )
          &&
            isAssessmentPerformedDuringEncounter(visit, m, AXON5Elements.Querying_About_Sleep_Disturbances_Reason_Not_Specified)
      )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
  Documentation of medical reason for not querying patient (or caregiver) about sleep disturbances
  (e.g., patient is unable to respond and no informant is available).
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
        isAssessmentPerformedDuringEncounter(visit, m, AXON5Elements.Querying_About_Sleep_Disturbances_Medical_Reason)
      )
  }
}
