package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP238Elements,CalenderUnit,CompareOperator,TimeOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- QPP238_1
* Measure Title               :- Use of High-Risk Medications in the Elderly
* Measure Description         :- Percentage of patients 65 years of age and older who were ordered high-risk medications. Two rates are submitted.
                                 a. Percentage of patients who were ordered at least one high-risk medication.
                                 b. Percentage of patients who were ordered at least two of the same high-risk medications.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- 1
* Measure Stratification      :- 1
* Measure Developer           :- Kiran Phalke
* Initial GIT Version/Tag(CRA):- Measure_Develpment/Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Measure_Develpment/Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp238_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP238_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP238Elements.Hospice_Services,
      QPP238Elements.Hospice_Services_Snomedct,
      QPP238Elements.Hospice_Care,
      QPP238Elements.High_Risk_Medications_For_The_Elderly,
      QPP238Elements.High_Risk_Medications_With_Days_Supply_Criteria,
      QPP238Elements.One_High_Risk_Medication,
      QPP238Elements.One_High_Risk_Med_Not_Met


    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList,sparkSession,patientHistoryRDD)
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients 65 years and older who had a visit during the measurement period
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
               isAgeAbove(visit, m, true,65)
          &&  isVisitTypeIn(visit,m,
                                    QPP238Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
                                    QPP238Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up ,
                                    QPP238Elements.Ophthalmologic_Outpatient_Visit,
                                    QPP238Elements.Office_Visit,
                                    QPP238Elements.Home_Healthcare_Services,
                                    QPP238Elements.Face_To_Face_Interaction,
                                    QPP238Elements.Encounter_Inpatient,
                                    QPP238Elements.Annual_Wellness_Visit
                                  )

                      )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Exclude patients who were in hospice care during the measurement year
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            isProcedurePerformed(visit,m,QPP238Elements.Hospice_Services,patientHistoryBroadcastList)
        ||  wasInterventionPerformedInHistory(visit,m,QPP238Elements.Hospice_Services_Snomedct,patientHistoryBroadcastList)
        ||  wasInterventionPerformedInHistory(visit,m,QPP238Elements.Hospice_Care,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients with an order for at least one high-risk medication during the measurement period
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],sparkSession:SparkSession, patientHistoryRDD:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    val MedicationList:List[(String,String)] = List((QPP238Elements.High_Risk_Medications_With_Days_Supply_Criteria,QPP238Elements.High_Risk_Medications_With_Days_Supply_Criteria_Stop_Date))

    val MedicationOrder=cumulative(patientHistoryRDD, m,MedicationList,CalenderUnit.DAY,CalenderUnit.DAY,90,TimeOperator.EQUAL)

    val MedicationResultBroadcastList: Broadcast[List[(String,String,Double)]] = sparkSession.sparkContext.broadcast(MedicationOrder)

    intermediateForMet.filter(visit =>
      (

        isMedicationOrdered(visit,m,patientHistoryBroadcastList,QPP238Elements.High_Risk_Medications_For_The_Elderly)
          ||  getCommulativeResult(visit,m,QPP238Elements.High_Risk_Medications_With_Days_Supply_Criteria,90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
          ||  isMedicationOrdered(visit,m,patientHistoryBroadcastList,QPP238Elements.One_High_Risk_Medication)
        )
        && !isMedicationOrdered(visit,m,patientHistoryBroadcastList,QPP238Elements.One_High_Risk_Med_Not_Met)




    )
  }


}