package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PINN142
* Measure Title               :- Heart Failure: Symptom Management
* Measure Description         :- Percentage of patient visits for those patients aged ≥18 y with a diagnosis of HF and with
                                 quantitative results of an evaluation of both level of activity AND clinical symptoms
                                 documented in which patient symptoms have improved or remained consistent with treatment
                                 goals since last assessment OR patient symptoms have demonstrated clinically important
                                 deterioration since last assessment with a documented plan of care.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- 0
* Measure Stratification      :- 1
* Measure Developer           :- Aanchal.Rai
* Initial GIT Version/Tag(CRA):- 1.8
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object PINN142 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "PINN142"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,PINN142Elements.ACC_Encounter_Code_Set
      ,PINN142Elements.NYHA

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    //Mostrecent Patient History List
    val patientHistoryMostRecentBroadcastList: Broadcast[List[CassandraRow]] =
      sparkSession.sparkContext.broadcast(mostRecentPatientList(patientHistoryRDD, PINN142Elements.NYHA))

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList,patientHistoryMostRecentBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
IPP-- Patients aged ≥18 y with a diagnosis of HF and with quantitative results of an evaluation of both level of activity
AND clinical symptoms documented in which patient symptoms have improved
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], patientHistoryMostRecentBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] =  {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeBelow(visit,m,true ,18)
      &&
      isVisitTypeIn(visit,m,PINN142Elements.ACC_Encounter_Code_Set)
      &&
      isDiagnosedDuringEncounter(visit,m,PINN142Elements.Heart_Failure)
      &&
      wasEncounterStartsBeforeEncounterInXMonths(visit,m,PINN142Elements.ACC_Encounter_Code_Set,12,patientHistoryBroadcastList)
      &&
        wasAssessmentPerformedBeforeEncounterInXMonths(visit, m,PINN142_1Elements.NYHA, 12,patientHistoryMostRecentBroadcastList)
      &&
      isAssessmentPerformedDuringEncounter(visit, m,PINN142Elements.NYHA)


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator -- Patients who remained consistent with treatment goals since last assessment OR patient symptoms have demonstrated
clinically important deterioration since last assessment with a documented plan of care.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      wasAssessmentPerformedAfterAssessmentWithResult(visit,m,PINN142Elements.NYHA_Score_Final,0,"ge",PINN142Elements.NYHA,patientHistoryBroadcastList)
      ||
      (
        isInterventionPerformedDuringEncounter(visit, m,PINN142Elements.Plan_Of_Care_HF)
         &&
        wasAssessmentPerformedAfterAssessmentWithResult(visit,m,PINN142Elements.NYHA_Score_Final,0,"lt",PINN142Elements.NYHA,patientHistoryBroadcastList)
      )
    )
  }

}
