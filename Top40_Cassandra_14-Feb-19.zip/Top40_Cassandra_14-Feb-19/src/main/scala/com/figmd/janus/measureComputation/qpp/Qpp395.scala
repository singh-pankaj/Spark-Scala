package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 395
* Measure Title              :- Lung Cancer Reporting (Biopsy/Cytology Specimens)
* Measure Description        :- Pathology reports based on biopsy and/or cytology specimens with a diagnosis of primary
                                non-small cell lung cancer classified into specific histologic type or classified as
                                NSCLC-NOS with an explanation included in the pathology report
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp395 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp395"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Filter Exclusion
      val exclusionRDD = getExclusion(ippRDD)
      exclusionRDD.cache()

      val intermediateNumerator = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateNumerator.cache()

      // Filter Met
      val metRDD = getMet(intermediateNumerator)
      metRDD.cache()

      // Filter Intermediate
      val intermediateException = getSubtractRDD(intermediateNumerator, metRDD)
      intermediateException.cache()

      // Filter Exclusion
      val exceptionRDD = getExceptionRdd(intermediateException)
      exceptionRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, ippRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

    }

  }

  /*--------------------------------------------------------------------------------------------------------------------
    Biopsy and cytology specimen reports with a diagnosis of primary non-small cell lung cancer
   -------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isDiagnosedOnEncounter(visit, m, QPP395Elements.Lung_Cancer)
        && isLaboratoryTestOrderDuringEncounter(visit, m, QPP395Elements.Biopsy_Or_Cytology)

    )

  }

  /*--------------------------------------------------------------------------------------------------------------------
 Specimen site other than anatomic location of lung or is not classified as primary non-small cell lung cancer
-------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isLaboratoryTestOrderDuringEncounter(visit, m, QPP395Elements.Non_Lung_Site_Or_Non_Nsclc)
        || isLaboratoryTestOrderDuringEncounter(visit, m, QPP395Elements.Nsclc_Nos_Or_Non_Lung_Site)

    )

  }


  /*--------------------------------------------------------------------------------------------------------------------
  Biopsy and cytology specimen reports with a diagnosis of primary non-small cell lung cancer classified into specific
  histologic type (squamous cell carcinoma, adenocarcinoma) OR classified as NSCLC-NOS with an explanation included in
  the pathology report
   -------------------------------------------------------------------------------------------------------------------*/


  def getMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        isLaboratoryTestOrderDuringEncounter(visit, m, QPP395Elements.Appropriate_Documentation__Lung_Cancer_)
          ||
          (
            isDiagnosedOnEncounter(visit, m, QPP395Elements.Squamous_Cell_Carcinoma)
              || isDiagnosedOnEncounter(visit, m, QPP395Elements.Adenocarcinoma)
              || isLaboratoryTestOrderDuringEncounter(visit, m, QPP395Elements.Nsclc_Nos)
            )
          || isLaboratoryTestOrderDuringEncounter(visit, m, QPP395Elements.Lung_Cancer_Documentation)
        )
        && !isAssessmentPerformedDuringEncounter(visit, m, QPP395Elements.Appropriate_Documentation__Lung_Cancer__Not_Met)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
   Documentation of medical reason(s) for not including the histological type OR NSCLC-NOS classification with an
   explanation (e.g., biopsy taken for other purposes in a patient with a history of primary non-small cell lung cancer
    or other documented medical reasons)
    -------------------------------------------------------------------------------------------------------------------*/


  def getExceptionRdd(intermediateException: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      isAssessmentPerformedDuringEncounter(visit, m, QPP395Elements.Appropriate_Doc__Lung_Cancer__Medical_Reason)
        || isDiagnosedOnEncounter(visit, m, QPP395Elements.History_Of_Primary_Nsclc)
        || isDiagnosedOnEncounter(visit, m, QPP395Elements.Other_Lung_Conditions)
    )
  }

}






