package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty,CalenderUnit,ECQM90V8Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Ecqm90v8
* Measure Title               :- Functional Status Assessments for Congestive Heart Failure
* Measure Description         :- Percentage of patients 18 years of age and older with congestive heart failure who completed
                                 initial and follow-up patient-reported functional status assessments
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- VRUSHALI.GHOLAP
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.8
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.8
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm90V8 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm90V8"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,ECQM90V8Elements.Heart_Failure
      ,ECQM90V8Elements.Office_Visit
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val firstEncounterRDD = firstEncouterPerformedInXDaysAfterStart(MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate),ECQM90V8Elements.Office_Visit,185,patientHistoryRDD)
    val firstEncounterBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]], firstEncounterBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList,firstEncounterBroadcastList)
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      firstEncounterBroadcastList.destroy()

    }

  }

/*-----------------------------------------------------------------------------------------------------------------------
  Patients 18 years of age and older who had two outpatient encounters during the measurement year and a diagnosis of
  congestive heart failure
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],firstEncounterBroadcastList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
         isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
      && wasDiagnosedInHistory(visit,m,ECQM90V8Elements.Heart_Failure,patientHistoryBroadcastList)
      && wasEncounterPerformedAfterFirstEncounterPerformedInRange(visit,m,ECQM90V8Elements.Office_Visit,ECQM90V8Elements.Office_Visit,30,180,patientHistoryBroadcastList, firstEncounterBroadcastList)

    )
  }

/*-----------------------------------------------------------------------------------------------------------------------
  Exclude patients with severe cognitive impairment or patients with a diagnosis of cancer.
  Exclude patients who were in hospice care during the measurement year.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        isEncounterPerformedWithDischargeStatus(visit,m,ECQM90V8Elements.Encounter_Inpatient,ECQM90V8Elements.Discharged_To_Home_For_Hospice_Care,patientHistoryBroadcastList)
    ||  isEncounterPerformedWithDischargeStatus(visit,m,ECQM90V8Elements.Encounter_Inpatient,ECQM90V8Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,patientHistoryBroadcastList)
    ||  wasInterventionPerformedInHistory(visit,m,ECQM90V8Elements.Hospice_Care_Ambulatory,patientHistoryBroadcastList)
    ||  wasDiagnosedInHistory(visit,m,ECQM90V8Elements.Severe_Dementia,patientHistoryBroadcastList)
    )
  }

/*-----------------------------------------------------------------------------------------------------------------------
  Patien ts with patient-reported functional status assessment results (eg, VR-12; VR-36; MLHF-Q; KCCQ; PROMIS-10 Global Health,
  PROMIS-29) present in the EHR two weeks before or during the initial FSA encounter and results for the follow-up FSA at least
  30 days but no more than 180 days after the initial functional status assessment
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],firstEncounterBroadcastList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
       wasAssessmentPerformedOrConcurrentWithFirstEncounterInXperiod(visit,m,CalenderUnit.WEEK,2,ECQM90V8Elements.Office_Visit,patientHistoryBroadcastList,firstEncounterBroadcastList,Seq(ECQM90V8Elements.Congestive_Heart_Failure_Functional_Assessment ))
// need to add logic for Assessment after initial assessment
    )
  }


}