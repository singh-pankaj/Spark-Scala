package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP104Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp104
* Measure Title              :- Prostate Cancer: Combination Androgen Deprivation Therapy for High Risk or Very High Risk Prostate Cancer
* Measure Description        :- Percentage of patients, regardless of age, with a diagnosis of prostate cancer at high or
*                               very high risk of recurrence receiving external beam radiotherapy to the prostate who were prescribed androgen deprivation therapy in combination with
*                               external beam radiotherapy to the prostate
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp104 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp104"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {



    //Backtracking List
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,QPP104Elements.Prostate_Cancer )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect.toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
                              isMale(visit,m)
                          &&  isDiagnosis(visit,m,QPP104Elements.Prostate_Cancer,patientHistoryBroadcastList)
                          &&  (
                                  (
                                          wasAssessmentPerformedBeforeXProcedure(visit,m,AdminElements.Encounter_Date,QPP104Elements.Risk_Stratification_Of_Prostate_Cancer_High_Or_Very_High,patientHistoryBroadcastList)
                                      ||  wasAssessmentPerformedBeforeXProcedure(visit,m,AdminElements.Encounter_Date,QPP104Elements.Risk_Stratification_Of_Prostate_Cancer_Md_Notes,patientHistoryBroadcastList)
                                  )
                                ||
                                  (
                                        (
                                              wasSummationOfLaboratoryTestBeforeDiagnosisWithResultXValue(visit,m,QPP104Elements.Documentation_Of_Primary_Gleason_Score,QPP104Elements.Documentation_Of_Secondary_Gleason_Score,AdminElements.Encounter_Date,8,"ge",patientHistoryBroadcastList)
                                          &&  wasSummationOfLaboratoryTestBeforeDiagnosisWithResultXValue(visit,m,QPP104Elements.Documentation_Of_Primary_Gleason_Score,QPP104Elements.Documentation_Of_Secondary_Gleason_Score,AdminElements.Encounter_Date,10,"le",patientHistoryBroadcastList)
                                        )
                                      ||
                                        (
                                              wasLaboratoryTestPerformedValueBeforeEncounter(visit,m,QPP104Elements.Gleason_Score_V,8,"ge",patientHistoryBroadcastList)
                                          &&  wasLaboratoryTestPerformedValueBeforeEncounter(visit,m,QPP104Elements.Gleason_Score_V,10,"le",patientHistoryBroadcastList)
                                        )
                                      ||
                                        (
                                              wasSummationOfLaboratoryTestBeforeDiagnosisWithResultXValue(visit,m,QPP104Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,QPP104Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AdminElements.Encounter_Date,8,"ge",patientHistoryBroadcastList)
                                          &&  wasSummationOfLaboratoryTestBeforeDiagnosisWithResultXValue(visit,m,QPP104Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,QPP104Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AdminElements.Encounter_Date,10,"le",patientHistoryBroadcastList)
                                        )
                                      ||
                                        (
                                              wasLaboratoryTestPerformedValueBeforeEncounter(visit,m,QPP104Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,8,"ge",patientHistoryBroadcastList)
                                          &&  wasLaboratoryTestPerformedValueBeforeEncounter(visit,m,QPP104Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,10,"le",patientHistoryBroadcastList)
                                        )
                                      ||    wasLaboratoryTestPerformedBeforeEncounter(visit,m,QPP104Elements.Gleason_Score_High_Risk,patientHistoryBroadcastList)
                                      ||
                                        (
                                              wasLaboratoryTestPerformedValueBeforeEncounter(visit,m,QPP104Elements.Documentation_Of_Psa_In_Md_Notes,20,"gt",patientHistoryBroadcastList)
                                          ||  wasLaboratoryTestPerformedValueBeforeEncounter(visit,m,QPP104Elements.Prostate_Specific_Antigen,20,"gt",patientHistoryBroadcastList)
                                        )
                                      ||
                                        (
                                              wasDiagnosisPerformedBeforeProcedure(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP104Elements.Clinical_T_Staging)
                                          ||  wasDiagnosisPerformedBeforeProcedure(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP104Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes)
                                          ||  wasDiagnosisPerformedBeforeProcedure(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP104Elements.Clinical_Stage_T3b_To_T4)
                                          ||  wasDiagnosisPerformedBeforeProcedure(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP104Elements.T_Stage_T3a)
                                          ||  wasDiagnosisPerformedBeforeProcedure(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP104Elements.Documentation_Of_Clinical_T_Staging)

                                        )
                                      ||
                                        (
                                              wasLaboratoryTestPerformedValueBeforeEncounter(visit,m,QPP104Elements.Total_Biopsy_Cores,4,"gt",patientHistoryBroadcastList)
                                          &&  (
                                                    wasLaboratoryTestPerformedValueBeforeEncounter(visit,m,QPP104Elements.Gleason_Score_V,8,"ge",patientHistoryBroadcastList)
                                                &&  wasLaboratoryTestPerformedValueBeforeEncounter(visit,m,QPP104Elements.Gleason_Score_V,10,"le",patientHistoryBroadcastList)

                                              )

                                        )
                                      ||
                                        (
                                                wasLaboratoryTestPerformedValueBeforeEncounter(visit,m,QPP104Elements.Total_Biopsy_Cores_Md_Notes,4,"gt",patientHistoryBroadcastList)
                                            && (
                                                    wasLaboratoryTestPerformedValueBeforeEncounter(visit,m,QPP104Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,8,"ge",patientHistoryBroadcastList)
                                                &&  wasLaboratoryTestPerformedValueBeforeEncounter(visit,m,QPP104Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,10,"le",patientHistoryBroadcastList)

                                               )

                                        )
                                  )

                              )
                          &&  (
                                  (
                                        wasProcedureAfterDiagnosis(visit,m,QPP104Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,QPP104Elements.Prostate_Cancer)
                                    ||  wasProcedureAfterDiagnosis(visit,m,QPP104Elements.Documentation_Of_Ebrt_In_Md_Notes,patientHistoryBroadcastList,QPP104Elements.Prostate_Cancer)
                                    ||  wasProcedureAfterDiagnosis(visit,m,QPP104Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,QPP104Elements.Prostate_Cancer)
                                    ||  wasProcedureAfterDiagnosis(visit,m,QPP104Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,QPP104Elements.Prostate_Cancer)
                                  )
                                &&
                                  (
                                        isProcedurePerformed(visit,m,QPP104Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList)
                                    ||  isProcedurePerformed(visit,m,QPP104Elements.Documentation_Of_Ebrt_In_Md_Notes,patientHistoryBroadcastList)
                                    ||  isProcedurePerformed(visit,m,QPP104Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList)
                                    ||  isProcedurePerformed(visit,m,QPP104Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList)
                                  )
                              )
                          &&
                             !(
                                     wasAssessmentPerformedAfterDiagnosis(visit,m,QPP104Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,QPP104Elements.Prostate_Cancer)
                                 ||  wasAssessmentPerformedAfterDiagnosis(visit,m,QPP104Elements.Documentation_Of_Ebrt_In_Md_Notes,patientHistoryBroadcastList,QPP104Elements.Prostate_Cancer)
                                 ||  wasAssessmentPerformedAfterDiagnosis(visit,m,QPP104Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,QPP104Elements.Prostate_Cancer)
                                 ||  wasAssessmentPerformedAfterDiagnosis(visit,m,QPP104Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,QPP104Elements.Prostate_Cancer)

                              )

    )
  }

  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    denominatorRDD.filter(visit =>
                            wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,QPP104Elements.Metastatic_Cancer)
    )
  }

  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateForMet.filter(visit =>
                              (
                                    (
                                          wasMedicationAdministeredBeforeOrEqualEncounter(visit,m,QPP104Elements.Adjuvant_Hormonal_Therapy,patientHistoryBroadcastList)
                                      ||  wasMedicationAdministeredBeforeOrEqualEncounter(visit,m,QPP104Elements.Adjuvant_Hormonal_Therapy_Md_Notes,patientHistoryBroadcastList)
                                    )
                                ||  isAssessmentPerformed(visit,m,QPP104Elements.Adjuvant_Hormonal_Therapy,patientHistoryBroadcastList)
                              )
                           && !wasAssessmentPerformedBeforeOrEqualEncounter(visit,m,QPP104Elements.Androgen_Deprivation_Therapy_Reason_Not_Specified,patientHistoryBroadcastList)
    )
  }


  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermediateForException.filter(visit =>
                            isMedicationAdministeredOnEncounter(visit,m,QPP104Elements.Androgen_Deprivation_Therapy_Medical_Reason)
                        ||  isMedicationAdministeredOnEncounter(visit,m,QPP104Elements.Androgen_Deprivation_Therapy_Patient_Reason)
                        ||
                            (
                                  wasProcedurePerformedAfterEncounter(visit,m,AdminElements.Encounter_Date,QPP104Elements.Salvage_Therapy,patientHistoryBroadcastList)
                              ||  wasProcedurePerformedAfterEncounter(visit,m,AdminElements.Encounter_Date,QPP104Elements.Salvage_Thearpy_Md_Notes,patientHistoryBroadcastList)


                            )
                        ||
                           (
                             (
                                  isProcedurePerformed(visit,m,QPP104Elements.Radical_Prostatectomy,patientHistoryBroadcastList)
                               || isProcedurePerformed(visit,m,QPP104Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList)

                             )
                           &&
                             (
                                  wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP104Elements.Radical_Prostatectomy)
                               || wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP104Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes)

                             )

                           )

    )
  }



}









