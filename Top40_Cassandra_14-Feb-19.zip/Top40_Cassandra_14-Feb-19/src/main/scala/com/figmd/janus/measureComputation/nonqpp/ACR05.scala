package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty,ACR05Elements,TimeOperator,CalenderUnit,CompareOperator}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- ACR05
* Measure Title               :- Glucocorticosteroids and Other Secondary Causes
* Measure Description         :- Percentage of patients aged 18 years and older with one of the following conditions or therapies: receiving oral glucocorticosteroid therapy
                                 for greater than 3 months OR hypogonadism OR fracture history OR transplant history OR obesity surgery OR malabsorption disease OR receiving
                                 aromatase therapy for breast cancer who had a central DXA ordered or performed  or pharmacologic therapy prescribed within 12 months
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KAJAL_JADHAO_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object ACR05 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "ACR05"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      ACR05Elements.Hypogonadism
      , ACR05Elements.Oral_Glucocorticosteroid_Therapy
      , ACR05Elements.Fracture_History
      , ACR05Elements.Transplant_History
      , ACR05Elements.Obesity_Surgery
      , ACR05Elements.Malabsorption_Disease
      , ACR05Elements.Aromatase_Therapy_For_Breast_Cancer
      , ACR05Elements.Aromatase_Therapy_For_Breast_Cancer_Icd
      , ACR05Elements.Central_Dxa
      , ACR05Elements.Pharmacologic_Therapy
      , ACR05Elements.Pharmacologic_Therapy__Reason_Not_Specified
      , ACR05Elements.Medical_Reason_Central_Dxa_Measurement_Ordered_Or_Performed
      , ACR05Elements.Patient_Reason_Central_Dxa_Measurement_Ordered_Or_Performed
      , ACR05Elements.System_Reason_Central_Dxa_Measurement_Ordered_Or_Performed
      , ACR05Elements.Medical_Reason_Prescription_Of_Pharmacologic_Therapy
      , ACR05Elements.Patient_Reason_Prescription_Of_Pharmacologic_Therapy)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(sparkSession,initialRDD,patientHistoryBroadcastList,patientHistoryRDD:RDD[CassandraRow])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Percentage of patients received oral glucocorticosteroid therapy OR hypogonadism OR fracture history OR transplant history OR obesity surgery
OR malabsorption disease OR received aromatase therapy for breast cancer.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(sparkSession: SparkSession,initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryRDD:RDD[CassandraRow]):RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val MedicationList:List[(String,String)] = List((ACR05Elements.Oral_Glucocorticosteroid_Therapy,ACR05Elements.Oral_Glucocorticosteroid_Therapy_Stop_Date))

    val MedicationResult=cumulative(patientHistoryRDD, m,MedicationList,CalenderUnit.MONTH,CalenderUnit.MONTH,3,TimeOperator.EQUAL)

    val MedicationResultBroadcastList: Broadcast[List[(String,String,Double)]] = sparkSession.sparkContext.broadcast(MedicationResult)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && (
        getCommulativeResult(visit,m,ACR05Elements.Oral_Glucocorticosteroid_Therapy,3,CompareOperator.EQUAL,MedicationResultBroadcastList)
          || wasDiagnosedInHistory(visit,m,ACR05Elements.Hypogonadism,patientHistoryBroadcastList)
          || wasDiagnosedInHistory(visit,m,ACR05Elements.Fracture_History,patientHistoryBroadcastList)
          || wasDiagnosedInHistory(visit,m,ACR05Elements.Transplant_History,patientHistoryBroadcastList)
          || wasProcedurePerformedInHistory(visit,m,ACR05Elements.Obesity_Surgery,patientHistoryBroadcastList)
          || wasDiagnosedInHistory(visit,m,ACR05Elements.Malabsorption_Disease,patientHistoryBroadcastList)
          || wasMedicationAdministeredInHistory(visit,m,ACR05Elements.Aromatase_Therapy_For_Breast_Cancer,patientHistoryBroadcastList)
          || wasDiagnosedInHistory(visit,m,ACR05Elements.Aromatase_Therapy_For_Breast_Cancer_Icd,patientHistoryBroadcastList)
        )


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Central DXA ordered or performed OR pharmacologic therapy prescribed within 12 months.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      (
        isProcedureOrdered(visit,m,ACR05Elements.Central_Dxa,patientHistoryBroadcastList)
          || isProcedurePerformed(visit,m,ACR05Elements.Central_Dxa,patientHistoryBroadcastList)
          || isMedicationOrdered(visit,m,patientHistoryBroadcastList,ACR05Elements.Pharmacologic_Therapy )

        )

        &&
        ! isMedicationOrderedNotDone(visit,m,patientHistoryBroadcastList,ACR05Elements.Pharmacologic_Therapy__Reason_Not_Specified )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Documented medical, patient or system reason for not ordering or performing central DXA OR documented medical or patient reason for not prescribing pharmacologic therapy.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      (
        isProcedureOrderNotDone(visit,m,ACR05Elements.Medical_Reason_Central_Dxa_Measurement_Ordered_Or_Performed ,patientHistoryBroadcastList)
          || isProcedurePerformedNotDone(visit,m,ACR05Elements.Medical_Reason_Central_Dxa_Measurement_Ordered_Or_Performed ,patientHistoryBroadcastList)
          || isProcedureOrderNotDone(visit,m,ACR05Elements.Patient_Reason_Central_Dxa_Measurement_Ordered_Or_Performed ,patientHistoryBroadcastList)
          || isProcedurePerformedNotDone(visit,m,ACR05Elements.Patient_Reason_Central_Dxa_Measurement_Ordered_Or_Performed ,patientHistoryBroadcastList)
          || isProcedureOrderNotDone(visit,m,ACR05Elements.System_Reason_Central_Dxa_Measurement_Ordered_Or_Performed ,patientHistoryBroadcastList)
          || isProcedurePerformedNotDone(visit,m,ACR05Elements.System_Reason_Central_Dxa_Measurement_Ordered_Or_Performed ,patientHistoryBroadcastList)
          || isMedicationOrderedNotDone(visit,m,patientHistoryBroadcastList,ACR05Elements.Medical_Reason_Prescription_Of_Pharmacologic_Therapy )
          || isMedicationOrderedNotDone(visit,m,patientHistoryBroadcastList,ACR05Elements.Patient_Reason_Prescription_Of_Pharmacologic_Therapy )
        )

    )
  }
}