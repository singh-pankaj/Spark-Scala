package com.figmd.janus.measureComputation.nonqpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Axon 3
* Measure Title              :- Depression and Anxiety Screening for Patients with Epilepsy
* Measure Description        :- Percentage of patients with a diagnosis of epilepsy who were screened for depression and anxiety.
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
* Initial GIT Version/Tag(CRA):- 1.4
* Latest GIT Version/Tag(CRA) :- 1.9
----------------------------------------------------------------------------------------------------------------------------*/


object Axon3 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Axon3"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val getPatientHistoryList = getPatientHistory(sparkSession, initialRDD
      , AXON3Elements.Depression_Diagnosis
      , AXON3Elements.Anxiety_Disorders

    ).collect.toList

    val patientHistory: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistory)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      //Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD)
      metRDD.cache()

      val intermediate = getSubtractRDD(ippRDD, metRDD)
      intermediate.cache()

      // Filter Exclusion
      val exceptionRDD = getExceptionRdd(intermediate, patientHistory)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediate, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistory.destroy()


    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Initial Population : Patients age 12 and older diagnosed with epilepsy
   -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit,m,true,12)
        && isVisitTypeIn(visit, m
        , AXON3Elements.Office_Visit
        , AXON3Elements.Outpatient_Consultation
      )
        && isDiagnosedDuringEncounter(visit, m, AXON3Elements.Epilepsy)
    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
  Numerator : Patients with epilepsy who were screened for both depression* and anxiety^ at every office visit.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
     (
      (
      (
        isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.PHQ_2)
        &&
        isAssessmentPerformedResultInRange(visit, m, AXON3Elements.PHQ_2_Score, 0, 6)
      )
       ||
        (
          isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.NDDI_E_Tool)
          &&
          isAssessmentPerformedResultInRange(visit, m, AXON3Elements.NDDI_E_Score, 6, 24)
        )
        ||
        (
          isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.PHQ_9_Tool)
          &&
          isAssessmentPerformedResultInRange(visit, m, AXON3Elements.PHQ_9_Score, 0, 27)
        )
        ||
        (
          isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.PHQ_A_Tool)
          &&
          isAssessmentPerformedResultInRange(visit, m, AXON3Elements.PHQ_A_Score, 0, 27)
        )
        ||
        (
          isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.BDI_Tool)
          &&
          isAssessmentPerformedResultInRange(visit, m, AXON3Elements.BDI_Score, 0, 63)
        )
        ||
        (
          isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.BDI_II_Tool)
          &&
          isAssessmentPerformedResultInRange(visit, m, AXON3Elements.BDI_II_Score, 0, 63)
        )
        ||
        (
          isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.ET4_Tool)
          &&
          isAssessmentPerformedResultInRange(visit, m, AXON3Elements.ET4_Score, 0, 10)
          &&
          isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.ET7_Tool)
          &&
          isAssessmentPerformedResultInRange(visit, m, AXON3Elements.ET7_Score, 0, 10)
        )
       ||
        (
          isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.SDQ_Tool)
          &&
          isAssessmentPerformedResultInRange(visit, m, AXON3Elements.SDQ_Score, 0, 40)
        )
       )
       &&
       (
        (
         isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.ET4_Tool)
         &&
         isAssessmentPerformedResultInRange(visit, m, AXON3Elements.ET4_Score, 0, 10)
         &&
         isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.ET7_Tool)
         &&
         isAssessmentPerformedResultInRange(visit, m, AXON3Elements.ET7_Score, 0, 10)
         )
        ||
         (
         isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.SDQ_Tool)
         &&
         isAssessmentPerformedResultInRange(visit, m, AXON3Elements.SDQ_Score, 0, 40)
         )
         ||
         (
          isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.GAD_2_Tool)
          &&
          isAssessmentPerformedResultInRange(visit, m, AXON3Elements.GAD_2_Score, 0, 6)
         )
         ||
         (
          isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.GAD_7_Tool)
          &&
          isAssessmentPerformedResultInRange(visit, m, AXON3Elements.GAD_7_Score, 0, 21)
         )
         ||
         (
           isAssessmentPerformedDuringEncounter(visit, m, AXON3Elements.STAI_Tool)
           &&
           isAssessmentPerformedResultInRange(visit, m, AXON3Elements.STAI_Score, 20, 80)
         )
       )
    )
        ||
        isAssessmentPerformedOnEncounter(visit, m, AXON3Elements.Depression_And_Anxiety_Screening)
    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
  Exception :
  1.Patients who are unable or decline to complete epilepsy specific screening tool.
  2.Patient has a diagnosis of depression or anxiety on active problem list.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getExceptionRdd(intermediateException: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, AXON3Elements.Patient_Declines_for_Anxiety_And_Depression_Screening)
        ||
        (
          wasDiagnosisInHistory(visit, m, AXON3Elements.Depression_Diagnosis, patientHistory)
          ||
          wasDiagnosisInHistory(visit, m, AXON3Elements.Anxiety_Disorders, patientHistory)
        )
    )
  }

}






