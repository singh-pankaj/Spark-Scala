package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.apache.spark.broadcast.Broadcast

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 128
* Measure Title              :-Anti-depressant Medication Management
* Measure Description        :- Percentage of patients 18 years of age and older who were treated with antidepressant medication, had a diagnosis of major depression, and who remained on an antidepressant medication treatment. Two rates are reported.
                                a. Percentage of patients who remained on an antidepressant medication for at least 84 days (12 weeks).
                                b. Percentage of patients who remained on an antidepressant medication for at least 180 days (6 months).
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 2
* Measure Stratification     :- 1
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm128V7_2 extends MeasureUtilityUpdate with MeasureUpdate   {

  val MEASURE_NAME = "Ecqm128v7_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patient_history_list = getPatientHistory(sparkSession,initialRDD,
      ECQM128V7Elements.Major_Depression,
      ECQM128V7Elements.Antidepressant_Medication,
      ECQM128V7Elements.Discharged_To_Home_For_Hospice_Care,
      ECQM128V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
      ECQM128V7Elements.Hospice_Care_Ambulatory

    ).collect().toList



    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)



    val patineHistoryRDD=getPatientHistory(sparkSession,initialRDD,
      ECQM128V7Elements.Major_Depression,
      ECQM128V7Elements.Antidepressant_Medication,
      ECQM128V7Elements.Discharged_To_Home_For_Hospice_Care,
      ECQM128V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
      ECQM128V7Elements.Hospice_Care_Ambulatory
    )
    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val eligibleRDD = ippRDD

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRDD(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      val metRDD = getMet(intermediateA, sparkSession)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not Mate
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, eligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryBroadcastList.destroy()
    }
  }

  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,  globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&  (
        wasDiagnosedBeforeEncounterWithinXDays(visit, m,ECQM128V7Elements.Antidepressant_Medication_Date,ECQM128V7Elements.Major_Depression,60,patientHistoryBroadcastList)
          || wasDiagnosedAfterEncounterWithInXDays(visit, m, ECQM128V7Elements.Antidepressant_Medication,60,patientHistoryBroadcastList,ECQM128V7Elements.Major_Depression)
        )
        &&  (
        wasMedicationDispensedBeforeOrConcurrentStartWithInDays(visit, m, ECQM128V7Elements.Antidepressant_Medication,270,CalenderUnit.DAY,patientHistoryBroadcastList)
          || wasMedicationDispensedStartsAfterStartInXDays(visit, m, ECQM128V7Elements.Antidepressant_Medication,90,patientHistoryBroadcastList)

        )
        &&  isVisitTypeIn(visit,m,ECQM128V7Elements.Office_Visit,
        ECQM128V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
        ECQM128V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
        ECQM128V7Elements.Home_Healthcare_Services,
        ECQM128V7Elements.Annual_Wellness_Visit,
        ECQM128V7Elements.Psych_Visit___Diagnostic_Evaluation,
        ECQM128V7Elements.Psych_Visit___Psychotherapy,
        ECQM128V7Elements.Telephone_Evaluation,
        ECQM128V7Elements.Telephone_Management)
    )

  }

  def getExclusionRDD(ippRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>

      isEncounterPerformedWithDischargeStatus(visit,m,ECQM128V7Elements.Encounter_Inpatient,ECQM128V7Elements.Discharged_To_Home_For_Hospice_Care,patientHistoryBroadcastList)
        ||  isEncounterPerformedWithDischargeStatus(visit,m,ECQM128V7Elements.Encounter_Inpatient,ECQM128V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,patientHistoryBroadcastList)
        ||  wasInterventionPerformedInHistory(visit,m,ECQM128V7Elements.Hospice_Care_Ambulatory,patientHistoryBroadcastList)
        ||  wasMedicationActiveStartsBeforeInXDays(visit,m,ECQM128V7Elements.Antidepressant_Medication,105,TimeOperator.BEFOREorEQUAL,patientHistoryBroadcastList,Seq(ECQM128V7Elements.Antidepressant_Medication))


    )
  }
  def getMet(ippRDD: RDD[CassandraRow],sparkSession: SparkSession): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    val cumilative_list1=cumulative(ippRDD,m, List((ECQM128V7Elements.Antidepressant_Medication_Date,ECQM128V7Elements.Anti_Depressant_Medication_Stop_Date)),CalenderUnit.DAY,CalenderUnit.MONTH,9,"BEFORE")
    val patientcumilativeBroadcastList: Broadcast[List[(String,String,Double)]] = sparkSession.sparkContext.broadcast(cumilative_list1)
    ippRDD.filter(visit => getCommulativeResult(visit,m,ECQM128V7Elements.Antidepressant_Medication,180,CompareOperator.GREATER_EQUAL,patientcumilativeBroadcastList)

    )
  }


}

