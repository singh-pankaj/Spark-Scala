package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,CAP14Elements,CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAP14
* Measure Title               :- Appropriate Formalin Fixation Time (6 – 72 hours) of Breast Cancer Specimens to Ensure Accurate Ancillary Testing Results
* Measure Description         :- Percentage of breast cancer specimens (cytology, biopsy and/or resection) in which the total fixation time in formalin is between 6-72 hours.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMIT.SINGH
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object CAP14 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "CAP14"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
        CAP14Elements.Breast_Cancer_Specimen,
        CAP14Elements.Specimen_Site_Other_Than_Breast,
        CAP14Elements.Specimen_Not_Requiring_Formalin_Fixation_Reason

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  All breast cancer specimens (cytology, biopsy, and/or resection).
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
         isLaboratoryTestPerformedOnEncounter(visit,m,CAP14Elements.Breast_Cancer_Specimen)
      && isDiagnosedDuringEncounter(visit,m,CAP14Elements.Breast_Cancer)


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Specimen is from site other than the breast (ie., metastatic)
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
           isInterventionPerformedDuringEncounter(visit,m,CAP14Elements.Specimen_Site_Other_Than_Breast)


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Breast cancer specimens (cytology, biopsy and/or resection) in which the total fixation time in formalin is between 6-72 hours.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
         isProcedurePerformedWithResultDuringEncounter(visit,m,CAP14Elements.Total_Formalin_Fixation_Time, 6,CompareOperator.EQUAL)
      && isProcedurePerformedWithResultDuringEncounter(visit,m,CAP14Elements.Total_Formalin_Fixation_Time, 72,CompareOperator.EQUAL)


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Documentation of reason(s) for specimen not needing formalin fixation (eg., re-excision without residual tumor, non-carcinomas)
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
              isInterventionPerformedDuringEncounter(visit,m,CAP14Elements.Specimen_Not_Requiring_Formalin_Fixation_Reason)


    )
  }
}

