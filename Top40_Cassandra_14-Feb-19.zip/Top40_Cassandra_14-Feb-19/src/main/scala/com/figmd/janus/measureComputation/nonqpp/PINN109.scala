package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, PINN109Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PINN109
* Measure Title               :- Coronary Artery Disease: Treatment of Blood Cholesterol to Reduce Atherosclerotic Cardiovascular Risk
* Measure Description         :- Percentage of Patients 18-75 with CAD who were offered moderate-to-high intensity statin
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KAJAL_JADHAO_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object PINN109 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "PINN109"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,PINN109Elements.Acc_Encounter_Code_Set
      ,PINN109Elements.Coronary_Artery_Disease
      ,PINN109Elements.Cardiac_Surgery
      ,PINN109Elements.Coronary_Artery_Bypass_Graft__Cabg_
      ,PINN109Elements.Percutaneous_Coronary_Interventions

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 18, CalenderUnit.YEAR)
        &&  isAgeBelowBeforeStart(visit, m, false, 76, CalenderUnit.YEAR)
        &&  isEncounterPerformed(visit,m,PINN109Elements.Acc_Encounter_Code_Set,patientHistoryBroadcastList)
        &&( wasDiagnosedBeforeOrEqualEncounter(visit,m,PINN109Elements.Coronary_Artery_Disease,patientHistoryBroadcastList)
        &&  wasProcedurePerformedBeforeOrEqualEncounter(visit,m,PINN109Elements.Cardiac_Surgery,patientHistoryBroadcastList)
        ||  wasProcedurePerformedBeforeOrEqualEncounter(visit,m,PINN109Elements.Coronary_Artery_Bypass_Graft__Cabg_,patientHistoryBroadcastList)
        ||  wasInterventionPerformedBeforeEncounter(visit,m,PINN109Elements.Percutaneous_Coronary_Interventions,patientHistoryBroadcastList))
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      isMedicationActiveDuringEncounter(visit,m,PINN109Elements.High_Intensity_Statin)
        || isMedicationActiveDuringEncounter(visit,m,PINN109Elements.Moderate_Intensity_Statin)

        || isMedicationOrderedDuringEncounter(visit,m,PINN109Elements.High_Intensity_Statin)
        || isMedicationOrderedDuringEncounter(visit,m,PINN109Elements.Moderate_Intensity_Statin)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
No-Med Reason
No-Patient Reason
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>

      isAssessmentPerformedDuringEncounter(visit,m,PINN109Elements.Medical_Reason)
        || isAssessmentPerformedDuringEncounter(visit,m,PINN109Elements.Patient_Reason)


    )
  }
}