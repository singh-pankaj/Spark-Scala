package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{QPP12Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 12
* Measure Title              :- Primary Open-Angle Glaucoma (POAG): Optic Nerve Evaluation
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of primary open-angle glaucoma (POAG)
                                who have an optic nerve head evaluation during one or more office visits within 12 months.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp12 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP12"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patient_history_list = getPatientHistory(sparkSession, initialRDD
      , QPP12Elements.Primary_Open_Angle_Glaucoma
      , QPP12Elements.Optic_Nerve_Head_Evaluation
      , QPP12Elements.Cup_To_Disc_Ratio
      , QPP12Elements.Optic_Disc_Exam_For_Structural_Abnormalities
      , QPP12Elements.Optc_Nrvhdevalutn_Reason_Not_Specified
      , QPP12Elements.Medical_Reason_Not_Perform
      , QPP12Elements.Optc_Nrvhdevalutn_Medical_Reason
      , QPP12Elements.Medical_Reason).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
   All patients aged 18 years and older with a diagnosis of primary open-angle glaucoma
   -----------------------------------------------------------------------------------------*/

  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
            isPatientAdult(visit, m)
        &&  isVisitTypeIn(visit,m
            ,QPP12Elements.Ophthalmological_Services
            ,QPP12Elements.Care_Services_In_Long_Term_Residential_Facility
            ,QPP12Elements.Nursing_Facility_Visit
            ,QPP12Elements.Office_Visit
            ,QPP12Elements.Outpatient_Consultation
            ,QPP12Elements.Face_To_Face_Interaction)
        &&  wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP12Elements.Primary_Open_Angle_Glaucoma,patientHistoryBroadcastList)
        && !isTeleHealthModifier(visit,m
            ,QPP12Elements.Office_Visit_Telehealth_Modifier
            ,QPP12Elements.Nursing_Facility_Visit_Telehealth_Modifier
            ,QPP12Elements.Ophthalmological_Services_Telehealth_Modifier
            ,QPP12Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier_Date
            ,QPP12Elements.Outpatient_Consultation_Telehealth_Modifier)
        &&  isPOSEncounterNotPerformed(visit, m, QPP12Elements.Pos_02)
    )
  }

  /*------------------------------------------------------------------------------------------------
   Patients who have an optic nerve head evaluation during one or more office visits within 12 months
   ------------------------------------------------------------------------------------------------*/

  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        (
               isDiagnosticStudyPerformed(visit,m,QPP12Elements.Optic_Nerve_Head_Evaluation,patientHistoryBroadcastList)
          ||   (
                      isDiagnosticStudyPerformed(visit,m,QPP12Elements.Cup_To_Disc_Ratio,patientHistoryBroadcastList)
                 &&   isDiagnosticStudyPerformed(visit,m,QPP12Elements.Optic_Disc_Exam_For_Structural_Abnormalities,patientHistoryBroadcastList)
               )
        )
        &&  !isDiagnosticStudyPerformed(visit,m,QPP12Elements.Optc_Nrvhdevalutn_Reason_Not_Specified,patientHistoryBroadcastList)
    )

  }

  /*------------------------------------------------------------------------------------------------
    Documentation of medical reason(s) for not performing an optic nerve head evaluation
   ------------------------------------------------------------------------------------------------*/

  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow]  = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateForException.filter(visit =>

             isDiagnosticStudyPerformed(visit,m,QPP12Elements.Medical_Reason_Not_Perform,patientHistoryBroadcastList)
        ||   isDiagnosticStudyPerformed(visit,m,QPP12Elements.Optc_Nrvhdevalutn_Medical_Reason,patientHistoryBroadcastList)
        ||   isActionNotPerformedWithReason(visit,m,QPP12Elements.Medical_Reason,patientHistoryBroadcastList)

    )

  }

}
