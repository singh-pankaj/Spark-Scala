package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP179Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 179
* Measure Title              :- Rheumatoid Arthritis (RA): Assessment and Classification of Disease Prognosis
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of rheumatoid arthritis (RA) who have an assessment and classification
                                of disease prognosis at least once within 12 months
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp179 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp179"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //Backtracking List
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP179Elements.Active_Rheumatoid_Arthritis,
      QPP179Elements.Prognosis,
      QPP179Elements.Good_Prognosis_1,
      QPP179Elements.Good_Prognosis_2,
      QPP179Elements.Poor_Prognosis_1,
      QPP179Elements.Poor_Prognosis_2,
      QPP179Elements.Disease_Assessment,
      QPP179Elements.Ra_Assessement_Poor_Prognosis,
      QPP179Elements.Ra_Assessement_Good_Prognosis,
      QPP179Elements.Disease_Prog_Reason_Not_Specified).collect.toList;

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateB = getSubtractRDD(ippRDD, metRDD)
      intermediateB.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : Patients aged 18 years and older with a diagnosis of RA
----------------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m, QPP179Elements.Office_Visit, QPP179Elements.Home_Healthcare_Services, QPP179Elements.Initial_Preventive_Physical_Examination)
        && isDiagnosedWithBeforeOrEqual(visit, m, AdminElements.Encounter_Date, patientHistoryBroadcastList,QPP179Elements.Active_Rheumatoid_Arthritis)
        && !isTeleHealthEncounterPerformed(visit, m, QPP179Elements.Initial_Preventive_Physical_Examination_Telehealth_Modifier,
        QPP179Elements.Office_Visit_Telehealth_Modifier, QPP179Elements.Home_Healthcare_Services_Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP179Elements.Pos_02)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Patients with at least one documented assessment and classification (good/poor) of disease prognosis utilizing
clinical markers of poor prognosis within 12 months
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ipp.filter(visit =>
      (    wasDiagnosticStudyPerformedBeforeEncounter(visit, m, AdminElements.Encounter_Date, QPP179Elements.Prognosis, 12, patientHistoryBroadcastList)
        || wasDiagnosticStudyPerformedBeforeEncounter(visit, m, AdminElements.Encounter_Date, QPP179Elements.Good_Prognosis_1, 12, patientHistoryBroadcastList)
        || wasDiagnosticStudyPerformedBeforeEncounter(visit, m, AdminElements.Encounter_Date, QPP179Elements.Good_Prognosis_2, 12, patientHistoryBroadcastList)
        || wasDiagnosticStudyPerformedWithMethodBeforeEncounter(visit, m, AdminElements.Encounter_Date, QPP179Elements.Poor_Prognosis_1, QPP179Elements.Clinical_Markers, 12, patientHistoryBroadcastList)
        || wasDiagnosticStudyPerformedWithMethodBeforeEncounter(visit, m, AdminElements.Encounter_Date, QPP179Elements.Poor_Prognosis_2, QPP179Elements.Clinical_Markers, 12, patientHistoryBroadcastList)
        || wasDiagnosticStudyPerformedBeforeEncounter(visit, m, AdminElements.Encounter_Date, QPP179Elements.Disease_Assessment, 12, patientHistoryBroadcastList)
        || wasDiagnosticStudyPerformedBeforeEncounter(visit, m, AdminElements.Encounter_Date, QPP179Elements.Ra_Assessement_Poor_Prognosis, 12, patientHistoryBroadcastList)
        || wasDiagnosticStudyPerformedBeforeEncounter(visit, m, AdminElements.Encounter_Date, QPP179Elements.Ra_Assessement_Good_Prognosis, 12, patientHistoryBroadcastList)
        )
        && !wasDiagnosticStudyPerformedBeforeEncounter(visit, m, AdminElements.Encounter_Date, QPP179Elements.Disease_Prog_Reason_Not_Specified, 12, patientHistoryBroadcastList)

    )
  }
}
