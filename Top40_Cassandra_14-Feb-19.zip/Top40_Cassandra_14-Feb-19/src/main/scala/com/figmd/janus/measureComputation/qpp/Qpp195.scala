package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP195Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 195
* Measure Title              :- Radiology: Stenosis Measurement in Carotid Imaging Reports
* Measure Description        :- Percentage of final reports for carotid imaging studies (neck magnetic resonance angiography [MRA], neck computed tomography angiography [CTA],
*                               neck duplex ultrasound, carotid angiogram) performed that include direct or indirect
                                reference to measurements of distal internal carotid diameter as the denominator for stenosis measurement
* Calculation Implementation :- Episode-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp195 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp195"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD, QPP195Elements.Carotid_Imaging_Report, QPP195Elements.Carotid_Imaging_Report_Grp, QPP195Elements.Report_Reason_Not_Specified_Grp).collect.toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exceptions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val intermediateRDD = ippRDD.subtract(metRDD)
      intermediateRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }

  //All final reports for carotid imaging studies (neck MR angiography [MRA], neck CT angiography [CTA], neck duplex ultrasound, carotid angiogram) performed.
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isProcedurePerformedDuringEncounter(visit, m, QPP195Elements.Carotid_Imaging_Studies))

  }


  //Final reports for carotid imaging studies that include direct or indirect reference to measurements of distal internal carotid diameter as the denominator for stenosis measurement.
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        wasInterventionDoneAfterProcedure(visit, m, QPP195Elements.Carotid_Imaging_Studies_Date, patientHistoryBroadcastList, QPP195Elements.Carotid_Imaging_Report)
          || wasAssessmentDoneAfterProcedure(visit, m, QPP195Elements.Carotid_Imaging_Studies_Date, patientHistoryBroadcastList, QPP195Elements.Carotid_Imaging_Report_Grp)
        ) && !wasAssessmentNotDoneAfterProcedureWithReasonBeforeEnd(visit, m, QPP195Elements.Carotid_Imaging_Studies, QPP195Elements.Report_Reason_Not_Specified_Grp, patientHistoryBroadcastList)

    )
  }


}

