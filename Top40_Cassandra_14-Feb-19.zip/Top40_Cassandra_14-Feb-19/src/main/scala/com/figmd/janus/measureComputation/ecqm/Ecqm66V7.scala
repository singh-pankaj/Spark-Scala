package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 66
* Measure Title              :- Functional Status Assessment for Total Knee Replacement
* Measure Description        :- Percentage of patients 18 years of age and older who received an elective primary total
                                knee arthroplasty (TKA) and completed a functional status assessment within 90 days prior
                                to the surgery and in the 270-365 days after the surgery.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm66V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm66V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , ECQM66V7Elements.Primary_Tka_Procedure
      , ECQM66V7Elements.Encounter_Inpatient
      , ECQM66V7Elements.Discharged_To_Home_For_Hospice_Care
      , ECQM66V7Elements.Encounter_Inpatient
      , ECQM66V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care
      , ECQM66V7Elements.Hospice_Care_Ambulatory
      , ECQM66V7Elements.Primary_Tka_Procedure
      , ECQM66V7Elements.Fracture___Lower_Body
      , ECQM66V7Elements.Severe_Dementia
      , ECQM66V7Elements.Total_Knee_Arthroplasty_Functional_Status_Assesment
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Eligable IPP
      //val eligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      /*exclusion RDD*/
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryBroadcastList.destroy()
    }
  }

  /*------------------------------------------------------------------------------
    Patients 19 years of age and older who had a primary total knee arthroplasty (TKA) in the year prior to the
    measurement period and who had an outpatient encounter during the measurement period
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)


    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 19, CalenderUnit.YEAR)
        && wasProcedurePerformedBeforeStartDateInXPeriod(visit, m, ECQM66V7Elements.Primary_Tka_Procedure, CalenderUnit.MONTH, 12, patientHistoryList)
        && isVisitTypeIn(visit, m
        , ECQM66V7Elements.Outpatient_Consultation
        , ECQM66V7Elements.Office_Visit
        , ECQM66V7Elements.Postoperative_Visit)
    )
  }

  /*------------------------------------------------------------------------------
  Patients with two or more fractures indicating trauma at the time of the total knee arthroplasty or patients with
  severe cognitive impairment that overlaps the measurement period.

  Exclude patients whose hospice care overlaps the measurement period.
  ------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      isEncounterPerformedWithDischargeStatus(visit, m, ECQM66V7Elements.Encounter_Inpatient, ECQM66V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        || isEncounterPerformedWithDischargeStatus(visit, m, ECQM66V7Elements.Encounter_Inpatient, ECQM66V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        || isInterventionOrder(visit, m, ECQM66V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        || isInterventionPerformedInHistory(visit, m, ECQM66V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        || getDiagnoisisCountBeforeEncounter(visit, m, ECQM66V7Elements.Primary_Tka_Procedure, ECQM66V7Elements.Fracture___Lower_Body, CalenderUnit.DAY, 1, 2, "ge", patientHistoryList)
        || wasDiagnosedInHistory(visit, m, ECQM66V7Elements.Severe_Dementia, patientHistoryList)
    )
  }

  /*------------------------------------------------------------------------------
   Patients with patient-reported functional status assessment results (i.e., VR-12, PROMIS-10 Global Health, KOOS, KOOS Jr.)
   in the 90 days prior to or on the day of the primary TKA procedure, and in the 270 - 365 days after the TKA procedure
   ------------------------------------ ------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      wasAssessmentPerformedBeforeWithinXPeriod(visit, m, ECQM66V7Elements.Primary_Tka_Procedure, ECQM66V7Elements.Total_Knee_Arthroplasty_Functional_Status_Assesment, CalenderUnit.DAY, 90, patientHistoryList)
        && wasAssessmentPerformedAfterProcedureInBetweenXPeriodes(visit, m, ECQM66V7Elements.Total_Knee_Arthroplasty_Functional_Status_Assesment, ECQM66V7Elements.Primary_Tka_Procedure, CalenderUnit.DAY, 270, CalenderUnit.DAY, 365, patientHistoryList)
    )
  }
}