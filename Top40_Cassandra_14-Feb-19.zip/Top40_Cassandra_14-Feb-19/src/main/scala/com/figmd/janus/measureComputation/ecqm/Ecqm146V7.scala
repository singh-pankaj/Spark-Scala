package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm146v7
* Measure Title              :- Appropriate Testing for Children with Pharyngitis
* Measure Description        :- Percentage of children 3-18 years of age who were diagnosed with pharyngitis, 
*				ordered an antibiotic and received a group A streptococcus (strep) test for the episode
* Calculation Implementation :- Episode-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Sumant Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm146V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm146V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession,initialRDD
      ,ECQM146V7Elements.Ambulatory_Ed_Visit
      ,ECQM146V7Elements.Antibiotic_Medications_For_Pharyngitis
      ,ECQM146V7Elements.Acute_Pharyngitis
      ,ECQM146V7Elements.Acute_Tonsillitis
      ,ECQM146V7Elements.Encounter_Inpatient
      ,ECQM146V7Elements.Discharged_To_Home_For_Hospice_Care
      ,ECQM146V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care
      ,ECQM146V7Elements.Hospice_Care_Ambulatory
      ,ECQM146V7Elements.Group_A_Streptococcus_Test
    )
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val ippRDD = getIpp(initialRDD,patientHistoryList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      //Denominator
      val denominatorRDD=ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      val intermediateRDD = ippRDD.subtract(exclusionRDD)
      intermediateRDD.cache()

      // Filter Met
      val metRDD = getMet(intermediateRDD, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryList.destroy()

    }
  }


  /*-----------------------------------------------------------------------------------------------------------------------
  Children 3-18 years of age who had an outpatient or emergency department (ED) visit with a diagnosis of pharyngitis
  during the measurement period and an antibiotic ordered on or three days after the visit
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
          isAgeBetween(visit, m, 3,CompareOperator.GREATER_EQUAL, 18,CompareOperator.LESS)
        &&
          isEncounterPerformed(visit, m, ECQM146V7Elements.Ambulatory_Ed_Visit, patientHistoryList)
        &&
          wasMedicationStartsAfterEncounterInXDays(visit, m, ECQM146V7Elements.Antibiotic_Medications_For_Pharyngitis, ECQM146V7Elements.Ambulatory_Ed_Visit, 3, patientHistoryList)
        &&
          (
              wasDiagnosedInHistory(visit, m, ECQM146V7Elements.Acute_Pharyngitis, patientHistoryList)
            ||
              wasDiagnosedInHistory(visit, m, ECQM146V7Elements.Acute_Tonsillitis, patientHistoryList)
          )
    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
  Children who are taking antibiotics in the 30 days prior to the diagnosis of pharyngitis.
  Exclude patients whose hospice care overlaps the measurement period.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
          isEncounterPerformedWithDischargeStatus(visit, m, ECQM146V7Elements.Encounter_Inpatient,
                ECQM146V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        ||
          isEncounterPerformedWithDischargeStatus(visit, m, ECQM146V7Elements.Encounter_Inpatient,
                ECQM146V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        ||
          isInterventionOrder(visit, m, ECQM146V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        ||
          isInterventionPerformed(visit, m, ECQM146V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        ||
          (
              (
                  wasMedicationActiveStartsBeforeInXDays(visit, m, ECQM146V7Elements.Acute_Pharyngitis,
                           30, CompareOperator.LESS_EQUAL, patientHistoryList,
                            Seq(ECQM146V7Elements.Antibiotic_Medications_For_Pharyngitis))
                ||
                  wasMedicationActiveStartsBeforeInXDays(visit, m, ECQM146V7Elements.Acute_Tonsillitis,
                           30, CompareOperator.LESS_EQUAL, patientHistoryList,
                            Seq(ECQM146V7Elements.Antibiotic_Medications_For_Pharyngitis))
              )
            &&
              (
                  wasMedicationActiveStartsBeforeInXDays(visit, m, ECQM146V7Elements.Acute_Pharyngitis,
                            1, CompareOperator.GREATER_EQUAL, patientHistoryList,
                            Seq(ECQM146V7Elements.Antibiotic_Medications_For_Pharyngitis))
                ||
                  wasMedicationActiveStartsBeforeInXDays(visit, m, ECQM146V7Elements.Acute_Tonsillitis,
                            1, CompareOperator.GREATER_EQUAL, patientHistoryList,
                            Seq(ECQM146V7Elements.Antibiotic_Medications_For_Pharyngitis))
              )
          )
        ||
          (
              (
                  wasMedicationActiveStartsBeforeInXDays(visit, m, ECQM146V7Elements.Acute_Pharyngitis,
                            30, CompareOperator.GREATER, patientHistoryList,
                            Seq(ECQM146V7Elements.Antibiotic_Medications_For_Pharyngitis))
                ||
                  wasMedicationActiveStartsBeforeInXDays(visit, m, ECQM146V7Elements.Acute_Tonsillitis,
                            30, CompareOperator.GREATER, patientHistoryList,
                            Seq(ECQM146V7Elements.Antibiotic_Medications_For_Pharyngitis))
              )

            && !
              (
                  wasMedicationActiveEndsBeforeInXDays(visit, m, ECQM146V7Elements.Acute_Pharyngitis,
                            30, CompareOperator.GREATER, patientHistoryList,
                            Seq(ECQM146V7Elements.Antibiotic_Medications_For_Pharyngitis))
                ||
                  wasMedicationActiveEndsBeforeInXDays(visit, m, ECQM146V7Elements.Acute_Tonsillitis,
                            30, CompareOperator.GREATER, patientHistoryList,
                            Seq(ECQM146V7Elements.Antibiotic_Medications_For_Pharyngitis))
              )

          )
    )
  }



  /*-----------------------------------------------------------------------------------------------------------------------
  Children 3-18 years of age who had an outpatient or emergency department (ED) visit with a diagnosis of pharyngitis
  during the measurement period and an antibiotic ordered on or three days after the visit
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateRDD.filter(visit =>
       (
           isLaboratoryTestPerformedBeforeWithinXDays(visit, m, ECQM146V7Elements.Ambulatory_Ed_Visit, ECQM146V7Elements.Group_A_Streptococcus_Test,3, patientHistoryList)
         ||
           isLaboratoryTestPerformedAfterWithinXDays(visit, m, ECQM146V7Elements.Ambulatory_Ed_Visit, ECQM146V7Elements.Group_A_Streptococcus_Test,3, patientHistoryList)
       )

    )
  }


}

