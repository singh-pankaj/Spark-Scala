package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty,CAPQI05Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAPQI05
* Measure Title               :- Quantitative Immunohistochemical (IHC) Evaluation of Human Epidermal Growth Factor Receptor 2 Testing (HER2) for Breast Cancer Patients
* Measure Description         :- This is a measure based on whether quantitative evaluation of Human Epidermal Growth Factor Receptor 2 Testing (HER2) by immunohistochemistry (IHC) uses the
                                 system recommended in the current ASCO/CAP Guidelines for Human Epidermal Growth Factor Receptor 2 Testing in breast cancer
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- Kajal Jadhao
* Initial GIT Version/Tag(CRA):-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object CAPQI05 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "CAPQI05"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      CAPQI05Elements.Breast_Cancer
      , CAPQI05Elements.Breast_Tumor_Evaluation_By_Her2_Ihc
      , CAPQI05Elements.Quantitative_Non_Her2_Ihc_Evaluation
      , CAPQI05Elements.Quantitative_Evaluation_Of_Non_Her2_Ihc
      , CAPQI05Elements.Quantitative_Non_Her2_Ihc_Evaluation_Kw
      , CAPQI05Elements.Quantitative_Evaluation_By_Her2_Ihc
      , CAPQI05Elements.Quantitative_Her2_By_Ihc_Evaluation
      , CAPQI05Elements.Quantitative_Eval_Reason_Not_Specified


    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
All breast cancer patients with quantitative breast tumor evaluation by HER2 IHC.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
             wasDiagnosisBeforeOrEqualLaboratoryTest(visit,m,CAPQI05Elements.Breast_Cancer,CAPQI05Elements.Breast_Tumor_Evaluation_By_Her2_Ihc,patientHistoryBroadcastList)
          && isLaboratoryTestPerformed(visit,m,CAPQI05Elements.Breast_Tumor_Evaluation_By_Her2_Ihc,patientHistoryBroadcastList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Quantitative non-HER2 IHC evaluation (eg, testing for estrogen or progesterone receptors, [ER/PR]) performed.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>

      isLaboratoryTestPerformedDuringLaboratoryTest(visit,m,CAPQI05Elements.Quantitative_Non_Her2_Ihc_Evaluation,CAPQI05Elements.Quantitative_Non_Her2_Ihc_Evaluation_Date,CAPQI05Elements.Breast_Tumor_Evaluation_By_Her2_Ihc,CAPQI05Elements.Breast_Tumor_Evaluation_By_Her2_Ihc_Date)
        ||  (wasLaboratoryTestPerformedAfterDiagnosis(visit,m,CAPQI05Elements.Breast_Cancer,CAPQI05Elements.Quantitative_Evaluation_Of_Non_Her2_Ihc,patientHistoryBroadcastList)
        && ! isLaboratoryTestPerformedDuringLaboratoryTest(visit,m,CAPQI05Elements.Quantitative_Non_Her2_Ihc_Evaluation_Kw,CAPQI05Elements.Quantitative_Non_Her2_Ihc_Evaluation_Kw_Date,CAPQI05Elements.Quantitative_Evaluation_Of_Non_Her2_Ihc,CAPQI05Elements.Quantitative_Evaluation_Of_Non_Her2_Ihc_Date))
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Breast cancer patients receiving quantitative breast tumor HER2 IHC evaluation using the ASCO/CAP recommended manual system or a computer-assisted system consistent with
the optimal algorithm for HER2 testing as described in the current ASCO/CAP guideline.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
           (isLaboratoryTestPerformedDuringLaboratoryTest(visit,m,CAPQI05Elements.Quantitative_Evaluation_By_Her2_Ihc,CAPQI05Elements.Quantitative_Evaluation_By_Her2_Ihc_Date,CAPQI05Elements.Breast_Tumor_Evaluation_By_Her2_Ihc,CAPQI05Elements.Breast_Tumor_Evaluation_By_Her2_Ihc_Date)
        || isLaboratoryTestPerformedDuringLaboratoryTest(visit,m,CAPQI05Elements.Quantitative_Her2_By_Ihc_Evaluation,CAPQI05Elements.Quantitative_Her2_By_Ihc_Evaluation_Date,CAPQI05Elements.Breast_Tumor_Evaluation_By_Her2_Ihc,CAPQI05Elements.Breast_Tumor_Evaluation_By_Her2_Ihc_Date))
        && ! isLaboratoryTestPerformedDuringLaboratoryTest(visit,m,CAPQI05Elements.Quantitative_Eval_Reason_Not_Specified,CAPQI05Elements.Quantitative_Eval_Reason_Not_Specified_Date,CAPQI05Elements.Breast_Tumor_Evaluation_By_Her2_Ihc,CAPQI05Elements.Breast_Tumor_Evaluation_By_Her2_Ihc_Date)


    )
  }


}