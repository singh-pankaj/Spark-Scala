package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AAN24Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAN24
* Measure Title               :- Vestibular Rehabilitation for Unilateral or Bilateral Vestibular Hypofunction
* Measure Description         :- Percentage of patients diagnosed with unilateral or bilateral vestibular hypofunction who were referred, prescribed, recommended for, or received vestibular rehabilitation.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KAJAL_JADHAO_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object AAN24 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAN24"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , AAN24Elements.Vestibular_Hypofunction
      , AAN24Elements.Physical_Therapy_Evaluation
      , AAN24Elements.Occupational_Therapy_Evaluation
      , AAN24Elements.Vestibular_Rehabilitation
      , AAN24Elements.Refusal_For_Vestibular_Rehabilitation
      , AAN24Elements.Clinically_Asymptomatic_Or_Compensated
      , AAN24Elements.Documentation_Of_Prior_Ineffective_Vestibular_Rehab)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients diagnosed with unilateral or bilateral vestibular hypofunction
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      (
        isProcedurePerformedDuringEncounter(visit, m, AAN24Elements.Vestibular_Evaluation)
          || isEncounterPerformedDuringEncounter(visit, m, AAN24Elements.Outpatient_Consultation)
          || isEncounterPerformedDuringEncounter(visit, m, AAN24Elements.Office_Visit)
        )
        && wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,AAN24Elements.Vestibular_Hypofunction)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with an order for a referral to physical therapy or occupational therapy for vestibular rehabilitation, OR prescription for vestibular rehabilitation,
OR documentation that vestibular rehabilitation was recommended, OR documentation that vestibular rehabilitation was provided.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      isInterventionPerformed(visit, m,AAN24Elements.Physical_Therapy_Evaluation,patientHistoryBroadcastList)
        || isInterventionPerformed(visit,m,AAN24Elements.Occupational_Therapy_Evaluation,patientHistoryBroadcastList)
        || isInterventionPerformed(visit,m,AAN24Elements.Vestibular_Rehabilitation,patientHistoryBroadcastList)


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who have refused or declined vestibular rehabilitation; documentation of prior ineffective vestibular rehabilitation; patients with clinically
asymptomatic or compensated in unilteral or bilateral vestibular hypofunction.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      isCommunicationFromPatientToProvider(visit,m,AAN24Elements.Refusal_For_Vestibular_Rehabilitation,patientHistoryBroadcastList)
        || isAssessmentPerformed(visit,m,AAN24Elements.Clinically_Asymptomatic_Or_Compensated,patientHistoryBroadcastList)
        || isAssessmentPerformed(visit,m,AAN24Elements.Documentation_Of_Prior_Ineffective_Vestibular_Rehab,patientHistoryBroadcastList)

    )
  }
}