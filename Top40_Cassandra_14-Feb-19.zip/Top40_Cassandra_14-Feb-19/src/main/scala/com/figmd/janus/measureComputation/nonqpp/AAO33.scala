package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AAO33Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO33
* Measure Title               :- Age-related Hearing Loss: Shared Decision Making
* Measure Description         :- Patients age 60 years and older with a diagnosis of bilateral presbycusis or symmetric sensorineural hearing
                                 loss or their caregiver(s) who report shared decision making with a healthcare provider regarding treatment options
                                 for their hearing loss using a standardized tool and a subsequent plan of care.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.RASURE
* Initial GIT Version/Tag(CRA):- 1.5
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/

object AAO33 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO33"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,AAO33Elements.Symmetric_Sensorineural_Hearing_Loss,
      AAO33Elements.Bilateral_Presbycusis_And_Symmetric_Sensorineural_Hearing_Loss,
      AAO33Elements.Shared_Decision_Making,
      AAO33Elements.Patient_Refusal,
      AAO33Elements.Patient_Already_Participated,
      AAO33Elements.No_Response_Questionnaire
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population : 1. Patients age 60 years and older with a diagnosis of bilateral presbycusis or symmetric sensorineural hearing loss.

2. Patients who report participation in shared decision making.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit,m,true,60)
        && isVisitTypeIn(visit,m,AAO33Elements.Office_Visit,
        AAO33Elements.Adult_Outpatient_Visit,
        AAO33Elements.Ambulatory_Ed_Visit
      )
        && (
        wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,AAO33Elements.Symmetric_Sensorineural_Hearing_Loss)
          || wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,AAO33Elements.Bilateral_Presbycusis_And_Symmetric_Sensorineural_Hearing_Loss)
        )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator : 1. Patients (or their caregivers) who report participation in shared decision making regarding treatment options for their hearing loss using a standardized tool.

2. Patients (or their caregivers) who report a treatment plan or documentation of a treatment plan in the medical record.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      isCommunicationFromPatientToProvider(visit,m,AAO33Elements.Shared_Decision_Making,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exceptions : No response from patient after 2 electronic communications and 3 weeks after last communication; patient refusal.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      isCommunicationFromPatientToProvider(visit,m,AAO33Elements.Patient_Refusal,patientHistoryBroadcastList)
        || isInterventionPerformed(visit,m,AAO33Elements.No_Response_Questionnaire,patientHistoryBroadcastList)
        || isPatientCareExperience(visit,m,AAO33Elements.Patient_Already_Participated,patientHistoryBroadcastList)
    )
  }
}