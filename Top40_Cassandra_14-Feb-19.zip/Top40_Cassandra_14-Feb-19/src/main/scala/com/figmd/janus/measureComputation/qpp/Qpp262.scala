package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP262Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 262
* Measure Title              :- Image Confirmation of Successful Excision of Image-Localized Breast Lesion
* Measure Description        :- Image confirmation of lesion(s) targeted for image guided excisional biopsy or image guided partial mastectomy in patients with nonpalpable, image-detected breast lesion(s). Lesions may include: microcalcifications, mammographic or sonographic mass or architectural distortion, focal suspicious abnormalities on magnetic resonance imaging (MRI) or other breast imaging amenable to localization such as positron emission tomography (PET) mammography, or a biopsy marker demarcating site of confirmed pathology as established by previous core biopsy
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp262 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp262"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP262Elements.Breast_Lesion,
      QPP262Elements.Excisional_Biopsy_Or_Partial_Mastectomy,
      QPP262Elements.X_Ray_Breast,
      QPP262Elements.Ultrasound_Of_Breast,
      QPP262Elements.Mri_Breast,
      QPP262Elements.Pet_Mammography,
      QPP262Elements.Other_Imaging_Modality
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      //    metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()
      //

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /* Number of patients aged 18 years and older on date of encounter with non-palpable, image-detected (by mammogram, ultrasound, or breast MRI, PET mammography or other imaging modality) breast lesion requiring localization of lesion (benign or malignant) for targeted resection (either excisional biopsy or partial mastectomy) */
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        isProcedurePerformedDuringEncounter(visit, m, QPP262Elements.Excisional_Biopsy_Or_Partial_Mastectomy)
        && wasDiagnosisBeforeOrEqualProcedure(visit, m, QPP262Elements.Breast_Lesion, QPP262Elements.Excisional_Biopsy_Or_Partial_Mastectomy, patientHistoryBroadcastList)
    )
  }


  // Denominator Exclusion criteria
  /*Patients with needle localization specimens which are not amenable to intraoperative imaging such as MRI needle wire localization, or targets which are tentatively identified on mammogram or ultrasound which do not contain a biopsy marker but which can be verified on intraoperative inspection or pathology (e.g., needle biopsy site where the biopsy marker is remote from the actual biopsy site) */
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isProcedurePerformedDuringEncounter(visit, m, QPP262Elements.Excisional_Biopsy_Or_Partial_Mastectomy)
        ||
        isProcedurePerformedDuringOtherProcedure(visit, m, QPP262Elements.Unamenable_Specimen, QPP262Elements.Excisional_Biopsy_Or_Partial_Mastectomy)
    )
  }

  // Numerator criteria
  /* Patients undergoing excisional biopsy or partial mastectomy of a non-palpable lesion whose excised breast tissue was evaluated by imaging (x-ray, ultrasound, MRI, PET mammography or other imaging modality) intraoperatively to confirm successful inclusion of targeted lesion*/
  def getMet(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        isProcedurePerformedDuringEncounter(visit, m, QPP262Elements.Excised_Tissue_Imaging)
          &&
          isDiagnosticStudyPerformedAfterProcedure(visit, m, patientHistoryBroadcastList, QPP262Elements.Excisional_Biopsy_Or_Partial_Mastectomy, QPP262Elements.X_Ray_Breast,
            QPP262Elements.Ultrasound_Of_Breast,
            QPP262Elements.Mri_Breast,
            QPP262Elements.Pet_Mammography,
            QPP262Elements.Other_Imaging_Modality)

          && !isProcedurePerformedDuringEncounter(visit, m, QPP262Elements.Excised_Tissue_Reason_Not_Specified)
        )
    )
  }


}
