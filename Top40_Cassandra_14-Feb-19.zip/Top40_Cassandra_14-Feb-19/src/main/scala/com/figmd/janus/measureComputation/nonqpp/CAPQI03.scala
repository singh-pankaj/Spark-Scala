package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,CAPQI03Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAPQI03
* Measure Title               :- Breast Cancer Resection Pathology Reporting: pT Category (Primary Tumor) and pN Category (Regional Lymph Nodes) with Histologic Grade
* Measure Description         :- Percentage of breast cancer resection pathology reports that include the pTcategory (primary tumor),the pN category (regional lymph nodes),
                                 and the histologic grade.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMIT.SINGH
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
----------------------------------------------------------------------------------------------------------------------------*/

object CAPQI03 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "CAPQI03"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      CAPQI03Elements.Breast_Cancer,
      CAPQI03Elements.Level_V_Surgical_Pathology_Exam


    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  /*-----------------------------------------------------------------------------------------------------------------------
  All breast cancer resection pathology reports (excluding biopsies)
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
             wasDiagnosedBeforeOrEqualEncounter(visit,m,CAPQI03Elements.Breast_Cancer,patientHistoryBroadcastList)
        &&   isLaboratoryTestPerformedOnEncounter(visit,m,CAPQI03Elements.Level_V_Surgical_Pathology_Exam)


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Specimen site other than anatomic location of primary tumor
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
             isLaboratoryTestPerformedOnEncounter(visit,m,CAPQI03Elements.Specimen_Site_Primary_Tumor)
        &&   isLaboratoryTestPerformedOnEncounter(visit,m,CAPQI03Elements.Specimen_Site__Non_Primary_Breast_Tumor_)


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Reports that include the pT category, the pN category and the histologic grade
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
             (
                    isLaboratoryTestPerformedAfterOrEqualEncounter(visit,m,CAPQI03Elements.Appropriate_Documentation_For_Breast_Cancer,patientHistoryBroadcastList,CAPQI03Elements.Level_V_Surgical_Pathology_Exam)
       ||           isLaboratoryTestPerformedAfterOrEqualEncounter(visit,m,CAPQI03Elements.Breast_Cancer_Documentation,patientHistoryBroadcastList,CAPQI03Elements.Level_V_Surgical_Pathology_Exam)
             )
       &&    (
                    isLaboratoryTestPerformedAfterOrEqualEncounter(visit,m,CAPQI03Elements.Documentation_Of_Pt_Category,patientHistoryBroadcastList,CAPQI03Elements.Level_V_Surgical_Pathology_Exam)
                &&  isLaboratoryTestPerformedAfterOrEqualEncounter(visit,m,CAPQI03Elements.Documentation_Of_Pn_Category,patientHistoryBroadcastList,CAPQI03Elements.Level_V_Surgical_Pathology_Exam)
                &&  isLaboratoryTestPerformedAfterOrEqualEncounter(visit,m,CAPQI03Elements.Histologic_Grade,patientHistoryBroadcastList,CAPQI03Elements.Level_V_Surgical_Pathology_Exam)
             )
        &&     (
                  !isLaboratoryTestPerformedNotDone(visit,m,CAPQI03Elements.Appropriate_Doc__Breast__Reason_Not_Specified,patientHistoryBroadcastList)
               )


        )

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Documentation of medical reason(s) for not including the pT category, the pN category, or the histologic grade in the pathology report (eg, re-excision without residual tumor, non-carcinomas)
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
          isLaboratoryTestPerformedNotDoneAfterOrEqualEncounter(visit,m,CAPQI03Elements.Level_V_Surgical_Pathology_Exam,patientHistoryBroadcastList,CAPQI03Elements.Appropriate_Doc__Breast___Medical_Reason)
      ||  isProcedurePerformedDuringEncounter(visit,m,CAPQI03Elements.Re_Excision_Without_Tumor)
      ||  isLaboratoryTestPerformedOnEncounter(visit,m,CAPQI03Elements.Non_Carcinoma)



    )
  }
}

