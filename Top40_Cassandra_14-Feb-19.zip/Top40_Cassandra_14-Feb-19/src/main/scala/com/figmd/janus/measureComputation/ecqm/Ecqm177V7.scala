package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 177
* Measure Title              :- Child and Adolescent Major Depressive Disorder (MDD): Suicide Risk Assessment
* Measure Description        :- Percentage of patient visits for those patients aged 6 through 17 years with a
*                               diagnosis of major depressive disorder with an assessment for suicide risk
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Rishikesh patil
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm177V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm177V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

    }
  }


  // IPP - Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 6, CalenderUnit.YEAR)
        &&
        isAgeBelowBeforeStart(visit, m, false, 17, CalenderUnit.YEAR)
        &&

        /** $MDDEncounters177 **/
        (
          isVisitTypeIn(visit, m, ECQM177V7Elements.Office_Visit) && isDiagnosedOnEncounter(visit, m, ECQM177V7Elements.Major_Depressive_Disorder_Active)
            ||
            isVisitTypeIn(visit, m, ECQM177V7Elements.Outpatient_Consultation) && isDiagnosedOnEncounter(visit, m, ECQM177V7Elements.Major_Depressive_Disorder_Active)
            ||
            isVisitTypeIn(visit, m, ECQM177V7Elements.Psych_Visit___Diagnostic_Evaluation) && isDiagnosedOnEncounter(visit, m, ECQM177V7Elements.Major_Depressive_Disorder_Active)
            ||
            isVisitTypeIn(visit, m, ECQM177V7Elements.Psych_Visit___Family_Psychotherapy) && isDiagnosedOnEncounter(visit, m, ECQM177V7Elements.Major_Depressive_Disorder_Active)
            ||
            isVisitTypeIn(visit, m, ECQM177V7Elements.Group_Psychotherapy) && isDiagnosedOnEncounter(visit, m, ECQM177V7Elements.Major_Depressive_Disorder_Active)
            ||
            isVisitTypeIn(visit, m, ECQM177V7Elements.Psych_Visit___Psychotherapy) && isDiagnosedOnEncounter(visit, m, ECQM177V7Elements.Major_Depressive_Disorder_Active)
          )
    )

  }


  // Numerator criteria
  def getMet(denominatorRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
      isInterventionPerformedDuringEncounter(visit, m, ECQM177V7Elements.Suicide_Risk_Assessment)
        &&

        /** $MDDEncounters177 **/
        (
          isVisitTypeIn(visit, m, ECQM177V7Elements.Office_Visit) && isDiagnosedOnEncounter(visit, m, ECQM177V7Elements.Major_Depressive_Disorder_Active)
            ||
            isVisitTypeIn(visit, m, ECQM177V7Elements.Outpatient_Consultation) && isDiagnosedOnEncounter(visit, m, ECQM177V7Elements.Major_Depressive_Disorder_Active)
            ||
            isVisitTypeIn(visit, m, ECQM177V7Elements.Psych_Visit___Diagnostic_Evaluation) && isDiagnosedOnEncounter(visit, m, ECQM177V7Elements.Major_Depressive_Disorder_Active)
            ||
            isVisitTypeIn(visit, m, ECQM177V7Elements.Psych_Visit___Family_Psychotherapy) && isDiagnosedOnEncounter(visit, m, ECQM177V7Elements.Major_Depressive_Disorder_Active)
            ||
            isVisitTypeIn(visit, m, ECQM177V7Elements.Group_Psychotherapy) && isDiagnosedOnEncounter(visit, m, ECQM177V7Elements.Major_Depressive_Disorder_Active)
            ||
            isVisitTypeIn(visit, m, ECQM177V7Elements.Psych_Visit___Psychotherapy) && isDiagnosedOnEncounter(visit, m, ECQM177V7Elements.Major_Depressive_Disorder_Active)
          )
    )
  }

}

