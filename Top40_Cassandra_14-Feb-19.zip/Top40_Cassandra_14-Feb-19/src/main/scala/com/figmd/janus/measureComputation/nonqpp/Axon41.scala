package com.figmd.janus.measureComputation.nonqpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate, quarter_end_date}
import com.figmd.janus.measureComputation.master.{AXON41Elements, MeasureProperty,CalenderUnit}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.joda.time.DateTime

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Axon41
* Measure Title               :- Quality of Life Outcome for Patients with Epilepsy
* Measure Description         :- Percentage of patients whose quality of life assessment results are maintained or improved during the measurement period.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KIRTI_RAUT_FIGMD_COM
* Initial GIT Version/Tag(CRA):-1.8
* Latest GIT Version/Tag(CRA) :-1.8
----------------------------------------------------------------------------------------------------------------------------*/

object Axon41 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "Axon41"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      AXON41Elements.Qolie_10_Score,
      AXON41Elements.Office_Visit,
      AXON41Elements.Score_Maintained

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val leastRecentRDD: List[CassandraRow] = leastRecentPatientList(patientHistoryRDD, AXON41Elements.Qolie_10_Score
    )

    val leastRecentPatienthistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastRecentRDD)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList,leastRecentPatienthistoryList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      leastRecentPatienthistoryList.unpersist()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------

Patients aged 18 years and older diagnosed with epilepsy who had two office visits during the two year measurement period which occurred at least 4 weeks apart.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

   // val globalStartDate1 = globalEndDate.minusMonths(24)


    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit,m)
        &&    isDiagnosisOnEncounter(visit,m,AXON41Elements.Epilepsy)
        &&    wasEncounterPerformedAfterEndOfEncounterInXWeek(visit,m,AXON41Elements.Office_Visit,CalenderUnit.WEEK,4,CalenderUnit.MONTH,24,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

Patients whose most recent QOLIE-10-P score is maintained or improved from the prior QOLIE-10-P score obtained in the measurement period.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],leastRecentPatienthistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
           wasAssessmentPerformedAfterEndOfEncounterInXWeek(visit,m,AXON41Elements.Qolie_10_Score,AXON41Elements.Score_Maintained,CalenderUnit.WEEK,4,CalenderUnit.MONTH,24,patientHistoryBroadcastList)

    )
  }

}
