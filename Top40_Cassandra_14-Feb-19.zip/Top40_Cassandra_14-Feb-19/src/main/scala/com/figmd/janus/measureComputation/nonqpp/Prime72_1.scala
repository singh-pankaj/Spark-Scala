package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, PRIME72Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- PRIME 72
* Measure Title              :- Preventive Care and Screening: Cholesterol - Fasting Low Density Lipoprotein (LDL-C) Test Performed
* Measure Description        :- Percentage of patients aged 20 through 79 years whose risk factors have been assessed and a fasting LDL-C test has been performed.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 3
* Measure Stratum No.        :- 1
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Prime72_1 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Prime72_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {
      val patientHistory: List[CassandraRow] = getPatientHistory(sparkSession, ippRDD,
        PRIME72Elements.Acute_Myocardial_Infarction,
        PRIME72Elements.Hemorrhagic_Stroke,
        PRIME72Elements.Ischemic_Stroke,
        PRIME72Elements.Ischemic_Vascular_Disease,
        PRIME72Elements.Coronary_Artery_Disease_No_Mi,
        PRIME72Elements.Diabetes,
        PRIME72Elements.Abdominal_Aortic_Aneurysm,
        PRIME72Elements.Atherosclerosis_And_Peripheral_Arterial_Disease,
        PRIME72Elements.Pci,
        PRIME72Elements.Carotid_Intervention,
        PRIME72Elements.Cabg_Surgeries,
        PRIME72Elements.Framingham_Coronary_Heart_Disease_10_Year_Risk,
        PRIME72Elements.Palliative_Care,
        PRIME72Elements.Ldl_Code,
        PRIME72Elements.Total_Cholesterol,
        PRIME72Elements.High_Density_Lipoprotein__Hdl_,
        PRIME72Elements.Triglycerides,
        PRIME72Elements.Patient_Reason_Refused).collect().toList

      val patienthistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistory)


        // Eligible IPP
        val denominatorRDD = getEligibleIpp(ippRDD, patienthistoryList)
        denominatorRDD.cache()


        // Filter Exclusions
        val exclusionRDD = getExclusionRDD(denominatorRDD, patienthistoryList)
        exclusionRDD.cache()

        val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
        intermediateA.cache()

        // Filter Met
        val metRDD = getMetRDD(intermediateA, patienthistoryList)
        metRDD.cache()

        // Filter Exceptions
        val intermediateB = getSubtractRDD(intermediateA, metRDD)
        intermediateB.cache()

        val exceptionRDD = getExceptionRDD(intermediateB, patienthistoryList)
        exceptionRDD.cache()

        // Filter not Met
        val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
        notMetRDD.cache()

        saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
        patienthistoryList.destroy()
      }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
All patients 20 through 79 years of age before the beginning of the measurement period
----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeBetween(visit, m, 20, 80)
        && isVisitTypeIn(visit, m, PRIME72Elements.Cholesterol_Measure_Encounter_Codes)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Denominator 1: (High Risk)
All patients aged 20 through 79 years who have CHD or CHD Risk Equivalent OR 10-Year Framingham Risk > 20%
----------------------------------------------------------------------------------------------------------------------------*/

  def getEligibleIpp(ippRDD: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (wasDiagnosedInHistory(visit, m, PRIME72Elements.Acute_Myocardial_Infarction, patienthistoryList)
        || wasDiagnosedInHistory(visit, m, PRIME72Elements.Hemorrhagic_Stroke, patienthistoryList)
        || wasDiagnosedInHistory(visit, m, PRIME72Elements.Ischemic_Stroke, patienthistoryList)
        || wasDiagnosedInHistory(visit, m, PRIME72Elements.Ischemic_Vascular_Disease, patienthistoryList)
        || wasDiagnosedInHistory(visit, m, PRIME72Elements.Coronary_Artery_Disease_No_Mi, patienthistoryList)
        || wasDiagnosedInHistory(visit, m, PRIME72Elements.Diabetes, patienthistoryList)
        || wasDiagnosedInHistory(visit, m, PRIME72Elements.Abdominal_Aortic_Aneurysm, patienthistoryList)
        || wasDiagnosedInHistory(visit, m, PRIME72Elements.Atherosclerosis_And_Peripheral_Arterial_Disease, patienthistoryList)
        || wasProcedurePerformedInHistory(visit, m, PRIME72Elements.Pci, patienthistoryList)
        || wasProcedurePerformedInHistory(visit, m, PRIME72Elements.Cabg_Surgeries, patienthistoryList)
        || wasProcedurePerformedInHistory(visit, m, PRIME72Elements.Carotid_Intervention, patienthistoryList)
        )
        || isAssessmentPerformedValue(visit, m, PRIME72Elements.Framingham_Coronary_Heart_Disease_10_Year_Risk, 20, "gt", patienthistoryList)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Patients who have an active diagnosis of pregnancy
OR
Patients who are receiving palliative care
----------------------------------------------------------------------------------------------------------------------------*/

  def getExclusionRDD(eligibleRdd: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    eligibleRdd.filter(visit =>
      isInterventionOrdered(visit, m, PRIME72Elements.Palliative_Care, patienthistoryList)
        || isDiagnosedOnEncounter(visit, m, PRIME72Elements.Pregnancy_Dx)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Numerator 1: (High Risk)
Patients who had a fasting LDL-C test performed or a calculated LDL-C during the measurement period
----------------------------------------------------------------------------------------------------------------------------*/

  def getMetRDD(rdd: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isLaboratoryTestPerformed(visit, m, PRIME72Elements.Ldl_Code, patienthistoryList)
        || (isLaboratoryTestPerformed(visit, m, PRIME72Elements.Total_Cholesterol, patienthistoryList)
        && isLaboratoryTestPerformed(visit, m, PRIME72Elements.High_Density_Lipoprotein__Hdl_, patienthistoryList)
        && isLaboratoryTestPerformed(visit, m, PRIME72Elements.Triglycerides, patienthistoryList)
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Patient Reason(s):
Patient Refusal
A fasting LDL-C test is not performed during the measurement period for a valid patient reason.
----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(rdd: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isLaboratoryTestPerformed(visit, m, PRIME72Elements.Patient_Reason_Refused, patienthistoryList)
    )
  }
}
