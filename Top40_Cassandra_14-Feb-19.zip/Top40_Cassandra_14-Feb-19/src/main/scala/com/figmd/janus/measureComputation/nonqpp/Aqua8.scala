package com.figmd.janus.measureComputation.nonqpp



import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{AQUA13Elements, AQUA8Elements, AdminElements, MeasureProperty}
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AQUA8
* Measure Title              :- Hospital re-admissions/complications within 30 days of TRUS Biopsy
* Measure Description        :- Percentage of patients who had TRUS biopsy performed who had >=24h after the biopsy): infection, hematuria, new antibiotic Rx after biopsy, or inpatient consultation within 30 days.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Aqua8 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Aqua8"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    var patient_history_list = getPatientHistory(sparkSession,initialRDD,


      AQUA8Elements.Antibiotic_After_Biopsy,
      AQUA8Elements.Infections_Due_To_Biopsy,
      AQUA8Elements.Documentation_Of_Hematuria,
      AQUA8Elements.Inpatient_Consultation

    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)
    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }

  }

  //Number of patients with a TRUS biopsy performed
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
                          isProcedurePerformedDuringEncounter(visit,m,AQUA8Elements.Trus_Biopsy)
                      &&   isProcedurePerformedDuringEncounter(visit,m,AQUA8Elements.Transrectal_Ultrasound_Biopsy)
              )
  }

  // Exclusion criteria   Diagnosis: Documentation of Hematuria" <= 90 day(s) starts before start of "Procedure, Performed: TRUS Biopsy"
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
                            !wasDiagnosedBeforeProcedureInXDays(visit,m,AQUA8Elements.Trus_Biopsy,90,patientHistoryList,AQUA8Elements.Documentation_Of_Hematuria)
                )
  }


//Number of patients with a TRUS biopsy performed that had infection, hematuria, new antibiotic Rx after biopsy, or inpatient consultation within 30 days
  def getMet(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
                                (
                                      wasMedicationOrderedStartsAfterEndOfWithinXPeriod(visit,m,AQUA8Elements.Trus_Biopsy,AQUA8Elements.Antibiotic_After_Biopsy,"HOURS",24,"ge","DAYS",30,"le",patientHistoryList)
                                  &&  wasMedicationOrderedStartsAfterEndOfWithinXPeriod(visit,m,AQUA8Elements.Transrectal_Ultrasound_Biopsy,AQUA8Elements.Antibiotic_After_Biopsy,"HOURS",24,"ge","DAYS",30,"le",patientHistoryList)
                                )
                            ||  (
                                      wasDiagnosisDoneStartsAfterEndOfWithinXPeriod(visit,m,AQUA8Elements.Trus_Biopsy,AQUA8Elements.Infections_Due_To_Biopsy,"HOURS",24,"ge","DAYS",30,"le",patientHistoryList)
                                  &&  wasDiagnosisDoneStartsAfterEndOfWithinXPeriod(visit,m,AQUA8Elements.Transrectal_Ultrasound_Biopsy,AQUA8Elements.Infections_Due_To_Biopsy,"HOURS",24,"ge","DAYS",30,"le",patientHistoryList)
                                )
                            ||  (
                                      wasDiagnosisDoneStartsAfterEndOfWithinXPeriod(visit,m,AQUA8Elements.Trus_Biopsy,AQUA8Elements.Documentation_Of_Hematuria,"HOURS",24,"ge","DAYS",30,"le",patientHistoryList)
                                  &&  wasDiagnosisDoneStartsAfterEndOfWithinXPeriod(visit,m,AQUA8Elements.Transrectal_Ultrasound_Biopsy,AQUA8Elements.Documentation_Of_Hematuria,"HOURS",24,"ge","DAYS",30,"le",patientHistoryList)
                                )
                            ||  (
                                      wasCommunicationDoneStartsAfterEndOfWithinXPeriod(visit,m,AQUA8Elements.Trus_Biopsy,AQUA8Elements.Inpatient_Consultation,"HOURS",24,"ge","DAYS",30,"le",patientHistoryList)
                                  &&  wasCommunicationDoneStartsAfterEndOfWithinXPeriod(visit,m,AQUA8Elements.Transrectal_Ultrasound_Biopsy,AQUA8Elements.Inpatient_Consultation,"HOURS",24,"ge","DAYS",30,"le",patientHistoryList)

                                )

    )
  }

}

