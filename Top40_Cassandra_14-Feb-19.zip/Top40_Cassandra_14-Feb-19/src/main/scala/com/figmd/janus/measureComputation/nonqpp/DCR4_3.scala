package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, TimeOperator,DCR4Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- DCR4_3
* Measure Title               :- Diabetes: Preventive Care and Screening:Tobacco Use: Screening and Cessation Intervention
* Measure Description         :- Percentage of patients aged 18 years and older with a diagnosis of diabetes who were screened for tobacco use one or more times within 24 months AND who received cessation counseling intervention if identified as a tobacco user.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KIRTI_RAUT_FIGMD_COM
* Initial GIT Version/Tag(CRA):-1.8
* Latest GIT Version/Tag(CRA) :-1.8
----------------------------------------------------------------------------------------------------------------------------*/

object DCR4_3 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "DCR4_3"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryListRDD = getPatientHistory(sparkSession, initialRDD,

      DCR4Elements.Preventive_Care_Services___Group_Counseling,
      DCR4Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
      DCR4Elements.Preventive_Care_Services___Other,
      DCR4Elements.Annual_Wellness_Visit,
      DCR4Elements.Preventive_Care_Services_Individual_Counseling,
      DCR4Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
      DCR4Elements.Speech_And_Hearing_Evaluation,
      DCR4Elements.Psychoanalysis,
      DCR4Elements.Psych_Visit___Psychotherapy,
      DCR4Elements.Psych_Visit___Diagnostic_Evaluation,
      DCR4Elements.Ophthalmological_Services,
      DCR4Elements.Office_Visit,
      DCR4Elements.Occupational_Therapy_Evaluation,
      DCR4Elements.Health_And_Behavioral_Assessment___Initial,
      DCR4Elements.Health___Behavioral_Assessment___Individual,
      DCR4Elements.Health_And_Behavioral_Assessment__Reassessment,
      DCR4Elements.Home_Healthcare_Services,
      DCR4Elements.Face_To_Face_Interaction,
      DCR4Elements.Tobacco_Use_Screening,
      DCR4Elements.Tobacco_User,
      DCR4Elements.Tobacco_Non_User,
      DCR4Elements.Diabetes


    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryListRDD.collect.toList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList,patientHistoryListRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryListRDD:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    val countElementList1: List[(String, Int)] = countElement(patientHistoryListRDD, m,
      DCR4Elements.Preventive_Care_Services___Group_Counseling,
      DCR4Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
      DCR4Elements.Preventive_Care_Services___Other,
      DCR4Elements.Annual_Wellness_Visit,
      DCR4Elements.Preventive_Care_Services_Individual_Counseling,
      DCR4Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up)


    val countElementList2: List[(String, Int)] = countElement(patientHistoryListRDD, m,
      DCR4Elements.Speech_And_Hearing_Evaluation,
      DCR4Elements.Psychoanalysis,
      DCR4Elements.Psych_Visit___Psychotherapy,
      DCR4Elements.Psych_Visit___Diagnostic_Evaluation,
      DCR4Elements.Ophthalmological_Services,
      DCR4Elements.Office_Visit,
      DCR4Elements.Occupational_Therapy_Evaluation,
      DCR4Elements.Health_And_Behavioral_Assessment___Initial,
      DCR4Elements.Health___Behavioral_Assessment___Individual,
      DCR4Elements.Health_And_Behavioral_Assessment__Reassessment,
      DCR4Elements.Home_Healthcare_Services,
      DCR4Elements.Face_To_Face_Interaction
    )

    initialRDD.filter(visit =>
      isPatientAdult(visit,m)
        && (    getEncounterCountFromHistory(visit, m, 1, true, countElementList1)
        ||    getEncounterCountFromHistory(visit, m, 2, true, countElementList2)
        )
        &&      wasDiagnosedBeforeOrEqualEncounter(visit,m,DCR4Elements.Diabetes,patientHistoryBroadcastList)
    )

  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      wasAssessmentPerformedwithResultStartBeforeEncounter(visit,m,AdminElements.Encounter_Date,TimeOperator.BEFORE,DCR4Elements.Tobacco_Use_Screening,DCR4Elements.Tobacco_Non_User,patientHistoryBroadcastList) //waitng for fun
        ||         (
        wasAssessmentPerformedwithResultStartBeforeEncounter(visit,m,AdminElements.Encounter_Date,TimeOperator.BEFORE,DCR4Elements.Tobacco_Use_Screening,DCR4Elements.Tobacco_User,patientHistoryBroadcastList)
          &&
          (       isInterventionPerformedStartsAfterOrConcurrentWithStartOfElement(visit,m,DCR4Elements.Tobacco_Use_Screening,DCR4Elements.Tobacco_Use_Cessation_Counseling,patientHistoryBroadcastList)  //waitng for fun
            ||   isMedicationOrderedStartsAfterOrConcurrentWithStartOfElement(visit,m,DCR4Elements.Tobacco_Use_Screening,DCR4Elements.Tobacco_Use_Cessation_Pharmacotherapy,patientHistoryBroadcastList)
            ||   isMedicationActiveStartsAfterOrConcurrentWithStartOfElement(visit,m,DCR4Elements.Tobacco_Use_Screening,DCR4Elements.Tobacco_Use_Cessation_Pharmacotherapy,patientHistoryBroadcastList)
            )
          &&
          (
            isInterventionPerformedBeforeEnd(visit,m,DCR4Elements.Tobacco_Use_Cessation_Counseling,patientHistoryBroadcastList)
              ||  wasMedicationOrderBefore(visit,m,patientHistoryBroadcastList,DCR4Elements.Tobacco_Use_Cessation_Pharmacotherapy)
              ||  wasMedicationActiveBeforeEnd(visit,m,DCR4Elements.Tobacco_Use_Cessation_Pharmacotherapy,patientHistoryBroadcastList)
            )
        )
    )
  }
  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      isAssessmentPerformedDuringEncounter(visit,m,DCR4Elements.Medical_Reason)

    )
  }
}