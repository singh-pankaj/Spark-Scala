package com.figmd.janus.measureComputation.nonqpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qopi 15
* Measure Title              :- GCSF administered to patients who received chemotherapy for metastatic cancer
* Measure Description        :- Percentage of adult patients with metastatic cancer who are administered chemotherapy
*                               and who receive a colony stimulating factor  (Lower Score -Better)
* Calculation Implementation :- Patient Specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/


object Qopi15 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qopi15"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val getPatientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QOPI15Elements.Metastatic_Cancer
      , QOPI15Elements.Tumor_Staging
      , QOPI15Elements.M_Stage_M1
      , QOPI15Elements.M_Stage_M1a
      , QOPI15Elements.M_Stage_M1b
      , QOPI15Elements.M_Stage_M1c
      , QOPI15Elements.Cancer_Stage_Iii
      , QOPI15Elements.Cancer_Stage_Iiia
      , QOPI15Elements.Cancer_Stage_Iiib
      , QOPI15Elements.Cancer_Stage_Iiic
      , QOPI15Elements.Cancer_Stage_Iv
      , QOPI15Elements.Cancer_Stage_Iva
      , QOPI15Elements.Cancer_Stage_Ivb
      , QOPI15Elements.Cancer_Stage_Ivc
      , QOPI15Elements.Hodgkins_Disease
      , QOPI15Elements.Leukemia
      , QOPI15Elements.Testicular_Cancer
      , QOPI15Elements.Neoplasm_Of_Placenta
      , QOPI15Elements.Trophoblastic_Neoplasm
      , QOPI15Elements.Trophoblastic_Neoplasia
      , QOPI15Elements.Non_Hodgkins_Lymphoma
      , QOPI15Elements.Intent_Of_Chemotherapy
      , QOPI15Elements.Antineoplastic_Agents
      , QOPI15Elements.Intent_Non_Curative
      , QOPI15Elements.Chemotherapy_Initiation
      , QOPI15Elements.Antineoplastic_Agents
      , QOPI15Elements.Filgrastim
      , QOPI15Elements.Neulasta
    ).collect.toList

    val patientHistory: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistory)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Filter Denominator
      val denominatorRDD = getDenominator(ippRDD, patientHistory: Broadcast[List[CassandraRow]])
      denominatorRDD.cache()

      // Filter Not Eligible
      /*val notEligibleRDD =sparkSession.sparkContext.emptyRDD[CassandraRow]
    notEligibleRDD.cache()*/

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(denominatorRDD, patientHistory: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMetRdd(intermediateA, patientHistory: Broadcast[List[CassandraRow]])
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistory.destroy()
      
    }

  }


  // IPP criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && wasDiagnosisInHistory(visit, m, QOPI15Elements.Metastatic_Cancer, patientHistory)
        && isVisitTypeIn(visit, m, QOPI15Elements.Office_Visit, QOPI15Elements.Patient_Provider_Interaction)
    )
  }

  // Denominator Criteria
  def getDenominator(eligibleRdd: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE, globalStartDate, globalEndDate)
    eligibleRdd.filter(visit =>
      (
        wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI15Elements.Metastatic_Cancer, QOPI15Elements.Tumor_Staging, QOPI15Elements.M_Stage_M1, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI15Elements.Metastatic_Cancer, QOPI15Elements.Tumor_Staging, QOPI15Elements.M_Stage_M1a, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI15Elements.Metastatic_Cancer, QOPI15Elements.Tumor_Staging, QOPI15Elements.M_Stage_M1b, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI15Elements.Metastatic_Cancer, QOPI15Elements.Tumor_Staging, QOPI15Elements.M_Stage_M1c, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI15Elements.Metastatic_Cancer, QOPI15Elements.Tumor_Staging, QOPI15Elements.Cancer_Stage_Iii, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI15Elements.Metastatic_Cancer, QOPI15Elements.Tumor_Staging, QOPI15Elements.Cancer_Stage_Iiia, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI15Elements.Metastatic_Cancer, QOPI15Elements.Tumor_Staging, QOPI15Elements.Cancer_Stage_Iiib, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI15Elements.Metastatic_Cancer, QOPI15Elements.Tumor_Staging, QOPI15Elements.Cancer_Stage_Iiic, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI15Elements.Metastatic_Cancer, QOPI15Elements.Tumor_Staging, QOPI15Elements.Cancer_Stage_Iv, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI15Elements.Metastatic_Cancer, QOPI15Elements.Tumor_Staging, QOPI15Elements.Cancer_Stage_Iva, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI15Elements.Metastatic_Cancer, QOPI15Elements.Tumor_Staging, QOPI15Elements.Cancer_Stage_Ivb, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI15Elements.Metastatic_Cancer, QOPI15Elements.Tumor_Staging, QOPI15Elements.Cancer_Stage_Ivc, patientHistory)
        )
        &&
        (
          wasProcedureAfterDiagnosis(visit, m, QOPI15Elements.Chemotherapy_Initiation, patientHistory, QOPI15Elements.Metastatic_Cancer)
            ||
            wasInterverntionStudyWithResultAfterMedication(visit, m, QOPI15Elements.Intent_Of_Chemotherapy, QOPI15Elements.Antineoplastic_Agents, QOPI15Elements.Intent_Non_Curative, patientHistory)
            ||
            wasMedicationAfterDiagnosis(visit, m, QOPI15Elements.Antineoplastic_Agents, patientHistory, QOPI15Elements.Metastatic_Cancer)
          )
    )
  }

  // Exclusion criteria
  def getExclusionRdd(exclusionRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    exclusionRDD.filter(visit =>
      wasDiagnosedBeforeOrEqualEncounter(visit, m, QOPI15Elements.Hodgkins_Disease, patientHistory)
        ||
        wasDiagnosedBeforeOrEqualEncounter(visit, m, QOPI15Elements.Leukemia, patientHistory)
        ||
        wasDiagnosedBeforeOrEqualEncounter(visit, m, QOPI15Elements.Testicular_Cancer, patientHistory)
        ||
        wasDiagnosedBeforeOrEqualEncounter(visit, m, QOPI15Elements.Neoplasm_Of_Placenta, patientHistory)
        ||
        wasDiagnosedBeforeOrEqualEncounter(visit, m, QOPI15Elements.Trophoblastic_Neoplasm, patientHistory)
        ||
        wasDiagnosedBeforeOrEqualEncounter(visit, m, QOPI15Elements.Trophoblastic_Neoplasia, patientHistory)
        ||
        wasDiagnosedBeforeOrEqualEncounter(visit, m, QOPI15Elements.Non_Hodgkins_Lymphoma, patientHistory)
    )

  }

  // Numerator criteria
  def getMetRdd(metRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    metRDD.filter(visit =>
      wasMedicationStartsAfterEndOfMedication(visit, m, QOPI15Elements.Antineoplastic_Agents, patientHistory, QOPI15Elements.Filgrastim)
        ||
        wasMedicationStartsAfterEndOfMedication(visit, m, QOPI15Elements.Antineoplastic_Agents, patientHistory, QOPI15Elements.Neulasta)
    )
  }


}






