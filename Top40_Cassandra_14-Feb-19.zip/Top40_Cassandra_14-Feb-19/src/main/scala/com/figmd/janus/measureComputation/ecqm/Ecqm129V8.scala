package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ECQM129V8Elements, MeasureProperty}
import com.figmd.janus.util.measure.{MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Ecqm129V8
* Measure Title               :- Prostate Cancer: Avoidance of Overuse of Bone Scan for Staging Low Risk Prostate Cancer Patients
* Measure Description         :- Percentage of patients, regardless of age, with a diagnosis of prostate cancer at low (or very low)
                                 risk of recurrence receiving interstitial prostate brachytherapy, OR external beam radiotherapy to the prostate,
                                 OR radical prostatectomy, OR cryotherapy who did not have a bone scan performed at any time since diagnosis of prostate cancer
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMIT.SINGH
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm129V8 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "Ecqm129V8"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
          ECQM129V8Elements.Prostate_Cancer
      ,ECQM129V8Elements.Prostate_Cancer_Primary_Tumor_Size_T1a
      ,ECQM129V8Elements.Prostate_Cancer_Primary_Tumor_Size_T1b
      ,ECQM129V8Elements.Prostate_Cancer_Primary_Tumor_Size_T1c
      ,ECQM129V8Elements.Prostate_Cancer_Primary_Tumor_Size_T2a
      ,ECQM129V8Elements.Prostate_Specific_Antigen_Test
      ,ECQM129V8Elements.Cancer_Staging
      ,ECQM129V8Elements.Prostate_Cancer_Treatment
      )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    val leastRecentAssessmentBroadcastList = sparkSession.sparkContext.broadcast(
      leastRecentPatientList(patientHistoryRDD,ECQM129V8Elements.Prostate_Cancer_Treatment))
    val mostRecentAssessmentBroadcastList = sparkSession.sparkContext.broadcast(
      mostRecentPatientList(patientHistoryRDD,ECQM129V8Elements.Cancer_Staging))




    // Filter IPP
    val ippRDD = getIpp(sparkSession: SparkSession, initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Filter Denominator
      val denominatorRDD = getDenominator(ippRDD, patientHistoryBroadcastList,leastRecentAssessmentBroadcastList,mostRecentAssessmentBroadcastList)
      denominatorRDD.cache()

      // Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  All patients, regardless of age, with a diagnosis of prostate cancer
-----------------------------------------------------------------------------------------------------------------------*/
  // IPP criteria
  def getIpp(sparkSession: SparkSession, initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
        wasDiagnosedInHistory(visit,m,ECQM129V8Elements.Prostate_Cancer,patientHistoryBroadcastList)
     && isMale(visit,m)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Equals Initial Population at low (or very low) risk of recurrence receiving interstitial prostate brachytherapy, OR external beam radiotherapy to the prostate, OR radical prostatectomy, OR cryotherapy
-----------------------------------------------------------------------------------------------------------------------*/
  // Denominator criteria
  def getDenominator(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],leastRecentAssessmentBroadcastList: Broadcast[List[CassandraRow]],mostRecentAssessmentBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE, globalStartDate, globalEndDate)
val ResultElement=List(ECQM129V8Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,ECQM129V8Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,ECQM129V8Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,ECQM129V8Elements.Prostate_Cancer_Primary_Tumor_Size_T2a)

    ippRDD.filter(visit =>

       WasLaboratoryTestPerformedBeforeLastProcedure(visit,m,ECQM129V8Elements.Prostate_Specific_Antigen_Test,ECQM129V8Elements.Cancer_Staging,ECQM129V8Elements.Prostate_Cancer_Treatment,10,ResultElement,mostRecentAssessmentBroadcastList,leastRecentAssessmentBroadcastList)
    && wasLaboratoryTestPerformedBeforeStartOfFirstProcedures(visit,m,ECQM129V8Elements.Cancer_Staging,ECQM129V8Elements.Prostate_Specific_Antigen_Test,6,mostRecentAssessmentBroadcastList,leastRecentAssessmentBroadcastList)


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients who did not have a bone scan performed at any time since diagnosis of prostate cancer
-----------------------------------------------------------------------------------------------------------------------*/
  // Numerator criteria
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>

                   !wasDiagnosticStudyPerformedAfterDiagnosisInHistory(visit,m,ECQM129V8Elements.Prostate_Cancer,patientHistoryBroadcastList,ECQM129V8Elements.Bone_Scan)



    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Documentation of reason(s) for performing a bone scan (including documented pain, salvage therapy, other medical reasons, bone scan ordered by someone other than reporting physician)
-----------------------------------------------------------------------------------------------------------------------*/
  // Exception criteria
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateForException.filter(visit =>
               wasDiagnosedAfterDiagnosisInHistory(visit,m,ECQM129V8Elements.Prostate_Cancer,patientHistoryBroadcastList,ECQM129V8Elements.Pain_Related_To_Prostate_Cancer)
        ||     wasProcedurePerformedAfterDiagnosisInHistory(visit,m,ECQM129V8Elements.Prostate_Cancer,patientHistoryBroadcastList,ECQM129V8Elements.Salvage_Therapy)
        ||     wasDiagnosticStudyPerformedAfterDiagnosisWithReason(visit,m,ECQM129V8Elements.Bone_Scan,ECQM129V8Elements.Reason_Documented,ECQM129V8Elements.Prostate_Cancer,patientHistoryBroadcastList)


    )
  }
}