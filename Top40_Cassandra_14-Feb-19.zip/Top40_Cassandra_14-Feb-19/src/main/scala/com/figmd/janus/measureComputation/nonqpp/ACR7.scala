package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ACR7Elements, CalenderUnit, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACR 7
* Measure Title              :- Gout: Serum Urate Target
* Measure Description        :- Percentage of patients aged 18 and older with a diagnosis of gout treated with urate-lowering
*                               therapy (ULT) for at least 12 months, whose most recent serum urate result is less than 6.8 mg/dL.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/
object ACR7 extends MeasureUtilityUpdate with MeasureUpdate {

val MEASURE_NAME = "ACR7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD,
      ACR7Elements.Gout,
      ACR7Elements.Urate_Lowering_Therapy__Ult_,
      ACR7Elements.Tacrolimus,
      ACR7Elements.Cyclosporine,
      ACR7Elements.History_Of_Solid_Organ_Transplant,
      ACR7Elements.Serum_Urate_Level_Measurement,
      ACR7Elements.Chronic_Kidney_Disease_Stage_3_4_5,
      ACR7Elements.End_Stage_Renal_Disease
    )

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIppRDD(initialRDD, patientHistoryList, patientHistoryRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Eligible IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMetRDD(intermediateA, patientHistoryList)
      metRDD.cache()

      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      // Filter Exception
      val exceptionRDD = getException(intermediateB, patientHistoryList)
      exceptionRDD.cache()


      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD, notMetRDD, MEASURE_NAME)
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
   Adult patients aged 18 and older with a diagnosis of gout treated with urate lowering therapy (ULT) for at least 12 months.
   ----------------------------------------------------------------------------------------------------------------------------*/

  def getIppRDD(initialRDD: RDD[CassandraRow],patientHistoryList :Broadcast[List[CassandraRow]],patientHistoryRDD : RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
          isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
            && isVisitTypeIn(visit, m, ACR7Elements.Face_To_Face_Interaction,
                                        ACR7Elements.Office_Visit,
                                        ACR7Elements.Home_Healthcare_Services,
                                        ACR7Elements.Care_Services_In_Long_Term_Residential_Facility,
                                        ACR7Elements.Nursing_Facility_Visit,
                                        ACR7Elements.Outpatient_Consultation)
            && isVisitTypeIn(visit, m, ACR7Elements.Gout)
            && wasDiagnosisBeforeOrEqualStartDate(visit, m, ACR7Elements.Gout, patientHistoryList)
            && wasMedicationActiveBeforeOrEqualStartDate(visit, m, ACR7Elements.Urate_Lowering_Therapy__Ult_, patientHistoryList)
            && wasMedicationActiveBeforeEnd(visit, m, ACR7Elements.Urate_Lowering_Therapy__Ult_, patientHistoryList)
            && wasMedicationActiveAfterMedicationInXDays(visit, m, ACR7Elements.Urate_Lowering_Therapy__Ult_, ACR7Elements.Urate_Lowering_Therapy__Ult_, 90, patientHistoryList)

    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
 Patients with a history of solid organ transplant.
 ----------------------------------------------------------------------------------------------------------------------------*/

  def getExclusion(rdd: RDD[CassandraRow],patientHistoryList :Broadcast[List[CassandraRow]]): RDD[CassandraRow] =
  {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    rdd.filter(visit =>
      wasMedicationActiveBeforeEndWithinXMonths(visit, m, ACR7Elements.Tacrolimus, 24, patientHistoryList)
      || wasMedicationActiveBeforeEndWithinXMonths(visit, m, ACR7Elements.Cyclosporine, 24, patientHistoryList)
        || wasDiagnosisBeforeEndWithinXMonths(visit, m, ACR7Elements.History_Of_Solid_Organ_Transplant, 24, patientHistoryList)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
 Patients whose most recent serum urate level is less than 6.8 mg/dL.
 ----------------------------------------------------------------------------------------------------------------------------*/

  def getMetRDD(rdd: RDD[CassandraRow],patientHistoryList :Broadcast[List[CassandraRow]]): RDD[CassandraRow] =
  {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
   rdd.filter(visit =>
     isMostRecentLaboratoryTestValueLessThanX(visit, m, ACR7Elements.Serum_Urate_Level_Measurement, 6.8, "lt", patientHistoryList)
   )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
 Documentation of medical reason(s) for not expecting a serum urate target level of < 6.8 mg/dL (ie, any eGFR level < 30 mL/min
 or Stage 3 or greater chronic kidney disease in the measurement year or year prior).
 ----------------------------------------------------------------------------------------------------------------------------*/

  def getException(rdd: RDD[CassandraRow],patientHistoryList :Broadcast[List[CassandraRow]]): RDD[CassandraRow] =
  {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    rdd.filter(visit =>
      wasDiagnosisBeforeEndWithinXMonths(visit, m, ACR7Elements.Chronic_Kidney_Disease_Stage_3_4_5, 24, patientHistoryList)
      || wasDiagnosisBeforeEndWithinXMonths(visit, m, ACR7Elements.End_Stage_Renal_Disease, 24, patientHistoryList)

    )
  }

}
