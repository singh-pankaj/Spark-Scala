package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty,PRIME80Elements,CalenderUnit,CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PRIME80
* Measure Title               :- Comprehensive Diabetes Care: Blood Pressure Control (<140/90 mm Hg)
* Measure Description         :- The percentage of patients 18-75 years of age with diabetes (type 1 and type 2) whose
                                 most recent blood pressure level taken during the measurement year is <140/90 mm Hg.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SANKET.DHAPTE
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object PRIME80 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "PRIME80"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,PRIME80Elements.Diabetes
      ,PRIME80Elements.Hospice_Services_Snomedct
      ,PRIME80Elements.Polycystic_Ovaries
      ,PRIME80Elements.Systolic_Blood_Pressure
      ,PRIME80Elements.Diastolic_Blood_Pressure
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients 18-75 years of age by the end of the measurement year who had a diagnosis of diabetes (type 1 and type 2)
  during the measurement year or the year prior to the measurement year.
  -----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
         isAgeBetween(visit,m,18,CompareOperator.GREATER_EQUAL,76,CompareOperator.LESS)
      && isVisitTypeIn(visit,m
                              ,PRIME80Elements.Annual_Wellness_Visit
                              ,PRIME80Elements.Adult_Outpatient_Visit
                              ,PRIME80Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
                              ,PRIME80Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
                              ,PRIME80Elements.Home_Healthcare_Services
                              ,PRIME80Elements.Office_Visit
                      )
      && wasDiagnosisStartsBeforeEndPriorToXMonths(visit,m,PRIME80Elements.Diabetes,24,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  -Patients who use hospice services or elect to use a hospice benefit any time during the measurement year, regardless
 	 of when the services began.
  -A diagnosis of polycystic ovaries, in any setting, any time in the patient’s history through December 31 of the
   measurement year, or
  -A diagnosis of gestational or steroid-induced diabetes, in any setting, during the measurement year or the year prior
   to the measurement year.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
         isInterventionPerformedInHistory(visit,m,PRIME80Elements.Hospice_Services_Snomedct,patientHistoryBroadcastList)
      || wasDiagnosedInHistory(visit,m,PRIME80Elements.Polycystic_Ovaries,patientHistoryBroadcastList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients whose most recent blood pressure level was <140/90 mm Hg during the measurement year.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      isDiastolicBPSystolicBPPerformedOnEncounter(visit,m,PRIME80Elements.Systolic_Blood_Pressure,PRIME80Elements.Diastolic_Blood_Pressure,PRIME80Elements.Systolic_Blood_Pressure_Date,PRIME80Elements.Diastolic_Blood_Pressure_Date,90.0,140)

    )
  }


}