package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty,AUGS2Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Augs2
* Measure Title               :- Preoperative pessary for Pelvic Organ Prolapse attempted by patient
* Measure Description         :- The percentage of patients who have attempted pessary placement or the treatment of pelvic organ prolapse prior to surgical intervention.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.RASURE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/

object Augs2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Augs2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,AUGS2Elements.Surgery_For_Pop,
      AUGS2Elements.Pessary_Placement
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population : All patients undergoing pelvic organ prolapse (POP) surgery.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
           isFemale(visit,m)
        && isProcedurePerformed(visit,m,AUGS2Elements.Surgery_For_Pop,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exclusions : Patients requiring surgery for a gynecologic condition who also have concurrent prolapse surgery.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
          isProcedurePerformedDuringProcedure(visit,m,AUGS2Elements.Gynecologic_Or_Pelvic_Malignancy_Surgery,AUGS2Elements.Gynecologic_Or_Pelvic_Malignancy_Surgery_Date,AUGS2Elements.Surgery_For_Pop,AUGS2Elements.Surgery_For_Pop_Date)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator : The number of patients that who have attempted pessary placement for the treatment of pelvic organ prolapse prior to surgical intervention.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
          wasDeviceAppliedBeforeStartofProcedure(visit,m,AUGS2Elements.Surgery_For_Pop,patientHistoryBroadcastList,AUGS2Elements.Pessary_Placement)
    )
  }


}