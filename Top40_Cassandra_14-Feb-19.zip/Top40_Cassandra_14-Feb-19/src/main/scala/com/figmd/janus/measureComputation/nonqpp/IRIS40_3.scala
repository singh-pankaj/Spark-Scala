package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, IRIS40Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS40_3
* Measure Title               :- Regaining Vision After Cataract Surgery
* Measure Description         :- Percentage of patients aged 18 years and older with a diagnosis of cataract who had cataract surgery and 20/20 best-corrected distance visual acuity
                                 OR an improvement in best-corrected distance visual acuity within 30 days following the cataract surgery.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 3
* Measure Stratum No.         :- 3
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS40_3 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS40_3"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
                ,IRIS40Elements.Visual_Acuity
                ,IRIS40Elements.Visual_Acuity_Eye
                ,IRIS40Elements.Snellen_Lines
                ,IRIS40Elements.Snellen_Lines__Eye
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients aged 18 years and older with a diagnosis of cataract who had cataract surgeryPatients aged 18 y
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val filteredRDD = getPatientRDDBetweenPeriodsInMeasurementPeriod(initialRDD, m, CalenderUnit.MONTH, 11, true)

    filteredRDD.filter(
      visit =>
            isPatientAdult(visit,m)
        &&  isPhysicalExamPerformedwithValueBeforeProcedure(visit,m,IRIS40Elements.Cataract_Surgery,1.30,CompareOperator.GREATER_EQUAL,patientHistoryBroadcastList,IRIS40Elements.Visual_Acuity)
        &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS40Elements.Cataract_Surgery_Eye,patientHistoryBroadcastList,Seq(IRIS40Elements.Visual_Acuity_Eye))
        &&  isProcedurePerformedDuringEncounter(visit,m,IRIS40Elements.Cataract_Surgery)
        && ! isProcedurePerformedDuringEncounter(visit,m,IRIS40Elements.Cataract_Surgery_Modifiers)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with high risk combined cataract surgery and glaucoma surgery procedures.Patients with high ris
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            isProcedurePerformedDuringProcedure(visit,m,IRIS40Elements.Cataract_Surgery,IRIS40Elements.Cataract_Surgery_Date,IRIS40Elements.Glaucoma_Surgery,IRIS40Elements.Glaucoma_Surgery_Date)
        &&  checkEyeElementsInRange(visit,m,IRIS40Elements.Cataract_Surgery_Eye,IRIS40Elements.Glaucoma_Surgery__Eye)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with comorbidities with a pre-operative visual acuity of 20/400 or worse and a 1 line or better improvement in the post-operative
best-corrected distance visual acuity from pre-operative visual acuity
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
            isProcedurePerformedDuringProcedure(visit,m,IRIS40Elements.Cataract_Surgery,IRIS40Elements.Cataract_Surgery_Date,IRIS40Elements.Comorbidities_,IRIS40Elements.Comorbidities__Date)
        &&  checkEyeElementsInRange(visit,m,IRIS40Elements.Cataract_Surgery_Eye,IRIS40Elements.Comorbidities_Eye)
        &&  wasPhysicalExamValueAfterPhysicalExamWithInXDays(visit,m,IRIS40Elements.Visual_Acuity_Date,IRIS40Elements.Snellen_Lines,30,1,CompareOperator.GREATER_EQUAL,patientHistoryBroadcastList)
        &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS40Elements.Cataract_Surgery_Eye,patientHistoryBroadcastList,Seq(IRIS40Elements.Snellen_Lines__Eye))
    )
  }

}