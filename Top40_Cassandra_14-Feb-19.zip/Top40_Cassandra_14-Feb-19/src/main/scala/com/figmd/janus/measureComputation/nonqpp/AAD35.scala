package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, AAD35Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD 35
* Measure Title              :- Biopsy: Use of Biopsy Site Photos or Directional Diagrams Prior to Surgery
* Measure Description        :- Proportion of biopsies by the clinician consistent with a cutaneous basal cell carcinoma
                                or squamous cell carcinoma (to include in situ disease) for whom a biopsy site photo or
                                detailed directional diagram was made available to the operating provider (may be the
                                same as the biopsying provider) prior to surgery.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object AAD35 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "AAD35"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      AAD35Elements.Cutaneous_Scc_Or_Bcc,
      AAD35Elements.Referral_To_Operating_Provider,
      AAD35Elements.Destruction_Of_Malignant_Lesion,
      AAD35Elements.Surgical_Treatment_For_Cutaneous_Scc_Or_Bcc,
      AAD35Elements.Excision_Grp,
      AAD35Elements.Mohs_Microscopic_Technique,
      AAD35Elements.Referral_To_Operating_Provider,
      AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,
      AAD35Elements.Biopsy_Tracking_System,
      AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }



  /*------------------------------------------------------------------------------------------------
   All cutaneous biopsies by the clinician consistent with cutaneous basal or squamous cell carcinoma (including in situ
    disease) that the clinician treated with an excision, electrodesiccation, curettage, cryosurgery, or Mohs surgery,
    or referred to another clinician to perform one of these procedures.
  ------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isProcedurePerformedDuringEncounter(visit,m,AAD35Elements.Cutaneous_Biopsy_Grp)
        && wasDiagnosedAfterProcedure(visit,m,AdminElements.Encounter_Date,patientHistoryList,AAD35Elements.Cutaneous_Scc_Or_Bcc)
        &&
        (
          wasAssessmentPerformedAfterDiagnosis(visit,m,AAD35Elements.Cutaneous_Scc_Or_Bcc,patientHistoryList,AAD35Elements.Referral_To_Operating_Provider)
            || wasAssessmentPerformedAfterDiagnosis(visit,m,AAD35Elements.Cutaneous_Scc_Or_Bcc,patientHistoryList,AAD35Elements.Destruction_Of_Malignant_Lesion)
            || wasAssessmentPerformedAfterDiagnosis(visit,m,AAD35Elements.Cutaneous_Scc_Or_Bcc,patientHistoryList,AAD35Elements.Surgical_Treatment_For_Cutaneous_Scc_Or_Bcc)
            || wasAssessmentPerformedAfterDiagnosis(visit,m,AAD35Elements.Cutaneous_Scc_Or_Bcc,patientHistoryList,AAD35Elements.Excision_Grp)
            || wasAssessmentPerformedAfterDiagnosis(visit,m,AAD35Elements.Cutaneous_Scc_Or_Bcc,patientHistoryList,AAD35Elements.Mohs_Microscopic_Technique)
          )
    )
  }


  /*------------------------------------------------------------------------------------------------
   Number of cutaneous biopsies by the clinician consistent with basal cell carcinoma or squamous cell carcinoma (to include
   in situ disease) that the clinician treated with an excision, electrodesiccation, curettage, cryosurgery or Mohs surgery,
   or referred to another clinician to perform one of these procedures for which a biopsy site photo or detailed
   directional diagram was made available to the operating provider prior to surgical treatment for use in his or her
   pre-op evaluation.
   ------------------------------------------------------------------------------------------------*/

  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      (
        wasCommunicationFromProviderToProviderwithSourceAfterEncounter(visit,m,AAD35Elements.Cutaneous_Biopsy_Grp,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Biopsy_Tracking_System,patientHistoryList)
          ||  wasCommunicationFromProviderToProviderwithSourceAfterEncounter(visit,m,AAD35Elements.Cutaneous_Biopsy_Grp,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram,patientHistoryList)
        )
        &&
        (
          wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Referral_To_Operating_Provider,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Biopsy_Tracking_System,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Referral_To_Operating_Provider,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Destruction_Of_Malignant_Lesion,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Biopsy_Tracking_System,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Destruction_Of_Malignant_Lesion,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Surgical_Treatment_For_Cutaneous_Scc_Or_Bcc,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Biopsy_Tracking_System,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Surgical_Treatment_For_Cutaneous_Scc_Or_Bcc,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Excision_Grp,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Biopsy_Tracking_System,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Excision_Grp,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Mohs_Microscopic_Technique,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Biopsy_Tracking_System,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Mohs_Microscopic_Technique,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram,patientHistoryList)

          )
    )
  }

}
