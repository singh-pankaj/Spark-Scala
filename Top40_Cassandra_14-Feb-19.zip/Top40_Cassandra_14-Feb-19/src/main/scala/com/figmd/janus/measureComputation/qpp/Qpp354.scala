
package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP354Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 354
* Measure Title              :- Anastomotic Leak Intervention
* Measure Description        :- Percentage of patients aged 18 years and older who required an anastomotic leak intervention
                                following gastric bypass or colectomy surgery.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp354 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp354"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP354Elements.Gastric_Bypass_Or_Colectomy_Surgery
      , QPP354Elements.Anastomotic_Leak
      , QPP354Elements.Presence_Of_Anastomotic_Leak
      , QPP354Elements.Presence_Of_Anastomotic_Leak
      , QPP354Elements.Anastomotic_Leak__Not_Met).collect.toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

/*-------------------------------------------------------------------------------------------------------------------------
Patients aged 18 years and older undergoing gastric bypass or colectomy surgery.
----------------------------------------------------------------------------------------------------------------------------*/

  // Filter IPP
  def getIpp(initialRDD:RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
          isPatientAdult(visit,m)
      &&  wasProcedurePerformedAfterStartWithInXMonths(visit,m,QPP354Elements.Gastric_Bypass_Or_Colectomy_Surgery,11,"MONTH",patientHistoryBroadcastList)
    )
  }

/*-------------------------------------------------------------------------------------------------------------------------
Intervention (via return to operating room, interventional radiology, or interventional gastroenterology) for presence of leak
of endoluminal contents (such as air, fluid, GI contents, or contrast material) through an anastomosis.
The presence of an infection/abscess thought to be related to an anastomosis, even if the leak cannot be definitively
identified as visualized during an operation, or by contrast extravasation would also be considered an anastomotic leak.
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(denominatorRDD: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    denominatorRDD.filter(visit =>
      (   wasInterventionAdverseEventAfterProcedureWithInXDays(visit,m,QPP354Elements.Gastric_Bypass_Or_Colectomy_Surgery,QPP354Elements.Anastomotic_Leak,30,patientHistoryBroadcastList)
      ||  wasInterventionAdverseEventAfterProcedureWithInXDays(visit,m,QPP354Elements.Gastric_Bypass_Or_Colectomy_Surgery,QPP354Elements.Presence_Of_Anastomotic_Leak,30,patientHistoryBroadcastList)
      ||  wasEncounterPerformedWithReasonAfterProcedureWithInXDays(visit,m,QPP354Elements.Gastric_Bypass_Or_Colectomy_Surgery,QPP354Elements.Presence_Of_Anastomotic_Leak,QPP354Elements.Anastomotic_Leak,30,"DAY",patientHistoryBroadcastList)
      )
      && ! wasInterventionAdverseEventAfterProcedureWithInXDays(visit,m,QPP354Elements.Gastric_Bypass_Or_Colectomy_Surgery,QPP354Elements.Anastomotic_Leak__Not_Met,30,patientHistoryBroadcastList)
   )
  }
}
