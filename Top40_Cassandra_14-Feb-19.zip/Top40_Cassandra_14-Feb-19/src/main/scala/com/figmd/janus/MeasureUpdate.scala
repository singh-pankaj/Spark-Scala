package com.figmd.janus

import com.datastax.spark.connector.CassandraRow
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SparkSession}

trait MeasureUpdate {
    def refresh(sparkSession: SparkSession,rdd:RDD[CassandraRow]): Unit
  }
trait MeasureUpdate1 {
  def refresh(sparkSession: SparkSession,rdd:RDD[CassandraRow],patientList:Array[String]): Unit
}