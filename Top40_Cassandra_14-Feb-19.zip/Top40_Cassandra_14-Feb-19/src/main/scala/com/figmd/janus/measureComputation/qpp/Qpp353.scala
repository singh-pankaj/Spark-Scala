package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP353Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 353
* Measure Title              :- Total Knee Replacement: Identification of Implanted Prosthesis in Operative Report
* Measure Description        :- Percentage of patients regardless of age undergoing a total knee replacement whose operative report identifies the prosthetic implant specifications including the prosthetic implant manufacturer, the brand name of the prosthetic implant and the size of each prosthetic implant
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp353 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp353"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP353Elements.Total_Knee_Replacement,
      QPP353Elements.Prosthetic_Implant_Specifications,
      QPP353Elements.Prosthetic_Implant_Brand_Name,
      QPP353Elements.Prosthetic_Implant_Size,
      QPP353Elements.Prosthetic_Implant_Manufacturer,
      QPP353Elements.Prosthetic_Implant_Reason_Not_Specified
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }


  // IPP-Denominator criteria
  /* All patients regardless of age undergoing a total knee replacement */
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isProcedurePerformedDuringEncounter(visit, m, QPP353Elements.Total_Knee_Replacement)

    )
  }


  // Numerator criteria
  /* Patients whose operative report identifies the prosthetic implant specifications including the prosthetic implant manufacturer, the brand name of the prosthetic implant and the size of each prosthetic implant */
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      (
        isInterventionPerformed(visit, m, QPP353Elements.Prosthetic_Implant_Specifications, patientHistoryBroadcastList)
          ||
          (isInterventionPerformedAfterProcedure(visit, m, QPP353Elements.Total_Knee_Replacement, QPP353Elements.Prosthetic_Implant_Size, patientHistoryBroadcastList)
            && isInterventionPerformedAfterProcedure(visit, m, QPP353Elements.Total_Knee_Replacement, QPP353Elements.Prosthetic_Implant_Brand_Name, patientHistoryBroadcastList)
            && isInterventionPerformedAfterProcedure(visit, m, QPP353Elements.Total_Knee_Replacement, QPP353Elements.Prosthetic_Implant_Manufacturer, patientHistoryBroadcastList)
            )
        )
        && !isInterventionPerformed(visit, m, QPP353Elements.Prosthetic_Implant_Reason_Not_Specified, patientHistoryBroadcastList)
    )
  }


}
