package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,AQUA24Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AQUA24
* Measure Title               :- Testosterone and PSA levels checked for CRPC patients
* Measure Description         :- Percentage of patients on hormonal therapy who have their testosterone and PSA levels checked before starting treatment for CRPC
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- PRIYANKA CHAVAN
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/

object AQUA24 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "AQUA24"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,AQUA24Elements.Advanced_Prostate_Cancer
      ,AQUA24Elements.Adt
      ,AQUA24Elements.Adt_Md_Notes
      ,AQUA24Elements.Testosterone_Level_Test
      ,AQUA24Elements.Testosterone_Level_Test_Result
      ,AQUA24Elements.Documentation_Of_Psa
      ,AQUA24Elements.Documentation_Of_Psa_In_Md_Notes
      ,AQUA24Elements.Prostate_Specific_Antigen
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Patients with advanced prostate cancer on hormonal
   -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
             isMale(visit,m)
        &&   wasDiagnosedInHistory(visit,m,AQUA24Elements.Advanced_Prostate_Cancer,patientHistoryBroadcastList)
        &&   (
                    wasProcedurePerformedAfterDiagnosisInHistory(visit,m,AQUA24Elements.Adt,patientHistoryBroadcastList,AQUA24Elements.Advanced_Prostate_Cancer)
               ||   wasProcedurePerformedAfterDiagnosisInHistory(visit,m,AQUA24Elements.Adt_Md_Notes,patientHistoryBroadcastList,AQUA24Elements.Advanced_Prostate_Cancer)
             )
        &&   (
                    wasProcedurePerformedBeforeEndInXDays(visit,m,AQUA24Elements.Adt,275,patientHistoryBroadcastList)
               ||   wasProcedurePerformedBeforeEndInXDays(visit,m,AQUA24Elements.Adt_Md_Notes,275,patientHistoryBroadcastList)
             )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Patients who have their testosterone and PSA levels checked 90 days before starting treatment for CRPC
   ------------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        (
                 isLaboratoryTestPerformedBeforeWithinXDays(visit,m,AQUA24Elements.Testosterone_Level_Test,AQUA24Elements.Adt,90,patientHistoryBroadcastList)
            ||   isLaboratoryTestPerformedBeforeWithinXDays(visit,m,AQUA24Elements.Testosterone_Level_Test_Result,AQUA24Elements.Adt,90,patientHistoryBroadcastList)
            ||   isLaboratoryTestPerformedBeforeWithinXDays(visit,m,AQUA24Elements.Testosterone_Level_Test,AQUA24Elements.Adt_Md_Notes,90,patientHistoryBroadcastList)
            ||   isLaboratoryTestPerformedBeforeWithinXDays(visit,m,AQUA24Elements.Testosterone_Level_Test_Result,AQUA24Elements.Adt_Md_Notes,90,patientHistoryBroadcastList)
        )
        &&
        (
                 isLaboratoryTestPerformedBeforeWithinXDays(visit,m,AQUA24Elements.Documentation_Of_Psa,AQUA24Elements.Adt,90,patientHistoryBroadcastList)
            ||   isLaboratoryTestPerformedBeforeWithinXDays(visit,m,AQUA24Elements.Documentation_Of_Psa_In_Md_Notes,AQUA24Elements.Adt,90,patientHistoryBroadcastList)
            ||   isLaboratoryTestPerformedBeforeWithinXDays(visit,m,AQUA24Elements.Documentation_Of_Psa,AQUA24Elements.Adt_Md_Notes,90,patientHistoryBroadcastList)
            ||   isLaboratoryTestPerformedBeforeWithinXDays(visit,m,AQUA24Elements.Documentation_Of_Psa_In_Md_Notes,AQUA24Elements.Adt_Md_Notes,90,patientHistoryBroadcastList)
            ||   isLaboratoryTestPerformedBeforeWithinXDays(visit,m,AQUA24Elements.Prostate_Specific_Antigen,AQUA24Elements.Adt,90,patientHistoryBroadcastList)
            ||   isLaboratoryTestPerformedBeforeWithinXDays(visit,m,AQUA24Elements.Prostate_Specific_Antigen,AQUA24Elements.Adt_Md_Notes,90,patientHistoryBroadcastList)
        )
    )
  }

}
