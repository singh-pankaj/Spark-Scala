package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Qpp331
* Measure Title               :- Adult Sinusitis: Antibiotic Prescribed for Acute Viral Sinusitis (Overuse)
* Measure Description         :- Percentage of patients, aged 18 years and older, with a diagnosis of acute viral sinusitis who were prescribed an antibiotic within 10 days after onset of symptoms
* Calculation Implementation  :- Episode-specific
* Improvement Notation        :- Lower Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.RASURE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.8
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp331 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp331"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,QPP331Elements.Antibiotics_Prescribed,
      QPP331Elements.Antibiotics,
      QPP331Elements.Brain_Abscess,
      QPP331Elements.Periorbital_Abscess,
      QPP331Elements.Antibiotics_Not_Met,
      QPP331Elements.Antibiotics_Medical_Reason
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population :All patients aged 18 years and older with a diagnosis of acute sinusitis
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
           isPatientAdult(visit,m)
        && isVisitTypeIn(visit,m,QPP331Elements.Office_Visit,
             QPP331Elements.Home_Healthcare_Services,
             QPP331Elements.Nursing_Facility_Visit,
             QPP331Elements.Emergency_Department_Visit,
             QPP331Elements.Care_Services_In_Long_Term_Residential_Facility_Gp
           )
        && isDiagnosedOnEncounter(visit,m,QPP331Elements.Acute_Sinusitis)
        && ! isTeleHealthEncounterPerformed(visit,m,QPP331Elements.Office_Visit_Telehealth_Modifier,
             QPP331Elements.Home_Healthcare_Services_Telehealth_Modifier,
             QPP331Elements.Nursing_Facility_Visit_Telehealth_Modifier,
             QPP331Elements.Emergency_Department_Visit_Telehealth_Modifier,
             QPP331Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
           )
        && isPOSEncounterNotPerformed(visit,m,QPP331Elements.Pos_02)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator :Patients prescribed any antibiotic within 10 days after onset of symptoms
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
          (
               isAssessmentPerformed(visit,m,QPP331Elements.Antibiotics_Prescribed,patientHistoryBroadcastList)
            || wasMedicationOrderedAfterDiagnosisInXDays(visit,m,QPP331Elements.Acute_Sinusitis,QPP331Elements.Antibiotics,10,patientHistoryBroadcastList)
          )
      && ! isAssessmentPerformed(visit,m,QPP331Elements.Antibiotics_Not_Met,patientHistoryBroadcastList)
      && ! (
               wasMedicationOrderedWithReasonAfterDiagnosisInXDays(visit,m,QPP331Elements.Acute_Sinusitis,QPP331Elements.Antibiotics,10,CalenderUnit.DAY,CompareOperator.LESS_EQUAL,QPP331Elements.Brain_Abscess,patientHistoryBroadcastList)
            || wasMedicationOrderedWithReasonAfterDiagnosisInXDays(visit,m,QPP331Elements.Acute_Sinusitis,QPP331Elements.Antibiotics,10,CalenderUnit.DAY,CompareOperator.LESS_EQUAL,QPP331Elements.Periorbital_Abscess,patientHistoryBroadcastList)
           )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exceptions :Antibiotic regimen prescribed within 10 days after onset of symptoms for documented medical reason
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
          isAssessmentPerformed(visit,m,QPP331Elements.Antibiotics_Medical_Reason,patientHistoryBroadcastList)
        || (
               wasMedicationOrderedWithReasonAfterDiagnosisInXDays(visit,m,QPP331Elements.Acute_Sinusitis,QPP331Elements.Antibiotics,10,CalenderUnit.DAY,CompareOperator.LESS_EQUAL,QPP331Elements.Brain_Abscess,patientHistoryBroadcastList)
            || wasMedicationOrderedWithReasonAfterDiagnosisInXDays(visit,m,QPP331Elements.Acute_Sinusitis,QPP331Elements.Antibiotics,10,CalenderUnit.DAY,CompareOperator.LESS_EQUAL,QPP331Elements.Periorbital_Abscess,patientHistoryBroadcastList)
          )

    )
  }
}