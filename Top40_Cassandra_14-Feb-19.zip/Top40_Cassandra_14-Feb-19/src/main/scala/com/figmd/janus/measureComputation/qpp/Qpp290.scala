package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP290Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 290
* Measure Title              :- Parkinson’s Disease: Psychiatric Symptoms Assessment for Patients with Parkinson’s Disease
* Measure Description        :- Percentage of all patients with a diagnosis of Parkinson’s Disease [PD] who were assessed
*                               for psychiatric symptoms in the past 12 months
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp290 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "QPP290"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val patientHistoryList = getPatientHistory(sparkSession, ippRDD,
        QPP290Elements.Assessment_Of_Psychiatric_Symptoms,
        QPP290Elements.Assessment_Of_Psychiatric_Symptoms_Kw,
        QPP290Elements.Impulse_Control_Disorder,
        QPP290Elements.Depression,
        QPP290Elements.Anxiety_Disorder,
        QPP290Elements.Psychosis,
        QPP290Elements.Apathy,
        QPP290Elements.Psychiatric_Symptoms_Reason_Not_Specified
      ).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()


      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter exceptionRDD
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Not Met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // Denominator Exclusion criteria
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isVisitTypeIn(visit, m
        , QPP290Elements.Office_Visit
        , QPP290Elements.Nursing_Facility_Visit
        , QPP290Elements.Inpatient_Consultation
        , QPP290Elements.Discharge_Services___Hospital_Inpatient
        , QPP290Elements.Hospital_Inpatient_Visit___Initial
        , QPP290Elements.Hospital_Inpatient_Visit_Subsequent)
        && isDiagnosedOnEncounter(visit, m, QPP290Elements.Parkinson_s_Disease)
        && !isTeleHealthModifier(visit, m
        , QPP290Elements.Office_Visit_Telehealth_Modifier
        , QPP290Elements.Nursing_Facility_Visit_Telehealth_Modifier
        , QPP290Elements.Inpatient_Consultation_Telehealth_Modifier
        , QPP290Elements.Discharge_Services___Hospital_Inpatient_Telehealth_Modifier
        , QPP290Elements.Hospital_Inpatient_Visit___Initial_Telehealth_Modifier
        , QPP290Elements.Hospital_Inpatient_Visit_Subsequent_Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP290Elements.Pos_02)

    )

  }


  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        (
          wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP290Elements.Assessment_Of_Psychiatric_Symptoms, 12, patientHistoryBroadcastList)
            || wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP290Elements.Assessment_Of_Psychiatric_Symptoms_Kw, 12, patientHistoryBroadcastList)
          )
          ||
          (
            wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP290Elements.Impulse_Control_Disorder, 12, patientHistoryBroadcastList)
              && wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP290Elements.Depression, 12, patientHistoryBroadcastList)
              && wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP290Elements.Anxiety_Disorder, 12, patientHistoryBroadcastList)
              && wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP290Elements.Psychosis, 12, patientHistoryBroadcastList)
              && wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP290Elements.Apathy, 12, patientHistoryBroadcastList)
            )
        )
        && !wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP290Elements.Psychiatric_Symptoms_Reason_Not_Specified, 12, patientHistoryBroadcastList)

    )
  }

}
