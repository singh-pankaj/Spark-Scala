package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP111Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 111
* Measure Title              :- Pneumococcal Vaccination Status for Older Adults
* Measure Description        :- Percentage of patients 65 years of age and older who have ever received a pneumococcal vaccine
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp111  extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp111"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP


    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //getPatientHistoryList
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        QPP111Elements.Hospice_Services,
        QPP111Elements.Hospice_Services_Snomedct,
        QPP111Elements.Hospice_Care,
        QPP111Elements.Pneumococcal_Vaccine_2,
        QPP111Elements.Pneumococcal_Vaccine_Administered,
        QPP111Elements.History_Of_Pneumococcal_Vaccine,
        QPP111Elements.Pneumococcal_Vaccine_1,
        QPP111Elements.Pneumococcal_Vaccination).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      //    metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()
      //
      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
      isPatientElderly(visit, m)
        &&
        isVisitTypeIn(visit, m,
          QPP111Elements.Office_Visit,
          QPP111Elements.Face_To_Face_Interaction,
          QPP111Elements.Annual_Wellness_Visit,
          QPP111Elements.Home_Healthcare_Services,
          QPP111Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
          QPP111Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
          QPP111Elements.Initial_Preventive_Physical_Examination)
    )
  }



  // Denominator Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      isInterventionPerformed(visit, m, QPP111Elements.Hospice_Services, patientHistoryBroadcastList)
        ||
        wasInterventionPerformedOrOrderedInHistory(visit, m, QPP111Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
        ||
        wasInterventionPerformedOrOrderedInHistory(visit, m, QPP111Elements.Hospice_Care, patientHistoryBroadcastList)
    )
  }


  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      (
        wasImmunizationAdministeredInHistory(visit, m, QPP111Elements.Pneumococcal_Vaccine_2, patientHistoryBroadcastList)
          ||
          wasProcedurePerformedInHistory(visit, m, QPP111Elements.Pneumococcal_Vaccine_Administered, patientHistoryBroadcastList)
          ||
          wasImmunizationAdministeredInHistory(visit, m, QPP111Elements.Pneumococcal_Vaccine_1, patientHistoryBroadcastList)
          ||
          wasImmunizationAdministeredInHistory(visit, m, QPP111Elements.History_Of_Pneumococcal_Vaccine, patientHistoryBroadcastList)
          ||
          wasImmunizationAdministeredInHistory(visit, m, QPP111Elements.Pneumococcal_Vaccination, patientHistoryBroadcastList)
        )
        && !isImmunizationAdministeredDuringEncounter(visit,m, QPP111Elements.Pneumococcal_Vaccine_Reason_Not_Specified)
    )
  }

}
