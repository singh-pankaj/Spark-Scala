package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP181Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*--------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 181
* Measure Title              :- Elder Maltreatment Screen and Follow-Up Plan
* Measure Description        :- Percentage of patients aged 65 years and older with a documented elder maltreatment screen using
                                an Elder Maltreatment Screening tool on the date of encounter AND a documented follow-up plan on the date of the positive screen
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp181 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp181"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {




    //  Filter IPP--
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Backtracking List-
      val patientHistoryList = getPatientHistory(sparkSession,ippRDD,
        QPP181Elements.Elder_Maltreatment_Screening,
        QPP181Elements.Elder_Maltreatment_Screen_Not_Met,
        QPP181Elements.Elder_Maltreatment_Screen_Ineligible).collect.toList;

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateB = getSubtractRDD(ippRDD, metRDD)
      intermediateB.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateB, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : All patients aged 65 years and older
----------------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true,65)
        && isVisitTypeIn(visit, m, QPP181Elements.Annual_Nursing_Facility_Assessment,
        QPP181Elements.Occupational_Therapy_Function,
        QPP181Elements.Initial_Preventive_Physical_Examination,
        QPP181Elements.Psych_Visit___Diagnostic_Evaluation,
        QPP181Elements.Psych_Visit___Psychotherapy,
        QPP181Elements.Health___Behavioral_Assessment___Individual,
        QPP181Elements.Health_And_Behavioral_Assessment___Initial,
        QPP181Elements.Health_And_Behavioral_Assessment__Reassessment,
        QPP181Elements.Medical_Nutrition_Therapy,
        QPP181Elements.Annual_Wellness_Visit,
        QPP181Elements.Neurobehavior_Status,
        QPP181Elements.Home_Healthcare_Services,
        QPP181Elements.Care_Services_In_Long_Term_Residential_Facility,
        QPP181Elements.Nursing_Facility_Visit,
        QPP181Elements.Office_Visit,
        QPP181Elements.Cervical_Or_Vaginal_Cancer_Screening,
        QPP181Elements.Psychiatric_Care_Management,
        QPP181Elements.Cognitive_Impairment_Assessment,
        QPP181Elements.Prostate_Cancer_Screening
      )
        && !isTeleHealthEncounterPerformed(visit, m, QPP181Elements.Neurobehavior_Status_Telehealth_Modifier,
        QPP181Elements.Health_And_Behavioral_Assessment___Individual_Telehealth_Modifier,
        QPP181Elements.Health_And_Behavioral_Assessment_Reassessment_Telehealth_Modifier,
        QPP181Elements.Annual_Wellness_Visit_Telehealth_Modifier,
        QPP181Elements.Initial_Preventive_Physical_Examination_Telehealth_Modifier,
        QPP181Elements.Home_Healthcare_Services_Telehealth_Modifier,
        QPP181Elements.Nursing_Facility_Visit_Telehealth_Modifier,
        QPP181Elements.Office_Visit_Telehealth_Modifier,
        QPP181Elements.Medical_Nutrition_Therapy_Telehealth_Modifier,
        QPP181Elements.Occupational_Therapy_Evaluation_Telehealth_Modifier,
        QPP181Elements.Health_And_Behavioral_Assessment__Initial_Telehealth_Modifier,
        QPP181Elements.Psych_Visit___Psychotherapy_Telehealth_Modifier,
        QPP181Elements.Psych_Visit___Diagnostic_Evaluation_Telehealth_Modifier,
        QPP181Elements.Evaluation_And_Management__Telehealth_Modifier,
        QPP181Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier,
        QPP181Elements.Cervical_Or_Vaginal_Cancer_Screening_Telehealth_Modifier,
        QPP181Elements.Psychiatric_Care_Management_Telehealth_Modifier,
        QPP181Elements.Cognitive_Impairment_Assessment_Telehealth_Modifier,
        QPP181Elements.Prostate_Cancer_Screening_Telehealth_Modifier
      )
        && isPOSEncounterNotPerformed(visit,m,QPP181Elements.Pos_02)
    )

  }



  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Patients with a documented elder maltreatment screen using an Elder Maltreatment Screening tool on the date of the encounter
and follow-up plan documented on the date of the positive screen.
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    ipp.filter(visit =>
      (    isInterventionPerformed(visit,m,QPP181Elements.Elder_Maltreatment_Screening,patientHistoryBroadcastList)
        || (isInterventionPerformedDuringEncounter(visit,m,QPP181Elements.Elder_Maltreatment_Screen_Follow_Up_Plan)
        && isInterventionPerformedWithResultDuringEncounter(visit,m,QPP181Elements.Elder_Maltreatment_Screening_Tool,QPP181Elements.Elder_Maltreatment_Screen_Positive)
        )
        || (isInterventionPerformedDuringEncounter(visit,m,QPP181Elements.Elder_Maltreatment_Screen_Follow_Up_Plan)
        && (isInterventionPerformedWithResultDuringEncounter(visit,m,QPP181Elements.Neglect,QPP181Elements.Elder_Maltreatment_Screen_Positive)
        || isInterventionPerformedWithResultDuringEncounter(visit,m,QPP181Elements.Sexual_Abuse,QPP181Elements.Elder_Maltreatment_Screen_Positive)
        || isInterventionPerformedWithResultDuringEncounter(visit,m,QPP181Elements.Physical_Abuse,QPP181Elements.Elder_Maltreatment_Screen_Positive)
        || isInterventionPerformedWithResultDuringEncounter(visit,m,QPP181Elements.Emotional_Or_Psychological_Abuse,QPP181Elements.Elder_Maltreatment_Screen_Positive)
        || isInterventionPerformedWithResultDuringEncounter(visit,m,QPP181Elements.Unwarranted_Control,QPP181Elements.Elder_Maltreatment_Screen_Positive)
        || isInterventionPerformedWithResultDuringEncounter(visit,m,QPP181Elements.Financial_Or_Material_Exploitation,QPP181Elements.Elder_Maltreatment_Screen_Positive)
        || isInterventionPerformedWithResultDuringEncounter(visit,m,QPP181Elements.Abandonment,QPP181Elements.Elder_Maltreatment_Screen_Positive)
        )
        )
        || isInterventionPerformedWithResultDuringEncounter(visit,m,QPP181Elements.Elder_Maltreatment_Screening_Tool,QPP181Elements.Elder_Maltreatment_Screen_Negative)
        )
        && !isInterventionNotDone(visit,m,QPP181Elements.Elder_Maltreatment_Screen_Not_Met,patientHistoryBroadcastList)

    )
  }

  /*--------------------------------------------------------------------------------------------------------------------------
Denominator Exceptions : Elder maltreatment screen not documented; documentation that patient is not eligible for the elder maltreatment screen at the time of the encounter.
OR
Elder maltreatment screen documented as positive, followup plan not documented, documentation the patient is not eligible for follow-up plan at the time of the encounter.
----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermediateRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermediateRDD.filter(visit =>
      isInterventionPerformed(visit,m,QPP181Elements.Elder_Maltreatment_Screen_Ineligible,patientHistoryBroadcastList)
        || isInterventionPerformedDuringIntervention(visit,m,QPP181Elements.Patient_Refusal,QPP181Elements.Elder_Maltreatment_Screening_Tool)
        || isInterventionPerformedDuringIntervention(visit,m,QPP181Elements.Urgent_Or_Emergent_Medical_Situation,QPP181Elements.Elder_Maltreatment_Screening_Tool)
    )
  }
}
