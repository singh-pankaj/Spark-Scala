package com.figmd.janus.measureComputation.ecqm


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ECQM 161
* Measure Title              :- Adult Major Depressive Disorder (MDD): Suicide Risk Assessment
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of major depressive disorder (MDD) with a suicide risk assessment completed during the visit in which a new diagnosis or recurrent episode was identified
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- NA
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm161V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "ECQM161V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val getPatientHistoryList = getPatientHistory(sparkSession, initialRDD, ECQM161V7Elements.Major_Depressive_Disorder_Active)
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }


  /* All patients aged 18 years and older with a diagnosis of major depressive disorder (MDD) */

  def getIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isAgeAbove(visit, m, true, 17)
        && isVisitTypeIn(visit, m, ECQM161V7Elements.Psych_Visit___Diagnostic_Evaluation,
        ECQM161V7Elements.Psych_Visit___Psychotherapy,
        ECQM161V7Elements.Emergency_Department_Visit,
        ECQM161V7Elements.Office_Visit,
        ECQM161V7Elements.Outpatient_Consultation,
        ECQM161V7Elements.Psychoanalysis
      )
        && !wasCurrentElementDiagnosisPreviouslyDiagniosedWithinXDays(visit, m, ECQM161V7Elements.Major_Depressive_Disorder_Active, 105, patientHistoryList)
    )
  }

  /* Patients with a suicide risk assessment completed during the visit in which a new diagnosis or recurrent episode was identified  */

  def getMet(denominatorRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit => isInterventionPerformedOnEncounter(visit, m, ECQM161V7Elements.Suicide_Risk_Assessment)

    )
  }


}