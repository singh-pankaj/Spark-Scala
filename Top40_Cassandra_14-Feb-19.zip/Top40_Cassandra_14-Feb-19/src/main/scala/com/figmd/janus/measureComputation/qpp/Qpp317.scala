package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP317Elements, _}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.util.measure.MeasureUtilityUpdate

object Qpp317 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp317"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession,initialRDD,
      QPP317Elements.Bp_Screening_Encounter_Codes,
          QPP317Elements.Hypertension,
      QPP317Elements.Diastolic_Blood_Pressure,
      QPP317Elements.Systolic_Blood_Pressure,
      QPP317Elements.Referral_To_Alternative_Provider___Primary_Care_Provider,
      QPP317Elements.Finding_Of_Hypertension,
      QPP317Elements.Lifestyle_Recommendation,
      QPP317Elements.Weight_Reduction_Recommended,
      QPP317Elements.Dietary_Recommendations,
      QPP317Elements.Physical_Activity_Recommendation,
      QPP317Elements.Moderation_Of_Etoh_Consumption_Recommendation,
      QPP317Elements.Anti_Hypertensive_Pharmacologic_Therapy,
      QPP317Elements.Laboratory_Tests_For_Hypertension,
      QPP317Elements.Ecg_12_Lead_Or_Study_Order,
      QPP317Elements.Normal_Blood_Pressure,
      QPP317Elements.Hypertensive_And_Pre_Hypertensive_Blood_Pressure_Follow_Up,
      QPP317Elements.Blood_Pressure_Documented,
      QPP317Elements.Patient_Reason_Refused,
      QPP317Elements.Follow_Up_For_Bp_Reason
    )

    val patientHistoryBrodcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val MostrecentpatientHistoryRDD=mostRecentPatientList(patientHistoryRDD,QPP317Elements.Bp_Screening_Encounter_Codes,

      QPP317Elements.Normal_Blood_Pressure,
      QPP317Elements.Hypertensive_And_Pre_Hypertensive_Blood_Pressure_Follow_Up,
      QPP317Elements.Blood_Pressure_Documented)

    val MostrecentpatientHistoryBrodcastList: Broadcast[List[CassandraRow]]=sparkSession.sparkContext.broadcast(MostrecentpatientHistoryRDD)




    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBrodcastList:Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBrodcastList)
      exclusionRDD.cache()

      val intermediateExclusion = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateExclusion.cache()

      val metRDD = getMet(intermediateExclusion,  patientHistoryBrodcastList,MostrecentpatientHistoryBrodcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateMet = getSubtractRDD(intermediateExclusion, metRDD)
      intermediateMet.cache()

      val exceptionRDD = getException(intermediateMet,patientHistoryBrodcastList)
      exceptionRDD.cache()

      // Filter not Mate
      val notMetRDD = getSubtractRDD(intermediateMet, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, sparkSession.sparkContext.emptyRDD, sparkSession.sparkContext.emptyRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      MostrecentpatientHistoryBrodcastList.destroy()
      patientHistoryBrodcastList.destroy()
    }
  }

  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBrodcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit,m)
      && isEncounterPerformed(visit, m, QPP317Elements.Bp_Screening_Encounter_Codes,patientHistoryBrodcastList)
      && !isTeleHealthModifier(visit, m,
                                      QPP317Elements.Emergency_Department_Visit_Telehealth_Modifier,
        QPP317Elements.Preventive_Care_Services___Established_Office_Visit_18_And_Up_Telehealth_Modifier,
        QPP317Elements.Preventive_Care_Services_Initial_Office_Visit_18_And_Up_Telehealth_Modifier,
        QPP317Elements.Extraction_Erupted_Tooth__Telehealth_Modifier,
        QPP317Elements.Cervical_Or_Vaginal_Cancer_Screening_Telehealth_Modifier,
        QPP317Elements.Initial_Preventive_Physical_Examination_Telehealth_Modifier,
        QPP317Elements.Annual_Wellness_Visit_Telehealth_Modifier,
        QPP317Elements.Psych_Visit___Diagnostic_Evaluation_Telehealth_Modifier,
        QPP317Elements.Ophthalmological_Services_Telehealth_Modifier,
        QPP317Elements.Office_Visit_Telehealth_Modifier,
        QPP317Elements.Nursing_Facility_Visit_Telehealth_Modifier,
        QPP317Elements.Evaluation_And_Management__Telehealth_Modifier,
        QPP317Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier,
        QPP317Elements.Home_Healthcare_Services_Telehealth_Modifier,
        QPP317Elements.Discharge_Services___Nursing_Facility_Telehealth_Modifier,
        QPP317Elements.Observation_Or_Inpatient_Hospital_Care_Telehealth,
        QPP317Elements.Rest_Home_Care_Services__Telehealth_Modifier)
      && isPOSEncounterNotPerformed(visit, m, QPP317Elements.Pos_02)
    )

  }

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryBrodcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow]= {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
          wasDiagnosedBeforeEncounter(visit, m,  QPP317Elements.Hypertension,patientHistoryBrodcastList)
      &&  isAssessmentPerformedDuringEncounter(visit,m,QPP317Elements.Active_Hypertension)
    )

  }



  def getMet(intermediateA: RDD[CassandraRow],patientHistoryBrodcastList: Broadcast[List[CassandraRow]],mostRecentPatientHistoryBrodcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow]={
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter( visit=>

        (
            (
                isMostRecentEncounterPerformedBeforePhysicalExamPerformed(visit, m, QPP317Elements.Diastolic_Blood_Pressure_Date, QPP317Elements.Bp_Screening_Encounter_Codes, mostRecentPatientHistoryBrodcastList)
            &&  isMostRecentEncounterPerformedBeforePhysicalExamPerformed(visit, m, QPP317Elements.Systolic_Blood_Pressure_Date, QPP317Elements.Bp_Screening_Encounter_Codes, mostRecentPatientHistoryBrodcastList)
            )
         &&
            (
                  (
                       wasPhysicalExamPerformedWithValueDuringMostRecentEncounter(visit,m,QPP317Elements.Systolic_Blood_Pressure,120,CompareOperator.LESS,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)
                    && wasPhysicalExamPerformedWithValueDuringMostRecentEncounter(visit,m,QPP317Elements.Diastolic_Blood_Pressure,80,CompareOperator.LESS,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)
                  )

              ||
                (
                    (
                      (
                            wasPhysicalExamPerformedWithValueInRangeDuringMostRecentEncounter(visit,m,QPP317Elements.Systolic_Blood_Pressure,120,140,CompareOperator.GREATER_EQUAL_And_LESS,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)
                        &&  wasPhysicalExamPerformedWithValueDuringMostRecentEncounter(visit,m,QPP317Elements.Diastolic_Blood_Pressure,90,CompareOperator.LESS,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)
                      )
                    ||
                      (
                            wasPhysicalExamPerformedWithValueInRangeDuringMostRecentEncounter(visit,m,QPP317Elements.Diastolic_Blood_Pressure,80,90,CompareOperator.GREATER_EQUAL_And_LESS,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)
                        &&  wasPhysicalExamPerformedWithValueDuringMostRecentEncounter(visit,m,QPP317Elements.Systolic_Blood_Pressure,140,CompareOperator.LESS,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)
                      )
                    )
                  &&
                  (
                      isInterventionOrderedWithReasonAfterEncounterWithinXDays(visit,m,QPP317Elements.Referral_To_Alternative_Provider___Primary_Care_Provider,QPP317Elements.Finding_Of_Hypertension,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                   || (
                          (
                                isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Lifestyle_Recommendation,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                            ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Weight_Reduction_Recommended,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                            ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Dietary_Recommendations,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                            ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Physical_Activity_Recommendation,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                            ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Moderation_Of_Etoh_Consumption_Recommendation,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                          )
                        &&  isInterventionOrderedWithReasonAfterEncounterWithinXDays(visit,m,QPP317Elements.Followup_Within_One_Year,QPP317Elements.Finding_Of_Hypertension,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                      )

                  )
                )
              ||
                (
                    (
                        (
                              !wasphysicalExamPerformedBeforeEncounterWithinYears(visit,m,QPP317Elements.Systolic_Blood_Pressure,1,patientHistoryBrodcastList)
                          &&  !wasphysicalExamPerformedBeforeEncounterWithinYears(visit,m,QPP317Elements.Diastolic_Blood_Pressure,1,patientHistoryBrodcastList)

                        )
                     ||
                        (
                              wasPhysicalExamPerformedValueBeforeMostRecentEncounterWithinXYears(visit,m,QPP317Elements.Systolic_Blood_Pressure,140,CompareOperator.LESS,1,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)
                          &&  wasPhysicalExamPerformedValueBeforeMostRecentEncounterWithinXYears(visit,m,QPP317Elements.Diastolic_Blood_Pressure,90,CompareOperator.LESS,1,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)

                        )

                    )
                  &&
                    (
                          wasPhysicalExamPerformedWithValueDuringMostRecentEncounter(visit,m,QPP317Elements.Systolic_Blood_Pressure,140,CompareOperator.GREATER_EQUAL,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)
                      ||  wasPhysicalExamPerformedWithValueDuringMostRecentEncounter(visit,m,QPP317Elements.Diastolic_Blood_Pressure,90,CompareOperator.GREATER_EQUAL,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)

                    )
                  &&
                    (
                          isInterventionOrderedWithReasonAfterEncounterWithinXDays(visit,m,QPP317Elements.Referral_To_Alternative_Provider___Primary_Care_Provider,QPP317Elements.Finding_Of_Hypertension,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                      ||
                        (
                            (
                                  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Lifestyle_Recommendation,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                              ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Weight_Reduction_Recommended,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                              ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Dietary_Recommendations,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                              ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Physical_Activity_Recommendation,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                              ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Moderation_Of_Etoh_Consumption_Recommendation,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                            )
                            &&  isInterventionOrderedWithReasonAfterEncounterWithinXDays(visit,m,QPP317Elements.Followup_Within_4_Weeks,QPP317Elements.Finding_Of_Hypertension,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                        )


                      )
                )
              ||
                (
                    (
                          wasPhysicalExamPerformedValueBeforeMostRecentEncounterWithinXYears(visit,m,QPP317Elements.Systolic_Blood_Pressure,140,CompareOperator.GREATER_EQUAL,1,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)
                      ||  wasPhysicalExamPerformedValueBeforeMostRecentEncounterWithinXYears(visit,m,QPP317Elements.Diastolic_Blood_Pressure,90,CompareOperator.GREATER_EQUAL,1,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)

                    )
                  &&
                    (
                           wasPhysicalExamPerformedWithValueDuringMostRecentEncounter(visit,m,QPP317Elements.Systolic_Blood_Pressure,140,CompareOperator.GREATER_EQUAL,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)
                      ||   wasPhysicalExamPerformedWithValueDuringMostRecentEncounter(visit,m,QPP317Elements.Diastolic_Blood_Pressure,90,CompareOperator.GREATER_EQUAL,patientHistoryBrodcastList,mostRecentPatientHistoryBrodcastList)
                    )
                  &&
                    (
                            isInterventionOrderedWithReasonAfterEncounterWithinXDays(visit,m,QPP317Elements.Referral_To_Alternative_Provider___Primary_Care_Provider,QPP317Elements.Finding_Of_Hypertension,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                        ||
                           (
                                (
                                      isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Lifestyle_Recommendation,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                                  ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Weight_Reduction_Recommended,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                                  ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Dietary_Recommendations,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                                  ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Physical_Activity_Recommendation,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                                  ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Moderation_Of_Etoh_Consumption_Recommendation,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)

                               )
                            &&
                                (
                                      isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Anti_Hypertensive_Pharmacologic_Therapy,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                                  ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Laboratory_Tests_For_Hypertension,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)
                                  ||  isInterventionOrderedAfterEncounterWithinXDays(visit,m,QPP317Elements.Ecg_12_Lead_Or_Study_Order,QPP317Elements.Bp_Screening_Encounter_Codes,CalenderUnit.DAY,1,patientHistoryBrodcastList)


                                )
                          )


                    )



                )

              )

          )
        ||
          (
            (
                  isMostRecentAssessmentPerformed(visit,m,QPP317Elements.Normal_Blood_Pressure,mostRecentPatientHistoryBrodcastList)
              ||  isMostRecentAssessmentPerformed(visit,m,QPP317Elements.Hypertensive_And_Pre_Hypertensive_Blood_Pressure_Follow_Up,mostRecentPatientHistoryBrodcastList)
              ||  isMostRecentAssessmentPerformed(visit,m,QPP317Elements.Blood_Pressure_Documented,mostRecentPatientHistoryBrodcastList)

            )
            &&
              !(
                    isAssessmentPerformed(visit,m,QPP317Elements.Hypertensive_Bp_Reason_Not_Specified,patientHistoryBrodcastList)
                ||  isAssessmentPerformed(visit,m,QPP317Elements.Bp_Reason_Not_Specified,patientHistoryBrodcastList)

              )


          )
        )


  }

  def getException(intermediateB: RDD[CassandraRow],patientHistoryBrodcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow]={
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateB.filter(visit=>

            isPhysicalExamPerformedDuringEncounter(visit,m,QPP317Elements.Medical_Or_Other_Reason_Not_Done)
        ||  isPhysicalExamPerformedDuringEncounter(visit,m,QPP317Elements.Patient_Reason_Refused)
        ||  isAssessmentPerformed(visit,m,QPP317Elements.Follow_Up_For_Bp_Reason,patientHistoryBrodcastList )
      )
  }






}