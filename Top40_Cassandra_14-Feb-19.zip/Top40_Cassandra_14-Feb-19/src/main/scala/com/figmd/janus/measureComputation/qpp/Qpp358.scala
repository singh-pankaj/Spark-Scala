package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP358Elements,TimeOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Qpp358
* Measure Title               :- Patient-Centered Surgical Risk Assessment and Communication
* Measure Description         :- Percentage of patients who underwent a non-emergency surgery who had their personalized
* risks of postoperative complications assessed by their surgical team prior to surgery using a clinical data-based, patient-specific risk calculator and who received personal discussion of those risks with the surgeon.
* Calculation Implementation  :- Procedure specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SANKET.DHAPTE
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.8
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.8
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp358 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp358"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
                                                                      ,QPP358Elements.Non__Emergent_Surgery
                                                                      ,QPP358Elements.Non_Emergent_Surgery__Dual_
                                                                      ,QPP358Elements.Emergency_Surgery_Grp
                                                                      ,QPP358Elements.Emergency_Surgery
                                                                       ,QPP358Elements.Patient_Specific_Risk_Assessment_Grp
                                                                      ,QPP358Elements.Non__Emergent_Surgery
                                                                      ,QPP358Elements.Non_Emergent_Surgery__Dual_
                                                                      ,QPP358Elements.Risk_Assessment_With_Risk_Calculator
                                                                      ,QPP358Elements.Communication_Of_Risk_Assessment
                                                                      ,QPP358Elements.Postoperative_Complications_Grp
                                                                      ,QPP358Elements.Risk_Assessment_Not_Met_Grp

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
  The total number of adult patients (age 18 and over) having had non-emergency surgery.
  -----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
         isPatientAdult(visit,m)
      && (
               isProcedurePerformedDuringEncounter(visit,m,QPP358Elements.Non__Emergent_Surgery)
           ||  isProcedurePerformedDuringEncounter(visit,m,QPP358Elements.Non_Emergent_Surgery__Dual_)
           )

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Emergency surgery
  -----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
         isProcedurePerformed(visit,m,QPP358Elements.Emergency_Surgery_Grp,patientHistoryBroadcastList)
      || isProcedurePerformed(visit,m,QPP358Elements.Emergency_Surgery,patientHistoryBroadcastList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Documentation of empirical, personalized risk assessment based on the patientâ€™s risk factors with a validated risk
calculator using multi-institutional clinical data, the specific risk calculator used, and communication of risk assessment
from risk calculator with the patient and/or family.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
      (
         wasInterventionPerformedBeforeEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP358Elements.Patient_Specific_Risk_Assessment_Grp)
      || (
             wasInterventionPerformedAfterOrEqualEncounter(visit,m,QPP358Elements.Patient_Specific_Risk_Assessment_Grp,patientHistoryBroadcastList)
          && (
               wasInterventionPerformedBeforeProcedureInHistory(visit,m,QPP358Elements.Patient_Specific_Risk_Assessment_Grp,QPP358Elements.Non__Emergent_Surgery,TimeOperator.BEFOREorEQUAL,patientHistoryBroadcastList)
               || wasInterventionPerformedBeforeProcedureInHistory(visit,m,QPP358Elements.Patient_Specific_Risk_Assessment_Grp,QPP358Elements.Non_Emergent_Surgery__Dual_,TimeOperator.BEFOREorEQUAL,patientHistoryBroadcastList)
               )
          )
        )
      || (
           wasInterventionPerformedBeforeEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP358Elements.Risk_Assessment_With_Risk_Calculator)
        || wasCommunicationFromProviderToPatientBeforeEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP358Elements.Communication_Of_Risk_Assessment
                                                                                                                                ,QPP358Elements.Postoperative_Complications_Grp)
          )
        )
      && !wasInterventionPerformedBeforeEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP358Elements.Risk_Assessment_Not_Met_Grp)
    )
  }


}