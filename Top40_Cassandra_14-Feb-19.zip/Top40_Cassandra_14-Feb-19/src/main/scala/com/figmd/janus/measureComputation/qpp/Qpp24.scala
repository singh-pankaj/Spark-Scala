package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP24Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 24
* Measure Title              :- Communication with the Physician or Other Clinician Managing On-going Care Post-Fracture for Men and Women Aged 50 Years and Older
* Measure Description        :- Percentage of patients aged 50 years and older treated for a fracture with documentation of communication, between the physician
*                               treating the fracture and the physician or other clinician managing the patient’s on-going care, that a fracture occurred and that
*                               the patient was or should be considered for osteoporosis treatment or testing. This measure is reported by the physician who treats
*                               the fracture and who therefore is held accountable for the communication.
* Calculation Implementation :- Episode-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp24 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp24"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD, QPP24Elements.Fracturediagnosis,
      QPP24Elements.Post_Fracture_Care,
      QPP24Elements.Post_Fracture_Care_Reason_Not_Specified,
      QPP24Elements.Hospice_Care,
      QPP24Elements.Hospice_Services,
      QPP24Elements.Hospice_Services_Snomedct).collect.toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession,initialRDD,ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exceptions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateMetRDD = getSubtractRDD(ippRDD,exclusionRDD)
      intermediateMetRDD.cache()

      // Filter Met
      val metRDD = getMet(intermediateMetRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateExceptionRDD = getSubtractRDD(ippRDD,metRDD)
      intermediateExceptionRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateExceptionRDD, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }

  //Adults aged 50 years and older who experienced a fracture, except fractures of the finger, toe, face or skull
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      (
        isAgeAbove(visit, m, true, 50)
        &&
        (

             isVisitTypeIn(visit, m, QPP24Elements.Office_Visit, QPP24Elements.Initial_Preventive_Physical_Examination)
            && isDiagnosedDuringEncounter(visit, m, QPP24Elements.Fracturediagnosis)
          )
          ||
          (
               isProcedurePerformedDuringEncounter(visit, m, QPP24Elements.Documentation_Of_Treatment_For_Fracture)
              && wasDiagnosedBefore(visit, m, QPP24Elements.Documentation_Of_Treatment_For_Fracture_Date, QPP24Elements.Fracturediagnosis, patientHistoryList)
            )
        ))
  }

  //Patient using hospice services any time during the measurement period
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isInterventionBeforeEnd(visit, m, QPP24Elements.Hospice_Care, patientHistoryList)
        || isInterventionBeforeEnd(visit, m, QPP24Elements.Hospice_Services_Snomedct, patientHistoryList)
        || isInterventionPerformed(visit, m, QPP24Elements.Hospice_Services, patientHistoryList)
    )
  }

  //Patients with documentation of communication with the physician or other clinician managing the patient’s on-going care that a fracture occurred and that the patient was or should be considered for osteoporosis testing or treatment
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (isCommunicationFromProviderToProviderOnEncounter(visit, m, QPP24Elements.Post_Fracture_Care_Communication_Documented)
        ||
        (
          wasCommunicationFromProvidertoProviderAfterEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryList, QPP24Elements.Post_Fracture_Care)
            && wasCommunicationDoneAfterProcedureWithinXMonths(visit, m, QPP24Elements.Documentation_Of_Treatment_For_Fracture, QPP24Elements.Documentation_Of_Treatment_For_Fracture_Date, 3, patientHistoryList, QPP24Elements.Post_Fracture_Care)
          )
        || isCommunicationFromProviderToProviderOnEncounter(visit, m, QPP24Elements.Post_Fracture_Care)
        )
        && !isCommunicationFromProvidertoProviderNotDone(visit, m, QPP24Elements.Post_Fracture_Care_Reason_Not_Specified, patientHistoryList)

    )
  }


}

