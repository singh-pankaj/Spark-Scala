package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm117V7
* Measure Title              :- Childhood Immunization Status
* Measure Description        :- Percentage of children 2 years of age who had four diphtheria, tetanus and
*                               acellular pertussis (DTaP); three polio (IPV), one measles, mumps and rubella (MMR);
*                               three H influenza type B (HiB); three hepatitis B (Hep B); one chicken pox (VZV);
*                               four pneumococcal conjugate (PCV); one hepatitis A (Hep A); two or three rotavirus (RV);
 *                              and two influenza (flu) vaccines by their second birthday
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score equals better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumant Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm117V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm117V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , ECQM117V7Elements.Anaphylactic_Reaction_To_Common_Baker_s_Yeast
      , ECQM117V7Elements.Anaphylactic_Reaction_To_Dtap_Vaccine
      , ECQM117V7Elements.Anaphylactic_Reaction_To_Hemophilus_Influenza_B__Hib__Vaccine
      , ECQM117V7Elements.Anaphylactic_Reaction_To_Hepatitis_A_Vaccine
      , ECQM117V7Elements.Anaphylactic_Reaction_To_Hepatitis_B_Vaccine
      , ECQM117V7Elements.Anaphylactic_Reaction_To_Inactivated_Polio_Vaccine__Ipv_
      , ECQM117V7Elements.Anaphylactic_Reaction_To_Influenza_Vaccine
      , ECQM117V7Elements.Anaphylactic_Reaction_To_Neomycin
      , ECQM117V7Elements.Anaphylactic_Reaction_To_Pneumococcal_Conjugate_Vaccine
      , ECQM117V7Elements.Anaphylactic_Reaction_To_Polymyxin
      , ECQM117V7Elements.Anaphylactic_Reaction_To_Rotavirus_Vaccine
      , ECQM117V7Elements.Anaphylactic_Reaction_To_Rotavirus_Vaccine
      , ECQM117V7Elements.Anaphylactic_Reaction_To_Streptomycin
      , ECQM117V7Elements.Anti_Hepatitis_A_Igg_Antigen_Test
      , ECQM117V7Elements.Anti_Hepatitis_B_Virus_Surface_Ab
      , ECQM117V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care
      , ECQM117V7Elements.Discharged_To_Home_For_Hospice_Care
      , ECQM117V7Elements.Disorders_Of_The_Immune_System
      , ECQM117V7Elements.Dtap_Vaccine
      , ECQM117V7Elements.Dtap_Vaccine_Administered
      , ECQM117V7Elements.Encephalopathy_Due_To_Childhood_Vaccination
      , ECQM117V7Elements.Encounter_Inpatient
      , ECQM117V7Elements.Haemophilus_Influenzae_Type_B__Hib__Vaccine
      , ECQM117V7Elements.Haemophilus_Influenzae_Type_B__Hib__Vaccine_Administered
      , ECQM117V7Elements.Hepatitis_A
      , ECQM117V7Elements.Hepatitis_A_Vaccine
      , ECQM117V7Elements.Hepatitis_A_Vaccine_Administered
      , ECQM117V7Elements.Hepatitis_B
      , ECQM117V7Elements.Hepatitis_B_Vaccine
      , ECQM117V7Elements.Hepatitis_B_Vaccine_Administered
      , ECQM117V7Elements.Hiv
      , ECQM117V7Elements.Home_Healthcare_Services
      , ECQM117V7Elements.Hospice_Care_Ambulatory
      , ECQM117V7Elements.Inactivated_Polio_Vaccine__Ipv_
      , ECQM117V7Elements.Inactivated_Polio_Vaccine__Ipv__Administered
      , ECQM117V7Elements.Influenza_Vaccine
      , ECQM117V7Elements.Influenza_Vaccine_Administered
      , ECQM117V7Elements.Intussusception
      , ECQM117V7Elements.Malignant_Neoplasm_Of_Lymphatic_And_Hematopoietic_Tissue
      , ECQM117V7Elements.Measles
      , ECQM117V7Elements.Measles__Mumps_And_Rubella__Mmr__Vaccine
      , ECQM117V7Elements.Measles__Mumps_And_Rubella__Mmr__Vaccine_Administered
      , ECQM117V7Elements.Measles_Antibody_Test__Igg_Antibody_Presence_
      , ECQM117V7Elements.Measles_Antibody_Test__Igg_Antibody_Titer_
      , ECQM117V7Elements.Mumps
      , ECQM117V7Elements.Office_Visit
      , ECQM117V7Elements.Pneumococcal_Conjugate_Vaccine
      , ECQM117V7Elements.Pneumococcal_Conjugate_Vaccine_Administered
      , ECQM117V7Elements.Preventive_Care__Established_Office_Visit__0_To_17
      , ECQM117V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
      , ECQM117V7Elements.Rotavirus_Vaccine__2_Dose_Schedule_
      , ECQM117V7Elements.Rotavirus_Vaccine__2_Dose_Schedule__Administered
      , ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule_
      , ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule__Administered
      , ECQM117V7Elements.Rubella
      , ECQM117V7Elements.Severe_Combined_Immunodeficiency
      , ECQM117V7Elements.Varicella_Zoster
      , ECQM117V7Elements.Varicella_Zoster_Antibody_Test__Igg_Antibody_Presence_
      , ECQM117V7Elements.Varicella_Zoster_Antibody_Test__Igg_Antibody_Titer_
      , ECQM117V7Elements.Varicella_Zoster_Vaccine__Vzv_
      , ECQM117V7Elements.Varicella_Zoster_Vaccine__Vzv__Administered
    )
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val ippRDD = getIpp(initialRDD, patientHistoryList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exclusions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      val intermediateRDD = ippRDD.subtract(exclusionRDD)
      intermediateRDD.cache()

      // Filter Met
      val metRDD = getMet(intermediateRDD, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()

    }
  }

/*-----------------------------------------------------------------------------------------------------------------------
  Children who turn 2 years of age during the measurement period and who have a visit during the measurement period
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeBetween(visit, m, 1, CompareOperator.GREATER_EQUAL, 2, CompareOperator.LESS)
        &&
        (
          isEncounterPerformed(visit, m, ECQM117V7Elements.Office_Visit, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM117V7Elements.Home_Healthcare_Services, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM117V7Elements.Preventive_Care__Established_Office_Visit__0_To_17, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM117V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17, patientHistoryList)
          )
    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
  Exclude patients whose hospice care overlaps the measurement period
  -----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isEncounterPerformedWithDischargeStatus(visit, m, ECQM117V7Elements.Encounter_Inpatient, ECQM117V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        ||
        isEncounterPerformedWithDischargeStatus(visit, m, ECQM117V7Elements.Encounter_Inpatient, ECQM117V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        || //Intervention ordered and Intervention performed on same element -  no need to check twice
        isInterventionPerformed(visit, m, ECQM117V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Children who have evidence showing they received recommended vaccines, had documented history of the illness,
  had a seropositive test result, or had an allergic reaction to the vaccine by their second birthday
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateRDD.filter(visit =>
      (
        wasVaccinatedXTimes(visit, m, ECQM117V7Elements.Dtap_Vaccine, ECQM117V7Elements.Dtap_Vaccine_Administered, CalenderUnit.DAY, 42, 730, 4, patientHistoryList)
          ||
          wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Dtap_Vaccine, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
          ||
          wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Encephalopathy_Due_To_Childhood_Vaccination, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
        )
        &&
        (
          wasVaccinatedXTimes(visit, m, ECQM117V7Elements.Inactivated_Polio_Vaccine__Ipv_, ECQM117V7Elements.Inactivated_Polio_Vaccine__Ipv__Administered, CalenderUnit.DAY, 42, 730, 3, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Inactivated_Polio_Vaccine__Ipv_, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Streptomycin, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Polymyxin, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Neomycin, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
          )
        &&
        (
          wasImmunizationPerformedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Measles__Mumps_And_Rubella__Mmr__Vaccine, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasProcedurePerformedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Measles__Mumps_And_Rubella__Mmr__Vaccine_Administered, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Disorders_Of_The_Immune_System, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Hiv, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Malignant_Neoplasm_Of_Lymphatic_And_Hematopoietic_Tissue, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Neomycin, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            (
              wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Measles, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
                ||
                wasLaboratoryTestWithResultInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Measles_Antibody_Test__Igg_Antibody_Titer_, 1.10, CompareOperator.GREATER_EQUAL, CalenderUnit.DAY, 730, patientHistoryList)
                ||
                wasLaboratoryTestWithResultInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Measles_Antibody_Test__Igg_Antibody_Presence_, CalenderUnit.DAY, 730, patientHistoryList)
              )
              &&
              (
                wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Mumps, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
                  ||
                  wasLaboratoryTestWithResultInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Measles_Antibody_Test__Igg_Antibody_Titer_, 1.10, CompareOperator.GREATER_EQUAL, CalenderUnit.DAY, 730, patientHistoryList)
                  ||
                  wasLaboratoryTestWithResultInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Measles_Antibody_Test__Igg_Antibody_Presence_, CalenderUnit.DAY, 730, patientHistoryList)
                )
              &&
              (
                wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Rubella, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
                  ||
                  wasLaboratoryTestWithResultInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Measles_Antibody_Test__Igg_Antibody_Titer_, 1.10, CompareOperator.GREATER_EQUAL, CalenderUnit.DAY, 730, patientHistoryList)
                  ||
                  wasLaboratoryTestWithResultInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Measles_Antibody_Test__Igg_Antibody_Presence_, CalenderUnit.DAY, 730, patientHistoryList)
                )
          )
        &&
        (
          wasVaccinatedXTimes(visit, m, ECQM117V7Elements.Haemophilus_Influenzae_Type_B__Hib__Vaccine, ECQM117V7Elements.Haemophilus_Influenzae_Type_B__Hib__Vaccine_Administered, CalenderUnit.DAY, 42, 730, 3, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Hemophilus_Influenza_B__Hib__Vaccine, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
          )
        &&
        (
          wasVaccinatedXTimes(visit, m, ECQM117V7Elements.Hepatitis_B_Vaccine, ECQM117V7Elements.Hepatitis_B_Vaccine_Administered, CalenderUnit.DAY, 0, 730, 3, patientHistoryList)
            ||
            wasLaboratoryTestWithResultInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anti_Hepatitis_B_Virus_Surface_Ab, CalenderUnit.DAY, 730, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Hepatitis_B_Vaccine, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Common_Baker_s_Yeast, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Hepatitis_B, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
          )
        &&
        (
          wasImmunizationPerformedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Varicella_Zoster_Vaccine__Vzv_, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasProcedurePerformedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Varicella_Zoster_Vaccine__Vzv__Administered, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Disorders_Of_The_Immune_System, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Hiv, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Malignant_Neoplasm_Of_Lymphatic_And_Hematopoietic_Tissue, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Neomycin, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasLaboratoryTestWithResultInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Varicella_Zoster_Antibody_Test__Igg_Antibody_Titer_, 1.10, CompareOperator.GREATER_EQUAL, CalenderUnit.DAY, 730, patientHistoryList)
            ||
            wasLaboratoryTestWithResultInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Varicella_Zoster_Antibody_Test__Igg_Antibody_Presence_, CalenderUnit.DAY, 730, patientHistoryList)
          )
        &&
        (
          wasVaccinatedXTimes(visit, m, ECQM117V7Elements.Pneumococcal_Conjugate_Vaccine, ECQM117V7Elements.Pneumococcal_Conjugate_Vaccine_Administered, CalenderUnit.DAY, 42, 730, 4, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Pneumococcal_Conjugate_Vaccine, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
          )
        &&
        (
          wasImmunizationPerformedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Hepatitis_A_Vaccine, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasProcedurePerformedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Hepatitis_A_Vaccine_Administered, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Hepatitis_A_Vaccine, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Hepatitis_A, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasLaboratoryTestWithResultInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anti_Hepatitis_A_Igg_Antigen_Test, CalenderUnit.DAY, 730, patientHistoryList)
          )
        &&
        (
          wasVaccinatedXTimes(visit, m, ECQM117V7Elements.Rotavirus_Vaccine__2_Dose_Schedule_, ECQM117V7Elements.Rotavirus_Vaccine__2_Dose_Schedule__Administered, CalenderUnit.DAY, 42, 730, 2, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Rotavirus_Vaccine, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Severe_Combined_Immunodeficiency, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Intussusception, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasVaccinatedInSequence(visit, m,
              List(ECQM117V7Elements.Rotavirus_Vaccine__2_Dose_Schedule_, ECQM117V7Elements.Rotavirus_Vaccine__2_Dose_Schedule__Administered),
              List(ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule_, ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule__Administered),
              List(ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule_, ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule__Administered),
              CalenderUnit.DAY, 1, CompareOperator.GREATER_EQUAL, 42, 730, patientHistoryList)
            ||
            wasVaccinatedInSequence(visit, m,
              List(ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule_, ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule__Administered),
              List(ECQM117V7Elements.Rotavirus_Vaccine__2_Dose_Schedule_, ECQM117V7Elements.Rotavirus_Vaccine__2_Dose_Schedule__Administered),
              List(ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule_, ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule__Administered),
              CalenderUnit.DAY, 1, CompareOperator.GREATER_EQUAL, 42, 730, patientHistoryList)
            ||
            wasVaccinatedInSequence(visit, m,
              List(ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule_, ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule__Administered),
              List(ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule_, ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule__Administered),
              List(ECQM117V7Elements.Rotavirus_Vaccine__2_Dose_Schedule_, ECQM117V7Elements.Rotavirus_Vaccine__2_Dose_Schedule__Administered),
              CalenderUnit.DAY, 1, CompareOperator.GREATER_EQUAL, 42, 730, patientHistoryList)
            ||
            wasVaccinatedXTimes(visit, m, ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule_, ECQM117V7Elements.Rotavirus_Vaccine__3_Dose_Schedule__Administered, CalenderUnit.DAY, 42, 730, 3, patientHistoryList)
          )
        &&
        (
          wasVaccinatedXTimes(visit, m, ECQM117V7Elements.Influenza_Vaccine, ECQM117V7Elements.Influenza_Vaccine_Administered, CalenderUnit.DAY, 180, 730, 2, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Influenza_Vaccine, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Malignant_Neoplasm_Of_Lymphatic_And_Hematopoietic_Tissue, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Anaphylactic_Reaction_To_Neomycin, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Hiv, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
            ||
            wasDiagnosedInXDaysAfterBirthDate(visit, m, ECQM117V7Elements.Disorders_Of_The_Immune_System, CalenderUnit.DAY, 730, CompareOperator.LESS_EQUAL, patientHistoryList)
          )
    )
  }

}

