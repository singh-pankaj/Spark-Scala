package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP236Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 236
* Measure Title              :- Controlling High Blood Pressure
* Measure Description        :- Percentage of patients 18 - 85 years of age who had a diagnosis of hypertension
                                and whose blood pressure was adequately controlled (< 140/90 mmHg) during the measurement period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/



object  Qpp236  extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp236"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryList = getPatientHistory(sparkSession,initialRDD
      ,QPP236Elements.Essential_Hypertension
      ,QPP236Elements.Pregnancy
      ,QPP236Elements.End_Stage_Renal_Disease
      ,QPP236Elements.Chronic_Kidney_Disease__Stage_5
      ,QPP236Elements.Vascular_Access_For_Dialysis
      ,QPP236Elements.Kidney_Transplant
      ,QPP236Elements.Dialysis_Services
      ,QPP236Elements.Esrd_Monthly_Outpatient_Services
      ,QPP236Elements.Hospice_Services
      ,QPP236Elements.Hospice_Services_Snomedct
      ,QPP236Elements.Hospice_Care
      ,QPP236Elements.Medical_Exclusions
      ,QPP236Elements.Isnp_Or_Long_Term_Care
      ,QPP236Elements.Institutional_Special_Needs_Plans
      ,QPP236Elements.Long_Term_Care_Pos
      ,QPP236Elements.Lowest_Diastolic_Bp
      ,QPP236Elements.Lowest_Systolic_Bp
    ).collect().toList

    val patientHistoryBroadcastList:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    val patientHistoryEshy = getPatientHistory(sparkSession,initialRDD,QPP236Elements.Essential_Hypertension)

    val firstDateList:List[CassandraRow]=minDate(patientHistoryEshy,QPP236Elements.Essential_Hypertension,QPP236Elements.Essential_Hypertension_Date)
    val firstDateBroadcastList:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(firstDateList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD,firstDateBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Filter Exclusions

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()
      // Filter Intermediate
      val intermediateNumerator = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateNumerator.cache()
      // Filter Met
      val metRDD = getMet(intermediateNumerator)
      metRDD.cache()
      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateNumerator, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      firstDateBroadcastList.destroy()
    }
  }


  def getIpp(initialRDD: RDD[CassandraRow], firstDateBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>

             isPatientAdult(visit,m)
        &&   isAgeBelow(visit,m,false,86)
        &&   wasDiagnosedInFirstXMonths(visit,m,QPP236Elements.Essential_Hypertension,firstDateBroadcastList,6)
        &&   isVisitTypeIn(visit,m,QPP236Elements.Adult_Outpatient_Visit)
    )

  }

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
           isDiagnosedWithOnEncounter(visit,m,QPP236Elements.Pregnancy)
        ||
          (
                 isDiagnosedWithOnEncounter(visit,m,QPP236Elements.End_Stage_Renal_Disease)
              || isDiagnosedWithOnEncounter(visit,m,QPP236Elements.Chronic_Kidney_Disease__Stage_5)
            )
        ||
          (
                 wasProcedurePerformedInHistory(visit,m,QPP236Elements.Vascular_Access_For_Dialysis,patientHistoryBroadcastList)
              || wasEncounterPerformedInHistory(visit,m,QPP236Elements.Esrd_Monthly_Outpatient_Services,patientHistoryBroadcastList)
              || wasProcedurePerformedInHistory(visit,m,QPP236Elements.Kidney_Transplant,patientHistoryBroadcastList)
              || wasProcedurePerformedInHistory(visit,m,QPP236Elements.Dialysis_Services,patientHistoryBroadcastList)
            )
        || isInterventionPerformed(visit,m,QPP236Elements.Hospice_Services,patientHistoryBroadcastList)
        ||
          (
                 wasInterventionPerformedInHistory(visit,m,QPP236Elements.Hospice_Services_Snomedct,patientHistoryBroadcastList)
              || wasInterventionPerformedInHistory(visit,m,QPP236Elements.Hospice_Care,patientHistoryBroadcastList)
            )
        || wasInterventionPerformedInHistory(visit,m,QPP236Elements.Medical_Exclusions,patientHistoryBroadcastList)
        || wasInterventionPerformedInHistory(visit,m,QPP236Elements.Isnp_Or_Long_Term_Care,patientHistoryBroadcastList)
        ||
          (
            isAgeAbove(visit,m,true,65)
              &&
              (
                     wasInterventionPerformedInHistory(visit,m,QPP236Elements.Institutional_Special_Needs_Plans,patientHistoryBroadcastList)
                  || wasEncounterPerformed(visit,m,QPP236Elements.Long_Term_Care_Pos,patientHistoryBroadcastList)
                )
            )
    )
  }

  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
           isDiastolicBPSystolicBPPerformedOnEncounter(visit,m,QPP236Elements.Lowest_Systolic_Bp,QPP236Elements.Lowest_Diastolic_Bp,QPP236Elements.Lowest_Systolic_Bp_Date,QPP236Elements.Lowest_Diastolic_Bp_Date,90.0,140)
        ||
          (
               isPhysicalExamPerformedDuringEncounter(visit,m,QPP236Elements.Systolic_Bp)
            && isPhysicalExamPerformedDuringEncounter(visit,m,QPP236Elements.Diastolic_Bp)
          )
          && !(
                (
                     isPhysicalExamPerformedDuringEncounter(visit,m,QPP236Elements.Systolic_Blood_Pressure_Not_Met)
                  && isPhysicalExamPerformedDuringEncounter(visit,m,QPP236Elements.Diastolic_Blood_Pressure_Not_Met)
                )
              || isPhysicalExamPerformedDuringEncounter(visit,m,QPP236Elements.Blood_Pressure_Measurement_Reason_Not_Specified)
              )
    )
  }

}
