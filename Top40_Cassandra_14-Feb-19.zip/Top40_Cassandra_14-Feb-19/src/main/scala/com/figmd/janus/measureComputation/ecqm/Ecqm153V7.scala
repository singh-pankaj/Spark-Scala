package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ECQM153V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm153v7
* Measure Title              :- Chlamydia Screening for Women
* Measure Description        :- Percentage of women 16-24 years of age who were identified as sexually active and who had at least one test for chlamydia during the measurement period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- 2
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm153V7 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Ecqm153V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patient_history_list = getPatientHistory(sparkSession, initialRDD,
      ECQM153V7Elements.Female,
      ECQM153V7Elements.Office_Visit,
      ECQM153V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
      ECQM153V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
      ECQM153V7Elements.Preventive_Care__Established_Office_Visit__0_To_17,
      ECQM153V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,
      ECQM153V7Elements.Home_Healthcare_Services,
      ECQM153V7Elements.Sexually_Active,
      ECQM153V7Elements.Yes_Response,
      ECQM153V7Elements.Other_Female_Reproductive_Conditions,
      ECQM153V7Elements.Genital_Herpes,
      ECQM153V7Elements.Gonococcal_Infections_And_Venereal_Diseases,
      ECQM153V7Elements.Contraceptive_Medications,
      ECQM153V7Elements.Contraceptive_Medications,
      ECQM153V7Elements.Inflammatory_Diseases_Of_Female_Reproductive_Organs,
      ECQM153V7Elements.Chlamydia,
      ECQM153V7Elements.Hiv,
      ECQM153V7Elements.Syphilis,
      ECQM153V7Elements.Complications_Of_Pregnancy__Childbirth_And_The_Puerperium,
      ECQM153V7Elements.Pregnancy_Test,
      ECQM153V7Elements.Pap_Test,
      ECQM153V7Elements.Delivery_Live_Births,
      ECQM153V7Elements.Lab_Tests_During_Pregnancy,
      ECQM153V7Elements.Lab_Tests_For_Sexually_Transmitted_Infections,
      ECQM153V7Elements.Diagnostic_Studies_During_Pregnancy,
      ECQM153V7Elements.Procedures_During_Pregnancy,
      ECQM153V7Elements.Procedures_Involving_Contraceptive_Devices,
      ECQM153V7Elements.Hospice_Care_Ambulatory,
      ECQM153V7Elements.Isotretinoin,
      ECQM153V7Elements.X_Ray_Study__All_Inclusive_,
      ECQM153V7Elements.Carrier_Of_Predominantly_Sexually_Transmitted_Infection,
      ECQM153V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
      ECQM153V7Elements.Discharged_To_Home_For_Hospice_Care,
      ECQM153V7Elements.Chlamydia_Screening,
      ECQM153V7Elements.Encounter_Inpatient
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible RDD
      //val eligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }

  //Women 16 to 24 years of age who are sexually active and who had a visit in the measurement period
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeBetween(visit, m, 16, 24)
        && isFemale(visit, m)
        && isVisitTypeIn(visit, m,
        ECQM153V7Elements.Office_Visit,
        ECQM153V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
        ECQM153V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
        ECQM153V7Elements.Preventive_Care__Established_Office_Visit__0_To_17,
        ECQM153V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,
        ECQM153V7Elements.Home_Healthcare_Services

      )
        &&
        (
          isAssessmentPerformedWithResult(visit, m, ECQM153V7Elements.Sexually_Active, ECQM153V7Elements.Yes_Response, "EQUAL", patientHistoryList)
            ||
            (
              wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Other_Female_Reproductive_Conditions, patientHistoryList)
                || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Genital_Herpes, patientHistoryList)
                || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Gonococcal_Infections_And_Venereal_Diseases, patientHistoryList)
                || wasMedicationActiveInHistory(visit, m, ECQM153V7Elements.Contraceptive_Medications, patientHistoryList)
                || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Inflammatory_Diseases_Of_Female_Reproductive_Organs, patientHistoryList)
                || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Chlamydia, patientHistoryList)
                || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Hiv, patientHistoryList)
                || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Syphilis, patientHistoryList)
                || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Complications_Of_Pregnancy__Childbirth_And_The_Puerperium, patientHistoryList)

              )
            ||
            (

              isLaboratoryTestPerformed(visit, m, ECQM153V7Elements.Pregnancy_Test, patientHistoryList)
                || isLaboratoryTestPerformed(visit, m, ECQM153V7Elements.Pap_Test, patientHistoryList)
                || isProcedurePerformed(visit, m, ECQM153V7Elements.Delivery_Live_Births, patientHistoryList)
                || isLaboratoryTestPerformed(visit, m, ECQM153V7Elements.Lab_Tests_During_Pregnancy, patientHistoryList)
                || isLaboratoryTestPerformed(visit, m, ECQM153V7Elements.Lab_Tests_For_Sexually_Transmitted_Infections, patientHistoryList)
                || isMedicationOrdered(visit, m, patientHistoryList, ECQM153V7Elements.Contraceptive_Medications)
                || isDiagnosticStudyPerformed(visit, m, ECQM153V7Elements.Diagnostic_Studies_During_Pregnancy, patientHistoryList)
                || isProcedurePerformed(visit, m, ECQM153V7Elements.Procedures_During_Pregnancy, patientHistoryList)
                || isProcedurePerformed(visit, m, ECQM153V7Elements.Procedures_Involving_Contraceptive_Devices, patientHistoryList)
              )

          )


    )
  }

  //Exclusion Criteria
  //Women who are only eligible for the initial population due to a pregnancy test and who had an x-ray or an order for a specified medication within 7 days of the pregnancy test.

  // Exclude patients whose hospice care overlaps the measurement period.
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (
        isEncounterPerformedWithDischargeStatus(visit, m, ECQM153V7Elements.Encounter_Inpatient, ECQM153V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
          || isEncounterPerformedWithDischargeStatus(visit, m, ECQM153V7Elements.Encounter_Inpatient, ECQM153V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
          // as overlaps "Measurement Period" covers During measurement period not added same element for during
          || wasInterventionPerformedInHistory(visit, m, ECQM153V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
          ||
          (
            (
              wasMedicationStartsAfterEndOfXDaysOfMedication(visit, m, ECQM153V7Elements.Pregnancy_Test, ECQM153V7Elements.Pregnancy_Test_Date, 7, ECQM153V7Elements.Isotretinoin, patientHistoryList)
                || wasDiagnosisStartsAfterElementWithinXDays(visit, m, ECQM153V7Elements.Pregnancy_Test, ECQM153V7Elements.X_Ray_Study__All_Inclusive_, 7, patientHistoryList)

              )
              &&
              !(
                (
                  wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Other_Female_Reproductive_Conditions, patientHistoryList)
                    || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Genital_Herpes, patientHistoryList)
                    || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Gonococcal_Infections_And_Venereal_Diseases, patientHistoryList)
                    || wasMedicationActiveInHistory(visit, m, ECQM153V7Elements.Contraceptive_Medications, patientHistoryList)
                    || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Inflammatory_Diseases_Of_Female_Reproductive_Organs, patientHistoryList)
                    || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Chlamydia, patientHistoryList)
                    || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Hiv, patientHistoryList)
                    || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Syphilis, patientHistoryList)

                    || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Complications_Of_Pregnancy__Childbirth_And_The_Puerperium, patientHistoryList)
                    || wasDiagnosedInHistory(visit, m, ECQM153V7Elements.Carrier_Of_Predominantly_Sexually_Transmitted_Infection, patientHistoryList)

                  )
                  ||
                  (


                    isLaboratoryTestPerformed(visit, m, ECQM153V7Elements.Pap_Test, patientHistoryList)
                      || isProcedurePerformed(visit, m, ECQM153V7Elements.Delivery_Live_Births, patientHistoryList)
                      || isLaboratoryTestPerformed(visit, m, ECQM153V7Elements.Lab_Tests_During_Pregnancy, patientHistoryList)
                      || isLaboratoryTestPerformed(visit, m, ECQM153V7Elements.Lab_Tests_For_Sexually_Transmitted_Infections, patientHistoryList)
                      || isMedicationOrdered(visit, m, patientHistoryList, ECQM153V7Elements.Contraceptive_Medications)
                      || isDiagnosticStudyPerformed(visit, m, ECQM153V7Elements.Diagnostic_Studies_During_Pregnancy, patientHistoryList)
                      || isProcedurePerformed(visit, m, ECQM153V7Elements.Procedures_During_Pregnancy, patientHistoryList)
                      || isProcedurePerformed(visit, m, ECQM153V7Elements.Procedures_Involving_Contraceptive_Devices, patientHistoryList)
                    )
                )
            )
        )

    )
  }

  //Women with at least one chlamydia test during the measurement period
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      isLaboratoryTestPerformed(visit, m, ECQM153V7Elements.Chlamydia_Screening, patientHistoryList)


    )
  }

}