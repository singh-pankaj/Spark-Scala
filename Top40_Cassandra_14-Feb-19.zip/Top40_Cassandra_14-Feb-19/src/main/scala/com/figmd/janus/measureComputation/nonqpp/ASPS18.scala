package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ASPS18Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- ASPS18
* Measure Title               :- Shared-decision making for post-operative management of discomfort following rhinoplasty
* Measure Description         :- Percentage of patients aged 15 years and older who had a rhinoplasty procedure who had documentation
*                                of a pre-operative shared-decision making strategy for multi-modal post-operative management of discomfort.
* Calculation Implementation  :- Procedure Specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SHREYA_ASHTEKAR_FIGMD_COM
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object ASPS18 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "ASPS18"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      ASPS18Elements.Asthma,
      ASPS18Elements.Coronary_Artery_Disease,
      ASPS18Elements.Chronic_Obstructive_Pulmonary_Disease,
      ASPS18Elements.Systemic_Pain_Management__Grp,
      ASPS18Elements.Non_Systemic_Pain_Management__Grp
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population :
All patients aged 15 years and older who had a rhinoplasty procedure.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit,m,true,15)
      &&
      isEncounterPerformedOnEncounter(visit,m,ASPS18Elements.Ambulatory_Visit)
      &&
      isProcedurePerformedDuringEncounter(visit,m,ASPS18Elements.Rhinoplasty)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator :
Patients who had documentation of a pre-operative shared-decision making strategy for multi-modal post-operative management of discomfort.
Definitions: Documentation of discussion of at least two mechanisms of pain management from the following terms or phrases will meet the measure:
Non-opioid analgesics: Non-narcotic/Non-opioid, Acetaminophen/Tylenol, Cox-II inhibitor (Celecoxib), Local/Marcaine/Block, Anxiolytic, Tramadol, NSAID/ibuprofen
Non-systemic: Ice/Cooling, Elevation, Rest, Mindfulness, Meditation
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      wasCommunicationFromPatientToProviderBeforeEncounter(visit,m,ASPS18Elements.Systemic_Pain_Management__Grp,patientHistoryBroadcastList)
      &&
      wasCommunicationFromPatientToProviderBeforeEncounter(visit,m,ASPS18Elements.Non_Systemic_Pain_Management__Grp,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exceptions :
Patient reasons for not taking a non-opioid analgesic
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      wasDiagnosedBeforeOrEqualEncounter(visit,m,ASPS18Elements.Asthma,patientHistoryBroadcastList)
      ||
      wasDiagnosedBeforeOrEqualEncounter(visit,m,ASPS18Elements.Coronary_Artery_Disease,patientHistoryBroadcastList)
      ||
      wasDiagnosedBeforeOrEqualEncounter(visit,m,ASPS18Elements.Chronic_Obstructive_Pulmonary_Disease,patientHistoryBroadcastList)

    )
  }
}