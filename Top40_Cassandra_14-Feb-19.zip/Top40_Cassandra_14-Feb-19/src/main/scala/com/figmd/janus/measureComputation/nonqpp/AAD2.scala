package com.figmd.janus.measureComputation.nonqpp

import java.util.Date
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, _}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD 2
* Measure Title              :- Psoriasis: Screening for Psoriatic Arthritis
* Measure Description        :- Percentage of patients with diagnosis of psoriasis who are screened for psoriatic
                                arthritis at least once during the measurement period.
* Calculation Implementation :- Patient Specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/



object AAD2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAD2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, initialRDD
                                                                    ,AAD2Elements.Presence_Of_Joint_Symptoms_Grp
                                                                    ,AAD2Elements.Absence_Of_Joint_Symptoms_Grp
                                                                    ,AAD2Elements.Visualization_Of_Joints_Grp
                                                                    ,AAD2Elements.Surrounding_Structures_Entheses_Grp
                                                                    ,AAD2Elements.Examination_Dactylitis_Grp
                                                                    ,AAD2Elements.Psoriatic_Arthritis_Screening_Using_Pase_Grp
                                                                    ,AAD2Elements.Psoriatic_Arthritis_Screening_Using_Topas_Grp
                                                                    ,AAD2Elements.Psoriatic_Arthritis_Screening_Using_Pest_Grp_Date
                                                  ).collect.toList
    val patientHistory: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistory)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistory)
      metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)

      patientHistory.unpersist()

    }
  }

  /*--------------------------------------------------------------------------------------------------------------------
    All patients with a diagnosis of psoriasis.

    Patients who meet each of the following criteria are included in the population:
    - Patient aged 18 years or older at the start of the measurement period.
    - Patient had an outpatient face to face encounter
    - Patient had diagnosis of psoriasis
   -------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
         isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
      && isVisitTypeIn(visit,m,AAD2Elements.Office_Visit)
      &&
           (
                isDiagnosedOnEncounter(visit,m,AAD2Elements.Psoriasis)
            ||  isDiagnosedOnEncounter(visit,m,AAD2Elements.Plaque_Psoriasis__Psoriasis_Vulgaris_)

           )

    )

  }

  /*--------------------------------------------------------------------------------------------------------------------
   Patients with existing diagnosis of psoriatic arthritis
   -------------------------------------------------------------------------------------------------------------------*/



  def getExclusionRdd(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
      isDiagnosedOnEncounter(visit,m,AAD2Elements.Psoriatic_Arthritis )

    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Patients with psoriasis (any type) are screened for psoriatic arthritis by documenting in the medical record
  the presence or absence of joint symptoms at least once during the measurement period.
  Screening for psoriatic arthritis is defined as any one of the following:
  Documentation of inquiry about the presence or absence of joint symptoms including any of the following:
       morning stiffness, pain, redness, and/or swelling of joints.
  Documentation of a physical examination
      (e.g. visualization of joints, surrounding structures (entheses) and fingers/toes for dactylitis)
  Documentation of the use of a validated psoriatic arthritis screening instrument such as the PASE
      (Psoriatic Arthritis Screening and Evaluation), ToPAS (Toronto Psoriatic Arthritis Screening),
      or PEST (Psoriasis Epidemiology Screening Tool).
   -------------------------------------------------------------------------------------------------------------------*/



  def getMet(intermediateA: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
         isAssessmentPerformed(visit,m,AAD2Elements.Presence_Of_Joint_Symptoms_Grp,patientHistory)
      || isAssessmentPerformed(visit,m,AAD2Elements.Absence_Of_Joint_Symptoms_Grp,patientHistory)
      ||
           (
             isAssessmentPerformed(visit,m,AAD2Elements.Visualization_Of_Joints_Grp,patientHistory)
          && isAssessmentPerformed(visit,m,AAD2Elements.Surrounding_Structures_Entheses_Grp,patientHistory)
          && isAssessmentPerformed(visit,m,AAD2Elements.Examination_Dactylitis_Grp,patientHistory)
             )
      || isAssessmentPerformed(visit,m,AAD2Elements.Psoriatic_Arthritis_Screening_Using_Pase_Grp,patientHistory)
      || isAssessmentPerformed(visit,m,AAD2Elements.Psoriatic_Arthritis_Screening_Using_Topas_Grp,patientHistory)
      || isAssessmentPerformed(visit,m,AAD2Elements.Psoriatic_Arthritis_Screening_Using_Pest_Grp_Date,patientHistory)
    )
  }

}







