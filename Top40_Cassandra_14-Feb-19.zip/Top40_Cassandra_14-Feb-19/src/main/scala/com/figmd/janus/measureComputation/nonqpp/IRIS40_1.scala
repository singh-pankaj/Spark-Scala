package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS40_1
* Measure Title               :- Regaining Vision After Cataract Surgery
* Measure Description         :- Percentage of patients aged 18 years and older with a diagnosis of cataract who had cataract surgery and 20/20 best-corrected distance visual acuity
                                 OR an improvement in best-corrected distance visual acuity within 30 days following the cataract surgery.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 3
* Measure Stratum No.         :- 1
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS40_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS40_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
              ,IRIS40Elements.Visual_Acuity
              ,IRIS40Elements.Glaucoma_Surgery__Eye
              ,IRIS40Elements.Best_Corrected_Left_Eye_Va_Value
              ,IRIS40Elements.Best_Corrected_Right_Eye_Va_Value
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val correctVAValues: Array[String] = Array("20/10", "20/11", "20/12", "20/13", "20/14", "20/15", "20/16", "20/17", "20/18", "20/19", "20/2", "20/20", "20/3","20/4", "20/5", "20/6", "20/7", "20/8", "20/9")


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList,correctVAValues)
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients aged 18 years and older with a diagnosis of cataract who had cataract surgery
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val filteredRDD = getPatientRDDBetweenPeriodsInMeasurementPeriod(initialRDD, m, CalenderUnit.MONTH, 11, true)

    filteredRDD.filter(
      visit =>
           isPatientAdult(visit,m)
        && wasPhysicalExamPerformedBeforeProcedure(visit,m,IRIS40Elements.Cataract_Surgery,IRIS40Elements.Visual_Acuity,patientHistoryBroadcastList)
        && isProcedurePerformedDuringEncounter(visit,m,IRIS40Elements.Cataract_Surgery)
        && wasPhysicalExamPerformedAfterProcedure(visit,m,IRIS40Elements.Cataract_Surgery,patientHistoryBroadcastList,IRIS40Elements.Visual_Acuity)
        && ! isProcedurePerformedDuringEncounter(visit,m,IRIS40Elements.Cataract_Surgery_Modifiers)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with high risk combined cataract surgery and glaucoma surgery procedures.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            isProcedurePerformedDuringProcedure(visit,m,IRIS40Elements.Cataract_Surgery,IRIS40Elements.Cataract_Surgery_Date,IRIS40Elements.Glaucoma_Surgery,IRIS40Elements.Glaucoma_Surgery_Date)
        &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS40Elements.Cataract_Surgery_Eye,patientHistoryBroadcastList,Seq(IRIS40Elements.Glaucoma_Surgery__Eye))

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
20/20 best-corrected distance visual acuity OR an improvement in best-corrected distance visual acuity achieved within 30 days following the cataract surgery:
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], correctVAValues: Array[String]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
       ! (    isProcedurePerformedDuringProcedure(visit,m,IRIS40Elements.Cataract_Surgery,IRIS40Elements.Cataract_Surgery_Date,IRIS40Elements.Comorbidities_,IRIS40Elements.Comorbidities__Date)
          &&  checkEyeElementsInRange(visit,m,IRIS40Elements.Cataract_Surgery_Eye,IRIS40Elements.Comorbidities_Eye)
         )
     &&  (  (    wasCorrectedVisualAcuityValueGreaterXDays(visit, m, IRIS40Elements.Best_Corrected_Left_Eye_Va_Value, IRIS40Elements.Cataract_Surgery, 30, correctVAValues, patientHistoryBroadcastList)
             ||  wasCorrectedVisualAcuityValueGreaterXDays(visit, m, IRIS40Elements.Best_Corrected_Right_Eye_Va_Value, IRIS40Elements.Cataract_Surgery, 30, correctVAValues, patientHistoryBroadcastList)
            )
         ||  isImprovementInVisualAcuity(visit,m,IRIS40Elements.Cataract_Surgery,IRIS40Elements.Visual_Acuity,CalenderUnit.DAY,30,CompareOperator.LESS_EQUAL,0,patientHistoryBroadcastList)
        )
    )
  }

}