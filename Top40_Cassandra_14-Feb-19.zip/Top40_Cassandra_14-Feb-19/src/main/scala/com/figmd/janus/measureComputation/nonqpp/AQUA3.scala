package com.figmd.janus.measureComputation.nonqpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AQUA 3
* Measure Title              :- Cryptorchidism: Inappropriate use of scrotal/groin ultrasound on boys
* Measure Description        :- Percentage of patients (boys) =< 18 yrs. of age newly diagnosed with undescended testis
                                or retractile testis with an order for ultrasound (scrotal or groin) placed.
* Calculation Implementation :- Patient Specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/


object AQUA3 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Aqua3"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, initialRDD
      , AQUA3Elements.Obese_Or_Overweight
      , AQUA3Elements.Clinical_Concerns
      , AQUA3Elements.Torsion_Of_Undescended_Testis
      , AQUA3Elements.Order_For_Scrotal_Or_Groin_Ultrasound
      , AQUA3Elements.Cryptorchidism
      , AQUA3Elements.Hypospadias
      , AQUA3Elements.Sexual_Differentiation_Disorder
      , AQUA3Elements.Bilateral_Non_Palpable_Testes
    ).collect.toList
    val patientHistory: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistory)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Exclusion
      val exclusionRDD = getExclusion(initialRDD, patientHistory)
      exclusionRDD.cache()

      val intermediateNumerator = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateNumerator.cache()

      // Filter Met
      val metRDD = getMet(intermediateNumerator, patientHistory)
      metRDD.cache()

      // Filter Intermediate
      val intermediateException = getSubtractRDD(intermediateNumerator, metRDD)
      intermediateException.cache()

      // Filter Exclusion
      val exceptionRDD = getExceptionRdd(intermediateException, patientHistory)
      exceptionRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, ippRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistory.unpersist()

    }

  }

  /*--------------------------------------------------------------------------------------------------------------------
    Number of patients (boys) =< 18 yrs. of age newly diagnosed with undescended testis or retractile testis
   -------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isDiagnosedOnEncounter(visit, m, AQUA3Elements.Cryptorchidism)
        && isVisitTypeIn(visit, m
        , AQUA3Elements.Office_Visit
        , AQUA3Elements.Outpatient_Consultation
        , AQUA3Elements.Inpatient_Consultation)

    )

  }

  /*--------------------------------------------------------------------------------------------------------------------
  Relative exclusion – obese/overweight boys with nonpalpable testis may benefit from ultrasound to identify an inguinal testis;
  clinical concern of torsion of undescended testis, or to differentiate UDT from incarcerated hernia or other acute scrotal/inguinal process
 -------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(rdd: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      wasDiagnosedBeforeEncounter(visit, m, AQUA3Elements.Obese_Or_Overweight, patientHistory)
        || wasDiagnosedBeforeEncounter(visit, m, AQUA3Elements.Clinical_Concerns, patientHistory)
        || wasDiagnosedBeforeEncounter(visit, m, AQUA3Elements.Torsion_Of_Undescended_Testis, patientHistory)

    )

  }

  /*--------------------------------------------------------------------------------------------------------------------
  Number of patients (boys) =< 18 yrs. of age newly diagnosed with undescended testis or retractile testis with a scrotal or groin ultrasound order placed
   -------------------------------------------------------------------------------------------------------------------*/


  def getMet(ippRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      wasLaboratoryTestOrderAfterDiagnosis(visit, m, AQUA3Elements.Order_For_Scrotal_Or_Groin_Ultrasound, patientHistory, AQUA3Elements.Cryptorchidism)
        && isLaboratoryTestOrder(visit, m, AQUA3Elements.Order_For_Scrotal_Or_Groin_Ultrasound,patientHistory)
    )
  }


  /*--------------------------------------------------------------------------------------------------------------------
  1) Boys with hypospadias or other findings concerning for disorder of sexual differentiation;
  2) Boys with bilateral nonpalpable testes
   -------------------------------------------------------------------------------------------------------------------*/


  def getExceptionRdd(intermediateException: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      wasDiagnosedBeforeEncounter(visit, m, AQUA3Elements.Hypospadias, patientHistory)
        || wasDiagnosedBeforeEncounter(visit, m, AQUA3Elements.Sexual_Differentiation_Disorder, patientHistory)
        || wasDiagnosedBeforeEncounter(visit, m, AQUA3Elements.Bilateral_Non_Palpable_Testes, patientHistory)
    )
  }

}






