package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, _}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp384
* Measure Title              :- Adult Primary Rhegmatogenous Retinal Detachment Surgery: No Return to the Operating Room Within 90 Days of Surgery
* Measure Description        :- Patients aged 18 years and older who had surgery for primary rhegmatogenous retinal detachment who did not require a return to the operating room within 90 days of surgery
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp384 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp384"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP384Elements.Primary_Rhegmatogenous_Retinal_Detachment,
      QPP384Elements.Primary_Rhegmatogenous_Retinal_Detachment_Eye,
      QPP384Elements.Return_To_The_Or___Eye,
      QPP384Elements.Return_To_The_Or,
      QPP384Elements.Primary_Rhegmatogenous_Retinal_Detachment,
      QPP384Elements.Return_To_Operating_Room_Not_Met
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isProcedurePerformedWithinXMonths(visit, m, QPP384Elements.Primary_Rhegmatogenous_Retinal_Detachment, 9, patientHistoryBroadcastList)
    )
  }


  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
      isMedicationAdministeredOnEncounter(visit, m, QPP384Elements.Silicone_Oil)
        || isProcedurePerformedDuringEncounter(visit, m, QPP384Elements.Surgical_Procedures_Silicone_Oil_Use)
    )
  }

  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateForMet.filter(visit =>
      (
        (
          isProcedurePerformedDuringEncounter(visit, m, QPP384Elements.Return_To_Operating_Room)
            && checkEyeOnEncounterEqualsWithOtherEye(visit, m, true, QPP384Elements.Return_To_The_Or___Eye, patientHistoryBroadcastList, Seq(QPP384Elements.Primary_Rhegmatogenous_Retinal_Detachment_Eye))
          )
          ||
          !(
            isPhysicalExamPerformedInXDaysAfterProcedure(visit, m, QPP384Elements.Primary_Rhegmatogenous_Retinal_Detachment, QPP384Elements.Return_To_The_Or, 90, patientHistoryBroadcastList)
              && checkEyeOnEncounterEqualsWithOtherEye(visit, m, true, QPP384Elements.Return_To_The_Or___Eye, patientHistoryBroadcastList, Seq(QPP384Elements.Primary_Rhegmatogenous_Retinal_Detachment_Eye))
            )
        )
        && !isProcedurePerformed(visit, m, QPP384Elements.Return_To_Operating_Room_Not_Met, patientHistoryBroadcastList)
    )
  }

}
