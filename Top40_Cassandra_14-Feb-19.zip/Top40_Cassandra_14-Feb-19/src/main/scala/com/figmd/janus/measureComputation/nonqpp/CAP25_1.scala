package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, CAP25Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAP25_1
* Measure Title               :- Cancer Protocol and Turnaround Time for Carcinoma of the Pancreas
* Measure Description         :- Percentage of all eligible pancreatic exocrine carcinoma (including small cell and
*                                large cell (poorly differentiated) neuroendocrine carcinoma) specimens:
                                 - Partial Pancreatectomy
                                 - Total Pancreatectomy
                                 - Pancreaticoduodenectomy (Whipple Resection)
                                 for which all required data elements of the Cancer Protocol are included
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- None
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.6
----------------------------------------------------------------------------------------------------------------------------*/

object CAP25_1 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "CAP25_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
        , CAP25Elements.Confirm_Pancreatic_Carcinoma_Resection
        , CAP25Elements.Surgical_Pathology_Accession_Number
        , CAP25Elements.Consultation_Catii
        , CAP25Elements.Surgical_Pathology_Accession_Number_Date
        , CAP25Elements.Confirm_Case_Required_Consultation
        , CAP25Elements.Confirm_Case_Required_Consultation_Date
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All final pathology reports for eligible pancreatic exocrine carcinoma cases that require the use of a CAP cancer protocol.
CPT®: 88309
AND
Any of the ICD 10 codes:
C25: malignant neoplasm of pancreas
C25.0: malignant neoplasm of head of pancreas
C25.1: malignant neoplasm of body of pancreas
C25.2: malignant neoplasm of tail of pancreas
C25.3: malignant neoplasm of pancreatic duct
C25.7: malignant neoplasm of other parts of pancreas
C25.8: malignant neoplasm of overlapping sites of pancreas
C25.9: malignant neoplasm of pancreas, unspecified
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
        isDiagnosisOverlapsProcedure(visit, m, CAP25Elements.Confirm_Pancreatic_Carcinoma_Resection,
                              CAP25Elements.Surgical_Pathology_Accession_Number, patientHistoryBroadcastList)
      &&
        isLaboratoryTestOrder(visit, m, CAP25Elements.Surgical_Pathology_Accession_Number, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
1.Biopsy procedures
2.Intraductal papillary mucinous neoplasms without associated invasive carcinoma
3.Mucinous cystic neoplasms without associated invasive carcinoma
4.Well-differentiated neuroendocrine tumors
5.Tumors of the ampulla of Vater
6.Lymphoma Sarcoma
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        isDiagnosisListDuringLaboratoryTest(visit, m, CAP25Elements.Surgical_Pathology_Accession_Number
              , CAP25Elements.Tumors_Of_Ampulla_Of_Vater
              , CAP25Elements.Low_Grade_Neuroendocrine_Tumors
              , CAP25Elements.Lymphoma_And_Sarcoma
              , CAP25Elements.Mucinous_Cystic_Neoplasms
              , CAP25Elements.Intraductal_Papillary_Mucinous_Neoplasm
        )
      ||
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Biopsy, CAP25Elements.Biopsy_Date,
                CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
      ||
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Biopsy_Or_Low_Grade_Tumor,
                CAP25Elements.Biopsy_Or_Low_Grade_Tumor_Date, CAP25Elements.Surgical_Pathology_Accession_Number,
                CAP25Elements.Surgical_Pathology_Accession_Number_Date)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
 All eligible cases containing all of the required elements found in the current CAP Pancreatic Exocrine protocol. Optional data (marked with a “+” in the CAP cancer protocol) is not required but may be present.
The current protocol, the required elements include:
- Procedure
- Tumor Site
- Tumor Size
- Histologic Type
- Histologic Grade (ductal carcinoma only)
- Tumor Extension
- Margins
- Treatment Effect (required only if applicable)
- Lymphovascular Invasion
- Perineural Invasion
- Regional Lymph Nodes
- Pathologic Stage Classification (pTNM, AJCC 8th Edition)
* If an item is not applicable, an “N/A” listing is required.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
        (
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Procedure_Documented, CAP25Elements.Procedure_Documented_Date,
              CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Tumor_Site_Documented, CAP25Elements.Tumor_Site_Documented_Date,
              CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Tumor_Size_Documented, CAP25Elements.Tumor_Size_Documented_Date,
              CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Histologic_Type_Documented, CAP25Elements.Histologic_Type_Documented_Date,
              CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Histologic_Grade__Ductal_Carcinoma_Only__Documented,
              CAP25Elements.Histologic_Grade__Ductal_Carcinoma_Only__Documented_Date,
              CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Microscopic_Tumor_Extension_Documented,
              CAP25Elements.Microscopic_Tumor_Extension_Documented_Date,
              CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Margins_Documented, CAP25Elements.Margins_Documented_Date,
              CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Lymph_Vascular_Invasion_Documented,
              CAP25Elements.Lymph_Vascular_Invasion_Documented_Date,
              CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Perineural_Invasion_Documented,
              CAP25Elements.Perineural_Invasion_Documented_Date,
              CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Regional_Lymph_Nodes, CAP25Elements.Regional_Lymph_Nodes_Date,
              CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Pathologic_Stage_Classification_Documented,
              CAP25Elements.Pathologic_Stage_Classification_Documented_Date,
              CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
        )
        ||
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Pancreatic_Cancer_Protocol, CAP25Elements.Pancreatic_Cancer_Protocol_Date,
              CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
      )
      && !
        isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP25Elements.Pancreas_Cancer_Not_Met, CAP25Elements.Pancreas_Cancer_Not_Met_Date,
            CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Cases requiring intra-departmental or extra-departmental consultation.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
          isCommunicationFromProviderToProviderDuringLaboratoryTest(visit, m, CAP25Elements.Surgical_Pathology_Accession_Number, CAP25Elements.Surgical_Pathology_Accession_Number_Date,
          CAP25Elements.Confirm_Case_Required_Consultation, CAP25Elements.Confirm_Case_Required_Consultation_Date,
          patientHistoryBroadcastList)
        ||
          isCommunicationFromProvidertoProvider(visit, m, CAP25Elements.Consultation_Catii, patientHistoryBroadcastList)
    )
  }

}

