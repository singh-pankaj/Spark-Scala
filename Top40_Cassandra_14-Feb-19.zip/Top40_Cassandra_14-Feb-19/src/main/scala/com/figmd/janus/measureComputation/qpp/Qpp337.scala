package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, QPP337Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 337
* Measure Title              :- Psoriasis: Tuberculosis (TB) Prevention for Patients with Psoriasis, Psoriatic Arthritis
                                and Rheumatoid Arthritis on a Biological Immune Response Modifier
* Measure Description        :- Percentage of patients, regardless of age, with Psoriasis, Psoriatic Arthritis and
                                Rheumatoid Arthritis on a Biological Immune Response Modifier whose providers are
                                ensuring active tuberculosis prevention either through yearly negative standard
                                tuberculosis screening tests or are reviewing the patient’s history to determine
                                if they have had appropriate management for a recent or prior positive test
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score equals better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp337 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP337"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP337Elements.Biologic_Immune_Response_Modifier_Grp
      , QPP337Elements.Biologic_Immune_Response_Modifiers
      , QPP337Elements.Initials_Of_Clinician_Prescribed_The_Biologic
      , QPP337Elements.Initials_Of_Clinician_That_Administered_The_Tb_Test
      , QPP337Elements.Initials_Of_Clinician_That_Performed_Skin_Test
      , QPP337Elements.Mantoux_Test
      , QPP337Elements.Mantoux_Test_Negative
      , QPP337Elements.Mantoux_Test_Positive
      , QPP337Elements.Ct_Scan
      , QPP337Elements.History_Of_Tuberculosis
      , QPP337Elements.Negative_Imaging
      , QPP337Elements.Chest_X_Ray
      , QPP337Elements.History_Of_Tuberculosis
      , QPP337Elements.Negative_Imaging
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*------------------------------------------------------------------------------
     All patients, regardless of age, with a diagnosis of psoriasis and/or psoriatic arthritis and/or rheumatoid
     arthritis who are on a biologic immune response modifier
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)


    initialRDD.filter(visit =>
      (
          isDiagnosedOnEncounter(visit,m,QPP337Elements.Psoriasis_Or_Psoriatic_Arthritis)
       || isDiagnosedOnEncounter(visit,m,QPP337Elements.Rheumatoid_Arthritis)
      )
    && isVisitTypeIn(visit,m
                            ,QPP337Elements.Office_Visit
                            ,QPP337Elements.Outpatient_Consultation
                            ,QPP337Elements.Initial_Preventive_Physical_Examination_Grp
                     )
    &&
        (
            (
                wasMedicationActiveBeforeOrEqualStartDate(visit,m,QPP337Elements.Biologic_Immune_Response_Modifier_Grp,patientHistoryBroadcastList)
             || wasMedicationActiveBeforeOrEqualStartDate(visit,m,QPP337Elements.Biologic_Immune_Response_Modifiers,patientHistoryBroadcastList)
            )
        ||  (
                isAssessmentPerformed(visit,m,QPP337Elements.Biologic_Immune_Response_Modifier_Grp,patientHistoryBroadcastList)
             || isMedicationOrdered(visit,m,patientHistoryBroadcastList,QPP337Elements.Biologic_Immune_Response_Modifiers)
            )
        )
    && isPOSEncounterNotPerformed(visit,m,QPP337Elements.Pos_02_Date)
    && !isTeleHealthModifier(visit,m
                                    ,QPP337Elements.Office_Visit_Telehealth_Modifier
                                    ,QPP337Elements.Outpatient_Consultation_Telehealth_Modifier
                                    ,QPP337Elements.Initial_Preventive_Physical_Examination_Telehealth_Modifier

                            )
    )
  }




  /*------------------------------------------------------------------------------
    Patients who have a documented negative annual TB screening or have documentation of the management of a positive
    TB screening test with no evidence of active tuberculosis, confirmed through use of radiographic imaging (i.e., chest x-ray, CT)
   ------------------------------------------------------------------------------*/

  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
      isLaboratoryTestOrder(visit,m,QPP337Elements.Screening_Of_Tuberculosis,patientHistoryBroadcastList)
    ||
     (
      (
        (
            wasInterventionPerformedBeforeEncounterWithinXMonths(visit,m,QPP337Elements.Initials_Of_Clinician_Prescribed_The_Biologic,12,patientHistoryBroadcastList)
         && wasInterventionPerformedBeforeEncounterWithinXMonths(visit,m,QPP337Elements.Initials_Of_Clinician_That_Administered_The_Tb_Test,12,patientHistoryBroadcastList)
         && wasInterventionPerformedBeforeEncounterWithinXMonths(visit,m,QPP337Elements.Initials_Of_Clinician_That_Performed_Skin_Test,12,patientHistoryBroadcastList)
        )
        &&
          (
            wasProcedurePerformedwithResultBeforeEncounter(visit,m
                                                                    ,QPP337Elements.Mantoux_Test
                                                                    ,QPP337Elements.Mantoux_Test_Negative,CalenderUnit.MONTH,12,patientHistoryBroadcastList)
          ||
              (
                wasProcedurePerformedwithResultBeforeEncounter(visit,m
                                                                  ,QPP337Elements.Mantoux_Test
                                                                  ,QPP337Elements.Mantoux_Test_Positive,CalenderUnit.MONTH,12,patientHistoryBroadcastList)
                    &&
                      (
                            wasProcedurePerformedwithReasonAndResultBeforeEncounter(visit,m
                                                                                        ,QPP337Elements.Ct_Scan
                                                                                        ,QPP337Elements.History_Of_Tuberculosis
                                                                                        ,QPP337Elements.Negative_Imaging,12,patientHistoryBroadcastList)
                        ||  wasProcedurePerformedwithReasonAndResultBeforeEncounter(visit,m
                                                                                            ,QPP337Elements.Chest_X_Ray
                                                                                            ,QPP337Elements.History_Of_Tuberculosis
                                                                                            ,QPP337Elements.Negative_Imaging,12,patientHistoryBroadcastList)
                      )
              )
          )
      )
    ||
        (
          (
                 isInterventionPerformed(visit,m,QPP337Elements.Initials_Of_Clinician_Prescribed_The_Biologic,patientHistoryBroadcastList)
              && isInterventionPerformed(visit,m,QPP337Elements.Initials_Of_Clinician_That_Administered_The_Tb_Test,patientHistoryBroadcastList)
              && isInterventionPerformed(visit,m,QPP337Elements.Initials_Of_Clinician_That_Performed_Skin_Test,patientHistoryBroadcastList)
            )
            &&
            (
              wasProcedurePerformedwithResultBeforeEncounter(visit,m
                                                                    ,QPP337Elements.Mantoux_Test
                                                                    ,QPP337Elements.Mantoux_Test_Negative,CalenderUnit.MONTH,12,patientHistoryBroadcastList)
                ||
                (
                  wasProcedurePerformedwithResultBefore(visit,m
                                                                ,QPP337Elements.Mantoux_Test
                                                                ,QPP337Elements.Mantoux_Test_Positive,12,patientHistoryBroadcastList)
                    &&
                    (
                       wasProcedurePerformedwithReasonAndResultBefore(visit,m
                                                                              ,QPP337Elements.Ct_Scan
                                                                              ,QPP337Elements.History_Of_Tuberculosis
                                                                              ,QPP337Elements.Negative_Imaging,12,patientHistoryBroadcastList)
                        ||  wasProcedurePerformedwithReasonAndResultBefore(visit,m
                                                                                  ,QPP337Elements.Chest_X_Ray
                                                                                  ,QPP337Elements.History_Of_Tuberculosis
                                                                                  ,QPP337Elements.Negative_Imaging,12,patientHistoryBroadcastList)
                    )
                  )
              )
          )
       )
    && !isAssessmentPerformed(visit,m,QPP337Elements.Tb_Screening_Not_Met,patientHistoryBroadcastList)
    )

  }

  /*------------------------------------------------------------------------------
   Documentation of patient reasons(s) for not having records of negative or managed positive TB screen
   (e.g., patient does not return for Mantoux (PPD) skin test evaluation)
   ------------------------------------------------------------------------------*/

  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateForException.filter(visit =>
        isLaboratoryTestOrder(visit,m,QPP337Elements.Tb_Screen_Patient_Reason_Grp,patientHistoryBroadcastList)
     || isLaboratoryTestOrder(visit,m,QPP337Elements.No_Return_Mantoux__Ppd__Skin_Test_Evaluation_Grp,patientHistoryBroadcastList)
    )

  }
}

