package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,CAP27Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAP27_1
* Measure Title               :- Cancer Protocol and Turnaround Time for Invasive Carcinoma of Renal Tubular Origin
* Measure Description         :-  Percentage of all eligible kidney resections specimens:
                                  Partial Nephrectomy
                                  Total Nephrectomy
                                  Radical Nephrectomy
                                  for which all required data elements of the Cancer Protocol are included
                                  AND meet the maximum 4 business day turnaround time (TAT) requirement (Report Date – Accession Date ≤ 4 business days).
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KIRTI_RAUT_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.8
----------------------------------------------------------------------------------------------------------------------------*/

object CAP27_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "CAP27_1"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      CAP27Elements.Confirm_Renal_Tubular_Carcinoma_Resection,
      CAP27Elements.Consultation_CATII
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population :
All final pathology reports for eligible kidney resection cases that require the use of a CAP cancer protocol.
CPT®: 88307
AND
Any of the ICD 10 codes:
C64: malignant neoplasm of kidney, except renal pelvis
C64.1: malignant neoplasm of right kidney, except renal pelvis
C64.2: malignant neoplasm of left kidney, except renal pelvis
C64.9: malignant neoplasm of unspecified kidney, except renal pelvis
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      wasDiagnosisBeforeOrEqualProcedure(visit,m,CAP27Elements.Confirm_Renal_Tubular_Carcinoma_Resection,CAP27Elements.Surgical_pathology_accession_number,patientHistoryBroadcastList)
      &&  isProcedurePerformedDuringEncounter(visit,m,CAP27Elements.Surgical_pathology_accession_number) // Its a Procedure Specific measure hence checking Procedure on Encounter rather than during measurement period

    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exclusion :
1.Biopsy procedures
2.Wilms tumors
3.Tumors of urothelial origin
Lymphoma and Sarcoma
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
      (      isLaboratoryTestPerformedDuringProcedure(visit,m,CAP27Elements.Biopsy,CAP27Elements.Biopsy_Date,CAP27Elements.Surgical_pathology_accession_number,CAP27Elements.Surgical_pathology_accession_number_Date)
        ||   isDiagnosedDuringProcedure(visit,m,CAP27Elements.Lymphoma_and_Sarcoma,CAP27Elements.Surgical_pathology_accession_number)
        ||   isDiagnosedDuringProcedure(visit,m,CAP27Elements.Urothelial_and_Wilms_Tumor,CAP27Elements.Surgical_pathology_accession_number)
       )
      || isLaboratoryTestPerformedDuringProcedure(visit,m,CAP27Elements.Biopsy_Dateor_Lymphoma_or_WIlms_Tumor,CAP27Elements.Biopsy_Dateor_Lymphoma_or_WIlms_Tumor_Date,CAP27Elements.Surgical_pathology_accession_number,CAP27Elements.Surgical_pathology_accession_number_Date)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator :
Rate 1: All eligible cases containing all of the required elements found in the current CAP Invasive Carcinoma of Renal Tubular Origin protocol. Optional data (marked with a “+” in the CAP cancer protocol) is not required but may be present.
The current protocol, the required elements include:
Specimen Laterality
Procedure
Tumor Size (largest tumor if multiple)
Tumor Focality
Histologic Type
Sarcomatoid Features
Rhabdoid Features
Histologic Grade
Tumor Necrosis
Tumor Extension
Margins
Regional Lymph Nodes
Pathologic Stage Classification (pTNM, AJCC 8th Edition)
Pathologic Findings in Non-neoplastic Kidney
* If an item is not applicable, an “N/A” listing is required.
Rate 2: Final pathology report in the laboratory/hospital information system with result verified and reported by the laboratory, available to the requesting physician(s) within 4 business days.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    // Its a Procedure Specific measure hence checking All Lab Tests on Encounter

    intermediateForMet.filter(visit =>
            (
                            (       isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Specimen_Laterality_Documented)
                                &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Procedure_Documented)
                                &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Tumor_Size_Documented)
                                &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Tumor_Focality_Documented)
                                &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Histologic_Type_documented)
                                &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Sarcomatoid_Features_Present_Documented)
                                &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Rhabdoid_features_Documented)
                                &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Histologic_Grade_Documented)
                                &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Tumor_Necrosis_Present_Documented)
                                &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Tumor_Extension_Documented)
                                &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Margins_Documented)
                                &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Regional_Lymph_nodes_documented)
                                &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Pathologic_Findings_in_Nonneoplastic_Kidney_Documented)
                                &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Pathologic_Stage_Classification_Documented)
                              )
                            ||

                                isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.CAP_Renal_Protocol)

            )
      && ! isLaboratoryTestPerformedOnEncounter(visit,m,CAP27Elements.Renal_Protocol_Not_Met)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exception: Cases requiring intra-departmental or extra-departmental consultation.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
            isCommunicationFromProviderToProviderOnEncounter(visit,m,CAP27Elements.Confirm_case_required_Consultation)
        ||  isCommunicationFromProvidertoProvider(visit,m,CAP27Elements.Consultation_CATII,patientHistoryBroadcastList)

    )
  }
}
