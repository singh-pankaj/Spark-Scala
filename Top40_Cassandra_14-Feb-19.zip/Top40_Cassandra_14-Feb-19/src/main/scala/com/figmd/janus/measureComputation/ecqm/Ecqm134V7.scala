package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ECQM134V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS134v7
* Measure Title              :- Diabetes: Medical Attention for Nephropathy
* Measure Description        :- The percentage of patients 18-75 years of age with diabetes who had a nephropathy screening
*                               test or evidence of nephropathy during the measurement period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm134V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm134V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patient_history_list = getPatientHistory(sparkSession, initialRDD,
      ECQM134V7Elements.Diabetes,
      ECQM134V7Elements.Discharged_To_Home_For_Hospice_Care,
      ECQM134V7Elements.Ace_Inhibitor_Or_Arb,
      ECQM134V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
      ECQM134V7Elements.Hospice_Care_Ambulatory,
      ECQM134V7Elements.Hypertensive_Chronic_Kidney_Disease,
      ECQM134V7Elements.Kidney_Failure,
      ECQM134V7Elements.Glomerulonephritis_And_Nephrotic_Syndrome,
      ECQM134V7Elements.Diabetic_Nephropathy,
      ECQM134V7Elements.Proteinuria,
      ECQM134V7Elements.Kidney_Transplant,
      ECQM134V7Elements.Vascular_Access_For_Dialysis,
      ECQM134V7Elements.Dialysis_Services,
      ECQM134V7Elements.Other_Services_Related_To_Dialysis,
      ECQM134V7Elements.Dialysis_Education,
      ECQM134V7Elements.Esrd_Monthly_Outpatient_Services,
      ECQM134V7Elements.Urine_Protein_Tests).collect().toList


    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //eligible RDD

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //val eligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }

  //Patients 18-75 years of age with diabetes with a visit during the measurement period
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeBetween(visit, m, 18, "ge", 75, "lt", "startDate")
        &&
        isDiagnosisOverlapsEncounter(visit, m, patientHistoryList,ECQM134V7Elements.Diabetes)
        &&
        isVisitTypeIn(visit, m,
          ECQM134V7Elements.Office_Visit,
          ECQM134V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
          ECQM134V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
          ECQM134V7Elements.Home_Healthcare_Services,
          ECQM134V7Elements.Annual_Wellness_Visit)
    )
  }

  //Patients who use hospice services any time during the measurement period
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit => (

      isEncounterPerformedWithDischargeStatus(visit, m, ECQM134V7Elements.Encounter_Inpatient, ECQM134V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        || isEncounterPerformedWithDischargeStatus(visit, m, ECQM134V7Elements.Encounter_Inpatient, ECQM134V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        //Commented below code as "Overlaps measurement period" is inclusive of "During measurement period".
        //         ||
        //         isInterventionOrder(visit, m, ECQM134V7Elements.Hospice_Care_Ambulatory,patientHistoryList)
        || wasInterventionPerformedInHistory(visit, m, ECQM134V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
      )
    )
  }

  //Patients with a screening for nephropathy or evidence of nephropathy during the measurement period
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit => (
      (
        wasMedicationActiveInHistory(visit, m, ECQM134V7Elements.Ace_Inhibitor_Or_Arb, patientHistoryList)
          ||
          wasDiagnosedInHistory(visit, m, ECQM134V7Elements.Hypertensive_Chronic_Kidney_Disease, patientHistoryList)
          ||
          wasDiagnosedInHistory(visit, m, ECQM134V7Elements.Kidney_Failure, patientHistoryList)
          ||
          wasDiagnosedInHistory(visit, m, ECQM134V7Elements.Glomerulonephritis_And_Nephrotic_Syndrome, patientHistoryList)
          ||
          wasDiagnosedInHistory(visit, m, ECQM134V7Elements.Diabetic_Nephropathy, patientHistoryList)
          ||
          wasDiagnosedInHistory(visit, m, ECQM134V7Elements.Proteinuria, patientHistoryList)
        )
        ||
        (
          isProcedurePerformed(visit, m, ECQM134V7Elements.Kidney_Transplant, patientHistoryList)
            ||
            isProcedurePerformed(visit, m, ECQM134V7Elements.Vascular_Access_For_Dialysis, patientHistoryList)
            ||
            isProcedurePerformed(visit, m, ECQM134V7Elements.Dialysis_Services, patientHistoryList)
            ||
            isInterventionPerformed(visit, m, ECQM134V7Elements.Other_Services_Related_To_Dialysis, patientHistoryList)
            ||
            isInterventionPerformed(visit, m, ECQM134V7Elements.Dialysis_Education, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM134V7Elements.Esrd_Monthly_Outpatient_Services, patientHistoryList)
            ||
            isLaboratoryTestPerformed(visit, m, ECQM134V7Elements.Urine_Protein_Tests, patientHistoryList)
          )
      )

    )
  }
}