package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, TEST15Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Test15
* Measure Title               :- Cerumen Impaction: Treatment for Non-Intact Tympanic Membrane
* Measure Description         :- Percentage of patients with cerumen impaction and a suggestive history of a non-intact
*                                tympanic membrane who receive just manual removal.
* Calculation Implementation  :- Visit-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.6
----------------------------------------------------------------------------------------------------------------------------*/

object TEST15 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "Test15"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , TEST15Elements.Ear_Surgery_Affecting_Tympanic_Membrane
      , TEST15Elements.Cerumen_Impaction
      , TEST15Elements.Non__Intact_Tympanic_Membrane
      , TEST15Elements.Open_Mastoid_Cavity
      , TEST15Elements.Ear_Surgery_Affecting_Tympanic_Membrane
      , TEST15Elements.Cerumen_Removal
      , TEST15Elements.Irrigation
      , TEST15Elements.Cerumenolytics
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients over 6 months of age who present with an ambulatory visit with cerumen impaction where
  at least one method to remove cerumen was attempted who also have a non-intact tympanic membrane (current,
  resolved or historical diagnosis) or open mastoid cavity.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
            isAgeAboveInMonth(visit, m, true, 6)
          &&
            isVisitTypeIn(visit, m, TEST15Elements.Ambulatory_Visit)
          &&
            isDiagnosedDuringEncounter(visit, m, TEST15Elements.Cerumen_Impaction)
          &&
            (
                isDiagnosedDuringEncounter(visit, m, TEST15Elements.Non__Intact_Tympanic_Membrane)
              ||
                isDiagnosedDuringEncounter(visit, m, TEST15Elements.Open_Mastoid_Cavity)
            )
          &&
            (
                isProcedurePerformedAfterDiagnosisAndBeforeEnd(visit, m, TEST15Elements.Ear_Surgery_Affecting_Tympanic_Membrane,
                        patientHistoryBroadcastList, TEST15Elements.Cerumen_Impaction,
                                                    TEST15Elements.Non__Intact_Tympanic_Membrane)
              ||
                isProcedurePerformedAfterDiagnosisAndBeforeEnd(visit, m, TEST15Elements.Ear_Surgery_Affecting_Tympanic_Membrane,
                        patientHistoryBroadcastList, TEST15Elements.Cerumen_Impaction,
                                                    TEST15Elements.Open_Mastoid_Cavity)
              ||
                isProcedurePerformedAfterDiagnosisAndBeforeEnd(visit, m, TEST15Elements.Cerumen_Removal,
                        patientHistoryBroadcastList, TEST15Elements.Cerumen_Impaction,
                                                    TEST15Elements.Non__Intact_Tympanic_Membrane)
              ||
                isProcedurePerformedAfterDiagnosisAndBeforeEnd(visit, m, TEST15Elements.Cerumen_Removal,
                        patientHistoryBroadcastList, TEST15Elements.Cerumen_Impaction,
                                                    TEST15Elements.Open_Mastoid_Cavity)
            )

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients where a cerumenolytic or irrigation was not used for cerumen removal after a diagnosis of
  non-intact tympanic membrane or open mastoid cavity.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      ! (
            isProcedurePerformedAfterDiagnosisAndBeforeEnd(visit, m, TEST15Elements.Irrigation,
                                  patientHistoryBroadcastList, TEST15Elements.Non__Intact_Tympanic_Membrane)
          ||
            isProcedurePerformedAfterDiagnosisAndBeforeEnd(visit, m, TEST15Elements.Irrigation,
                                  patientHistoryBroadcastList, TEST15Elements.Open_Mastoid_Cavity)
          || //Medication Ordered and Administered are same.
            isMedicationActiveAfterDiagnosisAndBeforeEnd(visit, m, TEST15Elements.Cerumenolytics,
                                  patientHistoryBroadcastList, TEST15Elements.Open_Mastoid_Cavity)
          ||
            isMedicationActiveAfterDiagnosisAndBeforeEnd(visit, m, TEST15Elements.Cerumenolytics,
                                  patientHistoryBroadcastList, TEST15Elements.Non__Intact_Tympanic_Membrane)
        )
    )
  }

}