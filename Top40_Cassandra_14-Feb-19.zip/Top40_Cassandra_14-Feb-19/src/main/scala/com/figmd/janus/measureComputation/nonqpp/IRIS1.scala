package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, IRIS1Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- IRIS 1
* Measure Title              :- Endothelial Keratoplasty - Post-operative improvement in best corrected visual acuity
                                to 20/40 or better
* Measure Description        :- Percentage of endothelial keratoplasty patients with a best corrected visual acuity
                                of 20/40 or better at 90 days after surgery.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS1"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession,rdd
                                                              ,IRIS1Elements.Indication_For_Surgery
                                                              ,IRIS1Elements.Corneal_Graft_Procedure
                                                              ,IRIS1Elements.Indication_For_Surgery
                                                              ,IRIS1Elements.Corneal_Graft_Procedure
                                                              ,IRIS1Elements.Conditions_Complicating_Surgery
                                                              ,IRIS1Elements.Diagnosis___Eye
                                                              ,IRIS1Elements.Indication_For_Surgery__Eye
                                                              ,IRIS1Elements.Systemic_Sympathetic_Alpha_1a_Antagonist_Medication
                                                              ,IRIS1Elements.Systemic_Sympathetic_Alpha_1a_Antagonist_Medication___Eye
                                                              ,IRIS1Elements.Procedures_Complicating_Surgery
                                                              ,IRIS1Elements.Surgery___Eye
                                                              ,IRIS1Elements.Best_Corrected_Left_Eye_Va_Value
                                                              ,IRIS1Elements.Best_Corrected_Right_Eye_Va_Value
                                                )
    val patientHistory: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    val Correct_VA_Values: Array[String] = Array("20/10","20/11","20/12","20/13","20/14","20/15","20/16","20/17","20/18","20/19","20/2","20/20","20/21","20/22","20/23","20/24","20/25","20/26","20/28","20/29","20/3","20/30","20/31","20/32","20/33","20/34","20/35","20/36","20/37","20/38","20/39","20/4","20/5","20/6","20/7","20/8","20/9","20/40")
    // Filter IPP
    val ippRDD = getIpp(rdd,patientHistory)
    ippRDD.cache()

    // denominator RDD
    val denominatorRDD = ippRDD
    denominatorRDD.cache()

    /*exclusion RDD*/
    val exclusionRDD =  sparkSession.sparkContext.emptyRDD[CassandraRow]
    exclusionRDD.cache()

    // Filter Intermediate RDD
    val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA,patientHistory,Correct_VA_Values)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA, metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD,denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    patientHistory.destroy()
  }

  /*------------------------------------------------------------------------------
    Patients aged 18 years or older who underwent a corneal graft procedure
   ------------------------------------------------------------------------------*/

  def getIpp(rdd: RDD[CassandraRow],patientHistory:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
          isPatientAdult(visit,m)
      &&  wasProcedurePerformedBeforeEndInDays(visit,m,IRIS1Elements.Corneal_Graft_Procedure,90,patientHistory)
      &&  isProcedurePerformedDuringEncounter(visit,m,IRIS1Elements.Corneal_Graft_Procedure)
      &&  isDiagnosedOnEncounter(visit,m,IRIS1Elements.Indication_For_Surgery)
      &&  checkEyeElementsInRange(visit,m,IRIS1Elements.Indication_For_Surgery__Eye,IRIS1Elements.Corneal_Graft_Procedure___Eye)

    )
  }

  /*------------------------------------------------------------------------------
   Aphakia, Anterior chamber IOL, Prior penetrating keratoplasty,Prior glaucoma filtering surgery,Choroidal Hemorrhage
   and Rupture,Chronic Iridocyclitis,Degeneration of Macula and Posterior Pole,Degenerative Disorders of Globe,Diabetic
   Macular Edema,Diabetic Retinopathy,Disorders of Optic Chiasm,Disorders of Visual Cortex,Disseminated Chorioretinitis
   and Disseminated Retinochoroiditis,Hereditary Choroidal Dystrophies,Hereditary Retinal Dystrophies,Injury to Optic
   Nerve and Pathways,Moderate or Severe Impairment, Better Eye, Profound Impairment Lesser Eye,Nystagmus and Other
   Irregular Eye Movements,Optic Atrophy,Other Endophthalmitis,Other Proliferative Retinopathy,Pathologic Myopia,
   Profound Impairment,Both Eyes,Purulent Endophthalmitis,Retinal Vascular Occlusion,Scleritis and Episcleritis,Prior
   Pars Plana Vitrectomy,Acute and Subacute Iridocyclitis,Adhesions and  Disruptions of Iris and  Ciliary Body,
   Dislocation of Lens,Cataract Secondary to Ocular Disorders,Cataract, Congenital,	Cataract, Mature or Hypermature,
   Cataract, Posterior Polar,Central Corneal Ulcer,High Hyperopia,	Hypotony of Eye,Injury to Optic Nerve and Pathways,
   Open Wound of Eyeball,Pathologic Myopia,	Posterior Lenticonus,Retrolental Fibroplasias,Traumatic Cataract,Use of
   Systemic Sympathetic Alpha-1a Antagonist Medication for Treatment of Prostatic Hypertrophy Patient taking tamsulosin
   hydrochloride,	Uveitis,Vascular Disorders of Iris and Ciliary Body
   ------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistory:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
       (
           isDiagnosedWithBeforeOrEqual(visit,m,IRIS1Elements.Conditions_Complicating_Surgery_Date,patientHistory,IRIS1Elements.Corneal_Graft_Procedure)
        && checkEyeElementsInRange(visit,m,IRIS1Elements.Diagnosis___Eye,IRIS1Elements.Indication_For_Surgery__Eye)
       )
    ||
       (
           isDiagnosedWithBeforeOrEqual(visit,m,IRIS1Elements.Systemic_Sympathetic_Alpha_1a_Antagonist_Medication_Date,patientHistory,IRIS1Elements.Corneal_Graft_Procedure)
       && checkEyeElementsInRange(visit,m,IRIS1Elements.Systemic_Sympathetic_Alpha_1a_Antagonist_Medication___Eye,IRIS1Elements.Indication_For_Surgery__Eye)
       )
    ||
       (
           isDiagnosedWithBeforeOrEqual(visit,m,IRIS1Elements.Procedures_Complicating_Surgery_Date,patientHistory,IRIS1Elements.Corneal_Graft_Procedure)
       && checkEyeElementsInRange(visit,m,IRIS1Elements.Surgery___Eye,IRIS1Elements.Indication_For_Surgery__Eye)
       )
    )
  }

  /*------------------------------------------------------------------------------
   Patients with a best corrected visual acuity of 20/40 or better within 90 days of surgery
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistory:Broadcast[List[CassandraRow]],Correct_VA_Values: Array[String]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
         wasCorrectedVisualAcuityValueGreaterXDays(visit, m ,IRIS1Elements.Best_Corrected_Left_Eye_Va_Value,IRIS1Elements.Corneal_Graft_Procedure,90,Correct_VA_Values,patientHistory)
      || wasCorrectedVisualAcuityValueGreaterXDays(visit, m ,IRIS1Elements.Best_Corrected_Right_Eye_Va_Value,IRIS1Elements.Corneal_Graft_Procedure,90,Correct_VA_Values,patientHistory)
    )

  }
}
