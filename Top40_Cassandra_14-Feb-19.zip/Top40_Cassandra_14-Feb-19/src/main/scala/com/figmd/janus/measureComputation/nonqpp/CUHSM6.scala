package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CUHSM6
* Measure Title               :- Adherence to Mood Stabilizers for Individuals with Bipolar I Disorder
* Measure Description         :- Percentage of individuals at least 18 years of age as of the beginning of the measurement
                                 period with bipolar I disorder who had at least two prescription drug claims for mood stabilizer
                                 medications and had a Proportion of Days Covered (PDC) of at least 0.8 for mood stabilizer
                                 medications during the measurement period (12 consecutive months).
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- Aanchal.Rai
* Initial GIT Version/Tag(CRA):- 1.8
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object CUHSM6 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "CUHSM6"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      CUHSM6Elements.Mood_Stabilizers,
      CUHSM6Elements.Mood_Stabilizers_Meds,
      CUHSM6Elements.Pdc_For_Mood_Stabilizers_Grp
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
IPP - Individuals at least 18 years of age as of the beginning of the measurement period with bipolar I disorder and at
      least two prescription drug claims for mood stabilizer medications during the measurement period (12 consecutive months).
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patienthistoryRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val encounterCountList: List[(String, Int)] = countElement(patienthistoryRdd, m,
      CUHSM6Elements.Mood_Stabilizers,
      CUHSM6Elements.Mood_Stabilizers_Meds
   )

    initialRDD.filter(visit =>
    isPatientAdult(visit,m)
      &&
      wasDiagnosedInHistory(visit,m,CUHSM6Elements.Bipolar_Disorder_I_Grp,patientHistoryBroadcastList)
      &&
      isVisitTypeIn(visit,m
        ,CUHSM6Elements.Emergency_Department_Visit
        ,CUHSM6Elements.Acute_Inpatient_Setting
        ,CUHSM6Elements.Non_Acute_Inpatient_Setting_Grp
        ,CUHSM6Elements.Service_In_Non_Acute_Inpatient_Setting_Grp
        ,CUHSM6Elements.Service_In_Outpatient_Setting
        ,CUHSM6Elements.Ed_Setting
      )
      &&
      getEncounterCountFromHistory(visit, m, 2, true, encounterCountList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//Numerator - Individuals with bipolar I disorder who had at least two prescription drug claims for mood stabilizer
              medications and have a PDC of at least 0.8 for mood stabilizer medications.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
     isAssessmentPerformedWithResultValueDuringEncounter(visit,m,CUHSM6Elements.Proportion_Of_Days_Covered_For_Mood_Stabilizers_Grp,0.8,CompareOperator.GREATER_EQUAL)
      ||
      isAssessmentPerformed(visit,m,CUHSM6Elements.Pdc_For_Mood_Stabilizers_Grp,patientHistoryBroadcastList)

    )
  }

}
