package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, MeasureProperty, QPP442Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Qpp442
* Measure Title               :- Persistence of Beta-Blocker Treatment After a Heart Attack
* Measure Description         :- The percentage of patients 18 years of age and older during the measurement year who were hospitalized
                                  and discharged from July 1 of the year prior to the measurement year to June 30 of the measurement year
                                  with a diagnosis of acute myocardial infarction (AMI) and who were prescribed persistent beta-blocker
                                  treatment for six months after discharge.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- VRUSHALI.GHOLAP
* Initial GIT Version/Tag(CRA):-
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/
//Pending with Gap logic for cummulative days
object QPP442 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP442"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,QPP442Elements.Discharge_For_Ami
      ,QPP442Elements.Discharge
      ,QPP442Elements.Acute_Myocardial_Infarction__Ami_
      ,QPP442Elements.Chronic_Respiratory_Conditions_Fumes_Vapors
      ,QPP442Elements.Copd
      ,QPP442Elements.Asthma_Diagnosis_Grouping
      ,QPP442Elements.Obstructive_Chronic_Bronchitis
      ,QPP442Elements.Sinus_Bradycardia
      ,QPP442Elements.Hypotension
      ,QPP442Elements.Heart_Block
      ,QPP442Elements.Obstructive_Chronic_Bronchitis
      ,QPP442Elements.Medication_Dispensing_Event
      ,QPP442Elements.Patient_Transfer_Non_Acute_Care
      ,QPP442Elements.Patient_Transfer_Non_Acute_Care
      ,QPP442Elements.Allergy_To_Beta_Blocker_Therapy
      ,QPP442Elements.Hospice_Services
      ,QPP442Elements.Allergy_To_Beta_Blocker_Snomed
      ,QPP442Elements.Hospice_Services_Snomedct
      ,QPP442Elements.Hospice_Care
      ,QPP442Elements.Beta_Blocker_Therapy_Date
      ,QPP442Elements.Beta_Blocker_Therapy_Stop_Date
      ,QPP442Elements.Beta_Blocker_Therapy
      ,QPP442Elements.Beta_Blocker_Treatment
      ,QPP442Elements.Beta_Blocker_Treatment_Not_Met
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Get exclusion
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      //Get intermediate RDD for Met
      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      //getCummulativeList
      val medicationList : List[(String,String)] = List((QPP442Elements.Beta_Blocker_Therapy_Date,QPP442Elements.Beta_Blocker_Therapy_Stop_Date))
      val cummulativeList = cumulative(patientHistoryRDD,MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate),medicationList,"before",CalenderUnit.MONTH,6,"during")
      //need define time for medication
      val cummulativeBroadcastList /*:Broadcast[List[(String,String)]]*/  = sparkSession.sparkContext.broadcast(cummulativeList)

      //get Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]],cummulativeBroadcastList)
      metRDD.cache()

      //get exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //get Met
      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

/*-----------------------------------------------------------------------------------------------------------------------
Patients 18 years of age and older as of December 31 of the measurement year who were hospitalized and discharged from July 1 of
the year prior to the measurement year to June 30 of the measurement year with diagnosis of AMI.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
        isPatientAdult(visit,m)
      &&(
         isAssessmentPerformed(visit,m,QPP442Elements.Discharge_For_Ami,patientHistoryBroadcastList)
          || (   wasEncounterPerformedAfterStartWithInXMonths(visit,m,QPP442Elements.Discharge,6,patientHistoryBroadcastList)
              && wasEncounterPerformedBeforeStartInXMonths(visit,m,QPP442Elements.Discharge,6,patientHistoryBroadcastList)
              && wasEncounterPerformedAfterDiagnosis(visit,m,QPP442Elements.Discharge,patientHistoryBroadcastList,QPP442Elements.Acute_Myocardial_Infarction__Ami_)
           )
        )
      && wasDiagnosisBeforeStartInXMonths(visit,m,QPP442Elements.Acute_Myocardial_Infarction__Ami_,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
      && wasDiagnosisStartsAfterStartOfWithinXPeriod(visit,m,QPP442Elements.Acute_Myocardial_Infarction__Ami_,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
      && isVisitTypeIn(visit,m
          ,QPP442Elements.Home_Healthcare_Services
          ,QPP442Elements.Care_Services_In_Long_Term_Residential_Facility
          ,QPP442Elements.Nursing_Facility_Visit
          ,QPP442Elements.Initial_Nursing_Facility
          ,QPP442Elements.Office_Visit)
    )
  }

/*-----------------------------------------------------------------------------------------------------------------------
Table PBH-D: Medications to Identify Exclusions (History of Asthma)
Description Bronchodilator combinations: Budesonide-formoterol,Fluticasone-vilanterol,Fluticasone-salmeterol,Mometasone-formoterol
Inhaled corticosteroids: Beclomethasone,Budesonide,Ciclesonide,Flunisolide,Fluticasone,Fluticasone CFC free,Mometasone
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
         wasDiagnosedInHistory(visit,m,QPP442Elements.Chronic_Respiratory_Conditions_Fumes_Vapors,patientHistoryBroadcastList)
      || wasDiagnosedInHistory(visit,m,QPP442Elements.Copd,patientHistoryBroadcastList)
      || wasDiagnosedInHistory(visit,m,QPP442Elements.Asthma_Diagnosis_Grouping,patientHistoryBroadcastList)
      || wasDiagnosedInHistory(visit,m,QPP442Elements.Obstructive_Chronic_Bronchitis,patientHistoryBroadcastList)
      || wasDiagnosedInHistory(visit,m,QPP442Elements.Sinus_Bradycardia,patientHistoryBroadcastList)
      || wasDiagnosedInHistory(visit,m,QPP442Elements.Hypotension,patientHistoryBroadcastList)
      || wasDiagnosedInHistory(visit,m,QPP442Elements.Heart_Block,patientHistoryBroadcastList)
      || wasMedicationDispensedBeforeEnd(visit,m,QPP442Elements.Obstructive_Chronic_Bronchitis,patientHistoryBroadcastList)

      || isAssessmentPerformed(visit,m,QPP442Elements.Medication_Dispensing_Event,patientHistoryBroadcastList)
      || isTransferTo(visit,m,QPP442Elements.Patient_Transfer_Non_Acute_Care,patientHistoryBroadcastList)
      || isAssessmentPerformed(visit,m,QPP442Elements.Patient_Transfer_Non_Acute_Care,patientHistoryBroadcastList)
      || isAssessmentPerformed(visit,m,QPP442Elements.Allergy_To_Beta_Blocker_Therapy,patientHistoryBroadcastList)
      || isAssessmentPerformed(visit,m,QPP442Elements.Hospice_Services,patientHistoryBroadcastList)

      || wasMedicationAllergyBeforeEnd(visit,m,QPP442Elements.Allergy_To_Beta_Blocker_Snomed,patientHistoryBroadcastList)
      || wasInterventionPerformedInHistory(visit,m,QPP442Elements.Hospice_Services_Snomedct,patientHistoryBroadcastList)
      || wasInterventionPerformedInHistory(visit,m,QPP442Elements.Hospice_Care,patientHistoryBroadcastList)

    )
  }

/*-----------------------------------------------------------------------------------------------------------------------
Patients who had at least 135 days of treatment with beta-blockers post-discharge during the 180-day measurement interval.
NUMERATOR NOTE: Performance for the measure is based on at least 135 days of beta-blocker treatment during the 180-day
measurement interval post discharge for AMI. This allows gaps in medication treatment of up to a total of 45 days
during the 180-day measurement interval.
Assess for active prescriptions and include days supply that fall within the 180-day measurement interval.
For patients who were on beta-blockers prior to admission and those who were dispensed an ambulatory prescription during their inpatient stay,
factor those prescriptions into adherence rates if the actual treatment days fall within the 180-day measurement interval.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],cummulativeBroadcastList : Broadcast[List[(String,String,Double)]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateForMet.filter(visit =>
      (
        isAssessmentPerformed(visit,m,QPP442Elements.Beta_Blocker_Treatment,patientHistoryBroadcastList)
        ||
          (  ( wasMedicationOrderedOrActiveAfterDischargeInPeriod(visit,m,Seq(QPP442Elements.Beta_Blocker_Therapy),CalenderUnit.DAY,180,patientHistoryBroadcastList,QPP442Elements.Discharge_For_Ami)
            || wasMedicationOrderedOrActiveAfterDischargeInPeriod(visit,m,Seq(QPP442Elements.Beta_Blocker_Therapy),CalenderUnit.DAY,180,patientHistoryBroadcastList,QPP442Elements.Discharge)
            )
            && getCommulativeResult(visit,m,QPP442Elements.Beta_Blocker_Therapy,135,CalenderUnit.DAY,cummulativeBroadcastList)
            )
      )
      && !isAssessmentPerformed(visit,m,QPP442Elements.Beta_Blocker_Treatment_Not_Met,patientHistoryBroadcastList)
    )
  }


}