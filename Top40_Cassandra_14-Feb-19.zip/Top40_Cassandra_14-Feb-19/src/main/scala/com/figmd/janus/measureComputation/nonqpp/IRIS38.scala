package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{IRIS38Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS38
* Measure Title               :- Endothelial Keratoplasty – Dislocation Requiring Surgical Intervention
* Measure Description         :- Percentage of endothelial keratoplasty patients with a rebubbling or revision or repair procedure within 90 days after surgery
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Lower Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS38 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS38"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
          ,IRIS38Elements.Exclusions_Corneal_Graft
          ,IRIS38Elements.Exclusions_Corneal_Graft_Eye
          ,IRIS38Elements.Surgical_Intervention_For_Corneal_Graft
          ,IRIS38Elements.Surgical_Intervention_For_Corneal_Graft_Eye
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients aged 18 years or older who underwent an endothelial keratoplasty surgery
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
            isPatientAdult(visit,m)
        &&  isProcedurePerformedDuringEncounter(visit,m,IRIS38Elements.Corneal_Graft_Procedure)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Adherent leukoma
Pupillary membranes
Adhesions and disruptions of iris and ciliary body
Anterior synechiae (iris)
Goniosynechiae
Iridodialysis
Posterior synechiae (iris)
Recession of chamber angle
Pupillary abnormalities
Other disorders of iris and ciliary body
Anterior chamber IOL
Aphakia
Dislocation of lens
Hypotony of eye
Open wound of eyeball
Prior glaucoma filtering surgery
Prior pars plana vitrectomy
Prior penetrating keratoplasty
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
          isAssessmentPerformed(visit,m,IRIS38Elements.Exclusions_Corneal_Graft,patientHistoryBroadcastList)
      &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,true,IRIS38Elements.Corneal_Graft_Procedure___Eye,patientHistoryBroadcastList,Seq(IRIS38Elements.Exclusions_Corneal_Graft_Eye))
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with a surgical intervention within 90 days of endothelial keratoplasty surgery.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
            wasProcedurePerformedAfterProcedureWithInXDays(visit,m,IRIS38Elements.Surgical_Intervention_For_Corneal_Graft,IRIS38Elements.Corneal_Graft_Procedure,90,patientHistoryBroadcastList)
        &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS38Elements.Corneal_Graft_Procedure___Eye,patientHistoryBroadcastList,Seq(IRIS38Elements.Surgical_Intervention_For_Corneal_Graft_Eye))
    )
  }

}