package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CompareOperator, ECQM131V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.ecqm.Ecqm144V7_2.{MEASURE_NAME, checkEmptyIPPRDD}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 131v7
* Measure Title              :- Diabetes: Eye Exam
* Measure Description        :- Percentage of patients 18-75 years of age with diabetes who had a retinal or dilated eye exam by an eye care professional during the measurement period or a negative retinal exam (no evidence of retinopathy) in the 12 months prior to the measurement period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/
object Ecqm131V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm131V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      ECQM131V7Elements.Diabetes,
      ECQM131V7Elements.Discharged_To_Home_For_Hospice_Care,
      ECQM131V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
      ECQM131V7Elements.Hospice_Care_Ambulatory,
      ECQM131V7Elements.Retinal_Or_Dilated_Eye_Exam,
      ECQM131V7Elements.Negative_Finding
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }

  //Patients 18-75 years of age with diabetes with a visit during the measurement period
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      wasDiagnosisInHistory(visit, m, ECQM131V7Elements.Diabetes, patientHistoryList)
        &&
        isAgeBetween(visit, m, 18, CompareOperator.GREATER_EQUAL, 75, CompareOperator.LESS, "m.quarterStartDate")
        &&
        isVisitTypeIn(visit, m,
          ECQM131V7Elements.Office_Visit,
          ECQM131V7Elements.Home_Healthcare_Services,
          ECQM131V7Elements.Annual_Wellness_Visit,
          ECQM131V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
          ECQM131V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
          ECQM131V7Elements.Ophthalmological_Services)
    )
  }

  // Exclude patients whose hospice care overlaps the measurement period

  //  overlaps condition includes during measurement period condition.
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      isEncounterPerformedWithDischargeStatus(visit, m, ECQM131V7Elements.Encounter_Inpatient, ECQM131V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        ||
        isEncounterPerformedWithDischargeStatus(visit, m, ECQM131V7Elements.Encounter_Inpatient, ECQM131V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        ||
        /*wasInterventionOrdered(visit, m,patientHistoryList,ECQM131V7Elements.Hospice_Care_Ambulatory)
        ||*/
        isInterventionPerformedOverlapsMeasurementPeriod(visit, m, patientHistoryList, ECQM131V7Elements.Hospice_Care_Ambulatory)

    )
  }

  // Patients with an eye screening for diabetic retinal disease. This includes diabetics who had one of the following:
  //A retinal or dilated eye exam by an eye care professional in the measurement period or a negative retinal exam (no evidence of retinopathy) by an eye care professional in the year prior to the measurement period
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      isPhysicalExamPerformed(visit, m, ECQM131V7Elements.Retinal_Or_Dilated_Eye_Exam, patientHistoryList)
        || wasPhysicalExamPerformedXPeriodForRetinalDilatedExamWithResult(visit, m, ECQM131V7Elements.Retinal_Or_Dilated_Eye_Exam, ECQM131V7Elements.Negative_Finding, 12, CompareOperator.LESS, CompareOperator.GREATER, patientHistoryList)
    )

  }

}
