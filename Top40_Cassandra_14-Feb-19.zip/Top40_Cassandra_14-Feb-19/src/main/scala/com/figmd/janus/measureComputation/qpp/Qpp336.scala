
package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP336Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 336
* Measure Title              :- Maternity Care: Post-Partum Follow-Up and Care Coordination.
* Measure Description        :- Percentage of patients, regardless of age, who gave birth during a 12-month period who were
                                seen for post-partum care within 8 weeks of giving birth who received a breast feeding evaluation
                                and education, post-partum depression screening, post-partum glucose screening for gestational diabetes patients, and family and contraceptive planning.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp336 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp336"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP336Elements.Post_Partum_Care_Visit).collect.toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
       // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  All patients, regardless of age, who gave birth during a 12-month period seen for post-partum care visit before or
  at 8 weeks of giving birth, during measurement period.
  ----------------------------------------------------------------------------------------------------------------------------*/

  // Filter IPP
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
           isProcedurePerformed(visit, m, QPP336Elements.Delivery, patientHistoryBroadcastList)
        && wasEncounterPerformedAfterProcedureWithInXWeeks(visit, m, QPP336Elements.Delivery, QPP336Elements.Post_Partum_Care_Visit, 8, patientHistoryBroadcastList)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Patients receiving the following at a post-partum visit:
  • Breast feeding evaluation and education, including patient-reported breast feeding
  • Post-partum depression screening
  • Post-partum glucose screening for gestational diabetes patients and
  • Family and contraceptive planning
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
   (  (    isDiagnosedOnEncounter(visit, m, QPP336Elements.Gestational_Diabetes)
        && isLaboratoryTestOrderDuringEncounter(visit, m, QPP336Elements.Post_Partum_Glucose_Screening_For_Gestational_Diabetes_Patients)
        && (   isAssessmentPerformedOnEncounter(visit, m, QPP336Elements.Edinburghpostnatal_Depression_Scale)
            || isCareGoalDuringEncounter(visit, m, QPP336Elements.Maternal_Post_Partum_Depression_Care)
            || isInterventionPerformedDuringEncounter(visit, m, QPP336Elements.Maternal_Post_Partum_Depression_Screening)
            || isAssessmentPerformedOnEncounter(visit, m, QPP336Elements.Depression_Assessment)
            || isAssessmentPerformedOnEncounter(visit, m, QPP336Elements.Postpartum_Depression_Procedure_Regime)
            || isAssessmentPerformedOnEncounter(visit, m, QPP336Elements.Phq_9_Tool)
            || isAssessmentPerformedOnEncounter(visit, m, QPP336Elements.Phq_2)
            || isAssessmentPerformedOnEncounter(visit, m, QPP336Elements.Bdi_Tool)
          )
        && (  isAssessmentPerformedOnEncounter(visit, m, QPP336Elements.Family_Planning_Counseling)
            || isCareGoalDuringEncounter(visit, m, QPP336Elements.Family_And_Contraceptive_Planning)
           )
        && isCareGoalDuringEncounter(visit, m, QPP336Elements.Breast_Feeding_Evaluation_And_Education)
      )
    ||  isAssessmentPerformedOnEncounter(visit, m, QPP336Elements.Post_Partum_Screenings_Evaluations_And_Education_Performed)
   )
    && ! isCareGoalDuringEncounter(visit, m, QPP336Elements.Postpar_Scree_Not_Met)
  )
 }
}
