package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, ECQM157V7Elements, MeasureProperty}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 157v7
* Measure Title              :- Oncology: Medical and Radiation - Pain Intensity Quantified
* Measure Description        :- Percentage of patient visits, regardless of patient age, with a diagnosis of cancer currently receiving chemotherapy or radiation therapy in which pain intensity is quantified
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- 1
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm157V7_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm157V7_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      ECQM157V7Elements.Cancer,
      ECQM157V7Elements.Chemotherapy_Administration)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD)
      metRDD.cache()

      // Filter Exceptions
      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : All patient visits, regardless of patient age, with a diagnosis of cancer currently receiving chemotherapy or radiation therapy
----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isVisitTypeIn(visit, m, ECQM157V7Elements.Office_Visit)
        && wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM157V7Elements.Cancer, patientHistoryBroadcastList)
        && wasProcedurePerformedBeforeEncounterInXPeriod(visit, m, ECQM157V7Elements.Chemotherapy_Administration, CalenderUnit.DAY, 30, patientHistoryBroadcastList)
        && wasProcedureStartsAfterEndOfEncounter(visit, m, AdminElements.Encounter_Date, ECQM157V7Elements.Chemotherapy_Administration, 30, patientHistoryBroadcastList)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Patient visits in which pain intensity is quantified
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      isAssessmentPerformedDuringEncounter(visit, m, ECQM157V7Elements.Standardized_Pain_Assessment_Tool)
    )
  }
}

