package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, PP5Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PP5
* Measure Title               :- Bipolar disorder: the percentage of patients diagnosed and treated for bipolar disorder who are monitored for change in their symptom complex within 12 weeks
*                                of initiating treatment; AND if there is no change or deterioration in symptoms, a revised care plan is documented
  *                              following the 12 week monitoring phase
* Measure Description         :- This measure is used to assess the percentage of patients aged 10 years and older diagnosed and treated for bipolar disorder who are monitored for change
*                                in their symptom complex within 12 weeks of initiating treatment AND who are provided with a documented revised care plan after the 12-week monitoring phase,
*                                if there is no change or deterioration in their symptoms.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KIRTI RAUT
* Initial GIT Version/Tag(CRA):-Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :-Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object PP5 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "PP5"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      PP5Elements.Bipolar_Disorder,
      PP5Elements.Treatment_Of_Bipolar,
      PP5Elements.Bipolar_Disorder_New_Episode_Grp,
      PP5Elements.Screening_Assessment_Tool_For_Bipolar_Disorder_Grp,
      PP5Elements.Antipsychotic_Medications,
      PP5Elements.Mood_Stabilizers,
      PP5Elements.Bipolar_Disorder_Documented,
      PP5Elements.Assessment_Of_Symptom_Complex_Using_A_Tool_Or_Monitoring_Form,
      PP5Elements.Assessment_Of_Symptom_Complex_Using_3_Symptoms,
      PP5Elements.Improvement_In_Symptoms_Bd,
      PP5Elements.No_Change_In_Symptoms_Bd,
      PP5Elements.Deterioration_In_Symptoms_Bd,
      PP5Elements.Optimization_Of_Medication_Doses_Grp,
      PP5Elements.Addition_Of_First_Line_Medication_Grp,
      PP5Elements.Addition_Of_Alternate_Medication_Grp,
      PP5Elements.Combination_Of_Psychotherapy_And_Pharmacotherapy_Grp,
      PP5Elements.Bh_Electroconvulsive_Therapy

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val leastPatientHistoryList=leastRecentPatientList(initialRDD,PP5Elements.Bipolar_Disorder,PP5Elements.Treatment_Of_Bipolar)
    val leastRecentPatientHistoryBroadcastList:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastPatientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList,leastRecentPatientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList,leastRecentPatientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      leastRecentPatientHistoryBroadcastList.destroy()

    }
  }


  /*-----------------------------------------------------------------------------------------------------------------------
   	Patients aged 10 years and older diagnosed and treated for bipolar disorder.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],leastRecentPatientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)




    initialRDD.filter(visit =>
      isAgeAbove(visit,m,true,10)
        && isVisitTypeIn(visit, m,
        PP5Elements.Office_Visit,
        PP5Elements.Outpatient_Consultation,
        PP5Elements.Face_To_Face_Interaction,
        PP5Elements.Home_Healthcare_Services,
        PP5Elements.Psych_Visit_Grpg,
        PP5Elements.Preventive_Initial_Office_Visit_Grp,
        PP5Elements.Preventive_Care_Services_Established_Office_Visit_Grp
      )
        &&
        (
          wasFirstDiagnosed(visit,m,PP5Elements.Bipolar_Disorder,leastRecentPatientHistoryBroadcastList)
            || wasDiagnosisInHistory(visit,m,PP5Elements.Bipolar_Disorder_New_Episode_Grp,patientHistoryBroadcastList)
          )
        &&
        (
          isDiagnosisOverlapsEncounter(visit,m,patientHistoryBroadcastList,PP5Elements.Bipolar_Disorder_Documented,PP5Elements.Bipolar_Disorder_Impression_Documented_Grp)
            || isAssessmentPerformedBeforeOrEqual(visit,m,PP5Elements.Screening_Assessment_Tool_For_Bipolar_Disorder_Grp,patientHistoryBroadcastList)
          )
        &&

          isMedicationOrdered(visit,m,patientHistoryBroadcastList,PP5Elements.Antipsychotic_Medications,PP5Elements.Mood_Stabilizers)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
   	Patients who were assessed for change in their symptom complex, using a validated tool or a monitoring form, within 12 weeks of initiating treatment for bipolar disorder.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],leastRecentPatientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
                              (wasAssessmentPerformedEndsAfterStartOfWithinXPeriod(visit,m,PP5Elements.Assessment_Of_Symptom_Complex_Using_A_Tool_Or_Monitoring_Form,CalenderUnit.WEEK,12,PP5Elements.Treatment_Of_Bipolar,leastRecentPatientHistoryBroadcastList)
                           ||  wasAssessmentPerformedEndsAfterStartOfWithinXPeriod(visit,m,PP5Elements.Assessment_Of_Symptom_Complex_Using_3_Symptoms,CalenderUnit.WEEK,12,PP5Elements.Treatment_Of_Bipolar,leastRecentPatientHistoryBroadcastList)
                                )
      &&
                                (
                                (
                                    wasAssessmentPerformedWithResultAfterIntervetionWithInXWeek(visit,m,PP5Elements.Assessment_Of_Symptom_Complex_Using_A_Tool_Or_Monitoring_Form,PP5Elements.Improvement_In_Symptoms_Bd,PP5Elements.Treatment_Of_Bipolar,12,CalenderUnit.WEEK,leastRecentPatientHistoryBroadcastList)
                                  || wasAssessmentPerformedWithResultAfterIntervetionWithInXWeek(visit,m,PP5Elements.Assessment_Of_Symptom_Complex_Using_3_Symptoms,PP5Elements.Improvement_In_Symptoms_Bd,PP5Elements.Treatment_Of_Bipolar,12,CalenderUnit.WEEK,leastRecentPatientHistoryBroadcastList)
                                )
                                ||
                                  (
                                     (
                                            wasAssessmentPerformedWithResultAfterIntervetionWithInXWeek(visit,m,PP5Elements.Assessment_Of_Symptom_Complex_Using_A_Tool_Or_Monitoring_Form,PP5Elements.No_Change_In_Symptoms_Bd,PP5Elements.Treatment_Of_Bipolar,12,CalenderUnit.WEEK,leastRecentPatientHistoryBroadcastList)
                                         || wasAssessmentPerformedWithResultAfterIntervetionWithInXWeek(visit,m,PP5Elements.Assessment_Of_Symptom_Complex_Using_A_Tool_Or_Monitoring_Form,PP5Elements.Deterioration_In_Symptoms_Bd,PP5Elements.Treatment_Of_Bipolar,12,CalenderUnit.WEEK,leastRecentPatientHistoryBroadcastList)
                                         || wasAssessmentPerformedWithResultAfterIntervetionWithInXWeek(visit,m,PP5Elements.Assessment_Of_Symptom_Complex_Using_3_Symptoms,PP5Elements.No_Change_In_Symptoms_Bd,PP5Elements.Treatment_Of_Bipolar,12,CalenderUnit.WEEK,leastRecentPatientHistoryBroadcastList)
                                         || wasAssessmentPerformedWithResultAfterIntervetionWithInXWeek(visit,m,PP5Elements.Assessment_Of_Symptom_Complex_Using_3_Symptoms,PP5Elements.Deterioration_In_Symptoms_Bd,PP5Elements.Treatment_Of_Bipolar,12,CalenderUnit.WEEK,leastRecentPatientHistoryBroadcastList)
                                     )
                                    &&
                                      (
                                        wasCareGoalInXPeriod(visit, m,CalenderUnit.WEEK, 12,PP5Elements.Treatment_Of_Bipolar, patientHistoryBroadcastList,leastRecentPatientHistoryBroadcastList,
                                          PP5Elements.Optimization_Of_Medication_Doses_Grp,
                                          PP5Elements.Addition_Of_First_Line_Medication_Grp,
                                          PP5Elements.Addition_Of_Alternate_Medication_Grp,
                                          PP5Elements.Combination_Of_Psychotherapy_And_Pharmacotherapy_Grp,
                                          PP5Elements.Bh_Electroconvulsive_Therapy)
                                      )
                                    )
                               )
    )
  }


}
