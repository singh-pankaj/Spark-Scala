package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.ecqm.Ecqm144V7_2.{MEASURE_NAME, checkEmptyIPPRDD}
import com.figmd.janus.measureComputation.master.{ECQM138V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS138v7
* Measure Title              :- Preventive Care and Screening: Tobacco Use: Screening and Cessation Intervention
* Measure Description        :- "Percentage of patients aged 18 years and older who were screened for tobacco use one or more times within 24 months
                                 AND who received tobacco cessation intervention if identified as a tobacco user
                                Three rates are reported:
                                a. Percentage of patients aged 18 years and older who were screened for tobacco use one or more times within 24 months
                                b. Percentage of patients aged 18 years and older who were screened for tobacco use and identified as a tobacco user who received tobacco cessation intervention
                                c. Percentage of patients aged 18 years and older who were screened for tobacco use one or more times within 24 months AND who received tobacco cessation intervention if identified as a tobacco user"
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 3
* Measure Stratum No.        :- 3
* Measure Stratification     :- 3
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm138V7_3 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Ecqm138v7_3"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    //Backtracking List
    val patientHistoryListRdd = getPatientHistory(sparkSession, initialRDD,
      ECQM138V7Elements.Health___Behavioral_Assessment___Individual,
      ECQM138V7Elements.Health_And_Behavioral_Assessment___Initial,
      ECQM138V7Elements.Health_And_Behavioral_Assessment__Reassessment,
      ECQM138V7Elements.Home_Healthcare_Services,
      ECQM138V7Elements.Occupational_Therapy_Evaluation,
      ECQM138V7Elements.Office_Visit,
      ECQM138V7Elements.Ophthalmological_Services,
      ECQM138V7Elements.Psych_Visit___Diagnostic_Evaluation,
      ECQM138V7Elements.Psych_Visit___Psychotherapy,
      ECQM138V7Elements.Psychoanalysis,
      ECQM138V7Elements.Speech_And_Hearing_Evaluation,
      ECQM138V7Elements.Annual_Wellness_Visit,
      ECQM138V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
      ECQM138V7Elements.Preventive_Care_Services___Group_Counseling,
      ECQM138V7Elements.Preventive_Care_Services___Other,
      ECQM138V7Elements.Preventive_Care_Services_Individual_Counseling,
      ECQM138V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
      ECQM138V7Elements.Tobacco_Use_Screening,
      ECQM138V7Elements.Tobacco_User,
      ECQM138V7Elements.Medical_Reason,
      ECQM138V7Elements.Tobacco_Use_Cessation_Counseling,
      ECQM138V7Elements.Tobacco_Use_Cessation_Pharmacotherapy,
      ECQM138V7Elements.Limited_Life_Expectancy)
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryListRdd.collect.toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList, patientHistoryListRdd)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //Mostrecent Patient History List
      val patientHistoryMostRecentList: Broadcast[List[CassandraRow]] =
        sparkSession.sparkContext
          .broadcast(mostRecentPatientList(patientHistoryListRdd, ECQM138V7Elements.Tobacco_Use_Screening))


      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryMostRecentList, patientHistoryList)
      metRDD.cache()

      // Filter Intermediate
      val intermediateException = getSubtractRDD(ippRDD, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateException, patientHistoryMostRecentList, patientHistoryList: Broadcast[List[CassandraRow]])
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryMostRecentList.destroy()
      patientHistoryList.destroy()
    }
  }


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], patientHistoryListRdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val countElementList2: List[(String, Int)] = countElement(patientHistoryListRdd, m,
      ECQM138V7Elements.Health___Behavioral_Assessment___Individual,
      ECQM138V7Elements.Health_And_Behavioral_Assessment___Initial,
      ECQM138V7Elements.Health_And_Behavioral_Assessment__Reassessment,
      ECQM138V7Elements.Home_Healthcare_Services,
      ECQM138V7Elements.Occupational_Therapy_Evaluation,
      ECQM138V7Elements.Office_Visit,
      ECQM138V7Elements.Ophthalmological_Services,
      ECQM138V7Elements.Psych_Visit___Diagnostic_Evaluation,
      ECQM138V7Elements.Psych_Visit___Psychotherapy,
      ECQM138V7Elements.Psychoanalysis,
      ECQM138V7Elements.Speech_And_Hearing_Evaluation)

    val countElementList1: List[(String, Int)] = countElement(patientHistoryListRdd, m,
      ECQM138V7Elements.Annual_Wellness_Visit,
      ECQM138V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
      ECQM138V7Elements.Preventive_Care_Services___Group_Counseling,
      ECQM138V7Elements.Preventive_Care_Services___Other,
      ECQM138V7Elements.Preventive_Care_Services_Individual_Counseling,
      ECQM138V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && (
        getEncounterCountFromHistory(visit, m, 2, true, countElementList2)
          || getEncounterCountFromHistory(visit, m, 1, true, countElementList1)
        ))
  }

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryMostRecentList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      wasPatientTobaccoNonUserWithin24Months(visit, m, ECQM138V7Elements.Tobacco_Use_Screening, ECQM138V7Elements.Tobacco_Non_User, 24, patientHistoryMostRecentList, patientHistoryList)
        ||
        (tobaccoCessationInterventionDoneAfterTobaccoScreeningUser(visit, m, ECQM138V7Elements.Tobacco_Use_Cessation_Counseling_Date, ECQM138V7Elements.Tobacco_Use_Screening, ECQM138V7Elements.Tobacco_User, 24, patientHistoryMostRecentList, patientHistoryList)
          && TobaccoCessationInterventionDoneBeforeEndDate(visit, m, ECQM138V7Elements.Tobacco_Use_Cessation_Counseling, patientHistoryList))
        || (tobaccoCessationInterventionDoneAfterTobaccoScreeningUser(visit, m, ECQM138V7Elements.Tobacco_Use_Cessation_Pharmacotherapy_Date, ECQM138V7Elements.Tobacco_Use_Screening, ECQM138V7Elements.Tobacco_User, 24, patientHistoryMostRecentList, patientHistoryList)
        && TobaccoCessationInterventionDoneBeforeEndDate(visit, m, ECQM138V7Elements.Tobacco_Use_Cessation_Pharmacotherapy, patientHistoryList))
    )
  }

  def getExceptionRDD(intermediateRdd: RDD[CassandraRow], patientHistoryMostRecentList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateRdd.filter(visit =>
      wasDiagnosedInHistory(visit, m, ECQM138V7Elements.Limited_Life_Expectancy, patientHistoryList)
        || wasCounselingNotPerformedAfterTobaccoScreeningUser(visit, m, ECQM138V7Elements.Medical_Reason_Date, ECQM138V7Elements.Tobacco_Use_Screening, ECQM138V7Elements.Tobacco_User, 24, patientHistoryMostRecentList, patientHistoryList)
        || wasMedicationNotOrderedAfterTobaccoScreeningUser(visit, m, ECQM138V7Elements.Medical_Reason_Date, ECQM138V7Elements.Tobacco_Use_Screening, ECQM138V7Elements.Tobacco_User, 24, patientHistoryMostRecentList, patientHistoryList)
    )
  }


}


