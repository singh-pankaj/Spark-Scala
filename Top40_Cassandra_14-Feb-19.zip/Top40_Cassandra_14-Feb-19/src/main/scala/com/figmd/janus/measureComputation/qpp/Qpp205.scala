package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP205Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.qpp.Qpp205.isAssessmentPerformed

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 205
* Measure Title              :- HIV/AIDS: Sexually Transmitted Disease Screening for Chlamydia, Gonorrhea, and Syphilis
* Measure Description        :- Percentage of patients aged 13 years and older with a diagnosis of HIV/AIDS for whom chlamydia, gonorrhea, and syphilis screenings were performed at least once since the diagnosis of HIV infection
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp205 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp205"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP


    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP205Elements.Hiv,
      QPP205Elements.Hospice_Services,
      QPP205Elements.Hospice_Services_Snomedct,
      QPP205Elements.Hospice_Care,
      QPP205Elements.Chlamydia_Gonorrhea_And_Syphilis_Screening,
      QPP205Elements.Chlamydia_Screening,
      QPP205Elements.Gonorrhea_Screening_Grp,
      QPP205Elements.Syphilis_Screening_Grp,
      QPP205Elements.Screening_For_Venereal_Disease_Grp,
      QPP205Elements.Screening_Reason_Not_Specified_Grp,
      QPP205Elements.Patient_Refusal,
      QPP205Elements.Screening_Patient_Reason_Grp
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      //    metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()
      //

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /* Patients aged 13 and older with a diagnosis of HIV/AIDS who had at least two medical visits during the measurement year, with at least 90 days between each visit "*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 13)
        && isDiagnosedOnEncounter(visit, m, QPP205Elements.Hiv)
        &&
        isVisitTypeIn(visit, m,
          QPP205Elements.Office_Visit,
          QPP205Elements.Initial_Preventive_Physical_Examination_Grp,
          QPP205Elements.Hospice_Services,
          QPP205Elements.Hospice_Services_Snomedct,
          QPP205Elements.Hospice_Care,
          QPP205Elements.Chlamydia_Gonorrhea_And_Syphilis_Screening,
          QPP205Elements.Chlamydia_Screening,
          QPP205Elements.Gonorrhea_Screening_Grp,
          QPP205Elements.Syphilis_Screening_Grp,
          QPP205Elements.Screening_For_Venereal_Disease_Grp,
          QPP205Elements.Screening_Reason_Not_Specified_Grp,
          QPP205Elements.Patient_Refusal,
          QPP205Elements.Screening_Patient_Reason_Grp
        )
    )
  }


  // Denominator Exclusion criteria
  /* Patients who use hospice services any time during the measurement period */

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isProcedurePerformed(visit, m, QPP205Elements.Hospice_Services, patientHistoryBroadcastList)
        ||
        (
          isProcedurePerformed(visit, m, QPP205Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
            || isInterventionPerformed(visit, m, QPP205Elements.Hospice_Care, patientHistoryBroadcastList)
          )
    )
  }


  // Numerator criteria
  /* Patients with chlamydia, gonorrhea, and syphilis screenings performed at least once since the diagnosis of HIV infection */

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>

      (
        isAssessmentPerformed(visit, m, QPP205Elements.Chlamydia_Gonorrhea_And_Syphilis_Screening, patientHistoryBroadcastList)
          ||
          (
            isAssessmentPerformed(visit, m, QPP205Elements.Chlamydia_Screening, patientHistoryBroadcastList)
              &&
              isAssessmentPerformed(visit, m, QPP205Elements.Gonorrhea_Screening_Grp, patientHistoryBroadcastList)
              &&
              isAssessmentPerformed(visit, m, QPP205Elements.Syphilis_Screening_Grp, patientHistoryBroadcastList)
            )
          || isAssessmentPerformed(visit, m, QPP205Elements.Screening_For_Venereal_Disease_Grp, patientHistoryBroadcastList)
        )
        && !isAssessmentPerformed(visit, m, QPP205Elements.Screening_Reason_Not_Specified_Grp, patientHistoryBroadcastList)
    )
  }


  // Numerator criteria
  /* Chlamydia, gonorrhea, and syphilis screening results not documented (Patient refusal is the only allowed exception) */

  def getException(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      !isAssessmentPerformed(visit, m, QPP205Elements.Patient_Refusal, patientHistoryBroadcastList)
        || isAssessmentPerformed(visit, m, QPP205Elements.Screening_Patient_Reason_Grp, patientHistoryBroadcastList)

    )
  }


}
