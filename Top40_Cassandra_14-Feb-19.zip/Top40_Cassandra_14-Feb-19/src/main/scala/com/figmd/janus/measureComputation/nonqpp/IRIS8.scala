package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, IRIS8Elements,CalenderUnit,CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- IRIS 8
* Measure Title              :- Surgical Pediatric Esotropia: Postoperative alignment
* Measure Description        :- Percentage of surgical esotropia pediatric patients with a postoperative alignment of
                                12 prism diopters (PD) or less without a reoperation.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS8 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS8"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD

    )
    val patientHistory: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistory)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusionRdd(ippRDD, patientHistory, patientHistoryRDD)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistory)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistory.destroy()
    }
  }

  /*------------------------------------------------------------------------------
     	All patients aged 18 years or less who underwent a surgical procedure for esotropia
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow],patientHistory:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
         isPatientAdult(visit,m)
      &&
        (
             isDiagnosedOnEncounter(visit,m,IRIS8Elements.Esotropia)
          || isDiagnosedOnEncounter(visit,m,IRIS8Elements.Intermittent_Esotropia)
          || isDiagnosedOnEncounter(visit,m,IRIS8Elements.Partially_Accommodative_Esotropia)
        )
      &&  wasProcedurePerformedBeforeEndInDays(visit,m,IRIS8Elements.Esotropia_Surgery,90,patientHistory)
      &&  isProcedurePerformedDuringEncounter(visit,m,IRIS8Elements.Esotropia_Surgery)
      &&  (
               checkEyeElementsInRange(visit,m,IRIS8Elements.Esotropia_Surgery__Eye,IRIS8Elements.Esotropia__Eye)
           ||  checkEyeElementsInRange(visit,m,IRIS8Elements.Esotropia_Surgery__Eye,IRIS8Elements.Intermittent_Esotropia__Eye)
           ||  checkEyeElementsInRange(visit,m,IRIS8Elements.Esotropia_Surgery__Eye,IRIS8Elements.Partially_Accommodative_Esotropia__Eye)
           )
    )

  }

  /*------------------------------------------------------------------------------
   	1. Patients with a history of diplopia, CN 6 palsy or Duane syndrome
    2. Patients who have a reoperation between the original surgery and the visit 4 to 12 weeks after the original surgery date
   ------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistory:Broadcast[List[CassandraRow]],patientHistoryRDD:RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>

      (
           isDiagnosedOnEncounter(visit,m,IRIS8Elements.Diplopia)
        && checkEyeElementsInRange(visit,m,IRIS8Elements.Esotropia_Surgery__Eye,IRIS8Elements.Diplopia__Eye)
      )
    ||
      (
           isDiagnosedOnEncounter(visit,m,IRIS8Elements.Sixth_Nerve_Palsy)
        && checkEyeElementsInRange(visit,m,IRIS8Elements.Sixth_Nerve_Palsy__Eye,IRIS8Elements.Diplopia__Eye)
      )
    ||
      (
          isDiagnosedOnEncounter(visit,m,IRIS8Elements.Duane_Syndrome)
        && checkEyeElementsInRange(visit,m,IRIS8Elements.Duane_Syndrome__Eye,IRIS8Elements.Diplopia__Eye)
      )
    ||   wasProcedureEyeEqualsWithInXDaysAfter(visit,m,IRIS8Elements.Esotropia_Surgery,84,patientHistoryRDD,IRIS8Elements.Esotropia_Surgery__Eye,
        IRIS8Elements.Esotropia_Surgery)


    )
  }

 /*------------------------------------------------------------------------------
    Postoperative alignment of 12 PD or less recorded between 4 and 12 weeks after surgery and no re-operation in the reporting period.
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistory:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>

       wasPhysicalExamPerformedAfterEncounterBetweenXPeriodesWithValues(visit,m,IRIS8Elements.Prism_Diopter,IRIS8Elements.Esotropia_Surgery,CompareOperator.LESS_EQUAL,12,CalenderUnit.WEEK,4,CalenderUnit.WEEK,12,patientHistory)
    && checkEyeElementAfterEncounterEyeElementBetweenXPeriods(visit,m,IRIS8Elements.Prism_Diopter__Eye,CalenderUnit.WEEK,4,CalenderUnit.WEEK,12,patientHistory,IRIS8Elements.Esotropia_Surgery__Eye)
    )

  }

}