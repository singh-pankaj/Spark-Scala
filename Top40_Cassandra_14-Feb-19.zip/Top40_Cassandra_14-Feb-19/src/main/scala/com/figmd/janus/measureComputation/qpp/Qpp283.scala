package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, CalenderUnit, MeasureProperty, QPP283Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 283
* Measure Title              :- Dementia Associated Behavioral and Psychiatric Symptoms Screening and Management
* Measure Description        :- Percentage of patients with dementia for whom there was a documented symptoms screening*
                                for behavioral and psychiatric symptoms, including depression, AND for whom, if symptoms
                                screening was positive, there was also documentation of recommendations for symptoms
                                management in the last 12 months.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp283 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "QPP283"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP283Elements.Dementia_Screening_Postive_Met
      , QPP283Elements.Dementia_Screening_Negative_Met
      , QPP283Elements.Neuropsychiatric_Assessment
      , QPP283Elements.Neuropsychiatric_Assessment_Tool
      , QPP283Elements.Positive_Result_Dementia_Screening
      , QPP283Elements.Behavioural_And_Psychiatric_Symptoms_Management_Rcommendations
      , QPP283Elements.Negative_Result_Dementia_Screening
      , QPP283Elements.Dementia_Screening_Not_Met
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      // metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()
      //

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  /*------------------------------------------------------------------------------------------------
   All patients with dementia
  ------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isDiagnosedOnEncounter(visit, m, QPP283Elements.Dementia)
        && isVisitTypeIn(visit, m
        , QPP283Elements.Occupational_Therapy_Evaluation
        , QPP283Elements.Health_And_Behavior_Intervention
        , QPP283Elements.Home_Healthcare_Services
        , QPP283Elements.Care_Services_In_Long_Term_Residential_Facility
        , QPP283Elements.Nursing_Facility_Visit
        , QPP283Elements.Health___Behavioral_Assessment___Individual
        , QPP283Elements.Health_And_Behavioral_Assessment__Reassessment
        , QPP283Elements.Health_And_Behavioral_Assessment___Initial
        , QPP283Elements.Behavioral_Neuropsych_Assessment
        , QPP283Elements.Psych_Visit___Psychotherapy
        , QPP283Elements.Assisted_Living_Facility
        , QPP283Elements.Chronic_Care_Management_Services
        , QPP283Elements.Office_Visit
      )
        && !isTeleHealthModifier(visit, m
        , QPP283Elements.Health_And_Behavior_Intervention_Telehealth_Modifier
        , QPP283Elements.Behavioral_Neuropsych_Assessment_Telehealth_Modifier
        , QPP283Elements.Health_And_Behavioral_Assessment___Individual_Telehealth_Modifier
        , QPP283Elements.Health_And_Behavioral_Assessment_Reassessment_Telehealth_Modifier
        , QPP283Elements.Health_And_Behavioral_Assessment__Initial_Telehealth_Modifier
        , QPP283Elements.Nursing_Facility_Visit_Telehealth_Modifier
        , QPP283Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
        , QPP283Elements.Home_Healthcare_Services_Telehealth_Modifier
        , QPP283Elements.Occupational_Therapy_Evaluation_Telehealth_Modifier
        , QPP283Elements.Office_Visit_Telehealth_Modifier
        , QPP283Elements.Psych_Visit___Psychotherapy_Telehealth_Modifier
        , QPP283Elements.Assisted_Living_Facility_Telehealth_Modifier
        , QPP283Elements.Chronic_Care_Management_Services_Telehealth_Modifier
      )
        && isPOSEncounterNotPerformed(visit, m, QPP283Elements.Pos_02)
    )
  }


  /*------------------------------------------------------------------------------------------------
  Patients with dementia for whom there was a documented screening for behavioral and psychiatric symptoms, including
  depression in the last 12 months and for whom, if screening was positive, there was also documentation of
  recommendations for management in the last 12 months.
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRdd.filter(visit =>
      (
        wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, QPP283Elements.Dementia_Screening_Postive_Met, 12, patientHistoryBroadcastList)
          || wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, QPP283Elements.Dementia_Screening_Negative_Met, 12, patientHistoryBroadcastList)
          ||
          (
            wasAssessmentPerformedwithMethodBeforeEncounter(visit, m, QPP283Elements.Neuropsychiatric_Assessment, QPP283Elements.Neuropsychiatric_Assessment_Tool, CalenderUnit.MONTH, 12, patientHistoryBroadcastList)
              && wasAssessmentPerformedBeforeXMonthsEncounter(visit, m, QPP283Elements.Positive_Result_Dementia_Screening, 12, patientHistoryBroadcastList)
              && wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, QPP283Elements.Behavioural_And_Psychiatric_Symptoms_Management_Rcommendations, 12, patientHistoryBroadcastList)
            )
          ||
          (
            wasAssessmentPerformedwithMethodBeforeEncounter(visit, m, QPP283Elements.Neuropsychiatric_Assessment, QPP283Elements.Neuropsychiatric_Assessment_Tool, CalenderUnit.MONTH, 12, patientHistoryBroadcastList)
              && wasAssessmentPerformedBeforeXMonthsEncounter(visit, m, QPP283Elements.Negative_Result_Dementia_Screening, 12, patientHistoryBroadcastList)
            )
        )
        && !wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, QPP283Elements.Dementia_Screening_Not_Met, 12, patientHistoryBroadcastList)
    )


  }

}
