package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP126Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 126
* Measure Title              :- Diabetes Mellitus: Diabetic Foot and Ankle Care, Peripheral Neuropathy – Neurological Evaluation
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of diabetes mellitus who had a neurological examination of their lower extremities within 12 months.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp126 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp126"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession,initialRDD,
          QPP126Elements.Diabetes_Gr,
          QPP126Elements.Diabetes_Mellitus,
          QPP126Elements.Diabetic_Peripheral_Neuropathy,
          QPP126Elements.Alzheimer_s_Disease,
          QPP126Elements.Dementia,
          QPP126Elements.Bilateral_Amputee,
          QPP126Elements.Cognitive_And_Psychiatric_Disorders_Indicative_Of_Impaired_Cognition,
          QPP126Elements.Right_Unilateral_Amputation_Above_Or_Below_Knee,
          QPP126Elements.Left_Unilateral_Amputation_Above_Or_Below_Knee,
          QPP126Elements.Lower_Extremity_Neurological_Exam,
          QPP126Elements.Monofilament_10_G,
          QPP126Elements.Lower_Extremity_Neurological_Testing_Evaluation_Of_Motor_And_Sensory_Abilities,
          QPP126Elements.Lower_Extremity_Neurological_Exam_Not_Met
      )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusion
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD,exclusionRDD , metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
          isPatientAdult(visit, m)
      && (isVisitTypeIn(visit, m,
                        QPP126Elements.Home_Healthcare_Services,
                        QPP126Elements.Care_Services_In_Long_Term_Residential_Facility,
                        QPP126Elements.Nursing_Facility_Visit,
                        QPP126Elements.Office_Visit,
                        QPP126Elements.Medical_Nutrition_Therapy,
                        QPP126Elements.Physical_Therapy_Evaluation_Cpt,
                        QPP126Elements.Re_Evaluation_Of_Physical_Therapy_Cpt
                      )
            || isProcedurePerformedDuringEncounter(visit, m, QPP126Elements.Debridement_Trimming_Cutting)
            || isProcedurePerformedDuringEncounter(visit, m, QPP126Elements.Debridement)
         )
      &&
      (
         wasDiagnosedInHistory(visit, m, QPP126Elements.Diabetes_Gr, patientHistoryBroadcastList)
      || wasDiagnosedInHistory(visit, m, QPP126Elements.Diabetes_Mellitus, patientHistoryBroadcastList)
        )
      && (
          !isTeleHealthModifier(visit, m,QPP126Elements.Physical_Therapy_Visit_Telehealth,
                                  QPP126Elements.Medical_Nutrition_Therapy__Telehealth_Modifier,
                                  QPP126Elements.Office_Visit_Telehealth_Modifier,
                                  QPP126Elements.Nursing_Facility_Visit_Telehealth_Modifier,
                                  QPP126Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier,
                                  QPP126Elements.Home_Healthcare_Services_Telehealth_Modifier,
                                  QPP126Elements.Physical_Therapy_Telehealth_Modifier
                       )
                   || !isProcedurePerformedDuringEncounter(visit, m, QPP126Elements.Debridement_Telehealth_Modifier)
                   || !isProcedurePerformedDuringEncounter(visit, m, QPP126Elements.Debridement_Trimming_Cutting_Telehealth_Modifier)
         )
      || isPOSEncounterNotPerformed(visit, m, QPP126Elements.Pos_02)
     )

  }

  // Denominator Exclusion criteria
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
                             wasDiagnosedInHistory(visit, m, QPP126Elements.Diabetic_Peripheral_Neuropathy, patientHistoryBroadcastList)
                          || wasDiagnosedInHistory(visit, m, QPP126Elements.Alzheimer_s_Disease, patientHistoryBroadcastList)
                          || wasDiagnosedInHistory(visit, m, QPP126Elements.Dementia, patientHistoryBroadcastList)
                          || wasDiagnosedInHistory(visit, m, QPP126Elements.Bilateral_Amputee, patientHistoryBroadcastList)
                          || wasDiagnosedInHistory(visit, m, QPP126Elements.Cognitive_And_Psychiatric_Disorders_Indicative_Of_Impaired_Cognition, patientHistoryBroadcastList)
                          || wasAssessmentPerformedInHistory(visit, m, QPP126Elements.Right_Unilateral_Amputation_Above_Or_Below_Knee, patientHistoryBroadcastList)
                          || wasAssessmentPerformedInHistory(visit, m, QPP126Elements.Left_Unilateral_Amputation_Above_Or_Below_Knee, patientHistoryBroadcastList)
                 )
  }

  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    ipp.filter(visit =>
      (
        ((
          (
             isAssessmentPerformedOnEncounter(visit, m, QPP126Elements.Lower_Extremity_Neurological_Exam)
          || wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP126Elements.Lower_Extremity_Neurological_Exam, 12,patientHistoryBroadcastList)
          )
            &&
            wasAssessmentPerformedAfterDiagnosis(visit, m, QPP126Elements.Lower_Extremity_Neurological_Exam, patientHistoryBroadcastList, QPP126Elements.Diabetes_Gr, QPP126Elements.Diabetes_Mellitus)
        ) && (
                (
                     isAssessmentPerformedOnEncounter(visit, m, QPP126Elements.Monofilament_10_G)
                  && isAssessmentPerformedOnEncounter(visit, m, QPP126Elements.Lower_Extremity_Neurological_Testing_Evaluation_Of_Motor_And_Sensory_Abilities)
                )//$NeurologicalExam during $Encounter
                  ||
                (
                     wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP126Elements.Monofilament_10_G, 12,patientHistoryBroadcastList)
                  && wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP126Elements.Lower_Extremity_Neurological_Testing_Evaluation_Of_Motor_And_Sensory_Abilities, 12,patientHistoryBroadcastList)
                )//$NeurologicalExam <= 12 month(s) starts before start of $Encounter
             ) && (
                       wasAssessmentPerformedAfterDiagnosis(visit, m, QPP126Elements.Monofilament_10_G, patientHistoryBroadcastList, QPP126Elements.Diabetes_Gr, QPP126Elements.Diabetes_Mellitus)
                    && wasAssessmentPerformedAfterDiagnosis(visit, m, QPP126Elements.Lower_Extremity_Neurological_Testing_Evaluation_Of_Motor_And_Sensory_Abilities, patientHistoryBroadcastList, QPP126Elements.Diabetes_Gr, QPP126Elements.Diabetes_Mellitus)
                  ) //$NeurologicalExam starts after start of Union of:
                    //"Diagnosis: Diabetes_Gr"
                    //"Diagnosis: Diabetes Mellitus"
          ) && !(
                  (
                      isAssessmentPerformedOnEncounter(visit, m, QPP126Elements.Lower_Extremity_Neurological_Exam_Not_Met)
                   || wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP126Elements.Lower_Extremity_Neurological_Exam_Not_Met, 12,patientHistoryBroadcastList)
                  )&&  wasAssessmentPerformedAfterDiagnosis(visit, m, QPP126Elements.Lower_Extremity_Neurological_Exam_Not_Met, patientHistoryBroadcastList, QPP126Elements.Diabetes_Gr, QPP126Elements.Diabetes_Mellitus)
                )
        )

    )
  }




}
