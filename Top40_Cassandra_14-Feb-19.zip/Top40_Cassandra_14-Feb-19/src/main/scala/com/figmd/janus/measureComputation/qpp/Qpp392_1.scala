package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP392Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 392_1
* Measure Title              :- HRS-12: Cardiac Tamponade and/or Pericardiocentesis Following Atrial Fibrillation Ablation
* Measure Description        :- Rate of cardiac tamponade and/or pericardiocentesis following atrial fibrillation ablation This measure is reported as four rates stratified by age and gender:
                                • Reporting Age Criteria 1: Females 18-64years of age
                                • Reporting Age Criteria 2: Males 18-64 years of age
                                • Reporting Age Criteria 3: Females 65 years of age and older
                                • Reporting Age Criteria 4: Males 65 years of age and older
                                  REPORTING CRITERIA 5: Overall percentage of patients with cardiac tamponade and/or pericardiocentesis occurring within 30 days
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp392_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP392_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP392Elements.Atrial_Fibrillation_Ablation,
      QPP392Elements.Atrial_Fibrillation,
      QPP392Elements.Cardiac_Tamponade_And_Or_Pericardiocentesis,
      QPP392Elements.Cardiac_Tamponade,
      QPP392Elements.Pericardiocentesis,
      QPP392Elements.Cardiac_Tamponade_And_Or_Pericardiocentesis_Not_Met).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  // IPP-Denominator criteria
  /* All patients aged 18 years and older with atrial fibrillation ablation performed during the reporting period */

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isFemale(visit, m)
        && isAgeBetween(visit, m, 18, 65)
        && isDiagnosedWithInHistory(visit, m, QPP392Elements.Atrial_Fibrillation, patientHistoryBroadcastList)
        && isProcedurePerformed(visit, m, QPP392Elements.Atrial_Fibrillation_Ablation, patientHistoryBroadcastList)
        && isProcedurePerformedWithinXMonths(visit, m, QPP392Elements.Atrial_Fibrillation_Ablation, 11, patientHistoryBroadcastList)

    )
  }


  // Numerator criteria
  /* The number of patients from the denominator with cardiac tamponade and/or pericardiocentesis occurring within 30 days following atrial fibrillation ablation */

  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      (
        isAssessmentPerformed(visit, m, QPP392Elements.Cardiac_Tamponade_And_Or_Pericardiocentesis, patientHistoryBroadcastList)
          ||
          isDiagnosticStudyPerformedInXDaysAfterProcedure(visit, m, QPP392Elements.Cardiac_Tamponade, QPP392Elements.Atrial_Fibrillation_Ablation, 30, patientHistoryBroadcastList)
          ||
          isDiagnosticStudyPerformedInXDaysAfterProcedure(visit, m, QPP392Elements.Pericardiocentesis, QPP392Elements.Atrial_Fibrillation_Ablation, 30, patientHistoryBroadcastList)
        )
        && !isAssessmentPerformed(visit, m, QPP392Elements.Cardiac_Tamponade_And_Or_Pericardiocentesis_Not_Met, patientHistoryBroadcastList)
    )
  }


}
