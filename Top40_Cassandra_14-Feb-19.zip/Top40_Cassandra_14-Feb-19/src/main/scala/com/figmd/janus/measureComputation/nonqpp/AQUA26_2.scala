package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,AQUA26Elements,CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AQUA26_2
* Measure Title               :- Benign Prostate Hyperplasia Care: Benign Prostate Hyperplasia
* Measure Description         :- Percentage of patients with new diagnosis of BPH who had a creatinine lab order placed or had a CT abdomen, MRI abdomen, ultrasound abdomen ordered or performed.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 3
* Measure Stratum No.         :- 2
* Measure Stratification      :- NA
* Measure Developer           :- PRIYANKA CHAVAN
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/

object AQUA26_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AQUA26_2"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,AQUA26Elements.Benign_Prostate_Hyperplasia_New
      ,AQUA26Elements.Creatinine_Test
      ,AQUA26Elements.Documentation_Of_Renal_Insufficiency
      ,AQUA26Elements.Ct_Of_Abdomen
      ,AQUA26Elements.Mri_Of_Abdomen
      ,AQUA26Elements.Ultrasound_Of_Abdomen
      ,AQUA26Elements.Renal_Insufficiency_Kywrds
      ,AQUA26Elements.Documentation_Of_Hematuria
      ,AQUA26Elements.Documentation_Of_Flank_Pain
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
     Number of patients with a new diagnosis of benign prostatic hyperplasia(BPH)
	-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
             isMale(visit,m)
        &&   isDiagnosed(visit,m,AQUA26Elements.Benign_Prostate_Hyperplasia_New,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
   B. Number of patients with new diagnosis of BPH who had a CT abdomen, MRI abdomen, ultrasound abdomen ordered or performed
	-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            isLaboratoryTestPerformedAfterDiagnosisAndBeforeEnd(visit,m,AQUA26Elements.Ct_Of_Abdomen,patientHistoryBroadcastList,AQUA26Elements.Benign_Prostate_Hyperplasia_New)
        ||  isLaboratoryTestPerformedAfterDiagnosisAndBeforeEnd(visit,m,AQUA26Elements.Mri_Of_Abdomen,patientHistoryBroadcastList,AQUA26Elements.Benign_Prostate_Hyperplasia_New)
        ||  isLaboratoryTestPerformedAfterDiagnosisAndBeforeEnd(visit,m,AQUA26Elements.Ultrasound_Of_Abdomen,patientHistoryBroadcastList,AQUA26Elements.Benign_Prostate_Hyperplasia_New)
    )
  }

  /*----------------------------------------------------------------------------------------------------------------------------------
	Patients with known renal insufficiency (Cr >1.5 or documented in past medical history) or with documented flank pain or hematuria
	----------------------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
        (
               wasDiagnosedInHistory(visit,m,AQUA26Elements.Documentation_Of_Renal_Insufficiency,patientHistoryBroadcastList)
          &&   isLaboratoryTestPerformedValue(visit,m,AQUA26Elements.Creatinine_Test_Result, 1.5,CompareOperator.GREATER,patientHistoryBroadcastList)
        )
        ||
        (
                 isDiagnosed(visit,m,AQUA26Elements.Renal_Insufficiency_Kywrds,patientHistoryBroadcastList)
            ||   isDiagnosed(visit,m,AQUA26Elements.Documentation_Of_Hematuria,patientHistoryBroadcastList)
            ||	 isDiagnosed(visit,m,AQUA26Elements.Documentation_Of_Flank_Pain,patientHistoryBroadcastList)
        )
    )
  }
}