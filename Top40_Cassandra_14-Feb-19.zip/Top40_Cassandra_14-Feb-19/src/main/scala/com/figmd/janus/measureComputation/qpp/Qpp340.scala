package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, QPP340Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp340
* Measure Title              :- HIV Medical Visit Frequency
* Measure Description        :- Percentage of patients,regardless of age with a diagnosis of HIV who had atleast one medical visit in each 6 month period of the 24 month measurement period,with a minimum of 60 days between medical visits
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- 1
* Measure Developer          :- Vrushali Gholap
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp340 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp340"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      , QPP340Elements.Hiv_1
      , QPP340Elements.Patient_Deceased_1
      , QPP340Elements.Patient_Deceased_2
      , QPP340Elements.Medical_Visit_Hiv
      , QPP340Elements.Medvst_Not_Met
      , QPP340Elements.Initial_Preventive_Physical_Examination
      , QPP340Elements.Office_Visit
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val mForList = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    val occurenceList_A: List[CassandraRow] = patientListInXMonthRangeFromEnd(patientHistoryRDD, mForList, CalenderUnit.MONTH, 0, 6, QPP340Elements.Initial_Preventive_Physical_Examination, QPP340Elements.Office_Visit)
    val occurenceList_B: List[CassandraRow] = patientListInXMonthRangeFromEnd(patientHistoryRDD, mForList, CalenderUnit.MONTH, 6, 12, QPP340Elements.Initial_Preventive_Physical_Examination, QPP340Elements.Office_Visit)
    val occurenceList_C: List[CassandraRow] = patientListInXMonthRangeFromEnd(patientHistoryRDD, mForList, CalenderUnit.MONTH, 12, 18, QPP340Elements.Initial_Preventive_Physical_Examination, QPP340Elements.Office_Visit)
    val occurenceList_D: List[CassandraRow] = patientListInXMonthRangeFromEnd(patientHistoryRDD, mForList, CalenderUnit.MONTH, 18, 24, QPP340Elements.Initial_Preventive_Physical_Examination, QPP340Elements.Office_Visit)

    val occurenceBroadcastList_A: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(occurenceList_A)
    val occurenceBroadcastList_B: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(occurenceList_B)
    val occurenceBroadcastList_C: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(occurenceList_C)
    val occurenceBroadcastList_D: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(occurenceList_D)

    // Filter IPP
    val ippRDD = getIppRDD(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Exclusion
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate for MET
      val intermediateNumerator = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateNumerator.cache()

      // Filter Met
      val metRDD = getMetRDD(intermediateNumerator, patientHistoryBroadcastList, occurenceBroadcastList_A: Broadcast[List[CassandraRow]], occurenceBroadcastList_B: Broadcast[List[CassandraRow]], occurenceBroadcastList_C: Broadcast[List[CassandraRow]], occurenceBroadcastList_D: Broadcast[List[CassandraRow]])
      metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateNumerator, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      occurenceBroadcastList_A.destroy()
      occurenceBroadcastList_B.destroy()
      occurenceBroadcastList_C.destroy()
      occurenceBroadcastList_D.destroy()

    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Patients,regardless of age,with a diagnosis of HIV with atleast one medical visit in the performance period
  ----------------------------------------------------------------------------------------------------------------------------*/
  def getIppRDD(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isVisitTypeIn(visit, m, QPP340Elements.Initial_Preventive_Physical_Examination
        , QPP340Elements.Office_Visit)
        && wasDiagnosisStartsBeforeEndPriorToXMonths(visit, m, QPP340Elements.Hiv_1, 21, patientHistoryList)
      // Note : patients should be diagnosed with HIV during the first 3 months of the 24-month measurement period
      // or have a diagnosis prior to the 24 month measurement period. Thus checking only one condition that patient have a diagnosis prior to the 21 months.

    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Patient died at any time during the 24‐month measurement period
  -------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      wasPatientCharacteristicBeforeEndInXMonths(visit, m, QPP340Elements.Patient_Deceased_1, 24, patientHistoryList)
        || wasPatientCharacteristicBeforeEndInXMonths(visit, m, QPP340Elements.Patient_Deceased_2, 24, patientHistoryList)

    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Number of patients who had at least one medical visit in each 6 month period of the 24 month measurement period, with a minimum of 60 days between medical visits
   -------------------------------------------------------------------------------------------------------------------*/
  def getMetRDD(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], occurenceBroadcastList_A: Broadcast[List[CassandraRow]], occurenceBroadcastList_B: Broadcast[List[CassandraRow]], occurenceBroadcastList_C: Broadcast[List[CassandraRow]], occurenceBroadcastList_D: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      wasDifferenceOfVisitinXDays(visit, m, 60, occurenceBroadcastList_A, occurenceBroadcastList_B)
        && wasDifferenceOfVisitinXDays(visit, m, 60, occurenceBroadcastList_B, occurenceBroadcastList_C)
        && wasDifferenceOfVisitinXDays(visit, m, 60, occurenceBroadcastList_C, occurenceBroadcastList_D)
        && wasEncounterPerformed(visit, m, QPP340Elements.Medical_Visit_Hiv, patientHistoryList)
        && !wasEncounterPerformed(visit, m, QPP340Elements.Medvst_Not_Met, patientHistoryList)
    )
  }

}
