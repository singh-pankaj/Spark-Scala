package com.figmd.janus.measureComputation.nonqpp
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty,AAD29Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD 29
* Measure Title              :- Biopsy: Basal Cell Carcinoma Pathology Report - Subtyping Listed
* Measure Description        :- Percentage of all skin specimens diagnosed histologically as cutaneous BCC with pathology report listing the histopathological BCC subtype.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Vrushali Gholap
----------------------------------------------------------------------------------------------------------------------------*/
object AAD29 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "AAD29"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,AAD29Elements.Cutaneous_Basal_Cell_Carcinoma_Grp
      ,AAD29Elements.Undetermined_Bcc_Subtype_Grp
      ,AAD29Elements.Histopathological_Bcc_Subtype_Grp
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      /*exclusion RDD*/
      val exclusionRDD = getExclusionRdd(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryBroadcastList.destroy()
    }
  }

  /*------------------------------------------------------------------------------
    All skin specimens diagnosed histologically as cutaneous Basal Cell Carcinoma within the reporting period.
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
       isDiagnosed(visit,m,AAD29Elements.Cutaneous_Basal_Cell_Carcinoma_Grp,patientHistoryList)
      && (  isProcedurePerformedDuringEncounter(visit,m,AAD29Elements.Cutaneous_Biopsy_Grp)
          ||isProcedurePerformedDuringEncounter(visit,m,AAD29Elements.Cutaneous_Biopsy_External_Auditory_Canal_Grp)
          )
      //Procedure specific Measure thus procedure checked on encounter. And Exclusion and Numerator checked in context of Encounter.
    )
  }

  /*------------------------------------------------------------------------------
  All cases where the histopathological BCC subtype could not be accurately determined.
  For all exclusions, an explanation should be provided in the biopsy report
  (e.g., superficial tissue sampling or fragmentation of the skin specimen).
  ------------------------------------------------------------------------------*/

    def getExclusionRdd(denominatorRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
      val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
      denominatorRDD.filter(visit =>
        wasProcedurePerformedAfterOrEqualEncounter(visit,m,AAD29Elements.Undetermined_Bcc_Subtype_Grp,patientHistoryList)
      )}

  /*------------------------------------------------------------------------------
  Number of skin specimens with a diagnosis of BCC for which the pathology report listed the histopathological BCC subtype.
  ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      wasDiagnosticStudyPerformedAfterOrEqualEncounter(visit,m,AAD29Elements.Histopathological_Bcc_Subtype_Grp,patientHistoryList)
    )
  }

  }
