package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, QIM1Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- QIM1
* Measure Title               :- Cataracts: 20/40 or Better Visual Acuity within 90 Days Following Cataract Surgery
* Measure Description         :- Percentage of patients aged 18 years and older with a diagnosis of uncomplicated cataract who had cataract surgery and no significant ocular
                                 conditions impacting the visual outcome of surgery and had best-corrected visual acuity of 20/40 or better (distance or near) achieved within 90 days following the cataract surgery
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object QIM1 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "QIM1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QIM1Elements.Un_Corrected_Left_Eye_Va_Value
      , QIM1Elements.Un_Corrected_Right_Eye_Va_Value
      , QIM1Elements.Un_Specified_Left_Eye_Va_Value
      , QIM1Elements.Un_Specified_Right_Eye_Va_Value
      , QIM1Elements.Best_Corrected_Left_Eye_Va_Value
      , QIM1Elements.Best_Corrected_Right_Eye_Va_Value
      , QIM1Elements.Best_Corrected_Visual_Acuity
      , QIM1Elements.Visual_Acuity_20_40_Or_Better
      , QIM1Elements.Visual_Acuity_Eye
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val correctVAValues: Array[String] = Array("20/10", "20/11", "20/12", "20/13", "20/14", "20/15", "20/16", "20/17", "20/18", "20/19", "20/2", "20/20", "20/21", "20/22", "20/23", "20/24", "20/25", "20/26", "20/28", "20/29", "20/3", "20/30", "20/31", "20/32", "20/33", "20/34", "20/35", "20/36", "20/37", "20/38", "20/39", "20/4", "20/5", "20/6", "20/7", "20/8", "20/9", "20/40")

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList,correctVAValues)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients aged 18 years and older who had cataract surgery
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val filteredRDD = getPatientRDDBetweenPeriodsInMeasurementPeriod(initialRDD, m, CalenderUnit.DAY, 92, false)

    filteredRDD.filter(visit =>
           isPatientAdult(visit,m)
        && isProcedurePerformedDuringEncounter(visit, m, QIM1Elements.Cataract_Surgery)
        && isProcedurePerformedWasConcurrentWith(visit, m, QIM1Elements.Cataract_Surgery_Eye, QIM1Elements.Cataract_Surgery, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who had best-corrected visual acuity of 20/40 or better (distance or near) achieved within 90 days following cataract surgery
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], correctVAValues: Array[String]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      (
        wasCorrectedVisualAcuityValueGreaterXDays(visit, m, QIM1Elements.Un_Corrected_Left_Eye_Va_Value, QIM1Elements.Cataract_Surgery, 90, correctVAValues, patientHistoryBroadcastList)
          ||
          wasCorrectedVisualAcuityValueGreaterXDays(visit, m, QIM1Elements.Un_Corrected_Right_Eye_Va_Value, QIM1Elements.Cataract_Surgery, 90, correctVAValues, patientHistoryBroadcastList)
          ||
          wasCorrectedVisualAcuityValueGreaterXDays(visit, m, QIM1Elements.Un_Specified_Left_Eye_Va_Value, QIM1Elements.Cataract_Surgery, 90, correctVAValues, patientHistoryBroadcastList)
          ||
          wasCorrectedVisualAcuityValueGreaterXDays(visit, m, QIM1Elements.Un_Specified_Right_Eye_Va_Value, QIM1Elements.Cataract_Surgery, 90, correctVAValues, patientHistoryBroadcastList)
          ||
          wasCorrectedVisualAcuityValueGreaterXDays(visit, m, QIM1Elements.Best_Corrected_Left_Eye_Va_Value, QIM1Elements.Cataract_Surgery, 90, correctVAValues, patientHistoryBroadcastList)
          ||
          wasCorrectedVisualAcuityValueGreaterXDays(visit, m, QIM1Elements.Best_Corrected_Right_Eye_Va_Value, QIM1Elements.Cataract_Surgery, 90, correctVAValues, patientHistoryBroadcastList)
        )
        ||
        (
               isPhysicalExamAndVAValueAfterXProcedureDays(visit, m, QIM1Elements.Cataract_Surgery, QIM1Elements.Visual_Acuity_20_40_Or_Better, QIM1Elements.Best_Corrected_Visual_Acuity, 90, patientHistoryBroadcastList)
          &&
            isPhysicalExamPerformedDuringPhysicalExam(visit, m, QIM1Elements.Visual_Acuity_Eye, QIM1Elements.Visual_Acuity_Eye_Date, QIM1Elements.Best_Corrected_Visual_Acuity, QIM1Elements.Best_Corrected_Visual_Acuity_Date)
        )
    )
  }

}
