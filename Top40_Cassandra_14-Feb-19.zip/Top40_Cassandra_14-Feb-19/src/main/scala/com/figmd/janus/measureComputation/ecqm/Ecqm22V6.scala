package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, ECQM22V6Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm22v6
* Measure Title              :- Preventive Care and Screening: Screening for High Blood Pressure and Follow-Up Documented
* Measure Description        :- Percentage of patients aged 18 years and older seen during the reporting period who
*                               were screened for high blood pressure AND a recommended follow-up plan is documented
*                               based on the current blood pressure (BP) reading as indicated
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Sumant Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm22V6 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm22V6"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , ECQM22V6Elements.Bp_Screening_Encounter_Codes
      , ECQM22V6Elements.Diagnosis_Of_Hypertension
      , ECQM22V6Elements.Referral_To_Alternative_Provider___Primary_Care_Provider
      , ECQM22V6Elements.Finding_Of_Hypertension
      , ECQM22V6Elements.Lifestyle_Recommendation
      , ECQM22V6Elements.Weight_Reduction_Recommended
      , ECQM22V6Elements.Dietary_Recommendations
      , ECQM22V6Elements.Physical_Activity_Recommendation
      , ECQM22V6Elements.Moderation_Of_Etoh_Consumption_Recommendation
      , ECQM22V6Elements.Followup_Within_One_Year
      , ECQM22V6Elements.Systolic_Blood_Pressure
      , ECQM22V6Elements.Diastolic_Blood_Pressure
      , ECQM22V6Elements.Followup_Within_4_Weeks
      , ECQM22V6Elements.Anti_Hypertensive_Pharmacologic_Therapy
      , ECQM22V6Elements.Laboratory_Tests_For_Hypertension
      , ECQM22V6Elements.Ecg_12_Lead_Or_Study_Order
      , ECQM22V6Elements.Patient_Reason_Refused
    )

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val mostRecentRDD = mostRecentPatientList(patientHistoryRDD, ECQM22V6Elements.Bp_Screening_Encounter_Codes)
    val mostRecentRDDList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostRecentRDD)

    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exceptions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      val intermediateRDD = ippRDD.subtract(exclusionRDD)
      intermediateRDD.cache()

      // Filter Met
      val metRDD = getMet(intermediateRDD, patientHistoryList, mostRecentRDDList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateRDD, patientHistoryList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryList.destroy()
      mostRecentRDDList.destroy()
    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
  All patients aged 18 years and older at the beginning of the measurement period with at least one eligible encounter during the measurement period
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        isEncounterPerformed(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes, patientHistoryList)
    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
  Patient has an active diagnosis of hypertension
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      wasDiagnosedBeforeEncounter(visit, m, ECQM22V6Elements.Diagnosis_Of_Hypertension, patientHistoryList)
    )

  }


  /*-----------------------------------------------------------------------------------------------------------------------
  Patients who were screened for high blood pressure AND have a recommended follow-up plan documented, as indicated
  if the blood pressure is pre-hypertensive or hypertensive
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]],
             mostRecentRDDList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)


    intermediateRDD.filter(visit =>
      (
        isPhysicalExamPerformedDuringEncounter(visit, m, ECQM22V6Elements.Diastolic_Blood_Pressure)
          &&
          isPhysicalExamPerformedDuringEncounter(visit, m, ECQM22V6Elements.Systolic_Blood_Pressure)
        )
        &&
        (
          (
            isPhysicalExamPerformedWithResultDuringEncounter(visit, m,
              ECQM22V6Elements.Systolic_Blood_Pressure, 120, CompareOperator.LESS)
              &&
              isPhysicalExamPerformedWithResultDuringEncounter(visit, m,
                ECQM22V6Elements.Diastolic_Blood_Pressure, 80, CompareOperator.LESS)
            )
            ||
            (
              (
                (
                  wasPhysicalExamPerformedOnEncounterRange(visit, m,
                    ECQM22V6Elements.Systolic_Blood_Pressure, CompareOperator.GREATER_EQUAL_And_LESS, 120, 140)
                    &&
                    isPhysicalExamPerformedWithResultDuringEncounter(visit, m,
                      ECQM22V6Elements.Diastolic_Blood_Pressure, 90, CompareOperator.LESS)
                  )
                  ||
                  (
                    wasPhysicalExamPerformedOnEncounterRange(visit, m,
                      ECQM22V6Elements.Diastolic_Blood_Pressure, CompareOperator.GREATER_EQUAL_And_LESS, 80, 90)
                      &&
                      isPhysicalExamPerformedWithResultDuringEncounter(visit, m,
                        ECQM22V6Elements.Systolic_Blood_Pressure, 140, CompareOperator.LESS)
                    )
                )
                &&
                (
                  isInterventionOrderedWithReasonAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                    ECQM22V6Elements.Referral_To_Alternative_Provider___Primary_Care_Provider,
                    ECQM22V6Elements.Finding_Of_Hypertension, CalenderUnit.DAY, 1, patientHistoryList)
                    ||
                    (
                      (
                        isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                          ECQM22V6Elements.Lifestyle_Recommendation, CalenderUnit.DAY, 1, patientHistoryList)
                          ||
                          isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                            ECQM22V6Elements.Weight_Reduction_Recommended, CalenderUnit.DAY, 1, patientHistoryList)
                          ||
                          isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                            ECQM22V6Elements.Dietary_Recommendations, CalenderUnit.DAY, 1, patientHistoryList)
                          ||
                          isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                            ECQM22V6Elements.Physical_Activity_Recommendation, CalenderUnit.DAY, 1, patientHistoryList)
                          ||
                          isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                            ECQM22V6Elements.Moderation_Of_Etoh_Consumption_Recommendation, CalenderUnit.DAY, 1, patientHistoryList)
                        )
                        &&
                        isInterventionOrderedWithReasonAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                          ECQM22V6Elements.Followup_Within_One_Year, ECQM22V6Elements.Finding_Of_Hypertension, CalenderUnit.DAY, 1, patientHistoryList)
                      )
                  )
              )
            || //3rd OR
            (
              (
                (
                  !wasPhysicalExamPerformedInXYears(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                    ECQM22V6Elements.Systolic_Blood_Pressure, CalenderUnit.YEAR, 1, patientHistoryList)
                    &&
                    !wasPhysicalExamPerformedInXYears(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                      ECQM22V6Elements.Diastolic_Blood_Pressure, CalenderUnit.YEAR, 1, patientHistoryList)
                  )
                  ||
                  (// Most recent is today's encounter. No need to check 1 year before.
                    isPhysicalExamPerformedWithResultDuringEncounter(visit, m, ECQM22V6Elements.Systolic_Blood_Pressure, 140, CompareOperator.LESS)
                      &&
                      isPhysicalExamPerformedWithResultDuringEncounter(visit, m, ECQM22V6Elements.Diastolic_Blood_Pressure, 90, CompareOperator.LESS)
                    )
                )
                &&
                (
                  isPhysicalExamPerformedWithResultDuringEncounter(visit, m, ECQM22V6Elements.Systolic_Blood_Pressure, 140, CompareOperator.GREATER_EQUAL)
                    ||
                    isPhysicalExamPerformedWithResultDuringEncounter(visit, m, ECQM22V6Elements.Diastolic_Blood_Pressure, 90, CompareOperator.GREATER_EQUAL)
                  )
                &&
                (
                  isInterventionOrderedWithReasonAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                    ECQM22V6Elements.Referral_To_Alternative_Provider___Primary_Care_Provider,
                    ECQM22V6Elements.Finding_Of_Hypertension, CalenderUnit.DAY, 1, patientHistoryList)
                    ||
                    (
                      (
                        isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                          ECQM22V6Elements.Lifestyle_Recommendation, CalenderUnit.DAY, 1, patientHistoryList)
                          ||
                          isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                            ECQM22V6Elements.Weight_Reduction_Recommended, CalenderUnit.DAY, 1, patientHistoryList)
                          ||
                          isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                            ECQM22V6Elements.Dietary_Recommendations, CalenderUnit.DAY, 1, patientHistoryList)
                          ||
                          isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                            ECQM22V6Elements.Physical_Activity_Recommendation, CalenderUnit.DAY, 1, patientHistoryList)
                          ||
                          isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                            ECQM22V6Elements.Moderation_Of_Etoh_Consumption_Recommendation, CalenderUnit.DAY, 1, patientHistoryList)
                        )
                        &&
                        isInterventionOrderedWithReasonAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                          ECQM22V6Elements.Followup_Within_4_Weeks, ECQM22V6Elements.Finding_Of_Hypertension, CalenderUnit.DAY, 1, patientHistoryList)
                      )
                  )
              )
            || //4th OR
            (
              (// Most recent is today's encounter. No need to check 1 year before.
                isPhysicalExamPerformedWithResultDuringEncounter(visit, m, ECQM22V6Elements.Systolic_Blood_Pressure, 140, CompareOperator.GREATER_EQUAL)
                  ||
                  isPhysicalExamPerformedWithResultDuringEncounter(visit, m, ECQM22V6Elements.Diastolic_Blood_Pressure, 90, CompareOperator.GREATER_EQUAL)
                )
                &&
                (
                  isPhysicalExamPerformedWithResultDuringEncounter(visit, m, ECQM22V6Elements.Diastolic_Blood_Pressure, 140, CompareOperator.GREATER_EQUAL)
                    ||
                    isPhysicalExamPerformedWithResultDuringEncounter(visit, m, ECQM22V6Elements.Diastolic_Blood_Pressure, 90, CompareOperator.GREATER_EQUAL)
                  )
                &&
                (
                  isInterventionOrderedWithReasonAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                    ECQM22V6Elements.Referral_To_Alternative_Provider___Primary_Care_Provider,
                    ECQM22V6Elements.Finding_Of_Hypertension, CalenderUnit.DAY, 1, patientHistoryList)
                    ||
                    (
                      (
                        isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                          ECQM22V6Elements.Lifestyle_Recommendation, CalenderUnit.DAY, 1, patientHistoryList)
                          ||
                          isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                            ECQM22V6Elements.Weight_Reduction_Recommended, CalenderUnit.DAY, 1, patientHistoryList)
                          ||
                          isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                            ECQM22V6Elements.Dietary_Recommendations, CalenderUnit.DAY, 1, patientHistoryList)
                          ||
                          isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                            ECQM22V6Elements.Physical_Activity_Recommendation, CalenderUnit.DAY, 1, patientHistoryList)
                          ||
                          isInterventionOrderedAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                            ECQM22V6Elements.Moderation_Of_Etoh_Consumption_Recommendation, CalenderUnit.DAY, 1, patientHistoryList)
                        )
                        &&
                        (
                          isMedicationOrderedNotDoneWithReasonAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                            ECQM22V6Elements.Anti_Hypertensive_Pharmacologic_Therapy, CalenderUnit.DAY, 1, patientHistoryList)
                            ||
                            isLaboratoryTestNotDoneWithReasonAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                              ECQM22V6Elements.Laboratory_Tests_For_Hypertension, CalenderUnit.DAY, 1, patientHistoryList)
                            ||
                            isDiagnosticStudyNotDoneWithReasonAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Bp_Screening_Encounter_Codes,
                              ECQM22V6Elements.Ecg_12_Lead_Or_Study_Order, CalenderUnit.DAY, 1, patientHistoryList)

                          )
                      )
                  )
              )
          )

    )

  }


/*-----------------------------------------------------------------------------------------------------------------------
Patient Reason(s):
  Patient refuses to participate (either BP measurement or follow-up)
OR
Medical Reason(s):
  Patient is in an urgent or emergent medical situation where time is of the essence and to delay treatment would
  jeopardize the patient's health status.  This may include but is not limited to severely elevated BP when immediate
  medical treatment is indicated.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    // Note : The For Reason data is not available in the table
    intermediateRDD.filter(visit =>
      isPhysicalExamPerformedDuringEncounter(visit, m, ECQM22V6Elements.Medical_Or_Other_Reason_Not_Done)
        ||
        isPhysicalExamPerformedDuringEncounter(visit, m, ECQM22V6Elements.Patient_Reason_Refused)
        ||
        isInterventionOrderedNotDoneWithReasonAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Patient_Reason_Refused,
          ECQM22V6Elements.Bp_Screening_Encounter_Codes, CalenderUnit.DAY, 1, patientHistoryList)
        ||
        isMedicationOrderedNotDoneWithReasonAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Patient_Reason_Refused,
          ECQM22V6Elements.Bp_Screening_Encounter_Codes, CalenderUnit.DAY, 1, patientHistoryList)
        ||
        isLaboratoryTestNotDoneWithReasonAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Patient_Reason_Refused,
          ECQM22V6Elements.Bp_Screening_Encounter_Codes, CalenderUnit.DAY, 1, patientHistoryList)
        ||
        isDiagnosticStudyNotDoneWithReasonAfterEncounterWithinXDays(visit, m, ECQM22V6Elements.Patient_Reason_Refused,
          ECQM22V6Elements.Bp_Screening_Encounter_Codes, CalenderUnit.DAY, 1, patientHistoryList)
    )

  }

}

