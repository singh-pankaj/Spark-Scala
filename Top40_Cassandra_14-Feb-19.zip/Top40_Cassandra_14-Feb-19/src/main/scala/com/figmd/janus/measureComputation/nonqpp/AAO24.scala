package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AAO24Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO24
* Measure Title               :- Allergic Rhinitis: Leukotriene Inhibitors
* Measure Description         :- Percentage of patients with allergic rhinitis who do not receive leukotriene inhibitors.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SHREYA_ASHTEKAR_FIGMD_COM
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object AAO24 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "AAO24"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      AAO24Elements.Allergic_Rhinitis_Grouping,
      AAO24Elements.Sleep_Apnea,
      AAO24Elements.Asthma,
      AAO24Elements.Leukotriene_Antagonist,
      AAO24Elements.Inhaled_Corticosteroids,
      AAO24Elements.Benign_Prostate_Hyperplasia,
      AAO24Elements.Prostate_Cancer,
      AAO24Elements.Inhaled_Corticosteroids
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population:
Patients ages 2 years and up with allergic rhinitis seen for an ambulatory visit with a diagnosis of
allergic rhinitis who do not have an active order (prescription or reported over the counter use) of intranasal
corticosteroids or second-generation antihistamines.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit,m,true,2)
        &&
        isEncounterPerformedOnEncounter(visit,m,AAO24Elements.Ambulatory_Visit)
        &&
        wasDiagnosedBeforeOrEqualEncounter(visit,m,AAO24Elements.Allergic_Rhinitis_Grouping,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exclusions:
Exclude patients with concomitant diagnosis of asthma or sleep apnea
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      wasDiagnosedInHistory(visit,m,AAO24Elements.Sleep_Apnea,patientHistoryBroadcastList)
        ||
        wasDiagnosedInHistory(visit,m,AAO24Elements.Asthma,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator:
Patients who do not receive leukotriene inhibitors.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      !(isMedicationOrdered(visit,m,patientHistoryBroadcastList,AAO24Elements.Leukotriene_Antagonist))
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exceptions:
Patients with allergy to intranasal corticosteroids, allergy to second generation antihistamines, or prostate issues (due to concern for intolerance of primary therapy options)
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      wasMedicationAllergyBeforeEncounter(visit,m,AAO24Elements.Inhaled_Corticosteroids,patientHistoryBroadcastList)
        ||
        wasDiagnosedBeforeOrEqualEncounter(visit,m,AAO24Elements.Benign_Prostate_Hyperplasia,patientHistoryBroadcastList)
        ||
        wasDiagnosedBeforeOrEqualEncounter(visit,m,AAO24Elements.Prostate_Cancer,patientHistoryBroadcastList)
        ||
        wasMedicationAllergyBeforeEncounter(visit,m,AAO24Elements.Inhaled_Corticosteroids,patientHistoryBroadcastList)
    )
  }
}