package com.figmd.janus.measureComputation.nonqpp



import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AQUA01
* Measure Title              :- Prostate Cancer: Documentation of PSA, Gleason score and clinical stage for risk stratification
* Measure Description        :- Percentage of patients newly diagnosed with Prostate Cancer with documentation of PSA level, Gleason score (primary and secondary pattern)
*                               and clinical stage in the MD notes before treatment.  This is a multiple item measure.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 4
* Measure Stratification     :- 4
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object AQUA01_4 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "AQUA01_4"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val hisrotyRDD = getPatientHistory(sparkSession, initialRDD,

      AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Prostate_Specific_Antigen_Test


    )


    var least_recent_patient_history_list = leastRecentPatientList(hisrotyRDD,
      AQUA01Elements.Prostate_Cancer_New,
      AQUA01Elements.External_Beam_Radiotherapy,
      AQUA01Elements.Gold__Fiducial_Marker,
      AQUA01Elements.Interstitial_Prostate_Brachytherapy,
      AQUA01Elements.Cryotherapy,
      AQUA01Elements.Radical_Prostatectomy,
      AQUA01Elements.Adt,
      AQUA01Elements.Watchful_Waiting,
      AQUA01Elements.Active_Surveillance,
      AQUA01Elements.Documentation_Of_Ebrt_In_Md_Notes,
      AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,
      AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,
      AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,
      AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,
      AQUA01Elements.Adt_Md_Notes,
      AQUA01Elements.Watchful_Waiting_Md_Notes,
      AQUA01Elements.Active_Surveillance_Md_Notes)



    var leastRecentpatientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(least_recent_patient_history_list)

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(hisrotyRDD.collect().toList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList,leastRecentpatientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()



      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryList,leastRecentpatientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }
  }




  //Number of newly diagnosed Prostate Cancer patients
  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>

      isMale(visit,m)
        &&  wasFirstDiagnosed(visit,m,AQUA01Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
    )
  }


  //Women undergoing revision surgery within 12 months of primary surgery
  def getMet(ippRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>



      (
        (
          (
                  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
              ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
              ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
              ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
              ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
              ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
              ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
              ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
            )
            &&
            (
                    wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

              )

          )
          ||
          (
            (
                    wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
              )
              &&
              (
                      wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Specific_Antigen_Test,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                )

            )
          ||
          (
            (
                    wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
              )
              &&
              (
                      wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Psa_In_Md_Notes,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                )

            )


        )
      &&
        (
          (
            (
              (
                      wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                )
                &&
                (
                        wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                  )

              )
              &&
              (
                (
                        wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  )
                  &&
                  (
                          wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                    )

                )



            )
            ||
            (
              (
                (
                        wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  )
                  &&
                  (
                          wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                    )

                )
                &&
                (
                  (
                          wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    )
                    &&
                    (
                            wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                      )

                  )
              )
            ||
            (
              (
                (
                        wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  )
                  &&
                  (
                          wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Gleason_Score_V,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                    )

                )


              )
            ||
            (
              (
                (
                        wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  )
                  &&
                  (
                          wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                    )

                )


              )

        )
      &&
        (
          (
            (
                    wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
              )
              &&
              (
                      wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Cancer_Staging,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                )

            )
            ||
            (
              (
                      wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                )
                &&
                (
                        wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                  )

              )
            ||
            (
              (
                      wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                )
                &&
                (
                        wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1a,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                  )

              )
            ||
            (
              (
                      wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                )
                &&
                (
                        wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1b,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                  )

              )
            ||
            (
              (
                      wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                )
                &&
                (
                        wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T1c,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                  )

              )
            ||
            (
              (
                      wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                )
                &&
                (
                        wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Prostate_Cancer_Primary_Tumor_Size_T2a,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                  )

              )
            ||
            (
              (
                      wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                )
                &&
                (
                        wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.T_Stage_T3a,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                  )

              )
            ||
            (
              (
                      wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                )
                &&
                (
                        wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_Stage_T3b_To_T4,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                  )

              )
            ||
            (
              (
                      wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                )
                &&
                (
                        wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Clinical_T_Staging_V,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                  )

              )
            ||
            (
              (
                      wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                  ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                )
                &&
                (
                        wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                    ||  wasDiagnosisBeforeFirstProcedure(visit,m,AQUA01Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,AQUA01Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                  )

              )




          )

    )
  }

}