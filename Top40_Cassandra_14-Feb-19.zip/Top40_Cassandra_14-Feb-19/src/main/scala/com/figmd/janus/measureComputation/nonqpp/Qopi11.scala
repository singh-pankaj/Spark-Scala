package com.figmd.janus.measureComputation.nonqpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qopi 11
* Measure Title              :- Combination chemotherapy received within 4 months of diagnosis by women under 70 with
*                               AJCC stage IA (T1c) and IB to III ER/PR negative breast cancer
* Measure Description        :- Percentage of adult women under 70 with a diagnosis of AJCC stage IA (T1c) and IB - III
*                               ER/PR negative breast cancer who receive combination chemotherapy within 4 months of diagnosis
* Calculation Implementation :- Patient Specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/


object Qopi11 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qopi11"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val getPatientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QOPI11Elements.Breast_Cancer
    ).collect.toList

    val patientHistory: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistory)
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      // Filter Denominator
      val denominatorRDD = getDenominator(ippRDD, patientHistory: Broadcast[List[CassandraRow]])
      denominatorRDD.cache()

      // Filter Not Eligible
      /* val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    notEligibleRDD.cache()*/

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(denominatorRDD, patientHistory: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMetRdd(intermediateA, patientHistory: Broadcast[List[CassandraRow]])
      metRDD.cache()

      // Filter Intermediate RDD
      val intermediateException = getSubtractRDD(intermediateA, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateException, patientHistory: Broadcast[List[CassandraRow]])
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistory.destroy()
    }
  }


  // IPP criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 18)
        &&
        isAgeBelow(visit, m, false, 70)
        &&
        isFemale(visit, m)
        &&
        wasDiagnosisInHistory(visit, m, QOPI11Elements.Breast_Cancer, patientHistory)
        &&
        isVisitTypeIn(visit, m, QOPI11Elements.Office_Visit, QOPI11Elements.Patient_Provider_Interaction)
    )
  }


  // Denominator Criteria
  def getDenominator(eligibleRdd: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE, globalStartDate, globalEndDate)
    eligibleRdd.filter(visit =>
      (
        (
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.Cancer_Stage_Ii, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.Cancer_Stage_Iia, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.Cancer_Stage_Iib, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.Cancer_Stage_Iii, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.Cancer_Stage_Iiia, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.Cancer_Stage_Iiib, patientHistory)
          ||
          wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.Cancer_Stage_Iiic, patientHistory)
          )
          ||
          (
            (
              wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.T_Stage_T1c, patientHistory)
              &&
              wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.T_Stage_T2, patientHistory)
              &&
              wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.T_Stage_T3, patientHistory)
              &&
              wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.T_Stage_T4, patientHistory)
              &&
              wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.T_Stage_T4a, patientHistory)
              &&
              wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.T_Stage_T4b, patientHistory)
              &&
              wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.T_Stage_T4c, patientHistory)
              )
              &&
              wasDiagnosticStudyPerformedWithResult(visit, m, QOPI11Elements.Tumor_Staging, QOPI11Elements.N_Stage_N0, patientHistory)
            )
          ||
          (
            (
              wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.Cancer_Stage_Ia, patientHistory)
              &&
              wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.T_Stage_T1c, patientHistory)
            )
              ||
              wasDiagnosticStudyPerformedWithResult(visit, m, QOPI11Elements.Tumor_Staging, QOPI11Elements.Cancer_Stage_Ib, patientHistory)
            )
          ||
          (
            wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.N_Stage_N3c, patientHistory)
            ||
            wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.N_Stage_N3, patientHistory)
            ||
            wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.N_Stage_N2, patientHistory)
            ||
            wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.N_Stage_N1, patientHistory)
            ||
              (
              wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.T_Stage_T1c, patientHistory)
              &&
              wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.N_Stage_Pn1mi, patientHistory)
              )
            )
          ||
          (
            (
              wasLaboratoryTestWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Estrogen_Receptor_Er, QOPI11Elements.Estrogen_Receptor_Negative, patientHistory)
              &&
              wasLaboratoryTestWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Progesterone_Receptor_Pr, QOPI11Elements.Progesterone_Receptor_Negative, patientHistory)
            )
              ||
              (
                wasLaboratoryTestOrderAfterDiagnosis(visit, m,QOPI11Elements.Breast_Cancer, patientHistory, QOPI11Elements.Estrogen_Receptor_Negative )
                &&
                wasLaboratoryTestOrderAfterDiagnosis(visit, m,QOPI11Elements.Breast_Cancer, patientHistory, QOPI11Elements.Progesterone_Receptor_Negative )
              )
            )
        )
    )
  }


  // Exclusion criteria
  def getExclusionRdd(exclusionRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    exclusionRDD.filter(visit =>

      wasElementAfterOrConcurrentAnotherElement(visit, m, QOPI11Elements.Chemotherapy_Initiation ,QOPI11Elements.Transfer_To_Practice ,patientHistory)
      ||
      wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.M_Stage_M1, patientHistory)
      ||
      wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.Histologic_Confirmation_Of_Cystosarcoma_Phyllodes, patientHistory)
      ||
      wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.Histologic_Confirmation_Of_Malignant_Phyllodes, patientHistory)
      ||
      wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.Histologic_Confirmation_Of_Mucinous_Carcinoma, patientHistory)
      ||
      wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.Tubular_Carcinoma, patientHistory)
      ||
      wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Tumor_Staging, QOPI11Elements.Histologic_Confirmation_Of_Cystosarcoma_Phyllodes, patientHistory)
      ||
      wasDiagnosisDoneAfterInitialDiagnosis(visit, m, QOPI11Elements.Cystosarcoma_Phyllodes, patientHistory, QOPI11Elements.Breast_Cancer)
      ||
      wasDiagnosisDoneAfterInitialDiagnosis(visit, m, QOPI11Elements.Mucinous_Carcinoma, patientHistory, QOPI11Elements.Breast_Cancer)
      ||
      wasDiagnosisDoneAfterInitialDiagnosis(visit, m, QOPI11Elements.Malignant_Phyllodes, patientHistory, QOPI11Elements.Breast_Cancer)
      ||
      wasDiagnosisDoneAfterInitialDiagnosis(visit, m, QOPI11Elements.Tubular_Carcinoma, patientHistory, QOPI11Elements.Breast_Cancer)
      ||
      wasPatientCharacteristicExpiredAfterXDaysDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Expired, 124, patientHistory)
      ||
      wasEncounterPerformedAfterXDaysDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, 124, patientHistory)
    )

  }


  // Numerator criteria
  def getMetRdd(metRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    metRDD.filter(visit =>
      wasMedicationAdministeredAfterXDaysDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Breast_Combination_Therapy, 124, patientHistory)
      ||
      wasMedicationAdministeredAfterXDaysDiagnosis(visit, m, QOPI11Elements.Breast_Cancer, QOPI11Elements.Alternative_Treatment, 124, patientHistory)
    )
  }


  // Exception criteria
  def getException(exceptionRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    exceptionRDD.filter(visit =>
    isMedicationAllergyDuringEncounter(visit, m, QOPI11Elements.Medical_Reason)
    ||
    isMedicationAllergyDuringEncounter(visit, m, QOPI11Elements.Patient_Reason)
    ||
    isMedicationAllergyDuringEncounter(visit, m, QOPI11Elements.System_Reason)
    )
  }
}






