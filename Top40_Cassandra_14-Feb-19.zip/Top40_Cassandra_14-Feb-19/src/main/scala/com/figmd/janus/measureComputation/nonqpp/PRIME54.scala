package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,PRIME54Elements,CompareOperator,AdminElements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PRIME54
* Measure Title               :- Diabetes: Low Density Lipoprotein (LDL-C) Control (< 100 mg/dL)
* Measure Description         :- Percentage of patients 18-75 years of age with diabetes whose LDL-C was adequately
                                 controlled (<100 mg/dL) during the measurement period.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SANKET.DHAPTE
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object PRIME54 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "PRIME54"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
                                                                        ,PRIME54Elements.Diabetes__Type_I_And_Type_Ii_
                                                                        ,PRIME54Elements.Ldl_C
                                               )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    val mostRecentRDD = mostRecentPatientList(patientHistoryRDD: RDD[CassandraRow], PRIME54Elements.Ldl_C)
    val mostRecentpatientList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostRecentRDD)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, mostRecentpatientList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients 18-75 years of age with diabetes with a visit during the measurement period
  ----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
         isDiagnosedWithInHistory(visit,m,PRIME54Elements.Diabetes__Type_I_And_Type_Ii_,patientHistoryBroadcastList)
      && isAgeBetween(visit,m,18,CompareOperator.GREATER_EQUAL,76,CompareOperator.LESS,AdminElements.Encounter_Date)
      && isVisitTypeIn(visit,m
                               ,PRIME54Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
                               ,PRIME54Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
                               ,PRIME54Elements.Office_Visit
                               ,PRIME54Elements.Home_Healthcare_Services
                               ,PRIME54Elements.Face_To_Face_Interaction
                               ,PRIME54Elements.Annual_Wellness_Visit
                       )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients whose most recent LDL-C level performed during the measurement period is <100 mg/dL
  ----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], mostRecentpatientList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>

      isMostRecentLaboratoryTestPerformedValue(visit,m,PRIME54Elements.Ldl_C,100,CompareOperator.LESS,mostRecentpatientList)
    )
  }

}
