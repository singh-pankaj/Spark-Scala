package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- TEST6
* Measure Title               :- Tonsillectomy: Secondary Post-Tonsillectomy Hemorrhage in Adults
* Measure Description         :- The rate of secondary post-tonsillectomy hemorrhage that requires reevaluation or intervention in >18 years of age
                                 seen by the operating surgeon between 2 and 21 days after surgery.
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Lower Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.RASURE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- http://192.168.109.178/MeasureDevelopment/Measure_Development_2019/tree/Development/NonQPP/AAOHNS/TEST6
----------------------------------------------------------------------------------------------------------------------------*/

object TEST6 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "TEST6"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,TEST6Elements.Tonsillectomy,
      TEST6Elements.Bleeding__Clotting_Disorders,
      TEST6Elements.Post__Tonsillectomy_Hemorrhage__Secondary_,
      TEST6Elements.Secondary_Hemorrhage,
      TEST6Elements.Patient_Experienced_Hemorrhage,
      TEST6Elements.Reevaluation_For_Post_Tonsillectomy_Hemorrhage,
      TEST6Elements.Office_Or_Other_Outpatient_Visit,
      TEST6Elements.Discharge_Services__Observation_Care,
      TEST6Elements.Discharge_Services___Hospital_Inpatient_Same_Day_Discharge,
      TEST6Elements.Outpatient_Consultation,
      TEST6Elements.Hospital_Inpatient_Visit___Initial,
      TEST6Elements.Hospital_Observation_Care___Initial,
      TEST6Elements.Subsequent_Hospital_Care,
      TEST6Elements.Subsequent_Observation_Care
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population : All patients >18 years of age who undergo tonsillectomy and are seen by the operating surgeon between 2 and 21 days after surgery.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit,m)
        && isProcedurePerformedDuringEncounter(visit,m,TEST6Elements.Tonsillectomy)
        && isVisitTypeIn(visit,m,TEST6Elements.Office_Or_Other_Outpatient_Visit,
        TEST6Elements.Discharge_Services__Observation_Care,
        TEST6Elements.Discharge_Services___Hospital_Inpatient_Same_Day_Discharge,
        TEST6Elements.Outpatient_Consultation,
        TEST6Elements.Hospital_Inpatient_Visit___Initial,
        TEST6Elements.Hospital_Observation_Care___Initial,
        TEST6Elements.Subsequent_Hospital_Care,
        TEST6Elements.Subsequent_Observation_Care
      )
        && wasEncounterPerformedAfterEndofProcedureWithInXDays(visit,m,TEST6Elements.Tonsillectomy,Seq(TEST6Elements.Office_Or_Other_Outpatient_Visit,
        TEST6Elements.Discharge_Services__Observation_Care,
        TEST6Elements.Discharge_Services___Hospital_Inpatient_Same_Day_Discharge,
        TEST6Elements.Outpatient_Consultation,
        TEST6Elements.Hospital_Inpatient_Visit___Initial,
        TEST6Elements.Hospital_Observation_Care___Initial,
        TEST6Elements.Subsequent_Hospital_Care,
        TEST6Elements.Subsequent_Observation_Care),CalenderUnit.DAY,2,CompareOperator.GREATER_EQUAL,CalenderUnit.DAY,21,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exclusions :Patients with known bleeding and/or clotting disorders
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      wasDiagnosisOverlapsProcedureInHistory(visit,m,TEST6Elements.Bleeding__Clotting_Disorders,TEST6Elements.Tonsillectomy,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator : All patients >18 years of age who experience secondary post-tonsillectomy hemorrhage that requires reevaluation
or intervention between 2 and 21 days after surgery.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (    wasProcedurePerformedAfterEndofProcedureWithInXDays(visit,m,TEST6Elements.Tonsillectomy,Seq(TEST6Elements.Post__Tonsillectomy_Hemorrhage__Secondary_),CalenderUnit.DAY,2,CompareOperator.GREATER_EQUAL,CalenderUnit.DAY,21,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
        || wasDiagnosisAfterEndofProcedureWithInXDays(visit,m,TEST6Elements.Tonsillectomy,Seq(TEST6Elements.Secondary_Hemorrhage),CalenderUnit.DAY,2,CompareOperator.GREATER_EQUAL,CalenderUnit.DAY,21,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
        )
        && (    wasInterventionPerformedAfterEndofProcedureWithInXDays(visit,m,TEST6Elements.Tonsillectomy,Seq(TEST6Elements.Patient_Experienced_Hemorrhage),CalenderUnit.DAY,2,CompareOperator.GREATER_EQUAL,CalenderUnit.DAY,21,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
        || wasInterventionPerformedAfterEndofProcedureWithInXDays(visit,m,TEST6Elements.Tonsillectomy,Seq(TEST6Elements.Reevaluation_For_Post_Tonsillectomy_Hemorrhage),CalenderUnit.DAY,2,CompareOperator.GREATER_EQUAL,CalenderUnit.DAY,21,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
        )
    )
  }


}