
package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP386Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 386
* Measure Title              :- ALS: Amyotrophic Lateral Sclerosis (ALS) Patient Care Preferences
* Measure Description        :- Percentage of patients diagnosed with Amyotrophic Lateral Sclerosis (ALS) who were offered
                                assistance in planning for end of life issues (e.g., advance directives, invasive ventilation, hospice)
                                at least once annually
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp386 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP386"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()


      //Backtracking List
      val patientHistoryList = getPatientHistory(sparkSession, ippRDD
        , QPP386Elements.Hospice_G
        , QPP386Elements.Hospice_Care
        , QPP386Elements.Hospice_Services_Snomedct
        , QPP386Elements.Assistance_With_End_Of_Life
        , QPP386Elements.Discussion_About_Hospice_Services
        , QPP386Elements.Invasive_Ventilation
        , QPP386Elements.Advance_Directives
        , QPP386Elements.Assistance_With_End_Of_Life_Not_Met).collect.toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

      if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

        //Denominator is equal to IPP
        val denominatorRDD = ippRDD
        denominatorRDD.cache()

        val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
        exclusionRDD.cache()

        val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
        intermediateForMet.cache()

        val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
        metRDD.cache()

        val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


        val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
        notMetRDD.cache()

        saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
        patientHistoryBroadcastList.destroy()

      }

  }


    /*-------------------------------------------------------------------------------------------------------------------------
All patients with a diagnosis of Amyotrophic Lateral Sclerosis (ALS)
----------------------------------------------------------------------------------------------------------------------------*/


    def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

      val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

      initialRDD.filter(visit =>
        isDiagnosisOnEncounter(visit, m, QPP386Elements.Amyotrophic_Lateral_Sclerosis)
          && isVisitTypeIn(visit, m
          , QPP386Elements.Office_Visit
          , QPP386Elements.Nursing_Facility_Visit
          , QPP386Elements.Care_Services_In_Long_Term_Residential_Facility
          , QPP386Elements.Psychotherapy_Services
          , QPP386Elements.Annual_Nursing_Facility_Assessment
          , QPP386Elements.Home_Health_Care_Services)
          && !isTeleHealthModifier(visit, m
          , QPP386Elements.Evaluation_And_Management__Telehealth_Modifier
          , QPP386Elements.Psychotherapy_Services_Telehealth_Modifier
          , QPP386Elements.Nursing_Facility_Visit_Telehealth_Modifier
          , QPP386Elements.Office_Visit_Telehealth_Modifier
          , QPP386Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
          , QPP386Elements.Home_Health_Care_Services_Telehealth_Modifier)
          && isPOSEncounterNotPerformed(visit, m, QPP386Elements.Pos_02)
      )
    }



    /*-------------------------------------------------------------------------------------------------------------------------
Patient in hospice at any time during the measurement period
----------------------------------------------------------------------------------------------------------------------------*/

    def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

      val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

      denominatorRDD.filter(visit =>
        isInterventionPerformed(visit, m, QPP386Elements.Hospice_G, patientHistoryBroadcastList)
          || wasInterventionPerformedInHistory(visit, m, QPP386Elements.Hospice_Care, patientHistoryBroadcastList)
          || wasInterventionPerformedInHistory(visit, m, QPP386Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
      )
    }


    /*-------------------------------------------------------------------------------------------------------------------------
Patients who were offered assistance in planning for end of life issues (e.g., advance directives, invasive ventilation,
or hospice) at least once annually
----------------------------------------------------------------------------------------------------------------------------*/

    def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

      val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

      intermediateForMet.filter(visit =>
        (isInterventionPerformed(visit, m, QPP386Elements.Assistance_With_End_Of_Life, patientHistoryBroadcastList)
          || isCommunicationFromProvidertoProvider(visit, m, QPP386Elements.Discussion_About_Hospice_Services, patientHistoryBroadcastList)
          || isCommunicationFromProvidertoProvider(visit, m, QPP386Elements.Invasive_Ventilation, patientHistoryBroadcastList)
          || isCommunicationFromProvidertoProvider(visit, m, QPP386Elements.Advance_Directives, patientHistoryBroadcastList)
          )
          && !isInterventionPerformed(visit, m, QPP386Elements.Assistance_With_End_Of_Life_Not_Met, patientHistoryBroadcastList)
      )
    }
}

