package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AAO32Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO32_4
* Measure Title               :- Standard BPPV Management
* Measure Description         :- Percentage of BPPV patients who received vestibular testing, imaging, and antihistamine or benzodiazepine medications
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Lower Score indicates better quality
* Reporting Criteria          :- 4
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SHREYA_ASHTEKAR_FIGMD_COM
* Initial GIT Version/Tag(CRA):- 1.8
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object AAO32_4 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO32_4"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      AAO32Elements.Benign_Paroxysmal_Positional_Vertigo,
      AAO32Elements.Benzodiazepines,
      AAO32Elements.Vestibular_Testing,
      AAO32Elements.Antihistamines,
      AAO32Elements.Ct_Or_Mri_Scan,
      AAO32Elements.Cta_Or_Mra

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients diagnosed with posterior canal BPPV
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
        isVisitTypeIn(visit,m,AAO32Elements.Office_Visit,AAO32Elements.Office_Or_Other_Outpatient_Visit,AAO32Elements.Office_Consultation)
         &&
         wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients whose diagnosis of BPPV was made after vestibular testing, imaging, or antihistamine or benzo prescribed are not included in the eligible population for the denominator.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        wasDiagnosedAfterMedicationAdministered(visit,m,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo,patientHistoryBroadcastList,AAO32Elements.Benzodiazepines)
        ||
        wasDiagnosedAfterInterventionPerformed(visit,m,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo,patientHistoryBroadcastList,AAO32Elements.Vestibular_Testing)
        ||
        wasDiagnosedAfterMedicationAdministered(visit,m,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo,patientHistoryBroadcastList,AAO32Elements.Antihistamines)
        ||
        wasDiagnosedAfterInterventionPerformed(visit,m,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo,patientHistoryBroadcastList,AAO32Elements.Ct_Or_Mri_Scan)
        ||
        wasDiagnosedAfterInterventionPerformed(visit,m,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo,patientHistoryBroadcastList,AAO32Elements.Cta_Or_Mra)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
D.Total patient performance on the 3 above components
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      wasInterventionOrderAfterDiagnosis(visit,m,AAO32Elements.Vestibular_Testing,patientHistoryBroadcastList,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo)
        ||
        (
          wasInterventionOrderAfterDiagnosis(visit,m,AAO32Elements.Ct_Or_Mri_Scan,patientHistoryBroadcastList,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo)
          ||
          wasInterventionOrderAfterDiagnosis(visit,m,AAO32Elements.Cta_Or_Mra,patientHistoryBroadcastList,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo)
        )
        ||
        (
           wasMedicationOrderAfterDiagnosis(visit,m,AAO32Elements.Benzodiazepines,patientHistoryBroadcastList,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo)
           ||
           wasMedicationOrderAfterDiagnosis(visit,m,AAO32Elements.Antihistamines,patientHistoryBroadcastList,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo)
        )
    )
  }


}