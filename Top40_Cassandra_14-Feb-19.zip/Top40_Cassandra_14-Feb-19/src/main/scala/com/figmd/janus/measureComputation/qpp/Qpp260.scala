package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP260Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 260
* Measure Title              :- Rate of Carotid Endarterectomy (CEA) for Asymptomatic Patients, without Major Complications (Discharged to Home by Post-Operative Day #2)
* Measure Description        :- Percent of asymptomatic patients undergoing CEA who are discharged to home no later than post-operative day #2.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp260 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp260"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP


    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP260Elements.Carotid_Territory_Tia_Stroke, QPP260Elements.Ipsilateral_Carotid_Territory_Tia_Or_Stroke, QPP260Elements.Vertebrobasilar_Tia, QPP260Elements.Vertebrobasilar_Tia_Stroke, QPP260Elements.Contralateral_Carotid_Territory_Tia_Or_Stroke

    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, metRDD)
      intermediateA.cache()


      // Filter Exceptions
      val exceptionRDD = getMet(intermediateA, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()
      //
      // Filter Exceptions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /* All carotid endarterectomy procedures. */
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        isProcedurePerformedDuringEncounter(visit, m, QPP260Elements.Carotid_Endarterectomy__Cea_)
    )
  }


  // Numerator criteria
  /* Symptomatic carotid stenosis: Ipsilateral carotid territory TIA or stroke less than 120 days prior to procedure.
   OR   Other carotid stenosis: Ipsilateral TIA or stroke 120 days or greater prior to procedure or any prior contralateral carotid territory or vertebrobasilar TIA or stroke.*/

  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (isDiagnosedOnEncounter(visit, m, QPP260Elements.Symptomatic_Carotid_Stenosis)
        || wasDiagnosedBeforeProcedureInXDays(visit, m, QPP260Elements.Carotid_Endarterectomy__Cea_, 120, patientHistoryBroadcastList, QPP260Elements.Carotid_Territory_Tia_Stroke, QPP260Elements.Ipsilateral_Carotid_Territory_Tia_Or_Stroke)
        )
        ||
        (isDiagnosedOnEncounter(visit, m, QPP260Elements.Other_Carotid_Stenosis)
          || wasDiagnosedBeforeProcedureInXDays(visit, m, QPP260Elements.Carotid_Endarterectomy__Cea_, 120, patientHistoryBroadcastList, QPP260Elements.Carotid_Territory_Tia_Stroke, QPP260Elements.Ipsilateral_Carotid_Territory_Tia_Or_Stroke)
          )
        ||
        (isDiagnosedOnEncounter(visit, m, QPP260Elements.Symptomatic_Carotid_Stenosis)
          || wasDiagnosedBeforeProcedureInXDays(visit, m, QPP260Elements.Carotid_Endarterectomy__Cea_, 120, patientHistoryBroadcastList, QPP260Elements.Vertebrobasilar_Tia, QPP260Elements.Vertebrobasilar_Tia_Stroke, QPP260Elements.Contralateral_Carotid_Territory_Tia_Or_Stroke)
          )
    )

  }


  // Numerator criteria
  /* 	Patients that are asymptomatic neurologically who were discharged alive, to home no later than post-operative day #2 following CEA. */
  def getMet(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isVisitTypeIn(visit, m, QPP260Elements.Discharge_To_Home)
        ||
        (isEncounterPerformedAfterEndOfProcedureInXdays(visit, m, QPP260Elements.Carotid_Endarterectomy__Cea_, QPP260Elements.Discharge_To_Home, 2, patientHistoryBroadcastList)
          || isEncounterPerformedAfterEndOfProcedureInXdays(visit, m, QPP260Elements.Carotid_Endarterectomy__Cea_, QPP260Elements.Transfer_To_Nursing_Facility, 2, patientHistoryBroadcastList)
          )
          && !isVisitTypeIn(visit, m, QPP260Elements.Discharge_Home_Not_Met)

    )

  }


}
