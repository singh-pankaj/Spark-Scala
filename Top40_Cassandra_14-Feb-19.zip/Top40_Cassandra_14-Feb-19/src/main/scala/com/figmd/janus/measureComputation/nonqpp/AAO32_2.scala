package com.figmd.janus.measureComputation.nonqpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AAO32Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO32_2
* Measure Title               :- Standard BPPV Management
* Measure Description         :- Percentage of BPPV patients who received vestibular testing, imaging, and antihistamine or benzodiazepine medications
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Lower Score indicates better quality
* Reporting Criteria          :- 4
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SHREYA_ASHTEKAR_FIGMD_COM
* Initial GIT Version/Tag(CRA):- 1.8
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object AAO32_2 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "AAO32_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      AAO32Elements.Benign_Paroxysmal_Positional_Vertigo,
      AAO32Elements.Benzodiazepines,
      AAO32Elements.Vestibular_Testing,
      AAO32Elements.Antihistamines,
      AAO32Elements.Ct_Or_Mri_Scan,
      AAO32Elements.Cta_Or_Mra,
      AAO32Elements.Intervention_Exclusion_Bppv

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients diagnosed with posterior canal BPPV
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isVisitTypeIn(visit,m,AAO32Elements.Office_Visit,AAO32Elements.Office_Or_Other_Outpatient_Visit,AAO32Elements.Office_Consultation)
        &&
        wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
 	Patients whose diagnosis of BPPV was made after vestibular testing, imaging, or antihistamine or benzo prescribed are not included in the eligible population for the denominator.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      wasDiagnosedAfterMedicationAdministered(visit,m,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo,patientHistoryBroadcastList,AAO32Elements.Benzodiazepines)
        ||
        wasDiagnosedAfterInterventionPerformed(visit,m,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo,patientHistoryBroadcastList,AAO32Elements.Vestibular_Testing)
        ||
        wasDiagnosedAfterMedicationAdministered(visit,m,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo,patientHistoryBroadcastList,AAO32Elements.Antihistamines)
        ||
        wasDiagnosedAfterInterventionPerformed(visit,m,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo,patientHistoryBroadcastList,AAO32Elements.Ct_Or_Mri_Scan)
        ||
        wasDiagnosedAfterInterventionPerformed(visit,m,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo,patientHistoryBroadcastList,AAO32Elements.Cta_Or_Mra)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
B Patients with BPPV referred, recommended, or ordered a CTA, CT, MRA, or MRI by the encounter provider. * A lower score is indicative of better quality.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
        wasInterventionOrderAfterDiagnosis(visit,m,AAO32Elements.Ct_Or_Mri_Scan,patientHistoryBroadcastList,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo)
        ||
        wasInterventionOrderAfterDiagnosis(visit,m,AAO32Elements.Cta_Or_Mra,patientHistoryBroadcastList,AAO32Elements.Benign_Paroxysmal_Positional_Vertigo)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
For numerator component B patients may be excluded if they have:
• Atypical BPPV (anterior canal, relapsing BPPV (To be captured via search term
processing this exclusion should be written as “Patient has relapsing BPPV.”), BPPV
associated with other neurological conditions, or severe multi-canal BPPV)
• Focal deficit or unilateral hearing loss
• Vision changes
• Trauma history
• Recent surgery
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      wasDiagnosedInHistory(visit,m,AAO32Elements.Intervention_Exclusion_Bppv,patientHistoryBroadcastList)
    )
  }
}