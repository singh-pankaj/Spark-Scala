package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty,TEST22Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- TEST22
* Measure Title               :- Allergic Rhinitis: Sinonasal Imaging
* Measure Description         :- Percentage of patients with allergic rhinitis who do not receive sinonasal imaging for
                                 allergic rhinitis.
* Calculation Implementation  :- Visit-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SANKET.DHAPTE
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object TEST22 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "TEST22"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,TEST22Elements.Allergic_Rhinitis_Grouping
      ,TEST22Elements.Sinonasal_Imaging
      ,TEST22Elements.Conditions_Indicating_Appropriate_Sinonasal_Imaging
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients ages 2 years and up with allergic rhinitis seen for an ambulatory visit with a diagnosis of allergic rhinitis.
  -----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
         isAgeAbove(visit,m,true,2)
      && isVisitTypeIn(visit,m,TEST22Elements.Ambulatory_Visit)
      && wasDiagnosedBeforeOrEqualEncounter(visit,m,TEST22Elements.Allergic_Rhinitis_Grouping,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients with rhinosinusitis, nasal polyposis, suspected nasal neoplasm, or other nasal conditions requiring imaging.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      wasProcedurePerformedwithResult(visit,m,TEST22Elements.Sinonasal_Imaging,TEST22Elements.Conditions_Indicating_Appropriate_Sinonasal_Imaging,patientHistoryBroadcastList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients who do not have sinonasal imaging ordered or performed during a visit for allergic rhinitis.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      !isProcedurePerformed(visit,m,TEST22Elements.Sinonasal_Imaging,patientHistoryBroadcastList)

    )
  }


}