package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements,CompareOperator, MeasureProperty, QOPI93Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- QOPI93
* Measure Title               :- Concurrent Chemoradiation for Patients with a Diagnosis of Stage IIIB NSCLC
* Measure Description         :- Proportion of patients with a diagnosis of stage IIIB non-small cell lung (NSCLC) cancer who received concurrent platinum based doublet chemotherapy and radiation treatment.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KAJAL_JADHAO_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object QOPI93 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "QOPI93"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,QOPI93Elements.NSCLC_Date
      ,QOPI93Elements.Tumor_staging
      ,QOPI93Elements.Clinical_Trial_Participant
      ,QOPI93Elements.ECOG_Result
      ,QOPI93Elements.Karnofsky_Result
      ,QOPI93Elements.Zubrod_result_keywords
      ,QOPI93Elements.Cisplatin
      ,QOPI93Elements.Carboplatin
      ,QOPI93Elements.Chemotherapy_for_NSCLC_Oxaliplatin
      ,QOPI93Elements.Radiation_Therapy
      ,QOPI93Elements.Medical_Reason

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with a Diagnosis of Stage IIIB NSCLC
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit,m,QOPI93Elements.Office_Visit,QOPI93Elements.Patient_Provider_Interaction)
        && wasDiagnosisBeforeorEqualEncounter(visit,m,QOPI93Elements.NSCLC_Date,AdminElements.Encounter_Date,patientHistoryBroadcastList)
        && wasDiagnosisAfterOrConcurentWithDiagnosis(visit,m,QOPI93Elements.NSCLC,patientHistoryBroadcastList,QOPI93Elements.Tumor_staging)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
1)patiets who are clinical trial participant
2)Patients with poor performance status
3)Patients with diagnosis of Superior sulcus cancers
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      wasAssessmentPerformedBeforeOrEqualEncounter(visit,m,QOPI93Elements.Clinical_Trial_Participant,patientHistoryBroadcastList)
        || wasDiagnosisBeforeorEqualEncounter(visit,m,AdminElements.Encounter_Date,QOPI93Elements.Clinical_Trial_Participant,patientHistoryBroadcastList)
        || isAssessmentPerformedDuringEncounter(visit,m,QOPI93Elements.ECOG_Performance_Status_Poor)
        || isAssessmentPerformedWithResultValueDuringEncounter(visit,m,QOPI93Elements.ECOG_Result,3,CompareOperator.EQUAL)
        || isAssessmentPerformedWithResultValueDuringEncounter(visit,m,QOPI93Elements.ECOG_Result,4,CompareOperator.EQUAL)
        || isAssessmentPerformedWithResultValueDuringEncounter(visit,m,QOPI93Elements.Karnofsky_Result,50,CompareOperator.LESS_EQUAL)
        || isAssessmentPerformedWithResultValueDuringEncounter(visit,m,QOPI93Elements.Zubrod_result_keywords,3,CompareOperator.EQUAL)
        || isAssessmentPerformedWithResultValueDuringEncounter(visit,m,QOPI93Elements.Zubrod_result_keywords,4,CompareOperator.EQUAL)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who received Concurrent Chemoradiation
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      ( wasMedicationAdministeredBeforeOrEqualEncounter(visit,m,QOPI93Elements.Cisplatin,patientHistoryBroadcastList)
        || wasMedicationAdministeredBeforeOrEqualEncounter(visit,m,QOPI93Elements.Carboplatin,patientHistoryBroadcastList)
        || wasMedicationAdministeredBeforeOrEqualEncounter(visit,m,QOPI93Elements.Chemotherapy_for_NSCLC_Oxaliplatin,patientHistoryBroadcastList))
        &&(isProcedurePerformedWasConcurrentWith(visit,m,QOPI93Elements.Radiation_Therapy,QOPI93Elements.Cisplatin,patientHistoryBroadcastList)
        ||isProcedurePerformedWasConcurrentWith(visit,m,QOPI93Elements.Radiation_Therapy,QOPI93Elements.Carboplatin,patientHistoryBroadcastList)
        ||isProcedurePerformedWasConcurrentWith(visit,m,QOPI93Elements.Radiation_Therapy,QOPI93Elements.Chemotherapy_for_NSCLC_Oxaliplatin,patientHistoryBroadcastList))

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Documentation for medical reason for not administering concurrent chemoradiation.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
          wasProcedurePerformedBeforeOrEqual(visit,m,QOPI93Elements.Radiation_Therapy,QOPI93Elements.Medical_Reason,patientHistoryBroadcastList)
        ||wasMedicationAdministeredBeforeOrEqual(visit,m,QOPI93Elements.Chemotherapy_for_NSCLC_Oxaliplatin,QOPI93Elements.Medical_Reason,patientHistoryBroadcastList)
        ||wasMedicationAdministeredBeforeOrEqual(visit,m,QOPI93Elements.Carboplatin,QOPI93Elements.Medical_Reason,patientHistoryBroadcastList)
        ||wasMedicationAdministeredBeforeOrEqual(visit,m,QOPI93Elements.Cisplatin,QOPI93Elements.Medical_Reason,patientHistoryBroadcastList)
    )
  }
}