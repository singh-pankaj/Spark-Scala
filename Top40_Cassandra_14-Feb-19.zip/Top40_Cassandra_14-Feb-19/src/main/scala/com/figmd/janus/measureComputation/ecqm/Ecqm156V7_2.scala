package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm156V7
* Measure Title              :- Use of High-Risk Medications in the Elderly
* Measure Description        :- Percentage of patients 65 years of age and older who were ordered high-risk medications.
*                               Two rates are reported.
*                               a. Percentage of patients who were ordered at least one high-risk medication.
*                               b. Percentage of patients who were ordered at least two of the same high-risk medications.
*                               This class takes care of the measuring rate a. - at least one high-risk medication.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 2
* Measure Stratification     :- 1
* Measure Developer          :- Sumant Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm156V7_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm156V7_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    var patientHistoryRDD = getPatientHistory(sparkSession,initialRDD
      , ECQM156V7Elements.Encounter_Inpatient
      , ECQM156V7Elements.Discharged_To_Home_For_Hospice_Care
      , ECQM156V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care
      , ECQM156V7Elements.Hospice_Care_Ambulatory
      , ECQM156V7Elements.Hydrochlorothiazide___Methyldopa
      , ECQM156V7Elements.Chlorpheniramine___Ibuprofen___Pseudoephedrine
      , ECQM156V7Elements.Carbetapentane___Chlorpheniramine___Ephedrine___Phenylephrine
      , ECQM156V7Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan
      , ECQM156V7Elements.Dexchlorpheniramine___Pseudoephedrine
      , ECQM156V7Elements.Dexbrompheniramine___Dextromethorphan___Phenylephrine
      , ECQM156V7Elements.Amitriptyline___Perphenazine
      , ECQM156V7Elements.Dexbrompheniramine_Maleate___Pseudoephedrine_Hydrochloride
      , ECQM156V7Elements.Dexbrompheniramine___Pseudoephedrine
      , ECQM156V7Elements.Chlophedianol___Dexbrompheniramine___Phenylephrine
      , ECQM156V7Elements.Chlophedianol___Dexbrompheniramine___Pseudoephedrine
      , ECQM156V7Elements.Chlophedianol___Dexchlorpheniramine___Pseudoephedrine
      , ECQM156V7Elements.Brompheniramine___Codeine___Pseudoephedrine
      , ECQM156V7Elements.Dextromethorphan___Doxylamine
      , ECQM156V7Elements.Chlorpheniramine___Phenylephrine___Phenyltoloxamine
      , ECQM156V7Elements.Acetaminophen___Dextromethorphan___Diphenhydramine___Phenylephrine
      , ECQM156V7Elements.Carbetapentane___Chlorpheniramine___Phenylephrine
      , ECQM156V7Elements.Chlophedianol___Chlorpheniramine___Phenylephrine
      , ECQM156V7Elements.Meprobamate
      , ECQM156V7Elements.Trimipramine
      , ECQM156V7Elements.Phenobarbital
      , ECQM156V7Elements.Dipyridamole
      , ECQM156V7Elements.Meperidine
      , ECQM156V7Elements.Chlorpropamide
      , ECQM156V7Elements.Carbinoxamine
      , ECQM156V7Elements.Clemastine
      , ECQM156V7Elements.Disopyramide
      , ECQM156V7Elements.Estropipate
      , ECQM156V7Elements.Methyldopa
      , ECQM156V7Elements.Trihexyphenidyl
      , ECQM156V7Elements.Clomipramine
      , ECQM156V7Elements.Guanfacine
      , ECQM156V7Elements.Megestrol
      , ECQM156V7Elements.Chlorpheniramine
      , ECQM156V7Elements.Nifedipine
      , ECQM156V7Elements.Conjugated_Estrogens
      , ECQM156V7Elements.Metaxalone
      , ECQM156V7Elements.Imipramine
      , ECQM156V7Elements.Benztropine
      , ECQM156V7Elements.Chlorzoxazone
      , ECQM156V7Elements.Ketorolac_Tromethamine
      , ECQM156V7Elements.Estradiol
      , ECQM156V7Elements.Indomethacin
      , ECQM156V7Elements.Glyburide
      , ECQM156V7Elements.Carisoprodol
      , ECQM156V7Elements.Methocarbamol
      , ECQM156V7Elements.Diphenhydramine_Hydrochloride
      , ECQM156V7Elements.Cyclobenzaprine_Hydrochloride
      , ECQM156V7Elements.Amitriptyline_Hydrochloride
      , ECQM156V7Elements.Hydroxyzine
      , ECQM156V7Elements.Dexbrompheniramine
      , ECQM156V7Elements.Butabarbital
      , ECQM156V7Elements.Triprolidine
      , ECQM156V7Elements.Esterified_Estrogens
      , ECQM156V7Elements.Isoxsuprine
      , ECQM156V7Elements.Brompheniramine
      , ECQM156V7Elements.Amitriptyline_____Chlordiazepoxide
      , ECQM156V7Elements.Acetaminophen___Dextromethorphan___Diphenhydramine___Phenylephrine
      , ECQM156V7Elements.Codeine___Phenylephrine___Promethazine
      , ECQM156V7Elements.Diphenhydramine___Ibuprofen
      , ECQM156V7Elements.Chlorpheniramine___Hydrocodone___Pseudoephedrine
      , ECQM156V7Elements.Dexchlorpheniramine___Dextromethorphan___Pseudoephedrine
      , ECQM156V7Elements.Chlorpheniramine___Codeine
      , ECQM156V7Elements.Diphenhydramine___Phenylephrine
      , ECQM156V7Elements.Chlorpheniramine___Phenylephrine___Pyrilamine
      , ECQM156V7Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan___Phenylephrine
      , ECQM156V7Elements.Chlorpheniramine___Dextromethorphan___Phenylephrine
      , ECQM156V7Elements.Chlorpheniramine___Pseudoephedrine
      , ECQM156V7Elements.Acetaminophen___Chlorpheniramine___Pseudoephedrine
      , ECQM156V7Elements.Acetaminophen___Butalbital
      , ECQM156V7Elements.Acetaminophen___Diphenhydramine___Phenylephrine
      , ECQM156V7Elements.Esterified_Estrogens___Methyltestosterone
      , ECQM156V7Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan___Pseudoephedrine
      , ECQM156V7Elements.Estradiol___Norethindrone
      , ECQM156V7Elements.Conjugated_Estrogens___Medroxyprogesterone
      , ECQM156V7Elements.Brompheniramine___Dextromethorphan___Phenylephrine
      , ECQM156V7Elements.Acetaminophen___Butalbital___Caffeine___Codeine
      , ECQM156V7Elements.Brompheniramine___Phenylephrine
      , ECQM156V7Elements.Acetaminophen___Chlorpheniramine___Phenylephrine
      , ECQM156V7Elements.Chlorpheniramine___Hydrocodone
      , ECQM156V7Elements.Brompheniramine___Pseudoephedrine
      , ECQM156V7Elements.Chlorpheniramine___Dextromethorphan___Pseudoephedrine
      , ECQM156V7Elements.Acetaminophen___Dextromethorphan___Doxylamine
      , ECQM156V7Elements.Brompheniramine___Dextromethorphan___Pseudoephedrine
      , ECQM156V7Elements.Chlorpheniramine___Phenylephrine
      , ECQM156V7Elements.Acetaminophen___Diphenhydramine
      , ECQM156V7Elements.Desiccated_Thyroid
      , ECQM156V7Elements.Atropine___Hyoscyamine___Phenobarbital___Scopolamine
      , ECQM156V7Elements.Glyburide___Metformin
      , ECQM156V7Elements.Acetaminophen___Butalbital___Caffeine
      , ECQM156V7Elements.Promethazine_Hydrochloride
      , ECQM156V7Elements.Acetaminophen___Brompheniramine
      , ECQM156V7Elements.Dextromethorphan___Diphenhydramine___Phenylephrine
      , ECQM156V7Elements.Dienogest___Estradiol_Multiphasic
      , ECQM156V7Elements.Brompheniramine___Codeine___Phenylephrine
      , ECQM156V7Elements.Drospirenone___Estradiol
      , ECQM156V7Elements.Meclizine
      , ECQM156V7Elements.Nortriptyline
      , ECQM156V7Elements.Paroxetine
      , ECQM156V7Elements.Protriptyline
      , ECQM156V7Elements.Hyoscyamine___Methenamine___Mblue___Sodium_Biphosphate
      , ECQM156V7Elements.Hyoscyamine
      , ECQM156V7Elements.Hyoscyamine___Methenamine___Mblue___Phenyl_Salicyl___Sodium_Biphosphate
      , ECQM156V7Elements.Hyoscyamine___Methenamine___Mblue___Phenyl_Salicyl
      , ECQM156V7Elements.Dimenhydrinate
      , ECQM156V7Elements.Dicyclomine
      , ECQM156V7Elements.Cyproheptadine
      , ECQM156V7Elements.Desipramine
      , ECQM156V7Elements.Amoxapine
      , ECQM156V7Elements.Atropine___Diphenoxylate
      , ECQM156V7Elements.Nonbenzodiazepine_Hypnotics
      , ECQM156V7Elements.Nonbenzodiazepine_Hypnotics_Date
      , ECQM156V7Elements.Anti_Infectives__Other
      , ECQM156V7Elements.Anti_Infectives__other_Date
    )
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val nonbenzodiazepineList = List[(String, String)]((ECQM156V7Elements.Nonbenzodiazepine_Hypnotics_Date,
      ECQM156V7Elements.Nonbenzodiazepine_Hypnotics_Stop_Date))
    val nonbenzodiazepineBroadcastList = sparkSession.sparkContext.broadcast(
      cumulative(patientHistoryRDD, m, nonbenzodiazepineList, CalenderUnit.DAY,
        CalenderUnit.DAY, 0, "DURING"))
    val antiInfectivesList = List[(String, String)]((ECQM156V7Elements.Anti_Infectives__other_Date,
      ECQM156V7Elements.Anti_Infectives_Other_Stop_Date))
    val antiInfectivesBroadcastList = sparkSession.sparkContext.broadcast(
      cumulative(patientHistoryRDD, m, antiInfectivesList, CalenderUnit.DAY,
        CalenderUnit.DAY, 0, "DURING"))


    val ippRDD = getIpp(initialRDD,patientHistoryList: Broadcast[List[CassandraRow]])
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exceptions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      val intermediateRDD = ippRDD.subtract(exclusionRDD)
      intermediateRDD.cache()

      // Filter Met
      val metRDD = getMet(intermediateRDD, patientHistoryList, nonbenzodiazepineBroadcastList, antiInfectivesBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
      nonbenzodiazepineBroadcastList.destroy()
      antiInfectivesBroadcastList.destroy()

    }
  }


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
      isPatientElderly(visit, m)
        &&
        isVisitTypeIn(visit, m
          , ECQM156V7Elements.Office_Visit
          , ECQM156V7Elements.Ophthalmologic_Outpatient_Visit
          , ECQM156V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
          , ECQM156V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
          , ECQM156V7Elements.Annual_Wellness_Visit
          , ECQM156V7Elements.Home_Healthcare_Services
          , ECQM156V7Elements.Discharge_Services___Nursing_Facility
          , ECQM156V7Elements.Nursing_Facility_Visit
          , ECQM156V7Elements.Care_Services_In_Long_Term_Residential_Facility
        )
    )
  }


  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isEncounterPerformedWithDischargeStatus(visit, m, ECQM156V7Elements.Encounter_Inpatient, ECQM156V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        ||
        isEncounterPerformedWithDischargeStatus(visit, m, ECQM156V7Elements.Encounter_Inpatient, ECQM156V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        ||
        isInterventionOrder(visit, m, ECQM156V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        ||
        isInterventionOrdered(visit, m, ECQM156V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
    )
  }

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]],
             nonbenzodiazepineBroadcastList : Broadcast[List[(String,String, Double)]],
             antiInfectivesBroadcastList : Broadcast[List[(String,String, Double)]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>

      wasMedicationOrderedAfterMedicationWithinXPeriod(visit, m,
        Seq(ECQM156V7Elements.Hydrochlorothiazide___Methyldopa
          , ECQM156V7Elements.Chlorpheniramine___Ibuprofen___Pseudoephedrine
          , ECQM156V7Elements.Carbetapentane___Chlorpheniramine___Ephedrine___Phenylephrine
          , ECQM156V7Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan
          , ECQM156V7Elements.Dexchlorpheniramine___Pseudoephedrine
          , ECQM156V7Elements.Dexbrompheniramine___Dextromethorphan___Phenylephrine
          , ECQM156V7Elements.Amitriptyline___Perphenazine
          , ECQM156V7Elements.Dexbrompheniramine_Maleate___Pseudoephedrine_Hydrochloride
          , ECQM156V7Elements.Dexbrompheniramine___Pseudoephedrine
          , ECQM156V7Elements.Chlophedianol___Dexbrompheniramine___Phenylephrine
          , ECQM156V7Elements.Chlophedianol___Dexbrompheniramine___Pseudoephedrine
          , ECQM156V7Elements.Chlophedianol___Dexchlorpheniramine___Pseudoephedrine
          , ECQM156V7Elements.Brompheniramine___Codeine___Pseudoephedrine
          , ECQM156V7Elements.Dextromethorphan___Doxylamine
          , ECQM156V7Elements.Chlorpheniramine___Phenylephrine___Phenyltoloxamine
          , ECQM156V7Elements.Acetaminophen___Dextromethorphan___Diphenhydramine___Phenylephrine
          , ECQM156V7Elements.Carbetapentane___Chlorpheniramine___Phenylephrine
          , ECQM156V7Elements.Chlophedianol___Chlorpheniramine___Phenylephrine
          , ECQM156V7Elements.Meprobamate
          , ECQM156V7Elements.Trimipramine
          , ECQM156V7Elements.Phenobarbital
          , ECQM156V7Elements.Dipyridamole
          , ECQM156V7Elements.Meperidine
          , ECQM156V7Elements.Chlorpropamide
          , ECQM156V7Elements.Carbinoxamine
          , ECQM156V7Elements.Clemastine
          , ECQM156V7Elements.Disopyramide
          , ECQM156V7Elements.Estropipate
          , ECQM156V7Elements.Methyldopa
          , ECQM156V7Elements.Trihexyphenidyl
          , ECQM156V7Elements.Clomipramine
          , ECQM156V7Elements.Guanfacine
          , ECQM156V7Elements.Megestrol
          , ECQM156V7Elements.Chlorpheniramine
          , ECQM156V7Elements.Nifedipine
          , ECQM156V7Elements.Conjugated_Estrogens
          , ECQM156V7Elements.Metaxalone
          , ECQM156V7Elements.Imipramine
          , ECQM156V7Elements.Benztropine
          , ECQM156V7Elements.Chlorzoxazone
          , ECQM156V7Elements.Ketorolac_Tromethamine
          , ECQM156V7Elements.Estradiol
          , ECQM156V7Elements.Indomethacin
          , ECQM156V7Elements.Glyburide
          , ECQM156V7Elements.Carisoprodol
          , ECQM156V7Elements.Methocarbamol
          , ECQM156V7Elements.Diphenhydramine_Hydrochloride
          , ECQM156V7Elements.Cyclobenzaprine_Hydrochloride
          , ECQM156V7Elements.Amitriptyline_Hydrochloride
          , ECQM156V7Elements.Hydroxyzine
          , ECQM156V7Elements.Dexbrompheniramine
          , ECQM156V7Elements.Butabarbital
          , ECQM156V7Elements.Triprolidine
          , ECQM156V7Elements.Esterified_Estrogens
          , ECQM156V7Elements.Isoxsuprine
          , ECQM156V7Elements.Brompheniramine
          , ECQM156V7Elements.Amitriptyline_____Chlordiazepoxide
          , ECQM156V7Elements.Acetaminophen___Dextromethorphan___Diphenhydramine___Phenylephrine
          , ECQM156V7Elements.Codeine___Phenylephrine___Promethazine
          , ECQM156V7Elements.Diphenhydramine___Ibuprofen
          , ECQM156V7Elements.Chlorpheniramine___Hydrocodone___Pseudoephedrine
          , ECQM156V7Elements.Dexchlorpheniramine___Dextromethorphan___Pseudoephedrine
          , ECQM156V7Elements.Chlorpheniramine___Codeine
          , ECQM156V7Elements.Diphenhydramine___Phenylephrine
          , ECQM156V7Elements.Chlorpheniramine___Phenylephrine___Pyrilamine
          , ECQM156V7Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan___Phenylephrine
          , ECQM156V7Elements.Chlorpheniramine___Dextromethorphan___Phenylephrine
          , ECQM156V7Elements.Chlorpheniramine___Pseudoephedrine
          , ECQM156V7Elements.Acetaminophen___Chlorpheniramine___Pseudoephedrine
          , ECQM156V7Elements.Acetaminophen___Butalbital
          , ECQM156V7Elements.Acetaminophen___Diphenhydramine___Phenylephrine
          , ECQM156V7Elements.Esterified_Estrogens___Methyltestosterone
          , ECQM156V7Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan___Pseudoephedrine
          , ECQM156V7Elements.Estradiol___Norethindrone
          , ECQM156V7Elements.Conjugated_Estrogens___Medroxyprogesterone
          , ECQM156V7Elements.Brompheniramine___Dextromethorphan___Phenylephrine
          , ECQM156V7Elements.Acetaminophen___Butalbital___Caffeine___Codeine
          , ECQM156V7Elements.Brompheniramine___Phenylephrine
          , ECQM156V7Elements.Acetaminophen___Chlorpheniramine___Phenylephrine
          , ECQM156V7Elements.Chlorpheniramine___Hydrocodone
          , ECQM156V7Elements.Brompheniramine___Pseudoephedrine
          , ECQM156V7Elements.Chlorpheniramine___Dextromethorphan___Pseudoephedrine
          , ECQM156V7Elements.Acetaminophen___Dextromethorphan___Doxylamine
          , ECQM156V7Elements.Brompheniramine___Dextromethorphan___Pseudoephedrine
          , ECQM156V7Elements.Chlorpheniramine___Phenylephrine
          , ECQM156V7Elements.Acetaminophen___Diphenhydramine
          , ECQM156V7Elements.Desiccated_Thyroid
          , ECQM156V7Elements.Atropine___Hyoscyamine___Phenobarbital___Scopolamine
          , ECQM156V7Elements.Glyburide___Metformin
          , ECQM156V7Elements.Acetaminophen___Butalbital___Caffeine
          , ECQM156V7Elements.Promethazine_Hydrochloride
          , ECQM156V7Elements.Acetaminophen___Brompheniramine
          , ECQM156V7Elements.Dextromethorphan___Diphenhydramine___Phenylephrine
          , ECQM156V7Elements.Dienogest___Estradiol_Multiphasic
          , ECQM156V7Elements.Brompheniramine___Codeine___Phenylephrine
          , ECQM156V7Elements.Drospirenone___Estradiol
          , ECQM156V7Elements.Meclizine
          , ECQM156V7Elements.Paroxetine
          , ECQM156V7Elements.Protriptyline
          , ECQM156V7Elements.Hyoscyamine___Methenamine___Mblue___Sodium_Biphosphate
          , ECQM156V7Elements.Hyoscyamine
          , ECQM156V7Elements.Hyoscyamine___Methenamine___Mblue___Phenyl_Salicyl___Sodium_Biphosphate
          , ECQM156V7Elements.Hyoscyamine___Methenamine___Mblue___Phenyl_Salicyl
          , ECQM156V7Elements.Dimenhydrinate
          , ECQM156V7Elements.Dicyclomine
          , ECQM156V7Elements.Cyproheptadine
          , ECQM156V7Elements.Desipramine
          , ECQM156V7Elements.Amoxapine
          , ECQM156V7Elements.Atropine___Diphenoxylate)
        , CalenderUnit.DAY, 1, patientHistoryList)
        ||
        (
          isMedicationOrdered(visit, m, patientHistoryList, ECQM156V7Elements.Phenobarbital)
            &&
            wasMedicationOrderedAfterMedicationWithinXPeriod(visit, m, ECQM156V7Elements.Nortriptyline, CalenderUnit.DAY, 1, patientHistoryList, ECQM156V7Elements.Nortriptyline)
          )
        ||
        (
          getCommulativeResult(visit, m, ECQM156V7Elements.Nonbenzodiazepine_Hypnotics, 90, CompareOperator.GREATER_EQUAL, nonbenzodiazepineBroadcastList)
            &&
            wasMedicationOrderedAfterMedicationWithinXPeriod(visit, m, ECQM156V7Elements.Nonbenzodiazepine_Hypnotics, CalenderUnit.DAY, 1, patientHistoryList, ECQM156V7Elements.Nonbenzodiazepine_Hypnotics)
          )
        ||
        (
          getCommulativeResult(visit, m, ECQM156V7Elements.Anti_Infectives__Other, 90, CompareOperator.GREATER_EQUAL, antiInfectivesBroadcastList)
            &&
            wasMedicationOrderedAfterMedicationWithinXPeriod(visit, m, ECQM156V7Elements.Anti_Infectives__Other, CalenderUnit.DAY, 1, patientHistoryList, ECQM156V7Elements.Anti_Infectives__Other)
          )

    )
  }


}

