package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty}
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 75v7
* Measure Title              :- Children Who Have Dental Decay or Cavities
* Measure Description        :- Percentage of children, age 0-20 years, who have had tooth decay or cavities during the measurement period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm75V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm75V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patient_history_list = getPatientHistory(sparkSession, initialRDD
      , ECQM75V7Elements.Dental_Caries
      , ECQM75V7Elements.Encounter_Inpatient
      , ECQM75V7Elements.Hospice_Care_Ambulatory
      , ECQM75V7Elements.Discharged_To_Home_For_Hospice_Care
      , ECQM75V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care
    )

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession,initialRDD ,ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      /*val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    notEligibleRDD.cache()*/

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit=>
    isAgeAbove(visit, m, true,0)
    &&
    isAgeBelow(visit, m, false,20)
    &&
    isVisitTypeIn(visit, m
      , ECQM75V7Elements.Preventive_Care__Established_Office_Visit__0_To_17
      , ECQM75V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
      , ECQM75V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
      , ECQM75V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
      , ECQM75V7Elements.Office_Visit
      , ECQM75V7Elements.Clinical_Oral_Evaluation
    )
    )
  }

  // Denominator Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      isEncounterPerformed(visit, m, ECQM75V7Elements.Encounter_Inpatient, patientHistoryList) && isDateEqual(visit, m,  ECQM75V7Elements.Encounter_Inpatient_Date,  ECQM75V7Elements.Discharged_To_Home_For_Hospice_Care_Date)
      ||
      isEncounterPerformed(visit, m, ECQM75V7Elements.Encounter_Inpatient, patientHistoryList) && isDateEqual(visit, m,  ECQM75V7Elements.Encounter_Inpatient_Date,  ECQM75V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care_Date)
      ||
      wasInterventionPerformedOrOrderedInHistory(visit, m, ECQM75V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
    )
  }


  // Numerator criteria
  def getMet(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    rdd.filter(visit=>
      wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM75V7Elements.Dental_Caries ,patientHistoryList)
    )
  }
}

