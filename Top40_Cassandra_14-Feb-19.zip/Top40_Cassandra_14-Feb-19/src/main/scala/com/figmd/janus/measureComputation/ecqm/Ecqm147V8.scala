package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ECQM147V8Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm147
* Measure Title              :- Preventive Care and Screening: Influenza Immunization
* Measure Description        :- Percentage of patients aged 6 months and older seen for a visit between October 1 and March 31
				who received an influenza immunization OR who reported previous receipt of an influenza immunization
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Sumant Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm147V8 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm147V8"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , ECQM147V8Elements.Office_Visit
      , ECQM147V8Elements.Outpatient_Consultation
      , ECQM147V8Elements.Care_Services_In_Long_Term_Residential_Facility
      , ECQM147V8Elements.Home_Healthcare_Services
      , ECQM147V8Elements.Patient_Provider_Interaction
      , ECQM147V8Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
      , ECQM147V8Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
      , ECQM147V8Elements.Preventive_Care_Services_Individual_Counseling
      , ECQM147V8Elements.Preventive_Care_Services___Group_Counseling
      , ECQM147V8Elements.Preventive_Care_Services___Other
      , ECQM147V8Elements.Discharge_Services___Nursing_Facility
      , ECQM147V8Elements.Nursing_Facility_Visit
      , ECQM147V8Elements.Annual_Wellness_Visit
      , ECQM147V8Elements.Peritoneal_Dialysis_110
      , ECQM147V8Elements.Hemodialysis_110
      , ECQM147V8Elements.Preventive_Care__Established_Office_Visit__0_To_17
      , ECQM147V8Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
      , ECQM147V8Elements.Encounter_Influenza
      , ECQM147V8Elements.Influenza_Vaccination
      , ECQM147V8Elements.Influenza_Vaccine
      , ECQM147V8Elements.Previous_Receipt_Of_Influenza_Vaccine
      , ECQM147V8Elements.Influenza_Vaccination_Declined
      , ECQM147V8Elements.Medical_Reason
      , ECQM147V8Elements.Patient_Reason
      , ECQM147V8Elements.System_Reason
      , ECQM147V8Elements.Allergy_To_Eggs
      , ECQM147V8Elements.Egg_Substance
      , ECQM147V8Elements.Allergy_To_Influenza_Vaccine
      , ECQM147V8Elements.Intolerance_To_Influenza_Vaccine
    )
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val ippRDD = getIpp(initialRDD, patientHistoryList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val intermediateRDD = ippRDD.subtract(exclusionRDD)
      intermediateRDD.cache()

      // Filter Met
      val metRDD = getMet(intermediateRDD, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateRDD, patientHistoryList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryList.destroy()
    }

  }


  /*-----------------------------------------------------------------------------------------------------------------------
  All patients aged 6 months and older seen for a visit during the measurement period
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAboveInMonth(visit, m, true, 6)
        &&
        (
          isEncounterPerformed(visit, m, ECQM147V8Elements.Office_Visit, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Outpatient_Consultation, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Care_Services_In_Long_Term_Residential_Facility, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Home_Healthcare_Services, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Patient_Provider_Interaction, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Preventive_Care_Services_Individual_Counseling, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Preventive_Care_Services___Group_Counseling, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Preventive_Care_Services___Other, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Discharge_Services___Nursing_Facility, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Nursing_Facility_Visit, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Annual_Wellness_Visit, patientHistoryList)
            ||
            isProcedurePerformed(visit, m, ECQM147V8Elements.Peritoneal_Dialysis_110, patientHistoryList)
            ||
            isProcedurePerformed(visit, m, ECQM147V8Elements.Hemodialysis_110, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Preventive_Care__Established_Office_Visit__0_To_17, patientHistoryList)
            ||
            isEncounterPerformed(visit, m, ECQM147V8Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up, patientHistoryList)
          )

    )
  }



  /*-----------------------------------------------------------------------------------------------------------------------
  Equals Initial Population and seen for a visit between October 1 and March 31
  -----------------------------------------------------------------------------------------------------------------------*/
  def getEligible(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      //"Encounter, Performed: Encounter-Influenza" satisfies any:
      wasDuringInfluenzaPeriodLastThreeMonthInHistory(visit, m, ECQM147V8Elements.Encounter_Influenza, patientHistoryList)
        ||
        isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Encounter_Influenza)
        ||
        // "Procedure, Performed: Hemodialysis_110" satisfies any:
        wasDuringInfluenzaPeriodLastThreeMonthInHistory(visit, m, ECQM147V8Elements.Hemodialysis_110, patientHistoryList)
        ||
        isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Hemodialysis_110)
        ||
        // "Procedure, Performed: Peritoneal Dialysis_110" satisfies any:
        wasDuringInfluenzaPeriodLastThreeMonthInHistory(visit, m, ECQM147V8Elements.Peritoneal_Dialysis_110, patientHistoryList)
        ||
        isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Peritoneal_Dialysis_110)

    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
  Patients who received an influenza immunization OR who reported previous receipt of an influenza immunization
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateRDD.filter(visit =>
      wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, ECQM147V8Elements.Influenza_Vaccination, patientHistoryList)
        ||
        isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Influenza_Vaccination)
        ||
        wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, ECQM147V8Elements.Influenza_Vaccine, patientHistoryList)
        ||
        isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Influenza_Vaccine)
        ||
        wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, ECQM147V8Elements.Previous_Receipt_Of_Influenza_Vaccine, patientHistoryList)
        ||
        isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Previous_Receipt_Of_Influenza_Vaccine)
    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
  Documentation of medical reason(s) for not receiving influenza immunization (eg, patient allergy, other medical reasons).
  Documentation of patient reason(s) for not receiving influenza immunization (eg, patient declined, other patient reasons).
  Documentation of system reason(s) for not receiving influenza immunization (eg, vaccine not available, other system reasons).
  -----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateRDD.filter(visit =>
      (
        wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, ECQM147V8Elements.Influenza_Vaccination_Declined, patientHistoryList)
          ||
          wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, ECQM147V8Elements.Medical_Reason, patientHistoryList)
          ||
          wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, ECQM147V8Elements.Patient_Reason, patientHistoryList)
          ||
          wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, ECQM147V8Elements.System_Reason, patientHistoryList)
          ||
          isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Influenza_Vaccination_Declined)
          ||
          isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Medical_Reason)
          ||
          isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Patient_Reason)
          ||
          isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.System_Reason)
          ||
          (
            isDiagnosed(visit, m, ECQM147V8Elements.Allergy_To_Eggs, patientHistoryList)
              &&
              !isDuringInfluenzaPeriodAfterFirstThreeMonth(visit, m, ECQM147V8Elements.Allergy_To_Eggs)
              &&
              !isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Allergy_To_Eggs)
            )
          ||
          (
            isDiagnosed(visit, m, ECQM147V8Elements.Egg_Substance, patientHistoryList)
              &&
              !isDuringInfluenzaPeriodAfterFirstThreeMonth(visit, m, ECQM147V8Elements.Egg_Substance)
              &&
              !isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Egg_Substance)
            )
          ||
          (
            isDiagnosed(visit, m, ECQM147V8Elements.Allergy_To_Influenza_Vaccine, patientHistoryList)
              &&
              !isDuringInfluenzaPeriodAfterFirstThreeMonth(visit, m, ECQM147V8Elements.Allergy_To_Influenza_Vaccine)
              &&
              !isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Allergy_To_Influenza_Vaccine)
            )
          ||
          (
            isDiagnosed(visit, m, ECQM147V8Elements.Intolerance_To_Influenza_Vaccine, patientHistoryList)
              &&
              !isDuringInfluenzaPeriodAfterFirstThreeMonth(visit, m, ECQM147V8Elements.Intolerance_To_Influenza_Vaccine)
              &&
              !isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Intolerance_To_Influenza_Vaccine)
            )
          ||
          (
            isDiagnosed(visit, m, ECQM147V8Elements.Influenza_Vaccination, patientHistoryList)
              &&
              !isDuringInfluenzaPeriodAfterFirstThreeMonth(visit, m, ECQM147V8Elements.Influenza_Vaccination)
              &&
              !isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Influenza_Vaccination)
            )
          ||
          (
            isDiagnosed(visit, m, ECQM147V8Elements.Influenza_Vaccine, patientHistoryList)
              &&
              !isDuringInfluenzaPeriodAfterFirstThreeMonth(visit, m, ECQM147V8Elements.Influenza_Vaccine)
              &&
              !isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Influenza_Vaccine)
            )
          ||
          (
            isDiagnosed(visit, m, ECQM147V8Elements.Allergy_To_Influenza_Vaccine, patientHistoryList)
              &&
              !isDuringInfluenzaPeriodAfterFirstThreeMonth(visit, m, ECQM147V8Elements.Allergy_To_Influenza_Vaccine)
              &&
              !isDuringInfluenzaPeriodFirstThreeMonth(visit, m, ECQM147V8Elements.Allergy_To_Influenza_Vaccine)
            )
        )
    )
  }

}

