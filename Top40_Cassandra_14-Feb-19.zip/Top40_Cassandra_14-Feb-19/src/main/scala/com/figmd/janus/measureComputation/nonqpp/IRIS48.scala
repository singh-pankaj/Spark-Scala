package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, IRIS48Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS48
* Measure Title               :- Adult Surgical Esotropia: Postoperative alignment
* Measure Description         :- Percentage of adult esotropia patients receiving surgical treatment with a posttreatment alignment of 12 prism diopters (PD) or less.
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS48 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS48"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,IRIS48Elements.Esotropia
      ,IRIS48Elements.Intermittent_Esotropia
      ,IRIS48Elements.Partially_Accommodative_Esotropia
      ,IRIS48Elements.Divergence_Insufficiency
      ,IRIS48Elements.Sixth_Nerve_Palsy
      ,IRIS48Elements.Esotropia__Eye
      ,IRIS48Elements.Intermittent_Esotropia__Eye
      ,IRIS48Elements.Partially_Accommodative_Esotropia__Eye
      ,IRIS48Elements.Divergence_Insufficiency_Eye
      ,IRIS48Elements.Sixth_Nerve_Palsy__Eye
      ,IRIS48Elements.Duane_Syndrome
      ,IRIS48Elements.Duane_Syndrome__Eye
      ,IRIS48Elements.Scarring_Of_Extraocular_Muscles
      ,IRIS48Elements.Scarring_Of_Extraocular_Muscles_Eye
      ,IRIS48Elements.Prism_Diopter
      ,IRIS48Elements.Prism_Diopter__Eye
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients aged 19 years or more who underwent a surgical treatment for esotropia.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
            isAgeAbove(visit,m,true,19)
        &&  (   wasDiagnosedBeforeOrEqualProcedure(visit,m,IRIS48Elements.Esotropia_Surgery,IRIS48Elements.Esotropia,patientHistoryBroadcastList)
             || wasDiagnosedBeforeOrEqualProcedure(visit,m,IRIS48Elements.Esotropia_Surgery,IRIS48Elements.Intermittent_Esotropia,patientHistoryBroadcastList)
             || wasDiagnosedBeforeOrEqualProcedure(visit,m,IRIS48Elements.Esotropia_Surgery,IRIS48Elements.Partially_Accommodative_Esotropia,patientHistoryBroadcastList)
             || wasDiagnosedBeforeOrEqualProcedure(visit,m,IRIS48Elements.Esotropia_Surgery,IRIS48Elements.Divergence_Insufficiency,patientHistoryBroadcastList)
             || wasDiagnosedBeforeOrEqualProcedure(visit,m,IRIS48Elements.Esotropia_Surgery,IRIS48Elements.Sixth_Nerve_Palsy,patientHistoryBroadcastList)
            )
        &&  isProcedurePerformedDuringEncounter(visit,m,IRIS48Elements.Esotropia_Surgery)
        &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,true,IRIS48Elements.Esotropia_Surgery__Eye,patientHistoryBroadcastList
                                                ,Seq(IRIS48Elements.Esotropia__Eye
                                                    ,IRIS48Elements.Intermittent_Esotropia__Eye
                                                    ,IRIS48Elements.Partially_Accommodative_Esotropia__Eye
                                                    ,IRIS48Elements.Divergence_Insufficiency_Eye
                                                    ,IRIS48Elements.Sixth_Nerve_Palsy__Eye))
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Duane syndrome ; Scarring of extraocular muscles .
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
          (    wasDiagnosedInHistory(visit,m,IRIS48Elements.Duane_Syndrome,patientHistoryBroadcastList)
           &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS48Elements.Esotropia_Surgery__Eye,patientHistoryBroadcastList,Seq(IRIS48Elements.Duane_Syndrome__Eye))
          )
       ||
          (    wasProcedurePerformedInHistory(visit,m,IRIS48Elements.Scarring_Of_Extraocular_Muscles,patientHistoryBroadcastList)
           &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS48Elements.Esotropia_Surgery__Eye,patientHistoryBroadcastList,Seq(IRIS48Elements.Scarring_Of_Extraocular_Muscles_Eye))
          )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Posttreatment alignment of 12 PD or less recorded between 4 and 12 weeks after treatment.
Note: If there are multiple prism diopter measurements, the lowest measurement (likely to be the Simultaneous Prism and Cover Test) is to be used
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
          wasPhysicalExamPerformedAfterProcedureBetweenXPeriodesWithValues(visit,m,IRIS48Elements.Prism_Diopter,IRIS48Elements.Esotropia_Surgery,CompareOperator.LESS_EQUAL,12,CalenderUnit.WEEK,12,CalenderUnit.WEEK,4,patientHistoryBroadcastList)
      &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS48Elements.Esotropia_Surgery__Eye,patientHistoryBroadcastList,Seq(IRIS48Elements.Prism_Diopter__Eye))
    )
  }

}