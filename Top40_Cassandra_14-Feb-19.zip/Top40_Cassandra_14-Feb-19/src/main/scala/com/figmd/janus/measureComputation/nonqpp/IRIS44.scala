package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, IRIS44Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS44
* Measure Title               :- Glaucoma - Visual Field Progression
* Measure Description         :- Percentage of patients with a diagnosis of glaucoma, with a mean deviation loss of more than 3dB from their baseline value.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Lower Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS44 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS44"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,IRIS44Elements.Visual_Field_Examination
      ,IRIS44Elements.Visual_Field_Mean_Deviation
      ,IRIS44Elements.Primary_Open_Angle_Glaucoma
      ,IRIS44Elements.Open_Angle_Glaucoma_Unspecified
      ,IRIS44Elements.Pigmentary_Glaucoma
      ,IRIS44Elements.Pseudoexfoliation_Glaucoma
      ,IRIS44Elements.Low_Tension_Glaucoma
      ,IRIS44Elements.Absolute_Glaucoma_Blindness
      ,IRIS44Elements.Absolute_Glaucoma_Blindness_Eye
      ,IRIS44Elements.Primary_Open_Angle_Glaucoma_Eye
      ,IRIS44Elements.Incisional_Glaucoma_Surgery
      ,IRIS44Elements.Incisional_Glaucoma_Surgery__Eye
      ,IRIS44Elements.Visual_Field_Worsening_Conditions
      ,IRIS44Elements.Visual_Field_Worsening_Conditions__Eye
      ,IRIS44Elements.Visual_Acuity_Findings
      ,IRIS44Elements.Visual_Acuity_Findings__Eye
      ,IRIS44Elements.Visual_Field_Mean_Deviation_Eye
      ,IRIS44Elements.Open_Angle_Glaucoma_Unspecified__Eye
      ,IRIS44Elements.Pigmentary_Glaucoma_Eye
      ,IRIS44Elements.Pseudoexfoliation_Glaucoma_Eye
      ,IRIS44Elements.Low_Tension_Glaucoma_Eye
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val FirstVisualFieldExamination = getElementCountListStartsBeforeEndOfMeasurement(patientHistoryRDD,m,3,IRIS44Elements.Visual_Field_Examination,IRIS44Elements.Visual_Field_Mean_Deviation)

    val leastPatientList = leastPatientListBeforeEndOfWithinXPeriod(patientHistoryRDD,m,CalenderUnit.YEAR,3,IRIS44Elements.Visual_Field_Examination,IRIS44Elements.Visual_Field_Mean_Deviation)
    val leastPatientBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastPatientList)

    val mostPatientList = mostPatientListBeforeEndWithinXPeriod(patientHistoryRDD,m,CalenderUnit.YEAR,3,IRIS44Elements.Visual_Field_Examination,IRIS44Elements.Visual_Field_Mean_Deviation)
    val mostPatientBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostPatientList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList,patientHistoryRDD,leastPatientBroadcastList,mostPatientBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList,leastPatientBroadcastList,mostPatientBroadcastList)
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients aged between 40 and 85 years, with a minimum of 2 visual field tests during the prior 3 years, with a glaucoma diagnosis.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryRDD: RDD[CassandraRow],leastPatientList: Broadcast[List[CassandraRow]],mostPatientList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val CountOfVisualFieldExamination = countBeforeEndOfMPWithinXPeriod(patientHistoryRDD,m,CalenderUnit.YEAR,3,IRIS44Elements.Visual_Field_Examination,IRIS44Elements.Visual_Field_Mean_Deviation)

    initialRDD.filter(
      visit =>
                isAgeBetweenOnLeastRecentElement(visit,m,IRIS44Elements.Visual_Field_Examination,CompareOperator.GREATER_EQUAL,40,CompareOperator.LESS,86,patientHistoryBroadcastList)
            &&  wasDiagnosedInHistory(visit,m,IRIS44Elements.Primary_Open_Angle_Glaucoma,patientHistoryBroadcastList)
            &&  wasDiagnosedInHistory(visit,m,IRIS44Elements.Open_Angle_Glaucoma_Unspecified,patientHistoryBroadcastList)
            &&  wasDiagnosedInHistory(visit,m,IRIS44Elements.Pigmentary_Glaucoma,patientHistoryBroadcastList)
            &&  wasDiagnosedInHistory(visit,m,IRIS44Elements.Pseudoexfoliation_Glaucoma,patientHistoryBroadcastList)
            &&  wasDiagnosedInHistory(visit,m,IRIS44Elements.Low_Tension_Glaucoma,patientHistoryBroadcastList)
            &&  isCountGreaterOrEqual(visit,m,2,true,CountOfVisualFieldExamination)
            &&  wasPhysicalExamPerformedAfterPhysicalExamInHistory(visit,m,IRIS44Elements.Visual_Field_Examination,leastPatientList,IRIS44Elements.Visual_Field_Mean_Deviation)
            &&  wasPhysicalExamPerformedAfterPhysicalExamInHistory(visit,m,IRIS44Elements.Visual_Field_Examination,mostPatientList,IRIS44Elements.Visual_Field_Mean_Deviation)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
1. Eyes with absolute glaucoma blindness
2. Eyes with a glaucoma incisional surgery performed within the last 90 days
3. Conditions that may results in visual field worsening independent of glaucoma
4. Visual acuity findings Count fingers (CF or FC), Hand motion (HM), Light perception (LP), No light perception (NLP)
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        (    wasDiagnosedInHistory(visit,m,IRIS44Elements.Absolute_Glaucoma_Blindness,patientHistoryBroadcastList)
         &&  (    checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Absolute_Glaucoma_Blindness_Eye,patientHistoryBroadcastList,IRIS44Elements.Primary_Open_Angle_Glaucoma_Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Absolute_Glaucoma_Blindness_Eye,patientHistoryBroadcastList,IRIS44Elements.Open_Angle_Glaucoma_Unspecified__Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Absolute_Glaucoma_Blindness_Eye,patientHistoryBroadcastList,IRIS44Elements.Pigmentary_Glaucoma_Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Absolute_Glaucoma_Blindness_Eye,patientHistoryBroadcastList,IRIS44Elements.Pseudoexfoliation_Glaucoma_Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Absolute_Glaucoma_Blindness_Eye,patientHistoryBroadcastList,IRIS44Elements.Low_Tension_Glaucoma_Eye)
             )
        )
      ||
        (    wasProcedurePerformedBeforePhysicalExamWithInXDays(visit,m,IRIS44Elements.Visual_Field_Examination,IRIS44Elements.Incisional_Glaucoma_Surgery,CalenderUnit.DAY,90,patientHistoryBroadcastList)
          &&  (   checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Incisional_Glaucoma_Surgery__Eye,patientHistoryBroadcastList,IRIS44Elements.Primary_Open_Angle_Glaucoma_Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Incisional_Glaucoma_Surgery__Eye,patientHistoryBroadcastList,IRIS44Elements.Open_Angle_Glaucoma_Unspecified__Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Incisional_Glaucoma_Surgery__Eye,patientHistoryBroadcastList,IRIS44Elements.Pigmentary_Glaucoma_Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Incisional_Glaucoma_Surgery__Eye,patientHistoryBroadcastList,IRIS44Elements.Pseudoexfoliation_Glaucoma_Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Incisional_Glaucoma_Surgery__Eye,patientHistoryBroadcastList,IRIS44Elements.Low_Tension_Glaucoma_Eye)
              )
        )
      ||
        (    wasDiagnosedInHistory(visit,m,IRIS44Elements.Visual_Field_Worsening_Conditions,patientHistoryBroadcastList)
          &&  (   checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Field_Worsening_Conditions__Eye,patientHistoryBroadcastList,IRIS44Elements.Primary_Open_Angle_Glaucoma_Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Field_Worsening_Conditions__Eye,patientHistoryBroadcastList,IRIS44Elements.Open_Angle_Glaucoma_Unspecified__Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Field_Worsening_Conditions__Eye,patientHistoryBroadcastList,IRIS44Elements.Pigmentary_Glaucoma_Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Field_Worsening_Conditions__Eye,patientHistoryBroadcastList,IRIS44Elements.Pseudoexfoliation_Glaucoma_Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Field_Worsening_Conditions__Eye,patientHistoryBroadcastList,IRIS44Elements.Low_Tension_Glaucoma_Eye)
              )
        )
      ||
        (    wasDiagnosedInHistory(visit,m,IRIS44Elements.Visual_Acuity_Findings,patientHistoryBroadcastList)
          &&  (   checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Acuity_Findings__Eye,patientHistoryBroadcastList,IRIS44Elements.Primary_Open_Angle_Glaucoma_Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Acuity_Findings__Eye,patientHistoryBroadcastList,IRIS44Elements.Open_Angle_Glaucoma_Unspecified__Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Acuity_Findings__Eye,patientHistoryBroadcastList,IRIS44Elements.Pigmentary_Glaucoma_Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Acuity_Findings__Eye,patientHistoryBroadcastList,IRIS44Elements.Pseudoexfoliation_Glaucoma_Eye)
              ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Acuity_Findings__Eye,patientHistoryBroadcastList,IRIS44Elements.Low_Tension_Glaucoma_Eye)
              )
        )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with a mean deviation loss of 3dB or more from baseline visual field tests to the most recent test.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],leastPatientList: Broadcast[List[CassandraRow]],mostPatientList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
          wasVisualFieldTestResultAfterVisualFieldExamination(visit,m,IRIS44Elements.Visual_Field_Mean_Deviation,CompareOperator.GREATER_EQUAL,3,mostPatientList,leastPatientList)
      &&  (   checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Field_Mean_Deviation_Eye,patientHistoryBroadcastList,IRIS44Elements.Primary_Open_Angle_Glaucoma_Eye)
           || checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Field_Mean_Deviation_Eye,patientHistoryBroadcastList,IRIS44Elements.Open_Angle_Glaucoma_Unspecified__Eye)
           || checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Field_Mean_Deviation_Eye,patientHistoryBroadcastList,IRIS44Elements.Pigmentary_Glaucoma_Eye)
           || checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Field_Mean_Deviation_Eye,patientHistoryBroadcastList,IRIS44Elements.Pseudoexfoliation_Glaucoma_Eye)
           || checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS44Elements.Visual_Field_Mean_Deviation_Eye,patientHistoryBroadcastList,IRIS44Elements.Low_Tension_Glaucoma_Eye)
          )
    )
  }


}