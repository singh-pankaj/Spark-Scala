package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AQUA 29
* Measure Title               :- Prostate Cancer: Patient Report of Urinary function after treatment
* Measure Description         :- Percentage of patients who had a reported urinary function score at 12 months after
*                                treatment that is within 80% of the reported urinary function score at baseline (before treatment)
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- Rishikesh Patil
* Initial GIT Version/Tag(CRA):- 1.9
* Latest GIT Version/Tag(CRA) :- 1.9
----------------------------------------------------------------------------------------------------------------------------*/

object AQUA29 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "AQUA29"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , AQUA29Elements.Prostate_Cancer_New
      , AQUA29Elements.Baseline_Urinary_Function__Epic_26_
      , AQUA29Elements.Documentation_Of_Ebrt_In_Md_Notes
      , AQUA29Elements.Gold__Fiducial_Markers_In_Md_Notes
      , AQUA29Elements.Adt_Md_Notes
      , AQUA29Elements.Documentation_Of_Cryotherapy_In_Md_Notes
      , AQUA29Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes
      , AQUA29Elements.Documentation_Of_Brachytherapy_In_Md_Notes
      , AQUA29Elements.Interstitial_Prostate_Brachytherapy
      , AQUA29Elements.Radical_Prostatectomy
      , AQUA29Elements.Cryotherapy
      , AQUA29Elements.Adt
      , AQUA29Elements.External_Beam_Radiotherapy
      , AQUA29Elements.Gold__Fiducial_Marker
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  All newly diagnosed prostate cancer patients
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isMale(visit, m)
      &&
      wasDiagnosisBeforeStartInXMonths(visit, m, AQUA29Elements.Prostate_Cancer_New, CalenderUnit.MONTH ,12, patientHistoryBroadcastList)
        &&
        (
          wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,AQUA29Elements.Baseline_Urinary_Function__Epic_26_,AQUA29Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
          &&
          (
            wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA29Elements.Baseline_Urinary_Function__Epic_26_,AQUA29Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList)
            ||
            wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA29Elements.Baseline_Urinary_Function__Epic_26_,AQUA29Elements.Radical_Prostatectomy,patientHistoryBroadcastList)
            ||
            wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA29Elements.Baseline_Urinary_Function__Epic_26_,AQUA29Elements.Cryotherapy,patientHistoryBroadcastList)
            ||
            wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA29Elements.Baseline_Urinary_Function__Epic_26_,AQUA29Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList)
            ||
            wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA29Elements.Baseline_Urinary_Function__Epic_26_,AQUA29Elements.Adt,patientHistoryBroadcastList)
            ||
            wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA29Elements.Baseline_Urinary_Function__Epic_26_,AQUA29Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList)
            ||
            wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA29Elements.Baseline_Urinary_Function__Epic_26_,AQUA29Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList)
            ||
            wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA29Elements.Baseline_Urinary_Function__Epic_26_,AQUA29Elements.Documentation_Of_Ebrt_In_Md_Notes,patientHistoryBroadcastList)
            ||
            wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA29Elements.Baseline_Urinary_Function__Epic_26_,AQUA29Elements.Adt_Md_Notes,patientHistoryBroadcastList)
            ||
            wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA29Elements.Baseline_Urinary_Function__Epic_26_,AQUA29Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList)
            ||
            wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA29Elements.Baseline_Urinary_Function__Epic_26_,AQUA29Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList)
            ||
            wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA29Elements.Baseline_Urinary_Function__Epic_26_,AQUA29Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList)
            )
          )
        &&
        (
          wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA29Elements.Interstitial_Prostate_Brachytherapy,AQUA29Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
          ||
          wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA29Elements.Radical_Prostatectomy,AQUA29Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
          ||
          wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA29Elements.Cryotherapy,AQUA29Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
          ||
          wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA29Elements.External_Beam_Radiotherapy,AQUA29Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
          ||
          wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA29Elements.Adt,AQUA29Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
          ||
          wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA29Elements.Gold__Fiducial_Marker,AQUA29Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
          ||
          wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA29Elements.Gold__Fiducial_Markers_In_Md_Notes,AQUA29Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
          ||
          wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA29Elements.Documentation_Of_Ebrt_In_Md_Notes,AQUA29Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
          ||
          wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA29Elements.Adt_Md_Notes,AQUA29Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
          ||
          wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA29Elements.Documentation_Of_Cryotherapy_In_Md_Notes,AQUA29Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
          ||
          wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA29Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,AQUA29Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
          ||
          wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA29Elements.Documentation_Of_Brachytherapy_In_Md_Notes,AQUA29Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
          )
        )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Men completing EPIC-26 urinary function domain who had a reported urinary function score within 80% of the reported
  urinary function score at baseline (before treatment)
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>

        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA29Elements.Urinary_Function_Report__Epic_26_
          , AQUA29Elements.Documentation_Of_Ebrt_In_Md_Notes, "le", 80, "le", patientHistoryBroadcastList)
      ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA29Elements.Urinary_Function_Report__Epic_26_
          , AQUA29Elements.Gold__Fiducial_Markers_In_Md_Notes, "le", 80, "le", patientHistoryBroadcastList)
      ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA29Elements.Urinary_Function_Report__Epic_26_
          , AQUA29Elements.Adt_Md_Notes, "le", 80, "le", patientHistoryBroadcastList)
      ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA29Elements.Urinary_Function_Report__Epic_26_
          , AQUA29Elements.Documentation_Of_Cryotherapy_In_Md_Notes, "le", 80, "le", patientHistoryBroadcastList)
      ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA29Elements.Urinary_Function_Report__Epic_26_
          , AQUA29Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes, "le", 80, "le", patientHistoryBroadcastList)
      ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA29Elements.Urinary_Function_Report__Epic_26_
          , AQUA29Elements.Documentation_Of_Brachytherapy_In_Md_Notes, "le", 80, "le", patientHistoryBroadcastList)
      ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA29Elements.Urinary_Function_Report__Epic_26_
          , AQUA29Elements.Interstitial_Prostate_Brachytherapy, "le", 80, "le", patientHistoryBroadcastList)
      ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA29Elements.Urinary_Function_Report__Epic_26_
          , AQUA29Elements.Radical_Prostatectomy, "le", 80, "le", patientHistoryBroadcastList)
      ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA29Elements.Urinary_Function_Report__Epic_26_
          , AQUA29Elements.Cryotherapy, "le", 80, "le", patientHistoryBroadcastList)
      ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA29Elements.Urinary_Function_Report__Epic_26_
          , AQUA29Elements.Adt, "le", 80, "le", patientHistoryBroadcastList)
      ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA29Elements.Urinary_Function_Report__Epic_26_
          , AQUA29Elements.External_Beam_Radiotherapy, "le", 80, "le", patientHistoryBroadcastList)
      ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA29Elements.Urinary_Function_Report__Epic_26_
          , AQUA29Elements.Gold__Fiducial_Marker, "le", 80, "le", patientHistoryBroadcastList)

    )
  }

}
