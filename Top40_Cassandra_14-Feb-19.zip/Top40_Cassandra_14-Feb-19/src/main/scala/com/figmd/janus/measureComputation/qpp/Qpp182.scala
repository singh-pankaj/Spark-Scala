package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, CompareOperator, MeasureProperty, QPP182Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 182
* Measure Title              :- Functional Outcome Assessment
* Measure Description        :- Percentage of visits for patients aged 18 years and older with documentation of a current functional outcome assessment using a standardized functional outcome assessment tool on the date of the encounter AND documentation of a care plan based on identified functional outcome deficiencies on the date of the identified deficiencies.
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp182 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp182"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP182Elements.Oswestry_Disability_Index__Odi_,
      QPP182Elements.Promis_Score,
      QPP182Elements.Neck_Disability_Index,
      QPP182Elements.Roland_Morris_Disability_Questionnaire,
      QPP182Elements.Hip_Knee_Outcome_Questionnaire_Gr,
      QPP182Elements.Disabilities_Of_Arm_Shoulder_Hand__Dash_,
      QPP182Elements.Lower_Extremity_Functional_Scale__Lefs_, QPP182Elements.Care_Plan).collect().toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getExclusionRdd(metRDD)

      val intermediateA = getSubtractRDD(ippRDD, metRDD)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //All visits for patients aged 18 years and older
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true)
        &&
        isVisitTypeIn(visit, m,
          QPP182Elements.Chiropractic_Manipulative_Treatment,
          QPP182Elements.Office_Visit,
          QPP182Elements.Physical_Therapy_Evaluation_Cpt,
          QPP182Elements.Re_Evaluation_Of_Physical_Therapy_Cpt,
          QPP182Elements.Occupational_Therapy_Cpt,
          QPP182Elements.Occupational_Therapy_Re_Evalution_Cpt)
    )
  }

  //
  def getExclusionRdd(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        isAssessmentPerformedOnEncounter(visit, m, QPP182Elements.Functional_Outcome_Patient_Not_Eligible)
          ||
          isAssessmentRecommended(visit, m, QPP182Elements.Care_Plan_Patient_Not_Eligible)
          ||
          isAssessmentPerformedOnEncounter(visit, m, QPP182Elements.Functional_Assessment_Patient_Not_Eligible)
        )
        ||
        (
          isAssessmentPerformedOnEncounter(visit, m, QPP182Elements.Foa_Not_Doc_For_Performed)
            ||
            isAssessmentPerformedOnEncounter(visit, m, QPP182Elements.Care_Plan_Not_Doc_For_Performed)
          )
    )
  }

  //Patients with a documented current functional outcome assessment using a standardized tool AND a documented care plan based on the identified functional outcome deficiencies
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        (
          //$PositiveAssessment
          (
            (
              isAssessmentValueOnEncounter(visit, m, QPP182Elements.Oswestry_Disability_Index__Odi_, 21, CompareOperator.GREATER)
                && isAssessmentValueOnEncounter(visit, m, QPP182Elements.Oswestry_Disability_Index__Odi_, 100, CompareOperator.LESS)
              )
              ||
              (
                isAssessmentValueOnEncounter(visit, m, QPP182Elements.Promis_Score, 21.2, CompareOperator.GREATER)
                  && isAssessmentValueOnEncounter(visit, m, QPP182Elements.Promis_Score, 48.3, CompareOperator.LESS)
                )
              ||
              isAssessmentValueOnEncounter(visit, m, QPP182Elements.Neck_Disability_Index, 5, CompareOperator.GREATER)
              ||
              (
                isAssessmentValueOnEncounter(visit, m, QPP182Elements.Roland_Morris_Disability_Questionnaire, 1, CompareOperator.GREATER)
                  && isAssessmentValueOnEncounter(visit, m, QPP182Elements.Roland_Morris_Disability_Questionnaire, 24, CompareOperator.LESS)
                )
              ||
              (
                isAssessmentValueOnEncounter(visit, m, QPP182Elements.Hip_Knee_Outcome_Questionnaire_Gr, 0, CompareOperator.GREATER)
                  && isAssessmentValueOnEncounter(visit, m, QPP182Elements.Hip_Knee_Outcome_Questionnaire_Gr, 92, CompareOperator.LESS)
                )
              ||
              (
                isAssessmentValueOnEncounter(visit, m, QPP182Elements.Disabilities_Of_Arm_Shoulder_Hand__Dash_, 0, CompareOperator.GREATER)
                  && isAssessmentValueOnEncounter(visit, m, QPP182Elements.Disabilities_Of_Arm_Shoulder_Hand__Dash_, 92, CompareOperator.LESS)
                )
              ||
              (
                isAssessmentValueOnEncounter(visit, m, QPP182Elements.Lower_Extremity_Functional_Scale__Lefs_, 0, CompareOperator.GREATER)
                  && isAssessmentValueOnEncounter(visit, m, QPP182Elements.Lower_Extremity_Functional_Scale__Lefs_, 74, CompareOperator.LESS)
                )
            )
            &&
            isAssessmentRecommended(visit, m, QPP182Elements.Care_Plan)
          )
          ||
          isAssessmentPerformedDuringEncounter(visit, m, QPP182Elements.Functional_Outcome_Assessment_Care_Plan)
          ||
          //$NegativeAssessment
          (
            (
              isAssessmentValueOnEncounter(visit, m, QPP182Elements.Oswestry_Disability_Index__Odi_, 0, CompareOperator.GREATER)
                && isAssessmentValueOnEncounter(visit, m, QPP182Elements.Oswestry_Disability_Index__Odi_, 20, CompareOperator.LESS)
              )
              ||
              (
                isAssessmentValueOnEncounter(visit, m, QPP182Elements.Promis_Score, 50.8, CompareOperator.GREATER)
                  && isAssessmentValueOnEncounter(visit, m, QPP182Elements.Oswestry_Disability_Index__Odi_, 67.6, CompareOperator.LESS)
                )
              ||
              (
                isAssessmentValueOnEncounter(visit, m, QPP182Elements.Neck_Disability_Index, 0, CompareOperator.GREATER)
                  && isAssessmentValueOnEncounter(visit, m, QPP182Elements.Neck_Disability_Index, 4, CompareOperator.LESS)
                )
              ||
              (
                isAssessmentValueOnEncounter(visit, m, QPP182Elements.Disabilities_Of_Arm_Shoulder_Hand__Dash_, 93, CompareOperator.GREATER)
                  && isAssessmentValueOnEncounter(visit, m, QPP182Elements.Disabilities_Of_Arm_Shoulder_Hand__Dash_, 100, CompareOperator.LESS)
                )
              ||
              (
                isAssessmentValueOnEncounter(visit, m, QPP182Elements.Hip_Knee_Outcome_Questionnaire_Gr, 93, CompareOperator.GREATER)
                  && isAssessmentValueOnEncounter(visit, m, QPP182Elements.Hip_Knee_Outcome_Questionnaire_Gr, 100, CompareOperator.LESS)
                )
              ||
              (
                isAssessmentValueOnEncounter(visit, m, QPP182Elements.Lower_Extremity_Functional_Scale__Lefs_, 75, CompareOperator.GREATER)
                  && isAssessmentValueOnEncounter(visit, m, QPP182Elements.Lower_Extremity_Functional_Scale__Lefs_, 80, CompareOperator.LESS)
                )
              ||
              isAssessmentValueOnEncounter(visit, m, QPP182Elements.Roland_Morris_Disability_Questionnaire, 0, CompareOperator.EQUAL)
            )
          ||
          isAssessmentPerformedDuringEncounter(visit, m, QPP182Elements.Functional_Assessment)
          ||
          //$PositiveAssessment <= 30 day(s) starts before start of $Encounter
          (
            (
              (
                wasAssessmentValueBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, QPP182Elements.Oswestry_Disability_Index__Odi_, 30, 21, CompareOperator.GREATER, patientHistoryBroadcastList)
                  && wasAssessmentValueBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, QPP182Elements.Oswestry_Disability_Index__Odi_, 30, 100, CompareOperator.LESS, patientHistoryBroadcastList)
                )
                ||
                (
                  wasAssessmentValueBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, QPP182Elements.Promis_Score, 30, 21.2, CompareOperator.GREATER, patientHistoryBroadcastList)
                    && wasAssessmentValueBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, QPP182Elements.Promis_Score, 30, 48.3, CompareOperator.LESS, patientHistoryBroadcastList)
                  )
                ||
                wasAssessmentValueBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, QPP182Elements.Neck_Disability_Index, 30, 5, CompareOperator.GREATER, patientHistoryBroadcastList)
                ||
                (
                  wasAssessmentValueBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, QPP182Elements.Roland_Morris_Disability_Questionnaire, 30, 1, CompareOperator.GREATER, patientHistoryBroadcastList)
                    && wasAssessmentValueBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, QPP182Elements.Roland_Morris_Disability_Questionnaire, 30, 24, CompareOperator.LESS, patientHistoryBroadcastList)
                  )
                ||
                (
                  wasAssessmentValueBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, QPP182Elements.Hip_Knee_Outcome_Questionnaire_Gr, 30, 0, CompareOperator.GREATER, patientHistoryBroadcastList)
                    && wasAssessmentValueBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, QPP182Elements.Hip_Knee_Outcome_Questionnaire_Gr, 30, 92, CompareOperator.LESS, patientHistoryBroadcastList)
                  )
                ||
                (
                  wasAssessmentValueBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, QPP182Elements.Disabilities_Of_Arm_Shoulder_Hand__Dash_, 30, 0, CompareOperator.GREATER, patientHistoryBroadcastList)
                    && wasAssessmentValueBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, QPP182Elements.Disabilities_Of_Arm_Shoulder_Hand__Dash_, 30, 92, CompareOperator.LESS, patientHistoryBroadcastList)
                  )
                ||
                (
                  wasAssessmentValueBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, QPP182Elements.Lower_Extremity_Functional_Scale__Lefs_, 30, 0, CompareOperator.GREATER, patientHistoryBroadcastList)
                    && wasAssessmentValueBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, QPP182Elements.Lower_Extremity_Functional_Scale__Lefs_, 30, 74, CompareOperator.LESS, patientHistoryBroadcastList)
                  )
              )
              &&
              wasAssessmentBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, 30, patientHistoryBroadcastList, QPP182Elements.Care_Plan)
            )
          ||
          isAssessmentPerformedDuringEncounter(visit, m, QPP182Elements.Functional_Assessment_Care_Plan)
        )
        &&
        !(
          isAssessmentPerformedOnEncounter(visit, m, QPP182Elements.Functional_Outcome_Reason_Not_Specified)
          ||
          isAssessmentPerformedOnEncounter(visit, m, QPP182Elements.Care_Plan_Reason_Not_Specified)
          )
    )
  }
}
