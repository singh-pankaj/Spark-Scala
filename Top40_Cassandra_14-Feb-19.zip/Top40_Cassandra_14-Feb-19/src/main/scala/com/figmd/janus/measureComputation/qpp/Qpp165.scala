package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP165Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 165
* Measure Title              :- Coronary Artery Bypass Graft (CABG): Deep Sternal Wound Infection Rate
* Measure Description        :- Percentage of patients aged 18 years and older undergoing isolated CABG surgery who,
                                within 30 days postoperatively, develop deep sternal wound infection involving muscle,
                                bone, and/or mediastinum requiring operative intervention
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp165 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "Qpp165"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP165Elements.Deep_Sternal_Wound_Infection
      , QPP165Elements.Deep_Sternal_Wound_Infection_Icd10
      , QPP165Elements.Re_Exploration_Of_Mediastinum
      , QPP165Elements.Positive_Culture
      , QPP165Elements.Perioperative_Prophylaxis
      , QPP165Elements.No_Deep_Sternal_Wound_Infection
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      // metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()
      //

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  /*------------------------------------------------------------------------------------------------
    All patients undergoing isolated CABG surgery
  ------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        (isProcedurePerformedDuringEncounter(visit, m, QPP165Elements.Coronary_Artery_Bypass_Graft)
          ||
          (isProcedurePerformedDuringEncounter(visit, m, QPP165Elements.Coronary_Artery_Bypass_Graft)
            &&
            isProcedurePerformedDuringEncounter(visit, m, QPP165Elements.Cabg_Reoperation)
            )
          )
    )
  }


  /*------------------------------------------------------------------------------------------------
  Patients who, within 30 days postoperatively, develop deep sternal wound infection involving muscle, bone, and/or mediastinum requiring operative intervention. Patient must have ALL of the following conditions:
  1.) wound opened with excision of tissue (incision and drainage) or re-exploration of mediastinum,
  2.) positive culture unless patient is on antibiotics at time of culture or no culture obtained, and
  3.) treatment with antibiotics beyond perioperative prophylaxis
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRdd.filter(visit =>
      (
        isDiagnosed(visit, m, QPP165Elements.Deep_Sternal_Wound_Infection, patientHistoryBroadcastList)
          || wasDiagnosedAfterXDaysProcedure(visit, m, AdminElements.Encounter_Date, QPP165Elements.Deep_Sternal_Wound_Infection_Icd10, 30, patientHistoryBroadcastList)
        )
        &&
        (
          wasProcedurePerformedAfterXDaysProcedure(visit, m, AdminElements.Encounter_Date, QPP165Elements.Re_Exploration_Of_Mediastinum, 30, patientHistoryBroadcastList)
            && wasProcedurePerformedAfterXDaysProcedure(visit, m, AdminElements.Encounter_Date, QPP165Elements.Positive_Culture, 30, patientHistoryBroadcastList)
            && wasProcedurePerformedAfterXDaysProcedure(visit, m, AdminElements.Encounter_Date, QPP165Elements.Perioperative_Prophylaxis, 30, patientHistoryBroadcastList)
          )
        && !isDiagnosed(visit, m, QPP165Elements.No_Deep_Sternal_Wound_Infection, patientHistoryBroadcastList)
    )


  }

}
