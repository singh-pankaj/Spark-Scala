package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, IRIS5Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- IRIS 5
* Measure Title              :- Surgery for Acquired Involutional Ptosis - Patients with an Improvement of Marginal
                                Reflex Distance
* Measure Description        :- Percentage of surgical ptosis patients with an improvement of MRD postoperatively within
                                90 days following the surgical procedure
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS5 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS5"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , IRIS5Elements.Ptosis_Surgical_Procedure_Date
      , IRIS5Elements.Involutional_Ptosis
      , IRIS5Elements.Ptosis_Surgical_Procedure
      , IRIS5Elements.Marginal_Reflex_Distance
      , IRIS5Elements.Mrd__Eye
      , IRIS5Elements.Involutional_Ptosis__Eye
      , IRIS5Elements.Ptosis_Surgical_Procedure__Eye
      , IRIS5Elements.Marginal_Reflex_Distance
      , IRIS5Elements.Improvement_Eye
      , IRIS5Elements.Improvement
    )
    val patientHistory: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistory)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistory)
      metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistory.destroy()
    }
  }

  /*------------------------------------------------------------------------------
   All patients aged 18 years or older with a diagnosis of acquired involutional ptosis who underwent a surgical procedure for the condition.
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow],patientHistory:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
         isPatientAdult(visit,m)
      && isDiagnosedWithBeforeOrEqual(visit,m,IRIS5Elements.Ptosis_Surgical_Procedure_Date,patientHistory,IRIS5Elements.Involutional_Ptosis)
      && isPhysicalExamPerformedDuringEncounter(visit,m,IRIS5Elements.Ptosis_Surgical_Procedure)
      && isPhysicalExamPerformedBeforeSurgery(visit,m,IRIS5Elements.Ptosis_Surgical_Procedure_Date,patientHistory,IRIS5Elements.Marginal_Reflex_Distance)
      && checkEyeElementsInRange(visit,m,IRIS5Elements.Mrd__Eye,IRIS5Elements.Involutional_Ptosis__Eye)
      && wasProcedurePerformedBeforeEndInDays(visit,m,IRIS5Elements.Ptosis_Surgical_Procedure,90,patientHistory)
      && checkEyeElementsInRange(visit,m,IRIS5Elements.Ptosis_Surgical_Procedure__Eye,IRIS5Elements.Involutional_Ptosis__Eye)
      && isPhysicalExamPerformedAfterWithinXDays(visit,m,IRIS5Elements.Ptosis_Surgical_Procedure_Date,IRIS5Elements.Marginal_Reflex_Distance,90,patientHistory)
      && checkEyeElementAfterEncounterEyeElementInXDays(visit,m,IRIS5Elements.Ptosis_Surgical_Procedure__Eye,90,patientHistory,IRIS5Elements.Improvement_Eye)
    )
  }


  /*------------------------------------------------------------------------------
  Patients who achieved an improvement in MRD postoperatively within 90 days following surgery.
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistory:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
           isPhysicalExamPerformedAfterWithinXDays(visit,m,IRIS5Elements.Ptosis_Surgical_Procedure_Date,IRIS5Elements.Improvement,90,patientHistory)
        && checkEyeElementAfterEncounterEyeElementInXDays(visit,m,IRIS5Elements.Ptosis_Surgical_Procedure__Eye,90,patientHistory,IRIS5Elements.Improvement_Eye)
    )

  }
}
