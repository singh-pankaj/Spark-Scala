
package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ACEP21Elements, AdminElements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACEP 21
* Measure Title              :- Emergency Medicine: Coagulation Studies in Patients Presenting with Chest Pain with No Coagulopathy or Bleeding
* Measure Description        :- Percentage of emergency department visits for patients aged 18 years and older with an emergency department discharge diagnosis of chest pain during which coagulation studies were ordered by an emergency care provider
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Lower score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Acep21 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Acep21"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, initialRDD
      , ACEP21Elements.End_Stage_Liver_Disease
      , ACEP21Elements.Coagulopathies
      , ACEP21Elements.Thrombocytopenia
      , ACEP21Elements.Anticoagulant
      , ACEP21Elements.Pulmonary_And_Gastrointestional_Hemorrhage
      , ACEP21Elements.Atrial_Fibrillation).collect.toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //filter denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
All emergency department visits for patients aged 18 years and older with an emergency department discharge diagnosis of chest pain
----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD:RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
          isPatientAdult(visit,m)
       && isVisitTypeIn(visit,m
            ,ACEP21Elements.Emergency_Department_Visit
            ,ACEP21Elements.Critical_Care_Evaluation_And_Management)
       && isDiagnosisDuringEDOrCCEncounter(visit,m,ACEP21Elements.Non_Traumatic_Chest_Pain,ACEP21Elements.Non_Traumatic_Chest_Pain_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date)
       && isEncounterPerformedDuringEDorCC(visit,m,ACEP21Elements.Discharge_To_Home_From_Ed,ACEP21Elements.Discharge_To_Home_From_Ed_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date)
       //&& ! wasDiagnosedBeforeEDOrCCEncounter(visit,m,ACEP21Elements.Non_Traumatic_Chest_Pain,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Patients with any of the following clinical indications for ordering coagulation studies:
  - End stage liver disease
  - Coagulopathy
  - Thrombocytopenia
  - Currently taking or newly prescribed any of the following anticoagulant medications*:
      apixaban, argatroban, bivalirudin, dabigatran, dalteparin, desirudin,
      edoxaban, enoxaparin, fondaparinux, heparin, lepirudin, rivaroxaban, tinzaparin, warfarin
  - Pregnancy
  - Pulmonary or gastrointestinal hemorrhage
  - Atrial fibrillation
  - Inability to obtain medical history
  - Trauma
  - Patients who left before treatment completion
    * The aforementioned list of medications/drug names is based on clinical guidelines and other evidence and may not be all-inclusive or current.  Physicians and other health care professionals should refer to the FDA's web site page entitled "Drug Safety Communications" for up-to-date drug recall and alert information when prescribing medications.  As part of the measure maintenance process, the measure and specifications will be updated routinely to account for newly released and FDA approved pharmacologic agents.
----------------------------------------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
          wasDiagnosedBeforeEDOrCCEncounter(visit,m,ACEP21Elements.End_Stage_Liver_Disease,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
      ||  wasDiagnosedBeforeEDOrCCEncounter(visit,m,ACEP21Elements.Coagulopathies,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
      ||  wasDiagnosedBeforeEDOrCCEncounter(visit,m,ACEP21Elements.Thrombocytopenia,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
      ||  wasMedicationBeforeEDOrCCEncounter(visit,m,ACEP21Elements.Anticoagulant,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
      ||  isDiagnosisDuringEDOrCCEncounter(visit,m,ACEP21Elements.Pregnancy,ACEP21Elements.Pregnancy_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date)
      ||  wasDiagnosedBeforeEDOrCCEncounter(visit,m,ACEP21Elements.Pulmonary_And_Gastrointestional_Hemorrhage,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
      ||  wasDiagnosedBeforeEDOrCCEncounter(visit,m,ACEP21Elements.Atrial_Fibrillation,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
      ||  isMedicationDuringEDOrCCEncounter(visit,m,ACEP21Elements.Anticoagulant,ACEP21Elements.Anticoagulant_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date)
      ||  isDiagnosisDuringEDOrCCEncounter(visit,m,ACEP21Elements.Trauma,ACEP21Elements.Trauma_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date)
      ||  (
                isVisitTypeIn(visit,m
                  ,ACEP21Elements.Emergency_Department_Visit
                  ,ACEP21Elements.Critical_Care_Evaluation_And_Management)
            &&  (     isEncounterPerformedEDOrCCEncounter(visit,m,ACEP21Elements.Emergency_Department_Visit,ACEP21Elements.Left_Before_Treatment_Completion)
                  ||  isEncounterPerformedEDOrCCEncounter(visit,m,ACEP21Elements.Critical_Care_Evaluation_And_Management,ACEP21Elements.Left_Before_Treatment_Completion)
                )
          )
    )
  }


/*-------------------------------------------------------------------------------------------------------------------------
Emergency department visits during which coagulation studies (PT, PTT, or INR tests) were ordered by an emergency care provider
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
          isLaboratoryTestOrderDuringEDOrCCEncounter(visit,m,ACEP21Elements.Prothrombin_Time,ACEP21Elements.Prothrombin_Time_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date)
      ||  isLaboratoryTestOrderDuringEDOrCCEncounter(visit,m,ACEP21Elements.Activated_Partial_Thromboplastin_Time,ACEP21Elements.Activated_Partial_Thromboplastin_Time_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date)
      ||  isLaboratoryTestOrderDuringEDOrCCEncounter(visit,m,ACEP21Elements.Inr,ACEP21Elements.Inr_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP21Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }
}
