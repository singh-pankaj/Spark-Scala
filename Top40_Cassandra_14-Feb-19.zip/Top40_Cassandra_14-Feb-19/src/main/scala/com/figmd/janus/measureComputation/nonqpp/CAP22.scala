package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAP22
* Measure Title               :- Turn-Around Time (TAT) - Standard biopsies
* Measure Description         :- Percentage of final pathology reports for biopsies that meet the maximum 2 business day turnaround time (TAT) requirement (Report Date – Accession Date ≤ 2 business days).
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- Aanchal.Rai
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object CAP22 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "CAP22"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      CAP22Elements.Specimen_Accession_Date,
      CAP22Elements.Consultation_CATII,
      CAP22Elements.Specimen_Verification_Date,
      CAP22Elements.Pathology_Report_Verified,
      CAP22Elements.Report_Verification_Not_Met
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD )
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//IPP - All final pathology reports for patients, regardless of age, who undergo a biopsy (any biopsy; eg., CPT 88305,
        HCPCS code G0416), including those with special stains, immunohistochemistry (IHC), or molecular studies).
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      wasLaboratoryTestPerformedBeforeEncounter(visit,m,CAP22Elements.Specimen_Accession_Date,patientHistoryBroadcastList)
      &&
      (
      isLaboratoryTestPerformedOnEncounter(visit,m, CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
      ||
        (
          isLaboratoryTestPerformedOnEncounter(visit,m, CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
          &&
          isLaboratoryTestPerformedOnEncounter(visit,m, CAP22Elements.IHC_Or_Molecular_Studies_Or_Special_Stains)
        )
      )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//Exclusion - Biopsy associated with any other specimen type (i.e., CPT: 88307, 88309, 99300, 88304).
              Cytopathology cases (ie., Cell blocks) (CPT©: 88173, 88112).
              Cases requiring decalcification (CPT 88311).
  -----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      ( isLaboratoryTestConcurrent(visit,m,CAP22Elements.Special_Handling_Cases_Grp,CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
        ||  (  isLaboratoryTestConcurrent(visit,m,CAP22Elements.Special_Handling_Cases_Grp,CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
        && isLaboratoryTestConcurrent(visit,m,CAP22Elements.Special_Handling_Cases_Grp,CAP22Elements.IHC_Or_Molecular_Studies_Or_Special_Stains)
        )
        )
        ||
        ( isLaboratoryTestConcurrent(visit,m,CAP22Elements.Confirm_More_Than_Just_Standard_88305_Biopsy_Ies_Were_Received,CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
          ||  (  isLaboratoryTestConcurrent(visit,m,CAP22Elements.Confirm_More_Than_Just_Standard_88305_Biopsy_Ies_Were_Received,CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
          && isLaboratoryTestConcurrent(visit,m,CAP22Elements.Confirm_More_Than_Just_Standard_88305_Biopsy_Ies_Were_Received,CAP22Elements.IHC_Or_Molecular_Studies_Or_Special_Stains)
          )
          )
        ||
        ( isLaboratoryTestConcurrent(visit,m,CAP22Elements.Cases_With_Special_Handling,CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
          ||  (  isLaboratoryTestConcurrent(visit,m,CAP22Elements.Cases_With_Special_Handling,CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
          && isLaboratoryTestConcurrent(visit,m,CAP22Elements.Cases_With_Special_Handling,CAP22Elements.IHC_Or_Molecular_Studies_Or_Special_Stains)
          )
          )

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//Numerator - Final pathology report for biopsies in the laboratory/hospital information system with result verified and
              reported by the laboratory, available to the requesting physician(s) within 2 business days.
 -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>

      (  isLaboratoryTestPerformedAfterWithinXBusinessDays(visit,m,CAP22Elements.Specimen_Accession_Date,CAP22Elements.Specimen_Verification_Date,2,patienthistoryList)
        || isLaboratoryTestPerformAfterEncounter(visit,m,CAP22Elements.Specimen_Accession_Date,patienthistoryList,CAP22Elements.Pathology_Report_Verified)
      )
        &&
        !(   isLaboratoryTestPerformAfterEncounter(visit,m,CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305,patienthistoryList,CAP22Elements.Report_Verification_Not_Met)
          ||  (  isLaboratoryTestPerformAfterEncounter(visit,m,CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305,patienthistoryList,CAP22Elements.Report_Verification_Not_Met)
          && isLaboratoryTestPerformAfterEncounter(visit,m,CAP22Elements.IHC_Or_Molecular_Studies_Or_Special_Stains,patienthistoryList,CAP22Elements.Report_Verification_Not_Met)
          )
          )

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//Exception - Cases requiring intra-departmental or extra-departmental consultation.
              Skin excisions with margins coded as 88305.
 -----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>


     (  isLaboratoryTestConcurrent(visit,m,CAP22Elements.Skin_Excision_With_Margin,CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
       ||  (  isLaboratoryTestConcurrent(visit,m,CAP22Elements.Skin_Excision_With_Margin,CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
       && isLaboratoryTestConcurrent(visit,m,CAP22Elements.Skin_Excision_With_Margin,CAP22Elements.IHC_Or_Molecular_Studies_Or_Special_Stains)
       )
     )
       ||
       (  isCommunicationFromProviderToProviderConcurrent(visit,m,CAP22Elements.Confirm_Case_Required_Consultation,CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
         ||  (  isCommunicationFromProviderToProviderConcurrent(visit,m,CAP22Elements.Confirm_Case_Required_Consultation,CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
         && isCommunicationFromProviderToProviderConcurrent(visit,m,CAP22Elements.Confirm_Case_Required_Consultation,CAP22Elements.IHC_Or_Molecular_Studies_Or_Special_Stains)
         )
         )
       || isCommunicationFromProvidertoProvider(visit,m,CAP22Elements.Consultation_CATII,patienthistoryList)
    )
  }
}
