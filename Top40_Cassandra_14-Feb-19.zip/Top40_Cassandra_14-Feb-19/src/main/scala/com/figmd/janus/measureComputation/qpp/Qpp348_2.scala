package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp348
* Measure Title              :- HRS-3 Implantable Cardioverter-Defibrillator (ICD) Complications Rate
* Measure Description        :- Patients with physician-specific risk-standardized rates of procedural complications following the first time implantation of an ICD.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- 1
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp348_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp348_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP348Elements.Implantation_Of_Icd_Grouping,
      QPP348Elements.Removal_Of_Icd,
      QPP348Elements.Documentation_Of_Complications,
      QPP348Elements.Mechanical_Complications_Requiring_Revision,
      QPP348Elements.Additional_Icd_Implantation,
      QPP348Elements.Device_Related_Infection,
      QPP348Elements.Doc_Comp_Not_Met


    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val leastRecentPatientHistoryList = leastRecentPatientList(initialRDD,
      QPP348Elements.Implantation_Of_Icd_Grouping,
      QPP348Elements.Removal_Of_Icd,
      QPP348Elements.Documentation_Of_Complications,
      QPP348Elements.Mechanical_Complications_Requiring_Revision,
      QPP348Elements.Additional_Icd_Implantation,
      QPP348Elements.Device_Related_Infection,
      QPP348Elements.Doc_Comp_Not_Met)

    val leastRecentPatientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastRecentPatientHistoryList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList, leastRecentPatientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*
  All patients aged 65 years and older who have a history of falls (history of falls is defined as 2 or more falls in
  the past year or any fall with injury in the past year). Documentation of patient reported history of falls is sufficient
   */

  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], leastRecentPatientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isAgeAbove(visit, m, true, 65)
        && wasFirstProcedurePerformedWithinXPeriodBeforeEnd(visit, m, QPP348Elements.Implantation_Of_Icd_Grouping, "DAYS", 91, CompareOperator.GREATER_EQUAL, leastRecentPatientHistoryBroadcastList)
    )
  }

  //Hospice services for patient provided any time during the measurement period
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
      isProcedurePerformed(visit, m, QPP348Elements.Removal_Of_Icd, patientHistoryBroadcastList)
    )
  }

  //Patients who had a risk assessment for falls completed within 12 months
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
        wasDiagnosedAfterXDaysProcedure(visit, m, QPP348Elements.Implantation_Of_Icd_Grouping, QPP348Elements.Documentation_Of_Complications, 90, patientHistoryBroadcastList)
          || (
          wasDiagnosedAfterXDaysProcedure(visit, m, QPP348Elements.Implantation_Of_Icd_Grouping, QPP348Elements.Mechanical_Complications_Requiring_Revision, 90, patientHistoryBroadcastList)
            || wasProcedurePerformedStartsXDaysAfterEndOfProcedure(visit, m, QPP348Elements.Additional_Icd_Implantation, QPP348Elements.Implantation_Of_Icd_Grouping, 90, patientHistoryBroadcastList)
            || wasDiagnosedAfterXDaysProcedure(visit, m, QPP348Elements.Implantation_Of_Icd_Grouping, QPP348Elements.Device_Related_Infection, 90, patientHistoryBroadcastList)
          )

        )
        && !wasDiagnosedAfterXDaysProcedure(visit, m, QPP348Elements.Implantation_Of_Icd_Grouping, QPP348Elements.Doc_Comp_Not_Met, 90, patientHistoryBroadcastList)
    )
  }


}

