package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP342Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp 342
* Measure Title              :- Pain Brought Under Control Within 48 Hours
* Measure Description        :- Patients aged 18 and older who report being uncomfortable because of pain at the initial assessment (after admission to palliative care services) who report pain was brought to a comfortable level within 48 hours
* Calculation Implementation :- Patient specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp342 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp342"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP342Elements.Pain_At_Comfortable_Level

    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }


  // IPP-Denominator criteria
  /* Patients aged 18 and older admitted to palliative care services who communicated and self-reported that they were uncomfortable due to pain at the initial assessment (by responding “yes” when asked if they were uncomfortable because of pain). */

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m, QPP342Elements.Transitional_Care_Management,
        QPP342Elements.Care_Services_In_Long_Term_Residential_Facility,
        QPP342Elements.Home_Healthcare_Services,
        QPP342Elements.Hospital_Inpatient_Visit___Initial,
        QPP342Elements.Subsequent_Hospital_Care,
        QPP342Elements.Nursing_Facility_Visit
      )
        && isVisitTypeIn(visit, m, QPP342Elements.Admission_To_Palliative_Care)
        && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP342Elements.Undertsand_The_Language)
        && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP342Elements.Patient_Self_Reported_Pain)

    )
  }


  // Numerator criteria
  /* Patients whose pain was brought to a comfortable level within 48 hours of initial assessment (after admission to palliative care services). */

  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ipp.filter(visit =>
      (
        isInterventionPerformedOnEncounter(visit, m, QPP342Elements.Pain_Brought_To_A_Comfortable_Level)
          && isInterventionPerformedAfterEncounterWithinXHours(visit, m, QPP342Elements.Pain_At_Comfortable_Level, 48, patientHistoryBroadcastList)
        )
        && !isInterventionPerformedOnEncounter(visit, m, QPP342Elements.Pain_Comf_Level_Not_Met)
    )
  }


}
