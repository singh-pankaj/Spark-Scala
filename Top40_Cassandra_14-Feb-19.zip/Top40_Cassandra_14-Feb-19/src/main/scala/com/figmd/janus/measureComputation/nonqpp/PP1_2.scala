package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty,PP1Elements,TimeOperator,CalenderUnit,CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PP1_2
* Measure Title               :- Annual Monitoring for Patients on Persistent Medications (MPM)
* Measure Description         :- This measure assesses the percentage of patients 18 years of age and older who received a least 180 treatment days of ambulatory medication therapy for a select therapeutic agent during the measurement year and at least one therapeutic monitoring event for the therapeutic agent in the measurement year. Report the following three rates and a total rate:
- Rate 1: Annual Monitoring for patients on angiotensin converting enzyme (ACE) inhibitors or angiotensin receptor blockers (ARB): At least one serum potassium and a serum creatinine therapeutic monitoring test in the measurement year.
- Rate 2: Annual monitoring for patients on digoxin: At least one serum potassium, one serum creatinine and a serum digoxin therapeutic monitoring test in the measurement year.
- Rate 3: Annual monitoring for patients on diuretics: At least one serum potassium and a serum creatinine therapeutic monitoring test in the measurement year.
- Total rate (the sum of the three numerators divided by the sum of the three denominators)."
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KIRTI_RAUT_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :-Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object PP1_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "PP1_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      PP1Elements.Inpatient_Encounter,
      PP1Elements.Creatinine_Level,
      PP1Elements.Creatinine_Level_Lab,
      PP1Elements.Potassium_Level,
      PP1Elements.Potassium_Level_Lab,
      PP1Elements.Digoxin_Level,
      PP1Elements.Digoxin_Level_Lab,
      PP1Elements.Digoxin_Date,
      PP1Elements.Digoxin_Stop_Date

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(sparkSession,initialRDD,patientHistoryBroadcastList,patientHistoryRDD:RDD[CassandraRow])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }



  /*-----------------------------------------------------------------------------------------------------------------------
  Patients age 18 and older as of the end of the measurement year (e.g., December 31) who are on selected persistent medications (ACE Inhibitors/ARB, Digoxin or Diuretics.)
  -----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(sparkSession: SparkSession,initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryRDD:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val MedicationList:List[(String,String)] = List((PP1Elements.Digoxin_Date,PP1Elements.Digoxin_Stop_Date))

    val MedicationResult=cumulative(patientHistoryRDD, m,MedicationList,CalenderUnit.DAY,CalenderUnit.DAY,180,TimeOperator.AFTERorEQUAL)

    val MedicationResultBroadcastList: Broadcast[List[(String,String,Double)]] = sparkSession.sparkContext.broadcast(MedicationResult)
    initialRDD.filter(
      visit =>
        isPatientAdult(visit,m)
          &&
          isVisitTypeIn(visit,m,
            PP1Elements.Psych_Visit___Psychotherapy,
            PP1Elements.Group_Psychotherapy,
            PP1Elements.Psych_Enc,
            PP1Elements.Office_Visit,
            PP1Elements.Bh_Outpatient_Psychotherapy,
            PP1Elements.Psychoanalysis
          )
          &&
          getCommulativeResult(visit,m,PP1Elements.Digoxin,180,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
    )  }

  /*-----------------------------------------------------------------------------------------------------------------------
Inpatient encounters only.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      isEncounterPerformed(visit,m,PP1Elements.Inpatient_Encounter,patientHistoryBroadcastList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

This measure is reported as three rates and a total rate.
Rate 1: Annual monitoring for patients on ACE inhibitors or ARBs: the number of patients with at least one serum potassium and serum creatinine therapeutic monitoring test in the measurement year.
Rate 2: Annual monitoring for patients on digoxin: the number of patients with at least one serum potassium, one serum creatinine, and a serum digoxin therapeutic monitoring test in the measurement year.
Rate 3: Annual monitoring for patients on diuretics: the number of patients with at least one serum potassium and serum creatinine therapeutic monitoring test in the measurement year.
Total rate: sum of the 3 numerators.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>

      (    isLaboratoryTestPerformed(visit,m,PP1Elements.Creatinine_Level,patientHistoryBroadcastList)
        ||isLaboratoryTestPerformed(visit,m,PP1Elements.Creatinine_Level_Lab,patientHistoryBroadcastList)
        )
        &&

        (     isLaboratoryTestPerformed(visit,m,PP1Elements.Potassium_Level,patientHistoryBroadcastList)
          ||isLaboratoryTestPerformed(visit,m,PP1Elements.Potassium_Level_Lab,patientHistoryBroadcastList)
          )
        &&

        (     isLaboratoryTestPerformed(visit,m,PP1Elements.Digoxin_Level,patientHistoryBroadcastList)
          ||isLaboratoryTestPerformed(visit,m,PP1Elements.Digoxin_Level_Lab,patientHistoryBroadcastList)
          )

    )
  }
}