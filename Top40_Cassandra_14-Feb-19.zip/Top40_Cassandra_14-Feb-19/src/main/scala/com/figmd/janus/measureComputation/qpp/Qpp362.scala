package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP362Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 362
* Measure Title              :- Optimizing Patient Exposure to Ionizing Radiation: Computed Tomography (CT) Images Available for Patient Follow-up and Comparison Purposes
* Measure Description        :- Percentage of final reports for computed tomography (CT) studies performed for all
                                patients, regardless of age, which document that Digital Imaging and Communications in
                                Medicine (DICOM) format image data are available to nonaffiliated external healthcare
                                facilities or entities on a secure, media free, reciprocally searchable basis with
                                patient authorization for at least a 12-month period after the study
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher score equals better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp362 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp362"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP362Elements.Dicom_Format
      , QPP362Elements.Secure
      , QPP362Elements.Media_Free
      , QPP362Elements.Reciprocal_Search
      , QPP362Elements.Patient_Authorization
      , QPP362Elements.Report_Available_For_12_Month_Period
      , QPP362Elements.Appropriate_Documentation_Of_Dicom_Image_Data
      , QPP362Elements.Dicom_Reason_Not_Specified
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }
  /*------------------------------------------------------------------------------
    All final reports for patients, regardless of age, undergoing a CT procedure
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)


    initialRDD.filter(visit =>
      isDiagnosticStudyOnEncounter(visit,m,QPP362Elements.Ct_Imaging)
    )
  }

  /*------------------------------------------------------------------------------
    Final reports for CT studies which document that DICOM format image data are available to non-affiliated external
    healthcare facilities or entities on a secure, media-free, reciprocally searchable basis with patient authorization
    for at least a 12-month period after the study
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      (
          (
             wasInterventionPerformedAfterEncounterinHistory(visit,m,QPP362Elements.Ct_Imaging,patientHistoryBroadcastList,QPP362Elements.Dicom_Format)
          && wasInterventionPerformedAfterEncounterinHistory(visit,m,QPP362Elements.Ct_Imaging,patientHistoryBroadcastList,QPP362Elements.Secure)
          && wasInterventionPerformedAfterEncounterinHistory(visit,m,QPP362Elements.Ct_Imaging,patientHistoryBroadcastList,QPP362Elements.Media_Free)
          && wasInterventionPerformedAfterEncounterinHistory(visit,m,QPP362Elements.Ct_Imaging,patientHistoryBroadcastList,QPP362Elements.Reciprocal_Search)
          && wasInterventionPerformedAfterEncounterinHistory(visit,m,QPP362Elements.Ct_Imaging,patientHistoryBroadcastList,QPP362Elements.Patient_Authorization)
          && wasInterventionPerformedAfterEncounterinHistory(visit,m,QPP362Elements.Ct_Imaging,patientHistoryBroadcastList,QPP362Elements.Report_Available_For_12_Month_Period)
        )
      ||  wasInterventionPerformedAfterEncounterinHistory(visit,m,QPP362Elements.Ct_Imaging,patientHistoryBroadcastList,QPP362Elements.Appropriate_Documentation_Of_Dicom_Image_Data)
    )
    && isInterventionPerformed(visit,m,QPP362Elements.Dicom_Reason_Not_Specified,patientHistoryBroadcastList)
    )
  }
}