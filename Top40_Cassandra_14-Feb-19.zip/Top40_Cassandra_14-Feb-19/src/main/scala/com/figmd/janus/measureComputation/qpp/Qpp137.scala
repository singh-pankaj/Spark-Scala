package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP137Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*--------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 137
* Measure Title              :- Melanoma: Continuity of Care – Recall System
* Measure Description        :- Percentage of patients, regardless of age, with a current diagnosis of melanoma or a history of melanoma whose information was entered, at least once within a 12 month period, into a recall system that includes:
                                • A target date for the next complete physical skin exam, AND
                                • A process to follow up with patients who either did not make an appointment within the specified timeframe or who missed a scheduled appointment
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp137 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp137"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //Backtracking List
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP137Elements.Patient_Information_In_Recall_System_Grp,
      QPP137Elements.Patient_Identifier_Grp,
      QPP137Elements.Patient_Contact_Information,
      QPP137Elements.Cancer_Diagnosis_Es__In_Recall_System_Grp,
      QPP137Elements.Target_Date_For_Complete_Physical_Exam_Grp,
      QPP137Elements.Patient_Info_System_Reason,
      QPP137Elements.Melanoma_Monitored_By_Another_Provider
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect.toList)


    //  Filter IPP-
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      // Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateB = ippRDD.subtract(metRDD)
      intermediateB.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateB, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : All patients, regardless of age, with a current diagnosis of melanoma or a history of melanoma
----------------------------------------------------------------------------------------------------------------------------*/


  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isVisitTypeIn(visit, m, QPP137Elements.Office_Visit, QPP137Elements.Outpatient_Consultation)
        && (isDiagnosedOnEncounter(visit, m, QPP137Elements.Melanoma)
        || isDiagnosedOnEncounter(visit, m, QPP137Elements.History_Of_Melanoma)
        )
        && !isTeleHealthEncounterPerformed(visit, m, QPP137Elements.Office_Visit_Telehealth_Modifier_Grp, QPP137Elements.Outpatient_Consultation_Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP137Elements.Pos_02)
    )

  }


  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Patients whose information is entered, at least once within a 12 month period, into a recall system that includes:

• A target date for the next complete physical exam
• A process to follow up with patients who either did not make an appointment within the specified timeframe or who missed scheduled appointment
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ipp.filter(visit =>
      (  isInterventionPerformed(visit, m, QPP137Elements.Patient_Information_In_Recall_System_Grp, patientHistoryBroadcastList)
        || (
               isPatientCharacteristic(visit, m, QPP137Elements.Patient_Identifier_Grp, patientHistoryBroadcastList)
            && isPatientCharacteristic(visit, m, QPP137Elements.Patient_Contact_Information, patientHistoryBroadcastList)
            && isInterventionPerformed(visit, m, QPP137Elements.Cancer_Diagnosis_Es__In_Recall_System_Grp, patientHistoryBroadcastList)
            && (   isPhysicalExamOrdered(visit, m, QPP137Elements.Target_Date_For_Complete_Physical_Exam_Grp, patientHistoryBroadcastList)
                || isInterventionPerformed(visit, m, QPP137Elements.Follow_Up_Missed_Appointment_Grp, patientHistoryBroadcastList)
               )
          )
    )
        && !isInterventionNotDoneDuringEncounter(visit, m, QPP137Elements.Patient_Info_Reason_Not_Specified)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------------
Denominator Exceptions : Documentation of system reason(s) for not entering patient’s information into a recall system
(e.g., melanoma being monitored by another physician provider)
----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermedaiateRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermedaiateRdd.filter(visit =>
      isInterventionNotDone(visit, m, QPP137Elements.Patient_Info_System_Reason, patientHistoryBroadcastList)
        || isInterventionNotDone(visit, m, QPP137Elements.Melanoma_Monitored_By_Another_Provider, patientHistoryBroadcastList)
    )
  }
}
