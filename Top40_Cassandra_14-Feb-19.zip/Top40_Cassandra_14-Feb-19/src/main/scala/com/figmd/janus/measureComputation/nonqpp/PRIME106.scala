package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,PRIME106Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PRIME106
* Measure Title               :- All Patients Who Die an Expected Death with an ICD that Has Been Deactivated
* Measure Description         :- Percentage of adult 18 and older patients in any care setting who die an expected death from cancer or other terminal illness and who have an implantable cardioverter-defibrillator (ICD) in place at the time of death that was deactivated prior to death or there is documentation why it was not deactivated
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SANKET.DHAPTE
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.8
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.8
----------------------------------------------------------------------------------------------------------------------------*/

object PRIME106 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "PRIME106"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
                                                                        ,PRIME106Elements.Implantable_Cardioverter_Defibrillator_Icd
                                                                        ,PRIME106Elements.Icd_Deactivation
                                                                        ,PRIME106Elements.Icd_Documented_Reasons
                                              )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
 	Patients who died an expected death who have an ICD in place
 	-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
         isPatientAdult(visit,m)
      && wasDeviceAppliedBeforeOrEqualEncounter(visit,m,PRIME106Elements.Implantable_Cardioverter_Defibrillator_Icd,patientHistoryBroadcastList)
      && isPatientCharacteristicDuringEncounter(visit,m,PRIME106Elements.Expired)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
 	Patients who have their ICDs deactivated prior to death or have documentation of why this was not done
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
         wasProcedurePerformedBeforeEncounter(visit,m,PRIME106Elements.Icd_Deactivation,patientHistoryBroadcastList)
      || wasProcedurePerformedBeforeEncounter(visit,m,PRIME106Elements.Icd_Documented_Reasons,patientHistoryBroadcastList)

    )
  }

}
