package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,AAD32Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD32
* Measure Title              :- Basal Cell Carcinoma/Squamous Cell Carcinoma: Surgical Safety Post-Operative Communication
* Measure Description        :- Percentage of patients with documented communication from the clinician's practice
*                               within 15 days of a surgical encounter for BCC/ SCC.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- VRUSHALI GHOLAP
----------------------------------------------------------------------------------------------------------------------------*/

object AAD32 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "AAD32"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //getPatientHistoryRDD
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD
        ,AAD32Elements.Cumulative_Follow_Up_Grp
        ,AAD32Elements.Follow_Up_Status_Grp
      )
      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

/*------------------------------------------------------------------------------
  All patients undergoing a scalpel-based surgical procedure for non-melanoma skin cancer located on the trunk or upper extremities
  (codes 17313 through 17315, 11600 through 11646, and 17260 through 17266) within the reporting period.
 ------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
         isDiagnosedOnEncounter(visit,m,AAD32Elements.Bcc_Or_Scc_Grp)
      && isProcedurePerformedDuringEncounter(visit,m,AAD32Elements.Scalpel_Based_Surgery_Grp)
      //RDD have records only from measurement period thus not checked procedure during encounter.
        )
  }

/*------------------------------------------------------------------------------
  The number of patients that were contacted by the clinician's practice within 15 days of the surgical encounter
  and documentation of the communication is made in the patient's chart.
 ------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
          wasCommunicationDoneAfterProcedureWithinXDays(visit,m,AAD32Elements.Scalpel_Based_Surgery_Grp,AAD32Elements.Scalpel_Based_Surgery_Grp_Date,15,patientHistoryBroadcastList,AAD32Elements.Cumulative_Follow_Up_Grp)
       && wasCommunicationDoneAfterProcedureWithinXDays(visit,m,AAD32Elements.Scalpel_Based_Surgery_Grp,AAD32Elements.Scalpel_Based_Surgery_Grp_Date,15,patientHistoryBroadcastList,AAD32Elements.Follow_Up_Status_Grp)
    )
  }

}
