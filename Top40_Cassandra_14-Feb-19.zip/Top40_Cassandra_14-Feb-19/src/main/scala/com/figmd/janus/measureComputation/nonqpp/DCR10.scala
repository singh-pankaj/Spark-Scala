package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, CalenderUnit, DCR10Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- DCR10
* Measure Title               :- Diabetes: Advance Care Plan
* Measure Description         :- Percentage of patients aged 65 years and older with diabetes who have an advance care plan or surrogate decision maker documented in the medical record or documentation in the
                                 medical record that an advance care plan was discussed but the patient did not wish or was not able to name a surrogate decision maker or provide an advance care plan
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KAJAL_JADHAO_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object DCR10 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "DCR10"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,DCR10Elements.Acc_Encounter_Code_Set
      ,DCR10Elements.Diabetes
      ,DCR10Elements.Hospice_Care
      ,DCR10Elements.Hospice_Services_Snomedct
      ,DCR10Elements.Documentation_Of_Advance_Care_Plan

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
        isAgeAboveBeforeStart(visit, m, true, 18, CalenderUnit.MONTH)
          && isEncounterPerformed(visit,m,DCR10Elements.Acc_Encounter_Code_Set,patientHistoryBroadcastList)
          && wasDiagnosedBeforeOrEqualEncounter(visit,m,DCR10Elements.Diabetes,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      wasInterventionPerformedBeforeEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,DCR10Elements.Hospice_Care)
        ||wasInterventionPerformedBeforeEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,DCR10Elements.Hospice_Services_Snomedct)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      wasInterventionPerformedBeforeEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,DCR10Elements.Documentation_Of_Advance_Care_Plan)



    )
  }


}