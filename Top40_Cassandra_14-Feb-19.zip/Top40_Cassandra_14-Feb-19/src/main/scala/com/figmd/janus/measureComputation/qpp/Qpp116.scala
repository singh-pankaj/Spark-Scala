package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP116Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP116
* Measure Title              :- Avoidance of Antibiotic Treatment in Adults With Acute Bronchitis
* Measure Description        :- The percentage of adults 18–64 years of age with a diagnosis of acute bronchitis who were not prescribed or dispensed an antibiotic prescription
* Calculation Implementation :- Episode-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- 1
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp116 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP116"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP116Elements.Antibiotics_Prescribed,
      QPP116Elements.Decision_To_Admit_To_Hospital_Inpatient,
      QPP116Elements.Decision_To_Admit_To_Hospital_Inpatient,
      QPP116Elements.Hospice_Services,
      QPP116Elements.Hospice_Care,
      QPP116Elements.Hospice_Services_Snomedct,
      QPP116Elements.Antibiotics_Met,
      QPP116Elements.Antibiotics,
      QPP116Elements.Antibiotics_Not_Met
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      // Filter denominator Exclusions
      val exclusionRDD = getDenominatorExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      //eligible initial population RDD
      val intermediateRdd = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateRdd.cache()
      // Met rdd
      val metRDD = getMet(sparkSession, intermediateRdd, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRdd, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  * All patients aged 18 through 64 years of age with an outpatient, observation or emergency department (ED) visit with a diagnosis of acute bronchitis during the measurement period
  *-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    rdd.filter(visit=>
      isAgeAbove(visit,m,true)
        && isAgeBelow(visit,m,false,65)
        &&
        isVisitTypeIn(visit,m,QPP116Elements.Discharge_Services__Observation_Care,
          QPP116Elements.Hospital_Observation_Care___Initial,
          QPP116Elements.Hospital_Outpatient_Clinic_Visit,
          QPP116Elements.Home_Healthcare_Services,
          QPP116Elements.Annual_Wellness_Visit,
          QPP116Elements.Initial_Preventive_Physical_Examination,
          QPP116Elements.Clinic_Visit,
          QPP116Elements.Work_Related_Or_Medical_Disability_Examination,
          QPP116Elements.Preventive_Medicine_Evaluation_And_Management,
          QPP116Elements.Home_Visit,
          QPP116Elements.Observation_Care_Discharge_Day_Management,
          QPP116Elements.Emergency_Department_Visit,
          QPP116Elements.Office_Visit)
        && isDiagnosedDuringEncounter(visit,m,QPP116Elements.Acute_Bronchitis)

    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   Observation or ED visits that result in an inpatient admission
  OR
  Documentation of medical reason(s) for prescribing or dispensing antibiotic (e.g., intestinal infection, pertussis, bacterial infection, Lyme disease, otitis media, acute sinusitis, acute pharyngitis, acute tonsillitis, chronic sinusitis, infection of the pharynx/larynx/tonsils/adenoids, prostatitis, cellulitis/ mastoiditis/bone infections, acute lymphadenitis, impetigo, skin staph infections, pneumonia, gonococcal infections/venereal disease (syphilis, chlamydia, inflammatory diseases [female reproductive organs]), infections of the kidney, cystitis/UTI, acne, HIV disease/asymptomatic HIV, cystic fibrosis, disorders of the immune system, malignancy neoplasms, chronic bronchitis,
  emphysema, bronchiectasis, extrinsic allergic alveolitis, chronic airway obstruction, chronic obstructive asthma, pneumoconiosis and other lung disease due to external agents, other diseases of the respiratory system, and tuberculosis.
  OR
  Patients who use hospice services any time during the measurement period.
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getDenominatorExclusionRdd(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    rdd.filter(visit=>
      wasInterventionPerformedStartAfterEncounter(visit,m,QPP116Elements.Decision_To_Admit_To_Hospital_Inpatient,QPP116Elements.Decision_To_Admit_To_Hospital_Inpatient,1,patientHistoryBroadcastList)
      ||wasInterventionPerformedInHistory(visit,m,QPP116Elements.Hospice_Services,patientHistoryBroadcastList)
      ||(
          wasInterventionPerformedInHistory(visit,m,QPP116Elements.Hospice_Care,patientHistoryBroadcastList)||
          wasInterventionPerformedInHistory(visit,m,QPP116Elements.Hospice_Services_Snomedct,patientHistoryBroadcastList)
        )
      ||isDiagnosedDuringEncounter(visit,m,QPP116Elements.Medical_Exclusions)
      ||(
          isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Acne)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Acute_Lymphadenitis)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Acute_Pharyngitis)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Acute_Tonsillitis)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Bronchiectasis)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Cellulitis_Mastoiditis_And_Other_Bone_Infections)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Chlamydia)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Chronic_Airway_Obstruction)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Chronic_Obstructive_Asthma)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Chronic_Bronchitis)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Cystic_Fibrosis)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Cystitis_Or_Urinary_Tract_Infection)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Emphysema)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Extrinsic_Allergic_Alveolitis)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Gonococcal_Infections_And_Venereal_Diseases)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Hiv_Disease__Asymptomatic_Hiv)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Immune_Deficiency)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Impetigo)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Infection_Of_The_Kidney)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Infections_Of_The_Pharynx__Larynx__Tonsils_And_Adenoids)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Inflammatory_Diseases_Of_Female_Reproductive_Organs)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Intestinal_Infection)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Lyme_Disease)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Malignant_Neoplasms)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Otitis_Media)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Pneumoconiosis)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Pneumonia)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Skin_Staph_Infections)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Syphilis)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Tuberculosis)
        ||isMedicationOrderedDuringEncounter(visit,m,QPP116Elements.Bacterial_Infection)
      )
      ||wasMedicationStartsBeforeEncounterWithInXDays(visit,m,QPP116Elements.Antibiotics_Prescribed,30,patientHistoryBroadcastList,QPP116Elements.Antibiotics_Prescribed)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  * Patients who were not prescribed or dispensed antibiotics on or within 3 days of the initial date of service
  * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getMet(spark:SparkSession,rdd: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    rdd.filter(visit=>
      (wasAssessmentStartsAfterEncounterInXDays(visit,m,QPP116Elements.Antibiotics_Met,QPP116Elements.Antibiotics_Met_Date,3,patientHistoryBroadcastList)
      ||
      !wasMedicationStartsBeforeEncounterWithInXDays(visit,m,QPP116Elements.Antibiotics,3,patientHistoryBroadcastList,QPP116Elements.Antibiotics))
      &&
        wasAssessmentStartsAfterEncounterInXDays(visit,m,QPP116Elements.Antibiotics_Not_Met,QPP116Elements.Antibiotics_Not_Met_Date,3,patientHistoryBroadcastList)


    )
  }


}
