package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp352
* Measure Title              :- Total Knee Replacement: Preoperative Antibiotic Infusion with Proximal Tourniquet
* Measure Description        :- Percentage of patients regardless of age undergoing a total knee replacement who had the prophylactic antibiotic
                                completely infused prior to the inflation of the proximal tourniquet.
 *
*
* Calculation Implementation :- visit-specific (procedure-specific)
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Sawant
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp352 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp352"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP352Elements.Total_Knee_Replacement
      , QPP352Elements.Infusion_Of_Prophylactic_Antibiotic
      , QPP352Elements.Prophylactic_Antibiotic
      , QPP352Elements.Infusion_Prophylactic_Medical_Reason
      , QPP352Elements.Infusion_Prophylactic_Exceptions

    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  /*-------------------------------------------------------------------------------------------------------------------------
   Patients regardless of age undergoing a total knee replacement performed.
   * ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
      isProcedurePerformed(visit,m,QPP352Elements.Total_Knee_Replacement,patientHistoryBroadcastList)
    )
  }
  /*-------------------------------------------------------------------------------------------------------------------------
  Patients who had the prophylactic antibiotic completely infused prior to the inflation of the proximal tourniquet (tourniquet around the proximal thigh).
   * ----------------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    denominatorRDD.filter(visit =>
    isMedicationAdministered(visit,m,QPP352Elements.Infusion_Of_Prophylactic_Antibiotic,patientHistoryBroadcastList)
    || (  isProcedurePerformedDuringProcedure(visit,m,QPP352Elements.Inflation_Of_Proximal_Tourniquet,QPP352Elements.Inflation_Of_Proximal_Tourniquet_Date,QPP352Elements.Total_Knee_Replacement,QPP352Elements.Total_Knee_Replacement_Date)
       || wasMedicationAdministeredBeforeStartOfProcedure(visit,m,QPP352Elements.Inflation_Of_Proximal_Tourniquet,QPP352Elements.Prophylactic_Antibiotic,patientHistoryBroadcastList)
       )
    )
  }
  /*-------------------------------------------------------------------------------------------------------------------------
   Documentation of medical reason(s) for not completely infusing the prophylactic antibiotic prior to the inflation of the proximal tourniquet (e.g., a tourniquet was not used).
   * ----------------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermediateForException.filter(visit=>
         isMedicationAdministeredNotDoneForReason(visit,m,QPP352Elements.Infusion_Prophylactic_Medical_Reason,patientHistoryBroadcastList)
     ||  wasMedicationAdministeredNotDoneWithReasonBeforeStartOfProcedure(visit,m,QPP352Elements.Inflation_Of_Proximal_Tourniquet,QPP352Elements.Infusion_Prophylactic_Exceptions,patientHistoryBroadcastList)
    )
  }
}
