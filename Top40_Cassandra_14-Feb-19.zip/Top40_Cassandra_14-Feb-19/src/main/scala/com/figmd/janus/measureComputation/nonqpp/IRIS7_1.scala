package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{IRIS7Elements, MeasureProperty,CalenderUnit}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- IRIS 7
* Measure Title              :- Amblyopia: Interocular visual acuity
* Measure Description        :- Percentage of newly diagnosed amblyopic patients with one or more of the following:

                                 A. a corrected interocular (or if not reported, the uncorrected) visual acuity
                                 difference < 0.23 logMAR 3- 12 months after first diagnosis of amblyopia

                                 B. an improvement in the corrected visual acuity of the amblyopic eye greater or equal
                                 to 0.30 logMAR 3-12 months after first diagnosis of amblyopia

                                  C. a final visual acuity in the amblyopic eye equal to 20/30 or better (less than or
                                  equal to 0.18 logMar) 3-12 months after first diagnosis of amblyopia

* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 3
* Measure Stratum No.        :- 1
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/


object IRIS7_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS7_1"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, initialRDD
      , IRIS7Elements.Amblyopia
      , IRIS7Elements.Amblyopia__Eye
      , IRIS7Elements.Visual_Acuity_Of_Left_Eye
      , IRIS7Elements.Visual_Acuity_Of_Right_Eye
      , IRIS7Elements.Deprivation_Amblyopia
      , IRIS7Elements.Deprivation_Amblyopia__Eye
      , IRIS7Elements.Infantile_Juvenile_And_Presenile_Cataract
      , IRIS7Elements.Infantile_Juvenile_And_Presenile_Cataract__Eye
      , IRIS7Elements.Aphakia
      , IRIS7Elements.Aphakia__Eye
      , IRIS7Elements.Pseudophakia
      , IRIS7Elements.Pseudophakia__Eye
    ).collect.toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()

    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
    All patients aged between 3 to 7 years with newly diagnosed amblyopia with recognition visual acuity difference
    of > 0.29 logMAR (IOD criterion is to exclude bilateral ametropic amblyopia)
   ----------------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD:RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
        isAgeAboveBeforeStart(visit,m,true,3,CalenderUnit.YEAR)
     && isAgeBelowBeforeStart(visit,m,false,8,CalenderUnit.YEAR)
     && isDiagnosedOnEncounter(visit,m,IRIS7Elements.Amblyopia)
     && isDiagnosedWithinXMonths(visit,m,IRIS7Elements.Amblyopia,6,patientHistoryList)
     && isPhysicalExamPerformedDuringEncounter(visit,m,IRIS7Elements.Visual_Acuity_Of_Left_Eye)
     && isPhysicalExamPerformedDuringEncounter(visit,m,IRIS7Elements.Visual_Acuity_Of_Right_Eye)
     && isDifferenceInPhysicalExam(visit,m,IRIS7Elements.Visual_Acuity_Of_Left_Eye,IRIS7Elements.Visual_Acuity_Of_Right_Eye,0.30)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
    Patients with diagnosis of deprivation amblyopia, cataract, aphakia, or pseudophakia
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
          (
               isDiagnosedWithInHistory(visit,m,IRIS7Elements.Deprivation_Amblyopia,patientHistoryList)
           &&  checkEyeElementBeforeDiagnosisEyesElement(visit,m,IRIS7Elements.Deprivation_Amblyopia__Eye,patientHistoryList,IRIS7Elements.Amblyopia__Eye)
          )
      ||  (
              isDiagnosedWithInHistory(visit,m,IRIS7Elements.Infantile_Juvenile_And_Presenile_Cataract,patientHistoryList)
           && checkEyeElementBeforeDiagnosisEyesElement(visit,m,IRIS7Elements.Infantile_Juvenile_And_Presenile_Cataract__Eye,patientHistoryList,IRIS7Elements.Amblyopia__Eye)
          )
      ||  (
          isDiagnosedWithInHistory(visit,m,IRIS7Elements.Aphakia,patientHistoryList)
          &&  checkEyeElementBeforeDiagnosisEyesElement(visit,m,IRIS7Elements.Aphakia__Eye,patientHistoryList,IRIS7Elements.Amblyopia__Eye)
          )
      ||
          (
          isDiagnosedWithInHistory(visit,m,IRIS7Elements.Pseudophakia,patientHistoryList)
          &&  checkEyeElementBeforeDiagnosisEyesElement(visit,m,IRIS7Elements.Pseudophakia__Eye,patientHistoryList,IRIS7Elements.Amblyopia__Eye)
           )
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
  Patients with interocular visual acuity difference of < 0.23 logMAR* or an improvement of three or more Snellen lines
  (> or = 0.30 logMAR)** in the amblyopic eye or a final visual acuity in the amblyopic eye of 20/30 or better
  (< or = 0.18 logMAR)*** recorded between 3 and 12 months after first use of amblyopia diagnosis code

  *Difference in visual acuity values between right and left eye (inter-eye)

  **Difference between baseline and visual acuity at 3-12 months in the amblyopic eye (intra-eye)

  ***Absolute visual acuity, not a difference
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      isDifferenceInPhysicalExamPerformedInRangeMonths(visit,m,IRIS7Elements.Amblyopia,IRIS7Elements.Visual_Acuity_Of_Left_Eye,IRIS7Elements.Visual_Acuity_Of_Right_Eye,0.23,3,12,0,patientHistoryList)
    )
  }
}
