package com.figmd.janus.measureComputation.ecqm
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ECQM50V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 50
* Measure Title              :-Closing the Referral Loop: Receipt of Specialist Report
* Measure Description        :- Percentage of patients with referrals, regardless of age, for which the referring provider receives a report from the provider to whom the patient was referred
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm50V7 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Ecqm50V7"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryList = getPatientHistory(sparkSession,initialRDD,
      ECQM50V7Elements.Referral,
      ECQM50V7Elements.Consultant_Report
    ).collect().toList

    val leastPatientHistoryList=leastRecentPatientList(initialRDD,ECQM50V7Elements.Referral)
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    val leastRecentPatientHistoryBroadcastList:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastPatientHistoryList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList,leastRecentPatientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      leastRecentPatientHistoryBroadcastList.destroy()
    }
  }

  //Number of patients, regardless of age, who were referred by one provider to another provider, and who had a visit during the measurement period
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]],leastRecentPatientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
      wasFirstProcedurePerformed(visit,m,ECQM50V7Elements.Referral,leastRecentPatientHistoryList)
        &&  isVisitTypeIn(visit,m,
        ECQM50V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,
        ECQM50V7Elements.Preventive_Care__Established_Office_Visit__0_To_17,
        ECQM50V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
        ECQM50V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
        ECQM50V7Elements.Office_Visit,
        ECQM50V7Elements.Ophthalmological_Services

      )

    )
  }

  //Number of patients with a referral, for which the referring provider received a report from the provider to whom the patient was referred
  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>

      wasCommunicationFromProvidertoProviderAfterEncounter(visit,m,ECQM50V7Elements.Referral_Date,patientHistoryList,ECQM50V7Elements.Consultant_Report)



    )
  }

}