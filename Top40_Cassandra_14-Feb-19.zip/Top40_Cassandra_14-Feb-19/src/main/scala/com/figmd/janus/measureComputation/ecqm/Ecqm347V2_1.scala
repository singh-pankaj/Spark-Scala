package com.figmd.janus.measureComputation.ecqm

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.{MeasureUpdate}
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS347v2
* Measure Title              :- Statin Therapy for the Prevention and Treatment of Cardiovascular Disease
* Measure Description        :- "Percentage of the following patients - all considered at high risk of cardiovascular events
                                 - who were prescribed or were on statin therapy during the measurement period:
                                 -Adults aged >= 21 years who were previously diagnosed with or currently have an active
                                 diagnosis of clinical atherosclerotic cardiovascular disease (ASCVD); OR
                                 -Adults aged >= 21 years who have ever had a fasting or direct low-density lipoprotein
                                 cholesterol (LDL-C) level >= 190 mg/dL or were previously diagnosed with or currently have
                                 an active diagnosis of familial or pure hypercholesterolemia; OR
                                 -Adults aged 40-75 years with a diagnosis of diabetes with a fasting or direct LDL-C level
                                  of 70-189 mg/dL"
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 3
* Measure Stratum No.        :- 1
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm347V2_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm347V2_1"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Backtracking List
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD
        ,ECQM347V2Elements.Myocardial_Infarction
        ,ECQM347V2Elements.Cerebrovascular_Disease__Stroke__Tia
        ,ECQM347V2Elements.Atherosclerosis_And_Peripheral_Arterial_Disease
        ,ECQM347V2Elements.Ischemic_Heart_Disease_Or_Coronary_Occlusion__Rupture__Or_Thrombosis
        ,ECQM347V2Elements.Stable_And_Unstable_Angina
        ,ECQM347V2Elements.Pci
        ,ECQM347V2Elements.Cabg_Surgeries
        ,ECQM347V2Elements.Carotid_Intervention
        ,ECQM347V2Elements.Breastfeeding
        ,ECQM347V2Elements.Rhabdomyolysis
        ,ECQM347V2Elements.Low_Intensity_Statin_Therapy
        ,ECQM347V2Elements.Moderate_Intensity_Statin_Therapy
        ,ECQM347V2Elements.High_Intensity_Statin_Therapy
        ,ECQM347V2Elements.Palliative_Care
        ,ECQM347V2Elements.End_Stage_Renal_Disease
        ,ECQM347V2Elements.Hepatitis_A
        ,ECQM347V2Elements.Hepatitis_B
        ,ECQM347V2Elements.Liver_Disease
        ,ECQM347V2Elements.Statin_Allergen).collect.toList
      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

      // Eligible IPP
      val denominatorRDD = getEligibleIpp(ippRDD, patientHistoryBroadcastList)
      denominatorRDD.cache()

      /*// Filter notEligible
      val notEligibleRDD = getSubtractRDD(ippRDD, denominatorRDD)
      notEligibleRDD.cache()*/

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate for Met
      val intermediateMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateException = getSubtractRDD(intermediateMet, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
    All patients aged 21 years and older at the beginning of the measurement period with
    a patient encounter during the measurement period.
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
             isAgeAboveBeforeStart(visit, m ,true,21,CalenderUnit.YEAR)
        &&   isVisitTypeIn(visit,m,ECQM347V2Elements.Office_Visit
             ,ECQM347V2Elements.Outpatient_Consultation
             ,ECQM347V2Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
             ,ECQM347V2Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
             ,ECQM347V2Elements.Preventive_Care_Services_Individual_Counseling
             ,ECQM347V2Elements.Preventive_Care_Services___Other
             ,ECQM347V2Elements.Annual_Wellness_Visit
             ,ECQM347V2Elements.Outpatient_Encounters_For_Preventive_Care)
    )
  }

  /*---------------------------------------------------------------------------------------------
    All patients who meet one or more of the following criteria (considered at "high risk" for
    cardiovascular events, under ACC/AHA guidelines):
    1)  Patients aged >= 21 years at the beginning of the measurement period with clinical
        ASCVD diagnosis
  ----------------------------------------------------------------------------------------------*/

  def getEligibleIpp(ippRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,ELIGIBLE,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
        (
               wasProcedurePerformedInHistory(visit,m,ECQM347V2Elements.Pci,patientHistoryList)
          ||   wasProcedurePerformedInHistory(visit,m,ECQM347V2Elements.Cabg_Surgeries,patientHistoryList)
          ||   wasProcedurePerformedInHistory(visit,m,ECQM347V2Elements.Carotid_Intervention,patientHistoryList)
          ||   wasDiagnosedInHistory(visit,m,ECQM347V2Elements.Myocardial_Infarction,patientHistoryList)
          ||   wasDiagnosedInHistory(visit,m,ECQM347V2Elements.Cerebrovascular_Disease__Stroke__Tia,patientHistoryList)
          ||   wasDiagnosedInHistory(visit,m,ECQM347V2Elements.Atherosclerosis_And_Peripheral_Arterial_Disease,patientHistoryList)
          ||   wasDiagnosedInHistory(visit,m,ECQM347V2Elements.Ischemic_Heart_Disease_Or_Coronary_Occlusion__Rupture__Or_Thrombosis,patientHistoryList)
          ||   wasDiagnosedInHistory(visit,m,ECQM347V2Elements.Stable_And_Unstable_Angina,patientHistoryList)
        )
    )
  }

  /*---------------------------------------------------------------------------------------------
    Patients who have a diagnosis of pregnancy
    Patients who are breastfeeding
    Patients who have a diagnosis of rhabdomyolysis
   ----------------------------------------------------------------------------------------------*/

  def getExclusionRdd(denominatorRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCLUSION,globalStartDate,globalEndDate)

    denominatorRDD.filter(visit =>
            isDiagnosedDuringEncounter(visit,m,ECQM347V2Elements.Pregnancy_Dx)
        ||  wasDiagnosedInHistory(visit,m,ECQM347V2Elements.Breastfeeding,patientHistoryList)
        ||  wasDiagnosedInHistory(visit,m,ECQM347V2Elements.Rhabdomyolysis,patientHistoryList)

    )
  }

  /*----------------------------------------------------------------------------------------
    Patients who are actively using or who receive an order (prescription) for
    statin therapy at any point during the measurement period
   -----------------------------------------------------------------------------------------*/

  def getMet(intermediateMet: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateMet.filter(visit =>
      (
          (
                isMedicationOrdered(visit,m,patientHistoryList,ECQM347V2Elements.Low_Intensity_Statin_Therapy)
            ||  isMedicationOrdered(visit,m,patientHistoryList,ECQM347V2Elements.Moderate_Intensity_Statin_Therapy)
            ||  isMedicationOrdered(visit,m,patientHistoryList,ECQM347V2Elements.High_Intensity_Statin_Therapy)
          )
          ||
          (
                  wasMedicationActiveInHistory(visit,m,ECQM347V2Elements.Low_Intensity_Statin_Therapy,patientHistoryList)
              ||  wasMedicationActiveInHistory(visit,m,ECQM347V2Elements.Moderate_Intensity_Statin_Therapy,patientHistoryList)
              ||  wasMedicationActiveInHistory(visit,m,ECQM347V2Elements.High_Intensity_Statin_Therapy,patientHistoryList)
          )
        )
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------------------------------
  Patients with adverse effect, allergy, or intolerance to statin medication
  Patients who are receiving palliative care
  Patients with active liver disease or hepatic disease or insufficiency
  Patients with end-stage renal disease (ESRD)
  Patients with diabetes who have the most recent fasting or direct LDL-C laboratory test result < 70 mg/dL and are not taking statin therapy
   ---------------------------------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateException:RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCEPTION,globalStartDate,globalEndDate)

    intermediateException.filter(visit =>
            wasInterventionPerformedInHistory(visit,m,ECQM347V2Elements.Palliative_Care,patientHistoryList)
        ||  wasDiagnosedInHistory(visit,m,ECQM347V2Elements.End_Stage_Renal_Disease,patientHistoryList)
        ||  wasDiagnosedInHistory(visit,m,ECQM347V2Elements.Hepatitis_A,patientHistoryList)
        ||  wasDiagnosedInHistory(visit,m,ECQM347V2Elements.Hepatitis_B,patientHistoryList)
        ||  wasDiagnosedInHistory(visit,m,ECQM347V2Elements.Liver_Disease,patientHistoryList)
        ||  wasMedicationAdverseEffectInHistory(visit,m,ECQM347V2Elements.Statin_Allergen,patientHistoryList)
        ||  wasMedicationAllergyInHistory(visit,m,ECQM347V2Elements.Statin_Allergen,patientHistoryList)
        ||  wasMedicationIntoleranceInHistory (visit,m,ECQM347V2Elements.Statin_Allergen,patientHistoryList)
        ||  isVisitTypeIn(visit,m,ECQM347V2Elements.Palliative_Care_Encounter)
    )
  }
}
