package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ECQM165V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm165
* Measure Title              :- Controlling High Blood Pressure
* Measure Description        :- Percentage of patients 18-85 years of age who had a diagnosis of hypertension and whose
*                               blood pressure was adequately controlled (<140/90mmHg) during the measurement period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Sumant Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm165V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm165V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , ECQM165V7Elements.Pregnancy
      , ECQM165V7Elements.End_Stage_Renal_Disease
      , ECQM165V7Elements.Chronic_Kidney_Disease__Stage_5
      , ECQM165V7Elements.Kidney_Transplant_Recipient
      , ECQM165V7Elements.Lowest_Diastolic_Bp
      , ECQM165V7Elements.Lowest_Systolic_Bp
    )
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val mostRecentRDD = mostRecentPatientList(patientHistoryRDD
      , ECQM165V7Elements.Adult_Outpatient_Visit
      , ECQM165V7Elements.Lowest_Diastolic_Bp
      , ECQM165V7Elements.Lowest_Systolic_Bp)
    val mostRecentRDDList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostRecentRDD)

    val dignosisEssentialHypertensionRDD = mostRecentPatientList(patientHistoryRDD, ECQM165V7Elements.Essential_Hypertension)
    val dignosisEssentialHypertensionRDDList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(dignosisEssentialHypertensionRDD)

    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exceptions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
      exclusionRDD.cache() // Filter Met

      val intermediateRDD = ippRDD.subtract(exclusionRDD)
      intermediateRDD.cache()

      val metRDD = getMet(intermediateRDD, patientHistoryList, mostRecentRDDList, dignosisEssentialHypertensionRDDList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryList.destroy()
      dignosisEssentialHypertensionRDDList.destroy()
    }
  }


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 18)
        &&
        isAgeBelow(visit, m, false, 85)
        &&
        (
          isDiagnosisStartsAfterStartWithinXMonths(visit, m, ECQM165V7Elements.Essential_Hypertension, 6, patientHistoryList)
            ||
            (
              wasOccurrenceOfDiagnosis(visit, m, ECQM165V7Elements.Essential_Hypertension, patientHistoryList)
                &&
                isDiagnosis(visit, m, ECQM165V7Elements.Essential_Hypertension, patientHistoryList)
              )
          )
        &&
        isVisitTypeIn(visit, m
          , ECQM165V7Elements.Office_Visit
          , ECQM165V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
          , ECQM165V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
          , ECQM165V7Elements.Home_Healthcare_Services
          , ECQM165V7Elements.Annual_Wellness_Visit)
    )
  }


  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isEncounterPerformed(visit, m, ECQM165V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        ||
        isEncounterPerformed(visit, m, ECQM165V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        ||
        isInterventionPerformed(visit, m, ECQM165V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        ||
        interventionOrder(visit, m, ECQM165V7Elements.Hospice_Care_Ambulatory)
        ||
        isDiagnosis(visit, m, ECQM165V7Elements.Pregnancy, patientHistoryList)
        ||
        isDiagnosis(visit, m, ECQM165V7Elements.End_Stage_Renal_Disease, patientHistoryList)
        ||
        isDiagnosis(visit, m, ECQM165V7Elements.Chronic_Kidney_Disease__Stage_5, patientHistoryList)
        ||
        isDiagnosis(visit, m, ECQM165V7Elements.Kidney_Transplant_Recipient, patientHistoryList)
        ||
        isProcedurePerformed(visit, m, ECQM165V7Elements.Vascular_Access_For_Dialysis, patientHistoryList)
        ||
        isEncounterPerformed(visit, m, ECQM165V7Elements.Esrd_Monthly_Outpatient_Services, patientHistoryList)
        ||
        isProcedurePerformed(visit, m, ECQM165V7Elements.Kidney_Transplant, patientHistoryList)
        ||
        isProcedurePerformed(visit, m, ECQM165V7Elements.Dialysis_Services, patientHistoryList)
    )
  }


  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]],
             mostRecentRDDList: Broadcast[List[CassandraRow]],
             dignosisEssentialHypertensionRDDList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      isEncounterPerformed(visit, m, ECQM165V7Elements.Adult_Outpatient_Visit, mostRecentRDDList)
        &&
        laboratoryTestPerformedOverlapsEncounter(visit, m, ECQM165V7Elements.Lowest_Diastolic_Bp, mostRecentRDDList)
        &&
        laboratoryTestPerformedOverlapsEncounter(visit, m, ECQM165V7Elements.Lowest_Systolic_Bp, mostRecentRDDList)
        &&
        isDiagnosis(visit, m, ECQM165V7Elements.Essential_Hypertension, patientHistoryList)
        &&
        wasEncounterPerformedAfterXDaysDiagnosis(visit, m, ECQM165V7Elements.Adult_Outpatient_Visit, 0, dignosisEssentialHypertensionRDDList)
        &&
        isLaboratoryTestPerformedValue(visit, m, ECQM165V7Elements.Lowest_Diastolic_Bp, 90, "lt", mostRecentRDDList)
        &&
        isLaboratoryTestPerformedValue(visit, m, ECQM165V7Elements.Lowest_Systolic_Bp, 140, "lt", mostRecentRDDList)
    )
  }


}

