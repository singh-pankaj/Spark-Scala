package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- ASPS17
* Measure Title               :- Patient satisfaction with rhinoplasty procedure
* Measure Description         :- Percentage of patients aged 15 years and older who had a rhinoplasty procedure who
*                                demonstrated improvement* in functional and/or aesthetic satisfaction using a validated
*                                patient satisfaction tool (such as SCHNOS, NOSE, SNOT, RHINO) within a year following their procedure.
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- NA
* Measure Developer           :- Rishikesh Patil
* Initial GIT Version/Tag(CRA):- 1.7
* Latest GIT Version/Tag(CRA) :- 1.7
----------------------------------------------------------------------------------------------------------------------------*/

object ASPS17 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "ASPS17"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , ASPS17Elements.Rhinoplasty
      , ASPS17Elements.Validated_Patient_Satisfaction_Tool
      , ASPS17Elements.Patient_Satisfaction_Tool
      , ASPS17Elements.Score_Improved
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  //IPP Criteria
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 15)
      &&
      isProcedurePerformedDuringEncounter(visit, m, ASPS17Elements.Ambulatory_Visit)
      &&
      wasProcedurePerformedWithinXMonths(visit, m, ASPS17Elements.Rhinoplasty, 11, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  //Numerator Criteria
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>

      wasAssessmentPerformedBeforeOrEqual(visit, m, ASPS17Elements.Rhinoplasty, ASPS17Elements.Validated_Patient_Satisfaction_Tool, patientHistoryBroadcastList)
      &&
      wasAssessmentPerformedBeforeOrEqual(visit, m, ASPS17Elements.Rhinoplasty, ASPS17Elements.Patient_Satisfaction_Tool, patientHistoryBroadcastList)
      &&
      wasAssessmentPerformedAfterEncounterWithInXMonths(visit, m, ASPS17Elements.Rhinoplasty, ASPS17Elements.Validated_Patient_Satisfaction_Tool, 12, patientHistoryBroadcastList)
      &&
      wasAssessmentPerformedAfterEncounterWithInXMonths(visit, m, ASPS17Elements.Rhinoplasty, ASPS17Elements.Patient_Satisfaction_Tool, 12, patientHistoryBroadcastList)
      &&
      wasAssessmentPerformedAfterAssessmentPerformedWithResult(visit, m, ASPS17Elements.Patient_Satisfaction_Tool, ASPS17Elements.Score_Improved, ASPS17Elements.Patient_Satisfaction_Tool, patientHistoryBroadcastList)
    )
  }

}
