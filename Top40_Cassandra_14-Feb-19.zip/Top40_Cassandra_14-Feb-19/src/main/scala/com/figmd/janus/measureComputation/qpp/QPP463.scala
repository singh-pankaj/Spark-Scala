package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, MeasureProperty, QPP463Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.apache.spark.sql.sources.LessThanOrEqual

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- QPP463
* Measure Title               :- Prevention of Post-Operative Vomiting (POV) – Combination Therapy (Pediatrics)
* Measure Description         :- Percentage of patients aged 3 through 17 years, who undergo a procedure under general anesthesia in which an
                                 inhalational anesthetic is used for maintenance AND who have two or more risk factors for post-operative vomiting
                                 (POV), who receive combination therapy consisting of at least two prophylactic pharmacologic anti-emetic agents of
                                 different classes preoperatively and/or intraoperatively
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KAJAL_JADHAO_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object QPP463 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "QPP463"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,QPP463Elements.Surgery_Or_Therapy
      ,QPP463Elements.Inhalational_Anesthetic_Agent
      ,QPP463Elements.Post_Oprtive_Vomiting_2_Or_More_Risk

      ,QPP463Elements.Surgerythera_Start
      ,QPP463Elements.Surgerythera_End
      ,QPP463Elements.Strabismus_Surgery
      ,QPP463Elements.Ponv_History_G

      ,QPP463Elements.Inhalation_Anesthetic_Cases
      ,QPP463Elements.Combi_Min_2_Anti_Emetic
      ,QPP463Elements.Fiveht3_Receptor_Anta
      ,QPP463Elements.Dexamethasone_Rx
      ,QPP463Elements.Dexamethasone_Inj
      ,QPP463Elements.Antihistamines
      ,QPP463Elements.Butyrophenones_Rx
      ,QPP463Elements.Combination_Therapy_Not_Received
      ,QPP463Elements.Medical_Reason_No_Combination_Therapy
      ,QPP463Elements.No_Combination_Therapy_Key
      ,QPP463Elements.Allergy_To_Medication
      ,QPP463Elements.Intolerance_To_Combination_Therapy
      ,QPP463Elements.Fiveht3_Receptor_Antagonists
      ,QPP463Elements.Dexamethasone
      ,QPP463Elements.Dexamethasone_Injectable
      ,QPP463Elements.Antihistamines_Pov
      ,QPP463Elements.Butyrophenones

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients, aged 3 through 17 years, who undergo a procedure under general anesthesia in which an inhalational
anesthetic is used for maintenance AND who have two or more risk factors for POV, during measurement period.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 3, CalenderUnit.YEAR)
        &&  isAgeBelowBeforeStart(visit, m, false, 18, CalenderUnit.YEAR)
        && isProcedurePerformed(visit,m,QPP463Elements.Surgery_Or_Therapy,patientHistoryBroadcastList)
        && wasMedicationDuringProcedureInHistory(visit,m,QPP463Elements.Inhalational_Anesthetic_Agent,patientHistoryBroadcastList,QPP463Elements.Surgery_Or_Therapy)
        && (isProcedureAdverseEventDuringProcedure(visit,m,QPP463Elements.Surgery_Or_Therapy,QPP463Elements.Post_Oprtive_Vomiting_2_Or_More_Risk)
        ||riskUnionAtLeast2(visit,m,patientHistoryBroadcastList))
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Cases in which an inhalational anesthetic is used only for induction
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      isAssessmentPerformedDuringProcedure(visit,m,QPP463Elements.Inhalation_Anesthetic_Cases,QPP463Elements.Inhalation_Anesthetic_Cases_Date,QPP463Elements.Surgery_Or_Therapy,QPP463Elements.Surgery_Or_Therapy)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who receive combination therapy consisting of at least two prophylactic pharmacologic anti-emetic agents of
different classes preoperatively and/or intraoperatively
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (wasMedicationDuringProcedureInHistory(visit,m,QPP463Elements.Combi_Min_2_Anti_Emetic,patientHistoryBroadcastList,QPP463Elements.Surgery_Or_Therapy)
        || countOfMedicationStartsBeforeEndOfProcedure(visit,m,QPP463Elements.Surgery_Or_Therapy,2,CompareOperator.GREATER_EQUAL,patientHistoryBroadcastList,QPP463Elements.Fiveht3_Receptor_Anta,QPP463Elements.Dexamethasone_Rx,QPP463Elements.Dexamethasone_Inj,QPP463Elements.Antihistamines,QPP463Elements.Butyrophenones_Rx))
        && !wasMedicationDuringProcedureInHistory(visit,m,QPP463Elements.Combination_Therapy_Not_Received,patientHistoryBroadcastList,QPP463Elements.Surgery_Or_Therapy)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Documentation of medical reason for not receiving
combination therapy consisting of at least two prophylactic
pharmacologic anti-emetic agents of different classes
preoperatively and/or intraoperatively (e.g., intolerance or
other medical reason) (G9957)
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      isInterventionPerformedDuringProcedure(visit,m,QPP463Elements.Medical_Reason_No_Combination_Therapy,QPP463Elements.Medical_Reason_No_Combination_Therapy_Date,QPP463Elements.Surgery_Or_Therapy,QPP463Elements.Surgery_Or_Therapy_Date)
        ||isInterventionPerformedDuringProcedure(visit,m,QPP463Elements.No_Combination_Therapy_Key,QPP463Elements.No_Combination_Therapy_Key_Date,QPP463Elements.Surgery_Or_Therapy,QPP463Elements.Surgery_Or_Therapy_Date)
        ||wasMedicationDuringProcedureInHistory(visit,m,QPP463Elements.Allergy_To_Medication,patientHistoryBroadcastList,QPP463Elements.Surgery_Or_Therapy)
        ||wasMedicationDuringProcedureInHistory(visit,m,QPP463Elements.Intolerance_To_Combination_Therapy,patientHistoryBroadcastList,QPP463Elements.Surgery_Or_Therapy)
        ||wasMedicationDuringProcedureInHistory(visit,m,QPP463Elements.Fiveht3_Receptor_Antagonists,patientHistoryBroadcastList,QPP463Elements.Surgery_Or_Therapy)
        ||wasMedicationDuringProcedureInHistory(visit,m,QPP463Elements.Dexamethasone,patientHistoryBroadcastList,QPP463Elements.Surgery_Or_Therapy)
        ||wasMedicationDuringProcedureInHistory(visit,m,QPP463Elements.Dexamethasone_Injectable,patientHistoryBroadcastList,QPP463Elements.Surgery_Or_Therapy)
        ||wasMedicationDuringProcedureInHistory(visit,m,QPP463Elements.Antihistamines_Pov,patientHistoryBroadcastList,QPP463Elements.Surgery_Or_Therapy)
        ||wasMedicationDuringProcedureInHistory(visit,m,QPP463Elements.Butyrophenones,patientHistoryBroadcastList,QPP463Elements.Surgery_Or_Therapy)
    )
  }
}