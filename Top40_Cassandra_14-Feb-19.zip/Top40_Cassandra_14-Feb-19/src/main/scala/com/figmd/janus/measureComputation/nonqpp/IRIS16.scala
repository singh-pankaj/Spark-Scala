package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{IRIS16Elements, MeasureProperty, _}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- IRIS 16
* Measure Title              :- Acute Anterior Uveitis - Post-treatment visual acuity
* Measure Description        :- Percentage of acute anterior uveitis patients with a post-treatment best corrected visual acuity of 20/40 or better
*                               OR patients whose visual acuity had returned to their baseline value prior to onset of uveitis
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object IRIS16 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "IRIS16"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      IRIS16Elements.Acute_Uveitis,
      IRIS16Elements.Acute_Uveitis_Eye,
      IRIS16Elements.Uveitis_Medications,
      IRIS16Elements.Uveitis_Medications__Eye,
      IRIS16Elements.Visual_Acuity,
      IRIS16Elements.Visual_Acuity_Eye,
      IRIS16Elements.Va_Return_To_Baseline,
      IRIS16Elements.Va_Return_To_Baseline__Eye,
      IRIS16Elements.Best_Corrected_Right_Eye_Va_Value,
      IRIS16Elements.Best_Corrected_Left_Eye_Va_Value,
      IRIS16Elements.Un_Corrected_Left_Eye_Va_Value,
      IRIS16Elements.Un_Corrected_Right_Eye_Va_Value,
      IRIS16Elements.Un_Specified_Right_Eye_Va_Value,
      IRIS16Elements.Un_Specified_Left_Eye_Va_Value
    ).collect().toList
    var historyRdd = getPatientHistory(sparkSession, initialRDD,
      IRIS16Elements.Acute_Uveitis,
      IRIS16Elements.Acute_Uveitis_Eye,
      IRIS16Elements.Uveitis_Medications,
      IRIS16Elements.Uveitis_Medications__Eye,
      IRIS16Elements.Visual_Acuity,
      IRIS16Elements.Visual_Acuity_Eye,
      IRIS16Elements.Va_Return_To_Baseline,
      IRIS16Elements.Va_Return_To_Baseline__Eye
    )


    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)
    var most_recent_histroty_list = mostRecentPatientList(historyRdd, IRIS16Elements.Acute_Uveitis_Eye, IRIS16Elements.Uveitis_Medications__Eye, IRIS16Elements.Acute_Uveitis, IRIS16Elements.Visual_Acuity, IRIS16Elements.Visual_Acuity_Eye)
    val mostRecentpatientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(most_recent_histroty_list)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList, mostRecentpatientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      mostRecentpatientHistoryList.destroy()
      mostRecentpatientHistoryList.destroy()
    }
  }

  //Patients aged 18 years or older who underwent treatment for acute anterior uveitis
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult (visit, m)
        && isDiagnosedWithInHistory(visit,m,IRIS16Elements.Acute_Uveitis,patientHistoryList)
        &&
        (
          wasMedicationAdministeredBeforeEndInDays(visit, m, IRIS16Elements.Uveitis_Medications,90,patientHistoryList)
            &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,true,IRIS16Elements.Uveitis_Medications__Eye,patientHistoryList,Seq(IRIS16Elements.Acute_Uveitis_Eye))

          )
    )
  }

  //Patients with a best corrected visual acuity of 20/40 or better within 90 days of treatment initiation
  //OR
  //Patients whose visual acuity had returned to their baseline value prior to onset of acute uveitis within 90 days of treatment initiation
  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]],mostRecentpatientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    val Correct_VA_Values: Array[String] = Array("20/10","20/11","20/12","20/13","20/14","20/15","20/16","20/17","20/18","20/19","20/2","20/20","20/21","20/22","20/23","20/24","20/25","20/26","20/28","20/29","20/3","20/30","20/31","20/32","20/33","20/34","20/35","20/36","20/37","20/38","20/39","20/4","20/5","20/6","20/7","20/8","20/9","20/40")
    intermediateA.filter(visit =>
      (
        (
          wasMostRecentPhysicalExamBeforePhysicalExamPerformed(visit,m,IRIS16Elements.Acute_Uveitis,IRIS16Elements.Visual_Acuity,patientHistoryList,mostRecentpatientHistoryList)
            &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS16Elements.Visual_Acuity_Eye,patientHistoryList,Seq(IRIS16Elements.Acute_Uveitis_Eye,IRIS16Elements.Visual_Acuity_Eye,IRIS16Elements.Uveitis_Medications__Eye))

          )
          &&
          (
            isPhysicalExamPerformedInXDaysAfterProcedure(visit,m,IRIS16Elements.Uveitis_Medications,IRIS16Elements.Va_Return_To_Baseline,90,patientHistoryList)
              &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS16Elements.Va_Return_To_Baseline__Eye,patientHistoryList,Seq(IRIS16Elements.Acute_Uveitis_Eye,IRIS16Elements.Va_Return_To_Baseline__Eye,IRIS16Elements.Visual_Acuity_Eye,IRIS16Elements.Uveitis_Medications__Eye))

            )
        )
        ||
        (
          wasCorrectedVisualAcuityValueGreaterXDays(visit,m,IRIS16Elements.Best_Corrected_Right_Eye_Va_Value,IRIS16Elements.Uveitis_Medications,90,Correct_VA_Values,patientHistoryList)
            ||   wasCorrectedVisualAcuityValueGreaterXDays(visit,m,IRIS16Elements.Best_Corrected_Left_Eye_Va_Value,IRIS16Elements.Uveitis_Medications,90,Correct_VA_Values,patientHistoryList)
            ||   wasCorrectedVisualAcuityValueGreaterXDays(visit,m,IRIS16Elements.Un_Corrected_Right_Eye_Va_Value,IRIS16Elements.Uveitis_Medications,90,Correct_VA_Values,patientHistoryList)
            ||   wasCorrectedVisualAcuityValueGreaterXDays(visit,m,IRIS16Elements.Un_Corrected_Left_Eye_Va_Value,IRIS16Elements.Uveitis_Medications,90,Correct_VA_Values,patientHistoryList)
            ||   wasCorrectedVisualAcuityValueGreaterXDays(visit,m,IRIS16Elements.Un_Specified_Right_Eye_Va_Value,IRIS16Elements.Uveitis_Medications,90,Correct_VA_Values,patientHistoryList)
            ||   wasCorrectedVisualAcuityValueGreaterXDays(visit,m,IRIS16Elements.Un_Specified_Left_Eye_Va_Value,IRIS16Elements.Uveitis_Medications,90,Correct_VA_Values,patientHistoryList)

          )



    )
  }

}