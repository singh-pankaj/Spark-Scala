package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, QPP441Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate,spark}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- QPP441_1
* Measure Title               :-Ischemic Vascular Disease (IVD) All or None Outcome Measure (Optimal Control)
* Measure Description         :-The IVD All-or-None Measure is one outcome measure (optimal control). The measure contains four goals. All four goals within a measure must be reached in order to meet that measure. The numerator for the all-or-none measure should be collected from the organization's total IVD denominator. All-or-None Outcome Measure (Optimal Control) -
                                Using the IVD denominator optimal results include:
                                • Most recent blood pressure (BP) measurement is less than or equal to 140/90 mm Hg -- And
                                • Most recent tobacco status is Tobacco Free -- And
                                • Daily Aspirin or Other Antiplatelet Unless Contraindicated -- And
                                • Statin Use Unless Contraindicated
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KAJAL_JADHAO_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object QPP441_1 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "QPP441_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP441Elements.Coronary_Artery_Disease__Cad_
      , QPP441Elements.Cad_Risk_Equivalent_Condition
      , QPP441Elements.Patient_Alive
      , QPP441Elements.Hospice_Services
      , QPP441Elements.Hospice_Care
      , QPP441Elements.Hospice_Services_Snomedct
      , QPP441Elements.Bp_Measurement
      , QPP441Elements.Bp_Measurement_Not_Met
      , QPP441Elements.Tobacco_Status
      , QPP441Elements.Systolic_Blood_Pressure
      , QPP441Elements.Diastolic_Blood_Pressure
      , QPP441Elements.Current_Tobacco_Non_User
      , QPP441Elements.Aspirin_And_Other_Antiplatelets
      , QPP441Elements.Aspirin_Or_Other_Antiplatelet_Medical_Reason
      , QPP441Elements.Medical_Reason_S_
      , QPP441Elements.Aspirin_Or_Other_Antiplatelet_Not_Met
      , QPP441Elements.Statin_Use
      , QPP441Elements.Statin_Medical_Reason
      , QPP441Elements.Pregnancy
      , QPP441Elements.Cirrhosis
      , QPP441Elements.Muscle_Pain
      , QPP441Elements.In_Vitro_Fertilization
      , QPP441Elements.Esrd_Services
      , QPP441Elements.Clomiphene
      , QPP441Elements.Statin_Use_Not_Met
      , QPP441Elements.Home_And_Health_Fair
      , QPP441Elements.Bp_Measurement_Emergency

      , QPP441Elements.Patient_Home_Services
      , QPP441Elements.Initial_Preventive_Physical_Examination
      , QPP441Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
      , QPP441Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
      , QPP441Elements.Initial_Care
      , QPP441Elements.Preventive_Care_Services___Group_Counseling
      , QPP441Elements.Preventive_Care_Services_Individual_Counseling
      , QPP441Elements.Health_Risk_Assessment
      , QPP441Elements.Preventive_Care_Services___Other
      , QPP441Elements.Home_Visit
      , QPP441Elements.Outpatient_Consultation
      , QPP441Elements.Chronic_Care_Management_Services
      , QPP441Elements.Face_To_Face_Visit
      , QPP441Elements.Annual_Wellness_Visit
      , QPP441Elements.Office_Visit
      , QPP441Elements.Preventive_Care__Established_Office_Visit__0_To_17
      , QPP441Elements.Preventive_Medicine_Re_Evaluation

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val mostRecentRDD = mostRecentPatientList(patientHistoryRDD: RDD[CassandraRow],QPP441Elements.Systolic_Blood_Pressure,QPP441Elements.Diastolic_Blood_Pressure,QPP441Elements.Current_Tobacco_Non_User )
    val mostRecentBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostRecentRDD)


    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList,mostRecentBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList,patientHistoryRDD)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      mostRecentBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Reporting Criteria 1: Patients with CAD or a CAD Risk-Equivalent Condition (other atherosclerotic vascular disease, including peripheral
arterial disease, atherosclerotic aortic disease, and carotid artery disease) 18-75 years of age and alive as of the last day of the measurement period and a minimum of two CAD or
CAD Risk-Equivalent Condition coded office visits with a Primary Care Provider (PCP) / Cardiologist in 24 months and one office visits in 12 months.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 18, CalenderUnit.YEAR)
        && isAgeBelowBeforeStart(visit, m, false, 76, CalenderUnit.YEAR)
        &&
        isVisitTypeIn(visit, m
          , QPP441Elements.Patient_Home_Services
          , QPP441Elements.Initial_Preventive_Physical_Examination
          , QPP441Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
          , QPP441Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
          , QPP441Elements.Initial_Care
          , QPP441Elements.Preventive_Care_Services___Group_Counseling
          , QPP441Elements.Preventive_Care_Services_Individual_Counseling
          , QPP441Elements.Health_Risk_Assessment
          , QPP441Elements.Preventive_Care_Services___Other
          , QPP441Elements.Home_Visit
          , QPP441Elements.Outpatient_Consultation
          , QPP441Elements.Chronic_Care_Management_Services
          , QPP441Elements.Face_To_Face_Visit
          , QPP441Elements.Annual_Wellness_Visit
          , QPP441Elements.Office_Visit
          , QPP441Elements.Preventive_Care__Established_Office_Visit__0_To_17
          , QPP441Elements.Preventive_Medicine_Re_Evaluation)
        &&
        countElementBeforeXPeriod(patientHistoryRDD,m,24
          , QPP441Elements.Patient_Home_Services
          , QPP441Elements.Initial_Preventive_Physical_Examination
          , QPP441Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
          , QPP441Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
          , QPP441Elements.Initial_Care
          , QPP441Elements.Preventive_Care_Services___Group_Counseling
          , QPP441Elements.Preventive_Care_Services_Individual_Counseling
          , QPP441Elements.Health_Risk_Assessment
          , QPP441Elements.Preventive_Care_Services___Other
          , QPP441Elements.Home_Visit
          , QPP441Elements.Outpatient_Consultation
          , QPP441Elements.Chronic_Care_Management_Services
          , QPP441Elements.Face_To_Face_Visit
          , QPP441Elements.Annual_Wellness_Visit
          , QPP441Elements.Office_Visit
          , QPP441Elements.Preventive_Care__Established_Office_Visit__0_To_17
          , QPP441Elements.Preventive_Medicine_Re_Evaluation
        )

        && (wasDiagnosedBeforeEncounter(visit,m,QPP441Elements.Coronary_Artery_Disease__Cad_,patientHistoryBroadcastList)
        || wasDiagnosedBeforeEncounter(visit,m,QPP441Elements.Cad_Risk_Equivalent_Condition,patientHistoryBroadcastList))
        && isPatientCharacteristic(visit,m,QPP441Elements.Patient_Alive,patientHistoryBroadcastList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      isInterventionPerformed(visit,m,QPP441Elements.Hospice_Services,patientHistoryBroadcastList)
        || isInterventionPerformed(visit,m,QPP441Elements.Hospice_Care,patientHistoryBroadcastList)
        || isInterventionPerformed(visit,m,QPP441Elements.Hospice_Services_Snomedct,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
The number of IVD patients who meet ALL of the following targets:
• Most recent BP is less than or equal to 140/90 mm Hg And
• Most recent tobacco status is Tobacco Free (NOTE: If there is No Documentation of Tobacco Status the patient is not compliant for this measure) And
• Daily Aspirin or Other Antiplatelet Unless Contraindicated And
• Statin Use Unless Contraindicated
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],mostRecentBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>

      (
        (isAssessmentPerformed(visit,m,QPP441Elements.Bp_Measurement,patientHistoryBroadcastList)
          || isDiagnosticPerformed(visit,m,QPP441Elements.Systolic_Blood_Pressure,140,mostRecentBroadcastList)
          || isDiagnosticPerformed(visit,m,QPP441Elements.Diastolic_Blood_Pressure,90,mostRecentBroadcastList)
          &&
          ! (isAssessmentPerformed(visit,m,QPP441Elements.Bp_Measurement_Not_Met,patientHistoryBroadcastList)
            || isDiagnosticPerformed(visit,m,QPP441Elements.Systolic_Blood_Pressure,140,mostRecentBroadcastList)
            || isDiagnosticPerformed(visit,m,QPP441Elements.Diastolic_Blood_Pressure,90,mostRecentBroadcastList))
          )
          &&
          ((isAssessmentPerformed(visit,m,QPP441Elements.Tobacco_Status,patientHistoryBroadcastList)
            || isDiagnosticPerformedWithoutValue(visit,m,QPP441Elements.Current_Tobacco_Non_User,mostRecentBroadcastList))
            &&
            !(isAssessmentPerformed(visit,m,QPP441Elements.Tobacco_Status_Not_Met,patientHistoryBroadcastList)
              || isDiagnosticPerformedWithoutValue(visit,m,QPP441Elements.Current_Tobacco_Non_User,mostRecentBroadcastList)))
          &&
          (
            ((isAssessmentPerformed(visit,m,QPP441Elements.Aspirin_And_Other_Antiplatelets,patientHistoryBroadcastList)
              || wasMedicationActiveBeforeOrEqualEncounter(visit,m,QPP441Elements.Aspirin_And_Other_Antiplatelets,patientHistoryBroadcastList))
              || (isAssessmentPerformed(visit,m,QPP441Elements.Aspirin_Or_Other_Antiplatelet_Medical_Reason,patientHistoryBroadcastList)
              || isAssessmentPerformed(visit,m,QPP441Elements.Medical_Reason_S_,patientHistoryBroadcastList)))
              &&
              !isAssessmentPerformed(visit,m,QPP441Elements.Aspirin_Or_Other_Antiplatelet_Not_Met,patientHistoryBroadcastList)
            )
          &&
          (
            (
              isAssessmentPerformed(visit,m,QPP441Elements.Statin_Use,patientHistoryBroadcastList)
                ||wasMedicationActiveBeforeOrEqualEncounter(visit,m,QPP441Elements.Statin_Therapy,patientHistoryBroadcastList)
                ||isAssessmentPerformed(visit,m,QPP441Elements.Statin_Medical_Reason,patientHistoryBroadcastList)
                ||wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,QPP441Elements.Pregnancy,QPP441Elements.Cirrhosis,QPP441Elements.Muscle_Pain)
                ||wasProcedurePerformedBeforeOrEqualEncounter(visit,m,QPP441Elements.In_Vitro_Fertilization,patientHistoryBroadcastList)
                ||wasProcedurePerformedBeforeOrEqualEncounter(visit,m,QPP441Elements.Esrd_Services,patientHistoryBroadcastList)
                ||wasMedicationActiveBeforeOrEqualEncounter(visit,m,QPP441Elements.Clomiphene,patientHistoryBroadcastList)
              )
              &&
              !isAssessmentPerformed(visit,m,QPP441Elements.Statin_Use_Not_Met,patientHistoryBroadcastList)
            )
        )
    )

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Blood pressure recorded during inpatient stays, Emergency Room Visits, Urgent Care Visits, and Patient Self-Reported BP’s (Home and Health Fair BP results)
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    val latestIOPList =  spark.sparkContext.broadcast(mostRecentPatientList(patientHistoryRDD,QPP441Elements.Systolic_Blood_Pressure,QPP441Elements.Diastolic_Blood_Pressure ))

    intermediateForException.filter(visit =>

      (isEncounterPerformed(visit,m,QPP441Elements.Home_And_Health_Fair,patientHistoryBroadcastList)
        && wasDiagnosticStudyPerformedOnSameDay(visit, m, QPP441Elements.Home_And_Health_Fair, latestIOPList))
        || isDiagnosticStudyPerformed(visit,m,QPP441Elements.Bp_Measurement_Emergency,patientHistoryBroadcastList)

    )

  }
}