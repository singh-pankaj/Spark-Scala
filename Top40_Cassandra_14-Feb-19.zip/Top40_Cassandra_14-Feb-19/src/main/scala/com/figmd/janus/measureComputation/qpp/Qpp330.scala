package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP330Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 330
* Measure Title              :- Adult Kidney Disease: Catheter Use for Greater Than or Equal to 90 Days
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of End Stage Renal Disease
                                (ESRD) receiving maintenance hemodialysis for greater than or equal to 90 days whose mode
                                of vascular access is a catheter
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp330 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp330"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP330Elements.Maintenance_Hemodialysis
      , QPP330Elements.Catheter_As_Vascular_Access
      , QPP330Elements.Palliative_Dialysis_Catheter
      , QPP330Elements.Palliative_Dialysis
      , QPP330Elements.Catheter
      , QPP330Elements.End_Stage_Renal_Disease__Esrd_
      , QPP330Elements.Transplant_Program
      , QPP330Elements.Approved_Qualified_Transplant_Program
      , QPP330Elements.Scheduled_Kidney_Transplant
      , QPP330Elements.Catheter_Vascular_Access
      , QPP330Elements.Catheter_Documented_Reasons)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val leastRecentList: List[CassandraRow] = leastRecentPatientList(patientHistoryRDD, QPP330Elements.Maintenance_Hemodialysis)

    val leastRecentPatientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastRecentList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList, leastRecentPatientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //eligible RDD
      val denomintorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exclusion
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate RDD
      val intermediateException = getSubtractRDD(intermediateMet, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denomintorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      leastRecentPatientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
   All patients aged 18 years and older with a diagnosis of ESRD receiving maintenance
   hemodialysis for greater than or equal to 90 days
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], leastRecentPatientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m, QPP330Elements.Monthly_Esrd_Services)
        && wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP330Elements.End_Stage_Renal_Disease__Esrd_, patientHistoryBroadcastList)
        && isProcedurePerformedWithinXMonths(visit, m, QPP330Elements.Maintenance_Hemodialysis, 9, leastRecentPatientHistoryBroadcastList)
        && (
        isProcedurePerformedWithinXMonths(visit, m, QPP330Elements.Catheter_As_Vascular_Access, 9, patientHistoryBroadcastList)
          || isProcedurePerformedDuringProcedureWithReason(visit, m, QPP330Elements.Vascular_Access, QPP330Elements.Maintenance_Hemodialysis, QPP330Elements.Catheter)
        )
    )
  }

  /*------------------------------------------------------------------------------------------------
    Patient is undergoing palliative dialysis with a catheter
    OR
    Patient approved by a qualified transplant program and scheduled to receive a living donor kidney transplant:
   ------------------------------------------------------------------------------------------------*/

  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isProcedurePerformed(visit, m, QPP330Elements.Palliative_Dialysis_Catheter, patientHistoryBroadcastList)
        || (
        isProcedurePerformed(visit, m, QPP330Elements.Palliative_Dialysis, patientHistoryBroadcastList)
          && isDeviceApplied(visit, m, QPP330Elements.Catheter, patientHistoryBroadcastList)
        )
        || isProcedurePerformed(visit, m, QPP330Elements.Transplant_Program, patientHistoryBroadcastList)
        || (
        isInterventionPerformed(visit, m, QPP330Elements.Approved_Qualified_Transplant_Program, patientHistoryBroadcastList)
          && isInterventionPerformed(visit, m, QPP330Elements.Scheduled_Kidney_Transplant, patientHistoryBroadcastList)
        )
    )
  }

  /*------------------------------------------------------------------------------------------------
   Patients whose mode of vascular access is a catheter
   ------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        isProcedurePerformed(visit, m, QPP330Elements.Catheter_Vascular_Access, patientHistoryBroadcastList)
          || isProcedurePerformedDuringProcedureWithReason(visit, m, QPP330Elements.Vascular_Access, QPP330Elements.Maintenance_Hemodialysis, QPP330Elements.Catheter)
        )
        && !isProcedurePerformedDuringProcedureWithReason(visit, m, QPP330Elements.Vascular_Access, QPP330Elements.Maintenance_Hemodialysis, QPP330Elements.Catheter)
        && !isProcedurePerformedDuringProcedureWithReason(visit, m, QPP330Elements.Vascular_Access, QPP330Elements.Maintenance_Hemodialysis, QPP330Elements.Vas_Access_Patient_Reason)
    )

  }

  /*-------------------------------------------------------------------------------------------------------------------
   Documentation of patient receiving maintenance hemodialysis for greater than or equal to 90 days
   with a catheter for documented reasons (e.g. other medical reasons, patient declined AVF/AVG, other patient reasons)
   -------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermedaiateRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermedaiateRdd.filter(visit =>
      isProcedurePerformed(visit, m, QPP330Elements.Catheter_Documented_Reasons, patientHistoryBroadcastList)
        || (
        isProcedurePerformedDuringProcedureWithReason(visit, m, QPP330Elements.Vascular_Access, QPP330Elements.Maintenance_Hemodialysis, QPP330Elements.Catheter)
          && isProcedurePerformedDuringProcedureWithReason(visit, m, QPP330Elements.Vascular_Access, QPP330Elements.Maintenance_Hemodialysis, QPP330Elements.Vas_Access_Patient_Reason)
        )
    )

  }

}
