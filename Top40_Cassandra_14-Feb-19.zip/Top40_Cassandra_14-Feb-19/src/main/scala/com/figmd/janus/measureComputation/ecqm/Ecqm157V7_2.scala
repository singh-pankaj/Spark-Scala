package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, ECQM157V7Elements}
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 157v7
* Measure Title              :- Oncology: Medical and Radiation - Pain Intensity Quantified
* Measure Description        :- Percentage of patient visits, regardless of patient age, with a diagnosis of cancer currently receiving chemotherapy or radiation therapy in which pain intensity is quantified
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 2
* Measure Stratification     :- 1
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm157V7_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "ECQM157v7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patient_history_list = getPatientHistory(sparkSession, initialRDD,
      ECQM157V7Elements.Cancer,
      ECQM157V7Elements.Radiation_Treatment_Management)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      /* val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    notEligibleRDD.cache()*/

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : All patient visits, regardless of patient age, with a diagnosis of cancer currently receiving chemotherapy or radiation therapy
----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isProcedurePerformedDuringEncounter(visit, m, ECQM157V7Elements.Radiation_Treatment_Management)
        && wasDiagnosedBeforeOrEqualProcedure(visit, m, ECQM157V7Elements.Radiation_Treatment_Management, ECQM157V7Elements.Cancer, patientHistoryBroadcastList)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Patient visits in which pain intensity is quantified
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      isAssessmentPerformedDuringProcedure(visit, m, ECQM157V7Elements.Standardized_Pain_Assessment_Tool, ECQM157V7Elements.Standardized_Pain_Assessment_Tool_Date, ECQM157V7Elements.Radiation_Treatment_Management, ECQM157V7Elements.Radiation_Treatment_Management_Date)

    )
  }
}

