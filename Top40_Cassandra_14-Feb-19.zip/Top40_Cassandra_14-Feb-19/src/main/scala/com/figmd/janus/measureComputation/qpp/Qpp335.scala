package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP335Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


/*--------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 335
* Measure Title              :- Maternity Care: Elective Delivery or Early Induction Without Medical Indication at >= 37 and < 39 Weeks (Overuse)
* Measure Description        :- Percentage of patients, regardless of age, who gave birth during a 12-month period who delivered a live
                                singletonat ≥ 37 and < 39 weeks of gestation completed who had elective deliveries or early inductions without medical indication
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp335 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp335"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // val patientHistory:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistory)

    //Backtracking List
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP335Elements.Elective_Deliveries_Or_Early_Inductions,
      QPP335Elements.Elective_Deliveries,
      QPP335Elements.Gestation,
      QPP335Elements.Uterine_Surgery,
      QPP335Elements.Maternal_Conditions_Complicating_Pregnancy_Delivery,
      QPP335Elements.Malposition_And_Malpresentation_Of_Fetus,
      QPP335Elements.Hemorrhage_And_Placental_Complication,
      QPP335Elements.Fetal_Conditions_Complicating_Pregnancy_Or_Delivery,
      QPP335Elements.Rupture_Of_Membranes_Premature_Or_Prolonged,
      QPP335Elements.Preeclampsia_And_Eclampsia,
      QPP335Elements.Late_Pregnancy,
      QPP335Elements.Hypertension,
      QPP335Elements.Elec_Or_Ear_Ind_Medical_Reason,
      QPP335Elements.Participation_In_Clinical_Trial).collect.toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : All patients, regardless of age, who gave birth during a 12-month period delivering a live singleton
at ≥ 37 and < 39 weeks of gestation completed without medical indication for induction.
----------------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
         isFemale(visit,m)
      && isDiagnosisOnEncounter(visit,m,QPP335Elements.Live_Singleton)
      && isProcedurePerformedDuringEncounter(visit,m,QPP335Elements.Delivery_Visit)
      && isAssessmentPerformed(visit,m,QPP335Elements.Gestation,patientHistoryBroadcastList)
      && isAssessmentPerformedDuringProcedure(visit,m,QPP335Elements.Gestation,QPP335Elements.Gestation_Date,QPP335Elements.Delivery_Visit,QPP335Elements.Delivery_Visit_Date)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Patients who had elective deliveries or early inductions.
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(denominatorRDD: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    denominatorRDD.filter(visit =>
      (  wasProcedurePerformedAfterOrEqualProcedure(visit,m,QPP335Elements.Delivery_Visit,patientHistoryBroadcastList,QPP335Elements.Elective_Deliveries_Or_Early_Inductions)
      || isProcedurePerformedDuringProcedure(visit,m,QPP335Elements.Early_Inductions_Or_Elective_Deliveries_Not_Performed,QPP335Elements.Early_Inductions_Or_Elective_Deliveries_Not_Performed_Date,QPP335Elements.Delivery_Visit,QPP335Elements.Delivery_Visit_Date)
        )
      && !(
              wasProcedurePerformedAfterOrEqualProcedure(visit,m,QPP335Elements.Delivery_Visit,patientHistoryBroadcastList,QPP335Elements.Elective_Deliveries)
           || isProcedurePerformedDuringProcedure(visit,m,QPP335Elements.Elective_Deliveries_Icd,QPP335Elements.Elective_Deliveries_Icd_Date,QPP335Elements.Delivery_Visit,QPP335Elements.Delivery_Visit_Date)
           || isProcedurePerformedDuringProcedure(visit,m,QPP335Elements.Early_Inductions_Or_Elective_Deliveries_Performed,QPP335Elements.Early_Inductions_Or_Elective_Deliveries_Performed_Date,QPP335Elements.Delivery_Visit,QPP335Elements.Delivery_Visit_Date)
          )
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------------
Denominator Exceptions : Medical indication for induction [Documentation of reason(s) for elective delivery (C-section) or early
induction (e.g., hemorrhage and placental complications, hypertension, preeclampsia and eclampsia, rupture of membranes- premature or prolonged,
maternal conditions complicating pregnancy/delivery, fetal conditions complicating pregnancy/delivery, late pregnancy, prior uterine surgery, or participation in clinical trial)]
----------------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateForException: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermediateForException.filter(visit =>
          wasProcedurePerformedAfterOrEqualProcedure(visit,m,QPP335Elements.Delivery_Visit,patientHistoryBroadcastList,QPP335Elements.Elec_Or_Ear_Ind_Medical_Reason)
      ||  wasProcedurePerformedBeforeOtherProcedure(visit,m,QPP335Elements.Uterine_Surgery,patientHistoryBroadcastList,QPP335Elements.Delivery_Visit)
      ||  wasInterventionPerformedBeforeProcedure(visit,m,QPP335Elements.Delivery_Visit,patientHistoryBroadcastList,QPP335Elements.Participation_In_Clinical_Trial)
      ||  wasDiagnosisBeforeOrEqualProcedure(visit,m,QPP335Elements.Maternal_Conditions_Complicating_Pregnancy_Delivery,QPP335Elements.Delivery_Visit,patientHistoryBroadcastList)
      ||  wasDiagnosisBeforeOrEqualProcedure(visit,m,QPP335Elements.Malposition_And_Malpresentation_Of_Fetus,QPP335Elements.Delivery_Visit,patientHistoryBroadcastList)
      ||  wasDiagnosisBeforeOrEqualProcedure(visit,m,QPP335Elements.Hemorrhage_And_Placental_Complication,QPP335Elements.Delivery_Visit,patientHistoryBroadcastList)
      ||  wasDiagnosisBeforeOrEqualProcedure(visit,m,QPP335Elements.Fetal_Conditions_Complicating_Pregnancy_Or_Delivery,QPP335Elements.Delivery_Visit,patientHistoryBroadcastList)
      ||  wasDiagnosisBeforeOrEqualProcedure(visit,m,QPP335Elements.Rupture_Of_Membranes_Premature_Or_Prolonged,QPP335Elements.Delivery_Visit,patientHistoryBroadcastList)
      ||  wasDiagnosisBeforeOrEqualProcedure(visit,m,QPP335Elements.Preeclampsia_And_Eclampsia,QPP335Elements.Delivery_Visit,patientHistoryBroadcastList)
      ||  wasDiagnosisBeforeOrEqualProcedure(visit,m,QPP335Elements.Late_Pregnancy,QPP335Elements.Delivery_Visit,patientHistoryBroadcastList)
      ||  wasDiagnosisBeforeOrEqualProcedure(visit,m,QPP335Elements.Hypertension,QPP335Elements.Delivery_Visit,patientHistoryBroadcastList)

    )
  }
}


