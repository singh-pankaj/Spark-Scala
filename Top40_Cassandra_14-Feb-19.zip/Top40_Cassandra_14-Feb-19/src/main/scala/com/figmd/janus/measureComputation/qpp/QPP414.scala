package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, MeasureProperty, QPP414Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- QPP414
* Measure Title               :- Evaluation or Interview for Risk of Opioid Misuse
* Measure Description         :- All patients 18 and older prescribed opiates for longer than six weeks duration evaluated for risk
                                 of opioidmisuse using a brief validated instrument (e.g. Opioid Risk Tool, SOAPP-R) or patient interview
                                 documented at leastonce during Opioid Therapy in the medical record
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMIT.SINGH
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object QPP414 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP414"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    val patientHistoryRDD = getPatientHistory(sparkSession,initialRDD
      ,QPP414Elements.Office_Visit_Telehealth_Modifier
      ,QPP414Elements.Nursing_Facility_Visit_Telehealth_Modifier
      ,QPP414Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
      ,QPP414Elements.Home_Healthcare_Services_Telehealth_Modifier
      ,QPP414Elements.Hospice_Care
      ,QPP414Elements.Hospice_Services_Snomedct
      ,QPP414Elements.Opioid_Medication

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val medicationList = List[(String, String)]((QPP414Elements.Opioid_Medication,QPP414Elements.Opioid_Medication_Date))
    val medicationDurationBroadcastList = sparkSession.sparkContext.broadcast(
        consecutive(patientHistoryRDD, m, medicationList, CalenderUnit.WEEK,
        CalenderUnit.WEEK, 0, CalenderUnit.DAY, 1, "DURING"))




    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]],medicationDurationBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      medicationDurationBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
  All patients 18 and older prescribed opiates for longer than six weeks duration
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], medicationDurationBroadcastList : Broadcast[List[(String,String, Double)]] ): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&  isVisitTypeIn(visit, m
        , QPP414Elements.Home_Healthcare_Services
        , QPP414Elements.Care_Services_In_Long_Term_Residential_Facility
        , QPP414Elements.Nursing_Facility_Visit
        , QPP414Elements.Office_Visit
      )
        &&
        (
                isAssessmentPerformed(visit, m, QPP414Elements.Opiates_Prescribed,patientHistoryBroadcastList)

            ||  getConsecutiveResult(visit, m, QPP414Elements.Opioid_Medication, 6, CompareOperator.GREATER_EQUAL, medicationDurationBroadcastList)

          )
        && !
          (
                isEncounterPerformed(visit, m, QPP414Elements.Office_Visit_Telehealth_Modifier, patientHistoryBroadcastList)
            ||  isEncounterPerformed(visit, m, QPP414Elements.Nursing_Facility_Visit_Telehealth_Modifier, patientHistoryBroadcastList)
            ||  isEncounterPerformed(visit, m, QPP414Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier, patientHistoryBroadcastList)
            ||  isEncounterPerformed(visit, m, QPP414Elements.Home_Healthcare_Services_Telehealth_Modifier, patientHistoryBroadcastList)
          )


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients who were in hospice at any time during the performance period
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            wasInterventionPerformedInHistory(visit, m, QPP414Elements.Hospice, patientHistoryBroadcastList)
        ||  wasInterventionPerformedInHistory(visit, m, QPP414Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
        ||  wasInterventionPerformedInHistory(visit, m, QPP414Elements.Hospice_Care, patientHistoryBroadcastList)

    )

  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients evaluated for risk of misuse of opiates by using a brief validated instrument
 (e.g., Opioid Risk Tool, Opioid Assessment for Patients with Pain, revised (SOAPP-R)) or patient interview at least once during opioid therapy
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (

           isProcedurePerformedDuringAssessmentWithMethod(visit,m,QPP414Elements.Risk_Of_Misuse_Of_Opiates,QPP414Elements.Risk_Of_Misuse_Of_Opiates_Tools,QPP414Elements.Opiates_Prescribed)
      ||   isProcedurePerformedDuringMedicationOrderWithMethod(visit,m,QPP414Elements.Risk_Of_Misuse_Of_Opiates,QPP414Elements.Risk_Of_Misuse_Of_Opiates_Tools,QPP414Elements.Opioid_Medication)
      ||   isCommunicationFromProviderToPatientDuringAssessment(visit,m,QPP414Elements.Patient_Interview_During_Therapy,QPP414Elements.Patient_Interview_During_Therapy_Date,QPP414Elements.Opiates_Prescribed,QPP414Elements.Opiates_Prescribed_Date)
      ||   isCommunicationFromProviderToPatientDuringMedication(visit,m,QPP414Elements.Patient_Interview_During_Therapy,QPP414Elements.Patient_Interview_During_Therapy_Date,QPP414Elements.Opioid_Medication,QPP414Elements.Opioid_Medication_Date)
      ||   isProcedurePerformed(visit,m,QPP414Elements.Opiates_Misuse_Risk_Evaluation,patientHistoryBroadcastList)

      )
      &&   (
             !isProcedurePerformedNotDoneOnEncounter(visit,m,QPP414Elements.Opiates_Misuse_Risk_Evaluation_Not_Met)
           )


    )
  }


}