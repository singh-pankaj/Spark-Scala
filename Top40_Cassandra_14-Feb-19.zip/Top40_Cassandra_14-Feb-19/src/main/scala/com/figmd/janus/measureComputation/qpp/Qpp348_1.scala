package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp348
* Measure Title              :- HRS-3 Implantable Cardioverter-Defibrillator (ICD) Complications Rate
* Measure Description        :- Patients with physician-specific risk-standardized rates of procedural complications following the first time implantation of an ICD.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- 1
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp348_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp348_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val getPatientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP348Elements.Implantation_Of_Icd_Grouping,
      QPP348Elements.Removal_Of_Icd,
      QPP348Elements.Pneumothorax,
      QPP348Elements.Hemothorax,
      QPP348Elements.Chest_Tube_Insertion,
      QPP348Elements.Blood_Transfusion,
      QPP348Elements.Hematoma_Evacuation,
      QPP348Elements.Documentation_Of_Complications_Or_Mortality,
      QPP348Elements.Doc_Comp_Or_Mortality_Not_Met
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryRDD.collect().toList)

    val leastRecentPatientHistoryListRDD = leastRecentPatientList(initialRDD,
      QPP348Elements.Implantation_Of_Icd_Grouping,
      QPP348Elements.Removal_Of_Icd,
      QPP348Elements.Pneumothorax,
      QPP348Elements.Hemothorax,
      QPP348Elements.Chest_Tube_Insertion,
      QPP348Elements.Blood_Transfusion,
      QPP348Elements.Hematoma_Evacuation,
      QPP348Elements.Documentation_Of_Complications_Or_Mortality,
      QPP348Elements.Doc_Comp_Or_Mortality_Not_Met)

    val leastRecentBroadcastPatientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastRecentPatientHistoryListRDD)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList, leastRecentBroadcastPatientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*
  All patients aged 65 years and older who have a history of falls (history of falls is defined as 2 or more falls in
  the past year or any fall with injury in the past year). Documentation of patient reported history of falls is sufficient
   */

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], leastRecentBroadcastPatientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 65)
        && wasFirstProcedurePerformedWithinXPeriodBeforeEnd(visit, m, QPP348Elements.Implantation_Of_Icd_Grouping, "DAYS", 31, CompareOperator.GREATER_EQUAL, leastRecentBroadcastPatientHistoryList)
    )
  }

  //Hospice services for patient provided any time during the measurement period
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
      isProcedurePerformed(visit, m, QPP348Elements.Removal_Of_Icd, patientHistoryBroadcastList)
    )
  }

  //Patients who had a risk assessment for falls completed within 12 months
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
        isPatientExpiredInXDaysAfterProcedure(visit, m, QPP348Elements.Implantation_Of_Icd_Grouping, AdminElements.Encounter_Date, 30, patientHistoryBroadcastList)
          || (
          (
            wasDiagnosedAfterXDaysProcedure(visit, m, QPP348Elements.Implantation_Of_Icd_Grouping, QPP348Elements.Pneumothorax, 30, patientHistoryBroadcastList)
              || wasDiagnosedAfterXDaysProcedure(visit, m, QPP348Elements.Implantation_Of_Icd_Grouping, QPP348Elements.Hemothorax, 30, patientHistoryBroadcastList)
            )
            && wasProcedurePerformedStartsXDaysAfterEndOfProcedure(visit, m, QPP348Elements.Chest_Tube_Insertion, QPP348Elements.Implantation_Of_Icd_Grouping, 30, patientHistoryBroadcastList)

          )
          || (
          wasProcedurePerformedStartsXDaysAfterEndOfProcedure(visit, m, QPP348Elements.Hematoma_Evacuation, QPP348Elements.Implantation_Of_Icd_Grouping, 30, patientHistoryBroadcastList)
            && wasProcedurePerformedStartsXDaysAfterEndOfProcedure(visit, m, QPP348Elements.Blood_Transfusion, QPP348Elements.Implantation_Of_Icd_Grouping, 30, patientHistoryBroadcastList)

          )
          || wasDiagnosisAfterProcedurePerformed(visit, m, QPP348Elements.Documentation_Of_Complications_Or_Mortality, patientHistoryBroadcastList, QPP348Elements.Implantation_Of_Icd_Grouping)


        )
        && !wasDiagnosisAfterProcedurePerformed(visit, m, QPP348Elements.Doc_Comp_Or_Mortality_Not_Met, patientHistoryBroadcastList, QPP348Elements.Implantation_Of_Icd_Grouping)
    )
  }


}
