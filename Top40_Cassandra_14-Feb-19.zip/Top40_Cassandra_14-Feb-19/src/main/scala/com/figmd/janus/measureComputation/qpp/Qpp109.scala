package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ECQM149V7Elements, MeasureProperty, QPP109Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.qpp.Qpp111._

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp109
* Measure Title              :- Osteoarthritis (OA): Function and Pain Assessment
* Measure Description        :- Percentage of patient visits for patients aged 21 years and older with a diagnosis of osteoarthritis (OA) with assessment for function and pain.
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp109 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp109"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP109Elements.Osteoarthritis
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD ,ippRDD, MEASURE_NAME)) {
      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      //exclusionRDD.cache()

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD)
      metRDD.cache()

      // Filter Intermediate B
      val intermediateB = getSubtractRDD(ippRDD, metRDD)
      intermediateB.cache()

      // Filter Denominator Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      //Filter Not Met
      val notMetRDD = intermediateB
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  // /* All patient visits for patients aged 21 years and older with a diagnosis of OA. */
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 21)
        &&
        isVisitTypeIn(visit, m,
          QPP109Elements.Office_Visit
        )
        && isDiagnosisOverlapsEncounter(visit, m, patientHistoryBroadcastList, QPP109Elements.Osteoarthritis)
    )
  }


  // Numerator criteria
  /* Patient visits with assessment for level of function and pain documented (may include the use of a standardized scale or the completion of an assessment questionnaire, such as an SF-36, AAOS Hip & Knee Questionnaire). */

  def getMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (isAssessmentPerformedOnEncounter(visit, m, QPP109Elements.Assessment_Of_Osteoarthritis_Symptoms_And_Functional_Status)
        || isAssessmentPerformedOnEncounter(visit, m, QPP109Elements.Osteoarthritis_Symptoms)
        || isAssessmentPerformedOnEncounter(visit, m, QPP109Elements.Functional_And_Pain_Assessment_Tool)
        || (isAssessmentPerformedOnEncounter(visit, m, QPP109Elements.Pain_Assessment)
        && (isAssessmentPerformedOnEncounter(visit, m, QPP109Elements.Osteoarthritis_Symptoms_And_Status) || isAssessmentPerformedOnEncounter(visit, m, QPP109Elements.Functional_Assessment)))
        )
        && !isAssessmentPerformedOnEncounter(visit, m, QPP109Elements.Osteoarthritis_Functional_Status__Reason_Not_Specified)

    )
  }

}
