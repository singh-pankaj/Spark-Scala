package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP394Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp394
* Measure Title              :- Immunizations for Adolescents
* Measure Description        :- The percentage of adolescents 13 years of age who had the recommended immunizations by their 13th birthday
*                             1) Patients who had one dose of meningococcal vaccine on or between the patient's 11th and 13th birthdays
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 4
* Measure Stratum No.        :- 1
* Measure Stratification     :- 1
* Measure Developer          :- Vrushali Gholap
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp394_1 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp394_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD,
      QPP394Elements.Allergy_To_Vaccine,
      QPP394Elements.Contraindication_To_Vaccine,
      QPP394Elements.Receiving_Hospice_Care,
      QPP394Elements.Hospice_Care_Services,
      QPP394Elements.Meningococcal_Vaccine_G,
      QPP394Elements.Meningococcal_Vaccine,
      QPP394Elements.Mvacc_Not_Met)


    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIppRDD(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Exclusion
      val exclusionRDD = getExclusionRDD(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate for MET
      val intermediateNumerator = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateNumerator.cache()

      // Filter Met
      val metRDD = getMetRDD(intermediateNumerator, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateNumerator, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*--------------------------------------------------------------------------------------------------------------------
     Adolescents who turn 13 years of age during the measurement period
    -------------------------------------------------------------------------------------------------------------------*/

  def getIppRDD(initialRDD: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 13)
        && isAgeBelow(visit, m, false, 14)
        && isVisitTypeIn(visit, m
        , QPP394Elements.Initial_Preventive_Physical_Examination
        , QPP394Elements.Home_Healthcare_Services
        , QPP394Elements.Care_Services_In_Long_Term_Residential_Facility
        , QPP394Elements.Office_Visit
      )
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Meningococcal, Tdap and/or HPV vaccine contraindicated OR patient allergic to the meningococcal, Tdap, and/or HPV vaccine
  OR
  Patients who use hospice services any time during the measurement period
  -------------------------------------------------------------------------------------------------------------------*/
  def getExclusionRDD(rdd: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      wasDiagnosedInHistory(visit, m, QPP394Elements.Allergy_To_Vaccine, patienthistoryList)
        || wasDiagnosedInHistory(visit, m, QPP394Elements.Contraindication_To_Vaccine, patienthistoryList)
        || isPatientCharacteristic(visit, m, QPP394Elements.Receiving_Hospice_Care, patienthistoryList)
        || isInterventionPerformed(visit, m, QPP394Elements.Hospice_Care_Services, patienthistoryList)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Criteria 1: Adolescents who had one dose of meningococcal vaccine on or between the patient's 11th and 13th birthdays
  -------------------------------------------------------------------------------------------------------------------*/
  def getMetRDD(rdd: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      (isImmunizationAdministered(visit, m, QPP394Elements.Meningococcal_Vaccine_G, patienthistoryList)
        || isImmunizationCountMatchingBetweenTwoBirthdays(visit, m, AdminElements.Date_of_Birth, QPP394Elements.Meningococcal_Vaccine, 11, 13, 1, patienthistoryList))
        && !isImmunizationAdministered(visit, m, QPP394Elements.Mvacc_Not_Met, patienthistoryList)
    )
  }
}
