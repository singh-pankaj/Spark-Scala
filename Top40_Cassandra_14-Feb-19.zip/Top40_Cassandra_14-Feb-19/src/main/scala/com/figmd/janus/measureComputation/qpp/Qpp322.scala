package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP322Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp 322
* Measure Title              :- Cardiac Stress Imaging Not Meeting Appropriate Use Criteria: Preoperative Evaluation in Low Risk Surgery Patients.
* Measure Description        :- Percentage of stress single-photon emission computed tomography (SPECT) myocardial perfusion imaging(MPI), stress echocardiogram (ECHO), cardiac computed tomography angiography (CCTA), or cardiac magnetic resonance (CMR) performed in low-risk surgery patients 18 years or older for preoperative evaluation during the 12-month submission period.
* Calculation Implementation :- Procedure specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp322 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp322"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP

    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //getPatientHistoryList
      val patientHistoryList = getPatientHistory(sparkSession, ippRDD,
        QPP322Elements.Pre_Evaluation_Surgery, QPP322Elements.Low_Cardiac_Risk_Surgery,
        QPP322Elements.Cardiac_Stress_Imaging,
        QPP322Elements.Pre_Evaluation_Not_Met
      ).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      //    metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()
      //
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /* All instances of stress single-photon emission computed tomography (SPECT) myocardial perfusion imaging (MPI), stress echocardiogram (ECHO), cardiac computed tomography angiography (CCTA), or cardiac magnetic resonance (CMR) performed on patients aged 18 years and older during the submission period. */

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isDiagnosticStudyPerformedOnEncounter(visit, m, QPP322Elements.Cardiac_Stress_Imaging)

    )
  }


  // Numerator criteria
  /* Number of stress SPECT MPI, stress echo, CCTA, or CMR primarily performed in low risk surgery patients for preoperative evaluation within 30 days preceding low-risk non-cardiac surgery*/

  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ipp.filter(visit =>

      (isAssessmentPerformedBeforeProcedure(visit, m, QPP322Elements.Low_Cardiac_Risk_Surgery, patientHistoryBroadcastList, QPP322Elements.Pre_Evaluation_Surgery)
        &&
        isDiagnosticStudyPerformedInXDaysBeforeProcedure(visit, m, QPP322Elements.Cardiac_Stress_Imaging, QPP322Elements.Low_Cardiac_Risk_Surgery, 30, patientHistoryBroadcastList)
        )
        &&
        (!isAssesmentPerformedDuringEncounter(visit, m, QPP322Elements.Pre_Evaluation_Not_Met)
          ||
          !wasDiagnosticStudyPerformedBeforeXDaysFromProcedure(visit, m, QPP322Elements.Low_Cardiac_Risk_Surgery, 30, patientHistoryBroadcastList, Seq(QPP322Elements.Cardiac_Stress_Imaging))
          )
    )
  }


}

