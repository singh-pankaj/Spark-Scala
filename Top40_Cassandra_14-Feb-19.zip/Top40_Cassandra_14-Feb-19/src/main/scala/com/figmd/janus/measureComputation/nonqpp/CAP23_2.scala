package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAP23_2
* Measure Title               :- Cancer Protocol and Turnaround Time for Carcinoma and Carcinosarcoma of the Endometrium
* Measure Description         :- Percentage of all eligible Carcinoma and Carcinosarcoma of the Endometrium specimens for
*                                which all required data elements of the Cancer Protocol are included AND meet the maximum
*                                4 business day turnaround time (TAT) requirement (Report Date – Accession Date ≤ 4 business days).
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 2
* Measure Developer           :- Aanchal.Rai
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object CAP23_2 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "CAP23_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,CAP23Elements.Confirm_Primary_Endometrial_Carcinoma_Resection
      ,CAP23Elements.Specimen_Accession_Date

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {



      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//IPP - All final pathology reports for eligible carcinoma of the endometrium cases that require the use of a CAP cancer protocol
(includes carcinomas, carcinosarcomas (malignant mixed Müllerian tumor) and neuroendocrine carcinomas arising in the endometrium).
CPT®: 88309 (for abdominal hysterectomy with/without bilateral salpingo-oophorectomy for neoplasia)
AND Any of the ICD 10 codes:
C54.0: malignant neoplasm of isthmus uteri C54.1: malignant neoplasm of endometrium
C54.3: malignant neoplasm of fundus uteri
C54.8: malignant neoplasm of overlapping sites of corpus uteri
C54.9: malignant neoplasm of corpus uteri, unspecified
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
        isLaboratoryTestPerformedOnEncounter(visit,m,CAP23Elements.Surgical_Pathology_Accession_Number)
        &&
        wasDiagnosedBeforeOrEqualEncounter(visit,m,CAP23Elements.Confirm_Primary_Endometrial_Carcinoma_Resection,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//Exclusion - a. Biopsy procedures
  -----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow] ): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      isLaboratoryTestConcurrent(visit,m,CAP23Elements.Biopsy_Date,CAP23Elements.Surgical_Pathology_Accession_Number_Date)
        ||  isLaboratoryTestConcurrent(visit,m,CAP23Elements.Biopsy_Procedure_Date,CAP23Elements.Surgical_Pathology_Accession_Number_Date)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator - Rate 1: All eligible cases containing all of the required elements found in the current CAP Carcinoma of the
Endometrium protocol. Optional data (marked with a “+” in the CAP cancer protocol) is not required but may be present.
The current protocol, the required elements include:
Procedure
Histologic Type
Histologic Grade
Myometrial Invasion
Uterine Serosa Involvement
Cervical Stromal Involvement
Other Tissue/Organ Involvement
Margins (required only if cervix and/or parametrium/paracervix is involved by carcinoma)
a.Ectocervical/Vaginal Cuff Margin
b.Parametrial/Paracervical Margin
Lymphovascular Invasion
Regional Lymph Nodes details
Pathologic Stage Classification (pTNM, AJCC 8th Edition)
* If an item is not applicable, an “N/A” listing is required.
Rate 2: Final pathology report in the laboratory/hospital information system with result verified and reported by the laboratory,
available to the requesting physician(s) within 4 business days.
 -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>

      isLaboratoryTestPerformedAfterWithinXDays(visit,m,CAP23Elements.Specimen_Verification_Date,CAP23Elements.Specimen_Accession_Date,4,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//Exception - a. Cases requiring intradepartmental or extra-departmental consultation.
 -----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      isCommunicationFromProviderToProviderConcurrent(visit,m,CAP23Elements.Confirm_case_required_Consultation_Date,CAP23Elements.Surgical_Pathology_Accession_Number_Date)
    )
  }
}
