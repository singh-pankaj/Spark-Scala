package com.figmd.janus.measureComputation.ecqm


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ECQM145V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm145v8_1
* Measure Title              :- Coronary Artery Disease (CAD): Beta-Blocker Therapy-Prior Myocardial Infarction (MI) or Left Ventricular Systolic Dysfunction (LVEF <40%)
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of coronary artery disease seen within a 12-month period 
*                               who also have a prior MI or a current or prior LVEF <40% who were prescribed beta-blocker therapy
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 1
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm145V7_1 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "Ecqm145V7_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patienthistoryRdd = getPatientHistory(sparkSession, initialRDD,
      ECQM145V7Elements.Coronary_Artery_Disease_No_Mi,
      ECQM145V7Elements.Cardiac_Surgery,
      ECQM145V7Elements.Ejection_Fraction,
      ECQM145V7Elements.Moderate_Or_Severe_Lvsd,
      ECQM145V7Elements.Left_Ventricular_Systolic_Dysfunction,
      ECQM145V7Elements.Heart_Rate_2,
      ECQM145V7Elements.Beta_Blocker_Therapy_For_Lvsd,
      ECQM145V7Elements.Arrhythmia,
      ECQM145V7Elements.Hypotension,
      ECQM145V7Elements.Asthma,
      ECQM145V7Elements.Allergy_To_Beta_Blocker_Therapy,
      ECQM145V7Elements.Intolerance_To_Beta_Blocker_Therapy,
      ECQM145V7Elements.Beta_Blocker_Therapy,
      ECQM145V7Elements.Bradycardia,
      ECQM145V7Elements.Beta_Blocker_Therapy_Ingredient,
      ECQM145V7Elements.Atrioventricular_Block,
      ECQM145V7Elements.Cardiac_Pacer_In_Situ,
      ECQM145V7Elements.Cardiac_Pacer,
      ECQM145V7Elements.Office_Visit,
      ECQM145V7Elements.Outpatient_Consultation,
      ECQM145V7Elements.Nursing_Facility_Visit,
      ECQM145V7Elements.Care_Services_In_Long_Term_Residential_Facility,
      ECQM145V7Elements.Home_Healthcare_Services,
      ECQM145V7Elements.Patient_Provider_Interaction
    )

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistoryRdd.collect().toList)

    val mostRecentpatienthistoryRdd = mostRecentPatientList(patienthistoryRdd, ECQM145V7Elements.Heart_Rate_2)
    val mostRecentElementBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistoryRdd.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(sparkSession: SparkSession, initialRDD, patienthistoryRdd, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      // Filter Eligible
      val denominatorRDD = getEligibleRdd(ippRDD, patientHistoryList)
      denominatorRDD.cache()

      // Filter Not Eligible
      /*val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      noteligibleRDD.cache()*/

      // Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryList)
      metRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(denominatorRDD, metRDD)
      intermediateA.cache()

      // Filter Exceptions
      val exceptionRDD = getexceptionRDD(intermediateA, patientHistoryList, mostRecentElementBroadcastList)
      exceptionRDD.cache()

      // Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryList.destroy()
      mostRecentElementBroadcastList.destroy()
    }
  }

  // IPP criteria  All patients aged 18 years and older with a diagnosis of coronary artery disease seen within a 12-month period
  def getIpp(sparkSession: SparkSession, initialRDD: RDD[CassandraRow], patienthistoryRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    val countElementList: List[(String, Int)] = countElement(patienthistoryRdd, m,
      ECQM145V7Elements.Office_Visit,
      ECQM145V7Elements.Outpatient_Consultation,
      ECQM145V7Elements.Nursing_Facility_Visit,
      ECQM145V7Elements.Care_Services_In_Long_Term_Residential_Facility,
      ECQM145V7Elements.Home_Healthcare_Services,
      ECQM145V7Elements.Patient_Provider_Interaction
    )
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && getEncounterCountFromHistory(visit, m, 2, true, countElementList)
        &&
        (
          wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM145V7Elements.Coronary_Artery_Disease_No_Mi, patientHistoryList)
            || wasProcedurePerformedBeforeOrEqualEncounter(visit, m, ECQM145V7Elements.Cardiac_Surgery, patientHistoryList)
          )

    )
  }

  // Denominator criteria   Equals Initial Population who also have prior (within the past 3 years) MI or a current or prior LVEF <40%
  def getEligibleRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      wasDiagnosticStudyPerformedBeforeOrEqualEncounterWithResult(visit, m, ECQM145V7Elements.Ejection_Fraction, 40, "lt", patientHistoryList)
        || wasDiagnosedBeforeEndOfEncounter(visit, m, ECQM145V7Elements.Moderate_Or_Severe_Lvsd, patientHistoryList)
        || wasDiagnosedBeforeEndOfEncounter(visit, m, ECQM145V7Elements.Left_Ventricular_Systolic_Dysfunction, patientHistoryList)

    )
  }

  // Numerator criteria   Patients who were prescribed beta-blocker therapy
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      isMedicationOrderedOnEncounter(visit, m, ECQM145V7Elements.Beta_Blocker_Therapy_For_Lvsd)
        || wasMedicationActiveInHistory(visit, m, ECQM145V7Elements.Beta_Blocker_Therapy_For_Lvsd, patientHistoryList: Broadcast[List[CassandraRow]])

    )
  }

  // Exception criteria
  // Documentation of medical reason(s) for not prescribing beta-blocker therapy (eg, allergy, intolerance, other medical reasons).
  //
  //Documentation of patient reason(s) for not prescribing beta-blocker therapy (eg, patient declined, other patient reasons).
  //
  //Documentation of system reason(s) for not prescribing beta-blocker therapy (eg, other reasons attributable to the health care system).

  def getexceptionRDD(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], mostRecentElementBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        wasMostRecentPhysicalExamBeforePhysicalExamPerformed(visit, m, ECQM145V7Elements.Heart_Rate, ECQM145V7Elements.Heart_Rate_2, patientHistoryList, mostRecentElementBroadcastList)
          && isPhysicalExamPerformedValueLessThanOnEncounter(visit, m, ECQM145V7Elements.Heart_Rate_2, 50) //rebase or check
          && isPhysicalExamPerformedValueLessThanOnEncounter(visit, m, ECQM145V7Elements.Heart_Rate, 50)
        )
        ||
        (
          isMedicationOrderedOnEncounter(visit, m, ECQM145V7Elements.Medical_Reason)
            || isMedicationOrderedOnEncounter(visit, m, ECQM145V7Elements.Patient_Reason)
            || isMedicationOrderedOnEncounter(visit, m, ECQM145V7Elements.System_Reason_2018)
          )
        ||
        (
          wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM145V7Elements.Arrhythmia, patientHistoryList)
            || wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM145V7Elements.Hypotension, patientHistoryList)
            || wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM145V7Elements.Asthma, patientHistoryList)
            || wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM145V7Elements.Allergy_To_Beta_Blocker_Therapy, patientHistoryList)
            || wasMedicationInToleraneInHistory(visit, m, ECQM145V7Elements.Beta_Blocker_Therapy, patientHistoryList)
            || wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM145V7Elements.Intolerance_To_Beta_Blocker_Therapy, patientHistoryList)
            || wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM145V7Elements.Bradycardia, patientHistoryList)
            || wasMedicationAllergyInHistory(visit, m, ECQM145V7Elements.Beta_Blocker_Therapy_Ingredient, patientHistoryList)
          )
        ||
        (
          wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM145V7Elements.Atrioventricular_Block, patientHistoryList)
            && !wasDiagnosedBeforeEncounter(visit, m, ECQM145V7Elements.Cardiac_Pacer_In_Situ, patientHistoryList)
            && !isDeviceAppliedBeforeOrEqual(visit, m, ECQM145V7Elements.Cardiac_Pacer, patientHistoryList)
          )

    )
  }
}