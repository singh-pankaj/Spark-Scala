
package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AAO20Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO20
* Measure Title               :- Tympanostomy Tubes: Pre-operative Hearing Evaluation in Children
* Measure Description         :- Percentage of patients aged 2 months through 12 years with a diagnosis of otitis media with effusion (OME) who received tympanostomy tube insertion who had a hearing test performed within 6 months
                                 prior to tympanostomy tube insertion
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KAJAL_JADHAO_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.5

----------------------------------------------------------------------------------------------------------------------------*/

object AAO20 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO20"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , AAO20Elements.Otitis_Media_With_Effusion
      , AAO20Elements.Tympanostomy_Tube_Insertion
      , AAO20Elements.Hearing_Test_Performed
      , AAO20Elements.Hearing_Test
      , AAO20Elements.Patient_Reason_Hearing_Testing

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients aged 6 months through 12 years with a diagnosis of OME who received tympanostomy tube insertion.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAboveInMonth(visit, m, true,6)
        && isAgeBelow(visit, m, false, 13)
        && isProcedurePerformedDuringEncounter(visit,m,AAO20Elements.Tympanostomy_Tube_Insertion)
        && wasDiagnosedBeforeEncounter(visit,m,AAO20Elements.Otitis_Media_With_Effusion,patientHistoryBroadcastList)


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who had a hearing test performed within 6 months prior to tympanostomy tube insertion.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      wasDiagnosticStudyPerformedBeforeEncounterWithInXmonths(visit,m,AAO20Elements.Hearing_Test_Performed,6,patientHistoryBroadcastList)
        && isDiagnosticStudyDuringMesurementPeriod(visit,m,AAO20Elements.Hearing_Test,patientHistoryBroadcastList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patient or caregiver(s) refusal of hearing test.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      wasAssessmentPerformedBeforeEncounterWithinXMonths(visit,m,AAO20Elements.Patient_Reason_Hearing_Testing,6,patientHistoryBroadcastList)

    )
  }
}