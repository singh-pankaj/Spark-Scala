
package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CompareOperator, MeasureProperty, QPP117Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 117
* Measure Title              :- Diabetes: Eye Exam
* Measure Description        :- Percentage of patients 18-75 years of age with diabetes who had a retinal or dilated eye exam by an eye care professional during the measurement period or a negative retinal exam (no evidence of retinopathy) in the 12 months prior to the measurement period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp117 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp117"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD, QPP117Elements.Diabetes, QPP117Elements.Hospice_Services,
      QPP117Elements.Hospice_Services, QPP117Elements.Hospice_Services_Snomedct, QPP117Elements.Hospice_Care, QPP117Elements.Retinal_Or_Dilated_Eye_Exam,
      QPP117Elements.Negative_Finding, QPP117Elements.Documentation_Of_Dilated_Retinal_Eye_Exam, QPP117Elements.Negative_Finding,
      QPP117Elements.Dilated_Retinal_Eye_Exam, QPP117Elements.Low_Risk_For_Retinopathy, QPP117Elements.Dilatedeyeexm_Reason_Not_Specified)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect.toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateB = getSubtractRDD(intermediateA, metRDD)

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    rdd.filter(
      visit =>
        wasDiagnosisInHistory(visit, m, QPP117Elements.Diabetes, patientHistoryBroadcastList)
          && isAgeBetween(visit, m, 18, 76)
          && isVisitTypeIn(visit, m, QPP117Elements.Initial_Preventive_Physical_Examination, QPP117Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
          QPP117Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up, QPP117Elements.Ophthalmological_Services,
          QPP117Elements.Office_Visit, QPP117Elements.Home_Healthcare_Services, QPP117Elements.Face_To_Face_Interaction, QPP117Elements.Annual_Wellness_Visit)
    )

  }

  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isInterventionPerformedInHistory(visit, m, QPP117Elements.Hospice_Services, patientHistoryBroadcastList)
        ||
        (
        isInterventionBeforeEnd(visit, m, QPP117Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
               ||
        isInterventionBeforeEnd(visit, m, QPP117Elements.Hospice_Care, patientHistoryBroadcastList)
        )
    )
  }


  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      ((

        (wasAssessmentPerformedXForRetinalDilatedExam(visit, m, QPP117Elements.Retinal_Or_Dilated_Eye_Exam, 12,CompareOperator.LESS, patientHistoryBroadcastList)
          &&
          wasAssessmentPerformedXPeriodForRetinalDilatedExamWithResult(visit, m, QPP117Elements.Retinal_Or_Dilated_Eye_Exam,QPP117Elements.Negative_Finding,12,CompareOperator.LESS,CompareOperator.EQUAL,patientHistoryBroadcastList)
          )
          ||
          (wasAssessmentPerformedXForRetinalDilatedExam(visit, m, QPP117Elements.Documentation_Of_Dilated_Retinal_Eye_Exam, 12,CompareOperator.LESS, patientHistoryBroadcastList)
            ||
          wasAssessmentPerformedXPeriodForRetinalDilatedExamWithResult(visit, m, QPP117Elements.Documentation_Of_Dilated_Retinal_Eye_Exam,QPP117Elements.Negative_Finding,12,CompareOperator.LESS,CompareOperator.EQUAL,patientHistoryBroadcastList)
          )
        ||(
          isAssessmentPerformed(visit, m, QPP117Elements.Dilated_Retinal_Eye_Exam, patientHistoryBroadcastList)
          || isAssessmentPerformed(visit, m, QPP117Elements.Low_Risk_For_Retinopathy, patientHistoryBroadcastList)
        ))
        && ! isAssessmentPerformed(visit, m, QPP117Elements.Dilatedeyeexm_Reason_Not_Specified, patientHistoryBroadcastList)
        )
    )
  }

}