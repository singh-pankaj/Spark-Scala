package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.measureComputation.master.{MeasureProperty,AXON7Elements}
import com.figmd.janus.util.measure._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Axon 07
* Measure Title               :- Falls: Falls screening (aggregation of AAN disease specific falls measures)
* Measure Description         :- Percentage of patients with Parkinson’s disease, multiple sclerosis, distal symmetric
*                                polyneuropathy, ALS, epilepsy, dementia who were screened for falls at least annually
*                                and counseling provided on falls prevention for those with 2 or more falls or 1 fall with injury.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- Rishikesh Patil
* Initial GIT Version/Tag(CRA):- 1.8
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object Axon7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AXON7"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , AXON7Elements.Falls_Screening
      , AXON7Elements.Two_Or_More_Falls_Or_1_Fall_With_Injury
      , AXON7Elements.One_Fall_Or_No_Fall
      , AXON7Elements.Unable_To_Respond
      , AXON7Elements.Cognitive_Impairment
      , AXON7Elements.Patient_Not_Ambulatory
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  //IPP Criteria
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>

      isVisitTypeIn(visit, m
        , AXON7Elements.Care_Services_In_Long_Term_Residential_Facility
        , AXON7Elements.Home_Healthcare_Services
        , AXON7Elements.Nursing_Facility_Visit
        , AXON7Elements.Outpatient_Consultation
        , AXON7Elements.Evaluation_And_Management_Physician_Visit
        , AXON7Elements.Home_Care_Visit
        , AXON7Elements.Physical_Examination
        , AXON7Elements.Office_Visit
      )
    &&
        (
          isDiagnosedDuringEncounter(visit, m, AXON7Elements.Multiple_Sclerosis)
          ||
          isDiagnosedDuringEncounter(visit, m, AXON7Elements.Parkinson_s_Disease)
          ||
          isDiagnosedDuringEncounter(visit, m, AXON7Elements.Epilepsy)
          ||
          isDiagnosedDuringEncounter(visit, m, AXON7Elements.Distal_Symmetric_Polyneuropathy)
          ||
          isDiagnosedDuringEncounter(visit, m, AXON7Elements.Dementia)
          ||
          isDiagnosedDuringEncounter(visit, m, AXON7Elements.Amyotrophic_Lateral_Sclerosis)
        )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  //Numerator Criteria
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
    (
      isAssessmentPerformedWithResultDuringEncounter(visit, m, AXON7Elements.Falls_Screening, AXON7Elements.Two_Or_More_Falls_Or_1_Fall_With_Injury)
      &&
      isInterventionPerformedDuringEncounter(visit, m, AXON7Elements.Counseling_For_Falls)
    )
      ||
      isAssessmentPerformedWithResultDuringEncounter(visit, m, AXON7Elements.Falls_Screening, AXON7Elements.One_Fall_Or_No_Fall)
      ||
      isAssessmentPerformedDuringEncounter(visit, m, AXON7Elements.Query_For_Falls)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

  -----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      (
        isPatientCharacteristicDuringEncounter(visit, m, AXON7Elements.Unable_To_Respond)
        &&
        isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, AXON7Elements.Informant_Unavailable)
      )
      ||
      (
       wasPatientCharacteristicInHistory(visit, m, AXON7Elements.Unable_To_Respond, patientHistoryBroadcastList)
       &&
       wasDiagnosisInHistory(visit, m, AXON7Elements.Cognitive_Impairment, patientHistoryBroadcastList)
      )
      ||
      wasPatientCharacteristicInHistory(visit, m, AXON7Elements.Patient_Not_Ambulatory, patientHistoryBroadcastList)
      ||
      isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, AXON7Elements.Patient_Declines)
      ||
      isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, AXON7Elements.Patient_Declined)
    )
  }
}