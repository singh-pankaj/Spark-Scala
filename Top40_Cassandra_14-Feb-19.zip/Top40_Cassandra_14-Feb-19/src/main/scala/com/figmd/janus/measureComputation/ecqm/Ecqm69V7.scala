package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, CompareOperator, ECQM69V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Ecqm69V7
* Measure Title               :- Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow-Up Plan
* Measure Description         :- Percentage of patients aged 18 years and older with a BMI documented during the current encounter
                                 or during the previous twelve months AND with a BMI outside of normal parameters, a follow-up plan
                                 is documented during the encounter or during the previous twelve months of the current encounter
                                  Normal Parameters:       Age 18 years and older BMI => 18.5 and < 25 kg/m2
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- VRUSHALI.GHOLAP
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm69V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm69V7"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //getPatientHistoryRDD
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD
        ,ECQM69V7Elements.Palliative_Care_Encounter
        ,ECQM69V7Elements.Palliative_Care
        ,ECQM69V7Elements.Medical_Or_Other_Reason_Not_Done
      )

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet)
      metRDD.cache()

      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
/*-----------------------------------------------------------------------------------------------------------------------
  All patients 18 and older on the date of the encounter with at least one eligible encounter during the measurement period
 -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
           isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m, ECQM69V7Elements.Bmi_Encounter_Code_Set)
    )
  }

/*-----------------------------------------------------------------------------------------------------------------------
Patients who are pregnant
Patients receiving palliative care
Patients who refuse measurement of height and/or weight or refuse follow-up
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>

           wasEncounterPerformedBeforeOrEqualOfEncounter(visit, m, ECQM69V7Elements.Palliative_Care_Encounter, patientHistoryBroadcastList)
        || wasInterventionPerformedBeforeEncounter(visit, m, ECQM69V7Elements.Palliative_Care, patientHistoryBroadcastList)
        || wasPhysicalExamNotPerformedDuringEncounter(visit, m, AdminElements.Encounter_Date,ECQM69V7Elements.Patient_Reason_Refused_Date)
        || isDiagnosedOnEncounter(visit, m, ECQM69V7Elements.Pregnancy_Dx)
    )
  }

/*-----------------------------------------------------------------------------------------------------------------------
Patients with a documented BMI during the encounter or during the previous twelve months, AND when the BMI is outside of normal
parameters, a follow-up plan is documented during the encounter or during the previous twelve months of the current encounter
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>

     (     isPatientBMINormal(visit, m, ECQM69V7Elements.Bmi_Loinc_Value, CompareOperator.GREATER_EQUAL,18.5)
        && isPatientBMINormal(visit, m, ECQM69V7Elements.Bmi_Loinc_Value, CompareOperator.LESS,25))
    ||(isPatientBMINormal(visit, m, ECQM69V7Elements.Bmi_Loinc_Value,  CompareOperator.GREATER_EQUAL,25)
        &&
        (  isInterventionOrderOnEncounter(visit, m, ECQM69V7Elements.Above_Normal_Follow_Up)
        || isInterventionOrderOnEncounter(visit, m, ECQM69V7Elements.Referrals_Where_Weight_Assessment_May_Occur)
        || isMedicationOrderedOnEncounter(visit, m, ECQM69V7Elements.Above_Normal_Medications)
         ))
    ||(isPatientBMINormal(visit, m, ECQM69V7Elements.Bmi_Loinc_Value,  CompareOperator.LESS,18.5)
        &&
        (  isInterventionOrderOnEncounter(visit, m, ECQM69V7Elements.Below_Normal_Follow_Up)
        || isInterventionOrderOnEncounter(visit, m, ECQM69V7Elements.Referrals_Where_Weight_Assessment_May_Occur)
        || isMedicationOrderedOnEncounter(visit, m, ECQM69V7Elements.Below_Normal_Medications)
         ))
    )
  }

/*-----------------------------------------------------------------------------------------------------------------------
  Patients with a documented Medical Reason
  Patients in an urgent or emergent medical situation where time is of the essence and to delay treatment would jeopardize
  the patient's health status
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>

    wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, ECQM69V7Elements.Medical_Or_Other_Reason_Not_Done, 12, patientHistoryBroadcastList)

    )
  }
}

