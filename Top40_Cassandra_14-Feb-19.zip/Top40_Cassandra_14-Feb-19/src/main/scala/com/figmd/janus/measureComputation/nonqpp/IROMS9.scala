package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,IROMS9Elements,AdminElements,CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IROMS9
* Measure Title               :- Failure to Progress (FTP): Proportion of patients failing to achieve a Minimal Clinically Important Difference (MCID)
                                  to indicate functional improvement in rehabilitation of patients with neck pain/injury measured via the validated
                                  Neck Disability Index (NDI).
* Measure Description         :- The proportion of patients failing to achieve an MCID of ten (10) points or more improvement in the NDI change
                                  score for neck pain/injury patients treated during the observation period will be reported.
                                 Additionally, a risk-adjusted NDI change proportional difference will be determined by calculating the difference
                                  between the risk model predicted and observed MCID proportion will reported for each physical therapist or
                                  physical therapy group. The risk adjustment will be calculated using a logistic regression model using:
                                  baseline NDI score, baseline pain score, age, sex, payer, and symptom duration
                                  (time from surgery or injury to baseline physical therapy visit).
                                 These measures will serve as a physical or occupational therapy performance measure at the eligible physical or
                                  occupational therapist or physical or occupational therapy group level.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- VRUSHALI.GHOLAP
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.8
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.8
----------------------------------------------------------------------------------------------------------------------------*/

object IROMS9 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IROMS9"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
              ,IROMS9Elements.Occupational_Re_Evaluation_Visit
              ,IROMS9Elements.Physical_Re_Evalution_Visit
              ,IROMS9Elements.Discharge_Summary
              ,IROMS9Elements.Score_Ndi_At_Discharge
              ,IROMS9Elements.Neck_Disability_Index__Ndi_
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryRDD)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

/*-----------------------------------------------------------------------------------------------------------------------
  The total number of neck pain/injury patients evaluated and treated by a physical therapist (PT) or Occupational Therapist (OT),
  or PT or OT Group, during the observation window.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
           isPatientAdult(visit,m)
        && isVisitTypeIn(visit,m,IROMS9Elements.Occupational_Therapy_Visit,IROMS9Elements.Physical_Therapy_Visit)
        && isDiagnosedDuringEncounter(visit,m,IROMS9Elements.Functional_Deficit_Neck)
        && (   wasEncounterPerformedAfterAdmissionVisitBeforeEnd(visit,m,AdminElements.Encounter_Date,IROMS9Elements.Occupational_Re_Evaluation_Visit,patientHistoryBroadcastList)
        || wasEncounterPerformedAfterAdmissionVisitBeforeEnd(visit,m,AdminElements.Encounter_Date,IROMS9Elements.Physical_Re_Evalution_Visit,patientHistoryBroadcastList)
        || wasEncounterPerformedAfterAdmissionVisitBeforeEnd(visit,m,AdminElements.Encounter_Date,IROMS9Elements.Discharge_Summary,patientHistoryBroadcastList)
        )
        && isAssessmentPerformedDuringEncounterWithMethod(visit,m,IROMS9Elements.Ndi_Score_At_Admission,IROMS9Elements.Neck_Disability_Index__Ndi_)
        && (
        wasAssessmentPerformedAfterEncounterWithMethodOnDischargeVisit(visit,m,IROMS9Elements.Occupational_Re_Evaluation_Visit,IROMS9Elements.Neck_Disability_Index__Ndi_,IROMS9Elements.Score_Ndi_At_Discharge,patientHistoryBroadcastList)
          || wasAssessmentPerformedAfterEncounterWithMethodOnDischargeVisit(visit,m,IROMS9Elements.Physical_Re_Evalution_Visit,IROMS9Elements.Neck_Disability_Index__Ndi_,IROMS9Elements.Score_Ndi_At_Discharge,patientHistoryBroadcastList)
          || wasAssessmentPerformedAfterEncounterWithMethodOnDischargeVisit(visit,m,IROMS9Elements.Discharge_Summary,IROMS9Elements.Neck_Disability_Index__Ndi_,IROMS9Elements.Score_Ndi_At_Discharge,patientHistoryBroadcastList)
        )
    )
  }

/*-----------------------------------------------------------------------------------------------------------------------
  Exclude patients who did not complete 2 or more surveys.
  Patients will be excluded if they are non-English speaking and translation services are not available, if they are unable
  to read or have a mental impairment that compromises their understanding.
-----------------------------------------------------------------------------------------------------------------------*/
def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
  val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
  val countRDD = countElement(patientHistoryRDD, m ,IROMS9Elements.Neck_Disability_Index__Ndi_)
  denominatorRDD.filter(visit =>
    getAssessmentEncounterCountFromHistory(visit,m,2,countRDD)

  )
}


  /*-----------------------------------------------------------------------------------------------------------------------
The total number of patients with neck pain/injury to not achieve an MCID in their NDI change score (MCID >10) from their
initial visits to their final visits in PT/OT practice or PT/OT group during the observation window.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      wasScoreDifferenceBetweenAssessmentAndDischarge(visit,m,IROMS9Elements.Ndi_Score_At_Admission,IROMS9Elements.Score_Ndi_At_Discharge,10,CompareOperator.GREATER,patientHistoryBroadcastList)

    )
  }

/*-----------------------------------------------------------------------------------------------------------------------
PT/OT can use their clinical judgement to exclude patients who are extremely medically complex, who in their experience 
are likely to make poor clinical progress.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>

      isDiagnosticStudyPerformedDuringEncounter(visit,m,IROMS9Elements.Medically_Complex_Gr)
    )
  }
}

