package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP388Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp 388
* Measure Title              :- Cataract Surgery with Intra-Operative Complications (Unplanned Rupture of Posterior Capsule Requiring Unplanned Vitrectomy)
* Measure Description        :- Percentage of patients aged 18 years and older who had cataract surgery performed and had an unplanned rupture of the posterior capsule requiring vitrectomy
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp388 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp388"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

      //getPatientHistoryList
      val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
        QPP388Elements.History_Of_Preoperative_Posterior_Capsule_Rupture_G,
        QPP388Elements.History_Preoperative_Posterior_Capsule_Rupture).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

      if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

        //Denominator is equal to IPP
        val denominatorRDD = ippRDD
        denominatorRDD.cache()

        val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
        exclusionRDD.cache()

        val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
        intermediateForMet.cache()

        val metRDD = getMet(intermediateForMet)
        metRDD.cache()

        val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


        val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
        notMetRDD.cache()

        saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
        patientHistoryBroadcastList.destroy()

      }

    }


  // IPP-Denominator criteria
  /* All patients aged 18 years and older who had cataract surgery */

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>

      isPatientAdult(visit, m) &&
        isProcedurePerformedDuringEncounter(visit, m, QPP388Elements.Cataract_Surgery)
        && isProcedurePerformedOnXProcedure(visit, m, Seq(QPP388Elements.Cataract_Surgery_Eye, QPP388Elements.Cataract_Surgery))
        && !isProcedurePerformedDuringEncounter(visit, m, QPP388Elements.Cataract_Surgery_Modifiers)
    )
  }


  /* History of preoperative posterior capsule rupture */
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>

      isPatientAdult(visit, m) &&
        wasDiagnosedInHistory(visit, m, QPP388Elements.History_Of_Preoperative_Posterior_Capsule_Rupture_G, patientHistoryBroadcastList)
        && wasDiagnosedInHistory(visit, m, QPP388Elements.History_Preoperative_Posterior_Capsule_Rupture, patientHistoryBroadcastList)

    )
  }


  // Numerator criteria
  /* Patients who experienced an unplanned rupture of the posterior capsule requiring vitrectomy during cataract surgery */

  def getMet(intermediateForMet: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
        (isPhysicalExamPerformedDuringXProcedure(visit, m, Seq(QPP388Elements.Unplanned_Rupture, QPP388Elements.Cataract_Surgery))
          && isPhysicalExamPerformedDuringXProcedure(visit, m, Seq(QPP388Elements.Unplanned_Rupture_Eye, QPP388Elements.Unplanned_Rupture))
          && isProcedurePerformedOnXProcedure(visit, m, Seq(QPP388Elements.Vitrectomy, QPP388Elements.Cataract_Surgery))
          && isProcedurePerformedOnXProcedure(visit, m, Seq(QPP388Elements.Vitrectomy_Eye, QPP388Elements.Vitrectomy))
          )
          ||
          isPhysicalExamPerformedDuringEncounter(visit, m, QPP388Elements.Unplanned_Rupture_Posterior_Capsule_Req_Vitrectomy)
        )
        && !isPhysicalExamPerformedDuringEncounter(visit, m, QPP388Elements.Unplanned_Rupture_Posterior_Capsule_Req_Vitrectomy_Not_Met)
    )
  }

}
