package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CAP27Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAP27_2
* Measure Title               :- Cancer Protocol and Turnaround Time for Invasive Carcinoma of Renal Tubular Origin
* Measure Description         :-  Percentage of all eligible kidney resections specimens:
                                  Partial Nephrectomy
                                  Total Nephrectomy
                                  Radical Nephrectomy
                                  for which all required data elements of the Cancer Protocol are included
                                  AND meet the maximum 4 business day turnaround time (TAT) requirement (Report Date – Accession Date ≤ 4 business days).
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KIRTI_RAUT_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.8
----------------------------------------------------------------------------------------------------------------------------*/

object CAP27_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "CAP27_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      CAP27Elements.Specimen_Verification_Date,
      CAP27Elements.Specimen_Accession_Date,
      CAP27Elements.Confirm_Renal_Tubular_Carcinoma_Resection
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population :
All final pathology reports for eligible kidney resection cases that require the use of a CAP cancer protocol.
CPT®: 88307
AND
Any of the ICD 10 codes:
C64: malignant neoplasm of kidney, except renal pelvis
C64.1: malignant neoplasm of right kidney, except renal pelvis
C64.2: malignant neoplasm of left kidney, except renal pelvis
C64.9: malignant neoplasm of unspecified kidney, except renal pelvis
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
        wasDiagnosisBeforeOrEqualProcedure(visit,m,CAP27Elements.Confirm_Renal_Tubular_Carcinoma_Resection,CAP27Elements.Surgical_pathology_accession_number,patientHistoryBroadcastList)
          &&  isProcedurePerformedDuringEncounter(visit,m,CAP27Elements.Surgical_pathology_accession_number) // Its a Procedure Specific measure hence checking Procedure on Encounter rather than during measurement period

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exclusion :
1.Biopsy procedures
2.Wilms tumors
3.Tumors of urothelial origin
Lymphoma and Sarcoma
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
      (      isLaboratoryTestPerformedDuringProcedure(visit,m,CAP27Elements.Biopsy,CAP27Elements.Biopsy_Date,CAP27Elements.Surgical_pathology_accession_number,CAP27Elements.Surgical_pathology_accession_number_Date)
        ||   isDiagnosedDuringProcedure(visit,m,CAP27Elements.Lymphoma_and_Sarcoma,CAP27Elements.Surgical_pathology_accession_number)
        ||   isDiagnosedDuringProcedure(visit,m,CAP27Elements.Urothelial_and_Wilms_Tumor,CAP27Elements.Surgical_pathology_accession_number)
      )
    || isLaboratoryTestPerformedDuringProcedure(visit,m,CAP27Elements.Biopsy_Dateor_Lymphoma_or_WIlms_Tumor,CAP27Elements.Biopsy_Dateor_Lymphoma_or_WIlms_Tumor_Date,CAP27Elements.Surgical_pathology_accession_number,CAP27Elements.Surgical_pathology_accession_number_Date)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator : Cases requiring intra-departmental or extra-departmental consultation.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      isLaboratoryTestOrderedAfterWithinXBusinessDays(visit,m,CAP27Elements.Specimen_Verification_Date,CAP27Elements.Specimen_Accession_Date,4,patientHistoryBroadcastList)

    )
  }


}