package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ACR08Elements, CalenderUnit, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACR 08
* Measure Title              :- Gout: ULT Therapy
* Measure Description        :- Percentage of patients aged 18 and older with a diagnosis of gout and either tophus/tophi or at least two gout flares (attacks)
*                               in the past year who have a serum urate level  > 6.0 mg/dL, who are prescribed urate lowering therapy (ULT).
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/
object ACR08 extends MeasureUtilityUpdate with MeasureUpdate {

val MEASURE_NAME = "ACR08"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD,
      ACR08Elements.Occurence_Of_Gout_Flares,
      ACR08Elements.Serum_Urate_Level_Measurement,
      ACR08Elements.Gouty_Tophus,
      ACR08Elements.Urate_Lowering_Therapy__Ult_,
      ACR08Elements.Gout
    )

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIppRDD(initialRDD, patientHistoryList, patientHistoryRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      // Eligible IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMetRDD(intermediateA, patientHistoryList)
      metRDD.cache()
      // Filter not Met

      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
   Adult patients aged 18 and older with a diagnosis of gout and a serum urate level > 6.0 mg/dL who have at least one of the following:
   presence of tophus/tophi or two or more gout flares (attacks) in the past year.
   ----------------------------------------------------------------------------------------------------------------------------*/

  def getIppRDD(initialRDD: RDD[CassandraRow],patientHistoryList :Broadcast[List[CassandraRow]],patientHistoryRDD : RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    val goultFlaresCount = countElement(patientHistoryRDD, m,  ACR08Elements.Occurence_Of_Gout_Flares)

    initialRDD.filter(visit =>
          isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
            && isVisitTypeIn(visit, m, ACR08Elements.Face_To_Face_Interaction,
                                        ACR08Elements.Office_Visit,
                                        ACR08Elements.Home_Healthcare_Services,
                                        ACR08Elements.Care_Services_In_Long_Term_Residential_Facility,
                                        ACR08Elements.Nursing_Facility_Visit,
                                        ACR08Elements.Outpatient_Consultation)
            && wasDiagnosisBeforeOrEqualStartDate(visit, m, ACR08Elements.Gout, patientHistoryList)
            && isRecentLaboratoryTestResultGreaterThanValue(visit, m, ACR08Elements.Serum_Urate_Level_Measurement, 6, "ge", patientHistoryList)
            && (
              wasDiagnosisBeforeStartInXMonths(visit, m, ACR08Elements.Gouty_Tophus,CalenderUnit.MONTH, 12, patientHistoryList)
              || getEncounterCountFromHistory(visit,m,2,true, goultFlaresCount)
            )

    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
 Patients who are prescribed urate lowering therapy (ULT).
 ----------------------------------------------------------------------------------------------------------------------------*/

  def getMetRDD(rdd: RDD[CassandraRow],patientHistoryList :Broadcast[List[CassandraRow]]): RDD[CassandraRow] =
  {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
   rdd.filter(visit =>
     wasMedicationOrderedAfterDiagnosis(visit, m, ACR08Elements.Urate_Lowering_Therapy__Ult_, patientHistoryList, ACR08Elements.Gout)
   )
  }

}
