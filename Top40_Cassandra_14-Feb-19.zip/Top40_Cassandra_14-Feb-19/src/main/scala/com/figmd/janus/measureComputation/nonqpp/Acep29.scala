package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ACEP29Elements, AdminElements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Acep29
* Measure Title              :- Sepsis Management: Septic Shock: Repeat Lactate Level Measurement
* Measure Description        :- Percentage of emergency department visits for patients aged 18 years and older with septic shock
*                               and an elevated serum lactate result (>2mmol/L) with a second serum lactate measurement ordered following the
*                               elevated serum lactate result during the emergency department visit
* Calculation Implementation :- Visit Specific
* Improvement Notation       :- Higher score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Acep29 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Acep29"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      AdminElements.Emergency_Visit_Arrival_Date,
      AdminElements.Emergency_Visit_Departure_Date,
      ACEP29Elements.Critical_Care_Evaluation_And_Management_Date,
      ACEP29Elements.Acute_Care_Or_Inpatient_Facility
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = getDenominator(ippRDD)
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isEDorCCEncounterPerformed(visit, m, patientHistoryList, AdminElements.Emergency_Visit_Arrival_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management)
        && (isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP29Elements.Septic_Shock, ACEP29Elements.Septic_Shock_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
        || (isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP29Elements.Sepsis, ACEP29Elements.Sepsis_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
        && isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP29Elements.Acute_Hypotension, ACEP29Elements.Acute_Hypotension_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
        )
        ||
        ( wasDiagnosedBeforeEDOrCCEncounter(visit, m, ACEP29Elements.Infection, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date, patientHistoryList)
          && isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP29Elements.Acute_Hypotension, ACEP29Elements.Acute_Hypotension_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
          )
        )
    )
  }

  def getDenominator(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] ={
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      checkElementValueOnEncounter(visit, m,ACEP29Elements.Serum_Lactate, 2, "ge")
    )

  }

  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>

      wasPatientTransferedFromAcuteCareWithinXHours(visit, m, ACEP29Elements.Acute_Care_Or_Inpatient_Facility, AdminElements.Emergency_Visit_Arrival_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management, 6, patientHistoryList)
        ||
        (isPatientLeftBeforeTreatmentCompletionOnEDOrCCEncounter(visit, m, ACEP29Elements.Left_Before_Treatment_Completion, ACEP29Elements.Left_Before_Treatment_Completion_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
          || isPatientExpiredOnEDOrCCEncounter(visit, m, ACEP29Elements.Patient_Expired, ACEP29Elements.Patient_Expired_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
          )
        || (
        (isEncounterPerformedOnEncounter(visit, m, ACEP29Elements.Critical_Care_Evaluation_And_Management)
          || isEncounterPerformedOnEncounter(visit, m, ACEP29Elements.Emergency_Department_Visit))
        && (isDateTimeBetweenLessXHours(visit, m, ACEP29Elements.Serum_Lactate_Date, AdminElements.Emergency_Visit_Arrival_Date, 2)
          || isDateTimeBetweenLessXHours(visit, m, ACEP29Elements.Serum_Lactate_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date, 2))
      )
        ||
        (
          isInterventionOrderedDuringEDOrCCEncounter(visit, m, ACEP29Elements.Comfort_Measures, ACEP29Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
            || isInterventionPerformedDuringEDOrCCEncounter(visit, m, ACEP29Elements.Comfort_Measures, ACEP29Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
            || isCommunicationFromPatientToProviderDoneDuringEDOrCCEncounter(visit, m, ACEP29Elements.Declined_Sepsis_Care, ACEP29Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP29Elements.Cardiac_Arrest, ACEP29Elements.Cardiac_Arrest_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP29Elements.Second_And_Third_Degree_Burn, ACEP29Elements.Second_And_Third_Degree_Burn_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP29Elements.Seizure, ACEP29Elements.Seizure_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP29Elements.Gastrointestinal_Hemorrhage, ACEP29Elements.Gastrointestinal_Hemorrhage_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP29Elements.Hemorrhagic_Stroke, ACEP29Elements.Hemorrhagic_Stroke_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP29Elements.Ischemic_Stroke, ACEP29Elements.Ischemic_Stroke_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP29Elements.Myocardial_Infarction, ACEP29Elements.Myocardial_Infarction_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP29Elements.Toxicological_Emergency, ACEP29Elements.Toxicological_Emergency_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP29Elements.Trauma, ACEP29Elements.Trauma_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)

          )
    )
  }


  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>

      isLaboratoryTestStartedAfterProcedure(visit, m, ACEP29Elements.Repeat_Serum_Lactate_Order, ACEP29Elements.Serum_Lactate, patientHistoryList)
      &&
      isLaboratoryTestOrderDuringEDOrCCEncounter(visit, m, ACEP29Elements.Repeat_Serum_Lactate_Order, ACEP29Elements.Repeat_Serum_Lactate_Order_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP29Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }
}
