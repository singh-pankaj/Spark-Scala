package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP19Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 19
* Measure Title              :- Diabetic Retinopathy: Communication with the Physician Managing Ongoing Diabetes Care
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of diabetic retinopathy
                                who had a dilated macular or fundus exam performed with documented communication to
                                the physician who manages the ongoing care of the patient with diabetes mellitus
                                regarding the findings of the macular or fundus exam at least once within 12 months.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/



object  Qpp19  extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp19"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patienthistory = getPatientHistory(sparkSession,initialRDD
      ,QPP19Elements.Communication_To_The_Physician
      ,QPP19Elements.Presence_Absence_Of_Macular_Edema_And_Level_Of_Severity_Of_Retinopathy
      ,QPP19Elements.Dilated_Macular_Or_Fundus_Exam_Findings_Communicated
      ,QPP19Elements.Communication_To_The_Physician
      ,QPP19Elements.Level_Of_Severity_Of_Retinopathy
      ,QPP19Elements.Level_Of_Severity_Of_Retinopathy_Findings
      ,QPP19Elements.Macular_Edema_Findings_Present
      ,QPP19Elements.Macular_Edema_Findings_Absent
      ,QPP19Elements.Documentation_Of_Macular_Edema
      ,QPP19Elements.Medical_Reason
      ,QPP19Elements.Patient_Reason).collect().toList

    val patientHistoryBroadcastList:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistory)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }



  /*--------------------------------------------------------------------------------------------------------------------
  All patients aged 18 years and older with a diagnosis of diabetic retinopathy who had a dilated macular or fundus exam performed.
  --------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
         isPatientAdult(visit,m)
      && isVisitTypeIn(visit,m
                              ,QPP19Elements.Ophthalmological_Services
                              ,QPP19Elements.Care_Services_In_Long_Term_Residential_Facility
                              ,QPP19Elements.Nursing_Facility_Visit
                              ,QPP19Elements.Office_Visit
                              ,QPP19Elements.Outpatient_Consultation
                              ,QPP19Elements.Face_To_Face_Interaction)
      && isDiagnosedOnEncounter(visit,m,QPP19Elements.Diabetic_Retinopathy)
      && (
              isProcedurePerformed(visit,m,QPP19Elements.Presence_Absence_Of_Macular_Edema_And_Level_Of_Severity_Of_Retinopathy,patientHistoryBroadcastList)
          ||  (
                   isPhysicalExamPerformedDuringEncounter(visit,m,QPP19Elements.Macular_Exam)
                && (
                        isPhysicalExamPerformedDuringEncounter(visit,m,QPP19Elements.Level_Of_Severity_Of_Retinopathy)
                     && isAssessmentPerformedDuringEncounter(visit,m,QPP19Elements.Documentation_Of_Macular_Edema)
                   )
                )
          || (
                isPhysicalExamPerformedDuringEncounter(visit,m,QPP19Elements.Dilated_Macular_Or_Fundus)
                  && (
                        isPhysicalExamPerformedDuringEncounter(visit,m,QPP19Elements.Level_Of_Severity_Of_Retinopathy)
                     && isAssessmentPerformedDuringEncounter(visit,m,QPP19Elements.Documentation_Of_Macular_Edema)
                     )
                )
          )
      && !isTeleHealthModifier(visit,m
                                      ,QPP19Elements.Care_Services_In_Long_Term_Residential_Facility
                                      ,QPP19Elements.Nursing_Facility_Visit
                                      ,QPP19Elements.Office_Visit
                                      ,QPP19Elements.Ophthalmological_Services
                                      ,QPP19Elements.Outpatient_Consultation
                                      )
      && isPOSEncounterNotPerformed(visit,m,QPP19Elements.Pos_02)
    )

  }

  /*--------------------------------------------------------------------------------------------------------------------
   Patients with documentation, at least once within 12 months, of the findings of the dilated macular or fundus exam
   via communication to the physician who manages the patient's diabetic care.
   -------------------------------------------------------------------------------------------------------------------*/


  def getMet(denominatorRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    denominatorRDD.filter(visit =>
        (
             wasCommunicationFromProvidertoProviderAfterEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP19Elements.Dilated_Macular_Or_Fundus_Exam_Findings_Communicated)
          || (
                wasCommunicationFromProvidertoProviderAfterEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP19Elements.Communication_To_The_Physician)
             && wasCommunicationFromProvidertoProviderAfterEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP19Elements.Level_Of_Severity_Of_Retinopathy
                                                                                                                            ,QPP19Elements.Level_Of_Severity_Of_Retinopathy_Findings)
             && wasCommunicationFromProvidertoProviderAfterEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP19Elements.Macular_Edema_Findings_Present
                                                                                                                            ,QPP19Elements.Macular_Edema_Findings_Absent
                                                                                                                            ,QPP19Elements.Documentation_Of_Macular_Edema)
             )
        )
     && !isCommunicationFromProvidertoProviderNotDone(visit,m,QPP19Elements.Exam_Findings_Reason_Not_Specified,patientHistoryBroadcastList)

    )
  }

  /*-------------------------------------------------------------------------------------------------------------------
  Documentation of medical reason(s) for not communicating the findings of the dilated macular or fundus exam to
  the physician who manages the ongoing care of the patient with diabetes.

  Documentation of patient reason(s) for not communicating the findings of the dilated macular or fundus exam to
  the physician who manages the ongoing care of the patient with diabetes.

  Documentation of medical reason(s) for not communicating the findings of the dilated macular or fundus exam to
  the physician or other qualified health care professional managing the ongoing care of the patient with diabetes.

  Documentation of patient reason(s) for not communicating the findings of the dilated macular or fundus exam to
  the physician or other qualified health care professional managing the ongoing care of the patient with diabetes.
  -------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateForException: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {


    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    intermediateForException.filter(visit =>
          wasCommunicationFromProvidertoProviderAfterEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP19Elements.Medical_Reason
                                                                                                                        ,QPP19Elements.Patient_Reason)
      ||  isCommunicationFromProviderToProviderOnEncounter(visit,m,QPP19Elements.Exam_Findings_Medical_Reason)
      ||  isCommunicationFromProviderToProviderOnEncounter(visit,m,QPP19Elements.Exam_Findings_Patient_Reason)

    )
  }

}
