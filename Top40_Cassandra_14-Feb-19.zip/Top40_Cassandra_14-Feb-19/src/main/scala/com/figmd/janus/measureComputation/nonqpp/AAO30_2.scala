package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO30_2
* Measure Title               :- Early Oral Cancer: Staging and Treatment
* Measure Description         :- Percentage of patients with a diagnosis of oral cavity cancer seen in the practice setting
                                 who have a TNM cancer stage documented in the medical record within one month of the first
                                 office visit AND who receive treatment if identified with a primary tumor depth > 4 mm
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 2
* Measure Developer           :- Aanchal.Rai
* Initial GIT Version/Tag(CRA):- 1.8
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object AAO30_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO30_2"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,AAO30Elements.Primary_Tumor_Depth
      ,AAO30Elements.Expired
      ,AAO30Elements.Patient_Refusal

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  /*--------------------------------------------------------------------------------------------------------------------------
  IPP- 1. Patients aged 18 and older diagnosed with early oral cavity cancer.

       2. Patients 18 years or older diagnosed with clinical node negative (clinical state T1N0M0 or T2N0M0) oral cavity
          cancer with the depth of the primary tumor > 4mm documented in the medical record within one month of the first office visit.
  ----------------------------------------------------------------------------------------------------------------------------- */


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
        isPatientAdult(visit,m)
        &&
        isVisitTypeIn(visit,m,AAO30Elements.Office_Visit)
        &&
        isDiagnosedDuringEncounter(visit,m,AAO30Elements.Node_Negative_Oral_Cavity_Cancer)
        &&
        isAssesssmentPerformedXDaysAfterEncounter(visit,m,AAO30Elements.Primary_Tumor_Depth,31,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Exclusion - Exclude patients who expire prior to treatment.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
      isPatientExpiredXDaysAfterEncounter(visit,m,AAO30Elements.Expired,31,patientHistoryBroadcastList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator - 1. Patients for which cancer stage at the diagnosis is documented in the medical record within 31 days of the first office visit.

            2. Patients who receive any of the following surgical treatment of the primary tumor: Sentinel lymph node biopsy,
               elective neck dissection, definitve radiation.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
        wasProcedureDoneAfterAssessment(visit,m,AAO30Elements.Sentinel_Lymph_Node_Biopsy_Oral_Cancer_Date,patientHistoryBroadcastList,AAO30Elements.Primary_Tumor_Depth)
      ||
        wasProcedureDoneAfterAssessment(visit,m,AAO30Elements.Elective_Neck_Dissection,patientHistoryBroadcastList,AAO30Elements.Primary_Tumor_Depth)
      ||
        wasProcedureDoneAfterAssessment(visit,m,AAO30Elements.Definitive_Radiation_Of_The_Neck,patientHistoryBroadcastList,AAO30Elements.Primary_Tumor_Depth)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Exception - Medical reasons for not performing surgical treatment or patient refusal of treatment.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      isCommmunicationFromPatientToProviderDoneXDaysAfterEncounter(visit,m,AAO30Elements.Patient_Refusal,31,patientHistoryBroadcastList)
        ||
        !wasProcedurePerformedForMedicalReasonAfterAssessment(visit,m,AAO30Elements.Medical_Reason,AAO30Elements.Primary_Tumor_Depth,AAO30Elements.Medical_Reason_SNLB,patientHistoryBroadcastList)


    )
  }
}

