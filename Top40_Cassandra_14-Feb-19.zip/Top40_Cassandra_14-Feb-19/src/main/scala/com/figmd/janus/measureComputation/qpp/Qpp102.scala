package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CompareOperator, MeasureProperty, QPP102Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Qpp102
* Measure Title               :- Prostate Cancer: Avoidance of Overuse of Bone Scan for Staging Low Risk Prostate Cancer Patients
* Measure Description         :- Percentage of patients, regardless of age, with a diagnosis of prostate cancer at low
*                               (or very low) risk of recurrence receiving interstitial prostate brachytherapy,
*                               OR external beam radiotherapy to the prostate, OR radical prostatectomy,
*                               OR cryotherapy who did not have a bone scan performed at any time since diagnosis of prostate cancer.
* Calculation Implementation  :- Episode specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.7
* Latest GIT Version/Tag(CRA) :- 1.7
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp102 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp102"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
                , QPP102Elements.Prostate_Cancer
                , QPP102Elements.Prostate_Specific_Antigen_Test
                , QPP102Elements.Documentation_Of_Psa_In_Md_Notes
                , QPP102Elements.Documentation_Of_Primary_Gleason_Score
                , QPP102Elements.Documentation_Of_Primary_Gleason_Score_Date
                , QPP102Elements.Documentation_Of_Secondary_Gleason_Score
                , QPP102Elements.Documentation_Of_Secondary_Gleason_Score_Date
                , QPP102Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes
                , QPP102Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes_Date
                , QPP102Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes
                , QPP102Elements.Gleason_Score_Low_Risk
                , QPP102Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes_Date
                , QPP102Elements.Gleason_Score_V
                , QPP102Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes
                , QPP102Elements.Documentation_Of_Clinical_T_Staging
                , QPP102Elements.Cancer_Staging
                , QPP102Elements.Prostate_Cancer_Primary_Tumor_Size_T1a
                , QPP102Elements.Prostate_Cancer_Primary_Tumor_Size_T1b
                , QPP102Elements.Prostate_Cancer_Primary_Tumor_Size_T1c
                , QPP102Elements.Prostate_Cancer_Primary_Tumor_Size_T2a
                , QPP102Elements.Documentation_Of_Clinical_T_Stage_In_Md_Notes__Very_Low_Risk
                , QPP102Elements.Risk_Stratification_Of_Prostate_Cancer
                , QPP102Elements.Bone_Scan_Met
                , QPP102Elements.Bone_Scan_Not_Met
                , QPP102Elements.Bone_Scan_Md_Notes
                , QPP102Elements.Bone_Scan
                , QPP102Elements.Pain_Related_To_Prostate_Cancer
                , QPP102Elements.Salvage_Therapy
                , QPP102Elements.Salvage_Thearpy_Md_Notes
                , QPP102Elements.Reason_Documented
                , QPP102Elements.Bone_Scan_System_Reason
                , QPP102Elements.Bone_Scan_Medical_Reason
                , QPP102Elements.Prostate_Cancer_Treatment_Surgery
                , QPP102Elements.Gold__Fiducial_Marker
                , QPP102Elements.Interstitial_Prostate_Brachytherapy
                , QPP102Elements.External_Beam_Radiotherapy
                , QPP102Elements.Cryotherapy
                , QPP102Elements.Prostate_Cancer_Treatment_Radiation
                , QPP102Elements.Radical_Prostatectomy
                , QPP102Elements.Gold__Fiducial_Markers_In_Md_Notes
                , QPP102Elements.Documentation_Of_Cryotherapy_In_Md_Notes
                , QPP102Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes
                , QPP102Elements.Documentation_Of_Ebrt_In_Md_Notes
                , QPP102Elements.Documentation_Of_Brachytherapy_In_Md_Notes
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients, regardless of age, with a diagnosis of prostate cancer at low (or very low) risk of recurrence receiving
interstitial prostate brachytherapy, OR external beam radiotherapy to the prostate, OR radical prostatectomy, OR cryotherapy
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
          isPatientCharacteristicDuringEncounter(visit, m, QPP102Elements.Male)
        &&
          wasDiagnosedInHistory(visit, m, QPP102Elements.Prostate_Cancer, patientHistoryBroadcastList)
        &&
          (
            (
              (
                  wasElementBeforeProstateCancerTreatmentWithValue(visit, m, QPP102Elements.Prostate_Specific_Antigen_Test, 10, CompareOperator.LESS, patientHistoryBroadcastList)
                ||
                  wasElementBeforeProstateCancerTreatmentWithValue(visit, m, QPP102Elements.Documentation_Of_Psa_In_Md_Notes, 10, CompareOperator.LESS, patientHistoryBroadcastList)
              )
              &&
              (
                    wasSumOfLaboratoryTestResultsBeforeProstateCancerTreatment(visit, m, QPP102Elements.Documentation_Of_Primary_Gleason_Score,
                          QPP102Elements.Documentation_Of_Primary_Gleason_Score_Date, QPP102Elements.Documentation_Of_Secondary_Gleason_Score,
                          QPP102Elements.Documentation_Of_Secondary_Gleason_Score_Date, 6, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
                ||
                    wasSumOfLaboratoryTestResultsBeforeProstateCancerTreatment(visit, m, QPP102Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,
                      QPP102Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes_Date, QPP102Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,
                      QPP102Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes_Date, 6, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
                ||
                  wasElementBeforeProstateCancerTreatment(visit, m, QPP102Elements.Gleason_Score_Low_Risk, patientHistoryBroadcastList)
                ||
                  wasElementBeforeProstateCancerTreatmentWithValue(visit, m, QPP102Elements.Gleason_Score_V, 6, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
                ||
                  wasElementBeforeProstateCancerTreatmentWithValue(visit, m, QPP102Elements.Documentation_Of_Gleason_Score_In_The_Md_Notes, 6, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
              )
              &&
              (
                  wasElementBeforeProstateCancerTreatment(visit, m, QPP102Elements.Documentation_Of_Clinical_T_Staging, patientHistoryBroadcastList)
                ||
                  wasElementBeforeProstateCancerTreatmentWithResult(visit, m, QPP102Elements.Cancer_Staging, QPP102Elements.Prostate_Cancer_Primary_Tumor_Size_T1a, patientHistoryBroadcastList)
                ||
                  wasElementBeforeProstateCancerTreatmentWithResult(visit, m, QPP102Elements.Cancer_Staging, QPP102Elements.Prostate_Cancer_Primary_Tumor_Size_T1b, patientHistoryBroadcastList)
                ||
                  wasElementBeforeProstateCancerTreatmentWithResult(visit, m, QPP102Elements.Cancer_Staging, QPP102Elements.Prostate_Cancer_Primary_Tumor_Size_T1c, patientHistoryBroadcastList)
                ||
                  wasElementBeforeProstateCancerTreatmentWithResult(visit, m, QPP102Elements.Cancer_Staging, QPP102Elements.Prostate_Cancer_Primary_Tumor_Size_T2a, patientHistoryBroadcastList)
                ||
                  wasElementBeforeProstateCancerTreatment(visit, m, QPP102Elements.Documentation_Of_Clinical_T_Stage_In_Md_Notes__Very_Low_Risk, patientHistoryBroadcastList)
              )
            )
            ||
              isAssessmentPerformed(visit,m, QPP102Elements.Risk_Stratification_Of_Prostate_Cancer, patientHistoryBroadcastList)
          )
        &&
          isProstateCancerTreatment(visit, m, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who did not have a bone scan performed at any time since diagnosis of prostate cancer
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        (
            wasDiagnosisDoneAfterInitialDiagnosis(visit, m, QPP102Elements.Bone_Scan_Met, patientHistoryBroadcastList, QPP102Elements.Prostate_Cancer)
          && !
            wasDiagnosisDoneAfterInitialDiagnosis(visit, m, QPP102Elements.Bone_Scan_Not_Met, patientHistoryBroadcastList, QPP102Elements.Prostate_Cancer)
        )
        ||
        (
          ! (
              wasDiagnosisDoneAfterInitialDiagnosis(visit, m, QPP102Elements.Bone_Scan_Md_Notes, patientHistoryBroadcastList, QPP102Elements.Prostate_Cancer)
            &&
              wasDiagnosisDoneAfterInitialDiagnosis(visit, m, QPP102Elements.Bone_Scan, patientHistoryBroadcastList, QPP102Elements.Prostate_Cancer)
            )

        )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Documentation of reason(s) for performing a bone scan (including documented pain, salvage therapy, other medical reasons, bone scan ordered by someone other than reporting physician)
OR
Documentation of medical reason(s) for performing a bone scan (including documented pain, salvage therapy, other medical reasons)
OR
Documentation of system reason(s) for performing a bone scan (including bone scan ordered by someone other than the reporting physician)
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
        wasDiagnosisDoneAfterInitialDiagnosis(visit, m, QPP102Elements.Pain_Related_To_Prostate_Cancer, patientHistoryBroadcastList, QPP102Elements.Prostate_Cancer)
      ||
        wasProcedureAfterDiagnosis(visit, m, QPP102Elements.Salvage_Therapy, patientHistoryBroadcastList, QPP102Elements.Prostate_Cancer)
      ||
        wasProcedureAfterDiagnosis(visit, m, QPP102Elements.Salvage_Thearpy_Md_Notes, patientHistoryBroadcastList, QPP102Elements.Prostate_Cancer)
      ||
        wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QPP102Elements.Prostate_Cancer, QPP102Elements.Bone_Scan, QPP102Elements.Reason_Documented, patientHistoryBroadcastList)
      ||
        wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QPP102Elements.Prostate_Cancer, QPP102Elements.Bone_Scan_Not_Met, QPP102Elements.Bone_Scan_System_Reason, patientHistoryBroadcastList)
      ||
        wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, QPP102Elements.Prostate_Cancer, QPP102Elements.Bone_Scan_Not_Met, QPP102Elements.Bone_Scan_Medical_Reason, patientHistoryBroadcastList)
    )
  }









}