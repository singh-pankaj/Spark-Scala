package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, CompareOperator, MeasureProperty, QPP119Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 119
* Measure Title              :- Diabetes: Medical Attention for Nephropathy
* Measure Description        :- The percentage of patients 18-75 years of age with diabetes who had a nephropathy screening
*                               test or evidence of nephropathy during the measurement period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp119 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp119"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP119Elements.Hospice_Services,
      QPP119Elements.Ace_Inhibitor_Or_Arb,
      QPP119Elements.Hospice_Services_Snomedct,
      QPP119Elements.Hospice_Care,
      QPP119Elements.Hypertensive_Chronic_Kidney_Disease,
      QPP119Elements.Kidney_Failure,
      QPP119Elements.Glomerulonephritis_And_Nephrotic_Syndrome,
      QPP119Elements.Diabetic_Nephropathy,
      QPP119Elements.Proteinuria,
      QPP119Elements.Kidney_Transplant,
      QPP119Elements.Vascular_Access_For_Dialysis,
      QPP119Elements.Dialysis_Services,
      QPP119Elements.Other_Services_Related_To_Dialysis,
      QPP119Elements.Dialysis_Education,
      QPP119Elements.Esrd_Monthly_Outpatient_Services,
      QPP119Elements.Urine_Protein_Tests,
      QPP119Elements.Positive_Microalbuminuria,
      QPP119Elements.Positive_Macroalbuminuria,
      QPP119Elements.Negative_Microalbuminuria,
      QPP119Elements.Treatment_For_Nephropathy,
      QPP119Elements.Ace_Or_Arb_Therapy,
      QPP119Elements.Macroalbuminuria_Test_Not_Met)


    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //Patients 18-75 years of age with diabetes with a visit during the measurement period
  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      /*isAgeAbove(visit, m, true)
        &&
        isAgeBelow(visit, m, false, 76)*/
      isAgeBetween(visit,m,18,CompareOperator.GREATER_EQUAL,76,CompareOperator.LESS,AdminElements.Encounter_Date)
        &&
        isDiagnosedOnEncounter(visit, m, QPP119Elements.Diabetes)
        //isDiagnosisOverlapsMeasurementPeriod(visit,m,patientHistoryBroadcastList,QPP119Elements.Diabetes)
        &&
        isVisitTypeIn(visit, m,
          QPP119Elements.Office_Visit,
          QPP119Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
          QPP119Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
          QPP119Elements.Home_Healthcare_Services,
          QPP119Elements.Face_To_Face_Interaction,
          QPP119Elements.Annual_Wellness_Visit,
          QPP119Elements.Initial_Preventive_Physical_Examination)
    )
  }

  //Patients who use hospice services any time during the measurement period
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit => (

      isInterventionPerformed(visit, m, QPP119Elements.Hospice_Services, patientHistoryBroadcastList)
        ||
        (
          wasInterventionPerformedInHistory(visit, m, QPP119Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
            ||
            wasInterventionPerformedInHistory(visit, m, QPP119Elements.Hospice_Care, patientHistoryBroadcastList)
          //isInterventionOverlapsMeasurementPeriod(visit,m,patientHistoryBroadcastList,QPP119Elements.Hospice_Services_Snomedct,QPP119Elements.Hospice_Care)
          )

      )
    )
  }

  //Patients with a screening for nephropathy or evidence of nephropathy during the measurement period
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit => (
      (
        wasMedicationOrderInHistory(visit, m, QPP119Elements.Ace_Inhibitor_Or_Arb, patientHistoryBroadcastList) //overlaps condition
          ||
          wasDiagnosisInHistory(visit, m, QPP119Elements.Hypertensive_Chronic_Kidney_Disease, patientHistoryBroadcastList)
          ||
          wasDiagnosisInHistory(visit, m, QPP119Elements.Kidney_Failure, patientHistoryBroadcastList)
          ||
          wasDiagnosisInHistory(visit, m, QPP119Elements.Glomerulonephritis_And_Nephrotic_Syndrome, patientHistoryBroadcastList)
          ||
          wasDiagnosisInHistory(visit, m, QPP119Elements.Diabetic_Nephropathy, patientHistoryBroadcastList)
          ||
          wasDiagnosisInHistory(visit, m, QPP119Elements.Proteinuria, patientHistoryBroadcastList)
        //||  isDiagnosisOverlapsEncounter(visit, m, patientHistoryBroadcastList, QPP119Elements.Hypertensive_Chronic_Kidney_Disease, QPP119Elements.Kidney_Failure,QPP119Elements.Glomerulonephritis_And_Nephrotic_Syndrome,QPP119Elements.Diabetic_Nephropathy,QPP119Elements.Proteinuria)
        )
        ||
        (
          isProcedurePerformed(visit, m, QPP119Elements.Kidney_Transplant, patientHistoryBroadcastList)
            ||
            isProcedurePerformed(visit, m, QPP119Elements.Vascular_Access_For_Dialysis, patientHistoryBroadcastList)
            ||
            isProcedurePerformed(visit, m, QPP119Elements.Dialysis_Services, patientHistoryBroadcastList)
            ||
            isInterventionPerformed(visit, m, QPP119Elements.Other_Services_Related_To_Dialysis, patientHistoryBroadcastList)
            ||
            isInterventionPerformed(visit, m, QPP119Elements.Dialysis_Education, patientHistoryBroadcastList)
            ||
            isEncounterPerformed(visit, m, QPP119Elements.Esrd_Monthly_Outpatient_Services, patientHistoryBroadcastList)
            ||
            isLaboratoryTestPerformed(visit, m, QPP119Elements.Urine_Protein_Tests, patientHistoryBroadcastList)
          //|| wasLaboratoryTestDuringMeasurementPeriod(visit,m,QPP119Elements.Urine_Protein_Tests, patientHistoryBroadcastList)
          )
        ||
        (
          isLaboratoryTestPerformed(visit, m, QPP119Elements.Positive_Microalbuminuria, patientHistoryBroadcastList)
            //wasLaboratoryTestDuringMeasurementPeriod(visit,m,QPP119Elements.Positive_Microalbuminuria, patientHistoryBroadcastList)
            ||
            isLaboratoryTestPerformed(visit, m, QPP119Elements.Positive_Macroalbuminuria, patientHistoryBroadcastList)
            // || wasLaboratoryTestDuringMeasurementPeriod(visit,m,QPP119Elements.Positive_Macroalbuminuria, patientHistoryBroadcastList)
            ||
            isLaboratoryTestPerformed(visit, m, QPP119Elements.Negative_Microalbuminuria, patientHistoryBroadcastList)
            // || wasLaboratoryTestDuringMeasurementPeriod(visit,m,QPP119Elements.Negative_Microalbuminuria, patientHistoryBroadcastList)
            ||
            isProcedurePerformed(visit, m, QPP119Elements.Treatment_For_Nephropathy, patientHistoryBroadcastList)
            ||
            isMedicationAdministeredPerformed(visit, m, QPP119Elements.Ace_Or_Arb_Therapy, patientHistoryBroadcastList)
          )
      )
      &&
      !isLaboratoryTestPerformedNotDone(visit, m, QPP119Elements.Macroalbuminuria_Test_Not_Met, patientHistoryBroadcastList) //need to remove Not word from function name
    )
  }
}