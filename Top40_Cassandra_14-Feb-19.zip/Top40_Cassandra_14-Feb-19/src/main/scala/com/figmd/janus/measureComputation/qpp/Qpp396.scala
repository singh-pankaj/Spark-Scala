package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 396
* Measure Title              :- Lung Cancer Reporting (Resection Specimens)
* Measure Description        :- Pathology reports based on resection specimens with a diagnosis of primary lung
                                carcinoma that include the pT category, pN category and for non-small cell lung cancer,
                                histologic type
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp396 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp396"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD )
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

    }
  }

  /*--------------------------------------------------------------------------------------------------------------------
    Pathology reports for resection specimens for primary lung carcinoma
   -------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isLaboratoryTestOrderDuringEncounter(visit, m, QPP396Elements.Generalised_Pathology_Exam)
        && isDiagnosedOnEncounter(visit, m, QPP396Elements.Lung_Cancer)


    )

  }

  /*--------------------------------------------------------------------------------------------------------------------
 Specimen site other than anatomic location of lung, OR classified as NSCLC-NOS
-------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      isLaboratoryTestOrderDuringEncounter(visit, m, QPP396Elements.Non_Lung_Site_Or_Nsclc_Nos)
        || isLaboratoryTestOrderDuringEncounter(visit, m, QPP396Elements.Nsclc_Nos_Or_Non_Lung_Site)

    )

  }


  /*--------------------------------------------------------------------------------------------------------------------
 Pathology reports based on resection specimens with a diagnosis of primary lung carcinoma that include the pT category,
  pN category and for non-small cell lung cancer, histologic type (squamous cell carcinoma, adenocarcinoma
  and NOT NSCLC-NOS)
   -------------------------------------------------------------------------------------------------------------------*/


  def getMet(intermediateForMet: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
        isLaboratoryTestOrderDuringEncounter(visit, m, QPP396Elements.Appropriate_Documentation__Lc_Resection_)
          ||
          (
            (
              isDiagnosedOnEncounter(visit, m, QPP396Elements.Squamous_Cell_Carcinoma)
                || isDiagnosedOnEncounter(visit, m, QPP396Elements.Adenocarcinoma)
                || isLaboratoryTestOrderDuringEncounter(visit, m, QPP396Elements.Absence_Of_Nsclc_Nos)
              )
              && isLaboratoryTestOrderDuringEncounter(visit, m, QPP396Elements.Documentation_Of_Pn_Category)
              && isLaboratoryTestOrderDuringEncounter(visit, m, QPP396Elements.Documentation_Of_Pt_Category)
            )
        )
        && !isAssessmentPerformedDuringEncounter(visit, m, QPP395Elements.Appropriate_Documentation__Lung_Cancer__Not_Met)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
   Documentation of medical reason for not including pT category, pN category and histologic type [For patient with
   appropriate exclusion criteria (e.g. metastatic disease, benign tumors, malignant tumors other than carcinomas,
   inadequate surgical specimens)]
    -------------------------------------------------------------------------------------------------------------------*/


  def getException(intermediateForException: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      isDiagnosedOnEncounter(visit, m, QPP396Elements.Metastatic_Disease)
        || isLaboratoryTestOrderDuringEncounter(visit, m, QPP396Elements.Inadequate_Surgical_Specimens)
        || isDiagnosedOnEncounter(visit, m, QPP396Elements.Benign_Tumors)
        || isDiagnosedOnEncounter(visit, m, QPP396Elements.Malignant_Tumors_Other_Than_Carcinomas)
        || isLaboratoryTestOrderDuringEncounter(visit, m, QPP396Elements.Appropriate_Doc__Lc_Resection__Medical_Reason)
    )
  }

}






