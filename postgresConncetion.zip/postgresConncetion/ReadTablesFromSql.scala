package com.figmd.connectivity

import javax.script.ScriptException
import org.apache.spark.sql.{DataFrame, SparkSession}

class ReadTablesFromSql {

  def readTables(sparkSess : SparkSession, tablename : String) : DataFrame ={
try{
    val masterTable =  sparkSess.read.format("jdbc")
      .option("url", "jdbc:sqlserver://10.20.201.236:1433;database=FIGMDHQIManagementACEP")
      .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
      .option("dbtable", tablename)
      .option("user", "mapping")
      .option("password", "mp3245")
      .load()

    println("success table read ....")
    masterTable
}catch {
  case e: ScriptException => e.printStackTrace
    null
}
  }

  def writeTables(sparkSess : SparkSession, tablename : String, df : DataFrame): Unit = {
    try {
    df.write.format("jdbc")
      .option("url", "jdbc:postgresql://10.20.201.36:5432/figmdhqimanagementacep")
      .option("driver", "org.postgresql.Driver")
      .option("dbtable", tablename)
      .option("user", "postgres")
      .option("password", "Janus@123")
      .save()

    println("Success table write........")
  }catch {
      case e: ScriptException => e.printStackTrace
    }
  }
}
