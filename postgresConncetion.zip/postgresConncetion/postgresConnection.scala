package com.figmd.connectivity

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

object postgresConnection {

  def main(args: Array[String]): Unit = {


    Logger.getLogger("org").setLevel(Level.WARN)
    Logger.getLogger("akka").setLevel(Level.WARN)

    val sparkSess = SparkSession.builder().master("local[*]").appName("Connectivity").getOrCreate()


    val tblListDF = sparkSess.read.format("csv")
      .option("delimiter", ",").option("inferSchema", "true")
      .load("file:///home/dev/gajanan/AcepMangTables.txt")
      .collect().map(_ (0).toString).toList



    for (tabname <- tblListDF) {

      val tables = (new ReadTablesFromSql).readTables(sparkSess,tabname)
      val postgrestable = (new ReadTablesFromSql).writeTables(sparkSess,tabname,tables)

      }



  }

}
