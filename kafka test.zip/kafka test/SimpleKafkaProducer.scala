import java.util.Properties

import com.fasterxml.jackson.databind.{JsonNode, ObjectMapper}
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession

class SimpleKafkaProducer(sc : SparkContext,sparkSess : SparkSession) extends Serializable {

  val sparksql = sparkSess.sqlContext

  val df = sparkSess
    .read
    .format("com.databricks.spark.xml")
    .option("rowTag", "languageCommunication")
    .option("valueTag", "anyName")
    .load("/user/ec2-user/temp_test/test.xml")

  var flattened = df
    .withColumn("languageCode", df("languageCode._code"))
    .withColumn("preferenceInd", df("preferenceInd._value"))

  var jsons = flattened.toJSON.collectAsList().toString

  //Configuration Settings of Producer
  val props: Properties = new Properties()
  props.put("bootstrap.servers", "localhost:9093")
  props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
  props.put("value.serializer","org.apache.kafka.connect.json.JsonSerializer")

  //Create kafkaProducer Object
  val producer  = new KafkaProducer[String, JsonNode](props)
  val objectMapper: ObjectMapper = new ObjectMapper()

  val jsonNode: JsonNode = objectMapper.readTree(jsons)

  //data pass to kafka topic
  val rec: ProducerRecord[String, JsonNode] = new ProducerRecord[String, JsonNode]("my-gaju-topic", jsonNode)

  producer.send(rec)
}