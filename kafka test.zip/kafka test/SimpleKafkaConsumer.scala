/*
Module  : XML Parser
spark-submit --class SimpleKafkaConsumer --packages com.databricks:spark-xml_2.10:0.4.1 /home/ec2-user/Akshay/KafkaSparkIntegration-assembly-0.3.jar
 */

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.streaming.kafka._



object SimpleKafkaConsumer extends Serializable {

  def main( args:Array[String] ){

    Logger.getLogger("org").setLevel(Level.WARN)
    Logger.getLogger("akka").setLevel(Level.WARN)

    //SparkSession
    val sparkSess = SparkSession.builder().master("local[*]").appName("My App").getOrCreate()
    val sc = sparkSess.sparkContext
    val sparksql = sparkSess.sqlContext
    val ssc = new StreamingContext(sc, Seconds(10))

    println("Hello 2........................")
    //call Producer class
    val producerclass = new SimpleKafkaProducer(sc,sparkSess)

    //createKafkaStream (streamingContext,
    //     [ZK quorum], [consumer group id], [per-topic number of Kafka partitions to consume])
    val kafkaStream = KafkaUtils.createStream(ssc, "localhost:2181","my-kafka-group", Map("my-gaju-topic" -> 1))

    //Read KafkaStream
    kafkaStream.foreachRDD { rdd =>
      val data = rdd.map(record => record._2)
      val json = sparksql.read.json(data)
      json.show()
      println("Write to kafka topic")
    }

    ssc.start()
    ssc.awaitTermination()
  }

}