package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS22
* Measure Title               :- Giant Cell Arteritis: Absence of fellow eye involvement after treatment
* Measure Description         :- Percentage of patients without fellow eye involvement 1-26 weeks after initiating treatment in patients with unilateral visual loss.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS22 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS22"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,IRIS22Elements.Ophthalmological_Services
      ,IRIS22Elements.Office_Visit
      ,IRIS22Elements.Office_Consultation
      ,IRIS22Elements.Giant_Cell_Arteritis
      ,IRIS22Elements.Unilateral_Vision_Loss
      ,IRIS22Elements.Giant_Cell_Arteritis__Eye
      ,IRIS22Elements.Unilateral_Vision_Loss__Eye
      ,IRIS22Elements.Corticosteroid
      ,IRIS22Elements.Corticosteroid__Eye
      ,IRIS22Elements.Other_Treatments
      ,IRIS22Elements.Other_Treatments__Eye
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList,patientHistoryRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients aged 18 years or greater with giant cell arteritis with unilateral vision loss
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val countElementList1: List[(String,Int)] = countElement(patientHistoryRDD,m
                                                        ,IRIS22Elements.Ophthalmological_Services
                                                        ,IRIS22Elements.Office_Visit
                                                        ,IRIS22Elements.Office_Consultation)

    initialRDD.filter(visit =>
           isPatientAdult(visit,m)
        && getEncounterCountFromHistory(visit,m,2,true, countElementList1)
        && isDiagnosisStartsAfterStartWithinXMonths(visit,m,IRIS22Elements.Giant_Cell_Arteritis,6,patientHistoryBroadcastList)
        && isDiagnosisStartsAfterStartWithinXMonths(visit,m,IRIS22Elements.Unilateral_Vision_Loss,6,patientHistoryBroadcastList)
        && checkSpecificEyeElementWIthOtherEyeElementInHistory(visit,m,IRIS22Elements.Giant_Cell_Arteritis__Eye,patientHistoryBroadcastList,IRIS22Elements.Unilateral_Vision_Loss__Eye)
        && (  ((   wasMedicationAdministeredAfterDiagnosed(visit,m,IRIS22Elements.Corticosteroid,patientHistoryBroadcastList,IRIS22Elements.Giant_Cell_Arteritis)
                && checkSpecificEyeElementAfterDiagnosisEyeElementInHistory(visit,m,IRIS22Elements.Corticosteroid__Eye,patientHistoryBroadcastList,IRIS22Elements.Giant_Cell_Arteritis__Eye)
               )
               ||
               (   wasMedicationAdministeredAfterDiagnosed(visit,m,IRIS22Elements.Corticosteroid,patientHistoryBroadcastList,IRIS22Elements.Unilateral_Vision_Loss)
                && checkSpecificEyeElementAfterDiagnosisEyeElementInHistory(visit,m,IRIS22Elements.Corticosteroid__Eye,patientHistoryBroadcastList,IRIS22Elements.Unilateral_Vision_Loss__Eye)
               )
              )
          ||
             ((   wasMedicationAdministeredAfterDiagnosed(visit,m,IRIS22Elements.Other_Treatments,patientHistoryBroadcastList,IRIS22Elements.Giant_Cell_Arteritis)
               && checkSpecificEyeElementAfterDiagnosisEyeElementInHistory(visit,m,IRIS22Elements.Other_Treatments__Eye,patientHistoryBroadcastList,IRIS22Elements.Giant_Cell_Arteritis__Eye)
              )
              ||
              (   wasMedicationAdministeredAfterDiagnosed(visit,m,IRIS22Elements.Other_Treatments,patientHistoryBroadcastList,IRIS22Elements.Unilateral_Vision_Loss)
               && checkSpecificEyeElementAfterDiagnosisEyeElementInHistory(visit,m,IRIS22Elements.Other_Treatments__Eye,patientHistoryBroadcastList,IRIS22Elements.Unilateral_Vision_Loss__Eye)
              )
             )
        )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients without fellow eye involvement 1-26 weeks after initiating treatment in patients with unilateral visual loss
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
     ! ((   wasDiagnosisAfterMedicationInXRange(visit,m,IRIS22Elements.Corticosteroid,IRIS22Elements.Giant_Cell_Arteritis,2,6,CalenderUnit.WEEK,CalenderUnit.WEEK,patientHistoryBroadcastList)
         && ! checkSpecificEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS22Elements.Corticosteroid__Eye,patientHistoryBroadcastList,Seq(IRIS22Elements.Giant_Cell_Arteritis__Eye))
        )
     || (   wasDiagnosisAfterMedicationInXRange(visit,m,IRIS22Elements.Other_Treatments,IRIS22Elements.Giant_Cell_Arteritis,2,6,CalenderUnit.WEEK,CalenderUnit.WEEK,patientHistoryBroadcastList)
         && ! checkSpecificEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS22Elements.Other_Treatments__Eye,patientHistoryBroadcastList,Seq(IRIS22Elements.Giant_Cell_Arteritis__Eye))
        )
      )
    )
  }
}
