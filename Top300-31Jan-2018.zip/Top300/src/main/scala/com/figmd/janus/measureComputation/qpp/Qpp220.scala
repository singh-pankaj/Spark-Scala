package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp220
* Measure Title              :- Functional Status Change for Patients with Low Back Impairments
* Measure Description        :- A patient-reported outcome measure of risk-adjusted change in functional status for patients 14 years+ with low back
                                impairments. The change in functional status (FS) is assessed using the Low Back FS patient-reported outcome
                                measure (PROM) (©Focus on Therapeutic Outcomes, Inc.). The measure is adjusted to patient characteristics
                                known to be associated with FS outcomes (risk adjusted) and used as a performance measure at the patient level, at
                                the individual clinician, and at the clinic level by to assess quality. The measure is available as a computer adaptive
                                test, for reduced patient burden, or a short form (static survey)
* Calculation Implementation :- Episode-specific
* Improvement Notation       :- Higher Score indicates better qualityHigher Score
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp220 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp220"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var getPatientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP220Elements.Office_Visit,
      QPP220Elements.Pain_Treatment_And_Evaluation,
      QPP220Elements.Fsa_Lumbar_Reason_Not_Specified,
      QPP220Elements.Fsa_Lumbar_Patient_Not_Eligible,
      QPP220Elements.Chiropractic_Evaluation,
      QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,
      QPP220Elements.Physical_Therapy,
      QPP220Elements.Occupational_Therapy,
      QPP220Elements.Discharge_After_Physical_Therapy,
      QPP220Elements.Discharge_After_Occupational_Therapy,
      QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,
      QPP220Elements.Patients_Functional_Status_Score_At_Admission,
      QPP220Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,
      QPP220Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission,
      QPP220Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,
      QPP220Elements.Patients_Functional_Status_Change_Score,
      QPP220Elements.Predicted_Functional_Status_Change_Score,
      QPP220Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission,
      QPP220Elements.Fsa_Lumbar,
      QPP220Elements.Fsa_Foot_Or_Ankle,
      QPP220Elements.Foto_s_Status_Survey


    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList.collect().toList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exceptions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val intermediateRDD = ippRDD.subtract(metRDD)
      intermediateRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getException(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryBroadcastList.destroy()

    }
  }
  /*
  All patients aged 65 years and older who have a history of falls (history of falls is defined as 2 or more falls in
  the past year or any fall with injury in the past year). Documentation of patient reported history of falls is sufficient
   */

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
                                isAgeAbove(visit,m,true,14)
                            &&  isVisitTypeIn(visit,m,QPP220Elements.Physical_Therapy,
                                                      QPP220Elements.Occupational_Therapy,
                                                      QPP220Elements.Office_Visit,
                                                      QPP220Elements.Chiropractic_Evaluation
                                              )
                            &&  (

                                      (
                                            wasEncounterPerformedBeforeOrEqualOfEncounter(visit,m,QPP220Elements.Physical_Therapy,patientHistoryList)
                                        &&  isEncounterPerformedOnEncounter(visit,m,QPP220Elements.Discharge_After_Physical_Therapy)
                                      )
                                      ||  (
                                            wasEncounterPerformedBeforeOrEqualOfEncounter(visit,m,QPP220Elements.Occupational_Therapy,patientHistoryList)
                                        &&  isEncounterPerformedOnEncounter(visit,m,QPP220Elements.Discharge_After_Occupational_Therapy)
                                      )
                                      ||  isAssessmentPerformedDuringEncounter(visit,m,QPP220Elements.Pain_Treatment_And_Evaluation)

                                  )
                            &&  isDiagnosisOverlapsEncounter(visit,m,patientHistoryList,QPP220Elements.Functional_Deficit_Lumbar)


                        )
  }

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistory:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
        (
              isCommunicationDoneFromPatientToProviderDuringEncounter(visit,m,QPP220Elements.Patient_Refusal)
          ||  isCommunicationDoneFromPatientToProviderDuringEncounter(visit,m,QPP220Elements.Fsa_Lumbar_Patient_Refusal)
          ||  isPatientCharacteristicDuringEncounter(visit,m,QPP220Elements.Unable_To_Complete_The_Foto_Lumbar_Intake_Prom)
          ||  isCommunicationDoneFromPatientToProviderDuringEncounter(visit,m,QPP220Elements.An_Adequate_Proxy_Is_Not_Available)
          ||  isDiagnosisOnEncounter(visit,m,QPP220Elements.Severe_Mental_Incapacity_Or_Language_Incompatibility)
        )
    ||  (
              wasDiagnosisInHistory(visit,m,QPP220Elements.Blindness,patientHistory)
          ||  wasPatientCharacteristicInHistory(visit,m,QPP220Elements.Illiteracy,patientHistory)
          ||  wasDiagnosisInHistory(visit,m,QPP220Elements.Psychotic_Disorder_Or_Related_Condition,patientHistory)

        )
    )
  }


  def getMet(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>

                            (

                              (
                                (
                                        wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Discharge_After_Physical_Therapy,QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.GREATER,patientHistoryList)
                                    ||  wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Discharge_After_Physical_Therapy,QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.EQUAL,patientHistoryList)
                                    ||  wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Discharge_After_Physical_Therapy,QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.LESS,patientHistoryList)
                                  )
                                  ||

                                  (
                                          wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Score_At_Admission,QPP220Elements.Physical_Therapy,CompareOperator.EQUAL,patientHistoryList)
                                      &&  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Score_At_Discharge,QPP220Elements.Discharge_After_Physical_Therapy,CompareOperator.EQUAL,patientHistoryList)
                                      &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission,QPP220Elements.Discharge_After_Physical_Therapy,patientHistoryList)
                                      &&  (
                                            wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Change_Score,QPP220Elements.Physical_Therapy,CompareOperator.EQUAL,patientHistoryList)
                                        ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Change_Score,QPP220Elements.Discharge_After_Physical_Therapy,CompareOperator.EQUAL,patientHistoryList)

                                      )
                                      &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,QPP220Elements.Discharge_After_Physical_Therapy,patientHistoryList)
                                    )
                                  ||
                                  (
                                          wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Change_Score,QPP220Elements.Discharge_After_Physical_Therapy,CompareOperator.EQUAL,patientHistoryList)
                                      &&  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Predicted_Functional_Status_Change_Score,QPP220Elements.Discharge_After_Physical_Therapy,CompareOperator.EQUAL,patientHistoryList)
                                      &&  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,QPP220Elements.Discharge_After_Physical_Therapy,CompareOperator.EQUAL,patientHistoryList)
                                    )
                                  ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Fsa_Lumbar,QPP220Elements.Discharge_After_Physical_Therapy,CompareOperator.EQUAL,patientHistoryList)
                                )
                                ||
                                (
                                  (
                                          wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Discharge_After_Occupational_Therapy,QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.GREATER,patientHistoryList)
                                      ||  wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Discharge_After_Occupational_Therapy,QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.EQUAL,patientHistoryList)
                                      ||  wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Discharge_After_Occupational_Therapy,QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.LESS,patientHistoryList)
                                    )
                                    ||
                                    (
                                            wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Score_At_Admission,QPP220Elements.Occupational_Therapy ,CompareOperator.EQUAL,patientHistoryList)
                                        &&  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Score_At_Discharge,QPP220Elements.Discharge_After_Occupational_Therapy,CompareOperator.EQUAL,patientHistoryList)
                                        &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission,QPP220Elements.Discharge_After_Occupational_Therapy,patientHistoryList)
                                        &&  (
                                              wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Change_Score,QPP220Elements.Occupational_Therapy,CompareOperator.EQUAL,patientHistoryList)
                                          ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Change_Score,QPP220Elements.Discharge_After_Occupational_Therapy,CompareOperator.EQUAL,patientHistoryList)

                                        )
                                        &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,QPP220Elements.Discharge_After_Occupational_Therapy,patientHistoryList)
                                      )
                                    ||
                                    (
                                            wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Change_Score,QPP220Elements.Discharge_After_Occupational_Therapy,CompareOperator.EQUAL,patientHistoryList)
                                        &&  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Predicted_Functional_Status_Change_Score,QPP220Elements.Discharge_After_Occupational_Therapy,CompareOperator.EQUAL,patientHistoryList)
                                        &&  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,QPP220Elements.Discharge_After_Occupational_Therapy,CompareOperator.EQUAL,patientHistoryList)
                                      )
                                    ||  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Fsa_Lumbar,QPP220Elements.Discharge_After_Occupational_Therapy,patientHistoryList)
                                  )
                                ||
                                (
                                  (
                                          wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Pain_Treatment_And_Evaluation,QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.GREATER,patientHistoryList)
                                      ||  wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Pain_Treatment_And_Evaluation,QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.EQUAL,patientHistoryList)
                                      ||  wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Pain_Treatment_And_Evaluation,QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.LESS,patientHistoryList)
                                    )
                                    ||
                                    (
                                            wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Score_At_Admission,QPP220Elements.Office_Visit ,CompareOperator.EQUAL,patientHistoryList)
                                        &&  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Score_At_Discharge,QPP220Elements.Pain_Treatment_And_Evaluation,CompareOperator.EQUAL,patientHistoryList)
                                        &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission,QPP220Elements.Pain_Treatment_And_Evaluation,patientHistoryList)
                                        &&  (
                                              wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Change_Score,QPP220Elements.Office_Visit,CompareOperator.EQUAL,patientHistoryList)
                                          ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Change_Score,QPP220Elements.Pain_Treatment_And_Evaluation,CompareOperator.EQUAL,patientHistoryList)

                                        )
                                        &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,QPP220Elements.Pain_Treatment_And_Evaluation,patientHistoryList)
                                      )
                                    ||
                                    (
                                            wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Change_Score,QPP220Elements.Pain_Treatment_And_Evaluation,CompareOperator.EQUAL,patientHistoryList)
                                        &&  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Predicted_Functional_Status_Change_Score,QPP220Elements.Pain_Treatment_And_Evaluation,CompareOperator.EQUAL,patientHistoryList)
                                        &&  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,QPP220Elements.Pain_Treatment_And_Evaluation,CompareOperator.EQUAL,patientHistoryList)
                                      )
                                    ||  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Fsa_Foot_Or_Ankle,QPP220Elements.Pain_Treatment_And_Evaluation,patientHistoryList)
                                  )
                                ||
                                (
                                  (
                                          wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Pain_Treatment_And_Evaluation,QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.GREATER,patientHistoryList)
                                      ||  wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Pain_Treatment_And_Evaluation,QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.EQUAL,patientHistoryList)
                                      ||  wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Pain_Treatment_And_Evaluation,QPP220Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.LESS,patientHistoryList)
                                    )
                                    ||
                                    (
                                            wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Score_At_Admission,QPP220Elements.Chiropractic_Evaluation ,CompareOperator.EQUAL,patientHistoryList)
                                        &&  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Score_At_Discharge,QPP220Elements.Pain_Treatment_And_Evaluation,CompareOperator.EQUAL,patientHistoryList)
                                        &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission,QPP220Elements.Pain_Treatment_And_Evaluation,patientHistoryList)
                                        &&  (
                                              wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Change_Score,QPP220Elements.Chiropractic_Evaluation,CompareOperator.EQUAL,patientHistoryList)
                                          ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Change_Score,QPP220Elements.Pain_Treatment_And_Evaluation,CompareOperator.EQUAL,patientHistoryList)

                                        )
                                        &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,QPP220Elements.Pain_Treatment_And_Evaluation,patientHistoryList)
                                      )
                                    ||
                                    (
                                            wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Functional_Status_Change_Score,QPP220Elements.Pain_Treatment_And_Evaluation,CompareOperator.EQUAL,patientHistoryList)
                                        &&  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Predicted_Functional_Status_Change_Score,QPP220Elements.Pain_Treatment_And_Evaluation,CompareOperator.EQUAL,patientHistoryList)
                                        &&  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,QPP220Elements.Pain_Treatment_And_Evaluation,CompareOperator.EQUAL,patientHistoryList)
                                      )
                                    ||  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP220Elements.Fsa_Foot_Or_Ankle,QPP220Elements.Pain_Treatment_And_Evaluation,patientHistoryList)
                                  )
                              )
                              && ! isAssesmentPerformedDuringEncounter(visit,m,QPP220Elements.Fsa_Lumbar_Reason_Not_Specified)
                          )


  }

  def getException(intermediateRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateRdd.filter(visit =>
      (
              wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Fsa_Lumbar_Patient_Not_Eligible,QPP220Elements.Physical_Therapy,CompareOperator.EQUAL,patientHistoryList)
          ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Fsa_Lumbar_Patient_Not_Eligible,QPP220Elements.Occupational_Therapy,CompareOperator.EQUAL,patientHistoryList)
          ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Fsa_Lumbar_Patient_Not_Eligible,QPP220Elements.Office_Visit,CompareOperator.EQUAL,patientHistoryList)
          ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Fsa_Lumbar_Patient_Not_Eligible,QPP220Elements.Chiropractic_Evaluation,CompareOperator.EQUAL,patientHistoryList)
          ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Foto_s_Status_Survey,QPP220Elements.Physical_Therapy,CompareOperator.EQUAL,patientHistoryList)
          ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Foto_s_Status_Survey,QPP220Elements.Occupational_Therapy,CompareOperator.EQUAL,patientHistoryList)
          ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Foto_s_Status_Survey,QPP220Elements.Office_Visit,CompareOperator.EQUAL,patientHistoryList)
          ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Foto_s_Status_Survey,QPP220Elements.Chiropractic_Evaluation,CompareOperator.EQUAL,patientHistoryList)
        )
        ||

        (
                wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Fsa_Lumbar_Patient_Not_Eligible,QPP220Elements.Discharge_After_Physical_Therapy,CompareOperator.EQUAL,patientHistoryList)
            ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Fsa_Lumbar_Patient_Not_Eligible,QPP220Elements.Discharge_After_Occupational_Therapy,CompareOperator.EQUAL,patientHistoryList)
            ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Fsa_Lumbar_Patient_Not_Eligible,QPP220Elements.Pain_Treatment_And_Evaluation,CompareOperator.EQUAL,patientHistoryList)

            ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Foto_s_Status_Survey,QPP220Elements.Discharge_After_Physical_Therapy,CompareOperator.EQUAL,patientHistoryList)
            ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Foto_s_Status_Survey,QPP220Elements.Discharge_After_Occupational_Therapy,CompareOperator.EQUAL,patientHistoryList)
            ||  wasAssessmentDuringProcedureInHistory(visit,m,QPP220Elements.Foto_s_Status_Survey,QPP220Elements.Pain_Treatment_And_Evaluation,CompareOperator.EQUAL,patientHistoryList)
          )
    )

  }

}



