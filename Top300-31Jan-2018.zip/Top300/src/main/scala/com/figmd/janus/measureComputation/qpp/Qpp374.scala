package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP374Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 374
* Measure Title              :- Closing the Referral Loop: Receipt of Specialist Report
* Measure Description        :- Percentage of patients with referrals, regardless of age, for which the referring provider receives a report from the provider to whom the patient was referred.
* Calculation Implementation :- Patient specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp374 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP374"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP374Elements.Referral_Report_Received_From_The_Another_Provider_, QPP374Elements.Consultant_Report, QPP374Elements.Referral_Report_Received_Grp,
      QPP374Elements.Referral_Report_Received_From_Another_Provider_Not_Met_Grp
    )


    val leastRecentBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastRecentPatientList(patientHistoryRDD, QPP374Elements.Referral_Report_Received_From_The_Another_Provider_, QPP374Elements.Consultant_Report, QPP374Elements.Referral_Report_Received_Grp))


    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList, leastRecentBroadcastList)
      metRDD.cache()

      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      denominatorRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }

  }
  // IPP-Denominator criteria
  /* Number of patients, regardless of age, who were referred by one provider to another provider, and who had a visit during the measurement period */

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>

      isInterventionPerformedFirstDuringMeasurementPeriod(visit, m, patientHistoryBroadcastList, QPP374Elements.Patient_Referred_To_Another_Provider_Or_Specialist_, QPP374Elements.Referral, QPP374Elements.Patient_Referred_To_Another_Provider)
        && isVisitTypeIn(visit, m, QPP374Elements.Office_Visit,
        QPP374Elements.Ophthalmological_Services,
        QPP374Elements.Preventive_Care__Established_Office_Visit__0_To_17,
        QPP374Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
        QPP374Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up_Date,
        QPP374Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,
        QPP374Elements.Face_To_Face_Interaction)
        && !isVisitTypeIn(visit, m, QPP374Elements.Office_Visit_Telehealth_Modifier_Grp,
        QPP374Elements.Ophthalmological_Services_Telehealth_Modifier,
        QPP374Elements.Preventive_Care___Established_Office_Visit_0_To_17_Telehealth_Modifier_Grp,
        QPP374Elements.Preventive_Care_Services___Established_Office_Visit_18_And_Up_Telehealth_Modifier,
        QPP374Elements.Preventive_Care_Services_Initial_Office_Visit_18_And_Up_Telehealth_Modifier,
        QPP374Elements.Preventive_Care__Initial_Office_Visit_0_To_17_Telehealth_Modifier_Grp)
        && !isVisitTypeIn(visit, m, QPP374Elements.Pos_02)

    )
  }


  // Numerator criteria
  /* Current smokers and who abstained from smoking prior to anesthesia on the day of surgery or procedure. */

  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], leastRecentBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ipp.filter(visit =>

      isCommunicationDoneFromProvidertoProviderAfterInterventionFirst(visit, m, Seq(QPP374Elements.Referral_Report_Received_From_The_Another_Provider_, QPP374Elements.Consultant_Report, QPP374Elements.Referral_Report_Received_Grp), patientHistoryBroadcastList, leastRecentBroadcastList, QPP374Elements.Patient_Referred_To_Another_Provider_Or_Specialist_, QPP374Elements.Referral, QPP374Elements.Patient_Referred_To_Another_Provider)
        && !isAssessmentPerformed(visit, m, QPP374Elements.Referral_Report_Received_From_Another_Provider_Not_Met_Grp, patientHistoryBroadcastList)
    )
  }


}
