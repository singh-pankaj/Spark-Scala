
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AQUA30
* Measure Title               :- Prostate Cancer: Patient report of Sexual function after treatment
* Measure Description         :- Percentage of patients who had a reported sexual function score at 24 months after treatment
                                 that is within 60% of the reported sexual function score at baseline (before treatment)
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- Aanchal.Rai
* Initial GIT Version/Tag(CRA):- 1.8
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object AQUA30 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "AQUA30"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , AQUA30Elements.Prostate_Cancer_New
      , AQUA30Elements.Baseline_Sexual_Function__Epic_26_
      , AQUA30Elements.Documentation_Of_Ebrt_In_Md_Notes
      , AQUA30Elements.Gold__Fiducial_Markers_In_Md_Notes
      , AQUA30Elements.Adt_Md_Notes
      , AQUA30Elements.Documentation_Of_Cryotherapy_In_Md_Notes
      , AQUA30Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes
      , AQUA30Elements.Documentation_Of_Brachytherapy_In_Md_Notes
      , AQUA30Elements.Interstitial_Prostate_Brachytherapy
      , AQUA30Elements.Radical_Prostatectomy
      , AQUA30Elements.Cryotherapy
      , AQUA30Elements.Adt
      , AQUA30Elements.External_Beam_Radiotherapy
      , AQUA30Elements.Gold__Fiducial_Marker
      ,AQUA30Elements.Baseline_Sexual_Function__Epic_26_
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  IPP - All newly diagnosed prostate cancer patients
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
       isMale(visit,m)
      &&
      wasElementBeforeStartDateInXPeriodEndDateInXPeriod(visit,m,AQUA30Elements.Prostate_Cancer_New,CalenderUnit.MONTH,24,CalenderUnit.MONTH,12,patientHistoryBroadcastList)
      &&
     ( wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,AQUA30Elements.Baseline_Sexual_Function__Epic_26_,AQUA30Elements.Prostate_Cancer_New,patientHistoryBroadcastList)

      &&
       (
       wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA30Elements.Baseline_Sexual_Function__Epic_26_,AQUA30Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList)
       ||
       wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA30Elements.Baseline_Sexual_Function__Epic_26_,AQUA30Elements.Radical_Prostatectomy,patientHistoryBroadcastList)
       ||
       wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA30Elements.Baseline_Sexual_Function__Epic_26_,AQUA30Elements.Cryotherapy,patientHistoryBroadcastList)
       ||
       wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA30Elements.Baseline_Sexual_Function__Epic_26_,AQUA30Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList)
       ||
       wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA30Elements.Baseline_Sexual_Function__Epic_26_,AQUA30Elements.Adt,patientHistoryBroadcastList)
       ||
       wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA30Elements.Baseline_Sexual_Function__Epic_26_,AQUA30Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList)
       ||
       wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA30Elements.Baseline_Sexual_Function__Epic_26_,AQUA30Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList)
       ||
       wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA30Elements.Baseline_Sexual_Function__Epic_26_,AQUA30Elements.Documentation_Of_Ebrt_In_Md_Notes,patientHistoryBroadcastList)
       ||
       wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA30Elements.Baseline_Sexual_Function__Epic_26_,AQUA30Elements.Adt_Md_Notes,patientHistoryBroadcastList)
       ||
       wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA30Elements.Baseline_Sexual_Function__Epic_26_,AQUA30Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList)
       ||
       wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA30Elements.Baseline_Sexual_Function__Epic_26_,AQUA30Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList)
       ||
       wasAssessmentPerformedBeforeOrConcurrentAnotherElement(visit,m,AQUA30Elements.Baseline_Sexual_Function__Epic_26_,AQUA30Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList)

       )
    )
      &&
      (
      wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA30Elements.Interstitial_Prostate_Brachytherapy,AQUA30Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
      ||
      wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA30Elements.Radical_Prostatectomy,AQUA30Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
      ||
      wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA30Elements.Cryotherapy,AQUA30Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
      ||
      wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA30Elements.External_Beam_Radiotherapy,AQUA30Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
      ||
      wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA30Elements.Adt,AQUA30Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
      ||
      wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA30Elements.Gold__Fiducial_Marker,AQUA30Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
      ||
      wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA30Elements.Gold__Fiducial_Markers_In_Md_Notes,AQUA30Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
      ||
      wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA30Elements.Documentation_Of_Ebrt_In_Md_Notes,AQUA30Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
      ||
      wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA30Elements.Adt_Md_Notes,AQUA30Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
      ||
      wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA30Elements.Documentation_Of_Cryotherapy_In_Md_Notes,AQUA30Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
      ||
      wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA30Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,AQUA30Elements.Prostate_Cancer_New,patientHistoryBroadcastList)
      ||
      wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA30Elements.Documentation_Of_Brachytherapy_In_Md_Notes,AQUA30Elements.Prostate_Cancer_New,patientHistoryBroadcastList)


       )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Numerator - Men completing EPIC-26 sexual function domain who had a reported sexual function score within 60% of the
              reported sexual function score at baseline (before treatment)
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>

      (wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA30Elements.Sexual_Function_Report, AQUA30Elements.Documentation_Of_Ebrt_In_Md_Notes, "le", 60, "le", patientHistoryBroadcastList)
        ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA30Elements.Sexual_Function_Report, AQUA30Elements.Gold__Fiducial_Markers_In_Md_Notes, "le", 60, "le", patientHistoryBroadcastList)
        ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA30Elements.Sexual_Function_Report , AQUA30Elements.Adt_Md_Notes, "le", 60, "le", patientHistoryBroadcastList)
        ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA30Elements.Sexual_Function_Report , AQUA30Elements.Documentation_Of_Cryotherapy_In_Md_Notes, "le", 60, "le", patientHistoryBroadcastList)
        ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA30Elements.Sexual_Function_Report , AQUA30Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes, "le", 60, "le", patientHistoryBroadcastList)
        ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA30Elements.Sexual_Function_Report , AQUA30Elements.Documentation_Of_Brachytherapy_In_Md_Notes, "le", 60, "le", patientHistoryBroadcastList)
        ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA30Elements.Sexual_Function_Report , AQUA30Elements.Interstitial_Prostate_Brachytherapy, "le", 60, "le", patientHistoryBroadcastList)
       ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA30Elements.Sexual_Function_Report , AQUA30Elements.Radical_Prostatectomy, "le", 60, "le", patientHistoryBroadcastList)
        ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA30Elements.Sexual_Function_Report , AQUA30Elements.Cryotherapy, "le", 60, "le", patientHistoryBroadcastList)
        ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA30Elements.Sexual_Function_Report , AQUA30Elements.Adt, "le", 60, "le", patientHistoryBroadcastList)
        ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA30Elements.Sexual_Function_Report , AQUA30Elements.External_Beam_Radiotherapy, "le", 60, "le", patientHistoryBroadcastList)
        ||
        wasElementPresentAfterOtherElementsWithResultComparison(visit, m, AQUA30Elements.Sexual_Function_Report , AQUA30Elements.Gold__Fiducial_Marker, "le", 60, "le", patientHistoryBroadcastList)
        )
      &&
      wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit,m,AQUA30Elements.Sexual_Function_Report,patientHistoryBroadcastList,AQUA30Elements.Baseline_Sexual_Function__Epic_26_)

    )
  }

}
