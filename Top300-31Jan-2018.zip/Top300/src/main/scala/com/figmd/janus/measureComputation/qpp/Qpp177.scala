package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 177
* Measure Title              :- Rheumatoid Arthritis (RA): Periodic Assessment of Disease Activity
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of rheumatoid arthritis
                                (RA) who have an assessment of disease activity at ≥50% of encounters for RA for each
                                 patient during the measurement year
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp177 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp177"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,QPP177Elements.Active_Rheumatoid_Arthritis).collect.toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }

  /*--------------------------------------------------------------------------------------------------------------------
    Patients aged 18 years and older with a diagnosis of RA
   -------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
                   isPatientAdult(visit,m)
                && isVisitTypeIn(visit,m
                                        ,QPP177Elements.Home_Healthcare_Services
                                        ,QPP177Elements.Office_Visit
                                        , QPP177Elements.Office_Visit
                                 )
                && wasDiagnosedInHistory(visit,m,QPP177Elements.Active_Rheumatoid_Arthritis,patientHistoryBroadcastList)
                && !isTeleHealthModifier(visit,m
                                        ,QPP177Elements.Home_Healthcare_Services
                                        ,QPP177Elements.Office_Visit
                                        , QPP177Elements.Office_Visit
                                        )
                && isPOSEncounterNotPerformed(visit,m,QPP177Elements.Pos_02)
              )

  }

  /*--------------------------------------------------------------------------------------------------------------------
  Patients with disease activity assessed by an ACR-endorsed rheumatoid arthritis disease activity measurement
  tool ≥50% of total number of outpatient RA encounters in the measurement year
   -------------------------------------------------------------------------------------------------------------------*/


  def getMet(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
        (
            isAssessmentPerformedDuringEncounter(visit,m,QPP177Elements.Ra_Encounters_Assessed)
         || isAssessmentPerformedDuringEncounter(visit,m,QPP177Elements.Assessment_Of_Disease_Activity)
        )
      &&
        !(
            isAssessmentPerformedDuringEncounter(visit,m,QPP177Elements.Ra_Encounters_Not_Met)
         || isAssessmentPerformedDuringEncounter(visit,m,QPP177Elements.Disease_Activity_Rsn_Not_Specified)
         )
    )
  }


}






