package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, IRIS47Elements, MeasureProperty}
import com.figmd.janus.util.measure.{MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS47
* Measure Title               :- Return to OR or endophthalmitis within 90 days after macular hole surgery
* Measure Description         :- Percentage of patients with a macular hole who returned to the OR
*                               (including repair of retinal detachment) or endophthalmitis within 90 days after
*                               surgical treatment for macular hole.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Lower Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.6
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS47 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS47"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
        , IRIS47Elements.Associated_Retinal_Detachment
        , IRIS47Elements.Macular_Hole
        , IRIS47Elements.Surgical_Procedure_To_Treat_Or_Close_Macular_Hole
        , IRIS47Elements.Macular_Hole_Eye
        , IRIS47Elements.Surgical_Procedure_To_Treat_Or_Close_Macular_Hole___Eye
        , IRIS47Elements.Associated_Retinal_Detachment__Eye
        , IRIS47Elements.Return_To_The_Or
        , IRIS47Elements.Return_To_The_Or___Eye
        , IRIS47Elements.Endophthalmitis
        , IRIS47Elements.Endophthalmitis__Eye
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
  All patients aged 18 years or older with a diagnosis of macular hole who received surgical treatment for macular hole.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
          isPatientAdult(visit, m)
        &&
          isProcedurePerformedDuringEncounter(visit, m, IRIS47Elements.Surgical_Procedure_To_Treat_Or_Close_Macular_Hole)
        &&
          isDiagnosisOverlapsProcedure(visit, m, IRIS47Elements.Macular_Hole,
                      IRIS47Elements.Surgical_Procedure_To_Treat_Or_Close_Macular_Hole, patientHistoryBroadcastList)
        &&
          isDiagnosisPerformedWasConcurrentWith(visit, m, IRIS47Elements.Macular_Hole_Eye,
                      IRIS47Elements.Macular_Hole, patientHistoryBroadcastList)
        &&
          isProcedurePerformedXDaysBeforeEnd(visit, m, IRIS47Elements.Surgical_Procedure_To_Treat_Or_Close_Macular_Hole, 90)
        &&
          isProcedurePerformedWasConcurrentWith(visit, m, IRIS47Elements.Surgical_Procedure_To_Treat_Or_Close_Macular_Hole,
                          IRIS47Elements.Surgical_Procedure_To_Treat_Or_Close_Macular_Hole___Eye, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Associated retinal detachment prior to the date of the surgical treatment of the macular hole
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
          isDiagnosedBeforeProcedure(visit, m, IRIS47Elements.Surgical_Procedure_To_Treat_Or_Close_Macular_Hole,
                                      patientHistoryBroadcastList, IRIS47Elements.Associated_Retinal_Detachment)
        &&
          wasDiagnosisOverlapsProcedureInHistory(visit, m, IRIS47Elements.Associated_Retinal_Detachment,
                          IRIS47Elements.Surgical_Procedure_To_Treat_Or_Close_Macular_Hole, patientHistoryBroadcastList)
        &&
          isDiagnosisPerformedWasConcurrentWith(visit, m, IRIS47Elements.Associated_Retinal_Detachment,
                          IRIS47Elements.Associated_Retinal_Detachment__Eye, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients with a macular hole who returned to the OR (including repair of retinal detachment) or
  endophthalmitis within 90 days of surgical treatment for macular hole
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
        (
            wasIntervaentionPerformedDaysAfterProcedure(visit, m, IRIS47Elements.Return_To_The_Or,
                    IRIS47Elements.Surgical_Procedure_To_Treat_Or_Close_Macular_Hole, 90, patientHistoryBroadcastList)
          &&
            isInterventionPerformedWasConcurrentWith(visit, m, IRIS47Elements.Return_To_The_Or,
                    IRIS47Elements.Return_To_The_Or___Eye, patientHistoryBroadcastList)
        )
      ||
        (
             wasProcedurePerformedAfterProcedureWithInXDays(visit, m, IRIS47Elements.Retinal_Detachment_Surgery,
                    IRIS47Elements.Surgical_Procedure_To_Treat_Or_Close_Macular_Hole, 90, patientHistoryBroadcastList)
          &&
             isProcedurePerformedWasConcurrentWith(visit, m, IRIS47Elements.Retinal_Detachment_Surgery,
                    IRIS47Elements.Retinal_Detachment_Surgery__Eye, patientHistoryBroadcastList)
        )
      ||
        (
            wasIntervaentionPerformedDaysAfterProcedure(visit, m, IRIS47Elements.Return_To_The_Or,
                    IRIS47Elements.Surgical_Procedure_To_Treat_Or_Close_Macular_Hole, 90, patientHistoryBroadcastList)
          &&
            isInterventionPerformedWasConcurrentWith(visit, m, IRIS47Elements.Return_To_The_Or,
                    IRIS47Elements.Return_To_The_Or___Eye, patientHistoryBroadcastList)
          &&
            isDiagnosedInXDaysAfterProcedure(visit, m, IRIS47Elements.Surgical_Procedure_To_Treat_Or_Close_Macular_Hole,
                    IRIS47Elements.Endophthalmitis, 90, patientHistoryBroadcastList)
          &&
            isDiagnosedConcurrentWith(visit, m, IRIS47Elements.Endophthalmitis, IRIS47Elements.Endophthalmitis__Eye)
        )
    )
  }
}