import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- QIM 2
* Measure Title               :- Chronic Anterior Uveitis: Post-treatment Grade 0 anterior chamber cells
* Measure Description         :- Percentage of patients with chronic anterior uveitis post-treatment with Grade 0 anterior chamber cells
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- Rishikesh Patil
* Initial GIT Version/Tag(CRA):- 1.8
* Latest GIT Version/Tag(CRA) :- 1.9
----------------------------------------------------------------------------------------------------------------------------*/

object QIM2 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "QIM2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QIM2Elements.Chronic_Uveitis
      , QIM2Elements.Chronic_Uveitis_Eye
      , QIM2Elements.Topical_Corticosteroids_Of_1_Percent_3x_Day_Or_Less
      , QIM2Elements.Uveitis_Medications__Eye
      , QIM2Elements.Grade_0_Anterior_Chamber_Cells
      , QIM2Elements.Grade_0_Anterior_Chamber_Cells__Eye
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    All patients aged 18 years or greater who underwent treatment for chronic anterior uveitis.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>

      isPatientAdult(visit, m)
      &&
      wasDiagnosedInHistory(visit, m, QIM2Elements.Chronic_Uveitis, patientHistoryBroadcastList)
      &&
      checkEyeElementBeforeDiagnosisEyesElementInHistory(visit, m, QIM2Elements.Chronic_Uveitis, patientHistoryBroadcastList, QIM2Elements.Chronic_Uveitis_Eye)
      &&
      wasMedicationActiveInHistory(visit, m, QIM2Elements.Topical_Corticosteroids_Of_1_Percent_3x_Day_Or_Less, patientHistoryBroadcastList)
      &&
      checkEyeElementBeforeDiagnosisEyesElementInHistory(visit, m, QIM2Elements.Topical_Corticosteroids_Of_1_Percent_3x_Day_Or_Less, patientHistoryBroadcastList, QIM2Elements.Uveitis_Medications__Eye)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    	Patients with Grade 0 anterior chamber cells at 30 days after treatment
      AND
      on topical corticosteroids of prednisolone acetate 1% 3X/day or less (or equivalent) at 60 days after treatment
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>

    wasDiagnosisStartsAfterElementWithinXDays(visit, m, QIM2Elements.Topical_Corticosteroids_Of_1_Percent_3x_Day_Or_Less,  QIM2Elements.Grade_0_Anterior_Chamber_Cells, 30 , patientHistoryBroadcastList)
    &&
    checkEyeElementBeforeDiagnosisEyesElementInHistory(visit, m, QIM2Elements.Grade_0_Anterior_Chamber_Cells, patientHistoryBroadcastList, QIM2Elements.Grade_0_Anterior_Chamber_Cells__Eye)
    &&
    !wasMedicationStartsAfterElementAfterXDays(visit, m, QIM2Elements.Topical_Corticosteroids_Of_1_Percent_3x_Day_Or_Less, QIM2Elements.Topical_Corticosteroids_Of_1_Percent_3x_Day_Or_Less, 60, patientHistoryBroadcastList)
    )
  }

}
