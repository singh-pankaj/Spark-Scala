package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP304Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 304
* Measure Title              :- Cataracts: Patient Satisfaction within 90 Days Following Cataract Surgery
* Measure Description        :- Percentage of patients aged 18 years and older who had cataract surgery and were satisfied
                                with their care within 90 days following the cataract surgery, based on completion of the
                                Consumer Assessment of Healthcare Providers and Systems Surgical Care Survey
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp304 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp304"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP304Elements.Cataract_Surgery_Eye
      , QPP304Elements.Cataract_Surgery
      , QPP304Elements.Cataract_Modifier
      , QPP304Elements.Satisfaction_With_Care_Not_Met
      , QPP304Elements.Satisfaction_With_Care
      , QPP304Elements.Satisfaction_Care_Achieved
      , QPP304Elements.Satisfaction__Patient_Reason
      , QPP304Elements.Satisfaction_With_Care_Patient_Reason).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate RDD
      val intermediateException = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
    All patients aged 18 years and older who had cataract surgery
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isProcedurePerformedWithinXMonths(visit, m, QPP304Elements.Cataract_Surgery, 9, patientHistoryBroadcastList)
        && isProcedurePerformedWithinXMonths(visit, m, QPP304Elements.Cataract_Surgery_Eye, 9, patientHistoryBroadcastList)
        && !isProcedurePerformed(visit, m, QPP304Elements.Cataract_Modifier, patientHistoryBroadcastList)
    )
  }

  /*---------------------------------------------------------------------------------------------------------
   Patients 18 years and older who were satisfied with their care within 90 days following cataract surgery,
   based on completion of the Consumer Assessment of Healthcare Providers and Systems Surgical Care Survey
   --------------------------------------------------------------------------------------------------------*/

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        isInterventionPerformed(visit, m, QPP304Elements.Satisfaction_With_Care, patientHistoryBroadcastList)
          || wasInterventionPerformedWithinXdaysAfterProcedure(visit, m, QPP304Elements.Satisfaction_Care_Achieved, QPP304Elements.Cataract_Surgery, 90, patientHistoryBroadcastList)
        )
        && !isInterventionPerformed(visit, m, QPP304Elements.Satisfaction_With_Care_Not_Met, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------
   Patient care survey was not completed by patient
   -----------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermediateException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      isInterventionPerformed(visit, m, QPP304Elements.Satisfaction_With_Care_Patient_Reason, patientHistoryBroadcastList)
        || isInterventionPerformed(visit, m, QPP304Elements.Satisfaction__Patient_Reason, patientHistoryBroadcastList)
    )

  }

}
