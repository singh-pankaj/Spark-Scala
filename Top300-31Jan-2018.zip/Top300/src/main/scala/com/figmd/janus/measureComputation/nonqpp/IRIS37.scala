package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{IRIS37Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS37
* Measure Title               :- Post-operative opioid management following oculoplastic surgery
* Measure Description         :- Percentage of patients aged 18 years and older who underwent oculoplastic surgical procedures who were assessed for opioid use/requirements
                                 post-operatively, defined by either not receiving opioids post-operatively, receiving opioids for pain for 7 days or less post-operatively,
                                 or if expected to require opioids for more than 7 days after the surgical procedure, having an opioid use management plan documented.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS37 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "IRIS37"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
            ,IRIS37Elements.Postoperative_Opioid_Use
            ,IRIS37Elements.Opioid_Use_Management_Plan
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients aged 18 years or older who underwent an oculoplastic surgical procedure
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
            isPatientAdult(visit,m)
        &&  isProcedurePerformedDuringEncounter(visit,m,IRIS37Elements.Oculoplasty_Surgery)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Percentage of patients aged 18 years and older who underwent oculoplastic surgical procedures who were assessed for opioid use/requirements post-operatively.
The performance measure criteria can be met in the following circumstances:

1)Patient did not receive a prescription for opioids post-operatively
2)Patient received a prescription for opioids post-operatively for 7 days or less duration
3)Patient received a prescription for opioids post-operatively for more than 7 days after the surgical procedure and had a documented opioid use management plan in the patient record.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      ! wasMedicationOrderedAfterProcedureWithInXDays(visit,m,IRIS37Elements.Postoperative_Opioid_Use,IRIS37Elements.Oculoplasty_Surgery,2,patientHistoryBroadcastList)
        && (  wasMedicationOrderedAfterProcedureWithInXDays(visit,m,IRIS37Elements.Postoperative_Opioid_Use,IRIS37Elements.Oculoplasty_Surgery,7,patientHistoryBroadcastList)
            ||
              (    wasMedicationOrderedAfterProcedureInXDays(visit,m,IRIS37Elements.Postoperative_Opioid_Use,IRIS37Elements.Oculoplasty_Surgery,7,patientHistoryBroadcastList)
               &&  wasAssessmentPerformedAfterMedication(visit,m,IRIS37Elements.Postoperative_Opioid_Use,IRIS37Elements.Opioid_Use_Management_Plan,patientHistoryBroadcastList)
              )
           )
    )
  }

}
