import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- QPP 180
* Measure Title               :- Rheumatoid Arthritis (RA): Glucocorticoid Management
* Measure Description         :- Percentage of patients aged 18 years and older with a diagnosis of rheumatoid arthritis
*                                (RA) who have been assessed for glucocorticoid use and, for those on prolonged doses of
*                                prednisone ≥ 10 mg daily (or equivalent) with improvement or no change in disease activity,
*                                documentation of glucocorticoid management plan within 12 months.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- Rishikesh Patil
* Initial GIT Version/Tag(CRA):- 1.8
* Latest GIT Version/Tag(CRA) :- 1.9
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp180 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP180"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP180Elements.Active_Rheumatoid_Arthritis
      , QPP180Elements.Initial_Preventive_Physical_Examination_Telehealth_Modifier
      , QPP180Elements.Home_Healthcare_Services_Telehealth_Modifier
      , QPP180Elements.Office_Visit_Telehealth_Modifier
      , QPP180Elements.Pos_02
      , QPP180Elements.Prednisone_Drug
      , QPP180Elements.Prednisone
      , QPP180Elements.Prednisolone
      , QPP180Elements.Cortisone
      , QPP180Elements.Hydrocortisone
      , QPP180Elements.Triamcinolone
      , QPP180Elements.Methylprednisolone
      , QPP180Elements.Dexamethasone
      , QPP180Elements.Betamethasone
      , QPP180Elements.Prednisone_1
      , QPP180Elements.Prednisolone_1
      , QPP180Elements.Cortisone_1
      , QPP180Elements.Hydrocortisone_1
      , QPP180Elements.Triamcinolone_1
      , QPP180Elements.Methylprednisolone_1
      , QPP180Elements.Dexamethasone_1
      , QPP180Elements.Betamethasone_1
      , QPP180Elements.Glucocorticoid_Therapy
      , QPP180Elements.Ra_Activity_Worsening
      , QPP180Elements.Prednisone_Drugs
      , QPP180Elements.Improvement__No_Change_In_Disease_Activity_For_Ra
      , QPP180Elements.Glucocorticoid_Management_Plan
      , QPP180Elements.Gluco_Mngmnt_Pln_Reason_Not_Specified
      , QPP180Elements.Gluco_Dose_Reason_Not_Specified
      , QPP180Elements.Gluco_Mngmnt_Pln_Medical_Reason
      , QPP180Elements.Glucocorticoid_Prescription
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val medicationList = List[(String, String)](
      (QPP180Elements.Prednisone_Date, QPP180Elements.Prednisone_Stopdate),
      (QPP180Elements.Prednisolone_Date, QPP180Elements.Prednisolone_Stopdate),
      (QPP180Elements.Cortisone_Date, QPP180Elements.Cortisone_Stopdate),
      (QPP180Elements.Hydrocortisone_Date, QPP180Elements.Hydrocortisone_Stopdate),
      (QPP180Elements.Triamcinolone_Date, QPP180Elements.Triamcinolone_Stopdate),
      (QPP180Elements.Methylprednisolone_Date, QPP180Elements.Methylprednisolone_Stopdate),
      (QPP180Elements.Dexamethasone_Date, QPP180Elements.Dexamethasone_Stopdate),
      (QPP180Elements.Betamethasone_Date, QPP180Elements.Betamethasone_Stopdate),
      (QPP180Elements.Prednisone_1_Date, QPP180Elements.Prednisone_Stopdate),
      (QPP180Elements.Prednisolone_1_Date, QPP180Elements.Prednisolone_Stopdate),
      (QPP180Elements.Cortisone_1_Date, QPP180Elements.Cortisone_Stopdate),
      (QPP180Elements.Hydrocortisone_1_Date, QPP180Elements.Hydrocortisone_Stopdate),
      (QPP180Elements.Triamcinolone_1_Date, QPP180Elements.Triamcinolone_Stopdate),
      (QPP180Elements.Methylprednisolone_1_Date, QPP180Elements.Methylprednisolone_Stopdate),
      (QPP180Elements.Dexamethasone_1_Date, QPP180Elements.Dexamethasone_Stopdate),
      (QPP180Elements.Betamethasone_1_Date, QPP180Elements.Betamethasone_Stopdate),
      (QPP180Elements.Glucocorticoid_Therapy_Date, QPP180Elements.Glucocorticoid_Therapy_Stopdate)
    )

    val medicationDurationBroadcastList = sparkSession.sparkContext.broadcast(consecutive(patientHistoryRDD, m,
        medicationList, CalenderUnit.MONTH, CalenderUnit.MONTH,0, CalenderUnit.DAY,1,"DURING"))

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList, medicationDurationBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Patients aged 18 years and older with a diagnosis of RA.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
      &&
      wasDiagnosedInHistory(visit, m, QPP180Elements.Active_Rheumatoid_Arthritis, patientHistoryBroadcastList)
      &&
      isVisitTypeIn(visit, m, QPP180Elements.Office_Visit, QPP180Elements.Home_Healthcare_Services, QPP180Elements.Initial_Preventive_Physical_Examination)
      &&
         !
          (
            isEncounterPerformed(visit, m, QPP180Elements.Initial_Preventive_Physical_Examination_Telehealth_Modifier, patientHistoryBroadcastList)
            ||
            isEncounterPerformed(visit, m, QPP180Elements.Home_Healthcare_Services_Telehealth_Modifier, patientHistoryBroadcastList)
            ||
            isEncounterPerformed(visit, m, QPP180Elements.Office_Visit_Telehealth_Modifier, patientHistoryBroadcastList)
            )
        && ! isEncounterPerformed(visit, m, QPP180Elements.Pos_02, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients who have been assessed for glucocorticoid use and for those on prolonged doses of prednisone ≥ 10 mg daily
  (or equivalent) with improvement or no change in disease activity, documentation of a glucocorticoid management plan within 12 months.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], medicationDurationBroadcastList : Broadcast[List[(String,String, Double)]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
     (
      isMedicationOrderedDuringEncounter(visit, m, QPP180Elements.Glucocorticoid_Therapy_Met)
      ||
      isMedicationAdministered(visit, m, QPP180Elements.Prednisone_Drug, patientHistoryBroadcastList)
      ||
      getConsecutiveResult(visit, m, QPP180Elements.Prednisone_1, 6, CompareOperator.LESS_EQUAL, medicationDurationBroadcastList)
      ||
      getConsecutiveResult(visit, m, QPP180Elements.Prednisolone_1, 6, CompareOperator.LESS_EQUAL, medicationDurationBroadcastList)
      ||
      getConsecutiveResult(visit, m, QPP180Elements.Cortisone_1, 6, CompareOperator.LESS_EQUAL, medicationDurationBroadcastList)
      ||
      getConsecutiveResult(visit, m, QPP180Elements.Hydrocortisone_1, 6, CompareOperator.LESS_EQUAL, medicationDurationBroadcastList)
      ||
      getConsecutiveResult(visit, m, QPP180Elements.Triamcinolone_1, 6, CompareOperator.LESS_EQUAL, medicationDurationBroadcastList)
      ||
      getConsecutiveResult(visit, m, QPP180Elements.Methylprednisolone_1, 6, CompareOperator.LESS_EQUAL, medicationDurationBroadcastList)
      ||
      getConsecutiveResult(visit, m, QPP180Elements.Dexamethasone_1, 6, CompareOperator.LESS_EQUAL, medicationDurationBroadcastList)
      ||
      getConsecutiveResult(visit, m, QPP180Elements.Betamethasone_1, 6, CompareOperator.LESS_EQUAL, medicationDurationBroadcastList)
      ||
      getConsecutiveResult(visit, m, QPP180Elements.Glucocorticoid_Therapy, 6, CompareOperator.LESS_EQUAL, medicationDurationBroadcastList)
      ||
      isDiagnosticStudyDuringMesurementPeriod(visit, m, QPP180Elements.Ra_Activity_Worsening, patientHistoryBroadcastList)
    )
      &&
       (
        isMedicationAdministered(visit, m, QPP180Elements.Prednisone_Drugs, patientHistoryBroadcastList)
        ||
         (
          (
           getConsecutiveResult(visit, m, QPP180Elements.Prednisone, 6, CompareOperator.GREATER, medicationDurationBroadcastList)
           ||
           getConsecutiveResult(visit, m, QPP180Elements.Prednisolone, 6, CompareOperator.GREATER, medicationDurationBroadcastList)
           ||
           getConsecutiveResult(visit, m, QPP180Elements.Cortisone, 6, CompareOperator.GREATER, medicationDurationBroadcastList)
           ||
           getConsecutiveResult(visit, m, QPP180Elements.Hydrocortisone, 6, CompareOperator.GREATER, medicationDurationBroadcastList)
           ||
           getConsecutiveResult(visit, m, QPP180Elements.Triamcinolone, 6, CompareOperator.GREATER, medicationDurationBroadcastList)
           ||
           getConsecutiveResult(visit, m, QPP180Elements.Methylprednisolone, 6, CompareOperator.GREATER, medicationDurationBroadcastList)
           ||
           getConsecutiveResult(visit, m, QPP180Elements.Dexamethasone, 6, CompareOperator.GREATER, medicationDurationBroadcastList)
           ||
           getConsecutiveResult(visit, m, QPP180Elements.Betamethasone, 6, CompareOperator.GREATER, medicationDurationBroadcastList)
          )
           &&
           isDiagnosticStudyDuringMesurementPeriod(visit, m, QPP180Elements.Improvement__No_Change_In_Disease_Activity_For_Ra, patientHistoryBroadcastList)
         )
       )
      &&
       isInterventionPerformed(visit, m, QPP180Elements.Glucocorticoid_Management_Plan, patientHistoryBroadcastList)
      &&
      ! (
        (
        isMedicationAdministered(visit, m, QPP180Elements.Gluco_Dose_Reason_Not_Specified, patientHistoryBroadcastList)
        ||
        isInterventionPerformed(visit, m, QPP180Elements.Gluco_Mngmnt_Pln_Reason_Not_Specified, patientHistoryBroadcastList)
        )
        &&
        isMedicationAdministered(visit, m, QPP180Elements.Prednisone_Drugs, patientHistoryBroadcastList)
       )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Documentation of medical reason(s) for not documenting glucocorticoid management plan (i.e., glucocorticoid prescription
  is for a medical condition other than RA).
  -----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
     (
      isInterventionPerformed(visit, m, QPP180Elements.Gluco_Mngmnt_Pln_Medical_Reason, patientHistoryBroadcastList)
      ||
      isInterventionPerformed(visit, m, QPP180Elements.Glucocorticoid_Prescription, patientHistoryBroadcastList)
     )
      &&
      isMedicationAdministered(visit, m, QPP180Elements.Prednisone_Drugs, patientHistoryBroadcastList)
    )
  }
}