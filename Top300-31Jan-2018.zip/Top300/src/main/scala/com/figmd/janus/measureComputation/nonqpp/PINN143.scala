
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PINN143
* Measure Title               :- Heart Failure: Patient Self-Care Education
* Measure Description         :- Percentage of patients aged >=18 years with a diagnosis of heart failure who were provided
 *                               with self-care education on >=3 elements of education during >=1 visit within a 12-month period
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- Aanchal.Rai
* Initial GIT Version/Tag(CRA):- 1.7
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object PINN143 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "PINN143"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
    PINN143Elements.ACC_Encounter_Code_Set,
    PINN143Elements.Heart_Failure,
    PINN143Elements.HF_Education_Referral_For_Visiting_Nurse_Or_Specific_Education_Or_Management_Programs,
    PINN143Elements.HF_Education_Minimizing_Or_Avoiding_Use_Of_NSAIDs,
    PINN143Elements.HF_Education_Prognosis_End_Of_Life_Issues,
    PINN143Elements.HF_Education_Medication_Instruction,
    PINN143Elements.HF_Education_Smoking_Cessation,
    PINN143Elements.Physical_Activity_Recommendation,
    PINN143Elements.HF_Education_Symptom_Management,
    PINN143Elements.HF_Education_Diet_Sodium_Restriction,
    PINN143Elements.HF_Education_Weight_Monitoring

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD,patientHistoryRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//IPP -- Patients aged >=18 years with a diagnosis of heart failure
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val encounterCountList: List[(String, Int)] = countElement(patientHistoryRDD, m,
      PINN143Elements.ACC_Encounter_Code_Set)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
      &&
      getEncounterCountFromHistory(visit, m, 1, true, encounterCountList)
      &&
      wasDiagnosedBeforeOrEqualEncounter(visit,m,PINN143Elements.Heart_Failure,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  //Numerator -- Patients who were provided with self-care education on >=3 elements of education during >=1 visit within a 12-month period
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    val encounterCountList: List[(String, Int)] = countElement(patientHistoryRDD, m,
      PINN143Elements.HF_Education_Referral_For_Visiting_Nurse_Or_Specific_Education_Or_Management_Programs,
      PINN143Elements.HF_Education_Minimizing_Or_Avoiding_Use_Of_NSAIDs,
      PINN143Elements.HF_Education_Prognosis_End_Of_Life_Issues,
      PINN143Elements.HF_Education_Medication_Instruction,
      PINN143Elements.HF_Education_Smoking_Cessation,
      PINN143Elements.Physical_Activity_Recommendation,
      PINN143Elements.HF_Education_Symptom_Management,
      PINN143Elements.HF_Education_Diet_Sodium_Restriction,
      PINN143Elements.HF_Education_Weight_Monitoring)


      denominatorRDD.filter(visit =>

      getEncounterCountFromHistory(visit, m, 3, true, encounterCountList)


    )
  }

}
