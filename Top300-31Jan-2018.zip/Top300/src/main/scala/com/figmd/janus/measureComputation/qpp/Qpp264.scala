package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP264Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 264
* Measure Title              :- Sentinel Lymph Node Biopsy for Invasive Breast Cancer
* Measure Description        :- The percentage of clinically node negative (clinical stage T1N0M0 or T2N0M0) breast cancer patients before or after neoadjuvant systemic therapy, who undergo a sentinel lymph node (SLN) procedure.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp264 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp264"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP


    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP264Elements.Breast_Cancer,
      QPP264Elements.Negative_Invasive_Breast_Cancer,
      QPP264Elements.Sentinel_Lymph_Node_Biopsy,
      QPP264Elements.Node_Biopsy,
      QPP264Elements.Slnbiop_Reason_Not_Specified,
      QPP264Elements.Incidental_Discovery_Of_Breast_Cancer_During_Reduction_Mammoplasty,
      QPP264Elements.Incidental_Discovery_Of_Breast_Cancer_On_Prophylactic_Mastectomy,
      QPP264Elements.Non_Invasive_Cancer,
      QPP264Elements.Pre_Operative_Biopsy_Proven_Lymph_Node_Metastases,
      QPP264Elements.Breast_Inflammatory_Cancer, QPP264Elements.Stage_3_Locally_Advanced_Cancer,
      QPP264Elements.Recurrent_Invasive_Breast_Cancer
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD)
      metRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, metRDD)
      intermediateA.cache()


      // Filter Exceptions
      val exceptionRDD = getException(intermediateA, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()
      //
      // Filter Exceptions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /*Patients aged 18 and older with primary invasive breast cancer. */
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        (isMale(visit, m) || isFemale(visit, m))
        &&
        isVisitTypeIn(visit, m, QPP264Elements.Mastectomy,
          QPP264Elements.Biopsy__Excision_Of_Lymph_Node,
          QPP264Elements.Dissection,
          QPP264Elements.Axillary_Lymphadenectomy,
          QPP264Elements.Intraoperative_Identification)
        &&
        isDiagnosisOverlapsEncounter(visit, m, patientHistoryList, QPP264Elements.Breast_Cancer/*, AdminElements.Encounter_Date*/)
        && (isInterventionPerformedOnEncounter(visit, m, QPP264Elements.Clinically_Node_Negative_Invasive_Breast_Cancer_T1n0m0_Or_T2n0m0)
        || isDiagnosisOverlapsMeasurementPeriod(visit, m, patientHistoryList, QPP264Elements.Negative_Invasive_Breast_Cancer)
        )

    )
  }


  // Numerator criteria
  /* Patients who undergo a SLN procedure. */
  def getMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        isProcedurePerformedDuringEncounter(visit, m, QPP264Elements.Sentinel_Lymph_Node_Biopsy)
          && !isProcedurePerformedDuringEncounter(visit, m, QPP264Elements.Node_Biopsy)
        )
        && !isProcedurePerformedDuringEncounter(visit, m, QPP264Elements.Node_Biopsy)
    )

  }

  /*Documentation of reason(s) sentinel lymph node biopsy not performed (e.g., reasons could include but not limited to; non-invasive cancer, incidental discovery of breast
  cancer on prophylactic mastectomy, incidental discovery of breast cancer on reduction mammoplasty, pre-operative biopsy proven lymph node (LN) metastases,
  inflammatory carcinoma, stage 3 locally advanced cancer,recurrent invasive breast cancer, clinically node positive after neoadjuvant systemic therapy, patient refusal after
  informed consent, patient with significant age,comorbidities, or limited life expectancy and favorable tumor; adjuvant systemic therapy unlikely to change)*/

  def getException(intermediateRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateRDD.filter(visit =>

      !isProcedurePerformedDuringEncounter(visit, m, QPP264Elements.Slnbiop_Reason_Not_Specified)
        ||
        (isProcedurePerformedOverlapsMeasurementPeriod(visit, m, patientHistoryList, QPP264Elements.Incidental_Discovery_Of_Breast_Cancer_During_Reduction_Mammoplasty,
          QPP264Elements.Incidental_Discovery_Of_Breast_Cancer_On_Prophylactic_Mastectomy)
          ||
          isDiagnosisOverlapsMeasurementPeriod(visit, m, patientHistoryList, QPP264Elements.Non_Invasive_Cancer,
            QPP264Elements.Pre_Operative_Biopsy_Proven_Lymph_Node_Metastases,
            QPP264Elements.Breast_Inflammatory_Cancer, QPP264Elements.Stage_3_Locally_Advanced_Cancer,
            QPP264Elements.Recurrent_Invasive_Breast_Cancer)
          )
    )
  }


}