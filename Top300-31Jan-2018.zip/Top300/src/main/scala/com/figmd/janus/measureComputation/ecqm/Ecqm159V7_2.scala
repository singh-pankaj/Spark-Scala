package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, CompareOperator, ECQM159V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Ecqm159V7_2
* Measure Title               :- Depression Remission at Twelve Months
* Measure Description         :- Adolescent patients 12 to 17 years of age and adult patients 18 years of age and older
*                                 with a diagnosis of major depression or dysthymia and an initial PHQ-9 or PHQ-9M score
*                                 greater than nine during the index event
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 2
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.7
* Latest GIT Version/Tag(CRA) :- 1.7
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm159V7_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm159V7_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
        , ECQM159V7Elements.Palliative_Care
        , ECQM159V7Elements.Palliative_Care_Encounter
        , ECQM159V7Elements.Care_Services_In_Long_Term_Residential_Facility
        , AdminElements.Expired
        , ECQM159V7Elements.Bipolar_Disorder
        , ECQM159V7Elements.Personality_Disorder
        , ECQM159V7Elements.Schizophrenia_Or_Psychotic_Disorder
        , ECQM159V7Elements.Pervasive_Developmental_Disorder
        , ECQM159V7Elements.Phq_9_Tool
        , ECQM159V7Elements.Tool_Phq_9
        , ECQM159V7Elements.Contact_Or_Office_Visit
        , ECQM159V7Elements.Major_Depression_Including_Remission
        , ECQM159V7Elements.Dysthymia
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
 Adult patients 18 years of age and older with a diagnosis of major depression
 or dysthymia and an initial PHQ-9 or PHQ-9M score greater than nine during the index event
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
          isPatientAdult(visit, m)
        &&
          isDepressionIndex(visit, m, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
1: Patients who died
2: Patients who received hospice or palliative care services
3: Patients who were permanent nursing home residents
4: Patients with a diagnosis of bipolar disorder
5: Patients with a diagnosis of personality disorder
6: Patients with a diagnosis of schizophrenia or psychotic disorder
7: Patients with a diagnosis of pervasive developmental disorder
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        isElementBeforeFirstDepressionIndex(visit, m, ECQM159V7Elements.Palliative_Care, patientHistoryBroadcastList)
      ||
        isElementBeforeFirstDepressionIndex(visit, m, ECQM159V7Elements.Palliative_Care_Encounter, patientHistoryBroadcastList)
      ||
        isElementBeforeFirstDepressionIndex(visit, m, ECQM159V7Elements.Care_Services_In_Long_Term_Residential_Facility, patientHistoryBroadcastList)
      ||
        isElementBeforeFirstDepressionIndex(visit, m, AdminElements.Expired, patientHistoryBroadcastList)
      ||
        isElementBeforeFirstDepressionIndex(visit, m, ECQM159V7Elements.Bipolar_Disorder, patientHistoryBroadcastList)
      ||
        isElementBeforeFirstDepressionIndex(visit, m, ECQM159V7Elements.Personality_Disorder, patientHistoryBroadcastList)
      ||
        isElementBeforeFirstDepressionIndex(visit, m, ECQM159V7Elements.Schizophrenia_Or_Psychotic_Disorder, patientHistoryBroadcastList)
      ||
        isElementBeforeFirstDepressionIndex(visit, m, ECQM159V7Elements.Pervasive_Developmental_Disorder, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Adolescent patients 12 to 17 years of age and adult patients 18 years of age and older who achieved remission at
twelve months as demonstrated by a twelve month (+/- 60 days) PHQ-9 or PHQ-9M score of less than five
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
        isAssessmentPerformedOnEncounter(visit, m, ECQM159V7Elements.Phq_9_Tool)
      &&
        isAssessmentPerformedValue(visit, m, ECQM159V7Elements.Tool_Phq_9, 5, CompareOperator.LESS, patientHistoryBroadcastList)
      &&
        isAssessmentPerformedStartsAfterEndOfAssessmentWithinMonthsRange(visit, m, ECQM159V7Elements.Phq_9_Tool, 9, 14, patientHistoryBroadcastList)
      &&
        isAssessmentPerformedStartsAfterEndOfAssessmentWithinMonthsRange(visit, m, ECQM159V7Elements.Tool_Phq_9, 9, 14, patientHistoryBroadcastList)
    )
  }




}