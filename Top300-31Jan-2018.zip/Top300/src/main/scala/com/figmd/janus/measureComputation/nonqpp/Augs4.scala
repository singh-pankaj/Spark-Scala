package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AUGS4Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Augs4
* Measure Title               :- Performing an intraoperative rectal examination at the time of prolapse repair
* Measure Description         :- Percentage of patients having a documented rectal examination at the time of surgery for repair of apical and posterior pelvic organ prolapse.
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.RASURE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/

object Augs4 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Augs4"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //getPatientHistoryRDD
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD, AUGS4Elements.Absence_Of_Rectum)
      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population : All patients undergoing apical or posterior pelvic organ prolapse (POP) surgery..
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
         isFemale(visit,m)
      && isProcedurePerformedDuringEncounter(visit,m,AUGS4Elements.Surgery_For_Apical_Or_Posterior_Pop)   // It is Procedure specific measure hence checking procedure on Encounter instead of during measurement period.
      )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator : The number of patients undergoing surgery for pelvic organ prolapse in whom an intraoperative rectal examination
was performed and documented.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
         isInterventionPerformedDuringProcedure(visit,m,AUGS4Elements.Intraoperative_Rectal_Examination,AUGS4Elements.Surgery_For_Apical_Or_Posterior_Pop)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exceptions : Patients who have undergone prior total proctectomy.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      isDiagnosisOverlapsProcedure(visit,m,AUGS4Elements.Absence_Of_Rectum,AUGS4Elements.Surgery_For_Apical_Or_Posterior_Pop,patientHistoryBroadcastList)
    )
  }
}