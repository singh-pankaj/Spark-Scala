package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,CAP28Elements,CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAP28_2
* Measure Title               :- Helicobacter Pylori Status and Turnaround Time
* Measure Description         :- Percentage of stomach biopsy cases with gastritis that addresses presence or absence of Helicobacter pylori included AND
                                 meet the maximum 2 business day turnaround time (TAT) requirement (Report Date – Accession Date ≤ 2 business days).
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- 2
* Measure Stratification      :- 1
* Measure Developer           :- SUMIT.SINGH
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
----------------------------------------------------------------------------------------------------------------------------*/

object CAP28_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "CAP28_2"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
           CAP28Elements.Chronic_Gastritis,
           CAP28Elements.Lymphocytic_Gastritis,
           CAP28Elements.Gastric_Lymphoma,
           CAP28Elements.Gastric_Resection,
           CAP28Elements.Helicobacter_Other_Exclusions,
           CAP28Elements.Gastric_Resection_Cptii,
           CAP28Elements.Consultation_Catii,
           CAP28Elements.Confirm_Case_Required_Consultation,
           CAP28Elements.Surgical_Pathology_Accession_Number

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  All final pathology reports for stomach biopsy cases with a diagnosis of chronic gastritis, chronic inactive gastritis, lymphocytic gastritis, chronic active gastritis or gastric lymphoma
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      (
              wasDiagnosedBeforeOrEqualEncounter(visit,m,CAP28Elements.Chronic_Gastritis,patientHistoryBroadcastList)
          ||  wasDiagnosedBeforeOrEqualEncounter(visit,m,CAP28Elements.Lymphocytic_Gastritis,patientHistoryBroadcastList)
          ||  wasDiagnosedBeforeOrEqualEncounter(visit,m,CAP28Elements.Gastric_Lymphoma,patientHistoryBroadcastList)
      )
          &&  isLaboratoryTestPerformedOnEncounter(visit,m,CAP28Elements.Stomach_Biopsy)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Gastric resections
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
      wasProcedurePerformedEndsBeforeStartOf(visit,m,CAP28Elements.Stomach_Biopsy,patientHistoryBroadcastList,CAP28Elements.Gastric_Resection)
        || isLaboratoryTestPerformedOnEncounter(visit,m,CAP28Elements.Helicobacter_Other_Exclusions)
        || isProcedurePerformedDuringEncounter(visit,m,CAP28Elements.Gastric_Resection_Cptii)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Rate 2: The final pathology report is in the laboratory/hospital information system with result verified and reported by the laboratory, available to the requesting physician(s) within 2 business days.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
              wasElementAfterElementWithinXDays(visit,m,CAP28Elements.Specimen_Accession_Date,CAP28Elements.Specimen_Verification_Date,2,patientHistoryBroadcastList)


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Cases requiring intra-departmental or extra-departmental consultation
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
             isCommunicationFromProvidertoProvider(visit,m,CAP28Elements.Consultation_Catii,patientHistoryBroadcastList)
        ||   communicationFromProviderToProviderInHistory(visit,m,CAP28Elements.Confirm_Case_Required_Consultation,CAP28Elements.Surgical_Pathology_Accession_Number,CompareOperator.EQUAL,patientHistoryBroadcastList)


    )
  }
}

