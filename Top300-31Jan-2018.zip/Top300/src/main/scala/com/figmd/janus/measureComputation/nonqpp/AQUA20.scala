package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,AQUA20Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AQUA20
* Measure Title               :- Genetic Testing of the Azoospermic Male
* Measure Description         :- Percentage of patients with non-obstructive azoospermia due to primary testis failure who were offered genetic testing
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- PRIYANKA CHAVAN
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/

object AQUA20 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AQUA20"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,AQUA20Elements.Non_Obstructive_Azoospermia_Testis_Failure
      ,AQUA20Elements.Genetic_Testing_Karyotype_1
      ,AQUA20Elements.Genetic_Testing_Karyotype_2
      ,AQUA20Elements.Genetic_Testing_Y_Chromosome
      ,AQUA20Elements.Genetic_Testing_Y_Chromosome_Microdeletion
      ,AQUA20Elements.Patient_Reason
      ,AQUA20Elements.Medical_Reason
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    All patients with non-obstructive azoospermia due to testis failure
   -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
             isMale(visit,m)
        &&   wasDiagnosedInHistory(visit,m,AQUA20Elements.Non_Obstructive_Azoospermia_Testis_Failure,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Patients who were offered genetic testing (karyotype AND y-chromosome microdeletion)
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        (
               wasLaboratoryTestPerformedAfterDiagnosis(visit,m,AQUA20Elements.Genetic_Testing_Karyotype_1,AQUA20Elements.Non_Obstructive_Azoospermia_Testis_Failure,patientHistoryBroadcastList)
          ||   wasLaboratoryTestPerformedAfterDiagnosis(visit,m,AQUA20Elements.Genetic_Testing_Karyotype_2,AQUA20Elements.Non_Obstructive_Azoospermia_Testis_Failure,patientHistoryBroadcastList)
        )
        &&
        (
               wasLaboratoryTestPerformedAfterDiagnosis(visit,m,AQUA20Elements.Genetic_Testing_Y_Chromosome,AQUA20Elements.Non_Obstructive_Azoospermia_Testis_Failure,patientHistoryBroadcastList)
          ||   wasLaboratoryTestPerformedAfterDiagnosis(visit,m,AQUA20Elements.Genetic_Testing_Y_Chromosome_Microdeletion,AQUA20Elements.Non_Obstructive_Azoospermia_Testis_Failure,patientHistoryBroadcastList)
        )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Documentation of medical reason(s) for not offering genetic testing
    OR
    Documentation of patient reason(s) for not offering genetic testing
   -----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
             isLaboratoryTestPerformedNotDone(visit,m,AQUA20Elements.Medical_Reason,patientHistoryBroadcastList)
        ||   isLaboratoryTestPerformedNotDone(visit,m,AQUA20Elements.Patient_Reason,patientHistoryBroadcastList)
    )
  }
}