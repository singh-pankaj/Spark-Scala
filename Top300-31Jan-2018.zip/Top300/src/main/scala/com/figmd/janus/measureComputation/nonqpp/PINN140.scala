package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,PINN140Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PINN140
* Measure Title               :- Heart Failure: Left Ventricular Ejection Fraction (LVEF) Assessment
* Measure Description         :- Percentage of patients aged >=18 years with a diagnosis of heart failure for whom the
                                 quantitative or qualitative results of a recent or prior (any time in the past) left
                                 ventricular ejection fraction assessment is documented within a 12-month period.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- Aanchal Rai
* Initial GIT Version/Tag(CRA):- 1.7
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object PINN140 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "PINN140"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,PINN140Elements.Heart_Failure
      ,PINN140Elements.Ejection_Fraction
      ,PINN140Elements.Left_Ventricular_Qualitative_Assessment
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*--------------------------------------------------------------------------------------------------------------------
  IPP - Patients aged >=18 years with a diagnosis of heart failure
  ----------------------------------------------------------------------------------------------------------------------
   */

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
        isPatientAdult(visit,m)
        && isVisitTypeIn(visit,m,PINN140Elements.ACC_Encounter_Code_Set)
        && wasDiagnosedBeforeOrEqualEncounter(visit,m,PINN140Elements.Heart_Failure,patientHistoryBroadcastList)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Numerator - Patients for whom the quantitative or qualitative results of a recent or prior (any time in the past) left
              ventricular ejection fraction assessment is documented within a 12-month period.
  ----------------------------------------------------------------------------------------------------------------------
   */

  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        wasDiagnosticStudyPerformedBeforeOrEqualEncounter(visit,m,PINN140Elements.Ejection_Fraction,patientHistoryBroadcastList)
        &&
        wasAssessmentPerformedBeforeOrEqualEncounter(visit,m,PINN140Elements.Left_Ventricular_Qualitative_Assessment,patientHistoryBroadcastList)

    )
  }

}
