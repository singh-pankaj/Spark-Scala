package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{QPP131Elements, _}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 131
* Measure Title              :- Pain Assessment and Follow-Up
* Measure Description        :- Percentage of visits for patients aged 18 years and older with documentation of a pain assessment using a standardized tool(s) on each visit AND documentation of a follow-up plan when pain is present
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp131 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp131"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //getPatientHistoryList
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        QPP131Elements.Medical_Situation,
        QPP131Elements.Physical_Disability_Incapacity,
        QPP131Elements.Mental_Illness
      )

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()


      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, metRDD)
      intermediateA.cache()

      val exceptionRDD = getException(intermediateA, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /* All visits for patients aged 18 years and older */

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)


    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m, QPP131Elements.Office_Visit,
        QPP131Elements.Cervical_Or_Vaginal_Cancer_Screening,
        QPP131Elements.Health_And_Behavioral_Assessment__Reassessment,
        QPP131Elements.Neuropsychological_Testing,
        QPP131Elements.Ophthalmological_Services,
        QPP131Elements.Psych_Visit___Diagnostic_Evaluation,
        QPP131Elements.Health_And_Behavioral_Assessment___Initial,
        QPP131Elements.Extraction_Erupted_Tooth,
        QPP131Elements.Chiropractic_Manipulative_Treatment,
        QPP131Elements.Annual_Wellness_Visit,
        QPP131Elements.Initial_Preventive_Physical_Examination,
        QPP131Elements.Home_Healthcare_Services,
        QPP131Elements.Domiciliary_Or_Rest_Home_Visit,
        QPP131Elements.Discharge_Services___Hospital_Inpatient,
        QPP131Elements.Discharge_Services___Hospital_Inpatient_Same_Day_Discharge,
        QPP131Elements.Discharge_Services___Hospital_Inpatient,
        QPP131Elements.Hospital_Inpatient_Visit___Initial,
        QPP131Elements.Therapeutic_Interventions,
        QPP131Elements.Treatment,
        QPP131Elements.Neurobehavioral_Status_Exam,
        QPP131Elements.Physical_Therapy_Evaluation_Cpt,
        QPP131Elements.Re_Evaluation_Of_Physical_Therapy_Cpt,
        QPP131Elements.Occupational_Therapy_Cpt,
        QPP131Elements.Occupational_Therapy_Re_Evalution_Cpt
      )


        && !isVisitTypeIn(visit, m, QPP131Elements.Extraction_Erupted_Tooth__Telehealth_Modifier,
        QPP131Elements.Health_And_Behavioral_Assessment_Reassessment_Telehealth_Modifier,
        QPP131Elements.Psych_Visit___Diagnostic_Evaluation_Telehealth_Modifier,
        QPP131Elements.Ophthalmological_Services_Telehealth_Modifier,
        QPP131Elements.Treatment_Telehealth_Modifier,
        QPP131Elements.Neuropsychological_Testing_Telehealth_Modifier,
        QPP131Elements.Neurobehavioral_Status_Exam_Telehealth_Modifier,
        QPP131Elements.Health_And_Behavioral_Assessment__Initial_Telehealth_Modifier,
        QPP131Elements.Annual_Wellness_Visit_Telehealth_Modifier,
        QPP131Elements.Cervical_Or_Vaginal_Cancer_Screening_Telehealth_Modifier,
        QPP131Elements.Office_Visit_Telehealth_Modifier,
        QPP131Elements.Occupational_Therapy_Evaluation_Telehealth_Modifier,
        QPP131Elements.Home_Healthcare_Services_Telehealth_Modifier,
        QPP131Elements.Domiciliary_Or_Rest_Home_Visit_Telehealth_Modifier,
        QPP131Elements.Discharge_Services___Hospital_Inpatient_Same_Day_Discharge_Telehealth_Modifier,
        QPP131Elements.Discharge_Services___Hospital_Inpatient_Telehealth_Modifier,
        QPP131Elements.Hospital_Inpatient_Visit___Initial_Telehealth_Modifier,
        QPP131Elements.Therapeutic_Interventions_Telehealth_Modifiers,
        QPP131Elements.Initial_Preventive_Physical_Examination_Telehealth_Modifier,
        QPP131Elements.Chiropractic_Manipulative_Treatment__Telehealth_Modifier,
        QPP131Elements.Physical_Therapy_Telehealth_Modifier

      )
        && !isVisitTypeIn(visit, m, QPP131Elements.Pos_02)
    )
  }


  // Numerator criteria
  /* Patient visits with a documented pain assessment using a standardized tool(s) AND documentation of a follow-up plan when pain is present.  */

  def getMet(ippRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    val standardizedToolElements = Seq(
      QPP131Elements.Brief_Pain_Inventory_Gr,
      QPP131Elements.Faces_Pain_Scale_Gr,
      QPP131Elements.Faces_Pain_Scale_Gr,
      QPP131Elements.Mcgill_Pain_Questionnaire,
      QPP131Elements.Multidimensional_Pain_Inventory,
      QPP131Elements.Numeric_Rating_Scale_Gr,
      QPP131Elements.Oswestry_Disability_Index__Odi_,
      QPP131Elements.Roland_Morris_Disability_Questionnaire,
      QPP131Elements.Verbal_Descriptor_Gr,
      QPP131Elements.Verbal_Numeric_Rating_Gr,
      QPP131Elements.Visual_Analog_Scale_Gr,
      QPP131Elements.Promis_Score)


    ippRdd.filter(visit =>  {
      val standardizedToolResult  = isStandardizedTool(visit, m)

      ((isInterventionPerformedOnEncounter(visit, m, QPP131Elements.Positive_Pain_Assessment___Follow_Up) || isInterventionPerformedOnEncounter(visit, m, QPP131Elements.Negative_Pain_Assessment___No_Follow_Up))
        ||
        /* Positive Pain Followup Starts */
        (
          isPositivePain(visit, m)
            &&
            isInterventionPerformedOnEncounter(visit, m, QPP131Elements.Follow_Up_Meds, QPP131Elements.Patient_Referred, QPP131Elements.Behavioural_Techniques_For_Pain_Management, QPP131Elements.Interventional_Therapy_For_Pain_Management_Grp)

            ||
            (
              isDiagnosedOnEncounter(visit, m, QPP131Elements.Positive_Pain)
                && standardizedToolResult
                && wasInterventionPerformedAfterAssessmentinHistory(visit, m, Seq(QPP131Elements.Follow_Up_Meds, QPP131Elements.Patient_Referred, QPP131Elements.Behavioural_Techniques_For_Pain_Management, QPP131Elements.Interventional_Therapy_For_Pain_Management_Grp), patientHistoryBroadcastList, standardizedToolElements)
                && isInterventionPerformedOnEncounter(visit, m, QPP131Elements.Follow_Up_Meds, QPP131Elements.Patient_Referred)
              )
          )
        /* Positive Pain Followup End */
        /* Negative No Followup Starts */
        ||
        (
          negativePain(visit, m)
            && isDiagnosedOnEncounter(visit, m, QPP131Elements.Negative_Pain)
            && standardizedToolResult
          )

        /* Negative No Followup Ends */
        &&
        !(isInterventionPerformedOnEncounter(visit, m, QPP131Elements.Follow_Up_Plan_Not_Doc_Reason_Not_Specified)
          || isPhysicalExamPerformedDuringEncounter(visit, m, QPP131Elements.Pain_Assessment_Not_Doc_Reason_Not_Specified))

    )

  }
    )


  }


  /* Emergency department visits for patients who had an order for a serum lactate level during the emergency department visit */

  def isStandardizedTool(visit: CassandraRow, m: MeasureProperty): Boolean = {
    (
      isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Brief_Pain_Inventory_Gr)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Faces_Pain_Scale_Gr)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Mcgill_Pain_Questionnaire)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Multidimensional_Pain_Inventory)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Neuropathic_Pain_Scale)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Numeric_Rating_Scale_Gr)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Oswestry_Disability_Index__Odi_)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Roland_Morris_Disability_Questionnaire)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Verbal_Descriptor_Gr)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Verbal_Numeric_Rating_Gr)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Visual_Analog_Scale_Gr)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Promis_Score)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Wong_Baker_Faces_Pain_Scale_Grp)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Pain_Thermometer)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Pictorial_Pain_Scale)
      )
  }

  def negativePain(visit: CassandraRow, m: MeasureProperty): Boolean = {
    (
      isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Brief_Pain_Inventory_Gr)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Faces_Pain_Scale_Gr)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Mcgill_Pain_Questionnaire)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Multidimensional_Pain_Inventory)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Numeric_Rating_Scale_Gr)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Roland_Morris_Disability_Questionnaire)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Verbal_Descriptor_Gr)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Verbal_Numeric_Rating_Gr)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Visual_Analog_Scale_Gr)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Promis_Score)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Wong_Baker_Faces_Pain_Scale_Grp)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Pain_Thermometer)
        || isAssessmentPerformedDuringEncounter(visit, m, QPP131Elements.Pictorial_Pain_Scale)
        || isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Neuropathic_Pain_Scale, 0, 4)
        || isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Oswestry_Disability_Index__Odi_, 0, 20)
        || isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Promis_Score, 50.8, 67.6)
        || isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Visual_Analog_Scale_Gr, 0, 4)
      )
  }

  def isPositivePain(visit: CassandraRow, m: MeasureProperty): Boolean = {
    (
      isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Brief_Pain_Inventory_Gr, 1, 10)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Faces_Pain_Scale_Gr, 2, 10)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Mcgill_Pain_Questionnaire, 1, 78)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Multidimensional_Pain_Inventory, 0.56, 0.75)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Neuropathic_Pain_Scale, 5, 10)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Numeric_Rating_Scale_Gr, 1, 10)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Verbal_Descriptor_Gr, 2, 10)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Verbal_Numeric_Rating_Gr, 1, 10)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Visual_Analog_Scale_Gr, 5, 100)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Roland_Morris_Disability_Questionnaire, 1, 24)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Oswestry_Disability_Index__Odi_, 21, 100)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Promis_Score, 21.2, 48.3)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Wong_Baker_Faces_Pain_Scale_Grp, 2, 10)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Pain_Thermometer, 2, 10)
        ||
        isAssessmentPerformedResultInRange(visit, m, QPP131Elements.Pictorial_Pain_Scale, 2, 10)
      )
  }

  def getException(intermediateRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateRDD.filter(visit => (
      isPhysicalExamPerformedDuringEncounter(visit, m, QPP131Elements.Pain_Assessment_Not_Doc_Patient_Not_Eligible)
        || isInterventionPerformedOnEncounter(visit, m, QPP131Elements.Follow_Up_Plan_Not_Doc_Patient_Not_Eligible)
        || (isPositivePain(visit, m)
        &&
        isDiagnosisOverlapsEncounter(visit, m, patientHistoryBroadcastList, QPP131Elements.Medical_Situation, QPP131Elements.Physical_Disability_Incapacity, QPP131Elements.Mental_Illness)

        )
      )
    )
  }
}


