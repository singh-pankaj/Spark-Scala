package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AUGS5Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Augs5
* Measure Title               :- Performing vaginal apical suspension at the time of hysterectomy to address pelvic organ prolapse
* Measure Description         :- Percentage of patients undergoing hysterectomy for the indication of pelvic organ prolapse in which
                                 a concomitant vaginal apical suspension (i.e. uterosacral, iliococygeus, sacrospinous or sacral colpopexy,
                                 or enterocele repair) is performed.
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.RASURE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/

object Augs5 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Augs5"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,AUGS5Elements.Pelvic_Organ_Prolapse,
      AUGS5Elements.Gynecologic_Or_Pelvic_Malignancy
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  // Note : It is a Procedure-specific measure hence checking all procedure on encounter instead of during measurement period.

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population : The number of patients undergoing hysterectomy performed for the indication of pelvic organ prolapse.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
           isFemale(visit,m)
        && wasDiagnosedInHistory(visit,m,AUGS5Elements.Pelvic_Organ_Prolapse,patientHistoryBroadcastList)
        && (
               (
                    isProcedurePerformedDuringEncounter(visit,m,AUGS5Elements.Trachelectomy)
                 && wasDiagnosedBeforeOrEqualProcedure(visit,m,AUGS5Elements.Trachelectomy,AUGS5Elements.Pelvic_Organ_Prolapse,patientHistoryBroadcastList)
               )
            || (
                    isProcedurePerformedDuringEncounter(visit,m,AUGS5Elements.Hysterectomy)
                 && wasDiagnosedBeforeOrEqualProcedure(visit,m,AUGS5Elements.Hysterectomy,AUGS5Elements.Pelvic_Organ_Prolapse,patientHistoryBroadcastList)
               )
           )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exclusions : • Patients with a gynecologic or other pelvic malignancy noted at the time of hysterectomy
• Patients undergoing a concurrent obliterative procedure (colpoclelsis)
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
           wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,AUGS5Elements.Gynecologic_Or_Pelvic_Malignancy)
        || isProcedurePerformedDuringEncounter(visit,m,AUGS5Elements.Obliterative_Procedure_Or_Vaginal_Closure)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator : The number of patients who have a concomitant vaginal apical suspension (i.e. enterocele repair, uterosacral-,
iliococygeus-, sacrospinous-, or sacral-colpopexy) at the time of hysterectomy for pelvic organ prolapse.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
          isProcedurePerformedDuringEncounter(visit,m,AUGS5Elements.Vaginal_Apical_Suspension)
    )
  }


}