package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp167
* Measure Title              :- Coronary Artery Bypass Graft (CABG): Postoperative Renal Failure
* Measure Description        :- Percentage of patients aged 18 years and older undergoing isolated CABG surgery (without pre-existing renal failure) who develop postoperative renal failure or require dialysis.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp167 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp167"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val patientHistoryList = getPatientHistory(sparkSession, ippRDD,
        QPP167Elements.History_Of_Renal_Failure_And_Serum_Creatinine_Level,
        QPP167Elements.Kidney_Failure,
        QPP167Elements.Serum_Creatinine_Level,
        QPP167Elements.Renal_Transplant,
        QPP167Elements.Postoperative_Renal_Failure,
        QPP167Elements.Postoperative__Renal_Failure,
        QPP167Elements.New_Requirement_For_Dialysis,
        QPP167Elements.Post_Renal_Failure_Not_Met,
        QPP167Elements.Difference_Between_Post_Operative_And_Pre_Operative_Creatinine
      ).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)
      val mostPatientHistoryList = mostRecentPatientList(getPatientHistory(sparkSession, initialRDD,
        QPP167Elements.Serum_Creatinine_Level), QPP167Elements.Serum_Creatinine_Level)
      val mostRecentPatientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostPatientHistoryList)

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList, mostRecentPatientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList, mostRecentPatientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      mostRecentPatientHistoryBroadcastList.destroy()
    }
  }

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        (
          isProcedurePerformedDuringEncounter(visit, m, QPP167Elements.Coronary_Artery_Bypass_Graft)
            ||
            (
              isProcedurePerformedDuringEncounter(visit, m, QPP167Elements.Coronary_Artery_Bypass_Graft)
                && isEncounterPerformedOnEncounter(visit, m, QPP167Elements.Cabg_Reoperation)
              )

          )
    )
  }


  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], mostRecentPatientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      isDiagnosisOverlapsEncounter(visit, m, patientHistoryBroadcastList, QPP167Elements.History_Of_Renal_Failure_And_Serum_Creatinine_Level)
        ||
        (
          isDiagnosisOverlapsEncounter(visit, m, patientHistoryBroadcastList, QPP167Elements.Kidney_Failure)
            || wasLaboratoryTestPerformedValueBeforeOrEqualEncounter(visit, m, QPP167Elements.Serum_Creatinine_Level, 4, CompareOperator.GREATER_EQUAL, patientHistoryBroadcastList)
            ||
            (
              wasProcedurePerformedEndsBeforeStartOf(visit, m, AdminElements.Encounter_Date, patientHistoryBroadcastList, QPP167Elements.Renal_Transplant)
                && wasLaboratoryTestPerformedValueBeforeOrEqualEncounter(visit, m, QPP167Elements.Serum_Creatinine_Level, 4, CompareOperator.GREATER_EQUAL, patientHistoryBroadcastList)
                && wasLaboratoryTestPerformedAfterDiagnosis(visit, m, QPP167Elements.Renal_Transplant, QPP167Elements.Serum_Creatinine_Level, patientHistoryBroadcastList)

              )


          )

    )
  }

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], mostRecentPatientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>


      (
        isDiagnosisAfterEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryBroadcastList, QPP167Elements.Postoperative_Renal_Failure)
          || isDiagnosisAfterEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryBroadcastList, QPP167Elements.Postoperative__Renal_Failure)
          || wasLaboratoryTestPerformedWithValueAfterDiagnosis(visit, m, QPP167Elements.Coronary_Artery_Bypass_Graft, QPP167Elements.Serum_Creatinine_Level, 4, CompareOperator.GREATER_EQUAL, patientHistoryBroadcastList)
          || (
          isMostRecentPhysicalExamPerformedBefore(visit, m, AdminElements.Encounter_Date, QPP167Elements.Serum_Creatinine_Level, mostRecentPatientHistoryBroadcastList)
            && isDiagnosisAfterEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryBroadcastList, QPP167Elements.Serum_Creatinine_Level)
            && isDiagnosisAfterEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryBroadcastList, QPP167Elements.Difference_Between_Post_Operative_And_Pre_Operative_Creatinine)
          )
          || wasInterventionPerformedStartAfterEndOfProcedurePerformed(visit, m, AdminElements.Encounter_Date, patientHistoryBroadcastList, QPP167Elements.New_Requirement_For_Dialysis)


        )

        && !isDiagnosisAfterEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryBroadcastList, QPP167Elements.Post_Renal_Failure_Not_Met)
    )
  }

}