package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS39
* Measure Title               :- Intraocular Pressure Reduction Following Trabeculectomy or an Aqueous Shunt Procedure
* Measure Description         :- Percentage of patients who underwent trabeculectomy or aqueous shunt procedures who had IOP
                                 reduced by 20% or more from their pretreatment between 3 and 4 months of treatment
                                 or a reduction in overall number of glaucoma medications.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.RASURE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.8
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS39 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS39"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      IRIS39Elements.Reduction_Glaucoma_Medications__Eye,
      IRIS39Elements.Chronic_Angle_Closure_Glaucoma,
      IRIS39Elements.Open_Angle_Glaucoma_Unspecified,
      IRIS39Elements.Pseudoexfoliation_Glaucoma,
      IRIS39Elements.Primary_Open_Angle_Glaucoma,
      IRIS39Elements.Pigmentary_Glaucoma,
      IRIS39Elements.Intraocular_Pressure__Iop_,
      IRIS39Elements.Visual_Acuity_Findings,
      IRIS39Elements.Absolute_Glaucoma_Blindness,
      IRIS39Elements.Reduction_In_Overall_Number_Of_Glaucoma_Medications,
      IRIS39Elements.Glaucoma_Medication_Eye,
      IRIS39Elements.Iop__Eye,
      IRIS39Elements.Glaucoma_Medications,
      IRIS39Elements.Difference_In_Iop


    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population : Patients aged between 40 and 85 years with a diagnosis of open-angle glaucoma, pigmentary glaucoma,
primary open-angle glaucoma, pseudoexfoliation glaucoma or chronic angle glaucoma and who underwent a trabeculectomy or an aqueous shunt procedure.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
           isAgeAbove(visit,m,true,40)
        && isAgeBelow(visit,m,false,86)
        && (
                isProcedurePerformedDuringEncounter(visit,m,IRIS39Elements.Trabeculectomy)
             || isProcedurePerformedDuringEncounter(visit,m,IRIS39Elements.Aqueous_Shunt)
           )
        && (
               wasDiagnosedInHistory(visit, m, IRIS39Elements.Chronic_Angle_Closure_Glaucoma, patientHistoryBroadcastList)
            || wasDiagnosedInHistory(visit, m, IRIS39Elements.Open_Angle_Glaucoma_Unspecified, patientHistoryBroadcastList)
            || wasDiagnosedInHistory(visit, m, IRIS39Elements.Pseudoexfoliation_Glaucoma, patientHistoryBroadcastList)
            || wasDiagnosedInHistory(visit, m, IRIS39Elements.Primary_Open_Angle_Glaucoma, patientHistoryBroadcastList)
            || wasDiagnosedInHistory(visit, m, IRIS39Elements.Pigmentary_Glaucoma, patientHistoryBroadcastList)
           )
        && (
               wasPhysicalExamPerformedStartsBeforeStartOfEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,IRIS39Elements.Intraocular_Pressure__Iop_)
            && checkEyeElementsInRangeIRIS2(visit,m,true,Seq(IRIS39Elements.Chronic_Angle_Closure_Glaucoma__Eye,IRIS39Elements.Open_Angle_Glaucoma_Unspecified,IRIS39Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS39Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS39Elements.Pigmentary_Glaucoma__Eye),patientHistoryBroadcastList,IRIS39Elements.Iop__Eye)
            )
        && (
               wasMedicationActiveStartsBeforeStartOfEncounter(visit,m,IRIS39Elements.Glaucoma_Medications,patientHistoryBroadcastList)
            && checkEyeElementsInRangeIRIS2(visit,m,true,Seq(IRIS39Elements.Chronic_Angle_Closure_Glaucoma__Eye,IRIS39Elements.Open_Angle_Glaucoma_Unspecified,IRIS39Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS39Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS39Elements.Pigmentary_Glaucoma__Eye),patientHistoryBroadcastList,IRIS39Elements.Glaucoma_Medication_Eye)
           )
        && (
              (   isProcedurePerformedDuringEncounter(visit,m,IRIS39Elements.Trabeculectomy)
               && checkEyeElementsInRangeIRIS2(visit,m,true,Seq(IRIS39Elements.Chronic_Angle_Closure_Glaucoma__Eye,IRIS39Elements.Open_Angle_Glaucoma_Unspecified,IRIS39Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS39Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS39Elements.Pigmentary_Glaucoma__Eye),patientHistoryBroadcastList,IRIS39Elements.Trabeculectomy_Eye)
               )
              || (   isProcedurePerformedDuringEncounter(visit,m,IRIS39Elements.Aqueous_Shunt)
                  && checkEyeElementsInRangeIRIS2(visit,m,true,Seq(IRIS39Elements.Chronic_Angle_Closure_Glaucoma__Eye,IRIS39Elements.Open_Angle_Glaucoma_Unspecified,IRIS39Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS39Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS39Elements.Pigmentary_Glaucoma__Eye),patientHistoryBroadcastList,IRIS39Elements.Aqueous_Shunt__Eye)
                 )
           )
        && (
               wasPhysicalExamPerformedBetweenMonthAfterEnd(visit,m,AdminElements.Encounter_Date,IRIS39Elements.Intraocular_Pressure__Iop_,3,4,CompareOperator.GREATER_EQUAL,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
            && checkEyeElementsInRangeIRIS2(visit,m,true,Seq(IRIS39Elements.Chronic_Angle_Closure_Glaucoma__Eye,IRIS39Elements.Open_Angle_Glaucoma_Unspecified,IRIS39Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS39Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS39Elements.Pigmentary_Glaucoma__Eye),patientHistoryBroadcastList,IRIS39Elements.Iop__Eye)
           )
        && (
                  wasMedicationActiveBetweenMonthAfterEnd(visit,m,AdminElements.Encounter_Date,IRIS39Elements.Glaucoma_Medications,3,4,CompareOperator.GREATER_EQUAL,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
               && checkEyeElementsInRangeIRIS2(visit,m,true,Seq(IRIS39Elements.Chronic_Angle_Closure_Glaucoma__Eye,IRIS39Elements.Open_Angle_Glaucoma_Unspecified,IRIS39Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS39Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS39Elements.Pigmentary_Glaucoma__Eye),patientHistoryBroadcastList,IRIS39Elements.Glaucoma_Medication_Eye)
             )

      )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exclusions : Eyes with absolute glaucoma blindness

Visual acuity findings: Count fingers (CF or FC), Hand motion (HM), Light perception (LP), No light perception (NLP).
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
          (
              isPhysicalExamPerformed(visit,m,IRIS39Elements.Visual_Acuity_Findings,patientHistoryBroadcastList)
           && checkEyeElementsInRangeIRIS2(visit,m,true,Seq(IRIS39Elements.Chronic_Angle_Closure_Glaucoma__Eye,IRIS39Elements.Open_Angle_Glaucoma_Unspecified,IRIS39Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS39Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS39Elements.Pigmentary_Glaucoma__Eye),patientHistoryBroadcastList,IRIS39Elements.Visual_Acuity_Findings__Eye)
          )
       || (
              isDiagnosed(visit,m,IRIS39Elements.Absolute_Glaucoma_Blindness,patientHistoryBroadcastList)
           && checkEyeElementsInRangeIRIS2(visit,m,true,Seq(IRIS39Elements.Chronic_Angle_Closure_Glaucoma__Eye,IRIS39Elements.Open_Angle_Glaucoma_Unspecified,IRIS39Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS39Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS39Elements.Pigmentary_Glaucoma__Eye),patientHistoryBroadcastList,IRIS39Elements.Absolute_Glaucoma_Blindness_Eye)
          )


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator : Eye(s) with a reduction in IOP ≥ 20% from the pretreatment level or a reduction in the overall number of glaucoma medications.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>

        (    wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,IRIS39Elements.Reduction_In_Overall_Number_Of_Glaucoma_Medications)
          && checkEyeElementsInRangeIRIS2(visit,m,true,Seq(IRIS39Elements.Chronic_Angle_Closure_Glaucoma__Eye,IRIS39Elements.Open_Angle_Glaucoma_Unspecified,IRIS39Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS39Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS39Elements.Pigmentary_Glaucoma__Eye),patientHistoryBroadcastList,IRIS39Elements.Reduction_Glaucoma_Medications__Eye)
        )
     || (
             isPhysicalExamPerformedDifferenceInIop(visit,m,IRIS39Elements.Difference_In_Iop,CalenderUnit.MONTH,3,CompareOperator.GREATER_EQUAL,CalenderUnit.MINUTE,4,CompareOperator.LESS_EQUAL,CompareOperator.GREATER_EQUAL,20,patientHistoryBroadcastList,IRIS39Elements.Trabeculectomy,IRIS39Elements.Aqueous_Shunt)
          && checkEyeElementsInRangeIRIS2(visit,m,true,Seq(IRIS39Elements.Chronic_Angle_Closure_Glaucoma__Eye,IRIS39Elements.Open_Angle_Glaucoma_Unspecified,IRIS39Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS39Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS39Elements.Pigmentary_Glaucoma__Eye),patientHistoryBroadcastList,IRIS39Elements.Iop__Eye)
        )
    )
  }


}