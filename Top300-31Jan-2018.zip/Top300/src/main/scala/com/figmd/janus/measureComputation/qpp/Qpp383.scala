package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.QPP383Elements
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{ MeasureProperty,CalenderUnit}
import com.figmd.janus.measureComputation.master.AdminElements


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 383
* Measure Title              :- Adherence to Antipsychotic Medications For Individuals with Schizophrenia
* Measure Description        :- Percentage of individuals at least 18 years of age as of the beginning of the measurement period with schizophrenia or schizoaffective disorder who had at least two prescriptions filled for any antipsychotic medication and
*                               who had a Proportion of Days Covered (PDC) of at least 0.8 for antipsychotic medications during the measurement period (12 consecutive months)
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp383 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp383"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD, QPP383Elements.Risperidone_Microspheres,
      QPP383Elements.Antipsychotic_Prescription,
      QPP383Elements.Atypical_Antipsychotic_Prescription,
      QPP383Elements.Acute_Inpatient_Setting,
      QPP383Elements.Pos_21_51,
      QPP383Elements.Schizophrenia_Or_Schizoaffective_Disorder,
      QPP383Elements.Risperidone_Microspheres,
      QPP383Elements.Injectable_Antipsychotic_Medications,
      QPP383Elements.Dementia,
      QPP383Elements.Pdc_For_Antipsychotics,
      QPP383Elements.Pdc_For_Antipsychotics_Met,
      QPP383Elements.Pdc_For_Antipsychotics_Not_Met)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //eligible RDD
      val denominatorRDD = ippRDD

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //Individuals at least 18 years of age as of the beginning of the measurement period with schizophrenia or schizoaffective disorder
  //and at least two prescriptions filled for any antipsychotic medication during the measurement period (12 consecutive months).
  def getIpp(initialRDD: RDD[CassandraRow],patineHistoryRDD: RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    val countElementList1: List[(String,Int)] = countElement(patineHistoryRDD,m,
                                                                                QPP383Elements.Antipsychotic_Prescription,
                                                                                QPP383Elements.Atypical_Antipsychotic_Prescription

                                                            )
    val countElementList2: List[(String,Int)] = countElement(patineHistoryRDD,m,
                                                                                QPP383Elements.Acute_Inpatient_Setting,
                                                                                QPP383Elements.Pos_21_51

                                                             )
    initialRDD.filter(visit =>
                          isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
                       && isDiagnosisOverlapsEncounter(visit,m,patientHistoryBroadcastList,QPP383Elements.Schizophrenia_Or_Schizoaffective_Disorder)
                       &&
                          (
                              (
                                    isMedicationAdministered(visit,m,QPP383Elements.Risperidone_Microspheres,patientHistoryBroadcastList)
                                ||  isMedicationAdministered(visit,m,QPP383Elements.Injectable_Antipsychotic_Medications,patientHistoryBroadcastList)
                              )
                            ||


                                getEncounterCountFromHistory(visit,m,2, true,countElementList1)

                          )
                       &&
                         (
                              (
                                    isEncounterPerformedConcurrentWith(visit,m,QPP383Elements.Acute_Inpatient_Setting,QPP383Elements.Pos_21_51)
                                &&  getEncounterCountFromHistory(visit,m,1, true,countElementList2)
                              )
                           ||
                              (
                                    getEncounterCountFromHistory(visit,m,2, true,countElementList1)
                                && isVisitTypeIn(visit,m,QPP383Elements.Service_In_Outpatient_Setting ,
                                      QPP383Elements.Pos,
                                      QPP383Elements.Emergency_Department_Visit,
                                      QPP383Elements.Ed_Setting,
                                      QPP383Elements.Pos_23,
                                      QPP383Elements.Service_In_Non_Acute_Inpatient_Setting,
                                      QPP383Elements.Pos_31_32_56)
                              )
                         )
    )
  }


  //Diagnosis for dementia
  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
                          wasDiagnosedInHistory(visit,m,QPP383Elements.Dementia,patientHistoryBroadcastList)
    )
  }

  //Individuals in the denominator who have a Proportion of Days Covered (PDC) of at least 0.8 for antipsychotic medications.
  def getMet(intermediateA: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
                                  (
                                        isAssessmentPerformed(visit,m,QPP383Elements.Pdc_For_Antipsychotics,patientHistoryBroadcastList)
                                    ||  isAssessmentPerformed(visit,m,QPP383Elements.Pdc_For_Antipsychotics_Met,patientHistoryBroadcastList)
                                  )
                                 && !isAssessmentPerformed(visit,m,QPP383Elements.Pdc_For_Antipsychotics_Not_Met,patientHistoryBroadcastList)
    )
  }

}
