package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, IRIS35Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS35
* Measure Title               :- Improvement of Macular Edema in Patients with Uveitis
* Measure Description         :- Percentage of patients with uveitis and macular edema with a reduction of 20% or greater in the central subfield thickness on OCT within 90 days after treatment.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS35 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "IRIS35"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,IRIS35Elements.Anterior_Uveitis
      ,IRIS35Elements.Posterior_Uveitis
      ,IRIS35Elements.Intermediate_Uveitis
      ,IRIS35Elements.Panuveitis
      ,IRIS35Elements.Macular_Edema
      ,IRIS35Elements.Macular_Edema_Eye
      ,IRIS35Elements.Anterior_Uveitis_Eye
      ,IRIS35Elements.Posterior_Uveitis_Eye
      ,IRIS35Elements.Intermediate_Uveitis_Eye
      ,IRIS35Elements.Panuveitis_Eye
      ,IRIS35Elements.Treatment_For_Macular_Edema
      ,IRIS35Elements.Optical_Coherence_Tomography__Oct_
      ,IRIS35Elements.Optical_Coherence_Tomography__Oct__Eye
      ,IRIS35Elements.Treatment_For_Macular_Edema
      ,IRIS35Elements.Treatment_For_Macular_Edema_Eye
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients aged 18 years or older with uveitis and macular edema who underwent treatment for uveitis or macular edema.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
              isPatientAdult(visit,m)
          &&  (     wasDiagnosedInHistory(visit,m,IRIS35Elements.Anterior_Uveitis,patientHistoryBroadcastList)
                ||  wasDiagnosedInHistory(visit,m,IRIS35Elements.Posterior_Uveitis,patientHistoryBroadcastList)
                ||  wasDiagnosedInHistory(visit,m,IRIS35Elements.Intermediate_Uveitis,patientHistoryBroadcastList)
                ||  wasDiagnosedInHistory(visit,m,IRIS35Elements.Panuveitis,patientHistoryBroadcastList)
              )
          &&  wasDiagnosedInHistory(visit,m,IRIS35Elements.Macular_Edema,patientHistoryBroadcastList)
          &&  (     checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS35Elements.Macular_Edema_Eye,patientHistoryBroadcastList,IRIS35Elements.Anterior_Uveitis_Eye)
                ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS35Elements.Macular_Edema_Eye,patientHistoryBroadcastList,IRIS35Elements.Posterior_Uveitis_Eye)
                ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS35Elements.Macular_Edema_Eye,patientHistoryBroadcastList,IRIS35Elements.Intermediate_Uveitis_Eye)
                ||  checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS35Elements.Macular_Edema_Eye,patientHistoryBroadcastList,IRIS35Elements.Panuveitis_Eye)
              )
          &&  wasProcedurePerformedBeforeMedication(visit,m,IRIS35Elements.Treatment_For_Macular_Edema,IRIS35Elements.Optical_Coherence_Tomography__Oct_,patientHistoryBroadcastList)
          &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,true,IRIS35Elements.Treatment_For_Macular_Edema_Eye,patientHistoryBroadcastList,Seq(IRIS35Elements.Optical_Coherence_Tomography__Oct__Eye))
          &&  (   (    wasMedicationActiveAfterDiagnosis(visit,m,IRIS35Elements.Treatment_For_Macular_Edema,patientHistoryBroadcastList,IRIS35Elements.Anterior_Uveitis)
                   &&  checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS35Elements.Treatment_For_Macular_Edema_Eye,patientHistoryBroadcastList,IRIS35Elements.Anterior_Uveitis_Eye)
                  )
              ||
                  (    wasMedicationActiveAfterDiagnosis(visit,m,IRIS35Elements.Treatment_For_Macular_Edema,patientHistoryBroadcastList,IRIS35Elements.Posterior_Uveitis)
                   &&  checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS35Elements.Treatment_For_Macular_Edema_Eye,patientHistoryBroadcastList,IRIS35Elements.Posterior_Uveitis_Eye)
                  )
              ||
                  (    wasMedicationActiveAfterDiagnosis(visit,m,IRIS35Elements.Treatment_For_Macular_Edema,patientHistoryBroadcastList,IRIS35Elements.Intermediate_Uveitis)
                   &&  checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS35Elements.Treatment_For_Macular_Edema_Eye,patientHistoryBroadcastList,IRIS35Elements.Intermediate_Uveitis_Eye)
                  )
              ||
                  (    wasMedicationActiveAfterDiagnosis(visit,m,IRIS35Elements.Treatment_For_Macular_Edema,patientHistoryBroadcastList,IRIS35Elements.Panuveitis)
                   &&  checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS35Elements.Treatment_For_Macular_Edema_Eye,patientHistoryBroadcastList,IRIS35Elements.Panuveitis_Eye)
                  )
             )
          && (    wasMedicationActiveAfterDiagnosis(visit,m,IRIS35Elements.Treatment_For_Macular_Edema,patientHistoryBroadcastList,IRIS35Elements.Macular_Edema)
              &&  checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS35Elements.Treatment_For_Macular_Edema_Eye,patientHistoryBroadcastList,IRIS35Elements.Macular_Edema_Eye)
             )
          && wasProcedurePerformedAfterMedicationWithInXDays(visit,m,IRIS35Elements.Treatment_For_Macular_Edema,IRIS35Elements.Optical_Coherence_Tomography__Oct_,CalenderUnit.DAY,90,patientHistoryBroadcastList)
          && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS35Elements.Treatment_For_Macular_Edema_Eye,patientHistoryBroadcastList,IRIS35Elements.Optical_Coherence_Tomography__Oct__Eye)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with a 20% reduction or greater of central subfield thickness within 90 days of treatment initiation.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
          wasProcedurePerformedAfterMedicationWithinXDays(visit,m,IRIS35Elements.Optical_Coherence_Tomography__Oct_,CalenderUnit.DAY,90,CompareOperator.GREATER_EQUAL,20,patientHistoryBroadcastList,IRIS35Elements.Treatment_For_Macular_Edema)
      &&  checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS35Elements.Treatment_For_Macular_Edema_Eye,patientHistoryBroadcastList,IRIS35Elements.Optical_Coherence_Tomography__Oct__Eye)
    )
  }

}
