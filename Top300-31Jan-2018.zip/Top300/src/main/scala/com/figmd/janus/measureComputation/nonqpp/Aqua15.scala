package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AQUA15Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AQUA 15
* Measure Title              :- Stones: Urinalysis documented 30 days before surgical stone procedures
* Measure Description        :- Percentage of patients with a documented urinalysis 30 days before surgical stone procedures
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/
object Aqua15 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Aqua15"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patienthistoryRdd = getPatientHistory(sparkSession, initialRDD,
      AQUA15Elements.Stones,
      AQUA15Elements.Urinalysis)

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistoryRdd.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }


  // IPP criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      wasDiagnosisInHistory(visit, m, AQUA15Elements.Stones, patientHistoryList)
        &&
        (
          isProcedurePerformedDuringEncounter(visit, m, AQUA15Elements.Cystoscopy_Stent_Placement)
          ||
          isProcedurePerformedDuringEncounter(visit, m, AQUA15Elements.Shock_Wave_Lithotripsy)
          ||
          isProcedurePerformedDuringEncounter(visit, m, AQUA15Elements.Litholapaxy)
          ||
          isProcedurePerformedDuringEncounter(visit, m, AQUA15Elements.Percutaneous_Nephrolithotomy)
          ||
          isProcedurePerformedDuringEncounter(visit, m, AQUA15Elements.Percutaneous_Nephrostomy_Tube_Placement)
          ||
          isProcedurePerformedDuringEncounter(visit, m, AQUA15Elements.Ureteroscopy)
          ||
          isProcedurePerformedDuringEncounter(visit, m, AQUA15Elements.Bladder_Procdeures_Md_Notes)
          )
    )
  }

  // Numerator criteria
  def getMet(metRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    metRDD.filter(visit =>
      wasDiagnosticStudyBeforeXDaysProcedure(visit, m,AQUA15Elements.Cystoscopy_Stent_Placement, AQUA15Elements.Urinalysis, 30,  patientHistoryList)
      ||
      wasDiagnosticStudyBeforeXDaysProcedure(visit, m,AQUA15Elements.Shock_Wave_Lithotripsy, AQUA15Elements.Urinalysis, 30,  patientHistoryList)
      ||
      wasDiagnosticStudyBeforeXDaysProcedure(visit, m,AQUA15Elements.Litholapaxy, AQUA15Elements.Urinalysis, 30,  patientHistoryList)
      ||
      wasDiagnosticStudyBeforeXDaysProcedure(visit, m,AQUA15Elements.Percutaneous_Nephrolithotomy, AQUA15Elements.Urinalysis, 30,  patientHistoryList)
      ||
      wasDiagnosticStudyBeforeXDaysProcedure(visit, m,AQUA15Elements.Percutaneous_Nephrostomy_Tube_Placement, AQUA15Elements.Urinalysis, 30,  patientHistoryList)
      ||
      wasDiagnosticStudyBeforeXDaysProcedure(visit, m,AQUA15Elements.Ureteroscopy, AQUA15Elements.Urinalysis, 30,  patientHistoryList)
      ||
      wasDiagnosticStudyBeforeXDaysProcedure(visit, m,AQUA15Elements.Bladder_Procdeures_Md_Notes, AQUA15Elements.Urinalysis, 30,  patientHistoryList)

    )
  }
}
