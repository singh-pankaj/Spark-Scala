package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,PRIME96Elements,CompareOperator,TimeOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PRIME96
* Measure Title               :- Adolescent Well Care Visits
* Measure Description         :- The percentage of children 12–21 years of age who had at least one comprehensive well-care
                                 visit with a PCP or an OB/GYN practitioner during the measurement year
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SANKET.DHAPTE
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object PRIME96 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "PRIME96"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,PRIME96Elements.Well_Child_Pcp_Visit
      ,PRIME96Elements.Well_Care_Visit
      ,PRIME96Elements.Physical_Exam
      ,PRIME96Elements.Physical_Developmental_History
      ,PRIME96Elements.Mental_Developmental_History
      ,PRIME96Elements.Health_History
      ,PRIME96Elements.Health_Education_Anticipatory_Guidance
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients 12-21 years of age during the measurement year.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeBetween(visit,m,12,CompareOperator.GREATER_EQUAL,22,CompareOperator.LESS)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  At least one comprehensive well-care visit with a PCP or an OB/GYN practitioner during the measurement year. The practitioner does not have to be the practitioner assigned to the member AND Documentation from the medical record must include a note indicating a visit with a PCP, the date when the well-child visit occurred
  and evidence of all of the following:
  • A health history.
  • A physical developmental history.
  • A mental developmental history.
  • A physical exam.
  • Health education/anticipatory guidance.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      (
        (
               isEncounterPerformed(visit,m,PRIME96Elements.Well_Child_Pcp_Visit,patientHistoryBroadcastList)
            || isEncounterPerformed(visit,m,PRIME96Elements.Well_Care_Visit,patientHistoryBroadcastList)
          )
          &&
          (
            (
                   wasAssessementPerformedDuringEncounterInHistory(visit,m,PRIME96Elements.Physical_Exam,PRIME96Elements.Well_Child_Pcp_Visit,TimeOperator.EQUAL,patientHistoryBroadcastList)
                && wasAssessementPerformedDuringEncounterInHistory(visit,m,PRIME96Elements.Physical_Developmental_History,PRIME96Elements.Well_Child_Pcp_Visit,TimeOperator.EQUAL,patientHistoryBroadcastList)
                && wasAssessementPerformedDuringEncounterInHistory(visit,m,PRIME96Elements.Mental_Developmental_History,PRIME96Elements.Well_Child_Pcp_Visit,TimeOperator.EQUAL,patientHistoryBroadcastList)
                && wasAssessementPerformedDuringEncounterInHistory(visit,m,PRIME96Elements.Health_History,PRIME96Elements.Well_Child_Pcp_Visit,TimeOperator.EQUAL,patientHistoryBroadcastList)
                && wasAssessementPerformedDuringEncounterInHistory(visit,m,PRIME96Elements.Health_Education_Anticipatory_Guidance,PRIME96Elements.Well_Child_Pcp_Visit,TimeOperator.EQUAL,patientHistoryBroadcastList)
              )
              ||
              (
                     wasAssessementPerformedDuringEncounterInHistory(visit,m,PRIME96Elements.Physical_Exam,PRIME96Elements.Well_Care_Visit,TimeOperator.EQUAL,patientHistoryBroadcastList)
                  && wasAssessementPerformedDuringEncounterInHistory(visit,m,PRIME96Elements.Physical_Developmental_History,PRIME96Elements.Well_Care_Visit,TimeOperator.EQUAL,patientHistoryBroadcastList)
                  && wasAssessementPerformedDuringEncounterInHistory(visit,m,PRIME96Elements.Mental_Developmental_History,PRIME96Elements.Well_Care_Visit,TimeOperator.EQUAL,patientHistoryBroadcastList)
                  && wasAssessementPerformedDuringEncounterInHistory(visit,m,PRIME96Elements.Health_History,PRIME96Elements.Well_Care_Visit,TimeOperator.EQUAL,patientHistoryBroadcastList)
                  && wasAssessementPerformedDuringEncounterInHistory(visit,m,PRIME96Elements.Health_Education_Anticipatory_Guidance,PRIME96Elements.Well_Care_Visit,TimeOperator.EQUAL,patientHistoryBroadcastList)
                )
            )
        )
        ||
        (
               isEncounterPerformed(visit,m,PRIME96Elements.Well_Child_Pcp_Visit,patientHistoryBroadcastList)
            || isEncounterPerformed(visit,m,PRIME96Elements.Well_Care_Visit,patientHistoryBroadcastList)
          )

    )
  }

}
