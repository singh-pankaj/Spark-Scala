package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AQUA16Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AQUA 16
* Measure Title              :- Non Muscle Invasive Bladder Cancer: Repeat Transurethal Resection of Bladder Tumor (TURBT) for T1 disease
* Measure Description        :- Percentage of patients with T1 disease, that had a second TURBTwithin 6 weeks of the initial TURBT
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/
object Aqua16 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Aqua16"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patienthistoryRdd = getPatientHistory(sparkSession, initialRDD,
      AQUA16Elements.Transurethral_Resection_For_Bladder_Tumor,
      AQUA16Elements.Bladder_Cancer,
      AQUA16Elements.T1_Disease,
      AQUA16Elements.Chemotherapy_Onset,
      AQUA16Elements.Radical_Cystectomy
    )

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistoryRdd.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Intermediate A
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Intermediate B
      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      // Filter Denominator Exception
      val exceptionRDD = getException(intermediateB, patientHistoryList)
      exceptionRDD.cache()

      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }


  // IPP criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      (
        wasDiagnosisAfterOrConcurentWithProcedure(visit, m, AQUA16Elements.Transurethral_Resection_For_Bladder_Tumor, patientHistoryList, AQUA16Elements.Bladder_Cancer)
          || wasDiagnosisAfterOrConcurentWithProcedure(visit, m, AQUA16Elements.Transurethral_Resection_For_Bladder_Tumor, patientHistoryList, AQUA16Elements.T1_Disease)
        )
        && isProcedurePerformedDuringEncounter(visit, m, AQUA16Elements.Transurethral_Resection_For_Bladder_Tumor)
    )
  }


  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      wasProcedurePerfiormedAfterDiagnosisWithinXWeeksInHistory(visit, m, AQUA16Elements.Transurethral_Resection_For_Bladder_Tumor_Repeat, 6, patientHistoryList, AQUA16Elements.T1_Disease)
        || wasProcedurePerfiormedAfterDiagnosisWithinXWeeksInHistory(visit, m, AQUA16Elements.Transurethral_Resection_For_Bladder_Tumor_Repeat, 6, patientHistoryList, AQUA16Elements.Bladder_Cancer)

    )
  }

  // Denominator Exception criteria
  def getException(intermediateB: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    var m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateB.filter(visit =>
      (wasProcedurePerformedXMonthsAfterDiagnosis(visit, m, AQUA16Elements.Bladder_Cancer, AQUA16Elements.Chemotherapy_Onset, 3, patientHistoryList)
        && wasProcedurePerformedXMonthsAfterDiagnosis(visit, m, AQUA16Elements.T1_Disease, AQUA16Elements.Chemotherapy_Onset, 3, patientHistoryList))
        ||
        (wasProcedurePerformedXMonthsAfterDiagnosis(visit, m, AQUA16Elements.Bladder_Cancer, AQUA16Elements.Radical_Cystectomy, 3, patientHistoryList)
          && wasProcedurePerformedXMonthsAfterDiagnosis(visit, m, AQUA16Elements.T1_Disease, AQUA16Elements.Radical_Cystectomy, 3, patientHistoryList))
    )
  }
}
