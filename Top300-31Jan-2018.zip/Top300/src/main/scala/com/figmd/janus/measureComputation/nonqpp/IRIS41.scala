package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, IRIS41Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS41
* Measure Title               :- Improved visual acuity after epiretinal membrane treatment within 120 days
* Measure Description         :- Percentage of patients with a 20% improvement in visual acuity within 120 days
*                                following epiretinal membrane treatment
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.6
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS41 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS41"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
          , IRIS41Elements.Epiretinal_Membrane
          , IRIS41Elements.Epiretinal_Membrane_Treatment
          , IRIS41Elements.Visual_Acuity
          , IRIS41Elements.Epiretinal_Membrane_Treatment_Eye
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]], patientHistoryRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
  All patients aged 18 years or older with a diagnosis of epiretinal membrane and had a procedure to treat epiretinal membrane
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], patientHistoryRDD:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
          isPatientAdult(visit, m)
        &&
          isProcedurePerformedDuringEncounter(visit, m, IRIS41Elements.Epiretinal_Membrane_Treatment)
        &&
          wasDiagnosisInHistory(visit, m, IRIS41Elements.Epiretinal_Membrane, patientHistoryBroadcastList)
        &&
          isDiagnosedConcurrentWith(visit, m, IRIS41Elements.Epiretinal_Membrane_Eye,IRIS41Elements.Epiretinal_Membrane)
        &&
          isPhysicalExamPerformedBeforeProcedure(visit, m, IRIS41Elements.Epiretinal_Membrane_Treatment, patientHistoryBroadcastList, IRIS41Elements.Visual_Acuity)
        &&
          isPhysicalExamPerformedConcurrentWith(visit, m, IRIS41Elements.Visual_Acuity_Eye, IRIS41Elements.Visual_Acuity)
        &&
          isProcedurePerformedXDaysBeforeEnd(visit, m, IRIS41Elements.Epiretinal_Membrane_Treatment, 120)
        &&
          isProcedurePerformedWasConcurrentWith(visit, m, IRIS41Elements.Epiretinal_Membrane_Treatment_Eye, IRIS41Elements.Epiretinal_Membrane_Treatment, patientHistoryBroadcastList)
        &&
          wasProcedureEyeEqualsWithInXDaysAfter(visit, m, IRIS41Elements.Visual_Acuity, 0, patientHistoryRDD, IRIS41Elements.Epiretinal_Membrane_Treatment)
        //No Need of this repeat call
        //&&
        //  isPhysicalExamPerformedConcurrentWith(visit, m, IRIS41Elements.Visual_Acuity_Eye, IRIS41Elements.Visual_Acuity)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Patients with uveitis or cystoid macular edema
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            (
                isDignosisBeforeProcedure(visit, m, IRIS41Elements.Uveitis, patientHistoryBroadcastList, IRIS41Elements.Epiretinal_Membrane_Treatment)
              &&
                wasDiagnosisOverlapsProcedureInHistory(visit, m, IRIS41Elements.Uveitis, IRIS41Elements.Epiretinal_Membrane_Treatment, patientHistoryBroadcastList)
              &&
                isDiagnosedConcurrentWith(visit, m, IRIS41Elements.Uveitis_Eye, IRIS41Elements.Uveitis)
            )
          ||
            (
                isDignosisBeforeProcedure(visit, m, IRIS41Elements.Cystoid_Macular_Edema, patientHistoryBroadcastList, IRIS41Elements.Epiretinal_Membrane_Treatment)
              &&
                wasDiagnosisOverlapsProcedureInHistory(visit, m, IRIS41Elements.Cystoid_Macular_Edema, IRIS41Elements.Epiretinal_Membrane_Treatment, patientHistoryBroadcastList)
              &&
                isDiagnosedConcurrentWith(visit, m, IRIS41Elements.Cystoid_Macular_Edema_Eye, IRIS41Elements.Cystoid_Macular_Edema)
            )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Patients with a 20% improvement in visual acuity within 120 days following epiretinal membrane treatment
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
          isPhysicalExamAndVAValueAfterXProcedureDays(visit, m, IRIS41Elements.Improved_Visual_Acuity, IRIS41Elements.Visual_Acuity, IRIS41Elements.Epiretinal_Membrane_Treatment, 120, patientHistoryBroadcastList)
        &&
          isPhysicalExamPerformedConcurrentWith(visit, m, IRIS41Elements.Improved_Visual_Acuity__Eye, IRIS41Elements.Improved_Visual_Acuity)
    )
  }


}

