package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AQUA18Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AQUA 18
* Measure Title              :- Non Muscle Invasive Bladder Cancer:Early surveillance cystoscopy within 4 months of initial diagnosis
* Measure Description        :- Percentage of patients who receive surveillance cystoscopy within 4 months of TURBT for bladder cancer.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/
object Aqua18 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Aqua18"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patienthistoryRdd = getPatientHistory(sparkSession, initialRDD,
      AQUA18Elements.Bladder_Cancer,
      AQUA18Elements.Transurethral_Resection_For_Bladder_Tumor,
      AQUA18Elements.Cystoscopy,
      AQUA18Elements.Chemotherapy_Onset,
      AQUA18Elements.Radical_Cystectomy,
      AQUA18Elements.Bladder_Cancer
    )

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistoryRdd.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

     // Filter Intermediate A
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Intermediate B
      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      // Filter Denominator Exception
      val exceptionRDD = getException(intermediateB, patientHistoryList)
      exceptionRDD.cache()

      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }


  // IPP criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isProcedurePerformedDuringEncounter(visit, m, AQUA18Elements.Transurethral_Resection_For_Bladder_Tumor)
        &&
        wasDiagnosisAfterProcedurePerformed(visit, m, AQUA18Elements.Bladder_Cancer, patientHistoryList, AQUA18Elements.Transurethral_Resection_For_Bladder_Tumor)
    )
  }

  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      wasProcedurePerformedAfterXMonthsOfProcedure(visit, m,
        AQUA18Elements.Transurethral_Resection_For_Bladder_Tumor, AQUA18Elements.Cystoscopy, 4, patientHistoryList)

    )
  }

  // Denominator Exception criteria
  def getException(intermediateB: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    var m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateB.filter(visit =>
      wasProcedurePerformedXMonthsAfterDiagnosis(visit,m, AQUA18Elements.Bladder_Cancer, AQUA18Elements.Chemotherapy_Onset,3,patientHistoryList)
      ||
      wasProcedurePerformedXMonthsAfterDiagnosis(visit,m, AQUA18Elements.Bladder_Cancer, AQUA18Elements.Radical_Cystectomy,3,patientHistoryList)
    )
  }
}
