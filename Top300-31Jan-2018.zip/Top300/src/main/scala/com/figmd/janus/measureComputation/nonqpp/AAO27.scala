package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO27
* Measure Title               :- Tympanostomy Tubes: Resolution of Otitis Media with Effusion in Children
* Measure Description         :- Percentage of patients aged 6 months to 12 years with a diagnosis of otitis media with effusion who are seen 2 to 8 weeks after tympanostomy tube surgery and otitis media with effusion is resolved.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KAJAL_JADHAO_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object AAO27 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO27"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,AAO27Elements.Tympanostomy_Tube_Insertion
      ,AAO27Elements.Otitis_Media_With_Effusion
      ,AAO27Elements.Resolution_Of_Otitis_Media_With_Effusion
      ,AAO27Elements.Patient_Refusal
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------


-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 6, CalenderUnit.MONTH)
        &&  isAgeBelowBeforeStart(visit, m, false, 13, CalenderUnit.YEAR)
        &&isProcedurePerformed(visit,m,AAO27Elements.Tympanostomy_Tube_Insertion,patientHistoryBroadcastList)
        && wasDiagnosisBeforeOrEqualProcedure(visit,m,AAO27Elements.Otitis_Media_With_Effusion,AAO27Elements.Tympanostomy_Tube_Insertion,patientHistoryBroadcastList)
        &&isVisitTypeIn(visit,m
        ,AAO27Elements.Preventive_Care__Established_Office_Visit__0_To_17
        ,AAO27Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
        ,AAO27Elements.Outpatient_Consultation
        ,AAO27Elements.Office_Visit)
        &&(encounterPerformedStartsAfterEndOfProcedure(visit,m,AAO27Elements.Tympanostomy_Tube_Insertion,AdminElements.Encounter_Date,CompareOperator.GREATER_EQUAL, CalenderUnit.WEEK, 2, patientHistoryBroadcastList)
        && encounterPerformedStartsAfterEndOfProcedure(visit,m,AAO27Elements.Tympanostomy_Tube_Insertion,AdminElements.Encounter_Date,CompareOperator.LESS_EQUAL, CalenderUnit.WEEK, 8, patientHistoryBroadcastList))
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients age 6 months to 12 years seen 2 to 8 weeks after surgery with resolution of otitis media with effusion.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      diagnosticStudyPerformedStartsAfterEndOfProcedure(visit,m,AAO27Elements.Tympanostomy_Tube_Insertion,AAO27Elements.Resolution_Of_Otitis_Media_With_Effusion,CompareOperator.GREATER_EQUAL, CalenderUnit.WEEK, 2, patientHistoryBroadcastList)
        && diagnosticStudyPerformedStartsAfterEndOfProcedure(visit,m,AAO27Elements.Tympanostomy_Tube_Insertion,AAO27Elements.Resolution_Of_Otitis_Media_With_Effusion,CompareOperator.LESS_EQUAL, CalenderUnit.WEEK, 8, patientHistoryBroadcastList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patient refusal for follow-up examination.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      isCommunicationFromProvidertoProvider(visit,m,AAO27Elements.Patient_Refusal,patientHistoryBroadcastList)
    )
  }
}