package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp356
* Measure Title              :- Unplanned Hospital Readmission within 30 Days of Principal Procedure
* Measure Description        :- Percentage of patients aged 18 years and older who had an unplanned hospital readmission within 30 days of principal procedure
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp356 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp356"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP356Elements.General_Surgery,
      QPP356Elements.Unplanned_Hospital_Readmission,
      QPP356Elements.Hospital_Readmission_Unplanned,
      QPP356Elements.Hospital_Admission,
      QPP356Elements.Readmission_Not_Met
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //eligible RDD
      val denominatorRDD = ippRDD

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()


      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //Patients aged 18 years and older undergoing a surgical procedure
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
            isPatientAdult(visit,m)
        && isProcedurePerformedDuringEncounter(visit,m,QPP356Elements.General_Surgery)
        &&  isProcedurePerformedWithinXMonths(visit,m,QPP356Elements.General_Surgery,11,patientHistoryBroadcastList)
    )
  }



  //Inpatient readmission to the same hospital for any reason or an outside hospital (if known to the surgeon), within 30 days of the principal surgical procedure
  def getMet(ippRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      (
        isEncounterPerformedOnEncounter(visit,m,QPP356Elements.Unplanned_Hospital_Readmission)
          ||
          (
                  wasEncounterStartsAfterEncounterInXDays(visit,m,QPP356Elements.General_Surgery,QPP356Elements.Hospital_Readmission_Unplanned,30,patientHistoryBroadcastList)
              ||  wasEncounterStartsAfterEncounterInXDays(visit,m,QPP356Elements.General_Surgery,QPP356Elements.Hospital_Admission,30,patientHistoryBroadcastList)
            )
        )
        && !wasEncounterStartsAfterEncounterInXDays(visit,m,QPP356Elements.General_Surgery,QPP356Elements.Readmission_Not_Met,30,patientHistoryBroadcastList)


    )
  }

}
