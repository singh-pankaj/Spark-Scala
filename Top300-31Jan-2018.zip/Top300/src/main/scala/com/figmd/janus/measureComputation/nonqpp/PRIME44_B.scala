package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, CompareOperator, MeasureProperty, PRIME44Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.nonqpp.PRIME44.{isAgeBetween, isMedicationOrdered}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PRIME44_B
* Measure Title               :- Use of Appropriate Medications for Asthma
* Measure Description         :- Percentage of patients 5-64 years of age who were identified as having persistent asthma and were appropriately ordered medication during the measurement period
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- 2
* Measure Stratification      :- 1
* Measure Developer           :- SUMIT.SINGH
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object PRIME44_B extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "PRIME44_B"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      PRIME44Elements.Persistent_Asthma,
      PRIME44Elements.Chronic_Obstructive_Pulmonary_Disease,
      PRIME44Elements.Obstructive_Chronic_Bronchitis,
      PRIME44Elements.Emphysema,
      PRIME44Elements.Cystic_Fibrosis,
      PRIME44Elements.Acute_Respiratory_Failure)


    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients 12-18 years of age with persistent asthma and a visit during the measurement period
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
             isAgeBetween(visit,m,5,CompareOperator.GREATER_EQUAL,65,CompareOperator.LESS,AdminElements.Encounter_Date)
          && isVisitTypeIn(visit,m,
             PRIME44Elements.Preventive_Care__Established_Office_Visit__0_To_17,
             PRIME44Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
             PRIME44Elements.Office_Visit,
             PRIME44Elements.Face_To_Face_Interaction,
             PRIME44Elements.Home_Healthcare_Services,
             PRIME44Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
             PRIME44Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17)
          &&  isDiagnosisOnEncounter(visit,m,PRIME44Elements.Persistent_Asthma)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients with a diagnosis of emphysema, COPD, obstructive chronic bronchitis, cystic fibrosis or acute respiratory failure that overlaps the measurement period
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      (  wasDiagnosedInHistory(visit,m,PRIME44Elements.Chronic_Obstructive_Pulmonary_Disease,patientHistoryBroadcastList)
        || wasDiagnosedInHistory(visit,m,PRIME44Elements.Obstructive_Chronic_Bronchitis,patientHistoryBroadcastList)
        || wasDiagnosedInHistory(visit,m,PRIME44Elements.Emphysema,patientHistoryBroadcastList)
        || wasDiagnosedInHistory(visit,m,PRIME44Elements.Cystic_Fibrosis,patientHistoryBroadcastList)
        || wasDiagnosedInHistory(visit,m,PRIME44Elements.Acute_Respiratory_Failure,patientHistoryBroadcastList)
        )


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients who were ordered at least one prescription for a preferred therapy during the measurement period
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
       isMedicationOrdered(visit,m,patientHistoryBroadcastList,PRIME44Elements.Preferred_Asthma_Therapy)


    )
  }


}