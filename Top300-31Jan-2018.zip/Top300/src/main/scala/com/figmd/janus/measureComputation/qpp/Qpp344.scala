package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 344
* Measure Title              :- Rate of Carotid Artery Stenting (CAS) for Asymptomatic Patients, Without Major
*                               Complications (Discharged to Home by Post-Operative Day #2)
* Measure Description        :- Percent of asymptomatic patients undergoing CAS who are discharged to home
*                               no later than post-operative day #2
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp344 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp344"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD

    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      // Eligible IPP
      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      denominatorRDD.cache()

      val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      notEligibleRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        isProcedurePerformedDuringEncounter(visit, m, QPP344Elements.Asymptomatic_Cas)
    )
  }


  // Denominator Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (
        (
          wasDiagnosisPerformedInXdaysBeforeEncounter(visit, m, QPP344Elements.Asymptomatic_Cas_Date, QPP344Elements.Symptomatic_Carotid_Stenosis, 120, patientHistoryBroadcastList)
            ||
            wasDiagnosisPerformedInXdaysBeforeEncounter(visit, m, QPP344Elements.Asymptomatic_Cas_Date, QPP344Elements.Ipsilateral_Carotid_Territory_Tia_Or_Stroke, 120, patientHistoryBroadcastList)
          )
          ||
          (
            wasDiagnosisPerformedInXdaysWithinEncounter(visit, m, QPP344Elements.Asymptomatic_Cas_Date, QPP344Elements.Other_Carotid_Stenosis, 120, patientHistoryBroadcastList)
              ||
              wasDiagnosisPerformedInXdaysWithinEncounter(visit, m, QPP344Elements.Asymptomatic_Cas_Date, QPP344Elements.Ipsilateral_Tia_Or_Stroke, 120, patientHistoryBroadcastList)
            )
          ||
          (
            wasDiagnosisBeforeOrEqualProcedure(visit, m, QPP344Elements.Contralateral_Carotid_Territory_Tia_Or_Stroke, QPP344Elements.Asymptomatic_Cas, patientHistoryBroadcastList)
              ||
              wasDiagnosisBeforeOrEqualProcedure(visit, m, QPP344Elements.Vertebrobasilar_Tia_Stroke, QPP344Elements.Asymptomatic_Cas, patientHistoryBroadcastList)
            )
        )
    )
  }


  // Numerator Criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        wasPatientDischargedAfterXDaysProcedure(visit, m, QPP344Elements.Discharge_Home, QPP344Elements.Asymptomatic_Cas, 2, patientHistoryBroadcastList)
          ||
          wasPatientDischargedAfterXDaysProcedure(visit, m, QPP344Elements.Discharge_To_Home, QPP344Elements.Asymptomatic_Cas, 2, patientHistoryBroadcastList)
        )
        &&
        !wasProcedurePerformedInXdaysWithinEncounter(visit, m, QPP344Elements.Asymptomatic_Cas_Date, QPP344Elements.Discharge_To_Home_Not_Met, 2, patientHistoryBroadcastList)
    )
  }


}

