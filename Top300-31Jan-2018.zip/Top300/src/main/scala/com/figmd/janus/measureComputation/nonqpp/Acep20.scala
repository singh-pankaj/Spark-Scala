package com.figmd.janus.measureComputation.nonqpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ACEP20Elements, AdminElements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACEP 20
* Measure Title              :- Emergency Medicine: Emergency Department Utilization of CT for Minor Blunt Head Trauma
*                               for Patients Aged 2 Through 17 Years
* Measure Description        :- Percentage of emergency department visits for patients aged 2 through 17 years who
*                               presented with a minor blunt head trauma who had a head CT for trauma ordered by an
*                               emergency care provider who are classified as low risk according to the PECARN
*                               prediction rules for traumatic brain injury
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Lower score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Acep20 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Acep20"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession,initialRDD,
      ACEP20Elements.Non_Penetrating_Head_Trauma,
      ACEP20Elements.Brain_Tumor,
      ACEP20Elements.Coagulopathies,
      ACEP20Elements.Thrombocytopenia,
      ACEP20Elements.Ventricular_Shunt).collect.toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Filter Denominator
      val denominatorRDD = getDenominator(ippRDD)
      denominatorRDD.cache()

      /*  // Filter Not Eligible
    val notEligibleRDD =sparkSession.sparkContext.emptyRDD[CassandraRow]
    notEligibleRDD.cache()*/

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(denominatorRDD, patientHistoryList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMetRdd(intermediateA, patientHistoryList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()
    }

  }

  // IPP criteria
  def getIpp(initialRDD:RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
      isAgeBetween(visit,m, 2, 18)
        &&
        isVisitTypeIn(visit,m, ACEP20Elements.Emergency_Department_Visit,ACEP20Elements.Critical_Care_Evaluation_And_Management)
        &&
        wasDiagnosedBeforeEDOrCCEncounter(visit, m,
          ACEP20Elements.Non_Penetrating_Head_Trauma,
          AdminElements.Emergency_Visit_Departure_Date,
          ACEP20Elements.Critical_Care_Evaluation_And_Management_Date,
          patientHistoryList)
    )
  }

  // Denominator Criteria
  def getDenominator(eligibleRdd: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE,globalStartDate,globalEndDate)
    eligibleRdd.filter(visit =>
      isDiagnosticStudyDuringEDOrCCEncounter(visit, m,
        ACEP20Elements.Head_Ct,
        ACEP20Elements.Head_Ct_Date,
        AdminElements.Emergency_Visit_Arrival_Date,
        AdminElements.Emergency_Visit_Departure_Date,
        ACEP20Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }

  // Denominator Exclusion criteria
  def getExclusionRdd(exclusionRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    exclusionRDD.filter(visit =>
      wasDiagnosedBeforeEDOrCCEncounter(visit, m,
        ACEP20Elements.Brain_Tumor,
        AdminElements.Emergency_Visit_Departure_Date,
        ACEP20Elements.Critical_Care_Evaluation_And_Management_Date,
        patientHistoryList)
        ||
        wasDiagnosedBeforeEDOrCCEncounter(visit, m,
          ACEP20Elements.Coagulopathies,
          AdminElements.Emergency_Visit_Departure_Date,
          ACEP20Elements.Critical_Care_Evaluation_And_Management_Date,
          patientHistoryList)
        ||
        wasDiagnosedBeforeEDOrCCEncounter(visit, m,
          ACEP20Elements.Thrombocytopenia,
          AdminElements.Emergency_Visit_Departure_Date,
          ACEP20Elements.Critical_Care_Evaluation_And_Management_Date,
          patientHistoryList)
        ||
        wasDiagnosedBeforeEDOrCCEncounter(visit, m,
          ACEP20Elements.Ventricular_Shunt,
          AdminElements.Emergency_Visit_Departure_Date,
          ACEP20Elements.Critical_Care_Evaluation_And_Management_Date,
          patientHistoryList)
    )
  }

  // Met criteria
  def getMetRdd(metRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    metRDD.filter(visit =>
      (
        !isGCSResultDuringEDorCCLessThanX(visit, m, ACEP20Elements.Glasgow_Coma_Scale,15,
          AdminElements.Emergency_Visit_Arrival_Date,
          AdminElements.Emergency_Visit_Departure_Date,
          ACEP20Elements.Critical_Care_Evaluation_And_Management_Date)
          &&
          !isSymptomDuringEDOrCCEncounter(visit, m,
            ACEP20Elements.Loss_Of_Consciousness,
            ACEP20Elements.Loss_Of_Consciousness_Date,
            AdminElements.Emergency_Visit_Arrival_Date,
            AdminElements.Emergency_Visit_Departure_Date,
            ACEP20Elements.Critical_Care_Evaluation_And_Management_Date)
          &&
          !isSymptomDuringEDOrCCEncounter(visit, m,
            ACEP20Elements.Physical_Signs_Of_Basilar_Skull_Fracture,
            ACEP20Elements.Physical_Signs_Of_Basilar_Skull_Fracture_Date,
            AdminElements.Emergency_Visit_Arrival_Date,
            AdminElements.Emergency_Visit_Departure_Date,
            ACEP20Elements.Critical_Care_Evaluation_And_Management_Date)
          &&
          !isDiagnosisDuringEDOrCCSeverity(visit,m,
            ACEP20Elements.Headache,
            ACEP20Elements.Headache_Date,
            ACEP20Elements.Severe,
            AdminElements.Emergency_Visit_Arrival_Date,
            AdminElements.Emergency_Visit_Departure_Date,
            ACEP20Elements.Critical_Care_Evaluation_And_Management_Date)
          &&
          !isSymptomDuringEDOrCCEncounter(visit, m,
            ACEP20Elements.Signs_Of_Altered_Mental_Status,
            ACEP20Elements.Signs_Of_Altered_Mental_Status_Date,
            AdminElements.Emergency_Visit_Arrival_Date,
            AdminElements.Emergency_Visit_Departure_Date,
            ACEP20Elements.Critical_Care_Evaluation_And_Management_Date)
          &&
          !isSymptomDuringEDOrCCEncounter(visit, m,
            ACEP20Elements.Vomiting,
            ACEP20Elements.Vomiting_Date,
            AdminElements.Emergency_Visit_Arrival_Date,
            AdminElements.Emergency_Visit_Departure_Date,
            ACEP20Elements.Critical_Care_Evaluation_And_Management_Date)
        )
        &&
        !(
          isVisitTypeIn(visit,m, ACEP20Elements.Emergency_Department_Visit,ACEP20Elements.Critical_Care_Evaluation_And_Management)
            &&
            (
            isEncounterPerformedEDOrCCEncounter(visit,m,ACEP20Elements.Critical_Care_Evaluation_And_Management,ACEP20Elements.Dangerous_Mechanism_Of_Injury)
            ||
            isEncounterPerformedEDOrCCEncounter(visit,m,ACEP20Elements.Critical_Care_Evaluation_And_Management,ACEP20Elements.Dangerous_Mechanism_Of_Injury)
            )
          )
    )
  }
}
