package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP355Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 355
* Measure Title              :- Unplanned Reoperation within the 30 Day Postoperative Period
* Measure Description        :- Percentage of patients aged 18 years and older who had any unplanned reoperation
                                within the 30 day postoperative period.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp355 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp355"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP355Elements.General_Surgery
      , QPP355Elements.Unplanned_Return_To_Operating_Room
      , QPP355Elements.General_Surgery_M
      , QPP355Elements.Unplanned_Return_Not_Met
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      // Filter Exclusions

      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }


  /*----------------------------------------------------------------------------------------------------------------
  * This measure is procedure specific and calculation on active procedure so we have checked only those procedure
   are active ie. ipp checked on encounterdate
  * One months is observation period so are calculating months from backward i.e -1 Month from QuarterEndDate
  ----------------------------------------------------------------------------------------------------------------*/


  /*--------------------------------------------------------------------------------------------------------------------
  Patients aged 18 years and older undergoing an operative procedure.
  --------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isProcedurePerformedDuringEncounter(visit, m, QPP355Elements.General_Surgery)
        && wasProcedurePerformedWithinXMonths(visit, m, QPP355Elements.General_Surgery, 1, patientHistoryBroadcastList)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------
  Unplanned return to the operating room for a surgical procedure, for any reason, within 30 days of the principal
  operative procedure.

  -------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        isProcedurePerformed(visit, m, QPP355Elements.Unplanned_Return_To_Operating_Room, patientHistoryBroadcastList)
          ||
          wasProcedureAfterXProcedureDays(visit, m, QPP355Elements.General_Surgery, QPP355Elements.General_Surgery_Date, 30, patientHistoryBroadcastList, QPP355Elements.General_Surgery_M)
        )
        &&
        !isProcedurePerformed(visit, m, QPP355Elements.Unplanned_Return_Not_Met, patientHistoryBroadcastList)
    )

  }

}
