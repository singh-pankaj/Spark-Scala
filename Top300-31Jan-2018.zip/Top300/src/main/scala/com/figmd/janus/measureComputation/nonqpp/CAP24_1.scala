package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, CAP24Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAP24_1
* Measure Title               :- Cancer Protocol and Turnaround Time for Carcinoma of the Intrahepatic Bile Ducts
* Measure Description         :- Percentage of all eligible carcinoma of the intrahepatic bile ducts specimens:
                                 - Hepatic resection
                                 - Partial hepatic resection
                                 - Total hepatic resection
                                 for which all required data elements of the Cancer Protocol are included
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- None
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.6
----------------------------------------------------------------------------------------------------------------------------*/


object CAP24_1 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "CAP24_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
          , CAP24Elements.Confirm_Intrahepatic_Bile_Duct_Carcinoma_Resection
          , CAP24Elements.Surgical_Pathology_Accession_Number
          , CAP24Elements.Consultation_Catii
          , CAP24Elements.Surgical_Pathology_Accession_Number_Date
          , CAP24Elements.Confirm_Case_Required_Consultation
          , CAP24Elements.Confirm_Case_Required_Consultation_Date
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  All final pathology reports for eligible hepatic resection cases that require the use of a CAP cancer protocol.
  CPT®: 88307 or 88309
  AND
  Any of the ICD 10 codes:
  C22.1: intrahepatic bile duct carcinoma
  C22.0: liver cell carcinoma
  C22.7: other specific carcinoma of liver
  C22.8: malignant neoplasm of liver, primary, unspecified as to type
  C22.9: malignant neoplasm of liver, not specified as primary or secondary
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
        isDiagnosisOverlapsProcedure(visit, m, CAP24Elements.Confirm_Intrahepatic_Bile_Duct_Carcinoma_Resection,
                            CAP24Elements.Surgical_Pathology_Accession_Number, patientHistoryBroadcastList)
      &&
        isProcedurePerformed(visit, m, CAP24Elements.Surgical_Pathology_Accession_Number, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  1.Biopsy procedures
  2.Hepatocellular carcinoma
  3.Hepatoblastoma
  Carcinomas of the perihilar bile ducts
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
          (
              isDiagnosisListDuringProcedure(visit, m, CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Liver_Cell_Carcinoma)
            &&
              isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Biopsy, CAP24Elements.Biopsy_Date,
                              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
          )
        ||
          isDiagnosisListDuringProcedure(visit, m, CAP24Elements.Surgical_Pathology_Accession_Number
                , CAP24Elements.Perihilar_Bile_Ducts_Tumor
                , CAP24Elements.Hepatocellular_Carcinoma
                , CAP24Elements.Hepatoblastoma
                , CAP24Elements.Cholangiocarcinoma
                , CAP24Elements.Angiosarcoma_Of_Liver
                , CAP24Elements.Other_Sarcomas_Of_Liver
                , CAP24Elements.Malignant_Neoplasm_Of_Extrahepatic_Bile_Duct_Gp
                , CAP24Elements.Secondary_Malignant_Neoplasm_Of_Liver_And_Intrahepatic_Bile_Duct
                , CAP24Elements.Hepatocellular_Carcinoma_Kw
               )
        ||
          isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Biopsy, CAP24Elements.Biopsy_Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
        ||
          isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Biopsy_Or_Carcinoma__Hepatoblastoma_, CAP24Elements.Biopsy_Or_Carcinoma__Hepatoblastoma__Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  All eligible cases containing all of the required elements found in the current CAP Intrahepatic Bile Ducts protocol. Optional data (marked with a “+” in the CAP cancer protocol) is not required but may be present.
  The current protocol, the required elements include:
  - Procedure
  - Tumor Size
  - Tumor Focality
  - Histologic Type
  - Histologic Grade
  - Tumor Extension
  - Margins
  - Lymphovascular Invasion
  - Regional Lymph Nodes
  - Pathologic Stage Classification (pTNM, AJCC 8th Edition)
  * If an item is not applicable, an “N/A” listing is required.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
        (
            isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Procedure_Documented, CAP24Elements.Procedure_Documented_Date,
                      CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
          &&
            isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Tumor_Size_Documented, CAP24Elements.Tumor_Size_Documented_Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
          &&
            isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Histologic_Type_Documented, CAP24Elements.Histologic_Type_Documented_Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
          &&
            isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Histologic_Grade_Documented, CAP24Elements.Histologic_Grade_Documented_Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
          &&
            isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Tumor_Extension_Documented, CAP24Elements.Tumor_Extension_Documented_Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
          &&
            isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Procedure_Documented, CAP24Elements.Procedure_Documented_Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
          &&
            isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Margins_Documented, CAP24Elements.Margins_Documented_Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
          &&
            isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Lymphovascular_Invasion_Documented, CAP24Elements.Lymphovascular_Invasion_Documented_Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
          &&
            isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Regional_Lymph_Nodes_Documented, CAP24Elements.Regional_Lymph_Nodes_Documented_Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
          &&
            isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Pathologic_Stage_Classification_Documented, CAP24Elements.Pathologic_Stage_Classification_Documented_Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
          &&
            isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Tumor_Focality, CAP24Elements.Tumor_Focality_Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
        )
        ||
            isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Cancer_Intrahepatic_Bile_Duct_Protocol, CAP24Elements.Cancer_Intrahepatic_Bile_Duct_Protocol_Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
      )
      && !
            isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Intrahepatic_Protocol_Not_Met, CAP24Elements.Intrahepatic_Protocol_Not_Met_Date,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Cases requiring intra-departmental or extra-departmental consultation.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
          isCommunicationFromProvidertoProvider(visit, m, CAP24Elements.Consultation_Catii, patientHistoryBroadcastList)
        ||
          isCommunicationFromProviderToProviderDuringProcedure(visit, m,
              CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date,
              CAP24Elements.Confirm_Case_Required_Consultation, CAP24Elements.Confirm_Case_Required_Consultation_Date,
              patientHistoryBroadcastList)
    )
  }


}