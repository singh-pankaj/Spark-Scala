package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, IRIS4Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- IRIS 4
* Measure Title              :- Glaucoma – Intraocular Pressure Reduction Following Laser Trabeculoplasty
* Measure Description        :- Percentage of patients who underwent laser trabeculoplasty who had IOP reduced by 20%
                                from their pretreatment level or had a reduction in overall number of glaucoma medications.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/



object  IRIS4  extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "IRIS4"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patienthistory = getPatientHistory(sparkSession, initialRDD
      , IRIS4Elements.Laser_Trabeculoplasty
      , IRIS4Elements.Intraocular_Pressure__Iop_
      , IRIS4Elements.Glaucoma_Medications
      , IRIS4Elements.Laser_Trabeculoplasty___Eye
      , IRIS4Elements.Glaucoma_Medication_Eye
      , IRIS4Elements.Glaucoma_Medications
      , IRIS4Elements.Reduction_Glaucoma_Medications__Eye
      , IRIS4Elements.Absolute_Glaucoma_Blindness
      , IRIS4Elements.Absolute_Glaucoma_Blindness_Eye
      , IRIS4Elements.Visual_Acuity_Findings
      , IRIS4Elements.Visual_Acuity_Findings__Eye
      , IRIS4Elements.Reduction_In_Overall_Number_Of_Glaucoma_Medications

    ).collect().toList

    val patientHistory: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistory)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistory)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(ippRDD, patientHistory)

      // Filter Intermediate
      val intermediateExclusion = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateExclusion.cache()

      // Filter Met
      val metRDD = getMet(intermediateExclusion, patientHistory)
      metRDD.cache()

      val notMetRDD = getSubtractRDD(intermediateExclusion, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistory.destroy()
    }
  }


  /*--------------------------------------------------------------------------------------------------------------------
  All patients seen for evaluation of primary headache
  --------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow],patientHistory:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
          isAgeAbove(visit,m,true,40)
      &&  isAgeBelow(visit,m,true,86)
      && (
            isPhysicalExamPerformedBeforeSurgery(visit,m,IRIS4Elements.Laser_Trabeculoplasty,patientHistory,IRIS4Elements.Intraocular_Pressure__Iop_)
      ||    (
                  wasMedicationActiveBeforeOrEqualEncounter(visit,m,IRIS4Elements.Glaucoma_Medications,patientHistory)
              &&  checkEyeElementBeforeDiagnosisEyesElement(visit,m,IRIS4Elements.Laser_Trabeculoplasty___Eye,patientHistory,IRIS4Elements.Glaucoma_Medication_Eye)
              )
          )
      &&  isProcedurePerformedDuringEncounter(visit,m,IRIS4Elements.Laser_Trabeculoplasty)
      &&  (

                wasPhysicalExamPerformedAfterEncounterBetweenXPeriodes(visit,m,IRIS4Elements.Intraocular_Pressure__Iop_,CalenderUnit.MONTH,2,CalenderUnit.MONTH,4,patientHistory)


         ||   (
                   wasMedicationAfterEncounterBetweenXPeriodes(visit,m,IRIS4Elements.Glaucoma_Medications,CalenderUnit.MONTH,2,CalenderUnit.MONTH,4,patientHistory)
                &&  checkEyeElementAfterEncounterEyeElementBetweenXPeriods(visit,m,IRIS4Elements.Laser_Trabeculoplasty___Eye,CalenderUnit.MONTH,2,CalenderUnit.MONTH,4,patientHistory,IRIS4Elements.Reduction_Glaucoma_Medications__Eye)
            )
         )
    )

  }

  /*-------------------------------------------------------------------------------------------------------------------
Documentation of patients with primary headache diagnosis and imaging other than CT or MRI obtained
Documentation of System reason(s) for obtaining imaging of the head (CT or MRI)
(i.e., needed as part of a clinical trial; other clinician ordered the study)
-------------------------------------------------------------------------------------------------------------------*/

  def getExclusion(ippRDD: RDD[CassandraRow],patientHistory:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
        (
                wasDiagnosedBeforeOrEqualEncounter(visit,m,IRIS4Elements.Absolute_Glaucoma_Blindness,patientHistory)
            &&  checkEyeElementBeforeDiagnosisEyesElement(visit,m,IRIS4Elements.Laser_Trabeculoplasty___Eye,patientHistory,IRIS4Elements.Absolute_Glaucoma_Blindness_Eye)
        )
      ||
          (
                  isPhysicalExamPerformedBeforeSurgery(visit,m,IRIS4Elements.Laser_Trabeculoplasty,patientHistory,IRIS4Elements.Visual_Acuity_Findings)
              &&  checkEyeElementBeforeDiagnosisEyesElement(visit,m,IRIS4Elements.Laser_Trabeculoplasty___Eye,patientHistory,IRIS4Elements.Visual_Acuity_Findings__Eye)
            )
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
   Patients for whom imaging of the head (Computed Tomography (CT) or Magnetic Resonance Imaging (MRI)) is obtained for
   the evaluation of primary headache when clinical indications are not present
   -------------------------------------------------------------------------------------------------------------------*/


  def getMet(intermediateA: RDD[CassandraRow],patientHistory:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      wasPhysicalExamPerformedBeforeAndAfterEncounter
      (visit,m,IRIS4Elements.Laser_Trabeculoplasty,IRIS4Elements.Intraocular_Pressure__Iop_
        ,CalenderUnit.MONTH,2,CalenderUnit.MONTH,4,20,patientHistory)
     ||
      (
        wasAssessmentDoneAfterProcedure(visit,m,IRIS4Elements.Laser_Trabeculoplasty,patientHistory,IRIS4Elements.Reduction_In_Overall_Number_Of_Glaucoma_Medications)
     && checkEyeElementBeforeDiagnosisEyesElement(visit,m,IRIS4Elements.Laser_Trabeculoplasty___Eye,patientHistory,IRIS4Elements.Reduction_Glaucoma_Medications__Eye)
        )
    )
  }



}
