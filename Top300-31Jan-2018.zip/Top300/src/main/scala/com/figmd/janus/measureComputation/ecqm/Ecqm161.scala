package com.figmd.janus.measureComputation.ecqm


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.measureComputation.qpp.Qpp1.getPatientHistory
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ECQM 161
* Measure Title              :- Adult Major Depressive Disorder (MDD): Suicide Risk Assessment
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of major depressive disorder (MDD) with a suicide risk assessment completed during the visit in which a new diagnosis or recurrent episode was identified
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- NA
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm161 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "ECQM161"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {


    var getPatientHistoryList = getPatientHistory(sparkSession, rdd, ECQM161V7Elements.Major_Depressive_Disorder_Active)
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(rdd, patientHistoryList)
    ippRDD.cache()

    val metRDD = getMet(ippRDD)
    metRDD.cache()
    // Filter Met


    val notMetRDD = getSubtractRDD(ippRDD, metRDD)
    notMetRDD.cache()

    val notEligible = sparkSession.sparkContext.emptyRDD[CassandraRow]
    val exclusionRdd = sparkSession.sparkContext.emptyRDD[CassandraRow]
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    saveToWebDM(rdd, ippRDD, notEligible, exclusionRdd, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }


  /* All patients aged 18 years and older with a diagnosis of major depressive disorder (MDD) */

  def getIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    var m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isAgeAbove(visit, m, true, 17)
        && isVisitTypeIn(visit, m, ECQM161V7Elements.Psych_Visit___Diagnostic_Evaluation,
        ECQM161V7Elements.Psych_Visit___Psychotherapy,
        ECQM161V7Elements.Emergency_Department_Visit,
        ECQM161V7Elements.Office_Visit,
        ECQM161V7Elements.Outpatient_Consultation,
        ECQM161V7Elements.Psychoanalysis
      )
        && !wasCurrentElementDiagnosisPreviouslyDiagniosedWithinXDays(visit, m, ECQM161V7Elements.Major_Depressive_Disorder_Active, 105, patientHistoryList)
    )
  }

  /* Patients with a suicide risk assessment completed during the visit in which a new diagnosis or recurrent episode was identified  */

  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    var m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit => isInterventionPerformedOnEncounter(visit, m, ECQM161V7Elements.Suicide_Risk_Assessment)

    )
  }


}