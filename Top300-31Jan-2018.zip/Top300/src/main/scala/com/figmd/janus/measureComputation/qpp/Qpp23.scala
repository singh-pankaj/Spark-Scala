package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP23Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 23
* Measure Title              :- Perioperative Care: Venous Thromboembolism (VTE) Prophylaxis (When Indicated in ALL Patients)
* Measure Description        :- Percentage of surgical patients aged 18 years and older undergoing procedures for which
*                               venous thromboembolism (VTE) prophylaxis is indicated in all patients, who had an order
*                               for Low Molecular Weight Heparin(LMWH), Low- Dose Unfractionated Heparin(LDUH),
*                               adjusted-dose warfarin, fondaparinux or mechanical prophylaxis to be given within 24 hours
*                               prior to incision time or within 24 hours after surgery end time.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp23 extends MeasureUtilityUpdate with MeasureUpdate  {

  val MEASURE_NAME = "Qpp23"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {



    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //getPatientHistoryList
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        QPP23Elements.Vte_Prophylaxis,
        QPP23Elements.Vte_Indications_For_Surgery,
        QPP23Elements.Vte_Prophylaxis_Medical_Reason
      ).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      // Filter Exceptions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate B
      val intermediateB = getSubtractRDD(denominatorRDD, metRDD)
      intermediateB.cache()

      // Filter Denominator Exception
      val exceptionRDD = getException(intermediateB, patientHistoryBroadcastList)
      exceptionRDD.cache()

      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /*-------------------------------------------------------------------------------------------------------------------
   	All surgical patients aged 18 years and older undergoing procedures for which VTE prophylaxisis indicated in all patients
  -------------------------------------------------------------------------------------------------------------------*/
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    rdd.filter(visit =>
      isPatientAdult(visit, m)
        &&
        (
          isProcedurePerformedDuringEncounter(visit, m, QPP23Elements.Vte_Indications_For_Surgery)
            ||
            isProcedurePerformedDuringEncounter(visit, m, QPP23Elements.Vte_Indications_For_Surgery_M)
          )
    )
  }

  // Numerator criteria

  /*-------------------------------------------------------------------------------------------------------------------
  Surgical patients who had an order for LMWH, LDUH, adjusted-dose warfarin, fondaparinux or mechanical prophylaxis to
  be given within 24 hours prior to incision time or within 24 hours after surgery end time
-------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      (isAssessmentPerformedDuringEncounter(visit, m,QPP23Elements.Documentation_For_Vte_Prophylaxis)
        ||
        (
          wasMedicationBeforeXhrOfProcedure(visit,m,QPP23Elements.Vte_Indications_For_Surgery,QPP23Elements.Vte_Prophylaxis,24,patientHistoryList)
            ||
          wasMedicationAfterXhrOfProcedure(visit,m,QPP23Elements.Vte_Indications_For_Surgery,QPP23Elements.Vte_Prophylaxis,24,patientHistoryList)
          )
        ||
        isProcedurePerformedDuringEncounter(visit, m, QPP23Elements.Mechanical_Prophylaxis)
        )
        &&
        !(isAssessmentPerformedDuringEncounter(visit, m, QPP23Elements.Vte_Reason_Not_Specified)
          ||
          (
            isProcedurePerformedDuringEncounter(visit, m, QPP23Elements.Ted_Hose)
              &&
            isProcedurePerformedDuringEncounter(visit,m,QPP23Elements.Mechanical_Prophylaxis)
          )
        )
    )

  }

  // Denominator Exception criteria
  /*-------------------------------------------------------------------------------------------------------------------
  Documentation of medical reason(s) for patient not receiving any form of VTE prophylaxis (LMWH, LDUH, adjusted-dose
  warfarin, fondaparinux or mechanical prophylaxis) within 24 hours prior to incision time or 24 hours after surgery end time
-------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateB: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    var m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)
    intermediateB.filter(visit =>
      isAssessmentPerformedDuringEncounter(visit, m,QPP23Elements.Vte_Prophylaxis_Medical_Reason)
        ||
        (wasMedicationBeforeXhrOfProcedure(visit,m,QPP23Elements.Vte_Indications_For_Surgery,QPP23Elements.Vte_Prophylaxis_Medical_Reason,24,patientHistoryList)
        ||
        wasMedicationAfterXhrOfProcedure(visit,m,QPP23Elements.Vte_Indications_For_Surgery,QPP23Elements.Vte_Prophylaxis_Medical_Reason,24,patientHistoryList))
    )

  }


}
