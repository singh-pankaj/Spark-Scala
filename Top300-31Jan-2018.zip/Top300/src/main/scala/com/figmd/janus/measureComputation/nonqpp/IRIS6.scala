package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{IRIS16Elements, MeasureProperty, _}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- IRIS 6
* Measure Title              :- Acquired Involutional Entropion - Normalized Lid Position After Surgical Repair
* Measure Description        :- Percentage of surgical entropion patients with postoperative normalized lid position
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object IRIS6 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "IRIS6"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      IRIS6Elements.Entropion_Surgery,
      IRIS6Elements.Involutional_Entropion,
      IRIS6Elements.Entropion_Surgery__Eye,
      IRIS6Elements.Normalized_Lid_Position__Eye

    ).collect().toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    val patineHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      IRIS6Elements.Entropion_Surgery,
      IRIS6Elements.Involutional_Entropion,
      IRIS6Elements.Entropion_Surgery__Eye,
      IRIS6Elements.Normalized_Lid_Position__Eye
    )

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()


      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patineHistoryRDD, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }
  }

  //All patients aged 18 years or older with a diagnosis of involutional entropion who underwent a surgical procedure for the condition
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
                            isPatientAdult (visit, m)
                        && isProcedurePerformedDuringEncounter(visit,m,IRIS6Elements.Entropion_Surgery)
                        && isDiagnosisPerformedDuringProcedurePerformed(visit,m,IRIS6Elements.Involutional_Entropion,IRIS6Elements.Involutional_Entropion_Date,IRIS6Elements.Entropion_Surgery,IRIS6Elements.Entropion_Surgery_Date)
                        && isDiagnosisPerformedWasConcurrentWith(visit,m,IRIS6Elements.Involutional_Entropion__Eye,IRIS6Elements.Involutional_Entropion,patientHistoryList)
                        && isProcedurePerformedXDaysBeforeEnd(visit, m, IRIS6Elements.Entropion_Surgery,90)
                        && checkEyeOnEncounterEqualsWithOtherEye(visit, m,true,IRIS6Elements.Entropion_Surgery__Eye,patientHistoryList,Seq(IRIS6Elements.Involutional_Entropion__Eye,IRIS6Elements.Entropion_Surgery__Eye))


                    )
  }

  //Patients with normalized lid position postoperatively within 90 days following surgery
  def getMet(intermediateA: RDD[CassandraRow],patineHistoryRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
                                      wasProcedurePerformedStartsXDaysAfterEndOfProcedure(visit, m,IRIS6Elements.Normalized_Lid_Position,IRIS6Elements.Entropion_Surgery,90, patientHistoryList)
                                  &&  checkEyeOnEncounterEqualsWithOtherEye(visit, m,true,IRIS6Elements.Normalized_Lid_Position__Eye,patientHistoryList,Seq(IRIS6Elements.Involutional_Entropion__Eye,IRIS6Elements.Entropion_Surgery__Eye))
                              )



  }
}