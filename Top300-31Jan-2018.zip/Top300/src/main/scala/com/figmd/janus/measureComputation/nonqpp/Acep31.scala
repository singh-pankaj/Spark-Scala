package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.{Measure, MeasureUpdate}
import com.figmd.janus.measureComputation.master.{ACEP31Elements, AdminElements, MeasureProperty}
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACEP 31
* Measure Title              :- Emergency Medicine: Appropriate Foley Catheter Use in the Emergency Department
* Measure Description        :- Percentage of emergency department (ED) visits for admitted patients aged 18 years and
*                               older where an indwelling Foley catheter is ordered and the patient had at least one indication for an indwelling Foley catheter
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/
object Acep31 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Acep31"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd)
    ippRDD.cache()

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, ippRDD, ACEP31Elements.Insertion_Of_Indwelling_Foley_Catheter, ACEP31Elements.Indwelling_Foley_Catheter).collect.toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    // Filter Exclusion
    val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA)
    metRDD.cache()

    val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA, metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, noteligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }


  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
           isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m, ACEP31Elements.Critical_Care_Evaluation_And_Management, ACEP31Elements.Emergency_Department_Visit)
        && isProcedureOrderDuringEDOrCCEncounter(visit, m, ACEP31Elements.Insertion_Of_Indwelling_Foley_Catheter, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP31Elements.Critical_Care_Evaluation_And_Management_Date)
        && isEncounterOrderDuringEDOrCCEncounter(visit, m, ACEP31Elements.Hospital_Admission_Or_Observation, ACEP31Elements.Hospital_Admission_Or_Observation_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP31Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }

  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit => (
                     wasProcedurePerformedInHistory(visit, m, AdminElements.Encounter_Date, patientHistoryList, ACEP31Elements.Insertion_Of_Indwelling_Foley_Catheter)
                  || wasDeviceAppliedInHistory(visit, m, ACEP31Elements.Indwelling_Foley_Catheter, patientHistoryList))
                 )
  }

  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      isProcedureOrderWithReasonDuringEDOrCCEncounter(visit, m, ACEP31Elements.Insertion_Of_Indwelling_Foley_Catheter_Date,
            AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP31Elements.Critical_Care_Evaluation_And_Management_Date,
            ACEP31Elements.Urinary_Retention__Obstruction,
            ACEP31Elements.Measurement_Of_Urinary_Output,
            ACEP31Elements.Preoperative_Use_For_Selected_Surgical_Procedures,
            ACEP31Elements.Open_Sacral_Wounds__Perineal_Wounds,
            ACEP31Elements.Immobilization,
            ACEP31Elements.Comfort_Measures,
            ACEP31Elements.Institution_Specific_Indication
        )
    )
  }

}







