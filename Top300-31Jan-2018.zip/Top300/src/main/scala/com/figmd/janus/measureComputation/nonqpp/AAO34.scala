package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty,AAO34Elements,CalenderUnit,TimeOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO34
* Measure Title               :- Postoperative Laryngeal Examination for Dysphonia
* Measure Description         :- Percentage of patients age 18 years and older who were diagnosed with dysphonia within 2 months after a thyroidectomy who received or were referred for laryngeal examination to examine vocal fold/cord mobility.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KIRTI_RAUT_FIGMD_COM
* Initial GIT Version/Tag(CRA):-1.8
* Latest GIT Version/Tag(CRA) :-1.8
----------------------------------------------------------------------------------------------------------------------------*/

object AAO34 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "AAO34"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      AAO34Elements.Thyroidectomy,
      AAO34Elements.Dysphonia,
      AAO34Elements.Thyroidectomy,
      AAO34Elements.Laryngeal_Examination
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients 18 years and older diagnosed with dysphonia within 2 months after a thyroidectomy.
•Dysphonia: A clinical disorder characterized by harsh and raspy voice arising from or spreading to the larynx.
For the purposes of this measure, dysphonia is referring to a change or hoarseness in the patient’s voice.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
                        isAgeAbove(visit,m,true,18)
                  &&    isVisitTypeIn(visit,m,
                            AAO34Elements.Inpatient_Consultation,
                            AAO34Elements.Discharge_Services___Hospital_Inpatient,
                            AAO34Elements.Subsequent_Hospital_Care,
                            AAO34Elements.Hospital_Inpatient_Visit___Initial,
                            AAO34Elements.Discharge_Services__Observation_Care,
                            AAO34Elements.Subsequent_Observation_Care,
                            AAO34Elements.Hospital_Observation_Care___Initial,
                            AAO34Elements.Office_Consultation,
                            AAO34Elements.Office_Visit,
                            AAO34Elements.Office_Or_Other_Outpatient_Visit,
                            AAO34Elements.Nursing_Facility_Visit
                        )
                  &&
                        isProcedurePerformed(visit,m,AAO34Elements.Thyroidectomy,patientHistoryBroadcastList)
                  &&
                        wasDiagnosisStartsAfterStartOfInXPeriod(visit,m,AAO34Elements.Thyroidectomy,CalenderUnit.MONTH,2,TimeOperator.AFTER,patientHistoryBroadcastList,AAO34Elements.Thyroidectomy)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
•	Patients diagnosed with dysphonia or vocal fold paralysis prior to thyroidectomy;
•	Patients undergoing concurrent laryngectomy.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
                                (   wasDiagnosisStartsBeforeStartOfProcedure(visit,m,AAO34Elements.Dysphonia,patienthistoryList,AAO34Elements.Laryngectomy)
                                 || wasDiagnosisStartsBeforeStartOfProcedure(visit,m,AAO34Elements.Vocal_Fold_Paralysis,patienthistoryList,AAO34Elements.Laryngectomy)
                                 )
                                  ||
                                  isProcedurePerformedDuringProcedure(visit,m,AAO34Elements.Laryngectomy,AAO34Elements.Laryngectomy_Date,AAO34Elements.Thyroidectomy,AAO34Elements.Thyroidectomy_Date)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who received or were referred for laryngeal examination to examine vocal fold/cord mobility.
Laryngeal examination to examine vocal fold/cord mobility: Examination by a qualified physician or clinician using
flexible laryngoscopy or stroboscopy.
-----------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateForMet: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
                                    isDiagnosticStudyPerformed(visit,m,AAO34Elements.Laryngeal_Examination,patienthistoryList)
                                ||  isDiagnosticStudyRecommended(visit,m,AAO34Elements.Laryngeal_Examination,patienthistoryList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patient exception for not receiving or being referred for a laryngoscopic examination to
examine vocal fold/cord mobility (e.g. patient refuses the laryngeal examination).
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
                                   isDiagnosticStudPerformedNotDonePatientReasonRefused(visit,m,AAO34Elements.Laryngeal_Examination,patienthistoryList)
                               ||  isDiagnosticStudyRecommendedNotDonePatientReasonRefused(visit,m,AAO34Elements.Laryngeal_Examination,patienthistoryList)

    )
  }
}