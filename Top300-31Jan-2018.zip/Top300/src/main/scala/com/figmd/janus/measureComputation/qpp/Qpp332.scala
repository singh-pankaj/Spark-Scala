
package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP332Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 332
* Measure Title              :- Adult Sinusitis: Appropriate Choice of Antibiotic: Amoxicillin With or Without Clavulanate Prescribed for Patients with Acute Bacterial Sinusitis (Appropriate Use)
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of acute bacterial sinusitis that were prescribed amoxicillin, with or without clavulanate, as a first line antibiotic at the time of diagnosis.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp332 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp332"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD, QPP332Elements.Acute_Sinusitis, QPP332Elements.Acute_Bacterial_Sinusitis1, QPP332Elements.Antibiotic_Regimen,
      QPP332Elements.Acute_Bacterial_Sinusitis_Grp, QPP332Elements.Antibiotic_Regimen_Grp).collect.toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //eligible RDD
      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      val metRDD = getMet(intermediateA)
      metRDD.cache()

      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      val exceptionRDD = getException(intermediateB)
      exceptionRDD.cache()

      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  //----------------IIPP-Denominator criteria-----------------------//
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
        isAgeAbove(visit, m, true, 18)
          && isVisitTypeIn(visit, m, QPP332Elements.Office_Visit,
          QPP332Elements.Emergency_Department_Visit,
          QPP332Elements.Home_Healthcare_Services,
          QPP332Elements.Care_Services_In_Long_Term_Residential_Facility_Gp)
          &&
          (
            (isDiagnosis(visit, m, QPP332Elements.Acute_Sinusitis, patientHistoryBroadcastList)
              &&
              isDiagnosis(visit, m, QPP332Elements.Acute_Bacterial_Sinusitis1, patientHistoryBroadcastList)
              &&
              isMedicationOrdered(visit, m, patientHistoryBroadcastList, QPP332Elements.Antibiotic_Regimen)
              )
              ||
              (
                isDiagnosis(visit, m, QPP332Elements.Acute_Sinusitis, patientHistoryBroadcastList)
                  &&
                  isDiagnosis(visit, m, QPP332Elements.Acute_Bacterial_Sinusitis_Grp, patientHistoryBroadcastList)
                  &&
                  isMedicationOrdered(visit, m, patientHistoryBroadcastList, QPP332Elements.Antibiotic_Regimen_Grp)
                )
            )
          &&
          !isTeleHealthModifier(visit, m, QPP332Elements.Office_Visit,
            QPP332Elements.Home_Healthcare_Services,
            QPP332Elements.Nursing_Facility_Visit_Telehealth_Modifier,
            QPP332Elements.Emergency_Department_Visit,
            QPP332Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier)
          &&
          isPOSEncounterNotPerformed(visit, m, QPP332Elements.Pos_02)
    )

  }

  //---------------- Numerator criteria------------------------------------//
  def getMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (
        isMedicationOrderedDuringEncounter(visit, m, QPP332Elements.Amoxicillin_With_Or_Without_Clavulanate1)
          || isMedicationOrderedDuringEncounter(visit, m, QPP332Elements.Amoxicillin_With_Or_Without_Clavulanate)
        ) && isMedicationOrderedDuringEncounter(visit, m, QPP332Elements.Amoxicillin_Clauvanate_Reason_Not_Specified)
    )
  }


  //------------------Denominator Exception criteria-----------------------//

  def getException(internediateB: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    internediateB.filter(visit =>
      (
        isMedicationOrderedDuringEncounter(visit, m, QPP332Elements.Amoxicillin_With_Or_Without_Clavulanate_Medical_Reason)
          ||
          (isMedicationOrderedDuringEncounter(visit, m, QPP332Elements.Amoxicillin_Medical_Reason)
            ||
            (
              isDiagnosedDuringEncounter(visit, m, QPP332Elements.Chronic_Sinusitis,
                QPP332Elements.Cystic_Fibrosis,
                QPP332Elements.Immune_Deficiency,
                QPP332Elements.Ciliary_Dyskinesia,
                QPP332Elements.Deviated_Nasal_Septum,
                QPP332Elements.Presence_Of_Resistant_Microorganisms,
                QPP332Elements.Immotile_Cilia_Disorders)
                ||
                isProcedurePerformedDuringEncounter(visit, m, QPP332Elements.Sinus_Surgery)
                ||
                isMedicationAllergyDuringEncounter(visit, m, QPP332Elements.Allergy_To_Medication)
              )
            )
        )
    )
  }

}