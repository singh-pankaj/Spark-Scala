package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, IRIS10Elements,CompareOperator}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- IRIS 10
* Measure Title              :- Exudative Age-Related Macular Degeneration - Loss of Visual Acuity
* Measure Description        :- Percentage of patients with a diagnosis of exudative age-related macular degeneration,
                                being treated with anti-VEGF agents, with a loss of less than 3 Snellen lines (which is
                                equivalent to less than 0.3 logMAR) of visual acuity within the past 12 months.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 1
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS10_1 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "IRIS10_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , IRIS10Elements.Intravitreal_Injection
      , IRIS10Elements.Anti_Vegf_Agents
      , IRIS10Elements.Visual_Acuity
      , IRIS10Elements.Exudative_Age_Related_Macular_Degeneration
      , IRIS10Elements.Loss_Of_Visual_Acuity
    )

    val leastRecentElementList = sparkSession.sparkContext.broadcast(leastRecentPatientList(patientHistoryRDD, IRIS10Elements.Visual_Acuity))

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val Correct_VA_Values: Array[String] = Array("20/10", "20/11", "20/12", "20/13", "20/14", "20/15", "20/16", "20/17", "20/18", "20/19", "20/2", "20/20", "20/21", "20/22", "20/23", "20/24", "20/25", "20/26", "20/28", "20/29", "20/3", "20/30", "20/31", "20/32", "20/33", "20/34", "20/35", "20/36", "20/37", "20/38", "20/39", "20/4", "20/5", "20/6", "20/7", "20/8", "20/9", "20/40")
    // Filter IPP
    val ippRDD = getIpp(sparkSession, initialRDD, patientHistoryRDD, patientHistoryList, leastRecentElementList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryList)
      // metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
      leastRecentElementList.destroy()

    }
  }


  /*------------------------------------------------------------------------------------------------
    Patients undergoing SWL followed by ipsilateral SWL within 6 months
 ------------------------------------------------------------------------------------------------*/

  def getIpp(sparkSession: SparkSession,initialRDD: RDD[CassandraRow],patientHistoryRDD :RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]],leastRecentElementList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    val firstTreatmentList =  sparkSession.sparkContext.broadcast(getHistoryOnMinDateOfElement(patientHistoryRDD, m, IRIS10Elements.Intravitreal_Injection ))
    val latestTreatmentList =  sparkSession.sparkContext.broadcast(getHistoryMostRecentDateOfElement(patientHistoryRDD, m, IRIS10Elements.Intravitreal_Injection ))
    val treatment=countElementEqualTwoDate(patientHistoryList,IRIS10Elements.Intravitreal_Injection,IRIS10Elements.Anti_Vegf_Agents)

    initialRDD.filter(visit =>
          wasAgeonFirstDate(visit,m,IRIS10Elements.Visual_Acuity,50,CompareOperator.GREATER_EQUAL,patientHistoryList)
      &&  wasDiagnosedInHistory(visit,m,IRIS10Elements.Exudative_Age_Related_Macular_Degeneration,patientHistoryList)
      && wasPhysicalExamPresentBeforeFirstAndAfterMostElementInHistory(visit,m,IRIS10Elements.Visual_Acuity,patientHistoryList,firstTreatmentList,latestTreatmentList)
      && getEncounterCountFromHistory(visit,m,5,true,treatment)
    )
  }


  /*------------------------------------------------------------------------------------------------
  Patients undergoing SWL on the ipsilateral side within 6 months
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRdd.filter(visit =>
      isPhysicalExamPerformedValue(visit,m,IRIS10Elements.Loss_Of_Visual_Acuity,0.3,CompareOperator.GREATER,patientHistoryList)
    )
  }

}
