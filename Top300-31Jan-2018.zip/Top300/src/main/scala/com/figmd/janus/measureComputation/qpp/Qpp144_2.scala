package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 144
* Measure Title              :- Oncology: Medical and Radiation – Plan of Care for Moderate to Severe Pain
* Measure Description        :- Percentage of patients, regardless of age, with a diagnosis of cancer currently receiving chemotherapy or radiation therapy
                                who report having moderate to severe pain with a plan of care to address pain documented on or before the date of the second visit with a clinician.
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 2
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp144_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp144_2"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD, QPP144Elements.Cancer)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Met
      val metRDD = getMet(ippRDD)
      metRDD.cache()
      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

/*-------------------------------------------------------------------------------------------------------------------------
SUBMISSION CRITERIA 2: All patients, regardless of age, with a diagnosis of cancer currently receiving radiation therapy
----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(rdd:RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
            wasDiagnosedInHistory(visit,m,QPP144Elements.Cancer,patientHistoryBroadcastList)
        &&  isProcedurePerformedDuringEncounter(visit,m,QPP144Elements.Radiation_Therapy)
        &&  (    isAssessmentPerformedDuringEncounter(visit,m,QPP144Elements.Pain_Screened_As_Moderate_To_Severe)
              || isAssessmentPerformedDuringEncounter(visit,m,QPP144Elements.Pain_Moderate_Severe_Screening)
              ||  (   isInterVentionPerformedValueDuringEncounter(visit,m,QPP144Elements.Nr_Scale_Moderate,4,CompareOperator.GREATER_EQUAL)
                   && isInterVentionPerformedValueDuringEncounter(visit,m,QPP144Elements.Nr_Scale_Moderate,6,CompareOperator.LESS_EQUAL)
                 )
              ||  (   isInterVentionPerformedValueDuringEncounter(visit,m,QPP144Elements.Fpr_Scale_Moderate,4,CompareOperator.GREATER_EQUAL)
                   && isInterVentionPerformedValueDuringEncounter(visit,m,QPP144Elements.Fpr_Scale_Moderate,6,CompareOperator.LESS_EQUAL)
                  )
              ||  (   isInterVentionPerformedValueDuringEncounter(visit,m,QPP144Elements.Nr_Scale_Severe,7,CompareOperator.GREATER_EQUAL)
                   && isInterVentionPerformedValueDuringEncounter(visit,m,QPP144Elements.Nr_Scale_Severe,10,CompareOperator.LESS_EQUAL)
                  )
              ||  (   isInterVentionPerformedValueDuringEncounter(visit,m,QPP144Elements.Fpr_Scale_Severe,7,CompareOperator.GREATER_EQUAL)
                   && isInterVentionPerformedValueDuringEncounter(visit,m,QPP144Elements.Fpr_Scale_Severe,10,CompareOperator.LESS_EQUAL)
                  )
            )
    )
  }


/*-------------------------------------------------------------------------------------------------------------------------
SUBMISSION CRITERIA 2: Patients for whom a plan of care to address moderate to severe pain is documented on or before the date of the second visit with a clinician
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
     (      isAssessmentPerformedOnEncounter(visit,m,QPP144Elements.Plan_Of_Care_For_Pain)
        ||  isInterventionPerformedDuringEncounter(visit,m,QPP144Elements.Plan_Of_Care)
        ||  isMedicationAdministeredOnEncounter(visit,m,QPP144Elements.Non_Opioid_Pain_Medications)
        ||  isMedicationAdministeredOnEncounter(visit,m,QPP144Elements.All_Opioids_For_Pain_Control)
        ||  isCommunicationFromProviderToPatientOnEncounter(visit,m,QPP144Elements.Follow_Up_Plan)
        ||  isInterventionPerformedDuringEncounter(visit,m,QPP144Elements.Pain_Education)
        ||  isInterventionPerformedDuringEncounter(visit,m,QPP144Elements.Psychological_Support)
     )
        && ! isAssessmentPerformedOnEncounter(visit,m,QPP144Elements.Plan_Of_Care_Moderate_Or_Severe_Not_Met)
    )
  }
}

