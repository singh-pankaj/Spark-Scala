package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, IRIS24Elements,MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS24
* Measure Title               :- Refractive Surgery:  Postoperative correction within +/- 0.5 Diopter of the Intended Correction
* Measure Description         :- Percentage of patients with a postoperative spherical equivalent (SE) within +/- 0.5 Diopter (D) of the intended correction or SE
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- Ganesh Warkhad
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS24 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "IRIS24"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
          ,IRIS24Elements.Intended_Refraction
          ,IRIS24Elements.Myopia
          ,IRIS24Elements.Myopia__Eye
          ,IRIS24Elements.Refractive_Surgery__Eye
          ,IRIS24Elements.Actual_Refraction__Eye
          ,IRIS24Elements.Actual_Refraction
          ,IRIS24Elements.Actual_Refraction__Eye
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList,patientHistoryRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients aged 18 years or greater and diagnosis of myopia and receiving refractive surgery treatment
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val filteredRDD = getPatientRDDBetweenPeriodsInMeasurementPeriod(initialRDD, m, CalenderUnit.DAY, 30, false)

    initialRDD.filter(visit =>
            isAgeAbove(visit, m, true)
        &&  wasDiagnosisInHistory(visit, m, IRIS24Elements.Myopia, patientHistoryBroadcastList)
        &&  (  wasPhysicalExamPerformedBeforeProcedure(visit,m,IRIS24Elements.Refractive_Surgery_1,IRIS24Elements.Intended_Refraction,patientHistoryBroadcastList)
             ||  (   wasPhysicalExamPerformedBeforeProcedure(visit,m,IRIS24Elements.Refractive_Surgery_3,IRIS24Elements.Intended_Refraction,patientHistoryBroadcastList)
                  && wasPhysicalExamPerformedBeforeProcedure(visit,m,IRIS24Elements.Refractive_Surgery_Keywords,IRIS24Elements.Intended_Refraction,patientHistoryBroadcastList)
                 )
            )
        &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,true,IRIS24Elements.Refractive_Surgery__Eye,patientHistoryBroadcastList,Seq(IRIS24Elements.Myopia__Eye))
        &&  (   isProcedurePerformedDuringEncounter(visit,m,IRIS24Elements.Refractive_Surgery_1)
             || (   isProcedurePerformedDuringEncounter(visit,m,IRIS24Elements.Refractive_Surgery_3)
                 && isProcedurePerformedDuringEncounter(visit,m,IRIS24Elements.Refractive_Surgery_Keywords)
                )
            )
        //&&  wasPhysicalExamPerformedAfterProcedureWithInXDays(visit,m,IRIS24Elements.Actual_Refraction,IRIS24Elements.Refractive_Surgery_1,30,patientHistoryBroadcastList)
        &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,true,IRIS24Elements.Refractive_Surgery__Eye,patientHistoryBroadcastList,Seq(IRIS24Elements.Actual_Refraction__Eye))
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients receiving refractive surgery with a postoperative spherical equivalent (SE) within +/- 0.5 Diopter (D) of the intended correction or SE within 30 days
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        wasDifferenceBetweenIntendedAndActualRefraction(visit,IRIS24Elements.Intended_Refraction,m,-0.5,0.5,patientHistoryBroadcastList,IRIS24Elements.Actual_Refraction)
      )
  }

}
