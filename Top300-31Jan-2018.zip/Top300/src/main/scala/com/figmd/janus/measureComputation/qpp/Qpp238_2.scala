package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, MeasureProperty, QPP238Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- QPP238_2
* Measure Title               :- Use of High-Risk Medications in the Elderly
* Measure Description         :- Percentage of patients 65 years of age and older who were ordered high-risk medications. Two rates are submitted.
                                 a. Percentage of patients who were ordered at least one high-risk medication.
                                 b. Percentage of patients who were ordered at least two of the same high-risk medications.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 2
* Measure Stratum No.         :- NA
* Measure Stratification      :- 2
* Measure Developer           :- kiran Phalke
* Initial GIT Version/Tag(CRA):- Measure_Development_2029-Release_Notes_for_2029_Measures_SI_2.6
* Latest GIT Version/Tag(CRA) :- Measure_Development_2029-Release_Notes_for_2029_Measures_SI_2.6
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp238_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP238_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP238Elements.Hydrochlorothiazide___Methyldopa,
      QPP238Elements.Chlorpheniramine___Ibuprofen___Pseudoephedrine,
      QPP238Elements.Carbetapentane___Chlorpheniramine___Ephedrine___Phenylephrine,
      QPP238Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan,
      QPP238Elements.Dexchlorpheniramine___Pseudoephedrine,
      QPP238Elements.Dexbrompheniramine___Dextromethorphan___Phenylephrine,
      QPP238Elements.Amitriptyline___Perphenazine,
      QPP238Elements.Dexbrompheniramine_Maleate___Pseudoephedrine_Hydrochloride,
      QPP238Elements.Codeine___Pseudoephedrine___Triprolidine,
      QPP238Elements.Codeine___Dexchlorpheniramine___Phenylephrine,
      QPP238Elements.Chlorpheniramine___Dihydrocodeine___Phenylephrine,
      QPP238Elements.Chlophedianol___Dexbrompheniramine___Phenylephrine,
      QPP238Elements.Codeine___Dexbrompheniramine___Pseudoephedrine,
      QPP238Elements.Dexbrompheniramine___Dextromethorphan___Pseudoephedrine,
      QPP238Elements.Chlorpheniramine___Codeine___Phenylephrine,
      QPP238Elements.Chlophedianol___Dexbrompheniramine___Pseudoephedrine,
      QPP238Elements.Acetaminophen___Dextromethorphan___Diphenhydramine,
      QPP238Elements.Estradiol___Levonorgestrel,
      QPP238Elements.Brompheniramine___Chlophedianol___Pseudoephedrine,
      QPP238Elements.Dextromethorphan___Doxylamine___Pseudoephedrine,
      QPP238Elements.Brompheniramine___Chlophedianol___Phenylephrine,
      QPP238Elements.Chlorpheniramine___Codeine___Pseudoephedrine,
      QPP238Elements.Chlophedianol___Dexchlorpheniramine___Pseudoephedrine,
      QPP238Elements.Doxylamine___Pseudoephedrine,
      QPP238Elements.Brompheniramine___Codeine___Pseudoephedrine,
      QPP238Elements.Dextromethorphan___Doxylamine,
      QPP238Elements.Chlorpheniramine___Phenylephrine___Phenyltoloxamine,
      QPP238Elements.Brompheniramine___Codeine,
      QPP238Elements.Acetaminophen___Dextromethorphan___Diphenhydramine,
      QPP238Elements.Carbetapentane___Chlorpheniramine___Phenylephrine,
      QPP238Elements.Chlophedianol___Chlorpheniramine___Phenylephrine,
      QPP238Elements.Meprobamate,
      QPP238Elements.Trimipramine,
      QPP238Elements.Ergoloid_Mesylates,
      QPP238Elements.Thioridazine,
      QPP238Elements.Pentobarbital,
      QPP238Elements.Dipyridamole,
      QPP238Elements.Meperidine,
      QPP238Elements.Doxylamine,
      QPP238Elements.Amobarbital,
      QPP238Elements.Secobarbital,
      QPP238Elements.Chlorpropamide,
      QPP238Elements.Ticlopidine,
      QPP238Elements.Carbinoxamine,
      QPP238Elements.Clemastine,
      QPP238Elements.Disopyramide,
      QPP238Elements.Estropipate,
      QPP238Elements.Methyldopa,
      QPP238Elements.Trihexyphenidyl,
      QPP238Elements.Clomipramine,
      QPP238Elements.Guanfacine,
      QPP238Elements.Megestrol,
      QPP238Elements.Chlorpheniramine,
      QPP238Elements.Nifedipine,
      QPP238Elements.Orphenadrine,
      QPP238Elements.Conjugated_Estrogens,
      QPP238Elements.Metaxalone,
      QPP238Elements.Imipramine,
      QPP238Elements.Benztropine,
      QPP238Elements.Chlorzoxazone,
      QPP238Elements.Ketorolac_Tromethamine,
      QPP238Elements.Estradiol,
      QPP238Elements.Indomethacin,
      QPP238Elements.Glyburide,
      QPP238Elements.Carisoprodol,
      QPP238Elements.Methocarbamol,
      QPP238Elements.Diphenhydramine_Hydrochloride,
      QPP238Elements.Cyclobenzaprine_Hydrochloride,
      QPP238Elements.Amitriptyline_Hydrochloride,
      QPP238Elements.Hydroxyzine,
      QPP238Elements.Dexbrompheniramine,
      QPP238Elements.Dexchlorpheniramine,
      QPP238Elements.Meperidine,
      QPP238Elements.Pentobarbital,
      QPP238Elements.Butabarbital,
      QPP238Elements.Pentazocine,
      QPP238Elements.Triprolidine,
      QPP238Elements.Esterified_Estrogens,
      QPP238Elements.Isoxsuprine,
      QPP238Elements.Brompheniramine,
      QPP238Elements.Amitriptyline_____Chlordiazepoxide,
      QPP238Elements.Acetaminophen___Dextromethorphan___Doxylamine___Phenylephrine,
      QPP238Elements.Acetaminophen___Chlorpheniramine,
      QPP238Elements.Codeine___Phenylephrine___Promethazine,
      QPP238Elements.Diphenhydramine___Ibuprofen,
      QPP238Elements.Phenylephrine___Promethazine,
      QPP238Elements.Chlorpheniramine___Dextromethorphan,
      QPP238Elements.Chlorpheniramine___Hydrocodone___Pseudoephedrine,
      QPP238Elements.Dexchlorpheniramine___Dextromethorphan___Pseudoephedrine,
      QPP238Elements.Chlorpheniramine___Codeine,
      QPP238Elements.Aspirin___Caffeine___Orphenadrine,
      QPP238Elements.Aspirin___Carisoprodol___Codeine,
      QPP238Elements.Diphenhydramine___Phenylephrine,
      QPP238Elements.Chlorpheniramine___Phenylephrine___Pyrilamine,
      QPP238Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan___Phenylephrine,
      QPP238Elements.Chlorpheniramine___Dextromethorphan___Phenylephrine,
      QPP238Elements.Aspirin___Carisoprodol,
      QPP238Elements.Dextromethorphan___Promethazine,
      QPP238Elements.Chlorpheniramine___Pseudoephedrine,
      QPP238Elements.Acetaminophen___Chlorpheniramine___Pseudoephedrine,
      QPP238Elements.Acetaminophen___Diphenhydramine___Phenylephrine,
      QPP238Elements.Esterified_Estrogens,
      QPP238Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan___Pseudoephedrine,
      QPP238Elements.Aspirin___Butalbital___Caffeine___Codeine,
      QPP238Elements.Estradiol___Norethindrone,
      QPP238Elements.Conjugated_Estrogens___Medroxyprogesterone,
      QPP238Elements.Brompheniramine___Dextromethorphan___Phenylephrine,
      QPP238Elements.Acetaminophen___Butalbital___Caffeine___Codeine,
      QPP238Elements.Brompheniramine___Phenylephrine,
      QPP238Elements.Acetaminophen___Chlorpheniramine___Phenylephrine,
      QPP238Elements.Acetaminophen___Dextromethorphan___Doxylamine___Pseudoephedrine,
      QPP238Elements.Chlorpheniramine___Hydrocodone,
      QPP238Elements.Brompheniramine___Pseudoephedrine,
      QPP238Elements.Trimethobenzamide,
      QPP238Elements.Chlorpheniramine___Dextromethorphan___Pseudoephedrine,
      QPP238Elements.Acetaminophen___Dextromethorphan___Doxylamine,
      QPP238Elements.Brompheniramine___Dextromethorphan___Pseudoephedrine,
      QPP238Elements.Codeine___Promethazine,
      QPP238Elements.Chlorpheniramine___Phenylephrine,
      QPP238Elements.Pseudoephedrine___Triprolidine,
      QPP238Elements.Naloxone___Pentazocine,
      QPP238Elements.Aspirin___Butalbital___Caffeine,
      QPP238Elements.Acetaminophen___Diphenhydramine,
      QPP238Elements.Desiccated_Thyroid,
      QPP238Elements.Atropine___Hyoscyamine___Phenobarbital___Scopolamine,
      QPP238Elements.Glyburide___Metformin,
      QPP238Elements.Acetaminophen___Butalbital___Caffeine,
      QPP238Elements.Promethazine_Hydrochloride,
      QPP238Elements.Aspirin___Diphenhydramine_Citrate,
      QPP238Elements.Acetaminophen___Diphenhydramine___Pseudoephedrine,
      QPP238Elements.Doxylamine___Pyridoxine,
      QPP238Elements.Aspirin___Chlorpheniramine___Phenylephrine,
      QPP238Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan___Guaifenesin,
      QPP238Elements.Dexbrompheniramine___Phenylephrine,
      QPP238Elements.Phenylephrine___Triprolidine,
      QPP238Elements.Bazedoxifene___Conjugated_Estrogens,
      QPP238Elements.Doxylamine___Phenylephrine,
      QPP238Elements.Acetaminophen___Brompheniramine,
      QPP238Elements.Diphenhydramine___Pseudoephedrine,
      QPP238Elements.Aspirin___Meprobamate,
      QPP238Elements.Diphenhydramine___Magnesium_Salicylate,
      QPP238Elements.Estradiol___Norgestimate_Biphasic,
      QPP238Elements.Dextromethorphan___Diphenhydramine___Phenylephrine,
      QPP238Elements.Dienogest___Estradiol_Multiphasic,
      QPP238Elements.Acetaminophen___Doxylamine___Phenylephrine,
      QPP238Elements.Dexchlorpheniramine___Phenylephrine,
      QPP238Elements.Acetaminophen___Dexbrompheniramine,
      QPP238Elements.Diphenhydramine___Naproxen,
      QPP238Elements.Brompheniramine___Chlophedianol___Phenylephrine,
      QPP238Elements.Drospirenone___Estradiol,
      QPP238Elements.Atropine___Chlorpheniramine___Hyoscyamine___Pseudoephedrine___Scopolamine



    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet,sparkSession, patientHistoryBroadcastList,patientHistoryRDD)
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients 65 years and older who had a visit during the measurement period
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
              isAgeAbove(visit, m, true,65)
          &&  isVisitTypeIn(visit,m,
                                    QPP238Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
                                    QPP238Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up ,
                                    QPP238Elements.Ophthalmologic_Outpatient_Visit,
                                    QPP238Elements.Office_Visit,
                                    QPP238Elements.Home_Healthcare_Services,
                                    QPP238Elements.Face_To_Face_Interaction,
                                    QPP238Elements.Encounter_Inpatient,
                                    QPP238Elements.Annual_Wellness_Visit
                            )

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Exclude patients who were in hospice care during the measurement year
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            isProcedurePerformed(visit,m,QPP238Elements.Hospice_Services,patientHistoryBroadcastList)
        ||  wasInterventionPerformedInHistory(visit,m,QPP238Elements.Hospice_Services_Snomedct,patientHistoryBroadcastList)
        ||  wasInterventionPerformedInHistory(visit,m,QPP238Elements.Hospice_Care,patientHistoryBroadcastList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients with at least two orders for the same high-risk medication during the measurement period
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], sparkSession:SparkSession,patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    val cumilative_list1=cumulative(intermediateForMet,m,List((QPP238Elements.Nonbenzodiazepine_Hypnotics,QPP238Elements.Anti_Infectives__Other)),CalenderUnit.DAY,CalenderUnit.YEAR,1,"DURING")
    val patientcumilativeBroadcastList: Broadcast[List[(String,String,Double)]] = sparkSession.sparkContext.broadcast(cumilative_list1)
    val countElementList2: List[(String,Int)] = ElementWisecountList(patientHistoryRDD,m,
      QPP238Elements.Hydrochlorothiazide___Methyldopa,
      QPP238Elements.Chlorpheniramine___Ibuprofen___Pseudoephedrine,
      QPP238Elements.Carbetapentane___Chlorpheniramine___Ephedrine___Phenylephrine,
      QPP238Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan,
      QPP238Elements.Dexchlorpheniramine___Pseudoephedrine,
      QPP238Elements.Dexbrompheniramine___Dextromethorphan___Phenylephrine,
      QPP238Elements.Amitriptyline___Perphenazine,
      QPP238Elements.Dexbrompheniramine_Maleate___Pseudoephedrine_Hydrochloride,
      QPP238Elements.Dexbrompheniramine___Pseudoephedrine,
      QPP238Elements.Codeine___Dexchlorpheniramine___Phenylephrine,
      QPP238Elements.Chlorpheniramine___Dihydrocodeine___Phenylephrine,
      QPP238Elements.Chlophedianol___Dexbrompheniramine___Phenylephrine,
      QPP238Elements.Codeine___Dexbrompheniramine___Pseudoephedrine,
      QPP238Elements.Dexbrompheniramine___Dextromethorphan___Pseudoephedrine,
      QPP238Elements.Chlorpheniramine___Codeine___Phenylephrine,
      QPP238Elements.Chlophedianol___Dexbrompheniramine___Pseudoephedrine,
      QPP238Elements.Acetaminophen___Dextromethorphan___Diphenhydramine,
      QPP238Elements.Estradiol___Levonorgestrel,
      QPP238Elements.Brompheniramine___Chlophedianol___Phenylephrine,
      QPP238Elements.Dexbrompheniramine___Dextromethorphan___Pseudoephedrine,
      QPP238Elements.Brompheniramine___Chlophedianol___Phenylephrine,
      QPP238Elements.Chlorpheniramine___Codeine___Pseudoephedrine,
      QPP238Elements.Chlophedianol___Dexbrompheniramine___Pseudoephedrine,
      QPP238Elements.Doxylamine___Pseudoephedrine,
      QPP238Elements.Brompheniramine___Codeine___Pseudoephedrine,
      QPP238Elements.Dextromethorphan___Doxylamine,
      QPP238Elements.Chlorpheniramine___Phenylephrine___Phenyltoloxamine,
      QPP238Elements.Brompheniramine___Codeine,
      QPP238Elements.Acetaminophen___Dextromethorphan___Diphenhydramine,
      QPP238Elements.Carbetapentane___Chlorpheniramine___Phenylephrine,
      QPP238Elements.Chlophedianol___Chlorpheniramine___Phenylephrine,
      QPP238Elements.Meprobamate,
      QPP238Elements.Trimipramine,
      QPP238Elements.Ergoloid_Mesylates,
      QPP238Elements.Thioridazine,
      QPP238Elements.Pentobarbital,
      QPP238Elements.Dipyridamole,
      QPP238Elements.Meperidine,
      QPP238Elements.Doxylamine,
      QPP238Elements.Amobarbital,
      QPP238Elements.Secobarbital,
      QPP238Elements.Chlorpropamide,
      QPP238Elements.Ticlopidine,
      QPP238Elements.Carbinoxamine,
      QPP238Elements.Clemastine,
      QPP238Elements.Disopyramide,
      QPP238Elements.Estropipate,
      QPP238Elements.Methyldopa,
      QPP238Elements.Trihexyphenidyl,
      QPP238Elements.Clomipramine,
      QPP238Elements.Guanfacine,
      QPP238Elements.Megestrol,
      QPP238Elements.Chlorpheniramine,
      QPP238Elements.Nifedipine,
      QPP238Elements.Orphenadrine,
      QPP238Elements.Conjugated_Estrogens,
      QPP238Elements.Metaxalone,
      QPP238Elements.Imipramine,
      QPP238Elements.Benztropine,
      QPP238Elements.Chlorzoxazone,
      QPP238Elements.Ketorolac_Tromethamine,
      QPP238Elements.Estradiol,
      QPP238Elements.Indomethacin,
      QPP238Elements.Glyburide,
      QPP238Elements.Carisoprodol,
      QPP238Elements.Methocarbamol,
      QPP238Elements.Diphenhydramine_Hydrochloride,
      QPP238Elements.Cyclobenzaprine_Hydrochloride,
      QPP238Elements.Amitriptyline_Hydrochloride,
      QPP238Elements.Hydroxyzine,
      QPP238Elements.Dexbrompheniramine,
      QPP238Elements.Dexchlorpheniramine,
      QPP238Elements.Meperidine___Promethazine,
      QPP238Elements.Pentobarbital,
      QPP238Elements.Butabarbital,
      QPP238Elements.Pentazocine,
      QPP238Elements.Triprolidine,
      QPP238Elements.Esterified_Estrogens,
      QPP238Elements.Isoxsuprine,
      QPP238Elements.Brompheniramine,
      QPP238Elements.Amitriptyline_____Chlordiazepoxide,
      QPP238Elements.Acetaminophen___Dextromethorphan___Diphenhydramine___Phenylephrine,
      QPP238Elements.Acetaminophen___Chlorpheniramine,
      QPP238Elements.Codeine___Phenylephrine___Promethazine,
      QPP238Elements.Diphenhydramine___Ibuprofen,
      QPP238Elements.Phenylephrine___Promethazine,
      QPP238Elements.Chlorpheniramine___Dextromethorphan,
      QPP238Elements.Chlorpheniramine___Hydrocodone___Pseudoephedrine,
      QPP238Elements.Dexbrompheniramine___Dextromethorphan___Pseudoephedrine,
      QPP238Elements.Chlorpheniramine___Codeine,
      QPP238Elements.Aspirin___Caffeine___Orphenadrine,
      QPP238Elements.Aspirin___Carisoprodol___Codeine,
      QPP238Elements.Diphenhydramine___Phenylephrine,
      QPP238Elements.Chlorpheniramine___Phenylephrine___Pyrilamine,
      QPP238Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan___Phenylephrine,
      QPP238Elements.Chlorpheniramine___Dextromethorphan___Phenylephrine,
      QPP238Elements.Aspirin___Carisoprodol,
      QPP238Elements.Dextromethorphan___Promethazine,
      QPP238Elements.Chlorpheniramine___Pseudoephedrine,
      QPP238Elements.Acetaminophen___Chlorpheniramine___Pseudoephedrine,
      QPP238Elements.Acetaminophen___Butalbital,
      QPP238Elements.Acetaminophen___Diphenhydramine___Phenylephrine,
      QPP238Elements.Esterified_Estrogens___Methyltestosterone,
      QPP238Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan___Pseudoephedrine,
      QPP238Elements.Aspirin___Butalbital___Caffeine___Codeine,
      QPP238Elements.Estradiol___Norethindrone,
      QPP238Elements.Conjugated_Estrogens___Medroxyprogesterone,
      QPP238Elements.Brompheniramine___Dextromethorphan___Phenylephrine,
      QPP238Elements.Acetaminophen___Butalbital___Caffeine___Codeine,
      QPP238Elements.Brompheniramine___Phenylephrine,
      QPP238Elements.Acetaminophen___Chlorpheniramine___Phenylephrine,
      QPP238Elements.Acetaminophen___Dextromethorphan___Doxylamine___Pseudoephedrine,
      QPP238Elements.Chlorpheniramine___Hydrocodone,
      QPP238Elements.Brompheniramine___Pseudoephedrine,
      QPP238Elements.Trimethobenzamide,
      QPP238Elements.Chlorpheniramine___Dextromethorphan___Pseudoephedrine,
      QPP238Elements.Acetaminophen___Dextromethorphan___Doxylamine,
      QPP238Elements.Brompheniramine___Dextromethorphan___Pseudoephedrine,
      QPP238Elements.Codeine___Promethazine,
      QPP238Elements.Chlorpheniramine___Phenylephrine,
      QPP238Elements.Pseudoephedrine___Triprolidine,
      QPP238Elements.Naloxone___Pentazocine,
      QPP238Elements.Aspirin___Butalbital___Caffeine,
      QPP238Elements.Acetaminophen___Diphenhydramine,
      QPP238Elements.Desiccated_Thyroid,
      QPP238Elements.Atropine___Hyoscyamine___Phenobarbital___Scopolamine,
      QPP238Elements.Glyburide___Metformin,
      QPP238Elements.Acetaminophen___Butalbital___Caffeine,
      QPP238Elements.Promethazine_Hydrochloride,
      QPP238Elements.Aspirin___Diphenhydramine_Citrate,
      QPP238Elements.Acetaminophen___Diphenhydramine___Pseudoephedrine,
      QPP238Elements.Doxylamine___Pyridoxine,
      QPP238Elements.Aspirin___Chlorpheniramine___Phenylephrine,
      QPP238Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan___Guaifenesin,
      QPP238Elements.Dexbrompheniramine___Phenylephrine,
      QPP238Elements.Phenylephrine___Triprolidine,
      QPP238Elements.Bazedoxifene___Conjugated_Estrogens,
      QPP238Elements.Doxylamine___Phenylephrine,
      QPP238Elements.Acetaminophen___Aspirin___Diphenhydramine,
      QPP238Elements.Acetaminophen___Brompheniramine,
      QPP238Elements.Diphenhydramine___Pseudoephedrine,
      QPP238Elements.Aspirin___Meprobamate,
      QPP238Elements.Diphenhydramine___Magnesium_Salicylate,
      QPP238Elements.Estradiol___Norgestimate_Biphasic,
      QPP238Elements.Dextromethorphan___Diphenhydramine___Phenylephrine,
      QPP238Elements.Dienogest___Estradiol_Multiphasic,
      QPP238Elements.Acetaminophen___Doxylamine___Phenylephrine,
      QPP238Elements.Dexbrompheniramine___Phenylephrine,
      QPP238Elements.Acetaminophen___Diphenhydramine,
      QPP238Elements.Diphenhydramine___Naproxen,
      QPP238Elements.Brompheniramine___Codeine___Phenylephrine,
      QPP238Elements.Drospirenone___Estradiol,
      QPP238Elements.Atropine___Chlorpheniramine___Hyoscyamine___Pseudoephedrine___Scopolamine



    )

    intermediateForMet.filter(visit =>
      (

                getElementCountFromHistory(visit,m,2,true,QPP238Elements.Hydrochlorothiazide___Methyldopa,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Ibuprofen___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Carbetapentane___Chlorpheniramine___Ephedrine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dexchlorpheniramine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dexbrompheniramine___Dextromethorphan___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Amitriptyline___Perphenazine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dexbrompheniramine_Maleate___Pseudoephedrine_Hydrochloride,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dexbrompheniramine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Codeine___Dexchlorpheniramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Dihydrocodeine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlophedianol___Dexbrompheniramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Codeine___Dexbrompheniramine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dexbrompheniramine___Dextromethorphan___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Codeine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlophedianol___Dexbrompheniramine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Dextromethorphan___Diphenhydramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Estradiol___Levonorgestrel,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Brompheniramine___Chlophedianol___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dexbrompheniramine___Dextromethorphan___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Brompheniramine___Chlophedianol___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Codeine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlophedianol___Dexbrompheniramine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Doxylamine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Brompheniramine___Codeine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dextromethorphan___Doxylamine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Phenylephrine___Phenyltoloxamine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Brompheniramine___Codeine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Dextromethorphan___Diphenhydramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Carbetapentane___Chlorpheniramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlophedianol___Chlorpheniramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Meprobamate,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Trimipramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Ergoloid_Mesylates,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Thioridazine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Pentobarbital,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dipyridamole,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Meperidine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Doxylamine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Amobarbital,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Secobarbital,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpropamide,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Ticlopidine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Carbinoxamine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Clemastine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Disopyramide,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Estropipate,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Methyldopa,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Trihexyphenidyl,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Clomipramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Guanfacine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Megestrol,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Nifedipine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Orphenadrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Conjugated_Estrogens,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Metaxalone,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Imipramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Benztropine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorzoxazone,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Ketorolac_Tromethamine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Estradiol,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Indomethacin,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Glyburide,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Carisoprodol,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Methocarbamol,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Diphenhydramine_Hydrochloride,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Cyclobenzaprine_Hydrochloride,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Amitriptyline_Hydrochloride,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Hydroxyzine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dexbrompheniramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dexchlorpheniramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Meperidine___Promethazine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Pentobarbital,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Butabarbital,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Pentazocine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Triprolidine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Esterified_Estrogens,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Isoxsuprine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Brompheniramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Amitriptyline_____Chlordiazepoxide,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Dextromethorphan___Diphenhydramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Chlorpheniramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Codeine___Phenylephrine___Promethazine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Diphenhydramine___Ibuprofen,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Phenylephrine___Promethazine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Dextromethorphan,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Hydrocodone___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dexbrompheniramine___Dextromethorphan___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Codeine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Aspirin___Caffeine___Orphenadrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Aspirin___Carisoprodol___Codeine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Diphenhydramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Phenylephrine___Pyrilamine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Dextromethorphan___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Aspirin___Carisoprodol,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dextromethorphan___Promethazine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Chlorpheniramine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Butalbital,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Diphenhydramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Esterified_Estrogens___Methyltestosterone,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Aspirin___Butalbital___Caffeine___Codeine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Estradiol___Norethindrone,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Conjugated_Estrogens___Medroxyprogesterone,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Brompheniramine___Dextromethorphan___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Butalbital___Caffeine___Codeine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Brompheniramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Chlorpheniramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Dextromethorphan___Doxylamine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Hydrocodone,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Brompheniramine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Trimethobenzamide,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Dextromethorphan___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Dextromethorphan___Doxylamine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Brompheniramine___Dextromethorphan___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Codeine___Promethazine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Chlorpheniramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Pseudoephedrine___Triprolidine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Naloxone___Pentazocine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Aspirin___Butalbital___Caffeine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Diphenhydramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Desiccated_Thyroid,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Atropine___Hyoscyamine___Phenobarbital___Scopolamine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Glyburide___Metformin,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Butalbital___Caffeine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Promethazine_Hydrochloride,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Aspirin___Diphenhydramine_Citrate,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Diphenhydramine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Doxylamine___Pyridoxine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Aspirin___Chlorpheniramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Chlorpheniramine___Dextromethorphan___Guaifenesin,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dexbrompheniramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Phenylephrine___Triprolidine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Bazedoxifene___Conjugated_Estrogens,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Doxylamine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Aspirin___Diphenhydramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Brompheniramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Diphenhydramine___Pseudoephedrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Aspirin___Meprobamate,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Diphenhydramine___Magnesium_Salicylate,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Estradiol___Norgestimate_Biphasic,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dextromethorphan___Diphenhydramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dienogest___Estradiol_Multiphasic,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Doxylamine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Dexbrompheniramine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Acetaminophen___Diphenhydramine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Diphenhydramine___Naproxen,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Brompheniramine___Codeine___Phenylephrine,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Drospirenone___Estradiol,countElementList2)
          ||    getElementCountFromHistory(visit,m,2,true,QPP238Elements.Atropine___Chlorpheniramine___Hyoscyamine___Pseudoephedrine___Scopolamine,countElementList2)
          ||  (
                      getCommulativeResult(visit,m,QPP238Elements.Nonbenzodiazepine_Hypnotics,90,CompareOperator.GREATER_EQUAL,patientcumilativeBroadcastList)
                  &&  getElementCountFromHistory(visit,m,2,true,QPP238Elements.Nonbenzodiazepine_Hypnotics,countElementList2)

              )
          ||  (
                      getCommulativeResult(visit,m,QPP238Elements.Anti_Infectives__Other,90,CompareOperator.GREATER_EQUAL,patientcumilativeBroadcastList)
                 &&   getElementCountFromHistory(visit,m,2,true,QPP238Elements.Anti_Infectives__Other,countElementList2)

               )
          ||  isMedicationOrdered(visit,m,patientHistoryBroadcastList,QPP238Elements.Two_High_Risk_Medications)
    )
    && !isMedicationOrdered(visit,m,patientHistoryBroadcastList,QPP238Elements.Two_High_Risk_Med_Not_Met)




    )
  }


}