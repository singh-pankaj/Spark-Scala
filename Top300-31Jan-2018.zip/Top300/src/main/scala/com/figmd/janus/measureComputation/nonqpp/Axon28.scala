package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty,Axon28Elements,CalenderUnit,CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Axon28
* Measure Title               :- Parkinsons: Falls Outcome for Patients with PD
* Measure Description         :- Percentage of patients diagnosed with PD for who the number of falls was maintained or reduced from initial baseline.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- PRIYANKA.CHAVAN
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object Axon28 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Axon28"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,Axon28Elements.Discharge
      ,Axon28Elements.Discharge_Services___Hospital_Inpatient
      ,Axon28Elements.Emergency_Department_Visit
      ,Axon28Elements.Emergency_Treatment
      ,Axon28Elements.Evaluation_And_Management_Inpatient
      ,Axon28Elements.Evaluation_And_Management_Physician_Visit
      ,Axon28Elements.Hospital_Inpatient_Visit___Initial
      ,Axon28Elements.Initial_Hospital_Visit
      ,Axon28Elements.Inpatient_Consultation
      ,Axon28Elements.Medical_Consultation
      ,Axon28Elements.Medical_Consultation_Inpatient
      ,Axon28Elements.Nursing_Facility_Visit
      ,Axon28Elements.Office_Visit
      ,Axon28Elements.Outpatient_Consultation
      ,Axon28Elements.Subsequent_Hospital_Care
      ,Axon28Elements.Fall_Rate_Documented_Improper_Format
      ,Axon28Elements.Fall_Rate_1
      ,Axon28Elements.Fall_Rate_2
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val leastPatientList = leastPatientListAfterStartWithinXPeriod(patientHistoryRDD,m,CalenderUnit.MONTH,6,Axon28Elements.Fall_Rate_1)
    val leastPatientListBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastPatientList)

    val MostPatientList  = mostPatientListAfterStartWithinXPeriod(patientHistoryRDD,m,CalenderUnit.MONTH,6,Axon28Elements.Fall_Rate_2)
    val MostPatientListBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(MostPatientList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]],leastPatientListBroadcastList,MostPatientListBroadcastList)
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with a diagnosis of Parkinson’s disease who had at least two encounters during the measurement period and had the
number of falls documented at each encounter. One encounter must occur in January 1 to June 30, 20XX and another encounter
must occur in July 1 to December 31, 20XX.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isDiagnosedOnEncounter(visit, m, Axon28Elements.Parkinson_s_Disease)
        &&
        (
          wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Discharge, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Discharge_Services___Hospital_Inpatient, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Emergency_Department_Visit, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Emergency_Treatment, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Evaluation_And_Management_Inpatient, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Evaluation_And_Management_Physician_Visit, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Hospital_Inpatient_Visit___Initial, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Initial_Hospital_Visit, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Inpatient_Consultation , 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Medical_Consultation, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Medical_Consultation_Inpatient, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Nursing_Facility_Visit, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Office_Visit, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Outpatient_Consultation, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedAfterStartWithInXMonths(visit, m, Axon28Elements.Subsequent_Hospital_Care, 6, patientHistoryBroadcastList)
          )
        &&
        (
                wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Discharge, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Discharge_Services___Hospital_Inpatient, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Emergency_Department_Visit, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Emergency_Treatment, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Evaluation_And_Management_Inpatient, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Evaluation_And_Management_Physician_Visit, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Hospital_Inpatient_Visit___Initial, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Initial_Hospital_Visit, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Inpatient_Consultation, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Medical_Consultation, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Medical_Consultation_Inpatient, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Nursing_Facility_Visit, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Office_Visit, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Outpatient_Consultation, 6, patientHistoryBroadcastList)
            ||  wasEncounterPerformedBeforeEndInXMonths(visit, m, Axon28Elements.Subsequent_Hospital_Care, 6, patientHistoryBroadcastList)
          )
        &&  isVisitTypeIn(visit, m,Axon28Elements.Discharge
            ,Axon28Elements.Discharge_Services___Hospital_Inpatient
            ,Axon28Elements.Emergency_Department_Visit
            ,Axon28Elements.Emergency_Treatment
            ,Axon28Elements.Evaluation_And_Management_Inpatient
            ,Axon28Elements.Evaluation_And_Management_Physician_Visit
            ,Axon28Elements.Hospital_Inpatient_Visit___Initial
            ,Axon28Elements.Initial_Hospital_Visit
            ,Axon28Elements.Inpatient_Consultation
            ,Axon28Elements.Medical_Consultation
            ,Axon28Elements.Medical_Consultation_Inpatient
            ,Axon28Elements.Nursing_Facility_Visit
            ,Axon28Elements.Office_Visit
            ,Axon28Elements.Outpatient_Consultation
            ,Axon28Elements.Subsequent_Hospital_Care )

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who reported their fall rate during the July 1 to December 31, 20XX^ encounter was maintained or reduced from prior
report during January 1 to June 30, 20XX* encounter of the measurement period.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            isAssessmentPerformedOnEncounter(visit, m,Axon28Elements.Fall_Rate_Documented_Improper_Format)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
No documentation of number of falls in the required format. (i.e.., “Patient reports n falls occurred during the last 6 months.”)
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],leastPatientListBroadcastList : Broadcast[List[CassandraRow]],MostPatientListBroadcastList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
            wasFallsRateMaintainedorReducedInLastSixMonth(visit,m,Axon28Elements.Fall_Rate_1,Axon28Elements.Fall_Rate_2, 0, CompareOperator.LESS_EQUAL ,MostPatientListBroadcastList,leastPatientListBroadcastList)
    )
  }


}