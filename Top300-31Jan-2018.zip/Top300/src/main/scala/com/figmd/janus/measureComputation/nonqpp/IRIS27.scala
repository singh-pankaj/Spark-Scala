package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, IRIS27Elements, IRIS42Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS27
* Measure Title               :- Complications After Cataract Surgery
* Measure Description         :- Percentage of patients aged 18 years and older with a diagnosis of cataract who had cataract surgery and had the following complications
                                 with 90 days after cataract surgery: prolonged inflammation, incision complications, iris complications, retinal detachment, cystoid macular edema, corneal complications.Percentage
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Lower Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS27 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "IRIS27"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
        ,IRIS27Elements.Prolonged_Inflammation
        ,IRIS27Elements.Prolonged_Inflammation___Eye
        ,IRIS27Elements.Incision_Complications
        ,IRIS27Elements.Incision_Complications___Eye
        ,IRIS27Elements.Iris_Complications
        ,IRIS27Elements.Iris_Complications___Eye
        ,IRIS27Elements.Retinal_Detachment
        ,IRIS27Elements.Retinal_Detachment___Eye
        ,IRIS27Elements.Cystoid_Macular_Edema
        ,IRIS27Elements.Cystoid_Macular_Edema_Eye
        ,IRIS27Elements.Corneal_Complications
        ,IRIS27Elements.Corneal_Complications___Eye
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients aged 18 years and older with a diagnosis of cataract who had cataract surgery
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val filteredRDD = getPatientRDDBetweenPeriodsInMeasurementPeriod(initialRDD, m, CalenderUnit.MONTH, 9, true)

    filteredRDD.filter(visit =>
            isPatientAdult(visit,m)
        &&  isProcedurePerformedDuringEncounter(visit,m,IRIS27Elements.Cataract_Surgery)
        && !isProcedurePerformedDuringEncounter(visit,m,IRIS27Elements.Cataract_Surgery_Modifiers)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients aged 18 years and older with a diagnosis of cataract who had cataract surgery and had the following complications with 90 days after cataract surgery:
prolonged inflammation, incision complications, iris complications, retinal detachment, cystoid macular edema, corneal complications.Patients.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            (   wasDiagnosedAfterProcedureWithInXDays(visit,m,IRIS27Elements.Prolonged_Inflammation,IRIS27Elements.Cataract_Surgery,90,patientHistoryBroadcastList)
             && checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS27Elements.Cataract_Surgery_Eye,patientHistoryBroadcastList,Seq(IRIS27Elements.Prolonged_Inflammation___Eye))
            )
         || (   wasDiagnosedAfterProcedureWithInXDays(visit,m,IRIS27Elements.Incision_Complications,IRIS27Elements.Cataract_Surgery,90,patientHistoryBroadcastList)
             && checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS27Elements.Cataract_Surgery_Eye,patientHistoryBroadcastList,Seq(IRIS27Elements.Incision_Complications___Eye))
            )
         || (   wasDiagnosedAfterProcedureWithInXDays(visit,m,IRIS27Elements.Iris_Complications,IRIS27Elements.Cataract_Surgery,90,patientHistoryBroadcastList)
             && checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS27Elements.Cataract_Surgery_Eye,patientHistoryBroadcastList,Seq(IRIS27Elements.Iris_Complications___Eye))
            )
         || (   wasDiagnosedAfterProcedureWithInXDays(visit,m,IRIS27Elements.Retinal_Detachment,IRIS27Elements.Cataract_Surgery,90,patientHistoryBroadcastList)
             && checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS27Elements.Cataract_Surgery_Eye,patientHistoryBroadcastList,Seq(IRIS27Elements.Retinal_Detachment___Eye))
            )
         || (   wasDiagnosedAfterProcedureWithInXDays(visit,m,IRIS27Elements.Cystoid_Macular_Edema,IRIS27Elements.Cataract_Surgery,90,patientHistoryBroadcastList)
             && checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS27Elements.Cataract_Surgery_Eye,patientHistoryBroadcastList,Seq(IRIS27Elements.Cystoid_Macular_Edema_Eye))
            )
         || (   wasDiagnosedAfterProcedureWithInXDays(visit,m,IRIS27Elements.Corneal_Complications,IRIS27Elements.Cataract_Surgery,90,patientHistoryBroadcastList)
             && checkEyeOnEncounterEqualsWithOtherEye(visit,m,false,IRIS27Elements.Cataract_Surgery_Eye,patientHistoryBroadcastList,Seq(IRIS27Elements.Corneal_Complications___Eye))
            )
    )
  }

}
