package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CompareOperator, MeasureProperty, QPP221Elements,AdminElements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp221
* Measure Title              :- Functional Status Change for Patients with Shoulder Impairments.
* Measure Description        :- A patient-reported outcome measure of risk-adjusted change in functional status for patients 14 years+ with shoulder
                                impairments. The change in functional status (FS) is assessed using the Shoulder FS patient-reported outcome
                                measure (PROM) (©Focus on Therapeutic Outcomes, Inc.).The measure is adjusted to patient characteristics known
                                to be associated with FS outcomes (risk adjusted) and used as a performance measure at the patient level, at the
                                individual clinician, and at the clinic level to assess quality. The measure is available as a computer adaptive test, for
                                reduced patient burden, or a short form (static survey).
* Calculation Implementation :- Episode-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- RAHUL.RASURE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp221 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp221"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,QPP221Elements.Physical_Therapy,
      QPP221Elements.Occupational_Therapy,
      QPP221Elements.Functional_Deficit_Shoulder,
      QPP221Elements.Psychotic_Disorder_Or_Related_Condition,
      QPP221Elements.Blindness,
      QPP221Elements.Illiteracy,
      QPP221Elements.Discharge_After_Physical_Therapy,
      QPP221Elements.Discharge_After_Occupational_Therapy,
      QPP221Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission,
      QPP221Elements.Predicted_Functional_Status_Change_Score,
      QPP221Elements.Patients_Functional_Status_Change_Score,
      QPP221Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,
      QPP221Elements.Fsa_Shoulder_Patient_Not_Eligible,
      QPP221Elements.Foto_s_Status_Survey

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population : All patients 14 years and older with shoulder impairments who have initiated rehabilitation treatment and completed the FOTO shoulder
FS outcome instrument at admission and discharge.
DENOMINATOR NOTE: *Signifies that this CPT Category I code is a non-covered service under the
Medicare Part B Physician Fee Schedule (PFS). These non-covered services should be counted in the
denominator population for registry-based measures.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
           isAgeAbove(visit,m,true,14)
        && isVisitTypeIn(visit,m,QPP221Elements.Physical_Therapy,
             QPP221Elements.Occupational_Therapy,
             QPP221Elements.Chiropractic_Manipulative_Gr,
             QPP221Elements.Follow_Up_Visit_Gr,
             QPP221Elements.Evaluation_Complete
           )
        && (
             (
                 wasEncounterPerformedBeforeOrEqualOfEncounter(visit,m,QPP221Elements.Physical_Therapy,patientHistoryBroadcastList)
              && isEncounterPerformedOnEncounter(visit,m,QPP221Elements.Discharge_After_Physical_Therapy)
              )
            || (
                    wasEncounterPerformedBeforeOrEqualOfEncounter(visit,m,QPP221Elements.Occupational_Therapy,patientHistoryBroadcastList)
                 && isEncounterPerformedOnEncounter(visit,m,QPP221Elements.Discharge_After_Occupational_Therapy)
                )
            )
        && wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,QPP221Elements.Functional_Deficit_Shoulder)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exclusions : Patient refused to participate
OR
Patient unable to complete the FOTO shoulder Intake PROM at admission and discharge  due to blindness, illiteracy,
severe mental incapacity or language incompatibility and an adequate proxy is not available
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
         (
              isCommunicationDoneFromPatientToProviderDuringEncounter(visit,m,QPP221Elements.Fsa_Shoulder_Patient_Refusal)
           || isCommunicationDoneFromPatientToProviderDuringEncounter(visit,m,QPP221Elements.Patient_Refusal)
           || isPatientCharacteristicDuringEncounter(visit,m,QPP221Elements.Unable_To_Complete_The_Foto_Shoulder_Intake_Prom)
           || isCommunicationDoneFromPatientToProviderDuringEncounter(visit,m,QPP221Elements.An_Adequate_Proxy_Is_Not_Available)
           || isDiagnosisOnEncounter(visit,m,QPP221Elements.Severe_Mental_Incapacity_Or_Language_Incompatibility)
         )
      || (
              wasDiagnosisInHistory(visit,m,QPP221Elements.Blindness,patientHistoryBroadcastList)
           || wasPatientCharacteristicInHistory(visit,m,QPP221Elements.Illiteracy,patientHistoryBroadcastList)
           || wasDiagnosisInHistory(visit,m,QPP221Elements.Psychotic_Disorder_Or_Related_Condition,patientHistoryBroadcastList)
          )
      )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator : Patients who were presented with the FOTO Shoulder Functional Status measure at Admission (Intake)
and Discharge (Status) for the purpose of calculating the patient’s Risk-adjusted Functional Status Change Residual Score
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
          (
                wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Discharge_After_Physical_Therapy,QPP221Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.GREATER,patientHistoryBroadcastList)
            ||  wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Discharge_After_Physical_Therapy,QPP221Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.EQUAL,patientHistoryBroadcastList)
            ||  wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Discharge_After_Physical_Therapy,QPP221Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.LESS,patientHistoryBroadcastList)
          )
          ||
          (
                  isAssessmentPerformedDuringEncounter(visit,m,QPP221Elements.Patients_Functional_Status_Score_At_Admission)
              &&  isAssessmentPerformedDuringEncounter(visit,m,QPP221Elements.Patients_Functional_Status_Score_At_Discharge)
              &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission,QPP221Elements.Discharge_After_Physical_Therapy,patientHistoryBroadcastList)
              &&  (
                    isAssessmentPerformedDuringEncounter(visit,m,QPP221Elements.Predicted_Functional_Status_Change_Score)
                  )
              &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,QPP221Elements.Discharge_After_Physical_Therapy,patientHistoryBroadcastList)
            )
          ||
          (
                  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Patients_Functional_Status_Change_Score,QPP221Elements.Discharge_After_Physical_Therapy,patientHistoryBroadcastList)
              &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Predicted_Functional_Status_Change_Score,QPP221Elements.Discharge_After_Physical_Therapy,patientHistoryBroadcastList)
              &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,QPP221Elements.Discharge_After_Physical_Therapy,patientHistoryBroadcastList)
            )
          ||  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Fsa_Shoulder,QPP221Elements.Discharge_After_Physical_Therapy,patientHistoryBroadcastList)
       )
     ||
      (
        (
          wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Discharge_After_Occupational_Therapy,QPP221Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.GREATER,patientHistoryBroadcastList)
            ||  wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Discharge_After_Occupational_Therapy,QPP221Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.EQUAL,patientHistoryBroadcastList)
            ||  wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Discharge_After_Occupational_Therapy,QPP221Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,0,CompareOperator.LESS,patientHistoryBroadcastList)
          )
          ||
          (
            isAssessmentPerformedDuringEncounter(visit,m,QPP221Elements.Patients_Functional_Status_Score_At_Admission)
              &&  isAssessmentPerformedDuringEncounter(visit,m,QPP221Elements.Patients_Functional_Status_Score_At_Discharge)
              &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission,QPP221Elements.Discharge_After_Occupational_Therapy,patientHistoryBroadcastList)
              &&  (
                    isAssessmentPerformedDuringEncounter(visit,m,QPP221Elements.Predicted_Functional_Status_Change_Score)
                  )
              &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,QPP221Elements.Discharge_After_Occupational_Therapy,patientHistoryBroadcastList)
            )
          ||
          (
            wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Patients_Functional_Status_Change_Score,QPP221Elements.Discharge_After_Occupational_Therapy,patientHistoryBroadcastList)
              &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Predicted_Functional_Status_Change_Score,QPP221Elements.Discharge_After_Occupational_Therapy,patientHistoryBroadcastList)
              &&  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,QPP221Elements.Discharge_After_Occupational_Therapy,patientHistoryBroadcastList)
            )
          ||  wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Fsa_Shoulder,QPP221Elements.Discharge_After_Occupational_Therapy,patientHistoryBroadcastList)
        )

      && ! isAssesmentPerformedDuringEncounter(visit,m,QPP221Elements.Fsa_Shoulder_Reason_Not_Specified)
     )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exceptions : Risk Adjusted Functional Status Change Residual Scores for the shoulder not measured because the
patient did not complete FOTO’s Status Survey near discharge, Not Appropriate
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
             wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Fsa_Shoulder_Patient_Not_Eligible,AdminElements.Encounter_Date,patientHistoryBroadcastList)
          || wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit,m,QPP221Elements.Foto_s_Status_Survey,AdminElements.Encounter_Date,patientHistoryBroadcastList)
          || isAssesmentPerformedDuringEncounter(visit,m,QPP221Elements.Fsa_Shoulder_Patient_Not_Eligible)
          || isAssesmentPerformedDuringEncounter(visit,m,QPP221Elements.Foto_s_Status_Survey)
      )
  }
}

