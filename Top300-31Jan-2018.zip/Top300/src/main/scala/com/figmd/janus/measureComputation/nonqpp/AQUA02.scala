package com.figmd.janus.measureComputation.nonqpp



import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AQUA02
* Measure Title              :- Prostate Cancer: Documentation of extent of biopsy involvement in the MD note
* Measure Description        :- Percentage of patients newly diagnosed with Prostate Cancer with documentation of extent of biopsy involvement
*                               (Number of cores positive / number of total cores) in the MD notes after diagnosis and before treatment.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object AQUA02 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "AQUA02"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val hisrotyRDD = getPatientHistory(sparkSession, initialRDD,

      AQUA02Elements.Trus_Biopsy,AQUA02Elements.Trus_Biopsy_Md_Notes,AQUA02Elements.Mri_Targeted_Biopsy,AQUA02Elements.Mri_Targeted_Biopsy_Md_Notes


    )


    var least_recent_patient_history_list = leastRecentPatientList(hisrotyRDD,

    AQUA02Elements.External_Beam_Radiotherapy,
    AQUA02Elements.Gold__Fiducial_Marker,
    AQUA02Elements.Interstitial_Prostate_Brachytherapy,
    AQUA02Elements.Cryotherapy,
    AQUA02Elements.Radical_Prostatectomy,
    AQUA02Elements.Adt,
    AQUA02Elements.Watchful_Waiting,
    AQUA02Elements.Active_Surveillance,
     AQUA02Elements.Documentation_Of_Ebrt_In_Md_Notes,
       AQUA02Elements.Gold__Fiducial_Markers_In_Md_Notes,
     AQUA02Elements.Documentation_Of_Brachytherapy_In_Md_Notes,
     AQUA02Elements.Documentation_Of_Cryotherapy_In_Md_Notes,
      AQUA02Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,
      AQUA02Elements.Adt_Md_Notes,
      AQUA02Elements.Watchful_Waiting_Md_Notes,
       AQUA02Elements.Active_Surveillance_Md_Notes)



    var leastRecentpatientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(least_recent_patient_history_list)

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(hisrotyRDD.collect().toList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList,leastRecentpatientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryList,leastRecentpatientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }
  }




  //Number of newly diagnosed Prostate Cancer patients
  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
                                isPatientAdult(visit,m)
                            &&  isMale(visit,m)
                            &&  wasFirstDiagnosed(visit,m,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                            &&  (
                                      isProcedurePerformed(visit,m,AQUA02Elements.Trus_Biopsy,patientHistoryBroadcastList)
                                  ||  isProcedurePerformed(visit,m,AQUA02Elements.Trus_Biopsy_Md_Notes,patientHistoryBroadcastList)
                                )
                            &&  (
                                  (
                                      (
                                            wasFirstProcedurePerformed(visit,m,AQUA02Elements.External_Beam_Radiotherapy,leastRecentpatientHistoryList)
                                        ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Gold__Fiducial_Marker,leastRecentpatientHistoryList)
                                        ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Interstitial_Prostate_Brachytherapy,leastRecentpatientHistoryList)
                                        ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Cryotherapy,leastRecentpatientHistoryList)
                                        ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Radical_Prostatectomy,leastRecentpatientHistoryList)
                                        ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Adt,leastRecentpatientHistoryList)
                                        ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Watchful_Waiting,leastRecentpatientHistoryList)
                                        ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Active_Surveillance,leastRecentpatientHistoryList)
                                      )
                                  &&
                                      (
                                            wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.External_Beam_Radiotherapy,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                        ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Gold__Fiducial_Marker,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                        ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Interstitial_Prostate_Brachytherapy,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                        ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Cryotherapy,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                        ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Radical_Prostatectomy,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                        ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Adt,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                        ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Watchful_Waiting,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                        ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Active_Surveillance,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                      )
                                  )
                                  ||
                                    (
                                        (
                                              wasFirstProcedurePerformed(visit,m,AQUA02Elements.Documentation_Of_Ebrt_In_Md_Notes,leastRecentpatientHistoryList)
                                          ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Gold__Fiducial_Markers_In_Md_Notes,leastRecentpatientHistoryList)
                                          ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Documentation_Of_Brachytherapy_In_Md_Notes,leastRecentpatientHistoryList)
                                          ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Documentation_Of_Cryotherapy_In_Md_Notes,leastRecentpatientHistoryList)
                                          ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,leastRecentpatientHistoryList)
                                          ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Adt_Md_Notes,leastRecentpatientHistoryList)
                                          ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Watchful_Waiting_Md_Notes,leastRecentpatientHistoryList)
                                          ||  wasFirstProcedurePerformed(visit,m,AQUA02Elements.Active_Surveillance_Md_Notes,leastRecentpatientHistoryList)
                                        )
                                        &&
                                        (
                                               wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Documentation_Of_Ebrt_In_Md_Notes,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                            ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Gold__Fiducial_Markers_In_Md_Notes,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                            ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Documentation_Of_Brachytherapy_In_Md_Notes,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                            ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Documentation_Of_Cryotherapy_In_Md_Notes,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                            ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                            ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Adt_Md_Notes,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                            ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Watchful_Waiting_Md_Notes,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                            ||  wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,AQUA02Elements.Active_Surveillance_Md_Notes,AQUA02Elements.Prostate_Cancer_New,leastRecentpatientHistoryList)
                                          )
                                    )


                                  )
                      )
  }

  def getExclusion(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    rdd.filter(visit =>
                        isProcedurePerformed(visit,m,AQUA02Elements.Mri_Targeted_Biopsy,patientHistoryBroadcastList)
                    ||  isProcedurePerformed(visit,m,AQUA02Elements.Mri_Targeted_Biopsy_Md_Notes,patientHistoryBroadcastList)
                  )

  }


  //Women undergoing revision surgery within 12 months of primary surgery
  def getMet(ippRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>



                        (
                              wasAssessmentPerformedAfterDiagnosis(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,patientHistoryBroadcastList,AQUA02Elements.Prostate_Cancer_New)
                          &&  (
                                    (
                                          wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                    )
                                  &&
                                    (
                                            wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                        ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Extent_Of_Biopsy_Involvement_Md_Notes,AQUA02Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                                    )

                              )
                         )
                        &&(
                            (
                                  wasProcedureAfterDiagnosis(visit,m,AQUA02Elements.Prostate_Cancer_New,patientHistoryBroadcastList,AQUA02Elements.Positive_Cores_Md_Notes)
                              &&  wasProcedureAfterDiagnosis(visit,m,AQUA02Elements.Prostate_Cancer_New,patientHistoryBroadcastList,AQUA02Elements.Total_Biopsy_Cores_Md_Notes)
                            )
                          &&
                              (
                                (
                                        wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Positive_Cores_Md_Notes,AQUA02Elements.External_Beam_Radiotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Positive_Cores_Md_Notes,AQUA02Elements.Gold__Fiducial_Marker,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Positive_Cores_Md_Notes,AQUA02Elements.Interstitial_Prostate_Brachytherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Positive_Cores_Md_Notes,AQUA02Elements.Cryotherapy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Positive_Cores_Md_Notes,AQUA02Elements.Radical_Prostatectomy,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Positive_Cores_Md_Notes,AQUA02Elements.Adt,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Positive_Cores_Md_Notes,AQUA02Elements.Watchful_Waiting,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                    ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Positive_Cores_Md_Notes,AQUA02Elements.Active_Surveillance,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                  )
                                  &&
                                  (
                                          wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Total_Biopsy_Cores_Md_Notes,AQUA02Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Total_Biopsy_Cores_Md_Notes,AQUA02Elements.Gold__Fiducial_Markers_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Total_Biopsy_Cores_Md_Notes,AQUA02Elements.Documentation_Of_Brachytherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Total_Biopsy_Cores_Md_Notes,AQUA02Elements.Documentation_Of_Cryotherapy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Total_Biopsy_Cores_Md_Notes,AQUA02Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Total_Biopsy_Cores_Md_Notes,AQUA02Elements.Adt_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Total_Biopsy_Cores_Md_Notes,AQUA02Elements.Watchful_Waiting_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)
                                      ||  wasAssessmentPerformedBeforeFirstProcedure(visit,m,AQUA02Elements.Total_Biopsy_Cores_Md_Notes,AQUA02Elements.Active_Surveillance_Md_Notes,patientHistoryBroadcastList,leastRecentpatientHistoryList)

                                    )

                              )

                        )

    )
  }

}