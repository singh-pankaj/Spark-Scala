package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm156V7
* Measure Title              :- Use of High-Risk Medications in the Elderly
* Measure Description        :- Percentage of patients 65 years of age and older who were ordered high-risk medications.
*                               Two rates are reported.
*                               a. Percentage of patients who were ordered at least one high-risk medication.
*                               b. Percentage of patients who were ordered at least two of the same high-risk medications.
*                               This class takes care of the measuring rate a. - at least one high-risk medication.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 1
* Measure Stratification     :- 1
* Measure Developer          :- Sumant Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm156V7_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm156V7_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    var patientHistoryRDD = getPatientHistory(sparkSession,initialRDD
      , ECQM156V7Elements.Office_Visit
      , ECQM156V7Elements.Ophthalmologic_Outpatient_Visit
      , ECQM156V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
      , ECQM156V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
      , ECQM156V7Elements.Annual_Wellness_Visit
      , ECQM156V7Elements.Home_Healthcare_Services
      , ECQM156V7Elements.Discharge_Services___Nursing_Facility
      , ECQM156V7Elements.Nursing_Facility_Visit
      , ECQM156V7Elements.Care_Services_In_Long_Term_Residential_Facility
      , ECQM156V7Elements.Encounter_Inpatient
      , ECQM156V7Elements.Discharged_To_Home_For_Hospice_Care
      , ECQM156V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care
      , ECQM156V7Elements.Hospice_Care_Ambulatory
      , ECQM156V7Elements.High_Risk_Medications_With_Days_Supply_Criteria
      , ECQM156V7Elements.High_Risk_Medications_For_The_Elderly
      , ECQM156V7Elements.High_Risk_Medications_For_The_Elderly_Date
      , ECQM156V7Elements.High_Risk_Medications_With_Days_Supply_Criteria_Stop_Date
    )
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val medicationList = List[(String, String)]((ECQM156V7Elements.High_Risk_Medications_For_The_Elderly_Date,
                                  ECQM156V7Elements.High_Risk_Medications_With_Days_Supply_Criteria_Stop_Date))

    val medicationDurationList = sparkSession.sparkContext.broadcast(
              cumulative(patientHistoryRDD, m, medicationList, "DAY",
                          CalenderUnit.DAY, 0, "DURING"))



    val ippRDD = getIpp(initialRDD,patientHistoryList: Broadcast[List[CassandraRow]])
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exceptions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      val intermediateRDD = ippRDD.subtract(exclusionRDD)
      intermediateRDD.cache()

      // Filter Met
      val metRDD = getMet(intermediateRDD, patientHistoryList, medicationDurationList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
      medicationDurationList.destroy()

    }
  }


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
          isPatientElderly(visit, m)
        &&
          isVisitTypeIn(visit, m
                        , ECQM156V7Elements.Office_Visit
                        , ECQM156V7Elements.Ophthalmologic_Outpatient_Visit
                        , ECQM156V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
                        , ECQM156V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
                        , ECQM156V7Elements.Annual_Wellness_Visit
                        , ECQM156V7Elements.Home_Healthcare_Services
                        , ECQM156V7Elements.Discharge_Services___Nursing_Facility
                        , ECQM156V7Elements.Nursing_Facility_Visit
                        ,ECQM156V7Elements.Care_Services_In_Long_Term_Residential_Facility
                )
            )
  }


  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
        isEncounterPerformedWithDischargeStatus(visit, m, ECQM156V7Elements.Encounter_Inpatient, ECQM156V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
      ||
        isEncounterPerformedWithDischargeStatus(visit, m, ECQM156V7Elements.Encounter_Inpatient, ECQM156V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
      ||
        isInterventionOrder(visit, m, ECQM156V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
      ||
        isInterventionOrdered(visit, m, ECQM156V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
      )
  }

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], medicationDurationList : Broadcast[List[(String,String, Double)]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
          isMedicationOrdered(visit, m, patientHistoryList, ECQM156V7Elements.High_Risk_Medications_For_The_Elderly)
      ||
          getCommulativeResult(visit, m, ECQM156V7Elements.High_Risk_Medications_With_Days_Supply_Criteria, 90,
                                CompareOperator.GREATER_EQUAL, medicationDurationList)
    )
  }

}

