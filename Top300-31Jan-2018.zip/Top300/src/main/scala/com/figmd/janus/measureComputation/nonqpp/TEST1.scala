package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, TEST1Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- TEST1
* Measure Title              :- Screening for Hearing Loss in Older Adults
* Measure Description        :- Percentage of patients age 60 years and older who were screened for hearing loss.
*                              
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- RAHUL.RASURE
* Initial GIT Version/Tag(CRA):-Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object TEST1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "TEST1"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,TEST1Elements.Screening_For_Hearing_Loss,
      TEST1Elements.Comprehensive_Audiometric_Testing,
      TEST1Elements.Head_Injury,
      TEST1Elements.Ear_Trauma,
      TEST1Elements.Hearing_Impairment
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD,  patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population : All patients age 60 years and older.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
           isAgeAbove(visit,m,true,60)
        && isVisitTypeIn(visit,m,TEST1Elements.Office_Visit,
             TEST1Elements.Adult_Outpatient_Visit,
             TEST1Elements.Ambulatory_Ed_Visit,
             TEST1Elements.Nursing_Facility_Visit,
             TEST1Elements.Home_Healthcare_Services,
             TEST1Elements.Care_Services_In_Long_Term_Residential_Facility
           )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exclusions : Medical reason for not screening for hearing loss (e.g. patients who had an audiogram;
patients with an active diagnosis of deafness, hearing impairment, head or ear trauma, history of other hearing
impairment.)
-----------------------------------------------------------------------------------------------------------------------*/

  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
           wasDiagnosticStudyPerformedPerformedBeforeEncounter(visit,m,TEST1Elements.Screening_For_Hearing_Loss,patientHistoryBroadcastList)
        || wasInterventionPerformedBeforeEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,TEST1Elements.Comprehensive_Audiometric_Testing)
        || wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,TEST1Elements.Head_Injury)
        || wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,TEST1Elements.Ear_Trauma)
        || wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,TEST1Elements.Hearing_Impairment)
    )

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator : Patients who were screened for hearing loss*
*Screening for Hearing Loss:
There is no defined process for screening for hearing loss. Clinicians may use clinical tests (e.g., detection of a
whispered voice, finger rub, or watch tick), a single question (e.g., “Do you have difficulty with your hearing?”),
questionnaires (e.g., Hearing Handicap Inventory for Elderly-Screening (HHIE-S)), online screening, NHANES
survey questions, or handheld audiometric devices (e.g., the AudioScope).
-----------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
            isDiagnosticStudyPerformed(visit,m,TEST1Elements.Screening_For_Hearing_Loss,patientHistoryBroadcastList))
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exception : Patient reason for not screening for hearing loss (e.g. patient refuses to complete the
hearing screening or reports having a recent screening).
-----------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
            isDiagnosticStudyPerformed(visit,m,TEST1Elements.Patient_Refusal,patientHistoryBroadcastList)
         )

  }
}

