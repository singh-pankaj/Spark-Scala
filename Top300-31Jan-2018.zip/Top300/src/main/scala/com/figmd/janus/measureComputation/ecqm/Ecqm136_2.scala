package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Ecqm136_2
* Measure Title               :- Follow-Up Care for Children Prescribed ADHD Medication (ADD)
* Measure Description         :- Percentage of children 6-12 years of age and newly dispensed a medication for attention-deficit/
                                  hyperactivity disorder (ADHD) who had appropriate follow-up care.  Two rates are reported.
                                  b. Percentage of children who remained on ADHD medication for at least 210 days and who,
                                  in addition to the visit in the Initiation Phase, had at least two additional follow-up visits with
                                  a practitioner within 270 days (9 months) after the Initiation Phase ended.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- VRUSHALI.GHOLAP
* Initial GIT Version/Tag(CRA):-
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm136_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm136_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,ECQM136V8Elements.Adhd_Medications
      ,ECQM136V8Elements.Inpatient_Encounter
      ,ECQM136V8Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care
      ,ECQM136V8Elements.Discharge_Services__Observation_Care
      ,ECQM136V8Elements.Hospice_Care_Ambulatory
      ,ECQM136V8Elements.Narcolepsy
      ,ECQM136V8Elements.Encounter_Inpatient
      ,ECQM136V8Elements.Mental_Health_Diagnoses
      ,ECQM136V8Elements.Substance_Abuse
      ,ECQM136V8Elements.Office_Visit
      ,ECQM136V8Elements.Hospital_Observation_Care___Initial
      ,ECQM136V8Elements.Preventive_Care_Services___Group_Counseling
      ,ECQM136V8Elements.Behavioral_Health_Follow_Up_Visit
      ,ECQM136V8Elements.Preventive_Care_Services_Individual_Counseling
      ,ECQM136V8Elements.Psychotherapy_And_Pharmacologic_Management
      ,ECQM136V8Elements.Discharge_Services__Observation_Care
      ,ECQM136V8Elements.Outpatient_Consultation
      ,ECQM136V8Elements.Home_Healthcare_Services
      ,ECQM136V8Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
      ,ECQM136V8Elements.Preventive_Care__Established_Office_Visit__0_To_17
      ,ECQM136V8Elements.Psych_Visit___Diagnostic_Evaluation
      ,ECQM136V8Elements.Psych_Visit___Psychotherapy
      ,ECQM136V8Elements.Telehealth_Services
      ,ECQM136V8Elements.Telephone_Management
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    val initialADHDMedicationRDDList :List[CassandraRow] = leastRecentPatientList(patientHistoryRDD,ECQM136V8Elements.Adhd_Medications)
    val initialADHDMedicationBroadcastList : Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(initialADHDMedicationRDDList)

    val MedicationList:List[(String,String)] = List((ECQM136V8Elements.Adhd_Medications_Date,ECQM136V8Elements.Adhd_Medication_Stop_Date))
    val MedicationResult=cumulative(patientHistoryRDD, MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate),MedicationList,CalenderUnit.DAY,CalenderUnit.DAY,300,TimeOperator.AFTER)
    val MedicationResultBroadcastList: Broadcast[List[(String,String,Double)]] = sparkSession.sparkContext.broadcast(MedicationResult)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList,initialADHDMedicationBroadcastList,MedicationResultBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList,initialADHDMedicationBroadcastList,patientHistoryRDD)
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

/*-----------------------------------------------------------------------------------------------------------------------
  Initial Population 2: Children 6-12 years of age who were dispensed an ADHD medication during the Intake Period and who remained on
  the medication for at least 210 days out of the 300 days following the IPSD, and who had a visit during the measurement period.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],initialADHDMedicationBroadcastList : Broadcast[List[CassandraRow]] ,MedicationResultBroadcastList : Broadcast[List[(String,String,Double)]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

//Cumulative medication is checked after start of Measurement period, it should be checked after initial AADHD medication dispensed.
    initialRDD.filter(
      visit =>
             wasMedicationDispensedBeforeOrConcurrentStartWithInDays(visit,m,ECQM136V8Elements.Adhd_Medications,90,CalenderUnit.DAY,initialADHDMedicationBroadcastList)
          && getCommulativeResult(visit,m,ECQM136V8Elements.Adhd_Medications,210,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
          && isAgeAboveBeforeStart(visit,m,true,6,CalenderUnit.YEAR)
          && isAgeBelowBeforeStart(visit,m,false,12,CalenderUnit.YEAR)
          && isVisitTypeIn(visit,m
                    ,ECQM136V8Elements.Office_Visit
                    ,ECQM136V8Elements.Home_Healthcare_Services
                    ,ECQM136V8Elements.Preventive_Care__Established_Office_Visit__0_To_17
                    ,ECQM136V8Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17)

    )
  }

/*-----------------------------------------------------------------------------------------------------------------------
  Denominator Exclusion 2: Exclude patients diagnosed with narcolepsy at any point in their history or during the measurement period.

  Exclude patients who had an acute inpatient stay with a principal diagnosis of mental health or substance abuse during the 300 days after the IPSD.
  Exclude patients who were actively on an ADHD medication in the 120 days prior to the Index Prescription Start Date.
  Exclude patients whose hospice care overlaps the measurement period.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],initialADHDMedicationBroadcastList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
           isEncounterPerformedWithDischargeStatus(visit,m,ECQM136V8Elements.Encounter_Inpatient,ECQM136V8Elements.Discharged_To_Home_For_Hospice_Care,patientHistoryBroadcastList)
        || isEncounterPerformedWithDischargeStatus(visit,m,ECQM136V8Elements.Encounter_Inpatient,ECQM136V8Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,patientHistoryBroadcastList)
        || wasInterventionPerformedInHistory(visit,m,ECQM136V8Elements.Hospice_Care_Ambulatory,patientHistoryBroadcastList)
        || wasDiagnosedInHistory(visit,m,ECQM136V8Elements.Narcolepsy,patientHistoryBroadcastList)
        || wasEncounterperformedWithDiagnosisAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Inpatient_Encounter,ECQM136V8Elements.Mental_Health_Diagnoses,ECQM136V8Elements.Adhd_Medications,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasEncounterperformedWithDiagnosisAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Inpatient_Encounter,ECQM136V8Elements.Substance_Abuse,ECQM136V8Elements.Adhd_Medications,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasMedicationBeforeFirstElementDateInXPeriod(visit,m,CalenderUnit.DAY,120,ECQM136V8Elements.Adhd_Medications,patientHistoryBroadcastList,initialADHDMedicationBroadcastList,Seq(ECQM136V8Elements.Adhd_Medications))

    )
  }

/*-----------------------------------------------------------------------------------------------------------------------
  Numerator 2: Patients who had at least one face-to-face visit with a practitioner with prescribing authority during the Initiation Phase,
  and at least two follow-up visits during the Continuation and Maintenance Phase. One of the two visits during the Continuation and
  Maintenance Phase may be a telephone visit with a practitioner.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],initialADHDMedicationBroadcastList : Broadcast[List[CassandraRow]],patientHistoryRDD :RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    val countRDD = countElementAfterFirstOtherElementWithinRangeInHistory(patientHistoryRDD,initialADHDMedicationBroadcastList,m,CalenderUnit.DAY,31,300
                              ,ECQM136V8Elements.Office_Visit
                              ,ECQM136V8Elements.Hospital_Observation_Care___Initial
                              ,ECQM136V8Elements.Preventive_Care_Services___Group_Counseling
                              ,ECQM136V8Elements.Behavioral_Health_Follow_Up_Visit
                              ,ECQM136V8Elements.Preventive_Care_Services_Individual_Counseling
                              ,ECQM136V8Elements.Psychotherapy_And_Pharmacologic_Management
                              ,ECQM136V8Elements.Discharge_Services__Observation_Care
                              ,ECQM136V8Elements.Outpatient_Consultation
                              ,ECQM136V8Elements.Home_Healthcare_Services
                              ,ECQM136V8Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
                              ,ECQM136V8Elements.Preventive_Care__Established_Office_Visit__0_To_17
                              ,ECQM136V8Elements.Psych_Visit___Diagnostic_Evaluation
                              ,ECQM136V8Elements.Psych_Visit___Psychotherapy)


    intermediateForMet.filter(visit =>
      (    wasEncounterperformedAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Office_Visit,ECQM136V8Elements.Adhd_Medications,30,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasEncounterperformedAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Hospital_Observation_Care___Initial,ECQM136V8Elements.Adhd_Medications,30,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasEncounterperformedAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Preventive_Care_Services___Group_Counseling,ECQM136V8Elements.Adhd_Medications,30,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasEncounterperformedAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Behavioral_Health_Follow_Up_Visit,ECQM136V8Elements.Adhd_Medications,30,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasEncounterperformedAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Preventive_Care_Services_Individual_Counseling,ECQM136V8Elements.Adhd_Medications,30,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasEncounterperformedWithFacilityLocationAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Psychotherapy_And_Pharmacologic_Management,ECQM136V8Elements.Ambulatory,ECQM136V8Elements.Adhd_Medications,30,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasEncounterperformedAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Discharge_Services__Observation_Care,ECQM136V8Elements.Adhd_Medications,30,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasEncounterperformedAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Outpatient_Consultation,ECQM136V8Elements.Adhd_Medications,30,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasEncounterperformedAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Home_Healthcare_Services,ECQM136V8Elements.Adhd_Medications,30,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasEncounterperformedAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,ECQM136V8Elements.Adhd_Medications,30,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasEncounterperformedAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Preventive_Care__Established_Office_Visit__0_To_17,ECQM136V8Elements.Adhd_Medications,30,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasEncounterperformedAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Psych_Visit___Diagnostic_Evaluation,ECQM136V8Elements.Adhd_Medications,30,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
        || wasEncounterperformedAfterOrEqualFirstElementDateInXdays(visit,m,ECQM136V8Elements.Psych_Visit___Psychotherapy,ECQM136V8Elements.Adhd_Medications,30,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
      )
      &&
        ( getEncounterCountFromHistory(visit,m,2,true,countRDD)
        ||
          (
            (    wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Office_Visit,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
              || wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Hospital_Observation_Care___Initial,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
              || wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Preventive_Care_Services___Group_Counseling,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
              || wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Behavioral_Health_Follow_Up_Visit,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
              || wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Preventive_Care_Services_Individual_Counseling,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
              || wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Psychotherapy_And_Pharmacologic_Management,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
              || wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Discharge_Services__Observation_Care,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
              || wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Outpatient_Consultation,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
              || wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Home_Healthcare_Services,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
              || wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
              || wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Preventive_Care__Established_Office_Visit__0_To_17,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
              || wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Psych_Visit___Diagnostic_Evaluation,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
              || wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Psych_Visit___Psychotherapy,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
            )
          &&
            (    wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Telehealth_Services,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)
              || wasEncounterperformedAfterOrEqualFirstElementDateInRange(visit,m,ECQM136V8Elements.Telephone_Management,ECQM136V8Elements.Adhd_Medications,CalenderUnit.DAY,31,300,patientHistoryBroadcastList,initialADHDMedicationBroadcastList)

            )
          )
          )

    )
  }


}