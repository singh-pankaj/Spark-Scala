package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 279
* Measure Title              :- Sleep Apnea: Assessment of Adherence to Positive Airway Pressure Therapy
* Measure Description        :- Percentage of visits for patients aged 18 years and older with a diagnosis of obstructive sleep apnea
*                               who were prescribed positive airway pressure therapy who had documentation that adherence to positive airway pressure therapy was objectively measured.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp279 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp279"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP279Elements.Office_Visit,
      QPP279Elements.Office_Visit_Telehealth_Modifier,
      QPP279Elements.Home_Healthcare_Services,
      QPP279Elements.Home_Healthcare_Services_Telehealth_Modifier,
      QPP279Elements.Nursing_Facility_Visit,
      QPP279Elements.Nursing_Facility_Visit_Telehealth_Modifier,
      QPP279Elements.Care_Services_In_Long_Term_Residential_Facility,
      QPP279Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier,
      QPP279Elements.Obstructive_Sleep_Apnea,
      QPP279Elements.Papt_Prescribed,
      QPP279Elements.Airway_Pressure_Therapy_Prescribed,
      QPP279Elements.Pos_02,
      QPP279Elements.Adherence_To_Papt,
      QPP279Elements.Objective_Measurement_Of_Adherence_Papt,
      QPP279Elements.Papt_Reason_Not_Specified,
      QPP279Elements.Papt_Not_Done_Reason,
      QPP279Elements.Data_Not_Available_On_Machine,
      QPP279Elements.Therapy_Not_Initiated,
      QPP279Elements.No_Data_From_Cpap
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    //val mostRecentpatienthistoryRdd=mostRecentPatientList(patientHistoryRDD,ECQM145V7Elements.Heart_Rate_2)
    val mostRecentElementBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateA, patientHistoryBroadcastList, mostRecentElementBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      mostRecentElementBroadcastList.destroy()
    }
  }

  //All patients aged 18 years and older with a diagnosis of sleep apnea
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m,
        QPP279Elements.Office_Visit,
        QPP279Elements.Home_Healthcare_Services,
        QPP279Elements.Nursing_Facility_Visit,
        QPP279Elements.Care_Services_In_Long_Term_Residential_Facility

      )
        && isDiagnosisOverlapsEncounter(visit, m, patientHistoryBroadcastList, QPP279Elements.Care_Services_In_Long_Term_Residential_Facility)
        &&
        (
          isProcedurePerformed(visit, m, QPP279Elements.Papt_Prescribed, patientHistoryBroadcastList)
            || wasProcedurePerformedInHistory(visit, m, QPP279Elements.Airway_Pressure_Therapy_Prescribed, patientHistoryBroadcastList)

          )
        && !isTeleHealthModifier(visit, m,
        QPP279Elements.Office_Visit_Telehealth_Modifier,
        QPP279Elements.Home_Healthcare_Services_Telehealth_Modifier,
        QPP279Elements.Nursing_Facility_Visit_Telehealth_Modifier,
        QPP279Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
      )
        && isPOSEncounterNotPerformed(visit, m, QPP279Elements.Pos_02)
    )
  }


  //Patient visits with documentation that adherence to positive airway pressure therapy was objectively measured
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>

      (
        isProcedurePerformed(visit, m, QPP279Elements.Adherence_To_Papt, patientHistoryBroadcastList)
          || isProcedurePerformed(visit, m, QPP279Elements.Objective_Measurement_Of_Adherence_Papt, patientHistoryBroadcastList)

        )
        &&
        !isProcedurePerformed(visit, m, QPP279Elements.Papt_Reason_Not_Specified, patientHistoryBroadcastList)

    )
  }


  //Documentation of reason(s) for not objectively measuring adherence to positive airway pressure therapy (e.g., patient didn’t bring data from continuous positive airway pressure [CPAP]
  // , therapy not yet initiated, not available on machine).
  def getExceptionRDD(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], mostRecentElementBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      isProcedurePerformed(visit, m, QPP279Elements.Papt_Reason_Not_Specified, patientHistoryBroadcastList)
        ||
        (
          isAssessmentPerformed(visit, m, QPP279Elements.Data_Not_Available_On_Machine, patientHistoryBroadcastList)
            || isAssessmentPerformed(visit, m, QPP279Elements.Therapy_Not_Initiated, patientHistoryBroadcastList)
            || isAssessmentPerformed(visit, m, QPP279Elements.No_Data_From_Cpap, patientHistoryBroadcastList)

          )

    )
  }

}
