
package com.figmd.janus.measureComputation.qpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.{MeasureUpdate}
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP268Elements, AdminElements}
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP268
* Measure Title              :- Epilepsy: Counseling for Women of Childbearing Potential with Epilepsy
* Measure Description        :- All female patients of childbearing potential (12- 44 years old) diagnosed with epilepsy
                                who were counseled or referred for counseling for how epilepsy and its treatment
                                may affect contraception OR pregnancy at least once a year
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp268 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp268"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP268Elements.Epilepsy
      , QPP268Elements.Female_Patients_Unable_To_Bear_Children_Grp
      , QPP268Elements.Counseling_For_Women
      , QPP268Elements.Counselled_On_Antiseizure_Medications
      , QPP268Elements.Counselled_On_Contraception_And_Drug_Interaction
      , QPP268Elements.Counseling_On_Folic_Acid_Supplementation
      , QPP268Elements.Counseling_For_Women_Reason_Not_Specified
      , QPP268Elements.Epilepsy_Counseling__Woman_Medical_Reason
      , QPP268Elements.Counseling_Medical_Reason).collect.toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate for Met
      val intermediateMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateException = getSubtractRDD(intermediateMet, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }

  /*-----------------------------------------------------------------------------------------
   All females of childbearing potential (12-44 years old) with a diagnosis of epilepsy
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isFemale(visit, m)
        && isAgeBetween(visit, m, 12, 45)
        && wasDiagnosedWithBeforeOrEqualEncounter(visit, m, QPP268Elements.Epilepsy, patientHistoryBroadcastList)
        && isVisitTypeIn(visit, m, QPP268Elements.Office_Visit)
        && !isTeleHealthEncounterPerformed(visit, m, QPP268Elements.Office_Visit_Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP268Elements.Pos_02)
    )
  }

  /*---------------------------------------------------------------------------------------------
    Female Patients Unable to Bear Children
    ----------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      wasDiagnosedInHistory(visit, m, QPP268Elements.Female_Patients_Unable_To_Bear_Children_Grp, patientHistoryBroadcastList)
    )
  }

  /*----------------------------------------------------------------------------------------
   Female patients or caregivers counseled at least once a year about how epilepsy and its
   treatment may affect contraception OR pregnancy
   -----------------------------------------------------------------------------------------*/

  def getMet(intermediateMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateMet.filter(visit =>
      (
        isInterventionPerformed(visit, m, QPP268Elements.Counseling_For_Women, patientHistoryBroadcastList)
          ||
          (
            isInterventionPerformed(visit, m, QPP268Elements.Counselled_On_Antiseizure_Medications, patientHistoryBroadcastList)
              && isInterventionPerformed(visit, m, QPP268Elements.Counselled_On_Contraception_And_Drug_Interaction, patientHistoryBroadcastList)
            )
          ||
          (
            isInterventionPerformed(visit, m, QPP268Elements.Counselled_On_Contraception_And_Drug_Interaction, patientHistoryBroadcastList)
              && isInterventionPerformed(visit, m, QPP268Elements.Counseling_On_Folic_Acid_Supplementation, patientHistoryBroadcastList)
            )
          ||
          (
            isInterventionPerformed(visit, m, QPP268Elements.Counselled_On_Antiseizure_Medications, patientHistoryBroadcastList)
              && isInterventionPerformed(visit, m, QPP268Elements.Counseling_On_Folic_Acid_Supplementation, patientHistoryBroadcastList)
            )
        )
        && !isInterventionPerformed(visit, m, QPP268Elements.Counseling_For_Women_Reason_Not_Specified, patientHistoryBroadcastList)
    )
  }

  /*---------------------------------------------------------------------------------------------------------------------------------------------
    Documentation of medical reason(s) why counseling was not performed for women of childbearing potential with epilepsy
   ---------------------------------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      isInterventionNotDone(visit, m, QPP268Elements.Epilepsy_Counseling__Woman_Medical_Reason, patientHistoryBroadcastList)
        || isInterventionNotDone(visit, m, QPP268Elements.Counseling_Medical_Reason, patientHistoryBroadcastList)
    )
  }
}
