package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,AXON6Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AXON06
* Measure Title               :- Parkinson's: Querying About Symptoms of Autonomic Dysfunction for Patients with Parkinson’s Disease With Follow-Up
* Measure Description         :- Percentage of all patients with a diagnosis of PD (or caregivers, as appropriate) who
*                                were queried about symptoms of autonomic dysfunction* in the past 12 months and if autonomic
 *                               dysfunction identified had appropriate follow-up.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- Aanchal.Rai
* Initial GIT Version/Tag(CRA):- 1.7
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object Axon6 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "AXON6"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,AXON6Elements.Symptoms_Of_Autonomic_Dysfunction_Present
      ,AXON6Elements.Follow_Up
      ,AXON6Elements.Autonomic_Dysfunction_Present
      ,AXON6Elements.Querying_About_Symptoms_Of_Autonomic_Dysfunction
      ,AXON6Elements.Present
      ,AXON6Elements.Absent
      ,AXON6Elements.Absence_Of_Autonomic_Dysfunction
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//IPP - All patients with a diagnosis of Parkinson’s disease
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
     isDiagnosedDuringEncounter(visit, m, AXON6Elements.Parkinson_s_Disease)
     &&
     isVisitTypeIn(visit, m,AXON6Elements.Evaluation_And_Management,AXON6Elements.Nursing_Facility_Visit,AXON6Elements.Outpatient_Consultation,AXON6Elements.Home_Healthcare_Services,
                   AXON6Elements.Care_Services_In_Long_Term_Residential_Facility,AXON6Elements.Office_Visit)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//Numerator - Percentage of all patients with a diagnosis of PD (or caregivers, as appropriate) who were queried about
              symptoms of autonomic dysfunction* in the past 12 months and if autonomic dysfunction identified had appropriate follow-up.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
     (   wasAssessmentPerformedBeforeEncounterInXMonths(visit, m, AXON6Elements.Symptoms_Of_Autonomic_Dysfunction_Present, 12, patientHistoryBroadcastList)
         &&
         wasInterventionPerformedAfterAssessment(visit,m,AXON6Elements.Follow_Up,patientHistoryBroadcastList,AXON6Elements.Symptoms_Of_Autonomic_Dysfunction_Present)
         &&
         wasInterventionPerformedBeforeEncounterWithinXMonths(visit,m,AXON6Elements.Follow_Up,12,patientHistoryBroadcastList)
     )
      ||
     (   wasAssessmentPerformedBeforeEncounterInXMonths(visit, m, AXON6Elements.Autonomic_Dysfunction_Present, 12, patientHistoryBroadcastList)
         &&
         wasInterventionPerformedAfterAssessment(visit,m,AXON6Elements.Follow_Up,patientHistoryBroadcastList,AXON6Elements.Autonomic_Dysfunction_Present)
         &&
         wasInterventionPerformedBeforeEncounterWithinXMonths(visit,m,AXON6Elements.Follow_Up,12,patientHistoryBroadcastList)
     )
      ||
     (   wasAssessmentPerformedBeforeEncounterInXMonthswithresult(visit,m,AXON6Elements.Querying_About_Symptoms_Of_Autonomic_Dysfunction,12, AXON6Elements.Present,patientHistoryBroadcastList)
         &&
         wasInterventionPerformedAfterAssessmentWithResult(visit, m, AXON6Elements.Follow_Up,AXON6Elements.Present,AXON6Elements.Querying_About_Symptoms_Of_Autonomic_Dysfunction,patientHistoryBroadcastList)
         &&
         wasInterventionPerformedBeforeEncounterWithinXMonths(visit,m,AXON6Elements.Follow_Up,12,patientHistoryBroadcastList)
      )
      ||
       wasAssessmentPerformedBeforeEncounterInXMonthswithresult(visit,m,AXON6Elements.Querying_About_Symptoms_Of_Autonomic_Dysfunction,12,AXON6Elements.Absent,patientHistoryBroadcastList)
      ||
       wasAssessmentPerformedBeforeEncounterInXMonths(visit, m, AXON6Elements.Absence_Of_Autonomic_Dysfunction, 12, patientHistoryBroadcastList)
    )
  }

}
