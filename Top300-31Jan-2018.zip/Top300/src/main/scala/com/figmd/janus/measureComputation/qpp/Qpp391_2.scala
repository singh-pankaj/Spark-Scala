package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP391Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp391
* Measure Title              :- Follow-Up After Hospitalization for Mental Illness (FUH)
* Measure Description        :- The percentage of discharges for patients 6 years of age and older who were hospitalized for treatment of selected mental illness diagnoses and who had a follow-up visit with a mental health practitioner. Two rates are submitted:
                                  • The percentage of discharges for which the patient received follow-up within 7 days after discharge.
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 2
* Measure Stratification     :- 1
* Measure Developer          :- Vrushali Gholap
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp391_2 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp391_2"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      , QPP391Elements.Mental_Illness
      , QPP391Elements.Patient_Discharged__Acute_Inpatient_Setting
      , QPP391Elements.Readmission_Or_Transfer_To_Non_Acute_Facility_Regardless_Of_Principal_Diagnosis
      , QPP391Elements.Readmission_Or_Transfer_To_Acute_Facility_Principal_Diagnosis_Non_Mental_Health
      , QPP391Elements.Hospice_Services1
      , QPP391Elements.Hospice_Services_Snomedct
      , QPP391Elements.Hospice_Care
      , QPP391Elements.Follow_Up_Discharge
      , QPP391Elements.Patient_Discharged__Acute_Inpatient_Setting
      , QPP391Elements.Patient_Received_Follow_Up_Discharge
      , QPP391Elements.Follow_Up_7_Days_Mental_Illness_Not_Met
      , QPP391Elements.Follow_Up_Discharge_Medical_Reason
      , QPP391Elements.Patient_Deceased
      , QPP391Elements.Follow_Up_Mental_Illness
      , QPP391Elements.Patient_Non_Compliant
    )


    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIppRDD(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Filter Exclusion
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate for MET
      val intermediateNumerator = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateNumerator.cache()

      // Filter Met
      val metRDD = getMetRDD(intermediateNumerator, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateException = getSubtractRDD(intermediateNumerator, metRDD)
      intermediateException.cache()

      //eligible RDD
      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      denominatorRDD.cache()

      // Filter Exception
      val exceptionRDD = getExceptionRdd(intermediateException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Patients 6 years of age and older who were discharged from an acute inpatient setting (including acute care psychiatric facilities) with a principal diagnosis of mental illness on or between January 1 and December 1 of the measurement period.
----------------------------------------------------------------------------------------------------------------------------*/
  def getIppRDD(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 6)
        && isDiagnosisStartsAfterStartWithinXDays(visit, m, QPP391Elements.Mental_Illness, 335, patientHistoryBroadcastList)
        && isVisitTypeIn(visit, m, QPP391Elements.Hospital_Inpatient_Visit___Initial
        , QPP391Elements.Discharge_Services___Hospital_Inpatient
        , QPP391Elements.Subsequent_Hospital_Care
        , QPP391Elements.Critical_Care)
        && isPatientCharacteristicOnEncounter(visit, m, QPP391Elements.Patient_Alive_Acute_Inpatient_Setting_Discharge, AdminElements.Encounter_Date)
        && isEncounterPerformedInXDays(visit, m, QPP391Elements.Patient_Discharged__Acute_Inpatient_Setting, 335, patientHistoryBroadcastList)
        && !wasPatientTransferredToXDaysOnOrBeforeEncounter(visit, m, AdminElements.Encounter_Date, 30, patientHistoryBroadcastList, QPP391Elements.Readmission_Or_Transfer_To_Non_Acute_Facility_Regardless_Of_Principal_Diagnosis)
        && !wasPatientTransferredToXDaysOnOrBeforeEncounter(visit, m, AdminElements.Encounter_Date, 30, patientHistoryBroadcastList, QPP391Elements.Readmission_Or_Transfer_To_Acute_Facility_Principal_Diagnosis_Non_Mental_Health)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
Patients who use hospice services any time during the measurement period.
-------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isInterventionPerformed(visit, m, QPP391Elements.Hospice_Services1, patientHistoryBroadcastList)
        || wasInterventionPerformedOrOrderedInHistory(visit, m, QPP391Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
        || wasInterventionPerformedOrOrderedInHistory(visit, m, QPP391Elements.Hospice_Care, patientHistoryBroadcastList)

    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Patient Received Follow-Up within 7 Days from Discharge
   -------------------------------------------------------------------------------------------------------------------*/


  def getMetRDD(RDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    RDD.filter(visit =>

      (
        isInterventionPerformed(visit, m, QPP391Elements.Follow_Up_Discharge, patientHistoryBroadcastList)
          || wasInterventionPerformedAfterEncounterWithReason(visit, m, QPP391Elements.Patient_Discharged__Acute_Inpatient_Setting, QPP391Elements.Patient_Received_Follow_Up_Discharge, QPP391Elements.Mental_Illness, 7, patientHistoryBroadcastList)
        )
        && !isInterventionNotDone(visit, m, QPP391Elements.Follow_Up_7_Days_Mental_Illness_Not_Met, patientHistoryBroadcastList)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
    Clinician documented reason patient was not able to complete 7 day follow-up from acute inpatient setting discharge
    (i.e., patient death prior to follow-up visit, patient non-compliance for visit follow-up).
    -------------------------------------------------------------------------------------------------------------------*/


  def getExceptionRdd(intermediateException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      isInterventionNotDone(visit, m, QPP391Elements.Follow_Up_Discharge_Medical_Reason, patientHistoryBroadcastList)
        || wasPatientDeceasedBeforeInterventionInHistory(visit, m, QPP391Elements.Follow_Up_Discharge, patientHistoryBroadcastList, QPP391Elements.Patient_Deceased)
        || isPatientCharacteristic(visit, m, QPP391Elements.Patient_Non_Compliant, patientHistoryBroadcastList)
    )
  }
}
