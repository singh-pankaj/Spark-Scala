package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, Axon25Elements, CalenderUnit, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.joda.time.DateTime

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Axon25
* Measure Title               :- Headache: Overuse of barbiturate and opioid containing medications for primary headache disorders
* Measure Description         :- Percentage of patients age 12 years and older with a diagnosis of primary headache who were prescribed
								                 opioid or barbiturate containing medications assessed for medication overuse within the 12-month
								                 measurement period, and if identified as overusing opioid or barbiturate containing medication,
								                 treated or referred for treatment.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- PRIYANKA CHAVAN
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object Axon25 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Axon25"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,Axon25Elements.Barbiturate
      ,Axon25Elements.Opioid
      ,Axon25Elements.Overuse_Of_Medications
      ,Axon25Elements.Assessment_for_overuse_and_referral
      ,Axon25Elements.Referral_For_Treatment
      ,Axon25Elements.Treatment_For_Overuse
      ,Axon25Elements.Treatment_Failure
      ,Axon25Elements.Nsaids__Triptan__Ergot
      ,Axon25Elements.Contraindication_Primary_Headache
      ,Axon25Elements.History_of_Overuse
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val MedicationList:List[(String,String)] = List((Axon25Elements.Opioid_Date,Axon25Elements.Opioid_Stop_Date))
    val consecutiveMedicationList: List[(String, String,(DateTime, DateTime))] = getconsecutiveDateList(patientHistoryRDD: RDD[CassandraRow], m, MedicationList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList,consecutiveMedicationList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
	All patients aged 12 years and older diagnosed with a primary headache disorder and prescribed an opioid or barbiturate
	containing medication
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
            isAgeAbove(visit, m, true, 12)
        &&	isVisitTypeIn(visit, m ,Axon25Elements.Subsequent_Nursing_Facility_Visit
            ,Axon25Elements.Evaluation_And_Management
            ,Axon25Elements.Emergency_Department_Visit
            ,Axon25Elements.Inpatient_Consultation
            ,Axon25Elements.Discharge_Services___Hospital_Inpatient
            ,Axon25Elements.Subsequent_Hospital_Care
            ,Axon25Elements.Hospital_Inpatient_Visit___Initial
            ,Axon25Elements.Outpatient_Consultation
            ,Axon25Elements.Preventive_Medicine_Evaluation
            ,Axon25Elements.Ph_Encounter
            ,Axon25Elements.Hospital_Admission
            ,Axon25Elements.Office_Visit)
        && 	isDiagnosedOnEncounter(visit, m ,Axon25Elements.Primary_Headache)
        &&  (
                    isMedicationOrdered(visit, m ,patientHistoryBroadcastList,Axon25Elements.Barbiturate)
                ||  isMedicationOrdered(visit, m ,patientHistoryBroadcastList,Axon25Elements.Opioid)
            )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
	Patients assessed for opioid or barbiturate containing medication overuse within the 12 month measurement period, and
	if identified as overusing opioid or barbiturate containing medication, treatment or referral for treatment was provided.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],consecutiveMedicationList: List[(String, String,(DateTime, DateTime))]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
             isInterventionPerformed(visit, m ,Axon25Elements.Assessment_for_overuse_and_referral,patientHistoryBroadcastList)
        ||   (
                  (
                          isMedicationOrdered(visit, m ,patientHistoryBroadcastList,Axon25Elements.Barbiturate)
                     ||   isAssessmentPerformed(visit, m ,Axon25Elements.Overuse_Of_Medications,patientHistoryBroadcastList)
                     ||   medicationOrderNTimesConsecutively(visit,m,Axon25Elements.Opioid,consecutiveMedicationList)
                  )
                  &&
                  (
                          wasInterventionPerformedAfterMedicationInHistory(visit,m,Axon25Elements.Referral_For_Treatment,patientHistoryBroadcastList,Axon25Elements.Opioid)
                     ||   wasInterventionPerformedAfterMedicationInHistory(visit,m,Axon25Elements.Referral_For_Treatment,patientHistoryBroadcastList,Axon25Elements.Barbiturate)
                     ||   wasInterventionPerformedAfterAssessmentInHistory(visit,m,Axon25Elements.Referral_For_Treatment,patientHistoryBroadcastList,Axon25Elements.Overuse_Of_Medications)
                     ||   wasInterventionPerformedAfterMedicationInHistory(visit,m,Axon25Elements.Treatment_For_Overuse,patientHistoryBroadcastList,Axon25Elements.Opioid)
                     ||   wasInterventionPerformedAfterMedicationInHistory(visit,m,Axon25Elements.Treatment_For_Overuse,patientHistoryBroadcastList,Axon25Elements.Barbiturate)
                     ||   wasInterventionPerformedAfterAssessmentInHistory(visit,m,Axon25Elements.Treatment_For_Overuse,patientHistoryBroadcastList,Axon25Elements.Overuse_Of_Medications)
                  )
             )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
	Medical exception for not assessing, treating, or referring patient for treatment of opioid or barbiturate medication overuse
	(i.e., patient already assessed and treated for opioid use disorder within the last year; patient has a documented failure
	of non-opioid options and does not have an opioid use disorder; patient has contraindications to all other medications for primary headache).
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
        (
               wasAssessmentPerformedBeforeStartInXMonths(visit, m ,Axon25Elements.Overuse_Of_Medications, CalenderUnit.MONTH, 12, patientHistoryBroadcastList)
          &&  (
                       wasInterventionPerformedBeforeStartInXMonths(visit, m ,Axon25Elements.Treatment_For_Overuse, CalenderUnit.MONTH, 12, patientHistoryBroadcastList)
                  ||   wasInterventionOrderedBeforeStartInXMonths(visit, m ,Axon25Elements.Referral_For_Treatment, CalenderUnit.MONTH, 12, patientHistoryBroadcastList)
              )
        )
        ||   wasInterventionPerformedAfterInterventionInHistory(visit,m,Axon25Elements.Treatment_Failure, patientHistoryBroadcastList,Axon25Elements.Treatment_For_Overuse)
        ||   wasMedicationOrderBeforeOrEqualEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,Axon25Elements.Nsaids__Triptan__Ergot)
        ||   isAssessmentPerformedOnEncounter(visit,m,Axon25Elements.Non_Overuser)
        ||   wasMedicationAdverseEffectsBeforeOrEqualOnEncounter(visit,m,Axon25Elements.Contraindication_Primary_Headache,patientHistoryBroadcastList)
        ||   isAssessmentPerformed(visit,m,Axon25Elements.History_of_Overuse,patientHistoryBroadcastList)
    )
  }
}