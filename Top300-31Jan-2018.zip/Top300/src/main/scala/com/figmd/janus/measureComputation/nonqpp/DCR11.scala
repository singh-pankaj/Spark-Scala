package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{DCR11Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- DCR11
* Measure Title               :- Diabetes & Peripheral Artery Disease (PAD): Antiplatelet Therapy
* Measure Description         :- Percentage of patients aged 18 and older with diabetes who received antiplatelet therapy to reduce the risk of myocardial infarction, stroke, or vascular death in patients with a history of symptomatic PAD
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SHREYA_ASHTEKAR_FIGMD_COM
* Initial GIT Version/Tag(CRA):- 1.8
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object DCR11 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "DCR11"
  
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      DCR11Elements.Aspirin_Or_Clopidogrel,
      DCR11Elements.Pad___Claudication,
      DCR11Elements.Pad___Critical_Limb_Ischemia,
      DCR11Elements.History_Of_Symptomatic_Pad,
      DCR11Elements.Amputation_For_Critical_Limb_Ischemia

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>

      (
        isPatientAdult(visit,m)
          &&
          isVisitTypeIn(visit,m,DCR11Elements.Acc_Encounter_Code_Set)
        )
        &&
        (
            wasDiagnosedBeforeOrEqualEncounter(visit,m,DCR11Elements.Pad___Claudication,patientHistoryBroadcastList)
            ||
            wasDiagnosedBeforeOrEqualEncounter(visit,m,DCR11Elements.Pad___Critical_Limb_Ischemia,patientHistoryBroadcastList)
            ||
            wasProcedurePerformedBeforeOrEqualEncounter(visit,m,DCR11Elements.History_Of_Symptomatic_Pad,patientHistoryBroadcastList)
            ||
            wasProcedurePerformedBeforeOrEqualEncounter(visit,m,DCR11Elements.Amputation_For_Critical_Limb_Ischemia,patientHistoryBroadcastList)
          )
        &&
        wasDiagnosedBeforeOrEqualEncounter(visit,m,DCR11Elements.Diabetes,patientHistoryBroadcastList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        wasMedicationActiveBeforeOrEqualEncounter(visit,m,DCR11Elements.Aspirin_Or_Clopidogrel,patientHistoryBroadcastList)
        &&
        isMedicationOrderedOnEncounter(visit,m,DCR11Elements.Aspirin_Or_Clopidogrel)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
        isAssesmentPerformedDuringEncounter(visit,m,DCR11Elements.System_Reason)
        ||
        isAssesmentPerformedDuringEncounter(visit,m,DCR11Elements.Medical_Reason)
        ||
        isCommunicationDoneFromPatientToProviderDuringEncounter(visit,m,DCR11Elements.Patient_Refusal)
        ||
        isMedicationActiveDuringEncounter(visit,m,DCR11Elements.Warfarin)
        ||
        isDiagnosisOnEncounter(visit,m,DCR11Elements.Bleeding_Disorder)
        ||
        isMedicationAllergyDuringEncounter(visit,m,DCR11Elements.Allergy_To_Medication)
        ||
        isMedicationAllergyDuringEncounter(visit,m,DCR11Elements.Aspirin_Or_Clopidogrel_Allergy)
        ||
        isMedicationOrderedOnEncounter(visit,m,DCR11Elements.Lack_Of_Drug_Availibility)
        ||
        isMedicationActiveDuringEncounter(visit,m,DCR11Elements.Antiplatelet_Therapy)
        ||
        isMedicationAllergyDuringEncounter(visit,m,DCR11Elements.Allergy_Aspirin_Or_Clopidogrel)
        ||
        isMedicationActiveDuringEncounter(visit,m,DCR11Elements.Aspirin_Or_Clopidogrel)
    )
  }
}