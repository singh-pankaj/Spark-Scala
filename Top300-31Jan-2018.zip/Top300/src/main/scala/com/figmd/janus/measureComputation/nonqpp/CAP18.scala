package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,CAP18Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAP18
* Measure Title               :- Mismatch Repair (MMR) or Microsatellite Instability (MSI) Biomarker Testing to Inform Clinical Management
                                 and Treatment Decisions in Patients with Primary or Metastatic Colorectal Carcinoma
* Measure Description         :- Percentage of all primary or metastatic colorectal carcinoma surgical pathology reports that address the
                                 status of biomarker evaluation for mismatch repair (MMR) by immunohistochemistry (biomarkers MLH1, MSH2, MSH6 and PMS2),
                                 or microsatellite instability (MSI) by DNA-based testing status, or both.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMIT.SINGH
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
----------------------------------------------------------------------------------------------------------------------------*/

object CAP18 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "CAP18"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
       CAP18Elements.Metastatic_Colorectal_Cancer,
       CAP18Elements.Mmr_Or_Msi_Not_Done,
       CAP18Elements.Biopsy_Or_Resection


    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  All surgical pathology reports for primary or metastatic colorectal carcinoma in either biopsy or resection specimen
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
          isLaboratoryTestPerformedOnEncounter(visit,m,CAP18Elements.Biopsy_Or_Resection)
      &&  isDiagnosedDuringEncounter(visit,m,CAP18Elements.Metastatic_Colorectal_Cancer)


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Surgical pathology reports that contain impression or conclusion of, or recommendation for testing of MMR, MSI, or both.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
           isLaboratoryTestPerformedOnEncounter(visit,m,CAP18Elements.Mmr_Protein_Test)
      ||   isLaboratoryTestPerformedOnEncounter(visit,m,CAP18Elements.Msi_Test)
      ||   isLaboratoryTestPerformedOnEncounter(visit,m,CAP18Elements.Mmr_Or_Msi)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Documentation of reason(s) MMR, MSI, or both tests were not performed (eg., payor-related limitations, patients receiving hospice).
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
          isLaboratoryTestPerformedOnEncounter(visit,m,CAP18Elements.Mmr_Or_Msi_Not_Done)

    )
  }
}