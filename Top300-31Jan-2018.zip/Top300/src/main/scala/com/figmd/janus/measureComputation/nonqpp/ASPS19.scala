package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty,ASPS19Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- ASPS19
* Measure Title               :- Pre-surgical discussion of motivations and outcomes for patients undergoing rhinoplasty
* Measure Description         :- Percentage of patients aged 15 years and older who had a rhinoplasty procedure with whom motivation
                                  for surgery and outcome expectations were discussed and for whom the following information was documented:
                                    1. Discussion of motivations and expectations*
                                    2. Surgical goals were realistic and exclusion criteria were reviewed.
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- VRUSHALI.GHOLAP
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.8
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.8
----------------------------------------------------------------------------------------------------------------------------*/

object ASPS19 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "ASPS19"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //getPatientHistoryRDD
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD
        ,ASPS19Elements.Documentation_Of_Motivation_Of_Surgery_Grp
        ,ASPS19Elements.Outcome_Expectations_Grp
      )

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients aged 15 years and older who had a rhinoplasty procedure
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
        isAgeAbove(visit,m,true,15)
      && isVisitTypeIn(visit,m,ASPS19Elements.Ambulatory_Visit)
      && isProcedurePerformedDuringEncounter(visit,m,ASPS19Elements.Rhinoplasty)
    )
  }
/*-----------------------------------------------------------------------------------------------------------------------
  Patients with whom motivation for surgery and expectations of outcomes were discussed
  and for whom the following information was documented:
  1. Discussion of motivations and expectations*

  2. Surgical goals were realistic and exclusion criteria were reviewed

  Definitions: *Documentation of any of words motivation, expectation, realistic, or
  unrealistic AND one of the following terms or phrases will meet the measure:

  Independent /Preference/Desire/Look like/Appearance
  Size: Big(ger), small(er)

  Shape: Straight, crooked, bent, hook, hump, bump, droop, flare, wide, thin, narrow, bulbous, pug, pointy, projection, rotation, flare, round, long(er), short(er)

  Proportion/Balance: Tip, bridge, overly-prominent nostrils/nostril asymmetry, change of appearance with smiling (pulling or widening), general asymmetry

  External shaming/Ridicule/Bullying/Advice/Critical/Tease(ing)

  Self-esteem/Self-conscious

  Facial Harmony/ gender characteristics/ ethnicity

  Function: Breathe/Breathing, Repair injury, Snoring, Olfaction, Recurrent infection,

  Altered sensation, Voice change

  Realistic/Unrealistic
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
       wasCommunicationFromPatientToProviderBeforeEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,ASPS19Elements.Documentation_Of_Motivation_Of_Surgery_Grp)
    || wasCommunicationFromPatientToProviderBeforeEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,ASPS19Elements.Outcome_Expectations_Grp)
    )
  }

}
