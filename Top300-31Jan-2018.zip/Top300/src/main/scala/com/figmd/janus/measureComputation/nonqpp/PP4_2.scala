package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, PP4Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- PP4_2
* Measure Title              :- Risky Behavior Assessment or Counseling by Age 18 Years
* Measure Description        :- The percentage of adolescents with documentation of assessment or counseling for risky behavior by the age of 18 years. Four rates are reported: Risk Assessment or Counseling for Alcohol Use, Risk Assessment or Counseling for Tobacco Use, Risk Assessment or Counseling for Other Substance Use, and Risk Assessment or Counseling for Sexual Activity.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 4
* Measure Stratum No.        :- 2
* Measure Stratification     :- 4
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/

object PP4_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "PP4_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Filter denominator Exclusions
      val denominatorExclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Met rdd
      val metRDD = getMet(ippRDD)
      metRDD.cache()

      // Filter Numerator Exclusion
      val numeratorExclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, denominatorExclusionRDD, metRDD, numeratorExclusionRDD, notMetRDD, MEASURE_NAME)

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  * Adolescents with a visit who turned 18 years of age in the measurement year.
  *-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 17, CalenderUnit.YEAR)
        &&
        isAgeAboveBeforeStart(visit, m, false, 19, CalenderUnit.YEAR)
        &&
        isVisitTypeIn(visit, m, PP4Elements.Office_Visit, PP4Elements.Outpatient_Consultation, PP4Elements.Face_To_Face_Interaction, PP4Elements.Preventive_Care__Established_Office_Visit__0_To_17, PP4Elements.Preventive_Care_Initial_Office_Visit_0_To_17, PP4Elements.Home_Healthcare_Services)
    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  * Adolescents who had documentation of a Risky Behavior Assessment or Counseling By Age 18 Years.
  * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getMet(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      isAssessmentPerformedOnEncounter(visit, m, PP4Elements.Tobacco_Use_Assessment)
        && isInterventionPerformedDuringEncounter(visit, m, PP4Elements.Tobacco_Use_Cessation_Counseling)
    )
  }


}
