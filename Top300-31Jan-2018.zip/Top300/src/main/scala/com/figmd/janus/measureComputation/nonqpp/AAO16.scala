package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AAO16Elements, CalenderUnit, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO16
* Measure Title               :- Age-related Hearing Loss: Hearing Evaluation
* Measure Description         :- Percentage of patients age 60 years and older who failed a hearing screening and/or who report,
                                 suspected hearing loss who received, were ordered, or were referred for comprehensive audiometric evaluation within 4 weeks the office visit.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.RASURE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object AAO16 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO16"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,AAO16Elements.Failed_Hearing_Screening,
      AAO16Elements.Patient_Refusal,
      AAO16Elements.Hearing_Impairment,
      AAO16Elements.Audiogram,
      AAO16Elements.Comprehensive_Audiometric_Testing
      )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population :Patients 60 years and older who failed a hearing screening and/or report suspected hearing loss at the physician office visit.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
             isAgeAbove(visit,m,true,60)
          && isVisitTypeIn(visit,m,AAO16Elements.Office_Visit,
               AAO16Elements.Adult_Outpatient_Visit,
               AAO16Elements.Ambulatory_Ed_Visit
             )
          && isAssessmentPerformed(visit,m,AAO16Elements.Failed_Hearing_Screening,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator :Patients who received, were ordered, or were referred for comprehensive audiometric evaluation.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
             wasInterventionPerformedAfterAssessmentInXPeriod(visit,m,AAO16Elements.Failed_Hearing_Screening,AAO16Elements.Comprehensive_Audiometric_Testing,"WEEK",4,patientHistoryBroadcastList)
          || wasInterventionOrderedAfterAssessmentInXPeriod(visit,m,AAO16Elements.Failed_Hearing_Screening,AAO16Elements.Comprehensive_Audiometric_Testing,"WEEK",4,patientHistoryBroadcastList)
          || wasInterventionRecommendedAfterAssessmentInXPeriod(visit,m,AAO16Elements.Failed_Hearing_Screening,AAO16Elements.Comprehensive_Audiometric_Testing,"WEEK",4,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exceptions :Medical reason for not evaluating for hearing loss include patients who had an audiogram within last year;
patients with an active diagnosis of deafness, hearing impairment, head or ear trauma, history of other hearing impairment. Patient refusal.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
             isCommunicationFromPatientToProvider(visit,m,AAO16Elements.Patient_Refusal,patientHistoryBroadcastList)
          || wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,AAO16Elements.Hearing_Impairment)
          || wasInterventionPerformedBeforeEncounterInXMonths(visit,m,AAO16Elements.Audiogram,"MONTH",12,patientHistoryBroadcastList)

    )
  }
}