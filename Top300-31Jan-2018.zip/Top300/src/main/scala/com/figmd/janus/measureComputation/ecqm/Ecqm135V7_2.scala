package com.figmd.janus.measureComputation.ecqm


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, ECQM135V7Elements, _}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 135
* Measure Title              :- Heart Failure (HF): Angiotensin-Converting Enzyme (ACE) Inhibitor or Angiotensin Receptor Blocker (ARB) Therapy for Left Ventricular Systolic Dysfunction (LVSD)
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of heart failure (HF) with a current or prior left ventricular ejection fraction (LVEF) < 40%
*                               who were prescribed ACE inhibitor or ARB therapy either within a 12-month period when seen in the outpatient setting OR at each hospital discharge
* Calculation Implementation :- visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 2
* Measure Stratification     :- 2
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm135V7_2 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Ecqm135V7_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patient_history_list = getPatientHistory(sparkSession, initialRDD,
      ECQM135V7Elements.Heart_Failure,

      ECQM135V7Elements.Ejection_Fraction,
      ECQM135V7Elements.Moderate_Or_Severe_Lvsd,
      ECQM135V7Elements.Care_Services_In_Long_Term_Residential_Facility,

      ECQM135V7Elements.Patient_Provider_Interaction,
      ECQM135V7Elements.Home_Healthcare_Services,
      ECQM135V7Elements.Nursing_Facility_Visit,
      ECQM135V7Elements.Office_Visit,
      ECQM135V7Elements.Outpatient_Consultation,
      ECQM135V7Elements.Ace_Inhibitor_Or_Arb_Ingredient,

      ECQM135V7Elements.Medical_Reason,
      ECQM135V7Elements.Patient_Reason,

      ECQM135V7Elements.Patient_Reason_For_Ace_Inhibitor_Or_Arb_Decline,
      ECQM135V7Elements.Allergy_To_Ace_Inhibitor_Or_Arb,

      ECQM135V7Elements.Intolerance_To_Ace_Inhibitor_Or_Arb,
      ECQM135V7Elements.Pregnancy,
      ECQM135V7Elements.Renal_Failure_Due_To_Ace_Inhibitor,

      ECQM135V7Elements.Discharge_Services___Hospital_Inpatient).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    val patineHistoryRDD = getPatientHistory(sparkSession, initialRDD, ECQM135V7Elements.Office_Visit,
      ECQM135V7Elements.Outpatient_Consultation,
      ECQM135V7Elements.Nursing_Facility_Visit,
      ECQM135V7Elements.Care_Services_In_Long_Term_Residential_Facility,
      ECQM135V7Elements.Home_Healthcare_Services,
      ECQM135V7Elements.Patient_Provider_Interaction,
      ECQM135V7Elements.Heart_Failure)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patineHistoryRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible RDD
      val denominatorRDD = getEligibleRDD(ippRDD, patientHistoryList)
      denominatorRDD.cache()


      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateA, patientHistoryList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()

    }
  }

  //All patients aged 18 years and older with a diagnosis of heart failure
  def getIpp(initialRDD: RDD[CassandraRow], patineHistoryRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)


    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 18, CalenderUnit.YEAR)
        && isVisitTypeIn(visit, m, ECQM135V7Elements.Discharge_Services___Hospital_Inpatient)
        && isDiagnosisOverlapsEncounter(visit, m, patientHistoryList, ECQM135V7Elements.Heart_Failure)
    )
  }

  //Equals Initial Population with a current or prior LVEF < 40%
  def getEligibleRDD(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>

      (
        wasDiagnosticStudyPerformedBeforeOrEqualEncounterWithResult(visit, m, ECQM135V7Elements.Ejection_Fraction, 40, "lt", patientHistoryList)
          || wasDiagnosedBeforeEncounter(visit, m, ECQM135V7Elements.Moderate_Or_Severe_Lvsd, patientHistoryList)
          || wasDiagnosedBeforeEncounter(visit, m, ECQM135V7Elements.Left_Ventricular_Systolic_Dysfunction, patientHistoryList)

        )
    )
  }

  //Patients who were prescribed ACE inhibitor or ARB therapy either within a 12-month period when seen in the outpatient setting OR at each hospital discharge
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>

      (
        isMedicationOrderedDuringEncounter(visit, m, ECQM135V7Elements.Ace_Inhibitor_Or_Arb)
          || wasMedicationActiveInHistory(visit, m, ECQM135V7Elements.Ace_Inhibitor_Or_Arb, patientHistoryList)

        )

    )

  }

  //Documentation of medical reason(s) for not prescribing ACE inhibitor or ARB therapy (eg, hypotensive patients who are at immediate risk of cardiogenic shock, hospitalized patients who have experienced marked azotemia, allergy, intolerance, other medical reasons).
  //
  //Documentation of patient reason(s) for not prescribing ACE inhibitor or ARB therapy (eg, patient declined, other patient reasons).
  //
  //Documentation of system reason(s) for not prescribing ACE inhibitor or ARB therapy (eg, other system reasons).
  def getExceptionRDD(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>

      (
        isMedicationOrderedDuringEncounter(visit, m, ECQM135V7Elements.Medical_Reason)
          || isMedicationOrderedDuringEncounter(visit, m, ECQM135V7Elements.Patient_Reason)
          || isMedicationOrderedDuringEncounter(visit, m, ECQM135V7Elements.System_Reason_2018)
          || isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, ECQM135V7Elements.Patient_Reason_For_Ace_Inhibitor_Or_Arb_Decline)
        )
        ||
        (
          wasMedicationAllergyInHistory(visit, m, ECQM135V7Elements.Ace_Inhibitor_Or_Arb_Ingredient, patientHistoryList)
            || isDiagnosisOverlapsEncounter(visit, m, patientHistoryList, ECQM135V7Elements.Allergy_To_Ace_Inhibitor_Or_Arb)
            || wasMedicationInToleraneInHistory(visit, m, ECQM135V7Elements.Intolerance_To_Ace_Inhibitor_Or_Arb, patientHistoryList)
            || isDiagnosisOverlapsEncounter(visit, m, patientHistoryList, ECQM135V7Elements.Intolerance_To_Ace_Inhibitor_Or_Arb)
            || isDiagnosisOverlapsEncounter(visit, m, patientHistoryList, ECQM135V7Elements.Pregnancy)
            || isDiagnosisOverlapsEncounter(visit, m, patientHistoryList, ECQM135V7Elements.Renal_Failure_Due_To_Ace_Inhibitor)
          )


    )
  }


}



