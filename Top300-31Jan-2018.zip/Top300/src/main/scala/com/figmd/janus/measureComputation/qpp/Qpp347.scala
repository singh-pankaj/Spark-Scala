package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp 347
* Measure Title              :- Rate of Endovascular Aneurysm Repair (EVAR) of Small or Moderate Non-Ruptured Infrarenal
*                               Abdominal Aortic Aneurysms (AAA) Who Are Discharged Alive
* Measure Description        :- Percent of patients undergoing endovascular repair of small or moderate non-ruptured infrarenal
*                               abdominal aortic aneurysms (AAA) who are discharged alive
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp347 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp347"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP347Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa_Date
      , QPP347Elements.Infrarenal_Non_Ruptured_Aaa
      , QPP347Elements.Diameter_Of_Aortic_Aneurysm_Between_5_5_5_9_Cm
      , QPP347Elements.Diameter_Of_Aortic_Aneurysm_Of_At_Least_6_Cm
      , QPP347Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
      , QPP347Elements.Diameter_Of_Aortic_Aneurysm
      , QPP347Elements.Patient_Alive_Acute_Inpatient_Setting_Discharge
      , QPP347Elements.Discharge
      , QPP347Elements.Patient_Deceased
      , QPP347Elements.Hospitalization
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>

      isPatientAdult(visit, m)
        &&
        isProcedurePerformedDuringEncounter(visit, m, QPP347Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa)
        &&
        wasDiagnosisBeforeorEqualEncounter(visit, m, QPP347Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa_Date, QPP347Elements.Infrarenal_Non_Ruptured_Aaa, patientHistoryBroadcastList)
    )

  }


  def getExclusion(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      (
        (
          isFemale(visit, m)
            &&
            (
              wasDiagnosticStudyPerformedBeforeProcedure(visit, m
                , QPP347Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
                , patientHistoryBroadcastList
                , QPP347Elements.Diameter_Of_Aortic_Aneurysm_Between_5_5_5_9_Cm)
                ||
                wasDiagnosticStudyPerformedBeforeProcedure(visit, m
                  , QPP347Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
                  , patientHistoryBroadcastList
                  , QPP347Elements.Diameter_Of_Aortic_Aneurysm_Of_At_Least_6_Cm)
              )
          )
          ||
          (
            isMale(visit, m)
              &&
              wasDiagnosticStudyPerformedBeforeProcedure(visit, m
                , QPP347Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
                , patientHistoryBroadcastList
                , QPP347Elements.Diameter_Of_Aortic_Aneurysm_Of_At_Least_6_Cm)
            )
        )
        ||
        (
          isFemale(visit, m)
            &&
            wasDiagnosticStudyValueGreaterOrEqualBeforeProcedurePerformed(visit, m
              , QPP347Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
              , QPP347Elements.Diameter_Of_Aortic_Aneurysm
              , "ge"
              , 5.5
              , patientHistoryBroadcastList)
            &&
            wasDiagnosticStudyValueGreaterOrEqualBeforeProcedurePerformed(visit, m
              , QPP347Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
              , QPP347Elements.Diameter_Of_Aortic_Aneurysm
              , "le"
              , 5.9
              , patientHistoryBroadcastList)

          )
        ||
        (
          (
            isMale(visit, m)
              &&
              wasDiagnosticStudyValueGreaterOrEqualBeforeProcedurePerformed(visit, m
                , QPP347Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
                , QPP347Elements.Diameter_Of_Aortic_Aneurysm
                , "ge"
                , 6
                , patientHistoryBroadcastList)
            )
            ||
            (
              isFemale(visit, m)
                &&
                wasDiagnosticStudyValueGreaterOrEqualBeforeProcedurePerformed(visit, m
                  , QPP347Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
                  , QPP347Elements.Diameter_Of_Aortic_Aneurysm
                  , "ge"
                  , 6
                  , patientHistoryBroadcastList)
              )
          )
    )
  }


  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        isInterventionPerformedOnEncounter(visit, m, QPP347Elements.Discharged_Alive)
          ||
          (
            wasInterventionPerformedAfterProcedure(visit, m
              , QPP347Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa_Date
              , patientHistoryBroadcastList
              , QPP347Elements.Patient_Alive_Acute_Inpatient_Setting_Discharge)
            //&&
            //isPatientAliveBeforeDischarge(visit, m, AdminElements.Encounter_Date, patientHistoryBroadcastList, Seq(QPP347Elements.Patient_Alive_Acute_Inpatient_Setting_Discharge), QPP347Elements.Discharge)

            )
        )
        &&
        !(
          isInterventionPerformedOnEncounter(visit, m, QPP347Elements.Death_In_The_Hospital)
            ||
            (

              wasPatientExpiredAfterProcedure(visit, m, QPP347Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa_Date, patientHistoryBroadcastList, QPP347Elements.Patient_Deceased)
                ||
                (
                  wasPatientExpiredDuringEncounter(visit, m, QPP347Elements.Patient_Deceased, QPP347Elements.Hospitalization, TimeOperator.EQUAL, patientHistoryBroadcastList)
                    ||
                    isPatientExpiredBeforeDischarge(visit, m, AdminElements.Encounter_Date, patientHistoryBroadcastList, Seq(QPP347Elements.Patient_Deceased), QPP347Elements.Discharge)
                  )

              )
          )
    )
  }

}
