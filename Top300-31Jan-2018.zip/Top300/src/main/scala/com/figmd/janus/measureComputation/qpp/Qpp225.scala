package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{QPP225Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp225
* Measure Title              :- Radiology: Reminder System for Screening Mammograms
* Measure Description        :- Percentage of patients undergoing a screening mammogram whose information is entered into a reminder system with a target due date for the next mammogram
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp225 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp225"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP225Elements.Screening_Mammogram,
      QPP225Elements.Mammography_Screening,
      QPP225Elements.Contact_Information,
      QPP225Elements.Screening_Mammogram,
      QPP225Elements.Patient_Identifier,
      QPP225Elements.Target_Due_Date_Next_Mammogram,
      QPP225Elements.Information_Reminder_System
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Filter denominator Exclusions
      val denominatorExceptionRDD = getDenominatorExceptionRdd(ippRDD, patientHistoryBroadcastList)
      denominatorExceptionRDD.cache()

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //eligible initial population RDD
      val intermediateRDD = getSubtractRDD(ippRDD, denominatorExceptionRDD)

      // Met rdd
      val metRDD = getMet(intermediateRDD, patientHistoryBroadcastList)
      metRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, denominatorExceptionRDD, metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  * All patients undergoing a screening mammogram
  *-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isDiagnosedWithInHistory(visit, m, QPP225Elements.Screening_Mammogram, patientHistoryBroadcastList)
        && isProcedurePerformed(visit, m, QPP225Elements.Mammography_Screening, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  * Patients whose information is entered into a reminder system with a target due date for the next mammogram
  * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getMet(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    val seqStr: Seq[String] = Seq(QPP225Elements.Contact_Information, QPP225Elements.Screening_Mammogram, QPP225Elements.Patient_Identifier, QPP225Elements.Target_Due_Date_Next_Mammogram)
    rdd.filter(visit =>
      (
        wasInterventionPerformedInHistory(visit, m, QPP225Elements.Information_Reminder_System, patientHistoryBroadcastList)
          || wasInterventionPerformedStartAfterEndOfProcedurePerformedSatisfiedAll(visit, m, QPP225Elements.Reminder_System_Date, QPP225Elements.Mammography_Screening, patientHistoryBroadcastList, seqStr)
        )
        &&
        !wasInterventionPerformedStartAfterEndOfProcedurePerformed(visit, m, QPP225Elements.Information_Medical_Reason, patientHistoryBroadcastList, QPP225Elements.Mammography_Screening)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   Documentation of medical reason(s) for not entering patient information into a reminder system (eg, further screening mammograms are not indicated, such as patients with a limited life expectancy, other medical reason(s))
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getDenominatorExceptionRdd(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit, m, QPP225Elements.Information_Medical_Reason_Date, patientHistoryBroadcastList, QPP225Elements.Mammography_Screening)
        || wasInterventionPerformedStartAfterEndOfProcedurePerformed(visit, m, QPP225Elements.Further_Mammogram_Not_Indicated, patientHistoryBroadcastList, QPP225Elements.Mammography_Screening)
        || wasDiagnosisStartAfterEndOfProcedurePerformed(visit, m, QPP225Elements.Limited_Life_Expectancy, patientHistoryBroadcastList, QPP225Elements.Mammography_Screening)
    )
  }


}
