package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,PRIME108Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PRIME108
* Measure Title               :- Patients with Advanced Cancer Screened for Pain at Outpatient Visits
* Measure Description         :- The percentage of adult 18 and older patients with advanced solid tumor and hematologic
                                 cancers evaluated during a palliative care visit who are screened for pain at each
                                 outpatient visit or documentation that a screening was attempted.
* Calculation Implementation  :- Visit-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SANKET.DHAPTE
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.8
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.8
----------------------------------------------------------------------------------------------------------------------------*/

object PRIME108 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "PRIME108"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
                                                                        ,PRIME108Elements.Palliative_Care
                                                                        ,PRIME108Elements.Cancer_Metastatic
                                                                        ,PRIME108Elements.Metastatic_Cancer
                                                  )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Adult patients 18 and older with advanced cancer who have at least one outpatient palliative care visit.
    -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
         isPatientAdult(visit,m)
      && isInterventionPerformedInHistory(visit,m,PRIME108Elements.Palliative_Care,patientHistoryBroadcastList)
      && (
              isDiagnosedWithInHistory(visit,m,PRIME108Elements.Cancer_Metastatic,patientHistoryBroadcastList)
           || isDiagnosedWithInHistory(visit,m,PRIME108Elements.Metastatic_Cancer,patientHistoryBroadcastList)
         )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Outpatient visits from the denominator in which the patient was screened for pain.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        isInterventionPerformedOnEncounter(visit,m,PRIME108Elements.Documentation_Of_Pain_Assessment)

    )
  }

}
