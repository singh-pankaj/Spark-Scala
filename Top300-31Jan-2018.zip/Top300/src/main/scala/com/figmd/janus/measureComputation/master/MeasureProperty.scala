package com.figmd.janus.measureComputation.master

import java.util.Date

import org.joda.time.DateTime

case class MeasureProperty(MeasureName: String, ConditionType: String,quarterStartDate:DateTime,quarterEndDate:DateTime){

}
