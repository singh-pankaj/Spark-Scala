package com.figmd.janus.measureComputation.nonqpp
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ACR02Elements, CalenderUnit, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACR02
* Measure Title              :- Advanced: Functional Status Assessment for Patients with Rheumatoid Arthritis (RA)
* Measure Description        :- Percentage of patients 18 years and older with a diagnosis of rheumatoid arthritis whose functional status is assessed using a standardized measurement tool at least once during the measurement period.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/

object ACR02 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "ACR02"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      ACR02Elements.Face_To_Face_Interaction,
      ACR02Elements.Outpatient_Consultation,
      ACR02Elements.Nursing_Facility_Visit,
      ACR02Elements.Care_Services_In_Long_Term_Residential_Facility,
      ACR02Elements.Home_Healthcare_Services,
      ACR02Elements.Office_Visit
      ,ACR02Elements.Instruments_For_Screening_Purpose
      ,ACR02Elements.Functional_Status_Assessed_Using_A_Standardized_Measurement_Tool)
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patient_history_list)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      // Filter denominator Exclusions
      val denominatorExclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //eligible initial population RDD
      val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //Met initialRDD
      val metRDD = getMet(ippRDD, patientHistoryList)

      //exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, notEligibleRDD, denominatorExclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryList.unpersist()
    }

  }

  /*
  * Patients age 18 and older with a diagnosis of rheumatoid arthritis seen for two or more face-to-face encounters for RA with the same clinician during the measurement period.
  * */
  def getIpp(initialRDD: RDD[CassandraRow], patienthistoryRdd: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val countElementList: List[(String,Int)] = countElement(patienthistoryRdd,m,
      ACR02Elements.Face_To_Face_Interaction,
      ACR02Elements.Outpatient_Consultation,
      ACR02Elements.Nursing_Facility_Visit,
      ACR02Elements.Care_Services_In_Long_Term_Residential_Facility,
      ACR02Elements.Home_Healthcare_Services,
      ACR02Elements.Office_Visit
    )

    initialRDD.filter(visit=>
      isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
      &&
      getEncounterCountFromHistory(visit,m,2,true, countElementList)
    )
  }


  /*
  * Percentage of patients with functional status assessment documented once during the measurement year.  Functional status can be assessed using one of a number of valid and reliable instruments available from the medical literature.
  * */
  def getMet(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    rdd.filter(visit=>(
      isAssessmentPerformed(visit,m,ACR02Elements.Functional_Status_Assessed_Using_A_Standardized_Measurement_Tool,patientHistoryList)
      ||
      isAssessmentPerformed(visit,m,ACR02Elements.Instruments_For_Screening_Purpose,patientHistoryList)
    )&&
      !isAssessmentPerformed(visit,m,ACR02Elements.Functional_Status_Assessed_Using_A_Standardized_Measurement_Tool,patientHistoryList)
    )

  }

}
