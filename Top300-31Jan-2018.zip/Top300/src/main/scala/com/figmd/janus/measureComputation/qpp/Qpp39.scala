package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP39Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 39
* Measure Title              :- Screening for Osteoporosis for Women Aged 65-85 Years of Age
* Measure Description        :- Percentage of female patients aged 65-85 years of age who ever had a central dual-energy X-ray absorptiometry (DXA) to check for osteoporosis.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp39 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp39"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {


      //Backtracking List
      val patientHistoryList = getPatientHistory(sparkSession, ippRDD,
        QPP39Elements.Hospice_Services,
        QPP39Elements.Hospice_Services_Snomedct,
        QPP39Elements.Hospice_Care,
        QPP39Elements.Documentation_Of_Dxa,
        QPP39Elements.Documentation_Of__Dxa,
        QPP39Elements.Documentation_Of_Dxa_Reason_Not_Specified).collect.toList
      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)


      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD,patientHistoryBroadcastList,sparkSession)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateMet.cache()


      // Filter Met
      val metRDD = getMet(intermediateMet, patientHistoryBroadcastList,sparkSession)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not meate
      val notMetRDD = getSubtractRDD(intermediateMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  /*-----------------------------------------------------------------------------
  Female patients aged 65-85 years on date of encounter.
  ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isFemale(visit, m)
        && isAgeBetween(visit, m, 65, 86)
        && isVisitTypeIn(visit, m, QPP39Elements.Office_Visit)
        && !isDiagnosedWithOnEncounter(visit, m, QPP39Elements.Osteoporosis)
    )
  }

  /*-----------------------------------------------------------------------------
  Patient receiving hospice services any time during the measurement period.
  ------------------------------------------------------------------------------*/


  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]],sparkSession :SparkSession): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    val cf = ippRDD.map(z => z.getString("patientuid")).distinct().collect().toList
    val patientHistoryBroadcastList1 = patientHistoryList.value.filter( x => cf.contains(x.getString(0)))
    val patientHistoryBroadcastList2: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryBroadcastList1)


    //ippRDD.collect().filter( x => isInterventionPerformed(x, m, QPP39Elements.Hospice_Services, patientHistoryBroadcastList2))

    ippRDD.filter(visit => //patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))) &&
      isInterventionPerformed(visit, m, QPP39Elements.Hospice_Services, patientHistoryBroadcastList2)
        || (
        wasInterventionPerformedInHistory(visit, m, QPP39Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList2)
          || wasInterventionPerformedInHistory(visit, m, QPP39Elements.Hospice_Care, patientHistoryBroadcastList2)
        )
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
   The number of women who have documentation in their medical record of having received a DXA test of the hip or spine.
   ---------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateMet: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]],sparkSession :SparkSession): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    val cf = intermediateMet.map(z => z.getString("patientuid")).distinct().collect().toList
    val patientHistoryBroadcastList1 = patientHistoryList.value.filter( x => cf.contains(x.getString(0)))
    val patientHistoryBroadcastList2: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryBroadcastList1)


    intermediateMet.filter(visit =>
      (
        isDiagnosticStudyPerformed(visit, m, QPP39Elements.Documentation_Of_Dxa, patientHistoryBroadcastList2)
          || wasDiagnosticStudyPerformedBeforeOrEqualEncounter(visit, m, QPP39Elements.Documentation_Of__Dxa, patientHistoryBroadcastList2)
        )
        && !isDiagnosticStudyPerformed(visit, m, QPP39Elements.Documentation_Of_Dxa_Reason_Not_Specified, patientHistoryBroadcastList2)
    )
  }

}

