package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CompareOperator, ECQM130V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- ECQM 130
* Measure Title               :- Pneumococcal Vaccination Status for Older Adults
* Measure Description         :- Percentage of patients 65 years of age and older who have ever received a pneumococcal vaccine
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- NA
* Measure Developer           :- Sagar Kulkarni
* Initial GIT Version/Tag(CRA):-
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm130V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm130V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //getPatientHistoryList
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        ECQM130V7Elements.Discharged_To_Home_For_Hospice_Care,
        ECQM130V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
        ECQM130V7Elements.Hospice_Care_Ambulatory,
        ECQM130V7Elements.Malignant_Neoplasm_Of_Colon,
        ECQM130V7Elements.Total_Colectomy,
        ECQM130V7Elements.Colonoscopy,
        ECQM130V7Elements.Fecal_Occult_Blood_Test__Fobt_,
        ECQM130V7Elements.Flexible_Sigmoidoscopy,
        ECQM130V7Elements.Fit_Dna,
        ECQM130V7Elements.Encounter_Inpatient,
        ECQM130V7Elements.Ct_Colonography).collect().toList

      val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)


      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(denominatorRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateForNumerator = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForNumerator.cache()

      // Filter Met
      val metRDD = getMet(intermediateForNumerator, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForNumerator, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
    Patients 50-75 years of age with a visit during the measurement period
  ----------------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeBetween(visit, m, 50, CompareOperator.GREATER_EQUAL,75,CompareOperator.LESS)
        && isVisitTypeIn(visit, m,
        ECQM130V7Elements.Office_Visit,
        ECQM130V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
        ECQM130V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
        ECQM130V7Elements.Home_Healthcare_Services,
        ECQM130V7Elements.Annual_Wellness_Visit)
    )
  }
  /*-------------------------------------------------------------------------------------------------------------------------
   Patients with a diagnosis or past history of total colectomy or colorectal cancer.
  Exclude patients whose hospice care overlaps the measurement period.
  ----------------------------------------------------------------------------------------------------------------------------*/
  def getExclusionRdd(denominatorRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      isEncounterPerformedWithDischargeStatus(visit, m, ECQM130V7Elements.Encounter_Inpatient, ECQM130V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        || isEncounterPerformedWithDischargeStatus(visit, m, ECQM130V7Elements.Encounter_Inpatient, ECQM130V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        || isInterventionPerformedBeforeEnd(visit, m, ECQM130V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        || wasDiagnosedInHistory(visit, m, ECQM130V7Elements.Malignant_Neoplasm_Of_Colon, patientHistoryList)
        || wasProcedurePerformedInHistory(visit, m, ECQM130V7Elements.Total_Colectomy, patientHistoryList)

    )
  }
  /*-------------------------------------------------------------------------------------------------------------------------
  Patients with one or more screenings for colorectal cancer. Appropriate screenings are defined by any one of the following criteria:
    - Fecal occult blood test (FOBT) during the measurement period
    - Flexible sigmoidoscopy during the measurement period or the four years prior to the measurement period
  - Colonoscopy during the measurement period or the nine years prior to the measurement period
    - FIT-DNA during the measurement period or the two years prior to the measurement period
    - CT Colonography during the measurement period or the four years prior to the measurement period
  ----------------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      wasProcedurePerformedBeforeEndInXYears(visit, m, ECQM130V7Elements.Colonoscopy, 9, patientHistoryList)
        || isLaboratoryTestPerformed(visit, m, ECQM130V7Elements.Fecal_Occult_Blood_Test__Fobt_, patientHistoryList)
        || wasProcedurePerformedBeforeEndInXYears(visit, m, ECQM130V7Elements.Flexible_Sigmoidoscopy, 4, patientHistoryList)
        || wasLaboratoryTestPerformedBeforeEndInXYears(visit, m, ECQM130V7Elements.Fit_Dna, 2, patientHistoryList)
        || wasProcedurePerformedBeforeEndInXYears(visit, m, ECQM130V7Elements.Ct_Colonography, 4, patientHistoryList)
    )
  }

}