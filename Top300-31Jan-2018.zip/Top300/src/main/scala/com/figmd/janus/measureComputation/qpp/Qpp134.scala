package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP134Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 134
* Measure Title              :- Preventive Care and Screening: Screening for Depression and Follow-Up Plan
* Measure Description        :- Percentage of patients aged 12 years and older screened for depression on the date of
                                the encounter using an age appropriate standardized depression screening tool AND if
                                positive, a follow-up plan is documented on the date of the positive screen.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/



object  Qpp134  extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp134"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP134Elements.Depression_Diagnosis
      , QPP134Elements.Bipolar_Diagnosis
      , QPP134Elements.Active_Depression_Or_Bipolar_Disorder
      , QPP134Elements.Depression__Positive_And_Follow_Up_Documented
      , QPP134Elements.Depression_Negative_And_Follow_Up_Plan_Not_Required
      , QPP134Elements.Depression_Screening_Reason_Not_Specified
      , QPP134Elements.Depression_Positive_No_Follow_Up_Reason_Not_Specified
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    // Filter Exclusions
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)

      // Filter Intermediate
      val intermediateNumerator = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateNumerator.cache()

      // Filter Met
      val metRDD = getMet(intermediateNumerator, patientHistoryBroadcastList)
      metRDD.cache()


      val intermediateException = getSubtractRDD(intermediateNumerator, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateException)
      exceptionRDD.cache()

      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, ippRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }


  /*--------------------------------------------------------------------------------------------------------------------
  All patients aged 12 years and older before the beginning of the measurement period with at least one eligible
  encounter during the measurement period
  --------------------------------------------------------------------------------------------------------------------*/


  def getIpp(rdd: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
          isAgeAbove(visit,m,true,12)
       && isVisitTypeIn(visit,m
                               ,QPP134Elements.Depression_Screening__Encounter_Codes
                               ,QPP134Elements.Occupational_Therapy)
    )

  }

  /*-------------------------------------------------------------------------------------------------------------------
Patients with an active diagnosis for Depression or a diagnosis of Bipolar Disorder
-------------------------------------------------------------------------------------------------------------------*/

  def getExclusion(ippRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
         wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP134Elements.Depression_Diagnosis,patientHistoryBroadcastList)
      || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP134Elements.Bipolar_Diagnosis,patientHistoryBroadcastList)
      || isDiagnosis(visit,m,QPP134Elements.Active_Depression_Or_Bipolar_Disorder,patientHistoryBroadcastList)
    )
  }



  /*--------------------------------------------------------------------------------------------------------------------
   Patients screened for depression on the date of the encounter  using an age appropriate standardized tool
   AND if positive, a follow-up plan is documented on the date of the positive screen
   -------------------------------------------------------------------------------------------------------------------*/


  def getMet(intermediateNumerator: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateNumerator.filter(visit =>
      (
        (
           (
                 isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adolescent_Depression_Screening)
              || isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adult_Depression_Screening_Tools)
           )
        && (
                 (
                     isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adolescent_Depression_Screening)
                  && isAssessmentPerformedForScreeningOnEncounter(visit,m,QPP134Elements.Negative_Depression_Screening)
                  )
              || (
                     isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adolescent_Depression_Screening_Tools)
                  && isAssessmentPerformedForResultOnEncounter(visit,m,QPP134Elements.Negative_Screening)
                 )
            )
        &&  isAgeBelow(visit,m,false,18)
       )
     ||
        (
          (
                 isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adolescent_Depression_Screening)
              || isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adult_Depression_Screening_Tools)
            )
            &&  (
                  (
                       isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adolescent_Depression_Screening)
                    && isAssessmentPerformedForScreeningOnEncounter(visit,m,QPP134Elements.Positive_Depression_Screening)
                  )
              || (
                       isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adolescent_Depression_Screening_Tools)
                    && isAssessmentPerformedForResultOnEncounter(visit,m,QPP134Elements.Positive_Screening)
                  )
                 )
            &&  (
                    isInterventionPerformedOnEncounter(visit,m,QPP134Elements.Additional_Evaluation_For_Depression___Adolescent)
                 || isInterventionPerformedOnEncounter(visit,m,QPP134Elements.Referral_For_Depression_Adolescent)
                 || isMedicationOrderedDuringEncounter(visit,m,QPP134Elements.Depression_Medications___Adolescent)
                 || isInterventionPerformedOnEncounter(visit,m,QPP134Elements.Follow_Up_For_Depression___Adolescent)
                 || isProcedurePerformedDuringEncounter(visit,m,QPP134Elements.Suicide_Risk_Assessment)
                )
            && isAgeBelow(visit,m,false,18)
          )
      ||
         (
           (
                  isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adult_Depression_Screening)
               || isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adult_Depression_Screening_Tools)
             )
             &&  (
                   (
                       isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adult_Depression_Screening)
                    && isAssessmentPerformedForScreeningOnEncounter(visit,m,QPP134Elements.Negative_Depression_Screening)
                   )
               ||  (
                       isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adult_Depression_Screening_Tools)
                    && isAssessmentPerformedForResultOnEncounter(visit,m,QPP134Elements.Negative_Screening)
                   )
                 )
             &&  isPatientAdult(visit,m)
         )
      ||
         (
                (
                      isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adult_Depression_Screening)
                   || isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adult_Depression_Screening_Tools)
                 )
             && (
                  (
                    isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adult_Depression_Screening)
                      && isAssessmentPerformedForScreeningOnEncounter(visit,m,QPP134Elements.Positive_Depression_Screening)
                    )
                    || (
                    isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Adult_Depression_Screening_Tools)
                      && isAssessmentPerformedForResultOnEncounter(visit,m,QPP134Elements.Positive_Screening)
                    )
                  )
             &&  (
                      isInterventionPerformedOnEncounter(visit,m,QPP134Elements.Additional_Evaluation_For_Depression___Adolescent)
                   || isInterventionPerformedOnEncounter(visit,m,QPP134Elements.Referral_For_Depression_Adolescent)
                   || isMedicationOrderedDuringEncounter(visit,m,QPP134Elements.Depression_Medications___Adolescent)
                   || isInterventionPerformedOnEncounter(visit,m,QPP134Elements.Follow_Up_For_Depression___Adolescent)
                   || isProcedurePerformedDuringEncounter(visit,m,QPP134Elements.Suicide_Risk_Assessment)
                 )
             && isPatientAdult(visit,m)
         )
      || (
             isAssessmentPerformed(visit,m,QPP134Elements.Depression__Positive_And_Follow_Up_Documented,patientHistoryBroadcastList)
           || isAssessmentPerformed(visit,m,QPP134Elements.Depression_Negative_And_Follow_Up_Plan_Not_Required,patientHistoryBroadcastList)
         )
    )
   && !(
            isAssessmentPerformed(visit,m,QPP134Elements.Depression_Screening_Reason_Not_Specified,patientHistoryBroadcastList)
         || isAssessmentPerformed(visit,m,QPP134Elements.Depression_Positive_No_Follow_Up_Reason_Not_Specified,patientHistoryBroadcastList)
       )
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------
  Patient Reason(s)
  Patient refuses to participate
  OR
  Medical Reason(s)
  Patient is in an urgent or emergent situation where time is of the essence and to delay treatment would jeopardize
  the patient's health status
  OR
  Situations where the patient's functional capacity or motivation to improve may impact the accuracy of results of
  standardized depression assessment tools.  For example: certain court appointed cases or cases of delirium
  -------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateException: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    intermediateException.filter(visit =>
           isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Depression_Screening_Documented_Reason)
        || isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Medical_Or_Other_Reason_Not_Done)
        || isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Patient_Reason_Refused)
        || isCommunicationFromProviderToProviderOnEncounter(visit,m,QPP134Elements.Patient_Refusal)
        || isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Urgent_Or_Emergent_Medical_Situation)
        || isAssessmentPerformedOnEncounter(visit,m,QPP134Elements.Situation_Of_Functional_Capacity_Or_Motivation)
    )
  }

}
