package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,PP7Elements,TimeOperator,CalenderUnit,CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PP7
* Measure Title               :- Use of Multiple Concurrent Antipsychotics in Children and Adolescents (APC)
* Measure Description         :- This measure is used to assess the percentage of children and adolescents 1 to 17 years of age who were on two or more concurrent antipsychotic medications.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KIRTI_RAUT_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :-Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object PP7 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "PP7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      PP7Elements.Cariprazine,
      PP7Elements.Cariprazine_Stopdate,
      PP7Elements.Ziprasidone,
      PP7Elements.Ziprasidone_Stopdate,
      PP7Elements.Trifluoperazine,
      PP7Elements.Trifluoperazine_Stopdate,
      PP7Elements.Thiothixene,
      PP7Elements.Thiothixene_Stopdate,
      PP7Elements.Thioridazine,
      PP7Elements.Thioridazine_Stopdate,
      PP7Elements.Risperidone,
      PP7Elements.Risperidone_Stopdate,
      PP7Elements.Pimozide,
      PP7Elements.Pimozide_Stopdate,
      PP7Elements.Perphenazine,
      PP7Elements.Perphenazine_Stopdate,
      PP7Elements.Olanzapine,
      PP7Elements.Olanzapine_Stopdate,
      PP7Elements.Molindone,
      PP7Elements.Molindone_Stopdate,
      PP7Elements.Lurasidone,
      PP7Elements.Lurasidone_Stopdate,
      PP7Elements.Fluphenazine,
      PP7Elements.Fluphenazine_Stopdate,
      PP7Elements.Clozapine,
      PP7Elements.Clozapine_Stopdate,
      PP7Elements.Brexpiprazole,
      PP7Elements.Brexpiprazole_Stopdate,
      PP7Elements.Asenapine,
      PP7Elements.Asenapine_Stopdate,
      PP7Elements.Aripiprazole,
      PP7Elements.Aripiprazole_Stopdate,
      PP7Elements.Chlorpromazine,
      PP7Elements.Chlorpromazine_Stopdate,
      PP7Elements.Loxapine,
      PP7Elements.Loxapine_Stopdate,
      PP7Elements.Paliperidone,
      PP7Elements.Paliperidone_Stopdate,
      PP7Elements.Iloperidone,
      PP7Elements.Iloperidone_Stopdate,
      PP7Elements.Quetiapine,
      PP7Elements.Quetiapine_Stopdate,
      PP7Elements.Haloperidol,
      PP7Elements.Haloperidol_Stopdate

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(sparkSession,initialRDD, patientHistoryBroadcastList,patientHistoryRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Children and adolescents age 1 to 17 years as of December 31 of the measurement year with 90 days of continuous antipsychotic medication treatment during the measurement year
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(sparkSession: SparkSession,initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryRDD:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val MedicationList:List[(String,String)] = List(
      (PP7Elements.Cariprazine, PP7Elements.Cariprazine_Stopdate),
      (PP7Elements.Ziprasidone,PP7Elements.Ziprasidone_Stopdate),
      (PP7Elements.Trifluoperazine,PP7Elements.Trifluoperazine_Stopdate),
      (PP7Elements.Thiothixene,PP7Elements.Thiothixene_Stopdate),
      (PP7Elements.Thioridazine,PP7Elements.Thioridazine_Stopdate),
      (PP7Elements.Risperidone,PP7Elements.Risperidone_Stopdate),
      (PP7Elements.Pimozide,PP7Elements.Pimozide_Stopdate),
      (PP7Elements.Perphenazine,PP7Elements.Perphenazine_Stopdate),
      (PP7Elements.Olanzapine,PP7Elements.Olanzapine_Stopdate),
      (PP7Elements.Molindone,PP7Elements.Molindone_Stopdate),
      (PP7Elements.Lurasidone,PP7Elements.Lurasidone_Stopdate),
      (PP7Elements.Fluphenazine,PP7Elements.Fluphenazine_Stopdate),
      (PP7Elements.Clozapine,PP7Elements.Clozapine_Stopdate),
      (PP7Elements.Brexpiprazole,PP7Elements.Brexpiprazole_Stopdate),
      (PP7Elements.Asenapine,PP7Elements.Asenapine_Stopdate),
      (PP7Elements.Aripiprazole,PP7Elements.Aripiprazole_Stopdate),
      (PP7Elements.Chlorpromazine,PP7Elements.Chlorpromazine_Stopdate),
      (PP7Elements.Loxapine,PP7Elements.Loxapine_Stopdate),
      (PP7Elements.Paliperidone,PP7Elements.Paliperidone_Stopdate),
      (PP7Elements.Iloperidone,PP7Elements.Iloperidone_Stopdate),
      (PP7Elements.Quetiapine,PP7Elements.Quetiapine_Stopdate),
      (PP7Elements.Haloperidol,PP7Elements.Haloperidol_Stopdate)
    )


    val MedicationResult=cumulative(patientHistoryRDD, m,MedicationList,CalenderUnit.DAY,CalenderUnit.DAY,90,TimeOperator.EQUAL)

    val MedicationResultBroadcastList: Broadcast[List[(String,String,Double)]] = sparkSession.sparkContext.broadcast(MedicationResult)

    initialRDD.filter(visit =>
      isAgeBetweenBeforeStart(visit,m,1,CompareOperator.GREATER_EQUAL,18,CalenderUnit.YEAR)
        &&  isVisitTypeIn(visit,m,
        PP7Elements.Office_Visit,
        PP7Elements.Outpatient_Consultation, PP7Elements.Face_To_Face_Interaction,
        PP7Elements.Home_Healthcare_Services,
        PP7Elements.Preventive_Care_Initial_Office_Visit_0_To_17,
        PP7Elements.Preventive_Care__Established_Office_Visit__0_To_17)
        &&
        getCommulativeResult(visit,m, PP7Elements.Cariprazine, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Ziprasidone, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Trifluoperazine, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Thiothixene, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Thioridazine, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Risperidone,90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Pimozide, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Perphenazine, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Olanzapine, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Molindone, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Lurasidone, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Fluphenazine, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Clozapine, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Brexpiprazole, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Asenapine, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Aripiprazole, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Chlorpromazine, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Loxapine,90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Paliperidone, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Iloperidone, 90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Quetiapine,90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
        ||    getCommulativeResult(visit,m, PP7Elements.Haloperidol,90,CompareOperator.GREATER_EQUAL,MedicationResultBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Members on two or more concurrent antipsychotic medications for at least 90 consecutive days during the measurement year
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {


    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      wasMedicationAdministeredBeforeOrEqualInDays(visit,m,90,patientHistoryBroadcastList,
        PP7Elements.Cariprazine,
        PP7Elements.Ziprasidone,
        PP7Elements.Trifluoperazine,
        PP7Elements.Thiothixene,
        PP7Elements.Thioridazine,
        PP7Elements.Risperidone,
        PP7Elements.Pimozide,
        PP7Elements.Perphenazine,
        PP7Elements.Olanzapine,
        PP7Elements.Molindone,
        PP7Elements.Lurasidone,
        PP7Elements.Fluphenazine,
        PP7Elements.Clozapine,
        PP7Elements.Brexpiprazole,
        PP7Elements.Asenapine,
        PP7Elements.Aripiprazole,
        PP7Elements.Haloperidol,
        PP7Elements.Chlorpromazine,
        PP7Elements.Loxapine,
        PP7Elements.Paliperidone,
        PP7Elements.Quetiapine,
        PP7Elements.Iloperidone
      )
    )
  }

}
