package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP286Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp286
* Measure Title              :- Dementia: Safety Concern Screening and Follow-Up for Patients with Dementia
* Measure Description        :- Percentage of patients with dementia or their caregiver(s) for whom there was a documented safety concerns screening in two domains of risk: 1) dangerousness to self or others and 2) environmental risks; and if safety concerns screening was positive in the last 12 months, there was documentation of mitigation recommendations, including but not limited to referral to other resources.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- 1
* Measure Developer          :- Vrushali Gholap
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp286 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP286"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIppRDD(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME))
    {

      val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, ippRDD
        , QPP286Elements.Safety_Concern_Provided
        , QPP286Elements.Safety_Concern_Negative_1
        , QPP286Elements.Environmental_Risks
        , QPP286Elements.Safety_Concern_Negative_2
        , QPP286Elements.Dangerousness_To_Self__Others
        , QPP286Elements.Safety_Concern_Positive
        , QPP286Elements.Mitigation_Recommendations
        , QPP286Elements.Safety_Concern_Reason_Not_Specified
        , QPP286Elements.Safety_Concern_Referral
        , QPP286Elements.Safety_Concern_Medical_Reason
        , QPP286Elements.Palliative_Care
      )
      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMetRDD(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateException = getSubtractRDD(ippRDD, metRDD)
      intermediateException.cache()

      // Filter Exception
      val exceptionRDD = getExceptionRdd(intermediateException, patientHistoryBroadcastList)
      exceptionRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  All patients with dementia
  ----------------------------------------------------------------------------------------------------------------------------*/
  def getIppRDD(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isDiagnosedDuringEncounter(visit, m, QPP286Elements.Dementia)
        && isVisitTypeIn(visit, m, QPP286Elements.Office_Visit
        , QPP286Elements.Nursing_Facility_Visit
        , QPP286Elements.Home_Healthcare_Services
        , QPP286Elements.Care_Services_In_Long_Term_Residential_Facility
        , QPP286Elements.Health_And_Behavioral_Assessment__Reassessment
        , QPP286Elements.Health_And_Behavior_Intervention
        , QPP286Elements.Behavioral_Neuropsych_Assessment
        , QPP286Elements.Psych_Visit___Psychotherapy
        , QPP286Elements.Occupational_Therapy_Evaluation
        , QPP286Elements.Health_And_Behavioral_Assessment___Initial
        , QPP286Elements.Individual_Physician_Supervision
        , QPP286Elements.Advance_Care_Planning
        , QPP286Elements.Chronic_Care_Management
        , QPP286Elements.Discharge_Services___Hospital_Inpatient
        , QPP286Elements.Emergency_Department_Visit
        , QPP286Elements.Hospital_Inpatient_Visit_Subsequent)
        && !isTeleHealthModifier(visit, m, QPP286Elements.Office_Visit_Telehealth_Modifier
        , QPP286Elements.Nursing_Facility_Visit_Telehealth_Modifier
        , QPP286Elements.Home_Healthcare_Services_Telehealth_Modifier
        , QPP286Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
        , QPP286Elements.Health_And_Behavioral_Assessment_Reassessment_Telehealth_Modifier
        , QPP286Elements.Health_And_Behavior_Intervention_Telehealth_Modifier
        , QPP286Elements.Behavioral_Neuropsych_Assessment_Telehealth_Modifier
        , QPP286Elements.Psych_Visit___Psychotherapy_Telehealth_Modifier
        , QPP286Elements.Occupational_Therapy_Evaluation_Telehealth_Modifier
        , QPP286Elements.Health_And_Behavioral_Assessment__Initial_Telehealth_Modifier
        , QPP286Elements.Individual_Physician_Supervision_Telehealth_Modifier
        , QPP286Elements.Advance_Care_Planning_Telehealth_Modifier
        , QPP286Elements.Chronic_Care_Management_Telehealth_Modifier
        , QPP286Elements.Discharge_Services___Hospital_Inpatient_Telehealth_Modifier
        , QPP286Elements.Emergency_Department_Visit_Telehealth_Modifier
        , QPP286Elements.Hospital_Inpatient_Visit_Subsequent_Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP286Elements.Pos_02)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Patients with dementia or their caregiver(s) for whom there was a documented safety concerns screening in two domains of risk:
  1) dangerousness to self or others and
  2) environmental risks; and if safety concerns screening was positive in the last 12 months, there was documentation of mitigation recommendations, including but not limited to referral to other resources.
   -------------------------------------------------------------------------------------------------------------------*/

  def getMetRDD(RDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    RDD.filter(visit =>
      wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, QPP286Elements.Safety_Concern_Provided, 12, patientHistoryBroadcastList)
        || wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, QPP286Elements.Safety_Concern_Negative_1, 12, patientHistoryBroadcastList)
        || (wasAssessmentPerformedBeforeEncounterInXMonthswithresult(visit, m, QPP286Elements.Environmental_Risks, 12, QPP286Elements.Safety_Concern_Negative_2, patientHistoryBroadcastList)
        && wasAssessmentPerformedBeforeEncounterInXMonthswithresult(visit, m, QPP286Elements.Dangerousness_To_Self__Others, 12, QPP286Elements.Safety_Concern_Negative_2, patientHistoryBroadcastList))
        || (wasAssessmentPerformedBeforeEncounterInXMonthswithresult(visit, m, QPP286Elements.Environmental_Risks, 12, QPP286Elements.Safety_Concern_Positive, patientHistoryBroadcastList)
        && wasAssessmentPerformedBeforeEncounterInXMonthswithresult(visit, m, QPP286Elements.Dangerousness_To_Self__Others, 12, QPP286Elements.Safety_Concern_Positive, patientHistoryBroadcastList)
        && wasAssessmentPerformedBeforeEncounterInXMonths(visit, m, QPP286Elements.Mitigation_Recommendations, 12, patientHistoryBroadcastList))
        || !(wasInterventionPerformedNotDoneStartsBeforeEncounterInXMonths(visit, m, QPP286Elements.Safety_Concern_Reason_Not_Specified, 12, patientHistoryBroadcastList)
        || wasCommunicationDoneFromProviderToPatientBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP286Elements.Safety_Concern_Referral, 12, patientHistoryBroadcastList)
        )
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Documentation of medical reason(s) for not providing safety concerns screen OR for not providing recommendations, orders or referrals for positive screen
  (e.g., patient in palliative care, other medical reason)
  -------------------------------------------------------------------------------------------------------------------*/


  def getExceptionRdd(intermediateException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      wasAssessmentPerformedBeforeEncounterInXMonths(visit, m, QPP286Elements.Safety_Concern_Medical_Reason, 12, patientHistoryBroadcastList)
        || wasInterventionPerformedNotDoneStartsBeforeEncounterInXMonths(visit, m, QPP286Elements.Palliative_Care, 12, patientHistoryBroadcastList)

    )
  }
}
