package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AAO23Elements, AdminElements, CompareOperator, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO23
* Measure Title               :- Allergic Rhinitis: Intranasal Corticosteriods or Oral Antihistamines
* Measure Description         :- Percentage of patients with allergic rhinitis who are offered intranasal corticosteroids or non-sedating oral antihistamines.Percentage
* Calculation Implementation  :- Visit-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object AAO23 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO23"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,AAO23Elements.Allergic_Rhinitis_Grouping
      ,AAO23Elements.Oral_Antihistamines
      ,AAO23Elements.Intranasal_Corticosteroids
      ,AAO23Elements.Allergic_To_Oral_Antihistamines
      ,AAO23Elements.Allergic_To_Intranasal_Corticosteroids
      ,AAO23Elements.Prostate_Cancer
      ,AAO23Elements.Benign_Prostate_Hyperplasia
      ,AAO23Elements.Epistaxis
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients age 2 years and older with a diagnosis of allergic rhinitis.Patients age 2 yea
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
              isAgeAbove(visit,m,true,2)
          &&  isVisitTypeIn(visit,m,AAO23Elements.Ambulatory_Visit)
          &&  wasDiagnosisBeforeorEqualEncounter(visit,m,AdminElements.Encounter_Date,AAO23Elements.Allergic_Rhinitis_Grouping,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who are taking intranasal steroids or oral antihistamines. A prescription for or medication reconciliation of over
the counter medications can be used to identify patients taking medications.Patients
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            wasMedicationActiveBeforeEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,AAO23Elements.Oral_Antihistamines)
        &&  wasMedicationOrderBeforeOrEqualEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,AAO23Elements.Oral_Antihistamines)
        &&  wasMedicationActiveBeforeEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,AAO23Elements.Intranasal_Corticosteroids)
        &&  wasMedicationOrderBeforeOrEqualEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,AAO23Elements.Intranasal_Corticosteroids)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with an allergy to oral antihistamines or intranasal corticosteroids.

Patients with prostate cancer or benign prostatic hypertrophy as these patients may be intolerant of medications.

Patients with a history of epistaxis due to intranasal steroids use.

Patient refusalPatients with an aller
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
            wasMedicationAllergyBeforeEncounter(visit,m,AAO23Elements.Allergic_To_Oral_Antihistamines,patientHistoryBroadcastList)
        &&  wasMedicationAllergyBeforeEncounter(visit,m,AAO23Elements.Allergic_To_Intranasal_Corticosteroids,patientHistoryBroadcastList)
        &&  wasDiagnosisBeforeorEqualEncounter(visit,m,AdminElements.Encounter_Date,AAO23Elements.Prostate_Cancer,patientHistoryBroadcastList)
        &&  wasDiagnosisBeforeorEqualEncounter(visit,m,AdminElements.Encounter_Date,AAO23Elements.Benign_Prostate_Hyperplasia,patientHistoryBroadcastList)
        &&  wasDiagnosisBeforeorEqualEncounter(visit,m,AdminElements.Encounter_Date,AAO23Elements.Epistaxis,patientHistoryBroadcastList)
        &&  wasCommunicationFromPatientToProviderBeforeEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,AAO23Elements.Patient_Refusal)
    )
  }
}