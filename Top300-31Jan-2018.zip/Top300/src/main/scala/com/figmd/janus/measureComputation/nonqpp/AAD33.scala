package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AAD33Elements, AdminElements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD 33
* Measure Title              :- Basal Cell Carcinoma/Squamous Cell Carcinoma: Surgical Safety Post-Operative Bleeding
* Measure Description        :- Percentage of patients seen for bleeding or hematoma within 15 days of a surgical encounter for BCC/SCC and intervention required.
* Calculation Implementation :- Procedure Specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object AAD33 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAD33"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession,initialRDD,
      AAD33Elements.Genetic_Or_Acquired_Bleeding_Disorders,
      AAD33Elements.Bleeding,
      AAD33Elements.Hematoma,
      AAD33Elements.Hemorrhage_Or_Hematoma,
      AAD33Elements.Treatment_Beyond_Standard_Wound_Care
    ).collect.toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      /*// Filter Not Eligible
      val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      notEligibleRDD.cache()*/

      // denominator count
      val denominatorRDD = ippRDD
      denominatorRDD.cache()


      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMetRdd(intermediateA, patientHistoryList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()
    }

  }

  // IPP criteria
  def getIpp(initialRDD:RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
    isDiagnosisOnEncounter(visit, m, AAD33Elements.Bcc_Or_Scc_Grp)
      && isProcedurePerformedDuringEncounter(visit, m, AAD33Elements.Scalpel_Based_Surgery_Grp)
    )
  }

  // Denominator Exclusion criteria
  def getExclusionRdd(metRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    metRDD.filter(visit =>
    isDiagnosis(visit, m, AAD33Elements.Genetic_Or_Acquired_Bleeding_Disorders, patientHistoryList)
    )
  }

  // Met criteria
  def getMetRdd(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      wasProcedurePerformedXDaysAfterProcedure(visit, m, AAD33Elements.Scalpel_Based_Surgery_Grp, AAD33Elements.Bleeding, 15, patientHistoryList)
      || wasProcedurePerformedXDaysAfterProcedure(visit, m, AAD33Elements.Scalpel_Based_Surgery_Grp, AAD33Elements.Hematoma, 15, patientHistoryList)
      || wasProcedurePerformedXDaysAfterProcedure(visit, m, AAD33Elements.Scalpel_Based_Surgery_Grp, AAD33Elements.Hemorrhage_Or_Hematoma, 15, patientHistoryList)
      || wasProcedurePerformedXDaysAfterProcedure(visit, m, AAD33Elements.Scalpel_Based_Surgery_Grp, AAD33Elements.Treatment_Beyond_Standard_Wound_Care, 15, patientHistoryList)
      )
  }
}
