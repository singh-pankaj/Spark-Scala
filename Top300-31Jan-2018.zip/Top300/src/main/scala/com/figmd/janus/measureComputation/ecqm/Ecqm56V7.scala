package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, ECQM56V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- ECQM56V7
* Measure Title               :- Functional Status Assessment for Total Hip Replacement
* Measure Description         :- Percentage of patients 18 years of age and older who received an elective primary total hip arthroplasty (THA)
                                 and completed a functional status assessment within 90 days prior to the surgery and in the 270-365 days after the surgery.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SHREYA_ASHTEKAR
* Initial GIT Version/Tag(CRA):- 1.8
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm56V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "ECQM56V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      ECQM56V7Elements.Primary_Tha_Procedure,
      ECQM56V7Elements.Discharged_To_Home_For_Hospice_Care,
      ECQM56V7Elements.Encounter_Inpatient,
      ECQM56V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
      ECQM56V7Elements.Hospice_Care_Ambulatory,
      ECQM56V7Elements.Fracture___Lower_Body,
      ECQM56V7Elements.Severe_Dementia,
      ECQM56V7Elements.Total_Hip_Arthroplasty_Complete_Functional_Assesment

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population :
Patients 19 years of age and older who had a primary total hip arthroplasty (THA) in the year prior to the measurement period and who had an outpatient encounter during the measurement period
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
        isAgeAbove(visit,m,true,19)
      &&
          WasProcedurePerformStartBeforeXMonths(visit,m,ECQM56V7Elements.Primary_Tha_Procedure, CalenderUnit.MONTH,12,patientHistoryBroadcastList)
      &&
      (
        isVisitTypeIn(visit,m,
          ECQM56V7Elements.Outpatient_Consultation,
          ECQM56V7Elements.Office_Visit,
          ECQM56V7Elements.Postoperative_Visit)
      )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exclusions
Patients with two or more fractures indicating trauma at the time of the total hip arthroplasty or patients with severe cognitive impairment that overlaps measurement period.
Exclude patients whose hospice care overlaps the measurement period.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      isEncounterPerformedWithDischargeStatus(visit,m,ECQM56V7Elements.Encounter_Inpatient,ECQM56V7Elements.Discharged_To_Home_For_Hospice_Care,patientHistoryBroadcastList)
      ||
      isEncounterPerformedWithDischargeStatus(visit,m,ECQM56V7Elements.Encounter_Inpatient,ECQM56V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,patientHistoryBroadcastList)
      ||
      (
        wasInterventionPerformedInHistory(visit,m,ECQM56V7Elements.Hospice_Care_Ambulatory,patientHistoryBroadcastList)
        ||
        isInterventionOrder(visit,m,ECQM56V7Elements.Hospice_Care_Ambulatory,patientHistoryBroadcastList)
      )
      ||
      (
        getDiagnoisisCountBeforeEncounter(visit,m,ECQM56V7Elements.Primary_Tha_Procedure,ECQM56V7Elements.Fracture___Lower_Body,CalenderUnit.DAY, 1, 2, "ge", patientHistoryBroadcastList)
      )
      ||
      wasDiagnosedInHistory(visit,m,ECQM56V7Elements.Severe_Dementia,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator:
Patients with patient-reported functional status assessment results (i.e., VR-12, PROMIS-10-Global Health, HOOS, HOOS Jr.) in the 90 days prior to or on the day of the primary THA procedure, and in the 270 - 365 days after THA procedure
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      wasAssessmentPerformedBeforeWithinXPeriod(visit,m,ECQM56V7Elements.Primary_Tha_Procedure,ECQM56V7Elements.Total_Hip_Arthroplasty_Complete_Functional_Assesment,CalenderUnit.DAY, 90, patientHistoryBroadcastList)
      &&
      wasAssessmentPerformedAfterProcedureInBetweenXPeriodes(visit, m, ECQM56V7Elements.Total_Hip_Arthroplasty_Complete_Functional_Assesment, ECQM56V7Elements.Primary_Tha_Procedure, CalenderUnit.DAY, 270, CalenderUnit.DAY, 365, patientHistoryBroadcastList)
    )
  }
}