package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP185Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp 185
* Measure Title              :- Colonoscopy Interval for Patients with a History of Adenomatous Polyps – Avoidance of Inappropriate Use
* Measure Description        :- Percentage of patients aged 18 years and older receiving a surveillance colonoscopy,with a history of a  prior adenomatous polyp(s) in previous colonoscopy findings, which had an interval of 3 or more years since their last colonoscopy
* Calculation Implementation :- Procedure specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp185 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp185"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP185Elements.Surveillance_Colonoscopy,
      QPP185Elements.History_Of_Adenomatous_Colonic_Polyps,
      QPP185Elements.Crohns_Disease,
      QPP185Elements.Ulcerative_Colitis,
      QPP185Elements.Lower_Gastrointestinal_Bleeding,
      QPP185Elements.Personal_Or_Family_History_Of_Colon_Cancer
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateRdd = getSubtractRDD(ippRDD, metRDD)

      // Filter not Exception
      val exceptionRDD = getException(intermediateRdd, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRdd, exceptionRDD)
      notMetRDD.cache()
      //
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /* All patients aged 18 years and older receiving a surveillance colonoscopy during measurement period, with a history of a prior adenomatous polyp(s) in previous colonoscopy findings. */

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isProcedurePerformedDuringEncounter(visit, m, QPP185Elements.Surveillance_Colonoscopy)
        && isDiagnosedBeforeProcedure(visit, m, QPP185Elements.Surveillance_Colonoscopy, patientHistoryBroadcastList, QPP185Elements.History_Of_Adenomatous_Colonic_Polyps)
        && wasProcedurePerformedBeforeOtherProcedure(visit, m, QPP185Elements.Surveillance_Colonoscopy, patientHistoryBroadcastList, QPP185Elements.Surveillance_Colonoscopy)
        && !isVisitTypeIn(visit, m, QPP185Elements.Colonoscopy_52_53_73_74)
    )
  }


  // Numerator criteria
  /* Patients who had an interval of 3 or more years since their last colonoscopy */

  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ipp.filter(visit =>
      (
        isProcedurePerformedDuringEncounter(visit, m, QPP185Elements.Colonoscopy)
          || isProcedurePerformedBeforeOtherProcedureInXYears(visit, m, QPP185Elements.Surveillance_Colonoscopy, 3, patientHistoryBroadcastList, QPP185Elements.Surveillance_Colonoscopy)
        )
        && !isAssessmentPerformedOnEncounter(visit, m, QPP185Elements.Clnscpy_Reason_Not_Specified)
    )
  }

  // Exception criteria
  /* Documentation of medical reason(s) for an interval of less than 3 years since the last colonoscopy (eg, last colonoscopy incomplete, last colonoscopy had inadequate prep, piecemeal removal of adenomas, last colonoscopy found greater than 10 adenomas, or patient at high risk for colon cancer [Crohn’s disease, ulcerative colitis, lower gastrointestinal bleeding, personal or family history of colon cancer])
                                                                   OR
Documentation of system reason(s) for an interval of less than 3 years since the last colonoscopy (eg, unable to locate previous colonoscopy report, previous colonoscopy report was incomplete)*/

  def getException(intermediate: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediate.filter(visit =>
      isAssessmentPerformedOnEncounter(visit, m, QPP185Elements.Clnscpy_System_Reason)
        || !isAssessmentPerformedOnEncounter(visit, m, QPP185Elements.Clnscpy_Medical_Reason)
        || ((isDignosedBeforeProcedureInXYears(visit, m, QPP185Elements.Surveillance_Colonoscopy, 3, patientHistoryBroadcastList, QPP185Elements.Crohns_Disease, QPP185Elements.Ulcerative_Colitis, QPP185Elements.Lower_Gastrointestinal_Bleeding, QPP185Elements.Personal_Or_Family_History_Of_Colon_Cancer)
        || isProcedurePerformedBeforeOtherProcedureInXYears(visit, m, QPP185Elements.Surveillance_Colonoscopy, 3, patientHistoryBroadcastList, QPP185Elements.Incomplete_Colonoscopy)
        )
        &&
        (isDignosedAfterProcedureInXYears(visit, m, QPP185Elements.Surveillance_Colonoscopy, 3, patientHistoryBroadcastList, QPP185Elements.Crohns_Disease, QPP185Elements.Ulcerative_Colitis, QPP185Elements.Lower_Gastrointestinal_Bleeding, QPP185Elements.Personal_Or_Family_History_Of_Colon_Cancer)
          || isProcedurePerformedAfterOtherProcedureInXYears(visit, m, QPP185Elements.Surveillance_Colonoscopy, 3, patientHistoryBroadcastList, QPP185Elements.Incomplete_Colonoscopy)
          )
        )
    )
  }


}
