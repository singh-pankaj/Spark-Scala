package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.{Measure, MeasureUpdate}
import com.figmd.janus.measureComputation.master.{ACEP40Elements, AdminElements, MeasureProperty}
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACEP 40_1
* Measure Title              :- ED Median Time from ED arrival to ED departure for discharged ED patients for Pediatric Patients
* Measure Description        :- ED Median Time from ED arrival to ED departure for discharged for pediatric patients, excluding patients with psychiatric
*                               and mental health disorders and patients who were transferred to another acute care hospital
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/
object Acep40 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Acep40"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {



    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, rdd, ACEP40Elements.Discharge_From_Emergency_Department,
      ACEP40Elements.Acute_Care_Hospital).collect.toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(rdd,patientHistoryList)
    ippRDD.cache()


    // Filter Exclusion
    val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    metRDD.cache()

    val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA, metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, noteligibleRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

  }


  def getIpp(rdd: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
                          isAgeBelow(visit,m,false,18)
                       && isVisitTypeIn(visit, m, ACEP40Elements.Emergency_Department_Visit, ACEP40Elements.Critical_Care_Evaluation_And_Management)
                       && wasEncounterPerformedAfterEDorCCEncounter(visit, m, ACEP40Elements.Discharge_From_Emergency_Department, AdminElements.Emergency_Visit_Arrival_Date,ACEP40Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
                       && !
                            (
                                  isEncounterPerformedEDOrCCEncounter(visit,m,ACEP40Elements.Emergency_Department_Visit,ACEP40Elements.Psychiatric_Mental_Health_Diagnosis)
                              ||  isEncounterPerformedEDOrCCEncounter(visit,m,ACEP40Elements.Critical_Care_Evaluation_And_Management,ACEP40Elements.Psychiatric_Mental_Health_Diagnosis)

                            )
                       && ! wasTransferAfterOrConcurrentProcedure(visit,m,ACEP40Elements.Acute_Care_Hospital,AdminElements.Encounter_Date,patientHistoryList)

    )
  }

  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
                            isEncounterPerformedEDOrCCEncounter(visit,m,ACEP40Elements.Emergency_Department_Visit,ACEP40Elements.Patient_Expired)
                         || isEncounterPerformedEDOrCCEncounter(visit,m,ACEP40Elements.Critical_Care_Evaluation_And_Management,ACEP40Elements.Patient_Expired)
                          )
  }

  def getObservation1(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
           isEncounterPerformedEDOrCCEncounter(visit,m,ACEP40Elements.Emergency_Department_Visit,ACEP40Elements.Patient_Expired)
        || isEncounterPerformedEDOrCCEncounter(visit,m,ACEP40Elements.Critical_Care_Evaluation_And_Management,ACEP40Elements.Patient_Expired)
    )
  }


  def getObservation2(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
           isEncounterPerformedEDOrCCEncounter(visit,m,ACEP40Elements.Emergency_Department_Visit,ACEP40Elements.Patient_Expired)
        || isEncounterPerformedEDOrCCEncounter(visit,m,ACEP40Elements.Critical_Care_Evaluation_And_Management,ACEP40Elements.Patient_Expired)

    )
  }



}








