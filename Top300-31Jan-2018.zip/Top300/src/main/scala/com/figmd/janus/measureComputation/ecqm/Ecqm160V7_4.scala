package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.ecqm.Ecqm144V7_2.{MEASURE_NAME, checkEmptyIPPRDD}
import com.figmd.janus.measureComputation.master.{ECQM160V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS160v7
* Measure Title              :- Depression Utilization of the PHQ-9 Tool
* Measure Description        :- The percentage of adolescent patients 12 to 17 years of age and adult patients age 18 and older with
                                the diagnosis of major depression or dysthymia who have a completed PHQ-9 during each applicable 4 month period in which there was a qualifying depression encounter
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 4
* Measure Stratification     :- 2
* Measure Developer          :- Rahul Rasure.
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm160V7_4 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm160V7_4"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patient_history_list = getPatientHistory(sparkSession, initialRDD,
      ECQM160V7Elements.Contact_Or_Office_Visit,
      ECQM160V7Elements.Major_Depression_Including_Remission,
      ECQM160V7Elements.Dysthymia,
      ECQM160V7Elements.Bipolar_Disorder,
      ECQM160V7Elements.Personality_Disorder,
      ECQM160V7Elements.Schizophrenia_Or_Psychotic_Disorder,
      ECQM160V7Elements.Pervasive_Developmental_Disorder,
      ECQM160V7Elements.Palliative_Care_Encounter,
      ECQM160V7Elements.Palliative_Care,
      ECQM160V7Elements.Care_Services_In_Long_Term_Residential_Facility,
      ECQM160V7Elements.Phq_9_Tool).collect().toList


    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //eligible RDD
      //val eligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : Adolescent patients 12 to 17 years of age and adult patients 18 years of age and older with an office visit
and the diagnosis of major depression or dysthymia during the four month period
----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && (wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM160V7Elements.Major_Depression_Including_Remission, patientHistoryList)
        || wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM160V7Elements.Dysthymia, patientHistoryList)
        )
        && wasEncounterPerformedEndsBeforeEndOfWithinXPeriod(visit, m, ECQM160V7Elements.Contact_Or_Office_Visit, "MONTH", 4, "endsBefore", patientHistoryList)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Denominator Exclusions :
1: Patients who died
2: Patients who received hospice or palliative care services
3: Patients who were permanent nursing home residents
4: Patients with a diagnosis of bipolar disorder
5: Patients with a diagnosis of personality disorder
6: Patients with a diagnosis of schizophrenia or psychotic disorder
7: Patients with a diagnosis of pervasive developmental disorder
----------------------------------------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM160V7Elements.Bipolar_Disorder, patientHistoryList)
        || wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM160V7Elements.Personality_Disorder, patientHistoryList)
        || wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM160V7Elements.Schizophrenia_Or_Psychotic_Disorder, patientHistoryList)
        || wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM160V7Elements.Pervasive_Developmental_Disorder, patientHistoryList)
        || wasEncounterPerformedBeforeOrEqualOfEncounter(visit, m, ECQM160V7Elements.Palliative_Care_Encounter, patientHistoryList)
        || wasEncounterPerformedBeforeOrEqualOfEncounter(visit, m, ECQM160V7Elements.Care_Services_In_Long_Term_Residential_Facility, patientHistoryList)
        || wasInterventionOrderedStartsBeforeEndOfEncounter(visit, m, ECQM160V7Elements.Palliative_Care, patientHistoryList)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Adolescent patients 12 to 17 years of age and adult patients 18 years of age and older who have a PHQ-9 or PHQ-9M tool
administered at least once during the four-month period.
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      wasAssessmentPerformedEndsBeforeEndOfWithinXPeriod(visit, m, ECQM160V7Elements.Phq_9_Tool, "MONTH", 4, "endsBefore", patientHistoryList)
    )
  }
}