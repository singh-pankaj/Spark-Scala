package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, AQUA14Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AQUA 14
* Measure Title              :- Stones: Repeat Shock Wave Lithotripsy (SWL) within 6 months of treatment
* Measure Description        :- Percentage of patients who underwent endoscopic procedures following SWL
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Aqua14 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "Aqua14"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , AQUA14Elements.Shock_Wave_Lithotripsy_Left
      , AQUA14Elements.Shock_Wave_Lithotripsy_Right
      , AQUA14Elements.Shock_Wave_Lithotripsy_Bilateral
      , AQUA14Elements.Shock_Wave_Lithotripsy_Unspecified_Side

    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryList)
      // metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD,denominatorRDD , sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()

    }
  }


  /*------------------------------------------------------------------------------------------------
    Patients undergoing SWL followed by ipsilateral SWL within 6 months
 ------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
        wasDiagnosedBeforeOrEqualEncounter(visit,m,AQUA14Elements.Stones,patientHistoryList)
     &&
        (
            isProcedurePerformedDuringEncounter(visit,m,AQUA14Elements.Shock_Wave_Lithotripsy_Left)
         || isProcedurePerformedDuringEncounter(visit,m,AQUA14Elements.Shock_Wave_Lithotripsy_Right)
         || isProcedurePerformedDuringEncounter(visit,m,AQUA14Elements.Shock_Wave_Lithotripsy_Bilateral)
         || isProcedurePerformedDuringEncounter(visit,m,AQUA14Elements.Shock_Wave_Lithotripsy_Unspecified_Side)
        )
    )
  }


  /*------------------------------------------------------------------------------------------------
  Patients undergoing SWL on the ipsilateral side within 6 months
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRdd.filter(visit =>
         wasProcedureAfterEncounterWithInXMonths(visit,m,AQUA14Elements.Shock_Wave_Lithotripsy_Left_Date,AQUA14Elements.Shock_Wave_Lithotripsy_Left,6,patientHistoryList)
      || wasProcedureAfterEncounterWithInXMonths(visit,m,AQUA14Elements.Shock_Wave_Lithotripsy_Right_Date,AQUA14Elements.Shock_Wave_Lithotripsy_Right,6,patientHistoryList)
      || wasProcedureAfterEncounterWithInXMonths(visit,m,AQUA14Elements.Shock_Wave_Lithotripsy_Bilateral_Date,AQUA14Elements.Shock_Wave_Lithotripsy_Bilateral,6,patientHistoryList)
      || wasProcedureAfterEncounterWithInXMonths(visit,m,AQUA14Elements.Shock_Wave_Lithotripsy_Unspecified_Side_Date,AQUA14Elements.Shock_Wave_Lithotripsy_Unspecified_Side,6,patientHistoryList)
    )
  }

}
