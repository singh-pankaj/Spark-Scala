package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CompareOperator, MUSIC4Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- MUSIC 4
* Measure Title              :- Prostate Cancer: Active Surveillance/Watchful Waiting for Low Risk Prostate Cancer Patients
* Measure Description        :- Proportion of patients with low-risk prostate cancer receiving active surveillance or watchful waiting
* Calculation Implementation :- Patient-Process Specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object MUSIC4 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "MUSIC4"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      MUSIC4Elements.Documentation_Of_Primary_Gleason_Score,
      MUSIC4Elements.Documentation_Of_Secondary_Gleason_Score,
      MUSIC4Elements.Prostate_Cancer,
      MUSIC4Elements.Clinical_T_Staging_V,
      MUSIC4Elements.T_Staging_Procedure,
      MUSIC4Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes,
      MUSIC4Elements.Documentation_Of_Primary_Gleason_Score,
      MUSIC4Elements.Documentation_Of_Secondary_Gleason_Score,
      MUSIC4Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes,
      MUSIC4Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,
      MUSIC4Elements.Documentation_Of_Psa,
      MUSIC4Elements.Documentation_Of_Psa_In_Md_Notes,
      MUSIC4Elements.Prostate_Specific_Antigen_Test_Date,
      MUSIC4Elements.Risk_Stratification_Of_Prostate_Cancer_Low,
      MUSIC4Elements.Risk_Stratification_Of_Prostate_Cancer_In_Md_Notes,
      MUSIC4Elements.Risk_Stratification_Of_Prostate_Cancer_Not_Determined,
      MUSIC4Elements.Risk_Stratification_Of_Prostate_Cancer_No,
      MUSIC4Elements.Risk_Stratification_Of_Prostate_Cancer_Intermediate,
      MUSIC4Elements.Risk_Stratification_Of_Prostate_Cancer_High,
      MUSIC4Elements.Interstitial_Prostate_Brachytherapy,
      MUSIC4Elements.Radical_Prostatectomy,
      MUSIC4Elements.Cryotherapy,
      MUSIC4Elements.External_Beam_Radiotherapy,
      MUSIC4Elements.Adt,
      MUSIC4Elements.Gold__Fiducial_Marker,
      MUSIC4Elements.Documentation_Of_Brachytherapy_In_Md_Notes,
      MUSIC4Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes,
      MUSIC4Elements.Documentation_Of_Cryotherapy_In_Md_Notes,
      MUSIC4Elements.Documentation_Of_Ebrt_In_Md_Notes,
      MUSIC4Elements.Adt_Md_Notes,
      MUSIC4Elements.Gold__Fiducial_Markers_In_Md_Notes,
      MUSIC4Elements.Active_Surveillance,
      MUSIC4Elements.Active_Surveillance_Md_Notes,
      MUSIC4Elements.Watchful_Waiting,
      MUSIC4Elements.Watchful_Waiting_Md_Notes

    )

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Eligible IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Not Eligible
      /*val notEligibleRDD =sparkSession.sparkContext.emptyRDD[CassandraRow]
    notEligibleRDD.cache()*/

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }

  }

  /*-------------------------------------------------------------------------------------------------------------------------
# of low-risk prostate cancer patients 30 or older
----------------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val PGC_SGC_MostRecentList = mostRecentPatientList(patientHistoryRDD, MUSIC4Elements.Documentation_Of_Primary_Gleason_Score, MUSIC4Elements.Documentation_Of_Secondary_Gleason_Score)

    initialRDD.filter(visit =>
      isMale(visit, m)
        && isAgeAbove(visit, m, true, 30)
        && isDiagnosisWithBeforeEnd(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList)
        && (
        (
          (
            wasProcedurePerformedAfterDiagnosisInHistory(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.Clinical_T_Staging_V)
              || wasProcedurePerformedAfterDiagnosisInHistory(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.T_Staging_Procedure)
              || wasProcedurePerformedAfterDiagnosisInHistory(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.Documentation_Of_Clinical_T_Staging_In_Md_Notes)
            )
            && (
            wasSummationOfLaboratoryTestBeforeDiagnosisWithResultXValue(visit, m, MUSIC4Elements.Documentation_Of_Primary_Gleason_Score, MUSIC4Elements.Documentation_Of_Secondary_Gleason_Score,
              MUSIC4Elements.Prostate_Cancer, 6, CompareOperator.LESS_EQUAL, patientHistoryList)
              || wasSummationOfLaboratoryTestBeforeDiagnosisWithResultXValue(visit, m, MUSIC4Elements.Documentation_Of_Primary_Gleason_Score_In_Md_Notes, MUSIC4Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes,
              MUSIC4Elements.Prostate_Cancer, 6, CompareOperator.LESS_EQUAL, patientHistoryList)
              || wasLaboratoryTestOverlapsDiagnosisWithResult(visit, m, MUSIC4Elements.Gleason_Score_V, MUSIC4Elements.Prostate_Cancer, 6, "le", patientHistoryList)
              || wasDiagnosisAfterProcedurePerformedInHistory(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.Gleason_Score_Low_Risk)
              || wasLaboratoryTestOverlapsDiagnosisWithResult(visit, m, MUSIC4Elements.Documentation_Of_Secondary_Gleason_Score_In_Md_Notes_Date, MUSIC4Elements.Prostate_Cancer, 6, "le", patientHistoryList)
            )
            && (
            wasLaboratoryTestOverlapsDiagnosisWithResult(visit, m, MUSIC4Elements.Documentation_Of_Psa, MUSIC4Elements.Prostate_Cancer, 10, "lt", patientHistoryList)
              || wasLaboratoryTestOverlapsDiagnosisWithResult(visit, m, MUSIC4Elements.Documentation_Of_Psa_In_Md_Notes, MUSIC4Elements.Prostate_Cancer, 10, "lt", patientHistoryList)
              || wasLaboratoryTestOverlapsDiagnosisWithResult(visit, m, MUSIC4Elements.Prostate_Specific_Antigen_Test_Date, MUSIC4Elements.Prostate_Cancer, 10, "lt", patientHistoryList)
            )
          )
          || (
          wasAssessmentPerformedAfterDiagnosis(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.Risk_Stratification_Of_Prostate_Cancer_Low)
            || wasAssessmentPerformedAfterDiagnosis(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.Risk_Stratification_Of_Prostate_Cancer_In_Md_Notes)
          )
        )
        && !(
        wasAssessmentPerformedAfterDiagnosis(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.Risk_Stratification_Of_Prostate_Cancer_Not_Determined)
          || wasAssessmentPerformedAfterDiagnosis(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.Risk_Stratification_Of_Prostate_Cancer_No)
          || wasAssessmentPerformedAfterDiagnosis(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.Risk_Stratification_Of_Prostate_Cancer_Intermediate)
          || wasAssessmentPerformedAfterDiagnosis(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.Risk_Stratification_Of_Prostate_Cancer_High)
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Prostate cancer patients < 30 years of age; patients that have had prior treatment for prostate cancer
----------------------------------------------------------------------------------------------------------------------------*/

  // Denominator Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      isAgeBelow(visit, m, false, 30)
        || (
        isProcedurePerformedBeforeEnd(visit, m, MUSIC4Elements.Interstitial_Prostate_Brachytherapy, patientHistoryList)
          || isProcedurePerformedBeforeEnd(visit, m, MUSIC4Elements.Radical_Prostatectomy, patientHistoryList)
          || isProcedurePerformedBeforeEnd(visit, m, MUSIC4Elements.Cryotherapy, patientHistoryList)
          || isProcedurePerformedBeforeEnd(visit, m, MUSIC4Elements.External_Beam_Radiotherapy, patientHistoryList)
          || isProcedurePerformedBeforeEnd(visit, m, MUSIC4Elements.Adt, patientHistoryList)
          || isProcedurePerformedBeforeEnd(visit, m, MUSIC4Elements.Gold__Fiducial_Marker, patientHistoryList)
        )
        || (
        isProcedurePerformedBeforeEnd(visit, m, MUSIC4Elements.Documentation_Of_Brachytherapy_In_Md_Notes, patientHistoryList)
          || isProcedurePerformedBeforeEnd(visit, m, MUSIC4Elements.Documentation_Of_Radical_Prostatectomy_In_Md_Notes, patientHistoryList)
          || isProcedurePerformedBeforeEnd(visit, m, MUSIC4Elements.Documentation_Of_Cryotherapy_In_Md_Notes, patientHistoryList)
          || isProcedurePerformedBeforeEnd(visit, m, MUSIC4Elements.Documentation_Of_Ebrt_In_Md_Notes, patientHistoryList)
          || isProcedurePerformedBeforeEnd(visit, m, MUSIC4Elements.Adt_Md_Notes, patientHistoryList)
          || isProcedurePerformedBeforeEnd(visit, m, MUSIC4Elements.Gold__Fiducial_Markers_In_Md_Notes, patientHistoryList)
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
# of low-risk prostate cancer patients on active surveillance or watchful waiting
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        (
          wasProcedurePerformedAfterDiagnosisInHistory(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.Active_Surveillance)
            && isProcedurePerformed(visit, m, MUSIC4Elements.Active_Surveillance, patientHistoryList)
          )
          || (
          wasProcedurePerformedAfterDiagnosisInHistory(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.Active_Surveillance_Md_Notes)
            && isProcedurePerformed(visit, m, MUSIC4Elements.Active_Surveillance_Md_Notes, patientHistoryList)
          )
        )
        || (
        (
          wasProcedurePerformedAfterDiagnosisInHistory(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.Watchful_Waiting)
            && isProcedurePerformed(visit, m, MUSIC4Elements.Watchful_Waiting, patientHistoryList)
          )
          || (
          wasProcedurePerformedAfterDiagnosisInHistory(visit, m, MUSIC4Elements.Prostate_Cancer, patientHistoryList, MUSIC4Elements.Watchful_Waiting_Md_Notes)
            && isProcedurePerformed(visit, m, MUSIC4Elements.Watchful_Waiting_Md_Notes, patientHistoryList)
          )
        )
    )
  }

}

