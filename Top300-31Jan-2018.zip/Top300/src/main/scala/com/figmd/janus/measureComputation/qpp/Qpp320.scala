package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp320
* Measure Title              :- Appropriate Follow-Up Interval for Normal Colonoscopy in Average Risk Patients
* Measure Description        :- Percentage of patients aged 50 to 75 years of age receiving  a screening
  *                             colonoscopy without biopsy or polypectomy who had a recommended follow-up interval of at least 10 years
   *                            for repeat colonoscopy documented in their colonoscopy report

 *
*
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Sawant
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp320 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp320"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP320Elements.Screening_Of_Colonoscopy
      , QPP320Elements.Biopsy__Colonoscopy
      , QPP320Elements.Malignant_Neoplasm_Of_Colon_Screening
      , QPP320Elements.Colonoscopic_Polypectomy
      , QPP320Elements.Screening_Colonoscopy_52_53_73_74
      , QPP320Elements.Follow_Up_Colonoscopy
      , QPP320Elements.Documentation__Recommended_Follow_Up_Interval
      , QPP320Elements.Recommended_Follow_Up_Interval_Reason_Not_Specified
      , QPP320Elements.Inadequate_Preparation
      , QPP320Elements.Recommended_Follow_Up_Interval_Medical_Reason
      , QPP320Elements.Adenoma
      , QPP320Elements.Familial_Or_Personal_History_Of_Colonic_Polyps
      , QPP320Elements.Limited_Life_Expectancy
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      // Filter Met
      val metRDD = getMetRDD(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateException = getSubtractRDD(ippRDD, metRDD)
      intermediateException.cache()

      val exceptionRDD = getExceptionRDD(intermediateException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
   All patients aged 50 to 75 years of age receiving a screening colonoscopy without biopsy or polypectomy
   * ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit, m, equalFlag = true, 50)
        && isAgeBelow(visit, m, equalFlag = false, 76)
        && isProcedurePerformedDuringEncounter(visit, m, QPP320Elements.Screening_Of_Colonoscopy)
        && isProcedurePerformed(visit, m, QPP320Elements.Screening_Of_Colonoscopy, patientHistoryBroadcastList)
        && isDiagnosis(visit, m, QPP320Elements.Malignant_Neoplasm_Of_Colon_Screening, patientHistoryBroadcastList)
        && !wasEncounterPerformed(visit, m, QPP320Elements.Screening_Colonoscopy_52_53_73_74, patientHistoryBroadcastList)
        /*&& (!isProcedurePerformed(visit, m, QPP320Elements.Biopsy__Colonoscopy, patientHistoryBroadcastList)
        || !isProcedurePerformed(visit, m, QPP320Elements.Colonoscopic_Polypectomy, patientHistoryBroadcastList)    //as per new HR removed condition
        ) */

    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Patients who had recommended follow-up interval of at least 10 years for repeat colonoscopy documented in their colonoscopy report
   * ----------------------------------------------------------------------------------------------------------------------------*/
  def getMetRDD(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>

      ((isDiagnosticStudyPerformedAfterProcedure(visit, m, patientHistoryBroadcastList, QPP320Elements.Screening_Of_Colonoscopy, QPP320Elements.Documentation__Recommended_Follow_Up_Interval)
        && isDiagnosticStudyPerformed(visit, m, QPP320Elements.Documentation__Recommended_Follow_Up_Interval, patientHistoryBroadcastList)
        )
        ||
        (isDiagnosticStudyPerformedAfterProcedure(visit, m, patientHistoryBroadcastList, QPP320Elements.Screening_Of_Colonoscopy, QPP320Elements.Follow_Up_Colonoscopy)
          && isDiagnosticStudyPerformed(visit, m, QPP320Elements.Follow_Up_Colonoscopy, patientHistoryBroadcastList)
          )
        )
        &&
        (!isDiagnosticStudyPerformedAfterProcedure(visit, m, patientHistoryBroadcastList, QPP320Elements.Screening_Of_Colonoscopy, QPP320Elements.Recommended_Follow_Up_Interval_Reason_Not_Specified)
          && !isDiagnosticStudyPerformed(visit, m, QPP320Elements.Recommended_Follow_Up_Interval_Reason_Not_Specified, patientHistoryBroadcastList)
          )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
   Documentation of medical reason(s) for not recommending at least a 10 year follow-up interval (e.g., inadequate prep, familial or
   personal history of colonic polyps, patient had no adenoma and age is ≥ 66 years old, or life expectancy < 10 years old, other medical reasons)
   * ----------------------------------------------------------------------------------------------------------------------------*/
  def getExceptionRDD(intermediateB: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateB.filter(visit =>
      isDiagnosticStudyPerformed(visit, m, QPP320Elements.Recommended_Follow_Up_Interval_Medical_Reason, patientHistoryBroadcastList) //not done
        || wasDiagnosticStudyPerformedBeforeProcedure(visit, m, QPP320Elements.Screening_Of_Colonoscopy, patientHistoryBroadcastList, QPP320Elements.Inadequate_Preparation)

        ||
        (
          !wasDiagnosisBeforeOrEqualProcedure(visit, m, QPP320Elements.Adenoma, QPP320Elements.Screening_Of_Colonoscopy, patientHistoryBroadcastList)
            && isAgeAbove(visit, m, equalFlag = true, 66)
            && isProcedurePerformedDuringEncounter(visit, m, QPP320Elements.Screening_Of_Colonoscopy)
          )
        ||
        (
          wasDiagnosisBeforeOrEqualProcedure(visit, m, QPP320Elements.Familial_Or_Personal_History_Of_Colonic_Polyps, QPP320Elements.Screening_Of_Colonoscopy, patientHistoryBroadcastList)
            || isAssessmentPerformedBeforeOrEqual(visit, m, QPP320Elements.Screening_Of_Colonoscopy, patientHistoryBroadcastList, QPP320Elements.Limited_Life_Expectancy)

          )
    )
  }
}
