package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ACR09Elements, AdminElements, MeasureProperty,CompareOperator}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACR09
* Measure Title              :- Rheumatoid Arthritis Patients with Moderate or High Risk Disease Activity
* Measure Description        :- The proportion of individuals with RA who have moderate or high disease activity, including
                                at the most recent visit AND a visit at least 90 days prior to the most recent visit.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object ACR09 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "ACR09"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,ACR09Elements.Office_Visit
      ,ACR09Elements.Care_Services_In_Long_Term_Residential_Facility
      ,ACR09Elements.Home_Healthcare_Services
      ,ACR09Elements.Face_To_Face_Interaction
      ,ACR09Elements.Nursing_Facility_Visit
      ,ACR09Elements.Outpatient_Consultation
      ,ACR09Elements.Active_Rheumatoid_Arthritis
      ,ACR09Elements.Das28_Esr_Or_Crp
      ,ACR09Elements.Cdai
      ,ACR09Elements.Sdai
      ,ACR09Elements.Rapid___3
      ,ACR09Elements.Pas_Or_Pas_Ii
      ,ACR09Elements.Disease_Activity_Tools
      ,ACR09Elements.Inval_Out_Of_Range
    )

    val patientHistoryBroadcastRDD: Broadcast[RDD[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    //Mostrecent Patient History List
    val patientHistoryMostRecentList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostRecentPatientList(patientHistoryRDD
      ,ACR09Elements.Office_Visit
      ,ACR09Elements.Care_Services_In_Long_Term_Residential_Facility
      ,ACR09Elements.Home_Healthcare_Services
      ,ACR09Elements.Face_To_Face_Interaction
      ,ACR09Elements.Nursing_Facility_Visit
      ,ACR09Elements.Outpatient_Consultation))

    //Mostrecent Patient History List
    val patientHistorySecondMostRecentList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostRecentBeforeInXDays(patientHistoryMostRecentList,patientHistoryBroadcastRDD,90))

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryRDD,patientHistoryBroadcastList,patientHistorySecondMostRecentList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList,patientHistoryMostRecentList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList,patientHistoryMostRecentList,patientHistorySecondMostRecentList)
      metRDD.cache()

      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList,patientHistoryMostRecentList,patientHistorySecondMostRecentList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
    Two visits for RA at least 90 days apart AND age >18 years AND at least two RA
    disease activity measures during the measurement year. Patients without
    at least two measures are not included in the denominator.
 -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryRDD :RDD[CassandraRow],patientHistoryBroadcastList : Broadcast[List[CassandraRow]],patientHistorySecondMostRecentList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val countElementList: List[(String,Int)] = countElement(patientHistoryRDD,m
      ,ACR09Elements.Office_Visit
      ,ACR09Elements.Care_Services_In_Long_Term_Residential_Facility
      ,ACR09Elements.Home_Healthcare_Services
      ,ACR09Elements.Face_To_Face_Interaction
      ,ACR09Elements.Nursing_Facility_Visit
      ,ACR09Elements.Outpatient_Consultation)

    initialRDD.filter(visit =>
             isPatientAdult(visit,m)
        &&   isVisitTypeIn(visit,m
              ,ACR09Elements.Office_Visit
              ,ACR09Elements.Care_Services_In_Long_Term_Residential_Facility
              ,ACR09Elements.Home_Healthcare_Services
              ,ACR09Elements.Face_To_Face_Interaction
              ,ACR09Elements.Nursing_Facility_Visit
              ,ACR09Elements.Outpatient_Consultation)
        &&   wasDiagnosedWithBeforeOrEqualEncounter(visit,m,ACR09Elements.Active_Rheumatoid_Arthritis,patientHistoryBroadcastList)
        &&   getEncounterCountFromHistory(visit,m,2,true, countElementList)
        &&   (
                       isEncounterPerformedInXDaysBeforeMostRecentEncounter(visit,m,ACR09Elements.Office_Visit,90,patientHistoryBroadcastList,patientHistorySecondMostRecentList)
                  ||   isEncounterPerformedInXDaysBeforeMostRecentEncounter(visit,m,ACR09Elements.Care_Services_In_Long_Term_Residential_Facility,90,patientHistoryBroadcastList,patientHistorySecondMostRecentList)
                  ||   isEncounterPerformedInXDaysBeforeMostRecentEncounter(visit,m,ACR09Elements.Home_Healthcare_Services,90,patientHistoryBroadcastList,patientHistorySecondMostRecentList)
                  ||   isEncounterPerformedInXDaysBeforeMostRecentEncounter(visit,m,ACR09Elements.Face_To_Face_Interaction,90,patientHistoryBroadcastList,patientHistorySecondMostRecentList)
                  ||   isEncounterPerformedInXDaysBeforeMostRecentEncounter(visit,m,ACR09Elements.Nursing_Facility_Visit,90,patientHistoryBroadcastList,patientHistorySecondMostRecentList)
                  ||   isEncounterPerformedInXDaysBeforeMostRecentEncounter(visit,m,ACR09Elements.Outpatient_Consultation,90,patientHistoryBroadcastList,patientHistorySecondMostRecentList)
              )
    )
  }

  /*---------------------------------------------------------------------------------------------
 If a patient has no disease activity score recorded at their last encounter, they are excluded.
 ---------------------------------------------------------------------------------------------*/

  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryMostRecentList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
               wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Das28_Esr_Or_Crp,0,"eq",patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Cdai,0,"eq",patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Sdai,0,"eq",patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Rapid___3,0,"eq",patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Pas_Or_Pas_Ii,0,"eq",patientHistoryBroadcastList,patientHistoryMostRecentList)
    )
  }

  /*------------------------------------------------------------------------------------------------------------------
  Moderate or high disease activity score on 2 consecutive visits during the measurement year
  spaced at least 90 days apart, including the most recent visit, as measured by the CDAI, SDAI, RAPID3, DAS or PAS.
  If the patient has more than one measure, the following hierarchy DAS>SDAI>CDAI>RAPID3>PAS was used.
  In other words, we used the first measure in the hierarchy on a given day and discarded the others.
 -----------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryMostRecentList: Broadcast[List[CassandraRow]],patientHistorySecondMostRecentList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    val AssessmentList: Seq[(String, String, Double, String, Double)] = Seq((ACR09Elements.Das28_Esr_Or_Crp,CompareOperator.GREATER_EQUAL,3.2,CompareOperator.LESS_EQUAL,9.4),
      (ACR09Elements.Sdai,CompareOperator.GREATER_EQUAL,11.1,CompareOperator.LESS_EQUAL,86),
      (ACR09Elements.Cdai,CompareOperator.GREATER,10.1,CompareOperator.LESS_EQUAL,76),
      (ACR09Elements.Rapid___3,CompareOperator.GREATER,2.0,CompareOperator.LESS_EQUAL,10),
      (ACR09Elements.Pas_Or_Pas_Ii,CompareOperator.GREATER_EQUAL,3.71,CompareOperator.LESS_EQUAL,10))

    intermediateForMet.filter(visit =>
             wasAssessmentPerformedMostRecent(visit,m,ACR09Elements.Disease_Activity_Tools,patientHistoryBroadcastList,patientHistoryMostRecentList)
        &&   wasAssessmentPerformedMostRecent(visit,m,ACR09Elements.Disease_Activity_Tools,patientHistoryBroadcastList,patientHistorySecondMostRecentList)
        &&   wasAssessmentPerformedWithPrecedence(visit,m, AssessmentList, patientHistoryMostRecentList,patientHistoryBroadcastList)

        &&   !(
                     (
                              wasAssessmentPerformedWithInRangeValueDuringMostRecent(visit,m,ACR09Elements.Das28_Esr_Or_Crp,0,3.2,"ge&lt",patientHistoryBroadcastList,patientHistoryMostRecentList)
                          ||  wasAssessmentPerformedWithInRangeValueDuringMostRecent(visit,m,ACR09Elements.Das28_Esr_Or_Crp,0,3.2,"ge&lt",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
                     )
                     ||
                     (
                              wasAssessmentPerformedWithInRangeValueDuringMostRecent(visit,m,ACR09Elements.Sdai,0,11.1,"ge&lt",patientHistoryBroadcastList,patientHistoryMostRecentList)
                          ||  wasAssessmentPerformedWithInRangeValueDuringMostRecent(visit,m,ACR09Elements.Sdai,0,11.1,"ge&lt",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
                     )
                     ||
                     (
                              wasAssessmentPerformedWithInRangeValueDuringMostRecent(visit,m,ACR09Elements.Cdai,0,10.1,"ge&le",patientHistoryBroadcastList,patientHistoryMostRecentList)
                          ||  wasAssessmentPerformedWithInRangeValueDuringMostRecent(visit,m,ACR09Elements.Cdai,0,10.1,"ge&le",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
                     )
                     ||
                     (
                              wasAssessmentPerformedWithInRangeValueDuringMostRecent(visit,m,ACR09Elements.Rapid___3,0,2.0,"ge&le",patientHistoryBroadcastList,patientHistoryMostRecentList)
                          ||  wasAssessmentPerformedWithInRangeValueDuringMostRecent(visit,m,ACR09Elements.Rapid___3,0,2.0,"ge&le",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
                     )
                     ||
                     (
                              wasAssessmentPerformedWithInRangeValueDuringMostRecent(visit,m,ACR09Elements.Pas_Or_Pas_Ii,0,3.71,"ge&lt",patientHistoryBroadcastList,patientHistoryMostRecentList)
                          ||  wasAssessmentPerformedWithInRangeValueDuringMostRecent(visit,m,ACR09Elements.Pas_Or_Pas_Ii,0,3.71,"ge&lt",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
                     )
              )
    )
  }

  /*-----------------------------------------------------------------------------------------
  Disease activity score Invalid or Out of range
 -----------------------------------------------------------------------------------------*/

  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryMostRecentList: Broadcast[List[CassandraRow]],patientHistorySecondMostRecentList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
        (
               wasAssessmentPerformedMostRecent(visit,m,ACR09Elements.Inval_Out_Of_Range,patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Das28_Esr_Or_Crp,0,"lt",patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Das28_Esr_Or_Crp,9.4,"gt",patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Sdai,0,"lt",patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Sdai,86,"gt",patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Cdai,0,"lt",patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Cdai,76,"gt",patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Rapid___3,0,"lt",patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Rapid___3,10,"gt",patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Pas_Or_Pas_Ii,0,"lt",patientHistoryBroadcastList,patientHistoryMostRecentList)
          ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Pas_Or_Pas_Ii,10,"gt",patientHistoryBroadcastList,patientHistoryMostRecentList)
        )
        &&
        (
                 wasAssessmentPerformedMostRecent(visit,m,ACR09Elements.Inval_Out_Of_Range,patientHistoryBroadcastList,patientHistoryMostRecentList)
            ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Das28_Esr_Or_Crp,0,"lt",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
            ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Das28_Esr_Or_Crp,9.4,"gt",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
            ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Sdai,0,"lt",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
            ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Sdai,86,"gt",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
            ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Cdai,0,"lt",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
            ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Cdai,76,"gt",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
            ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Rapid___3,0,"lt",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
            ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Rapid___3,10,"gt",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
            ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Pas_Or_Pas_Ii,0,"lt",patientHistoryBroadcastList,patientHistorySecondMostRecentList)
            ||   wasAssessmentPerformedValueDuringMostRecent(visit,m,ACR09Elements.Pas_Or_Pas_Ii,10,"gt",patientHistoryBroadcastList,patientHistorySecondMostRecentList)

        )

      )
  }
}

