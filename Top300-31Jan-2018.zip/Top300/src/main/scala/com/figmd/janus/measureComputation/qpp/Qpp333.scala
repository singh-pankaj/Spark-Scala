package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP333Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp 333
* Measure Title              :- Adult Sinusitis: Computerized Tomography (CT) for Acute Sinusitis (Overuse)
* Measure Description        :- Percentage of patients aged 18 years and older, with a diagnosis of acute sinusitis who had a computerized tomography (CT) scan of the paranasal sinuses ordered at the time of diagnosis or received within 28 days after date of diagnosis.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp333 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp333"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP333Elements.Acute_Sinusitis).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible RDD
      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, metRDD)
      intermediateA.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateA)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()
      //

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /* All patients aged 18 years and older with a diagnosis of acute sinusitis */

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>

      isPatientAdult(visit, m)
        && (
        wasDiagnosedAfterStartOfMeasurementPeriod(visit, m, patientHistoryBroadcastList, QPP333Elements.Acute_Sinusitis)
          && wasDiagnosedInXDaysBeforeEndDate(visit, m, QPP333Elements.Acute_Sinusitis, 28, patientHistoryBroadcastList)
        )
        && isVisitTypeIn(visit, m,
        QPP333Elements.Office_Visit,
        QPP333Elements.Emergency_Department_Visit,
        QPP333Elements.Nursing_Facility_Visit,
        QPP333Elements.Care_Services_In_Long_Term_Residential_Facility_Gp,
        QPP333Elements.Home_Healthcare_Services
      )
        && !isVisitTypeIn(visit, m, QPP333Elements.Office_Visit_Telehealth_Modifier,
        QPP333Elements.Emergency_Department_Visit_Telehealth_Modifier,
        QPP333Elements.Nursing_Facility_Visit_Telehealth_Modifier,
        QPP333Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier,
        QPP333Elements.Home_Healthcare_Services_Telehealth_Modifier)
        && !isVisitTypeIn(visit, m, QPP333Elements.Pos_02)


    )
  }


  // Numerator criteria
  /* Patients who had a computerized tomography (CT) scan of the paranasal sinuses ordered at the time of diagnosis or received within 28 days after date of diagnosis */

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        (wasLaboratoryTestOrderedWithinXDaysFromDiagnosis(visit, m, QPP333Elements.Ct_Scan_Of_Paranasal_Sinuses_Loinc, QPP333Elements.Acute_Sinusitis, 28, patientHistoryBroadcastList)
          && isAssessmentPerformedDuringEncounter(visit, m, QPP333Elements.Ct_Scan_Of_Paranasal_Sinuses)
          )
          && !(isDiagnosedOnEncounter(visit, m, QPP333Elements.Acute_Sphenoid_Sinusitis)
          || isDiagnosedOnEncounter(visit, m, QPP333Elements.Acute_Frontal_Sinusitis)
          || isDiagnosedOnEncounter(visit, m, QPP333Elements.Periorbital_Abscess)
          || isDiagnosedOnEncounter(visit, m, QPP333Elements.Antibiotic_Resistance)
          )
        )
        && !isAssessmentPerformedDuringEncounter(visit, m, QPP333Elements.Ctparanasal_Not_Met)
    )
  }

  /* CT scan of the paranasal sinuses ordered at the time of diagnosis for documented reasons. */

  def getException(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        isLaboratoryTestOrder(visit, m, QPP333Elements.Ctparanasal_Medical_Reason)
          && (isDiagnosedOnEncounter(visit, m, QPP333Elements.Acute_Sphenoid_Sinusitis)
          || isDiagnosedOnEncounter(visit, m, QPP333Elements.Acute_Frontal_Sinusitis)
          || isDiagnosedOnEncounter(visit, m, QPP333Elements.Periorbital_Abscess)
          || isDiagnosedOnEncounter(visit, m, QPP333Elements.Antibiotic_Resistance)
          )
        )
        || isDiagnosedOnEncounter(visit, m, QPP333Elements.Compromised_Immunity)
    )
  }

}
