package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP168Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 168
* Measure Title              :- Coronary Artery Bypass Graft (CABG): Surgical Re-Exploration
* Measure Description        :- Percentage of patients aged 18 years and older undergoing isolated CABG surgery who
                                require a return to the operating room (OR) during the current hospitalization for
                                mediastinal bleeding with or without tamponade, graft occlusion, valve dysfunction, or
                                other cardiac reason.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp168 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp168"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Backtracking List
      val patientHistoryList = getPatientHistory(sparkSession,ippRDD
        ,QPP168Elements.Return_To_The_Or
        ,QPP168Elements.Graft_Occlusion
        ,QPP168Elements.Mediastinal_Bleeding
        ,QPP168Elements.Other_Cardiac_Reason
        ,QPP168Elements.Valve_Dysfuntion
        ,QPP168Elements.Re_Exploration
        ,QPP168Elements.Re_Exploration_Not_Required
      ).collect.toList
      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*------------------------------------------------------------------------------
    All patients undergoing isolated CABG surgery
   ------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
          isPatientAdult(visit,m)
      &&
            (
                   isProcedurePerformedDuringEncounter(visit,m,QPP168Elements.Coronary_Artery_Bypass_Graft)
              ||  (
                        isProcedurePerformedDuringEncounter(visit,m,QPP168Elements.Coronary_Artery_Bypass_Graft)
                    &&  isProcedurePerformedDuringEncounter(visit,m,QPP168Elements.Cabg_Reoperation)
                   )
            )
    )

  }

  /*--------------------------------------------------------------------------------------------------------------------
  Patients undergoing isolated CABG surgery who require a return to the OR during the current hospitalization for
  mediastinal bleeding with or without tamponade, graft occlusion, valve dysfunction, or other cardiac reason
  --------------------------------------------------------------------------------------------------------------------*/

  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    ipp.filter(visit =>
      (
        (
          wasEncounterPeformedAfterEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP168Elements.Return_To_The_Or)
          &&
            (
                wasEncounterPeformedAfterEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP168Elements.Graft_Occlusion)
             || wasEncounterPeformedAfterEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP168Elements.Mediastinal_Bleeding)
             || wasEncounterPeformedAfterEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP168Elements.Other_Cardiac_Reason)
             || wasEncounterPeformedAfterEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP168Elements.Valve_Dysfuntion)
            )
          )
      || wasEncounterPeformedAfterEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP168Elements.Re_Exploration)
      )
    && !wasEncounterPeformedAfterEncounter(visit,m,AdminElements.Encounter_Date,patientHistoryBroadcastList,QPP168Elements.Re_Exploration_Not_Required)

    )
  }

}
