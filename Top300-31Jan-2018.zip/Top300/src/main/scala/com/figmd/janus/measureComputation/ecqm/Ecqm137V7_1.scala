package com.figmd.janus.measureComputation.ecqm


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, ECQM137V7Elements, _}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 137
* Measure Title              :- Initiation and Engagement of Alcohol and Other Drug Dependence Treatment
* Measure Description        :- Percentage of patients 13 years of age and older with a new episode of alcohol or other drug abuse or (AOD) dependence who received the following. Two rates are reported.
                                a. Percentage of patients who initiated treatment within 14 days of the diagnosis.
                                b. Percentage of patients who initiated treatment and who had two or more additional services with an AOD diagnosis within 30 days of the initiation visit.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 1
* Measure Stratification     :- 2
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm137V7_1 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Ecqm137V7_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patient_history_list = getPatientHistory(sparkSession, initialRDD,
      ECQM137V7Elements.Alcohol_And_Drug_Dependence,
      ECQM137V7Elements.Discharged_To_Home_For_Hospice_Care,
      ECQM137V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
      ECQM137V7Elements.Hospice_Care_Ambulatory,
      ECQM137V7Elements.Alcohol_And_Drug_Dependence_Treatment,
      ECQM137V7Elements.Psych_Visit___Psychotherapy,
      ECQM137V7Elements.Encounter_Inpatient,
      ECQM137V7Elements.Discharge_Services___Hospital_Inpatient).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)



    // Filter IPP
    val ippRDD = getIpp(initialRDD,  patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession,initialRDD ,ippRDD, MEASURE_NAME)) {


      //eligible RDD
      //val eligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val denominatorRDD=ippRDD
      denominatorRDD.cache()


      // Filter Exclusions
      val exclusionRDD = getExclusionRDD(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }

  // IPP Criteria:
  // Patients age 13 years of age and older who were diagnosed with a new episode of alcohol, opioid, or other drug abuse or dependency during a visit between January 1 and November 15 of the measurement period
  def getIpp(initialRDD: RDD[CassandraRow],  patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 13)
        && isVisitTypeIn(visit, m, ECQM137V7Elements.Office_Visit,
        ECQM137V7Elements.Emergency_Department_Visit,
        ECQM137V7Elements.Detoxification_Visit,
        ECQM137V7Elements.Hospital_Observation_Care___Initial,
        ECQM137V7Elements.Hospital_Inpatient_Visit___Initial,
        ECQM137V7Elements.Discharge_Services___Hospital_Inpatient_Same_Day_Discharge,
        ECQM137V7Elements.Discharge_Services___Hospital_Inpatient

      )
        && isDiagnosisStartsAfterStartWithinXDays(visit, m, ECQM137V7Elements.Alcohol_And_Drug_Dependence, 319, patientHistoryList)

    )
  }

  //Exclusion Criteria

  //Patients with a previous active diagnosis of alcohol, opioid or other drug abuse or dependence in the 60 days prior to the first episode of alcohol or drug dependence

  //Exclude patients whose hospice care overlaps the measurement period.

  //  Exclude patients who were in hospice care during the measurement year.

  def getExclusionRDD(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      wasDiagnosedBeforeEncounterWithinXDays(visit, m, AdminElements.Encounter_Date, ECQM137V7Elements.Alcohol_And_Drug_Dependence, 60, patientHistoryList)
        || isEncounterPerformedWithDischargeStatus(visit, m, ECQM137V7Elements.Encounter_Inpatient, ECQM137V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        || isEncounterPerformedWithDischargeStatus(visit, m, ECQM137V7Elements.Encounter_Inpatient, ECQM137V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        || isInterventionOrder(visit, m, ECQM137V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        || wasInterventionPerformedInHistory(visit, m, ECQM137V7Elements.Hospice_Care_Ambulatory, patientHistoryList)


    )
  }

  //Met Crireria
  //Numerator 1: Patients who initiated treatment within 14 days of the diagnosis

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      wasEncounterStartsAfterEncounterInXDays(visit, m, AdminElements.Encounter_Date, ECQM137V7Elements.Alcohol_And_Drug_Dependence_Treatment, 14, patientHistoryList)
        || wasEncounterStartsAfterEncounterInXDays(visit, m, AdminElements.Encounter_Date, ECQM137V7Elements.Psych_Visit___Psychotherapy, 14, patientHistoryList)


    )

  }
}


