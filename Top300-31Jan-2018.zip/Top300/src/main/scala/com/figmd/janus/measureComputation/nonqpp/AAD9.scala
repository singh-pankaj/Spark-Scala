package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AAD9Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD 09
* Measure Title              :- Biopsy: Anatomic Location Accuracy
* Measure Description        :- Percentage of patients with skin biopsy specimens and a diagnosis of cutaneous basal or
*                               squamous cell carcinoma (including in situ disease) for which the biopsying clinician
*                               documented the incorrect anatomical site of the biopsy
* Calculation Implementation :- Procedure Specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object AAD9 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAD9"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession,initialRDD
      , AAD9Elements.Cutaneous_Biopsy_Grp
      , AAD9Elements.Cutaneous_Scc_Or_Bcc
      , AAD9Elements.Biopsy_Site_Documented_In_Pathology_Report_Grp
      , AAD9Elements.Biopsy_Site_Documented_In_Biopsy_Tracking_System_Grp
      , AAD9Elements.Incorrect_Anatomical_Site_Grp
    ).collect.toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMetRdd(intermediateA, patientHistoryList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()
    }

  }

  // IPP criteria
  def getIpp(initialRDD:RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
      &&
      wasDiagnosisPerformedAfterProcedure(visit, m, AAD9Elements.Cutaneous_Biopsy_Grp, patientHistoryList, AAD9Elements.Cutaneous_Scc_Or_Bcc )
      &&
      isProcedurePerformedDuringEncounter(visit, m, AAD9Elements.Cutaneous_Biopsy_Grp)
    )
  }

  // Met criteria
  def getMetRdd(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      wasInterventionPerformedfterProcedurePerformedInHistory(visit, m, AAD9Elements.Cutaneous_Biopsy_Grp, patientHistoryList, AAD9Elements.Biopsy_Site_Documented_In_Pathology_Report_Grp )
      &&
      wasInterventionPerformedfterProcedurePerformedInHistory(visit, m, AAD9Elements.Cutaneous_Biopsy_Grp, patientHistoryList, AAD9Elements.Biopsy_Site_Documented_In_Biopsy_Tracking_System_Grp )
      &&
      wasInterventionPerformedfterProcedurePerformedInHistory(visit, m, AAD9Elements.Cutaneous_Biopsy_Grp, patientHistoryList, AAD9Elements.Incorrect_Anatomical_Site_Grp )
    )
  }
}
