package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,AAO17Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO17
* Measure Title               :- Age-related Hearing Loss: Advanced Diagnostic Imaging of Bilateral Presbycusis or Symmetric SNHL
* Measure Description         :- Percentage of patients age 60 years and older with a diagnosis of bilateral presbycusis or symmetric sensorineural hearing loss
                                 who were NOT ordered magnetic resonance imaging (MRI) or a computed tomography scan (CT scan) of the brain,
                                 temporal bone or internal auditory canal for the primary indication of hearing loss.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMIT.SINGH
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object AAO17 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO17"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      AAO17Elements.Bilateral_Presbycusis,
      AAO17Elements.Symmetric_Sensorineural_Hearing_Loss,
      AAO17Elements.Dizziness,
      AAO17Elements.Tinnitus,
      AAO17Elements.Cranial_Nerve_Abnormality,
      AAO17Elements.Head_Injury,
      AAO17Elements.Otosclerosis,
      AAO17Elements.Chronic_Otitis_Media,
      AAO17Elements.Hearing_Loss,
      AAO17Elements.Hearing_Loss_Due_To_Disease,
      AAO17Elements.Mri_Or_Ct_Scan

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients age 60 years and older diagnosed with bilateral presbycusis or symmetric sensorineural hearing loss
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
        isAgeAbove(visit, m, true, 60)
    &&  isVisitTypeIn(visit,m,
          AAO17Elements.Adult_Outpatient_Visit,
          AAO17Elements.Office_Visit,
          AAO17Elements.Ambulatory_Ed_Visit
                      )

    &&  (    wasDiagnosedBeforeOrEqualEncounter(visit, m, AAO17Elements.Bilateral_Presbycusis , patientHistoryBroadcastList)
          || wasDiagnosedBeforeOrEqualEncounter(visit, m, AAO17Elements.Symmetric_Sensorineural_Hearing_Loss , patientHistoryBroadcastList)
        )


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients who were NOT ordered magnetic resonance imaging (MRI) or a computed tomography scan (CT scan) of the brain
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        !isDiagnosticStudyPerformed(visit, m, AAO17Elements.Mri_Or_Ct_Scan ,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Medical reason that may require an MRI or CT scan of the brain, temporal bone or internal auditory canal etc..
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
             (
                   wasDiagnosedBeforeOrEqualEncounter(visit, m, AAO17Elements.Dizziness , patientHistoryBroadcastList)
               ||  wasDiagnosedBeforeOrEqualEncounter(visit, m, AAO17Elements.Tinnitus , patientHistoryBroadcastList)
               ||  wasDiagnosedBeforeOrEqualEncounter(visit, m, AAO17Elements.Cranial_Nerve_Abnormality , patientHistoryBroadcastList)
               ||  wasDiagnosedBeforeOrEqualEncounter(visit, m, AAO17Elements.Head_Injury , patientHistoryBroadcastList)
               ||  wasDiagnosedBeforeOrEqualEncounter(visit, m, AAO17Elements.Otosclerosis , patientHistoryBroadcastList)
               ||  wasDiagnosedBeforeOrEqualEncounter(visit, m, AAO17Elements.Chronic_Otitis_Media , patientHistoryBroadcastList)
               ||  wasDiagnosedBeforeOrEqualEncounter(visit, m, AAO17Elements.Hearing_Loss , patientHistoryBroadcastList)
               ||  wasDiagnosedBeforeOrEqualEncounter(visit, m, AAO17Elements.Hearing_Loss_Due_To_Disease , patientHistoryBroadcastList)
               ||  isInterventionPerformedDuringEncounter(visit,m,AAO17Elements.Cochlear_Implant_Referral)
               ||  isInterventionPerformedDuringEncounter(visit,m,AAO17Elements.Surgical_Management_Referral)

             )



    )
  }
}