package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AAO13Elements, AdminElements, MeasureProperty,CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO13
* Measure Title               :- Bell's Palsy: Inappropriate Use of Magnetic Resonance Imaging or Computed Tomography Scan
* Measure Description         :- Percentage of patients age 16 years and older with a new onset diagnosis of Bell’s palsy
                                 within the past 3 months who had a magnetic resonance imaging (MRI) or a computed tomography scan (CT)
                                 of the internal auditory canal, head, neck or brain ordered for the primary diagnosis of Bell’s palsy.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Lower score indicates better quality.
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- VRUSHALI.GHOLAP
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object AAO13 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO13"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,AAO13Elements.Bells_Palsy
      ,AAO13Elements.Ct_Or_Mri_Scan
      ,AAO13Elements.Brain_Tumor
      ,AAO13Elements.Cerebrovascular_Disease__Stroke__Tia
      ,AAO13Elements.Other_Neurological_Disorder
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
/*-----------------------------------------------------------------------------------------------------------------------
  All patients age 16 years and older with a diagnosis of Bell’s palsy at the date of service.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
         isAgeAbove(visit,m,true,16)
      && isVisitTypeIn(visit,m
            ,AAO13Elements.Inpatient_Consultation
            ,AAO13Elements.Discharge_Services___Hospital_Inpatient
            ,AAO13Elements.Hospital_Inpatient_Visit___Initial
            ,AAO13Elements.Discharge_Services__Observation_Care
            ,AAO13Elements.Subsequent_Observation_Care
            ,AAO13Elements.Hospital_Observation_Care___Initial
            ,AAO13Elements.Office_Consultation
            ,AAO13Elements.Office_Visit
            ,AAO13Elements.Office_Or_Other_Outpatient_Visit
            ,AAO13Elements.Subsequent_Hospital_Care
            ,AAO13Elements.Nursing_Facility_Visit)
      && wasDiagnosedBeforeEncounterWithinXMonths(visit,m,AdminElements.Encounter_Date,AAO13Elements.Bells_Palsy,3,patientHistoryBroadcastList)
    )
  }
/*-----------------------------------------------------------------------------------------------------------------------
  Patients who whom a MRI or CT scan of the internal auditory canal, head, neck, or brain was ordered
  within 3 months of a diagnosis of Bell’s palsy.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
    wasProcedurePerformedXMonthsAfterDiagnosis(visit,m,AAO13Elements.Bells_Palsy,AAO13Elements.Ct_Or_Mri_Scan,3,patientHistoryBroadcastList)
    )
  }

/*-----------------------------------------------------------------------------------------------------------------------
  Medical reason for ordering an MRI or CT scan of the internal auditory canal, head, neck or brain for
  the primary diagnosis of Bell’s palsy include:

e  •Patient with diagnosis of Bell’s palsy more than 3 months prior to the date of the referral or performance of imaging with no signs of recovery.
  •Patient with recurrent diagnosis of Bell’s palsy.
  •Patient with paralysis limited to a specific branch, or branches, of the facial nerve.
  •Patients with paralysis associated with other cranial nerve abnormalities, including olfactory nerve, glossopharyngeal nerve,
   vagus nerve, and hypoglossal nerve.
  •Patient with other diagnosed neurological abnormalities, including simultaneous sudden hearing loss, tinnitus, and/or dizziness;
   stroke; tumor; seizures; extremity weakness; and/or extremity hypesthesia.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
         wasDiagnosedBeforeProcedureInXMonths(visit,m,AAO13Elements.Ct_Or_Mri_Scan,AAO13Elements.Bells_Palsy,AAO13Elements.No_Sign_Of_Recovery, 3,patientHistoryBroadcastList)
      || wasProcedurePerformedWithReason(visit,m,AAO13Elements.Ct_Or_Mri_Scan,AAO13Elements.Brain_Tumor,CompareOperator.EQUAL,patientHistoryBroadcastList)
      || wasProcedurePerformedWithReason(visit,m,AAO13Elements.Ct_Or_Mri_Scan,AAO13Elements.Cerebrovascular_Disease__Stroke__Tia,CompareOperator.EQUAL,patientHistoryBroadcastList)
      || wasProcedurePerformedWithReason(visit,m,AAO13Elements.Ct_Or_Mri_Scan,AAO13Elements.Other_Neurological_Disorder,CompareOperator.EQUAL,patientHistoryBroadcastList)

    )
  }


}