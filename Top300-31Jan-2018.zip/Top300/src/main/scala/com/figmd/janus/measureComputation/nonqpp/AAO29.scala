package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate,spark}
import com.figmd.janus.measureComputation.master.{AAO20Elements, AAO29Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO29
* Measure Title               :- Quality of Life for Patients with Neurotology Disorders
* Measure Description         :- Percentage of neurotology patients whose most recent Quality of Life scores were maintained or improved during the measurement period.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KAJAL_JADHAO_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object AAO29 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO29"
  val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , AAO29Elements.Neurotology_Disorder
      , AAO29Elements.Neurotology_Evaluation
      , AAO29Elements.Dizziness_Handicap_Inventory_Score
      , AAO29Elements.Promis_29_Profile
      , AAO29Elements.Promis_Global_Health_Scale
      , AAO29Elements.Neuro_Qol
      , AAO29Elements.Short_Form__Sf_36_
      , AAO29Elements.Vertigo_Symptom_Scale__Vss_
      , AAO29Elements.Vestibular_Activities_Of_Daily_Living_Scale__Vadl_
      , AAO29Elements.Activities_Specific_Balance_Confidence__Abc__Scale
      , AAO29Elements.Vestibular_Activities_And_Participation__Vap__Measure
      , AAO29Elements.Vestibular_Rehabilitation_Benefit_Questionnaire__Vrbq_
      , AAO29Elements.University_Of_California_Los_Angeles_Dizziness_Questionnaire__Ucla_Dq_
      , AAO29Elements.Patient_Refusal)
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val patientHistoryList1 = countElement(patientHistoryRDD,m
      , AAO29Elements.Office_Visit
      , AAO29Elements.Office_Consultation
      , AAO29Elements.Office_Or_Other_Outpatient_Visit
      , AAO29Elements.Neurotology_Evaluation)

    val patientHistoryList2 = countElement(patientHistoryRDD,m
      , AAO29Elements.Dizziness_Handicap_Inventory_Score
      , AAO29Elements.Promis_29_Profile
      , AAO29Elements.Promis_Global_Health_Scale
      , AAO29Elements.Neuro_Qol
      , AAO29Elements.Short_Form__Sf_36_
      , AAO29Elements.Vertigo_Symptom_Scale__Vss_
      , AAO29Elements.Vestibular_Activities_Of_Daily_Living_Scale__Vadl_
      , AAO29Elements.Activities_Specific_Balance_Confidence__Abc__Scale
      , AAO29Elements.Vestibular_Activities_And_Participation__Vap__Measure
      , AAO29Elements.Vestibular_Rehabilitation_Benefit_Questionnaire__Vrbq_
      ,AAO29Elements.University_Of_California_Los_Angeles_Dizziness_Questionnaire__Ucla_Dq_)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList,patientHistoryList1)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList,patientHistoryRDD,patientHistoryList2)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients aged 18 years and older with neurotology specific diagnosis seen at least two times during the measurement period.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryList1: List[(String, Int)]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>

      isPatientAdult(visit,m)
        && wasDiagnosedWithBeforeOrEqualEncounter(visit,m,AAO29Elements.Neurotology_Disorder,patientHistoryBroadcastList)
        && getEncounterCountFromHistory(visit, m, 2, true, patientHistoryList1)
        && (isVisitTypeIn(visit,m
        ,AAO29Elements.Office_Visit
        ,AAO29Elements.Office_Consultation
        ,AAO29Elements.Office_Or_Other_Outpatient_Visit)
        || isInterventionPerformed(visit,m,AAO29Elements.Neurotology_Evaluation,patientHistoryBroadcastList))
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with age appropriate quality of life assessment whose most recent scores were maintained or improved on the same age appropriate quality of life assessment administered twice during the measurement period.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryRDD: RDD[CassandraRow],patientHistoryList2: List[(String, Int)]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    val LeastRecentList =  spark.sparkContext.broadcast(leastRecentPatientListDuringMeasurementPeriod(patientHistoryRDD, m
       , AAO29Elements.Dizziness_Handicap_Inventory_Score
      , AAO29Elements.Promis_29_Profile
      , AAO29Elements.Promis_Global_Health_Scale
      , AAO29Elements.Neuro_Qol
      , AAO29Elements.Short_Form__Sf_36_
      , AAO29Elements.Vertigo_Symptom_Scale__Vss_
      , AAO29Elements.Vestibular_Activities_Of_Daily_Living_Scale__Vadl_
      , AAO29Elements.Activities_Specific_Balance_Confidence__Abc__Scale
      , AAO29Elements.Vestibular_Activities_And_Participation__Vap__Measure
      , AAO29Elements.Vestibular_Rehabilitation_Benefit_Questionnaire__Vrbq_
      , AAO29Elements.University_Of_California_Los_Angeles_Dizziness_Questionnaire__Ucla_Dq_))

    val MostRecentList =  spark.sparkContext.broadcast(mostRecentPatientListDuringMP(patientHistoryRDD, m,
        AAO29Elements.Dizziness_Handicap_Inventory_Score
      , AAO29Elements.Promis_29_Profile
      , AAO29Elements.Promis_Global_Health_Scale
      , AAO29Elements.Neuro_Qol
      , AAO29Elements.Short_Form__Sf_36_
      , AAO29Elements.Vertigo_Symptom_Scale__Vss_
      , AAO29Elements.Vestibular_Activities_Of_Daily_Living_Scale__Vadl_
      , AAO29Elements.Activities_Specific_Balance_Confidence__Abc__Scale
      , AAO29Elements.Vestibular_Activities_And_Participation__Vap__Measure
      , AAO29Elements.Vestibular_Rehabilitation_Benefit_Questionnaire__Vrbq_
      ,AAO29Elements.University_Of_California_Los_Angeles_Dizziness_Questionnaire__Ucla_Dq_))


      denominatorRDD.filter(visit =>

        isCountGreaterOrEqual(visit, m, 3, true, patientHistoryList2)
        && isLeastAndMostRecentValueStatus(visit,m,AAO29Elements.Dizziness_Handicap_Inventory_Score,0,MostRecentList,LeastRecentList)
        && isLeastAndMostRecentValueStatus(visit,m,AAO29Elements.Promis_29_Profile,0,MostRecentList,LeastRecentList)
        && isLeastAndMostRecentValueStatus(visit,m,AAO29Elements.Promis_Global_Health_Scale,0,MostRecentList,LeastRecentList)
        && isLeastAndMostRecentValueStatus(visit,m,AAO29Elements.Neuro_Qol,0,MostRecentList,LeastRecentList)
        && isLeastAndMostRecentValueStatus(visit,m,AAO29Elements.Short_Form__Sf_36_,0,MostRecentList,LeastRecentList)
        && isLeastAndMostRecentValueStatus(visit,m,AAO29Elements.Vertigo_Symptom_Scale__Vss_,0,MostRecentList,LeastRecentList)
        && isLeastAndMostRecentValueStatus(visit,m,AAO29Elements.Vestibular_Activities_Of_Daily_Living_Scale__Vadl_,0,MostRecentList,LeastRecentList)
        && isLeastAndMostRecentValueStatus(visit,m,AAO29Elements.Activities_Specific_Balance_Confidence__Abc__Scale,0,MostRecentList,LeastRecentList)
        && isLeastAndMostRecentValueStatus(visit,m,AAO29Elements.Vestibular_Activities_And_Participation__Vap__Measure,0,MostRecentList,LeastRecentList)
        && isLeastAndMostRecentValueStatus(visit,m,AAO29Elements.Vestibular_Rehabilitation_Benefit_Questionnaire__Vrbq_,0,MostRecentList,LeastRecentList)
        && isLeastAndMostRecentValueStatus(visit,m,AAO29Elements.University_Of_California_Los_Angeles_Dizziness_Questionnaire__Ucla_Dq_,0,MostRecentList,LeastRecentList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who are unable or decline to complete screening tool.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      isCommunicationFromProvidertoProvider(visit,m,AAO29Elements.Patient_Refusal,patientHistoryBroadcastList)

    )
  }
}