package com.figmd.janus.measureComputation.nonqpp
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AAD3Elements, CalenderUnit, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD3
* Measure Title              :- Basal Cell Carcinoma/Squamous Cell Carcinoma: Mohs Surgery for Superficial Basal Cell Carcinoma of the Trunk for Immune Competent Patients
* Measure Description        :- The percentage of immune‐competent patients with pathologically‐proven primary superficial basal cell carcinoma (BCC) lesions on the trunk (chest, back, abdomen) who are treated with Mohs surgery.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/

object AAD3 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAD3"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patient_history_list = getPatientHistory(sparkSession, initialRDD
      ,AAD3Elements.Mohs_Surgery_Grp
      ,AAD3Elements.Cutaneous_Biopsy_Of_Trunk_Grp
      ,AAD3Elements.Basal_Cell_Carcinoma_Of_The_Trunk_Grp
      ,AAD3Elements.Immunocompromised_Conditions
      ,AAD3Elements.Hiv
      ,AAD3Elements.Organ_Transplant
      ,AAD3Elements.Active_Pharmacologic_Immunosuppression
      ,AAD3Elements.Hematologic_Malignancy_Grp
      ,AAD3Elements.Superficial_Basal_Cell_Carcinoma
      ,AAD3Elements.Documentation_Of_Mixed_Tumor_Histology).collect().toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter denominator Exclusions
      val denominatorExclusionRDD = getDenominatorExclusionRdd(ippRDD, patientHistoryList)
      denominatorExclusionRDD.cache()

      //eligible initial population RDD
      val intermediateRDD = getSubtractRDD(ippRDD, denominatorExclusionRDD)

      // Filter Intermediate Met
      val intermediateB = getMet(intermediateRDD, patientHistoryList)
      intermediateB.cache()

      // Filter Numerator Exclusion
      val numeratorExclusionRDD = getNumeratorExclusionRdd(intermediateB, patientHistoryList)


      val metRDD = getSubtractRDD(intermediateB, numeratorExclusionRDD)

      // Filter not met
      val intermediateC = getSubtractRDD(intermediateB, metRDD)
      val notMetRDD = getSubtractRDD(intermediateC, numeratorExclusionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, denominatorExclusionRDD, metRDD, numeratorExclusionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()
    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  * All pathologically-proven primary superficial basal cell carcinoma (BCC) lesions on the trunk (chest, back, abdomen) on immune-competent patients treated by the provider within the reporting period.
  * Ages 18 and older at the start of the measurement period
  *-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit=>
      isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
        &&
        wasProcedurePerformedInHistory(visit,m,AAD3Elements.Cutaneous_Biopsy_Of_Trunk_Grp,patientHistoryList)
        &&(
        wasDiagnosedAfterProcedure(visit,m,AAD3Elements.Basal_Cell_Carcinoma_Of_The_Trunk_Grp,patientHistoryList,AAD3Elements.Cutaneous_Biopsy_Of_Trunk_Grp)
          &&
          wasDiagnosedInHistory(visit,m,AAD3Elements.Basal_Cell_Carcinoma_Of_The_Trunk_Grp,patientHistoryList)
        )
    )
  }


/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 Patients whose immune system is compromised by disease or active treatment of disease.
Examples of immunocompromised patients include
but are not limited to HIV, organ transplant, hematologic malignancy, or pharmacologic immunosuppression.
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
def getDenominatorExclusionRdd(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

rdd.filter(visit=>
  wasDiagnosedWithInHistory(visit,m,AAD3Elements.Immunocompromised_Conditions,patientHistoryList)
    || wasDiagnosedWithInHistory(visit,m,AAD3Elements.Hiv,patientHistoryList)
    || wasDiagnosedWithInHistory(visit,m,AAD3Elements.Organ_Transplant,patientHistoryList)
    || wasDiagnosedWithInHistory(visit,m,AAD3Elements.Hematologic_Malignancy_Grp,patientHistoryList)
    || wasDiagnosedWithInHistory(visit,m,AAD3Elements.Active_Pharmacologic_Immunosuppression,patientHistoryList)
)
}

/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* Number of patients with pathologically‐ proven primary superficial BCC of the trunk treated by the provider utilizing Mohs surgery [CPT 17313].
* -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
def getMet(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
rdd.filter(visit=>
    ( wasDiagnosedAfterProcedure(visit,m,AAD3Elements.Mohs_Surgery_Grp,patientHistoryList,AAD3Elements.Basal_Cell_Carcinoma_Of_The_Trunk_Grp,AAD3Elements.Superficial_Basal_Cell_Carcinoma)
      && wasDiagnosedInHistory(visit,m,AAD3Elements.Mohs_Surgery_Grp,patientHistoryList)
    )
    &&
    ( wasDiagnosedAfterProcedure(visit,m,AAD3Elements.Superficial_Basal_Cell_Carcinoma,patientHistoryList,AAD3Elements.Cutaneous_Biopsy_Of_Trunk_Grp)
      && wasDiagnosedInHistory(visit,m,AAD3Elements.Superficial_Basal_Cell_Carcinoma,patientHistoryList)
    )
)
}

/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
* • Tumors that have a pathologically documented mixed histology including a more aggressive histologic subtype, or a more aggressive tumor is found on any stage if Mohs surgery is performed.
Examples of pathology report documentation for this exclusion include but are not limited to:
1) Pathology report states that it cannot exclude a deeper or more aggressive tumor histology for any reason other than because it is a partial biopsy sample
2) Pathology report states that there is a collision tumor with another tumor that has a more aggressive histology
*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- */
def getNumeratorExclusionRdd(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
rdd.filter(visit=>
  wasDiagnosedAfterProcedure(visit,m,AAD3Elements.Documentation_Of_Mixed_Tumor_Histology,patientHistoryList,AAD3Elements.Mohs_Surgery_Grp)
)
}

}
