package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AQUA12
* Measure Title              :- Benign Prostate Hyperplasia: IPSS improvement after diagnosis
* Measure Description        :- Percentage of patients with NEW diagnosis of clinically significant BPH who had IPSS (international prostate symptoms score)
 *                              or AUASS (American urological association symptom score) improvement by ≥20%.
 *
*
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Sawant
----------------------------------------------------------------------------------------------------------------------------*/

object AQUA12 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "AQUA12"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      AQUA12Elements.Benign_Prostate_Hyperplasia_New
      , AQUA12Elements.Ipss_Baseline
      , AQUA12Elements.Auass_Baseline
      , AQUA12Elements.International_Prostate_Symptoms_Score
      , AQUA12Elements.American_Urological_Association_Symptom_Score
      , AQUA12Elements.Ips_Score
      , AQUA12Elements.Auas_Score
      , AQUA12Elements.Difference_Ipss_Baseline___Ips_Score
      , AQUA12Elements.Difference_Auass_Baseline___Auas_Score

    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRDD(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMetRDD(intermediateA, patientHistoryList)
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }
  /*-------------------------------------------------------------------------------------------------------------------------
   *  Number of patients with a new diagnosis of benign prostatic hyperplasia(BPH) and baseline IPSS / AUASS ≥8
   * ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
           isMale(visit,m)
        && isDiagnosis(visit,m,AQUA12Elements.Benign_Prostate_Hyperplasia_New,patientHistoryList)
        &&
        (     wasInterventionPerformedWithResultXDuringDiagnosis(visit,m,AQUA12Elements.Ipss_Baseline,AQUA12Elements.Benign_Prostate_Hyperplasia_New,"DURING",8,"ge",patientHistoryList)
          ||  wasInterventionPerformedWithResultXDuringDiagnosis(visit,m,AQUA12Elements.Auass_Baseline,AQUA12Elements.Benign_Prostate_Hyperplasia_New,"DURING",8,"ge",patientHistoryList)
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
 * IPSS <8 at baseline
 * ----------------------------------------------------------------------------------------------------------------------------*/
  def getExclusionRDD(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
      (     wasInterventionPerformedWithResultXDuringDiagnosis(visit,m,AQUA12Elements.Ipss_Baseline,AQUA12Elements.Benign_Prostate_Hyperplasia_New,"DURING",8,"lt",patientHistoryList)
        ||  wasInterventionPerformedWithResultXDuringDiagnosis(visit,m,AQUA12Elements.Auass_Baseline,AQUA12Elements.Benign_Prostate_Hyperplasia_New,"DURING",8,"lt",patientHistoryList)
      )
    )

  }
  /*-------------------------------------------------------------------------------------------------------------------------
    Number of patients with a new diagnosis of benign prostatic hyperplasia(BPH) with a a baseline IPSS/AUASS ≥8 (definiing at least "moderate" symptoms)
     who are documented to have an improvement (decrease) in IPSS/AUASS by at least 20% within 12 months of diagnosis
   * ----------------------------------------------------------------------------------------------------------------------------*/
  def getMetRDD(intermediateA: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>

      (     (   wasInterventionStartsAfterStartOfDiagnosisWithinXPeriod(visit,m,AQUA12Elements.Benign_Prostate_Hyperplasia_New,AQUA12Elements.International_Prostate_Symptoms_Score,12,patientHistoryList)
            ||  wasInterventionStartsAfterStartOfDiagnosisWithinXPeriod(visit,m,AQUA12Elements.Benign_Prostate_Hyperplasia_New,AQUA12Elements.American_Urological_Association_Symptom_Score,12,patientHistoryList)
            )
        ||  (   wasInterventionStartsAfterStartOfDiagnosisWithinXPeriod(visit,m,AQUA12Elements.Benign_Prostate_Hyperplasia_New,AQUA12Elements.Ips_Score,12,patientHistoryList)
            ||  wasInterventionStartsAfterStartOfDiagnosisWithinXPeriod(visit,m,AQUA12Elements.Benign_Prostate_Hyperplasia_New,AQUA12Elements.Auas_Score,12,patientHistoryList)
            )
      )
     &&
            (
                wasInterventionStartsAfterStartOfDiagnosisWithinXPeriodWithResult(visit,m,AQUA12Elements.Benign_Prostate_Hyperplasia_New,AQUA12Elements.Difference_Ipss_Baseline___Ips_Score,"MONTH",12,20,"ge","le",patientHistoryList)
            ||  wasInterventionStartsAfterStartOfDiagnosisWithinXPeriodWithResult(visit,m,AQUA12Elements.Benign_Prostate_Hyperplasia_New,AQUA12Elements.Difference_Auass_Baseline___Auas_Score,"MONTH",12,20,"ge","le",patientHistoryList)
            )
    )
  }

}



