package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CompareOperator, MeasureProperty, PINN9Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PINN9
* Measure Title               :- Hypertension: Blood Pressure Treatment and Control for High Risk Patients
* Measure Description         :- Proportion of adults, ≥ 18 years of age, with both hypertension and a ≥ 10% CVD risk OR
*                                high-risk diagnosis (i.e. ASCVD, chronic kidney disease, diabetes) who were prescribed
*                                antihypertensive medication or who had adequately controlled blood pressure
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.7
* Latest GIT Version/Tag(CRA) :- 1.7
----------------------------------------------------------------------------------------------------------------------------*/

object PINN9 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "PINN9"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
                      , PINN9Elements.ACC_Encounter_Code_Set
                      , PINN9Elements.Diabetes
                      , PINN9Elements.Chronic_Kidney_Disease
                      , PINN9Elements.Atherosclerotic_Cardiovascular_Disease
                      , PINN9Elements.Beta_Blocker_Therapy
                      , PINN9Elements.ACE_Inhibitor_or_ARB
                      , PINN9Elements.Calcium_Channel_Blockers
                      , PINN9Elements.Diuretics_Medications
                      , PINN9Elements.Systolic_Blood_Pressure
                      , PINN9Elements.Diastolic_Blood_Pressure
                      )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    val mostRecentHistoryBroadcastList = sparkSession.sparkContext.broadcast(mostRecentPatientList(patientHistoryRDD, PINN9Elements.ACC_Encounter_Code_Set))

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList, mostRecentHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList, mostRecentHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      mostRecentHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Adults, ≥ 18 years of age, with both hypertension and a ≥ 10% CVD risk OR high-risk diagnosis (i.e. ASCVD, chronic kidney disease, diabetes)
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],
                                mostRecentHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
          isPatientAdult(visit, m)
        &&
          encounterPerformed(visit, m, PINN9Elements.ACC_Encounter_Code_Set)
        &&
          (
              isAssessmentValueOnEncounter(visit, m, PINN9Elements.CVD_Risk_Calculator, 10, CompareOperator.GREATER_EQUAL)
            ||
              wasDiagnosedInHistory(visit, m, PINN9Elements.Diabetes, patientHistoryBroadcastList)
            ||
              wasDiagnosedInHistory(visit, m, PINN9Elements.Chronic_Kidney_Disease, patientHistoryBroadcastList)
            ||
              wasDiagnosedInHistory(visit, m, PINN9Elements.Atherosclerotic_Cardiovascular_Disease, patientHistoryBroadcastList)
          )
        &&
          wasBPAdequatelyControlledBeforeMostRecentEncounterPerformed(visit, m, PINN9Elements.ACC_Encounter_Code_Set, 24,
                        patientHistoryBroadcastList, mostRecentHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Two instances of blood pressure levels for the patient in specified range should be excluded from denominator population who are pregnant.
These patients should be excluded:
1st instance of blood pressure with specified range + diagnosis pregnancy
2nd instance of blood pressure with specified range + diagnosis pregnancy
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],
                            mostRecentHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
          isDiagnosedDuringEncounter(visit, m, PINN9Elements.Pregnancy)
        &&
          wasBPAdequatelyControlledBeforeMostRecentEncounterPerformed(visit, m, PINN9Elements.ACC_Encounter_Code_Set, 24,
              patientHistoryBroadcastList, mostRecentHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
 Patients who were prescribed antihypertensive medication or who had adequately controlled blood pressure
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
        isInterVentionPerformedValueDuringEncounter(visit, m, PINN9Elements.Diastolic_Blood_Pressure, 80, CompareOperator.LESS)
      &&
        isInterVentionPerformedValueDuringEncounter(visit, m, PINN9Elements.Systolic_Blood_Pressure, 130, CompareOperator.LESS)
      )
      ||
      (
          isInterVentionPerformedValueDuringEncounter(visit, m, PINN9Elements.Diastolic_Blood_Pressure, 80, CompareOperator.GREATER_EQUAL)
        &&
          isInterVentionPerformedValueDuringEncounter(visit, m, PINN9Elements.Systolic_Blood_Pressure, 130, CompareOperator.GREATER_EQUAL)
        &&
        (
            wasMedicationAdministeredInHistory(visit, m, PINN9Elements.Beta_Blocker_Therapy, patientHistoryBroadcastList)
          ||
            wasMedicationAdministeredInHistory(visit, m, PINN9Elements.ACE_Inhibitor_or_ARB, patientHistoryBroadcastList)
          ||
            wasMedicationAdministeredInHistory(visit, m, PINN9Elements.Calcium_Channel_Blockers, patientHistoryBroadcastList)
          ||
            wasMedicationAdministeredInHistory(visit, m, PINN9Elements.Diuretics_Medications, patientHistoryBroadcastList)
        )
      )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
No-System Reason
No-Medical Reason
No-Patient Reason
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
          isAssessmentPerformedDuringEncounter(visit, m, PINN9Elements.System_Reason)
        ||
          isAssessmentPerformedDuringEncounter(visit, m, PINN9Elements.Patient_Reason)
        ||
          isAssessmentPerformedDuringEncounter(visit, m, PINN9Elements.Medical_Reason)
    )
  }



}