package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP191Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 191
* Measure Title              :- Cataracts: 20/40 or Better Visual Acuity within 90 Days Following Cataract Surgery
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of uncomplicated
                                cataract who had cataract surgery and no significant ocular conditions impacting the
                                visual outcome of surgery and had best-corrected visual acuity of 20/40 or better
                                (distance or near) achieved within 90 days following the cataract surgery
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher score equals better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp191 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp191"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
                                                                  , QPP191Elements.Cataract_Surgery
                                                                  , QPP191Elements.Significant_Ocular_Conditions
                                                                  , QPP191Elements.Cataract_Surgery_Eye
                                                                  , QPP191Elements.Significant_Ocular_Conditions__Eye
                                                                  , QPP191Elements.Corrected_Visual_Acuity_20_40_Grp
                                                                  , QPP191Elements.Best_Corrected_Right_Eye_Va_Value
                                                                  , QPP191Elements.Visual_Acuity_20_40_Or_Better
                                                                  , QPP191Elements.Un_Specified_Left_Eye_Va_Value
                                                                  , QPP191Elements.Un_Specified_Right_Eye_Va_Method
                                                                  , QPP191Elements.Un_Corrected_Left_Eye_Va_Value
                                                                  , QPP191Elements.Un_Corrected_Right_Eye_Va_Value
                                                                  , QPP191Elements.Best_Corrected_Left_Eye_Va_Value
                                                                  , QPP191Elements.Best_Corrected_Right_Eye_Va_Value
                                                                  , QPP191Elements.Corrected_Visual_Acuity_20_40_Reason_Not_Specified_Grp
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    //Visual Acuity Calculation
    val Correct_VA_Values: Array[String] = Array("20/10", "20/11", "20/12", "20/13", "20/14", "20/15", "20/16", "20/17", "20/18", "20/19", "20/2", "20/20", "20/3", "20/4", "20/5", "20/6", "20/7", "20/8", "20/9")

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      /*exclusion RDD*/
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, Correct_VA_Values, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*------------------------------------------------------------------------------
    All patients aged 18 years and older who had cataract surgery and no significant ocular conditions impacting the
    visual outcome of surgery
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)


    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isProcedurePerformedDuringEncounter(visit, m, QPP191Elements.Cataract_Surgery)
        && wasProcedurePerformedBeforeEndInDays(visit, m, QPP191Elements.Cataract_Surgery, 92, patientHistoryBroadcastList)
        && !isProcedurePerformedDuringEncounter(visit, m, QPP191Elements.Cataract_Surgery_Modifiers)
    )
  }

  /*------------------------------------------------------------------------------
    Patients with significant ocular conditions impacting the visual outcome of surgery
   ------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP191Elements.Significant_Ocular_Conditions, patientHistoryBroadcastList)
        && checkEyeElementBeforeDiagnosisEyesElement(visit, m, QPP191Elements.Cataract_Surgery_Eye, patientHistoryBroadcastList, QPP191Elements.Significant_Ocular_Conditions__Eye)

    )
  }


  /*------------------------------------------------------------------------------
   Patients who had best-corrected visual acuity of 20/40 or better (distance or near) achieved within 90 days following
    cataract surgery
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], Correct_VA_Values: Array[String], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        isAssessmentPerformed(visit, m, QPP191Elements.Corrected_Visual_Acuity_20_40_Grp, patientHistoryBroadcastList)
          || wasBestVisualAucityWithResulAfterXDaysProcedure(visit, m, QPP191Elements.Best_Corrected_Visual_Acuity, QPP191Elements.Cataract_Surgery, QPP191Elements.Visual_Acuity_20_40_Or_Better, 90, patientHistoryBroadcastList)
          || wasCorrectedVisualAcuityValueGreaterXDays(visit, m, QPP191Elements.Un_Specified_Left_Eye_Va_Value, QPP191Elements.Cataract_Surgery, 90, Correct_VA_Values, patientHistoryBroadcastList)
          || wasCorrectedVisualAcuityValueGreaterXDays(visit, m, QPP191Elements.Un_Specified_Right_Eye_Va_Method, QPP191Elements.Cataract_Surgery, 90, Correct_VA_Values, patientHistoryBroadcastList)
          || wasCorrectedVisualAcuityValueGreaterXDays(visit, m, QPP191Elements.Un_Corrected_Left_Eye_Va_Value, QPP191Elements.Cataract_Surgery, 90, Correct_VA_Values, patientHistoryBroadcastList)
          || wasCorrectedVisualAcuityValueGreaterXDays(visit, m, QPP191Elements.Un_Corrected_Right_Eye_Va_Value, QPP191Elements.Cataract_Surgery, 90, Correct_VA_Values, patientHistoryBroadcastList)
          || wasCorrectedVisualAcuityValueGreaterXDays(visit, m, QPP191Elements.Best_Corrected_Left_Eye_Va_Value, QPP191Elements.Cataract_Surgery, 90, Correct_VA_Values, patientHistoryBroadcastList)
          || wasCorrectedVisualAcuityValueGreaterXDays(visit, m, QPP191Elements.Best_Corrected_Right_Eye_Va_Value, QPP191Elements.Cataract_Surgery, 90, Correct_VA_Values, patientHistoryBroadcastList)
        )
        && !isInterventionPerformed(visit, m, QPP191Elements.Corrected_Visual_Acuity_20_40_Reason_Not_Specified_Grp, patientHistoryBroadcastList)
    )
  }
}