
package com.figmd.janus.measureComputation.nonqpp

import java.util.Date
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{ACEP22Elements, AdminElements, MeasureProperty}
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.nonqpp.Acep22.wasAssessmentPerformedWithResultBeforeDignosticStudyWithInXHours

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACEP 22
* Measure Title              :- Emergency Medicine: Appropriate Emergency Department Utilization of CT for Pulmonary Embolism
* Measure Description        :- Percentage of emergency department visits during which patients aged 18 years and older had
                                a CT pulmonary angiogram (CTPA) ordered by an emergency care provider, regardless of discharge disposition
                                , with either moderate or high pre-test clinical probability for pulmonary embolism OR positive result or elevated D-dimer level
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Acep22 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Acep22"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, initialRDD
      , ACEP22Elements.Pretest_Clinical_Probability_For_Pulmonary_Embolism
      , ACEP22Elements.Moderate
      , ACEP22Elements.High
      , ACEP22Elements.Positive_Finding
      , ACEP22Elements.Elevated_D_Dimer).collect.toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //filter denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
     /* val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      notEligibleRDD.cache()*/

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      // Filter Intermediate
      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateB)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()
    }
  }

/*-------------------------------------------------------------------------------------------------------------------------
All emergency department visits during which patients aged 18 years and older had a CT pulmonary angiogram (CTPA)
ordered by an emergency care provider, regardless of discharge disposition
----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
           isPatientAdult(visit,m)
        && isVisitTypeIn(visit,m
              ,ACEP22Elements.Emergency_Department_Visit
              ,ACEP22Elements.Critical_Care_Evaluation_And_Management)
        && isDiagnosticStudyDuringEDOrCCEncounter(visit,m,ACEP22Elements.Ct_Pulmonary_Angiogram_Ctpa,ACEP22Elements.Ct_Pulmonary_Angiogram_Ctpa_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP22Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }

/*-------------------------------------------------------------------------------------------------------------------------
Patients with any of the following:
     -  Pregnancy
----------------------------------------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
            isDiagnosisDuringEDOrCCEncounter(visit,m,ACEP22Elements.Pregnancy,ACEP22Elements.Pregnancy_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP22Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Emergency department visits for patients with either:
1.  Moderate or high pre-test clinical probability for pulmonary embolism
       OR
2.  Positive result or elevated D-dimer level
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
          wasAssessmentPerformedWithResultBeforeDignosticStudyWithInXHours(visit,m,ACEP22Elements.Ct_Pulmonary_Angiogram_Ctpa,ACEP22Elements.Pretest_Clinical_Probability_For_Pulmonary_Embolism,ACEP22Elements.Moderate,24,patientHistoryList)
      ||  wasAssessmentPerformedWithResultBeforeDignosticStudyWithInXHours(visit,m,ACEP22Elements.Ct_Pulmonary_Angiogram_Ctpa,ACEP22Elements.Pretest_Clinical_Probability_For_Pulmonary_Embolism,ACEP22Elements.High,24,patientHistoryList)
      ||  wasAssessmentPerformedWithResultBeforeDignosticStudyWithInXHours(visit,m,ACEP22Elements.Ct_Pulmonary_Angiogram_Ctpa,ACEP22Elements.D_Dimer,ACEP22Elements.Positive_Finding,24,patientHistoryList)
      ||  wasAssessmentPerformedWithResultBeforeDignosticStudyWithInXHours(visit,m,ACEP22Elements.Ct_Pulmonary_Angiogram_Ctpa,ACEP22Elements.D_Dimer,ACEP22Elements.Elevated_D_Dimer,24,patientHistoryList)
    )
  }

/*-------------------------------------------------------------------------------------------------------------------------
Medical reason for ordering a CTPA without moderate or high pre-test clinical probability for pulmonary embolism
AND no positive result or elevated D-dimer level (eg, CT ordered for aortic dissection)
----------------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
            isDiagnosticStudyOrderedWithReasonDuringEDOrCCEncounter(visit,m,ACEP22Elements.Ct_Pulmonary_Angiogram_Ctpa,ACEP22Elements.Ct_Pulmonary_Angiogram_Ctpa_Date,ACEP22Elements.Medical_Reason_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP22Elements.Critical_Care_Evaluation_And_Management_Date)
        ||  isDiagnosticStudyOrderedWithReasonDuringEDOrCCEncounter(visit,m,ACEP22Elements.Ct_Pulmonary_Angiogram_Ctpa,ACEP22Elements.Ct_Pulmonary_Angiogram_Ctpa_Date,ACEP22Elements.Aortic_Dissection_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP22Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }
}
