package com.figmd.janus.measureComputation.nonqpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.{MeasureUpdate}
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty, ACEPQI02Elements,AdminElements}
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACEPQI02
* Measure Title              :- Emergency Medicine: Appropriate Imaging for Recurrent Renal Colic
* Measure Description        :- Percentage of emergency department (ED) visits for patients aged 18-50 years presenting with
                                flank pain with a history of kidney stones during which no imaging is ordered, OR appropriate
                                imaging (ie, plain film radiography or ultrasound) is ordered
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- lower score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 1
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object ACEPQI02_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "ACEPQI02_1"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    val getPatientHistoryList = getPatientHistory(sparkSession, initialRDD
      ,ACEPQI02Elements.Kidney_Stones
      ,ACEPQI02Elements.Kidney_Conditions
      ,ACEPQI02Elements.All_Cancer
      ,ACEPQI02Elements.Anticoagulant
      ,ACEPQI02Elements.Urology_Surgery
      ,ACEPQI02Elements.Flank_Pain
      ,ACEPQI02Elements.Kidney_Transplant).collect.toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //filter denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter notEligible
      //val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate for Met
      val intermediateMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateMet)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()
    }

  }

  /*-----------------------------------------------------------------------------------------
   All emergency department visits for patients aged 18 - 50 years presenting with flank pain
   with any history of kidney stones
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD:RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
            isAgeBetween(visit, m ,18,51)
        &&  isVisitTypeIn(visit,m,ACEPQI02Elements.Critical_Care_Evaluation_And_Management,ACEPQI02Elements.Emergency_Department_Visit)
        &&  isSymptomDuringEDOrCCEncounter(visit,m,ACEPQI02Elements.Flank_Pain,ACEPQI02Elements.Flank_Pain_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date)
        &&  wasDiagnosedBeforeEDOrCCEncounter(visit, m,ACEPQI02Elements.Kidney_Stones ,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList )
    )
  }

  /*---------------------------------------------------------------------------------------------
    - Infection (fever, elevated white blood cell count, laboratory confirmation of urinary tract infection)
    - Cancer
    - Known acute or chronic renal disease (ie, transplant, creatinine >1.5 mg/dL, renal insufficiency, polycystic kidney disease, acute kidney failure)
    - Patient on anticoagulants
    - Stone episode duration >= 72 hours
    - Pregnancy
    - Trauma
    - Persistent pain that cannot be controlled during the ED visit
    - Urologic procedure performed in the past 48 hours
   ----------------------------------------------------------------------------------------------*/

  def getExclusionRdd(eligibleRdd: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCLUSION,globalStartDate,globalEndDate)

    eligibleRdd.filter(visit =>
            isLaboratoryTestResultGreaterOrLessDuringEDOrCCEncounter(visit,m,ACEPQI02Elements.Creatinine,1.5,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date,true)
        ||  isLaboratoryTestResultGreaterOrLessDuringEDOrCCEncounter(visit,m,ACEPQI02Elements.Glomerular_Filtration_Rate,60,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date,false)
        ||  isPhysicalExamResultGraterOrEqualXDuringEDOrCCEncounter(visit,m,ACEPQI02Elements.Body_Temperature,37.5,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date)
        ||  isLaboratoryTestResultGreaterOrLessDuringEDOrCCEncounter(visit,m,ACEPQI02Elements.Leukocyte_In_Urine,11000,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date,true)
        ||  isLaboratoryTestWithResultDuringEdorCC(visit,m,ACEPQI02Elements.Nitrites_In_Urine,ACEPQI02Elements.Positive,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date)
        ||  isLaboratoryTestWithResultDuringEdorCC(visit,m,ACEPQI02Elements.Leukocyte_Esterase_In_Urine,ACEPQI02Elements.Positive,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date)
        ||  isSymptomDuringEDOrCCEncounter(visit,m,ACEPQI02Elements.Uncontrollable_Pain,ACEPQI02Elements.Uncontrollable_Pain_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date)
        ||  isDiagnosisDuringEDOrCCEncounter(visit,m,ACEPQI02Elements.Pregnancy,ACEPQI02Elements.Pregnancy_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date)
        ||  isDiagnosisDuringEDOrCCEncounter(visit,m,ACEPQI02Elements.Trauma,ACEPQI02Elements.Trauma_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date)
        ||  wasDiagnosedBeforeEDOrCCEncounter(visit, m,ACEPQI02Elements.Kidney_Conditions ,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        ||  wasDiagnosedBeforeEDOrCCEncounter(visit, m,ACEPQI02Elements.All_Cancer ,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        ||  wasMedicationBeforeEDOrCCEncounter(visit, m,ACEPQI02Elements.Anticoagulant ,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        ||  wasProcedureInXhoursBeforeOrConcurrentEDOrCCEncounter(visit,m,ACEPQI02Elements.Urology_Surgery,48,AdminElements.Emergency_Visit_Arrival_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        ||  wasSymptomInXhoursBeforeEDOrCCEncounter(visit,m,ACEPQI02Elements.Flank_Pain,72,AdminElements.Emergency_Visit_Arrival_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        ||  wasProcedurePerformedBeforeEDOrCCEncounter(visit, m,ACEPQI02Elements.Kidney_Transplant ,AdminElements.Emergency_Visit_Arrival_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
    )
  }

  /*----------------------------------------------------------------------------------------
   Emergency department visits during which no imaging is ordered OR appropriate imaging
   (ie, plain film radiography or ultrasound) is ordered
   -----------------------------------------------------------------------------------------*/

  def getMet(intermediateMet: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateMet.filter(visit =>
            !isDiagnosticStudyDuringEDOrCCEncounter(visit,m,ACEPQI02Elements.Ct_Of_Abdomen__Pelvis,ACEPQI02Elements.Ct_Of_Abdomen__Pelvis_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date)
        &&  !isDiagnosticStudyDuringEDOrCCEncounter(visit,m,ACEPQI02Elements.Kub__Xray__Abdomen__Pelvis,ACEPQI02Elements.Kub__Xray__Abdomen__Pelvis_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date)
        &&  !isDiagnosticStudyDuringEDOrCCEncounter(visit,m,ACEPQI02Elements.Ultrasound_Of_Abdomen__Pelvis__Flank,ACEPQI02Elements.Ultrasound_Of_Abdomen__Pelvis__Flank_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date)
        &&  !isDiagnosticStudyDuringEDOrCCEncounter(visit,m,ACEPQI02Elements.Mri_Of_Abdomen__Pelvis__Flank,ACEPQI02Elements.Mri_Of_Abdomen__Pelvis__Flank_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEPQI02Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }

}
