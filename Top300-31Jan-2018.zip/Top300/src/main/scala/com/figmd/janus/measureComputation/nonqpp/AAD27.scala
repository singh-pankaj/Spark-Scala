package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,AAD27Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD 27
* Measure Title              :- Basal Cell Carcinoma/Squamous Cell Carcinoma: Skin Cancer Prevention Education
                                and Screening for Transplant Recipients
* Measure Description        :- Percentage of outpatient organ transplant recipients receiving sun protection education
                                and a full skin exam or documented referral to a dermatologist.
* Calculation Implementation :- Patient Specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object AAD27 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAD27"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,AAD27Elements.Organ_Transplant
      ,AAD27Elements.Full_Skin_Exam
      ,AAD27Elements.Full_Skin_Exam
      ,AAD27Elements.Sun_Protection_Education
      ,AAD27Elements.Preventive_Care_Of_Skin
      ,AAD27Elements.Referred_For_Skin_Preventive_Activity
      ,AAD27Elements.Sun_Protection_Education
      ,AAD27Elements.Patient_Reason

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*--------------------------------------------------------------------------------------------------------------------
    All Organ Transplant Recipients seen by provider in an outpatient setting within the reporting period.
   -------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
   initialRDD.filter(visit =>
     isDiagnosis(visit,m,AAD27Elements.Organ_Transplant,patientHistoryBroadcastList)
       && isVisitTypeIn(visit,m,AAD27Elements.Office_Visit)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Number of patients receiving sun protection education and a full skin exam once within the reporting period (1 year)
  by the provider or documentation of either a referral to or completion of these preventative activities by a dermatologist.
   -------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      (
        isInterventionPerformed(visit,m,AAD27Elements.Full_Skin_Exam,patientHistoryBroadcastList)
          && isInterventionOrder(visit,m,AAD27Elements.Sun_Protection_Education,patientHistoryBroadcastList)
        )
        || isEncounterPerformed(visit,m,AAD27Elements.Preventive_Care_Of_Skin,patientHistoryBroadcastList)
        || isInterventionOrder(visit,m,AAD27Elements.Referred_For_Skin_Preventive_Activity,patientHistoryBroadcastList)
        || isInterventionRecommended(visit,m,AAD27Elements.Sun_Protection_Education,patientHistoryBroadcastList)

    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
   Documented refusal by patient to schedule follow-up annual screens after documented appropriate counseling on risk
   for skin cancer.
   -------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      isCommunicationFromProvidertoProvider(visit,m,AAD27Elements.Patient_Reason,patientHistoryBroadcastList)
    )
  }
}