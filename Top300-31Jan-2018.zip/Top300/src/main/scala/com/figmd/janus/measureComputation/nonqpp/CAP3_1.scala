package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CAP3_1
* Measure Title              :- Cancer Protocol and Turnaround Time for Invasive Carcinoma of Renal Tubular Origin
* Measure Description        :- Percentage of all eligible kidney resections specimens:
                                Partial Nephrectomy
                                Total Nephrectomy
                                Radical Nephrectomy
                                for which all required data elements of the Cancer Protocol are included
                                AND meet the maximum 4 business day turnaround time (TAT) requirement (Report Date – Accession Date ≤ 4 business days).
*
* Calculation Implementation :- visit-specific (procedure-specific)
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- NA
* The overall performance score is a weighted average of: (Performance 1 x 70%)+(Performance 2 x 30%)
* Measure Developer          :- Priyanka Sawant
----------------------------------------------------------------------------------------------------------------------------*/
object CAP3_1 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "CAP3_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      CAP3Elements.Surgical_Pathology_Accession_Number
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()
    if(checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRDD(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMetRDD(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      val exceptionRDD = getExceptionRDD(intermediateB, patientHistoryList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
All final pathology reports for eligible kidney resection cases that require the use of a CAP cancer protocol.
CPT®: 88307
AND
Any of the ICD 10 codes:
C64: malignant neoplasm of kidney, except renal pelvis
C64.1: malignant neoplasm of right kidney, except renal pelvis
C64.2: malignant neoplasm of left kidney, except renal pelvis
C64.9: malignant neoplasm of unspecified kidney, except renal pelvis
 * ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
            wasProcedurePerformedInHistory(visit,m,CAP3Elements.Surgical_Pathology_Accession_Number,patientHistoryList)
        &&  wasDiagnosisBeforeorEqualEncounter(visit, m, CAP3Elements.Confirm_Renal_Tubular_Carcinoma_Resection_Date, CAP2Elements.Surgical_Pathology_Accession_Number, patientHistoryList)
    )
  }
  /*-------------------------------------------------------------------------------------------------------------------------
1.Biopsy procedures
2.Wilms tumors
3.Tumors of urothelial origin
Lymphoma and Sarcoma
* ----------------------------------------------------------------------------------------------------------------------------*/
  def getExclusionRDD(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
            isLaboratoryTestConcurrent(visit,m,CAP3Elements.Biopsy_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
        ||  isDiagnosedConcurrentWith(visit,m,CAP3Elements.Lymphoma_And_Sarcoma_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
        ||  isDiagnosedConcurrentWith(visit,m,CAP3Elements.Urothelial_And_Wilms_Tumor_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
        ||  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Biopsy_Or_Lymphoma_Or_Wilms_Tumor_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
    )
  }
  /*-------------------------------------------------------------------------------------------------------------------------
Rate 1: All eligible cases containing all of the required elements found in the current CAP Invasive Carcinoma of Renal Tubular Origin protocol. Optional data (marked with a “+” in the CAP cancer protocol) is not required but may be present.
The current protocol, the required elements include:
Specimen Laterality
Procedure
Tumor Size (largest tumor if multiple)
Tumor Focality
Histologic Type
Sarcomatoid Features
Rhabdoid Features
Histologic Grade
Tumor Necrosis
Tumor Extension
Margins
Regional Lymph Nodes
Pathologic Stage Classification (pTNM, AJCC 8th Edition)
Pathologic Findings in Non-neoplastic Kidney
* If an item is not applicable, an “N/A” listing is required.
   * ----------------------------------------------------------------------------------------------------------------------------*/
  def getMetRDD(intermediateA: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      (
        (     isLaboratoryTestConcurrent(visit,m,CAP3Elements.Specimen_Laterality_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Procedure_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Tumor_Size_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Tumor_Focality_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Histologic_Type_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Sarcomatoid_Features_Present_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Rhabdoid_Features_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Histologic_Grade_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Tumor_Necrosis_Present_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Tumor_Extension_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Margins_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Regional_Lymph_Nodes_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Pathologic_Findings_In_Nonneoplastic_Kidney_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Pathologic_Stage_Classification_Documented_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
          )
          ||     isLaboratoryTestConcurrent(visit,m,CAP3Elements.Cap_Renal_Protocol_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
        )
        &&  !   isLaboratoryTestConcurrent(visit,m,CAP3Elements.Renal_Protocol_Not_Met_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)

    )
  }
  /*-------------------------------------------------------------------------------------------------------------------------
  Cases requiring intra-departmental or extra-departmental consultation.
  * ----------------------------------------------------------------------------------------------------------------------------*/
  def getExceptionRDD(intermediateB: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)
    intermediateB.filter(visit=>
           isCommunicationFromProviderToProviderConcurrent(visit,m,CAP3Elements.Confirm_Case_Required_Consultation_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
        || isCommunicationFromProvidertoProvider(visit,m,CAP3Elements.Consultation_Catii,patientHistoryList)
    )
  }
}
