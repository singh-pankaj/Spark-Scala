package com.figmd.janus.measureComputation.qpp
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP387Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp387
* Measure Title              :- Annual Hepatitis C Virus (HCV) Screening for Patients who are Active Injection Drug Users
* Measure Description        :- Percentage of patients, regardless of age, who are active injection drug users who received screening for HCV infection within the 12 month reporting period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- 1
* Measure Developer          :- Vrushali Gholap
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp387 extends MeasureUtilityUpdate with MeasureUpdate{
  val MEASURE_NAME = "Qpp387"
  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      , QPP387Elements.Active_Injection_Drug_Use
      , QPP387Elements.Outpatient_Consultation
      , QPP387Elements.Home_Healthcare_Services
      , QPP387Elements.Care_Services_In_Long_Term_Residential_Facility
      , QPP387Elements.Nursing_Facility_Visit
      , QPP387Elements.Office_Visit
      , QPP387Elements.Chronic_Hepatitis_C
      , QPP387Elements.Hcv_Infection_Screening
      , QPP387Elements.Hcv_Antibody_Test
      , QPP387Elements.Hcv_Rna_Test
      , QPP387Elements.Hcv_Screening_Not_Met
      , QPP387Elements.Decompensated_Cirrhosis
      , QPP387Elements.Ascites
      , QPP387Elements.Hepatocellular_Carcinoma
      , QPP387Elements.Hepatic_Encephalopathy
      , QPP387Elements.Limited_Life_Expectancy
      , QPP387Elements.Hcv_Screening_Medical_Reason
      , QPP387Elements.Hcv_Screening_Patient_Reason
      , QPP387Elements.Waitlist_For_Organ_Transplant
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIppRDD(initialRDD, patientHistoryBroadcastList, patientHistoryRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val patientHistoryIppRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, ippRDD
        , AdminElements.Encounter_Date
      )

      val mostRecentRDD: List[CassandraRow] = mostRecentPatientListOnEncounter(ippRDD)

      val mostRecentPatienthistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostRecentRDD)

      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //Filter Exclusion
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate for MET
      val intermediateNumerator = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateNumerator.cache()

      // Filter Met
      val metRDD = getMetRDD(intermediateNumerator, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateException = getSubtractRDD(intermediateNumerator, metRDD)
      intermediateException.cache()

      // Filter Exception
      val exceptionRDD = getExceptionRdd(intermediateException, patientHistoryBroadcastList, mostRecentPatienthistoryBroadcastList)
      exceptionRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      mostRecentPatienthistoryBroadcastList.destroy()
    }
  }
  /*-------------------------------------------------------------------------------------------------------------------------
ll patients, regardless of age, who are seen twice for any visit or who had at least one preventive visit within the 12 month reporting period who are active injection drug users
----------------------------------------------------------------------------------------------------------------------------*/
  def getIppRDD(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList : Broadcast[List[CassandraRow]],patientHistory: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)
    val countRDD = countElement(patientHistory, m ,QPP387Elements.Outpatient_Consultation
                                                  ,QPP387Elements.Home_Healthcare_Services
                                                  ,QPP387Elements.Care_Services_In_Long_Term_Residential_Facility
                                                  ,QPP387Elements.Nursing_Facility_Visit
                                                  ,QPP387Elements.Office_Visit)
    //while taking count visits those visit should not be telehealth modifier visit
    // , however currently checking there should not be more than 2 counts for telehealth modifier visits, Discussion in progress with CRA
    val countRDDTelehealth = countElement(patientHistory, m ,QPP387Elements.Office_Visit_Telehealth_Modifier
                                                      ,QPP387Elements.Nursing_Facility_Visit_Telehealth_Modifier
                                                      ,QPP387Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
                                                      ,QPP387Elements.Home_Healthcare_Services_Telehealth_Modifier
                                                      ,QPP387Elements.Outpatient_Consultation_Telehealth_Modifier)
    initialRDD.filter(visit =>
          isDiagnosed(visit,m,QPP387Elements.Active_Injection_Drug_Use,patientHistoryBroadcastList)
      &&  isVisitTypeIn(visit,m, QPP387Elements.Annual_Wellness_Visit
                                ,QPP387Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
                                ,QPP387Elements.Preventive_Care__Established_Office_Visit__0_To_17
                                ,QPP387Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
                                ,QPP387Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
                                ,QPP387Elements.Outpatient_Consultation
                                ,QPP387Elements.Home_Healthcare_Services
                                ,QPP387Elements.Care_Services_In_Long_Term_Residential_Facility
                                ,QPP387Elements.Nursing_Facility_Visit
                                ,QPP387Elements.Office_Visit)
      && getEncounterCountFromHistory(visit,m,2,true,countRDD)
      && !isTeleHealthModifier(visit,m,  QPP387Elements.Preventive_Care__Initial_Office_Visit_0_To_17_Telehealth_Modifier
                                        ,QPP387Elements.Preventive_Care_Services_Initial_Office_Visit_18_And_Up_Telehealth_Modifier
                                        ,QPP387Elements.Preventive_Care___Established_Office_Visit_0_To_17_Telehealth_Modifier
                                        ,QPP387Elements.Preventive_Care_Services___Established_Office_Visit_18_And_Up_Telehealth_Modifier
                                        ,QPP387Elements.Annual_Wellness_Visit_Telehealth_Modifier
                                        ,QPP387Elements.Office_Visit_Telehealth_Modifier
                                        ,QPP387Elements.Nursing_Facility_Visit_Telehealth_Modifier
                                        ,QPP387Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
                                        ,QPP387Elements.Home_Healthcare_Services_Telehealth_Modifier
                                        ,QPP387Elements.Outpatient_Consultation_Telehealth_Modifier)
      && !getEncounterCountFromHistory(visit,m,2,true,countRDDTelehealth)
      && isPOSEncounterNotPerformed(visit,m,QPP387Elements.Pos_02)
    )
  }
  /*--------------------------------------------------------------------------------------------------------------------
  Diagnosis for Chronic Hepatitis C
  -------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(rdd: RDD[CassandraRow], patientHistoryBroadcastList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryBroadcastList,QPP387Elements.Chronic_Hepatitis_C)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Patients who received screening for HCV infection within the 12 month reporting period
   -------------------------------------------------------------------------------------------------------------------*/


  def getMetRDD(RDD: RDD[CassandraRow], patientHistoryBroadcastList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    RDD.filter(visit =>
     (   isInterventionPerformed(visit,m,QPP387Elements.Hcv_Infection_Screening,patientHistoryBroadcastList)
      || isInterventionPerformed(visit,m,QPP387Elements.Hcv_Antibody_Test,patientHistoryBroadcastList)
      || isInterventionPerformed(visit,m,QPP387Elements.Hcv_Rna_Test,patientHistoryBroadcastList)
      )
      && !isInterventionPerformed(visit,m,QPP387Elements.Hcv_Screening_Not_Met,patientHistoryBroadcastList)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
Documentation of medical reason(s) for not receiving annual screening for HCV infection (e.g., decompensated cirrhosis indicating advanced disease [i.e., ascites, esophageal variceal bleeding, hepatic encephalopathy], hepatocellular carcinoma, waitlist for organ transplant, limited life expectancy, other medical reasons)
Documentation of patient reason(s) for not receiving annual screening for HCV infection (e.g., patient declined, other patient reasons)
  -------------------------------------------------------------------------------------------------------------------*/


  def getExceptionRdd(intermediateException: RDD[CassandraRow], patientHistoryBroadcastList : Broadcast[List[CassandraRow]],mostRecentPatienthistoryBroadcastList :Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
        wasDiagnosedDuringMostRecentEncounter(visit,m,QPP387Elements.Decompensated_Cirrhosis,patientHistoryBroadcastList,mostRecentPatienthistoryBroadcastList)
     || wasDiagnosedDuringMostRecentEncounter(visit,m,QPP387Elements.Hepatocellular_Carcinoma,patientHistoryBroadcastList,mostRecentPatienthistoryBroadcastList)
     || wasDiagnosedDuringMostRecentEncounter(visit,m,QPP387Elements.Hepatic_Encephalopathy,patientHistoryBroadcastList,mostRecentPatienthistoryBroadcastList)
     || wasDiagnosedDuringMostRecentEncounter(visit,m,QPP387Elements.Ascites,patientHistoryBroadcastList,mostRecentPatienthistoryBroadcastList)
     || wasPatientCharacteristicDuringMostrecentEncounter(visit,m,QPP387Elements.Limited_Life_Expectancy,patientHistoryBroadcastList,mostRecentPatienthistoryBroadcastList)
     || wasInterventionPerformedDuringMostRecentEncounter(visit,m,QPP387Elements.Hcv_Screening_Medical_Reason,patientHistoryBroadcastList,mostRecentPatienthistoryBroadcastList)
     || wasInterventionPerformedDuringMostRecentEncounter(visit,m,QPP387Elements.Hcv_Screening_Patient_Reason,patientHistoryBroadcastList,mostRecentPatienthistoryBroadcastList)
     || wasInterventionPerformedDuringMostRecentEncounter(visit,m,QPP387Elements.Waitlist_For_Organ_Transplant,patientHistoryBroadcastList,mostRecentPatienthistoryBroadcastList)
    )
  }
}
