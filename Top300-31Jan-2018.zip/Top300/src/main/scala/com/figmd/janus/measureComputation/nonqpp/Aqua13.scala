package com.figmd.janus.measureComputation.nonqpp



import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{AQUA13Elements, AQUA8Elements, AdminElements, MeasureProperty}
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AQUA13
* Measure Title              :- Stress Urinary Incontinence (SUI): Revision surgery wtihin 12 months of incontinence procedure
* Measure Description        :- Percentage of women who undergo surgery for stress incontinence who require revision surgery within 12 months.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Aqua13 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Aqua13"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    var patient_history_list = getPatientHistory(sparkSession, initialRDD,

      AQUA13Elements.Sui_Surgery_Urethral,
      AQUA13Elements.Repetition_Of_Urethral_Surgery

    ).collect().toList
    val hisrotyRDD = getPatientHistory(sparkSession, initialRDD,

      AQUA13Elements.Sui_Surgery_Urethral


    )
    var least_recent_patient_history_list = leastRecentPatientList(hisrotyRDD, AQUA13Elements.Sui_Surgery_Urethral)

    var leastRecentpatientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(least_recent_patient_history_list)

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, leastRecentpatientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }
  }


//Women undergoing incontinence surgery
  def getIpp(initialRDD: RDD[CassandraRow],leastRecentpatientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
                          isFemale(visit,m)
                      &&  wasFirstProcedurePerformed(visit,m,AQUA13Elements.Sui_Surgery_Urethral,leastRecentpatientHistoryList)
                    )
  }



//Women undergoing revision surgery within 12 months of primary surgery
  def getMet(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
                         wasProcedurePerformedStartsXDaysAfterEndOfProcedure(visit,m,AQUA13Elements.Repetition_Of_Urethral_Surgery,AQUA13Elements.Sui_Surgery_Urethral,365,patientHistoryList)
    )
  }

}