package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.joda.time.DateTime
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, QPP468Elements, TimeOperator,CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- QPP468
* Measure Title               :- Continuity of Pharmacotherapy for Opioid Use Disorder (OUD)
* Measure Description         :- Percentage of adults aged 18 years and older with pharmacotherapy for opioid use disorder (OUD) who have at least 180 days of continuous treatment
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KIRTI_RAUT_FIGMD_COM
* Initial GIT Version/Tag(CRA):-1.9
* Latest GIT Version/Tag(CRA) :-1.9
----------------------------------------------------------------------------------------------------------------------------*/

object QPP468 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "QPP468"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP468Elements.Opioid_Use_Disorder,
      QPP468Elements.Pharmacotherapy_Medications,
      QPP468Elements.Pharmacotherapy_Medications_Stop_Date,
      QPP468Elements.Opioid_Use_Disorder,
      QPP468Elements.Medications_Exceptions,
      QPP468Elements.Continuous_Medication_Not_Met,
      QPP468Elements.Continuous_Medication_180_Days,
      QPP468Elements.Annual_Wellness_Visit,
      QPP468Elements.Critical_Care_Evaluation_And_Management,
      QPP468Elements.Emergency_Department_Visit,
      QPP468Elements.Home_Healthcare_Services,
      QPP468Elements.Care_Services_In_Long_Term_Residential_Facility,
      QPP468Elements.Nursing_Facility_Visit
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val leastRecentRDD : List[CassandraRow] = leastRecentPatientList(patientHistoryRDD,QPP468Elements.Opioid_Use_Disorder)
    val leastRecentPatienthistoryList :Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastRecentRDD)

    val MedicationList:List[(String,String)] = List((QPP468Elements.Pharmacotherapy_Medications,QPP468Elements.Pharmacotherapy_Medications_Stop_Date))
    val medicationDurationBroadcastList = sparkSession.sparkContext.broadcast(consecutive(patientHistoryRDD, m, MedicationList, CalenderUnit.DAY,CalenderUnit.DAY, 180, CalenderUnit.DAY, 7, "AFTERorEQUAL"))


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList,leastRecentPatienthistoryList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList,patientHistoryRDD,medicationDurationBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
   Adults aged 18 years and older who had a diagnosis of OUD
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val tempStartDate = new DateTime(globalStartDate).minusDays(184)

    val m = MeasureProperty(MEASURE_NAME, IPP, tempStartDate,globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit,m,true,18)
        &&   (
        wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP468Elements.Opioid_Use_Disorder,patientHistoryBroadcastList)
          && isEncounterPerformedBeforeEnd(visit,m,QPP468Elements.Opioid_Use_Disorder,patientHistoryBroadcastList)
        )
        &&  (
        isVisitTypeIn(visit,m,QPP468Elements.Office_Visit,
          QPP468Elements.Annual_Wellness_Visit,
          QPP468Elements.Critical_Care_Evaluation_And_Management,
          QPP468Elements.Emergency_Department_Visit,
          QPP468Elements.Home_Healthcare_Services,
          QPP468Elements.Care_Services_In_Long_Term_Residential_Facility,
          QPP468Elements.Nursing_Facility_Visit)
          &&
          (    isEncounterPerformedInXDays(visit,m,QPP468Elements.Annual_Wellness_Visit,184,patientHistoryBroadcastList)
            || isEncounterPerformedInXDays(visit,m,QPP468Elements.Critical_Care_Evaluation_And_Management,184,patientHistoryBroadcastList)
            || isEncounterPerformedInXDays(visit,m,QPP468Elements.Emergency_Department_Visit,184,patientHistoryBroadcastList)
            || isEncounterPerformedInXDays(visit,m,QPP468Elements.Home_Healthcare_Services,184,patientHistoryBroadcastList)
            || isEncounterPerformedInXDays(visit,m,QPP468Elements.Care_Services_In_Long_Term_Residential_Facility,184,patientHistoryBroadcastList)
            || isEncounterPerformedInXDays(visit,m,QPP468Elements.Nursing_Facility_Visit,184,patientHistoryBroadcastList)

            )

        )
        &&
        isAssesmentPerformedDuringEncounter(visit,m,QPP468Elements.Currently_On_Pharmacotherapy)
        ||wasMedicationActiveBeforeOrEqualEncounter(visit,m,QPP468Elements.Pharmacotherapy_Medications,patientHistoryBroadcastList
      )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
 	Pharmacotherapy for OUD initiated after June 30 th of performance period
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],leastRecentPatienthistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      isAssesmentPerformedDuringEncounter(visit,m,QPP468Elements.Pharmacotherapy_After_June_30)
        &&      wasMedicationOrderedBeforeEndInXDays(visit,m,QPP468Elements.Pharmacotherapy_Medications,185,CalenderUnit.DAY,patientHistoryBroadcastList)
        &&      wasDiagnosisBeforeOrEqualEndInXDays(visit,m,QPP468Elements.Opioid_Use_Disorder,185,CalenderUnit.DAY,leastRecentPatienthistoryList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
 	Adults in the denominator who have at least 180 days of continuous pharmacotherapy with a medication prescribed
for OUD without a gap of more than seven days
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryRDD: RDD[CassandraRow],medicationDurationBroadcastList: Broadcast[List[(String,String, Double)]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)


    intermediateForMet.filter(visit =>
      (             getConsecutiveResult(visit, m, QPP468Elements.Pharmacotherapy_Medications, 180, CompareOperator.GREATER_EQUAL, medicationDurationBroadcastList)
        ||
        (
          (        isEncounterPerformedInXDays(visit,m,QPP468Elements.Annual_Wellness_Visit,180,patientHistoryBroadcastList)
            || isEncounterPerformedInXDays(visit,m,QPP468Elements.Critical_Care_Evaluation_And_Management,180,patientHistoryBroadcastList)
            || isEncounterPerformedInXDays(visit,m,QPP468Elements.Emergency_Department_Visit,180,patientHistoryBroadcastList)
            || isEncounterPerformedInXDays(visit,m,QPP468Elements.Home_Healthcare_Services,180,patientHistoryBroadcastList)
            || isEncounterPerformedInXDays(visit,m,QPP468Elements.Care_Services_In_Long_Term_Residential_Facility,180,patientHistoryBroadcastList)
            || isEncounterPerformedInXDays(visit,m,QPP468Elements.Nursing_Facility_Visit,180,patientHistoryBroadcastList)
            )
            &&
            (
              (
                wasMedicationActiveStartBeforeStart(visit,m,QPP468Elements.Pharmacotherapy_Medications,QPP468Elements.Annual_Wellness_Visit,TimeOperator.BEFORE,patientHistoryBroadcastList)
                  || wasMedicationActiveStartBeforeStart(visit,m,QPP468Elements.Pharmacotherapy_Medications,QPP468Elements.Critical_Care_Evaluation_And_Management,TimeOperator.BEFORE,patientHistoryBroadcastList)
                  || wasMedicationActiveStartBeforeStart(visit,m,QPP468Elements.Pharmacotherapy_Medications,QPP468Elements.Emergency_Department_Visit,TimeOperator.BEFORE,patientHistoryBroadcastList)
                  || wasMedicationActiveStartBeforeStart(visit,m,QPP468Elements.Pharmacotherapy_Medications,QPP468Elements.Home_Healthcare_Services,TimeOperator.BEFORE,patientHistoryBroadcastList)
                  || wasMedicationActiveStartBeforeStart(visit,m,QPP468Elements.Pharmacotherapy_Medications,QPP468Elements.Care_Services_In_Long_Term_Residential_Facility,TimeOperator.BEFORE,patientHistoryBroadcastList)
                  || wasMedicationActiveStartBeforeStart(visit,m,QPP468Elements.Pharmacotherapy_Medications,QPP468Elements.Nursing_Facility_Visit,TimeOperator.BEFORE,patientHistoryBroadcastList)
                )
                ||
                (       wasMedicationActiveStartBeforeStartInXDays(visit,m,QPP468Elements.Pharmacotherapy_Medications,QPP468Elements.Annual_Wellness_Visit,180,patientHistoryBroadcastList)
                  || wasMedicationActiveStartBeforeStartInXDays(visit,m,QPP468Elements.Pharmacotherapy_Medications,QPP468Elements.Critical_Care_Evaluation_And_Management,180,patientHistoryBroadcastList)
                  || wasMedicationActiveStartBeforeStartInXDays(visit,m,QPP468Elements.Pharmacotherapy_Medications,QPP468Elements.Emergency_Department_Visit,180,patientHistoryBroadcastList)
                  || wasMedicationActiveStartBeforeStartInXDays(visit,m,QPP468Elements.Pharmacotherapy_Medications,QPP468Elements.Home_Healthcare_Services,180,patientHistoryBroadcastList)
                  || wasMedicationActiveStartBeforeStartInXDays(visit,m,QPP468Elements.Pharmacotherapy_Medications,QPP468Elements.Care_Services_In_Long_Term_Residential_Facility,180,patientHistoryBroadcastList)
                  || wasMedicationActiveStartBeforeStartInXDays(visit,m,QPP468Elements.Pharmacotherapy_Medications,QPP468Elements.Nursing_Facility_Visit,180,patientHistoryBroadcastList)
                  )
              )
          )
        || isAssessmentPerformed(visit,m,QPP468Elements.Continuous_Medication_180_Days,patientHistoryBroadcastList)
        )
        &&
        !isAssessmentPerformed(visit,m,QPP468Elements.Continuous_Medication_Not_Met,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Adults who are deliberately phased out of Medication Assisted Treatment (MAT) prior to 180 days of continuous treatment
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      isAssessmentPerformed(visit,m,QPP468Elements.Medications_Exceptions,patientHistoryBroadcastList)

    )
  }
}