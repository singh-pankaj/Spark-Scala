package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CompareOperator, ECQM125V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm125v7
* Measure Title              :- Breast Cancer Screening
* Measure Description        :- Percentage of women 50-74 years of age who had a mammogram to screen for breast cancer
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm125V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm125V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val patient_history_rdd = getPatientHistory(sparkSession, ippRDD,
        ECQM125V7Elements.Discharged_To_Home_For_Hospice_Care,
        ECQM125V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
        ECQM125V7Elements.Encounter_Inpatient,
        ECQM125V7Elements.Hospice_Care_Ambulatory,
        ECQM125V7Elements.Bilateral_Mastectomy,
        ECQM125V7Elements.Unilateral_Mastectomy,
        ECQM125V7Elements.Unilateral_Mastectomy__Unspecified_Laterality,
        ECQM125V7Elements.Status_Post_Right_Mastectomy,
        ECQM125V7Elements.Status_Post_Left_Mastectomy,
        ECQM125V7Elements.Right,
        ECQM125V7Elements.Left,
        ECQM125V7Elements.History_Of_Bilateral_Mastectomy,
        ECQM125V7Elements.Mammography)

      val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
      val patient_history_list = patient_history_rdd.collect().toList

      val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

      val ProcedureCount: List[(String, Int)] = countElementBeforeOrEqualEnd(patient_history_rdd, m, ECQM125V7Elements.Unilateral_Mastectomy)

      //eligible RDD
      //val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList, ProcedureCount)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryList.destroy()

    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : Women 51-74 years of age with a visit during the measurement period
----------------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeBetweenBeforeStart(visit, m, 51, CompareOperator.GREATER_EQUAL, 74, CompareOperator.LESS)
        &&
        isFemale(visit, m)
        &&
        isVisitTypeIn(visit, m,
          ECQM125V7Elements.Office_Visit,
          ECQM125V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
          ECQM125V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
          ECQM125V7Elements.Home_Healthcare_Services,
          ECQM125V7Elements.Annual_Wellness_Visit)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Denominator Exclusions : Women who had a bilateral mastectomy or who have a history of a bilateral mastectomy or for whom there is evidence
of a right and a left unilateral mastectomy.
Exclude patients whose hospice care overlaps the measurement period.
----------------------------------------------------------------------------------------------------------------------------*/
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], ProcedureCount: List[(String, Int)]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)


    ippRDD.filter(visit =>

      isEncounterPerformedWithDischargeStatus(visit, m, ECQM125V7Elements.Encounter_Inpatient, ECQM125V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        || isEncounterPerformedWithDischargeStatus(visit, m, ECQM125V7Elements.Encounter_Inpatient, ECQM125V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        || isInterventionOrder(visit, m, ECQM125V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        || wasInterventionPerformedInHistory(visit, m, ECQM125V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        || wasProcedurePerformedInHistory(visit, m, ECQM125V7Elements.Bilateral_Mastectomy, patientHistoryList)
        || getProcedureCountFromHistory(visit, m, 2, false, ProcedureCount)
        || (
        (wasDiagnosedBeforeEndWithLaterality(visit, m, ECQM125V7Elements.Unilateral_Mastectomy__Unspecified_Laterality, ECQM125V7Elements.Right, patientHistoryList)
          || wasDiagnosedInHistory(visit, m, ECQM125V7Elements.Status_Post_Right_Mastectomy, patientHistoryList)
          )
          && (wasDiagnosedBeforeEndWithLaterality(visit, m, ECQM125V7Elements.Unilateral_Mastectomy__Unspecified_Laterality, ECQM125V7Elements.Left, patientHistoryList)
          || wasDiagnosedInHistory(visit, m, ECQM125V7Elements.Status_Post_Left_Mastectomy, patientHistoryList)
          )
        )
        || wasDiagnosedInHistory(visit, m, ECQM125V7Elements.History_Of_Bilateral_Mastectomy, patientHistoryList)

    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Women with one or more mammograms during the measurement period or the 15 months prior to the measurement period
----------------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      wasDiagnosticStudyBeforeXMonths(visit, m, ECQM125V7Elements.Mammography, 27, patientHistoryList)

    )
  }
}