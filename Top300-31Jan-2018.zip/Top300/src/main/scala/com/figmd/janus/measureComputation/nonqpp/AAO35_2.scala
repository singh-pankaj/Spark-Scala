package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,AAO35Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO35_2
* Measure Title               :- Benign Positional Paroxymal Vertigo (BPPV): Dix-Hallpike and Canalith Repositioning
* Measure Description         :- Percentage of patients with BPPV who had a Dix-Hallpike maneuver performed AND who had
                                 therapeutic canalith repositioning procedure (CRP) performed or who were referred for physical therapy
                                 or to a provider who can perform CRP if identified with posterior canal BPPV.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- 2
* Measure Stratification      :- 1
* Measure Developer           :- SUMIT.SINGH
* Initial GIT Version/Tag(CRA):- Measure_Develpment/Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Measure_Develpment/Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object AAO35_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO35_2"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
                  AAO35Elements.Benign_Paroxysmal_Positional_Vertigo,
                  AAO35Elements.Severe_Atherosclerotic_Disease,
                  AAO35Elements.Severe_Atherosclerotic_Disease,
                  AAO35Elements.Severe_Heart_Disease,
                  AAO35Elements.Comorbid_Conditions,
                  AAO35Elements.Limited_Cervical_Range_Of_Motion,
                  AAO35Elements.Dissection_Cerebral_Circulation,
                  AAO35Elements.Patient_Unable_To_Lay_Flat,
                  AAO35Elements.Unable_To_Seat_Or_Perform_Maneuver,
                  AAO35Elements.Refused_Or_Declined_Dix_Hallpike_Maneuver,
                  AAO35Elements.Morbid_Obesity,
                  AAO35Elements.Patient_Refuses_Crp,
                  AAO35Elements.Canalith_Repositioning_Procedure_Medical_Reason,
                  AAO35Elements.Spinal_Cord_Injury,
                  AAO35Elements.No_Vertigo_Or_Dizziness


    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  /*-----------------------------------------------------------------------------------------------------------------------
  Patients diagnosed with posterior canal BPPV
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
               isVisitTypeIn(visit,m,
                      AAO35Elements.Outpatient_Consultation,
                      AAO35Elements.Physical_Therapy,
                      AAO35Elements.Office_Visit,
                      AAO35Elements.Occupational_Therapy_Evaluation
      )
           && (
                 wasDiagnosedBeforeOrEqualEncounter(visit,m,AAO35Elements.Benign_Paroxysmal_Positional_Vertigo,patientHistoryBroadcastList)
               )


    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  For Denominator 2 Only:
  Patients diagnosed with anterior or lateral BPPV
  Patients with unspecified canal BPPV
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
                    isDiagnosedConcurrentWith(visit,m,AAO35Elements.Unspecified_Canal_Bppv,AAO35Elements.Benign_Paroxysmal_Positional_Vertigo)
              &&    isDiagnosedConcurrentWith(visit,m,AAO35Elements.Anterior_Or_Lateral_Bppv,AAO35Elements.Benign_Paroxysmal_Positional_Vertigo)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients who had therapeutic CRP performed or were referred to a provider who can perform CRP, or were prescribed or referred for physical therapy.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
                           elementStartAfterStartOfDiagnosis(visit,m,AAO35Elements.Canalith_Repositioning_Procedure,AAO35Elements.Benign_Paroxysmal_Positional_Vertigo,AAO35Elements.Posterior_Canal,patientHistoryBroadcastList)
                      ||   CommunicationFromProviderToProviderStartAfterStartOfDiagnosis(visit,m,AAO35Elements.Referral_For_Physical_Therapy,AAO35Elements.Benign_Paroxysmal_Positional_Vertigo,AAO35Elements.Posterior_Canal,patientHistoryBroadcastList)



    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      (
             wasDiagnosedBeforeOrEqualEncounter(visit,m,AAO35Elements.Severe_Atherosclerotic_Disease,patientHistoryBroadcastList)
          || wasDiagnosedBeforeOrEqualEncounter(visit,m,AAO35Elements.Severe_Heart_Disease,patientHistoryBroadcastList)
          || wasDiagnosedBeforeOrEqualEncounter(visit,m,AAO35Elements.Comorbid_Conditions,patientHistoryBroadcastList)
          || wasAssessmentPerformedBeforeOrEqualEncounter(visit,m,AAO35Elements.Limited_Cervical_Range_Of_Motion,patientHistoryBroadcastList)
          || wasDiagnosedBeforeOrEqualEncounter(visit,m,AAO35Elements.Dissection_Cerebral_Circulation,patientHistoryBroadcastList)
          || wasAssessmentPerformedBeforeOrEqualEncounter(visit,m,AAO35Elements.Patient_Unable_To_Lay_Flat,patientHistoryBroadcastList)
          || wasAssessmentPerformedBeforeOrEqualEncounter(visit,m,AAO35Elements.Unable_To_Seat_Or_Perform_Maneuver,patientHistoryBroadcastList)
          || wasAssessmentPerformedBeforeOrEqualEncounter(visit,m,AAO35Elements.Refused_Or_Declined_Dix_Hallpike_Maneuver,patientHistoryBroadcastList)
          || wasPhysicalExamPerformedBeforeOrEqualEncounter(visit,m,AAO35Elements.Morbid_Obesity,patientHistoryBroadcastList)
          || wasDiagnosedBeforeOrEqualEncounter(visit,m,AAO35Elements.Canalith_Repositioning_Procedure_Medical_Reason,patientHistoryBroadcastList)
          || wasDiagnosedBeforeOrEqualEncounter(visit,m,AAO35Elements.Spinal_Cord_Injury,patientHistoryBroadcastList)
          || wasCommunicationFromProviderToProviderBeforeOrEqualEncounter(visit,m,AAO35Elements.Patient_Refuses_Crp,patientHistoryBroadcastList)
        )
          &&  (
                isDiagnosedDuringEncounter(visit,m,AAO35Elements.Benign_Paroxysmal_Positional_Vertigo)
          ||    isAssessmentPerformedDuringEncounter(visit,m,AAO35Elements.No_Vertigo_Or_Dizziness)
              )


    )
  }
}

