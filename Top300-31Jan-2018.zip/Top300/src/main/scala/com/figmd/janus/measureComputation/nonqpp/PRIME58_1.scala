package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,PRIME58Elements,CalenderUnit}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PRIME58_1
* Measure Title               :- Ischemic Vascular Disease (IVD): Complete Lipid Profile and LDL-C Control (<100 mg/dL)
* Measure Description         :- Percentage of patients 18 years of age and older who were diagnosed with acute myocardial infarction (AMI),
                                 coronary artery bypass graft (CABG) or percutaneous coronary interventions (PCI) in the 12 months prior to
                                 the measurement period, or who had a diagnosis of ischemic vascular disease (IVD) during the measurement period,
                                 and who had a complete lipid profile performed during the measurement period and whose most recent Low-density Lipoprotein (LDL-C)
                                 was adequately controlled (< 100 mg/dL)
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- 1
* Measure Stratification      :- 1
* Measure Developer           :- SUMIT.SINGH
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object PRIME58_1 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "PRIME58_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
           PRIME58Elements.Acute_Myocardial_Infarction,
           PRIME58Elements.Percutaneous_Coronary_Interventions,
           PRIME58Elements.Coronary_Artery_Bypass_Graft,
           PRIME58Elements.Ischemic_Vascular_Disease,
           PRIME58Elements.Total_Cholesterol_Laboratory_Test,
           PRIME58Elements.Hdl_C_Laboratory_Test,
           PRIME58Elements.Ldl_C,
           PRIME58Elements.Triglycerides_Laboratory_Test

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
   Patients 18 years of age and older with a visit during the measurement year who had an AMI, CABG, or PCI during the 12 months
   prior to the measurement year or who had a diagnosis of IVD during the measurement year
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
                 isPatientAdult(visit,m)
            &&  (
                      WasDiagnosedStartBeforeXMonths(visit,m,PRIME58Elements.Acute_Myocardial_Infarction,CalenderUnit.MONTH ,12 ,patientHistoryBroadcastList)
                  ||  WasDiagnosedStartBeforeXMonths(visit,m,PRIME58Elements.Percutaneous_Coronary_Interventions,CalenderUnit.MONTH,12 ,patientHistoryBroadcastList)
                  ||  WasDiagnosedStartBeforeXMonths(visit,m,PRIME58Elements.Coronary_Artery_Bypass_Graft,CalenderUnit.MONTH ,12 ,patientHistoryBroadcastList)
                  ||  isDiagnosed(visit,m,PRIME58Elements.Ischemic_Vascular_Disease,patientHistoryBroadcastList)
                )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
   Patients with a complete lipid profile performed during the measurement period
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
                isLaboratoryTestOrder(visit,m,PRIME58Elements.Total_Cholesterol_Laboratory_Test,patientHistoryBroadcastList)
            &&  isLaboratoryTestOrder(visit,m,PRIME58Elements.Hdl_C_Laboratory_Test,patientHistoryBroadcastList)
            &&  isLaboratoryTestOrder(visit,m,PRIME58Elements.Ldl_C,patientHistoryBroadcastList)
            &&  isLaboratoryTestOrder(visit,m,PRIME58Elements.Triglycerides_Laboratory_Test,patientHistoryBroadcastList)



    )
  }

}
