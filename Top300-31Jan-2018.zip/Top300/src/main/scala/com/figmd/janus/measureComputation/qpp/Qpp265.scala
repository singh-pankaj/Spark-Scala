package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP265Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Qpp265
* Measure Title               :- Biopsy Follow-Up
* Measure Description         :- Percentage of new patients whose biopsy results have been reviewed and communicated to
*                               the primary care/referring physician and patient
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.5
* Latest GIT Version/Tag(CRA) :- 1.5
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp265 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp265"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP265Elements.Biopsy
      , QPP265Elements.Biopsy_Results
      , QPP265Elements.Biopsy_Result_Review
      , QPP265Elements.Communication_To_The_Primary_Care_Referring_Physician
      , QPP265Elements.Tracking_Process_Document
      , QPP265Elements.Initials_Of_Physician_Performing_Biopsy
      , QPP265Elements.Patient_Name
      , QPP265Elements.Date_Of_Biopsy_Result
      , QPP265Elements.Type_Of_Biopsy
      , QPP265Elements.Biopsy_Result_In_Tracking_Log
      , QPP265Elements.Biopsy_Results_Not_Met
      , QPP265Elements.Biopsy_Results_Documented_Reason
      , QPP265Elements.Primary_Care_Or_Referring_Care_Physician
      , QPP265Elements.Patient_Request_Not_Communicate_Biopsy_Results_With_The_Referring_Physician
      , QPP265Elements.Self_Referred_Patient

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isVisitTypeIn(visit, m
        , QPP265Elements.Office_Or_Other_Outpatient_Visit
        , QPP265Elements.Outpatient_Consultation
      )
        && !
          isVisitTypeIn(visit, m
            , QPP265Elements.Office_Or_Other_Outpatient_Visit_Telehealth_Modifier
            , QPP265Elements.Outpatient_Consultation_Telehealth_Modifier
            , QPP265Elements.Pos_02
          )
        &&
        isProcedurePerformed(visit, m, QPP265Elements.Biopsy, patientHistoryBroadcastList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>

      (
          isCommunicationFromProviderToPatientAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Biopsy_Results, patientHistoryBroadcastList)
        ||
          isCommunicationFromProviderToProviderAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Biopsy_Results, patientHistoryBroadcastList)
        ||
          (
              isCommunicationFromProviderToPatientAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Biopsy_Result_Review, patientHistoryBroadcastList)
            &&
              isCommunicationFromProviderToProviderAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Communication_To_The_Primary_Care_Referring_Physician, patientHistoryBroadcastList)
            &&
              isInterventionAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Tracking_Process_Document, patientHistoryBroadcastList)
            &&
              isInterventionAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Initials_Of_Physician_Performing_Biopsy, patientHistoryBroadcastList)
            &&
              isInterventionAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Patient_Name, patientHistoryBroadcastList)
            &&
              isInterventionAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Date_Of_Biopsy_Result, patientHistoryBroadcastList)
            &&
              isInterventionAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Type_Of_Biopsy, patientHistoryBroadcastList)
            &&
              isInterventionAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Biopsy_Result_In_Tracking_Log, patientHistoryBroadcastList)
//            && Repeat Call
//                isInterventionAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Date_Of_Biopsy_Result, patientHistoryBroadcastList)
            &&
              isDocumentationAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Documentation_Of_Biopsy_Tracking_Process_In_Patient_s_Medical_Records, patientHistoryBroadcastList)
          )
      )
      && !
        (
            ! isCommunicationFromProviderToProviderAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Biopsy_Results_Not_Met, patientHistoryBroadcastList)
          ||
            ! isCommunicationFromProviderToPatientAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Biopsy_Results_Not_Met, patientHistoryBroadcastList)
        )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
          isCommunicationFromProviderToProviderAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Biopsy_Results_Documented_Reason, patientHistoryBroadcastList)
        ||
          isCommunicationFromProviderToProviderAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Primary_Care_Or_Referring_Care_Physician, patientHistoryBroadcastList)
        ||
          isCommunicationFromProviderToProviderAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Patient_Request_Not_Communicate_Biopsy_Results_With_The_Referring_Physician, patientHistoryBroadcastList)
        ||
          isCommunicationFromProviderToProviderAfterProcedure(visit, m, QPP265Elements.Biopsy, QPP265Elements.Self_Referred_Patient, patientHistoryBroadcastList)
    )
  }

}