package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 345
* Measure Title              :- Rate of Asymptomatic Patients Undergoing Carotid Artery Stenting (CAS) Who Are Stroke Free or Discharged Alive
*
* Measure Description        :- Percent of asymptomatic patients undergoing CAS who are stroke free while in the hospital or discharged alive following surgery
*
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp345 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp345"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP345Elements.Ipsilateral_Carotid_Territory_Tia_Or_Stroke,
      QPP345Elements.Ipsilateral_Tia_Or_Stroke,
      QPP345Elements.Asymptomatic_Cas,
      QPP345Elements.Contralateral_Carotid_Territory_Tia_Or_Stroke,
      QPP345Elements.Vertebrobasilar_Tia_Stroke,
      QPP345Elements.Patient_Survival_Grp,
      QPP345Elements.Absence_Of_Stroke,
      QPP345Elements.Ischemic_Stroke,
      QPP345Elements.Hemorrhagic_Stroke

    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Eligible IPP
      val eligibleRdd = ippRDD
      eligibleRdd.cache()

      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }
  }


  //IPP-Denominator criteria : Patients aged 18 and older who are asymptomatic undergoing CAS
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isProcedurePerformedDuringEncounter(visit, m, QPP345Elements.Asymptomatic_Cas)
    )
  }


  // Denominator Exclusion criteria:
  //Symptomatic carotid stenosis: Ipsilateral carotid territory TIA or stroke less than 120 days prior to procedure
  // OR  Other carotid stenosis: Ipsilateral TIA or stroke 120 days or greater prior to procedure or any prior contralateral carotid territory or vertebrobasilar TIA or stroke
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>

      (
        wasDiagnosedBeforeProcedureInXDays(visit, m, QPP345Elements.Ipsilateral_Carotid_Territory_Tia_Or_Stroke, QPP345Elements.Asymptomatic_Cas, 120, patientHistoryBroadcastList)
          || isProcedurePerformedDuringEncounter(visit, m, QPP345Elements.Symptomatic_Carotid_Stenosis)
        )
        ||
        (
          isProcedurePerformedDuringEncounter(visit, m, QPP345Elements.Other_Carotid_Stenosis)
            || wasElementPresentBeforeInXPeriods(visit, m, QPP345Elements.Asymptomatic_Cas, CalenderUnit.DAY, 120, CompareOperator.GREATER_EQUAL, patientHistoryBroadcastList, Seq(QPP345Elements.Ipsilateral_Tia_Or_Stroke))
            ||
            (
              wasDiagnosedBefore(visit, m, QPP345Elements.Asymptomatic_Cas_Date, QPP345Elements.Contralateral_Carotid_Territory_Tia_Or_Stroke, patientHistoryBroadcastList)
                || wasDiagnosedBefore(visit, m, QPP345Elements.Asymptomatic_Cas_Date, QPP345Elements.Vertebrobasilar_Tia_Stroke, patientHistoryBroadcastList)
              )
          )

    )
  }


  // Numerator Criteria :Patients who are stroke free or in the hospital or discharged alive following CAS
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        isPatientCharacteristicDuringEncounter(visit, m, QPP345Elements.Survival_And_Absence_Stroke)
          || (
          (
            wasDiagnosedAfterProcedure(visit, m, QPP345Elements.Asymptomatic_Cas_Date, patientHistoryBroadcastList, QPP345Elements.Patient_Survival_Grp)
              && wasDiagnosedBefore(visit, m, QPP345Elements.Discharge_Date, QPP345Elements.Patient_Survival_Grp, patientHistoryBroadcastList)
            )
            ||
            (
              wasDiagnosedAfterProcedure(visit, m, QPP345Elements.Asymptomatic_Cas_Date, patientHistoryBroadcastList, QPP345Elements.Absence_Of_Stroke)
                && wasDiagnosedBefore(visit, m, QPP345Elements.Discharge_Date, QPP345Elements.Absence_Of_Stroke, patientHistoryBroadcastList)
              )
          )
        )
        && !(

        isPatientExpiredWithCause(visit, m, QPP345Elements.Expired, QPP345Elements.Patient_Deceased_Following_Cas)

          ||
          (
            isPatientCharacteristicOnEncounter(visit, m, QPP345Elements.Expired_Date, QPP345Elements.Asymptomatic_Cas_Date)
              && isPatientExpiredBeforeDischarge(visit, m, AdminElements.Encounter_Date, patientHistoryBroadcastList, Seq(QPP345Elements.Expired), QPP345Elements.Discharge)

            )


        )
        && !(
        isDiagnosticStudyOnEncounter(visit, m, QPP345Elements.Stroke_Following_Cas)
          || (
          wasDiagnosedAfterProcedure(visit, m, QPP345Elements.Asymptomatic_Cas_Date, patientHistoryBroadcastList, QPP345Elements.Ischemic_Stroke)
            && wasDiagnosedBefore(visit, m, QPP345Elements.Discharge_Date, QPP345Elements.Ischemic_Stroke, patientHistoryBroadcastList)
          )
          || (
          wasDiagnosedAfterProcedure(visit, m, QPP345Elements.Asymptomatic_Cas_Date, patientHistoryBroadcastList, QPP345Elements.Hemorrhagic_Stroke)
            && wasDiagnosedBefore(visit, m, QPP345Elements.Discharge_Date, QPP345Elements.Hemorrhagic_Stroke, patientHistoryBroadcastList)
          )


        )
    )


  }


}