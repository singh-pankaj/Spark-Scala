package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP275Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.qpp.Qpp275.{isAssessmentPerformedDuringEncounter, isAssessmentPerformedOnEncounter}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 275
* Measure Title              :- Inflammatory Bowel Disease (IBD): Assessment of Hepatitis B Virus (HBV) Status Before Initiating Anti-TNF (Tumor Necrosis Factor) Therapy
* Measure Description        :- Percentage of patients with a diagnosis of inflammatory bowel disease (IBD) who had Hepatitis B Virus (HBV) status assessed and results interpreted prior to initiating anti-TNF (tumor necrosis factor) therapy
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp275 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp275"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP


    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //getPatientHistoryList
      val patientHistoryList = getPatientHistory(sparkSession, ippRDD,
        QPP275Elements.Hepatitis_B_Virus__Hbv__Status,
        QPP275Elements.Hbv_Tools,
        QPP275Elements.Hbv_Status,
        QPP275Elements.Hepatitis_B___Immunity_Documented,
        QPP275Elements.Hbv_Status___Patient_Reason,
        QPP275Elements.Patient_Refusal
      ).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateA = getSubtractRDD(ippRDD, metRDD)

      // Filter Exceptions
      val exceptionRDD = getException(intermediateA, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()
      //


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /* All patients, regardless of age, with a diagnosis of inflammatory bowel disease who initiated an anti-TNF agent */

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isDiagnosedOnEncounter(visit, m, QPP275Elements.Inflammatory_Bowel_Disease)
        &&
        isVisitTypeIn(visit, m,
          QPP275Elements.Office_Visit,
          QPP275Elements.Home_Healthcare_Services,
          QPP275Elements.Smoking_And_Tobacco_Use_Cessation_Counseling_Visit,
          QPP275Elements.Office_Consultation)
        &&
        (isMedicationAdministeredOnEncounter(visit, m, QPP275Elements.Anti_Tnf___Agent)
          ||
          isMedicationAdministeredOnEncounter(visit, m, QPP275Elements.Anti_Tnf___Agent_Cpt)
          )
    )
  }


  // Numerator criteria
  /* Patients who had HBV status assessed and results interpreted prior to initiating anti-TNF therapy */

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (
        isAssessmentPerformedDuringEncounter(visit, m, QPP275Elements.Assessment_Of_Hbv_Status)
          ||
          wasAssessmentPerformedBeforeMedicationActive(visit, m, QPP275Elements.First_Course_Of_Anti_Tnf_Therapy, QPP275Elements.Hepatitis_B_Virus__Hbv__Status, QPP275Elements.Hbv_Tools, QPP275Elements.Hbv_Status, patientHistoryBroadcastList)
          ||
          (isAssessmentPerformedDuringEncounter(visit, m, QPP275Elements.Documented_Immunity_To_Hepatitis_B_G)
            // || wasAssessmentPerformedBeforeMedicationActive(visit, m, QPP275Elements.Hepatitis_B___Immunity_Documented, QPP275Elements.Anti_Tnf_Therapy, patientHistoryList)
            )
            &&
            !(isAssessmentPerformedDuringEncounter(visit, m, QPP275Elements.Hbv_Status_Not_Assessed__Reason_Not_Specified)
              && isAssessmentPerformedDuringEncounter(visit, m, QPP275Elements.Hbv_Results_Documented___No_Record)
              )
        )
    )
  }


  /*   Documented reason for not assessing Hepatitis B Virus (HBV) status (e.g. patient not receiving a first course of anti-TNF therapy, patient declined) within one year prior to first course of anti-TNF therapy */

  def getException(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      isAssessmentPerformedOnEncounter(visit, m, QPP275Elements.Assessment_Of_Hbv_Status_Patient_Reason)
        || wasAssessmentPerformedBeforeMedicationActive(visit, m, QPP275Elements.Hbv_Status___Patient_Reason, QPP275Elements.First_Course_Of_Anti_Tnf_Therapy, patientHistoryBroadcastList)
        || wasCommunicationDoneFromPatientToProviderBeforeMedicationActive(visit, m, QPP275Elements.Patient_Refusal, QPP275Elements.First_Course_Of_Anti_Tnf_Therapy, patientHistoryBroadcastList)
    )

  }

}