package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

import com.figmd.janus.measureComputation.master.{ECQM155V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm155v7
* Measure Title              :- Weight Assessment and Counseling for Nutrition and Physical Activity for Children and Adolescents
* Measure Description        :- "Description
                                 Percentage of patients 3-17 years of age who had an outpatient visit with a Primary Care Physician (PCP)
                                 or Obstetrician/Gynecologist (OB/GYN) and who had evidence of the following during the measurement period.
                                 Three rates are reported.
                                 - Percentage of patients with height, weight, and body mass index (BMI) percentile documentation
                                 - Percentage of patients with counseling for nutrition
                                 - Percentage of patients with counseling for physical activity"
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 3
* Measure Stratum No.        :- 1
* Measure Stratification     :- 2
* Measure Stratification No. :- 2
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm155V7_1_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm155V7_1_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //NotEligible
      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Backtracking
      val getPatientHistoryList = getPatientHistory(sparkSession, ippRDD,
        ECQM155V7Elements.Bmi_Percentile,
        ECQM155V7Elements.Height,
        ECQM155V7Elements.Weight,
        ECQM155V7Elements.Hospice_Care_Ambulatory,
        ECQM155V7Elements.Encounter_Inpatient,
        ECQM155V7Elements.Discharged_To_Home_For_Hospice_Care,
        ECQM155V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care)
      val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList.collect().toList)

      //Filter Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateMet, patientHistoryList)
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter NotMet
      val notMetRDD = getSubtractRDD(intermediateMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }

  /*---------------------------------------------------------------------------------------------------------------------
    Patients 3-17 years of age with at least one outpatient visit with a primary care physician (PCP)
    or an obstetrician/gynecologist (OB/GYN) during the measurement period
   ---------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeBetween(visit, m, 11, 17)
        && isVisitTypeIn(visit, m,
        ECQM155V7Elements.Office_Visit,
        ECQM155V7Elements.Preventive_Care_Services_Individual_Counseling,
        ECQM155V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,
        ECQM155V7Elements.Preventive_Care__Established_Office_Visit__0_To_17,
        ECQM155V7Elements.Preventive_Care_Services___Group_Counseling,
        ECQM155V7Elements.Home_Healthcare_Services)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
    Patients who have a diagnosis of pregnancy during the measurement period.
    Exclude patients whose hospice care overlaps the measurement period.
   ---------------------------------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        isEncounterPerformed(visit, m, ECQM155V7Elements.Encounter_Inpatient, patientHistoryList)
          && (
          isEncounterPerformed(visit, m, ECQM155V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
            || isEncounterPerformed(visit, m, ECQM155V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
          )
        )
        || wasInterventionPerformedInHistory(visit, m, ECQM155V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        || isInterventionOrdered(visit, m, ECQM155V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        || isDiagnosedWithOnEncounter(visit, m, ECQM155V7Elements.Pregnancy)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------------
    Numerator 1: Patients who had a height, weight and body mass index (BMI) percentile recorded during the measurement period
   --------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateMet: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateMet.filter(visit =>
      isPhysicalExamPerformed(visit, m, ECQM155V7Elements.Bmi_Percentile, patientHistoryList)
        && isPhysicalExamPerformed(visit, m, ECQM155V7Elements.Height, patientHistoryList)
        && isPhysicalExamPerformed(visit, m, ECQM155V7Elements.Weight, patientHistoryList)
    )
  }


}