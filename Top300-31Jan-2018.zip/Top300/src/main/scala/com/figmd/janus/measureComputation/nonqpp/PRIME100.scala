package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty,PRIME100Elements,CalenderUnit,CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- PRIME100
* Measure Title               :- Measuring the Value-Functions of Primary Care: Provider Level Continuity Measure
* Measure Description         :- Bice-Boxerman Continuity of Care Primary Care Physician Measure (BB-COC-PC).

                                 At a patient-level, BB-COC is a measure that considers the dispersion of primary care
                                 visits across providers, such that patients with higher scores have most of their primary
                                 care visits to the same provider or a small number of providers while those lower scores
                                 see a larger number providers.  Formally, an individual BB-COC score is calculated as follows:

                                 BB-COC=(∑_(i=1)^k n_i^2 -N)/(N(N-1))    (1)

                                 where k is the number of providers, n_i is the number of visits to provider i, and N is
                                 the total number of visits.  (Note that it is necessary that the patient has at least two visits.)
                                 We will calculate the physician-level continuity measure for all patients as follows:

                                 BB-COC-PC=(∑_1^k 〖((BB-COC)(n_k ))〗)/(N*(n_k))  (2)

                                 Where BB-COC is the individual patient continuity score, n is number of total primary
                                 care visits for patient k during the study period, and N is the total number of patients
                                 seen by the physicians during the study period.  This approach gives greater weight to
                                 patients with more visits.

* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SANKET.DHAPTE
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object PRIME100 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "PRIME100"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,PRIME100Elements.Office_Visit
      ,PRIME100Elements.Home_Healthcare_Services
      ,PRIME100Elements.Pcp_Visit
      ,PRIME100Elements.Counseling_Risk_Factor
      ,PRIME100Elements.Care_Plan_Oversight_Services
      ,PRIME100Elements.Prolonged_Services
      ,PRIME100Elements.Annual_Wellness_Visit
      ,PRIME100Elements.Initial_Preventive_Physical_Examination
      ,PRIME100Elements.Disability_Examination_Visit
      ,PRIME100Elements.Preventive_Care_Services___Other
      ,PRIME100Elements.Preventive_Care_Services___Group_Counseling
      ,PRIME100Elements.Preventive_Care_Services_Individual_Counseling
      ,PRIME100Elements.Preventive_Care__Established_Office_Visit__0_To_17
      ,PRIME100Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
      ,PRIME100Elements.Outpatient_Consultation
      ,PRIME100Elements.Subsequent_Observation_Care
      ,PRIME100Elements.Hospital_Observation_Care___Initial
      ,PRIME100Elements.Individual_Physician_Supervision
      ,PRIME100Elements.Nursing_Facility_Visit
      ,PRIME100Elements.Care_Services_In_Long_Term_Residential_Facility
      ,PRIME100Elements.Discharge_Services___Nursing_Facility
      ,PRIME100Elements.Post_Residency_Practice
      ,PRIME100Elements.New_Job
      ,PRIME100Elements.Physicians_Practicing_Multiple_Locations
      ,PRIME100Elements.Bice_Boxerman_Continuity_Of_Care_Score
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList,patientHistoryRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
The denominator in equation (2) is the number of patients cared for by a primary care physician, weighted by the number of primary care visits.  The main measure includes ALL patients from the PCP.  We will also develop measures restricted to 1) patients with multiple chronic conditions, and 2) high frequency patients (see below).
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    val countRDD = countElement(patientHistoryRDD, m
                                                      ,PRIME100Elements.Office_Visit
                                                      ,PRIME100Elements.Home_Healthcare_Services
                                                      ,PRIME100Elements.Pcp_Visit
                                                      ,PRIME100Elements.Counseling_Risk_Factor
                                                      ,PRIME100Elements.Care_Plan_Oversight_Services
                                                      ,PRIME100Elements.Prolonged_Services
                                                      ,PRIME100Elements.Annual_Wellness_Visit
                                                      ,PRIME100Elements.Initial_Preventive_Physical_Examination
                                                      ,PRIME100Elements.Disability_Examination_Visit
                                                      ,PRIME100Elements.Preventive_Care_Services___Other
                                                      ,PRIME100Elements.Preventive_Care_Services___Group_Counseling
                                                      ,PRIME100Elements.Preventive_Care_Services_Individual_Counseling
                                                      ,PRIME100Elements.Preventive_Care__Established_Office_Visit__0_To_17
                                                      ,PRIME100Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
                                                      ,PRIME100Elements.Outpatient_Consultation
                                                      ,PRIME100Elements.Subsequent_Observation_Care
                                                      ,PRIME100Elements.Hospital_Observation_Care___Initial
                                                      ,PRIME100Elements.Individual_Physician_Supervision
                                                      ,PRIME100Elements.Nursing_Facility_Visit
                                                      ,PRIME100Elements.Care_Services_In_Long_Term_Residential_Facility
                                                      ,PRIME100Elements.Discharge_Services___Nursing_Facility
                                )
    initialRDD.filter( visit =>
      getEncounterCountFromHistory(visit,m,2,true,countRDD)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
For our primary analysis, we will restrict our sample of PCPs to those that have a “stable” practice.  Specifically, we will exclude PCPs with
1) fewer than two years of post-residency practice,
2) physicians who have started a new job in the past two years, and
3) physicians practicing in multiple locations.  In additional analyses, we will examine these excluded physicians, given that we would expect them to have poorer continuity scores.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        wasProviderCharacteristicBeforeStartInXYear(visit,m,PRIME100Elements.Post_Residency_Practice,2,CalenderUnit.YEAR,CompareOperator.GREATER,patientHistoryBroadcastList)
     || wasProviderCharacteristicBeforeStartInXYear(visit,m,PRIME100Elements.New_Job,2,CalenderUnit.YEAR,CompareOperator.GREATER_EQUAL,patientHistoryBroadcastList)
     || wasProviderCharacteristicInHistory(visit,m,PRIME100Elements.Physicians_Practicing_Multiple_Locations,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
The numerator in equation (2) is the weighted sum of the BB-COC scores of patients (with 2 or more visits) cared for a primary care physician.  Each patients score is weighted by the number of primary care visits to give greater weight to patients with more visits.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>

      isAssessmentPerformed(visit,m,PRIME100Elements.Bice_Boxerman_Continuity_Of_Care_Score,patientHistoryBroadcastList)


    )
  }


}