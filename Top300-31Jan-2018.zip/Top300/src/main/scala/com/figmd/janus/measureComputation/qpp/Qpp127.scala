package com.figmd.janus.measureComputation.qpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master
import com.figmd.janus.measureComputation.qpp.Qpp127.wasAssessmentPerformedAfterDiagnosis

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 127
* Measure Title              :- Diabetes Mellitus: Diabetic Foot and Ankle Care, Ulcer Prevention – Evaluation of Footwear
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of diabetes mellitus who were evaluated for proper footwear and sizing
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp127 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp127"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      , QPP127Elements.Diabetes_Gr
      , QPP127Elements.Diabetes_Mellitus
      , QPP127Elements.Footwear_And_Sizing
      , QPP127Elements.Foot_Examination_Vascular
      , QPP127Elements.Foot_Examination_Dermatological
      , QPP127Elements.Foot_Examination_Structural_Biomechanical_Findings
      , QPP127Elements.Evaluation_Proper_Footwear
      , QPP127Elements.Appropriate_Footwear_Counseling
      , QPP127Elements.Footwear_And_Sizing_Not_Met
      , QPP127Elements.Bilateral_Amputee)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateA = getSubtractRDD(ippRDD, metRDD)
      intermediateA.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateA, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

/*-------------------------------------------------------------------------------------------------------------------------
All patients aged 18 years and older with a diagnosis of diabetes mellitus.
----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD:RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
            isPatientAdult(visit,m)
        &&  isVisitTypeIn(visit,m
              ,QPP127Elements.Office_Visit
              ,QPP127Elements.Debridement_Trimming_Cutting
              ,QPP127Elements.Debridement
              ,QPP127Elements.Home_Healthcare_Services
              ,QPP127Elements.Nursing_Facility_Visit
              ,QPP127Elements.Care_Services_In_Long_Term_Residential_Facility
              ,QPP127Elements.Physical_Therapy_Evaluation_97161_To_97164
              ,QPP127Elements.Medical_Nutrition_Therapy)
        &&  (    wasDiagnosedInHistory(visit,m,QPP127Elements.Diabetes_Gr,patientHistoryBroadcastList)
              || wasDiagnosedInHistory(visit,m,QPP127Elements.Diabetes_Mellitus,patientHistoryBroadcastList)
            )
        && ! isTeleHealthModifier(visit,m
              ,QPP127Elements.Office_Visit_Telehealth_Modifier
              ,QPP127Elements.Debridement_Trimming_Cutting_Telehealth_Modifier
              ,QPP127Elements.Debridement_Telehealth_Modifier
              ,QPP127Elements.Home_Healthcare_Services_Telehealth_Modifier
              ,QPP127Elements.Nursing_Facility_Visit_Telehealth_Modifier
              ,QPP127Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
              ,QPP127Elements.Physical_Therapy_Telehealth_Modifier
              ,QPP127Elements.Medical_Nutrition_Therapy__Telehealth_Modifier)
        &&  isPOSEncounterNotPerformed(visit,m,QPP127Elements.Pos_02)
    )
  }

/*-------------------------------------------------------------------------------------------------------------------------
Patients who were evaluated for proper footwear and sizing at least once within 12 months.
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      (   (  (   wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Gr,patientHistoryBroadcastList,QPP127Elements.Footwear_And_Sizing)
              || wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Mellitus,patientHistoryBroadcastList,QPP127Elements.Footwear_And_Sizing)
             )
             && wasAssessmentPerformedBeforeEncounterWithinXMonths(visit,m,AdminElements.Encounter_Date,QPP127Elements.Footwear_And_Sizing,12,patientHistoryBroadcastList)
          )
      || (  (   (   wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Gr,patientHistoryBroadcastList,QPP127Elements.Foot_Examination_Vascular)
                 || wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Mellitus,patientHistoryBroadcastList,QPP127Elements.Foot_Examination_Vascular)
                )
            &&  (   wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Gr,patientHistoryBroadcastList,QPP127Elements.Foot_Examination_Dermatological)
                 || wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Mellitus,patientHistoryBroadcastList,QPP127Elements.Foot_Examination_Dermatological)
                )
            &&  (   wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Gr,patientHistoryBroadcastList,QPP127Elements.Foot_Examination_Structural_Biomechanical_Findings)
                 || wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Mellitus,patientHistoryBroadcastList,QPP127Elements.Foot_Examination_Structural_Biomechanical_Findings)
                )
            && (    wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Gr,patientHistoryBroadcastList,QPP127Elements.Evaluation_Proper_Footwear)
                 || wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Mellitus,patientHistoryBroadcastList,QPP127Elements.Evaluation_Proper_Footwear)
               )
            && (    wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Gr,patientHistoryBroadcastList,QPP127Elements.Appropriate_Footwear_Counseling)
                 || wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Mellitus,patientHistoryBroadcastList,QPP127Elements.Appropriate_Footwear_Counseling)
               )
           )
          && (   wasAssessmentPerformedBeforeEncounterWithinXMonths(visit,m,AdminElements.Encounter_Date,QPP127Elements.Foot_Examination_Vascular,12,patientHistoryBroadcastList)
              && wasAssessmentPerformedBeforeEncounterWithinXMonths(visit,m,AdminElements.Encounter_Date,QPP127Elements.Foot_Examination_Dermatological,12,patientHistoryBroadcastList)
              && wasAssessmentPerformedBeforeEncounterWithinXMonths(visit,m,AdminElements.Encounter_Date,QPP127Elements.Foot_Examination_Structural_Biomechanical_Findings,12,patientHistoryBroadcastList)
              && wasAssessmentPerformedBeforeEncounterWithinXMonths(visit,m,AdminElements.Encounter_Date,QPP127Elements.Evaluation_Proper_Footwear,12,patientHistoryBroadcastList)
              && wasAssessmentPerformedBeforeEncounterWithinXMonths(visit,m,AdminElements.Encounter_Date,QPP127Elements.Appropriate_Footwear_Counseling,12,patientHistoryBroadcastList)
             )
        )
    )
    && ! (  (   wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Gr,patientHistoryBroadcastList,QPP127Elements.Footwear_And_Sizing_Not_Met)
             || wasAssessmentPerformedAfterDiagnosis(visit,m,QPP127Elements.Diabetes_Mellitus,patientHistoryBroadcastList,QPP127Elements.Footwear_And_Sizing_Not_Met)
            )
            && wasAssessmentPerformedBeforeEncounterWithinXMonths(visit,m,AdminElements.Encounter_Date,QPP127Elements.Footwear_And_Sizing_Not_Met,12,patientHistoryBroadcastList)
         )
 )
  }

/*-------------------------------------------------------------------------------------------------------------------------
Clinician documented that patient was not an eligible candidate for footwear evaluation measure.
----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    rdd.filter(visit =>
             isAssessmentPerformedDuringEncounter(visit,m,QPP127Elements.Foot_Sizing_Patient_Not_Eligible)
         ||  wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP127Elements.Bilateral_Amputee,patientHistoryBroadcastList)
    )
  }
}

