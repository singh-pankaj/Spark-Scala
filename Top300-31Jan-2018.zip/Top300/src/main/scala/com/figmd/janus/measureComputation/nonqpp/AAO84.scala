package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, AAO84Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAO 84
* Measure Title              :- Otitis Media with Effusion (OME): Avoidance of Inappropriate Use of Medications
* Measure Description        :- Percentage of patients aged 2 months through 12 years with a diagnosis of OME
*                               who were prescribed or recommended the use of steroids (either oral or intranasal),
*                               antimicrobials, antihistamines, or decongestants as therapy.
* Calculation Implementation :- Episode-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/

object AAO84 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO84"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var getPatientHistoryList = getPatientHistory(sparkSession,initialRDD,AAO84Elements.Medical_Reason_Antihistamines_Or_Decongestant,
      AAO84Elements.Allergic_Rhinitis_Grouping,
      AAO84Elements.Adenoidal_Hypertrophy,
      AAO84Elements.Nasal_Polyps,
      AAO84Elements.Asthma,
      AAO84Elements.Mastoiditis,
      AAO84Elements.Diagnosis_Of_Otitis_Media_With_Effusion
    )
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList.collect().toList)

    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //filter denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exceptions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD)
      metRDD.cache()

      val intermediateRDD = ippRDD.subtract(metRDD)
      intermediateRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateRDD, patientHistoryList: Broadcast[List[CassandraRow]])
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()
    }

  }

  /*
  All patients aged 2 months through 12 years with a diagnosis of OME
   */
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
      isAgeAboveInMonth(visit, m, true,2)
        && isAgeBelow(visit, m, false, 13)
        && isVisitTypeIn(visit, m, AAO84Elements.Office_Visit,
        AAO84Elements.Outpatient_Consultation,
        AAO84Elements.Preventive_Care__Established_Office_Visit__0_To_17,
        AAO84Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17)
        && isDiagnosedOnEncounter(visit, m, AAO84Elements.Diagnosis_Of_Otitis_Media_With_Effusion)
        && ! wasDiagnosisXDaysBeforeEncounter(visit, m, AAO84Elements.Diagnosis_Of_Otitis_Media_With_Effusion,90, patientHistoryList)

    )
  }
  /*
  Patients who were prescribed or recommended to receive any of the following:

    either antihistamines or decongestants
    systemic corticosteroids
    topical intranasal corticosteroids
    systemic antimicrobials
   */
  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
        (
          isMedicationOrderedOnEncounter(visit, m, AAO84Elements.Systemic_Antimicrobial_Therapy)
          || isMedicationOrderedOnEncounter(visit, m, AAO84Elements.Systemic_Corticosteroids)
          || isMedicationOrderedOnEncounter(visit, m, AAO84Elements.Antihistamines_Or_Decongestants_Rxnorm)
          || isMedicationOrderedOnEncounter(visit, m, AAO84Elements.Topical_Intranasal_Corticosteroids)
        ))
  }
  /*
  Medical reason(s) for patients already receiving steroids (either oral or intranasal), antimicrobials, antihistamines, or decongestants
   */

  def getException(intermediateRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermediateRdd.filter(visit =>
         wasDiagnosedInHistory(visit,m, AAO84Elements.Medical_Reason_Antihistamines_Or_Decongestant,patientHistoryList)
      || wasDiagnosedInHistory(visit,m, AAO84Elements.Allergic_Rhinitis_Grouping,patientHistoryList)
      || wasDiagnosedInHistory(visit,m, AAO84Elements.Adenoidal_Hypertrophy,patientHistoryList)
      || wasDiagnosedInHistory(visit,m, AAO84Elements.Nasal_Polyps,patientHistoryList)
      || wasDiagnosedInHistory(visit,m, AAO84Elements.Asthma,patientHistoryList)
      || wasDiagnosedInHistory(visit,m, AAO84Elements.Mastoiditis,patientHistoryList)
    )
  }

}
