package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{CompareOperator, MeasureProperty, QPP338Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 338
* Measure Title              :- HIV Viral Load Suppression
* Measure Description        :- The percentage of patients,regardless of age,with a diagnosis of HIV with a HIV viral load
                                less than 200copies/mL at last HIV viral load test during the measurement year
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp338 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp338"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      ,QPP338Elements.Hiv
      ,QPP338Elements.Hiv_Viral_Load_Not_Met
      ,QPP338Elements.Hiv_Viral_Load
      ,QPP338Elements.Viral_Load_For_Hiv).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
   Patients, regardless of age, with a diagnosis of HIV who had at least one medical visit
   during the performance period
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
             wasDiagnosedInHistory(visit,m,QPP338Elements.Hiv,patientHistoryList)
        &&   isVisitTypeIn(visit,m,
             QPP338Elements.Office_Visit,
             QPP338Elements.Initial_Preventive_Physical_Examination)
    )
  }

  /*---------------------------------------------------------------------------------------------------------
   Number of patients with a HIV viral load less than 200 copies/mL at last viral load test
   --------------------------------------------------------------------------------------------------------*/

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
        (
               wasLaboratoryTestPerformedAfterDiagnosis(visit,m,QPP338Elements.Hiv,QPP338Elements.Viral_Load_For_Hiv,patientHistoryList)
          ||   wasLaboratoryTestPerformedWithValueAfterDiagnosis(visit,m,QPP338Elements.Hiv,QPP338Elements.Hiv_Viral_Load,200,CompareOperator.LESS_EQUAL,patientHistoryList)
        )
        &&  !wasLaboratoryTestPerformedAfterDiagnosis(visit,m,QPP338Elements.Hiv,QPP338Elements.Hiv_Viral_Load_Not_Met,patientHistoryList)
    )
  }


}
