package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP350Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 350
* Measure Title              :- Total Knee Replacement: Shared Decision-Making: Trial of Conservative (Nonsurgical) Therapy
* Measure Description        :- Percentage of patients regardless of age undergoing a total knee replacement with documented shared
                                decisionmaking with discussion of conservative (non-surgical) therapy (e.g., non-steroidal anti-inflammatory drug
                                (NSAIDs), analgesics, weight loss, exercise, injections) prior to the procedure
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
* Initial GIT Version/Tag(CRA):-
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp350 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp350"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //getPatientHistoryList
      val patientHistoryList = getPatientHistory(sparkSession, ippRDD,
        QPP350Elements.Shared_Decision_Making_Approach,
        QPP350Elements.Shared_Decision_Making,
        QPP350Elements.Shared_Decision_Reason_Not_Specified
      ).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(denominatorRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  All patients regardless of age undergoing a total knee replacement
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>

      isProcedurePerformedDuringEncounter(visit, m, QPP350Elements.Total_Knee_Replacement)
    )

  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Patients with documented shared decision-making including discussion of conservative (non-surgical) therapy
    (e.g. NSAIDs, analgesics, weight loss, exercise, injections) prior to the procedure
   -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
      (
        isInterventionPerformed(visit, m, QPP350Elements.Shared_Decision_Making,patientHistoryBroadcastList)
          || wasInterventionPerformedBeforeProcedure(visit, m, QPP350Elements.Total_Knee_Replacement, patientHistoryBroadcastList, QPP350Elements.Shared_Decision_Making_Approach))
        && !isInterventionPerformedDuringProcedure(visit, m, QPP350Elements.Total_Knee_Replacement, QPP350Elements.Shared_Decision_Reason_Not_Specified)

    )
  }


}
