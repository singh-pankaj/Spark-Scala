package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP361Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 361
* Measure Title              :- Optimizing Patient Exposure to Ionizing Radiation: Reporting to a Radiation Dose Index Registry
* Measure Description        :- Percentage of total computed tomography (CT) studies performed for all patients,
                                regardless of age, that are submitted to a radiation dose index registry that is capable
                                of collecting at a minimum selected data elements
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher score equals better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp361 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp361"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP361Elements.Ct_Radiation_Dose_Index_Registry
      , QPP361Elements.Manufacturer
      , QPP361Elements.Study_Description
      , QPP361Elements.Manufacturer_Model_Name
      , QPP361Elements.Patient_Sex
      , QPP361Elements.Patient_Age
      , QPP361Elements.Patient_Size
      , QPP361Elements.Exposure_Time
      , QPP361Elements.X_Ray_Tube_Current
      , QPP361Elements.Kilovoltage
      , QPP361Elements.Mean_Volume_Computed_Tomography_Dose_Index
      , QPP361Elements.Dose_Length_Product
      , QPP361Elements.Ct_Rad_Reason_Not_Specified
      , QPP361Elements.Ct_Imaging
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      denominatorRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  /*------------------------------------------------------------------------------
    All final reports for patients, regardless of age, undergoing a CT procedure
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)


    initialRDD.filter(visit =>
      isDiagnosticStudyOnEncounter(visit,m,QPP361Elements.Ct_Imaging)
    )
  }

  /*------------------------------------------------------------------------------
    CT studies performed that are reported to a radiation dose index registry that is capable of collecting at a minimum all of the following data elements:
    •	Manufacturer
    •	Study description
    •	Manufacturer’s model name
    •	Patient’s weight
    •	Patient’s size
    •	Patient’s sex
    •	Patient’s age
    •	Exposure time
    •	X-Ray tube current
    •	Kilovoltage (kV)
    •	Mean Volume Computed tomography dose index (CTDIvol)
    •	Dose-length product (DLP)
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>

        (
             wasInterventionPerformedAfterEncounterinHistory(visit,m,QPP361Elements.Ct_Imaging,patientHistoryBroadcastList,QPP361Elements.Ct_Radiation_Dose_Index_Registry)
         ||
             (
                      wasDiagnosticStudyPerformedAfterEncounterinHistory(visit,m,QPP361Elements.Ct_Imaging,patientHistoryBroadcastList,QPP361Elements.Manufacturer)
                   && wasDiagnosticStudyPerformedAfterEncounterinHistory(visit,m,QPP361Elements.Ct_Imaging,patientHistoryBroadcastList,QPP361Elements.Study_Description)
                   && wasDiagnosticStudyPerformedAfterEncounterinHistory(visit,m,QPP361Elements.Ct_Imaging,patientHistoryBroadcastList,QPP361Elements.Manufacturer_Model_Name)
                   && wasPatientCharacteristicAfterEncounterinHistory(visit,m,QPP361Elements.Ct_Imaging,patientHistoryBroadcastList,QPP361Elements.Patient_Sex)
                   && wasPatientCharacteristicAfterEncounterinHistory(visit,m,QPP361Elements.Ct_Imaging,patientHistoryBroadcastList,QPP361Elements.Patient_Age)
                   && wasPatientCharacteristicAfterEncounterinHistory(visit,m,QPP361Elements.Ct_Imaging,patientHistoryBroadcastList,QPP361Elements.Patient_Size)
                   && wasDiagnosticStudyPerformedAfterEncounterinHistory(visit,m,QPP361Elements.Ct_Imaging,patientHistoryBroadcastList,QPP361Elements.Exposure_Time)
                   && wasDiagnosticStudyPerformedAfterEncounterinHistory(visit,m,QPP361Elements.Ct_Imaging,patientHistoryBroadcastList,QPP361Elements.X_Ray_Tube_Current)
                   && wasDiagnosticStudyPerformedAfterEncounterinHistory(visit,m,QPP361Elements.Ct_Imaging,patientHistoryBroadcastList,QPP361Elements.Kilovoltage)
                   && wasDiagnosticStudyPerformedAfterEncounterinHistory(visit,m,QPP361Elements.Ct_Imaging,patientHistoryBroadcastList,QPP361Elements.Mean_Volume_Computed_Tomography_Dose_Index)
                   && wasDiagnosticStudyPerformedAfterEncounterinHistory(visit,m,QPP361Elements.Ct_Imaging,patientHistoryBroadcastList,QPP361Elements.Dose_Length_Product)
             )
        )
        && !wasInterventionPerformedAfterEncounterinHistory(visit,m,QPP361Elements.Ct_Imaging,patientHistoryBroadcastList,QPP361Elements.Ct_Rad_Reason_Not_Specified)
    )
  }
}
