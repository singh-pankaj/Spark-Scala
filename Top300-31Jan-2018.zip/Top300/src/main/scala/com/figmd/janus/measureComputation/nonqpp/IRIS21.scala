package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, IRIS21Elements,MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS21
* Measure Title               :- Ocular Myasthenia Gravis: Improvement of ocular deviation or absence of diplopia or functional improvement
* Measure Description         :- Percentage of patients with improvement of ocular deviation or absence of diplopia in primary gaze after treatment
                                 or functional improvement of ptosis at 6 months
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.9
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.9
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS21 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "IRIS21"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,IRIS21Elements.Ophthalmological_Services
      ,IRIS21Elements.Office_Visit
      ,IRIS21Elements.Office_Consultation
      ,IRIS21Elements.Ocular_Myasthenia_Gravis
      ,IRIS21Elements.Ptosis
      ,IRIS21Elements.Ptosis__Eye
      ,IRIS21Elements.Ocular_Myasthenia_Gravis__Eye
      ,IRIS21Elements.Diplopia
      ,IRIS21Elements.Ocular_Myasthenia_Gravis__Eye
      ,IRIS21Elements.Diplopia__Eye
      ,IRIS21Elements.Ocular_Deviation
      ,IRIS21Elements.Drug_Therapy
      ,IRIS21Elements.Strabismus_Surgery
      ,IRIS21Elements.Extraocular_Muscle_Procedure
      ,IRIS21Elements.Blepharoptosis_Repair
      ,IRIS21Elements.Press_On_Prism_Procedure
      ,IRIS21Elements.Occluder_Lens_Procedure
      ,IRIS21Elements.Ocular_Deviation_Eye
      ,IRIS21Elements.Drug_Therapy__Eye
      ,IRIS21Elements.Strabismus_Surgery__Eye
      ,IRIS21Elements.Extraocular_Muscle_Procedure__Eye
      ,IRIS21Elements.Blepharoptosis_Repair_Eye
      ,IRIS21Elements.Press_On_Prism_Procedure_Eye
      ,IRIS21Elements.Occluder_Lens_Procedure__Eye
      ,IRIS21Elements.Ptosis__Diplopia
      ,IRIS21Elements.Ptosis__Diplopia_Eye
      ,IRIS21Elements.Absence_Of_Diplopia
      ,IRIS21Elements.Absence_Of_Diplopia__Eye
      ,IRIS21Elements.Improvement_Of_Ptosis
      ,IRIS21Elements.Improvement_Of_Ptosis__Eye
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList,patientHistoryRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients aged 18 years or older diagnosed with ocular myasthenia gravis between January 1 and June 30 of the reporting period and received treatment for the condition
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val countElementList1: List[(String,Int)] = countElementInXMonths(patientHistoryRDD,m,6
                                                    ,IRIS21Elements.Ophthalmological_Services
                                                    ,IRIS21Elements.Office_Visit
                                                    ,IRIS21Elements.Office_Consultation)
    initialRDD.filter(visit =>
              isPatientAdult(visit,m)
          &&  getEncounterCountFromHistory(visit,m,2,true, countElementList1)
          &&  isDiagnosisStartsAfterStartWithinXMonths(visit,m,IRIS21Elements.Ocular_Myasthenia_Gravis,6,patientHistoryBroadcastList)
          &&  (   (   isDiagnosisStartsAfterStartWithinXMonths(visit,m,IRIS21Elements.Ptosis,6,patientHistoryBroadcastList)
                   && checkSpecificEyeElementWIthOtherEyeElementInHistory(visit,m,IRIS21Elements.Ocular_Myasthenia_Gravis__Eye,patientHistoryBroadcastList,IRIS21Elements.Ptosis__Eye)
                  )
               || (   isDiagnosisStartsAfterStartWithinXMonths(visit,m,IRIS21Elements.Diplopia,6,patientHistoryBroadcastList)
                   && checkSpecificEyeElementWIthOtherEyeElementInHistory(visit,m,IRIS21Elements.Ocular_Myasthenia_Gravis__Eye,patientHistoryBroadcastList,IRIS21Elements.Diplopia__Eye)
                  )
              )
          &&  (   ( wasPhysicalExamPerformedBeforeProcedureInHistory(visit,m,IRIS21Elements.Ocular_Deviation,patientHistoryBroadcastList
                                                               ,IRIS21Elements.Drug_Therapy
                                                               ,IRIS21Elements.Strabismus_Surgery
                                                               ,IRIS21Elements.Extraocular_Muscle_Procedure
                                                               ,IRIS21Elements.Blepharoptosis_Repair
                                                               ,IRIS21Elements.Press_On_Prism_Procedure
                                                               ,IRIS21Elements.Occluder_Lens_Procedure)
                    &&  (   checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ocular_Deviation_Eye,patientHistoryBroadcastList,IRIS21Elements.Drug_Therapy__Eye)
                         || checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ocular_Deviation_Eye,patientHistoryBroadcastList,IRIS21Elements.Strabismus_Surgery__Eye)
                         || checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ocular_Deviation_Eye,patientHistoryBroadcastList,IRIS21Elements.Extraocular_Muscle_Procedure__Eye)
                         || checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ocular_Deviation_Eye,patientHistoryBroadcastList,IRIS21Elements.Blepharoptosis_Repair_Eye)
                         || checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ocular_Deviation_Eye,patientHistoryBroadcastList,IRIS21Elements.Press_On_Prism_Procedure_Eye)
                         || checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ocular_Deviation_Eye,patientHistoryBroadcastList,IRIS21Elements.Occluder_Lens_Procedure__Eye)
                        )
                  )

                ||

                  ( wasPhysicalExamPerformedBeforeProcedureInHistory(visit,m,IRIS21Elements.Ptosis__Diplopia,patientHistoryBroadcastList
                                                              ,IRIS21Elements.Drug_Therapy
                                                              ,IRIS21Elements.Strabismus_Surgery
                                                              ,IRIS21Elements.Extraocular_Muscle_Procedure
                                                              ,IRIS21Elements.Blepharoptosis_Repair
                                                              ,IRIS21Elements.Press_On_Prism_Procedure
                                                              ,IRIS21Elements.Occluder_Lens_Procedure)
                    &&  (   checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ptosis__Diplopia_Eye,patientHistoryBroadcastList,IRIS21Elements.Drug_Therapy__Eye)
                         || checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ptosis__Diplopia_Eye,patientHistoryBroadcastList,IRIS21Elements.Strabismus_Surgery__Eye)
                         || checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ptosis__Diplopia_Eye,patientHistoryBroadcastList,IRIS21Elements.Extraocular_Muscle_Procedure__Eye)
                         || checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ptosis__Diplopia_Eye,patientHistoryBroadcastList,IRIS21Elements.Blepharoptosis_Repair_Eye)
                         || checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ptosis__Diplopia_Eye,patientHistoryBroadcastList,IRIS21Elements.Press_On_Prism_Procedure_Eye)
                         || checkEyeElementBeforeDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ptosis__Diplopia_Eye,patientHistoryBroadcastList,IRIS21Elements.Occluder_Lens_Procedure__Eye)
                        )
                  )

             )

          &&  (   (   wasMedicationAdministredAfterDiagnosisInHistory(visit,m,IRIS21Elements.Drug_Therapy,patientHistoryBroadcastList,IRIS21Elements.Ocular_Myasthenia_Gravis)
                   && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Drug_Therapy__Eye,patientHistoryBroadcastList,IRIS21Elements.Ocular_Myasthenia_Gravis__Eye)
                  )
               || (  wasProcedurePerformedAfterDiagnosisInHistory(visit,m,IRIS21Elements.Strabismus_Surgery,patientHistoryBroadcastList,IRIS21Elements.Ocular_Myasthenia_Gravis)
                  && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Strabismus_Surgery__Eye,patientHistoryBroadcastList,IRIS21Elements.Ocular_Myasthenia_Gravis__Eye)
                  )
               || (  wasProcedurePerformedAfterDiagnosisInHistory(visit,m,IRIS21Elements.Extraocular_Muscle_Procedure,patientHistoryBroadcastList,IRIS21Elements.Ocular_Myasthenia_Gravis)
                  && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Extraocular_Muscle_Procedure__Eye,patientHistoryBroadcastList,IRIS21Elements.Ocular_Myasthenia_Gravis__Eye)
                  )
               || (  wasProcedurePerformedAfterDiagnosisInHistory(visit,m,IRIS21Elements.Blepharoptosis_Repair,patientHistoryBroadcastList,IRIS21Elements.Ocular_Myasthenia_Gravis)
                  && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Blepharoptosis_Repair_Eye,patientHistoryBroadcastList,IRIS21Elements.Ocular_Myasthenia_Gravis__Eye)
                  )
               || (   wasProcedurePerformedAfterDiagnosisInHistory(visit,m,IRIS21Elements.Press_On_Prism_Procedure,patientHistoryBroadcastList,IRIS21Elements.Ocular_Myasthenia_Gravis)
                   && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Press_On_Prism_Procedure_Eye,patientHistoryBroadcastList,IRIS21Elements.Ocular_Myasthenia_Gravis__Eye)
                  )
               || (   wasProcedurePerformedAfterDiagnosisInHistory(visit,m,IRIS21Elements.Occluder_Lens_Procedure,patientHistoryBroadcastList,IRIS21Elements.Ocular_Myasthenia_Gravis)
                   && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Occluder_Lens_Procedure__Eye,patientHistoryBroadcastList,IRIS21Elements.Ocular_Myasthenia_Gravis__Eye)
                  )
              )
          &&  (   (   wasMedicationAdministredAfterDiagnosisInHistory(visit,m,IRIS21Elements.Drug_Therapy,patientHistoryBroadcastList,IRIS21Elements.Ptosis,IRIS21Elements.Diplopia)
                   && (   checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Drug_Therapy__Eye,patientHistoryBroadcastList,IRIS21Elements.Ptosis__Eye)
                       || checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Drug_Therapy__Eye,patientHistoryBroadcastList,IRIS21Elements.Diplopia__Eye)
                      )
                  )
               || (   wasProcedurePerformedAfterDiagnosisInHistory(visit,m,IRIS21Elements.Strabismus_Surgery,patientHistoryBroadcastList,IRIS21Elements.Ptosis,IRIS21Elements.Diplopia)
                   && (   checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Strabismus_Surgery__Eye,patientHistoryBroadcastList,IRIS21Elements.Ptosis__Eye)
                       || checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Strabismus_Surgery__Eye,patientHistoryBroadcastList,IRIS21Elements.Diplopia__Eye)
                      )
                  )
               || (   wasProcedurePerformedAfterDiagnosisInHistory(visit,m,IRIS21Elements.Extraocular_Muscle_Procedure,patientHistoryBroadcastList,IRIS21Elements.Ptosis,IRIS21Elements.Diplopia)
                   && (   checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Extraocular_Muscle_Procedure__Eye,patientHistoryBroadcastList,IRIS21Elements.Ptosis__Eye)
                       || checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Extraocular_Muscle_Procedure__Eye,patientHistoryBroadcastList,IRIS21Elements.Diplopia__Eye)
                      )
                  )
               || (   wasProcedurePerformedAfterDiagnosisInHistory(visit,m,IRIS21Elements.Blepharoptosis_Repair,patientHistoryBroadcastList,IRIS21Elements.Ptosis,IRIS21Elements.Diplopia)
                   && (  checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Blepharoptosis_Repair_Eye,patientHistoryBroadcastList,IRIS21Elements.Ptosis__Eye)
                      || checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Blepharoptosis_Repair_Eye,patientHistoryBroadcastList,IRIS21Elements.Diplopia__Eye)
                      )
                  )
               || (   wasProcedurePerformedAfterDiagnosisInHistory(visit,m,IRIS21Elements.Press_On_Prism_Procedure,patientHistoryBroadcastList,IRIS21Elements.Ptosis,IRIS21Elements.Diplopia)
                   && (   checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Press_On_Prism_Procedure_Eye,patientHistoryBroadcastList,IRIS21Elements.Ptosis__Eye)
                       || checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Press_On_Prism_Procedure_Eye,patientHistoryBroadcastList,IRIS21Elements.Diplopia__Eye)
                      )
                  )
               || (   wasProcedurePerformedAfterDiagnosisInHistory(visit,m,IRIS21Elements.Occluder_Lens_Procedure,patientHistoryBroadcastList,IRIS21Elements.Ptosis,IRIS21Elements.Diplopia)
                   && (  checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Occluder_Lens_Procedure__Eye,patientHistoryBroadcastList,IRIS21Elements.Ptosis__Eye)
                      || checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Occluder_Lens_Procedure__Eye,patientHistoryBroadcastList,IRIS21Elements.Diplopia__Eye)
                      )
                  )
              )

          &&  (    (    (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Ocular_Deviation,IRIS21Elements.Drug_Therapy,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                         && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ocular_Deviation_Eye,patientHistoryBroadcastList,IRIS21Elements.Drug_Therapy__Eye)
                        )
                    ||  (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Ocular_Deviation,IRIS21Elements.Strabismus_Surgery,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                         && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ocular_Deviation_Eye,patientHistoryBroadcastList,IRIS21Elements.Strabismus_Surgery__Eye)
                        )
                    ||  (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Ocular_Deviation,IRIS21Elements.Extraocular_Muscle_Procedure,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                         && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ocular_Deviation_Eye,patientHistoryBroadcastList,IRIS21Elements.Extraocular_Muscle_Procedure__Eye)
                        )
                    ||  (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Ocular_Deviation,IRIS21Elements.Blepharoptosis_Repair,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                         && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ocular_Deviation_Eye,patientHistoryBroadcastList,IRIS21Elements.Blepharoptosis_Repair_Eye)
                        )
                    ||  (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Ocular_Deviation,IRIS21Elements.Press_On_Prism_Procedure,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                         && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ocular_Deviation_Eye,patientHistoryBroadcastList,IRIS21Elements.Press_On_Prism_Procedure_Eye)
                        )
                    ||  (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Ocular_Deviation,IRIS21Elements.Occluder_Lens_Procedure,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                         && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ocular_Deviation_Eye,patientHistoryBroadcastList,IRIS21Elements.Occluder_Lens_Procedure__Eye)
                        )
                  )
               ||
                (    (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Ptosis__Diplopia,IRIS21Elements.Drug_Therapy,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                       && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ptosis__Diplopia_Eye,patientHistoryBroadcastList,IRIS21Elements.Drug_Therapy__Eye)
                     )
                  || (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Ptosis__Diplopia,IRIS21Elements.Strabismus_Surgery,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                      && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ptosis__Diplopia_Eye,patientHistoryBroadcastList,IRIS21Elements.Strabismus_Surgery__Eye)
                     )
                  || (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Ptosis__Diplopia,IRIS21Elements.Extraocular_Muscle_Procedure,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                      && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ptosis__Diplopia_Eye,patientHistoryBroadcastList,IRIS21Elements.Extraocular_Muscle_Procedure__Eye)
                     )
                  || (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Ptosis__Diplopia,IRIS21Elements.Blepharoptosis_Repair,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                      && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ptosis__Diplopia_Eye,patientHistoryBroadcastList,IRIS21Elements.Blepharoptosis_Repair_Eye)
                     )
                  || (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Ptosis__Diplopia,IRIS21Elements.Press_On_Prism_Procedure,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                      && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ptosis__Diplopia_Eye,patientHistoryBroadcastList,IRIS21Elements.Press_On_Prism_Procedure_Eye)
                     )
                  || (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Ptosis__Diplopia,IRIS21Elements.Occluder_Lens_Procedure,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                      && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Ptosis__Diplopia_Eye,patientHistoryBroadcastList,IRIS21Elements.Occluder_Lens_Procedure__Eye)
                     )
                )
            )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with improvement of ocular deviation or absence of diplopia in primary gaze after treatment or functional improvement of ptosis at 6 months
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            wasImprovementInOcularDeviation(visit,m,List(IRIS21Elements.Ocular_Myasthenia_Gravis,IRIS21Elements.Diplopia,IRIS21Elements.Ptosis),List(
                                                                      IRIS21Elements.Drug_Therapy
                                                                      ,IRIS21Elements.Strabismus_Surgery
                                                                      ,IRIS21Elements.Extraocular_Muscle_Procedure
                                                                      ,IRIS21Elements.Blepharoptosis_Repair
                                                                      ,IRIS21Elements.Press_On_Prism_Procedure
                                                                      ,IRIS21Elements.Occluder_Lens_Procedure),IRIS21Elements.Ocular_Deviation,patientHistoryBroadcastList)
      ||
            (    (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Absence_Of_Diplopia,IRIS21Elements.Drug_Therapy,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                  && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Absence_Of_Diplopia__Eye,patientHistoryBroadcastList,IRIS21Elements.Drug_Therapy__Eye)
                 )
              ||  (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Absence_Of_Diplopia,IRIS21Elements.Strabismus_Surgery,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                   && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Absence_Of_Diplopia__Eye,patientHistoryBroadcastList,IRIS21Elements.Strabismus_Surgery__Eye)
                  )
              ||  (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Absence_Of_Diplopia,IRIS21Elements.Extraocular_Muscle_Procedure,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                   && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Absence_Of_Diplopia__Eye,patientHistoryBroadcastList,IRIS21Elements.Extraocular_Muscle_Procedure__Eye)
                  )
              ||  (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Absence_Of_Diplopia,IRIS21Elements.Blepharoptosis_Repair,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                   && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Absence_Of_Diplopia__Eye,patientHistoryBroadcastList,IRIS21Elements.Blepharoptosis_Repair_Eye)
                  )
              ||  (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Absence_Of_Diplopia,IRIS21Elements.Press_On_Prism_Procedure,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                   && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Absence_Of_Diplopia__Eye,patientHistoryBroadcastList,IRIS21Elements.Press_On_Prism_Procedure_Eye)
                  )
              ||  (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Absence_Of_Diplopia,IRIS21Elements.Occluder_Lens_Procedure,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                   && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Absence_Of_Diplopia__Eye,patientHistoryBroadcastList,IRIS21Elements.Occluder_Lens_Procedure__Eye)
                  )
            )

      ||
            (    (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Improvement_Of_Ptosis,IRIS21Elements.Drug_Therapy,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                   && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Improvement_Of_Ptosis__Eye,patientHistoryBroadcastList,IRIS21Elements.Drug_Therapy__Eye)
                 )
              || (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Improvement_Of_Ptosis,IRIS21Elements.Strabismus_Surgery,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                  && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Improvement_Of_Ptosis__Eye,patientHistoryBroadcastList,IRIS21Elements.Strabismus_Surgery__Eye)
                 )
              || (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Improvement_Of_Ptosis,IRIS21Elements.Extraocular_Muscle_Procedure,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                  && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Improvement_Of_Ptosis__Eye,patientHistoryBroadcastList,IRIS21Elements.Extraocular_Muscle_Procedure__Eye)
                 )
              || (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Improvement_Of_Ptosis,IRIS21Elements.Blepharoptosis_Repair,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                  && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Improvement_Of_Ptosis__Eye,patientHistoryBroadcastList,IRIS21Elements.Blepharoptosis_Repair_Eye)
                 )
              || (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Improvement_Of_Ptosis,IRIS21Elements.Press_On_Prism_Procedure,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                  && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Improvement_Of_Ptosis__Eye,patientHistoryBroadcastList,IRIS21Elements.Press_On_Prism_Procedure_Eye)
                 )
              || (   wasPhysicalExamPerformedInXMonthsAfterProcedure(visit,m,IRIS21Elements.Improvement_Of_Ptosis,IRIS21Elements.Occluder_Lens_Procedure,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
                  && checkEyeElementAfterDiagnosisEyesElementInHistory(visit,m,IRIS21Elements.Improvement_Of_Ptosis__Eye,patientHistoryBroadcastList,IRIS21Elements.Occluder_Lens_Procedure__Eye)
                 )
            )
    )
  }

}
