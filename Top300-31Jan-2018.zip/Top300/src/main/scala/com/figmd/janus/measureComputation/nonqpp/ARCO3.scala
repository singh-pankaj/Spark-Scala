package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,CalenderUnit,ARCO3Elements,TimeOperator,CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- ARCO03
* Measure Title               :- Antipsychotic Use in Persons with Dementia
* Measure Description         :- This measure is used to assess the percentage of individuals 65 years and older with
                                 dementia who are receiving an antipsychotic medication without evidence of a psychotic
                                 disorder or related condition.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SANKET.DHAPTE
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
----------------------------------------------------------------------------------------------------------------------------*/

object ARCO3 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "ARCO03"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,ARCO3Elements.Cholinesterase_Inhibitor_Nmda_Receptor_Antagonist_Grp
      ,ARCO3Elements.Cholinesterase_Inhibitor_Nmda_Receptor_Antagonist_Stop_Date
      ,ARCO3Elements.Dementia
      ,ARCO3Elements.Antipsychotic_Medications
      ,ARCO3Elements.Antpsychotic_Medication_Stop_Date
      ,ARCO3Elements.Psychotic_Disorder_Or_Related_Condition
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(sparkSession,initialRDD, patientHistoryBroadcastList,patientHistoryRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(sparkSession,denominatorRDD, patientHistoryBroadcastList,patientHistoryRDD)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients 65 years and older with either a diagnosis of dementia and/or two or more prescription claims and greater than
60 days supply for a cholinesterase inhibitor or an N-methyl-D-aspartate (NMDA) receptor antagonist.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(sparkSession: SparkSession,initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistory:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    val countRDD = countElement(patientHistory, m,ARCO3Elements.Cholinesterase_Inhibitor_Nmda_Receptor_Antagonist_Grp )
    val MedicationList:List[(String,String)] = List((ARCO3Elements.Cholinesterase_Inhibitor_Nmda_Receptor_Antagonist_Grp,ARCO3Elements.Cholinesterase_Inhibitor_Nmda_Receptor_Antagonist_Stop_Date))

    val MedicationResult=cumulative(patientHistory, m,MedicationList,CalenderUnit.DAY,CalenderUnit.DAY,0,TimeOperator.EQUAL)
    val MedicationResultBroadcastList: Broadcast[List[(String,String,Double)]] = sparkSession.sparkContext.broadcast(MedicationResult)
    initialRDD.filter(visit =>
         isAgeAboveBeforeStart(visit,m,true,65,CalenderUnit.YEAR)
      && wasDiagnosedInHistory(visit,m,ARCO3Elements.Dementia,patientHistoryBroadcastList)
      && getEncounterCountFromHistory(visit,m,2,true,countRDD)
      && getCommulativeResult(visit,m,ARCO3Elements.Cholinesterase_Inhibitor_Nmda_Receptor_Antagonist_Grp,60,CompareOperator.GREATER,MedicationResultBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
 	The number of patients in the denominator who had at least one prescription AND > 30 days supply for any anti psychotic
 	medication during the measurement period and do not have a diagnosis of schizophrenia,bipolar disorder,Huntington's
 	disease or Tourette's Syndrome.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(sparkSession: SparkSession,denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistory:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    val countRDD = countElement(patientHistory, m,ARCO3Elements.Antipsychotic_Medications )
    val MedicationList:List[(String,String)] = List((ARCO3Elements.Antipsychotic_Medications,ARCO3Elements.Antpsychotic_Medication_Stop_Date))

    val MedicationResult=cumulative(patientHistory, m,MedicationList,CalenderUnit.DAY,CalenderUnit.DAY,0,TimeOperator.EQUAL)
    val MedicationResultBroadcastList: Broadcast[List[(String,String,Double)]] = sparkSession.sparkContext.broadcast(MedicationResult)
    denominatorRDD.filter(visit =>
      (
          getEncounterCountFromHistory(visit,m,1,true,countRDD)
      &&  getCommulativeResult(visit,m,ARCO3Elements.Antipsychotic_Medications,30,CompareOperator.GREATER,MedicationResultBroadcastList)
        )
     && !wasDiagnosedInHistory(visit,m,ARCO3Elements.Psychotic_Disorder_Or_Related_Condition,patientHistoryBroadcastList)
    )
  }

}
