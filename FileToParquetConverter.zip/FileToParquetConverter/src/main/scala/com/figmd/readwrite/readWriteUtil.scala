package com.figmd.readwrite


//spark-submit --driver-memory 15G --deploy-mode cluster --master yarn --executor-memory 5G --num-executors 4 --executor-cores 3 --conf spark.yarn.maxAppAttempts=1 --class com.figmd.readwrite.readWriteUtil /home/dev/Akshay/filetoparquetconverter_2.11-0.1.jar

import org.apache.spark.sql.functions.{col}
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.Map
import scala.collection.immutable.ListMap

object readWriteUtil {

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder().getOrCreate()

    import spark.implicits._

    val section_headers = commonFunctions.getPostgresTable(spark, "section_headers").cache()

//        val PatientImmunization_lookup= commonFunctions.getlookupMap("PatientImmunization",section_headers)
//        val PatientGuardian_lookup= commonFunctions.getlookupMap("PatientGuardian",section_headers)
//        val PatientLabOrder_lookup= commonFunctions.getlookupMap("PatientLabOrder	",section_headers)

    val PatientDemographicss3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientDemographics/edea6658-b815-466d-aeea-17a9dd575dd1_[8f][d-f]*",spark)
    val PatientDemographics_lookup= commonFunctions.getlookupMap("PatientDemographics",section_headers)
    val PatientDemographicsFileWithHeaders = PatientDemographicss3Path.select(PatientDemographicss3Path.columns.map(c => col(c).as(PatientDemographics_lookup.getOrElse(c,c))): _*)
    PatientDemographicsFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientDemographics/")
    println("PatientDemographics done")


    val PatientSocialHistoryObservations3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientSocialHistoryObservation/813ee7ca-89da-4a2a-9b78-bbc710595fcc_f[d-f]*",spark)
    val PatientSocialHistoryObs_lookup= commonFunctions.getlookupMap("PatientSocialHistoryObs  ",section_headers)
    val PatientSocialHistoryObservationFileWithHeaders = PatientSocialHistoryObservations3Path.select(PatientSocialHistoryObservations3Path.columns.map(c => col(c).as(PatientSocialHistoryObs_lookup.getOrElse(c,c))): _*)
    PatientSocialHistoryObservationFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientSocialHistoryObservation/")
    println("PatientSocialHistoryObs done")

    val PatientAdvanceDirectives3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientAdvanceDirective/fa089e80-9064-41aa-9052-dbe36a15cb66_8[d-f]*",spark)
    val PatientAdvanceDirectiveObservation_lookup= commonFunctions.getlookupMap("PatientAdvanceDirectiveObservation",section_headers)
    val PatientAdvanceDirectiveFileWithHeaders = PatientAdvanceDirectives3Path.select(PatientAdvanceDirectives3Path.columns.map(c => col(c).as(PatientAdvanceDirectiveObservation_lookup.getOrElse(c,c))): _*)
    PatientAdvanceDirectiveFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientAdvanceDirective/")
    println("PatientAdvanceDirectiveObservation done")

    val PatientAllergiess3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientAllergies/ed4eba3a-8fda-4cf8-a0a0-204c08258599_8[d-f]*",spark)
    val PatientAllergy_lookup= commonFunctions.getlookupMap("PatientAllergy",section_headers)
    val PatientAllergiesFileWithHeaders = PatientAllergiess3Path.select(PatientAllergiess3Path.columns.map(c => col(c).as(PatientAllergy_lookup.getOrElse(c,c))): _*)
    PatientAllergiesFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientAllergies/")
    println("PatientAllergy done")

    val PatientPlanOfCares3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientPlanOfCare/4a188a2b-0e27-40d5-8a58-875e1113b4fa_8[d-f]*",spark)
    val PatientPlanOfCare_lookup= commonFunctions.getlookupMap("PatientPlanOfCare",section_headers)
    val PatientPlanOfCareFileWithHeaders = PatientPlanOfCares3Path.select(PatientPlanOfCares3Path.columns.map(c => col(c).as(PatientPlanOfCare_lookup.getOrElse(c,c))): _*)
    PatientPlanOfCareFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientPlanOfCare/")
    println("PatientPlanOfCare done")

    val PatientVitalSignss3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientVitalSigns/40eb7512-26ea-4eec-b05f-966fb63e1aa4_8[d-f]*",spark)
    val PatientVitalSignObservation_lookup= commonFunctions.getlookupMap("PatientVitalSignObservation",section_headers)
    val PatientVitalSignsFileWithHeaders = PatientVitalSignss3Path.select(PatientVitalSignss3Path.columns.map(c => col(c).as(PatientVitalSignObservation_lookup.getOrElse(c,c))): _*)
    PatientVitalSignsFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientVitalSigns/")
    println("PatientVitalSignObservation done")



    val PatientEncounters3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientEncounter/8ff9928e-7288-4491-8aa0-c7e0da5bbba8_8[d-f]*",spark)
    val PatientEncounter_lookup= commonFunctions.getlookupMap("PatientEncounter",section_headers)
    val PatientEncounterFileWithHeaders = PatientEncounters3Path.select(PatientEncounters3Path.columns.map(c => col(c).as(PatientEncounter_lookup.getOrElse(c,c))): _*)
    PatientEncounterFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientEncounter/")
    println("PatientEncounter done")

    val PatientEncounterDiagnosiss3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientEncounterDiagnosis/608cdee4-97d1-42a2-849d-9d9a95bc5131_8[d-f]*",spark)
    val PatientEncounterDiagnosis_lookup= commonFunctions.getlookupMap("PatientEncounterDiagnosis",section_headers)
    val PatientEncounterDiagnosisFileWithHeaders = PatientEncounterDiagnosiss3Path.select(PatientEncounterDiagnosiss3Path.columns.map(c => col(c).as(PatientEncounterDiagnosis_lookup.getOrElse(c,c))): _*)
    PatientEncounterDiagnosisFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientEncounterDiagnosis/")
    println("PatientEncounterDiaganosis done")

    val PatientEthnicitys3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientEthnicity/a06375b5-51cc-4028-88ea-1690c4e7b2e7_8[d-f]*",spark)
    val PatientEthnicity_lookup= commonFunctions.getlookupMap("PatientEthnicity",section_headers)
    val PatientEthnicityFileWithHeaders = PatientEthnicitys3Path.select(PatientEthnicitys3Path.columns.map(c => col(c).as(PatientEthnicity_lookup.getOrElse(c,c))): _*)
    PatientEthnicityFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientEthnicity/")
    println("PatientEthnicity done")

    val PatientFamilyHistorys3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientFamilyHistory/7b5b1bad-4a4d-454e-a9a7-942340314884_8[d-f]*",spark)
    val PatientFamilyHistory_lookup= commonFunctions.getlookupMap("PatientFamilyHistory",section_headers)
    val PatientFamilyHistoryFileWithHeaders = PatientFamilyHistorys3Path.select(PatientFamilyHistorys3Path.columns.map(c => col(c).as(PatientFamilyHistory_lookup.getOrElse(c,c))): _*)
    PatientFamilyHistoryFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientFamilyHistory/")
    println("PatientFamilyHistory done")

    val PatientLanguages3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientLanguage/750b0376-496d-4f3e-a061-5ea7f630b343_8[d-f]*",spark)
    val PatientLanguage_lookup= commonFunctions.getlookupMap("PatientLanguage",section_headers)
    val PatientLanguageFileWithHeaders = PatientLanguages3Path.select(PatientLanguages3Path.columns.map(c => col(c).as(PatientLanguage_lookup.getOrElse(c,c))): _*)
    PatientLanguageFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientLanguage/")
    println("PatientLanguage done")

    val PatientMedicationss3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientMedications/e9746c91-6a44-4b65-b398-06706d075422_8[d-f]*",spark)
    val PatientMedications_lookup= commonFunctions.getlookupMap("PatientMedications",section_headers)
    val PatientMedicationsFileWithHeaders = PatientMedicationss3Path.select(PatientMedicationss3Path.columns.map(c => col(c).as(PatientMedications_lookup.getOrElse(c,c))): _*)
    PatientMedicationsFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientMedications/")
    println("PatientMedications done")

    val PatientNotess3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientNotes/129e36f5-51dd-412c-8a83-15f50cc6563e_8[d-f]*",spark)
    val PatientNote_lookup= commonFunctions.getlookupMap("PatientNote",section_headers)
    val PatientNotesFileWithHeaders = PatientNotess3Path.select(PatientNotess3Path.columns.map(c => col(c).as(PatientNote_lookup.getOrElse(c,c))): _*)
    PatientNotesFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientNotes/")
    println("PatientNote done")

    val PatientPayers3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientPayer/a70ed65f-6cca-4808-82b4-fb2bcc5e737a_8[d-f]*",spark)
    val PatientInsurance_lookup= commonFunctions.getlookupMap("PatientInsurance",section_headers)
    val PatientPayerFileWithHeaders = PatientPayers3Path.select(PatientPayers3Path.columns.map(c => col(c).as(PatientInsurance_lookup.getOrElse(c,c))): _*)
    PatientPayerFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientInsurance/")
    println("PatientInsurance done")


    val PatientProblems3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientProblem/c02a8880-be91-4479-add2-02fe91f48db0_8[d-f]*",spark)
    val PatientProblem_lookup= commonFunctions.getlookupMap("PatientProblem",section_headers)
    val PatientProblemFileWithHeaders = PatientProblems3Path.select(PatientProblems3Path.columns.map(c => col(c).as(PatientProblem_lookup.getOrElse(c,c))): _*)
    PatientProblemFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientProblem/")
    println("PatientProblem done")

    val PatientProceduress3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientProcedures/41318672-877d-4c04-b2cb-61cd7db55864_8[d-f]*",spark)
    val PatientProcedure_lookup= commonFunctions.getlookupMap("PatientProcedure",section_headers)
    val PatientProceduresFileWithHeaders = PatientProceduress3Path.select(PatientProceduress3Path.columns.map(c => col(c).as(PatientProcedure_lookup.getOrElse(c,c))): _*)
    PatientProceduresFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientProcedures/")
    println("PatientProcedure done")

    val PatientRaces3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientRace/52ddf45c-6d51-418f-be58-eb8ce57fa2a1_8[d-f]*",spark)
    val PatientRace_lookup= commonFunctions.getlookupMap("PatientRace",section_headers)
    val PatientRaceFileWithHeaders = PatientRaces3Path.select(PatientRaces3Path.columns.map(c => col(c).as(PatientRace_lookup.getOrElse(c,c))): _*)
    PatientRaceFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientRace/")
    println("PatientRace done")

    val PatientResultObservations3Path= commonFunctions.readFile("s3://bd-dev/REGDATA_AAO/PatientResultObservation/f967c591-1460-4731-b6be-a620238630d2_8*",spark)
    val PatientresultObservation_lookup= commonFunctions.getlookupMap("PatientresultObservation",section_headers)
    val PatientResultObservationFileWithHeaders = PatientResultObservations3Path.select(PatientResultObservations3Path.columns.map(c => col(c).as(PatientresultObservation_lookup.getOrElse(c,c))): _*)
    PatientResultObservationFileWithHeaders.repartition(200).write.mode(saveMode = "overwrite").option("header","true").parquet("s3://bd-dev/REGDATA_AAO_PAR_11/PatientResultObservation/")
    println("PatientresultObservation done")


  }

}
