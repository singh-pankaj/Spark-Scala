package com.figmd.readwrite

//import com.figmd.ReadWrite.ApplicationConfig
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{ltrim, rtrim}
import org.apache.spark.sql.functions.col

import scala.collection.Map
import scala.collection.immutable.ListMap

object commonFunctions {
  def readFile(path : String,sparkSess : SparkSession) : DataFrame ={
    val file = sparkSess.read.option("delimiter", "\u0017").option("inferSchema", "true")
      .csv(path)

    file
  }

  def getlookupMap(tableName: String,section_header : DataFrame):Map[String,String]={

    //val ListTables = ReadTables.readtablesFromPostgres(spark)


    val invMap = section_header.filter(ltrim(rtrim(col("sectionname"))) === tableName).rdd
      .map(row => "_c" + row.getInt(2).toString -> row.getString(1).trim).collectAsMap()

    ListMap(invMap.toSeq.sortBy(_._1):_*)

  }

  def getPostgresTable(spark:SparkSession,tableName:String): DataFrame ={
/*    spark.read
      .format("jdbc")
      .option("url", "jdbc:postgresql://"+ApplicationConfig.prop.getProperty("postgresHostName")+":"+ApplicationConfig.prop.getProperty("postgresHostPort")+"/"+ApplicationConfig.prop.getProperty("postgresManagementDatabaseName"))
      .option("dbtable", tableName)
      .option("user", ApplicationConfig.prop.getProperty("postgresHostUserName"))
      .option("password", ApplicationConfig.prop.getProperty("postgresUserPass"))
      .load()*/

        spark.read
          .format("jdbc")
          .option("url", "jdbc:postgresql://10.20.201.36:5432/figmdhqimanagementaao")
          .option("dbtable", "section_headers")
          //.option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
          .option("user", "postgres")
          .option("password", "Janus@123")
          .load()

  }



}
