package com.figmd.janus.dataMart

class DataMart {
/*
  def createDataMart() : Unit =
    {

    }


  def getMasterVisit() : Unit =
   {

   }


   def getEthinicity() : Unit
  {

  }

*/



}
