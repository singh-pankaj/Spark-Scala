package com.figmd.janus.measureComputation.nonQppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.util._
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEPQI02_1 extends MeasureUtility with MeasureTrait{

  var MEASURE_NAME="MQI02_1"
  @transient lazy val postgresUtility=new PostgreUtility()

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {

    try {

      var columnRef = getFiledList(MEASURE_NAME)
      var rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0),columnRef(1),columnRef(2),columnRef(3),columnRef(4),columnRef(5),columnRef(6),columnRef(7),columnRef(8),columnRef(9),columnRef(10),columnRef(11),columnRef(12),columnRef(13),columnRef(14),columnRef(15),columnRef(16),columnRef(17),columnRef(18),columnRef(19),columnRef(20),columnRef(21),columnRef(22),columnRef(23),columnRef(24),columnRef(25),columnRef(26),columnRef(27),columnRef(28),columnRef(29),columnRef(30),columnRef(31),columnRef(32),columnRef(33),columnRef(34),columnRef(35),columnRef(36),columnRef(37),columnRef(38),columnRef(39),columnRef(40),columnRef(41),columnRef(42),columnRef(43),columnRef(44),columnRef(45),columnRef(46),columnRef(47),columnRef(48),columnRef(49),columnRef(50),columnRef(51),columnRef(52),columnRef(53),columnRef(54))

      val dateUtility = new DateUtility();

      var sparkObj = new SparkUtility()
      val initialrdd =sparkObj.filterPracticeIdFromInitialRDD(sparkSession, rdd)
         // Filter IPP
      var ippRDD = initialrdd
      .filter(r =>
           chkDateRangeExist(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate)  &&
          (
           (chkDateYearDiffGreaterOrEqual(r,IPP,MEASURE_NAME,"dob","encounterdate",18)
             && chkDateYearDiffLess(r,IPP,MEASURE_NAME,"dob","encounterdate",51))
             && (checkElementPresent(r, IPP, MEASURE_NAME, "edv")
             || checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem"))

              &&
             (checkElementPresent(r,IPP,MEASURE_NAME,"flnkpain")
               &&
             (chkDateRangeBetween(r,IPP,MEASURE_NAME,"flnkpain_date","ed_visit_arrival_date","ed_visit_departure_date")
                  ||
               chkDateEqual(r,IPP,MEASURE_NAME,"flnkpain_date","crtclcrem_date"))
             )
              &&
             (checkElementPresent(r,IPP,MEASURE_NAME,"kidneystone")
             &&
               (
                 chkDateRangeBetween(r,IPP,MEASURE_NAME,"kidneystone_date","ed_visit_arrival_date","ed_visit_departure_date")
                 ||
                   chkDateEqual(r,IPP,MEASURE_NAME,"kidneystone_date","crtclcrem_date"))
               )
            ))

      ippRDD.cache();


      val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val CRA = getBackTrackingList(rdd, ippRDD, "urolgysurg", "urolgysurg_date","flnkpain","flnkpain_date");

      val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)

      var Overlap_Rdd = rdd

      Overlap_Rdd.cache()



      val exclusionRDD = ippRDD.filter(r=>
        (
          (checkElementValueDoubleGreater(r, EXCLUSION, MEASURE_NAME, "creatnine",1.5)
            &&
            (
              chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "creatnine_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                ||
                chkDateEqual(r, EXCLUSION, MEASURE_NAME, "creatnine_date", "crtclcrem_date")
              ))
            ||
            (chkValueRangeLess(r, EXCLUSION, MEASURE_NAME, "glomfiltrate",60)
              &&
              (
                chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "glomfiltrate_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  chkDateEqual(r, EXCLUSION, MEASURE_NAME, "glomfiltrate_date", "crtclcrem_date")
                )
              )
            ||
            (checkElementValueDoubleGreaterOrEqual(r, EXCLUSION, MEASURE_NAME, "bodytemp",37.5)
              &&
              (
                chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "bodytemp_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  chkDateEqual(r, EXCLUSION, MEASURE_NAME, "bodytemp_date", "crtclcrem_date")
                ))
            ||
            (chkValueRangeGreater(r, EXCLUSION, MEASURE_NAME, "leukurine",11000)
              &&
              (
                chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "leukurine_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  chkDateEqual(r, EXCLUSION, MEASURE_NAME, "leukurine_date", "crtclcrem_date")
                ))
          ||
          (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "nitrurine")
            &&
            (
              chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "nitrurine_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                ||
                chkDateEqual(r, EXCLUSION, MEASURE_NAME, "nitrurine_date", "crtclcrem_date")
              )
              && checkElementPresent(r,EXCLUSION,MEASURE_NAME,"positive")
             )

          ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "leukesturn")
              &&
              (
                chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "leukesturn_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  chkDateEqual(r, EXCLUSION, MEASURE_NAME, "leukesturn_date", "crtclcrem_date")
                )
              && checkElementPresent(r,EXCLUSION,MEASURE_NAME,"positive"))
            ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "uncntrpain")
              &&
              (
                chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "uncntrpain_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  chkDateEqual(r, EXCLUSION, MEASURE_NAME, "uncntrpain_date", "crtclcrem_date")
                )
              )
            ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "alca")
              && chkDateRangeLessOrEqual(r, EXCLUSION, MEASURE_NAME, "alca_date", "ed_visit_departure_date")
                )
            ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "anticoag")
              && chkDateRangeLessOrEqual(r, EXCLUSION, MEASURE_NAME, "anticoag_date", "ed_visit_departure_date")
              )
            ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "kidcon")
              && chkDateRangeLessOrEqual(r, EXCLUSION, MEASURE_NAME, "kidcon_date", "ed_visit_departure_date")
              )
            ||
            ( checkElementValue(r,EXCLUSION,MEASURE_NAME,"sex",2)
              && checkElementPresent(r,EXCLUSION,MEASURE_NAME,"preg")
              && chkDateEqual(r,EXCLUSION,MEASURE_NAME,"preg_date","encounterdate")
              )
            ||
            (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "trau")
              && chkDateRangeLessOrEqual(r, EXCLUSION, MEASURE_NAME, "trau_date", "ed_visit_departure_date")
              )
          ||
            (checkElementPresent(r,EXCLUSION,MEASURE_NAME,"kitr")
              &&
              (chkDateRangeLessOrEqual(r,EXCLUSION,MEASURE_NAME,"kitr_date","ed_visit_arrival_date")
                ||
                chkDateRangeLessOrEqual(r,EXCLUSION,MEASURE_NAME,"kitr_date","crtclcrem_date")
                ))
          ||

            BackTracking48(r, EXCLUSION, MEASURE_NAME, CRA_list)

          ||
            BackTracking72(r, EXCLUSION, MEASURE_NAME, CRA_list)

          )
      )
      exclusionRDD.cache()


      val intermediateRDD = ippRDD.subtract(exclusionRDD)
      intermediateRDD.cache();

    // Filter Met
      var metRDD = intermediateRDD.filter(r =>
        checknull(r,MET,MEASURE_NAME,"ct_abd_pel")
          &&
         checknull(r,MET,MEASURE_NAME,"kub_xray_ap")
           &&
          checknull(r,MET,MEASURE_NAME,"ultra_apf")
           &&
          checknull(r,MET,MEASURE_NAME,"mri_apf")
      )
      metRDD.cache()

      val intermediateBRDD = intermediateRDD.subtract(metRDD)

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      exceptionRDD.cache()

      var notMetRDD = getNotMet(intermediateBRDD, exceptionRDD)

      if (DataMartCreator.debugMode == 1) {
        println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notEligibleRDD          ***" + notEligibleRDD.count())
        println("ACEP " + MEASURE_NAME + " *** exclusionRDD          ***" + exclusionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** exceptionRDD ***" + exceptionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** metRDD       ***" + metRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notMetRDD    ***" + notMetRDD.count())
        println("*********************************************************")
      }
      else
      { saveToWebDM(notEligibleRDD,exclusionRDD,metRDD, exceptionRDD, notMetRDD, MEASURE_NAME) }

      ippRDD.unpersist(true);
      metRDD.unpersist(true);
      notMetRDD.unpersist(true);
      exceptionRDD.unpersist(true);
      notEligibleRDD.unpersist(true);
      exclusionRDD.unpersist(true);

    postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"","","Measure computation done successfully","PASS")
  }
  catch {
    case e:Exception=>{
      postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"W0001","CRITICAL",Throwables.getStackTraceAsString(e),"FAIL")
      println(e.printStackTrace())
      System.exit(-1)

    }
  }

}

  def BackTracking48(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {

    for (x <- CRA.value) {
      if (x != "") {
        val back_data = x.split("~")
        val patientid = back_data(0);
        val element = back_data(1);
        val element_date = dateUtility.dateTimeParse(back_data(2));

        if (
          element == "1"
            &&
            (
              (
                !r.isNullAt("ed_visit_arrival_date") &&
                  (
                    r.getDateTime("ed_visit_arrival_date").equals(element_date)
                      ||
                      r.getDateTime("ed_visit_arrival_date").minusHours(48).equals(element_date)
                      ||
                      (
                        element_date.isBefore(r.getDateTime("ed_visit_arrival_date"))
                          &&
                          element_date.isAfter(r.getDateTime("ed_visit_arrival_date").minusHours(48))

                        )
                    )
                )
                ||
                (
                  !r.isNullAt("crtclcrem_date") &&
                    (
                      r.getDateTime("crtclcrem_date").equals(element_date)
                        ||
                        r.getDateTime("crtclcrem_date").minusHours(48).equals(element_date)
                        ||
                        (
                          element_date.isBefore(r.getDateTime("crtclcrem_date"))
                            &&
                            element_date.isAfter(r.getDateTime("crtclcrem_date").minusHours(48))

                          )
                      )
                  )
              )
        )
        {
          return true;
        }
      }

    }

    return false

  }

  def BackTracking72(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {


    for (x <- CRA.value) {
      if (x != "") {
        val back_data = x.split("~")
        val patientid = back_data(0);
        val element = back_data(3);
        val element_date = dateUtility.dateTimeParse(back_data(4));

        if (
          element == "1"
            &&
            (
              (
                !r.isNullAt("ed_visit_arrival_date") &&
                  (
                    r.getDateTime("ed_visit_arrival_date").equals(element_date)
                      ||
                      r.getDateTime("ed_visit_arrival_date").minusHours(72).equals(element_date)
                      ||
                      (
                        element_date.isBefore(r.getDateTime("ed_visit_arrival_date"))
                          &&
                          element_date.isAfter(r.getDateTime("ed_visit_arrival_date").minusHours(72))

                        )
                    )
                )
                ||
                (
                  !r.isNullAt("crtclcrem_date") &&
                    (
                      r.getDateTime("crtclcrem_date").equals(element_date)
                        ||
                        r.getDateTime("crtclcrem_date").minusHours(72).equals(element_date)
                        ||
                        (
                          element_date.isBefore(r.getDateTime("crtclcrem_date"))
                            &&
                            element_date.isAfter(r.getDateTime("crtclcrem_date").minusHours(72))

                          )
                      )
                  )
              )
        )
        {
          return true;
        }
      }

    }

    return false

  }


  def getBackTrackingList(rdd: CassandraTableScanRDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement_date1: String,backtrackelement2: String, backtrackelement_date2: String): List[String] = {

    val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).distinct().collect().toList

    val IPPFilterExclusionRDD = rdd.filter(x => (ipp_patient_list.contains(x.columnValues(2))))

    var CRA = IPPFilterExclusionRDD.map(x =>
      if (!x.isNullAt("patientuid")
        && !x.isNullAt(backtrackelement1) && (!x.isNullAt(backtrackelement_date1)) && !x.isNullAt(backtrackelement2) && !x.isNullAt(backtrackelement_date2)) {
        x.getString("patientuid") + "~" + x.getString(backtrackelement1) + "~" + x.getString(backtrackelement_date2) + "~" + x.getString(backtrackelement2) + "~" + x.getString(backtrackelement_date2)
      }
      else ""
    )
      .collect()
      .toList

    return CRA;
  }



}
