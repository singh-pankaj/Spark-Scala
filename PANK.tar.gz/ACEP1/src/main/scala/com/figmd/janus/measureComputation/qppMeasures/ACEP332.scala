package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.measureComputation.qppMeasures.ACEP255.{IPP, MEASURE_NAME, chkDateYearDiffGreaterOrEqual}
import com.figmd.janus.measureComputation.qppMeasures.ACEP331.{MEASURE_NAME, MET, chkDateRangeExist, saveToWebDM}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession

object ACEP332 extends MeasureUtility with MeasureTrait {

  var MEASURE_NAME = "M332"
  @transient lazy val postgresUtility=new PostgreUtility()
  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {

    try {
      val columnRef = getFiledList(MEASURE_NAME)
      val rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0), columnRef(1), columnRef(2), columnRef(3), columnRef(4), columnRef(5), columnRef(6), columnRef(7), columnRef(8), columnRef(9), columnRef(10), columnRef(11), columnRef(12), columnRef(13), columnRef(14), columnRef(15), columnRef(16), columnRef(17), columnRef(18), columnRef(19), columnRef(20), columnRef(21), columnRef(22), columnRef(23), columnRef(24), columnRef(25), columnRef(26), columnRef(27), columnRef(28), columnRef(29), columnRef(30), columnRef(31), columnRef(32), columnRef(33), columnRef(34), columnRef(35), columnRef(36), columnRef(37), columnRef(38), columnRef(39), columnRef(40), columnRef(41), columnRef(42), columnRef(43), columnRef(44), columnRef(45), columnRef(46), columnRef(47), columnRef(48), columnRef(49), columnRef(50), columnRef(51), columnRef(52), columnRef(53), columnRef(54), columnRef(55),columnRef(56), columnRef(57),columnRef(58), columnRef(59), columnRef(60), columnRef(61))
        .where(s"encounterdate>=? and encounterdate<=? "+prop.getProperty("practiceListCondition"),startDate, endDate)


      val dateUtility = new DateUtility()

      // Filter IPP
      val ippRDD = rdd
        .filter(r =>
            (
                chkDateYearDiffGreaterOrEqual(r,IPP,MEASURE_NAME,"dob","encounterdate",18)
                &&
                (
                    checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1") ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "nufavi") ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "caseinlorefa") ||
                    checkElementPresent(r, IPP, MEASURE_NAME, "hohese")
                )
                &&
                (
                  (

                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "actsnts_copy_867") &&
                        chkDateEqual(r, IPP, MEASURE_NAME, "actsnts_copy_867_date", "encounterdate")
                      )
                      &&
                      (
                        checkElementPresent(r, IPP, MEASURE_NAME, "bactsinusitis") &&
                          chkDateEqual(r, IPP, MEASURE_NAME, "bactsinusitis_date", "encounterdate")
                        )

                      &&
                      (
                        checkElementPresent(r, IPP, MEASURE_NAME, "antbtcrgmn1") &&
                        chkDateRangeExist(r, MET, MEASURE_NAME, "antbtcrgmn1_date", startDate, endDate)

                       )
                    )
                    ||
                    (
                      (
                        checkElementPresent(r, IPP, MEASURE_NAME, "actsnts_copy_867") &&
                          chkDateEqual(r, IPP, MEASURE_NAME, "actsnts_copy_867_date", "encounterdate")
                        )
                        &&
                        (
                          checkElementPresent(r, IPP, MEASURE_NAME, "acubctsin") &&
                            chkDateEqual(r, IPP, MEASURE_NAME, "acubctsin_date", "encounterdate")
                          )
                       && //
                          (
                          checkElementPresent(r, IPP, MEASURE_NAME, "abx_rxed1") &&
                          chkDateRangeBetweenMinusSecondsFromQuarterEndDate(r, IPP, MEASURE_NAME, "abx_rxed1_date", startDate, endDate,1)
                           )

                      )
                  )
                &&
                  (
                checknull(r, IPP, MEASURE_NAME, "eddeptvist_tm") ||
                checknull(r, IPP, MEASURE_NAME, "ov_thmdmod95") ||
                checknull(r, IPP, MEASURE_NAME, "hmhlthsrvc_tm") ||
                checknull(r, IPP, MEASURE_NAME, "nrsnfcltvst_tm") ||
                checknull(r, IPP, MEASURE_NAME, "csltrf_tm")
                  )
                 &&(
                  checknull(r, IPP, MEASURE_NAME, "telehealth")
                )



              )

        )

      ippRDD.cache()

      //met

      val metRDD = ippRDD.filter(r => (
        checkElementPresent(r, MET, MEASURE_NAME, "amoxwwo1") &&
          chkDateEqual(r, MET, MEASURE_NAME, "amoxwwo1_date", "encounterdate")
          ||
          (
            checkElementPresent(r, MET, MEASURE_NAME, "amoclau20") &&
              chkDateEqual(r, MET, MEASURE_NAME, "amoclau20_date", "encounterdate")
            )
        )
      )

      metRDD.cache()

      //ExceptionSourceCode

      var intermediateRDD = getinterRDD(ippRDD, metRDD).cache()


      val exceptionRDD = intermediateRDD.filter(r => (
         (
          checkElementPresent(r, MET, MEASURE_NAME, "amx4_mdrsn") &&
          chkDateEqual(r, EXCEPTION, MEASURE_NAME,"amx4_mdrsn_date","encounterdate")
        )
         ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "amclv23") &&
          chkDateEqual(r, EXCEPTION, MEASURE_NAME, "amclv23_date", "encounterdate")
        )||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "chrsnsts") &&
            chkDateEqual(r, EXCEPTION, MEASURE_NAME, "chrsnsts_date", "encounterdate")
          )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "cysfibrosis") &&
              chkDateEqual(r, EXCEPTION, MEASURE_NAME, "cysfibrosis_date", "encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "immndefcncy") &&
              chkDateEqual(r, EXCEPTION, MEASURE_NAME, "immndefcncy_date", "encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "clrydys") &&
              chkDateEqual(r, EXCEPTION, MEASURE_NAME, "clrydys_date", "encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "dvnslsptm") &&
              chkDateEqual(r, EXCEPTION, MEASURE_NAME, "dvnslsptm_date", "encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "recsnsts") &&
              chkDateEqual(r, EXCEPTION, MEASURE_NAME, "recsnsts_date", "encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "prsnrsmicorg") &&
              chkDateEqual(r, EXCEPTION, MEASURE_NAME, "prsnrsmicorg_date", "encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "immciliadis") &&
              chkDateEqual(r, EXCEPTION, MEASURE_NAME, "immciliadis_date", "encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "snssurg") &&
              chkDateEqual(r, EXCEPTION, MEASURE_NAME, "snssurg_date", "encounterdate")
            )
          ||
          (
            checkElementPresent(r, EXCEPTION, MEASURE_NAME, "alrgmed") &&
              chkDateEqual(r, EXCEPTION, MEASURE_NAME, "alrgmed_date", "encounterdate")
            )
          ))
      exceptionRDD.cache()

      var notMetRDD = getNotMet(intermediateRDD, exceptionRDD)


      val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      if (DataMartCreator.debugMode == 1) {
        println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notEligibleRDD          ***" + notEligibleRDD.count())
        println("ACEP " + MEASURE_NAME + " *** exclusionRDD          ***" + exclusionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** exceptionRDD ***" + exceptionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** metRDD       ***" + metRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notMetRDD    ***" + notMetRDD.count())
        println("*********************************************************")
      }    else
      { saveToWebDM(notEligibleRDD,exclusionRDD,metRDD, exceptionRDD, notMetRDD, MEASURE_NAME) }

      ippRDD.unpersist(true);
      metRDD.unpersist(true);
      notMetRDD.unpersist(true);
      exceptionRDD.unpersist(true);
      notEligibleRDD.unpersist(true);
      exclusionRDD.unpersist(true);

      postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "", "", "Measure computation done successfully", "PASS")
    }

    catch {
      case e: Exception => {
        println(e.printStackTrace())
        postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "W0001", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
        System.exit(-1)

      }
    }

  }
}
