package com.figmd.janus.measureComputation.nonQppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.util._
import com.figmd.janus.DataMartCreator.prop
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEPQI01 extends MeasureUtility with MeasureTrait{

  var MEASURE_NAME= "MQI01"
  @transient lazy val postgresUtility=new PostgreUtility()


  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {

try {
  val columnRef = getFiledList(MEASURE_NAME)
  val rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0), columnRef(1), columnRef(2), columnRef(3), columnRef(4), columnRef(5), columnRef(6), columnRef(7), columnRef(8), columnRef(9), columnRef(10), columnRef(11), columnRef(12), columnRef(13), columnRef(14), columnRef(15), columnRef(16), columnRef(17), columnRef(18), columnRef(19), columnRef(20), columnRef(21), columnRef(22), columnRef(23), columnRef(24), columnRef(25), columnRef(26), columnRef(27), columnRef(28), columnRef(29), columnRef(30), columnRef(31), columnRef(32), columnRef(33), columnRef(34), columnRef(35), columnRef(36), columnRef(37), columnRef(38), columnRef(39), columnRef(40), columnRef(41), columnRef(42), columnRef(43), columnRef(44), columnRef(45), columnRef(46), columnRef(47), columnRef(48), columnRef(49), columnRef(50), columnRef(51), columnRef(52), columnRef(53), columnRef(54))
  var sparkObj = new SparkUtility()
  val initialrdd =sparkObj.filterPracticeIdFromInitialRDD(sparkSession, rdd)

  val dateUtility = new DateUtility()

  // Filter IPP
  val ippRDD = initialrdd
    .filter(r =>
      (
        chkDateRangeExist(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate)
          //          chkDateRangeExistMinusDays(r, IPP, MEASURE_NAME, "ed_visit_arrival_date", startDate, endDate,6 )
          &&
          (
            chkDateYearDiffGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "encounterdate", 18)

              &&
              (
                checkElementPresent(r, IPP, MEASURE_NAME, "edv")
                  ||
                  checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem")
                )
              &&
              (

                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "septshck")
                    &&
                    (
                      chkDateRangeBetween(r, IPP, MEASURE_NAME, "septshck_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                        ||
                        chkDateEqual(r, IPP, MEASURE_NAME, "septshck_date", "crtclcrem_date")
                      )
                  )
                  ||
                  (
                    (
                      (
                        checkElementPresent(r, IPP, MEASURE_NAME, "sepsis")
                          &&
                          (
                            chkDateRangeBetween(r, IPP, MEASURE_NAME, "sepsis_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                              ||
                              chkDateEqual(r, IPP, MEASURE_NAME, "sepsis_date", "crtclcrem_date")
                            )
                        )
                        ||
                        (
                          checkElementPresent(r, IPP, MEASURE_NAME, "infec")
                            &&
                            chkDateRangeLessOrEqual(r, IPP, MEASURE_NAME, "infec_date", "ed_visit_departure_date")
                          )
                      )
                      &&
                      (
                        checkElementPresent(r, IPP, MEASURE_NAME, "acutehypo") &&
                          (chkDateRangeBetween(r, IPP, MEASURE_NAME, "acutehypo_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                            ||
                            chkDateEqual(r, IPP, MEASURE_NAME, "acutehypo_date", "crtclcrem_date")


                            )
                        )

                    )
                )
            )
        )
    )
  ippRDD.cache()

  val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

  val CRA = getBackTrackingList(rdd, ippRDD, "acutecifacility", "acutecifacility_date");

  val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)

  var Overlap_Rdd = rdd

  Overlap_Rdd.cache()




  val exclusionRDD =ippRDD.filter(r =>
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "lftbeftrtmcom")
            &&
            (
              chkDateRangeBetween(r,EXCLUSION,MEASURE_NAME,"lftbeftrtmcom_date","ed_visit_arrival_date","ed_visit_departure_date")
                ||

                chkDateEqual(r,EXCLUSION,MEASURE_NAME,"lftbeftrtmcom_date","crtclcrem_date")

              )
          )

        ||
//   death_ind, death_date Element no present in the Data Dictionary.
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "death_ind")
            &&
            (
            chkDateRangeBetween(r,EXCLUSION,MEASURE_NAME,"death_date","ed_visit_arrival_date","ed_visit_departure_date")
              ||

              chkDateEqual(r,EXCLUSION,MEASURE_NAME,"death_date","crtclcrem_date")
            )
          )

        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "come")
            &&
            (chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "come_date", "ed_visit_arrival_date", "ed_visit_departure_date")
              ||
              chkDateEqual(r,EXCLUSION,MEASURE_NAME,"come_date","crtclcrem_date")
              )
          )
        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "decsepcare") &&
            ( chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "decsepcare_date", "ed_visit_arrival_date", "ed_visit_departure_date")
              ||
              chkDateEqual(r,EXCLUSION,MEASURE_NAME,"decsepcare_date","crtclcrem_date")
              )

          )
        ||
        (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "cardarrst") &&
          (chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "cardarrst_date", "ed_visit_arrival_date", "ed_visit_departure_date")
            ||
            chkDateEqual(r,EXCLUSION,MEASURE_NAME,"cardarrst_date","crtclcrem_date")

            ))
        ||
        (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "scndthrddgreeburn")
          &&
          (
            chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "scndthrddgreeburn_date", "ed_visit_arrival_date", "ed_visit_departure_date")
              ||
            chkDateEqual(r,EXCLUSION,MEASURE_NAME,"scndthrddgreeburn_date","crtclcrem_date")


            )
          )
        ||
        (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "szure")
          &&
          (
            chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "szure_date", "ed_visit_arrival_date", "ed_visit_departure_date")
            ||
            chkDateEqual(r,EXCLUSION,MEASURE_NAME,"szure_date","crtclcrem_date")

            ))

        ||
        (
          (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "acutegasthem")
          &&
          (chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "acutegasthem_date", "ed_visit_arrival_date", "ed_visit_departure_date")
            ||
            chkDateEqual(r,EXCLUSION,MEASURE_NAME,"acutegasthem_date","crtclcrem_date")
            )
            )
        ||
        ( checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hest")
          &&
          (chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "hest_date", "ed_visit_arrival_date", "ed_visit_departure_date")
            ||
           chkDateEqual(r,EXCLUSION,MEASURE_NAME,"hest_date","crtclcrem_date")

            )

          )
        ||
        (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "isst")
          &&
          (chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "isst_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||

            chkDateEqual(r,EXCLUSION,MEASURE_NAME,"isst_date","crtclcrem_date")

            )


          )
        ||
        (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "myin") &&
          (chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "myin_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||

            chkDateEqual(r,EXCLUSION,MEASURE_NAME,"myin_date","crtclcrem_date")


            ) )

        ||
        (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "toxemrg")&&
          (chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "toxemrg_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||

            chkDateEqual(r,EXCLUSION,MEASURE_NAME,"toxemrg_date","crtclcrem_date")


            ))
        ||
        (checkElementPresent(r, EXCLUSION, MEASURE_NAME, "trau") &&
          (chkDateRangeBetween(r, EXCLUSION, MEASURE_NAME, "trau_date", "ed_visit_arrival_date", "ed_visit_departure_date") ||

            chkDateEqual(r,EXCLUSION,MEASURE_NAME,"trau_date","crtclcrem_date")

            )


          )
      )

          ||

          BackTracking(r, EXCLUSION, MEASURE_NAME, CRA_list)
  )
  exclusionRDD.cache()

  val intermediateRDD = ippRDD.subtract(exclusionRDD)

  val metRDD = intermediateRDD.filter(r =>
    (
      checkElementPresent(r, MET, MEASURE_NAME, "bldcultre")
        &&
        (
          chkDateRangeBetween(r, MET, MEASURE_NAME, "bldcultre_date", "ed_visit_arrival_date", "ed_visit_departure_date")
            ||
            chkDateEqual(r, MET, MEASURE_NAME, "bldcultre_date", "crtclcrem_date")

          )
      )
  )
  metRDD.cache()

  val notMetRDD = intermediateRDD.subtract(metRDD)


  val exceptionRDD=sparkSession.sparkContext.emptyRDD[CassandraRow]
  if (DataMartCreator.debugMode == 1) {
    println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
//    println("ACEP " + MEASURE_NAME + " *** IPPRDDD         ***" + ippRDD1.count())
    println("ACEP " + MEASURE_NAME + " *** notEligibleRDD          ***" + notEligibleRDD.count())
    println("ACEP " + MEASURE_NAME + " *** exclusionRDD          ***" + exclusionRDD.count())
    println("ACEP " + MEASURE_NAME + " *** exceptionRDD ***" + exceptionRDD.count())
    println("ACEP " + MEASURE_NAME + " *** metRDD       ***" + metRDD.count())
    println("ACEP " + MEASURE_NAME + " *** notMetRDD    ***" + notMetRDD.count())
    println("*********************************************************")
  }
  else
  { saveToWebDM(notEligibleRDD,exclusionRDD,metRDD, exceptionRDD, notMetRDD, MEASURE_NAME) }

  ippRDD.unpersist(true);
  metRDD.unpersist(true);
  notMetRDD.unpersist(true);
  exceptionRDD.unpersist(true);
  notEligibleRDD.unpersist(true);
  exclusionRDD.unpersist(true);

  postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"","","Measure computation done successfully","PASS")
  }

  catch {
    case e: Exception => {
      println(e.printStackTrace())
      postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "W0001", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
      System.exit(-1)

    }
  }

  }
  def BackTracking(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {


    for (x <- CRA.value) {
      if (x != "") {
        val back_data = x.split("~")
        val patientid = back_data(0);
        val element = back_data(1);
        val element_date = dateUtility.dateTimeParse(back_data(2));

        if (
          element == "1"
            &&
            (
              (
                !r.isNullAt("ed_visit_arrival_date") &&
                  (
                    r.getDateTime("ed_visit_arrival_date").equals(element_date)
                      ||
                      r.getDateTime("ed_visit_arrival_date").minusHours(6).equals(element_date)
                      ||
                      (
                        element_date.isBefore(r.getDateTime("ed_visit_arrival_date"))
                          &&
                          element_date.isAfter(r.getDateTime("ed_visit_arrival_date").minusHours(6))

                        )
                    )
                )
                ||
                (
                  !r.isNullAt("crtclcrem_date") &&
                    (
                      r.getDateTime("crtclcrem_date").equals(element_date)
                        ||
                        r.getDateTime("crtclcrem_date").minusHours(6).equals(element_date)
                        ||
                        (
                          element_date.isBefore(r.getDateTime("crtclcrem_date"))
                            &&
                            element_date.isAfter(r.getDateTime("crtclcrem_date").minusHours(6))

                          )
                      )
                  )
              )
        )
        {
          return true;
        }
      }

    }
    return false

  }

  def getBackTrackingList(rdd: CassandraTableScanRDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement: String, backtrackelement_date: String): List[String] = {

    val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).distinct().collect().toList

    val IPPFilterExclusionRDD = rdd.filter(x => (ipp_patient_list.contains(x.columnValues(2))))

    var CRA = IPPFilterExclusionRDD.map(x =>
      if (!x.isNullAt("patientuid")
        && !x.isNullAt(backtrackelement) && !x.isNullAt(backtrackelement_date)) {
        x.getString("patientuid") + "~" + x.getString(backtrackelement) + "~" + x.getString(backtrackelement_date)
      }
      else ""
    )
      .collect()
      .toList

    return CRA;
  }

}
