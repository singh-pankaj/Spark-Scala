package com.figmd.janus.pojo

class Measure_24_Pojo {

  final var measureName ="ACEP 24_Pregnancy Test for Female Abdominal Pain Patients";
  final val ED_VISIT : Int=1;
  final val CrtclcrEM : Int=1;
  final val PulmnryEmblus : Int=1;
  final val ED_Visit_Arrival_date : String = "ED_Visit_Arrival_date"
  final val CrtclcrEM_Date : String = "CrtclcrEM_Date"
  final val Derpt_ED_Date : String = "Derpt_ED_Date"
  final val Arrvl_ED_Date : String = "Arrvl_ED_Date"
  final val PulmnryEmblus_Date : String = "PulmnryEmblus_Date"
  final val ED_Visit_Departure_date : String = "ED_Visit_Departure_date"



/*

  def ED_Visit_Arrival_date : Date;
  def ED_Visit_Arrival_date_ = (ED_Visit_Arrival_date : Date)


  def CrtclcrEM_Date : Date;
  def CrtclcrEM_Date_ = (CrtclcrEM_Date : Date)


  def Derpt_ED_Date : Date;
  def Derpt_ED_Date_ = (Derpt_ED_Date : Date)



  def Arrvl_ED_Date : Date;
  def Arrvl_ED_Date_ = (Arrvl_ED_Date : Date)


  def PulmnryEmblus_Date : Date;
  def PulmnryEmblus_Date_ = (PulmnryEmblus_Date : Date)


  def ED_Visit_Departure_date : Date;
  def ED_Visit_Departure_date_ = (ED_Visit_Departure_date : Date)

*/

}
