package com.figmd.janus.measureComputation.nonQppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession


object ACEP31 extends MeasureUtility with MeasureTrait {

  var MEASURE_NAME = "M31"
  @transient lazy val postgresUtility=new PostgreUtility()

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {

    try {
      val columnRef = getFiledList(MEASURE_NAME)
      val rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0), columnRef(1), columnRef(2), columnRef(3), columnRef(4), columnRef(5), columnRef(6), columnRef(7), columnRef(8), columnRef(9), columnRef(10), columnRef(11), columnRef(12), columnRef(13), columnRef(14), columnRef(15), columnRef(16), columnRef(17), columnRef(18), columnRef(19), columnRef(20), columnRef(21), columnRef(22), columnRef(23), columnRef(24), columnRef(25), columnRef(26), columnRef(27), columnRef(28), columnRef(29), columnRef(30), columnRef(31), columnRef(32), columnRef(33), columnRef(34), columnRef(35))
        .where(s"encounterdate>=? and encounterdate<=? "+prop.getProperty("practiceListCondition"),startDate, endDate)

      val dateUtility = new DateUtility()

      // Filter IPP
      val ippRDD = rdd

        .filter(r =>

          /*chkDateRangeExist(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&*/
             (
               chkDateYearDiffGreaterOrEqual(r,IPP,MEASURE_NAME,"dob","encounterdate",18)
            &&
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "edv") ||
                checkElementPresent(r, IPP, MEASURE_NAME, "crtclcrem")
              )
            &&
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "inserifc") &&
                (
                  chkDateRangeBetween(r, IPP, MEASURE_NAME, "inserifc_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                    ||
                  chkDateEqual(r, IPP, MEASURE_NAME, firstDate = "inserifc_date", compareDate = "crtclcrem_date")

                )

              )
            &&
            (     checkElementPresent(r, IPP, MEASURE_NAME, "hosadmobs") &&
                    (
                    chkDateRangeBetween(r, IPP, MEASURE_NAME, "hosadmobs_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                      ||
                    chkDateEqual(r, IPP, MEASURE_NAME, firstDate = "hosadmobs_date", compareDate = "crtclcrem_date")
                    )

                  )
               )
        )

      ippRDD.cache()

      val notEligibleRDD  = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //exclusion   //temp Table has been removed

      val exclusionRDD = ippRDD.filter(r =>

        checkElementPresent(r, EXCLUSION, MEASURE_NAME, "inserifc") &&
          (
            chkDateRangeLessOrEqual(r, EXCLUSION, MEASURE_NAME, "inserifc_date", "ed_visit_arrival_date")
              ||
              chkDateRangeLessOrEqual(r, EXCLUSION, MEASURE_NAME, "inserifc_date", "crtclcrem_date")

            )

          ||

          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ifc") &&
            (
              chkDateRangeLessOrEqual(r, EXCLUSION, MEASURE_NAME, "ifc_date", "ed_visit_arrival_date")
                ||
                chkDateRangeLessOrEqual(r, EXCLUSION, MEASURE_NAME, "ifc_date", "crtclcrem_date")
              )

      )

      exclusionRDD.cache()


      var intermediateRDD =ippRDD.subtract(exclusionRDD)


      val metRDD = intermediateRDD.filter(r => (
        (
          checkElementPresent(r, MET, MEASURE_NAME, "uriret_obst") &&
            (
              chkDateRangeBetween(r, MET, MEASURE_NAME, "uriret_obst_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                ||
              chkDateEqual(r, MET, MEASURE_NAME, firstDate = "uriret_obst_date", compareDate = "crtclcrem_date")

              )

          )
          ||
          (
            checkElementPresent(r, MET, MEASURE_NAME, "measuriout") &&
              (
                 chkDateRangeBetween(r, MET, MEASURE_NAME, "measuriout_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  chkDateEqual(r, MET, MEASURE_NAME, firstDate = "measuriout_date", compareDate = "crtclcrem_date")

                )

            )
          ||
          (
            checkElementPresent(r, MET, MEASURE_NAME, "preusessp") &&
              (
                chkDateRangeBetween(r, MET, MEASURE_NAME, "preusessp_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  chkDateEqual(r, MET, MEASURE_NAME, firstDate = "preusessp_date", compareDate = "crtclcrem_date")

                )

            )
          ||
          (
            checkElementPresent(r, MET, MEASURE_NAME, "opnsacperi_wounds")
              &&
              (
                chkDateRangeBetween(r, MET, MEASURE_NAME, "opnsacperi_wounds_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  chkDateEqual(r, MET, MEASURE_NAME, firstDate = "opnsacperi_wounds_date", compareDate = "crtclcrem_date")

                )

            )
          ||

          (
            checkElementPresent(r, MET, MEASURE_NAME, "immob")
              &&
              (
                chkDateRangeBetween(r, MET, MEASURE_NAME, "immob_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  chkDateEqual(r, MET, MEASURE_NAME, firstDate = "immob_date", compareDate = "crtclcrem_date")

                )

            )
          ||
          (
            checkElementPresent(r, MET, MEASURE_NAME, "comfrtm") &&
              (
                chkDateRangeBetween(r, MET, MEASURE_NAME, "comfrtm_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  chkDateEqual(r, MET, MEASURE_NAME, firstDate = "comfrtm_date", compareDate = "crtclcrem_date")

                )

            )
          ||
          (
            checkElementPresent(r, MET, MEASURE_NAME, "insspeind") &&
              (
                chkDateRangeBetween(r, MET, MEASURE_NAME, "insspeind_date", "ed_visit_arrival_date", "ed_visit_departure_date")
                  ||
                  chkDateEqual(r, MET, MEASURE_NAME, firstDate = "insspeind_date", compareDate = "crtclcrem_date")

                )
            )
        )
      )

      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      var notMetRDD = getNotMet(intermediateRDD, metRDD)

      //val notMetRDD = intermediateRDD.subtract(metRDD)

      if (DataMartCreator.debugMode == 1) {
        println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notEligibleRDD          ***" + notEligibleRDD.count())
        println("ACEP " + MEASURE_NAME + " *** exclusionRDD          ***" + exclusionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** exceptionRDD ***" + exceptionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** metRDD       ***" + metRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notMetRDD    ***" + notMetRDD.count())
        println("*********************************************************")
      }
      else
      { saveToWebDM(notEligibleRDD,exclusionRDD,metRDD, exceptionRDD, notMetRDD, MEASURE_NAME) }

      ippRDD.unpersist(true);
      metRDD.unpersist(true);
      notMetRDD.unpersist(true);
      exceptionRDD.unpersist(true);
      notEligibleRDD.unpersist(true);
      exclusionRDD.unpersist(true);

      postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"","","Measure computation done successfully","PASS")
    }
    catch {
      case e: Exception => {
        postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"W0001","CRITICAL",Throwables.getStackTraceAsString(e),"FAIL")
        println(e.printStackTrace())
        System.exit(-1)

      }
    }

  }
}