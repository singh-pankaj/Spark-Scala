package com.figmd.janus

import java.util.Date

import org.apache.spark.sql.SparkSession

trait MeasureTrait {
  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit
}