package com.figmd.janus.util

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.{Date, Properties}

import com.figmd.janus.DataMartCreator.{prop}
import com.datastax.spark.connector.{CassandraRow, _}
import org.apache.hadoop.fs.FileSystem
import org.apache.log4j._
import org.apache.spark.rdd.RDD
import com.figmd.janus.DataMartCreator
import org.apache.log4j.spi.LoggerFactory
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession

import scala.reflect.io.File


class MeasureUtility extends Serializable {


  @transient lazy val dateUtility = new DateUtility();
  @transient lazy val fileUtility = new FileUtility();
  @transient lazy val sparkUtility=new SparkUtility()
  @transient lazy val hdfsConf= FileSystem.get(sparkUtility.getSparkContext().sparkContext.hadoopConfiguration)
  @transient lazy val postgresUtilityObj = new PostgreUtility()
  @transient lazy val wfType=prop.getProperty("wfType")

//  var lfile =new String().concat(fileUtility.getProperty("file.output.path.log")).concat(randNum.toString)
//
//  val sb: StringBuilder = new StringBuilder
//  sb.append(fileUtility.getProperty("file.output.path.log"))
//  sb.append(randNum.toString)


  //var keyspace = fileUtility.getProperty("cassandra.keyspace.name");


  @transient lazy val DATE_TIME_FORMAT_EEE = DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")
  @transient lazy val DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy")
  var dateFormat = "yyyy-MM-dd"
  var logFile = prop.getProperty("measure_computation_output_path");
  final var IPP= "IPP"
  final var MET= "MET"
  final var EXCEPTION= "EXCEPTION"
  final var EXCLUSION= "EXCLUSION"
  final var ELIGIBLE= "ELIGIBLE"
  var message="";


  var str =  dateUtility.now + "~" + "1" + "~"


//    var logfilename =""
    lazy val logfilename=s"/tmp/ACEP/logger" //fileUtility.getPropertyLog()

//    println(randNum+"::::::::::::wfType:::::::::GANESH::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"+logfilename)

    //fileUtility.getProperty("file.output.path.log")
    //println("GANESH::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"+logfilename)
    lazy val propobj: Properties = new Properties()
    //p.setProperty("log4j.rootLogger","OFF")
    propobj.setProperty("log4j.rootLogger","WARN,file")
    //p.setProperty("log4j.logger.figmd","INFO,stdout,file")
    propobj.setProperty("log4j.appender.file","org.apache.log4j.FileAppender")//.FileAppender
    propobj.setProperty("log4j.additivity.file","false")
    //propobj.setProperty("log4j.rootCategory","WARN,file")
    //p.setProperty("log4j.appender.file.File","${spark.yarn.app.container.log.dir}/aceplogger.log")
    propobj.setProperty("log4j.appender.file.File",logfilename)
    propobj.setProperty("log4j.appender.file.ImmediateFlush","true")
    propobj.setProperty("log4j.appender.file.Threshold","WARN")
    propobj.setProperty("log4j.appender.file.Append","false")
    propobj.setProperty("log4j.appender.file.layout","org.apache.log4j.PatternLayout")
    propobj.setProperty("log4j.appender.file.layout.ConversionPattern","%m%n")

    //  p.setProperty("log4j.appender.file.filter.a","org.apache.log4j.varia.LevelMatchFilter")
    //  p.setProperty("log4j.appender.file.filter.a.StringToMatch","WARN")
    //  p.setProperty("log4j.appender.file.filter.a.AcceptOnMatch","false")
    //  p.setProperty("log4j.appender.file.filter.a","org.apache.log4j.varia.StringMatchFilter")
    //  p.setProperty("log4j.appender.file.filter.a.StringToMatch","Found")
    //  p.setProperty("log4j.appender.file.filter.a.AcceptOnMatch","true")

    //p.setProperty("log4j.appender.file.filter","org.apache.log4j.varia.DenyAllFilter")

    //  p.setProperty("log4j.appender.stdout","org.apache.log4j.ConsoleAppender")
    //  p.setProperty("log4j.appender.stdout.Threshold","INFO")
    //  p.setProperty("log4j.appender.stdout.layout","org.apache.log4j.PatternLayout")
    //  p.setProperty("log4j.appender.stdout.layout.ConversionPattern"," %-4r [%t] %-5p %c %x - %m%n")
    PropertyConfigurator.configure(propobj)

    //  log4j.appender.rolling.file=${spark.yarn.app.container.log.dir}/spark.log
    @transient lazy val loggerObj:Logger = Logger.getLogger(this.getClass.getName)


  def convertDateToDDMMYYYY(dateString:String): String ={
    //println("::::::::::::::::::::::::::::::::"+dateString)
    return LocalDateTime.parse(dateString, DATE_TIME_FORMAT_EEE).format(DATE_FORMAT)
  }

  //Function for chkDateYearDiffGreaterOrEqualAndLessThan
  def chkDateYearDiffGreaterOrEqualAndLessThan(r: CassandraRow, conditionType: String, measureName: String, startDate: String, endDate: String, compareYears1: Double,compareYears2: Double): Boolean = {
    var eDate=""
    if (!r.isNullAt(endDate)){ eDate= convertDateToDDMMYYYY(r.getDate(endDate).toString)}else{eDate= endDate}
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}

    val isExist = !r.isNullAt(startDate) && !r.isNullAt(endDate) && ((dateUtility.getAge(r.getString(startDate),r.getString(endDate)) > compareYears1 &&
      dateUtility.getAge(r.getString(startDate),r.getString(endDate)) < compareYears2) || dateUtility.getAge(r.getString(startDate),r.getString(endDate)) == compareYears1)
    if (isExist)
      message = sDate + " and " + eDate + " year difference is greater than or equal to (" + compareYears1 + ") and less than (" + compareYears2 + ") "
    else
      message = sDate + " and " + eDate + " year difference is not greater than or equal to (" + compareYears1 + ") and less than (" + compareYears2 + ") "
    measureLogger(r, measureName, conditionType, "chkDateYearDiffGreaterOrEqualAndLessThan", startDate, isExist, message)
    return isExist;
  }

  // check element equal to 1    e.g.= chstpn=1
  def checkElementPresent(r: CassandraRow, conditionType: String, measureName: String, elementName: String): Boolean = {
    val isExist = !r.isNullAt(elementName) && r.getString(elementName).equalsIgnoreCase("1")
    if (isExist)
      message = elementName + " Found"
    else
      message = elementName + " not Found"
    measureLogger(r, measureName, conditionType, "checkElementPresent", elementName, isExist,  message)
    return isExist;
  }

  //check element integer value e.g. chstpn=1
  def checkElementValue(r: CassandraRow, conditionType: String, measureName: String, elementName: String,value:Int): Boolean = {
    val isExist = !r.isNullAt(elementName) && r.getInt(elementName)==value
    if (isExist)
      message = elementName + " equals to "+value
    else
      message = elementName + " not equals to "+value
    measureLogger(r, measureName, conditionType, "checkElementValue", elementName, isExist,  message)
    return isExist;
  }

  def chkDateYearDiffGreaterOrEqual(r: CassandraRow, conditionType: String, measureName: String, startDate: String, endDate: String, compareYears: Double): Boolean = {
    var eDate=""
    if (!r.isNullAt(endDate)){ eDate= convertDateToDDMMYYYY(r.getDate(endDate).toString)}else{eDate= endDate}
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}

    val isExist = !r.isNullAt(startDate) && !r.isNullAt(endDate) && dateUtility.getAge(r.getString(startDate),r.getString(endDate)) >= compareYears
    if (isExist)
      message = sDate + " and " + eDate + " difference is greater than or equal to (" + compareYears + ") "
    else
      message = sDate + " and " + eDate + " difference is greater not than equal to (" + compareYears + ") "
    measureLogger(r, measureName, conditionType, "chkDateYearDiffGreaterOrEqual", startDate, isExist, message)
    return isExist;
  }

  def chkDateYearDiffLess(r: CassandraRow, conditionType: String, measureName: String, startDate: String, endDate: String, compareYears: Double): Boolean = {
    var eDate=""
    if (!r.isNullAt(endDate)){ eDate= convertDateToDDMMYYYY(r.getDate(endDate).toString)}else{eDate= endDate}
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}

    val isExist = !r.isNullAt(startDate) && !r.isNullAt(endDate) && dateUtility.getAge(r.getString(startDate),r.getString(endDate)) < compareYears
    if (isExist)
      message = sDate + " and " + eDate + " diffrence is less than (" + compareYears + ") "
    else
      message = sDate + " and " + eDate + " diffrence is not less than (" + compareYears + ") "
    measureLogger(r, measureName, conditionType, "chkDateYearDiffLess", startDate, isExist, message)
    return isExist;
  }

  def chkDateRangeLessOrEqualendDate(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, endDate: Date): Boolean = {
    var eDate=""
    if (!r.isNullAt(checkDate)){ eDate= convertDateToDDMMYYYY(r.getDate(checkDate).toString)}else{eDate= checkDate}

    val isExist =  !r.isNullAt(checkDate) &&
      (r.getDate(checkDate).before(endDate) || r.getDate(checkDate).equals(endDate))
    if (isExist)
      message= eDate+ " Found In Date Range less than equal to ("+ endDate+")"
    else
      message= eDate +" Not Found In Date Range less then equal to ("+ endDate+") "
    measureLogger(r, measureName, conditionType, "chkDateRangeLessOrEqualendDate", checkDate, isExist,message)
    return isExist;
  }


  def checkElementValueDoubleGreater(r: CassandraRow, conditionType: String, measureName: String, elementName:String, checkValue: Double): Boolean = {
    val isExist = !r.isNullAt(elementName) && r.getDouble(elementName) > checkValue
    if (isExist)
      message= elementName+ " is greater than ("+ checkValue +")"
    else
      message= elementName +" is not greater than ("+ checkValue +") "
    measureLogger(r, measureName, conditionType, "checkElementValueDoubleGreater", elementName, isExist,message)
    return isExist;
  }

  def checkElementValueDoubleGreaterOrEqual(r: CassandraRow, conditionType: String, measureName: String, elementName:String, checkValue: Double): Boolean = {
    val isExist = !r.isNullAt(elementName) && r.getDouble(elementName) >= checkValue
    if (isExist)
      message= elementName+ " is greater than or equal to ("+ checkValue +")"
    else
      message= elementName +" is not greater than or equal to ("+ checkValue +") "
    measureLogger(r, measureName, conditionType, "checkElementValueDoubleGreaterOrEqual", elementName, isExist,message)
    return isExist;
  }

  def checkElementValueDoubleLess(r: CassandraRow, conditionType: String, measureName: String, elementName:String, checkValue: Double): Boolean = {
    val isExist = !r.isNullAt(elementName) && r.getDouble(elementName) < checkValue
    if (isExist)
      message= elementName+ " is less than ("+ checkValue +")"
    else
      message= elementName +" is not less than ("+ checkValue +") "
    measureLogger(r, measureName, conditionType, "checkElementValueDoubleLess", elementName, isExist,message)
    return isExist;
  }

  def checkElementValueDoubleLessOrEqual(r: CassandraRow, conditionType: String, measureName: String, elementName:String, checkValue: Double): Boolean = {
    val isExist = !r.isNullAt(elementName) && r.getDouble(elementName) <= checkValue
    if (isExist)
      message= elementName+ " is less than equal to ("+ checkValue +")"
    else
      message= elementName +" is not less than equal to ("+ checkValue +") "
    measureLogger(r, measureName, conditionType, "checkElementValueDoubleLessOrEqual", elementName, isExist,message)
    return isExist;
  }

  def checknull(r: CassandraRow, conditionType: String, measureName: String, checkElement: String): Boolean = {
    val isExist = r.isNullAt(checkElement) || r.getString(checkElement)== "0" ||r.getString(checkElement).equals("0")|| r.getString(checkElement).equalsIgnoreCase("null")
    if (isExist)
      message = checkElement + " null Found"
    else
      message = checkElement + " null not Found"
    measureLogger(r, measureName, conditionType, "checknull", checkElement, isExist, message)
    return isExist;
  }

  def checkNullOrZero(r: CassandraRow, conditionType: String, measureName: String, checkElement: String): Boolean = {
    val isExist = r.isNullAt(checkElement) || r.getString(checkElement)== "0" ||r.getString(checkElement).equals("0")|| r.getString(checkElement).equalsIgnoreCase("null")
    if (isExist)
      message = checkElement + " null Found"
    else
      message = checkElement + " null not Found"
    measureLogger(r, measureName, conditionType, "checknull", checkElement, isExist, message)
    return isExist;
  }

  def chkDateRangeBetweenMinusHours(r:CassandraRow,conditionType:String,measureName:String,checkdate:String,compareDate:String,no_of_Hours:Int):Boolean={
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}
    var chkDate=""
    if (!r.isNullAt(checkdate)){ chkDate= convertDateToDDMMYYYY(r.getDate(checkdate).toString)}else{chkDate= checkdate}

    val isExist = !r.isNullAt(checkdate) && !r.isNullAt(compareDate) && (

      (
      (r.getDateTime(checkdate).isAfter(r.getDateTime(compareDate).minusHours(no_of_Hours))) && r.getDateTime(checkdate).isBefore(r.getDateTime(compareDate)) )
      || r.getDateTime(checkdate).equals(r.getDateTime(compareDate).minusHours(no_of_Hours))|| r.getDate(checkdate).equals(r.getDate(compareDate)))
    if (isExist)
      message = chkDate + " Found in Date Range (" + cDate+ ", "+cDate+" minus" + no_of_Hours +" hours)"
    else
      message = chkDate + " Not found in Date Range (" +cDate + " , "+cDate+"  minus " + no_of_Hours+" hours)"
    measureLogger(r,measureName,conditionType,"chkDateRangeBetweenMinusHours",checkdate,isExist,message)

    return isExist
  }

  // function for chkDateRangeLessOrEqualMinusHours
  def chkDateRangeLessOrEqualMinusHours(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, startDate: String,no_of_hours:Int): Boolean = {
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}

    val isExist = !r.isNullAt(startDate)   && !r.isNullAt(checkDate) && (r.getDateTime(checkDate).isBefore(r.getDateTime(startDate).minusHours(no_of_hours))
      || r.getDateTime(checkDate).equals(r.getDateTime(startDate).minusHours(no_of_hours)))
    if (isExist)
      message= checkDate+ " Found In Date Range Less Than Or Equal to ("+ sDate+" - "+no_of_hours+" hours)"
    else
      message= checkDate +" Not Found In Date Range Less Than Or Equal to ("+ sDate+"- "+no_of_hours+" hours) "
    measureLogger(r, measureName, conditionType, "chkDateRangeLessOrEqualMinusHours", checkDate, isExist,message)
    return isExist;
  }

  // function for chkDateRangeBetweenMinusDaysForTwoArg
  def chkDateRangeBetweenMinusDaysForTwoArg(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, compareDate: String, no_of_Days1: Int, no_of_Days2: Int): Boolean = {
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}
    var chkDate=""
    if (!r.isNullAt(checkDate)){ chkDate= convertDateToDDMMYYYY(r.getDate(checkDate).toString)}else{chkDate= checkDate}

    val isExist = !r.isNullAt(checkDate)  && !r.isNullAt(compareDate) && !r.isNullAt(checkDate) && ((
      (r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate).minusDays(no_of_Days1)) ) &&
        (r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate).minusDays(no_of_Days2)))
      )|| r.getDateTime(checkDate).equals(r.getDateTime(compareDate).minusDays(no_of_Days1))|| r.getDateTime(checkDate).equals(r.getDateTime(compareDate).minusDays(no_of_Days2))
      )
    if (isExist)
      message= chkDate+ " Found In Date Range ("+ cDate+" minus "+no_of_Days1+", "+cDate+" minus "+no_of_Days2+" days)"
    else
      message= chkDate +" Not Found In Date Range ("+ cDate+" minus "+no_of_Days1+", "+cDate+" minus "+no_of_Days2+" days) "
    measureLogger(r, measureName, conditionType, "chkDateRangeBetweenMinusDaysForTwoArg", checkDate, isExist,message)
    return isExist;
  }

  // function for chkDateRangeBetweenMinusDaysForTwoArg1Minus2plus
  def chkDateRangeBetweenMinusDaysForTwoArg1Minus2plus(r: CassandraRow, conditionType: String, measureName:String,checkDate:String, compareDate: String, no_of_Days1: Int, no_of_Days2: Int): Boolean = {
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}
    var chkDate=""
    if (!r.isNullAt(checkDate)){ chkDate= convertDateToDDMMYYYY(r.getDate(checkDate).toString)}else{chkDate= checkDate}

    val isExist = !r.isNullAt(checkDate)  && !r.isNullAt(compareDate) && !r.isNullAt(checkDate) &&((
      r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate).plusDays(no_of_Days1)) &&
        r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate).minusDays(no_of_Days2))
      )|| r.getDateTime(checkDate).equals(r.getDateTime(compareDate).plusDays(no_of_Days1))|| r.getDateTime(checkDate).equals(r.getDateTime(compareDate).minusDays(no_of_Days2))
      )

    if (isExist)
      message= chkDate+ " Found In Date Range ("+ cDate+" plus "+no_of_Days1+", "+cDate+" minus "+no_of_Days2+" days)"
    else
      message= chkDate +" Not Found In Date Range ("+ cDate+" plus "+no_of_Days1+", "+cDate+" minus "+no_of_Days2+" days) "
    measureLogger(r, measureName, conditionType, "chkDateRangeBetweenMinusDaysForTwoArg1Minus2plus", checkDate, isExist,message)
    return isExist;
  }

  //function for chkDateRangeBetweenPlusMinutes
  def chkDateRangeBetweenPlusMinutes(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, compareDate: String, no_of_Mins: Int): Boolean = {
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}
    var chkDate=""
    if (!r.isNullAt(checkDate)){ chkDate= convertDateToDDMMYYYY(r.getDate(checkDate).toString)}else{chkDate= checkDate}

    val isExist = !r.isNullAt(checkDate)  && !r.isNullAt(compareDate) && !r.isNullAt(checkDate) && ((
      r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate).plusMinutes(no_of_Mins))  && r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate))
      )|| r.getDateTime(checkDate).equals(r.getDateTime(compareDate).plusMinutes(no_of_Mins))|| r.getDate(checkDate).equals(r.getDate(compareDate))
      )
    if (isExist)
      message= chkDate+ " Found In Date Range ("+ cDate+", "+ cDate+" plus "+no_of_Mins+" minutes) "
    else
      message= chkDate +" Not Found In Date Range ("+ cDate+", "+ cDate+" plus "+no_of_Mins+" minutes) "
    measureLogger(r, measureName, conditionType, "chkDateRangeBetweenPlusMinutes", checkDate, isExist,message)
    return isExist;
  }

  //function for chkDateRangeBetweenMinusMinutes
  def chkDateRangeBetweenMinusMinutes(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, compareDate: String, no_of_Mins: Int): Boolean = {
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}
    var chkDate=""
    if (!r.isNullAt(checkDate)){ chkDate= convertDateToDDMMYYYY(r.getDate(checkDate).toString)}else{chkDate= checkDate}

    val isExist = !r.isNullAt(checkDate)  && !r.isNullAt(compareDate) && !r.isNullAt(checkDate) &&((
      r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate).minusMinutes(no_of_Mins))  &&
        r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate))
      )|| r.getDateTime(checkDate).equals(r.getDateTime(compareDate).minusMinutes(no_of_Mins))|| r.getDate(checkDate).equals(r.getDate(compareDate))
      )
    if (isExist)
      message= chkDate+ " Found In Date Range ("+ cDate+", "+ cDate+" minus "+no_of_Mins+" minutes) "
    else
      message= chkDate +" Not Found In Date Range ("+ cDate+", "+ cDate+" minus "+no_of_Mins+" minutes) "
    measureLogger(r, measureName, conditionType, "chkDateRangeBetweenMinusMinutes", checkDate, isExist,message)
    return isExist;
  }

  //function for chkDateRangeBetweenMinusMonths
  def chkDateRangeBetweenMinusMonths(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, compareDate: String, no_of_Months: Int): Boolean = {
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}
    var chkDate=""
    if (!r.isNullAt(checkDate)){ chkDate= convertDateToDDMMYYYY(r.getDate(checkDate).toString)}else{chkDate= checkDate}

    val isExist = !r.isNullAt(checkDate)  && !r.isNullAt(compareDate) && !r.isNullAt(checkDate) &&((
      r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate).minusMonths(no_of_Months))  &&
        r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate))
      )|| r.getDateTime(checkDate).equals(r.getDateTime(compareDate).minusMonths(no_of_Months))|| r.getDate(checkDate).equals(r.getDate(compareDate))
      )
    if (isExist)
      message= chkDate+ " Found In Date Range ("+ cDate+", "+ cDate+" minus "+no_of_Months+" Months) "
    else
      message= chkDate +" Not Found In Date Range ("+ cDate+", "+ cDate+" minus "+no_of_Months+" Months) "
    measureLogger(r, measureName, conditionType, "chkDateRangeBetweenMinusMonths", checkDate, isExist,message)
    return isExist;
  }


  //function for chkDateRangeBetweenPlusMonths
  def chkDateRangeBetweenPlusMonths(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, compareDate: String, no_of_Months: Int): Boolean = {
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}
    var chkDate=""
    if (!r.isNullAt(checkDate)){ chkDate= convertDateToDDMMYYYY(r.getDate(checkDate).toString)}else{chkDate= checkDate}

    val isExist = !r.isNullAt(checkDate)  && !r.isNullAt(compareDate) && !r.isNullAt(checkDate) &&((
      r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate).plusMonths(no_of_Months))  && r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate))
      )|| r.getDateTime(checkDate).equals(r.getDateTime(compareDate).plusMonths(no_of_Months))|| r.getDate(checkDate).equals(r.getDate(compareDate))
      )
    if (isExist)
      message= chkDate+ " Found In Date Range ("+ cDate+", "+ cDate+" plus "+no_of_Months+" Months) "
    else
      message= chkDate +" Not Found In Date Range ("+ cDate+", "+ cDate+" plus "+no_of_Months+" Months) "
    measureLogger(r, measureName, conditionType, "chkDateRangeBetweenPlusMonths", checkDate, isExist,message)
    return isExist;
  }

  // function for chkDateRangeBetweenMinusSeconds
  def chkDateRangeBetweenMinusSeconds(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, compareDate: String, no_of_Sec: Int): Boolean = {
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}
    var chkDate=""
    if (!r.isNullAt(checkDate)){ chkDate= convertDateToDDMMYYYY(r.getDate(checkDate).toString)}else{chkDate= checkDate}

    val isExist = !r.isNullAt(checkDate)  && !r.isNullAt(compareDate) &&((
      r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate).minusSeconds(no_of_Sec))  &&
      r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate))
      )|| r.getDateTime(checkDate).equals(r.getDateTime(compareDate).minusSeconds(no_of_Sec))|| r.getDate(checkDate).equals(r.getDate(compareDate))
      )
    if (isExist)
      message= chkDate+ " Found In Date Range ("+ cDate+", "+ cDate+" minus "+no_of_Sec+" Seconds) "
    else
      message= chkDate +" Not Found In Date Range ("+ cDate+", "+ cDate+" minus "+no_of_Sec+" Seconds) "
    measureLogger(r, measureName, conditionType, "chkDateRangeBetweenMinusSeconds", checkDate, isExist,message)
    return isExist;
  }

  // function for chkDateRangeBetweenMinusSeconds
  def chkDateRangeBetweenPlusSeconds(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, compareDate: String, no_of_Sec: Int): Boolean = {
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}
    var chkDate=""
    if (!r.isNullAt(checkDate)){ chkDate= convertDateToDDMMYYYY(r.getDate(checkDate).toString)}else{chkDate= checkDate}

    val isExist = !r.isNullAt(checkDate)  && !r.isNullAt(compareDate) && ((
      r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate).plusSeconds(no_of_Sec))  &&
      r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate))
      )|| r.getDateTime(checkDate).equals(r.getDateTime(compareDate).plusSeconds(no_of_Sec))|| r.getDate(checkDate).equals(r.getDate(compareDate))
      )
    if (isExist)
      message= chkDate+ " Found In Date Range ("+ cDate+", "+ cDate+" plus "+no_of_Sec+" Seconds) "
    else
      message= chkDate +" Not Found In Date Range ("+ cDate+", "+ cDate+" plus "+no_of_Sec+" Seconds) "
    measureLogger(r, measureName, conditionType, "chkDateRangeBetweenPlusSeconds", checkDate, isExist,message)
    return isExist;
  }

  //function for chkDateRangeBetweenMinusSecondsFromQuarterEndDate
  def chkDateRangeBetweenMinusSecondsFromQuarterEndDate(r: CassandraRow, conditionType: String, measureName: String, checkDate: String, startDate: Date, endDate:Date, no_of_Seconds: Int): Boolean = {

    var cDate = convertDateToDDMMYYYY(startDate.toString)
    var eDate = convertDateToDDMMYYYY(endDate.toString)

    endDate.setTime(endDate.getTime-(no_of_Seconds*1000))
    val isExist = !r.isNullAt(checkDate) && (

      (
      r.getDate(checkDate).after(startDate)  && r.getDate(checkDate).before(endDate)
      )|| r.getDate(checkDate).equals(startDate)|| r.getDate(checkDate).equals(endDate)
      )
    if (isExist)
      message = checkDate + " Found in Date Range (" + cDate + ", " + eDate + " minus" + no_of_Seconds + " Seconds)"
    else
      message = checkDate + " Not found in Date Range (" + cDate + " , " + eDate + "  minus " + no_of_Seconds + " Seconds)"
    measureLogger(r, measureName, conditionType, "chkDateRangeBetweenMinusSecondsFromQuarterEndDate", checkDate, isExist, message)

    return isExist
  }

  // function for chkValueRangeLess
  def chkValueRangeLess(r: CassandraRow, conditionType: String, measureName: String,checkValue:String, Value: Int): Boolean = {
    val isExist = !r.isNullAt(checkValue) && r.getInt(checkValue)<Value
    if (isExist)
      message= checkValue+ " is less than ("+ Value +")"
    else
      message= checkValue +" is not less than ("+ Value +") "
    measureLogger(r, measureName, conditionType, "chkValueRangeLess", checkValue, isExist,message)
    return isExist;
  }

  // function for chkValueRangeLessorEqual
  def chkValueRangeLessorEqual(r: CassandraRow, conditionType: String, measureName: String,checkValue:String, Value: Int): Boolean = {
    val isExist =  !r.isNullAt(checkValue) && r.getInt(checkValue) <= Value
    if (isExist)
      message= checkValue+ " is less than or equal to ("+ Value +")"
    else
      message= checkValue +" is not less than or equal to ("+ Value +") "
    measureLogger(r, measureName, conditionType, "chkValueRangeLessorEqual", checkValue, isExist,message)
    return isExist;
  }

  // function for chkValueRangeGreater
  def chkValueRangeGreater(r: CassandraRow, conditionType: String, measureName: String,checkValue:String, Value: Double): Boolean = {
    val isExist = !r.isNullAt(checkValue) && r.getDouble(checkValue) > Value
    if (isExist)
      message= checkValue+ " is greater than ("+ Value +")"
    else
      message= checkValue +" is not greater than ("+ Value +") "
    measureLogger(r, measureName, conditionType, "chkValueRangeGreater", checkValue, isExist,message)
    return isExist;
  }

  // function for chkValueRangeGreaterOrEqual
  def chkValueRangeGreaterOrEqual(r: CassandraRow, conditionType: String, measureName: String,checkValue:String, Value: Int): Boolean = {
    val isExist = !r.isNullAt(checkValue) && r.getInt(checkValue) >= Value
    if (isExist)
      message= checkValue+ " is greater than or equal to ("+ Value +")"
    else
      message= checkValue +" is not greater than or equal to ("+ Value +") "
    measureLogger(r, measureName, conditionType, "chkValueRangeGreaterOrEqual", checkValue, isExist,message)
    return isExist;
  }





  // function for chkDateRangeExist
  def chkDateRangeExist(r: CassandraRow, conditionType: String, measureName: String, elementName: String, startDate: Date, endDate: Date): Boolean = {

    var sDate = convertDateToDDMMYYYY(startDate.toString)
    var eDate = convertDateToDDMMYYYY(endDate.toString)

    val isExist = !r.isNullAt(elementName) && ((
      r.getDate(elementName).after(startDate)  &&
      r.getDate(elementName).before(endDate)
      )|| r.getDate(elementName).equals(startDate)|| r.getDate(elementName).equals(endDate)
      )
    if (isExist)
      message= elementName+ " Found In Date Range ("+ sDate+", "+eDate+")"
    else
      message= elementName +" Not Found In Date Range ("+ sDate+", "+eDate+") "
    measureLogger(r, measureName, conditionType, "chkDateRangeExist", elementName, isExist,message)
    return isExist;
  }

  // function for chkDateRangeBetween
  def chkDateRangeBetween(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, startDate: String, endDate: String): Boolean = {
    var sDate=""
    var eDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}
    if (!r.isNullAt(endDate)){ eDate= convertDateToDDMMYYYY(r.getDate(endDate).toString)}else{eDate= endDate}

    val isExist = !r.isNullAt(startDate)  && !r.isNullAt(endDate) && !r.isNullAt(checkDate) &&(
      (r.getDateTime(startDate).isBefore(r.getDateTime(endDate)) ||r.getDateTime(startDate).equals(r.getDateTime(endDate))) &&
      (
      r.getDateTime(checkDate).isAfter(r.getDateTime(startDate))  &&
      r.getDateTime(checkDate).isBefore(r.getDateTime(endDate))
      || r.getDateTime(checkDate).equals(r.getDateTime(startDate))|| r.getDateTime(checkDate).equals(r.getDateTime(endDate))
      )
      )
    if (isExist)
      message= checkDate+ " Found In Date Range ("+ sDate+", "+eDate+")"
    else
      message= checkDate +" Not Found In Date Range ("+ sDate+", "+eDate+") "
    measureLogger(r, measureName, conditionType, "chkDateRangeBetween", checkDate, isExist,message)
    return isExist;
  }

  // function for chkDateRangeGreater
  def chkDateRangeGreater(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, startDate: String): Boolean = {
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}


    val isExist = !r.isNullAt(startDate)   && !r.isNullAt(checkDate) && r.getDate(checkDate).after(r.getDate(startDate))
    if (isExist)
      message= checkDate+ " Found In Date Range Greater than ("+ sDate+")"
    else
      message= checkDate +" Not Found In Date Range Greater than ("+ sDate+") "
    measureLogger(r, measureName, conditionType, "chkDateRangeGreater", checkDate, isExist,message)
    return isExist;
  }

  // function for chkDateRangeBetweenMinusDays
  def chkDateRangeBetweenMinusDays(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, compareDate: String, no_of_Days: Int): Boolean = {
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}

    val isExist = !r.isNullAt(checkDate)  && !r.isNullAt(compareDate) && !r.isNullAt(checkDate) &&((
      r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate).minusDays(no_of_Days)) &&
      r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate))
      )|| r.getDateTime(checkDate).equals(r.getDateTime(compareDate).minusDays(no_of_Days))|| r.getDate(checkDate).equals(r.getDate(compareDate))
      )
    if (isExist)
      message= checkDate+ " Found In Date Range ("+cDate+", "+cDate+" minus "+no_of_Days+" days) "
    else
      message= checkDate +" Not Found In Date Range ("+ cDate+","+cDate+" minus "+no_of_Days+" days) "
    measureLogger(r, measureName, conditionType, "chkDateRangeBetweenMinusDays", checkDate, isExist,message)
    return isExist;
  }

  // function for chkDateRangeBetweenPlusDays
  def chkDateRangeBetweenPlusDays(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, compareDate: String, no_of_Days: Int): Boolean = {
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}

    val isExist = !r.isNullAt(checkDate)  && !r.isNullAt(compareDate) && !r.isNullAt(checkDate) &&((
      r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate).plusDays(no_of_Days)) &&
      r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate))
      )||r.getDateTime(checkDate).equals(r.getDateTime(compareDate).plusDays(no_of_Days))|| r.getDate(checkDate).equals(r.getDate(compareDate))
      )
    if (isExist)
      message= checkDate+ " Found In Date Range ("+ cDate+", plus "+no_of_Days+" days) "
    else
      message= checkDate +" Not Found In Date Range ("+ cDate+", plus "+no_of_Days+" days) "
    measureLogger(r, measureName, conditionType, "chkDateRangeBetweenPlusDays", checkDate, isExist,message)
    return isExist;
  }

  // function for chkDateRangeLessOrEqual
  def chkDateRangeLessOrEqual(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, startDate: String): Boolean = {
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}

    val isExist = !r.isNullAt(startDate)   && !r.isNullAt(checkDate) && (r.getDate(checkDate).before(r.getDate(startDate))|| r.getDate(checkDate).equals(r.getDate(startDate)))
    if (isExist)
      message= checkDate+ " Found In Date Range Less Than Or Equal to ("+ sDate+")"
    else
      message= checkDate +" Not Found In Date Range Less Than Or Equal to ("+ sDate+") "
    measureLogger(r, measureName, conditionType, "chkDateRangeLessOrEqual", checkDate, isExist,message)
    return isExist;
  }

  // function for chkDateRangeGreaterOrEqual
  def chkDateRangeGreaterOrEqual(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, startDate: String): Boolean = {
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}
    val isExist = !r.isNullAt(startDate)   && !r.isNullAt(checkDate) && (r.getDate(checkDate).after(r.getDate(startDate))|| r.getDate(checkDate).equals(r.getDate(startDate)))
    if (isExist)
      message= checkDate+ " Found In Date Range Greater Than Or Equal to ("+ sDate+")"
    else
      message= checkDate +" Not Found In Date Range Greater Than Or Equal to ("+ sDate+") "
    measureLogger(r, measureName, conditionType, "chkDateRangeGreaterOrEqual", checkDate, isExist,message)
    return isExist;
  }
  // function for chkDateRangeLessOrEqualAndSecoundDatePlusDays
  def chkDateRangeLessOrEqualAndSecoundDatePlusDays(r: CassandraRow, conditionType: String, measureName: String,firstDate:String, secoundDate: String,no_of_Days:Int): Boolean = {
    var fDate=""
    if (!r.isNullAt(firstDate)){ fDate= convertDateToDDMMYYYY(r.getDate(firstDate).toString)}else{fDate= firstDate}
    var sDate=""
    if (!r.isNullAt(secoundDate)){ sDate= convertDateToDDMMYYYY(r.getDate(secoundDate).toString)}else{sDate= secoundDate}


    val isExist = !r.isNullAt(firstDate)   && !r.isNullAt(secoundDate) && (r.getDateTime(firstDate).isAfter(r.getDateTime(secoundDate).plusDays(no_of_Days))|| r.getDateTime(firstDate).equals(r.getDateTime(secoundDate).plusDays(no_of_Days)))
    if (isExist)
      message= fDate+ " Found In Date Range Less Than Or Equal to ("+ sDate+") plus "+no_of_Days+" Days"
    else
      message= fDate +" Not Found In Date Range Greater Than Or Equal to ("+ sDate+") plus "+no_of_Days+" Days"
    measureLogger(r, measureName, conditionType, "chkDateRangeLessOrEqualAndSecoundDatePlusDays", fDate, isExist,message)
    return isExist;
  }
  // function for checkRange
  def checkRange(r: CassandraRow, conditionType: String, measureName: String, elementName: String, i: Integer, j: Integer): Boolean = {
    val isExist = !r.isNullAt(elementName) && r.getString(elementName).toInt >=i && r.getString(elementName).toInt <= j
    if (isExist)
      message= elementName+ " Found In Date Range ("+ i+", "+j+") "
    else
      message= elementName +" Not Found In Date Range ("+ i+", "+j+") "
    measureLogger(r, measureName, conditionType, "checkRange", elementName, isExist,message)
    return isExist;
  }

  // function for chkDateEqual
  def chkDateEqual(r: CassandraRow, conditionType: String, measureName: String, firstDate: String, compareDate: String): Boolean = {
    var cDate = ""
    if (!r.isNullAt(compareDate)) {
      cDate = convertDateToDDMMYYYY(r.getDate(compareDate).toString)
    } else {
      cDate = compareDate
    }
    var fDate = ""
    if (!r.isNullAt(firstDate)) {
      fDate = convertDateToDDMMYYYY(r.getDate(firstDate).toString)
    } else {
      fDate = firstDate
    }

    val isExist = !r.isNullAt(firstDate) && !r.isNullAt(compareDate) && (r.getDate(firstDate).getDay.equals(r.getDate(compareDate).getDay) && r.getDate(firstDate).getMonth.equals(r.getDate(compareDate).getMonth) && r.getDate(firstDate).getYear.equals(r.getDate(compareDate).getYear))

    if (isExist)
      message = "(" + fDate + ") Found In Date equals to (" + cDate + ") "
    else
      message = "(" + fDate + ") Date Not equal to (" + cDate + ") "
    measureLogger(r, measureName, conditionType, "chkDateEqual", firstDate, isExist, message)
    return isExist;

  }


  //function for chkDateDiffHoursLessThanHours()
  def chkDateDiffHoursLessThanHours(r: CassandraRow, conditionType: String, measureName: String,firstDate: String, secoundDate: String,hours :Int): Boolean =
  {
    var cDate=""
    if (!r.isNullAt(secoundDate)){ cDate= convertDateToDDMMYYYY(r.getDate(secoundDate).toString)}else{cDate= secoundDate}
    var fDate=""
    if (!r.isNullAt(firstDate)){ fDate= convertDateToDDMMYYYY(r.getDate(firstDate).toString)}else{fDate= firstDate}

    val isExist = !r.isNullAt(firstDate) && !r.isNullAt(secoundDate) && dateUtility.getDateDiffHourslessthan(firstDate,secoundDate,hours)

    if (isExist)
      message= "Date Difference between "+fDate+ " and "+ cDate+" is less than "+hours+" hours"
    else
      message= "Date Difference between "+fDate+ " and "+ cDate+" is Not less than "+hours+" hours"
    measureLogger(r, measureName, conditionType, "chkDateDiffHoursLessThanHours", firstDate, isExist, message)
    return isExist;
  }
  //function for chkDateDiffHoursGreaterThanOrEqualHours()
  def chkDateDiffHoursGreaterThanOrEqualHours(r: CassandraRow, conditionType: String, measureName: String,firstDate: String, secoundDate: String,hours :Int): Boolean =
  {
    var cDate=""
    if (!r.isNullAt(secoundDate)){ cDate= convertDateToDDMMYYYY(r.getDate(secoundDate).toString)}else{cDate= secoundDate}
    var fDate=""
    if (!r.isNullAt(firstDate)){ fDate= convertDateToDDMMYYYY(r.getDate(firstDate).toString)}else{fDate= firstDate}

    val isExist = !r.isNullAt(firstDate) && !r.isNullAt(secoundDate) && dateUtility.getDateDiffGreaterOrEqualHours(firstDate,secoundDate,hours)

    if (isExist)
      message= "Date Difference between "+fDate+ " and "+ cDate+" is greater than "+hours+" hours"
    else
      message= "Date Difference between "+fDate+ " and "+ cDate+" is Not less than "+hours+" hours"
    measureLogger(r, measureName, conditionType, "chkDateDiffHoursGreaterThanOrEqualHours", firstDate, isExist, message)
    return isExist;
  }

  //function for chkDateRangeLessThanMinusSecondsFromQuarterEndDate
  def chkDateRangeLessThanMinusSecondsFromQuarterEndDate(r: CassandraRow, conditionType: String, measureName: String, checkDate: String, endDate:Date, no_of_Seconds: Int): Boolean = {
    var eDate = convertDateToDDMMYYYY(endDate.toString)

    endDate.setTime(endDate.getTime-(no_of_Seconds*1000))
    val isExist = !r.isNullAt(checkDate) &&
      (r.getDate(checkDate).before(endDate) || r.getDate(checkDate).equals(endDate))
    if (isExist)
      message = checkDate + " Less than or Equal To ("  + eDate + " minus" + no_of_Seconds + " Seconds)"
    else
      message = checkDate + " Not Less than or Equal To ("  + eDate + "  minus " + no_of_Seconds + " Seconds)"
    measureLogger(r, measureName, conditionType, "chkDateRangeLessThanMinusSecondsFromQuarterEndDate", checkDate, isExist, message)

    return isExist
  }
  // function for chkDateMonthDiffGreaterOrEqual
  def chkDateMonthDiffGreaterOrEqual(r: CassandraRow, conditionType: String, measureName: String, startDate: String, endDate: String, compareYears: Double): Boolean = {
    var eDate=""
    if (!r.isNullAt(endDate)){ eDate= convertDateToDDMMYYYY(r.getDate(endDate).toString)}else{eDate= endDate}
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}

    val isExist = !r.isNullAt(startDate) && !r.isNullAt(endDate) && dateUtility.getAge(r.getString(startDate),r.getString(endDate)) >= compareYears
    if (isExist)
      message = sDate + " and " + eDate + " difference is greater than or equal to (" + compareYears + ") "
    else
      message = sDate + " and " + eDate + " difference is not greater than equal to (" + compareYears + ") "
    measureLogger(r, measureName, conditionType, "chkDateMonthDiffGreaterOrEqual", startDate, isExist, message)
    return isExist;
  }
  // function for chkDateYearDiffLessOrEqual
  def chkDateYearDiffLessOrEqual(r: CassandraRow, conditionType: String, measureName: String, startDate: String, endDate: String, compareYears: Double): Boolean = {
    var eDate=""
    if (!r.isNullAt(endDate)){ eDate= convertDateToDDMMYYYY(r.getDate(endDate).toString)}else{eDate= endDate}
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}

    val isExist = !r.isNullAt(startDate) && !r.isNullAt(endDate) && dateUtility.getAge(r.getString(startDate),r.getString(endDate)) <= compareYears
    if (isExist)
      message = sDate + " and " + eDate + " difference is less than or equal to (" + compareYears + ") "
    else
      message = sDate + " and " + eDate + " difference is not less than equal to (" + compareYears + ") "
    measureLogger(r, measureName, conditionType, "chkDateYearDiffLessOrEqual", startDate, isExist, message)
    return isExist;
  }

   // function for chkHoursRangeBetweenMinusDaysForTwoArg1Minus2plus
  def chkHoursRangeBetweenMinusDaysForTwoArg1Minus2plus(r: CassandraRow, conditionType: String, measureName:String,checkDate:String,compareDate: String, no_of_Days1: Int, no_of_Days2: Int): Boolean = {
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}
    var chkDate=""
    if (!r.isNullAt(checkDate)){ chkDate= convertDateToDDMMYYYY(r.getDate(checkDate).toString)}else{chkDate= checkDate}


    val isExist = !r.isNullAt(checkDate)  && !r.isNullAt(compareDate) && !r.isNullAt(checkDate) &&((
      r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate).plusHours(no_of_Days1))  &&
      r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate).minusHours(no_of_Days2))
      )|| r.getDateTime(checkDate).equals(r.getDateTime(compareDate).plusHours(no_of_Days1))|| r.getDateTime(checkDate).equals(r.getDateTime(compareDate).minusHours(no_of_Days2))
      )

    if (isExist)
      message= chkDate+ " Found In Hours Range ("+ chkDate+" plus "+no_of_Days1+", "+chkDate+" minus "+no_of_Days2+" Hours)"
    else
      message= chkDate +" Not Found In Hours Range ("+ chkDate+" plus "+no_of_Days1+", "+chkDate+" minus "+no_of_Days2+" Hours) "
    measureLogger(r, measureName, conditionType, "chkHoursRangeBetweenMinusDaysForTwoArg1Minus2plus", checkDate, isExist,message)
    return isExist;
  }

  //AND (ActSints = 1 AND ActSints_Date BETWEEN QuarterStartDate and Dateadd(DD,-28,DateADD(ss,-1,QuarterEnddate)))
  //function for chkDateRangeLessThanMinusDayFromQuarterEndDate Developer:Ajinkya
  def chkDateRangeLessThanMinusDayFromQuarterEndDate(r: CassandraRow, conditionType: String, measureName: String, checkDate: String, startDate: Date, endDate:Date, no_of_Days: Int): Boolean = {

    var sDate = convertDateToDDMMYYYY(startDate.toString)
    var eDate = convertDateToDDMMYYYY(endDate.toString)

    endDate.setTime(endDate.getTime-(no_of_Days*86400000))
    val isExist = !r.isNullAt(checkDate) && chkDateRangeBetweenMinusSecondsFromQuarterEndDate(r,conditionType,measureName,checkDate,startDate,endDate,-1)
    if (isExist)
      message = checkDate + " Between  ("  + sDate + " and "+eDate+" minus" + no_of_Days + " days)"
    else
      message = checkDate + " Not Between  ("  + sDate + " and "+eDate+" minus" + no_of_Days + " days)"
    measureLogger(r, measureName, conditionType, "chkDateRangeLessThanMinusDayFromQuarterEndDate", checkDate, isExist, message)

    return isExist
  }

  //function for chkDateDaysDiffGreater
  def chkDaysDiffGreater(r: CassandraRow, conditionType: String, measureName: String, startDate: String, endDate: String, compareDays: Double): Boolean = {
    var eDate=""
    if (!r.isNullAt(endDate)){ eDate= convertDateToDDMMYYYY(r.getDate(endDate).toString)}else{eDate= endDate}
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}


    val isExist = !r.isNullAt(startDate) && !r.isNullAt(endDate) && dateUtility.getDaysDiff(r.getString(startDate),r.getString(endDate)) > compareDays
    if (isExist)
      message = sDate + " and " + eDate + " day difference is greater than (" + compareDays + ") days"
    else
      message = sDate + " and " + eDate + " day difference is greater than (" + compareDays + ") days"
    measureLogger(r, measureName, conditionType, "chkDaysDiffGreater", startDate, isExist, message)
    return isExist;
  }
  //function for chkDateDaysDiffGreaterOrEqual
  def chkDaysDiffGreaterOrEqual(r: CassandraRow, conditionType: String, measureName: String, startDate: String, endDate: String, compareDays: Double): Boolean = {
    var eDate=""
    if (!r.isNullAt(endDate)){ eDate= convertDateToDDMMYYYY(r.getDate(endDate).toString)}else{eDate= endDate}
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}

    val isExist = !r.isNullAt(startDate) && !r.isNullAt(endDate) && dateUtility.getDaysDiff(r.getString(startDate),r.getString(endDate)) >= compareDays
    if (isExist)
      message = sDate + " and " + eDate + " day difference is greater than or equal to (" + compareDays + ") days"
    else
      message = sDate + " and " + eDate + " day difference is greater not than equal to (" + compareDays + ") days"
    measureLogger(r, measureName, conditionType, "chkDaysDiffGreaterOrEqual", startDate, isExist, message)
    return isExist;
  }
  //function for chkDateDaysDiffLess
  def chkDaysDiffLess(r: CassandraRow, conditionType: String, measureName: String, startDate: String, endDate: String, compareDays: Double): Boolean = {
    var eDate=""
    if (!r.isNullAt(endDate)){ eDate= convertDateToDDMMYYYY(r.getDate(endDate).toString)}else{eDate= endDate}
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}
    val isExist = !r.isNullAt(startDate) && !r.isNullAt(endDate) && dateUtility.getDaysDiff(r.getString(startDate),r.getString(endDate)) < compareDays
    if (isExist)
      message = sDate + " and " + eDate + " day difference is less than  (" + compareDays + ") days"
    else
      message = sDate + " and " + eDate + " day difference is less not  (" + compareDays + ") days"
    measureLogger(r, measureName, conditionType, "chkDaysDiffLess", startDate, isExist, message)
    return isExist;
  }
  //function for chkDateDaysDiffLessThanOrEqual
  def chkDaysDiffLessOrEqual(r: CassandraRow, conditionType: String, measureName: String, startDate: String, endDate: String, compareDays: Double): Boolean = {
    var eDate=""
    if (!r.isNullAt(endDate)){ eDate= convertDateToDDMMYYYY(r.getDate(endDate).toString)}else{eDate= endDate}
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}
    val isExist = !r.isNullAt(startDate) && !r.isNullAt(endDate) && dateUtility.getDaysDiff(r.getString(startDate),r.getString(endDate)) <= compareDays
    if (isExist)
      message = sDate + " and " + eDate + " day difference is less than or equal to (" + compareDays + ") days"
    else
      message = sDate + " and " + eDate + " day difference is less not than equal to (" + compareDays + ") days"
    measureLogger(r, measureName, conditionType, "chkDaysDiffLessOrEqual", startDate, isExist, message)
    return isExist;
  }
  //function for chkMinutesDiffGreater
  def chkMinutesDiffGreater(r: CassandraRow, conditionType: String, measureName: String, startDate: String, endDate: String, compareDays: Double): Boolean = {
    var eDate=""
    if (!r.isNullAt(endDate)){ eDate= convertDateToDDMMYYYY(r.getDate(endDate).toString)}else{eDate= endDate}
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}

    val isExist = !r.isNullAt(startDate) && !r.isNullAt(endDate) && dateUtility.getMinutesDiff(r.getString(startDate),r.getString(endDate)) > compareDays
    if (isExist)
      message = sDate + " and " + eDate + " difference is greater (" + compareDays + ") days"
    else
      message = sDate + " and " + eDate + " difference is not greater than (" + compareDays + ") days"
    measureLogger(r, measureName, conditionType, "chkMinutDiffGreater", startDate, isExist, message)
    return isExist;
  }
  //function for chkMinutesDiffLess
  def chkMinutesDiffLess(r: CassandraRow, conditionType: String, measureName: String, startDate: String, endDate: String, compareDays: Double): Boolean = {
    var eDate=""
    if (!r.isNullAt(endDate)){ eDate= convertDateToDDMMYYYY(r.getDate(endDate).toString)}else{eDate= endDate}
    var sDate=""
    if (!r.isNullAt(startDate)){ sDate= convertDateToDDMMYYYY(r.getDate(startDate).toString)}else{sDate= startDate}
    val isExist = !r.isNullAt(startDate) && !r.isNullAt(endDate) && dateUtility.getMinutesDiff(r.getString(startDate),r.getString(endDate)) < compareDays
    if (isExist)
      message = sDate + " and " + eDate + " difference is less than (" + compareDays + ") days"
    else
      message = sDate + " and " + eDate + " difference not is less than (" + compareDays + ") days"
    measureLogger(r, measureName, conditionType, "chkMinutesDiffLess", sDate, isExist, message)
    return isExist;
  }

  // function for chkValueRangeBetweenValue
  def chkValueRangeBetweenValue(r: CassandraRow, conditionType: String, measureName: String,checkValue:String, GreaterValue: Int, LesserValue:Int): Boolean = {
    val isExist = !r.isNullAt(checkValue) && (r.getInt(checkValue) <= GreaterValue)  && (r.getInt(checkValue) >= LesserValue)
    if (isExist)
      message= checkValue+ " is between "+ GreaterValue +" and "+ LesserValue
    else
      message= checkValue + " is not in between "+ GreaterValue +" and "+ LesserValue
    measureLogger(r, measureName, conditionType, "chkValueRangeBetweenValue", checkValue, isExist,message)
    return isExist;
  }
  //function for ChkElementChadscore326
  def ChkElementChadscore326(r: CassandraRow, conditionType: String, measureName: String, startDate: String, endDate: String,hefa: String, hyper: String,dibtmelts: String,prirstrk: String,vsclr_disease: String,sex: String): Int= {
    var chadscore=0

    if(!r.isNullAt(startDate) && !r.isNullAt(endDate) && dateUtility.getAge(r.getString(startDate),r.getString(endDate)) >= 75){chadscore=chadscore+2}
    if(!r.isNullAt(hefa) && r.getString(hefa).equals("1")){chadscore=chadscore+1}
    if(!r.isNullAt(startDate) && !r.isNullAt(endDate) && dateUtility.getAge(r.getString(startDate),r.getString(endDate)) >= 64 && dateUtility.getAge(r.getString(startDate),r.getString(endDate)) < 75){chadscore=chadscore+1}
    if(!r.isNullAt(hyper) && r.getString(hyper).equals("1")){chadscore=chadscore+1}
    if(!r.isNullAt(dibtmelts) && r.getString(dibtmelts).equals("1")){chadscore=chadscore+1}
    if(!r.isNullAt(prirstrk) && r.getString(prirstrk).equals("1")){chadscore=chadscore+2}
    if(!r.isNullAt(vsclr_disease) && r.getString(vsclr_disease).equals("1")){chadscore=chadscore+1}
    if(!r.isNullAt(sex) && r.getString(sex).equals("2")){chadscore=chadscore+1}

    return chadscore

  }
  //function for chkDateRangeLessOrEqualEncounterdateAddDays
  def chkDateRangeLessOrEqualEncounterdateAddDays(r: CassandraRow, conditionType: String, measureName: String,checkDate:String, compareDate: String, no_of_Days1: Int): Boolean = {
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}
    var chkDate=""
    if (!r.isNullAt(checkDate)){ chkDate= convertDateToDDMMYYYY(r.getDate(checkDate).toString)}else{chkDate= checkDate}

    val isExist = !r.isNullAt(checkDate)  && !r.isNullAt(compareDate) && (
      (r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate).plusDays(no_of_Days1)) || r.getDateTime(checkDate).equals(r.getDateTime(compareDate).plusDays(no_of_Days1)))
      )
    if (isExist)
      message= chkDate+ " Less than or equal to "+ cDate+" add "+no_of_Days1+", days)"
    else
      message= chkDate +" Not Less than or equal to "+ cDate+" add "+no_of_Days1+", days) "
    measureLogger(r, measureName, conditionType, "chkDateRangeLessOrEqualEncounterdateAddDays", checkDate, isExist,message)
    return isExist;
  }


  def getFiledList(measureName : String): Array[String] = {
    var elements = fileUtility.getProperty("measure."+measureName+".element.select");
    return elements.split(",")
  }

  def getNotMet(ippRDD: RDD[CassandraRow], metRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    return ippRDD.subtract(metRDD)
  }

  def getinterRDD(firstRDD: RDD[CassandraRow], secoundRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    return firstRDD.subtract(secoundRDD)
  }

  def getExceptionRdd(exceptionRDD: RDD[CassandraRow], notMetRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    return exceptionRDD.subtract(notMetRDD)
  }

  def getNotMetWithoutException(notMetRDD: RDD[CassandraRow], exceptionRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    return notMetRDD.subtract(exceptionRDD)
  }

  def isIppEqualsEligible: Boolean = {
    if (fileUtility.getProperty("isIPPequalsEligible").equalsIgnoreCase("true")) {
      return true;
    }
    else {
      return false;
    }
  }

  def getMetString(): String = {
    return str + "1" + "~" + "0" + "~" + "1" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0"
  }

  def getNotMetString(): String = {
    return str + "1" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "1" + "~" + "0" + "~" + "0"
  }

  def getExceptionString(): String = {
    return str + "1" + "~" + "0" + "~" + "0" + "~" + "1" + "~" + "0" + "~" + "0" + "~" + "0"
  }


  def getIPPString(): String = {
    return str + "1" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0"
  }

  def getNotEligiblePopulationString(): String = {
    return str + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0"
  }

  def getExclusionString(): String = {
    return str + "1" + "~" + "1" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0"
  }


  def saveToWebDM(notEligibleRDD: RDD[CassandraRow], exclusionRDD: RDD[CassandraRow], metRDD: RDD[CassandraRow], exceptionRDD: RDD[CassandraRow], notMetRDD: RDD[CassandraRow], measureId: String): Unit = {

    var quarterEndDate = prop.getProperty("quarterEndDate").trim

//    val hdfs = FileSystem.get(sparkUtility.getSparkContext().sparkContext.hadoopConfiguration)
    var path=new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path")+ "/" + wfType + "/" + measureId + "/" + quarterEndDate)
    if (hdfsConf.isDirectory(path))
      hdfsConf.delete(path, true)


//    if (hdfs.isDirectory(new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId + "/" + quarterEndDate)))
//      hdfs.delete(new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId + "/" + quarterEndDate), true)


    /*
        notEligibleRDD.map(l => (if(l.isNullAt(0) ) "" else l.columnValues(0)) + "," + (if(l.isNullAt(1) ) "" else l.columnValues(1)) + "," + (if(l.isNullAt(2) ) "" else l.columnValues(2)) + "," + (if(l.isNullAt(3) ) "" else l.columnValues(3)) + "," + (if(l.isNullAt(4) ) "" else l.columnValues(4))  + "," + (if(l.isNullAt(5) ) "" else l.columnValues(5)) + "," + (if(l.isNullAt(6) ) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))+ "," + (if(l.isNullAt(7) ) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))+ "," + (if(l.isNullAt(8) ) "" else l.columnValues(8)) + "," + (if(l.isNullAt(9) ) "" else l.columnValues(9)) + "," + (if(l.isNullAt(10) ) "" else l.columnValues(10)) + "," + (if(l.isNullAt(11) ) "" else l.columnValues(11)) + "," + measureId + ","+quarterEndDate+ "," + getNotEligiblePopulationString()).cache().saveAsTextFile(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId+ "/" +quarterEndDate + "/notEligible")
        exclusionRDD.map(l => (if(l.isNullAt(0) ) "" else l.columnValues(0)) + "," + (if(l.isNullAt(1) ) "" else l.columnValues(1)) + "," + (if(l.isNullAt(2) ) "" else l.columnValues(2)) + "," + (if(l.isNullAt(3) ) "" else l.columnValues(3)) + "," + (if(l.isNullAt(4) ) "" else l.columnValues(4))  + "," + (if(l.isNullAt(5) ) "" else l.columnValues(5)) + "," + (if(l.isNullAt(6) ) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))+ "," + (if(l.isNullAt(7) ) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))+ "," + (if(l.isNullAt(8) ) "" else l.columnValues(8)) + "," + (if(l.isNullAt(9) ) "" else l.columnValues(9)) + "," + (if(l.isNullAt(10) ) "" else l.columnValues(10)) + "," + (if(l.isNullAt(11) ) "" else l.columnValues(11)) + "," + measureId + "," +quarterEndDate+ ","+ getExclusionString()).cache().saveAsTextFile(prop.getProperty("measure_computation_output_path")  + "/" + wfType + "/" + measureId+ "/" +quarterEndDate + "/exclusion")
        metRDD.map(l => (if(l.isNullAt(0) ) "" else l.columnValues(0)) + "," + (if(l.isNullAt(1) ) "" else l.columnValues(1)) + "," + (if(l.isNullAt(2) ) "" else l.columnValues(2)) + "," + (if(l.isNullAt(3) ) "" else l.columnValues(3)) + "," + (if(l.isNullAt(4) ) "" else l.columnValues(4))  + "," + (if(l.isNullAt(5) ) "" else l.columnValues(5)) + "," + (if(l.isNullAt(6) ) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))+ "," + (if(l.isNullAt(7) ) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))+ "," + (if(l.isNullAt(8) ) "" else l.columnValues(8)) + "," + (if(l.isNullAt(9) ) "" else l.columnValues(9)) + "," + (if(l.isNullAt(10) ) "" else l.columnValues(10)) + "," + (if(l.isNullAt(11) ) "" else l.columnValues(11)) + "," + measureId + "," +quarterEndDate+ ","+ getMetString()).cache().saveAsTextFile(prop.getProperty("measure_computation_output_path")  + "/" + wfType + "/" + measureId+ "/" +quarterEndDate + "/met")
        exceptionRDD.map(l => (if(l.isNullAt(0) ) "" else l.columnValues(0)) + "," + (if(l.isNullAt(1) ) "" else l.columnValues(1)) + "," + (if(l.isNullAt(2) ) "" else l.columnValues(2)) + "," + (if(l.isNullAt(3) ) "" else l.columnValues(3)) + "," + (if(l.isNullAt(4) ) "" else l.columnValues(4))  + "," + (if(l.isNullAt(5) ) "" else l.columnValues(5)) + "," + (if(l.isNullAt(6) ) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))+ "," + (if(l.isNullAt(7) ) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))+ "," + (if(l.isNullAt(8) ) "" else l.columnValues(8)) + "," + (if(l.isNullAt(9) ) "" else l.columnValues(9)) + "," + (if(l.isNullAt(10) ) "" else l.columnValues(10)) + "," + (if(l.isNullAt(11) ) "" else l.columnValues(11)) + "," + measureId + "," +quarterEndDate+ ","+ getExceptionString()).cache().saveAsTextFile(prop.getProperty("measure_computation_output_path")  + "/" + wfType  +"/" + measureId+ "/" +quarterEndDate + "/exception")
        notMetRDD.map(l => (if(l.isNullAt(0) ) "" else l.columnValues(0)) + "," + (if(l.isNullAt(1) ) "" else l.columnValues(1)) + "," + (if(l.isNullAt(2) ) "" else l.columnValues(2)) + "," + (if(l.isNullAt(3) ) "" else l.columnValues(3)) + "," + (if(l.isNullAt(4) ) "" else l.columnValues(4))  + "," + (if(l.isNullAt(5) ) "" else l.columnValues(5)) + "," + (if(l.isNullAt(6) ) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))+ "," + (if(l.isNullAt(7) ) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))+ "," + (if(l.isNullAt(8) ) "" else l.columnValues(8)) + "," + (if(l.isNullAt(9) ) "" else l.columnValues(9)) + "," + (if(l.isNullAt(10) ) "" else l.columnValues(10)) + "," + (if(l.isNullAt(11) ) "" else l.columnValues(11)) + "," + measureId + "," +quarterEndDate+ ","+ getNotMetString()).cache().saveAsTextFile(prop.getProperty("measure_computation_output_path")  + "/" + wfType +"/" +measureId+ "/" +quarterEndDate+"/notMet")
    */

    notEligibleRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getNotEligiblePopulationString()).cache().saveAsTextFile(path + "/notEligible")
    exclusionRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getExclusionString()).cache().saveAsTextFile(path + "/exclusion")
    metRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getMetString()).cache().saveAsTextFile(path + "/met")
    exceptionRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getExceptionString()).cache().saveAsTextFile(path+ "/exception")
    notMetRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getNotMetString()).cache().saveAsTextFile(path+ "/notMet")



//    hdfs.close()
  }

//  def deletePriviousBatch(): Unit =
//  {
//    val hdfs= FileSystem.get(new SparkUtility().getSparkContext().sparkContext.hadoopConfiguration)
//    if(hdfs.isDirectory(new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType)))
//      hdfs.delete(new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType),true)
//    println("Deleted directory path: "+prop.getProperty("measure_computation_output_path") + "/" + wfType)
//    hdfs.close()
//  }

  def measureLogger(r: CassandraRow, measureName: String, conditionType: String, conditionName: String, elementName: String, status: Boolean, description : String): Unit = {
    try{
      //var logStr=""+measureName +"~"+quarterEndDate +"~"+wfType +"~"+r.getString("practiceuid")+"~"+ r.getString("patientuid")+"~"+ r.getString("visituid") + "~" + conditionType + "~" + conditionName + "~" + elementName + "~" + status + "~" + description
      var logStr = "" + measureName + "~" + r.getString("practiceuid") + "~" + r.getString("patientuid") + "~" + r.getString("visituid") + "~" + conditionType + "~" + conditionName + "~" + elementName + "~" + status + "~" + description
      loggerObj.warn(logStr)
    }
    catch {
      case e: Exception => println(e.printStackTrace)
    }
/*
    if(File(fileUtility.getProperty("file.output.path.log") ).exists)
    File(fileUtility.getProperty("file.output.path.log") ).appendAll(r.getString("practiceuid")+"~"+ measureName +"~"+r.getString("patientuid")+"~"+ r.getString("visituid") + "~" + conditionType + "~" + conditionName + "~" + elementName + "~" + status + "~" + description  + "\n")
    else {
      File(fileUtility.getProperty("file.output.path.log") ).createFile()
      File(fileUtility.getProperty("file.output.path.log") ).appendAll(r.getString("practiceuid")+"~"+ measureName +"~"+r.getString("patientuid")+"~"+ r.getString("visituid") + "~" + conditionType + "~" + conditionName + "~" + elementName + "~" + status + "~" + description  + "\n")
    }
*/



    // log.info(r.getString("practiceuid") + "," + r.getString("patientuid") + "," + r.getString("visituid") + "," + measureName + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description)

/*      val file=File(logFile)

       if (file.exists)
         file.appendAll(r.getString("practiceuid") + "~" +measureName + "~" +r.getString("patientuid") + "~" +r.getString("visituid") + "~" +conditionType + "~" +conditionName + "~" +elementName + "~" +status + "~" +description + "\n")
       else{
         file.createFile(true)
         file.appendAll(r.getString("practiceuid") + "~" +measureName + "~" +r.getString("patientuid") + "~" +r.getString("visituid") + "~" +conditionType + "~" +conditionName + "~" +elementName + "~" +status + "~" +description + "\n")
       }*/


    //hdfsConf.append(new org.apache.hadoop.fs.Path(fileUtility.getProperty("file.output.path")+"/"+measureName+"/"+measureName+".log")).writeBytes(r.getString("practiceuid")+","+ measureName +","+r.getString("patientuid")+","+ r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description  + "\n")

//        @transient lazy val hdfs= FileSystem.get(new SparkUtility().getSparkContext().sparkContext.hadoopConfiguration)


/*
        val path=new org.apache.hadoop.fs.Path(fileUtility.getProperty("file.output.path")+"/"+measureName+"/"+measureName+".log")
        //@transient lazy val oStream=hdfsConf.create(path)
        //oStream.writeUTF(r.getString("practiceuid")+","+ measureName +","+r.getString("patientuid")+","+ r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description  + "\n")
        //logarray.add(r.getString("practiceuid")+","+ measureName +","+r.getString("patientuid")+","+ r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description  + "\n")
        if(hdfsConf.isFile(path))
          hdfsConf.append(path).writeBytes(r.getString("practiceuid") + "," + measureName + "," + r.getString("patientuid") + "," + r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description + "\n")
        else {
          hdfsConf.create(path)
          hdfsConf.append(path).writeBytes(r.getString("practiceuid") + "," + measureName + "," + r.getString("patientuid") + "," + r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description + "\n")
        }*/

  }




  //**** Bharati
  def medianRDD(sparkSession: SparkSession,rdd:RDD[CassandraRow]): RDD[(CassandraRow,CassandraRow)]= {
    val EMrdd = sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"), prop.getProperty("keyspace_datamart_table_name_emergencydept_master"))
    //val EMrdd = sparkSession.sparkContext.cassandraTable("acep2018", "emergencydept_master")

    val tblrdd1 = rdd.map(x => (x.getString("servicelocationuid"), x))
    val emrdd = EMrdd.map(x => (x.getString("practiceuid"), x))
    val tblemRDD = tblrdd1.join(emrdd)
    val JoinRdd = tblemRDD.map(l => l._2)
    return JoinRdd
  }


  def getRDDEmergencyMaster(sparkSession: SparkSession,checkValue: String, Value: Int): Set[String] = {
    var rdd =  sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"), prop.getProperty("keyspace_datamart_table_name_emergencydept_master"))
      .where(s"$checkValue >= ?", s"$Value").map(x=>x.getString("practiceuid")).collect().toSet
    return rdd
  }

  def chkValueRangeGreaterOrEqualMedian1(sparkSession: SparkSession,checkValue: String, Value: Int): Set[String] = {
    var rdd =  sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"), prop.getProperty("keyspace_datamart_table_name_emergencydept_master"))
      .where(s"$checkValue >= ?", s"$Value").map(x=>x.getString("practiceuid")).collect().toSet
    return rdd
  }
  def chkValueFreestanding_EDMedian1(sparkSession: SparkSession,checkValue: String, Value: String): Set[String] = {
    var rdd =  sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"), prop.getProperty("keyspace_datamart_table_name_emergencydept_master"))
      .where(s"$checkValue = ?", s"$Value").map(x=>x.getString("practiceuid")).collect().toSet
    return rdd
  }
  def chkValueRangeLessorEqualMedian1(sparkSession: SparkSession,checkValue: String, Value: Int): Set[String] = {
    var rdd =  sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"), prop.getProperty("keyspace_datamart_table_name_emergencydept_master"))
      .where(s"$checkValue <= ?", s"$Value").map(x=>x.getString("practiceuid")).collect().toSet
    return rdd
  }
  def chkValueRangeGreaterOrLesserOrEqualMedian1(sparkSession: SparkSession,checkValue: String,LesserValue: Int, GreaterValue: Int): Set[String] = {
    var rdd =  sparkSession.sparkContext.cassandraTable(prop.getProperty("keyspace_datamart"), prop.getProperty("keyspace_datamart_table_name_emergencydept_master"))
      .where(s"$checkValue >= ? and $checkValue<=?", s"$LesserValue", s"$GreaterValue" ).map(x=>x.getString("practiceuid")).collect().toSet
    return rdd
  }

  def chkValueRangeGreaterOrEqualMedian(r: CassandraRow,r1: CassandraRow, conditionType: String, measureName: String,checkValue:String, Value: Int): Boolean = {
    val isExist = !r1.isNullAt(checkValue) && r1.getInt(checkValue) >= Value
    if (isExist)
      message= checkValue+ " is greater than or equal to ("+ Value +")"
    else
      message= checkValue +" is not greater than or equal to ("+ Value +") "
    measureLogger(r, measureName, conditionType, "chkValueRangeGreaterOrEqualMedian", checkValue, isExist,message)
    return isExist;
  }

  def chkValueRangeBetweenValueMedian(r: CassandraRow,r1: CassandraRow, conditionType: String, measureName: String,checkValue:String, GreaterValue: Int, LesserValue:Int): Boolean = {
    val isExist = !r1.isNullAt(checkValue) && (r1.getInt(checkValue) <= GreaterValue)  && (r1.getInt(checkValue) >= LesserValue)
    if (isExist)
      message= checkValue+ " is between "+ GreaterValue +" and "+ LesserValue
    else
      message= checkValue + " is not in between "+ GreaterValue +" and "+ LesserValue
    measureLogger(r, measureName, conditionType, "chkValueRangeBetweenValueMedian", checkValue, isExist,message)
    return isExist;
  }

  def chkValueRangeLessorEqualMedian(r: CassandraRow,r1: CassandraRow, conditionType: String, measureName: String,checkValue:String, Value: Int): Boolean = {
    val isExist =  !r1.isNullAt(checkValue) && r1.getInt(checkValue) <= Value
    if (isExist)
      message= checkValue+ " is less than or equal to ("+ Value +")"
    else
      message= checkValue +" is not less than or equal to ("+ Value +") "
    measureLogger(r, measureName, conditionType, "chkValueRangeLessorEqualMedian", checkValue, isExist,message)
    return isExist;
  }

  def median(inputList: List[Double]): Double = {
    val count = inputList.size
    if (count % 2 == 0) {
      val l = count / 2 - 1
      val r = l + 1
      return (inputList(l) + inputList(r)) / 2
    } else
      return inputList(count / 2)
  }

 /* def saveToWebDM_median(practiceRdd: RDD[(AnyRef,Double,Int)],providerRdd: RDD[(AnyRef,Double,Int)], locationRdd: RDD[(AnyRef,Double,Int)],measureId: String): Unit = {

    var quarterEndDate = prop.getProperty("quarterEndDate").trim
    var wfType = prop.getProperty("wfType").trim

    var path=new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path")+ "/" + wfType + "/" + measureId + "/" + quarterEndDate)
    if(hdfs.isDirectory(path))
      hdfs.delete(path,true)

    practiceRdd.map(l => l._1.toString +"~" +l._2 +"~" +l._3 +"~" + measureId + "~" + quarterEndDate+"~"+wfType).coalesce(50).cache().saveAsTextFile(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId + "/" + quarterEndDate + "/practice")
    providerRdd.map(l => l._1.toString +"~" +l._2 +"~" +l._3 +"~" + measureId + "~" + quarterEndDate+"~"+wfType).coalesce(50).cache().saveAsTextFile(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId + "/" + quarterEndDate + "/provider")
    locationRdd.map(l => l._1.toString +"~" +l._2 +"~" +l._3 +"~" + measureId + "~" + quarterEndDate+"~"+wfType).coalesce(50).cache().saveAsTextFile(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId + "/" + quarterEndDate + "/location")

    hdfs.close()
  }*/



  //Akansh

  def chkDateDiffHoursLess_ThanHours(r: CassandraRow, conditionType: String, measureName: String,firstDate: String, secondDate: String,hours :Int): Boolean =
  {
    var cDate=""
    if (!r.isNullAt(secondDate)){ cDate= convertDateToDDMMYYYY(r.getDate(secondDate).toString)}else{cDate= secondDate}
    var fDate=""
    if (!r.isNullAt(firstDate)){ fDate= convertDateToDDMMYYYY(r.getDate(firstDate).toString)}else{fDate= firstDate}

    val isExist = !r.isNullAt(firstDate) && !r.isNullAt(secondDate) && (dateUtility.get_DateDiffHours_lessthan(r.getDateTime(firstDate),r.getDateTime(secondDate),hours))

    if (isExist)
      message= "Date Difference between "+fDate+ " and "+ cDate+" is less than "+hours+" hours"
    else
      message= "Date Difference between "+fDate+ " and "+ cDate+" is Not less than "+hours+" hours"
    measureLogger(r, measureName, conditionType, "chkDateDiffHoursLess_ThanHours", firstDate, isExist, message)
    return isExist;
  }


  def chkDateDiffHoursGreaterThan_Or_Equal_Hours(r: CassandraRow, conditionType: String, measureName: String,firstDate: String, secondDate: String,hours :Int): Boolean =
  {
    var cDate=""
    if (!r.isNullAt(secondDate)){ cDate= convertDateToDDMMYYYY(r.getDate(secondDate).toString)}else{cDate= secondDate}
    var fDate=""
    if (!r.isNullAt(firstDate)){ fDate= convertDateToDDMMYYYY(r.getDate(firstDate).toString)}else{fDate= firstDate}

    val isExist = !r.isNullAt(firstDate) && !r.isNullAt(secondDate) && (dateUtility.get_DateDiffHours_lessthan(r.getDateTime(firstDate),r.getDateTime(secondDate),hours))

    if (isExist)
      message= "Date Difference between "+fDate+ " and "+ cDate+" is greater than "+hours+" hours"
    else
      message= "Date Difference between "+fDate+ " and "+ cDate+" is Not less than "+hours+" hours"
    measureLogger(r, measureName, conditionType, "chkDateDiffHoursGreaterThan_Or_Equal_Hours", firstDate, isExist, message)
    return isExist;
  }

  // Measure 25

  def convertDateToYYYYDDMM(dateString:String): String ={
    //println("::::::::::::::::::::::::::::::::"+dateString)
    return LocalDateTime.parse(dateString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
  }



  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  def MR_chk_TBusr_NonTbusr(r: CassandraRow, conditionType: String, measureName: String, checkDate:String,checkDate2: String,chkelmnt1:String,chkelmnt2:String): Boolean = {
    val first = !r.isNullAt(checkDate) && (returnDate(r,checkDate,checkDate2) != null) && r.getDate(checkDate).after(returnDate(r,checkDate,checkDate2)) && checkElementPresent(r, conditionType, measureName, chkelmnt1)
    val second = !r.isNullAt(checkDate2) && (returnDate(r,checkDate,checkDate2) != null) && r.getDate(checkDate2).after(returnDate(r,checkDate2,checkDate)) && checkElementPresent(r, conditionType, measureName, chkelmnt2)
    var Status=if (first) {true } else if (second) {false } else {false}

    return Status
  }



  def returnDate(r:CassandraRow,checkDate:String,checkDate2: String): Date={
    val ExistDate : Date = if(!r.isNullAt(checkDate2)){ r.getDate(checkDate2)} else r.getDate(checkDate)
    return ExistDate
  }

  def MR_checkElementStatus(r: CassandraRow, conditionType: String, measureName: String, Tbc_usr_status:Boolean ,Usr_Nusr_cond:Boolean ): Boolean = {

    val isExist = (Tbc_usr_status == Usr_Nusr_cond)

    if (Tbc_usr_status)
      message= "User is Non Tobacco user "
    else
      message= "User is  Tobacco user  "
    measureLogger(r, measureName, conditionType,"MR_checkelementvalue","tobacco_user",isExist,message )
    return isExist
  }


  def chkDateRangeExistMinusDays(r: CassandraRow, conditionType: String, measureName: String, elementName: String, startDate: Date, endDate: Date, Days: Int): Boolean = {

    var dt : Date = startDate
    var dateBefore = new Date(dt.getTime - (24*3600*1000)*Days );


    var sDate= convertDateToDDMMYYYY(startDate.toString)
    var eDate= convertDateToDDMMYYYY(endDate.toString)


    val isExist = !r.isNullAt(elementName) && ((
      r.getDate(elementName).after(dateBefore)  &&
      r.getDate(elementName).before(endDate)
      )|| r.getDate(elementName).equals(dateBefore)|| r.getDate(elementName).equals(endDate)
      )

    if (isExist)
      message= elementName+ " Found In Date Range ("+ sDate+", "+eDate+")"
    else
      message= elementName +" Not Found In Date Range ("+ sDate+", "+eDate+") "
    measureLogger(r, measureName, conditionType, "chkDateRangeExistMinusDays", elementName, isExist,message)
    return isExist;
  }



  //Ajinkya
  // function for chkDateRangeExistPlusDay
  def chkDateRangeExistPlusDays(r: CassandraRow, conditionType: String, measureName: String, elementName: String, startDate: Date, endDate: Date, Days: Int): Boolean = {
    var sDate= convertDateToDDMMYYYY(startDate.toString)
    var eDate= convertDateToDDMMYYYY(endDate.toString)


    var dt : Date = endDate //endDate
    var dateBefore = new Date(dt.getTime + (24*3600*1000)*Days);


    val isExist = !r.isNullAt(elementName) && ((
      r.getDate(elementName).after(startDate)  &&
      r.getDate(elementName).before(dateBefore)
      )|| r.getDate(elementName).equals(startDate)|| r.getDate(elementName).equals(dateBefore)
      )
    if (isExist)
      message= elementName+ " Found In Date Range ("+ sDate+", "+eDate+")"
    else
      message= elementName +" Not Found In Date Range ("+ sDate+", "+eDate+") "
    measureLogger(r, measureName, conditionType, "chkDateRangeExistPlusDays", elementName, isExist,message)
    return isExist;
  }

  /*def saveRDD(MEASURE_NAME:String,ippRDD:RDD[CassandraRow],locationRDD:RDD[(AnyRef,Double,Int)]): Unit ={
    println("ACEP " + MEASURE_NAME)
    if (DataMartCreator.debugMode == 1) {
      println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
      println("ACEP " + MEASURE_NAME + " *** locationRdd    ***" + locationRDD.count())
    }
    else {
      saveToWebDM_median(locationRDD, MEASURE_NAME)
      postgresUtilityObj.insertIntoProcessDetails(MEASURE_NAME, "", "", "Measure computation done successfully", "PASS")
    }

    locationRDD.unpersist(true);
  }
*/
   def saveToWebDM_median(locationRdd: RDD[(AnyRef, Double, Int)], measureId: String): Unit = {
    var quarterEndDate = prop.getProperty("quarterEndDate").trim
    var wfType = prop.getProperty("wfType").trim

//    val hdfsConf= FileSystem.get(sparkUtility.getSparkContext().sparkContext.hadoopConfiguration)
    var path=new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path")+ "/" + wfType + "/" + measureId + "/" + quarterEndDate)
    if(hdfsConf.isDirectory(path))
      hdfsConf.delete(path,true)

    locationRdd.filter(r=>if (r._1!="") true else false).map(l => if (l._1!="" && l._2!="" && l._3!="") { l._1  +"~" + l._2 +"~" + l._3 +"~" + measureId + "~" + quarterEndDate+"~"+wfType}).cache().saveAsTextFile(path + "/location")
//    hdfsConf.close()

    //if (l.isNullAt(0)) "" else l.columnValues(0)
  }


  def saveRDD(MEASURE_NAME:String,ippRDD:RDD[(AnyRef,AnyRef,AnyRef,Double)],practiceRDD:RDD[(AnyRef,Double,Int)],
               locationRDD:RDD[(AnyRef,AnyRef,Double,Int)]
               ,providerRDD:RDD[(AnyRef,AnyRef,Double,Int)],providerLocationRDD:RDD[(AnyRef,AnyRef,AnyRef,Double,Int)]): Unit ={

    if (DataMartCreator.debugMode == 1) {
      println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
      println("ACEP " + MEASURE_NAME + " *** practiceRDD    ***" + practiceRDD.count())
      println("ACEP " + MEASURE_NAME + " *** locationRdd    ***" + locationRDD.count())
      println("ACEP " + MEASURE_NAME + " *** ProviderRdd    ***" + providerRDD.count())
      println("ACEP " + MEASURE_NAME + " *** Provider+locationRdd   ***" + providerLocationRDD.count())
    }
    else {
      saveToWebDM_MD(practiceRDD,locationRDD,providerRDD,providerLocationRDD, MEASURE_NAME)
      postgresUtilityObj.insertIntoProcessDetails(MEASURE_NAME, "", "", "Measure computation done successfully", "PASS")
    }

    practiceRDD.unpersist(true);
    locationRDD.unpersist(true);
    providerRDD.unpersist(true);
    providerLocationRDD.unpersist(true);

  }
  def saveToWebDM_MD(practiceRDD:RDD[(AnyRef,Double,Int)]
                          ,locationRDD:RDD[(AnyRef,AnyRef,Double,Int)],
                          providerRDD:RDD[(AnyRef,AnyRef,Double,Int)],providerLocationRDD:RDD[(AnyRef,AnyRef,AnyRef,Double,Int)],
                          measureId: String): Unit = {
    var quarterEndDate = prop.getProperty("quarterEndDate").trim
    var wfType = prop.getProperty("wfType").trim


    var path=new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path")+ "/" + wfType + "/" + measureId + "/" + quarterEndDate)
    if(hdfsConf.isDirectory(path))
      hdfsConf.delete(path,true)

    practiceRDD.filter(r=>if (r._1!="") true else false).map(l => if (l._1!="" && l._2!="" && l._3!="") { l._1  +"~" + l._2 +"~" + l._3 +"~" + measureId + "~" + quarterEndDate+"~"+wfType}).cache().saveAsTextFile(path + "/practice")
    locationRDD.filter(r=>if (r._1!="") true else false).map(l => if (l._1!="" && l._2!="" && l._3!="" && l._4!="") { l._1  +"~" + l._2 +"~" + l._3 +"~" + l._4 +"~" + measureId + "~" + quarterEndDate+"~"+wfType}).cache().saveAsTextFile(path + "/location")
    providerRDD.filter(r=>if (r._1!="") true else false).map(l => if (l._1!="" && l._2!="" && l._3!="" && l._4!="") { l._1  +"~" + l._2 +"~" + l._3 +"~" + l._4 +"~" + measureId + "~" + quarterEndDate+"~"+wfType}).cache().saveAsTextFile(path + "/provider")
    providerLocationRDD.filter(r=>if (r._1!="") true else false).map(l => if (l._1!="" && l._2!="" && l._3!="" && l._4!="" && l._5!="") { l._1  +"~" + l._2 +"~" + l._3 +"~" + l._4 +"~" + l._5 +"~"+ measureId + "~" + quarterEndDate+"~"+wfType}).cache().saveAsTextFile(path + "/providerlocation")

  }

  // function for chkYearRangeLessThanSecondsArg
  def chkYearRangeLessThanSecondsArg(r: CassandraRow, conditionType: String, measureName:String,checkDate:String, compareDate: String, no_of_year: Int): Boolean = {
    var cDate=""
    if (!r.isNullAt(compareDate)){ cDate= convertDateToDDMMYYYY(r.getDate(compareDate).toString)}else{cDate= compareDate}
    var chkDate=""
    if (!r.isNullAt(checkDate)){ chkDate= convertDateToDDMMYYYY(r.getDate(checkDate).toString)}else{chkDate= checkDate}

    val isExist = !r.isNullAt(checkDate)  && !r.isNullAt(compareDate) &&
      r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate).minusYears(no_of_year))



    if (isExist)
      message= chkDate+ " Less than Year  ("+ cDate+" Minus "+no_of_year+", "+cDate+" minus "+no_of_year+" days)"
    else
      message= chkDate +" Not Less than Year ("+ cDate+" Minus "+no_of_year+", "+cDate+" minus "+no_of_year+" days) "
    measureLogger(r, measureName, conditionType, "chkYearRangeLessThanSecondsArg", checkDate, isExist,message)
    return isExist;
  }

}