package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import org.apache.spark.sql.SparkSession
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast

object ACEP415 extends MeasureUtility with Serializable with MeasureTrait {

  final var MEASURE_NAME = "M415"
  val dateUitilityObj=new DateUtility()
  @transient lazy val postgresUtility=new PostgreUtility()

  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {

    try {

      var columnRef = getFiledList(MEASURE_NAME)
      var rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0), columnRef(1), columnRef(2), columnRef(3), columnRef(4), columnRef(5), columnRef(6), columnRef(7), columnRef(8), columnRef(9), columnRef(10), columnRef(11), columnRef(12), columnRef(13), columnRef(14), columnRef(15), columnRef(16), columnRef(17), columnRef(18), columnRef(19), columnRef(20), columnRef(21), columnRef(22), columnRef(23), columnRef(24), columnRef(25), columnRef(26), columnRef(27), columnRef(28), columnRef(29), columnRef(30), columnRef(31), columnRef(32), columnRef(33), columnRef(34), columnRef(35), columnRef(36), columnRef(37), columnRef(38), columnRef(39), columnRef(40), columnRef(41), columnRef(42), columnRef(43), columnRef(44), columnRef(45), columnRef(46), columnRef(47), columnRef(48), columnRef(49), columnRef(50), columnRef(51), columnRef(52), columnRef(53), columnRef(54), columnRef(55), columnRef(56), columnRef(57), columnRef(58), columnRef(59), columnRef(60), columnRef(61), columnRef(62), columnRef(63), columnRef(64),columnRef(65),columnRef(66),columnRef(67),columnRef(68),columnRef(69),columnRef(70),columnRef(71))
        .where(s"encounterdate>=? and encounterdate<=? "+prop.getProperty("practiceListCondition"),startDate, endDate)
      val dateUtil = new DateUtility();

      println("START*************************" + MEASURE_NAME + "********************************")

//      val CRA = getBackTrackingList(rdd, "anmefoph", "encounterdate");
//      val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)


      // Filter IPP
      var ippRDD =rdd
       .filter(r =>
        (
           chkDateRangeExist(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate)
            &&
            chkDateYearDiffGreaterOrEqual(r, IPP, MEASURE_NAME, "dob", "edv_date", 18) &&
            checkElementPresent(r, IPP, MEASURE_NAME, "edv") &&
             chkDateRangeExist(r, IPP, MEASURE_NAME, "edv_date", startDate, endDate)&&
              (
                (
                  (
                      checkElementPresent(r, IPP, MEASURE_NAME, "hectpe") &&
                      chkDateEqual(r, IPP, MEASURE_NAME, "hectpe_date", "edv_date")
                    )
                    ||
                     (
                        checkElementPresent(r, IPP, MEASURE_NAME, "hdct") &&
                        chkDateEqual(r, IPP, MEASURE_NAME, "hdct_date", "edv_date")
                     )
                  )
                  &&
                  (
                     checkElementValue(r, IPP, MEASURE_NAME,"gcs",15)&&
                      chkDateEqual(r, IPP, MEASURE_NAME, "gcs_date", "edv_date")
                    )
                  &&
                  (
                      checkElementPresent(r, IPP, MEASURE_NAME, "npneheadtrm") &&
                      chkDateEqual(r, IPP, MEASURE_NAME, "npneheadtrm_date", "edv_date")
                    )
//
                /* && // element not found in DB
                 (

                   checkElementPresent(r, IPP, MEASURE_NAME, "doumn_nphdtrm_wthn24hrs_element") //&&
                     chkDateEqual(r, IPP, MEASURE_NAME, "doumn_nphdtrm_wthn24hrs_date", "edv_date")

                   )*/
                )

            ||
            (
                checkElementPresent(r, IPP, MEASURE_NAME, "paprwi24ho_1") &&
                chkDateEqual(r, IPP, MEASURE_NAME, "paprwi24ho_1_date", "npneheadtrm_date")
              )
          )
      )

      ippRDD.cache()




      var exclusionRDD = ippRDD.filter(r =>
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "brntumr")&&
              chkDateEqual(r, EXCLUSION, MEASURE_NAME, "brntumr_date", "edv_date")
          )||
          (
           checkElementPresent(r, EXCLUSION, MEASURE_NAME, "preg") &&
           chkDateEqual(r, EXCLUSION, MEASURE_NAME, "preg_date", "edv_date")
          )
           ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "antiplatthrp") &&
            chkDateRangeLessOrEqual(r, EXCLUSION, MEASURE_NAME, "antiplatthrp_date", "edv_date")
          ) ||
          (
           checkElementPresent(r, EXCLUSION, MEASURE_NAME, "vntrishnt")&&
             chkDateEqual(r, EXCLUSION, MEASURE_NAME, "vntrishnt_date", "edv_date")
          )
           ||
           ( checkElementPresent(r, EXCLUSION, MEASURE_NAME, "cofohect") &&
            chkDateRangeLessOrEqual(r, EXCLUSION, MEASURE_NAME, "cofohect_date", "npneheadtrm_date")
           )
           ||
             ( checkElementPresent(r, EXCLUSION, MEASURE_NAME, "trmaexcluhd") &&
               chkDateRangeLessOrEqual(r, EXCLUSION, MEASURE_NAME, "trmaexcluhd_date", "edv_date")
             )
      )
       var staggingRDD = ippRDD.subtract(exclusionRDD).cache()

      var metRDD = staggingRDD.filter(r =>
        (
          chkDateYearDiffGreaterOrEqual(r, MET, MEASURE_NAME, "dob", "edv_date", 65)
            ||
            (
              (
                checkElementPresent(r, MET, MEASURE_NAME, "hdac") &&
                  chkDateEqual(r, MET, MEASURE_NAME, "hdac_date", "edv_date") &&
                  checkElementPresent(r, MET, MEASURE_NAME, "seve")
                )
                ||
                (
                  checkElementPresent(r, MET, MEASURE_NAME, "vomit") &&
                    chkDateEqual(r, MET, MEASURE_NAME, "vomit_date", "edv_date")
                  )
                ||
                (

                  checkElementPresent(r, MET, MEASURE_NAME, "phylsignbslesklfrctr") &&
                    chkDateEqual(r, MET, MEASURE_NAME, "phylsignbslesklfrctr_date", "edv_date")
                  )
                ||
                (

                  checkElementPresent(r, MET, MEASURE_NAME, "fclneurodefct") &&
                    chkDateEqual(r, MET, MEASURE_NAME, "fclneurodefct_date", "edv_date")
                  )
              )
            ||
            (
              (
                checkElementPresent(r, MET, MEASURE_NAME, "coglpths")&&  // coglpths_date,thrmcytopn_date
                  chkDateRangeLessOrEqual(r, MET, MEASURE_NAME, "coglpths_date", "edv_date")
                )
                ||
                (
                  checkElementPresent(r, MET, MEASURE_NAME, "thrmcytopn")&&
                    chkDateRangeLessOrEqual(r, MET, MEASURE_NAME, "thrmcytopn_date", "edv_date")
                  )
                ||
                (
                  checkElementPresent(r, MET, MEASURE_NAME, "anticoag") &&
                    chkDateRangeLessOrEqual(r, MET, MEASURE_NAME, "anticoag_date", "edv_date")
                  )
              )
            ||
            (
              checkElementPresent(r, MET, MEASURE_NAME, "edv") &&
                checkElementPresent(r, MET, MEASURE_NAME, "dngmechinj_grp") &&
                chkDateRangeExist(r, MET, MEASURE_NAME, "edv_date", startDate, endDate)
              )
            ||

            (
              (
                (checkElementPresent(r, MET, MEASURE_NAME, "loss_concusnes") &&
                  chkDateEqual(r, MET, MEASURE_NAME, "loss_concusnes_date", "edv_date")
                  ) ||
                  (checkElementPresent(r, MET, MEASURE_NAME, "potram") &&
                    chkDateEqual(r, MET, MEASURE_NAME, "potram_date", "edv_date"))
                )
                && (
                (chkDateYearDiffGreaterOrEqualAndLessThan(r, MET, MEASURE_NAME, "dob", "encounterdate", 60, 65)
                  ) ||
                  (
                    (
                      checkElementPresent(r, MET, MEASURE_NAME, "hdac") &&
                        chkDateEqual(r, MET, MEASURE_NAME, "hdac_date", "edv_date")) ||
                      (
                        checkElementPresent(r, MET, MEASURE_NAME, "shtemede") &&
                          chkDateEqual(r, MET, MEASURE_NAME, "shtemede_date", "edv_date")) ||
                      (
                        checkElementPresent(r, MET, MEASURE_NAME, "szr_inj_") &&
                          chkDateEqual(r, MET, MEASURE_NAME, "szr_inj__date", "edv_date")) ||
                      (
                        checkElementPresent(r, MET, MEASURE_NAME, "evtrmhdnck") &&
                          chkDateEqual(r, MET, MEASURE_NAME, "evtrmhdnck_date", "edv_date"))
                    )
                  ||
                  checkElementPresent(r, MET, MEASURE_NAME, "drgalintoxi")
                )
              )
            ||
            (
              checkElementPresent(r, MET, MEASURE_NAME, "infoahect") &&
                chkDateRangeGreaterOrEqual(r, MET, MEASURE_NAME, "infoahect_date", "npneheadtrm_date"))
          )
      )

      metRDD.cache()


      // Filter Exceptions
      var exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      // Filter notEligibleRDD
      var notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      var notMetRDD = getNotMet(staggingRDD, metRDD)


      if (DataMartCreator.debugMode == 1) {
        println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notEligibleRDD          ***" + notEligibleRDD.count())
        println("ACEP " + MEASURE_NAME + " *** exclusionRDD          ***" + exclusionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** exceptionRDD ***" + exceptionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** metRDD       ***" + metRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notMetRDD    ***" + notMetRDD.count())
        println("*********************************************************")
      }    else
      { saveToWebDM(notEligibleRDD,exclusionRDD,metRDD, exceptionRDD, notMetRDD, MEASURE_NAME) }


      ippRDD.unpersist(true);
      metRDD.unpersist(true);
      notMetRDD.unpersist(true);
      exceptionRDD.unpersist(true);
      notEligibleRDD.unpersist(true);
      exclusionRDD.unpersist(true);

      postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "", "", "Measure computation done successfully", "PASS")
    }
    catch {
      case e: Exception => {
        println(e.printStackTrace())
        postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "W0001", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
        System.exit(-1)

      }
    }

  }  // IPP RDD content Backtracking

  def BackTracking(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {


    for (x <- CRA.value) {
      if (x != "") {
        //println(r.getString("visituid") + ">>>" + x)
        val back_data = x.split("~")
        val patientid = back_data(0);
        val doumn_nphdtrm_wthn24hrs_element = back_data(1);
        val doumn_nphdtrm_wthn24hrs_date = dateUitilityObj.dateTimeParse(back_data(2));


        if ((!r.isNullAt("edv_date") )
          && ((r.getString("patientuid").equals(patientid) || r.getString("patientuid") == patientid)
          &&(
          doumn_nphdtrm_wthn24hrs_element == "1"
          && (r.getDateTime("edv_date").minusHours(24).isBefore(doumn_nphdtrm_wthn24hrs_date) || (r.getDateTime("edv_date").minusHours(30).equals(doumn_nphdtrm_wthn24hrs_date)))
          )
          )
        ) {

          return true;
        }

      }

    }

    return false;

  }

  def getBackTrackingList(rdd: CassandraTableScanRDD[CassandraRow], backtrackelement1: String, backtrackelement2: String): List[String] = {

   // val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).distinct().collect().toList

   // val IPPFilterExclusionRDD = rdd.filter(x => (ipp_patient_list.contains(x.columnValues(2))))

    var CRA = rdd.select("patientuid",backtrackelement1,backtrackelement2).map(x =>
      if (!x.isNullAt("patientuid")
        && !x.isNullAt(backtrackelement1) && !x.isNullAt(backtrackelement2)) {
        x.getString("patientuid") + "~" + x.getString(backtrackelement1) + "~" + x.getString(backtrackelement2)
      }
      else ""
    )
      .collect()
      .toList

    return CRA;
  }
}

