package com.figmd.janus.measureComputation.equalMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession

object ACEP8 extends MeasureUtility with MeasureTrait{

  final var MEASURE_NAME= "M8"
  @transient lazy val postgresUtility=new PostgreUtility()
  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {
try{
    var columnRef = getFiledList(MEASURE_NAME)
    var rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0), columnRef(1), columnRef(2), columnRef(3), columnRef(4), columnRef(5), columnRef(6), columnRef(7), columnRef(8), columnRef(9), columnRef(10), columnRef(11),columnRef(12),columnRef(13), columnRef(14),columnRef(15),columnRef(16),columnRef(17),columnRef(18))
      .where(s"encounterdate>=? and encounterdate<=? "+prop.getProperty("practiceListCondition"),startDate, endDate)

    val dateUtil = new DateUtility();



    // Filter IPP
    var ippRDD = rdd
      .filter(r =>
//        chkDateRangeExist(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate)          &&
          (
            !r.isNullAt("dob") && !r.isNullAt("ed_visit_arrival_date")
              &&
            dateUtil.getAge(r.getString("dob"),r.getString("ed_visit_arrival_date")) >= 18
              &&
              checkElementPresent(r, IPP, MEASURE_NAME, "ed_crtcl")
              &&
              checkElementPresent(r, IPP, MEASURE_NAME, "discharge")
              &&
              chkDateRangeGreater(r, IPP, MEASURE_NAME, "discharge_date", "ed_visit_arrival_date")

            )

      )
    /*
"(
DateDiff(DD, DOB, ED_Visit_Arrival_date) / 365.23076923074 >= 18
AND ED_Crtcl = 1
AND Discharge = 1
AND Discharge_Date > ED_Visit_Arrival_date
)"
    */


    ippRDD.cache();

    // Filter Met
    var metRDD = ippRDD.filter(r =>
      checkElementPresent(r, MET, MEASURE_NAME, "ct_pe")
        &&
        chkDateRangeBetween(r, MET, MEASURE_NAME, "ct_pe_date", "ed_visit_arrival_date", "ed_visit_departure_date" )

    )

    metRDD.cache()

    // Filter Exceptions
    var exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //exceptionRDD.cache()

    var notMetRDD = getNotMet(ippRDD, metRDD)
    notMetRDD.cache()

    // Filter Exclusions
    var notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //notEligibleRDD.persist()

    // Filter Exclusions
    var exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //exclusionRDD.persist()

    if (DataMartCreator.debugMode == 1) {
      println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
      println("ACEP " + MEASURE_NAME + " *** notEligibleRDD          ***" + notEligibleRDD.count())
      println("ACEP " + MEASURE_NAME + " *** exclusionRDD          ***" + exclusionRDD.count())
      println("ACEP " + MEASURE_NAME + " *** exceptionRDD ***" + exceptionRDD.count())
      println("ACEP " + MEASURE_NAME + " *** metRDD       ***" + metRDD.count())
      println("ACEP " + MEASURE_NAME + " *** notMetRDD    ***" + notMetRDD.count())
      println("*********************************************************")
    }
    else
    { saveToWebDM(notEligibleRDD,exclusionRDD,metRDD, exceptionRDD, notMetRDD, MEASURE_NAME) }

    ippRDD.unpersist(true);
    metRDD.unpersist(true);
    notMetRDD.unpersist(true);
    exceptionRDD.unpersist(true);
    notEligibleRDD.unpersist(true);
    exclusionRDD.unpersist(true);
    postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"","","Measure computation done successfully","PASS")
}
catch {
  case e:Exception=>{
    println(e.printStackTrace())
    postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "W0001", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
    System.exit(-1)

  }
}

  }

}
