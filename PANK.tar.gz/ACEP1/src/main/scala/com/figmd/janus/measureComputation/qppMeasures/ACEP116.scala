package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.measureComputation.cmsMeasures.ACEP146.{BackTracking, EXCLUSION, MEASURE_NAME}
import com.figmd.janus.measureComputation.qppMeasures.ACEP116.chkDateRangeBetweenMinusDays
import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.measureComputation.qppMeasures.ACEP66.{IPP, MEASURE_NAME, chkDateRangeExistMinusDays, getBackTrackingList, _}
import com.figmd.janus.measureComputation.qppMeasures.ACEP93.{MEASURE_NAME, saveToWebDM}
import com.figmd.janus.util._
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD

object ACEP116 extends MeasureUtility with Serializable with MeasureTrait{

  final var MEASURE_NAME= "M116"
  @transient lazy val postgresUtility=new PostgreUtility()
  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {

    try {
      var columnRef = getFiledList(MEASURE_NAME)
      var rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0),columnRef(1),columnRef(2),columnRef(3),columnRef(4),columnRef(5),columnRef(6),columnRef(7),columnRef(8),columnRef(9),columnRef(10),columnRef(11),columnRef(12),columnRef(13),columnRef(14),columnRef(15),columnRef(16),columnRef(17),columnRef(18),columnRef(19),columnRef(20),columnRef(21),columnRef(22),columnRef(23),columnRef(24),columnRef(25),columnRef(26),columnRef(27),columnRef(28),columnRef(29),columnRef(30),columnRef(31),columnRef(32),columnRef(33),columnRef(34),columnRef(35),columnRef(36),columnRef(37),columnRef(38),columnRef(39),columnRef(40),columnRef(41),columnRef(42),columnRef(43),columnRef(44),columnRef(45),columnRef(46),columnRef(47),columnRef(48),columnRef(49),columnRef(50),columnRef(51),columnRef(52),columnRef(53),columnRef(54),columnRef(55),columnRef(56),columnRef(57),columnRef(58),columnRef(59),columnRef(60),columnRef(61),columnRef(62),columnRef(63),columnRef(64),columnRef(65),columnRef(66),columnRef(67),columnRef(68),columnRef(69),columnRef(70),columnRef(71),columnRef(72),columnRef(73),columnRef(74),columnRef(75),columnRef(76),columnRef(77),columnRef(78),columnRef(79),columnRef(80))

      val dateUtil = new DateUtility();

      var sparkObj = new SparkUtility()
      val initialrdd =sparkObj.filterPracticeIdFromInitialRDD(sparkSession, rdd)

      println("START*************************"+MEASURE_NAME+"********************************")
      // Filter IPP
      var ippRDD = initialrdd
        .filter(r =>
          (

          chkDateRangeExist(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate)&&
            (

               (
              chkDateYearDiffGreaterOrEqualAndLessThan(r, IPP, MEASURE_NAME,"dob","encounterdate",18,65)
              )
              &&
              (
              checkElementPresent(r, IPP, MEASURE_NAME, "diseobca") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "ihopsobs") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "hoouclvi") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "hohese")   ||
              checkElementPresent(r, IPP, MEASURE_NAME, "anwevi_1") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "ippexm") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "clvi") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "wrk_mntdis") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "prvmed_em") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "hm_vst") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "obs_cr_dis") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") ||
              checkElementPresent(r, IPP, MEASURE_NAME, "offvstg")
             )
            &&
            (

              checkElementPresent(r, IPP, MEASURE_NAME, "actbr")&&
              chkDateEqual(r,IPP, MEASURE_NAME,"actbr_date","encounterdate")
            )
          )
          )



        )

      ippRDD.cache()

      val CRA = getBackTrackingList(rdd, ippRDD, "antibiotics_dis", "antibiotics_dis_date");

      val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)




      // Filter Exclusions
      val exclusionRDD = ippRDD.filter(r =>
        (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "bctinf") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "otitsmda") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "actsin") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "acph")   ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "acto") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "chrsin") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "infctn_phrnx_lrynx_tnsls_adnds") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "imptgo") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "pneumonia") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "goinanvedi") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "infctn_kdny") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "asymphiv") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "cysfib")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "immndefcncy")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "mlgnancyneoplsm")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "chrncbrnchts")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "emphy")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "bronchiectasis")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "extrnsallrgcalvlts")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "chrobstrctvasthma")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "chrarwyobstrctn")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "pneomconosis")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "tubrclosis")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "infctn_sknstph")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "cycts_uti")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "acnee")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "actlymphdnts")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "infctn_cllts_mstcts_bone")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "intstnlinfctn")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "prtusis")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "lymdses") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "utinfc23") ||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "indioffereor")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "syph_1")||
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "chla")
        )
        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "meex")&&
            chkDateEqual(r,EXCLUSION, MEASURE_NAME,"meex_date","encounterdate")
        )
        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hose_1") &&
          chkDateRangeExist(r, EXCLUSION, MEASURE_NAME, "hose_1_date", startDate, endDate )
        )
        ||
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hospiceservices")
        )
        ||
         (
           checkElementPresent(r, EXCLUSION, MEASURE_NAME, "detoadtohoin") &&
           chkDateRangeBetweenPlusDays(r, EXCLUSION, MEASURE_NAME,"detoadtohoin_date","encounterdate",1)
         )
          ||
          (
            BackTracking(r, EXCLUSION, MEASURE_NAME, CRA_list)
          )
      )
      exclusionRDD.cache()

      var intermediateRDD = ippRDD.subtract(exclusionRDD)


    intermediateRDD.cache()


      // Filter Met

      var metRDD = intermediateRDD.filter(
        r=>(
         (
          (
          checkElementPresent(r, MET, MEASURE_NAME, "antbtcmt") &&
          chkDateRangeBetweenPlusDays(r, MET, MEASURE_NAME,"antbtcmt_date","actbr_date",3)
          )
          ||
           !(
              checkElementPresent(r, MET, MEASURE_NAME, "antibiotics_dis") &&
              chkDateRangeBetweenPlusDays(r, MET, MEASURE_NAME,"antibiotics_dis_date","actbr_date",3)
            )
          )
           &&
            !(
              checkElementPresent(r, MET, MEASURE_NAME, "anme_2") &&
              chkDateRangeBetweenPlusDays(r, MET, MEASURE_NAME,"anme_2_date","actbr_date",3)
              )

        )

      )
      metRDD.cache()

      val notEligibleRDD=sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exceptions
      var exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      var notMetRDD = getNotMet(intermediateRDD, metRDD)

      if (DataMartCreator.debugMode == 1) {
        println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notEligibleRDD          ***" + notEligibleRDD.count())
        println("ACEP " + MEASURE_NAME + " *** exclusionRDDTotal          ***" + exclusionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** intermediateRDD          ***" + intermediateRDD.count())
        println("ACEP " + MEASURE_NAME + " *** metRDD       ***" + metRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notMetRDD    ***" + notMetRDD.count())
        println("*********************************************************")
      }
      else
      { saveToWebDM(notEligibleRDD,exclusionRDD,metRDD, exceptionRDD, notMetRDD, MEASURE_NAME) }


      ippRDD.unpersist(true);
      metRDD.unpersist(true);
      notMetRDD.unpersist(true);
      exceptionRDD.unpersist(true);
      notEligibleRDD.unpersist(true);
      exclusionRDD.unpersist(true);

      postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"","","Measure computation done successfully","PASS")
    }
    catch {
      case e:Exception=>{
        println(e.printStackTrace())
        postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"W0001","CRITICAL",Throwables.getStackTraceAsString(e),"FAIL")

        System.exit(-1)

      }
    }

    def BackTracking(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {
      val flag = false;

      for (x <- CRA.value) {
        if (x != "") {
          //println(r.getString("visituid") + ">>>" + x)
          val back_data = x.split("~")
          val patientid = back_data(0);
          val antibiotics_dis_element = back_data(1);
          val antibiotics_dis_date = dateUtility.dateTimeParse(back_data(2));


          if ((!r.isNullAt("encounterdate") )
            && ((r.getString("patientuid").equals(patientid) || r.getString("patientuid") == patientid)
            &&(
            (antibiotics_dis_element == "1"
              && (
              (r.getDateTime("encounterdate").equals(antibiotics_dis_date)) ||
              (r.getDateTime("encounterdate").minusDays(30).equals(antibiotics_dis_date)) ||
              (r.getDateTime("encounterdate").minusDays(30).isAfter(antibiotics_dis_date)) &&
              (r.getDateTime("encounterdate").isBefore(antibiotics_dis_date))
              )
              )

              )

            )

          ) {

            return true;
          }

        }

      }

      return flag;

    }

    def getBackTrackingList(rdd: CassandraTableScanRDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement2: String): List[String] = {

      val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).distinct().collect().toList

      val IPPFilterExclusionRDD = rdd.select("patientuid",backtrackelement1,backtrackelement2).filter(x => (ipp_patient_list.contains(x.columnValues(2))))

      var CRA = IPPFilterExclusionRDD.map(x =>
        if (!x.isNullAt("patientuid")
          && !x.isNullAt(backtrackelement1) && !x.isNullAt(backtrackelement2)) {
          x.getString("patientuid") + "~" + x.getString(backtrackelement1) + "~" + x.getString(backtrackelement2)
        }
        else ""
      )
        .collect()
        .toList

      return CRA;
    }
  }

}
