package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.DataMartCreator.prop

import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession

object ACEP416 extends MeasureUtility with MeasureTrait{

  var MEASURE_NAME= "M416"
  @transient lazy val postgresUtility=new PostgreUtility()
  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {

try{
  val columnRef = getFiledList(MEASURE_NAME)
  val rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0), columnRef(1), columnRef(2), columnRef(3), columnRef(4), columnRef(5), columnRef(6), columnRef(7), columnRef(8), columnRef(9),columnRef(10), columnRef(11), columnRef(12), columnRef(13), columnRef(14), columnRef(15), columnRef(16), columnRef(17), columnRef(18), columnRef(19),columnRef(20),columnRef(21), columnRef(22), columnRef(23), columnRef(24), columnRef(25), columnRef(26),columnRef(27),columnRef(28),columnRef(29), columnRef(30), columnRef(31), columnRef(32),columnRef(33),columnRef(34),columnRef(35),columnRef(36),columnRef(37),columnRef(38),columnRef(39),columnRef(40),columnRef(41),columnRef(42),columnRef(43),columnRef(44),columnRef(45),columnRef(46),columnRef(47),columnRef(48),columnRef(49),columnRef(50),columnRef(51))
    .where(s"encounterdate>=? and encounterdate<=? "+prop.getProperty("practiceListCondition"),startDate, endDate)

    val dateUtility = new DateUtility()

    // Filter IPP
    val ippRDD = rdd
      .filter(r =>
            //chkDateRangeExist(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&
            (
              chkDateYearDiffGreaterOrEqualAndLessThan(r, IPP, MEASURE_NAME,"dob","edv_date",2,18)&&
                checkElementPresent(r, IPP, MEASURE_NAME, "edv")
                &&
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "paprwi24ho") &&
                    chkDateEqual(r, IPP, MEASURE_NAME,"paprwi24ho_date", "edv_date")
                  ||
                    (
                      checkElementPresent(r, IPP, MEASURE_NAME, "doumn_nphdtrm_wthn24hrs") &&
                      chkDateRangeLessOrEqual(r, IPP, MEASURE_NAME, "doumn_nphdtrm_wthn24hrs_date", "edv_date") &&
                      checkElementPresent(r, IPP, MEASURE_NAME, "npneheadtrm") &&
                        chkDateEqual(r, IPP, MEASURE_NAME,"npneheadtrm_date", "edv_date")
                    )
                  &&
                    (
                      checkElementValue(r, IPP, MEASURE_NAME, "gcs",15) &&
                        chkDateEqual(r, IPP, MEASURE_NAME,"gcs_date","edv_date")
                    )
                  &&
                    (
                        (
                          checkElementPresent(r, IPP, MEASURE_NAME, "hdct") &&
                            chkDateEqual(r, IPP, MEASURE_NAME,"hdct_date","edv_date")
                        )
                      ||
                        (
                            checkElementPresent(r, IPP, MEASURE_NAME, "hdctprfrmd") &&
                              chkDateEqual(r, IPP, MEASURE_NAME,"hdctprfrmd_date","edv_date")
                        )

                    )

                )

              )
      )

    ippRDD.cache()

     val exclusionRDD=ippRDD.filter(r =>
      (
        checkElementPresent(r, IPP, MEASURE_NAME, "brntumr") ||
        checkElementPresent(r, IPP, MEASURE_NAME, "coglpths") ||
        checkElementPresent(r, IPP, MEASURE_NAME, "thrmcytopn") ||
        //checkElementPresent(r, IPP, MEASURE_NAME, "vntrishtn") || // element not found
        checkElementPresent(r, IPP, MEASURE_NAME, "mudi")
      )
 )


    exclusionRDD.cache()


    var intermediateRDDA = getinterRDD(ippRDD, exclusionRDD).cache()


    val metRDD = intermediateRDDA.filter(r =>
  (
   !(
     (
       (
        checkElementPresent(r, MET, MEASURE_NAME, "loss_concusnes") &&
          chkDateEqual(r, MET, MEASURE_NAME, "loss_concusnes_date","edv_date")
       )
       &&
       (
        checkElementPresent(r, MET, MEASURE_NAME,"phylsignbslesklfrctr") &&
          chkDateEqual(r, MET, MEASURE_NAME,"phylsignbslesklfrctr_date","edv_date")
        )
        &&
          (
             checkElementPresent(r, MET, MEASURE_NAME,"hdac") &&
               chkDateEqual(r, MET, MEASURE_NAME,"hdac_date","edv_date")
          )
          &&
         (
            checkElementPresent(r, MET, MEASURE_NAME,"signaltmenstats") &&
              chkDateEqual(r, MET, MEASURE_NAME,"signaltmenstats_date","edv_date")
          )&&
          (
           checkElementPresent(r, MET, MEASURE_NAME,"vomit") &&
             chkDateEqual(r, MET, MEASURE_NAME,"vomit_date","edv_date")
          )
         &&
         (
           checkElementPresent(r, MET, MEASURE_NAME,"dngmechinj_grp") &&
            chkDateRangeExist(r, IPP, MEASURE_NAME, "dngmechinj_grp_date", startDate, endDate)
         )
         &&
         (
          checkElementPresent(r, MET, MEASURE_NAME,"seve") &&
            chkDateEqual(r, MET, MEASURE_NAME,"seve_date","edv_date")
         )
       )
     )||
       (
         checkElementPresent(r, MET, MEASURE_NAME,"peprru") &&
           chkDateEqual(r, MET, MEASURE_NAME,"peprru_date","edv_date")
       )
      )
    )
   metRDD.cache()

    var intermediateRDDB = getinterRDD(intermediateRDDA,metRDD)

    val exceptionRDD = intermediateRDDB.filter(r =>(
      /*(
        checkElementPresent(r, IPP, MEASURE_NAME, "signsltmenstats") &&
          chkDateRangeLessOrEqual(r, IPP, MEASURE_NAME, "signsltmenstats_date","edv_date")
        )*/
      //  &&
        (
          checkElementPresent(r, IPP, MEASURE_NAME,"vomit") &&
            chkDateEqual(r, MET, MEASURE_NAME,"vomit_date","edv_date")
          )
        &&
        (
          checkElementPresent(r, IPP, MEASURE_NAME,"edv") &&
            checkElementPresent(r, IPP, MEASURE_NAME,"dngmechinj_grp") &&
            chkDateEqual(r, MET, MEASURE_NAME,"dngmechinj_grp_date","edv_date")
          )
         ||
         (
          checkElementPresent(r, IPP, MEASURE_NAME,"peprru")&&
            chkDateEqual(r, MET, MEASURE_NAME,"peprru_date","edv_date")
          )

      ))
    exceptionRDD.cache()

    

    var notMetRDD = getNotMet(intermediateRDDB, exceptionRDD)


    val notEligibleRDD=sparkSession.sparkContext.emptyRDD[CassandraRow]


    if (DataMartCreator.debugMode == 1) {
      println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
      println("ACEP " + MEASURE_NAME + " *** notEligibleRDD          ***" + notEligibleRDD.count())
      println("ACEP " + MEASURE_NAME + " *** exclusionRDD          ***" + exclusionRDD.count())
      println("ACEP " + MEASURE_NAME + " *** exceptionRDD ***" + exceptionRDD.count())
      println("ACEP " + MEASURE_NAME + " *** metRDD       ***" + metRDD.count())
      println("ACEP " + MEASURE_NAME + " *** notMetRDD    ***" + notMetRDD.count())
      println("*********************************************************")
    }    else
    { saveToWebDM(notEligibleRDD,exclusionRDD,metRDD, exceptionRDD, notMetRDD, MEASURE_NAME) }

    ippRDD.unpersist(true);
    metRDD.unpersist(true);
    notMetRDD.unpersist(true);
    exceptionRDD.unpersist(true);
    notEligibleRDD.unpersist(true);
    exclusionRDD.unpersist(true);

  postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"","","Measure computation done successfully","PASS")
}

catch {
  case e: Exception => {
    println(e.printStackTrace())
    postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "W0001", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
    System.exit(-1)

  }
}
  }
}