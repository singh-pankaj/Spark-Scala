package com.figmd.janus.constants

object Constant{

 final val AND = "&"
 final val OR = "||"
 final val FIELD_SEPARATOR = ","

}
