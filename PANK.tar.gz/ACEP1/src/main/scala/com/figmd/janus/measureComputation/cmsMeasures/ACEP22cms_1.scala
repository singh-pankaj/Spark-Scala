package com.figmd.janus.measureComputation.cmsMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.util._
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD

object ACEP22cms_1 extends MeasureUtility with MeasureTrait {

  var MEASURE_NAME = "M22cms"


  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {

    try {

      val columnRef = getFiledList(MEASURE_NAME)
      val rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0), columnRef(1), columnRef(2), columnRef(3), columnRef(4), columnRef(5), columnRef(6), columnRef(7), columnRef(8), columnRef(9), columnRef(10), columnRef(11), columnRef(12),columnRef(13), columnRef(14), columnRef(15), columnRef(16), columnRef(17), columnRef(18), columnRef(19), columnRef(20), columnRef(21), columnRef(22), columnRef(23), columnRef(24), columnRef(25), columnRef(26), columnRef(27), columnRef(28), columnRef(29),columnRef(30), columnRef(31),columnRef(32),columnRef(33),columnRef(34),columnRef(35),columnRef(36),columnRef(37),columnRef(38),columnRef(39),columnRef(40),columnRef(41),columnRef(42),columnRef(43),columnRef(44),columnRef(45),columnRef(46),columnRef(47),columnRef(48),columnRef(49),columnRef(50),columnRef(51),columnRef(52),columnRef(53),columnRef(54),columnRef(55),columnRef(56),columnRef(57),columnRef(58),columnRef(59),columnRef(60),columnRef(61),columnRef(62),columnRef(63),columnRef(64),columnRef(65),columnRef(66),columnRef(67),columnRef(68),columnRef(69),columnRef(70),columnRef(71),columnRef(72),columnRef(73),columnRef(74))

      var sparkObj = new SparkUtility()
      val initialrdd =sparkObj.filterPracticeIdFromInitialRDD(sparkSession, rdd)

      val objPostgre = new PostgreUtility()

      val dateUtility = new DateUtility()
      //rdd.cache()


      // Filter IPP
      val ippRDD = initialrdd
        //val ippRDD = rdd
        .filter(r =>
        chkDateRangeExist(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&
          chkDateYearDiffGreaterOrEqual(r, IPP, MEASURE_NAME, "dob","encounterdate",18)&&
          (
            checkElementPresent(r, IPP, MEASURE_NAME, "bpscenco")&&
            chkDateRangeExist(r, IPP, MEASURE_NAME, "bpscenco_date", startDate, endDate)

            )
      )
      ippRDD.cache()

      val CRA = getBackTrackingList(rdd, ippRDD, "syblpr", "syblpr_date","diblpr","diblpr_date");

      var BackTrackingMost = rdd.map(l => ((l.isNullAt(3)),( (l.isNullAt(35) , l.isNullAt(36),l.isNullAt(68)))))
        .reduceByKey((x, y)=> ((if((x._1)>y._1) {x._1} else {y._1},if((x._2)>y._2) {x._2} else {y._2},if((x._3)>y._3){x._3} else {y._3})))

     val BackTrackingMostList: Broadcast[List[String]] =sparkSession.sparkContext.broadcast(CRA)



/* MostRecent element Rename  ****************** DO NOt REMOVED***********

      MostRecentBP_QPP=DiBlPr,
      MostRecentSP_QPP=SyBlPr,
      MostRecentSP_QPP_Date=syblpr_date,
      MostRecentBP_QPP_Date=diblpr_date
      LastYearMostRecentBP_QPP=DiBlPr,
      LastYearMostRecentSP_QPP=SyBlPr,
      LastYearMostRecentSP_QPP_Date=syblpr_date,
      LastYearMostRecentBP_QPP_Date=diblpr_date

      */

/* syblpr_date -- 35
diblpr_date ---36
bpscenco_date--68      */




//exclusion

val exclusionRDD = ippRDD.filter(r =>checkElementPresent(r, EXCLUSION, MEASURE_NAME, "diofhy"))
exclusionRDD.cache()

var intermediateRDD = getinterRDD(ippRDD, exclusionRDD)




val metRDD = intermediateRDD.filter(r => //bpscenco_date
  (
    ( (!r.isNullAt("syblpr")&& chkDateRangeLessOrEqual(r, MET, MEASURE_NAME, "bpscenco_date", "syblpr_date"))
      && (!r.isNullAt("diblpr")&& chkDateRangeLessOrEqual(r, MET, MEASURE_NAME, "bpscenco_date", "diblpr_date"))
      )
      &&
     (
      (
        (chkDateEqual(r, MET, MEASURE_NAME, "syblpr_date", "bpscenco_date")&&
          chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr", 120))
          &&
          (chkDateEqual(r, MET, MEASURE_NAME, "diblpr_date", "bpscenco_date")&&
            chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr", 80))
        )
      ||
      (
        (
          (
          (chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "syblpr", 120) &&
            chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr", 140)
            )&&
            (
              chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr", 90)
              )
          )||
          (
            (chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "diblpr", 80) &&
              chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr", 90)
              )&&
              (
                chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr", 140)
                )
            )
          )&&
        (
            ( // Most Recent NOt Required
              checkElementPresent(r, MET, MEASURE_NAME, "retoalprprcapr") &&
                checkElementPresent(r, MET, MEASURE_NAME, "fiofhy")&&
                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"retoalprprcapr_date","bpscenco_date",1)
              )
        ||
          (
            (
              (
                checkElementPresent(r, MET, MEASURE_NAME, "lire") &&
                  chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"lire_date","bpscenco_date",1)
                )||
                ( checkElementPresent(r, MET, MEASURE_NAME, "werere") &&
                  chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"werere_date","bpscenco_date",1)
                  )||
                ( checkElementPresent(r, MET, MEASURE_NAME, "dire_1") &&
                  chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"dire_1_date","bpscenco_date",1)
                  )||
                ( checkElementPresent(r, MET, MEASURE_NAME, "phacre") &&
                  chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"phacre_date","bpscenco_date",1)
                  )||
                (checkElementPresent(r, MET, MEASURE_NAME, "moofetcore") &&
                  chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"moofetcore_date","bpscenco_date",1)
                  )

              )&&
              (
                checkElementPresent(r, MET, MEASURE_NAME, "fowionye") &&
                  checkElementPresent(r, MET, MEASURE_NAME, "fiofhy")&&
                  chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"fowionye_date","bpscenco_date",1)
                )
            )
        ))||
      (
          ( /*(!(chkYearRangeLessThanSecondsArg(r,IPP,MEASURE_NAME,"syblpr_date","bpscenco_date",1) &&
            chkYearRangeLessThanSecondsArg(r,IPP,MEASURE_NAME,"diblpr_date","bpscenco_date",1)))
            // most recent not Required
              ||
            ((chkYearRangeLessThanSecondsArg(r,IPP,MEASURE_NAME,"syblpr_date","bpscenco_date",1) &&
              (chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr_element",140)) )&&
               (chkYearRangeLessThanSecondsArg(r,IPP,MEASURE_NAME,"diblpr_date","bpscenco_date",1)&&
              chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr_element",90))
              )*/
            //||
            ( BackTracking(r, EXCLUSION, MEASURE_NAME, BackTrackingMostList)
              )

          )
          &&

          ( (chkDateRangeLessOrEqual(r,MET, MEASURE_NAME,"bpscenco_date","syblpr_date")&&
            chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "syblpr", 140))
            ||
            (chkDateRangeLessOrEqual(r,MET, MEASURE_NAME,"bpscenco_date","diblpr_date")&&
              chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "diblpr", 90))
            )&&
          (
            (
              checkElementPresent(r, MET, MEASURE_NAME, "retoalprprcapr") &&
                checkElementPresent(r, MET, MEASURE_NAME, "fiofhy")&&
                chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"retoalprprcapr_date","bpscenco_date",1)
              )||
              (
                (
                  (
                    checkElementPresent(r, MET, MEASURE_NAME, "lire") &&
                      chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"lire_date","bpscenco_date",1)
                    )||
                    ( checkElementPresent(r, MET, MEASURE_NAME, "werere") &&
                      chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"werere_date","bpscenco_date",1)
                      )||
                    ( checkElementPresent(r, MET, MEASURE_NAME, "dire_1") &&
                      chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"dire_1_date","bpscenco_date",1)
                      )||
                    ( checkElementPresent(r, MET, MEASURE_NAME, "phacre") &&
                      chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"phacre_date","bpscenco_date",1)
                      )||
                    (checkElementPresent(r, MET, MEASURE_NAME, "moofetcore") &&
                      chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"moofetcore_date","bpscenco_date",1)
                      )

                  )&&
                  (
                    checkElementPresent(r, MET, MEASURE_NAME, "fowi4we") &&
                      checkElementPresent(r, MET, MEASURE_NAME, "fiofhy")&&
                      chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"fowionye_date","bpscenco_date",1)
                    )
                )
            )
        )||
      (

          (
            (chkDateYearDiffLess(r, MET, MEASURE_NAME, "syblpr_date", "bpscenco_date", 1)&&
              chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "syblpr", 140))
              ||
              (chkDateYearDiffLess(r, MET, MEASURE_NAME, "diblpr_date", "bpscenco_date", 1)&&
                chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "diblpr", 90))
            )&&
            (
              (chkDateRangeLessOrEqual(r,MET, MEASURE_NAME,"syblpr_date","bpscenco_date")&&
                chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "syblpr", 140))
                ||
                (chkDateRangeLessOrEqual(r,MET, MEASURE_NAME,"diblpr_date","bpscenco_date")&&
                  chkValueRangeGreaterOrEqual(r, MET, MEASURE_NAME, "diblpr", 90))
              )&&
            (
              (
                checkElementPresent(r, MET, MEASURE_NAME, "retoalprprcapr") &&
                  checkElementPresent(r, MET, MEASURE_NAME, "fiofhy")&&
                  chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"retoalprprcapr_date","bpscenco_date",1)
                )||
                (
                  (
                    (
                      checkElementPresent(r, MET, MEASURE_NAME, "lire") &&
                        chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"lire_date","bpscenco_date",1)
                      )||
                      ( checkElementPresent(r, MET, MEASURE_NAME, "werere") &&
                        chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"werere_date","bpscenco_date",1)
                        )||
                      ( checkElementPresent(r, MET, MEASURE_NAME, "dire_1") &&
                        chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"dire_1_date","bpscenco_date",1)
                        )||
                      ( checkElementPresent(r, MET, MEASURE_NAME, "phacre") &&
                        chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"phacre_date","bpscenco_date",1)
                        )||
                      (checkElementPresent(r, MET, MEASURE_NAME, "moofetcore") &&
                        chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"moofetcore_date","bpscenco_date",1)
                        )
                    )&&
                    (
                      (
                        checkElementPresent(r, MET, MEASURE_NAME, "anphth") &&
                          chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"anphth_date","bpscenco_date",1)
                        )||
                        (
                          checkElementPresent(r, MET, MEASURE_NAME, "latefohy") &&
                            chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"latefohy_date","bpscenco_date",1)
                          )||
                        (
                          checkElementPresent(r, MET, MEASURE_NAME, "ec12leorstor") &&
                            chkDateRangeLessOrEqualEncounterdateAddDays(r, MET, MEASURE_NAME,"ec12leorstor_date","bpscenco_date",1)
                          )
                      )

                  )

              )

        )


        )

    )



)

metRDD.cache()

var intermediateRDDA = getNotMet(intermediateRDD, metRDD)

    var exceptionRDD = intermediateRDDA.filter(r =>
  (checkElementPresent(r, IPP, MEASURE_NAME, "meorotrenodo") &&
    chkDateEqual(r,EXCEPTION,MEASURE_NAME,"meorotrenodo_date","encounterdate") )
    ||checkElementPresent(r, IPP, MEASURE_NAME, "parere_1") &&
    chkDateRangeGreaterOrEqual(r, IPP, MEASURE_NAME, "parere_1_date","encounterdate")&&
    chkDateRangeLessOrEqualAndSecoundDatePlusDays(r,MET,MEASURE_NAME,"parere_1_date","encounterdate",1)

)
exceptionRDD.cache()



val notMetRDD=intermediateRDDA.subtract(exceptionRDD)

// Filter notEligibleRDD
var notEligibleRDD = ippRDD.filter(r => false)
notEligibleRDD.cache()

if (DataMartCreator.debugMode == 1) {
  println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
  println("ACEP " + MEASURE_NAME + " *** notEligibleRDD          ***" + notEligibleRDD.count())
  println("ACEP " + MEASURE_NAME + " *** exclusionRDD          ***" + exclusionRDD.count())
  println("ACEP " + MEASURE_NAME + " *** exceptionRDD ***" + exceptionRDD.count())
  println("ACEP " + MEASURE_NAME + " *** metRDD       ***" + metRDD.count())
  println("ACEP " + MEASURE_NAME + " *** notMetRDD    ***" + notMetRDD.count())
  println("*********************************************************")
}    else
{ saveToWebDM(notEligibleRDD,exclusionRDD,metRDD, exceptionRDD, notMetRDD, MEASURE_NAME) }



ippRDD.unpersist(true);
metRDD.unpersist(true);
notMetRDD.unpersist(true);
exceptionRDD.unpersist(true);
notEligibleRDD.unpersist(true);
exclusionRDD.unpersist(true);
new PostgreUtility().insertIntoProcessDetails(MEASURE_NAME, "", "", "Measure computation done successfully", "PASS")

}

catch {
case e: Exception => {
  println(e.printStackTrace())
  new PostgreUtility().insertIntoProcessDetails(MEASURE_NAME, "W0001", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
  System.exit(-1)

}
}
}
def BackTracking(r: CassandraRow, conditionType: String, measureName: String, BackTrackingMostList: Broadcast[List[String]]): Boolean = {
val flag = false;




for (x <- BackTrackingMostList.value) {
if (x != "") {
  //println(r.getString("visituid") + ">>>" + x)
  val back_data = x.split("~")
  val patientid = back_data(0);
  val syblpr_element = back_data(1);
  val diblpr_element = back_data(2);
  val syblpr_date =dateUtility.dateTimeParse(back_data(3));
  val diblpr_date =dateUtility.dateTimeParse(back_data(4));





  if ((!r.isNullAt("bpscenco_date") && !r.isNullAt("bpscenco"))
    && ((r.getString("patientuid").equals(patientid) || r.getString("patientuid") == patientid)
    &&(
    (
      !(

        (
          (
            r.getDateTime("bpscenco_date").minusYears(1).equals(syblpr_date)
              &&
              r.getDateTime("bpscenco_date").minusYears(1).equals((diblpr_date))
            )
            &&
            (
              chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr_element",140)
                &&
                chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr_element",90)
              )
          ) ||
          (
            (
              r.getDateTime("bpscenco_date").isBefore(syblpr_date)
                &&
                r.getDateTime("bpscenco_date").isBefore((diblpr_date))
              )
              &&
              (
                r.getDateTime("bpscenco_date").minusYears(1).isAfter(diblpr_date)
                  &&
                  r.getDateTime("bpscenco_date").minusYears(1).isAfter(syblpr_date)
                )
              &&
              (
                chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr_element",140)
                  &&
                  chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr_element",90)
                )

            )
      )
      )
      ||
      (
        ((r.getDateTime("bpscenco_date").minusYears(1).isBefore(syblpr_date) || r.getDateTime("bpscenco_date").minusYears(1).equals(syblpr_date)) && (chkValueRangeLess(r, MET, MEASURE_NAME, "syblpr_element",140)))
          &&
          ((r.getDateTime("bpscenco_date").minusYears(1).isAfter(diblpr_date) || r.getDateTime("bpscenco_date").minusYears(1).equals(diblpr_date)) && (chkValueRangeLess(r, MET, MEASURE_NAME, "diblpr_element",90)))
        )


    )
    )
  ) {
    //println("match")
    return true;
  }

}

}

return flag;

}

def getBackTrackingList(rdd: CassandraTableScanRDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement2: String, backtrackelement3: String, backtrackelement4: String): List[String] = {

val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).collect().toSet

val IPPFilterExclusionRDD = rdd.select("patientuid",backtrackelement1,backtrackelement2,backtrackelement3,backtrackelement4).filter(x => (ipp_patient_list.contains(x.columnValues(2))))

var CRA = IPPFilterExclusionRDD.map(x =>
if (!x.isNullAt("patientuid")
  && !x.isNullAt(backtrackelement1) && !x.isNullAt(backtrackelement2) && !x.isNullAt(backtrackelement3) && !x.isNullAt(backtrackelement4)) {
  x.getString("patientuid") + "~" + x.getString(backtrackelement1) + "~" + x.getString(backtrackelement2) + "~" + x.getString(backtrackelement3)+ "~" + x.getString(backtrackelement4)
}
else ""
)
.collect()
.toList

return CRA;
}
}

