package com.figmd.janus.measureComputation.equalMeasures

import java.text.SimpleDateFormat
import java.util.Date

import com.datastax.spark.connector.CassandraRow

import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.util._
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession
import com.figmd.janus.DataMartCreator.prop
object ACEP12a  extends MeasureUtility  with MeasureTrait {
  var MEASURE_NAME= "M12a"
  @transient lazy val postgresUtility=new PostgreUtility()
  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {
try{
    val columnRef = getFiledList(MEASURE_NAME)
    val rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0), columnRef(1), columnRef(2), columnRef(3), columnRef(4), columnRef(5), columnRef(6), columnRef(7), columnRef(8), columnRef(9), columnRef(10), columnRef(11), columnRef(12),columnRef(13),columnRef(14),columnRef(15),columnRef(16),columnRef(17),columnRef(18),columnRef(19))
      .where(s"encounterdate>=? and encounterdate<=? "+prop.getProperty("practiceListCondition"),startDate, endDate)

    val simpleDateFormat: SimpleDateFormat = new SimpleDateFormat(new FileUtility().getProperty("date.format"));
    val dateUtility = new DateUtility();


    // Filter IPP
    val ippRDD = rdd
      .filter(r =>
        !r.isNullAt("encounterdate") &&
//          chkDateRangeExist(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate)  &&
          (
            !r.isNullAt("dob") &&
              !r.isNullAt("ed_visit_arrival_date") &&
              dateUtility.getAge(r.getString("dob"), r.getString("ed_visit_arrival_date")) >= 18 &&
              checkElementPresent(r, IPP, MEASURE_NAME, "ed_crtcl") &&
              checkElementPresent(r, IPP, MEASURE_NAME, "chstpn")
            )
      )

    ippRDD.cache();

    // Filter Met
    val metRDD = ippRDD.filter(r =>
      !r.isNullAt("strecg_date") &&
        !r.isNullAt("ed_visit_arrival_date") &&
        !r.isNullAt("ed_visit_departure_date") &&
        checkElementPresent(r, MET, MEASURE_NAME, "strecg") &&
        chkDateRangeBetween(r, MET, MEASURE_NAME, "strecg_date", "ed_visit_arrival_date", "ed_visit_departure_date")
    )
    metRDD.cache()

    // Filter Exceptions
    var exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //exceptionRDD.cache()

    var notMetRDD = getNotMet(ippRDD, metRDD)
    notMetRDD.cache()

    // Filter Exclusions
    var notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //notEligibleRDD.persist()

    // Filter Exclusions
    var exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    //exclusionRDD.persist()

    if (DataMartCreator.debugMode == 1) {
      println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
      println("ACEP " + MEASURE_NAME + " *** notEligibleRDD          ***" + notEligibleRDD.count())
      println("ACEP " + MEASURE_NAME + " *** exclusionRDD          ***" + exclusionRDD.count())
      println("ACEP " + MEASURE_NAME + " *** exceptionRDD ***" + exceptionRDD.count())
      println("ACEP " + MEASURE_NAME + " *** metRDD       ***" + metRDD.count())
      println("ACEP " + MEASURE_NAME + " *** notMetRDD    ***" + notMetRDD.count())
      println("*********************************************************")
    }
    else
    { saveToWebDM(notEligibleRDD,exclusionRDD,metRDD, exceptionRDD, notMetRDD, MEASURE_NAME) }

    ippRDD.unpersist(true);
    metRDD.unpersist(true);
    notMetRDD.unpersist(true);
    exceptionRDD.unpersist(true);
    notEligibleRDD.unpersist(true);
    exclusionRDD.unpersist(true);
    postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"","","Measure computation done successfully","PASS")
}
catch {
  case e:Exception=>{
    println(e.printStackTrace())
    postgresUtility.insertIntoProcessDetails(MEASURE_NAME,"W0001","CRITICAL",Throwables.getStackTraceAsString(e),"FAIL")
    System.exit(-1)

  }
}
  }
}
