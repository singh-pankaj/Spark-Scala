package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.DataMartCreator.prop
import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.util.{CassandraUtility, DateUtility, MeasureUtility, PostgreUtility}
import com.google.common.base.Throwables
import org.apache.spark.sql.SparkSession

object ACEP254 extends MeasureUtility with MeasureTrait {

  var MEASURE_NAME = "M254"
  @transient lazy val postgresUtility=new PostgreUtility()
  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {

    try {
      val columnRef = getFiledList(MEASURE_NAME)
      val rdd = new CassandraUtility().getCassandraRDD(sparkSession).select(columnRef(0), columnRef(1), columnRef(2), columnRef(3), columnRef(4), columnRef(5), columnRef(6), columnRef(7), columnRef(8), columnRef(9), columnRef(10), columnRef(11), columnRef(12), columnRef(13), columnRef(14), columnRef(15), columnRef(16), columnRef(17), columnRef(18), columnRef(19), columnRef(20), columnRef(21), columnRef(22), columnRef(23), columnRef(24), columnRef(25), columnRef(26),columnRef(27), columnRef(28), columnRef(29),columnRef(30), columnRef(31), columnRef(32), columnRef(33),columnRef(34), columnRef(35),columnRef(36))
        .where(s"encounterdate>=? and encounterdate<=? "+prop.getProperty("practiceListCondition"),startDate, endDate)

      val dateUtility = new DateUtility()

      // Filter IPP
      val ippRDD = rdd
        .filter(r =>


          (
            (
             checkElementValue(r, IPP, MEASURE_NAME, "sex", 2)
            )
            &&
            (
             chkDateYearDiffGreaterOrEqualAndLessThan(r, IPP, MEASURE_NAME,"dob","encounterdate",14,51)
            )
            &&
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "condtnscomplctngprgnancy") &&
              chkDateEqual(r,IPP, MEASURE_NAME,"condtnscomplctngprgnancy_date","encounterdate")
            )
            &&
           (
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1") &&
              chkDateRangeExist(r, IPP, MEASURE_NAME, "emdevi_1_date", startDate, endDate)
            )
            ||
            (
              checkElementPresent(r, IPP, MEASURE_NAME, "ccv") &&
              chkDateRangeExist(r, IPP, MEASURE_NAME, "ccv_date", startDate, endDate)
            )
             &&
              (
               (
                checkElementPresent(r, IPP, MEASURE_NAME, "pos2") &&
                chkDateEqual(r,IPP, MEASURE_NAME,"pos2_date","emdevi_1_date")
               )
               ||
                (
                  checkElementPresent(r, IPP, MEASURE_NAME, "pos2") &&
                  chkDateEqual(r,IPP, MEASURE_NAME,"pos2_date","ccv_date")
                )
              )
            )
              &&
              (
               (
                  checkElementPresent(r, IPP, MEASURE_NAME, "vagbldg") &&
                  chkDateEqual(r,IPP, MEASURE_NAME,"vagbldg_date","encounterdate")
               )
               ||
                (
                 checkElementPresent(r, IPP, MEASURE_NAME, "abd_pain")&&
                 chkDateEqual(r,IPP, MEASURE_NAME,"abd_pain_date","encounterdate")
                )
                )
             )
         )

      ippRDD.cache()

      //met

      val metRDD = ippRDD.filter(r =>
        (
          checkElementPresent(r, MET, MEASURE_NAME, "ultrtransab") &&
          chkDateEqual(r, MET, MEASURE_NAME, "ultrtransab_date", "encounterdate")
        )
         ||
          (
           checkElementPresent(r, MET, MEASURE_NAME, "tatv_prformd") &&
           chkDateEqual(r, MET, MEASURE_NAME, "tatv_prformd_date", "encounterdate")
          )
          ||
           (
              checkElementPresent(r, MET, MEASURE_NAME, "trnsvgus") &&
              chkDateEqual(r, MET, MEASURE_NAME, "trnsvgus_date", "encounterdate")
           )
      )

      metRDD.cache()

      var intermediateRDD = getinterRDD(ippRDD, metRDD).cache()


      val exceptionRDD = intermediateRDD.filter(r => (
        checkElementPresent(r, EXCEPTION, MEASURE_NAME, "intrutnprg") &&
          chkDateEqual(r, EXCEPTION, MEASURE_NAME, "intrutnprg_date", "encounterdate")
        )
        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "tatv_performd_medrsn") &&
          chkDateEqual(r, EXCEPTION, MEASURE_NAME, "tatv_performd_medrsn_date", "encounterdate")

          )

        ||
        (
          checkElementPresent(r, EXCEPTION, MEASURE_NAME, "multvisit1") &&
          chkHoursRangeBetweenMinusDaysForTwoArg1Minus2plus(r, EXCEPTION, MEASURE_NAME, "multvisit1_date","encounterdate",72,0)
        )

      )

      exceptionRDD.cache()


      var notMetRDD = getNotMet(intermediateRDD, exceptionRDD)

      val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      if (DataMartCreator.debugMode == 1) {
        println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notEligibleRDD          ***" + notEligibleRDD.count())
        println("ACEP " + MEASURE_NAME + " *** exclusionRDD          ***" + exclusionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** exceptionRDD ***" + exceptionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** metRDD       ***" + metRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notMetRDD    ***" + notMetRDD.count())
        println("*********************************************************")
      }    else
      { saveToWebDM(notEligibleRDD,exclusionRDD,metRDD, exceptionRDD, notMetRDD, MEASURE_NAME) }

      ippRDD.unpersist(true);
      metRDD.unpersist(true);
      notMetRDD.unpersist(true);
      exceptionRDD.unpersist(true);
      notEligibleRDD.unpersist(true);
      exclusionRDD.unpersist(true);

      postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "", "", "Measure computation done successfully", "PASS")
    }

    catch {
      case e: Exception => {
        println(e.printStackTrace())
        postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "W0001", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
        System.exit(-1)

      }
    }
  }
}