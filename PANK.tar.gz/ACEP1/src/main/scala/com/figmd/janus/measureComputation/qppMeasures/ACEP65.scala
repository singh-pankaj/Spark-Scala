package com.figmd.janus.measureComputation.qppMeasures

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.datastax.spark.connector.rdd.CassandraTableScanRDD
import com.figmd.janus.{DataMartCreator, MeasureTrait}
import com.figmd.janus.measureComputation.qppMeasures.ACEP116._
import com.figmd.janus.measureComputation.qppMeasures.ACEP66.{BackTracking, EXCLUSION, MEASURE_NAME, getBackTrackingList, _}
import com.figmd.janus.measureComputation.qppMeasures.ACEP76.{MEASURE_NAME, saveToWebDM}
import com.figmd.janus.util._
import com.google.common.base.Throwables
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ACEP65 extends MeasureUtility with MeasureTrait {

  var MEASURE_NAME = "M65"
  @transient lazy val postgresUtility=new PostgreUtility()

  def refresh(sparkSession: SparkSession, startDate: Date, endDate: Date): Unit = {

    try {
      val columnRef = getFiledList(MEASURE_NAME)
      val rdd = new CassandraUtility().getCassandraRDD(sparkSession)
        .select(columnRef(0), columnRef(1), columnRef(2), columnRef(3), columnRef(4), columnRef(5), columnRef(6), columnRef(7), columnRef(8), columnRef(9), columnRef(10), columnRef(11), columnRef(12), columnRef(13), columnRef(14), columnRef(15), columnRef(16), columnRef(17), columnRef(18), columnRef(19), columnRef(20), columnRef(21), columnRef(22), columnRef(23), columnRef(24), columnRef(25), columnRef(26), columnRef(27), columnRef(28), columnRef(29), columnRef(30), columnRef(31), columnRef(32),columnRef(33),columnRef(34))

      val dateUtility = new DateUtility()
      var sparkObj = new SparkUtility()
      val initialrdd =sparkObj.filterPracticeIdFromInitialRDD(sparkSession, rdd)
      // Filter IPP
      val ippRDD = initialrdd
        .filter(r =>

          chkDateRangeExist(r, IPP, MEASURE_NAME, "encounterdate", startDate, endDate) &&
            (
                 chkDateYearDiffGreaterOrEqualAndLessThan(r, IPP, MEASURE_NAME,"dob","encounterdate",3,19)&&
                   (
                     checkElementPresent(r, IPP, MEASURE_NAME, "ofvi_1")||
                 // checkElementPresent(r, IPP, MEASURE_NAME, "hoobcain")&& //Element NOt Found
                  checkElementPresent(r, IPP, MEASURE_NAME, "emdevi_1")||
                  //checkElementPresent(r, IPP, MEASURE_NAME, "prcaesofvi0to17")&&
                  checkElementPresent(r, IPP, MEASURE_NAME, "fain")&&
                  checkElementPresent(r, IPP, MEASURE_NAME, "diseobca")||
                  checkElementPresent(r, IPP, MEASURE_NAME, "ippexm")
                     )
                   &&
                 // checkElementPresent(r, IPP, MEASURE_NAME, "uprein")&&
                   chkDateEqual(r, IPP, MEASURE_NAME, "acph_date", "encounterdate")

              )

        )
      ippRDD.cache()

      val CRA = getBackTrackingList(rdd, ippRDD, "anmefoph", "anmefoph_date");

      val CRA_list: Broadcast[List[String]] = sparkSession.sparkContext.broadcast(CRA)

      //exclusion

      val exclusionRDD = ippRDD.filter(r =>
        (
          checkElementPresent(r, EXCLUSION, MEASURE_NAME, "anmefoph")
            ||
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohofohoca") ||
                checkElementPresent(r, EXCLUSION, MEASURE_NAME, "ditohecafafohoca")
              )
          )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hocaam")
            )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "hspsv") &&
              chkDateRangeExist(r, EXCLUSION, MEASURE_NAME, "hspsv_date", startDate, endDate)
            )
          ||
          (
            (
              checkElementPresent(r, EXCLUSION, MEASURE_NAME, "anmefoph") &&
                chkDateRangeBetweenMinusDaysForTwoArg(r, MET, MEASURE_NAME, "anmefoph_date", "acph_date", 30, 1)
              )
              ||
              (
                chkDateRangeBetweenMinusDaysForTwoArg(r, EXCLUSION, MEASURE_NAME, "anmefoph_date", "acto_date", 30, 1)
                )
            )
          ||
          (
            checkElementPresent(r, EXCLUSION, MEASURE_NAME, "antpharyn") &&
              chkDateRangeExist(r, EXCLUSION, MEASURE_NAME, "antpharyn_date", startDate, endDate)
            )||
          (
            BackTracking(r, EXCLUSION, MEASURE_NAME, CRA_list)
            )

      )
      exclusionRDD.cache()

      var intermediateRDD = ippRDD.subtract(exclusionRDD)

      intermediateRDD.cache()

      val metRDD = intermediateRDD.filter(r =>
        (
          (
            checkElementPresent(r, MET, MEASURE_NAME, "grastte") &&
              chkDateRangeBetweenMinusDaysForTwoArg1Minus2plus(r, MET, MEASURE_NAME, "amvi_copy_951_date", "grastte_date", 3, 3)
            )
            ||
            (
              checkElementPresent(r, MET, MEASURE_NAME, "grpastp") &&
                chkDateRangeBetweenMinusDaysForTwoArg1Minus2plus(r, MET, MEASURE_NAME, "grpastp_date", "acph_date", 3, 3)
              )
            ||
            (
              checkElementPresent(r, MET, MEASURE_NAME, "grpastp") &&
                chkDateRangeBetweenMinusDaysForTwoArg1Minus2plus(r, MET, MEASURE_NAME, "acto_date", "acph_date", 3, 3)
              )

          )
      )
      metRDD.cache()

      var notMetRDD = getNotMet(intermediateRDD, metRDD)

      // Filter Exceptions
      var exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()


      // Filter notEligibleRDD
      var notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]



      if (DataMartCreator.debugMode == 1) {
        println("ACEP " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notEligibleRDD          ***" + notEligibleRDD.count())
        println("ACEP " + MEASURE_NAME + " *** exclusionRDD          ***" + exclusionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** exceptionRDD ***" + exceptionRDD.count())
        println("ACEP " + MEASURE_NAME + " *** metRDD       ***" + metRDD.count())
        println("ACEP " + MEASURE_NAME + " *** notMetRDD    ***" + notMetRDD.count())
        println("*********************************************************")
      }    else
      { saveToWebDM(notEligibleRDD,exclusionRDD,metRDD, exceptionRDD, notMetRDD, MEASURE_NAME) }



      ippRDD.unpersist(true);
      metRDD.unpersist(true);
      notMetRDD.unpersist(true);
      exceptionRDD.unpersist(true);
      notEligibleRDD.unpersist(true);
      exclusionRDD.unpersist(true);
      postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "", "", "Measure computation done successfully", "PASS")

    }

    catch {
      case e: Exception => {
        println(e.printStackTrace())
        postgresUtility.insertIntoProcessDetails(MEASURE_NAME, "W0001", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
        System.exit(-1)

      }
    }
  }
  def BackTracking(r: CassandraRow, conditionType: String, measureName: String, CRA: Broadcast[List[String]]): Boolean = {
    val flag = false;

    for (x <- CRA.value) {
      if (x != "") {
        //println(r.getString("visituid") + ">>>" + x)
        val back_data = x.split("~")
        val patientid = back_data(0);
        val anmefoph_element = back_data(1);
        val anmefoph_date =dateUtility.dateTimeParse(back_data(2));



        if ((!r.isNullAt("encounterdate") )
          && ((r.getString("patientuid").equals(patientid) || r.getString("patientuid") == patientid)
          &&(
          (anmefoph_element == "1"

            )

          )
          )
        ) {

          return true;
        }

      }

    }

    return flag;

  }

  def getBackTrackingList(rdd: CassandraTableScanRDD[CassandraRow], ippRDD: RDD[CassandraRow], backtrackelement1: String, backtrackelement2: String): List[String] = {

    val ipp_patient_list = ippRDD.map(x => x.columnValues(3)).distinct().collect().toList

    val IPPFilterExclusionRDD = rdd.select("patientuid",backtrackelement1,backtrackelement2).filter(x => (ipp_patient_list.contains(x.columnValues(2))))

    var CRA = IPPFilterExclusionRDD.map(x =>
      if (!x.isNullAt("patientuid")
        && !x.isNullAt(backtrackelement1) && !x.isNullAt(backtrackelement2)) {
        x.getString("patientuid") + "~" + x.getString(backtrackelement1) + "~" + x.getString(backtrackelement2)
      }
      else ""
    )
      .collect()
      .toList

    return CRA;
  }
}

