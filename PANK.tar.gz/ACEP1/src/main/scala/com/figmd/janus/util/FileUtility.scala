package com.figmd.janus.util


import java.util.Properties


import scala.io.Source

class FileUtility extends Serializable {

  def getPropertyLog(): String = {

    lazy val properties: Properties = new Properties()

    val url = getClass.getResource("/application.properties")

    if (url != null) {
      val source = Source.fromURL(url)
      properties.load(source.bufferedReader())
    }

/*    if (randNum == 1) {
       properties.getProperty("file.output.path.log1")
    }else if (randNum == 2) {
       properties.getProperty("file.output.path.log2")
    }else if (randNum == 3) {
       properties.getProperty("file.output.path.log3")
    }else if (randNum == 4) {
       properties.getProperty("file.output.path.log4")
    }else if (randNum == 5) {
       properties.getProperty("file.output.path.log5")
    }else {
       properties.getProperty("file.output.path.log")
    }*/
    ("/tmp/ACEP/logger").trim
  }

  def getProperty(property: String): String = {

    var properties: Properties = null
    var logfilename=""
    val url = getClass.getResource("/application.properties")


    if (url != null) {
      val source = Source.fromURL(url)
      properties = new Properties()
      properties.load(source.bufferedReader())
    }
    return properties.getProperty(property);
  }

  def getProperty():Properties = {

    var properties: Properties = null
    val url = getClass.getResource("/application.properties")

    if (url != null) {
      val source = Source.fromURL(url)
      properties = new Properties()
      properties.load(source.bufferedReader())
    }

    return properties

  }


}
