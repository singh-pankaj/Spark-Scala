package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}

class AllergyTransformFunctions(sparkSess: SparkSession, masterAllergy: DataFrame
                                , mappingpracticecommondatamaster: DataFrame) {


  import sparkSess.implicits._

  def AllergyCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(masterAllergy.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AllergyCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterAllergyCode")
        , $"df2.CodeDescription".as("MasterAllergyDescription"))
  }


  def AllergyDescription(df: DataFrame): DataFrame = {
    df
      .as("df1").join(masterAllergy.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AllergyDescription" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedMasterAllergicToCode")
        , $"df2.CodeDescription".as("MappedMasterAllergyDescription"))
      .withColumn("MasterAllergyCode", when($"MappedMasterAllergicToCode".isNull, $"MasterAllergyCode")
        .otherwise($"MappedMasterAllergicToCode"))
      .withColumn("MasterAllergyDescription", when($"MappedMasterAllergyDescription".isNull, $"MasterAllergyDescription")
        .otherwise($"MappedMasterAllergyDescription"))
      .drop("MappedMasterAllergicToCode", "MappedMasterAllergyDescription")
  }


  def AllergyStatusCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AllergyStatusCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MasterAllergyStatusText"))
  }

  def AllergyStatusText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.AllergyStatusText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterAllergyStatusText", when($"MappedValue2".isNull, $"MasterAllergyStatusText")
        .otherwise($"MappedValue2"))
      .drop("MappedValue2")
  }
}
