package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.{DataFrame, SparkSession}

class InsuranceTransformFunction (sparkSess : SparkSession, MasterInsurance : DataFrame) {

  import sparkSess.implicits._


  //Master Insurance not contain Code and CodeDescription column
  def InsuredRelationToPatientCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(MasterInsurance.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.InsuredRelationToPatientCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.PayerId".as("MasterInsuredRelationToPatientText"))

  }

  def InsuredRelationToPatientText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(MasterInsurance.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.InsuredRelationToPatientText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.PayerId".as("MasterInsuredRelationToPatientText"))

  }
}