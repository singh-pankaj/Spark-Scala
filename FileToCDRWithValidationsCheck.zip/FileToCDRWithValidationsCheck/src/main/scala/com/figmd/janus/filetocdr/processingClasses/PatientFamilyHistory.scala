package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.FamilyHistoryTransformFunc
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientFamilyHistory(FamilyHistoryPath: String, selectedIds: DataFrame) extends LookupMaps {


  def FamilyHistoryProcessing(spark: SparkSession, mappingpractivecommondatamasterrelationship: DataFrame
                              , mappingpracticecommondatamaster: DataFrame, mappingpracticeproblem: DataFrame) {

    try {


      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientFamilyHistory")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientFamilyHistory")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientFamilyHistory")
      val errPath = ApplicationConfig.prop.getProperty("PatientFamilyHistoryErrPath")
      val validations = new ValidationCriteria(spark)

      import spark.implicits._
      val file = CommonFunc.readFile(FamilyHistoryPath, spark)

      val file1 = file.select(file.columns.map(c => col(c).as(PatientFamilyHistorylookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid")


      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastPatientFamilyHistoryRows = spark.sparkContext.broadcast(rows)

      /*
            val CleanedRecords1 = file1.filter(row => validations.checkNull(row, broadcastPatientFamilyHistoryRows, "PatientId","PracticeUid","RelationshipToPatientText"))

            val cachePatientFamilyHistoryValidations = CleanedRecords1.filter(row=>validations.checkNullCodeAndText(row,broadcastPatientFamilyHistoryRows, "RelationshipToPatientCode", "RelationshipToPatientText"))
      */

      val CleanedRecords = file1
        .transform(validations.checkNull("PatientId","PracticeUid","RelationshipToPatientText"))
        .transform(validations.checkNullCodeAndText("RelationshipToPatientCode", "RelationshipToPatientText"))
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "problemCode", "RelationshipToPatientText", "ObservationDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("problemCode", "PatientId", "PracticeUid", "ObservationDate", "ProblemDescription", "RelationshipToPatientText"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("ProblemDescription", "PatientId", "PracticeUid", "ObservationDate", "problemCode", "RelationshipToPatientText"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("ObservationDate", "PatientId", "PracticeUid", "ProblemDescription", "RelationshipToPatientText"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())



      val tf = new FamilyHistoryTransformFunc(spark, mappingpractivecommondatamasterrelationship
        , mappingpracticecommondatamaster, mappingpracticeproblem)

     // println("start familyhistory goes to lookup.............................")
      val cacheFamilyHistory3 = addPatientUid
        .transform(tf.RelationshipToPatientCode)
        .transform(tf.RelationshipToPatientText)
        //.transform(tf.ProblemTypeCode)
        //.transform(tf.ProblemTypeText)
        //.transform(tf.ProblemCode)
        //.transform(tf.ProblemDescription)
        .withColumnRenamed("ProblemCategory","CodeSystem")


      HiveUtility.dfwritetohive(cacheFamilyHistory3, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientFamilyHistoryRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientFamilyHistoryRows.destroy()

      /*val distinctPUid = cacheFamilyHistory3.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val FamilyHistoryData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cacheFamilyHistory3.select("PracticeUid", "PatientId", "PatientUid").distinct()
      broadcast(FiletoJoin)

      val otherData = FamilyHistoryData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PatientId" === $"df2.PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

     /* cacheFamilyHistory3.printSchema()
      otherData.printSchema()*/

      val newstructure = cacheFamilyHistory3.select(otherData.columns.head, otherData.columns.tail: _*)

      val AllFamilyHistoryData = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllFamilyHistoryData, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientFamilyHistoryRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientFamilyHistoryRows.destroy()*/


    }

    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }


}
