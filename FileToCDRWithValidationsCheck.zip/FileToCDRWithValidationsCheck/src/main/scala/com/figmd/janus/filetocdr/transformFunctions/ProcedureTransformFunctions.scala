package com.figmd.janus.filetocdr.transformFunctions


import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}

class ProcedureTransformFunctions(sparkSess: SparkSession
                                  , mappingPracticeProcedure: DataFrame
                                  , mappingpracticecommondatamaster: DataFrame) {


  import sparkSess.implicits._

  def PracticeCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterProcedureCode")
        , $"df2.CodeDescription".as("MasterProcedureDescription"))
  }

  def PracticeDescription(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureDescription" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedMasterProcedureCode")
        , $"df2.CodeDescription".as("MappedMasterProcedureText"))
      .withColumn("MasterProcedureCode", when($"MappedMasterProcedureCode".isNull, $"MasterProcedureCode")
        .otherwise($"MappedMasterProcedureCode"))
      .withColumn("MasterProcedureDescription", when($"MappedMasterProcedureText".isNull, $"MasterProcedureDescription")
        .otherwise($"MappedMasterProcedureText"))
      .drop("MappedMasterProcedureCode", "MappedMasterProcedureText")
  }

  def ProcedureStatusCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureStatusCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MasterProcedureStatusText"))
  }

  def ProcedureStatusText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProcedureStatusText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MappedMasterProcedureStatusText"))
      .withColumn("MasterProcedureStatusText", when($"MappedMasterProcedureStatusText".isNull, $"MasterProcedureStatusText")
        .otherwise($"MappedMasterProcedureStatusText"))
      .drop( "MappedMasterProcedureStatusText")
  }

  def TargetSiteCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MasterTargetSiteText"))
  }

  def TargetSiteText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingPracticeProcedure.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TargetSiteText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MappedMasterTargetSiteText"))
      .withColumn("MasterTargetSiteText", when($"MappedMasterTargetSiteText".isNull, $"MasterTargetSiteText")
        .otherwise($"MappedMasterTargetSiteText"))
      .drop("MappedMasterTargetSiteText")
  }


}
