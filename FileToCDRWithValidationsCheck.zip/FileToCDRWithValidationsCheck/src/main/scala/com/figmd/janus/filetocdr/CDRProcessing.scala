package com.figmd.janus.filetocdr


import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.processingClasses._
import com.figmd.janus.filetocdr.util.{Postgressutility, ReadConfigFile, SparkUtility}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.functions._


//spark-submit --master yarn --deploy-mode cluster --executor-memory 5G --num-executors 5 --executor-cores 3 --class com.figmd.janus.filetocdr.CDRProcessing /home/dev/Akshay/filetocdrjoin_2.11-0.1.jar


object CDRProcessing {

  def main(args: Array[String]): Unit = {


    val bucketname = args(0)
    val filename = args(1)

    val configObj = new ReadConfigFile(bucketname,filename)

    ApplicationConfig.setApplicationConfig(args)

    val sparkUtility = new SparkUtility()
    val sparkSess = sparkUtility.getSparkSession()
    val ReadTBL = new Postgressutility(sparkSess)

    Logger.getLogger("org").setLevel(Level.WARN)
    Logger.getLogger("akka").setLevel(Level.WARN)


    import sparkSess.implicits._

    println("Start programme............................")
    val tbl1 = ApplicationConfig.prop.getProperty("Allergy")
    val tbl2 = ApplicationConfig.prop.getProperty("Procedure")
    val tbl3 = ApplicationConfig.prop.getProperty("PracticeCommonData")
    val tbl4 = ApplicationConfig.prop.getProperty("Ethinicity")
    val tbl5 = ApplicationConfig.prop.getProperty("Race")
    val tbl6 = ApplicationConfig.prop.getProperty("Insurance")
    val tbl7 = ApplicationConfig.prop.getProperty("Problem")
    val tbl8 = ApplicationConfig.prop.getProperty("Medication")
    val tbl9 = ApplicationConfig.prop.getProperty("Route")
    val tbl10 = ApplicationConfig.prop.getProperty("RelationShip")

    val masterAllergy = ReadTBL.getPostgresTable(tbl1)
     broadcast(masterAllergy)

    val mappingPracticeProcedure = ReadTBL.getPostgresTable(tbl2)
    broadcast(mappingPracticeProcedure)

    val mappingpracticecommondatamaster = ReadTBL.getPostgresTable(tbl3)
    broadcast(mappingpracticecommondatamaster)

    val mappingpracticecommondatamasterethnicity = ReadTBL.getPostgresTable(tbl4)
    broadcast(mappingpracticecommondatamasterethnicity)

    val mappingpracticecommondatamasterrace = ReadTBL.getPostgresTable(tbl5)
    broadcast(mappingpracticecommondatamasterrace)

    val mappingpracticeinsurancedata = ReadTBL.getPostgresTableAllCols(tbl6)
    broadcast(mappingpracticeinsurancedata)

    val MappingPracticeProblem = ReadTBL.getPostgresTable(tbl7)
    broadcast(MappingPracticeProblem)

    val MappingPracticeMedication = ReadTBL.getPostgresTable(tbl8)
    broadcast(MappingPracticeMedication)

    val MappingPracticeCommonDataMasterMedicationRoute = ReadTBL.getPostgresTable(tbl9)
    broadcast(MappingPracticeCommonDataMasterMedicationRoute)

    val mappingracticecommondatamasterrelationship = ReadTBL.getPostgresTableAllCols(tbl10)
    broadcast(mappingracticecommondatamasterrelationship)


  val DemoPath = ApplicationConfig.prop.getProperty("PatientPath")
    val DemographicsDF = new PatientDemographics(DemoPath,mappingpracticecommondatamaster).demoProcessing(sparkSess)
    val selectedIds = DemographicsDF.head.select($"PracticeUid", $"PatientId", $"PatientUid")

    //val selectedIds = sparkSess.sql("select practiceuid,patientid,patientuid from acc_20181127.patient").distinct()
    val EthinicityPath = ApplicationConfig.prop.getProperty("PatientEthnicityPath")
    val PatientEthnicityDF: Unit = new PatientEthnicity(EthinicityPath, selectedIds)
      .EthinicityProccessing(sparkSess, mappingpracticecommondatamasterethnicity)


     val RacePath = ApplicationConfig.prop.getProperty("PatientRacePath")
    val PatientraceDF: Unit = new PatientRace(RacePath, selectedIds)
      .cacheRaceProcessing(sparkSess, mappingpracticecommondatamasterrace)

    val EncounterPath = ApplicationConfig.prop.getProperty("VisitPath")
    val CacheEncounterDF: Unit = new PatientEncounter(EncounterPath, selectedIds)
      .cachePatientEncounterProcessing(sparkSess,mappingpracticecommondatamaster)

    val InsurancePath = ApplicationConfig.prop.getProperty("PatientInsurancePath")
    val PatientInsuranceDF = new PatientInsurance(InsurancePath,selectedIds)
      .cachePatientinsuranceprocessing(sparkSess,mappingpracticeinsurancedata)

    val ProblemPath = ApplicationConfig.prop.getProperty("PatientProblemPath")
    val PatientProblemDF: Unit = new PatientProblem(ProblemPath, selectedIds)
      .cachePatientProblemProcessing(sparkSess, MappingPracticeProblem)

    val ProcedurePath = ApplicationConfig.prop.getProperty("PatientProceduresPath")
    val PatientProcedureDF: Unit = new PatientProcedure(ProcedurePath, selectedIds)
      .cachePatientProcedureProceesing(sparkSess, mappingPracticeProcedure, mappingpracticecommondatamaster)

  val AdvanceDirectivePath = ApplicationConfig.prop.getProperty("PatientAdvanceDirectivePath")
    val PatientAdvanceDirectiveDF: Unit = new PatientAdvanceDirectiveObservation(AdvanceDirectivePath, selectedIds)
      .cacheAdvObsProcessing(sparkSess, mappingpracticecommondatamaster)

    val AllergiesPath = ApplicationConfig.prop.getProperty("PatientAllergiesPath")
    val PatientAllergyDF: Unit = new PatientAllergy(AllergiesPath, selectedIds)
      .cacheAllergyProcessing(sparkSess, masterAllergy, mappingpracticecommondatamaster)

    val MedicationPath = ApplicationConfig.prop.getProperty("PatientMedicationsPath")
    val PatientMedicationDF: Unit = new PatientMedications(MedicationPath, selectedIds)
      .CacheMedicationsProcessing(sparkSess, mappingPracticeProcedure, MappingPracticeMedication, mappingpracticecommondatamaster)


    val PlanOfCarePath = ApplicationConfig.prop.getProperty("PatientPlanOfCarePath")
    val PatientPlanOfCareDF: Unit = new PatientPlanOfCare(PlanOfCarePath, selectedIds)
      .PlanOfCareProcessing(sparkSess, mappingpracticecommondatamaster)


    val ResultObservationPath = ApplicationConfig.prop.getProperty("PatientResultObservationPath")
    val PatientresultObservationbDF: Unit = new PatientresultObservation(ResultObservationPath, selectedIds)
      .cacheresultObsProcessing(sparkSess, mappingpracticecommondatamaster, mappingPracticeProcedure)


    val SocialHistoryObsPath = ApplicationConfig.prop.getProperty("PatientSocialHistoryObservationPath")
    val PatientSocialHistoryObsDF: Unit = new PatientSocialHistoryObs(SocialHistoryObsPath, selectedIds)
      .cacheSocialHistoryObsProcessing(sparkSess, mappingpracticecommondatamaster)


   val VitalSignPath = ApplicationConfig.prop.getProperty("PatientVitalSignsPath")
    val PatientVitalSignDF: Unit = new PatientVitalSignObservation(VitalSignPath, selectedIds)
      .VitalSignObservationProcessing(sparkSess, mappingpracticecommondatamaster)


    val FamilyHistoryPath = ApplicationConfig.prop.getProperty("PatientFamilyHistoryPath")
    val PatientFamilyHistoryDF: Unit = new PatientFamilyHistory(FamilyHistoryPath, selectedIds)
      .FamilyHistoryProcessing(sparkSess, mappingracticecommondatamasterrelationship, mappingpracticecommondatamaster
        , MappingPracticeProblem)

    val LanguagePath = ApplicationConfig.prop.getProperty("PatientLanguagePath")
    val PatientLanguageDF: Unit = new PatientLanguage(LanguagePath, selectedIds)
      .cachepatientLangProcessing(sparkSess,mappingpracticecommondatamaster)

    val PatientNotesPath = ApplicationConfig.prop.getProperty("PatientNotePath")
     val PatientNotesDF = new PatientNote(PatientNotesPath,selectedIds)
       .PatientNoteProcessing(sparkSess)


   /* val PatientNoteProblemPath = ApplicationConfig.prop.getProperty("PatientNoteProblemPath")
    val PatientNoteProblemDF = new PatientNoteProblem(PatientNoteProblemPath,selectedIds)
      .PatientNoteProblemProcessing(sparkSess)

    val PatientNoteProcedurePath = ApplicationConfig.prop.getProperty("PatientNoteProcedurePath")
    val PatientNoteProcedureDF = new PatientNoteProcedure(PatientNoteProcedurePath,selectedIds)
      .PatientNoteProcedureProcessing(sparkSess)

    val PatientNoteMedicationPath = ApplicationConfig.prop.getProperty("PatientNoteMedicationPath")
    val PatientNoteMedicationeDF = new PatientNoteMedication(PatientNoteMedicationPath,selectedIds)
      .PatientNoteMedicationProcessing(sparkSess)

    val PatientNoteResultObservationPath = ApplicationConfig.prop.getProperty("PatientNoteResultObservationPath")
    val PatientNoteResultObservationeDF = new PatientNoteResultObservation(PatientNoteResultObservationPath,selectedIds)
      .PatientNoteResultObservationProcessing(sparkSess)

    val PatientNoteVitalSignObservationPath = ApplicationConfig.prop.getProperty("PatientNoteVitalSignObservationPath")
    val PatientNoteVitalSignObservationDF = new PatientNoteVitalSignObservation(PatientNoteVitalSignObservationPath,selectedIds)
      .PatientNoteVitalSignProcessing(sparkSess)*/


    val ImmunizationPath = ApplicationConfig.prop.getProperty("PatientImmunizationPath")
    val PatientImmunizationDF = new PatientImmunization(ImmunizationPath,selectedIds)
      .ImmunizationProcessing(sparkSess, mappingpracticecommondatamaster,
        MappingPracticeCommonDataMasterMedicationRoute, mappingPracticeProcedure,
        MappingPracticeProblem, mappingpracticecommondatamaster)

    val PatientGuardianPath = ApplicationConfig.prop.getProperty("PatientGuardianPath")
    val PatientGuardianDF = new PatientGuardian(PatientGuardianPath,selectedIds)
      .PatientGuardianProcessing(sparkSess,mappingpracticecommondatamaster)


   /* val PatientLabOrderPath = ApplicationConfig.prop.getProperty("PatientLabOrderPath")
    val PatientLabOrderDF = new PatientLabOrder(PatientLabOrderPath,selectedIds)
      .CachePatientLabOrderProcessing(sparkSess)*/

    println("end..........................................")


  }

}
