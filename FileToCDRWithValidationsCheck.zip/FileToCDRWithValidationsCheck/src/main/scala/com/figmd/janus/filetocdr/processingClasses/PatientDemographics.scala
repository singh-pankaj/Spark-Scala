package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.DemographicsTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions.{col, to_timestamp, _}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientDemographics(DemoPath: String,mappingpracticecommondatamaster : DataFrame) extends LookupMaps {


  def demoProcessing(spark: SparkSession): Option[DataFrame] = {

    import spark.implicits._

    try {
      val file = CommonFunc.readFile(DemoPath, spark)

      val file1 = file.select(file.columns.map(c => col(c).as(PatientDemographicslookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid" ,"ReligiousAffiliationCode",
      "BirthStateCode","BirthState", "BirthZipCode", "BirthCountryCode", "BirthCountry", "BirthOrder",
      "MultipleBirthPlaceIndicator")
        .withColumn("DOB", when($"DOB".contains(":"),
          when(to_timestamp(regexp_replace($"DOB","-","/"), "MM/dd/yyyy HH:mm:ss").isNull,to_timestamp(regexp_replace($"DOB","-","/"), "yyyy/MM/dd HH:mm:ss"))
            .otherwise(to_timestamp(regexp_replace($"DOB","-","/"), "MM/dd/yyyy HH:mm:ss")))
          .otherwise(when(to_timestamp(regexp_replace($"DOB","-","/"), "MM/dd/yyyy").isNull,to_timestamp(regexp_replace($"DOB","-","/"), "yyyy/MM/dd"))
            .otherwise(to_timestamp(regexp_replace($"DOB","-","/"), "MM/dd/yyyy"))))


      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatient")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatient")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatient")
      val errPath = ApplicationConfig.prop.getProperty("PatientErrPath")

      val validations = new ValidationCriteria(spark)
      //val CachepatientDemo1 = file1.withColumn("DOB", to_timestamp($"DOB", "MM/dd/yyyy"))

      //val broadcastRows = spark.sparkContext.broadcast(rows)
     // println("validation start time : "  + Calendar.getInstance.getTime)

      val CleanedRecords = file1
        .transform(validations.checkNull("PatientId","PracticeUid","First","Last","DOB","Gender"))
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid"))


      val transformObj = new DemographicsTransformFunctions(spark,mappingpracticecommondatamaster)

      val getMastarValues = CleanedRecords
        .transform(transformObj.PhonetypeText1)
        .transform(transformObj.PhonetypeText2)
        .transform(transformObj.CountryCode)
        .transform(transformObj.CountryText)
        .transform(transformObj.GenderText)
        .transform(transformObj.MaritalStatusCode)
        .transform(transformObj.MaritalStatusText)
        .withColumn("ModifiedDate", lit("null"))
        .withColumn("CreatedDate", lit("null"))
        .withColumn("MedicalRecordNumber", lit("null"))
        .withColumn("AdditionalPatientID",lit("null"))


      val tempPatUid = getMastarValues.select("PatientId", "PracticeUid").distinct()
        .withColumn("PatientUid", CommonFunc.getNewUid())

      val PatUid = tempPatUid.persist()

       val CachepatientDemo2 = getMastarValues.as("df1").join(PatUid.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("ModifiedDate", current_timestamp())
        .withColumn("CreatedDate", current_timestamp())


      HiveUtility.dfwritetohive(CachepatientDemo2,mainTableName,spark,stagetableName,s3Path)

      val errList = validations.errorList
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")

      val send3uids = CachepatientDemo2.select("PracticeUid", "PatientId", "PatientUid")
      Some(send3uids)

      /*val distinctPUid = getMastarValues.select("PracticeUid").distinct()
      val fileJoinids = getMastarValues.select("PracticeUid", "PatientId")
      broadcast(fileJoinids)

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"


      val RequiredData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      // println("RequiredData Demo Data.....  "+RequiredData.count())

      val UUIDs = RequiredData.select("PracticeUid", "PatientId", "PatientUid", "CreatedDate")
        .distinct()
      broadcast(UUIDs)

      val PreviousPatient = getMastarValues.as("df1").join(UUIDs.as("df2"),
        Seq("PracticeUid", "PatientId"), "inner").select($"df1.*", $"df2.PatientUid", $"df2.CreatedDate"
        .as("PreviousDate"))
        .withColumn("ModifiedDate", current_timestamp())
        .withColumn("CreatedDate", $"PreviousDate").drop("PreviousDate")

      //println("PreviousPatient Demo Data.....  "+PreviousPatient.count())

      val newPatient = getMastarValues.as("df1").join(UUIDs.as("df2"),
        Seq("PracticeUid", "PatientId"), "left_anti").select($"df1.*")


      val tempPatUid = newPatient.select("PatientId", "PracticeUid").distinct()
        .withColumn("PatientUid", CommonFunc.getNewUid())

      val PatUid = tempPatUid.persist()
      //broadcast(PatUid)

      val CachepatientDemo2 = newPatient.as("df1").join(PatUid.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("ModifiedDate", current_timestamp())
        .withColumn("CreatedDate", current_timestamp())

      //println("CachepatientDemo2 Demo Data.....  "+CachepatientDemo2.count())

      val OtherPatient = RequiredData.as("df1").join(fileJoinids.as("df2"),
        Seq("PracticeUid", "PatientId"), "left_anti").select($"df1.*")


      /*PreviousPatient.printSchema()
      CachepatientDemo2.printSchema()
      OtherPatient.printSchema()
*/


      val allRecords = PreviousPatient.union(CachepatientDemo2).union(OtherPatient)
        .withColumn("MedicalRecordNumber", $"PatientID")

      HiveUtility.dfwritetohive(allRecords,mainTableName,spark,stagetableName,s3Path)

      val errList = validations.errorList
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")

      val send3uids = allRecords.select("PracticeUid", "PatientId", "PatientUid")
      Some(send3uids)
*/
    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }

  }


}
