package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.ResultObsTransformFunction
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientresultObservation(ResultObservationPath: String, selectedIds: DataFrame) extends LookupMaps {

  def cacheresultObsProcessing(spark: SparkSession, mappingpracticecommondatamaster: DataFrame
                               , mappingpracticeprocedure: DataFrame): Unit = {

    import spark.implicits._
    try {

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientResultObservation")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientResultObservation")
      val errPath = ApplicationConfig.prop.getProperty("PatientResultObservationErrPath")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientResultObservation")
      //Start CacheResultObservation
      val validations = new ValidationCriteria(spark)
      var file = CommonFunc.readFile(ResultObservationPath, spark)

      val file1 = file.select(file.columns.map(c => col(c).as(PatientResultObservationlookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","obssubid","BatchUid",
          "obsinterpretationcode", "obsinterpretationtext", "negationind", "referencelowerrange", "referenceupperrange",
          "procedurecategory")



      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastPatientresultObservationRows = spark.sparkContext.broadcast(rows)

      /*
            val CleanedRecords1 = file1.filter(row => validations.checkNull(row, broadcastPatientresultObservationRows, "PatientId", "PracticeUid","ObservationValue", "ObservationDate"))

            val cachePatientResultObservationValidations = CleanedRecords1.filter(row=>validations.checkNullCodeAndText(row,broadcastPatientresultObservationRows,"ObservationCode", "ObservationName"))
      */
      val CleanedRecords = file1
        .transform(validations.checkNull("PatientId","PracticeUid","ObservationValue","ObservationDate"))
        .transform(validations.checkNullCodeAndText("PracticeCode", "PracticeDescription"))
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "PracticeCode", "PracticeDescription", "ObservationValue", "ObservationDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("PracticeCode", "PatientId", "PracticeUid", "PracticeDescription", "ObservationValue", "ObservationDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("PracticeDescription", "PracticeCode", "PatientId", "PracticeUid", "ObservationValue", "ObservationDate"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())


      //Some column is remaining
      val resultObsObj = new ResultObsTransformFunction(spark, mappingpracticecommondatamaster, mappingpracticeprocedure)

      val CacheResultObservation2 = addPatientUid
        .transform(resultObsObj.PracticeCode)
        .transform(resultObsObj.PracticeDescription)
        .transform(resultObsObj.TargetSiteCode)
        .transform(resultObsObj.TargetSiteText)
       /* .transform(resultObsObj.ObsInterpretationCode)
        .transform(resultObsObj.ObsInterpretationText)
        .transform(resultObsObj.ProcedureCode)
        .transform(resultObsObj.ProcedureText)
        .transform(resultObsObj.MethodCode)
        .transform(resultObsObj.MethodCodeText)*/
        .withColumn("ResultValue", lit(null).cast("string"))
        .withColumn("ReferenceObservationRange", lit(null).cast("string"))
        .withColumn("ObservationDescription", lit(null).cast("string"))
        .withColumn("ObservationMethod", lit(null).cast("string"))
        .withColumnRenamed("ObservationCategory","CodeSystem")
        .withColumnRenamed("ObservationDate","ResultDate")
        .withColumn("DeviceUsed", lit(null).cast("string"))
        .withColumn("Note", lit(null).cast("string"))
        .drop("ObservationValue")
        .withColumn("ResultDate", when($"ResultDate".contains(":"),to_timestamp(regexp_replace($"ResultDate","-","/"), "MM/dd/yyyy HH:mm:ss"))
          .otherwise(to_timestamp(regexp_replace($"ResultDate","-","/"), "MM/dd/yyyy")))


      HiveUtility.dfwritetohive(CacheResultObservation2, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientresultObservationRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientresultObservationRows.destroy()

      /*val distinctPUid = CacheResultObservation2.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val ResultObsData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = CacheResultObservation2.select("PracticeUid", "PatientId", "PatientUid").distinct()
      // broadcast(FiletoJoin)

      val OtherData = ResultObsData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")


     /* CacheResultObservation2.printSchema()
      OtherData.printSchema()*/

      val newstructure = CacheResultObservation2.select(OtherData.columns.head, OtherData.columns.tail: _*)

      val AllResultObsData = newstructure.union(OtherData)
      HiveUtility.dfwritetohive(AllResultObsData, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientresultObservationRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientresultObservationRows.destroy()*/


    }
    catch {
      case ex: FileNotFoundException => {
        println("File Not found" + ex)
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }
  }
}
