package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.AdvObsTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientAdvanceDirectiveObservation(AdvanceDirectivePath: String, selectedIds: DataFrame) extends LookupMaps {

  def cacheAdvObsProcessing(spark: SparkSession, mappingpracticecommondatamaster: DataFrame) {


    val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientAdvancedirective")
    val stagetableName = ApplicationConfig.prop.getProperty("StagePatientAdvanceDirectives")
    val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientAdvanceDirectives")
    val errPath = ApplicationConfig.prop.getProperty("PatientAdvancedirectiveErrPath")
    import spark.implicits._

    val validations = new ValidationCriteria(spark)

    try {
      val file = CommonFunc.readFile(AdvanceDirectivePath, spark)

      val file1 = file.select(file.columns.map(c => col(c).as(PatientAdvanceDirectiveslookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid","AgentName","ExternalDocumentLink")
        .withColumn("EffectiveStartDate", when($"EffectiveStartDate".contains(":"),to_timestamp(regexp_replace($"EffectiveStartDate","-","/"), "MM/dd/yyyy HH:mm:ss"))
        .otherwise(to_timestamp(regexp_replace($"EffectiveStartDate","-","/"), "MM/dd/yyyy")))


      // println("file count   ..... ", +file1.count())
      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastPatientAdvanceDirectiveObservationRows = spark.sparkContext.broadcast(rows)


      /*
            val CleanedRecords1 = file1.filter(row => validations.checkNull(row, broadcastPatientAdvanceDirectiveObservationRows, "PatientId","PracticeUid","EffectiveStartDate"))
            val cachePatientAdvanceDirectiveObsValidations = CleanedRecords1.filter(row => validations.checkNullCodeAndText(row,broadcastPatientAdvanceDirectiveObservationRows, "AdvanceDirectiveTypeCode", "AdvanceDirectiveTypeDetails"))
      */

      val CleanedRecords = file1
        .transform(validations.checkNull("PatientId","PracticeUid","EffectiveStartDate"))
        .transform(validations.checkNullCodeAndText("AdvanceDirectiveTypeCode", "AdvanceDirectiveTypeDetails"))
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "AdvanceDirectiveTypeCode", "AdvanceDirectiveTypeDetails", "EffectiveStartDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("AdvanceDirectiveTypeCode", "PatientId", "PracticeUid", "AdvanceDirectiveTypeDetails", "EffectiveStartDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("AdvanceDirectiveTypeDetails", "PatientId", "PracticeUid", "AdvanceDirectiveTypeCode", "EffectiveStartDate"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())


      val tf = new AdvObsTransformFunctions(spark, mappingpracticecommondatamaster)

      val cachePatientAdvObservation3 = addPatientUid
        .transform(tf.DirectiveTypeCode)
        .transform(tf.DirectiveTypeDetails)
        .transform(tf.DirectiveStatusCode)
        .transform(tf.DirectiveStatusText)

      HiveUtility.dfwritetohive(cachePatientAdvObservation3, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientAdvanceDirectiveObservationRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientAdvanceDirectiveObservationRows.destroy()

     /* val distinctPUid = cachePatientAdvObservation3.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val AdvanceDirData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cachePatientAdvObservation3.select("PracticeUid", "PatientId", "PatientUid").distinct()
      broadcast(FiletoJoin)

      val otherData = AdvanceDirData.as("df1").join(FiletoJoin.as("df2")
        , Seq("PracticeUid", "PatientId", "PatientUid"), "left_anti")
        .select($"df1.*")

     /* cachePatientAdvObservation3.printSchema()
      otherData.printSchema()*/

     val newstructure = otherData.select(cachePatientAdvObservation3.columns.head, cachePatientAdvObservation3.columns.tail: _*)

      val AllAdvObservation = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllAdvObservation, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientAdvanceDirectiveObservationRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientAdvanceDirectiveObservationRows.destroy()*/
    }

    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }

    }
  }

}
