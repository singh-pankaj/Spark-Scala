package com.figmd.janus.filetocdr.constant

import java.util.Properties

import org.apache.log4j.{Level, Logger}

object ApplicationConfig {

  var prop = new Properties

  def setApplicationConfig(args: Array[String]): Unit = {


    prop.setProperty("awsAccessKeyId", "AKIALH6XLTJCI6I3N5RQ")
    prop.setProperty("awsSecretAccessKey", "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")
   /* prop.setProperty("postgresHostName", "10.20.201.36")
    prop.setProperty("warehouse", "/user/hive/warehouse")
    prop.setProperty("postgresHostPort", "5432")
    prop.setProperty("postgresManagementDatabaseName", "figmdhqimanagementaad")
    prop.setProperty("postgresHostUserName", "postgres")
    prop.setProperty("postgresUserPass", "Janus@123")
    prop.setProperty("num_executors", "10")
    prop.setProperty("executor_cores", "5")
    prop.setProperty("executor_memory", "7G")
    prop.setProperty("spark_master_url", "yarn")
    prop.setProperty("mode", "cluster")*/
    prop.setProperty("Allergy", "mappingpracticeallergy")
    prop.setProperty("Procedure", "mappingpracticeprocedure")
    prop.setProperty("PracticeCommonData", "mappingpracticecommondatamaster")
    prop.setProperty("Ethinicity", "mappingpracticecommondatamasterethnicity")
    prop.setProperty("Race", "mappingpracticecommondatamasterrace")
    prop.setProperty("Insurance", "mappingpracticeinsurancedata")
    prop.setProperty("Problem", "MappingPracticeProblem")
    prop.setProperty("Medication", "MappingPracticeMedication")
    prop.setProperty("Route", "MappingPracticeCommonDataMasterMedicationRoute")
    prop.setProperty("RelationShip", "MappingPracticeCommonDataMasterMedicationRoute")


    //prop.setProperty("RootPath", "s3://bd-dev/AAO_RPC_TEMP")
    //prop.setProperty("RootPath", "s3://bd-dev/REGDATA_AAO_PAR_11")
    //prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_AAD")
   // prop.setProperty("RootPath", "s3://bd-dev/REGDATA_USACS_PRECDR")
    //prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_AAOHNS")
   // prop.setProperty("RootPath", "s3://bd-dev/REGDATA/REGDATA_AAD")
    val rootPath = prop.getProperty("RootPath")

    prop.setProperty("PatientPath", s"$rootPath/PatientDemographics/")
    prop.setProperty("PatientEthnicityPath", s"$rootPath/PatientEthnicity/")
    prop.setProperty("PatientRacePath", s"$rootPath/PatientRace/")
    prop.setProperty("VisitPath", s"$rootPath/PatientEncounter/")
    prop.setProperty("PatientProblemPath", s"$rootPath/PatientProblem/")
    prop.setProperty("PatientProceduresPath", s"$rootPath/PatientProcedures/")
    prop.setProperty("PatientAdvanceDirectivePath", s"$rootPath/PatientAdvanceDirective/")
    prop.setProperty("PatientAllergiesPath", s"$rootPath/PatientAllergies/")
    prop.setProperty("PatientMedicationsPath", s"$rootPath/PatientMedications/")
    prop.setProperty("PatientPlanOfCarePath", s"$rootPath/PatientPlanOfCare/")
    prop.setProperty("PatientResultObservationPath",s"$rootPath/PatientResultObservation/")
    prop.setProperty("PatientSocialHistoryObservationPath", s"$rootPath/PatientSocialHistoryObservation/")
    prop.setProperty("PatientVitalSignsPath", s"$rootPath/PatientVitalSigns/")
    prop.setProperty("PatientFamilyHistoryPath", s"$rootPath/PatientFamilyHistory/")
    prop.setProperty("PatientLanguagePath", s"$rootPath/PatientLanguage/")
    prop.setProperty("PatientNotePath", s"$rootPath/PatientNotes/")
    prop.setProperty("PatientInsurancePath",s"$rootPath/PatientPayer/")
    prop.setProperty("PatientNoteProblemPath",s"$rootPath/PatientNoteProblem/")
    prop.setProperty("PatientNoteProcedurePath",s"$rootPath/PatientNoteProcedure/")
    prop.setProperty("PatientNoteMedicationPath",s"$rootPath/PatientNoteMedication/")
    prop.setProperty("PatientNoteResultObservationPath",s"$rootPath/PatientNoteResultObservation/")
    prop.setProperty("PatientNoteVitalSignObservationPath",s"$rootPath/PatientNoteVitalSignObservation/")
    prop.setProperty("PatientImmunizationPath",s"$rootPath/PatientImmunization/")
    prop.setProperty("PatientGuardianPath",s"$rootPath/PatientGuardian/")
    prop.setProperty("PatientLabOrderPath",s"$rootPath/PatientLabOrder/")


    //prop.setProperty("dbName","2018_11_15_aao")
    //prop.setProperty("dbName","2018_11_19_maindb")
    //prop.setProperty("dbName","finaldbstucture")

    val dbName = prop.getProperty("dbName")
    prop.setProperty("CDRPatient",s"$dbName.patient")
    prop.setProperty("CDRPatientEthnicity",s"$dbName.patientethnicity")
    prop.setProperty("CDRPatientRace",s"$dbName.patientrace")
    prop.setProperty("CDRVisit",s"$dbName.visit")
    prop.setProperty("CDRPatientProblem",s"$dbName.patientproblem")
    prop.setProperty("CDRPatientProcedures",s"$dbName.patientprocedure")
    prop.setProperty("CDRPatientAdvancedirective",s"$dbName.patientadvancedirective")
    prop.setProperty("CDRPatientInsurance",s"$dbName.patientinsurance")
    prop.setProperty("CDRPatientAllergies",s"$dbName.patientallergy")
    prop.setProperty("CDRPatientMedications",s"$dbName.patientmedication")
    prop.setProperty("CDRPatientPlanOfCare",s"$dbName.patientplanofcare")
    prop.setProperty("CDRPatientResultObservation",s"$dbName.patientresultobservation")
    prop.setProperty("CDRPatientSocialHistoryObservation",s"$dbName.patientsocialhistoryobservation")
    prop.setProperty("CDRPatientVitalSigns",s"$dbName.patientvitalsignobservation")
    prop.setProperty("CDRPatientFamilyHistory",s"$dbName.patientfamilyhistory")
    prop.setProperty("CDRPatientLanguage",s"$dbName.patientlanguage")
    prop.setProperty("CDRPatientNotes",s"$dbName.patientnote")
    prop.setProperty("CDRPatientNoteProblem",s"$dbName.patientnoteproblem")
    prop.setProperty("CDRPatientNoteProcedure",s"$dbName.patientnoteprocedure")
    prop.setProperty("CDRPatientNoteMedication",s"$dbName.patientnotemedication")
    prop.setProperty("CDRPatientNoteResultObservation",s"$dbName.patientnoteresultobservation")
    prop.setProperty("CDRPatientNoteVitalSignObservation",s"$dbName.patientnotevitalsignobservation")
    prop.setProperty("CDRPatientImmunization",s"$dbName.patientimmunization")
    prop.setProperty("CDRPatientGuardian",s"$dbName.patientguardian")
    prop.setProperty("CDRPatientLabOrder",s"$dbName.patientlaborder")


    //prop.setProperty("errFileRootPath", "s3://bd-dev/ErrorLogs/aad_20181126_newstructure/AAD")
    val errFileRootPath = prop.getProperty("errFileRootPath")

    //prop.setProperty("stageDB","2018_11_17_stagedb")
    //prop.setProperty("stageDB","aad_20181126_newstructure")
    val stageDB = prop.getProperty("stageDB")

    //prop.setProperty("s3Path","s3://bd-dev/Staging/aad_20181126_newstructure/")
    val s3Path = prop.getProperty("s3Path")

    prop.setProperty("StagePatient",s"$stageDB.Patient")
    prop.setProperty("s3LocationPatient",s"$s3Path/patient_stage/")

    prop.setProperty("StagePatientEthnicity",s"$stageDB.PatientEthnicity")
    prop.setProperty("s3LocationPatientEthnicity",s"$s3Path/Ethnicity_stage/")

    prop.setProperty("StagePatientRace",s"$stageDB.PatientRace")
    prop.setProperty("s3LocationPatientRace",s"$s3Path/Race_stage/")

    prop.setProperty("StageVisit",s"$stageDB.Visit")
    prop.setProperty("s3LocationVisit",s"$s3Path/Visit_stage/")

    prop.setProperty("StagePatientInsurance",s"$stageDB.PatientInsurance")
    prop.setProperty("s3LocationPatientInsurance",s"$s3Path/Insurance_Stage/")

    prop.setProperty("StagePatientProblem",s"$stageDB.PatientProblem")
    prop.setProperty("s3LocationPatientProblem",s"$s3Path/Problem_stage/")

    prop.setProperty("StagePatientProcedures",s"$stageDB.PatientProcedure")
    prop.setProperty("s3LocationPatientProcedures",s"$s3Path/Procedure_stage/")

    prop.setProperty("StagePatientAdvanceDirectives",s"$stageDB.PatientAdvanceDirective")
    prop.setProperty("s3LocationPatientAdvanceDirectives",s"$s3Path/AdvanceDirectives_stage/")

    prop.setProperty("StagePatientAllergy",s"$stageDB.PatientAllergy")
    prop.setProperty("s3LocationPatientAllergy",s"$s3Path/Allergy_stage/")

    prop.setProperty("StagePatientMedications",s"$stageDB.PatientMedication")
    prop.setProperty("s3LocationPatientMedications",s"$s3Path/Medication_stage/")

    prop.setProperty("StagePatientPlanOfCare",s"$stageDB.PatientPlanOfCare")
    prop.setProperty("s3LocationPatientPlanOfCare",s"$s3Path/PlanOfCare_stage/")

    prop.setProperty("StagePatientResultObservation",s"$stageDB.PatientResultObservation")
    prop.setProperty("s3LocationPatientResultObservation",s"$s3Path/ResultObs_stage/")

    prop.setProperty("StagePatientSocialHistoryObservation",s"$stageDB.PatientSocialHistoryObservation")
    prop.setProperty("s3LocationPatientSocialHistoryObservation",s"$s3Path/SocialHisObs_stage/")

    prop.setProperty("StagePatientVitalSigns",s"$stageDB.PatientVitalSignObservation")
    prop.setProperty("s3LocationPatientVitalSigns",s"$s3Path/VitalSignObs_stage/")

    prop.setProperty("StagePatientFamilyHistory",s"$stageDB.PatientFamilyHistory")
    prop.setProperty("s3LocationPatientFamilyHistory",s"$s3Path/FamilyHistory_stage/")

    prop.setProperty("StagePatientLanguage",s"$stageDB.PatientLanguage")
    prop.setProperty("s3LocationPatientLanguage",s"$s3Path/PatientLang_stage/")

    prop.setProperty("StagePatientNote",s"$stageDB.PatientNote")
    prop.setProperty("s3LocationPatientNote",s"$s3Path/PatientNotes_stage/")

    prop.setProperty("StagePatientNoteProblem",s"$stageDB.PatientNoteProblem")
    prop.setProperty("s3LocationPatientNoteProblem",s"$s3Path/PatientNoteProblem_stage/")

    prop.setProperty("StagePatientNoteProcedure",s"$stageDB.PatientNoteProcedure")
    prop.setProperty("s3LocationPatientNoteProcedure",s"$s3Path/PatientNoteProcedure_stage/")

    prop.setProperty("StagePatientNoteMedication",s"$stageDB.PatientNoteMedication")
    prop.setProperty("s3LocationPatientNoteMedication",s"$s3Path/PatientNoteMedication_stage/")

    prop.setProperty("StagePatientNoteResultObservation",s"$stageDB.PatientNoteResultObservation")
    prop.setProperty("s3LocationPatientNoteResultObservation",s"$s3Path/PatientNoteResultObservation_stage/")

    prop.setProperty("StagePatientNoteVitalSignObservation",s"$stageDB.PatientNoteVitalSignObservation")
    prop.setProperty("s3LocationPatientNoteVitalSignObservation",s"$s3Path/PatientNoteVitalSignObservation_stage/")

    prop.setProperty("StagePatientImmunization",s"$stageDB.PatientImmunization")
    prop.setProperty("s3LocationPatientImmunization",s"$s3Path/PatientImmunization_stage/")

    prop.setProperty("StagePatientGuardian",s"$stageDB.PatientImmunization")
    prop.setProperty("s3LocationPatientGuardian",s"$s3Path/PatientImmunization_stage/")

    prop.setProperty("StagePatientLabOrder",s"$stageDB.PatientLabOrder")
    prop.setProperty("s3LocationPatientLabOrder",s"$s3Path/PatientLabOrder_stage/")

    prop.setProperty("PatientErrPath", s"$errFileRootPath/PatientErrFiles/")
    prop.setProperty("PatientEthnicityErrPath", s"$errFileRootPath/PatientEthnicityErrFiles/")
    prop.setProperty("PatientRaceErrPath", s"$errFileRootPath/PatientRaceErrFiles/")
    prop.setProperty("VisitErrPath", s"$errFileRootPath/VisitErrFiles/")
    prop.setProperty("PatientProblemErrPath", s"$errFileRootPath/PatientProblemErrFiles/")
    prop.setProperty("PatientProceduresErrPath", s"$errFileRootPath/PatientProceduresErrFiles/")
    prop.setProperty("PatientAdvancedirectiveErrPath", s"$errFileRootPath/PatientAdvancedirectiveErrFiles/")
    prop.setProperty("PatientAllergiesErrPath", s"$errFileRootPath/PatientAllergiesErrFiles/")
    prop.setProperty("PatientMedicationsErrPath", s"$errFileRootPath/PatientMedicationsErrFiles/")
    prop.setProperty("PatientPlanOfCareErrPath", s"$errFileRootPath/PatientPlanOfCareErrFiles/")
    prop.setProperty("PatientResultObservationErrPath", s"$errFileRootPath/PatientResultObservationErrFiles/")
    prop.setProperty("PatientSocialHistoryObservationErrPath", s"$errFileRootPath/PatientSocialHistoryObservationErrFiles/")
    prop.setProperty("PatientVitalSignsErrPath", s"$errFileRootPath/PatientVitalSignsErrFiles/")
    prop.setProperty("PatientFamilyHistoryErrPath", s"$errFileRootPath/PatientFamilyHistoryErrFiles/")
    prop.setProperty("PatientLanguageErrPath", s"$errFileRootPath/PatientLanguageErrFiles/")
    prop.setProperty("PatientNoteErrPath", s"$errFileRootPath/PatientNoteErrFiles/")
    prop.setProperty("PatientInsuranceErrPath", s"$errFileRootPath/PatientNoteErrFiles/")
    prop.setProperty("PatientNoteProblemErrPath", s"$errFileRootPath/PatientNoteProblemErrFiles/")
    prop.setProperty("PatientNoteProcedureErrPath", s"$errFileRootPath/PatientNoteProcedureErrFiles/")
    prop.setProperty("PatientNoteMedicationErrPath", s"$errFileRootPath/PatientNoteMedicationErrFiles/")
    prop.setProperty("PatientNoteVitalSignObservationErrPath", s"$errFileRootPath/PatientNoteVitalSignObservationErrFiles/")
    prop.setProperty("PatientImmunizationErrPath", s"$errFileRootPath/PatientImmunizationErrFiles/")
    prop.setProperty("PatientGuardianErrPath", s"$errFileRootPath/PatientGuardianErrFiles/")
    prop.setProperty("PatientLabOrderErrPath", s"$errFileRootPath/PatientLabOrderErrFiles/")


    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)
    Logger.getLogger("myLogger").setLevel(Level.OFF)


  }
}
