package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.ProcedureTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientProcedure(ProcedurePath: String, selectedIds: DataFrame) extends LookupMaps {


  def cachePatientProcedureProceesing(spark: SparkSession, mappingPracticeProcedure: DataFrame
                                      , mappingpracticecommondatamaster: DataFrame) {

    import spark.implicits._

    try {

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientProcedures")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientProcedures")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientProcedures")
      val errPath = ApplicationConfig.prop.getProperty("PatientProceduresErrPath")
      val validations = new ValidationCriteria(spark)

      val file = CommonFunc.readFile(ProcedurePath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientProcedurelookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid", "ServiceProviderLastName",
          "ServiceProviderFirstName", "ServiceLocationId", "ServiceLocationName")
        .withColumn("EffectiveDate", when($"EffectiveDate".contains(":"),to_timestamp(regexp_replace($"EffectiveDate","-","/"), "MM/dd/yyyy HH:mm:ss"))
          .otherwise(to_timestamp(regexp_replace($"EffectiveDate","-","/"), "MM/dd/yyyy")))


      val rows = new util.ArrayList[Row]()
      val broadcastPatientProcedureRows = spark.sparkContext.broadcast(rows)
      val schema = file1.schema.add(StructField("ErrorMessage", StringType))

      /*
            val CleanedRecords1 = file1.filter(row => validations.checkNull(row, broadcastPatientProcedureRows, "PatientId","PracticeUid", "ProcedureDate"))

            val cachePatientProcedureValidations = CleanedRecords1.filter(row => validations.checkNullCodeAndText(row, broadcastPatientProcedureRows, "ProcedureCode", "ProcedureText"))
      */

      val CleanedRecords = file1.distinct()
       // .transform(validations.checkNull("PatientId","PracticeUid","EffectiveDate"))
        //.transform(validations.checkNullCodeAndText("ProcedureCode", "ProcedureDescription"))
        //.transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "ProcedureDescription", "ProcedureCode", "EffectiveDate", "ServiceProviderNPI"))
      //  .transform(validations.removeDuplicateWhenTextOrCodeIsNull("ProcedureCode", "ProcedureDescription", "PatientId", "PracticeUid", "EffectiveDate", "ServiceProviderNPI"))
        //transform(validations.removeDuplicateWhenTextOrCodeIsNull("ProcedureDescription", "ProcedureCode", "PatientId", "PracticeUid", "EffectiveDate", "ServiceProviderNPI"))
        //.transform(validations.removeDuplicateWhenTextOrCodeIsNull("ServiceProviderNPI", "ProcedureDescription", "ProcedureCode", "PatientId", "PracticeUid", "EffectiveDate"))
        //.transform(validations.removeDuplicateWhenCol1OrCol2IsNull("ServiceProviderNPI", "ProcedureDescription", "ProcedureCode", "PatientId", "PracticeUid", "EffectiveDate"))
        //.transform(validations.removeDuplicateWhenCol1OrCol2IsNull("ServiceProviderNPI", "ProcedureCode", "ProcedureDescription", "PatientId", "PracticeUid", "EffectiveDate"))

      //println("CleanedRecords count    "+CleanedRecords.count())

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())

     // println("addPatientUid count    "+addPatientUid.count())

      val ProcedureObj = new ProcedureTransformFunctions(spark, mappingPracticeProcedure, mappingpracticecommondatamaster)

      val cachePatientProcedure = addPatientUid
        .transform(ProcedureObj.PracticeCode)
        .transform(ProcedureObj.PracticeDescription)
        .transform(ProcedureObj.ProcedureStatusCode)
        .transform(ProcedureObj.ProcedureStatusText)
        .transform(ProcedureObj.TargetSiteCode)
        .transform(ProcedureObj.TargetSiteText)
        .withColumnRenamed("ProcedureCategory","CodeSystem")
        .withColumn("ProcedureNote", lit("null"))
        .withColumn("FollowupDate", lit("null"))
        .withColumn("InsuranceName", lit("null"))
        .withColumn("PayerId", lit("null"))

      //println("cachePatientProcedure count    "+cachePatientProcedure.count())

      HiveUtility.dfwritetohive(cachePatientProcedure, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientProcedureRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientProcedureRows.destroy()

    /*  val distinctPUid = cachePatientProcedure.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val ProcedureData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cachePatientProcedure.select("PracticeUid", "PatientId", "PatientUid").distinct()
      broadcast(FiletoJoin)

      val OtherData = ProcedureData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")


      /*cachePatientProcedure.printSchema()
      OtherData.printSchema()*/

      val newstructure = cachePatientProcedure.select(OtherData.columns.head, OtherData.columns.tail: _*)
      val allProcedureData = newstructure.union(OtherData)
      HiveUtility.dfwritetohive(allProcedureData, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientProcedureRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientProcedureRows.destroy()*/


    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }
  }

}
