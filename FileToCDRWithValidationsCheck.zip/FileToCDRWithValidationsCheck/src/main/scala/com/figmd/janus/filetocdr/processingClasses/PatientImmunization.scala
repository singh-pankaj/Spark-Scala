package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.CacheImmunizationTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}


class PatientImmunization(ImmunizationPath: String, selectedIds: DataFrame) extends LookupMaps {

  def ImmunizationProcessing(spark: SparkSession, mappingpracticecommondatamaster: DataFrame,
                             MappingPracticeCommonDataMasterMedicationRoute: DataFrame, MappingPracticeProcedure: DataFrame,
                             MappingPracticeProblem: DataFrame, MappingPracticeCommonDataMaster: DataFrame
                            ): Unit = {
    import spark.implicits._

    //Read required tables for CachePatientImmunization

    /*
    //Create map of file indices and column names
    val cachePatientImmunizationMapDF: Dataset[Row] = rt.joinedDf
      .filter($"CacheTableViewName"==="ViewCachePatientImmunization")
    val lookup: collection.Map[String, String] = getLookupMap(cachePatientImmunizationMapDF)
  */

    try {

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientImmunization")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientImmunization")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientImmunization")
      val errPath = ApplicationConfig.prop.getProperty("PatientImmunizationErrPath")
      val validations = new ValidationCriteria(spark)

      //Read file for CachePatientImmunizationPatientEthnicityText
      val file: DataFrame = CommonFunc.readFile(ImmunizationPath, spark)

      val CachePatientImmunization: DataFrame = file.select(file.columns.map(c => col(c).as(PatientImmunizationlookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid")
       // .withColumn("ImmuStartDate", to_timestamp($"ImmuStartDate", "MM/dd/yyyy HH:mm:ss"))


      // .transform(validations.checkNull("PatientId","PracticeUid"))
      // .transform(validations.checkNullCodeAndText("MedicationCode", "MedicationName"))
      //.transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "PracticePatientMedicationKey"))

      val CleanedRecords = CachePatientImmunization
        .transform(validations.checkNull("PatientId","PracticeUid","ImmunizationStartDate"))
        .transform(validations.checkNullCodeAndText("ImmunizationCode","ImmunizationName"))
        .transform(validations.removeDuplicateRecords("PatientId","PracticeUid","ImmunizationStartDate","ImmunizationCode","ImmunizationName"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("ImmunizationCode","PatientId","PracticeUid","ImmunizationStartDate","ImmunizationName"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("ImmunizationName","PatientId","PracticeUid","ImmunizationStartDate","ImmunizationCode"))



      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())

      //Get required functions for CachePatientImmunization
      val patientImmunization = new CacheImmunizationTransformFunctions(spark, mappingpracticecommondatamaster
        , MappingPracticeCommonDataMasterMedicationRoute, MappingPracticeProcedure, MappingPracticeProblem
        , MappingPracticeCommonDataMaster)

      val transformImmunization = addPatientUid
        .transform(patientImmunization.ImmunizationName)
        .transform(patientImmunization.ImmunizationCode)
        .transform(patientImmunization.MedicationRouteText)
        .transform(patientImmunization.MedicationRouteCode)
       // .transform(patientImmunization.ProcedureText)
        //.transform(patientImmunization.ProcedureCode)
        .transform(patientImmunization.MedicationIndicationProblemText)
        .transform(patientImmunization.MedicationIndicationProblemCode)
       // .transform(patientImmunization.MedicationReactionProblemText)
        //.transform(patientImmunization.MedicationReactionProblemCode)
        //.transform(patientImmunization.MedicationReactionProblemSeverityText)
       // .transform(patientImmunization.MedicationReactionProblemSeverityCode)
        .transform(patientImmunization.MedicationStatusText)
        .transform(patientImmunization.MedicationStatusCode)
        .withColumn("Strength",lit("null"))
        .withColumn("StrengthUnitCode",lit("null"))
        .withColumn("StrengthUnitText",lit("null"))
        .withColumn("FillerOrderNumber",lit("null"))
        .withColumn("OrderingProviderFirstName",lit("null"))
        .withColumn("OrderingProviderMiddleName",lit("null"))
        .withColumn("OrderingProviderLastName",lit("null"))
        .withColumn("EnteringOrganization",lit("null"))
        .withColumn("PlacerOrderNumber",lit("null"))

      HiveUtility.dfwritetohive(transformImmunization, mainTableName, spark, stagetableName, s3Path)

/*
      val distinctPUid = transformImmunization.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val ImmunizationData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val fileJoinids = transformImmunization.select("PracticeUid", "PatientId", "PatientUid").distinct()
      broadcast(fileJoinids)

      val OtherData = ImmunizationData.as("df1").join(fileJoinids.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

      transformImmunization.printSchema()
      OtherData.printSchema()

      val newstructure = transformImmunization.select(OtherData.columns.head, OtherData.columns.tail: _*)

      val AllImmunizationData = newstructure.union(OtherData)

      HiveUtility.dfwritetohive(AllImmunizationData, mainTableName, spark, stagetableName, s3Path)*/

    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
      }
    }

  }
}


