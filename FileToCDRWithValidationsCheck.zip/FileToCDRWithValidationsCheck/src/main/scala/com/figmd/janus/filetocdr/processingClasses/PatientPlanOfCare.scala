package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.PlanOfCareTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientPlanOfCare(PlanOfCarePath: String, selectedIds: DataFrame) extends LookupMaps {


  def PlanOfCareProcessing(spark: SparkSession, mappingpracticecommondatamaster: DataFrame) {

    /*
  //Create map of file indices and column names
  val cachePatientPlanOfCareMapDF: Dataset[Row] = rt.joinedDf
    .filter($"CacheTableViewName"==="ViewCachePatientPlanOfCare")
  val lookup: collection.Map[String, String] = getLookupMap(cachePatientPlanOfCareMapDF)
  */

    try {

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientPlanOfCare")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientPlanOfCare")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientPlanOfCare")
      val errPath = ApplicationConfig.prop.getProperty("PatientPlanOfCareErrPath")
      val validations = new ValidationCriteria(spark)


      //Read file for CachePatientPlanOfCare
      import spark.implicits._
      val file: DataFrame = CommonFunc.readFile(PlanOfCarePath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientPlanOfCarelookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid")
        .withColumn("EffectiveDate", when($"EffectiveDate".contains(":"),to_timestamp(regexp_replace($"EffectiveDate","-","/"), "MM/dd/yyyy HH:mm:ss"))
          .otherwise(to_timestamp(regexp_replace($"EffectiveDate","-","/"), "MM/dd/yyyy")))


      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastPatientPlanOfCareRows = spark.sparkContext.broadcast(rows)

      /*
            val cachePatientPlanOfCareValidations = file1.filter(row => validations.checkNull(row, broadcastPatientPlanOfCareRows, "PatientId", "PracticeUid", "EffectiveDate"))

            val cleanedRecords1 = cachePatientPlanOfCareValidations.filter(row=>validations.checkNullCodeAndText(row,broadcastPatientPlanOfCareRows,"PlanOfCareCode", "PlanOfCareText"))
      */

      val CleanedRecords = file1
        .transform(validations.checkNull("PatientId","PracticeUid","EffectiveDate"))
        .transform(validations.checkNullCodeAndText("PlanOfCareCode", "PlanOfCareText"))
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "PlanOfCareCode", "PlanOfCareText", "EffectiveDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("PlanOfCareCode", "PatientId", "PracticeUid", "PlanOfCareText", "EffectiveDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("PlanOfCareText", "PatientId", "PracticeUid", "PlanOfCareCode", "EffectiveDate"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())


      //Get required functions for CachePatientPlanOfCare
      val patientPlanOfCare = new PlanOfCareTransformFunctions(spark, mappingpracticecommondatamaster)

      val transformPatientPlanOfCareDF = addPatientUid
        .transform(patientPlanOfCare.PlanOfCareStatusText)
        .transform(patientPlanOfCare.PlanOfCareStatusCode)
        .transform(patientPlanOfCare.PlanOfCareText)
        .transform(patientPlanOfCare.PlanOfCareCode)
        .withColumn("ServiceProviderLastName", lit(null).cast("string"))
        .withColumn("ServiceProviderNPI", lit(null).cast("string"))
        .withColumn("ServiceProviderFirstName", lit(null).cast("string"))

      HiveUtility.dfwritetohive(transformPatientPlanOfCareDF, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientPlanOfCareRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientPlanOfCareRows.destroy()

     /* val distinctPUid = transformPatientPlanOfCareDF.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val PlanOfCareData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = transformPatientPlanOfCareDF.select("PracticeUid", "PatientId", "PatientUid").distinct()
      //broadcast(FiletoJoin)

      val OtherData = PlanOfCareData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

     /* transformPatientPlanOfCareDF.printSchema()
      OtherData.printSchema()*/

      val newstructure = transformPatientPlanOfCareDF.select(OtherData.columns.head, OtherData.columns.tail: _*)

      val AllPlanOfCareData = newstructure.union(OtherData)
      HiveUtility.dfwritetohive(AllPlanOfCareData, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientPlanOfCareRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientPlanOfCareRows.destroy()*/

    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }
  }
}
