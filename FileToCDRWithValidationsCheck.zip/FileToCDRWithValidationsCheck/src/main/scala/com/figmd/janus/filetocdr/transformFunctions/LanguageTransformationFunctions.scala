package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.when

class LanguageTransformationFunctions (spark:SparkSession,mappingpracticecommondatamaster:DataFrame){
  import spark.implicits._

  def LanguageCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.LanguageCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterLanguageCode")
        , $"df2.CodeDescription".as("MasterLanguageText"))
  }

  def LanguageText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.LanguageText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedMasterLanguageCode")
        , $"df2.CodeDescription".as("MappedMasterLanguageText"))
      .withColumn("MasterLanguageCode", when($"MappedMasterLanguageCode".isNull, $"MasterLanguageCode")
        .otherwise($"MappedMasterLanguageCode"))
      .withColumn("MasterLanguageText", when($"MappedMasterLanguageText".isNull, $"MasterLanguageText")
        .otherwise($"MappedMasterLanguageText"))
      .drop("MappedMasterLanguageCode", "MappedMasterLanguageText")
  }

  def LangaugeAbilityModeText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.LangaugeAbilityModeText" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MasterLangaugeAbilityModeText"))
  }

  def LanguageProficiencyLevelText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.LanguageProficiencyLevelText" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MasterLanguageProficiencyLevelText"))
  }


}
