package com.figmd.janus.filetocdr.util

import com.amazonaws.auth.{AWSStaticCredentialsProvider, BasicAWSCredentials}
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import com.amazonaws.services.s3.model.GetObjectRequest
import com.figmd.janus.filetocdr.constant.ApplicationConfig

import scala.io.Source

class ReadConfigFile(bucketname : String,filename : String) {

  val credentials = new BasicAWSCredentials("AKIALH6XLTJCI6I3N5RQ","svYK1gMbrlTJNWq8DUK355KyEUpYlhU+/+Rpk5y8")
 // val credentials = new BasicAWSCredentials("AKIAJC2BI34Q3U2RAHKA","TAgxUwck8azCQFSufpC+UW6d/c7Puh7HB2GShRY2")

  val s3Client = AmazonS3ClientBuilder.standard()
    .withCredentials(new AWSStaticCredentialsProvider(credentials))
    .build()

  val s3Object = s3Client.getObject(new GetObjectRequest(bucketname,filename))
  val myData = Source.fromInputStream(s3Object.getObjectContent).getLines.filter(l => !l.startsWith("#")).toArray

  for(property<- myData){
    val sp = property.split("=")
    val key = sp(0)
    val value = sp(1)
    ApplicationConfig.prop.setProperty(key,value)
    //println(key+" ++>>>> "+ApplicationConfig.prop.getProperty(key))
  }
}
