package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.ProblemTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientProblem(ProblemPath: String, selectedIds: DataFrame) extends LookupMaps {

  def cachePatientProblemProcessing(spark: SparkSession, mappingpracticeproblem: DataFrame) = {

    val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientProblem")
    val stagetableName = ApplicationConfig.prop.getProperty("StagePatientProblem")
    val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientProblem")
    val errPath = ApplicationConfig.prop.getProperty("PatientProblemErrPath")
    val validations = new ValidationCriteria(spark)

    import spark.implicits._

    try {
      val file = CommonFunc.readFile(ProblemPath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientProblemlookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid","NegationInd")
        .withColumn("DocumentationDate", when($"DocumentationDate".contains(":"),to_timestamp(regexp_replace($"DocumentationDate","-","/"), "MM/dd/yyyy HH:mm:ss"))
        .otherwise(to_timestamp(regexp_replace($"DocumentationDate","-","/"), "MM/dd/yyyy")))


      val rows = new util.ArrayList[Row]()
      val broadcastPatientProblemRows = spark.sparkContext.broadcast(rows)
      val schema = file1.schema.add(StructField("ErrorMessage", StringType))

      /*
            val cachePatientProblemValidations = file1.filter(row => validations.checkNull(row, broadcastPatientProblemRows, "PatientId","PracticeUid", "DocumentationDate"))

            val ClanedRecords1 = cachePatientProblemValidations.filter(row=>validations.checkNullCodeAndText(row,broadcastPatientProblemRows, "ProblemCode", "ProblemText"))
      */

      val CleanedRecords = file1
       // .transform(validations.checkNull("PatientId","PracticeUid","DocumentationDate"))
       // .transform(validations.checkNullCodeAndText("ProblemCode", "ProblemText"))
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "ProblemText", "ProblemCode", "DocumentationDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("ProblemCode", "PatientId", "PracticeUid", "problemtext", "DocumentationDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("ProblemText", "PatientId", "PracticeUid", "ProblemCode", "DocumentationDate"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())

      val problemObj = new ProblemTransformFunctions(spark, mappingpracticeproblem)

      val cachePatientProblem = addPatientUid
        .transform(problemObj.ProblemCode)
        .transform(problemObj.ProblemText)
        .transform(problemObj.ProblemStatusCode)
        .transform(problemObj.ProblemStatusText)
        .transform(problemObj.ProblemHealthStatusCode)
        .transform(problemObj.ProblemHealthStatusText)
        .transform(problemObj.TargetSiteCode)
        .transform(problemObj.TargetSiteText)
        .withColumn("Problem_Severity", lit("null"))
        .withColumn("Problem_Source", lit("null"))
        .withColumn("Problem_Sequence", lit("null"))


      HiveUtility.dfwritetohive(cachePatientProblem, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientProblemRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientProblemRows.destroy()

/*
      val distinctPUid = cachePatientProblem.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val ProblemData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cachePatientProblem.select("PracticeUid", "PatientId", "PatientUid")
        .distinct()
      broadcast(FiletoJoin)

      val OtherData = ProblemData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

     /* cachePatientProblem.printSchema()
      OtherData.printSchema()*/

      val newstructure = cachePatientProblem.select(OtherData.columns.head, OtherData.columns.tail: _*)

      val AllProblemData = newstructure.union(OtherData)
      HiveUtility.dfwritetohive(AllProblemData, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientProblemRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientProblemRows.destroy()*/
    }

    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
      }
    }
  }

}
