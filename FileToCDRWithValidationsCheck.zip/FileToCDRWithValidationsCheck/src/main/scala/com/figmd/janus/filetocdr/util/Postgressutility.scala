package com.figmd.janus.filetocdr.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import org.apache.spark.sql.{DataFrame, SparkSession}

class Postgressutility(sparkSess : SparkSession) {


  def getPostgresTable(tableName: String): DataFrame = {
    sparkSess.read
      .format("jdbc")
      .option("url", "jdbc:postgresql://" + ApplicationConfig.prop.getProperty("postgresHostName") + ":" + ApplicationConfig.prop.getProperty("postgresHostPort") + "/" + ApplicationConfig.prop.getProperty("postgresManagementDatabaseName"))
      //.option("dbtable", s"select PracticeUid, PracticeValue, PracticeDescription, Code, CodeDescription from $tableName")
      .option("dbtable", tableName)
      .option("user", ApplicationConfig.prop.getProperty("postgresHostUserName"))
      .option("password", ApplicationConfig.prop.getProperty("postgresUserPass"))
      .load()
  }

  def getPostgresTableAllCols(tableName: String): DataFrame = {
    sparkSess.read
      .format("jdbc")
      .option("url", "jdbc:postgresql://" + ApplicationConfig.prop.getProperty("postgresHostName") + ":" + ApplicationConfig.prop.getProperty("postgresHostPort") + "/" + ApplicationConfig.prop.getProperty("postgresManagementDatabaseName"))
      .option("dbtable", tableName)
      .option("user", ApplicationConfig.prop.getProperty("postgresHostUserName"))
      .option("password", ApplicationConfig.prop.getProperty("postgresUserPass"))
      .load()
  }
}
