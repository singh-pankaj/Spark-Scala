package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.MedicationTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientMedications(MedicationPath: String, selectedIds: DataFrame) extends LookupMaps {


  def CacheMedicationsProcessing(spark: SparkSession, MappingPracticeProcedure: DataFrame, MappingPracticeMedication: DataFrame,
                                 MappingPracticeCommonDataMaster: DataFrame) {
    import spark.implicits._


    try {
      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientMedications")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientMedications")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientMedications")
      val errPath = ApplicationConfig.prop.getProperty("PatientMedicationsErrPath")

      val validations = new ValidationCriteria(spark)


      val file: DataFrame = CommonFunc.readFile(MedicationPath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientMedicationslookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid", "dosequantityunitcode", "dosequantityunittext", "procedurecategory",
          "serviceproviderlastname", "serviceproviderfirstname", "supplyprescriberlastname",
          "supplyprescriberfirstname", "supplyperformerlastname", "supplyperformerfirstname",
          "medicationindicationcriteria", "medicationindicationproblemcategory", "medicationreactionproblemcategory",
          "medicationreactionproblemseveritytext")
        .withColumn("StartDate", when($"StartDate".contains(":"),to_timestamp(regexp_replace($"StartDate","-","/"), "MM/dd/yyyy HH:mm:ss"))
        .otherwise(to_timestamp(regexp_replace($"StartDate","-","/"), "MM/dd/yyyy")))

      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastPatientMedicationsRows = spark.sparkContext.broadcast(rows)


      /*
            val CleanedRecords1 = file1.filter(row => validations.checkNull(row, broadcastPatientMedicationsRows, "PatientId","PracticeUid"))

            val cachePatientMedicationValidations = CleanedRecords1.filter(row=>validations.checkNullCodeAndText(row,broadcastPatientMedicationsRows,"MedicationCode", "MedicationName"))
      */

      val CleanedRecords = file1.distinct()
       // .transform(validations.checkNull("PatientId","PracticeUid"))
       // .transform(validations.checkNullCodeAndText("MedicationCode", "MedicationName"))
        //.transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "PracticePatientMedicationKey"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())


      //Get required functions for CacheMedications
      val medications = new MedicationTransformFunctions(spark, MappingPracticeProcedure, MappingPracticeMedication, MappingPracticeCommonDataMaster)

      val transformMedicationsDF = addPatientUid
        //.transform(medications.ProcedureText)
       // .transform(medications.ProcedureCode)
        .transform(medications.MedicationName)
        .transform(medications.MedicationCode)
        .transform(medications.MedicationProductFormText)
        .transform(medications.MedicationProductFormCode)
        //.transform(medications.MedicationIndicationProblemText)
        //.transform(medications.MedicationIndicationProblemCode)
        .transform(medications.MedicationReactionProblemText)
        .transform(medications.MedicationReactionProblemCode)
        .transform(medications.MedicationReactionProblemSeverityText)
        .transform(medications.MedicationReactionProblemSeverityCode)
        .transform(medications.MedicationStatusText)
        .transform(medications.MedicationStatusCode)
        .transform(medications.MedicationRouteText)
        .withColumn("Sig", lit(null).cast("string"))
        .withColumn("refillsRemaining", lit(null).cast("string"))
        .withColumn("MedicationAdministrationCategory", lit(null).cast("string"))
        .withColumn("minDosePerPeriod", lit(null).cast("string"))
        .withColumn("MedSite", lit(null).cast("string"))
        .withColumn("Note", lit(null).cast("string"))
        .withColumn("ReasonForDiscontinuation", lit(null).cast("string"))
        .withColumn("StrengthUnitsCode", lit(null).cast("string"))
        .withColumn("StrengthUnitsText", lit(null).cast("string"))
        .withColumn("Strength", lit(null).cast("string"))
        .withColumn("Strength", lit(null).cast("string"))
        .withColumn("ProductForm", $"MedicationProductFormText")
        .withColumnRenamed("RepeatNumber", "RefillQuantity")
        .withColumn("Route", $"MedicationRouteText")

      HiveUtility.dfwritetohive(transformMedicationsDF, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientMedicationsRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientMedicationsRows.destroy()


      /*val distinctPUid = transformMedicationsDF.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val MedicationData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = transformMedicationsDF.select("PracticeUid", "PatientId", "PatientUid").distinct()
      broadcast(FiletoJoin)

      val OtherData = MedicationData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

     /* transformMedicationsDF.printSchema()
      OtherData.printSchema()
*/
      val newstructure = transformMedicationsDF.select(OtherData.columns.head, OtherData.columns.tail: _*)

      val AllMedicationData = newstructure.union(OtherData)
      HiveUtility.dfwritetohive(AllMedicationData, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientMedicationsRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientMedicationsRows.destroy()*/
    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
      }
    }
  }


}
