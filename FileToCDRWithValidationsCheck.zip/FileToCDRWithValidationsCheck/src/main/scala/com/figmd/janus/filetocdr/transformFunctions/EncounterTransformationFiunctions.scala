package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.when

class EncounterTransformationFiunctions (spark:SparkSession, mappingpracticecommondatamaster:DataFrame){


  import spark.implicits._
//  Masterencountertypecode
//  Masterencountertypetext



  def encountertypecode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.EncounterTypeCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterEncounterTypeCode")
        , $"df2.CodeDescription".as("MasterEncounterTypeText"))
  }

  def encountertypetext(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.EncounterTypeText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("mappedMasterencountertypecode")
        , $"df2.CodeDescription".as("MappedMasterencountertypetext"))
      .withColumn("MasterEncounterTypeCode", when($"mappedMasterencountertypecode".isNull
        , $"MasterEncounterTypeCode")
        .otherwise($"mappedMasterencountertypecode"))
      .withColumn("MasterEncounterTypeText", when($"MappedMasterencountertypetext".isNull
        , $"MasterEncounterTypeText")
        .otherwise($"MappedMasterencountertypetext"))
      .drop("mappedMasterencountertypecode", "MappedMasterencountertypetext")
  }


}
