package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.LanguageTransformationFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions.{col, current_timestamp}
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientLanguage(LanguagePath: String, selectedIds: DataFrame) extends LookupMaps {


  def cachepatientLangProcessing(spark: SparkSession,mappingpracticecommondatamaster : DataFrame) {


    //Start ImportPatientLanguageData

    try {

      import spark.implicits._
      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientLanguage")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientLanguage")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientLanguage")
      val errPath = ApplicationConfig.prop.getProperty("PatientLanguageErrPath")

      val validations = new ValidationCriteria(spark)

      val file = CommonFunc.readFile(LanguagePath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientLanguagelookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid","LanguageProficiencyLevelCode","LangaugeAbilityModeCode")

      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastPatientLanguageRows = spark.sparkContext.broadcast(rows)

      /*
            val cachePatientLanguageValidations = file1.filter(row => validations.checkNull(row, broadcastPatientLanguageRows, "PatientId","PracticeUid"))

            val CleanedRecords1 = cachePatientLanguageValidations.filter(row=>validations.checkNullCodeAndText(row,broadcastPatientLanguageRows, "LanguageCode", "LanguageText"))
      */

      val CleanedRecords = file1
        .transform(validations.checkNull("PatientId","PracticeUid"))
        .transform(validations.checkNullCodeAndText("LanguageCode", "LanguageText"))
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "LanguageCode", "LanguageText"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("LanguageCode", "PatientId", "PracticeUid", "LanguageText"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("LanguageText", "LanguageCode", "PatientId", "PracticeUid"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())


      val langObj = new LanguageTransformationFunctions(spark,mappingpracticecommondatamaster)

      val mastervalues = addPatientUid
        .transform(langObj.LanguageCode)
        .transform(langObj.LanguageText)
        .transform(langObj.LangaugeAbilityModeText)
        .transform(langObj.LanguageProficiencyLevelText)


      HiveUtility.dfwritetohive(mastervalues, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientLanguageRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientLanguageRows.destroy()

/*
      val distinctPUid = mastervalues.select("PracticeUid").distinct()
      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val LanguageData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = mastervalues.select("PracticeUid", "PatientId", "PatientUid").distinct()
      //broadcast(FiletoJoin)

      val OtherData = LanguageData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

     /* mastervalues.printSchema()
      OtherData.printSchema()*/

      val newstructure = mastervalues.select(OtherData.columns.head, OtherData.columns.tail: _*)

      val AllLanguageData = newstructure.union(OtherData)
      HiveUtility.dfwritetohive(AllLanguageData, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientLanguageRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientLanguageRows.destroy()*/

    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }
}
