package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions.{broadcast, col, lit}
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientNoteProcedure(PatientNoteProcedurePath: String, selectedIds: DataFrame) extends LookupMaps {


  def PatientNoteProcedureProcessing(spark: SparkSession) {


    try {

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientNoteProcedure")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientNoteProcedure")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientNoteProcedure")
      val errPath = ApplicationConfig.prop.getProperty("PatientNoteProcedureErrPath")

      val validations = new ValidationCriteria(spark)

      import spark.implicits._
      val file = CommonFunc.readFile(PatientNoteProcedurePath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientNoteslookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid")


      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastPatientNoteRows = spark.sparkContext.broadcast(rows)

      /*
            val CleanedRecords1 = file1.filter(row => validations.checkNull(row, broadcastPatientNoteRows, "PatientId","PracticeUid","EncounterDate","Note"))
      */

      val CleanedRecords = file1
        .transform(validations.checkNull("PatientId","PracticeUid","EncounterDate","Note"))
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "PracticePatientNoteKey"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("Type",lit("null"))


      val distinctPUid = addPatientUid.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val NotesProcedureData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = addPatientUid.select("PracticeUid", "PatientId", "PatientUid")
      broadcast(FiletoJoin)

      val OtherData = NotesProcedureData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

      val newstructure = addPatientUid.select(OtherData.columns.head, OtherData.columns.tail: _*)

      val AllNotesProcedureData = newstructure.union(OtherData)

      HiveUtility.dfwritetohive(AllNotesProcedureData, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientNoteRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientNoteRows.destroy()
    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        unknown.printStackTrace()

      }
    }
  }
}