package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.InsuranceTransformFunction
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions.{broadcast, col, current_timestamp, lit}
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientInsurance(InsurancePath: String, selectedIds: DataFrame) extends LookupMaps {

  def cachePatientinsuranceprocessing(sparkSess: SparkSession, MasterInsurance: DataFrame) = {
    //Start CachePayer

    try {

      import sparkSess.implicits._

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientInsurance")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientInsurance")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientInsurance")
      val errPath = ApplicationConfig.prop.getProperty("PatientInsuranceErrPath")
      val validations = new ValidationCriteria(sparkSess)


      val file = CommonFunc.readFile(InsurancePath, sparkSess)


      val file1 = file.select(file.columns.map(c => col(c).as(PatientInsuranceLookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid")

      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastPatientInsuranceRows = sparkSess.sparkContext.broadcast(rows)

      /*
            val RemoveDupInsurance = file1.filter(row => validations.checkNull(row, broadcastPatientInsuranceRows, "PatientId", "PracticeUid", "InsurancePlan", "DocumentationDate"))
      */

      val CleanedRecords = file1
        .transform(validations.checkNull("PatientId","PracticeUid","InsurancePlan","DocumentationDate"))
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "InsurancePlan"
          , "InsuranceCompany", "DocumentationDate", "policyId"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("PolicyId", "PatientId"
          , "PracticeUid", "InsurancePlan", "InsuranceCompany", "DocumentationDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("InsuranceCompany"
          , "PatientId", "PracticeUid", "InsurancePlan", "PolicyId", "DocumentationDate"))
        .transform(validations.removeDuplicateWhenCol1OrCol2IsNull("PolicyId", "InsuranceCompany",
          "PatientId", "PracticeUid", "InsurancePlan", "DocumentationDate"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())



      val InsuranceObj = new InsuranceTransformFunction(sparkSess, MasterInsurance)

      val CacheInsurance = addPatientUid
        .transform(InsuranceObj.InsuredRelationToPatientCode)
        .withColumn("GroupMemberID", lit("null"))
        .withColumn("IsMedicarePartB", lit("null"))
        .withColumn("Note", lit("null"))
        .withColumn("Address", lit("null"))
        .withColumnRenamed("InsuranceOrder", "ListOrder")
        .withColumnRenamed("InsuredPersonId", "PlanMemberID")
        .withColumn("CoverageRoleTypeText", $"InsuredRelationToPatientText")
        //.withColumn("ExternalID",lit("null"))


      HiveUtility.dfwritetohive(CacheInsurance, mainTableName, sparkSess, stagetableName, s3Path)

      val errList = validations.errorList += sparkSess.createDataFrame(broadcastPatientInsuranceRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")

      broadcastPatientInsuranceRows.destroy()

     /* val distinctPUid = CacheInsurance.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val InsuranceData = sparkSess.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val fileJoinids = CacheInsurance.select("PracticeUid", "PatientUid", "PatientId").distinct()
      broadcast(fileJoinids)

      val OtherData = InsuranceData.as("df1").join(fileJoinids.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId", "left_anti")
        .select($"df1.*")

     /* CacheInsurance.printSchema()
      OtherData.printSchema()*/

      val newstructure = CacheInsurance.select(OtherData.columns.head, OtherData.columns.tail: _*)
      val AllInsuranceData = newstructure.union(OtherData)

      HiveUtility.dfwritetohive(AllInsuranceData, mainTableName, sparkSess, stagetableName, s3Path)

      val errList = validations.errorList += sparkSess.createDataFrame(broadcastPatientInsuranceRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")

      broadcastPatientInsuranceRows.destroy()*/
    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }
  }
}
