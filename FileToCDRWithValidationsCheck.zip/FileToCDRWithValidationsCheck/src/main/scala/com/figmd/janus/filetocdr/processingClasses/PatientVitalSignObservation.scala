package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.VitalSignObsTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientVitalSignObservation(VitalSignPath: String, selectedIds: DataFrame) extends LookupMaps {

  def VitalSignObservationProcessing(spark: SparkSession, mappingpracticecommondatamaster: DataFrame
                                    ) = {
    import spark.implicits._

    try {
      println("Vital Sign start...........")
      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientVitalSigns")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientVitalSigns")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientVitalSigns")
      val errPath = ApplicationConfig.prop.getProperty("PatientVitalSignsErrPath")
      val validations = new ValidationCriteria(spark)

      //Read file for CachePatientVitalSignObservation
      val file: DataFrame = CommonFunc.readFile(VitalSignPath, spark)

      val file1 = file.select(file.columns.map(c => col(c).as(PatientVitalSignslookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid",
          "ObsInterpretationCode", "ObsInterpretationText", "ReferenceLowerRange", "ReferenceUpperRange",
          "MethodCode", "MethodCodeText")
        .withColumn("ObservationDate", when($"ObservationDate".contains(":"),to_timestamp(regexp_replace($"ObservationDate","-","/"), "MM/dd/yyyy HH:mm:ss"))
        .otherwise(to_timestamp(regexp_replace($"ObservationDate","-","/"), "MM/dd/yyyy")))



      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastPatientVitalSignObservationRows = spark.sparkContext.broadcast(rows)

      /*
            val CleanedRecords1 = file1.filter(row => validations.checkNull(row, broadcastPatientVitalSignObservationRows, "PatientId", "PracticeUid","ObservationValue", "ObservationDate"))

            val cachePatientVitalSignsObservationValidations = CleanedRecords1.filter(row=>validations.checkNullCodeAndText(row,broadcastPatientVitalSignObservationRows,"ObservationCode", "ObservationName"))
      */

      val CleanedRecords = file1
        .transform(validations.checkNull("PatientId","PracticeUid","ObservationValue","ObservationDate"))
        .transform(validations.checkNullCodeAndText("ObservationCode", "ObservationName"))
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "ObservationCode", "ObservationName", "ObservationValue", "ObservationDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("ObservationCode", "PatientId", "PracticeUid", "ObservationName", "ObservationValue", "ObservationDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("ObservationName", "ObservationCode", "PatientId", "PracticeUid", "ObservationValue", "ObservationDate"))


      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())

      val patientVitalSignObservationDF = new VitalSignObsTransformFunctions(spark, mappingpracticecommondatamaster)

      val transformPatientVitalSignObservationDF = addPatientUid
        .transform(patientVitalSignObservationDF.PracticeDescription)
        .transform(patientVitalSignObservationDF.PracticeCode)
        //.transform(patientVitalSignObservationDF.TargetSiteText)
        //.transform(patientVitalSignObservationDF.TargetSiteCode)
        //.transform(patientVitalSignObservationDF.ObsInterpretationText)
        //.transform(patientVitalSignObservationDF.ObsInterpretationCode)
        .withColumn("ResultValue", lit(null).cast("string"))
        .withColumn("ReferenceObservationRange", lit(null).cast("string"))
        .drop("ObservationValue")


      HiveUtility.dfwritetohive(transformPatientVitalSignObservationDF, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientVitalSignObservationRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientVitalSignObservationRows.destroy()


   /*   val distinctPUid = transformPatientVitalSignObservationDF.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val vitalsignData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = transformPatientVitalSignObservationDF.select("PracticeUid", "PatientId", "PatientUid")
        .distinct()
      broadcast(FiletoJoin)

      val OtherData = vitalsignData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

      /*transformPatientVitalSignObservationDF.printSchema()
      OtherData.printSchema()
*/
      val newstructure = transformPatientVitalSignObservationDF.select(OtherData.columns.head, OtherData.columns.tail: _*)

      val AllVitalSignData = newstructure.union(OtherData)
      HiveUtility.dfwritetohive(AllVitalSignData, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientVitalSignObservationRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientVitalSignObservationRows.destroy()*/


    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }

}
