package com.figmd.janus.filetocdr.validationFunctions

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import scala.util.control.Breaks.{break, breakable}
import scala.collection.mutable.ListBuffer


class ValidationCriteria(spark: SparkSession) extends Serializable {

  import spark.implicits._

  var errorList: ListBuffer[DataFrame] = ListBuffer[DataFrame]()

  def errorRecords(df: List[DataFrame]): DataFrame = {

    val errorDF = df.reduce(_ union _)
    errorDF

  }

  /*
    def checkNull(row: Row, rows1: Broadcast[util.ArrayList[Row]], columns: String*): Boolean = {
      var flag = false
      var ErrorMessage: String = null

      breakable {
        for (col <- columns) {
          print(col)
          if (row.isNullAt(row.fieldIndex(col)) || row.get(row.fieldIndex(col)).toString.replaceAll("\\s", "") == "") {
            ErrorMessage = s"$col not found"
            rows1.value.add(Row.merge(row, Row(ErrorMessage)))
            flag = false
            break()
          }
          else
            flag = true
        }
      }

      flag
    }
  */

  def checkNull(columns: String*)(input:DataFrame):DataFrame = {
    var flag = false
    var ErrorMessage: String = null
    var newlist: ListBuffer[Row] = ListBuffer[Row]()
    val schema = input.schema.add(StructField("ErrorMessage", StringType))
    for (row <- input.collect()) {
      breakable {
        for (col <- columns) {
          if (row.isNullAt(row.fieldIndex(col)) || row.get(row.fieldIndex(col)).toString.replaceAll("\\s", "") == "") {
            ErrorMessage = s"$col not found"
            val errorRow = Row.merge(row, Row(ErrorMessage))
            newlist.append(errorRow)
            flag = false
            break()
          }
          else
            flag = true
        }
      }

    }
    val errorlist = spark.sparkContext.parallelize(newlist)
    val errorDf = spark.createDataFrame(errorlist,schema)
    errorList += errorDf

    val goodDF = input.except(errorDf.drop("ErrorMessage"))
    goodDF
  }

  def checkNullCode(column: String)(df: DataFrame): DataFrame = {

    val errorDF = df.filter($"$column".isNull || $"$column" === "")
      .withColumn("ErrorMessage", lit(s"$column Not Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF

  }

  /*
    def checkNullPatientIdPracticeUidDate(Date:String)(df:DataFrame): DataFrame = {

      val errorDF = df.filter(($"PatientId".isNull && trim($"PatientId" === "")) || ($"PracticeUid".isNull && trim($"PracticeUid" === "")) || ($"$Date".isNull && trim($"$Date" === "")))
        .withColumn("ErrorMessage" , lit(s"Date  And Date Not Found"))

      val goodDF = df.except(errorDF.drop("ErrorMessage"))

      errorList += errorDF

      goodDF

    }
  */

  def checkNullCodeAndText(code: String, text: String)(df: DataFrame): DataFrame = {

    val errorDF = df.filter(($"$code".isNull && $"$code" === "") && ($"$text".isNull && $"$text" === ""))
      .withColumn("ErrorMessage", lit(s"$code  And $text Not Found"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF

  }

  /*
    def checkNullCodeAndText(row: Row, rows1: Broadcast[util.ArrayList[Row]], code: String, text:String): Boolean = {
      var flag = false
      var ErrorMessage: String = null

      if ((row.isNullAt(row.fieldIndex(code)) || row.get(row.fieldIndex(code)).toString.replaceAll("\\s", "") == "")
        && (row.isNullAt(row.fieldIndex(text)) || row.get(row.fieldIndex(text)).toString.replaceAll("\\s", "") == "")){
        ErrorMessage = s"$code and $text not found"
        rows1.value.add(Row.merge(row, Row(ErrorMessage)))
        flag = false
      }
      else{
        flag = true
      }

      flag
    }
  */

  def
  removeDuplicateRecords(list: String*)(df: DataFrame): DataFrame = {
    val RankDf = df
      .withColumn("rank", row_number().over(Window.partitionBy(list.head, list.tail: _*).orderBy(list.head)))

    val goodDF = RankDf.filter(col("rank") === 1).drop("rank")

    val errorDF = RankDf.filter(col("rank") > 1).drop("rank")
      .withColumn("ErrorMessage", lit("Duplicate record"))

    errorList += errorDF

    goodDF
  }

  def removeDuplicateWhenTextOrCodeIsNull(TextOrCode: String, column_combo: String*)(df: DataFrame): DataFrame = {
    val RankDf = df.withColumn("rank", when($"$TextOrCode".isNull, row_number().over(Window.partitionBy(column_combo.head)
      .orderBy(column_combo.head, column_combo.tail: _*))).otherwise(lit(1)))

    val goodDF = RankDf.filter(col("rank") === 1).drop("rank")

    val errorDF = RankDf.filter(col("rank") > 1).drop("rank")
      .withColumn("ErrorMessage", lit("Duplicate record"))

    errorList += errorDF

    goodDF

  }

  def removeDuplicateWhenCol1OrCol2IsNull(col1: String, col2: String, column_combo: String*)(df: DataFrame): DataFrame = {
    val RankDf = df.filter($"$col1".isNull && $"$col2".isNull)
      .withColumn("rank", row_number().over(Window.partitionBy(column_combo.head, column_combo.tail: _*).orderBy(column_combo.head)))

    val goodDF = RankDf.filter(col("rank") === 1).drop("rank")

    val errorDF = RankDf.filter(col("rank") > 1).drop("rank")
      .withColumn("ErrorMessage", lit("Duplicate record"))

    errorList += errorDF

    goodDF

  }


  def invalidNPIFound(df: DataFrame): DataFrame = {
    val errorDF = df.filter(length(col("ServiceProviderNPI")) =!= 10)
      .withColumn("ErrorMessage", lit("Invalid NPI Found,Length should be 10"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def invalidObservationCodeFound(df: DataFrame): DataFrame = {
    val errorDF = df.filter(col("ObservationName") === "")
      .withColumn("ErrorMessage", lit("Invalid ObservationCode Found without ObservationName"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def invalidPayerIdFound(df: DataFrame): DataFrame = {
    val errorDF = df.filter(length(col("payerid")) =!= 50)
      .withColumn("ErrorMessage", lit("Invalid PayerId"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def invalidPolicyIdFound(df: DataFrame): DataFrame = {
    val errorDF = df.filter(length(col("PolicyId")) =!= 50)
      .withColumn("ErrorMessage", lit(" Invalid policyid"))
    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }


  def differentMRNForSamePatientWithSSN(df: DataFrame): DataFrame = {

    val errorDF = df.as("df1").join(df.as("df2"), $"df1.FirstName" === $"df2.FirstName"
      && $"df1.PracticeUid" === $"df2.PracticeUid"
      && $"df1.DOB" === $"df2.DOB"
      && $"df1.LastName" === $"df2.LastName"
      && $"df1.SSN" === $"df2.SSN").where($"df1.PatientId" =!= $"df2.PatientId")
      .select($"df1.*")
      .withColumn("ErrorMessage", lit("Different MRN Found For Same firstname,lastname,dob,SSN,PracticeUid"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

  def differentMRNForSamePatientWithoutSSN(df: DataFrame): DataFrame = {

    val errorDF = df.as("df1").join(df.as("df2"), $"df1.FirstName" === $"df2.FirstName"
      && $"df1.PracticeUid" === $"df2.PracticeUid"
      && $"df1.DOB" === $"df2.DOB"
      && $"df1.LastName" === $"df2.LastName").where($"df1.PatientId" =!= $"df2.PatientId")
      .select($"df1.*")
      .withColumn("ErrorMessage", lit("Different MRN Found For Same firstname,lastname,dob,PracticeUid"))

    val goodDF = df.except(errorDF.drop("ErrorMessage"))

    errorList += errorDF

    goodDF
  }

}
