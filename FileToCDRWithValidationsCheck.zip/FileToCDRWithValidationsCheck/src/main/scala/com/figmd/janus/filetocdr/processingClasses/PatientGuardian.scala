package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.GuardianTransformationFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}


class PatientGuardian(PatientGuardianPath: String, selectedIds: DataFrame) extends LookupMaps {


  def PatientGuardianProcessing(spark: SparkSession,mappingpracticecommondatamaster : DataFrame) {

    /*
  //Create map of file indices and column names
  val cachePatientGuardianMapDF: Dataset[Row] = rt.joinedDf
    .filter($"CacheTableViewName"==="ViewCachePatientGuardian")
  val lookup: collection.Map[String, String] = getLookupMap(cachePatientGuardianMapDF)
  */


    try {

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientGuardian")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientGuardian")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientGuardian")
      val errPath = ApplicationConfig.prop.getProperty("PatientGuardianErrPath")


      //Read file for CachePatientGuardian
      val file: DataFrame = CommonFunc.readFile(PatientGuardianPath, spark)

      import spark.implicits._
      //Apply lookup to generate file Header
      val CachePatientGuardianDF: DataFrame = file.select(file.columns.map(c => col(c).as(PatientGuardianlookup.getOrElse(c, c))): _*)
        .drop("dummy1","dummy2","BatchUid")

      val validations = new ValidationCriteria(spark)



      val CleanedRecords = CachePatientGuardianDF
        .transform(validations.checkNull("PatientId","PracticeUid","GuardianFirstName"))
        .transform(validations.checkNullCodeAndText("RelationshipToPatientCode","RelationshipToPatientText"))
        .transform(validations.removeDuplicateRecords("RelationshipToPatientCode","RelationshipToPatientText","PatientId","PracticeUid","GuardianFirstName"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("RelationshipToPatientCode","RelationshipToPatientText","PatientId","PracticeUid","GuardianFirstName"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("RelationshipToPatientText","RelationshipToPatientCode","PatientId","PracticeUid","GuardianFirstName"))


      val addPatientUid1 = CleanedRecords.as("df1").join(selectedIds.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())


      val ImmunizationObj = new GuardianTransformationFunctions(spark,mappingpracticecommondatamaster)

      val masterValues = addPatientUid1
        .transform(ImmunizationObj.RelationshipToPatientCode)
        .transform(ImmunizationObj.RelationshipToPatientText)

      HiveUtility.dfwritetohive(masterValues, mainTableName, spark, stagetableName, s3Path)

     /* val distinctPUid = masterValues.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val PatientGuardianData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = masterValues.select("PracticeUid", "PatientId", "PatientUid")
      broadcast(FiletoJoin)

      val OtherData = PatientGuardianData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

    /*  masterValues.printSchema()
      OtherData.printSchema()*/

      val newstructure = masterValues.select(OtherData.columns.head, OtherData.columns.tail: _*)

      val AllPatientguardianData = newstructure.union(OtherData)
      HiveUtility.dfwritetohive(AllPatientguardianData, mainTableName, spark, stagetableName, s3Path)*/

    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }
}
