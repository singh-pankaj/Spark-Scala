package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.SocialHistoryObsTransformFunc
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientSocialHistoryObs(SocialHistoryObsPath: String, selectedIds: DataFrame) extends LookupMaps {

  def cacheSocialHistoryObsProcessing(spark: SparkSession, mappingpracticecommondatamaster: DataFrame) {

    import spark.implicits._


    try {
      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientSocialHistoryObservation")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientSocialHistoryObservation")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientSocialHistoryObservation")
      val errPath = ApplicationConfig.prop.getProperty("PatientSocialHistoryObservationErrPath")
      val validations = new ValidationCriteria(spark)

      val file = CommonFunc.readFile(SocialHistoryObsPath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientsocialHistorylookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid")
        .withColumn("DocumentationDate", when($"DocumentationDate".contains(":"),to_timestamp(regexp_replace($"DocumentationDate","-","/"), "MM/dd/yyyy HH:mm:ss"))
          .otherwise(to_timestamp(regexp_replace($"DocumentationDate","-","/"), "MM/dd/yyyy")))



      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastPatientSocialHistoryObsRows = spark.sparkContext.broadcast(rows)

      /*
            val cachePatientSocialHistObservationValidations = file1.filter(row => validations.checkNull(row, broadcastPatientSocialHistoryObsRows
              , "PatientId", "PracticeUid","SocialHistoryObservedValue","DocumentationDate"))
      */

      val CleanedRecords = file1
        .transform(validations.checkNull("PatientId","PracticeUid","SocialHistoryObservedValue","DocumentationDate"))
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "SocialHistoryObservedValue"
          , "SocialHistoryTypeCode", "SocialHistoryTypeText", "DocumentationDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("SocialHistoryTypeCode"
          , "PatientId", "PracticeUid", "SocialHistoryObservedValue", "SocialHistoryTypeText", "DocumentationDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("SocialHistoryTypeText"
          , "PatientId", "PracticeUid", "SocialHistoryObservedValue", "SocialHistoryTypeCode", "DocumentationDate"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())


      val tf = new SocialHistoryObsTransformFunc(spark, mappingpracticecommondatamaster)

      val cacheSocialHistoryObs3 = addPatientUid
        .transform(tf.SocialHistoryTypeCode)
        .transform(tf.SocialHistoryTypeText)
        .transform(tf.SocialHistoryStatusCode)
        .transform(tf.SocialHistoryStatusText)
        .withColumn("Note", lit("null"))

      HiveUtility.dfwritetohive(cacheSocialHistoryObs3, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientSocialHistoryObsRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientSocialHistoryObsRows.destroy()

  /*    val distinctPUid = cacheSocialHistoryObs3.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val SocialHisObsData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cacheSocialHistoryObs3.select("PracticeUid", "PatientId", "PatientUid").distinct()
      broadcast(FiletoJoin)

      val OtherData = SocialHisObsData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PatientId" === $"df2.PatientId" && $"df1.PracticeUid" === $"df2.PracticeUid" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

/*
      cacheSocialHistoryObs3.printSchema()
      OtherData.printSchema()*/

      val newstructure = cacheSocialHistoryObs3.select(OtherData.columns.head, OtherData.columns.tail: _*)

      val AllSocialHistoryData = newstructure.union(OtherData)
      HiveUtility.dfwritetohive(AllSocialHistoryData, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientSocialHistoryObsRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientSocialHistoryObsRows.destroy()*/


    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }
}
