package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.RaceTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientRace(RacePath: String, selectedIds: DataFrame) extends LookupMaps {


  def cacheRaceProcessing(spark: SparkSession, MasterRace: DataFrame) = {


    val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientRace")
    val stagetableName = ApplicationConfig.prop.getProperty("StagePatientRace")
    val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientRace")
    val errPath = ApplicationConfig.prop.getProperty("PatientRaceErrPath")
    val validations = new ValidationCriteria(spark)

    import spark.implicits._

    try {
      val file = CommonFunc.readFile(RacePath, spark)
      val file1 = file.select(file.columns.map(c => col(c).as(PatientRacelookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid")

     // println("Race count  ....   " + file1.count)
      val rows = new util.ArrayList[Row]()
      val broadcastPatientRaceRows = spark.sparkContext.broadcast(rows)
      val schema = file1.schema.add(StructField("ErrorMessage", StringType))

      /*
            val CleanedRecords1 = file1.filter(row => validations.checkNull(row, broadcastPatientRaceRows
              , "PatientId","PracticeUid"))

            val cachePatientRaceValidations = CleanedRecords1.filter(row=>validations.checkNullCodeAndText(row
              ,broadcastPatientRaceRows, "PatientRaceCode", "PatientRaceText"))
      */

      val CleanedRecords = file1
        .transform(validations.checkNull("PatientId","PracticeUid"))
        .transform(validations.checkNullCodeAndText("PatientRaceCode", "PatientRaceText"))
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "PatientRaceText", "PatientRaceCode"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("PatientRaceCode", "PatientId", "PracticeUid", "PatientRaceText"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("PatientRaceText", "PatientRaceCode", "PatientId", "PracticeUid"))


      //println("Race CleanedRecords..    " + CleanedRecords.count())

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())


      val raceObj = new RaceTransformFunctions(spark, MasterRace)

      val CachePatientRace = addPatientUid
        .transform(raceObj.PatientRaceText)
        .transform(raceObj.PatientRaceCode)


      HiveUtility.dfwritetohive(CachePatientRace, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientRaceRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientRaceRows.destroy()

    /*  val distinctPUid = CachePatientRace.select("PracticeUid").distinct()
      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val RaceData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val fileJoinids = CachePatientRace.select("PracticeUid", "PatientUid", "PatientId").distinct()
      broadcast(fileJoinids)

      val OtherData = RaceData.as("df1").join(fileJoinids.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")

     /* CachePatientRace.printSchema()
      OtherData.printSchema()*/

      val newstructure = CachePatientRace.select(OtherData.columns.head, OtherData.columns.tail: _*)

      val AllRaceData = newstructure.union(OtherData)

      HiveUtility.dfwritetohive(AllRaceData, mainTableName, spark, stagetableName, s3Path)

      val errList = validations.errorList += spark.createDataFrame(broadcastPatientRaceRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientRaceRows.destroy()*/
    }
    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }
    }

  }

}
