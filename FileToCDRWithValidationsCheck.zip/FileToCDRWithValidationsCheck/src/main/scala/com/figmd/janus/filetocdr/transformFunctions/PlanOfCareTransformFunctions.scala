package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}

class PlanOfCareTransformFunctions(spark: SparkSession, mappingpracticecommondatamaster: DataFrame) {


  import spark.implicits._

  def PlanOfCareStatusText(df: DataFrame): DataFrame = {
    df.as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PlanOfCareStatusText" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MasterPlanOfCareStatusText"))
  }

  def PlanOfCareStatusCode(df: DataFrame): DataFrame = {
    df.as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PlanOfCareStatusCode" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterPlanOfCareStatusText", when($"MappedValue2".isNull
        , $"MasterPlanOfCareStatusText").otherwise($"MappedValue2"))
      .drop( "MappedValue2")
  }

  def PlanOfCareText(df: DataFrame): DataFrame = {
    df.as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PlanOfCareText" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterPlanOfCareCode")
        , $"df2.CodeDescription".as("MasterPlanOfCareText"))
  }

  def PlanOfCareCode(df: DataFrame): DataFrame = {
    df.as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PlanOfCareCode" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedValue1")
        , $"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterPlanOfCareCode", when($"MappedValue1".isNull
        , $"MasterPlanOfCareCode").otherwise($"MappedValue1"))
      .withColumn("MasterPlanOfCareText", when($"MappedValue2".isNull
        , $"MasterPlanOfCareText").otherwise($"MappedValue2"))
      .drop("MappedValue1", "MappedValue2")
  }
}
