package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.when

class GuardianTransformationFunctions (spark:SparkSession,mappingpracticecommondatamaster:DataFrame){

  import spark.implicits._


  def RelationshipToPatientCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.RelationshipToPatientCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*",$"df2.CodeDescription".as("MasterRelationshipToPatientText"))
  }

  def RelationshipToPatientText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.RelationshipToPatientText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MappedMasterRelationshipToPatientText"))
      .withColumn("MasterRelationshipToPatientText", when($"MappedMasterRelationshipToPatientText".isNull, $"MasterRelationshipToPatientText")
        .otherwise($"MappedMasterRelationshipToPatientText"))
      .drop("MappedMasterRelationshipToPatientText")
  }

  
}
