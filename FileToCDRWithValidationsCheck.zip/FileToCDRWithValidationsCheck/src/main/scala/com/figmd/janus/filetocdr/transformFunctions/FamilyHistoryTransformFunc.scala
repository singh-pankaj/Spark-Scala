package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}

class FamilyHistoryTransformFunc(sparkSess: SparkSession
                                 , mappingpractivecommondatamasterrelationship: DataFrame
                                 , mappingpracticecommondatamaster: DataFrame
                                 , mappingpracticeproblem: DataFrame) {

  import sparkSess.implicits._

  def RelationshipToPatientCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpractivecommondatamasterrelationship.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.RelationshipToPatientCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MasterRelationshipToPatientText"))
  }


  def RelationshipToPatientText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.RelationshipToPatientText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MappedMasterRelationshipToPatientText"))
      .withColumn("MasterRelationshipToPatientText", when($"MappedMasterRelationshipToPatientText".isNull, $"MasterRelationshipToPatientText")
        .otherwise($"MappedMasterRelationshipToPatientText"))
      .drop( "MappedMasterRelationshipToPatientText")

  }

  /*def ProblemTypeCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemTypeCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterProblemTypeCode")
        , $"df2.CodeDescription".as("MasterProblemTypeText"))

  }

  def ProblemTypeText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemTypeText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedMasterProblemTypeCode")
        , $"df2.CodeDescription".as("MappedMasterProblemTypeText"))
      .withColumn("MasterProblemTypeCode", when($"MappedMasterProblemTypeCode".isNull, $"MasterProblemTypeCode")
        .otherwise($"MappedMasterProblemTypeCode"))
      .withColumn("MasterProblemTypeText", when($"MappedMasterProblemTypeText".isNull, $"MasterProblemTypeText")
        .otherwise($"MappedMasterProblemTypeText"))
      .drop("MappedMasterProblemTypeCode", "MappedMasterProblemTypeText")

  }

  def ProblemCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MasterProblemCode")
        , $"df2.CodeDescription".as("MasterProblemDescription"))

  }

  def ProblemDescription(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticeproblem.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.ProblemDescription" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.Code".as("MappedMasterProblemCode")
        , $"df2.CodeDescription".as("MappedMasterProblemDescription"))
      .withColumn("MasterProblemCode", when($"MappedMasterProblemCode".isNull, $"MasterProblemCode")
        .otherwise($"MappedMasterProblemCode"))
      .withColumn("MasterProblemDescription", when($"MappedMasterProblemDescription".isNull, $"MasterProblemDescription")
        .otherwise($"MappedMasterProblemDescription"))
      .drop("MappedMasterProblemCode", "MappedMasterProblemDescription")

  }*/

}
