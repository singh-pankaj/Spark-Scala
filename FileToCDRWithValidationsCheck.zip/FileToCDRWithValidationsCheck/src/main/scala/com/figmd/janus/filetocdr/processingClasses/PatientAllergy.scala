package com.figmd.janus.filetocdr.processingClasses

import java.io.FileNotFoundException
import java.util

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.transformFunctions.AllergyTransformFunctions
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

class PatientAllergy(AllergiesPath: String, selectedIds: DataFrame) extends LookupMaps {


  def cacheAllergyProcessing(spark: SparkSession, masterAllergy: DataFrame, mappingpracticecommondatamaster: DataFrame
                            ) {

    try {
      import spark.implicits._

      val validations = new ValidationCriteria(spark)

      val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientAllergies")
      val stagetableName = ApplicationConfig.prop.getProperty("StagePatientAllergy")
      val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientAllergy")
      val errPath = ApplicationConfig.prop.getProperty("PatientAllergiesErrPath")

      val file = CommonFunc.readFile(AllergiesPath, spark)

      val file1 = file.select(file.columns.map(c => col(c).as(PatientAllergieslookup.getOrElse(c, c))): _*)
        .drop("dummy1", "dummy2","BatchUid")
        //.withColumn("EffectiveStartDate", to_timestamp($"EffectiveStartDate", "MM/dd/yyyy"))
       // .withColumn("EffectiveEndDate", to_timestamp($"EffectiveEndDate", "MM/dd/yyyy"))


      val schema = file1.schema.add(StructField("ErrorMessage", StringType))
      val rows = new util.ArrayList[Row]()
      val broadcastPatientAllergyRows = spark.sparkContext.broadcast(rows)

      /*
            val CleanedRecords1 = file1.filter(row => validations.checkNull(row, broadcastPatientAllergyRows, "PatientId","PracticeUid","EffectiveStartDate"))

            val cachePatientAllergyValidations = CleanedRecords1.filter(row=>validations.checkNullCodeAndText(row,broadcastPatientAllergyRows, "AllergicToCode", "AllergicToDescription"))
      */


      val CleanedRecords = file1
        .transform(validations.checkNull("PatientId","PracticeUid","DocumentationDate"))
        .transform(validations.removeDuplicateRecords("PatientId", "PracticeUid", "AllergyDescription"
          , "AllergyCode", "DocumentationDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("AllergyDescription", "PatientId"
          , "PracticeUid", "AllergyCode", "DocumentationDate"))
        .transform(validations.removeDuplicateWhenTextOrCodeIsNull("AllergyCode", "PatientId"
          , "PracticeUid", "AllergyDescription", "DocumentationDate"))

      val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2"),
        $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
        .select($"df1.*", $"df2.PatientUid")
        .withColumn("CreatedDate",current_timestamp())
        .withColumn("ModifiedDate",current_timestamp())



      val tf = new AllergyTransformFunctions(spark, masterAllergy, mappingpracticecommondatamaster)

      val cacheAllergy = addPatientUid
        .transform(tf.AllergyCode)
        .transform(tf.AllergyDescription)
        .transform(tf.AllergyStatusCode)
        .transform(tf.AllergyStatusText)
        .withColumn("OnsetDate", lit("null"))
        .withColumn("AllergyCodeSystem", lit("null"))
        .withColumn("Note", lit("null"))


      HiveUtility.dfwritetohive(cacheAllergy, mainTableName, spark, stagetableName, s3Path)
      val errList = validations.errorList += spark.createDataFrame(broadcastPatientAllergyRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientAllergyRows.destroy()

     /* val distinctPUid = cacheAllergy.select("PracticeUid").distinct()

      val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
      val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

      val AllergyData = spark.sql(s"select * from $mainTableName where" +
        s" practiceuid in $PartitionPUID")

      val FiletoJoin = cacheAllergy.select("PracticeUid", "PatientId", "PatientUid").distinct()
      broadcast(FiletoJoin)

      val otherData = AllergyData.as("df1").join(FiletoJoin.as("df2")
        , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
          $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
        .select($"df1.*")


      /*cacheAllergy.printSchema()
      otherData.printSchema()*/

      val newstructure = cacheAllergy.select(otherData.columns.head, otherData.columns.tail: _*)

      val AllAllergy = newstructure.union(otherData)
      HiveUtility.dfwritetohive(AllAllergy, mainTableName, spark, stagetableName, s3Path)
      val errList = validations.errorList += spark.createDataFrame(broadcastPatientAllergyRows.value, schema)
      val errRec = validations.errorRecords(errList.toList)
      errRec.write.mode("overwrite").csv(s"$errPath")
      broadcastPatientAllergyRows.destroy()*/

    }


    catch {
      case ex: FileNotFoundException => {
        ex.printStackTrace()

      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")

      }

    }
  }

}
