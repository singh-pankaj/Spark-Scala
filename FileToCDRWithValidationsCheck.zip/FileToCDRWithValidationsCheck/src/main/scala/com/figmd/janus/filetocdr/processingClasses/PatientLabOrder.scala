package com.figmd.janus.filetocdr.processingClasses

import com.figmd.janus.filetocdr.constant.ApplicationConfig
import com.figmd.janus.filetocdr.util.{CommonFunc, HiveUtility, LookupMaps}
import com.figmd.janus.filetocdr.validationFunctions.ValidationCriteria
import com.sun.org.apache.xerces.internal.impl.validation.ValidationState
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class PatientLabOrder(PatientLabOrderPath: String, selectedIds: DataFrame) extends LookupMaps {

  def CachePatientLabOrderProcessing(spark: SparkSession) {
    import spark.implicits._

    /*
  //Create map of file indices and column names
  val cachePatientLabOrderMapDF: Dataset[Row] = rt.joinedDf
    .filter($"CacheTableViewName"==="ViewCachePatientLabOrder")
  val lookup: collection.Map[String, String] = getLookupMap(cachePatientLabOrderMapDF)
  */


    val mainTableName = ApplicationConfig.prop.getProperty("CDRPatientLabOrder")
    val stagetableName = ApplicationConfig.prop.getProperty("StagePatientLabOrder")
    val s3Path = ApplicationConfig.prop.getProperty("s3LocationPatientLabOrder")
    val errPath = ApplicationConfig.prop.getProperty("PatientLabOrderErrPath")
    val validations = new ValidationCriteria(spark)

    //Read file for CachePatientLabOrder
    val file: DataFrame = CommonFunc.readFile(PatientLabOrderPath, spark)

    //File NOt Found

    //Apply lookup to generate file Header
    val CachePatientLabOrderDF: DataFrame = file.select(file.columns.map(c => col(c).as(PatientLabOrderlookup.getOrElse(c, c))): _*)
      .drop("dummy1", "dummy2","BatchUid")



    val CleanedRecords = CachePatientLabOrderDF
      .transform(validations.checkNull("PatientId","PracticeUid","OrderDate"))
      .transform(validations.checkNullCodeAndText("PracticeCode","Description"))
      .transform(validations.removeDuplicateRecords("PatientId","PracticeUid","OrderDate","PracticeCode","Description","ResultValue"))
      .transform(validations.removeDuplicateWhenTextOrCodeIsNull("ResultValue","PatientId","PracticeUid","OrderDate","PracticeCode","Description"))
      .transform(validations.removeDuplicateWhenTextOrCodeIsNull("PracticeCode","PatientId","PracticeUid","OrderDate","Description"))
      .transform(validations.removeDuplicateWhenTextOrCodeIsNull("Description","PracticeCode","PatientId","PracticeUid","OrderDate"))

    val addPatientUid = CleanedRecords.as("df1").join(selectedIds.as("df2")
      , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId")
      .select($"df1.*", $"df2.PatientUid")

    HiveUtility.dfwritetohive(addPatientUid, mainTableName, spark, stagetableName, s3Path)


    /*val distinctPUid = addPatientUid.select("PracticeUid").distinct()

    val ListVal2: Array[Any] = distinctPUid.rdd.map(r => r(0)).cache().collect()
    val PartitionPUID = "(\"" + ListVal2.mkString("\",\"") + "\")"

    val PatientLabOrderData = spark.sql(s"select * from $mainTableName where" +
      s" practiceuid in $PartitionPUID")

    val FiletoJoin = addPatientUid.select("PracticeUid", "PatientId", "PatientUid")
    broadcast(FiletoJoin)

    val OtherData = PatientLabOrderData.as("df1").join(FiletoJoin.as("df2")
      , $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientId" === $"df2.PatientId" &&
        $"df1.PatientUid" === $"df2.PatientUid", "left_anti")
      .select($"df1.*")

    val newstructure = addPatientUid.select(OtherData.columns.head, OtherData.columns.tail: _*)

    val AllPatientLabOrderData = newstructure.union(OtherData)

    HiveUtility.dfwritetohive(AllPatientLabOrderData, mainTableName, spark, stagetableName, s3Path)
*/

  }
}
