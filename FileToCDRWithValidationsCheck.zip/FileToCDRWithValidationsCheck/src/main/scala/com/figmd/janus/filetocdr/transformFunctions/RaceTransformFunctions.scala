package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}

class RaceTransformFunctions(sparkSess: SparkSession, MasterRace: DataFrame) {


  import sparkSess.implicits._

  def PatientRaceText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(MasterRace.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientRaceText" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MasterPatientRaceText"))
  }

  def PatientRaceCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(MasterRace.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.PatientRaceCode" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MappedValue2"))
      .withColumn("MasterPatientRaceText", when($"MappedValue2".isNull, $"MasterPatientRaceText")
        .otherwise($"MappedValue2"))
      .drop( "MappedValue2")
  }
}
