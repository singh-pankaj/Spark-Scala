package com.figmd.janus.filetocdr.transformFunctions

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.when

class DemographicsTransformFunctions(spark:SparkSession,mappingpracticecommondatamaster:DataFrame) {

  import spark.implicits._

  def PhonetypeText1(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TelecomTypeText1" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*",  $"df2.CodeDescription".as("MasterPhoneTypeText"))
  }

  def PhonetypeText2(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.TelecomTypeText2" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MappedMasterPhonetypeText"))
      .withColumn("MasterPhoneTypeText", when($"MappedMasterPhonetypeText".isNull, $"MasterPhonetypeText")
        .otherwise($"MappedMasterPhonetypeText"))
      .drop( "MappedMasterPhonetypeText")

  }

  def CountryCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.CountryCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*",  $"df2.CodeDescription".as("MasterCountryText"))
  }

  def CountryText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.Country" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MappedMasterCountryText"))
      .withColumn("MasterCountryText", when($"MappedMasterCountryText".isNull, $"MasterCountryText")
        .otherwise($"MappedMasterCountryText"))
      .drop( "MappedMasterCountryText")

  }

  def GenderText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.Gender" === $"df2.PracticeValue","left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MasterGenderText"))

  }

  def MaritalStatusCode(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MaritalStatusCode" === $"df2.PracticeValue"
      , "left_outer")
      .select($"df1.*",  $"df2.CodeDescription".as("MasterMaritalStatusText"))
  }

  def MaritalStatusText(df: DataFrame): DataFrame = {
    df
      .as("df1").join(mappingpracticecommondatamaster.as("df2"),
      $"df1.PracticeUid" === $"df2.PracticeUid" && $"df1.MaritalStatusText" === $"df2.PracticeDescription"
      , "left_outer")
      .select($"df1.*", $"df2.CodeDescription".as("MappedMasterMaritalStatusText"))
      .withColumn("MasterMaritalStatusText", when($"MappedMasterMaritalStatusText".isNull, $"MasterMaritalStatusText")
        .otherwise($"MappedMasterMaritalStatusText"))
      .drop( "MappedMasterMaritalStatusText")

  }

}
