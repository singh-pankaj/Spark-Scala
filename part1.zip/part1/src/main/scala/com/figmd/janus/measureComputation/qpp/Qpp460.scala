package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, CalenderUnit, MeasureProperty, QPP460Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp460
* Measure Title              :- Average Change in Back Pain following Lumbar Fusion
* Measure Description        :- The average change (preoperative to one year postoperative) in back pain for patients
*                               18 years of age or older who had a lumbar fusion procedure
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Sumant Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp460 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp460"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP460Elements.Congenital_Scoliosis
      , QPP460Elements.Infection_Related_To_Lumbar_Spine
      , QPP460Elements.Fracture
      , QPP460Elements.Idiopathic_Scoliosis
      , QPP460Elements.Cancer
      , QPP460Elements.Back_Pain_Assessment_Vas
      , QPP460Elements.Lumbar_Spine_Fusion_Date
      , QPP460Elements.Back_Pain_Measurement
      , QPP460Elements.Pre_Operative_Vas_Score
      , QPP460Elements.Post_Operative_Vas_Score
      , QPP460Elements.Back_Pain_Not_Met
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

    // Filter Exceptions
    val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)
    exclusionRDD.cache()

    val intermediateRDD = getSubtractRDD(ippRDD,exclusionRDD)
        intermediateRDD.cache()

    val metRDD = getMet(intermediateRDD, patientHistoryBroadcastList)
        metRDD.cache()
    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
    notMetRDD.cache()
    saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
  }
}



  def getIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
          isPatientAdult(visit, m)
        &&
          wasProcedurePerformedBeforeStartBetweenMonths(visit, m, QPP460Elements.Lumbar_Spine_Fusion, CalenderUnit.MONTH, 15, CalenderUnit.MONTH, 4, patientHistoryList)
    )
  }


  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
          isAssessmentPerformedDuringProcedure(visit, m,
                    QPP460Elements.Medical_Condition_Exclusions, QPP460Elements.Medical_Condition_Exclusions_Date,
                    QPP460Elements.Lumbar_Spine_Fusion, QPP460Elements.Lumbar_Spine_Fusion_Date)
        ||
          isDiagnosedWithInHistory(visit, m, QPP460Elements.Congenital_Scoliosis, patientHistoryList)
        ||
          isDiagnosedWithInHistory(visit, m, QPP460Elements.Infection_Related_To_Lumbar_Spine, patientHistoryList)
        ||
          isDiagnosedWithInHistory(visit, m, QPP460Elements.Fracture, patientHistoryList)
        ||
          isDiagnosedWithInHistory(visit, m, QPP460Elements.Idiopathic_Scoliosis, patientHistoryList)
        ||
          isDiagnosedWithInHistory(visit, m, QPP460Elements.Cancer, patientHistoryList)
    )
  }

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
          wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit, m, QPP460Elements.Back_Pain_Assessment_Vas,
                                              patientHistoryList, QPP460Elements.Lumbar_Spine_Fusion_Date)

        ||
          (
              wasAssessmentPerformedInXMonthsBeforeProcedureWithResult(visit, m, QPP460Elements.Lumbar_Spine_Fusion,
                                              QPP460Elements.Back_Pain_Measurement, QPP460Elements.Visual_Analog_Scale,
                                          3, 4, 15, patientHistoryList)
            &&
              wasAssessmentPerformedInXMonthsBeforeProcedure(visit, m, QPP460Elements.Lumbar_Spine_Fusion,
                                              QPP460Elements.Pre_Operative_Vas_Score, 3, 4, 15, patientHistoryList)
            &&
              wasAssessmentPerformedInXMonthsBeforeProcedureWithResult(visit, m, QPP460Elements.Lumbar_Spine_Fusion,
                                              QPP460Elements.Back_Pain_Measurement, QPP460Elements.Visual_Analog_Scale,
                                          15, 4, 15, patientHistoryList)
            &&
              wasAssessmentPerformedInXMonthsAfterProcedureWithResult(visit, m, QPP460Elements.Lumbar_Spine_Fusion,
                                              QPP460Elements.Back_Pain_Measurement, QPP460Elements.Visual_Analog_Scale,
                CalenderUnit.MONTH,9,CalenderUnit.MONTH, 4,CalenderUnit.MONTH, 15, patientHistoryList)
            &&
              wasAssessmentPerformedInXMonthsBeforeProcedure(visit, m, QPP460Elements.Lumbar_Spine_Fusion,
                                              QPP460Elements.Pre_Operative_Vas_Score, 15, 4, 15, patientHistoryList)
            &&
              wasAssessmentPerformedInXMonthsAfterProcedure(visit, m, QPP460Elements.Lumbar_Spine_Fusion,
                                              QPP460Elements.Pre_Operative_Vas_Score, CalenderUnit.MONTH,9,CalenderUnit.MONTH ,4,CalenderUnit.MONTH, 15, patientHistoryList)
          )
      )
      &&
        ! wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit, m, QPP460Elements.Back_Pain_Not_Met,
                                              patientHistoryList, QPP460Elements.Lumbar_Spine_Fusion_Date)
    )

  }


}

