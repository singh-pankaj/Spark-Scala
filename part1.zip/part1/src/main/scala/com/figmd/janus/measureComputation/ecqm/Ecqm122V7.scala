package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CompareOperator, ECQM122V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm122V7
* Measure Title              :- Diabetes: Hemoglobin A1c (HbA1c) Poor Control (> 9%)
* Measure Description        :- Percentage of patients 18-75 years of age with diabetes who had hemoglobin A1c > 9.0% during the measurement period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Divyansh Mathur
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm122V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm122V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patient_history_list = getPatientHistory(sparkSession, initialRDD,

      ECQM122V7Elements.Diabetes,
      ECQM122V7Elements.Office_Visit,
      ECQM122V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
      ECQM122V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
      ECQM122V7Elements.Home_Healthcare_Services,
      ECQM122V7Elements.Annual_Wellness_Visit,
      ECQM122V7Elements.Encounter_Inpatient,
      ECQM122V7Elements.Discharged_To_Home_For_Hospice_Care,
      ECQM122V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
      ECQM122V7Elements.Hospice_Care_Ambulatory,
      ECQM122V7Elements.Hba1c_Result,
      ECQM122V7Elements.Hba1c_Laboratory_Test)

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list.collect().toList)

    val mostRecentRDD = mostRecentPatientList(patient_history_list: RDD[CassandraRow], ECQM122V7Elements.Hba1c_Laboratory_Test)
    val mostRecentPatientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostRecentRDD)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible initial population RDD

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter denominator Exclusions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      val intermediateRDD = getSubtractRDD(ippRDD, exclusionRDD)

      //Met rdd
      val metRDD = getMet(intermediateRDD, patientHistoryList, mostRecentPatientHistoryList)
      metRDD.cache()

      //exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryList.destroy()
      mostRecentPatientHistoryList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Patients 18-75 years of age with diabetes with a visit during the measurement period
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isDiagnosisOverlapsMeasurementPeriod(visit, m, patientHistoryList, ECQM122V7Elements.Diabetes)
        && isAgeBetween(visit, m, 18, CompareOperator.GREATER_EQUAL, 75, CompareOperator.LESS)
        && wasEncounterPerformed(visit, m, patientHistoryList, ECQM122V7Elements.Office_Visit, ECQM122V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up, ECQM122V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up, ECQM122V7Elements.Home_Healthcare_Services, ECQM122V7Elements.Annual_Wellness_Visit)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Exclude patients whose hospice care overlaps the measurement period
  ----------------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isEncounterPerformedWithDischargeStatus(visit, m, ECQM122V7Elements.Encounter_Inpatient, ECQM122V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        || isEncounterPerformedWithDischargeStatus(visit, m, ECQM122V7Elements.Encounter_Inpatient, ECQM122V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        || isInterventionPerformedOverlapsMeasurementPeriod(visit, m, patientHistoryList, ECQM122V7Elements.Hospice_Care_Ambulatory)
        || wasInterventionOrdered(visit, m, patientHistoryList, ECQM122V7Elements.Hospice_Care_Ambulatory)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Patients whose most recent HbA1c level (performed during the measurement period) is >9.0%
  ----------------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], mostRecentPatientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateRDD.filter(visit =>
      isLaboratoryTestPerformedWithValueDuringMeasurementPeriod(visit, m, ECQM122V7Elements.Hba1c_Laboratory_Test, ECQM122V7Elements.Hba1c_Result, 9, CompareOperator.GREATER, mostRecentPatientHistoryList, patientHistoryList)
        || isMostRecentLaboratoryTestPerformed(visit, m, ECQM122V7Elements.Hba1c_Laboratory_Test, mostRecentPatientHistoryList)
        || !isLabTestPerformed(visit, m, patientHistoryList, ECQM122V7Elements.Hba1c_Laboratory_Test)

    )
  }
}