package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ECQM130V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ECQM 130
* Measure Title              :- Pneumococcal Vaccination Status for Older Adults
* Measure Description        :- Percentage of patients 65 years of age and older who have ever received a pneumococcal vaccine
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm130V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm130V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //getPatientHistoryList
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        ECQM130V7Elements.Discharged_To_Home_For_Hospice_Care,
        ECQM130V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
        ECQM130V7Elements.Hospice_Care_Ambulatory,
        ECQM130V7Elements.Malignant_Neoplasm_Of_Colon,
        ECQM130V7Elements.Total_Colectomy,
        ECQM130V7Elements.Colonoscopy,
        ECQM130V7Elements.Fecal_Occult_Blood_Test__Fobt_,
        ECQM130V7Elements.Flexible_Sigmoidoscopy,
        ECQM130V7Elements.Fit_Dna,
        ECQM130V7Elements.Ct_Colonography).collect().toList

      val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)


      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }


  // IPP-Denominator criteria
  /* Patients 65 years of age and older with a visit during the measurement period  */

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeBetween(visit, m, 50, 75)
        && isVisitTypeIn(visit, m, ECQM130V7Elements.Office_Visit,
        ECQM130V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
        ECQM130V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
        ECQM130V7Elements.Home_Healthcare_Services,
        ECQM130V7Elements.Annual_Wellness_Visit)
    )
  }

  // Denominator Exclusion criteria

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isEncounterPerformedBeforeEnd(visit, m, ECQM130V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        || isEncounterPerformedBeforeEnd(visit, m, ECQM130V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        || isInterventionOrder(visit, m, ECQM130V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        || isInterventionPerformedBeforeEnd(visit, m, ECQM130V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
        || (
        isDiagnosisWithBeforeEnd(visit, m, ECQM130V7Elements.Malignant_Neoplasm_Of_Colon, patientHistoryList)
          || isDiagnosisWithBeforeEnd(visit, m, ECQM130V7Elements.Total_Colectomy, patientHistoryList)
        )


    )
  }


  // Numerator criteria

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      wasProcedurePerformedBeforeEndInXYears(visit, m, ECQM130V7Elements.Colonoscopy, 9, patientHistoryList)
        || isLaboratoryTestPerformed(visit, m, ECQM130V7Elements.Fecal_Occult_Blood_Test__Fobt_, patientHistoryList)
        || wasProcedurePerformedBeforeEndInXYears(visit, m, ECQM130V7Elements.Flexible_Sigmoidoscopy, 4, patientHistoryList)
        || wasLaboratoryTestPerformedBeforeEndInXYears(visit, m, ECQM130V7Elements.Fit_Dna, 2, patientHistoryList)
        || wasProcedurePerformedBeforeEndInXYears(visit, m, ECQM130V7Elements.Ct_Colonography, 9, patientHistoryList)
    )
  }

}