package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ACR01Elements, AdminElements, CalenderUnit, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACR01
* Measure Title              :- Advanced: Disease Activity Measurement for Patients with Rheumatoid Arthritis (RA)
* Measure Description        :- Percentage of patients 18 years and older with a diagnosis of rheumatoid arthritis
                                whose disease activity is assessed using a standardized measurement tool at 50% or more encounters
                                for RA with the same clinician during the measurement period.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object ACR01  extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "ACR01"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, initialRDD,ACR01Elements.Active_Rheumatoid_Arthritis).collect.toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    val InitialIpp = getInitialIpp(initialRDD,patientHistoryList)

    val PREIPPCount : Array[(String,String,Int)] = countElementByProvider(InitialIpp, m,
      ACR01Elements.Home_Healthcare_Services,
      ACR01Elements.Face_To_Face_Interaction,
      ACR01Elements.Care_Services_In_Long_Term_Residential_Facility,
      ACR01Elements.Office_Visit,
      ACR01Elements.Outpatient_Consultation,
      ACR01Elements.Nursing_Facility_Visit)

    // Filter IPP
    val ippRDD = getIpp(InitialIpp,patientHistoryList,PREIPPCount)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD ,ippRDD, MEASURE_NAME)) {

      //val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //Filter denominatorRDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
     val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val premetRDD = getpreMet(ippRDD)

      val MetCount: Array[(String, String, Int)] = countElementByProvider(premetRDD, m,
        ACR01Elements.Disease_Activity_Assessed_Using_A_Standardized_Measurement_Tool,
        ACR01Elements.Disease_Activity_Tools)

      val metRDD = getQualifingRDD(PREIPPCount, MetCount, premetRDD)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()
    }


  }

  /*-----------------------------------------------------------------------------------------
   Patients 18 years and older with a diagnosis of rheumatoid arthritis seen for two or more
   face-to-face encounters for RA with the same clinician during the measurement period.
   -----------------------------------------------------------------------------------------*/

  def getInitialIpp(initialRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
             isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
        &&   isVisitTypeIn(visit,m
             ,ACR01Elements.Office_Visit
             ,ACR01Elements.Care_Services_In_Long_Term_Residential_Facility
             ,ACR01Elements.Home_Healthcare_Services
             ,ACR01Elements.Face_To_Face_Interaction
             ,ACR01Elements.Nursing_Facility_Visit
             ,ACR01Elements.Outpatient_Consultation)
        &&   wasDiagnosedWithBeforeOrEqualEncounter(visit,m,ACR01Elements.Active_Rheumatoid_Arthritis,patientHistoryList)
    )
  }

  def getIpp(rdd: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]],PREIPPCount : Array[(String,String,Int)]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
             getEncounterCount(visit,m,2,true, PREIPPCount)
    )
  }

  /*-----------------------------------------------------------------------------------------
   Percentage of patients with >=50% of total number of outpatient RA encounters in the
   measurement year with assessment of disease activity using a standardized measure.
   -----------------------------------------------------------------------------------------*/

  def getpreMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
        (
               isAssesmentPerformedDuringEncounter(visit,m,ACR01Elements.Disease_Activity_Assessed_Using_A_Standardized_Measurement_Tool)
          ||   isAssesmentPerformedDuringEncounter(visit,m,ACR01Elements.Disease_Activity_Tools)
        )
        && !isAssesmentPerformedDuringEncounter(visit,m,ACR01Elements.Reason_Not_Specified_Disactassd)
    )
  }

}


