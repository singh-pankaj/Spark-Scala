package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP166Elements}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP111Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 166
* Measure Title              :- Coronary Artery Bypass Graft (CABG): Stroke
* Measure Description        :- Percentage of patients aged 18 years and older undergoing isolated CABG surgery who have a postoperative stroke (i.e., any confirmed neurological deficit of abrupt onset caused by a disturbance in blood supply to the brain) that did not resolve within 24 hours.
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp166 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "Qpp166"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP166Elements.Ischemic_Stroke,
      QPP166Elements.Ischemic_Stroke_Stop_Date_Time,
      QPP166Elements.Coronary_Artery_Bypass_Graft
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      // metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()
      //

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /* All patients aged 18 years and older undergoing isolated CABG surgery, during measurement period. */

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        (isProcedurePerformed(visit, m, QPP166Elements.Coronary_Artery_Bypass_Graft, patientHistoryBroadcastList)
          ||
          (isProcedurePerformed(visit, m, QPP166Elements.Coronary_Artery_Bypass_Graft, patientHistoryBroadcastList)
            &&
            isProcedurePerformed(visit, m, QPP166Elements.Cabg_Reoperation, patientHistoryBroadcastList)
            )
          )
    )
  }


  // Numerator criteria
  /* Patients undergoing isolated CABG surgery who have a postoperative stroke (i.e., any confirmed neurological deficit of abrupt onset caused by a disturbance in blood supply to the brain) that did not resolve within 24 hours. */

  def getMet(ippRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRdd.filter(visit =>

      isAdverseEventStartedAfterEndOfXProcedure(visit, m, QPP166Elements.Coronary_Artery_Bypass_Graft_Date, QPP166Elements.Stroke_Isolated_Cabg_Surgery, patientHistoryBroadcastList)
        ||
        (isAdverseEventStartedAfterEndOfXProcedure(visit, m, QPP166Elements.Coronary_Artery_Bypass_Graft_Date, QPP166Elements.Ischemic_Stroke, patientHistoryBroadcastList)
          &&
          isProcedureAdverseEvent(visit, m, QPP166Elements.Ischemic_Stroke, patientHistoryBroadcastList)
          &&
          wasAdverseEventNotStoppedInXHours(visit, m, QPP166Elements.Ischemic_Stroke_Stop_Date_Time, QPP166Elements.Ischemic_Stroke_Start_Date_Time, 24, patientHistoryBroadcastList)

          )

          && !isDiagnosedAfterEndOfXProcedure(visit, m, QPP166Elements.Coronary_Artery_Bypass_Graft_Date, QPP166Elements.Stroke_Not_Met, patientHistoryBroadcastList)
    )


  }

}
