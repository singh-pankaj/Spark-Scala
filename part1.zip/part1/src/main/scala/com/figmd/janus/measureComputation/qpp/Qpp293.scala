package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp293
* Measure Title              :- Parkinson’s Disease: Rehabilitative Therapy Options
* Measure Description        :- Percentage of all patients with a diagnosis of Parkinson’s Disease (or caregiver(s), as appropriate) who had
                                rehabilitative therapy options (e.g., physical, occupational, or speech therapy) discussed in the past 12 months
 *
*
* Calculation Implementation :- patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Sawant
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp293 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp293"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP293Elements.Parkinson_s_Disease
      , QPP293Elements.Rehabilitative_Therapy
      , QPP293Elements.Rehabilitative_Therapy_Options
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMetRDD(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateB = getSubtractRDD(ippRDD, metRDD)
      intermediateB.cache()

      val exceptionRDD = getExceptionRDD(intermediateB, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
   All patients with a diagnosis of Parkinson’s disease
   * ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isVisitTypeIn(visit, m, QPP293Elements.Office_Visit, QPP293Elements.Nursing_Facility_Visit)
        && wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP293Elements.Parkinson_s_Disease, patientHistoryBroadcastList)
        && !isTeleHealthEncounterNotPerformed(visit, m, QPP293Elements.Office_Visit_Telehealth_Modifier
        , QPP293Elements.Nursing_Facility_Visit_Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP293Elements.Pos_02)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  All patients with a diagnosis of Parkinson’s Disease (or caregiver(s), as appropriate) who had rehabilitative therapy options
  (i.e., physical, occupational, and speech therapy) discussed in the past 12 months
   * ----------------------------------------------------------------------------------------------------------------------------*/
  def getMetRDD(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (wasCommunicationDoneFromProviderToPatientBeforeEncounterWithinXMonths(visit, m, QPP293Elements.Office_Visit_Date, QPP293Elements.Rehabilitative_Therapy, 12, patientHistoryBroadcastList)
        || wasCommunicationDoneFromProviderToPatientBeforeEncounterWithinXMonths(visit, m, QPP293Elements.Nursing_Facility_Visit_Date, QPP293Elements.Rehabilitative_Therapy, 12, patientHistoryBroadcastList)
        )
        || (wasCommunicationDoneFromProviderToPatientBeforeEncounterWithinXMonths(visit, m, QPP293Elements.Office_Visit_Date, QPP293Elements.Rehabilitative_Therapy_Options, 12, patientHistoryBroadcastList)
        || wasCommunicationDoneFromProviderToPatientBeforeEncounterWithinXMonths(visit, m, QPP293Elements.Nursing_Facility_Visit_Date, QPP293Elements.Rehabilitative_Therapy_Options, 12, patientHistoryBroadcastList)
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Documentation of medical reason(s) for not discussing rehabilitative therapy options with patient (or caregiver).
   * ----------------------------------------------------------------------------------------------------------------------------*/
  def getExceptionRDD(intermediateB: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateB.filter(visit =>

      isCommunicationFromProviderToProviderConcurrent(visit, m, QPP293Elements.Rehabilitative_Therapy_Medical_Reason_Date, QPP293Elements.Office_Visit_Date)
        || isCommunicationFromProviderToProviderConcurrent(visit, m, QPP293Elements.Rehabilitative_Therapy_Medical_Reason_Date, QPP293Elements.Nursing_Facility_Visit_Date)

    )
  }
}
