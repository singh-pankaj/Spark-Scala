package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{Axon23Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Axon 23
* Measure Title              :- MS: Exercise and Appropriate Physical Activity Counseling for Patients with MS
* Measure Description        :- Percentage of patients with MS who are counseled on the benefits of exercise
                                and appropriate physical activity for patients with MS in the past 12 months.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/



object  Axon23  extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Axon23"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if(checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val patienthistory = getPatientHistory(sparkSession, initialRDD
        , Axon23Elements.Counseling_On_Benefits_Of_Exercise
        , Axon23Elements.Counseling_For_Appropriate_Exercise
      ).collect().toList

      val patientHistory: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistory)

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistory)
      metRDD.cache()


      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistory.destroy()


    }
  }


  /*--------------------------------------------------------------------------------------------------------------------
   	All patients with a diagnosis of MS
  --------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
          isDiagnosedOnEncounter(visit,m,Axon23Elements.Multiple_Sclerosis)
       && isVisitTypeIn(visit,m
                                ,Axon23Elements.Physical_Therapy_Evaluation
                                ,Axon23Elements.Occupational_Therapy
                                ,Axon23Elements.Outpatient_Consultation
                                ,Axon23Elements.Evaluation_And_Management_Physician_Visit
                                ,Axon23Elements.Office_Visit)


    )

  }



  /*--------------------------------------------------------------------------------------------------------------------
   Patients with MS counseled on the benefits of exercise and appropriate physical activity for patients with MS
   in past 12 months
   -------------------------------------------------------------------------------------------------------------------*/



  def getMet(ippRDD: RDD[CassandraRow],patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
           wasInterventionPerformedInXMonthsBeforeEncounter(visit,m,Axon23Elements.Counseling_On_Benefits_Of_Exercise,12,patientHistory)
        || wasInterventionPerformedInXMonthsBeforeEncounter(visit,m,Axon23Elements.Counseling_For_Appropriate_Exercise,12,patientHistory)
    )
  }

}
