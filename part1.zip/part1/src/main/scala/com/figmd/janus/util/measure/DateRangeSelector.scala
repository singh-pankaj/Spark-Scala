package com.figmd.janus
import java.time.{LocalDate}
import java.util.ArrayList

class DateRangeSelector {

  def selectRange(wf_type:String,Date:LocalDate): String ={
    var dateRange = "";
    wf_type match {
      case "MNR"=>  dateRange = calculateDateForMNR(Date);
      case "MR"=>  dateRange = calculateDateForMR(Date);
      case "QNR"=>  dateRange = calculateDateForQNR(Date);
      case "QR"=>  dateRange = calculateDateForQR(Date);
      case "QCNR"=>  dateRange = calculateDateForQCNR(Date);
      case "MIPS"=>  dateRange = calculateDateForQCNR(Date);
      case "REGULAR"=>  dateRange = calculateDateForRegular(Date);
    }
    return dateRange;
  }

  def calculateDateForMNR(curDate:LocalDate): String ={
    var range  = new ArrayList[String]()
    var currentDate = curDate;
    for(i <- 1 to 6) {
      val month_start_date = currentDate.withDayOfMonth(1)
      val month_end_date = currentDate.withDayOfMonth(currentDate.lengthOfMonth())

      range.add(month_start_date.toString+"~"+month_end_date.toString)
      currentDate = currentDate.minusMonths(1);
    }
      return range.toString
  }


  def calculateDateForMR(curDate:LocalDate): String ={
    var range  = new ArrayList[String]()
    var currentDate = curDate;
    for(i <- 1 to 6) {
      val month_end_date = currentDate.withDayOfMonth(currentDate.lengthOfMonth())
      val month_date = currentDate.minusMonths(11)
      val month_start_date = month_date.withDayOfMonth(1)

      range.add(month_start_date.toString+"~"+month_end_date.toString)
      currentDate = currentDate.minusMonths(1);
    }
    return range.toString
  }
  def calculateDateForQNR(curDate:LocalDate): String ={

    var range  = new ArrayList[String]()
    var currentDate = curDate;

    for(i <- 1 to 4) {
      val quarter_start_date: LocalDate = LocalDate.of(currentDate.getYear, currentDate.getMonth.firstMonthOfQuarter, 1)
      val endMonth = quarter_start_date.plusMonths(2)
      val quarter_end_date: LocalDate = endMonth.withDayOfMonth(endMonth.lengthOfMonth())

      range.add(quarter_start_date.toString+"~"+quarter_end_date.toString)
      currentDate = currentDate.minusMonths(3);
    }

    return range.toString
  }
  def calculateDateForQR(curDate:LocalDate):String={

    var range  = new ArrayList[String]()
    var currentDate = curDate;

    for(i <- 1 to 4) {
      val quarter_date: LocalDate = LocalDate.of(currentDate.getYear, currentDate.getMonth.firstMonthOfQuarter, 1)
      val quarter_start_date = LocalDate.of(currentDate.minusMonths(9).getYear, currentDate.minusMonths(9).getMonth.firstMonthOfQuarter, 1)
      val endMonth = quarter_date.plusMonths(2)
      val quarter_end_date: LocalDate = endMonth.withDayOfMonth(endMonth.lengthOfMonth())

      range.add(quarter_start_date.toString+"~"+quarter_end_date.toString)
      currentDate = currentDate.minusMonths(3);
    }

    return range.toString
  }

  def calculateDateForQCNR(curDate:LocalDate): String ={

    var range  = new ArrayList[String]()
    var currentDate = curDate;
    //println("|>>>>"+currentDate.getMonthValue)

    var flag:Float=(currentDate.getMonthValue.toFloat/3)
    //println(">>>>"+flag)
    //println(">>>>"+math.ceil(flag))
    var counter=math.ceil(flag).toInt
    for(i <- 1 to counter) {
      val quarter_start_date: LocalDate = LocalDate.of(currentDate.getYear, currentDate.getMonth.firstMonthOfQuarter, 1)
      val endMonth = quarter_start_date.plusMonths(2)
      val quarter_end_date: LocalDate = endMonth.withDayOfMonth(endMonth.lengthOfMonth())
      range.add(quarter_start_date.toString+"~"+quarter_end_date.toString)
      currentDate = currentDate.minusMonths(3);
    }

    return range.toString
  }

  def calculateDateForRegular(curDate:LocalDate): String ={

    var range  = new ArrayList[String]()
    var currentDate = curDate;
    var flag:Float=(currentDate.getMonthValue.toFloat/3)
    val quarter_start_date: LocalDate = LocalDate.of(currentDate.getYear, 1 , 1)
    val quarter_end_date: LocalDate = LocalDate.of(currentDate.getYear, 12 , 31)
    range.add(quarter_start_date.toString+"~"+quarter_end_date.toString)
    return range.toString
  }

}
