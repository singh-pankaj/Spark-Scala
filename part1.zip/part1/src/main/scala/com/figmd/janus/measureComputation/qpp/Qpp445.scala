package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 445
* Measure Title              :- Risk-Adjusted Operative Mortality for Coronary Artery Bypass Graft (CABG)
* Measure Description        :- Percent of patients aged 18 years and older undergoing isolated CABG who die, including
                                both all deaths occurring during the hospitalization in which the CABG was performed,
                                even if after 30 days, and those deaths occurring after discharge from the hospital,
                                but within 30 days of the procedure.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp445 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp445"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP445Elements.Death_30_G
      , QPP445Elements.Patient_Deceased
      , QPP445Elements.Discharge
      , QPP445Elements.Hospitalization
      , QPP445Elements.Patient_Died
      , QPP445Elements.Death_Not_Met
      , QPP445Elements.Patient_Alive_Acute_Inpatient_Setting_Discharge
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*------------------------------------------------------------------------------
    All patients undergoing isolated CABG during measurement period.
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)


    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && (
        isProcedurePerformedDuringEncounter(visit, m, QPP445Elements.Coronary_Artery_Bypass_Graft)
          ||
          (
            isProcedurePerformedDuringEncounter(visit, m, QPP445Elements.Coronary_Artery_Bypass_Graft)
              && isProcedurePerformedDuringEncounter(visit, m, QPP445Elements.Cabg_Reoperation)
            )
        )
    )
  }

  /*------------------------------------------------------------------------------
    Number of patients undergoing isolated CABG who die, including both all deaths occurring during the hospitalization
    in which the operation was performed, even if after 30 days, and those deaths occurring after discharge from the
    hospital, but within 30 days of the procedure
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        isPatientCharacteristic(visit, m, QPP445Elements.Death_30_G, patientHistoryBroadcastList)
          ||
          (
            wasPatientCharacteristicAfterOrEqualEncounter(visit, m, QPP445Elements.Patient_Deceased, patientHistoryBroadcastList)
              &&
              (
                wasPatientCharacteristicAfterEncounterinHistory(visit, m, QPP445Elements.Patient_Deceased, patientHistoryBroadcastList, QPP445Elements.Discharge)
                  || wasPatientCharacteristicEqualEncounterInHistory(visit, m, QPP445Elements.Patient_Deceased, QPP445Elements.Hospitalization, CompareOperator.EQUAL, patientHistoryBroadcastList)
                )
            )
          ||
          (
            wasPatientCharacteristicEqualEncounterInHistory(visit, m, QPP445Elements.Patient_Died, QPP445Elements.Discharge, CompareOperator.EQUAL, patientHistoryBroadcastList)
              || wasPatientCharacteristicAfterEncounterWithinXPeriod(visit, m, QPP445Elements.Patient_Died, CalenderUnit.DAY, 1, "ge", CalenderUnit.DAY, 30, "le", patientHistoryBroadcastList)
            )
        )
        && !(
        isPatientCharacteristic(visit, m, QPP445Elements.Death_Not_Met, patientHistoryBroadcastList)
          || wasPatientCharacteristicAfterEncounterWithinXPeriod(visit, m, QPP445Elements.Patient_Alive_Acute_Inpatient_Setting_Discharge, CalenderUnit.DAY, 1, "ge", CalenderUnit.DAY, 30, "le", patientHistoryBroadcastList)
          || wasPatientCharacteristicEqualEncounterInHistory(visit, m, QPP445Elements.Patient_Alive_Acute_Inpatient_Setting_Discharge, QPP445Elements.Discharge, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
          || wasPatientCharacteristicEqualEncounterInHistory(visit, m, QPP445Elements.Patient_Alive_Acute_Inpatient_Setting_Discharge, QPP445Elements.Hospitalization, CompareOperator.EQUAL, patientHistoryBroadcastList)
        )
    )
  }
}