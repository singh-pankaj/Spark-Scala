package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP70Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 70
* Measure Title              :- Hematology: Chronic Lymphocytic Leukemia (CLL): Baseline Flow Cytometry
* Measure Description        :- Percentage of patients aged 18 years and older, seen within a 12 month reporting period, with a diagnosis of chronic
                                lymphocytic leukemia (CLL) made at any time during or prior to the reporting period who had baseline flow cytometry studies performed and documented in the chart
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp70 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp70"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // val patientHistory:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistory)

    //Backtracking List
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP70Elements.Chronic_Lymphocytic_Leukemia,
      QPP70Elements.Baseline_Flow_Cytometry,
      QPP70Elements.Baseline_Flow_Cytometry_Medical_Reason,
      QPP70Elements.Baseline_Flow_Cytometry_Patient_Reason,
      QPP70Elements.Palliative_Care,
      QPP70Elements.Baseline_Flow_Cytometry_System_Reason,
      QPP70Elements.Flow_Cytometry_Studies,
      QPP70Elements.Anti_Neoplastic_Therapy,
      QPP70Elements.Baseline_Flow_Cytometry_Reason_Not_Specified
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect.toList)
    //  Filter IPP-
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateB = getSubtractRDD(denominatorRDD, metRDD)
      intermediateB.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateB, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }
  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : All patients aged 18 years and older, seen within a 12 month reporting period, with a diagnosis of chronic
lymphocytic leukemia (CLL) made at any time during or prior to the performance period
----------------------------------------------------------------------------------------------------------------------------*/


  def getIpp(rdd: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
      isPatientAdult(visit,m)
      && isVisitTypeIn(visit, m, QPP70Elements.Office_Visit,QPP70Elements.Outpatient_Consultation)
      && wasDiagnosedInHistory(visit, m, QPP70Elements.Chronic_Lymphocytic_Leukemia,patientHistoryBroadcastList)
      && !isTeleHealthEncounterNotPerformed(visit, m, QPP70Elements.Office_Visit_Telehealth_Modifier,QPP70Elements.Outpatient_Consultation_Telehealth_Modifier)
      && isPOSEncounterNotPerformed(visit, m, QPP70Elements.Pos_02)
    )

  }


  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Patients who had baseline flow cytometry studies performed and documented in the chart
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(ipp: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    ipp.filter(visit =>
      isLaboratoryTestPerformed(visit, m, QPP70Elements.Baseline_Flow_Cytometry, patientHistoryBroadcastList)
      || (isLaboratoryTestPerformedDuringDiagnosis(visit, m, QPP70Elements.Flow_Cytometry_Studies, QPP70Elements.Flow_Cytometry_Studies_Date,QPP70Elements.Chronic_Lymphocytic_Leukemia,QPP70Elements.Chronic_Lymphocytic_Leukemia_Date)
          && wasLaboratoryTestPerformedBeforeMedication(visit,m,QPP70Elements.Anti_Neoplastic_Therapy,patientHistoryBroadcastList,QPP70Elements.Flow_Cytometry_Studies)
          )
      && !isLaboratoryTestPerformedNotDone(visit, m, QPP70Elements.Baseline_Flow_Cytometry_Reason_Not_Specified, patientHistoryBroadcastList)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------------
Denominator Exceptions : Documentation of medical reason(s) for not performing baseline flow cytometry studies.
OR
Documentation of patient reason(s) for not performing baseline flow cytometry studies (eg, receiving palliative care or not receiving treatment as defined above).
OR
Documentation of system reason(s) for not performing baseline flow cytometry studies (eg, patient previously treated by another physician at the time baseline flow cytometry
studies were performed).
----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermedaiateRdd: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermedaiateRdd.filter(visit =>
      isLaboratoryTestPerformed(visit, m, QPP70Elements.Baseline_Flow_Cytometry_Medical_Reason, patientHistoryBroadcastList)
      || isLaboratoryTestPerformed(visit, m, QPP70Elements.Baseline_Flow_Cytometry_Patient_Reason, patientHistoryBroadcastList)
      || wasInterventionPerformedInHistory(visit, m, QPP70Elements.Palliative_Care, patientHistoryBroadcastList)
      || isLaboratoryTestPerformedNotDone(visit, m, QPP70Elements.Baseline_Flow_Cytometry_System_Reason, patientHistoryBroadcastList)
    )
  }
}

