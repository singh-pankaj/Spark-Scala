package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, ECQM52V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 52
* Measure Title              :-HIV/AIDS: Pneumocystis Jiroveci Pneumonia (PCP) Prophylaxis
* Measure Description        :- Percentage of patients aged 6 weeks and older with a diagnosis of HIV/AIDS who were prescribed Pneumocystis jiroveci pneumonia (PCP) prophylaxis
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 2
* Measure Stratification     :- 3
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm52V7_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm52V7_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val getPatientHistoryList = getPatientHistory(sparkSession, initialRDD,
      ECQM52V7Elements.Hiv_1,
      ECQM52V7Elements.Office_Visit,
      ECQM52V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
      ECQM52V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
      ECQM52V7Elements.Preventive_Care__Established_Office_Visit__0_To_17,
      ECQM52V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,
      ECQM52V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,
      ECQM52V7Elements.Outpatient_Consultation,
      ECQM52V7Elements.Encounter_Inpatient,
      ECQM52V7Elements.Discharged_To_Home_For_Hospice_Care,
      ECQM52V7Elements.Cd4__Count,
      ECQM52V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
      ECQM52V7Elements.Hospice_Care_Ambulatory,
      ECQM52V7Elements.Pneumocystis_Jiroveci_Pneumonia__Pcp__Prophylaxis,
      ECQM52V7Elements.Dapsone_And_Pyrimethamine,
      ECQM52V7Elements.Leucovorin


    )
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateA, patientHistoryList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }

  }

  //Initial Population 2: All patients aged 1-5 years of age with a diagnosis of HIV/AIDS
  // and a CD4 count below 500 cells/mm3 or a CD4 percentage below 15% who had at least two visits during the measurement year, with at least 90 days in between each visit
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 1, CalenderUnit.YEAR)
        && isAgeBelowBeforeStart(visit, m, false, 6, CalenderUnit.YEAR)
        && isDiagnosisWithBeforeEnd(visit, m, ECQM52V7Elements.Hiv_1, patientHistoryList)
        && (
        wasEncounterAfterXDaysOfElement(visit, m, ECQM52V7Elements.Office_Visit, 90, patientHistoryList)
          || wasEncounterAfterXDaysOfElement(visit, m, ECQM52V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up, 90, patientHistoryList)
          || wasEncounterAfterXDaysOfElement(visit, m, ECQM52V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up, 90, patientHistoryList)
          || wasEncounterAfterXDaysOfElement(visit, m, ECQM52V7Elements.Preventive_Care__Established_Office_Visit__0_To_17, 90, patientHistoryList)
          || wasEncounterAfterXDaysOfElement(visit, m, ECQM52V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17, 90, patientHistoryList)
          || wasEncounterAfterXDaysOfElement(visit, m, ECQM52V7Elements.Outpatient_Consultation, 90, patientHistoryList)

        )
        &&
        (
          wasLabTestEndsAfterStartWithinPeriodWithResult(visit, m, ECQM52V7Elements.Cd4__Count, CompareOperator.LESS, CalenderUnit.MONTH, 9, 500, CompareOperator.LESS, patientHistoryList)
            || wasLabTestEndsAfterStartWithinPeriodWithResult(visit, m, ECQM52V7Elements.Cd4__Percentage, CompareOperator.LESS, CalenderUnit.MONTH, 9, 15, CompareOperator.LESS, patientHistoryList)

          )


    )

  }

  //Exclude patients whose hospice care overlaps the measurement period
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isEncounterPerformedWithDischargeStatus(visit, m, ECQM52V7Elements.Encounter_Inpatient, ECQM52V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        || isEncounterPerformedWithDischargeStatus(visit, m, ECQM52V7Elements.Encounter_Inpatient, ECQM52V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        || wasInterventionPerformedInHistory(visit, m, ECQM52V7Elements.Hospice_Care_Ambulatory, patientHistoryList)


    )
  }

  //Numerator 2: Patients who were prescribed Pneumocystis jiroveci pneumonia (PCP) prophylaxis within 3 months of CD4 count below 500 cells/mm3 or a CD4 percentage below 15%
  def getMet(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      medicationOrderStartsAfterEndOfLabTest(visit, m, ECQM52V7Elements.Cd4__Count_Date, ECQM52V7Elements.Pneumocystis_Jiroveci_Pneumonia__Pcp__Prophylaxis, CompareOperator.LESS, CalenderUnit.MONTH, 3, patientHistoryList)
        || medicationOrderStartsAfterEndOfLabTest(visit, m, ECQM52V7Elements.Cd4__Percentage_Date, ECQM52V7Elements.Pneumocystis_Jiroveci_Pneumonia__Pcp__Prophylaxis, CompareOperator.LESS, CalenderUnit.MONTH, 3, patientHistoryList)

    )


  }

  //Denominator Exceptions 2: Patient did not receive PCP prophylaxis because there was a CD4 count above 500 cells/mm3
  // or CD4 percentage above 15% during the three months after a CD4 count below 500 cells/mm3 or CD4 percentage below 15%
  def getExceptionRDD(intermediateRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateRDD.filter(visit =>
      wasLabTestEndsAfterEndOfLabTestWithResultWithPeriod(visit, m, ECQM52V7Elements.Cd4__Count, ECQM52V7Elements.Cd4__Count, CompareOperator.LESS, CalenderUnit.MONTH, 3, 500, CompareOperator.GREATER_EQUAL, patientHistoryList)
        || wasLabTestEndsAfterEndOfLabTestWithResultWithPeriod(visit, m, ECQM52V7Elements.Cd4__Percentage, ECQM52V7Elements.Cd4__Percentage, CompareOperator.LESS, CalenderUnit.MONTH, 3, 15, CompareOperator.GREATER_EQUAL, patientHistoryList)
    )
  }


}


