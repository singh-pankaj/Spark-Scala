
package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP112Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 112
* Measure Title              :- Breast Cancer Screening
* Measure Description        :- Percentage of women 51 - 74 years of age who had a mammogram to screen for breast cancer
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp112 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp112"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
    //Backtracking List
    val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD, QPP112Elements.Bilateral_Or_Left_And_Right_Unilateral_Mastectomy,
      QPP112Elements.Unilateral_Mastectomy, QPP112Elements.Bilateral_Mastectomy, QPP112Elements.Status_Post_Left_Mastectomy, QPP112Elements.Right, QPP112Elements.Left
      , QPP112Elements.Hospice_Services_Snomedct, QPP112Elements.Hospice_Services, QPP112Elements.Isnp_Or_Long_Term_Care, QPP112Elements.Screening_Mammography, QPP112Elements.Mammography
      , QPP112Elements.Screening_Mammography_Reason_Not_Specified)

     val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect.toList)

    val exclusionRDD = getExclusion(ippRDD, patientHistoryRDD, patientHistoryBroadcastList)

    val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
    metRDD.cache()

    val intermediateB = getSubtractRDD(intermediateA, metRDD)

    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(initialRDD, ippRDD,denominatorRDD , exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    patientHistoryBroadcastList.destroy()
     }
  }

  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(
      visit =>
        isFemale(visit, m)
          &&
        isAgeBetween(visit, m, 51, 75)
          && isVisitTypeIn(visit, m, QPP112Elements.Office_Visit, QPP112Elements.Face_To_Face_Interaction, QPP112Elements.Home_Healthcare_Services,
          QPP112Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up, QPP112Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
          QPP112Elements.Annual_Wellness_Visit, QPP112Elements.Initial_Preventive_Physical_Examination)
    )

  }

  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    val countRDD = countElement(patientHistoryRDD, m, QPP112Elements.Unilateral_Mastectomy)

    ippRDD.filter(
      visit =>
        isProcedurePerformedBeforeEnd(visit, m, QPP112Elements.Bilateral_Mastectomy, patientHistoryBroadcastList)
          || getEncounterCountFromHistory(visit, m, 2, false, countRDD)

          ||
                (
          (
          isDiagnosisWithBeforeEnd(visit, m, QPP112Elements.Status_Post_Left_Mastectomy, patientHistoryBroadcastList)
            ||
            wasDiagnosedBeforeEndWithLaterality(visit, m, QPP112Elements.Unilateral_Mastectomy, QPP112Elements.Right, patientHistoryBroadcastList)
          )
          &&
          (
            isDiagnosisWithBeforeEnd(visit, m, QPP112Elements.Status_Post_Left_Mastectomy, patientHistoryBroadcastList)
              || wasDiagnosedBeforeEndWithLaterality(visit, m, QPP112Elements.Unilateral_Mastectomy, QPP112Elements.Left, patientHistoryBroadcastList)
            ))
          || isDiagnosisWithBeforeEnd(visit, m, QPP112Elements.Bilateral_Or_Left_And_Right_Unilateral_Mastectomy, patientHistoryBroadcastList)
          || isProcedurePerformed(visit, m, QPP112Elements.Bilateral_Or_Left_And_Right_Unilateral_Mastectomy, patientHistoryBroadcastList)
          || (
          isInterventionPerformedInHistory(visit, m, QPP112Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
            || isInterventionPerformedInHistory(visit, m, QPP112Elements.Hospice_Services, patientHistoryBroadcastList)
          )
          || isInterventionPerformed(visit, m, QPP112Elements.Hospice_Services, patientHistoryBroadcastList)
          || isInterventionPerformed(visit, m, QPP112Elements.Isnp_Or_Long_Term_Care, patientHistoryBroadcastList)

    )

  }


  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        (
          isDiagnosticStudyDuringMesurementPeriod(visit, m, QPP112Elements.Screening_Mammography, patientHistoryBroadcastList)
            || wasDiagnosticStudyBeforeXMonths(visit, m, QPP112Elements.Mammography, 27, patientHistoryBroadcastList)
          )
          && !isDiagnosticStudyDuringMesurementPeriod(visit, m, QPP112Elements.Screening_Mammography_Reason_Not_Specified, patientHistoryBroadcastList)
        ))
  }

}
