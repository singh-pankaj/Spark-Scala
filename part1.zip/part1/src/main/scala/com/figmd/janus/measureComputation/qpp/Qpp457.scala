package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP457Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 457
* Measure Title              :- Percentage of Patients Who Died from Cancer Admitted to Hospice for Less than 3 days (lower score â€“ better)
* Measure Description        :- Percentage of patients who died from cancer, and admitted to hospice and spent less than 3 days there
* Calculation Implementation :- Patient Specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp457 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp457"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP457Elements.Office_Visit,
      QPP457Elements.Cancer,
      QPP457Elements.Enrolled_In_Hospice,
      QPP457Elements.Hospice_Care_Services,
      QPP457Elements.Hospice_Care_Met
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Intermediate A
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()
      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()
      // Filter Intermediate B
      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()
      // Filter Denominator Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()
      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val officeVisits = countElement(patientHistoryRDD, m, QPP457Elements.Office_Visit)

    initialRDD.filter(visit =>
      isDiagnosisWithBeforeEnd(visit, m, QPP457Elements.Cancer, patientHistoryList)
        && getEncounterCountFromHistory(visit, m, 2, true, officeVisits)
        && (
        isInterventionPerformed(visit, m, QPP457Elements.Enrolled_In_Hospice, patientHistoryList)
          || isInterventionPerformed(visit, m, QPP457Elements.Hospice_Care_Services, patientHistoryList)
          && isVisitTypeIn(visit, m, QPP457Elements.Death_Due_To_Cancer_1, QPP457Elements.Death_Due_To_Cancer_2)
        )
    )
  }

  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>

      ((wasInterventionPerformedAfterEncounterinHistory(visit, m, QPP457Elements.Hospice_Care_Met, patientHistoryList, QPP457Elements.Office_Visit)
        && isInterventionPerformedBefore(visit, m, QPP457Elements.Death_Due_To_Cancer_1, patientHistoryList, QPP457Elements.Hospice_Care_Met))
        || (wasInterventionPerformedAfterEncounterinHistory(visit, m, QPP457Elements.Hospice_Care_Services, patientHistoryList, QPP457Elements.Office_Visit)
        && wasInterventionPerformedBeforeWithinXDaysOfPatientExpired(visit, m, QPP457Elements.Death_Due_To_Cancer_2, QPP457Elements.Hospice_Care_Services, 3, patientHistoryList)
        )
        )
        && !((wasInterventionPerformedAfterEncounterinHistory(visit, m, QPP457Elements.Hospice_Care_Not_Met, patientHistoryList, QPP457Elements.Office_Visit)
        && isInterventionPerformedBefore(visit, m, QPP457Elements.Death_Due_To_Cancer_1, patientHistoryList, QPP457Elements.Hospice_Care_Not_Met))
        || (wasInterventionPerformedAfterEncounterinHistory(visit, m, QPP457Elements.Hospice_Care_Services, patientHistoryList, QPP457Elements.Office_Visit)
        && wasInterventionPerformedBeforeXDaysGreaterOfPatientExpired(visit, m, QPP457Elements.Death_Due_To_Cancer_2, QPP457Elements.Hospice_Care_Services, 3, patientHistoryList)
        )
        )

    )
  }

}
