package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP325Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 325
* Measure Title              :- Adult Major Depressive Disorder (MDD): Coordination of Care of Patients with Specific Comorbid Conditions
* Measure Description        :- Percentage of medical records of patients aged 18 years and older with a diagnosis of
                                major depressive disorder (MDD) and a specific diagnosed comorbid condition (diabetes,
                                coronary artery disease, ischemic stroke, intracranial hemorrhage, chronic kidney disease [stages 4 or 5],
                                End Stage Renal Disease [ESRD] or congestive heart failure) being treated by another
                                clinician with communication to the clinician treating the comorbid condition.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp325 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp325"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP325Elements.Major_Depressive_Disorder_Active
      , QPP325Elements.Diabetes
      , QPP325Elements.Stroke
      , QPP325Elements.Chronic_Kidney_Disease__Stage_4_And_5_
      , QPP325Elements.Coronary_Artery_Disease
      , QPP325Elements.Heart_Failure
      , QPP325Elements.Medical_Records_Communication_To_Clinician
      , QPP325Elements.Mdcl_Rcrds_Communict_To_Clincn_Reason_Not_Specified
      , QPP325Elements.Mdcl_Rcrds_Communict_To_Clincn_Patient_Reason
      , QPP325Elements.Communication_To_Clinicians_Patient_Reason
      , QPP325Elements.Communication_To_Other_Clinician).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate RDD
      val intermediateException = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
   All medical records of patients aged 18 years and older with a diagnosis of major depressive
   disorder (MDD) and a specific diagnosed comorbid condition (diabetes, coronary artery disease,
   ischemic stroke, intracranial hemorrhage, chronic kidney disease [stages 4 or 5],
   ESRD or congestive heart failure) being treated by another clinician.
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m
        , QPP325Elements.Psych_Visit
        , QPP325Elements.Psychoanalysis
        , QPP325Elements.Office_Visit
        , QPP325Elements.Care_Management_Services
        , QPP325Elements.Psychiatric_Care_Management)
        && wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP325Elements.Major_Depressive_Disorder_Active, patientHistoryBroadcastList)
        && (
        wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP325Elements.Diabetes, patientHistoryBroadcastList)
          || wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP325Elements.Stroke, patientHistoryBroadcastList)
          || wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP325Elements.Chronic_Kidney_Disease__Stage_4_And_5_, patientHistoryBroadcastList)
          || wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP325Elements.Coronary_Artery_Disease, patientHistoryBroadcastList)
          || wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP325Elements.Heart_Failure, patientHistoryBroadcastList)
        )
    )
  }

  /*------------------------------------------------------------------------------------------------
    Medical records of patients with communication to the clinician treating the comorbid condition.
   ------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        isCommunicationFromProvidertoProvider(visit, m, QPP325Elements.Medical_Records_Communication_To_Clinician, patientHistoryBroadcastList)
          || wasCommunicationFromProvidertoProviderAfterOrEqualDiagnosisAndBeforeEnd(visit, m, QPP325Elements.Major_Depressive_Disorder_Active, QPP325Elements.Communication_To_Other_Clinician, patientHistoryBroadcastList)
        )
        && !isCommunicationFromProvidertoProvider(visit, m, QPP325Elements.Mdcl_Rcrds_Communict_To_Clincn_Reason_Not_Specified, patientHistoryBroadcastList)
    )

  }

  /*-----------------------------------------------------------------------------------------------------------------
    Clinician treating Major Depressive Disorder did not communicate to clinician treating comorbid
    condition for specified patient reason (e.g. patient is unable to communicate the diagnosis
    of a comorbid condition; the patient is unwilling to communicate the diagnosis of
    a comorbid condition; or he patient is unaware of the comorbid condition, or any other specified patient reason).
   -----------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermedaiateRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermedaiateRdd.filter(visit =>
      isCommunicationFromProvidertoProvider(visit, m, QPP325Elements.Mdcl_Rcrds_Communict_To_Clincn_Patient_Reason, patientHistoryBroadcastList)
        || isPatientCharacteristic(visit, m, QPP325Elements.Communication_To_Clinicians_Patient_Reason, patientHistoryBroadcastList)
    )

  }

}
