package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty}
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- TEST 5
* Measure Title              :- Tonsillectomy: Primary Post-Tonsillectomy Hemorrhage in Adults
* Measure Description        :- The rate of primary post-tonsillectomy hemorrhage within 1 day post-op that requires
*                               reevaluation or intervention in patients >18 years of age.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Test5 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Test5"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //getPatientHistoryList
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD
        , TEST5Elements.Bleeding__Clotting_Disorders
        , TEST5Elements.Tonsillectomy
        , TEST5Elements.Post__Tonsillectomy_Hemorrhage__Primary_
        , TEST5Elements.Primary_Hemorrhage
      ).collect().toList

      val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      /* val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    notEligibleRDD.cache()*/


      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()

    }
  }


  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        isProcedurePerformedDuringEncounter(visit, m, TEST5Elements.Tonsillectomy)
        &&
        isVisitTypeIn(visit, m
          , TEST5Elements.Office_Or_Other_Outpatient_Visit
          , TEST5Elements.Discharge_Services__Observation_Care
          , TEST5Elements.Discharge_Services___Hospital_Inpatient_Same_Day_Discharge
          , TEST5Elements.Outpatient_Consultation
          , TEST5Elements.Hospital_Inpatient_Visit___Initial
          , TEST5Elements.Hospital_Observation_Care___Initial
          , TEST5Elements.Subsequent_Hospital_Care
          , TEST5Elements.Subsequent_Observation_Care
        )
    )
  }


  // Denominator Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      wasDiagnosisBeforeOrEqualProcedure(visit, m, TEST5Elements.Bleeding__Clotting_Disorders, TEST5Elements.Tonsillectomy, patientHistoryList)
    )
  }

  // Numerator criteria
  def getMet(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      wasDiagnosisAfterXPeriodProcedure(visit, m, TEST4Elements.Tonsillectomy, 1, CompareOperator.LESS, patientHistoryList, TEST4Elements.Primary_Hemorrhage)
        ||
        wasProcedureAfterXProcedureDays(visit, m, TEST5Elements.Tonsillectomy, TEST5Elements.Tonsillectomy_Date, 1, patientHistoryList, TEST5Elements.Post__Tonsillectomy_Hemorrhage__Primary_)

    )
  }
}
