package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP118Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}
/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 118
* Measure Title              :- Coronary Artery Disease (CAD): Angiotensin-Converting Enzyme (ACE) Inhibitor or
*                               Angiotensin Receptor Blocker (ARB) Therapy - Diabetes or Left Ventricular Systolic Dysfunction (LVEF < 40%)
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of coronary artery disease seen within a 12 month
*                               period who also have diabetes OR a current or prior Left Ventricular Ejection Fraction (LVEF) < 40%
*                               who were prescribed ACE inhibitor or ARB therapy
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 1
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp118_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp118_1"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD,
      QPP118Elements.Office_Visit,
      QPP118Elements.Nursing_Facility_Visit,
      QPP118Elements.Care_Services_In_Long_Term_Residential_Facility,
      QPP118Elements.Home_Healthcare_Services,
      QPP118Elements.Coronary_Artery_Disease,
      QPP118Elements.Left_Ventricular_Ejection_Fraction,
      QPP118Elements.Left_Ventricular_Ejection_Fraction__Lvef_,
      QPP118Elements.Twod_Echocardiography,
      QPP118Elements.Lvef_Assessment,
      QPP118Elements.Ace_Inhibitor_Or_Arb_1,
      QPP118Elements.Ace_Inhibitor_Or_Arb_2,
      QPP118Elements.Ace_Or_Arb_Therapy_Patient_Not_Eligible,
      QPP118Elements.Allergy_To_Ace_Inhibitor_Or_Arb,
      QPP118Elements.Intolerance_To_Ace_Inhibitor_Or_Arb,
      QPP118Elements.Aortic_Or_Mitral_Valve_Diseases,
      QPP118Elements.Medical_Reason,
      QPP118Elements.Patient_Reason,
      QPP118Elements.Renal_Failure_Due_To_Ace_Inhibitor,
      QPP118Elements.Lack_Of_Drug_Availability)
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter Met
    val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
    metRDD.cache()

    val intermediateB =getSubtractRDD( ippRDD,metRDD)
    intermediateB.cache()

    // Filter Exceptions

    val exceptionRDD = getExceptionRDD(intermediateB, patientHistoryBroadcastList)

    // Filter Not Met
    val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    patientHistoryBroadcastList.destroy()
  }
}
//Reporting Criteria 1: All patients aged 18 years and older with a diagnosis of coronary artery disease seen within a 12 month period who also have a current or prior LVEF < 40%

  def getIpp(rdd: RDD[CassandraRow],patientHistoryRDD:RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    val countElementList2: List[(String,Int)] = countElement(patientHistoryRDD,m,
                      QPP118Elements.Office_Visit,
                      QPP118Elements.Nursing_Facility_Visit,
                      QPP118Elements.Care_Services_In_Long_Term_Residential_Facility,
                      QPP118Elements.Home_Healthcare_Services)

    rdd.filter(visit =>
      (
        isPatientAdult(visit, m)
          && isVisitTypeIn(visit, m,
          QPP118Elements.Office_Visit,
          QPP118Elements.Nursing_Facility_Visit,
          QPP118Elements.Care_Services_In_Long_Term_Residential_Facility,
          QPP118Elements.Home_Healthcare_Services)
          &&  getEncounterCountFromHistory(visit,m,2,true, countElementList2)
          && isDiagnosedDuringEncounter(visit, m, QPP118Elements.Coronary_Artery_Disease )
          &&
          (
               wasDiagnosticStudyPerformedInHistory(visit, m, QPP118Elements.Left_Ventricular_Ejection_Fraction, patientHistoryBroadcastList)
            || wasDiagnosticStudyPerformedInHistory(visit, m, QPP118Elements.Left_Ventricular_Ejection_Fraction__Lvef_, patientHistoryBroadcastList)
            ||
            (
              (
                wasProcedurePerformedInHistory(visit, m, QPP118Elements.Twod_Echocardiography, patientHistoryBroadcastList, QPP118Elements.Twod_Echocardiography)
                && wasDiagnosticStudyPerformedInHistory(visit, m, QPP118Elements.Left_Ventricular_Ejection_Fraction__Lvef_, patientHistoryBroadcastList)
              )
              ||
              (
                wasProcedurePerformedInHistory(visit, m, QPP118Elements.Twod_Echocardiography, patientHistoryBroadcastList, QPP118Elements.Twod_Echocardiography)
                && wasDiagnosticStudyPerformedInHistory(visit, m, QPP118Elements.Left_Ventricular_Ejection_Fraction, patientHistoryBroadcastList)
              )
              || isAssessmentPerformedValue(visit,m,QPP118Elements.Lvef_Assessment,40,"lt",patientHistoryBroadcastList)
            )
          )
          && ! isTeleHealthEncounterNotPerformed(visit, m,
                QPP118Elements.Home_Healthcare_Services_Telehealth_Modifier,
                QPP118Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier,
                QPP118Elements.Nursing_Facility_Visit_Telehealth_Modifier,
                QPP118Elements.Office_Visit_Telehealth_Modifier)
          &&  isPOSEncounterNotPerformed (visit, m, QPP118Elements.Pos_02)
      )
    )
  }

//Reporting Criteria 1: Patients who were prescribed ACE inhibitor or ARB therapy
  def getMet(intermediateA: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      (
        isMedicationOrderedDuringEncounter(visit,m,QPP118Elements.Ace_Inhibitor_Or_Arb_1)
        ||
        isMedicationOrderedDuringEncounter(visit,m,QPP118Elements.Ace_Inhibitor_Or_Arb_2)
        ||
        wasMedicationActiveInHistory(visit,m,QPP118Elements.Ace_Inhibitor_Or_Arb_1,patientHistoryBroadcastList)
      )
        && !isMedicationOrderedOnEncounter(visit,m,QPP118Elements.Ace_Or_Arb__Reason_Not_Specified)
    )
  }

  //Reporting Criteria 1 : Clinician documented that patient was not an eligible candidate for angiotensin converting enzyme (ACE) inhibitor or angiotensin receptor blocker (ARB) therapy (e.g., allergy, intolerance, pregnancy, renal failure due to ACE inhibitor, diseases of the aortic or mitral valve, other medical reasons) or (e.g., patient declined, other patient reasons) or (e.g., lack of drug availability, other reasons attributable to the health care system)

  def getExceptionRDD(intermediateRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)
    intermediateRDD.filter(visit =>
      (
        isMedicationOrdered(visit,m,patientHistoryBroadcastList,QPP118Elements.Ace_Or_Arb_Therapy_Patient_Not_Eligible)
          ||
          (
            (wasMedicationAllergyBeforeEncounter(visit,m,QPP118Elements.Allergy_To_Ace_Inhibitor_Or_Arb,patientHistoryBroadcastList)
              ||
              wasMedicationInToleraneInHistory(visit,m,QPP118Elements.Intolerance_To_Ace_Inhibitor_Or_Arb,patientHistoryBroadcastList)
              ||
              wasDiagnosedInHistory(visit,m,QPP118Elements.Aortic_Or_Mitral_Valve_Diseases,patientHistoryBroadcastList)
              ||
              wasMedicationOrderedNotDoneInHistory(visit,m,QPP118Elements.Medical_Reason,patientHistoryBroadcastList)
              ||
              wasMedicationOrderedNotDoneInHistory(visit,m,QPP118Elements.Patient_Reason,patientHistoryBroadcastList)
              ||
              wasDiagnosedInHistory(visit,m,QPP118Elements.Renal_Failure_Due_To_Ace_Inhibitor,patientHistoryBroadcastList))
              ||
              isMedicationOrdered(visit,m,patientHistoryBroadcastList,QPP118Elements.Lack_Of_Drug_Availability)
            )
          ||
          isDiagnosedDuringEncounter(visit,m,QPP118Elements.Pregnancy)
        )
    )
  }
}
