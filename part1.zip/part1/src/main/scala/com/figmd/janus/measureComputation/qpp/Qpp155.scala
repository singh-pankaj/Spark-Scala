package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP155Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp154
* Measure Title              :- Falls: Plan of Care
* Measure Description        :- Percentage of patients aged 65 years and older with a history of falls that had a plan of care for falls documented within 12 months.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp155 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp155"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP155Elements.History_Of_Single_Fall_With_Injury,
      QPP155Elements.History_Of_Falls_Without_Injury,
      QPP155Elements.Falls_History,
      QPP155Elements.Hospice_Services,
      QPP155Elements.Hospice_Care,
      QPP155Elements.Plan_Of_Care,
      QPP155Elements.Training,
      QPP155Elements.Balance_Strength__And_Gait_Training,
      QPP155Elements.Physical_Activity_Care_Plan,
      QPP155Elements.Falls_Plan_Of_Care_Reason_Not_Specified,
      QPP155Elements.Plan_Of_Care_Medical_Reason,
      QPP155Elements.Patient_Not_Ambulatory_Gr,
      QPP155Elements.Patient_Not_Ambulatory_Kywrd
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exceptions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val intermediateRDD = getSubtractRDD(ippRDD,metRDD)
      intermediateRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }

  /*
  All patients aged 65 years and older with a history of falls (history of falls is defined as 2 or more falls in
  the past year or any fall with injury in the past year). Documentation of patient reported history of falls is sufficient
   */

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientElderly(visit, m)
        && isVisitTypeIn(visit, m, QPP155Elements.Home_Healthcare_Services
        , QPP155Elements.Care_Services_In_Long_Term_Residential_Facility
        , QPP155Elements.Annual_Wellness_Visit
        , QPP155Elements.Nursing_Facility_Visit
        , QPP155Elements.Office_Visit
        , QPP155Elements.Audiology_Visit
        , QPP155Elements.Initial_Preventive_Physical_Examination
        , QPP155Elements.Physical_Therapy_Evaluation_Cpt
        , QPP155Elements.Re_Evaluation_Of_Physical_Therapy_Cpt
        , QPP155Elements.Occupational_Therapy_Cpt
        , QPP155Elements.Occupational_Therapy_Re_Evalution_Cpt)
        &&
        (
          isAssessmentPerformedOnEncounter(visit, m, QPP155Elements.History_Of_Falls)
            || wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP155Elements.History_Of_Single_Fall_With_Injury, 12, patientHistoryBroadcastList)
            || wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP155Elements.History_Of_Falls_Without_Injury, 12, patientHistoryBroadcastList)
            ||
            (
              wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP155Elements.History_Of_Falls_Without_Injury, 12, patientHistoryBroadcastList)
                && wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP155Elements.Falls_History, 12, patientHistoryBroadcastList)
              )
          ))
  }


  //Hospice services for patient provided any time during the measurement period
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      isInterventionBeforeEnd(visit, m, QPP155Elements.Hospice_Services, patientHistoryBroadcastList)
        || isInterventionBeforeEnd(visit, m, QPP155Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
        || isInterventionPerformed(visit, m, QPP155Elements.Hospice_Care, patientHistoryBroadcastList)
    )
  }

  //Patients with a plan of care for falls documented within 12 months
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        wasInterventionPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP155Elements.Plan_Of_Care, 12, patientHistoryBroadcastList)
          || wasProcedurePerformedInXYears(visit, m, QPP155Elements.Training, 1, patientHistoryBroadcastList)
          || wasInterventionPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP155Elements.Balance_Strength__And_Gait_Training, 12, patientHistoryBroadcastList)
          || wasInterventionAdverseEventInXMonths(visit, m, AdminElements.Encounter_Date, QPP155Elements.Physical_Activity_Care_Plan, 12, patientHistoryBroadcastList)
        ) && !wasInterventionPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP155Elements.Falls_Plan_Of_Care_Reason_Not_Specified, 12, patientHistoryBroadcastList)
    )
  }


  /*

  Patient not ambulatory, bed ridden, immobile, confined to chair, wheelchair bound, dependent on helper pushing wheelchair, independent in wheelchair or minimal help in wheelchair
   */
  def getException(intermediateRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateRdd.filter(visit =>
      (
        wasInterventionNotPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP155Elements.Plan_Of_Care_Medical_Reason, 12, patientHistoryBroadcastList)
          || wasPatientCharacteristicInHistory(visit, m, QPP155Elements.Patient_Not_Ambulatory_Gr, patientHistoryBroadcastList)
          || wasPatientCharacteristicInHistory(visit, m, QPP155Elements.Patient_Not_Ambulatory_Kywrd, patientHistoryBroadcastList)
        ))
  }

}
