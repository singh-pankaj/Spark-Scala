
package com.figmd.janus.measureComputation.qpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.{MeasureUpdate}
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP416Elements,AdminElements}
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 416
* Measure Title              :- Emergency Medicine: Emergency Department Utilization of CT for Minor Blunt
                                Head Trauma for Patients Aged 2 Through 17 Years
* Measure Description        :- Percentage of emergency department visits for patients aged 2 through 17 years who presented
                                with a minor blunt head trauma who had a head CT for trauma ordered by an emergency care provider
                                who are classified as low risk according to the Pediatric Emergency Care
                                Applied Research Network (PECARN) prediction rules for traumatic brain injury
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Lower score indicates  better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp416 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp416"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {
    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()
    //Patient history  List
    val patientHistoryRDD = getPatientHistory(sparkSession,ippRDD,
      QPP416Elements.Brain_Tumor,
      QPP416Elements.Coagulopathies,
      QPP416Elements.Thrombocytopenia,
      QPP416Elements.Ventricular_Shunt)
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect.toList)
    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
          denominatorRDD.cache()
      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()
      // Filter Intermediate for Met
      val intermediateMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateMet.cache()
      // Filter Met
      val metRDD = getMet(intermediateMet)
      metRDD.cache()
     // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateMet, metRDD)
      notMetRDD.cache()
      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------
    All emergency department visits for patients aged 2 through 17 years who presented with a minor blunt head trauma
    who had a head CT for trauma ordered by an emergency care provider*
   ------------------------------------------------------------------------------------------------------------------*/

  def getIpp(rdd:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
            isAgeBetween(visit,m,2,18)
        &&  isVisitTypeIn(visit,m,QPP416Elements.Critical_Care_Evaluation_And_Management,QPP416Elements.Emergency_Department_Visit)
        &&  (
                  (
                        isDiagnosisDuringEDOrCCEncounter(visit, m, QPP416Elements.Non_Penetrating_Head_Trauma,QPP416Elements.Non_Penetrating_Head_Trauma_Date,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date)
                    &&  (
                                isDiagnosticStudyDuringEDOrCCEncounter(visit, m, QPP416Elements.Head_Ct_Performed,QPP416Elements.Head_Ct_Performed_Date,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date)
                            ||  isDiagnosticStudyDuringEDOrCCEncounter(visit, m, QPP416Elements.Head_Ct,QPP416Elements.Head_Ct_Date,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date)
                        )
                  )
                 ||  isAssessmentDuringEDOrCCEncounter(visit,m,QPP416Elements.Minor_Blunt_Head_Trauma_Ct_Ordered_G,QPP416Elements.Minor_Blunt_Head_Trauma_Ct_Ordered_G_Date,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date)
            )
    )
  }

  /*---------------------------------------------------------------------------------------------
   Patients with any of the following:
   - Ventricular shunt
   - Brain tumor
   - Coagulopathy
   - Thrombocytopenia
   ----------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
             wasDiagnosedBeforeEDOrCCEncounter(visit, m,QPP416Elements.Brain_Tumor,AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        ||   wasDiagnosedBeforeEDOrCCEncounter(visit, m,QPP416Elements.Coagulopathies,AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        ||   wasDiagnosedBeforeEDOrCCEncounter(visit, m,QPP416Elements.Thrombocytopenia,AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        ||   wasDiagnosedBeforeEDOrCCEncounter(visit, m,QPP416Elements.Ventricular_Shunt,AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        ||   isAssessmentDuringEDOrCCEncounter(visit,m,QPP416Elements.Multiple_Diagnoses,QPP416Elements.Multiple_Diagnoses_Date,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }

  /*----------------------------------------------------------------------------------------
    Emergency department visits for patients who are classified as low risk according to
    the PECARN prediction rules for traumatic brain injury
   -----------------------------------------------------------------------------------------*/

  def getMet(intermediateMet: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateMet.filter(visit =>
        (
          (
                 !isSymptomDuringEDOrCCEncounter(visit,m,QPP416Elements.Signs_Of_Altered_Mental_Status,QPP416Elements.Signs_Of_Altered_Mental_Status_Date,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date)
            &&   !isSymptomDuringEDOrCCEncounter(visit,m,QPP416Elements.Physical_Signs_Of_Basilar_Skull_Fracture,QPP416Elements.Physical_Signs_Of_Basilar_Skull_Fracture_Date,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date)
            &&   !isSymptomDuringEDOrCCEncounter(visit,m,QPP416Elements.Loss_Of_Consciousness,QPP416Elements.Loss_Of_Consciousness_Date,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date)
            &&   !isSymptomDuringEDOrCCEncounter(visit,m,QPP416Elements.Vomiting,QPP416Elements.Vomiting_Date,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date)
            &&   !(
                        isVisitTypeIn(visit,m,QPP416Elements.Critical_Care_Evaluation_And_Management,QPP416Elements.Emergency_Department_Visit)
                        &&
                        (
                                  isEncounterPerformedEDOrCCEncounter(visit,m,QPP416Elements.Critical_Care_Evaluation_And_Management,QPP416Elements.Dangerous_Mechanism_Of_Injury)
                              ||  isEncounterPerformedEDOrCCEncounter(visit,m,QPP416Elements.Emergency_Department_Visit,QPP416Elements.Dangerous_Mechanism_Of_Injury)
                        )
                 )
            &&   !isSymptomDuringEDOrCCSeverity(visit,m,QPP416Elements.Headache,QPP416Elements.Headache_Date,QPP416Elements.Severe,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date)
            &&   !isGCSResultDuringEDorCCLessThanX(visit,m,QPP416Elements.Headache,15,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date)
          )
          ||  isAssessmentDuringEDOrCCEncounter(visit,m,QPP416Elements.Pecarn_Prediction_Rules,QPP416Elements.Pecarn_Prediction_Rules_Date,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date)
        )
        &&  !isAssessmentDuringEDOrCCEncounter(visit,m,QPP416Elements.Pecarn_Prediction_Rules_Not_Met,QPP416Elements.Pecarn_Prediction_Rules_Not_Met_Date,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,QPP416Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }

}
