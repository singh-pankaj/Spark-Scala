package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{QPP46Elements,  MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP46_3
* Measure Title              :- Medication Reconciliation Post-Discharge
* Measure Description        :- The percentage of discharges from any inpatient facility (e.g. hospital, skilled nursing facility, or rehabilitation facility) for patients 18 years of age and older seen within 30 days following discharge in the office by the physician, prescribing practitioner, registered nurse, or clinical pharmacist providing on-going care for whom the discharge medication list was reconciled with the current medication list in the outpatient medical record.
                                This measure is submitted as three rates stratified by age group:
                                • Submission Criteria 1: 18-64 years of age
                                • Submission Criteria 2: 65 years and older
                                • Total Rate: All patients 18 years of age and older
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 3
* Measure Stratum No.        :- 3
* Measure Stratification     :- 3
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp46_3 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP46_3"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      QPP46Elements.Hospice_Services,
      QPP46Elements.Hospice_Care,
      QPP46Elements.Hospice_Services_Snomedct,
      QPP46Elements.Medication_Reconciliation_Grp,
      QPP46Elements.Reconciliation_Of_Discharge_Medication,
      QPP46Elements.Discharge_From_Inpatient_Facility,
      QPP46Elements.Face_To_Face_Visit,
      QPP46Elements.Hospice_Services,
      QPP46Elements.Medications_Encounter_Code_Set,
      QPP46Elements.Psych_Enc,
      QPP46Elements.Psych_Visit,
      QPP46Elements.Care_Services_In_Long_Term_Residential_Facility,
      QPP46Elements.Office_Visit,
      QPP46Elements.Reconciliation_Med_Reason_Not_Specified
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter denominator Exclusions
      val exclusionRDD = getDenominatorExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      //eligible initial population RDD
      val intermediateRDD = getSubtractRDD(ippRDD, exclusionRDD)

      // Met rdd
      val metRDD = getMet(sparkSession, intermediateRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  * All discharges from any inpatient facility (e.g., hospital, skilled nursing facility, or rehabilitation facility) for patients 18 years of age and older seen within 30 days following discharge in the office by the physician, prescribing practitioner, registered nurse, or clinical pharmacist providing on-going care.
    Denominator Criteria (Eligible Cases):
    SUBMISSION CRITERIA 3: Total Rate: All patients 18 years of age and older
  *-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    rdd.filter(visit=>
      isAgeAbove(visit,m,true,18)
        && wasEncounterPerformed(visit,m,QPP46Elements.Discharge_From_Inpatient_Facility,patientHistoryList)
        &&(
        wasEncounterPerformed(visit,m,QPP46Elements.Office_Visit,patientHistoryList)
          || wasEncounterPerformed(visit,m,QPP46Elements.Home_Healthcare_Services,patientHistoryList)
          || wasEncounterPerformed(visit,m,QPP46Elements.Medications_Encounter_Code_Set,patientHistoryList)
          || wasEncounterPerformed(visit,m,QPP46Elements.Psych_Enc,patientHistoryList)
          || wasEncounterPerformed(visit,m,QPP46Elements.Psych_Visit,patientHistoryList)
          || wasEncounterPerformed(visit,m,QPP46Elements.Care_Services_In_Long_Term_Residential_Facility,patientHistoryList)
          || wasEncounterPerformed(visit,m,QPP46Elements.Face_To_Face_Visit,patientHistoryList)
        )
        &&
        (isEncounterPerformedXDaysInFuture(visit,m,QPP46Elements.Discharge_From_Inpatient_Facility,QPP46Elements.Face_To_Face_Visit,30,patientHistoryList)
          ||isEncounterPerformedXDaysInFuture(visit,m,QPP46Elements.Discharge_From_Inpatient_Facility,QPP46Elements.Hospice_Services,30,patientHistoryList)
          ||isEncounterPerformedXDaysInFuture(visit,m,QPP46Elements.Discharge_From_Inpatient_Facility,QPP46Elements.Medications_Encounter_Code_Set,30,patientHistoryList)
          ||isEncounterPerformedXDaysInFuture(visit,m,QPP46Elements.Discharge_From_Inpatient_Facility,QPP46Elements.Psych_Enc,30,patientHistoryList)
          ||isEncounterPerformedXDaysInFuture(visit,m,QPP46Elements.Discharge_From_Inpatient_Facility,QPP46Elements.Psych_Visit,30,patientHistoryList)
          ||isEncounterPerformedXDaysInFuture(visit,m,QPP46Elements.Discharge_From_Inpatient_Facility,QPP46Elements.Care_Services_In_Long_Term_Residential_Facility,30,patientHistoryList)
          ||isEncounterPerformedXDaysInFuture(visit,m,QPP46Elements.Discharge_From_Inpatient_Facility,QPP46Elements.Office_Visit,30,patientHistoryList)
          )
    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   Patient had hospice services any time during the measurement period.
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getDenominatorExclusionRdd(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    rdd.filter(visit=>wasInterventionPerformedInHistory(visit,m,QPP46Elements.Hospice_Services,patientHistoryList)
      ||(
      wasInterventionPerformedInHistory(visit,m,QPP46Elements.Hospice_Care,patientHistoryList)
        ||wasInterventionPerformedInHistory(visit,m,QPP46Elements.Hospice_Services_Snomedct,patientHistoryList)
      )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  * Medication reconciliation conducted by a prescribing practitioner, clinical pharmacists or registered nurse on or within 30 days of discharge.
  * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getMet(spark:SparkSession,rdd: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    rdd.filter(visit=>
      (
        isEncounterPerformedXDaysInFuture(visit,m,QPP46Elements.Discharge_From_Inpatient_Facility,QPP46Elements.Reconciliation_Of_Discharge_Medication,30,patientHistoryList)
          || isEncounterPerformedXDaysInFuture(visit,m,QPP46Elements.Discharge_From_Inpatient_Facility,QPP46Elements.Medication_Reconciliation_Grp,30,patientHistoryList)
        )
        &&
        !isEncounterPerformedXDaysInFuture(visit,m,QPP46Elements.Discharge_From_Inpatient_Facility,QPP46Elements.Reconciliation_Med_Reason_Not_Specified,30,patientHistoryList)
    )
  }


}
