package com.figmd.janus.measureComputation.qpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{QPP52Elements, _}
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.qpp.Qpp52.wasDiagnosedBeforeOrEqualEncounter

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 52
* Measure Title              :- Chronic Obstructive Pulmonary Disease (COPD): Long-Acting Inhaled Bronchodilator Therapy
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of COPD (FEV1/FVC < 70%) and
                                who have an FEV1 less than 60% predicted and have symptoms who were prescribed an long-acting inhaled bronchodilator
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp52 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp52"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      , QPP52Elements.Chronic_Obstructive_Pulmonary_Disease
      , QPP52Elements.Spirometry_Results_Demonstration
      , QPP52Elements.Cough__Sputum
      , QPP52Elements.Wheezing
      , QPP52Elements.Dyspnea
      , QPP52Elements.Fev1
      , QPP52Elements.Fev1__Fvc
      , QPP52Elements.Long_Acting_Inhaled_Bronchodilator
      , QPP52Elements.Medical_Reason
      , QPP52Elements.Patient_Reason
      , QPP52Elements.System_Reason_2018)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateA = getSubtractRDD(ippRDD, metRDD)
      intermediateA.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateA, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }
  /*-------------------------------------------------------------------------------------------------------------------------
All patients aged 18 years and older with a diagnosis of COPD (FEV1/FVC < 70%), who have an FEV1 < 60% predicted and have symptoms (e.g., dyspnea, cough/sputum, wheezing)
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(rdd:RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
            isPatientAdult(visit,m)
        &&  isVisitTypeIn(visit,m,QPP52Elements.Office_Visit)
        &&  wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP52Elements.Chronic_Obstructive_Pulmonary_Disease,patientHistoryBroadcastList)
        &&  (isLaboratoryTestPerformed(visit,m,QPP52Elements.Spirometry_Results_Demonstration,patientHistoryBroadcastList)
              || (  (  wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP52Elements.Cough__Sputum,patientHistoryBroadcastList)
                    || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP52Elements.Wheezing,patientHistoryBroadcastList)
                    || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP52Elements.Dyspnea,patientHistoryBroadcastList)
                    )
                   && wasLaboratoryTestPerformedValueBeforeOrEqualEncounter(visit,m,QPP52Elements.Fev1,60,"lt",patientHistoryBroadcastList)
                   && wasLaboratoryTestPerformedValueBeforeOrEqualEncounter(visit,m,QPP52Elements.Fev1__Fvc,60,"lt",patientHistoryBroadcastList)
                )
            )
        && ! isTeleHealthModifier(visit,m,QPP52Elements.Office_Visit_Telehealth_Modifier)
        &&  isPOSEncounterNotPerformed(visit,m,QPP67Elements.Pos_02)
    )
  }

/*-------------------------------------------------------------------------------------------------------------------------
Patients who were prescribed a long-acting inhaled bronchodilator
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      (  isMedicationOrderedDuringEncounter(visit,m,QPP52Elements.Inhaled_Bronchodilator)
      || wasMedicationActiveBeforeOrEqualEncounter(visit,m,QPP52Elements.Long_Acting_Inhaled_Bronchodilator,patientHistoryBroadcastList)
      )
      && ! isMedicationOrderedDuringEncounter(visit,m,QPP52Elements.Inhal_Bronchodil_Reason_Not_Specified)
    )
  }

/*-------------------------------------------------------------------------------------------------------------------------
Documentation of medical reason(s) for not prescribing a long-acting inhaled bronchodilator
OR
Documentation of patient reason(s) for not prescribing a long-acting inhaled bronchodilator
OR
Documentation of system reason(s) for not prescribing a long-acting inhaled bronchodilator
----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    rdd.filter(visit =>
         isMedicationOrderedDuringEncounter(visit,m,QPP52Elements.Inhal_Bronchodil_Medical_Reason)
      || isMedicationOrderedDuringEncounter(visit,m,QPP52Elements.Inhal_Bronchodil_Patient_Reason)
      || isMedicationOrderedDuringEncounter(visit,m,QPP52Elements.Inhal_Bronchodil_System_Reason)
      || isMedicationOrdered(visit,m,patientHistoryBroadcastList,QPP52Elements.Medical_Reason)
      || isMedicationOrdered(visit,m,patientHistoryBroadcastList,QPP52Elements.Patient_Reason)
      || isMedicationOrdered(visit,m,patientHistoryBroadcastList,QPP52Elements.System_Reason_2018)
    )
  }
}



