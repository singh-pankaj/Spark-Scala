package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{Axon13Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Axon 13
* Measure Title              :- Headache: Medication prescribed for acute migraine attack
* Measure Description        :- Percentage of patients age 12 years and older with a diagnosis of migraine who
                                were prescribed a guideline recommended medication for acute migraine attacks within
                                the 12 month measurement period.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/



object  Axon13  extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Axon13"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(rdd)
    ippRDD.cache()

    // denominator RDD
    val denominatorRDD = ippRDD
    denominatorRDD.cache()

    val patienthistory = getPatientHistory(sparkSession,ippRDD
      ,Axon13Elements.Migraine_Attack_Medication
      ,Axon13Elements.Guideline_Recommended_Medication
      ,Axon13Elements.Guideline_Recommended_Medication_Medical_Reason
      ,Axon13Elements.Nsaids
      ,Axon13Elements.Migraine_Medication_Medical_Reason
      ,Axon13Elements.Guideline_Recommended_Medication_Patient_Reason
      ,Axon13Elements.Guideline_Recommended_Medication_System_Reason
    ).collect().toList

    val patientHistory:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistory)

    // Filter Met
    val metRDD = getMet(ippRDD,patientHistory)
    metRDD.cache()

    // Filter Intermediate
    val intermediateException = getSubtractRDD(ippRDD, metRDD)
    intermediateException.cache()

    // Filter Exceptions
    val exceptionRDD = getException(intermediateException,patientHistory)
    exceptionRDD.cache()

    val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    patientHistory.destroy()

  }


  /*--------------------------------------------------------------------------------------------------------------------
  All patients age 12 years old and older with a diagnosis of migraine headache
  --------------------------------------------------------------------------------------------------------------------*/


  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
         isAgeAbove(visit,m,true,12)
      && isDiagnosedOnEncounter(visit,m,Axon13Elements.Migraine)
      && isVisitTypeIn(visit,m
                               ,Axon13Elements.Physical_Examination
                               ,Axon13Elements.Subsequent_Nursing_Facility_Visit
                               ,Axon13Elements.Home_Healthcare_Services
                               ,Axon13Elements.Physician_Supervision
                               ,Axon13Elements.Care_Services_In_Long_Term_Residential_Facility
                               ,Axon13Elements.Nursing_Facility_Visit
                               ,Axon13Elements.Inpatient_Consultation
                               ,Axon13Elements.Discharge_Services___Hospital_Inpatient
                               ,Axon13Elements.Subsequent_Hospital_Care
                               ,Axon13Elements.Hospital_Inpatient_Visit___Initial
                               ,Axon13Elements.Office_Visit
                               ,Axon13Elements.Outpatient_Consultation
                               ,Axon13Elements.Evaluation_And_Management_Physician_Visit)

    )

  }



  /*--------------------------------------------------------------------------------------------------------------------
   Patients who were prescribed a guideline recommended medication for acute migraine attacks within
   the 12 month measurement period
   -------------------------------------------------------------------------------------------------------------------*/



  def getMet(ippRDD: RDD[CassandraRow],patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
         isMedicationOrdered(visit,m,patientHistory,Axon13Elements.Migraine_Attack_Medication)
      || isMedicationOrdered(visit,m,patientHistory,Axon13Elements.Guideline_Recommended_Medication)
    )
  }



  /*-------------------------------------------------------------------------------------------------------------------
  • Medical exception for not prescribing a guideline recommended acute migraine medication
    (i.e., guideline recommended medication is medically contraindicated  or ineffective for the patient; migraines are
    effectively controlled with OTC medications or with NSAIDs; patient is already on an effective acute migraine
    medication prescribed by another clinician; patient has no pain with migraine)

  • Patient exception for not prescribing a guideline recommended acute migraine medication
    (i.e.,  patient declines a prescription for any acute migraine medication)

  • System exception for not prescribing a guideline recommended acute migraine medication
    (i.e.,  patient does not have insurance to cover the cost of prescribed abortive migraine medication)
  -------------------------------------------------------------------------------------------------------------------*/



  def getException(intermediateException: RDD[CassandraRow],patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    intermediateException.filter(visit =>
           isMedicationOrdered(visit,m,patientHistory,Axon13Elements.Guideline_Recommended_Medication_Medical_Reason)
        || wasMedicationActiveBeforeOrEqualEncounter(visit,m,Axon13Elements.Nsaids,patientHistory)
        || wasMedicationOrderNotDoneBeforeOrEqualEncounter(visit,m,Axon13Elements.Migraine_Medication_Medical_Reason,patientHistory)
        || isMedicationOrdered(visit,m,patientHistory,Axon13Elements.Guideline_Recommended_Medication_Patient_Reason)
        || isMedicationOrdered(visit,m,patientHistory,Axon13Elements.Guideline_Recommended_Medication_System_Reason)
    )
  }

}
