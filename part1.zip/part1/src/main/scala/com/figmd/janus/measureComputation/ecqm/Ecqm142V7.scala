package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, ECQM142V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm142v7
* Measure Title              :- Diabetic Retinopathy: Communication with the Physician Managing Ongoing Diabetes Care
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of diabetic retinopathy
								                who had a dilated macular or fundus exam performed with documented communication to the physician
								                who manages the ongoing care of the patient with diabetes mellitus regarding the findings
								                of the macular or fundus exam at least once within 12 months
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm142V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm142V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD, ECQM142V7Elements.Diabetic_Retinopathy,
      ECQM142V7Elements.Proliferative_Diabetic_Retinopathy,
      ECQM142V7Elements.Moderate_Diabetic_Retinopathy,
      ECQM142V7Elements.Mild_Non_Proliferative_Diabetic_Retinopathy,
      ECQM142V7Elements.Very_Severe_Non_Proliferative_Diabetic_Retinopathy,
      ECQM142V7Elements.Level_Of_Severity_Of_Retinopathy_Findings_Eye,
      ECQM142V7Elements.Macular_Edema_Findings_Present,
      ECQM142V7Elements.Macular_Edema_Findings_Absent,
      ECQM142V7Elements.Macular_Edema_Findings__Eye,
      ECQM142V7Elements.Diabetic_Retinopathy__Eye,
      ECQM142V7Elements.Macular_Exam__Eye,
      ECQM142V7Elements.Severe_Non_Proliferative_Diabetic_Retinopathy,
      ECQM142V7Elements.Medical_Reason,
      ECQM142V7Elements.Patient_Reason)
    val patientHistoryList = patientHistoryRDD.collect().toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    val patientHistorySortedListRDD = getElementsSortedRecords(initialRDD, patientHistoryBroadcastList,
      ECQM142V7Elements.Level_Of_Severity_Of_Retinopathy_Findings_Eye, ECQM142V7Elements.Macular_Edema_Findings__Eye, ECQM142V7Elements.Macular_Exam__Eye)

    val patientHistorySortedList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistorySortedListRDD)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Eligible IPP
      val denominatorRDD = getEligibleIpp(ippRDD, patientHistorySortedList)
      denominatorRDD.cache()

      // Filter Exclusions
      /*val denominatorRDD = getSubtractRDD(ippRDD,eligibleRdd)
    denominatorRDD.cache()*/

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryRDD, patientHistoryBroadcastList, patientHistorySortedList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateException.cache()

      val exceptionRDD = getexceptionRDD(intermediateException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not meate
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryBroadcastList.destroy()
      patientHistorySortedList.destroy()
    }

  }

  /*-----------------------------------------------------------------------------------------
    All patients aged 18 years and older with a diagnosis of diabetic retinopathy
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM142V7Elements.Diabetic_Retinopathy, patientHistoryList)
        && isVisitTypeIn(visit, m,
        ECQM142V7Elements.Ophthalmological_Services,
        ECQM142V7Elements.Care_Services_In_Long_Term_Residential_Facility,
        ECQM142V7Elements.Nursing_Facility_Visit,
        ECQM142V7Elements.Office_Visit,
        ECQM142V7Elements.Outpatient_Consultation)
    )
  }

  /*---------------------------------------------------------------------------------------------
    Equals Initial Population who had a dilated macular or fundus exam performed
   ----------------------------------------------------------------------------------------------*/

  def getEligibleIpp(ippRDD: RDD[CassandraRow], patientHistorySortedList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      isDiagnosticStudyOnEncounter(visit, m, ECQM142V7Elements.Macular_Exam)
        // &&    checkEyeElementsInRange(visit,m,ECQM142V7Elements.Diabetic_Retinopathy__Eye,ECQM142V7Elements.Macular_Exam__Eye)
        && checkEyeOnEncounterEqualsWithOtherEye(visit, m, true, ECQM142V7Elements.Diabetic_Retinopathy__Eye, patientHistorySortedList, Seq(ECQM142V7Elements.Macular_Exam__Eye))
    )
  }

  /*--------------------------------------------------------------------------------------------------
   Patients with documentation, at least once within 12 months, of the findings of the dilated macular
   or fundus exam via communication to the physician who manages the patient's diabetic care
  ---------------------------------------------------------------------------------------------------*/

  def getMet(eligibleRdd: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], patientHistorySortedList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    eligibleRdd.filter(visit =>
      (
        (
          isCommunicationAfterOrEqualEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryList, ECQM142V7Elements.Proliferative_Diabetic_Retinopathy)
            || isCommunicationAfterOrEqualEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryList, ECQM142V7Elements.Severe_Non_Proliferative_Diabetic_Retinopathy)
            || isCommunicationAfterOrEqualEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryList, ECQM142V7Elements.Moderate_Diabetic_Retinopathy)
            || isCommunicationAfterOrEqualEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryList, ECQM142V7Elements.Mild_Non_Proliferative_Diabetic_Retinopathy)
            || isCommunicationAfterOrEqualEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryList, ECQM142V7Elements.Very_Severe_Non_Proliferative_Diabetic_Retinopathy)
          ) && isCommunicationAfterOrEqualEncounterWithEye(visit, m, ECQM142V7Elements.Level_Of_Severity_Of_Retinopathy_Findings_Eye, patientHistorySortedList, ECQM142V7Elements.Macular_Exam__Eye)
        )
        &&
        (
          isCommunicationAfterOrEqualEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryList, ECQM142V7Elements.Macular_Edema_Findings_Present)
            || isCommunicationAfterOrEqualEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryList, ECQM142V7Elements.Macular_Edema_Findings_Absent)
          )
        &&
        (
          isCommunicationAfterOrEqualEncounterWithEye(visit, m, ECQM142V7Elements.Macular_Edema_Findings__Eye, patientHistorySortedList, ECQM142V7Elements.Macular_Exam__Eye)
          )
    )
  }

  /*---------------------------------------------------------------------------------------------------------------------------------------------
   Documentation of medical reason(s) for not communicating the findings of the dilated macular or fundus exam to the physician who manages
   the ongoing care of the patient with diabetes.
   Documentation of patient reason(s) for not communicating the findings of the dilated macular or fundus exam to the physician who manages
   the ongoing care of the patient with diabetes.
   --------------------------------------------------------------------------------------------------------------------------------------------*/

  def getexceptionRDD(intermediate: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    var m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediate.filter(visit =>
      isCommunicationFromProvidertoProviderNotdoneAfterOrEqualEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryList, ECQM142V7Elements.Medical_Reason)
        || isCommunicationFromProvidertoProviderNotdoneAfterOrEqualEncounter(visit, m, AdminElements.Encounter_Date, patientHistoryList, ECQM142V7Elements.Patient_Reason)
    )
  }


}