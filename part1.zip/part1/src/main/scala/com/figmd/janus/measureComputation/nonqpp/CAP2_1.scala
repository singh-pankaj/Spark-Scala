package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CAP2_1
* Measure Title              :- Cancer Protocol and Turnaround Time for Carcinoma and Carcinosarcoma of the Endometrium
* Measure Description        :- Percentage of all eligible Carcinoma and Carcinosarcoma of the Endometrium specimens for which all required data elements of the Cancer Protocol are included
*                                AND meet the maximum 4 business day turnaround time (TAT) requirement (Report Date – Accession Date ≤ 4 business days).
* Calculation Implementation :- visit-specific (procedure-specific)
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- NA
* The overall performance score is a weighted average of: (Performance 1 x 70%)+(Performance 2 x 30%)
* Measure Developer          :- Priyanka Sawant
----------------------------------------------------------------------------------------------------------------------------*/
object CAP2_1 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "CAP2_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      CAP2Elements.Surgical_Pathology_Accession_Number
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

   if(checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

     // denominator RDD
     val denominatorRDD = ippRDD
     denominatorRDD.cache()

     // Filter Exclusions
     val exclusionRDD = getExclusionRDD(ippRDD, patientHistoryList)
     exclusionRDD.cache()

     val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
     intermediateA.cache()

     // Filter Met
     val metRDD = getMetRDD(intermediateA, patientHistoryList)
     metRDD.cache()

     // Filter Exceptions
     val intermediateB = getSubtractRDD(intermediateA, metRDD)
     intermediateB.cache()

     val exceptionRDD = getExceptionRDD(intermediateB, patientHistoryList)
     exceptionRDD.cache()

     // Filter not Met
     val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
     notMetRDD.cache()

     saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
   }
  }
  /*-------------------------------------------------------------------------------------------------------------------------
 All final pathology reports for eligible carcinoma of the endometrium cases that require the use of a CAP cancer protocol (includes carcinomas, carcinosarcomas (malignant mixed Müllerian tumor) and neuroendocrine carcinomas arising in the endometrium).
CPT®: 88309 (for abdominal hysterectomy with/without bilateral salpingo-oophorectomy for neoplasia)
AND
Any of the ICD 10 codes:
C54.0: malignant neoplasm of isthmus uteri
C54.1: malignant neoplasm of endometrium
C54.3: malignant neoplasm of fundus uteri
C54.8: malignant neoplasm of overlapping sites of corpus uteri
C54.9: malignant neoplasm of corpus uteri, unspecified
 * ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
      isLaboratoryTestOrder(visit,m,CAP2Elements.Surgical_Pathology_Accession_Number,patientHistoryList)
        &&  wasDiagnosisBeforeorEqualEncounter(visit,m,CAP2Elements.Confirm_Primary_Endometrial_Carcinoma_Resection_Date,CAP2Elements.Surgical_Pathology_Accession_Number,patientHistoryList)
    )

  }
  /*-------------------------------------------------------------------------------------------------------------------------
 a. Biopsy procedures
 * ----------------------------------------------------------------------------------------------------------------------------*/
  def getExclusionRDD(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      isLaboratoryTestConcurrent(visit,m,CAP2Elements.Biopsy_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
        ||  isLaboratoryTestConcurrent(visit,m,CAP2Elements.Biopsy_Procedure_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
    )
  }
  /*-------------------------------------------------------------------------------------------------------------------------
 Rate 1: All eligible cases containing all of the required elements found in the current CAP Carcinoma of the Endometrium protocol. Optional data (marked with a “+” in the CAP cancer protocol) is not required but may be present.
 The current protocol, the required elements include:
 Procedure
 Histologic Type
 Histologic Grade
 Myometrial Invasion
 Uterine Serosa Involvement
 Cervical Stromal Involvement
 Other Tissue/Organ Involvement
 Margins (required only if cervix and/or parametrium/paracervix is involved by carcinoma)
 a.Ectocervical/Vaginal Cuff Margin
 b.Parametrial/Paracervical Margin
 Lymphovascular Invasion
 Regional Lymph Nodes details
 Pathologic Stage Classification (pTNM, AJCC 8th Edition)
 * If an item is not applicable, an “N/A” listing is required.
  * ----------------------------------------------------------------------------------------------------------------------------*/
  def getMetRDD(intermediateA: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      (
        (   isLaboratoryTestConcurrent(visit,m,CAP2Elements.Procedure_Documented_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP2Elements.Histologic_Type_Documented_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP2Elements.Histologic_Grade_Documented_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP2Elements.Myometrial_Invasion_Documented_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP2Elements.Uterine_Serosa_Involvement_Documented_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP2Elements.Cervical_Stromal_Involvement_Documented_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP2Elements.Other_Tissue_Organ_Involvement_Documented_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP2Elements.Margins_Documented_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
          &&  (  isLaboratoryTestConcurrent(visit,m,CAP2Elements.Ectocervical_Vaginal_Cuff_Margin_Documented_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
          || isLaboratoryTestConcurrent(visit,m,CAP2Elements.Parametrial_Paracervical_Margin_Documented_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
          )
          &&  isLaboratoryTestConcurrent(visit,m,CAP2Elements.Lymph_Vascular_Invasion_Documented_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP2Elements.Regional_Lymph_Nodes_Documented_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
          &&  isLaboratoryTestConcurrent(visit,m,CAP2Elements.Pathologic_Stage_Classification_Documented_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
          )
          ||  isLaboratoryTestConcurrent(visit,m,CAP2Elements.Cap_Endometrial_Protocol_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
        )
        &&  !   isLaboratoryTestConcurrent(visit,m,CAP2Elements.Cancer_Protocol_Not_Met_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)

    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  a. Cases requiring intradepartmental or extra-departmental consultation.
  * ----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermediateB: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermediateB.filter(visit=>
      isCommunicationFromProviderToProviderConcurrent(visit,m,CAP2Elements.Confirm_Case_Required_Consultation_Date,CAP2Elements.Surgical_Pathology_Accession_Number_Date)
    )
  }

}

