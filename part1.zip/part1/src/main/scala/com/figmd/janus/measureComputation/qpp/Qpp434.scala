package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{AdminElements, CompareOperator, MeasureProperty, QPP434Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 434
* Measure Title              :- Proportion of Patients Sustaining a Ureter Injury at the Time of any Pelvic Organ  Prolapse Repair
* Measure Description        :- Percentage of patients undergoing pelvic organ prolapse repairs who sustain an injury to
                                the ureter recognized either during or within 30 days after surgery.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp434 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp434"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP434Elements.Pelvic_Organ_Prolapse_Surgery
      , QPP434Elements.Ureter_Injury
      , QPP434Elements.Injury_To_Ureter
      , QPP434Elements.Ureter_Injury_Not_Met
      , QPP434Elements.Ureter_Injury_Medical_Reason
      , QPP434Elements.Injury
      , QPP434Elements.Urinary_Incontinence_Procedure
      , QPP434Elements.Injury_Medical_Reason
      , QPP434Elements.Expired

    ).collect().toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {
      //eligible RDD

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate RDD
      val intermediateException = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
   All patients undergoing anterior or apical pelvic organ prolapse (POP) surgery
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isFemale(visit, m)
        && isProcedurePerformedDuringEncounter(visit, m, QPP434Elements.Pelvic_Organ_Prolapse_Surgery)
        && wasProcedurePerformedBeforeOrEqualEndInMonths(visit, m, QPP434Elements.Pelvic_Organ_Prolapse_Surgery, 1, patientHistoryBroadcastList)
    )
  }

  /*------------------------------------------------------------------------------------------------
   The number of patients receiving a ureter injury with repair at the time of initial surgery or subsequently up to
   30 days postoperatively surgery
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        isProcedurePerformed(visit, m, QPP434Elements.Ureter_Injury, patientHistoryBroadcastList)
          || isProcedurePerformedDuringEncounter(visit, m, QPP434Elements.Injury_To_Ureter)
          || wasProcedurePerformedAfterXMonthsOfProcedure(visit, m, QPP434Elements.Pelvic_Organ_Prolapse_Surgery, QPP434Elements.Injury_To_Ureter, 1, patientHistoryBroadcastList)
        )
        && !isProcedurePerformed(visit, m, QPP434Elements.Ureter_Injury_Not_Met, patientHistoryBroadcastList)
    )

  }

  /*-----------------------------------------------------------------------------------------------------------------
    	Documented medical reasons for not reporting ureter injury (e.g. gynecologic or other pelvic malignancy documented,
    	concurrent surgery involving bladder pathology, injury that occurs during a urinary incontinence procedure, patient
    	death from non medical causes not related to surgery, patient died during procedure without evidence of ureter injury)
   -----------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermediateException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateException.filter(visit =>
      isProcedurePerformedDuringEncounter(visit, m, QPP434Elements.Ureter_Injury_Medical_Reason)
        || wasProcedurePerformedAfterXMonthsOfProcedure(visit, m, QPP434Elements.Pelvic_Organ_Prolapse_Surgery, QPP434Elements.Ureter_Injury_Medical_Reason, 1, patientHistoryBroadcastList)
        || isProcedurePerformedDuringEncounter(visit, m, QPP434Elements.Surgery_Involving_Bladder_Pathology)
        ||
        (
          wasDiagnosisEqualWithProcedureInHistory(visit, m, QPP434Elements.Injury, QPP434Elements.Urinary_Incontinence_Procedure, CompareOperator.EQUAL, patientHistoryBroadcastList)
            && wasProcedurePerformedAfterXMonthsOfProcedure(visit, m, QPP434Elements.Pelvic_Organ_Prolapse_Surgery, QPP434Elements.Urinary_Incontinence_Procedure, 1, patientHistoryBroadcastList)
          )
        || isDiagnosedOnEncounter(visit, m, QPP434Elements.Injury_Medical_Reason)
        || wasDiagnosedAfterXMonthsOfProcedure(visit, m, QPP434Elements.Pelvic_Organ_Prolapse_Surgery, QPP434Elements.Injury_Medical_Reason, 1, patientHistoryBroadcastList)
        || isPatientCharacteristicOnEncounter(visit, m, QPP434Elements.Expired, QPP434Elements.Pelvic_Organ_Prolapse_Surgery)
        || wasPatientCharacteristicAfterXMonthsOfProcedure(visit, m, QPP434Elements.Pelvic_Organ_Prolapse_Surgery, QPP434Elements.Expired, 1, patientHistoryBroadcastList)
    )

  }

}
