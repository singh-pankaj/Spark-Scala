package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{Elements, MeasureProperty, QPP130Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 130
* Measure Title              :- Documentation of Current Medications in the Medical Record
* Measure Description        :- Percentage of visits for patients aged 18 years and older for which the eligible professional or eligible clinician attests to documenting a list of current medications
*                               using all immediate resources available on the date of the encounter. This list must include ALL known prescriptions, over-the-counters, herbals,
*                               and vitamin/mineral/dietary (nutritional) supplements AND must contain the medications’ name, dosage, frequency and route of administration.
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp130 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp130"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD)
      metRDD.cache()


      val intermediateB = getSubtractRDD(ippRDD, metRDD)
      intermediateB.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateB)
      exceptionRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }
  }


  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit => isPatientAdult(visit, m)
      && isVisitTypeIn(visit, m,
      QPP130Elements.Medications_Encounter_Codes,
      QPP130Elements.Therapeutic_Interventions,
      QPP130Elements.Physical_Therapy_Evaluation_Cpt,
      QPP130Elements.Re_Evaluation_Of_Physical_Therapy_Cpt,
      QPP130Elements.Occupational_Therapy_Cpt,
      QPP130Elements.Occupational_Therapy_Re_Evalution_Cpt)
    )

  }


  def getMet(ipp: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ipp.filter(visit =>

      (
        isProcedurePerformedDuringEncounter(visit, m, QPP130Elements.Current_Medications_Documented)
          || isProcedurePerformedDuringEncounter(visit, m, QPP130Elements.Current_Medications)
          || isProcedurePerformedDuringEncounter(visit, m, QPP130Elements.Current_Medications_Documented_Snmd)
        )
        &&
        !isProcedurePerformedDuringEncounter(visit, m, QPP130Elements.Current_Medications_Documented_Reason_Not_Specified)
    )
  }


  def getException(intermediateRdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateRdd.filter(visit =>

      isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP130Elements.Current_Medications_Documented_Patient_Not_Eligible)
        || isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP130Elements.Medical_Situation)
        || isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP130Elements.Medical_Or_Other_Reason_Not_Done)

    )
  }
}






