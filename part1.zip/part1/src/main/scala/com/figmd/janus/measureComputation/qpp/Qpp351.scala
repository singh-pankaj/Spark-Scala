package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP351Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 351
* Measure Title              :- Total Knee Replacement: Shared Decision-Making: Trial of Conservative (Nonsurgical) Therapy
* Measure Description        :- Percentage of patients regardless of age undergoing a total knee replacement with documented shared decisionmaking with discussion of conservative (non-surgical) therapy (e.g., non-steroidal anti-inflammatory drug (NSAIDs), analgesics, weight loss, exercise, injections) prior to the procedure
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp351 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp351"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP351Elements.Total_Knee_Replacement,
      QPP351Elements.Stroke,
      QPP351Elements.Myocardial_Infarction,
      QPP351Elements.Arrhythmia,
      QPP351Elements.Pulmonary_Embolism,
      QPP351Elements.Deep_Venous_Thrombosis
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
          metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()
      //
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isProcedurePerformedDuringEncounter(visit, m, QPP351Elements.Total_Knee_Replacement)
    )
  }


  // Numerator criteria
  def getMet(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      (
        isInterventionPerformedOnEncounter(visit, m, QPP351Elements.Evaluation_Of_Risk_Factors)
          && (
          wasDiagnosedBeforeProcedureInXDays(visit, m, QPP351Elements.Total_Knee_Replacement, QPP351Elements.Stroke, 30, patientHistoryBroadcastList)
            || wasDiagnosedBeforeProcedureInXDays(visit, m, QPP351Elements.Total_Knee_Replacement, QPP351Elements.Myocardial_Infarction, 30, patientHistoryBroadcastList)
            || wasDiagnosedBeforeProcedureInXDays(visit, m, QPP351Elements.Total_Knee_Replacement, QPP351Elements.Arrhythmia, 30, patientHistoryBroadcastList)
            || wasDiagnosedBeforeProcedureInXDays(visit, m, QPP351Elements.Total_Knee_Replacement, QPP351Elements.Pulmonary_Embolism, 30, patientHistoryBroadcastList)
            || wasDiagnosedBeforeProcedureInXDays(visit, m, QPP351Elements.Total_Knee_Replacement, QPP351Elements.Deep_Venous_Thrombosis, 30, patientHistoryBroadcastList)
            || wasInterventionPerformedBeforeProcedureInXDays(visit, m, QPP351Elements.Total_Knee_Replacement, QPP351Elements.Evaluation_Of_Risk_Factors, 30, patientHistoryBroadcastList)
          )
        )
        && !isInterventionPerformed(visit, m, QPP351Elements.Evaluation_Of_Risk_Reason_Not_Specified, patientHistoryBroadcastList)
    )
  }


}
