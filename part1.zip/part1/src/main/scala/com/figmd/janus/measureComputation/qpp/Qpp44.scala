package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP44Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 44
* Measure Title              :- Coronary Artery Bypass Graft (CABG): Preoperative Beta-Blocker in Patients with Isolated CABG Surgery
* Measure Description        :- Percentage of isolated Coronary Artery Bypass Graft (CABG) surgeries for patients aged 18 years and older who received a beta-blocker within 24 hours prior to surgical incision
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp44 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp44"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP

    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //getPatientHistoryList
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        QPP44Elements.Beta_Blocker_Therapy,
        QPP44Elements.Medical_Reason
      ).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
       metRDD.cache()
      val intermediateA = getSubtractRDD(denominatorRDD, metRDD)

      // Filter Exceptions
      val exceptionRDD = getException(intermediateA, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isPatientAdult(visit, m)
        &&
        isProcedurePerformedDuringEncounter(visit, m, QPP44Elements.Isolated_Cabg_Surgery)
        &&
        (
          isProcedurePerformedDuringEncounter(visit, m, QPP44Elements.Coronary_Artery_Bypass_Graft)
            && isMedicationOrderedOnEncounter(visit, m, QPP44Elements.Anesthesia_For_Heart)
          )
    )
  }


  // Numerator criteria
  def getMet(ipp: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    ipp.filter(visit =>
      (
        isMedicationAdministeredOnEncounter(visit, m, QPP44Elements.Beta__Blocker_Therapy_Met)
          || isMedicationAdministeredBeforeProcedureInXHours(visit, m, AdminElements.Encounter_Date, QPP44Elements.Beta_Blocker_Therapy, 24, patientHistoryList)
        )
        && !isMedicationAdministeredOnEncounter(visit, m, QPP44Elements.Beta_Blocker_Therapy_Reason_Not_Specified)
    )
  }


  // Numerator criteria
  def getException(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>

      isMedicationAdministeredOnEncounter(visit, m, QPP44Elements.Beta_Blocker_Therapy_Reason_Not_Specified)
        || isMedicationAdministeredBeforeProcedureInXHours(visit, m, AdminElements.Encounter_Date, QPP44Elements.Medical_Reason, 24, patientHistoryList)
    )
  }

}
