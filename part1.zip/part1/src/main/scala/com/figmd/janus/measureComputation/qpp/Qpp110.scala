package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP110Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.qpp.Qpp110.wasDuringInfluenzaPeriodLastFiveMonthInHistory

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 110
* Measure Title              :- Preventive Care and Screening: Influenza Immunization
* Measure Description        :- Percentage of patients aged 6 months and older seen for a visit between
                                October 1 and March 31 who received an influenza immunization OR who reported previous receipt of an influenza immunization
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp110 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp110"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      var patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        QPP110Elements.Influenza_Immunization,
        QPP110Elements.Influenza_Vaccine,
        QPP110Elements.Influenza_Vaccination,
        QPP110Elements.Influenza_Immunization_Reason_Not_Specified,
        QPP110Elements.Influenza_Vaccination_Declined,
        QPP110Elements.Medical_Reason,
        QPP110Elements.System_Reason,
        QPP110Elements.Patient_Reason,
        QPP110Elements.Influenza_Immunization_Exception,
        QPP110Elements.Allergy_To_Eggs,
        QPP110Elements.Allergy_To_Influenza_Vaccine,
        QPP110Elements.Intolerance_To_Influenza_Vaccine,
        QPP110Elements.Intolerance_Influenza_Vaccine,
        QPP110Elements.Allergy_Influenza_Vaccine,
        QPP110Elements.Egg_Substance)

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

      // Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateB = getSubtractRDD(ippRDD, metRDD)
      intermediateB.cache()

      /*var getPatientHistoryList = getPatientHistory(sparkSession,rdd, QPP110Elements.Allergy_To_Eggs).collect.toList;
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)*/

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateB, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : All patients aged 6 months and older seen for a visit during the measurement period
Patients aged ≥ 6 months seen for a visit between October 1 and March 31
----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>

      isAgeAboveInMonth(visit, m,true,6)
      &&
        isVisitTypeIn(visit, m, QPP110Elements.Face_To_Face_Interaction,
          QPP110Elements.Peritoneal_Dialysis_110,
          QPP110Elements.Annual_Wellness_Visit,
          QPP110Elements.Discharge_Services___Nursing_Facility,
          QPP110Elements.Nursing_Facility_Visit,
          QPP110Elements.Preventive_Care__Established_Office_Visit__0_To_17,
          QPP110Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
          QPP110Elements.Hemodialysis_110,
          QPP110Elements.Office_Visit,
          QPP110Elements.Patient_Provider_Interaction,
          QPP110Elements.Home_Healthcare_Services,
          QPP110Elements.Care_Services_In_Long_Term_Residential_Facility,
          QPP110Elements.Outpatient_Consultation,
          QPP110Elements.Preventive_Care_Services___Group_Counseling,
          QPP110Elements.Preventive_Care_Services___Other,
          QPP110Elements.Preventive_Care_Services_Individual_Counseling,
          QPP110Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
          QPP110Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
        )
      && !isTeleHealthEncounterNotPerformed(visit, m, QPP110Elements.Annual_Wellness_Visit_Telehealth_Modifier,
          QPP110Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier,
          QPP110Elements.Discharge_Services___Nursing_Facility_Telehealth_Modifier,
          QPP110Elements.Hemodialysis_Telehealth_Modifier,
          QPP110Elements.Home_Healthcare_Services_Telehealth_Modifier,
          QPP110Elements.Nursing_Facility_Visit_Telehealth_Modifier,
          QPP110Elements.Outpatient_Consultation_Telehealth_Modifier,
          QPP110Elements.Office_Visit_Telehealth_Modifier,
          QPP110Elements.Preventive_Care___Established_Office_Visit_0_To_17_Telehealth_Modifier,
          QPP110Elements.Preventive_Care__Initial_Office_Visit_0_To_17_Telehealth_Modifier,
          QPP110Elements.Preventive_Care_Services_Initial_Office_Visit_18_And_Up_Telehealth_Modifier,
          QPP110Elements.Preventive_Care_Services___Established_Office_Visit_18_And_Up_Telehealth_Modifier,
          QPP110Elements.Preventive_Care_Services___Group_Counseling_Telehealth_Modifier,
          QPP110Elements.Preventive_Care_Services_Individual_Counseling_Telehealth_Modifier,
          QPP110Elements.Preventive_Care_Services___Other_Telehealth_Modifier,
          QPP110Elements.Peritoneal_Dialysis_Telehealth_Modifier
          )
      && isPOSEncounterNotPerformed(visit, m, QPP110Elements.Pos_02)
      &&
        (// Influenza period date criteria
           isDuringInfluenzaPeriodFirstThreeMonth(visit, m, AdminElements.Encounter_Date)
          || isDuringInfluenzaPeriodLastThreeMonth(visit, m, AdminElements.Encounter_Date)
          )
    )

  }

  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Patients who received an influenza immunization OR who reported previous receipt of an influenza immunization
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(ipp: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    ipp.filter(visit =>

      ( isInfluenzaImmunizationAdministered(visit, m, QPP110Elements.Influenza_Immunization)
        && (
        (
          (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, QPP110Elements.Influenza_Immunization_Date)
            || wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, QPP110Elements.Influenza_Immunization,patientHistoryBroadcastList )
            )
            && isDuringInfluenzaPeriodFirstThreeMonth(visit, m, AdminElements.Encounter_Date)
          )
          ||
          (
            isDuringInfluenzaPeriodLastFiveMonth(visit, m, QPP110Elements.Influenza_Immunization_Date)
              && isDuringInfluenzaPeriodLastThreeMonth(visit, m, AdminElements.Encounter_Date)
            )
          )
        )
    ||
       ( isInfluenzaVaccineAdministered(visit, m, QPP110Elements.Influenza_Vaccine)
          && (
          (
            (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, QPP110Elements.Influenza_Vaccine_Date)
              || wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, QPP110Elements.Influenza_Vaccine,patientHistoryBroadcastList)
              )
              && isDuringInfluenzaPeriodFirstThreeMonth(visit, m, AdminElements.Encounter_Date)
            )
            ||
            (
              isDuringInfluenzaPeriodLastFiveMonth(visit, m, QPP110Elements.Influenza_Vaccine_Date)
                && isDuringInfluenzaPeriodLastThreeMonth(visit, m, AdminElements.Encounter_Date)
              )
           )
       )
    ||
       ( isInfluenzaVaccinationProcedure(visit, m, QPP110Elements.Influenza_Vaccination)
          && (
          (
            (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, QPP110Elements.Influenza_Vaccination_Date)
              || wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, QPP110Elements.Influenza_Vaccination,patientHistoryBroadcastList)
              )
              && isDuringInfluenzaPeriodFirstThreeMonth(visit, m, AdminElements.Encounter_Date)
            )
            ||
            (
              isDuringInfluenzaPeriodLastFiveMonth(visit, m, QPP110Elements.Influenza_Vaccination_Date)
                && isDuringInfluenzaPeriodLastThreeMonth(visit, m, AdminElements.Encounter_Date)
              )
          )
       )
    ||
       ( isCommunicationFromPatientToProviderPreviousReceiptOfInfluenzaVaccine(visit, m, QPP110Elements.Previous_Receipt_Of_Influenza_Vaccine)
          && (
          (
            isDuringInfluenzaPeriodFirstThreeMonth(visit, m, QPP110Elements.Previous_Receipt_Of_Influenza_Vaccine_Date)
              && isDuringInfluenzaPeriodFirstThreeMonth(visit, m, AdminElements.Encounter_Date)
            )
            ||
            (
              isDuringInfluenzaPeriodLastFiveMonth(visit, m, QPP110Elements.Previous_Receipt_Of_Influenza_Vaccine_Date)
                && isDuringInfluenzaPeriodLastThreeMonth(visit, m, AdminElements.Encounter_Date)
              )
          )
       )
    ||
       ( isCommunicationFromPatientToProviderPreviousReceiptOfInfluenzaVaccination(visit, m, QPP110Elements.Previous_Receipt_Of_Influenza_Vaccination)
          && (
          (
            isDuringInfluenzaPeriodFirstThreeMonth(visit, m, QPP110Elements.Previous_Receipt_Of_Influenza_Vaccination_Date)
              && isDuringInfluenzaPeriodFirstThreeMonth(visit, m, AdminElements.Encounter_Date)
            )
            ||
            (
              isDuringInfluenzaPeriodLastFiveMonth(visit, m, QPP110Elements.Previous_Receipt_Of_Influenza_Vaccination_Date)
                && isDuringInfluenzaPeriodLastThreeMonth(visit, m, AdminElements.Encounter_Date)
              )
          )
       )
    && ! ( isInfluenzaImmunizationAdministered(visit, m, QPP110Elements.Influenza_Immunization_Reason_Not_Specified)
         && (
         (
           (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, QPP110Elements.Influenza_Immunization_Reason_Not_Specified_Date)
             || wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, QPP110Elements.Influenza_Immunization_Reason_Not_Specified,patientHistoryBroadcastList)
             )
             && isDuringInfluenzaPeriodFirstThreeMonth(visit, m, AdminElements.Encounter_Date)
           )
           ||
           (
             isDuringInfluenzaPeriodLastFiveMonth(visit, m, QPP110Elements.Influenza_Immunization_Reason_Not_Specified_Date)
               && isDuringInfluenzaPeriodLastThreeMonth(visit, m, AdminElements.Encounter_Date)
             )
          )
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Denominator Exceptions : Influenza immunization was not administered for reasons documented by clinician
(e.g., patient allergy or other medical reasons, patient declined or other patient reasons, vaccine not available or other system reasons)
----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermedaiateRdd: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermedaiateRdd.filter(visit =>
      ( isCommunicationFromPatientToProviderInfluenzaVaccinationDeclined(visit, m, QPP110Elements.Influenza_Vaccination_Declined)
        && (
          (
          (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, QPP110Elements.Influenza_Vaccination_Declined_Date)
            || wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, QPP110Elements.Influenza_Vaccination_Declined,patientHistoryBroadcastList)
            )
            && isDuringInfluenzaPeriodFirstThreeMonth(visit, m, AdminElements.Encounter_Date)
          )
          ||
          (
            isDuringInfluenzaPeriodLastFiveMonth(visit, m, QPP110Elements.Influenza_Vaccination_Declined_Date)
              && isDuringInfluenzaPeriodLastThreeMonth(visit, m, AdminElements.Encounter_Date)
            )
        )
      )
    || ( isActionNotPerformedWithReasonForInfluenza(visit, m, QPP110Elements.Medical_Reason)
        && (
        (
          (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, QPP110Elements.Medical_Reason_Date)
            || wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, QPP110Elements.Medical_Reason,patientHistoryBroadcastList)
            )
            && isDuringInfluenzaPeriodFirstThreeMonth(visit, m, AdminElements.Encounter_Date)
          )
          ||
          (
            isDuringInfluenzaPeriodLastFiveMonth(visit, m, QPP110Elements.Medical_Reason_Date)
              && isDuringInfluenzaPeriodLastThreeMonth(visit, m, AdminElements.Encounter_Date)
            )
          )
        )
    || ( isActionNotPerformedWithReasonForInfluenza(visit, m, QPP110Elements.Patient_Reason)
        && (
        (
          (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, QPP110Elements.Patient_Reason_Date)
            || wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, QPP110Elements.Patient_Reason,patientHistoryBroadcastList)
            )
            && isDuringInfluenzaPeriodFirstThreeMonth(visit, m, AdminElements.Encounter_Date)
          )
          ||
          (
            isDuringInfluenzaPeriodLastFiveMonth(visit, m, QPP110Elements.Patient_Reason_Date)
              && isDuringInfluenzaPeriodLastThreeMonth(visit, m, AdminElements.Encounter_Date)
            )
          )
        )
    || ( isActionNotPerformedWithReasonForInfluenza(visit, m, QPP110Elements.System_Reason)
        && (
        (
          (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, QPP110Elements.System_Reason_Date)
            || wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, QPP110Elements.System_Reason,patientHistoryBroadcastList)
            )
            && isDuringInfluenzaPeriodFirstThreeMonth(visit, m, AdminElements.Encounter_Date)
          )
          ||
          (
            isDuringInfluenzaPeriodLastFiveMonth(visit, m, QPP110Elements.System_Reason_Date)
              && isDuringInfluenzaPeriodLastThreeMonth(visit, m, AdminElements.Encounter_Date)
            )
         )
        )
    || ( isActionNotPerformedWithReasonForInfluenza(visit, m, QPP110Elements.Influenza_Immunization_Exception)
        && (
        (
          (isDuringInfluenzaPeriodFirstThreeMonth(visit, m, QPP110Elements.Influenza_Immunization_Exception_Date)
            || wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit, m, QPP110Elements.Influenza_Immunization_Exception,patientHistoryBroadcastList)
            )
            && isDuringInfluenzaPeriodFirstThreeMonth(visit, m, AdminElements.Encounter_Date)
          )
          ||
          (
            isDuringInfluenzaPeriodLastFiveMonth(visit, m, QPP110Elements.Influenza_Immunization_Exception_Date)
              && isDuringInfluenzaPeriodLastThreeMonth(visit, m, AdminElements.Encounter_Date)
            )
          )
        )
    || isAllergyToInfluenza(visit, m, QPP110Elements.Allergy_To_Eggs, patientHistoryBroadcastList)
    || isAllergyToInfluenza(visit, m, QPP110Elements.Allergy_To_Influenza_Vaccine, patientHistoryBroadcastList)
    || isIntoleranceToInfluenza(visit, m, QPP110Elements.Intolerance_To_Influenza_Vaccine, patientHistoryBroadcastList)
    || isIntoleranceToInfluenza(visit, m, QPP110Elements.Intolerance_Influenza_Vaccine, patientHistoryBroadcastList)
    || isAllergyToInfluenza(visit, m, QPP110Elements.Allergy_Influenza_Vaccine, patientHistoryBroadcastList)
    || isAllergyToInfluenza(visit, m, QPP110Elements.Egg_Substance, patientHistoryBroadcastList)

    )
  }
}






