package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, _}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 393
* Measure Title              :- HRS-9: Infection within 180 Days of Cardiac Implantable Electronic Device (CIED) Implantation, Replacement, or Revision
* Measure Description        :- Infection rate following CIED device implantation, replacement, or revision
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 2
* Measure Stratification     :- 2
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp393_2 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp393_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP393Elements.Cied_Procedures,
      QPP393Elements.Cied_Implantation_Replacement_Revision,
      QPP393Elements.New_Cied,
      QPP393Elements.Heart_Transplantation,
      QPP393Elements.Hospital_Admission,
      QPP393Elements.Postoperative_Infection,
      QPP393Elements.Removal_Revision_Of_Cied,
      QPP393Elements.Cied_Removal_Or_Revision,
      QPP393Elements.Replaced_Or_Revised_Cied,
      QPP393Elements.Patient__With_Infections__Admitted_Criteria_2,
      QPP393Elements.Patients__With_Infections__Admitted_Criteria_2_Not_Met
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //eligible RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //  Denominator 2: All patients with replacement or revision of a CIED from January 1, 2018 through June 30, 2018 of the performance period
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      (
        isProcedurePerformedWithinXMonths(visit, m, QPP393Elements.Cied_Procedures, 6, patientHistoryBroadcastList)
          || isProcedurePerformedWithinXMonths(visit, m, QPP393Elements.Cied_Implantation_Replacement_Revision, 6, patientHistoryBroadcastList)
        )
        &&
        (
          wasProcedureDuringProcedureInHistory(visit, m, QPP393Elements.New_Cied, QPP393Elements.Cied_Procedures, "EQUAL", patientHistoryBroadcastList)
            || wasProcedureDuringProcedureInHistory(visit, m, QPP393Elements.New_Cied, QPP393Elements.Cied_Implantation_Replacement_Revision, "EQUAL", patientHistoryBroadcastList)

          )
    )
  }

  //Procedure code for heart transplantation
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      wasProcedurePerformedInHistory(visit, m, QPP393Elements.Heart_Transplantation, patientHistoryBroadcastList)
    )
  }

  //Numerator 2: The number of patients from the denominator admitted with an infection requiring device removal or surgical revision within 180 days following CIED implantation, replacement, or revision.
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        isInterventionPerformed(visit, m, QPP393Elements.Patient__With_Infections__Admitted_Criteria_2, patientHistoryBroadcastList)
          ||
          (
            (
              wasEncounterStartsAfterEncounterInXDays(visit, m, QPP393Elements.Cied_Procedures, QPP393Elements.Hospital_Admission, 180, patientHistoryBroadcastList)
                || wasEncounterStartsAfterEncounterInXDays(visit, m, QPP393Elements.Cied_Implantation_Replacement_Revision, QPP393Elements.Hospital_Admission, 180, patientHistoryBroadcastList)

              )
              &&
              (
                wasDiagnosisDoneAfterProcedureWithinXDays(visit, m, QPP393Elements.Cied_Procedures, QPP393Elements.Cied_Procedures_Date, 180, patientHistoryBroadcastList, QPP393Elements.Postoperative_Infection)
                  || wasDiagnosisDoneAfterProcedureWithinXDays(visit, m, QPP393Elements.Cied_Implantation_Replacement_Revision, QPP393Elements.Cied_Implantation_Replacement_Revision_Date, 180, patientHistoryBroadcastList, QPP393Elements.Postoperative_Infection)

                )
              &&
              (
                wasProcedurePerformedXDaysAfterProcedure(visit, m, QPP393Elements.Cied_Procedures, QPP393Elements.Replaced_Or_Revised_Cied, 180, patientHistoryBroadcastList)
                  || wasProcedurePerformedXDaysAfterProcedure(visit, m, QPP393Elements.Cied_Implantation_Replacement_Revision, QPP393Elements.Replaced_Or_Revised_Cied, 180, patientHistoryBroadcastList)

                )
            )
          || isProcedurePerformed(visit, m, QPP393Elements.Cied_Removal_Or_Revision, patientHistoryBroadcastList)
        )
        && !isInterventionNotDone(visit, m, QPP393Elements.Patients__With_Infections__Admitted_Criteria_2_Not_Met, patientHistoryBroadcastList)

    )
  }

}
