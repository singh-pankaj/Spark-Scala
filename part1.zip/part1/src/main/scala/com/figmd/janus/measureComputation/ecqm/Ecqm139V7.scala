package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, ECQM139V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm139
* Measure Title              :- Falls: Screening for Future Fall Risk
* Measure Description        :- Percentage of patients 65 years of age and older who were screened for future fall risk during the measurement period
* Calculation Implementation :- Patient Specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm139V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm139V7"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {
      val patientHistoryList = getPatientHistory(sparkSession, ippRDD
        ,ECQM139V7Elements.Encounter_Inpatient
        ,ECQM139V7Elements.Discharged_To_Home_For_Hospice_Care
        ,ECQM139V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care
        ,ECQM139V7Elements.Hospice_Care_Ambulatory
        ,ECQM139V7Elements.Patient_Not_Ambulatory
        ,ECQM139V7Elements.Ambulatory_Status
        ,ECQM139V7Elements.Falls_Screening).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

      //Denominator
      val denominatorRDD=ippRDD
      denominatorRDD.cache()

      //NotEligiable
      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermidiateNumerator = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermidiateNumerator.cache()
      //met
      val metRDD = getMet(intermidiateNumerator,patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermidiateNumerator, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  // Filter IPP
  /* Patients aged 65 years and older with a visit during the measurement period */

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit => isAgeAboveBeforeStart(visit,m,true,65,CalenderUnit.YEAR)
      && isVisitTypeIn(visit,m
      ,ECQM139V7Elements.Office_Visit
      ,ECQM139V7Elements.Preventive_Care_Services_Individual_Counseling
      ,ECQM139V7Elements.Nursing_Facility_Visit
      ,ECQM139V7Elements.Care_Services_In_Long_Term_Residential_Facility
      ,ECQM139V7Elements.Home_Healthcare_Services
      ,ECQM139V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
      ,ECQM139V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
      ,ECQM139V7Elements.Annual_Wellness_Visit
      ,ECQM139V7Elements.Audiology_Visit
      ,ECQM139V7Elements.Ophthalmological_Services
      ,ECQM139V7Elements.Discharge_Services___Nursing_Facility)
    )
  }

  // Filter Exclusion
  /* Exclude patients who were in hospice care during the measurement year. Exclude patients who were non-ambulatory at some point in the measurement period. */

  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      isEncounterPerformedWithDischargeStatus(visit, m, ECQM139V7Elements.Encounter_Inpatient, ECQM139V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryBroadcastList)
        || isEncounterPerformedWithDischargeStatus(visit, m, ECQM139V7Elements.Encounter_Inpatient, ECQM139V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryBroadcastList)
        || isInterventionOrdered(visit, m, ECQM139V7Elements.Hospice_Care_Ambulatory,patientHistoryBroadcastList)
        //Commented below code as same element is checked twice
        //|| interventionPerformed(visit, m, ECQM139V7Elements.Hospice_Care_Ambulatory))
        || isAssessmentPerformed(visit, m, ECQM139V7Elements.Patient_Not_Ambulatory,patientHistoryBroadcastList)
        || (    wasAssessmentPerformedBeforeMeasurementPeriod(visit, m, patientHistoryBroadcastList, ECQM139V7Elements.Patient_Not_Ambulatory)
            && !isAssessmentPerformed(visit, m, ECQM139V7Elements.Ambulatory_Status,patientHistoryBroadcastList)
           )
    )
  }

  /* Patients who were screened for future fall risk at least once within the measurement period */
  def getMet(intermidiateNumerator: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermidiateNumerator.filter(visit =>
      isAssessmentPerformed(visit, m, ECQM139V7Elements.Falls_Screening,patientHistoryBroadcastList))

  }

}


