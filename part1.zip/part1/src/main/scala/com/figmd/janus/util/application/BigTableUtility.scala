package com.figmd.janus.util.application

import com.datastax.spark.connector.{CassandraRow, ColumnName}
import org.apache.spark.sql.execution.datasources.hbase.{HBaseRelation, HBaseTableCatalog}
import org.apache.spark.sql.{DataFrame, Row, SQLContext}
import com.figmd.janus.WebDataMartCreator.{prop, tableCatalogMap}
import org.apache.spark.sql.{DataFrame, SQLContext}
import org.apache.spark.sql.execution.datasources.hbase.HBaseTableCatalog
import com.datastax.spark.connector.CassandraRow
import org.apache.hadoop.conf.Configuration
import org.apache.spark.rdd.RDD

object BigTableUtility {

  def createAndSave(tableName: String, columnFamily: String, rowKeyColName: String, inputDataframe: DataFrame): Unit = {
    println("Inside create and save big table")
//    inputDataframe.printSchema()

    val dfColumns = inputDataframe.dtypes
    val cat = getCatalog(tableName)
    createAndSave(inputDataframe, cat)
  }

  def createAndSave(inputDataframe: DataFrame, cat: String): Unit = {
    inputDataframe.write.options(
      Map(HBaseTableCatalog.tableCatalog -> cat, HBaseTableCatalog.newTable -> "5", HBaseRelation.MAX_VERSIONS -> "1"))
      .format("org.apache.spark.sql.execution.datasources.hbase")
      .save()
  }

  def read(sqlContext: SQLContext, tableName: String): DataFrame = {
    val catalog = getCatalog(tableName)
    val df = sqlContext
      .read
      .options(Map(HBaseTableCatalog.tableCatalog->catalog))
      .format("org.apache.spark.sql.execution.datasources.hbase")
      .load()

    return df
  }


  def buildCatalog(tableName: String, rowKey: String, columnFamily: String, dfColumns: Array[(String, String)]): String = {
    val catPrefix =
      s"""{
         |"table":{"namespace":"default", "name":\"$tableName\", "tableCoder":"PrimitiveType"},
         |"rowkey":\"$rowKey\",
         |"columns":{"""

    val catPostfix =
      s"""
         |}
         |}"""

    // Build catalog columns description
    var colsCompleteCat = ""
    for (colInfo <- dfColumns) {
      val colName = colInfo._1
      val colType = getBigTableType(colInfo._2)
      var colCat: String = ""
      var cfName = getCFName(rowKey, colName, columnFamily)
      if (colsCompleteCat.equals("")) {
        colCat = s"""\n\"$colName\":{"cf":\"$cfName\", "col":\"$colName\", "type":\"$colType\"}"""
      }
      else {
        colCat = s""",\n\"$colName\":{"cf":\"$cfName\", "col":\"$colName\", "type":\"$colType\"}"""
      }
      colsCompleteCat = colsCompleteCat.concat(colCat)
    }
    return catPrefix.concat(colsCompleteCat).concat(catPostfix).stripMargin
  }

  //TODO: Add support of other data types
  def getBigTableType(dfColType: String): String = {
    var bigTableColType = dfColType
    bigTableColType = dfColType match {
      case "StringType" => "string"
      case "IntegerType" => "int"
      case "FloatType" => "float"
      case "LongType" => "long"
      case "DoubleType" => "double"
      case "BooleanType" => "boolean"
      case "DateType" => "date"
      case "TimestampType" => "timestamp"
      case "NullType" => null
      case null => null
      case _ => throw new UnsupportedOperationException(s"PrimitiveType coder: unsupported data type $dfColType")
    }
    return bigTableColType
  }

  def getCFName(rowKey: String, colName: String, columnFamily: String) : String = {
    if(rowKey == colName)
      return "rowkey"
    else
      return columnFamily
  }



  //TODO: Add below function
  //def chkDateEqual(r: CassandraRow,firstDate:String, compareDate:ListBuffer[String]): Boolean = {


  //TODO: Add below function
  //  def fetchPatientFromAllMeasureOutPut(spark:SparkSession): List[String] ={

  /**
    * This method returns Dataframe of Spark Row for given big table
    * @param sqlContext
    * @param tableName
    * @return
    */
  def getBigTableDF(sqlContext: SQLContext, tableName: String): DataFrame = {
    return read(sqlContext, tableName)
  }

  def getBigTableDF(sqlContext: SQLContext, tableName: String, columns: Seq[String], whereCql: String, whereValues: Any*): DataFrame = {
    val inputDF = read(sqlContext, tableName)
    val whereClause = whereCql.format(whereValues: _*)
    var filteredDF: DataFrame = null
    if(whereClause.length != 0) {
      filteredDF = inputDF.where(whereCql.format(whereValues: _*))
    } else {
      filteredDF = inputDF
    }
    val selColsDF = filteredDF.select(columns.head, columns.tail:_*)

    return selColsDF
  }

  /**
    * This method returns RDD of cassandra Rows from Big table based on input catalog
    * @param sqlContext
    * @param tableName
    * @return
    */
  def getCassandraRowsRDD(sqlContext: SQLContext, tableName: String): RDD[CassandraRow] = {
    val inputDF = read(sqlContext, tableName)
    return toCassandraRowRDD(inputDF)
  }

  /**
    * This method returns RDD of cassandra rows of given columns and where condition from Big table
    * @param sqlContext
    * @param tableName
    * @param columns
    * @param whereCql
    *         Use %s in whereCql for Parameter substituions
    *         If no need to filter data then whereCql can be empty string ("") and in that case it will be ignored.
    * @param whereValues
    *         These are optional values to be replaced in whereCql
    * @return
    */
  def getCassandraRowsRDD(sqlContext: SQLContext, tableName: String, columns: Seq[String], whereCql: String, whereValues: Any*): RDD[CassandraRow] = {
    val inputDF = read(sqlContext, tableName)
    val selColsDF = inputDF.select(columns.head, columns.tail:_*)
    val whereClause = whereCql.format(whereValues: _*)
    //println("Where clause: " + whereClause)  //TODO: Remove
    var filteredDF: DataFrame = null
    if(whereClause.length != 0) {
      filteredDF = selColsDF.where(whereCql.format(whereValues: _*))
    } else {
      filteredDF = selColsDF
    }

    return toCassandraRowRDD(filteredDF)
  }

  def getCassandraRowsDF(sqlContext: SQLContext, tableName: String, columns: Seq[String], whereCql: String, whereValues: Any*): DataFrame = {
    val inputDF = read(sqlContext, tableName)
    val selColsDF = inputDF.select(columns.head, columns.tail:_*)
    val whereClause = whereCql.format(whereValues: _*)
    //println("Where clause: " + whereClause)  //TODO: Remove
    var filteredDF: DataFrame = null
    if(whereClause.length != 0) {
      filteredDF = selColsDF.where(whereCql.format(whereValues: _*))
    } else {
      filteredDF = selColsDF
    }

    filteredDF
  }

  def getCassandraRowsRDD(sqlContext: SQLContext, tableName: String, columns: Seq[String]): RDD[CassandraRow] = {
    val inputDF = read(sqlContext, tableName)
    val selColsDF = inputDF.select(columns.head, columns.tail:_*)
    return toCassandraRowRDD(selColsDF)
  }

  def toCassandraRowRDD(inputDf: DataFrame): RDD[CassandraRow] = {
//    val dfColumns = inputDf.dtypes.toStream.map(colInfo => colInfo._1).mkString(",")
//    val inputRDD = inputDf.rdd
//    val sparkRowToCassandraRow = new SparkRowToCassandraRow(dfColumns)
//    val outputDf = inputRDD.map(row => sparkRowToCassandraRow.map(row)) //TOO: use only function
//    return outputDf
    val columnNames= inputDf.schema.fieldNames
    inputDf.rdd.map(r=> {
    CassandraRow.fromMap((columnNames zip r.toSeq).toMap)})
  }

  /*
  def getCatalog(tableName: String) : String = {
    // TODO: update table name in catalog file based on args?
    var tableCatalog: String = ""
    if(tableName.contains("encounter")) {
      //TODO: read catalog file name from property file or as argument
      tableCatalog = GCSFileUtility.readFile(new Configuration(), "gs://sparkmigrate/conf/encounter_catalog_test.txt")
        .mkString("\n")
    }
    else if(tableName.contains("patient")) {
      tableCatalog = GCSFileUtility.readFile(new Configuration(), "gs://sparkmigrate/conf/patient_history_catalog.txt")
        .mkString("\n")
    }
    else {
      throw new UnsupportedOperationException(s"Unsupported Table Name $tableName")
    }
    return tableCatalog
  }
  */
  def getCatalog(tableName: String) : String = {
    var tableCatalog: String = ""

    val catalogFile = tableCatalogMap.get(tableName)
    if(!catalogFile.isEmpty) {
      tableCatalog = GCSFileUtility.readFile(new Configuration(), catalogFile.get)
        .mkString("\n")
    }
    else {
      throw new UnsupportedOperationException(s"Unsupported Table Name $tableName")
    }
    return tableCatalog
  }


  //TODO: Remove this - added only for testing purpose - as it uses collect
  def printCassandraDataset(inputDataset: RDD[CassandraRow]): Unit = {
    inputDataset.foreach(cassandraRow => println(cassandraRow))
    println("Number of cassandra rows: " + inputDataset.count)

    val cassandraRows = inputDataset.collect()
    for(row <- cassandraRows) {
      println("Cassandra row data: " + row.getString("name") + "," + row.getInt("age") + ", " + row.getDate("dob"))
    }
  }

}
