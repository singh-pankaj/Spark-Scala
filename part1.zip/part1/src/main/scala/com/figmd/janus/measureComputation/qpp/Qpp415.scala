
package com.figmd.janus.measureComputation.qpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP415Elements}
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 415
* Measure Title              :- Emergency Medicine: Emergency Department Utilization of CT for Minor Blunt Head Trauma for Patients Aged 18 Years and Older
* Measure Description        :- Percentage of emergency department visits for patients aged 18 years and older who presented with a minor blunt
                                head trauma who had a head CT for trauma ordered by an emergency care provider who have an indication for a
                                head CT
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp415 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp415"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    //Backtracking List
    val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD
      , QPP415Elements.Brain_Tumor
      , QPP415Elements.Ventricular_Shunt
      , QPP415Elements.Antiplatelet_Therapy
      , QPP415Elements.Coagulopathies
      , QPP415Elements.Thrombocytopenia
      , QPP415Elements.Anticoagulant
      , QPP415Elements.Drug_Or_Alcohol_Intoxication)
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect.toList)
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()
      // Filter Intermediate
      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()
      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()
      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()
      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
All emergency department visits for patients aged 18 years and older who presented with a minor blunt head trauma
who had a head CT for trauma ordered by an emergency care provider.
----------------------------------------------------------------------------------------------------------------------------*/
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
           isPatientAdult(visit,m)
        && isVisitTypeIn(visit,m
                ,QPP415Elements.Emergency_Department_Visit
                ,QPP415Elements.Critical_Care_Evaluation_And_Management)
        && (
             (
              (    isDiagnosticStudyDuringEDOrCCEncounter(visit,m,QPP415Elements.Head_Ct_Performed,QPP415Elements.Head_Ct_Performed_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
                || isDiagnosticStudyDuringEDOrCCEncounter(visit,m,QPP415Elements.Head_Ct,QPP415Elements.Head_Ct_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
              )
                && isDiagnosisDuringEDOrCCEncounter(visit,m,QPP415Elements.Non_Penetrating_Head_Trauma,QPP415Elements.Non_Penetrating_Head_Trauma_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
             )
               ||  isAssessmentDuringEDOrCCEncounter(visit,m,QPP415Elements.Minor_Head_Trauma_Ct_G,QPP415Elements.Minor_Head_Trauma_Ct_G_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
          )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Patient has documentation of ventricular shunt, brain tumor, multisystem trauma, pregnancy, or is currently taking
an antiplatelet medication including: abciximab, cangrelor, cilostazol, clopidogrel, eptifibatide, prasugrel, ticlopidine,
ticagrelor, tirofiban, or vorapaxar.
----------------------------------------------------------------------------------------------------------------------------*/

  // Denominator Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
         wasDiagnosedBeforeEDOrCCEncounter(visit,m,QPP415Elements.Brain_Tumor,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
      || wasDiagnosedBeforeEDOrCCEncounter(visit,m,QPP415Elements.Ventricular_Shunt,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
      || wasMedicationBeforeEDOrCCEncounter(visit,m,QPP415Elements.Antiplatelet_Therapy,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
      || isDiagnosedWithOnEncounter(visit,m,QPP415Elements.Pregnancy)
      || isDiagnosisDuringEDOrCCEncounter(visit,m,QPP415Elements.Trauma_Excluding_Head,QPP415Elements.Trauma_Excluding_Head_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
      || isAssessmentDuringEDOrCCEncounter(visit,m,QPP415Elements.Complications_For_Head_Ct,QPP415Elements.Complications_For_Head_Ct_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Emergency department visits for patients who have an indication for a head CT
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      (     isGCSResultDuringEDorCCLessThanX(visit,m,QPP415Elements.Glasgow_Coma_Scale,15,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
        ||  isAgeAbove(visit,m,true,65)
        ||  isDiagnosisDuringEDOrCCSeverity(visit,m,QPP415Elements.Headache,QPP415Elements.Headache_Date,QPP415Elements.Severe,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
        ||  isSymptomDuringEDOrCCEncounter(visit,m,QPP415Elements.Vomiting,QPP415Elements.Vomiting_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
        ||  isSymptomDuringEDOrCCEncounter(visit,m,QPP415Elements.Physical_Signs_Of_Basilar_Skull_Fracture,QPP415Elements.Physical_Signs_Of_Basilar_Skull_Fracture_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
        ||  isSymptomDuringEDOrCCEncounter(visit,m,QPP415Elements.Focal_Neurological_Deficit,QPP415Elements.Focal_Neurological_Deficit_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
        ||  wasDiagnosedBeforeEDOrCCEncounter(visit,m,QPP415Elements.Coagulopathies,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        ||  wasDiagnosedBeforeEDOrCCEncounter(visit,m,QPP415Elements.Thrombocytopenia,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        ||  wasMedicationBeforeEDOrCCEncounter(visit,m,QPP415Elements.Anticoagulant,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        ||  (   isVisitTypeIn(visit,m
                    ,QPP415Elements.Emergency_Department_Visit
                    ,QPP415Elements.Critical_Care_Evaluation_And_Management)
             && (    isEncounterPerformedEDOrCCEncounter(visit,m,QPP415Elements.Critical_Care_Evaluation_And_Management,QPP415Elements.Dangerous_Mechanism_Of_Injury)
                 ||  isEncounterPerformedEDOrCCEncounter(visit,m,QPP415Elements.Emergency_Department_Visit,QPP415Elements.Dangerous_Mechanism_Of_Injury)
                )
            )
      || (
           (   isSymptomDuringEDOrCCEncounter(visit,m,QPP415Elements.Loss_Of_Consciousness,QPP415Elements.Loss_Of_Consciousness_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
            || isSymptomDuringEDOrCCEncounter(visit,m,QPP415Elements.Post_Traumatic_Amnesia,QPP415Elements.Post_Traumatic_Amnesia_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
           )
             &&
           (
                isGCSResultDuringEDorCCLessThanX(visit,m,QPP415Elements.Glasgow_Coma_Scale,15,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
             || isAgeBetween(visit,m,60,65)
             || isDiagnosisDuringEDOrCCSeverity(visit,m,QPP415Elements.Headache,QPP415Elements.Headache_Date,QPP415Elements.Severe,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
             || isSymptomDuringEDOrCCEncounter(visit,m,QPP415Elements.Short_Term_Memory_Deficits,QPP415Elements.Short_Term_Memory_Deficits_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
             || isSymptomDuringEDOrCCEncounter(visit,m,QPP415Elements.Seizure_After_Head_Injury,QPP415Elements.Seizure_After_Head_Injury_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
             || isSymptomDuringEDOrCCEncounter(visit,m,QPP415Elements.Evidence_Of_Trauma_Of_Head_Or_Neck,QPP415Elements.Evidence_Of_Trauma_Of_Head_Or_Neck_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
             || wasDiagnosedBeforeEDOrCCEncounter(visit,m,QPP415Elements.Drug_Or_Alcohol_Intoxication,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
           )
         )
      ||  isAssessmentDuringEDOrCCEncounter(visit,m,QPP415Elements.Indications_For_A_Head_Ct,QPP415Elements.Indications_For_A_Head_Ct_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
    )
     && ! isAssessmentDuringEDOrCCEncounter(visit,m,QPP415Elements.Indications_For_A_Head_Ct_Not_Met,QPP415Elements.Indications_For_A_Head_Ct_Not_Met_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,QPP415Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }
}
