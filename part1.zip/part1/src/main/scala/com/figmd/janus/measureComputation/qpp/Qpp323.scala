package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP323Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 323
* Measure Title              :- Cardiac Stress Imaging Not Meeting Appropriate Use Criteria: Routine Testing After
                                Percutaneous Coronary Intervention (PCI)
* Measure Description        :- Percentage of all stress single-photon emission computed tomography (SPECT) myocardial
                                perfusion imaging (MPI), stress echocardiogram (ECHO), cardiac computed tomography
                                angiography (CCTA), and cardiovascular magnetic resonance (CMR) performed in patients
                                aged 18 years and older routinely after percutaneous coronary intervention (PCI), with
                                reference to timing of test after PCI and symptom status.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp323 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "Qpp323"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP323Elements.Post_Evaluation_Pci
      , QPP323Elements.Post_Evaluation_Pci_Not_Met
      , QPP323Elements.Cardiac_Stress_Imaging
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  /*------------------------------------------------------------------------------------------------
   All instances of stress single-photon emission computed tomography (SPECT) myocardial perfusion imaging (MPI), stress
    echocardiogram (ECHO), cardiac computed tomography angiography (CCTA), or cardiac magnetic resonance (CMR) performed
     on patients aged 18 years and older during the submission period
  ------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isProcedurePerformedDuringEncounter(visit, m, QPP323Elements.Cardiac_Stress_Imaging)

    )
  }


  /*------------------------------------------------------------------------------------------------
   	Number of stress SPECT MPI, stress echo, CCTA and CMR performed in asymptomatic patients within 2 years of the most recent PCI
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRdd.filter(visit =>
      (
        isProcedurePerformed(visit, m, QPP323Elements.Post_Evaluation_Pci, patientHistoryBroadcastList)
          || (
          isProcedurePerformed(visit, m, QPP323Elements.Post_Evaluation_Pci, patientHistoryBroadcastList)
            && isPatientCharacteristicDuringEncounter(visit, m, QPP323Elements.Asymptomatic_Patient)
          )
        )
        && !isProcedurePerformed(visit, m, QPP323Elements.Post_Evaluation_Pci_Not_Met, patientHistoryBroadcastList)
    )

  }

}
