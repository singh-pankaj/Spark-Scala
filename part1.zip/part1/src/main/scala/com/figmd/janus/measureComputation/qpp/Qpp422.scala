package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{QPP422Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 422
* Measure Title              :- Performing Cystoscopy at the Time of Hysterectomy for Pelvic Organ
                                Prolapse to Detect Lower Urinary Tract Injury
* Measure Description        :- Percentage of patients who undergo cystoscopy to evaluate for lower urinary tract injury
                                at the time of hysterectomy for pelvic organ prolapse
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp422 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp422"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,QPP422Elements.Pelvic_Organ_Prolapse
      ,QPP422Elements.Hysterectomy)
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val leastRecentRDD : List[CassandraRow] = leastRecentPatientList(patientHistoryRDD,QPP422Elements.Pelvic_Organ_Prolapse)
    val leastRecentPatienthistoryList :Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastRecentRDD)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList,leastRecentPatienthistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //eligible RDD
      // val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD)
      metRDD.cache()

      // Filter Intermediate RDD
      val intermediateException = getSubtractRDD(ippRDD, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateException)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      leastRecentPatienthistoryList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
   All patients undergoing hysterectomy for pelvic organ prolapse
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]],leastRecentPatienthistoryList :Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
            isFemale(visit,m)
        &&  isDiagnosis(visit,m,QPP422Elements.Pelvic_Organ_Prolapse,patientHistoryList)
        &&  wasProcedurePerformedAfterOrEqualDiagnosisAndBeforeOrEqualEnd(visit,m,QPP422Elements.Hysterectomy,QPP422Elements.Pelvic_Organ_Prolapse,patientHistoryList)
    )
  }

  /*------------------------------------------------------------------------------------------------
    Patients in whom an intraoperative cystoscopy was performed to evaluate for lower urinary tract
    injury at the time of hysterectomy for pelvic organ prolapse
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
        (
               isProcedurePerformedDuringOtherProcedure(visit,m,QPP422Elements.Intraoperative_Cystoscopy,QPP422Elements.Hysterectomy)
          ||   isProcedurePerformedDuringProcedureWithReason(visit,m,QPP422Elements.Intraopertaive_Cystoscopy_Performed,QPP422Elements.Hysterectomy,QPP422Elements.Evaluate_For_Lower_Urinary_Tract_Injury)
        )
        &&  !isProcedurePerformedDuringOtherProcedure(visit,m,QPP422Elements.Intraoperative_Cystoscopy_Not_Met,QPP422Elements.Hysterectomy)
    )

  }

  /*-----------------------------------------------------------------------------------------------------------------
   Documented medical reasons for not performing intraoperative cystoscopy (e.g., urethral pathology precluding
   cystoscopy, any patient who has a congenital or acquired absence of the urethra)
   -----------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermediateException: RDD[CassandraRow]): RDD[CassandraRow]  = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateException.filter(visit =>
             isProcedurePerformedNotDoneDuringOtherProcedure(visit,m,QPP422Elements.Medical_Reason_Intraoperative_Cystoscopy,QPP422Elements.Hysterectomy)
        ||   isDiagnosticStudyPerformedDuringProcedure(visit,m,QPP422Elements.Intraoperative_Cystoscopy_Medical_Reason,QPP422Elements.Hysterectomy)
        ||   isPatientDiedDuringProcedure(visit,m,QPP422Elements.Patient_Died,QPP422Elements.Hysterectomy)
    )

  }

}
