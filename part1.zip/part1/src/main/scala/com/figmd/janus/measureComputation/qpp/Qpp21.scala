package com.figmd.janus.measureComputation.qpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.qpp.Qpp21.wasMedicationOrderedBeforeSurgeryWithinXHours

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 21
* Measure Title              :- Perioperative Care: Selection of Prophylactic Antibiotic – First OR Second Generation Cephalosporin
* Measure Description        :- Percentage of surgical patients aged 18 years and older undergoing procedures with the indications
                                for a first OR second generation cephalosporin prophylactic antibiotic who had an order for a first
                                OR second generation cephalosporin for antimicrobial prophylaxis
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp21 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp21"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryRDD:RDD[CassandraRow] =getPatientHistory(sparkSession,initialRDD
            ,QPP21Elements.Integumentary_Surgery
            ,QPP21Elements.Spinal_Surgery
            ,QPP21Elements.Hip_Reconstruction
            ,QPP21Elements.Fracture_Trauma_Surgery
            ,QPP21Elements.Knee_Reconstruction
            ,QPP21Elements.Vascular_Surgery
            ,QPP21Elements.Spleen_And_Lymphatic_Surgery
            ,QPP21Elements.Esophageal_Surgery
            ,QPP21Elements.Stomach_Surgery
            ,QPP21Elements.Small_Intestinal_Surgery
            ,QPP21Elements.Colon_Surgery
            ,QPP21Elements.Biliary_Surgery
            ,QPP21Elements.Pancreatic_Surgery
            ,QPP21Elements.Renal_Transplant_Surgery
            ,QPP21Elements.Neurological_Surgery
            ,QPP21Elements.Cardiothoracic_Surgery
            ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery
            ,QPP21Elements.Bariatric_Surgery
            ,QPP21Elements.Liver_Surgery
            ,QPP21Elements.Gynecologic_Surgery
            ,QPP21Elements.General_Surgery
            ,QPP21Elements.Rectal_Surgery
            ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum
            ,QPP21Elements.General_Thoracic_Surgery
            ,QPP21Elements.Foot_And_Ankle_Surgery
            ,QPP21Elements.Laryngectomy
            ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix
            ,QPP21Elements.Integumentary_Surgery__Dual_
            ,QPP21Elements.Spinal_Surgery__Dual_
            ,QPP21Elements.Hip_Reconstruction__Dual_
            ,QPP21Elements.Fracture_Trauma_Surgery__Dual_
            ,QPP21Elements.Knee_Reconstruction__Dual_
            ,QPP21Elements.Vascular_Surgery__Dual_
            ,QPP21Elements.Spleen_And_Lymphatic_Surgery__Dual_
            ,QPP21Elements.Esophageal_Surgery__Dual_
            ,QPP21Elements.Stomach_Surgery__Dual_
            ,QPP21Elements.Small_Intestinal_Surgery__Dual_
            ,QPP21Elements.Colon_Surgery__Dual_
            ,QPP21Elements.Biliary_Surgery__Dual_
            ,QPP21Elements.Pancreatic_Surgery__Dual_
            ,QPP21Elements.Renal_Transplant_Surgery__Dual_
            ,QPP21Elements.Neurological_Surgery__Dual_
            ,QPP21Elements.Cardiothoracic_Surgery__Dual_
            ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery__Dual_
            ,QPP21Elements.Bariatric_Surgery__Dual_
            ,QPP21Elements.Liver_Surgery__Dual_
            ,QPP21Elements.Gynecologic_Surgery__Dual_
            ,QPP21Elements.General_Surgery__Dual_
            ,QPP21Elements.Rectal_Surgery__Dual_
            ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum__Dual_
            ,QPP21Elements.Foot_And_Ankle_Surgery__Dual_
            ,QPP21Elements.Laryngectomy__Dual_
            ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix__Dual_
            ,QPP21Elements.General_Thoracic_Surgery__Dual_
            ,QPP21Elements.Cephalosporin_Med
            ,QPP21Elements.Cephalosporin
            ,QPP21Elements.Documentation_Of_Prior_Infections
            ,QPP21Elements.Enrollment_In_Clinical_Trials
            ,QPP21Elements.Oral_First_Or_Second_Generation_Cephalosporin)

    val patientHistoryBroadcastList :Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

       // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateA = getSubtractRDD(denominatorRDD, metRDD)
      intermediateA.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateA, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  All surgical patients aged 18 years and older undergoing procedures with the indications for a first
  OR second generation cephalosporin prophylactic antibiotic
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(rdd:RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
             isPatientAdult(visit,m)
         &&  isSurgeryPerformed(visit,m,patientHistoryList
                        ,QPP21Elements.Integumentary_Surgery
                        ,QPP21Elements.Spinal_Surgery
                        ,QPP21Elements.Hip_Reconstruction
                        ,QPP21Elements.Fracture_Trauma_Surgery
                        ,QPP21Elements.Knee_Reconstruction
                        ,QPP21Elements.Vascular_Surgery
                        ,QPP21Elements.Spleen_And_Lymphatic_Surgery
                        ,QPP21Elements.Esophageal_Surgery
                        ,QPP21Elements.Stomach_Surgery
                        ,QPP21Elements.Small_Intestinal_Surgery
                        ,QPP21Elements.Colon_Surgery
                        ,QPP21Elements.Biliary_Surgery
                        ,QPP21Elements.Pancreatic_Surgery
                        ,QPP21Elements.Renal_Transplant_Surgery
                        ,QPP21Elements.Neurological_Surgery
                        ,QPP21Elements.Cardiothoracic_Surgery
                        ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery
                        ,QPP21Elements.Bariatric_Surgery
                        ,QPP21Elements.Liver_Surgery
                        ,QPP21Elements.Gynecologic_Surgery
                        ,QPP21Elements.General_Surgery
                        ,QPP21Elements.Rectal_Surgery
                        ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum
                        ,QPP21Elements.General_Thoracic_Surgery
                        ,QPP21Elements.Foot_And_Ankle_Surgery
                        ,QPP21Elements.Laryngectomy
                        ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix
                        ,QPP21Elements.Integumentary_Surgery__Dual_
                        ,QPP21Elements.Spinal_Surgery__Dual_
                        ,QPP21Elements.Hip_Reconstruction__Dual_
                        ,QPP21Elements.Fracture_Trauma_Surgery__Dual_
                        ,QPP21Elements.Knee_Reconstruction__Dual_
                        ,QPP21Elements.Vascular_Surgery__Dual_
                        ,QPP21Elements.Spleen_And_Lymphatic_Surgery__Dual_
                        ,QPP21Elements.Esophageal_Surgery__Dual_
                        ,QPP21Elements.Stomach_Surgery__Dual_
                        ,QPP21Elements.Small_Intestinal_Surgery__Dual_
                        ,QPP21Elements.Colon_Surgery__Dual_
                        ,QPP21Elements.Biliary_Surgery__Dual_
                        ,QPP21Elements.Pancreatic_Surgery__Dual_
                        ,QPP21Elements.Renal_Transplant_Surgery__Dual_
                        ,QPP21Elements.Neurological_Surgery__Dual_
                        ,QPP21Elements.Cardiothoracic_Surgery__Dual_
                        ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery__Dual_
                        ,QPP21Elements.Bariatric_Surgery__Dual_
                        ,QPP21Elements.Liver_Surgery__Dual_
                        ,QPP21Elements.Gynecologic_Surgery__Dual_
                        ,QPP21Elements.General_Surgery__Dual_
                        ,QPP21Elements.Rectal_Surgery__Dual_
                        ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum__Dual_
                        ,QPP21Elements.Foot_And_Ankle_Surgery__Dual_
                        ,QPP21Elements.Laryngectomy__Dual_
                        ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix__Dual_
                        ,QPP21Elements.General_Thoracic_Surgery__Dual_)
    )
  }

/*-------------------------------------------------------------------------------------------------------------------------
Surgical patients who had an order for a first OR second generation cephalosporin for antimicrobial prophylaxis
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      (        wasMedicationOrderedBeforeSurgeryWithinXHours(visit,m,QPP21Elements.Cephalosporin_Med,24,patientHistoryList
                  ,QPP21Elements.Integumentary_Surgery
                  ,QPP21Elements.Spinal_Surgery
                  ,QPP21Elements.Hip_Reconstruction
                  ,QPP21Elements.Fracture_Trauma_Surgery
                  ,QPP21Elements.Knee_Reconstruction
                  ,QPP21Elements.Vascular_Surgery
                  ,QPP21Elements.Spleen_And_Lymphatic_Surgery
                  ,QPP21Elements.Esophageal_Surgery
                  ,QPP21Elements.Stomach_Surgery
                  ,QPP21Elements.Small_Intestinal_Surgery
                  ,QPP21Elements.Colon_Surgery
                  ,QPP21Elements.Biliary_Surgery
                  ,QPP21Elements.Pancreatic_Surgery
                  ,QPP21Elements.Renal_Transplant_Surgery
                  ,QPP21Elements.Neurological_Surgery
                  ,QPP21Elements.Cardiothoracic_Surgery
                  ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery
                  ,QPP21Elements.Bariatric_Surgery
                  ,QPP21Elements.Liver_Surgery
                  ,QPP21Elements.Gynecologic_Surgery
                  ,QPP21Elements.General_Surgery
                  ,QPP21Elements.Rectal_Surgery
                  ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum
                  ,QPP21Elements.General_Thoracic_Surgery
                  ,QPP21Elements.Foot_And_Ankle_Surgery
                  ,QPP21Elements.Laryngectomy
                  ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix
                  ,QPP21Elements.Integumentary_Surgery__Dual_
                  ,QPP21Elements.Spinal_Surgery__Dual_
                  ,QPP21Elements.Hip_Reconstruction__Dual_
                  ,QPP21Elements.Fracture_Trauma_Surgery__Dual_
                  ,QPP21Elements.Knee_Reconstruction__Dual_
                  ,QPP21Elements.Vascular_Surgery__Dual_
                  ,QPP21Elements.Spleen_And_Lymphatic_Surgery__Dual_
                  ,QPP21Elements.Esophageal_Surgery__Dual_
                  ,QPP21Elements.Stomach_Surgery__Dual_
                  ,QPP21Elements.Small_Intestinal_Surgery__Dual_
                  ,QPP21Elements.Colon_Surgery__Dual_
                  ,QPP21Elements.Biliary_Surgery__Dual_
                  ,QPP21Elements.Pancreatic_Surgery__Dual_
                  ,QPP21Elements.Renal_Transplant_Surgery__Dual_
                  ,QPP21Elements.Neurological_Surgery__Dual_
                  ,QPP21Elements.Cardiothoracic_Surgery__Dual_
                  ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery__Dual_
                  ,QPP21Elements.Bariatric_Surgery__Dual_
                  ,QPP21Elements.Liver_Surgery__Dual_
                  ,QPP21Elements.Gynecologic_Surgery__Dual_
                  ,QPP21Elements.General_Surgery__Dual_
                  ,QPP21Elements.Rectal_Surgery__Dual_
                  ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum__Dual_
                  ,QPP21Elements.Foot_And_Ankle_Surgery__Dual_
                  ,QPP21Elements.Laryngectomy__Dual_
                  ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix__Dual_
                  ,QPP21Elements.General_Thoracic_Surgery__Dual_)

            ||  wasAssessmentPerformedBeforeSurgeryWithinXHours(visit,m,QPP21Elements.Cephalosporin,24,patientHistoryList
                  ,QPP21Elements.Integumentary_Surgery
                  ,QPP21Elements.Spinal_Surgery
                  ,QPP21Elements.Hip_Reconstruction
                  ,QPP21Elements.Fracture_Trauma_Surgery
                  ,QPP21Elements.Knee_Reconstruction
                  ,QPP21Elements.Vascular_Surgery
                  ,QPP21Elements.Spleen_And_Lymphatic_Surgery
                  ,QPP21Elements.Esophageal_Surgery
                  ,QPP21Elements.Stomach_Surgery
                  ,QPP21Elements.Small_Intestinal_Surgery
                  ,QPP21Elements.Colon_Surgery
                  ,QPP21Elements.Biliary_Surgery
                  ,QPP21Elements.Pancreatic_Surgery
                  ,QPP21Elements.Renal_Transplant_Surgery
                  ,QPP21Elements.Neurological_Surgery
                  ,QPP21Elements.Cardiothoracic_Surgery
                  ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery
                  ,QPP21Elements.Bariatric_Surgery
                  ,QPP21Elements.Liver_Surgery
                  ,QPP21Elements.Gynecologic_Surgery
                  ,QPP21Elements.General_Surgery
                  ,QPP21Elements.Rectal_Surgery
                  ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum
                  ,QPP21Elements.General_Thoracic_Surgery
                  ,QPP21Elements.Foot_And_Ankle_Surgery
                  ,QPP21Elements.Laryngectomy
                  ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix
                  ,QPP21Elements.Integumentary_Surgery__Dual_
                  ,QPP21Elements.Spinal_Surgery__Dual_
                  ,QPP21Elements.Hip_Reconstruction__Dual_
                  ,QPP21Elements.Fracture_Trauma_Surgery__Dual_
                  ,QPP21Elements.Knee_Reconstruction__Dual_
                  ,QPP21Elements.Vascular_Surgery__Dual_
                  ,QPP21Elements.Spleen_And_Lymphatic_Surgery__Dual_
                  ,QPP21Elements.Esophageal_Surgery__Dual_
                  ,QPP21Elements.Stomach_Surgery__Dual_
                  ,QPP21Elements.Small_Intestinal_Surgery__Dual_
                  ,QPP21Elements.Colon_Surgery__Dual_
                  ,QPP21Elements.Biliary_Surgery__Dual_
                  ,QPP21Elements.Pancreatic_Surgery__Dual_
                  ,QPP21Elements.Renal_Transplant_Surgery__Dual_
                  ,QPP21Elements.Neurological_Surgery__Dual_
                  ,QPP21Elements.Cardiothoracic_Surgery__Dual_
                  ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery__Dual_
                  ,QPP21Elements.Bariatric_Surgery__Dual_
                  ,QPP21Elements.Liver_Surgery__Dual_
                  ,QPP21Elements.Gynecologic_Surgery__Dual_
                  ,QPP21Elements.General_Surgery__Dual_
                  ,QPP21Elements.Rectal_Surgery__Dual_
                  ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum__Dual_
                  ,QPP21Elements.Foot_And_Ankle_Surgery__Dual_
                  ,QPP21Elements.Laryngectomy__Dual_
                  ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix__Dual_
                  ,QPP21Elements.General_Thoracic_Surgery__Dual_)

            ||  wasMedicationAdministeredBeforeSurgeryWithinXHours(visit,m,QPP21Elements.Cephalosporin_Med,24,patientHistoryList
                  ,QPP21Elements.Integumentary_Surgery
                  ,QPP21Elements.Spinal_Surgery
                  ,QPP21Elements.Hip_Reconstruction
                  ,QPP21Elements.Fracture_Trauma_Surgery
                  ,QPP21Elements.Knee_Reconstruction
                  ,QPP21Elements.Vascular_Surgery
                  ,QPP21Elements.Spleen_And_Lymphatic_Surgery
                  ,QPP21Elements.Esophageal_Surgery
                  ,QPP21Elements.Stomach_Surgery
                  ,QPP21Elements.Small_Intestinal_Surgery
                  ,QPP21Elements.Colon_Surgery
                  ,QPP21Elements.Biliary_Surgery
                  ,QPP21Elements.Pancreatic_Surgery
                  ,QPP21Elements.Renal_Transplant_Surgery
                  ,QPP21Elements.Neurological_Surgery
                  ,QPP21Elements.Cardiothoracic_Surgery
                  ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery
                  ,QPP21Elements.Bariatric_Surgery
                  ,QPP21Elements.Liver_Surgery
                  ,QPP21Elements.Gynecologic_Surgery
                  ,QPP21Elements.General_Surgery
                  ,QPP21Elements.Rectal_Surgery
                  ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum
                  ,QPP21Elements.General_Thoracic_Surgery
                  ,QPP21Elements.Foot_And_Ankle_Surgery
                  ,QPP21Elements.Laryngectomy
                  ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix
                  ,QPP21Elements.Integumentary_Surgery__Dual_
                  ,QPP21Elements.Spinal_Surgery__Dual_
                  ,QPP21Elements.Hip_Reconstruction__Dual_
                  ,QPP21Elements.Fracture_Trauma_Surgery__Dual_
                  ,QPP21Elements.Knee_Reconstruction__Dual_
                  ,QPP21Elements.Vascular_Surgery__Dual_
                  ,QPP21Elements.Spleen_And_Lymphatic_Surgery__Dual_
                  ,QPP21Elements.Esophageal_Surgery__Dual_
                  ,QPP21Elements.Stomach_Surgery__Dual_
                  ,QPP21Elements.Small_Intestinal_Surgery__Dual_
                  ,QPP21Elements.Colon_Surgery__Dual_
                  ,QPP21Elements.Biliary_Surgery__Dual_
                  ,QPP21Elements.Pancreatic_Surgery__Dual_
                  ,QPP21Elements.Renal_Transplant_Surgery__Dual_
                  ,QPP21Elements.Neurological_Surgery__Dual_
                  ,QPP21Elements.Cardiothoracic_Surgery__Dual_
                  ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery__Dual_
                  ,QPP21Elements.Bariatric_Surgery__Dual_
                  ,QPP21Elements.Liver_Surgery__Dual_
                  ,QPP21Elements.Gynecologic_Surgery__Dual_
                  ,QPP21Elements.General_Surgery__Dual_
                  ,QPP21Elements.Rectal_Surgery__Dual_
                  ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum__Dual_
                  ,QPP21Elements.Foot_And_Ankle_Surgery__Dual_
                  ,QPP21Elements.Laryngectomy__Dual_
                  ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix__Dual_
                  ,QPP21Elements.General_Thoracic_Surgery__Dual_)
    )
        && ! isAssessmentPerformedDuringSurgery(visit,m,QPP21Elements.Order_Cephalosporin_Reason_Not_Specified_Date
                  ,QPP21Elements.Integumentary_Surgery_Date
                  ,QPP21Elements.Spinal_Surgery_Date
                  ,QPP21Elements.Hip_Reconstruction_Date
                  ,QPP21Elements.Fracture_Trauma_Surgery_Date
                  ,QPP21Elements.Knee_Reconstruction_Date
                  ,QPP21Elements.Vascular_Surgery_Date
                  ,QPP21Elements.Spleen_And_Lymphatic_Surgery_Date
                  ,QPP21Elements.Esophageal_Surgery_Date
                  ,QPP21Elements.Stomach_Surgery_Date
                  ,QPP21Elements.Small_Intestinal_Surgery_Date
                  ,QPP21Elements.Colon_Surgery_Date
                  ,QPP21Elements.Biliary_Surgery_Date
                  ,QPP21Elements.Pancreatic_Surgery_Date
                  ,QPP21Elements.Renal_Transplant_Surgery_Date
                  ,QPP21Elements.Neurological_Surgery_Date
                  ,QPP21Elements.Cardiothoracic_Surgery_Date
                  ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery_Date
                  ,QPP21Elements.Bariatric_Surgery_Date
                  ,QPP21Elements.Liver_Surgery_Date
                  ,QPP21Elements.Gynecologic_Surgery_Date
                  ,QPP21Elements.General_Surgery_Date
                  ,QPP21Elements.Rectal_Surgery_Date
                  ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum_Date
                  ,QPP21Elements.General_Thoracic_Surgery_Date
                  ,QPP21Elements.Foot_And_Ankle_Surgery_Date
                  ,QPP21Elements.Laryngectomy_Date
                  ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix_Date
                  ,QPP21Elements.Integumentary_Surgery__Dual__Date
                  ,QPP21Elements.Spinal_Surgery__Dual__Date
                  ,QPP21Elements.Hip_Reconstruction__Dual__Date
                  ,QPP21Elements.Fracture_Trauma_Surgery__Dual__Date
                  ,QPP21Elements.Knee_Reconstruction__Dual__Date
                  ,QPP21Elements.Vascular_Surgery__Dual__Date
                  ,QPP21Elements.Spleen_And_Lymphatic_Surgery__Dual__Date
                  ,QPP21Elements.Esophageal_Surgery__Dual__Date
                  ,QPP21Elements.Stomach_Surgery__Dual__Date
                  ,QPP21Elements.Small_Intestinal_Surgery__Dual__Date
                  ,QPP21Elements.Colon_Surgery__Dual__Date
                  ,QPP21Elements.Biliary_Surgery__Dual__Date
                  ,QPP21Elements.Pancreatic_Surgery__Dual__Date
                  ,QPP21Elements.Renal_Transplant_Surgery__Dual__Date
                  ,QPP21Elements.Neurological_Surgery__Dual__Date
                  ,QPP21Elements.Cardiothoracic_Surgery__Dual__Date
                  ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery__Dual__Date
                  ,QPP21Elements.Bariatric_Surgery__Dual__Date
                  ,QPP21Elements.Liver_Surgery__Dual__Date
                  ,QPP21Elements.Gynecologic_Surgery__Dual__Date
                  ,QPP21Elements.General_Surgery__Dual__Date
                  ,QPP21Elements.Rectal_Surgery__Dual__Date
                  ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum__Dual__Date
                  ,QPP21Elements.Foot_And_Ankle_Surgery__Dual__Date
                  ,QPP21Elements.Laryngectomy__Dual__Date
                  ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix__Dual__Date
                  ,QPP21Elements.General_Thoracic_Surgery__Dual__Date)
  )
}

/*-------------------------------------------------------------------------------------------------------------------------
Documentation of medical reason(s) for not ordering a first OR second generation cephalosporin for antimicrobial prophylaxis
(e.g., patients enrolled in clinical trials, patients with documented infection prior to surgical procedure of interest,
patients who were receiving antibiotics more than 24 hours prior to surgery [except colon surgery patients
taking oral prophylactic antibiotics], patients who were receiving antibiotics within 24 hours prior to arrival
[except colon surgery patients taking oral prophylactic antibiotics], other medical reason(s))
----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(rdd: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    rdd.filter(visit =>
      wasDiagnosisBeforeSurgery(visit,m,QPP21Elements.Documentation_Of_Prior_Infections,patienthistoryList
                ,QPP21Elements.Integumentary_Surgery
                ,QPP21Elements.Spinal_Surgery
                ,QPP21Elements.Hip_Reconstruction
                ,QPP21Elements.Fracture_Trauma_Surgery
                ,QPP21Elements.Knee_Reconstruction
                ,QPP21Elements.Vascular_Surgery
                ,QPP21Elements.Spleen_And_Lymphatic_Surgery
                ,QPP21Elements.Esophageal_Surgery
                ,QPP21Elements.Stomach_Surgery
                ,QPP21Elements.Small_Intestinal_Surgery
                ,QPP21Elements.Colon_Surgery
                ,QPP21Elements.Biliary_Surgery
                ,QPP21Elements.Pancreatic_Surgery
                ,QPP21Elements.Renal_Transplant_Surgery
                ,QPP21Elements.Neurological_Surgery
                ,QPP21Elements.Cardiothoracic_Surgery
                ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery
                ,QPP21Elements.Bariatric_Surgery
                ,QPP21Elements.Liver_Surgery
                ,QPP21Elements.Gynecologic_Surgery
                ,QPP21Elements.General_Surgery
                ,QPP21Elements.Rectal_Surgery
                ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum
                ,QPP21Elements.General_Thoracic_Surgery
                ,QPP21Elements.Foot_And_Ankle_Surgery
                ,QPP21Elements.Laryngectomy
                ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix
                ,QPP21Elements.Integumentary_Surgery__Dual_
                ,QPP21Elements.Spinal_Surgery__Dual_
                ,QPP21Elements.Hip_Reconstruction__Dual_
                ,QPP21Elements.Fracture_Trauma_Surgery__Dual_
                ,QPP21Elements.Knee_Reconstruction__Dual_
                ,QPP21Elements.Vascular_Surgery__Dual_
                ,QPP21Elements.Spleen_And_Lymphatic_Surgery__Dual_
                ,QPP21Elements.Esophageal_Surgery__Dual_
                ,QPP21Elements.Stomach_Surgery__Dual_
                ,QPP21Elements.Small_Intestinal_Surgery__Dual_
                ,QPP21Elements.Colon_Surgery__Dual_
                ,QPP21Elements.Biliary_Surgery__Dual_
                ,QPP21Elements.Pancreatic_Surgery__Dual_
                ,QPP21Elements.Renal_Transplant_Surgery__Dual_
                ,QPP21Elements.Neurological_Surgery__Dual_
                ,QPP21Elements.Cardiothoracic_Surgery__Dual_
                ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery__Dual_
                ,QPP21Elements.Bariatric_Surgery__Dual_
                ,QPP21Elements.Liver_Surgery__Dual_
                ,QPP21Elements.Gynecologic_Surgery__Dual_
                ,QPP21Elements.General_Surgery__Dual_
                ,QPP21Elements.Rectal_Surgery__Dual_
                ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum__Dual_
                ,QPP21Elements.Foot_And_Ankle_Surgery__Dual_
                ,QPP21Elements.Laryngectomy__Dual_
                ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix__Dual_
                ,QPP21Elements.General_Thoracic_Surgery__Dual_)
      ||  isPatientCharacteristic(visit,m,QPP21Elements.Enrollment_In_Clinical_Trials,patienthistoryList)
      ||  isAssessmentPerformedDuringSurgery(visit,m,QPP21Elements.Order_Cephalosporin_Medical_Reason_Date,QPP21Elements.Order_Cephalosporin_Medical_Reason_Date
                ,QPP21Elements.Integumentary_Surgery_Date
                ,QPP21Elements.Spinal_Surgery_Date
                ,QPP21Elements.Hip_Reconstruction_Date
                ,QPP21Elements.Fracture_Trauma_Surgery_Date
                ,QPP21Elements.Knee_Reconstruction_Date
                ,QPP21Elements.Vascular_Surgery_Date
                ,QPP21Elements.Spleen_And_Lymphatic_Surgery_Date
                ,QPP21Elements.Esophageal_Surgery_Date
                ,QPP21Elements.Stomach_Surgery_Date
                ,QPP21Elements.Small_Intestinal_Surgery_Date
                ,QPP21Elements.Colon_Surgery_Date
                ,QPP21Elements.Biliary_Surgery_Date
                ,QPP21Elements.Pancreatic_Surgery_Date
                ,QPP21Elements.Renal_Transplant_Surgery_Date
                ,QPP21Elements.Neurological_Surgery_Date
                ,QPP21Elements.Cardiothoracic_Surgery_Date
                ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery_Date
                ,QPP21Elements.Bariatric_Surgery_Date
                ,QPP21Elements.Liver_Surgery_Date
                ,QPP21Elements.Gynecologic_Surgery_Date
                ,QPP21Elements.General_Surgery_Date
                ,QPP21Elements.Rectal_Surgery_Date
                ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum_Date
                ,QPP21Elements.General_Thoracic_Surgery_Date
                ,QPP21Elements.Foot_And_Ankle_Surgery_Date
                ,QPP21Elements.Laryngectomy_Date
                ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix_Date
                ,QPP21Elements.Integumentary_Surgery__Dual__Date
                ,QPP21Elements.Spinal_Surgery__Dual__Date
                ,QPP21Elements.Hip_Reconstruction__Dual__Date
                ,QPP21Elements.Fracture_Trauma_Surgery__Dual__Date
                ,QPP21Elements.Knee_Reconstruction__Dual__Date
                ,QPP21Elements.Vascular_Surgery__Dual__Date
                ,QPP21Elements.Spleen_And_Lymphatic_Surgery__Dual__Date
                ,QPP21Elements.Esophageal_Surgery__Dual__Date
                ,QPP21Elements.Stomach_Surgery__Dual__Date
                ,QPP21Elements.Small_Intestinal_Surgery__Dual__Date
                ,QPP21Elements.Colon_Surgery__Dual__Date
                ,QPP21Elements.Biliary_Surgery__Dual__Date
                ,QPP21Elements.Pancreatic_Surgery__Dual__Date
                ,QPP21Elements.Renal_Transplant_Surgery__Dual__Date
                ,QPP21Elements.Neurological_Surgery__Dual__Date
                ,QPP21Elements.Cardiothoracic_Surgery__Dual__Date
                ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery__Dual__Date
                ,QPP21Elements.Bariatric_Surgery__Dual__Date
                ,QPP21Elements.Liver_Surgery__Dual__Date
                ,QPP21Elements.Gynecologic_Surgery__Dual__Date
                ,QPP21Elements.General_Surgery__Dual__Date
                ,QPP21Elements.Rectal_Surgery__Dual__Date
                ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum__Dual__Date
                ,QPP21Elements.Foot_And_Ankle_Surgery__Dual__Date
                ,QPP21Elements.Laryngectomy__Dual__Date
                ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix__Dual__Date
                ,QPP21Elements.General_Thoracic_Surgery__Dual__Date)
    || ( wasMedicationAdministeredBeforeSurgerytInXHours (visit,m,Seq(QPP21Elements.Cephalosporin_Med),"MONTH",24,TimeOperator.BEFORE,patienthistoryList
                ,QPP21Elements.Integumentary_Surgery
                ,QPP21Elements.Spinal_Surgery
                ,QPP21Elements.Hip_Reconstruction
                ,QPP21Elements.Fracture_Trauma_Surgery
                ,QPP21Elements.Knee_Reconstruction
                ,QPP21Elements.Vascular_Surgery
                ,QPP21Elements.Spleen_And_Lymphatic_Surgery
                ,QPP21Elements.Esophageal_Surgery
                ,QPP21Elements.Stomach_Surgery
                ,QPP21Elements.Small_Intestinal_Surgery
                ,QPP21Elements.Biliary_Surgery
                ,QPP21Elements.Pancreatic_Surgery
                ,QPP21Elements.Renal_Transplant_Surgery
                ,QPP21Elements.Neurological_Surgery
                ,QPP21Elements.Cardiothoracic_Surgery
                ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery
                ,QPP21Elements.Bariatric_Surgery
                ,QPP21Elements.Liver_Surgery
                ,QPP21Elements.Gynecologic_Surgery
                ,QPP21Elements.General_Surgery
                ,QPP21Elements.Rectal_Surgery
                ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum
                ,QPP21Elements.General_Thoracic_Surgery
                ,QPP21Elements.Foot_And_Ankle_Surgery
                ,QPP21Elements.Laryngectomy
                ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix
                ,QPP21Elements.Integumentary_Surgery__Dual_
                ,QPP21Elements.Spinal_Surgery__Dual_
                ,QPP21Elements.Hip_Reconstruction__Dual_
                ,QPP21Elements.Fracture_Trauma_Surgery__Dual_
                ,QPP21Elements.Knee_Reconstruction__Dual_
                ,QPP21Elements.Vascular_Surgery__Dual_
                ,QPP21Elements.Spleen_And_Lymphatic_Surgery__Dual_
                ,QPP21Elements.Esophageal_Surgery__Dual_
                ,QPP21Elements.Stomach_Surgery__Dual_
                ,QPP21Elements.Small_Intestinal_Surgery__Dual_
                ,QPP21Elements.Biliary_Surgery__Dual_
                ,QPP21Elements.Pancreatic_Surgery__Dual_
                ,QPP21Elements.Renal_Transplant_Surgery__Dual_
                ,QPP21Elements.Neurological_Surgery__Dual_
                ,QPP21Elements.Cardiothoracic_Surgery__Dual_
                ,QPP21Elements.Mediastinum_And_Diaphragm_Surgery__Dual_
                ,QPP21Elements.Bariatric_Surgery__Dual_
                ,QPP21Elements.Liver_Surgery__Dual_
                ,QPP21Elements.Gynecologic_Surgery__Dual_
                ,QPP21Elements.General_Surgery__Dual_
                ,QPP21Elements.Rectal_Surgery__Dual_
                ,QPP21Elements.Surgery_Of_The_Abdomen_Peritoneum_And_Omentum__Dual_
                ,QPP21Elements.Foot_And_Ankle_Surgery__Dual_
                ,QPP21Elements.Laryngectomy__Dual_
                ,QPP21Elements.Surgery_Of_Meckel_s_Diverticulum_And_Appendix__Dual_
                ,QPP21Elements.General_Thoracic_Surgery__Dual_)

        && ! wasMedicationOrderedBeforeSurgery(visit,m,QPP21Elements.Oral_First_Or_Second_Generation_Cephalosporin,patienthistoryList
                ,QPP21Elements.Colon_Surgery__Dual_
                ,QPP21Elements.Colon_Surgery)
      )
  || (   wasMedicationAdministeredBeforeEncounterWithinXHours(visit,m,QPP21Elements.Cephalosporin_Med,24,patienthistoryList,QPP21Elements.Hospital_Admission_Date)
      && ! wasMedicationOrderedBeforeSurgery(visit,m,QPP21Elements.Oral_First_Or_Second_Generation_Cephalosporin,patienthistoryList
               ,QPP21Elements.Colon_Surgery
               ,QPP21Elements.Colon_Surgery__Dual_)
     )
    )
  }
}

