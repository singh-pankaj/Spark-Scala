package com.figmd.janus.measureComputation.ecqm


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, ECQM154V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.ecqm.Ecqm144V7_2.{MEASURE_NAME, checkEmptyIPPRDD}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Ecqm154
* Measure Title              :- Appropriate Treatment for Children with Upper Respiratory Infection (URI)
* Measure Description        :- Percentage of children 3 months-18 years of age who were diagnosed with upper respiratory infection (URI) and were not dispensed an antibiotic prescription on or three days after the episode
* Calculation Implementation :- Visit-specific(Episode)
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm154V7 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Ecqm154V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patient_history_list = getPatientHistory(sparkSession, initialRDD,
      ECQM154V7Elements.Upper_Respiratory_Infection,
      ECQM154V7Elements.Encounter_Inpatient,
      ECQM154V7Elements.Discharged_To_Home_For_Hospice_Care,
      ECQM154V7Elements.Hospice_Care_Ambulatory,
      ECQM154V7Elements.Antibiotic_Medications_For_Pharyngitis,
      ECQM154V7Elements.Competing_Conditions_For_Respiratory_Conditions
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible RDD
      //val eligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }

  //Initial Populaation Criteria
  // Children age 3 months to 18 years who had an outpatient visit with a diagnosis of URI during the measurement period

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 3, CalenderUnit.MONTH)
        && isAgeBelowBeforeStart(visit, m, false, 18, CalenderUnit.YEAR)
        && isVisitTypeIn(visit, m, ECQM154V7Elements.Office_Visit,
        ECQM154V7Elements.Emergency_Department_Visit,
        ECQM154V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,
        ECQM154V7Elements.Preventive_Care__Established_Office_Visit__0_To_17,
        ECQM154V7Elements.Hospital_Observation_Care___Initial

      )
        && isDiagnosisOnEncounter(visit, m, ECQM154V7Elements.Upper_Respiratory_Infection)
        || isDiagnosisOverlapsEncounter(visit, m, patientHistoryList, ECQM154V7Elements.Upper_Respiratory_Infection)


      // Episode specific ETL please check comment from the sheet shared by CRA for Episode specific


    )


  }

  //Denomnator Exclusion Criteria
  //Exclude children who are taking antibiotics in the 30 days prior to the date of the encounter during which the diagnosis was established.
  // Exclude children who had an encounter with a competing diagnosis within three days after the initial diagnosis of URI.
  // Exclude patients whose hospice care overlaps the measurement period.

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>

      isEncounterPerformedWithDischargeStatus(visit, m, ECQM154V7Elements.Encounter_Inpatient, ECQM154V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        || isEncounterPerformedWithDischargeStatus(visit, m, ECQM154V7Elements.Encounter_Inpatient, ECQM154V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        || wasInterventionPerformedInHistory(visit, m, ECQM154V7Elements.Hospice_Care_Ambulatory, patientHistoryList)

        || (
        wasMedicationActiveStartsBeforeInXDays(visit, m, ECQM154V7Elements.Upper_Respiratory_Infection, 30, CompareOperator.LESS_EQUAL, patientHistoryList, Seq(ECQM154V7Elements.Antibiotic_Medications_For_Pharyngitis))
          && wasMedicationActiveStartsBeforeInXDays(visit, m, ECQM154V7Elements.Upper_Respiratory_Infection, 1, CompareOperator.GREATER_EQUAL, patientHistoryList, Seq(ECQM154V7Elements.Antibiotic_Medications_For_Pharyngitis))
        )


        || wasDiagnosisStartsAfterElementWithinXDays(visit, m, ECQM154V7Elements.Upper_Respiratory_Infection, ECQM154V7Elements.Competing_Conditions_For_Respiratory_Conditions, 3, patientHistoryList)
    )
  }

  //Children without a prescription for antibiotic medication on or 3 days after the outpatient or ED visit for an upper respiratory infection
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      !wasDiagnosisStartsAfterElementWithinXDays(visit, m, ECQM154V7Elements.Upper_Respiratory_Infection, ECQM154V7Elements.Antibiotic_Medications_For_Pharyngitis, 3, patientHistoryList)
    )
  }

}
