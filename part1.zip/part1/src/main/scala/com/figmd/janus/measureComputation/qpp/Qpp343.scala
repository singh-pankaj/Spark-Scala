
package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP343Elements, TimeOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 343
* Measure Title              :- Screening Colonoscopy Adenoma Detection Rate
* Measure Description        :- The percentage of patients age 50 years or older with at least one conventional adenoma or
                                colorectal cancer detected during screening colonoscopy
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp343 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp343"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP343Elements.Screening_Colonoscopy
      , QPP343Elements.Colonoscopy_52_53_73_74
      , QPP343Elements.Colonoscopy_Type
      , QPP343Elements.Colon_Cancer_Screening
      , QPP343Elements.Surveillance_Colonoscopy
      , QPP343Elements.Surveillance_Colonoscopy_Grpng
      , QPP343Elements.Diagnostic_Colonoscopy
      , QPP343Elements.Diagnostic_Colonoscopy_Grpng).collect.toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Eligible IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate
      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateB, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Patients age 50 years or older undergoing a screening colonoscopy
  ----------------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      (
        isAgeAbove(visit, m, true, 50)
          && isDiagnosedDuringProcedure(visit, m, QPP343Elements.Risk_Factors_For_Colorectal_Cancer, QPP343Elements.Screening_Colonoscopy)
          && isProcedurePerformed(visit, m, QPP343Elements.Screening_Colonoscopy, patientHistoryBroadcastList)
          && !isEncounterPerformed(visit, m, QPP343Elements.Colonoscopy_52_53_73_74, patientHistoryBroadcastList)
        )
        ||
        (
          isAgeAbove(visit, m, true, 50)
            && isProcedurePerformedWithMethod(visit, m, QPP343Elements.Colonoscopy_Type, QPP343Elements.Colon_Cancer_Screening, TimeOperator.EQUAL, patientHistoryBroadcastList)
            && isDiagnosticStudyPerformedWithResultDuringProcedure(visit, m, QPP343Elements.Bowel_Prep_Quality, QPP343Elements.Colonoscopy_Type, QPP343Elements.Adequate)
            && (
            isDiagnosticStudyPerformedDuringProcedure(visit, m, QPP343Elements.Terminal_Ileum_Photographed, QPP343Elements.Colonoscopy_Type)
              || isDiagnosticStudyPerformedDuringProcedure(visit, m, QPP343Elements.Ileocecal_Valve_Photographed, QPP343Elements.Colonoscopy_Type)
              || isDiagnosticStudyPerformedDuringProcedure(visit, m, QPP343Elements.Appendiceal_Orifice_Photographed, QPP343Elements.Colonoscopy_Type)
            )
          )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Surveillance colonoscopy --- Personal history of colonic polyps, colon cancer, or other malignant
  neoplasm of rectum, rectosigmoid junction, and anus
  OR
  Diagnostic colonoscopy
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isProcedurePerformed(visit, m, QPP343Elements.Surveillance_Colonoscopy, patientHistoryBroadcastList)
        || isProcedurePerformed(visit, m, QPP343Elements.Surveillance_Colonoscopy_Grpng, patientHistoryBroadcastList)
        || isProcedurePerformed(visit, m, QPP343Elements.Diagnostic_Colonoscopy, patientHistoryBroadcastList)
        || isProcedurePerformed(visit, m, QPP343Elements.Diagnostic_Colonoscopy_Grpng, patientHistoryBroadcastList)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
  Number of patients age 50 years or older with at least one conventional adenoma or colorectal cancer detected during screening colonoscopy
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      ((isDiagnosticStudyPerformedDuringProcedure(visit, m, QPP343Elements.Detection_Of_Conventional_Adenoma_Or_Colorectal_Cancer, QPP343Elements.Screening_Colonoscopy)
        || isDiagnosedDuringProcedure(visit, m, QPP343Elements.Colorectal_Cancer, QPP343Elements.Screening_Colonoscopy)
        )
        && !isDiagnosticStudyPerformedDuringProcedure(visit, m, QPP343Elements.Adenoma__Not_Met, QPP343Elements.Screening_Colonoscopy)
        )
        || (isDiagnosedDuringProcedure(visit, m, QPP343Elements.One_Or_2_Tubular_Adenomas___10_Mm, QPP343Elements.Colonoscopy_Type)
        || isDiagnosedDuringProcedure(visit, m, QPP343Elements.Three_Or_More_Adenomas, QPP343Elements.Colonoscopy_Type)
        || isDiagnosedDuringProcedure(visit, m, QPP343Elements.Advanced_Neoplasm, QPP343Elements.Colonoscopy_Type)
        || isDiagnosedDuringProcedure(visit, m, QPP343Elements.Adenocarcinoma, QPP343Elements.Colonoscopy_Type)
        || isDiagnosedDuringProcedure(visit, m, QPP343Elements.Adenomatous_Polyp, QPP343Elements.Colonoscopy_Type)
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Documentation that neoplasm detected is only diagnosed as traditional serrated adenoma, sessile serrated polyp, or sessile serrated adenoma
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      isDiagnosticStudyPerformedDuringProcedure(visit, m, QPP343Elements.Neoplasm_Medical_Reason, QPP343Elements.Screening_Colonoscopy)
        || isDiagnosticStudyPerformedDuringProcedure(visit, m, QPP343Elements.Neoplasm_Med_Reason_Other, QPP343Elements.Screening_Colonoscopy)
        || ((isDiagnosedDuringProcedure(visit, m, QPP343Elements.Serrated_Lesions, QPP343Elements.Colonoscopy_Type)
        || isDiagnosedDuringProcedure(visit, m, QPP343Elements.Sessile_Serrated_Polyp_With_Dysplasia, QPP343Elements.Colonoscopy_Type)
        || isDiagnosedDuringProcedure(visit, m, QPP343Elements.Sessile_Serrated_Polyp_S__With_No_Dysplasia, QPP343Elements.Colonoscopy_Type)
        )
        && !(isDiagnosedDuringProcedure(visit, m, QPP343Elements.One_Or_2_Tubular_Adenomas___10_Mm, QPP343Elements.Colonoscopy_Type)
        || isDiagnosedDuringProcedure(visit, m, QPP343Elements.Three_Or_More_Adenomas, QPP343Elements.Colonoscopy_Type)
        || isDiagnosedDuringProcedure(visit, m, QPP343Elements.Advanced_Neoplasm, QPP343Elements.Colonoscopy_Type)
        || isDiagnosedDuringProcedure(visit, m, QPP343Elements.Adenocarcinoma, QPP343Elements.Colonoscopy_Type)
        || isDiagnosedDuringProcedure(visit, m, QPP343Elements.Adenomatous_Polyp, QPP343Elements.Colonoscopy_Type)
        )
        )
    )
  }
}
