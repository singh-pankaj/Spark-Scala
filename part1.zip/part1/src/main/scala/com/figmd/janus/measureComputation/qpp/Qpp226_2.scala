package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, QPP226Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 226
* Measure Title              :- Preventive Care and Screening: Tobacco Use: Screening and Cessation Intervention
* Measure Description        :- "Percentage of patients aged 18 years and older who were screened for tobacco use one or more times within 24 months
                                 AND who received tobacco cessation intervention if identified as a tobacco user
                                Three rates are reported:
                                a. Percentage of patients aged 18 years and older who were screened for tobacco use one or more times within 24 months
                                b. Percentage of patients aged 18 years and older who were screened for tobacco use and identified as a tobacco user who received tobacco cessation intervention
                                c. Percentage of patients aged 18 years and older who were screened for tobacco use one or more times within 24 months AND who received tobacco cessation intervention if identified as a tobacco user"
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 3
* Measure Stratum No.        :- 2
* Measure Stratification     :- 3
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp226_2 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp226_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    //Backtracking List
    val patientHistoryListRDD = getPatientHistory(sparkSession, initialRDD,
      QPP226Elements.Health___Behavioral_Assessment___Individual,
      QPP226Elements.Health_And_Behavioral_Assessment___Initial,
      QPP226Elements.Health_And_Behavioral_Assessment__Reassessment,
      QPP226Elements.Home_Healthcare_Services,
      QPP226Elements.Occupational_Therapy_Evaluation,
      QPP226Elements.Office_Visit,
      QPP226Elements.Ophthalmological_Services,
      QPP226Elements.Psych_Visit___Diagnostic_Evaluation,
      QPP226Elements.Psych_Visit___Psychotherapy,
      QPP226Elements.Psychoanalysis,
      QPP226Elements.Speech_And_Hearing_Evaluation,
      QPP226Elements.Annual_Wellness_Visit,
      QPP226Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
      QPP226Elements.Preventive_Care_Services___Group_Counseling,
      QPP226Elements.Preventive_Care_Services___Other,
      QPP226Elements.Preventive_Care_Services_Individual_Counseling,
      QPP226Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
      QPP226Elements.Screened_For_Tobacco_Use_And_Identified_Tobacco_User,
      QPP226Elements.Screened_For_Tobacco_Use_And_Identified_Tobacco_Non_User,
      QPP226Elements.Tobacco_Screening_Reason_Unspecified,
      QPP226Elements.Tobacco_Use_Screening,
      QPP226Elements.Tobacco_User,
      QPP226Elements.Medical_Reason,
      QPP226Elements.Tobacco_Use_Cessation_Counseling,
      QPP226Elements.Tobacco_Use_Cessation_Pharmacotherapy,
      QPP226Elements.Limited_Life_Expectancy)
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryListRDD.collect.toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList, patientHistoryListRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Mostrecent Patient History List
      val patientHistoryMostRecentBroadcastList: Broadcast[List[CassandraRow]] =
        sparkSession.sparkContext
          .broadcast(mostRecentPatientList(patientHistoryListRDD, QPP226Elements.Tobacco_Use_Screening))

      // Filter IPP
      val denominatorRDD = getDenominator(ippRDD, patientHistoryMostRecentBroadcastList, patientHistoryBroadcastList)
      denominatorRDD.cache()


      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryMostRecentBroadcastList, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate
      val intermediateException = getSubtractRDD(ippRDD, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateException, patientHistoryMostRecentBroadcastList, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      patientHistoryMostRecentBroadcastList.destroy()
    }

  }


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], patientHistoryListRdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val countElementList2: List[(String, Int)] = countElement(patientHistoryListRdd, m,
      QPP226Elements.Health___Behavioral_Assessment___Individual,
      QPP226Elements.Health_And_Behavioral_Assessment___Initial,
      QPP226Elements.Health_And_Behavioral_Assessment__Reassessment,
      QPP226Elements.Home_Healthcare_Services,
      QPP226Elements.Occupational_Therapy_Evaluation,
      QPP226Elements.Office_Visit,
      QPP226Elements.Ophthalmological_Services,
      QPP226Elements.Psych_Visit___Diagnostic_Evaluation,
      QPP226Elements.Psych_Visit___Psychotherapy,
      QPP226Elements.Psychoanalysis,
      QPP226Elements.Speech_And_Hearing_Evaluation)

    val countElementList1: List[(String, Int)] = countElement(patientHistoryListRdd, m,
      QPP226Elements.Annual_Wellness_Visit,
      QPP226Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
      QPP226Elements.Preventive_Care_Services___Group_Counseling,
      QPP226Elements.Preventive_Care_Services___Other,
      QPP226Elements.Preventive_Care_Services_Individual_Counseling,
      QPP226Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && (
        getEncounterCountFromHistory(visit, m, 2, true, countElementList2)
          || getEncounterCountFromHistory(visit, m, 1, true, countElementList1)
        )
        && !isVisitTypeIn(visit, m, QPP226Elements.Health_And_Behavioral_Assessment_Reassessment_Telehealth_Modifier,
        QPP226Elements.Health_And_Behavioral_Assessment__Initial_Telehealth_Modifier,
        QPP226Elements.Health_And_Behavioral_Assessment___Individual_Telehealth_Modifier,
        QPP226Elements.Home_Healthcare_Services_Telehealth_Modifier,
        QPP226Elements.Office_Visit_Telehealth_Modifier,
        QPP226Elements.Ophthalmological_Services_Telehealth_Modifier,
        QPP226Elements.Psych_Visit___Diagnostic_Evaluation_Telehealth_Modifier,
        QPP226Elements.Psych_Visit___Psychotherapy_Telehealth_Modifier,
        QPP226Elements.Psychoanalysis_Telehealth_Modifier,
        QPP226Elements.Speech_And_Hearing_Evaluation_Telehealth_Modifier,
        QPP226Elements.Preventive_Care_Services___Established_Office_Visit_18_And_Up_Telehealth_Modifier,
        QPP226Elements.Preventive_Care_Services___Group_Counseling_Telehealth_Modifier,
        QPP226Elements.Preventive_Care_Services___Other_Telehealth_Modifier,
        QPP226Elements.Preventive_Care_Services_Individual_Counseling_Telehealth_Modifier,
        QPP226Elements.Preventive_Care_Services_Initial_Office_Visit_18_And_Up_Telehealth_Modifier,
        QPP226Elements.Annual_Wellness_Visit_Telehealth_Modifier,
        QPP226Elements.Occupational_Therapy_Evaluation_Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP226Elements.Pos_02))
  }

  def getDenominator(ippRDD: RDD[CassandraRow], patientHistoryMostRecentBroadcastList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      wasPatientTobaccoUserWithin24Months(visit, m, QPP226Elements.Tobacco_Use_Screening, QPP226Elements.Tobacco_User, 24, patientHistoryMostRecentBroadcastList, patientHistoryList)
        || wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP226Elements.Screened_For_Tobacco_Use_And_Identified_Tobacco_User, 24, patientHistoryList))
  }

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryMostRecentBroadcastList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        ((tobaccoCessationInterventionDoneAfterTobaccoScreeningUser(visit, m, QPP226Elements.Tobacco_Use_Cessation_Counseling_Date, QPP226Elements.Tobacco_Use_Screening, QPP226Elements.Tobacco_User, 24, patientHistoryMostRecentBroadcastList, patientHistoryList)
          && TobaccoCessationInterventionDoneBeforeEndDate(visit, m, QPP226Elements.Tobacco_Use_Cessation_Counseling, patientHistoryList))
          || (tobaccoCessationInterventionDoneAfterTobaccoScreeningUser(visit, m, QPP226Elements.Tobacco_Use_Cessation_Pharmacotherapy_Date, QPP226Elements.Tobacco_Use_Screening, QPP226Elements.Tobacco_User, 24, patientHistoryMostRecentBroadcastList, patientHistoryList)
          && TobaccoCessationInterventionDoneBeforeEndDate(visit, m, QPP226Elements.Tobacco_Use_Cessation_Pharmacotherapy, patientHistoryList))
          || (tobaccoCessationInterventionDoneAfterTobaccoScreeningUser(visit, m, QPP226Elements.Cessation_Intervention_For_Tobacco_User_Date, QPP226Elements.Tobacco_Use_Screening, QPP226Elements.Tobacco_User, 24, patientHistoryMostRecentBroadcastList, patientHistoryList)
          && TobaccoCessationInterventionDoneBeforeEndDate(visit, m, QPP226Elements.Cessation_Intervention_For_Tobacco_User, patientHistoryList)))

          && !wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP226Elements.Cessation_Intervention_Reason_Unspecified, 24, patientHistoryList)))
  }

  def getExceptionRDD(intermediateRdd: RDD[CassandraRow], patientHistoryMostRecentList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateRdd.filter(visit =>
      wasDiagnosedInHistory(visit, m, QPP226Elements.Limited_Life_Expectancy, patientHistoryList)
        || wasCounselingNotPerformedAfterTobaccoScreeningUser(visit, m, QPP226Elements.Medical_Reason_Date, QPP226Elements.Tobacco_Use_Screening, QPP226Elements.Tobacco_User, 24, patientHistoryMostRecentList, patientHistoryList)
        || wasMedicationNotOrderedAfterTobaccoScreeningUser(visit, m, QPP226Elements.Medical_Reason_Date, QPP226Elements.Tobacco_Use_Screening, QPP226Elements.Tobacco_User, 24, patientHistoryMostRecentList, patientHistoryList)
        || isInterventionPerformedDuringEncounter(visit, m, QPP226Elements.Cessation_Intervention_Medical_Reason)
    )
  }
}


