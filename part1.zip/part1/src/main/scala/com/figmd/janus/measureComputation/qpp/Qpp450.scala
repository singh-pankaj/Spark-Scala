package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, CompareOperator, MeasureProperty, QPP450Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 450
* Measure Title              :- Trastuzumab Received By Patients With AJCC Stage I (T1c) – III And HER2 Positive Breast Cancer Receiving Adjuvant Chemotherapy
* Measure Description        :- Proportion of female patients (aged 18 years and older) with AJCC stage I (T1c) – III, human epidermal growth factor receptor
 *                              2 (HER2) positive breast cancer receiving adjuvant chemotherapy who are also receiving trastuzumab
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp450 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp450"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP450Elements.Office_Visit,
      QPP450Elements.Breast_Cancer,
      QPP450Elements.Breast_Adjuvant_Chemotherapy,
      QPP450Elements.Adjuvant_Chemotherapy_Breast,
      QPP450Elements.Cancer_Stage_Iib,
      QPP450Elements.Cancer_Stage_Iiia,
      QPP450Elements.Cancer_Stage_Iii,
      QPP450Elements.Cancer_Stage_Ii,
      QPP450Elements.Cancer_Stage_Iia,
      QPP450Elements.Cancer_Stage_Iiib,
      QPP450Elements.Cancer_Stage_Iiic,
      QPP450Elements.Ajcc_Stage_Ii__Breast_Cancer,
      QPP450Elements.Ajcc_Stage_Iii__Breast_Cancer,
      QPP450Elements.Ajcc_Stage_I__Breast_Cancer,
      QPP450Elements.Metastatic_Disease,
      QPP450Elements.Metastatic_Cancer,
      QPP450Elements.Transfer_To_Practice_After_Initiation_Of_Chemotherapy,
      QPP450Elements.Transfer_To_Practice_After_Initial_Chemotherapy,
      QPP450Elements.Transfer_To_Practice,
      QPP450Elements.Chemotherapy_Initiation,
      QPP450Elements.Trastuzumab,
      QPP450Elements.Trastuzumab_Administration,
      QPP450Elements.Trastuzumab_Not_Met,
      QPP450Elements.Trastuzumab__Exceptions,
      QPP450Elements.Patient_Declined,
      QPP450Elements.Contraindication,
      QPP450Elements.Patient_Died,
      QPP450Elements.Neoadjuvant_Chemotherapy_Or_Radiation__Incomplete,
      QPP450Elements.Patient_Transferred
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      val denominatorRDD=ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateB=getSubtractRDD(intermediateA,metRDD)
          intermediateB.cache()
      // Filter Exceptions
      val exceptionRDD = getException(intermediateB, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Adult women with AJCC stage I (T1c) – III, HER2 positive breast cancer who receive adjuvant chemotherapy.
----------------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val officeVisits = countElement(patientHistoryRDD, m, QPP450Elements.Office_Visit)

    initialRDD.filter(visit =>
      isFemale(visit, m)
        && isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m, QPP450Elements.Office_Visit)
        && isDiagnosisWithBeforeEnd(visit, m, QPP450Elements.Breast_Cancer, patientHistoryList)
        && getEncounterCountFromHistory(visit, m, 2, true, officeVisits)
        && (
        isAssesmentPerformedBeforeEnd(visit, m, QPP450Elements.Breast_Adjuvant_Chemotherapy, patientHistoryList)
          || wasMedicationAdministeredBeforeOrEqualEncounter(visit, m, QPP450Elements.Adjuvant_Chemotherapy_Breast, patientHistoryList)
        )
        && (
        isAssessmentPerformed(visit, m, QPP450Elements.Her_2_Neu_Positive_1, patientHistoryList)
          || isAssessmentPerformed(visit, m, QPP450Elements.Her_2_Neu_Positive_2, patientHistoryList)
          || wasLaboratoryTestPerformedValueBeforeOrEqualEncounter(visit, m, QPP450Elements.Single_Probe_Average_Her2_Copy_Number, 6, CompareOperator.EQUAL, patientHistoryList)
          || (wasLaboratoryTestPerformedValueBeforeOrEqualEncounter(visit, m, QPP450Elements.Dual_Probe_Her2_Cep17_Ratio, 6, CompareOperator.EQUAL, patientHistoryList)
          && wasLaboratoryTestPerformedValueBeforeOrEqualEncounter(visit, m, QPP450Elements.Her2_Copy_Number, 4, CompareOperator.LESS_EQUAL, patientHistoryList))
          || (wasLaboratoryTestPerformedValueBeforeOrEqualEncounter(visit, m, QPP450Elements.Dual_Probe_Her2_Cep17_Ratio, 2, CompareOperator.LESS, patientHistoryList)
          && wasLaboratoryTestPerformedValueBeforeOrEqualEncounter(visit, m, QPP450Elements.Her2_Copy_Number, 6, CompareOperator.EQUAL, patientHistoryList))
        )
        && ((
        isAssessmentPerformed(visit, m, QPP450Elements.Ajcc_Stage_Ii_Or_Iii__Breast_Cancer, patientHistoryList)
          || isAssessmentPerformed(visit, m, QPP450Elements.Breast_Cancer_Ajcc_Stage_I__Ia_Or_Ib__And_T_Stage_Does_Not_Equal_T1_T1a_T1b, patientHistoryList)
        )
        || (
        wasAssessmentPerformedAfterDiagnosis(visit, m, QPP450Elements.Breast_Cancer, patientHistoryList, QPP450Elements.Cancer_Stage_Iib,
          QPP450Elements.Cancer_Stage_Iiia,
          QPP450Elements.Cancer_Stage_Iii,
          QPP450Elements.Cancer_Stage_Ii,
          QPP450Elements.Cancer_Stage_Iia,
          QPP450Elements.Cancer_Stage_Iiib,
          QPP450Elements.Cancer_Stage_Iiic,
          QPP450Elements.Ajcc_Stage_Ii__Breast_Cancer,
          QPP450Elements.Ajcc_Stage_Iii__Breast_Cancer)
          || wasAssessmentPerformedAfterDiagnosis(visit, m, QPP450Elements.Breast_Cancer, patientHistoryList, QPP450Elements.Ajcc_Stage_I__Breast_Cancer)
        )
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Patient transfer to practice after initiation of chemotherapy
  OR
  Patient has metastatic disease at diagnosis
----------------------------------------------------------------------------------------------------------------------------*/

  // Denominator Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (
        wasDiagnosisWithDiagnosisInHistory(visit, m, QPP450Elements.Metastatic_Disease, QPP450Elements.Breast_Cancer, patientHistoryList)
          || wasDiagnosisWithDiagnosisInHistory(visit, m, QPP450Elements.Metastatic_Cancer, QPP450Elements.Breast_Cancer, patientHistoryList)
        )
        || isTransfered(visit, m, QPP450Elements.Transfer_To_Practice_After_Initiation_Of_Chemotherapy, patientHistoryList)
        || isTransfered(visit, m, QPP450Elements.Transfer_To_Practice_After_Initial_Chemotherapy, patientHistoryList)
        || wasTransferedAfterProcedureInHistory(visit, m, QPP450Elements.Transfer_To_Practice, patientHistoryList, QPP450Elements.Chemotherapy_Initiation)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Trastuzumab administered within 12 months of diagnosis
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        isAssessmentPerformed(visit, m, QPP450Elements.Trastuzumab, patientHistoryList)
          || wasMedicationAfterXMonthsDiagnosis(visit, m, QPP450Elements.Trastuzumab_Administration, QPP450Elements.Breast_Cancer, 12, patientHistoryList)
        )
        && !isMedicationAdministered(visit, m, QPP450Elements.Trastuzumab_Not_Met, patientHistoryList)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Reason for not administering Trastuzumab documented (e.g. patient declined, patient died, patient transferred, contraindication or other clinical exclusion, neoadjuvant chemotherapy or radiation NOT complete)
----------------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      !isMedicationAdministered(visit, m, QPP450Elements.Trastuzumab__Exceptions, patientHistoryList)
        || (
        wasCommunicationStartsAfterDiagnosisInHistory(visit, m, QPP450Elements.Patient_Declined, patientHistoryList, QPP450Elements.Breast_Cancer)
          || wasMedicationAdministeredAfterDiagnosisInHistory(visit, m, QPP450Elements.Contraindication, patientHistoryList, QPP450Elements.Breast_Cancer)
          || wasCommunicationStartsAfterDiagnosisInHistory(visit, m, QPP450Elements.Patient_Died, patientHistoryList, QPP450Elements.Breast_Cancer)
          || wasProcedurePerformedAfterDiagnosisInHistory(visit, m, QPP450Elements.Neoadjuvant_Chemotherapy_Or_Radiation__Incomplete, patientHistoryList, QPP450Elements.Breast_Cancer)
          || wasTransferedToAfterDiagnosisInHistory(visit, m, QPP450Elements.Patient_Transferred, patientHistoryList, QPP450Elements.Breast_Cancer)
        )

    )
  }
}

