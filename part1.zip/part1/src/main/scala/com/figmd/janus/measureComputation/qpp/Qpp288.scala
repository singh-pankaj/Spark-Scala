package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP288Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 288
* Measure Title              :- Dementia: Education and Support of Caregivers for Patients with Dementia
* Measure Description        :- Percentage of patients with dementia whose caregiver(s) were provided with education on
*                               dementia disease management and health behavior changes AND were referred to additional
*                               resources for support in the last 12 months
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp288 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp288"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Backtracking List
      val patientHistoryList = getPatientHistory(sparkSession, initialRDD, QPP288Elements.Education_To_Caregiver,
        QPP288Elements.Education_Caregivers,
        QPP288Elements.Referral_To_Other_Resources,
        QPP288Elements.Educaregiver_Reason_Not_Specified
      ).collect.toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exclusion
      val exceptionRDD = getExceptionRdd(metRDD, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(metRDD, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // All patients with dementia
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isDiagnosedOnEncounter(visit, m, QPP288Elements.Dementia)
        &&
        isVisitTypeIn(visit, m,
          QPP288Elements.Office_Visit,
          QPP288Elements.Nursing_Facility_Visit,
          QPP288Elements.Home_Healthcare_Services,
          QPP288Elements.Psych_Visit,
          QPP288Elements.Behavioral_Neuropsych_Assessment,
          QPP288Elements.Health_And_Behavioral_Assessment___Initial,
          QPP288Elements.Health___Behavioral_Assessment___Individual,
          QPP288Elements.Care_Services_In_Long_Term_Residential_Facility,
          QPP288Elements.Health_And_Behavioral_Assessment__Reassessment,
          QPP288Elements.Home_Visit,
          QPP288Elements.Health_And_Behavior_Intervention,
          QPP288Elements.Chronic_Care_Management,
          QPP288Elements.Advance_Care_Planning,
          QPP288Elements.Individual_Physician_Supervision
        )

        && !isTeleHealthModifier(visit, m,
        QPP288Elements.Nursing_Facility_Visit_Telehealth_Modifier,
        QPP288Elements.Home_Healthcare_Services_Telehealth_Modifier,
        QPP288Elements.Health_And_Behavioral_Assessment_Reassessment_Telehealth_Modifier,
        QPP288Elements.Behavioral_Neuropsych_Assessment_Telehealth_Modifier,
        QPP288Elements.Health_And_Behavioral_Assessment__Initial_Telehealth_Modifier,
        QPP288Elements.Health_And_Behavioral_Assessment___Individual_Telehealth_Modifier,
        QPP288Elements.Office_Visit_Telehealth_Modifier,
        QPP288Elements.Psych_Visit_Telehealth_Modifier,
        QPP288Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier,
        QPP288Elements.Home_Visit_Telehealth_Modifier,
        QPP288Elements.Health_And_Behavior_Intervention_Telehealth_Modifier,
        QPP288Elements.Chronic_Care_Management_Telehealth_Modifier,
        QPP288Elements.Advance_Care_Planning_Telehealth_Modifier,
        QPP288Elements.Individual_Physician_Supervision_Telehealth_Modifier
      )
        && isPOSEncounterNotPerformed(visit, m, QPP288Elements.Pos_02)

    )

  }


  // Patients with dementia whose caregiver(s) were provided with education on dementia disease management and
  //health behavior changes AND were referred to additional resources for support in the last 12 months
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        (
          wasCommunicationDoneFromProviderToPatientBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP288Elements.Education_To_Caregiver, 12, patientHistoryBroadcastList)
            || wasCommunicationDoneFromProviderToPatientBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP288Elements.Education_Caregivers, 12, patientHistoryBroadcastList)
          )
          ||
          (
            wasCommunicationDoneFromProviderToPatientBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP288Elements.Referral_To_Other_Resources, 12, patientHistoryBroadcastList)
              &&
              (
                wasCommunicationDoneFromProviderToPatientBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP288Elements.Education_To_Caregiver, 12, patientHistoryBroadcastList)
                  || wasCommunicationDoneFromProviderToPatientBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP288Elements.Education_Caregivers, 12, patientHistoryBroadcastList)
                )
            )
        )
        && !wasCommunicationDoneFromProviderToPatientBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP288Elements.Educaregiver_Reason_Not_Specified, 12, patientHistoryBroadcastList)

    )
  }

  // Documentation of medical reason(s) for not providing the caregiver with education on disease management
  // and health behavior changes or referring to additional sources for support (eg, patient does not have a caregiver, other medical reason).
  def getExceptionRdd(intermediateException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      isCommunicationFromProviderToPatientOnEncounterNotDone(visit, m, QPP288Elements.Educaregiver_Medical_Reason)
        || isCommunicationFromProviderToPatientOnEncounterNotDone(visit, m, QPP288Elements.Caregiver_Not_Available)
    )

  }

}
