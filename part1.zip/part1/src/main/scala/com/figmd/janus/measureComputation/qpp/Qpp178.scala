package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP178Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 178
* Measure Title              :- Rheumatoid Arthritis (RA): Functional Status Assessment
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of rheumatoid arthritis (RA)
                                for whom a functional status assessment was performed at least once within 12 months.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp178 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp178"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //Backtracking List
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP178Elements.Active_Rheumatoid_Arthritis,
      QPP178Elements.Functional_Status_Assessment_For_Ra,
      QPP178Elements.Activities_Of_Daily_Living,
      QPP178Elements.Functional_Status_Assessment,
      QPP178Elements.Funcstsassesmnt_Reason_Not_Specified
    )
    val patientHistoryList = patientHistoryRDD.collect().toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)
    val leastRecentElementsBroadcastList = sparkSession.sparkContext.broadcast(leastRecentPatientList(patientHistoryRDD, QPP178Elements.Active_Rheumatoid_Arthritis))

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList, leastRecentElementsBroadcastList)
      metRDD.cache()

      val intermediateB = getSubtractRDD(ippRDD, metRDD)
      intermediateB.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      leastRecentElementsBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : All patients aged 18 years and older with a diagnosis of RA
----------------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m, QPP178Elements.Office_Visit, QPP178Elements.Home_Healthcare_Services, QPP178Elements.Initial_Preventive_Physical_Examination)
        && isDiagnosedWithBeforeOrEqual(visit, m, AdminElements.Encounter_Date, patientHistoryBroadcastList, QPP178Elements.Active_Rheumatoid_Arthritis)
        && !isTeleHealthEncounterNotPerformed(visit, m, QPP178Elements.Initial_Preventive_Physical_Examination_Telehealth_Modifier,
        QPP178Elements.Office_Visit_Telehealth_Modifier, QPP178Elements.Home_Healthcare_Services_Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP178Elements.Pos_02)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Patients for whom a standardized functional status assessment was performed at least once within 12 months
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], leastRecentElementsBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)


    ipp.filter(visit =>
      (isInterventionPerformedStartsAfterDiagnosis(visit, m, QPP178Elements.Functional_Status_Assessment_For_Ra, QPP178Elements.Active_Rheumatoid_Arthritis, leastRecentElementsBroadcastList, patientHistoryBroadcastList)
        && wasInterventionPerformedStartsBeforeEncounter(visit, m, AdminElements.Encounter_Date, QPP178Elements.Functional_Status_Assessment_For_Ra, 12, patientHistoryBroadcastList)
        )
        || (isPatientCareExperiencePerformedStartsAfterDiagnosis(visit, m, QPP178Elements.Activities_Of_Daily_Living, QPP178Elements.Active_Rheumatoid_Arthritis, leastRecentElementsBroadcastList, patientHistoryBroadcastList)
        && wasPatientCareExperiencePerformedStartsBeforeEncounter(visit, m, AdminElements.Encounter_Date, QPP178Elements.Activities_Of_Daily_Living, 12, patientHistoryBroadcastList)
        )
        || (isInterventionPerformedStartsAfterDiagnosis(visit, m, QPP178Elements.Functional_Status_Assessment, QPP178Elements.Active_Rheumatoid_Arthritis, leastRecentElementsBroadcastList, patientHistoryBroadcastList)
        && wasInterventionPerformedStartsBeforeEncounter(visit, m, AdminElements.Encounter_Date, QPP178Elements.Functional_Status_Assessment, 12, patientHistoryBroadcastList)
        )
        && !(isInterventionPerformedStartsAfterDiagnosis(visit, m, QPP178Elements.Funcstsassesmnt_Reason_Not_Specified, QPP178Elements.Active_Rheumatoid_Arthritis, leastRecentElementsBroadcastList, patientHistoryBroadcastList)
        && wasInterventionPerformedStartsBeforeEncounter(visit, m, AdminElements.Encounter_Date, QPP178Elements.Funcstsassesmnt_Reason_Not_Specified, 12, patientHistoryBroadcastList)
        )
    )
  }
}
