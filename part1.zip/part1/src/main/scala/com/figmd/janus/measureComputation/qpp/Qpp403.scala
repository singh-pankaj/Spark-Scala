package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP403Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp 403
* Measure Title              :- Adult Kidney Disease: Referral to Hospice
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of ESRD who withdraw from hemodialysis or peritoneal dialysis who are referred to hospice care
* Calculation Implementation :- Patient specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp403 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp403"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP403Elements.End_Stage_Renal_Disease,
      QPP403Elements.Discontinue_Hemodialysis_Or_Peritoneal_Dialysis,
      QPP403Elements.Discontinue_Hemo_Or_Peri_Dialysis,
      QPP403Elements.Hospice_Care,
      QPP403Elements.Ref_Hospice_Care
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      //
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Exceptions
      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateRdd = getSubtractRDD(denominatorRDD, metRDD)

      // Filter not Exception
      val exceptionRDD = getException(intermediateRdd, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRdd, exceptionRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  // IPP-Denominator criteria
  /* All patients aged 18 years and older with a diagnosis of ESRD who withdraw from hemodialysis or peritoneal dialysis */

  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m, QPP403Elements.Transitional_Care_Management,
        QPP403Elements.Care_Services_In_Long_Term_Residential_Facility,
        QPP403Elements.Home_Healthcare_Services,
        QPP403Elements.Hospital_Inpatient_Visit___Initial,
        QPP403Elements.Office_Visit,
        QPP403Elements.Nursing_Facility_Visit
      )
        && isDiagnosedWithInHistory(visit, m, QPP403Elements.End_Stage_Renal_Disease, patientHistoryBroadcastList)
        && (wasProcedurePerformedAfterDiagnosisInHistory(visit, m, QPP403Elements.Discontinue_Hemodialysis_Or_Peritoneal_Dialysis, patientHistoryBroadcastList, QPP403Elements.End_Stage_Renal_Disease)
        && wasProcedurePerformedAfterDiagnosisInHistory(visit, m, QPP403Elements.Discontinue_Hemo_Or_Peri_Dialysis, patientHistoryBroadcastList, QPP403Elements.End_Stage_Renal_Disease)
        )
        &&
        (isProcedurePerformed(visit, m, QPP403Elements.Discontinue_Hemodialysis_Or_Peritoneal_Dialysis, patientHistoryBroadcastList)
          && isProcedurePerformed(visit, m, QPP403Elements.Discontinue_Hemo_Or_Peri_Dialysis, patientHistoryBroadcastList)
        )
    )
  }


  // Numerator criteria
  /* Patients who are referred to hospice care*/

  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ipp.filter(visit =>
      (
        isInterventionOrder(visit, m, QPP403Elements.Hospice_Care, patientHistoryBroadcastList)
          && isInterventionOrder(visit, m, QPP403Elements.Ref_Hospice_Care, patientHistoryBroadcastList)
        )
        && !isInterventionOrderedAfterDiagnosis(visit, m, QPP403Elements.Hospice_Care_Not_Met, QPP403Elements.End_Stage_Renal_Disease, patientHistoryBroadcastList)
    )
  }

  // Exception criteria
  /* Documentation of patient reason(s) for not referring to hospice care (e.g., patient declined, other patient reasons)*/

  def getException(intermediate: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediate.filter(visit =>
      (
        !isInterventionOrderedAfterDiagnosis(visit, m, QPP403Elements.Hospice_Care_Not_Met, QPP403Elements.End_Stage_Renal_Disease, patientHistoryBroadcastList)
          || !isInterventionOrderedAfterDiagnosis(visit, m, QPP403Elements.Patient_Reason, QPP403Elements.End_Stage_Renal_Disease, patientHistoryBroadcastList)
        )
        && !isCommunicationFromPatientToProviderDoneAfterDiagnosis(visit, m, QPP403Elements.Patient_Declines, QPP403Elements.End_Stage_Renal_Disease, patientHistoryBroadcastList)
    )
  }

}
