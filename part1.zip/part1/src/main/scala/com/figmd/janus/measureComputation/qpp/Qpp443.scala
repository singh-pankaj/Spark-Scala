package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 443
* Measure Title              :- Non-Recommended Cervical Cancer Screening in Adolescent Females
* Measure Description        :- The percentage of adolescent females 16–20 years of age who were screened unnecessarily for cervical cancer
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp443 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp443"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {
      //getPatientHistoryList
      val patientHistoryList = getPatientHistory(sparkSession, ippRDD
        , QPP443Elements.History_Of_Cervical_Cancer_Hiv_Or_Immunodeficiencygrp
        , QPP443Elements.Hiv
        , QPP443Elements.Immunodeficient_Conditions
        , QPP443Elements.Cervical_Cancer_1
        , QPP443Elements.Hospice_Care
        , QPP443Elements.Hospice_Services_Snomedct
        , QPP443Elements.Cervical_Cytology_Or_Hpv
        , QPP443Elements.Hpv_Test
        , QPP443Elements.Cervical_Cytology
        , QPP443Elements.Cervical_Cytology_Grp
        , QPP443Elements.Hpv_Test_Cpt_Grp
        , QPP443Elements.Encounter_Screening_For_Hpv_Grp
        , QPP443Elements.Crvcyt__Not_Met
      ).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  //IPP-Denominator criteria
  /*--------------------------------------------------------------------------------------------------------------------
   Adolescent females 16-20 years of age with a visit during the measurement period
  --------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isFemale(visit, m)
        &&
        isAgeBetween(visit, m, 16, CompareOperator.GREATER_EQUAL, 21, CompareOperator.LESS)
        &&
        isVisitTypeIn(visit, m
          , QPP443Elements.Annual_Wellness_Visit
          , QPP443Elements.Office_Visit
          , QPP443Elements.Initial_Preventive_Physical_Examination
        )
    )
  }


  // Denominator Exclusion criteria
  /*--------------------------------------------------------------------------------------------------------------------
  	A history of cervical cancer, HIV, or immunodeficiency any time during the patientâ€™s history through the end of the measurement period.
   OR Patients who use hospice services any time during the measurement period
 --------------------------------------------------------------------------------------------------------------------*/
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      wasDiagnosisInHistory(visit, m, QPP443Elements.History_Of_Cervical_Cancer_Hiv_Or_Immunodeficiencygrp, patientHistoryBroadcastList)
        ||
        wasDiagnosisInHistory(visit, m, QPP443Elements.Hiv, patientHistoryBroadcastList)
        ||
        wasDiagnosisInHistory(visit, m, QPP443Elements.Immunodeficient_Conditions, patientHistoryBroadcastList)
        ||
        wasDiagnosisInHistory(visit, m, QPP443Elements.Cervical_Cancer_1, patientHistoryBroadcastList)
        ||
        isInterventionPerformed(visit, m, QPP443Elements.Hospice_Services, patientHistoryBroadcastList)
        ||
        wasInterventionPerformedOrOrderedInHistory(visit, m, QPP443Elements.Hospice_Care, patientHistoryBroadcastList)
        ||
        wasInterventionPerformedOrOrderedInHistory(visit, m, QPP443Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
    )
  }


  // Numerator Criteria
  /*--------------------------------------------------------------------------------------------------------------------
  Patients who received cervical cytology or an HPV test during the measurement period
 --------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        isAssessmentPerformed(visit, m, QPP443Elements.Cervical_Cytology_Or_Hpv, patientHistoryBroadcastList)
          ||
          isLaboratoryTestOrder(visit, m, QPP443Elements.Hpv_Test, patientHistoryBroadcastList)
          ||
          isLaboratoryTestOrder(visit, m, QPP443Elements.Cervical_Cytology, patientHistoryBroadcastList)
          ||
          isProcedurePerformed(visit, m, QPP443Elements.Cervical_Cytology_Grp, patientHistoryBroadcastList)
          ||
          isProcedurePerformed(visit, m, QPP443Elements.Hpv_Test_Cpt_Grp, patientHistoryBroadcastList)
          ||
          isDiagnosis(visit, m, QPP443Elements.Encounter_Screening_For_Hpv_Grp, patientHistoryBroadcastList)
        )
        && !isAssessmentPerformed(visit, m, QPP443Elements.Crvcyt__Not_Met, patientHistoryBroadcastList)
    )
  }


}

