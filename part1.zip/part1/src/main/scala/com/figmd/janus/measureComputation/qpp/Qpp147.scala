package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP147Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*--------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 147
* Measure Title              :- Nuclear Medicine: Correlation with Existing Imaging Studies for All Patients Undergoing Bone Scintigraphy
* Measure Description        :- Percentage of final reports for all patients, regardless of age, undergoing bone scintigraphy that include physician documentation of correlation with
                                existing relevant imaging studies (e.g., x-ray, MRI, CT, etc.) that were performed.
* Calculation Implementation :- procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp147 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp147"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession,initialRDD,
      QPP147Elements.Bone_Scintigraphy,
      QPP147Elements.Correlation_Existing_Study,
      QPP147Elements.Correlation_Imaging_Study,
      QPP147Elements.Correspond_Anatomic_Site,
      QPP147Elements.Bone__Scintigraphy_Reason_Not_Specified,
      QPP147Elements.Bone_Scintigraphy_System_Reason).collect.toList;

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    //  Filter IPP-
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      // Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateB = getSubtractRDD(ippRDD, metRDD)
      intermediateB.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateB, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : All final reports for patients, regardless of age, undergoing bone scintigraphy..
----------------------------------------------------------------------------------------------------------------------------*/


  def getIpp(rdd: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
      isProcedurePerformed(visit,m,QPP147Elements.Bone_Scintigraphy, patientHistoryBroadcastList)
    )

  }


  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Final reports that include physician documentation of correlation with existing relevant imaging studies (e.g., x-ray, MRI, CT, etc.).

----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(ipp: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    ipp.filter(visit =>

      (
            isInterventionPerformed(visit,m,QPP147Elements.Correlation_Existing_Study,patientHistoryBroadcastList)
        &&  wasInterventionPerformedAfterProcedure(visit,m,QPP147Elements.Bone_Scintigraphy,patientHistoryBroadcastList,QPP147Elements.Correlation_Existing_Study)
      )
      ||
        
      (
         (
               wasInterventionPerformedAfterProcedure(visit,m,QPP147Elements.Bone_Scintigraphy,patientHistoryBroadcastList,QPP147Elements.Correlation_Imaging_Study)
           &&  wasInterventionPerformedAfterProcedure(visit,m,QPP147Elements.Bone_Scintigraphy,patientHistoryBroadcastList,QPP147Elements.Correspond_Anatomic_Site)
         )
         &&
         (
               isInterventionPerformed(visit, m, QPP147Elements.Correlation_Imaging_Study,patientHistoryBroadcastList)
           &&  isInterventionPerformed(visit, m, QPP147Elements.Correspond_Anatomic_Site,patientHistoryBroadcastList)
         )
      )
      &&
      !(
              isInterventionPerformed(visit,m,QPP147Elements.Bone__Scintigraphy_Reason_Not_Specified,patientHistoryBroadcastList)
           && wasInterventionPerformedAfterProcedure(visit,m,QPP147Elements.Bone_Scintigraphy,patientHistoryBroadcastList,QPP147Elements.Bone__Scintigraphy_Reason_Not_Specified)
      )

    )
  }



  /*--------------------------------------------------------------------------------------------------------------------------
Denominator Exceptions : Documentation of system reason(s) for not documenting correlation with existing relevant imaging studies in final report
(e.g., no existing relevant imaging study available, patient did not have a previous relevant imaging study)

Note: Correlative studies are considered to be unavailable if relevant studies (reports and/or actual examination material) from other imaging modalities exist
but could not be obtained after reasonable efforts to retrieve the studies are made by the interpreting physician prior to the finalization of the bone scintigraphy
report.
----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermedaiateRdd: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermedaiateRdd.filter(visit =>
         isInterventionNotDone(visit,m,QPP147Elements.Bone_Scintigraphy_System_Reason,patientHistoryBroadcastList)
      && wasInterventionPerformedAfterProcedure(visit,m,QPP147Elements.Bone_Scintigraphy,patientHistoryBroadcastList,QPP147Elements.Bone_Scintigraphy_System_Reason)
    )
  }
}
