package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, _}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 397
* Measure Title              :- Melanoma Reporting
* Measure Description        :- Pathology reports for primary malignant cutaneous melanoma that include the pT category and a statement on thickness, ulceration and mitotic rate
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp397 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp397"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patient_history_list = getPatientHistory(sparkSession, initialRDD,
      QPP397Elements.Malignant_Cutaneous_Melanoma,
      QPP397Elements.Specimen_Site_Other_Than_Cutaneous,
      QPP397Elements.Specimen_Site_Other_Than_Anatomic_Cutaneous_Location,
      QPP397Elements.Pathology_Report_Medical_Reason,
      QPP397Elements.Pathology_Report_Not_Met,
      QPP397Elements.Report_For_Pt__Primary_Tumor_,
      QPP397Elements.Ulceration,
      QPP397Elements.Report_For_Mitotic_Rate_For_Primary_Tumor,
      QPP397Elements.Negative_Skin_Biopsies,
      QPP397Elements.History_Of_Melanoma,
      QPP397Elements.Medical_Reason_Melanoma_Reporting
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getexceptionRDD(intermediateA, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //All melanoma pathology reports for primary malignant cutaneous melanoma.
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isLaboratoryTestPerformedOnEncounter(visit, m, QPP397Elements.Level_Iv___Surgical_Pathology_Examination)
        && wasDiagnosisAfterOrConcurentWithProcedure(visit, m, QPP397Elements.Level_Iv___Surgical_Pathology_Examination, patientHistoryBroadcastList, QPP397Elements.Malignant_Cutaneous_Melanoma)

    )
  }

  //Specimen site other than anatomic cutaneous location
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (
        isDiagnosticStudyPerformed(visit, m, QPP397Elements.Specimen_Site_Other_Than_Cutaneous, patientHistoryBroadcastList)
          && wasDiagnosedBefore(visit, m, QPP397Elements.Level_Iv___Surgical_Pathology_Examination_Date, QPP397Elements.Specimen_Site_Other_Than_Cutaneous, patientHistoryBroadcastList)
        )
        ||
        (
          isDiagnosticStudyPerformed(visit, m, QPP397Elements.Specimen_Site_Other_Than_Anatomic_Cutaneous_Location, patientHistoryBroadcastList)
            && wasDiagnosedBefore(visit, m, QPP397Elements.Level_Iv___Surgical_Pathology_Examination_Date, QPP397Elements.Specimen_Site_Other_Than_Anatomic_Cutaneous_Location, patientHistoryBroadcastList)

          )
    )
  }

  //Pathology reports for primary malignant cutaneous melanoma that include the pT category and a statement on thickness, ulceration and mitotic rate.
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      isInterventionPerformedDuringEncounter(visit, m, QPP397Elements.Pathology_Report)
        ||
        (
          wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP397Elements.Level_Iv___Surgical_Pathology_Examination, QPP397Elements.Report_For_Pt__Primary_Tumor_, patientHistoryBroadcastList)
            && wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP397Elements.Level_Iv___Surgical_Pathology_Examination, QPP397Elements.Thickness, patientHistoryBroadcastList)
            && wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP397Elements.Level_Iv___Surgical_Pathology_Examination, QPP397Elements.Ulceration, patientHistoryBroadcastList)
            && wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP397Elements.Level_Iv___Surgical_Pathology_Examination, QPP397Elements.Report_For_Mitotic_Rate_For_Primary_Tumor, patientHistoryBroadcastList)


          )
          && !wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP397Elements.Level_Iv___Surgical_Pathology_Examination, QPP397Elements.Pathology_Report_Not_Met, patientHistoryBroadcastList)
    )
  }

  //Documentation of medical reason(s) for not including pT Category and a statement on thickness, ulceration
  // and mitotic rate (e.g., negative skin biopsies in a patient with a history of melanoma or other documented medical reasons)
  def getexceptionRDD(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        isInterventionPerformedDuringProcedure(visit, m, QPP397Elements.Pathology_Report_Medical_Reason, QPP397Elements.Pathology_Report_Medical_Reason_Date, QPP397Elements.Level_Iv___Surgical_Pathology_Examination, QPP397Elements.Level_Iv___Surgical_Pathology_Examination_Date)
          ||
          (
            wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP397Elements.Level_Iv___Surgical_Pathology_Examination, QPP397Elements.Negative_Skin_Biopsies, patientHistoryBroadcastList)
              && wasDiagnosedBefore(visit, m, QPP397Elements.Level_Iv___Surgical_Pathology_Examination, QPP397Elements.History_Of_Melanoma, patientHistoryBroadcastList)
            )
          || wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP397Elements.Level_Iv___Surgical_Pathology_Examination, QPP397Elements.Medical_Reason_Melanoma_Reporting, patientHistoryBroadcastList)
        )
    )

  }
}