package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP424Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 424
* Measure Title              :- Perioperative Temperature Management
* Measure Description        :- Percentage of patients, regardless of age, who undergo surgical or therapeutic procedures
                                under general or neuraxial anesthesia of 60 minutes duration or longer for whom at least
                                one body temperature greater than or equal to 35.5 degrees Celsius (or 95.9 degrees Fahrenheit)
                                was recorded within the 30 minutes immediately before or the 15 minutes immediately after
                                anesthesia end time.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher score indicates a better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/



object  Qpp424  extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp424"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {



    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      val patienthistoryRdd = getPatientHistory(sparkSession, ippRDD, QPP424Elements.Body_Temperature_Measurement).collect().toList
      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistoryRdd)

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateExclusion = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateExclusion.cache()

      // Filter Met
      val metRDD = getMet(intermediateExclusion, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate
      val intermediateException = getSubtractRDD(intermediateExclusion, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateException)
      exceptionRDD.cache()

      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }


  /*--------------------------------------------------------------------------------------------------------------------
   Patients for whom imaging of the head (Computed Tomography (CT) or Magnetic Resonance Imaging (MRI)) is obtained for
   the evaluation of primary headache when clinical indications are not present
   -------------------------------------------------------------------------------------------------------------------*/


  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
         isProcedurePerformedWithStopDateDuringEncounter(visit,m,QPP424Elements.Anesthesia,QPP424Elements.Anesthesia_Stop_Datetime)
      && isAssessmentPerformedDuringEncounter(visit,m,QPP424Elements.Anesthesia_Of_60_Minutes_Or_Longer)
    )

  }
  /*--------------------------------------------------------------------------------------------------------------------
   Monitored Anesthesia Care (MAC): G9654
    OR
    Peripheral Nerve Block (PNB): G9770
   -------------------------------------------------------------------------------------------------------------------*/


  def getExclusion(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
       isAssessmentPerformedDuringEncounter(visit,m,QPP424Elements.Monitored_Anesthesia_Care_2)
    || isProcedurePerformedDuringEncounter(visit,m,QPP424Elements.Monitored_Anesthesia_Care_1)
    || isAssessmentPerformedDuringEncounter(visit,m,QPP424Elements.Peripheral_Nerve_Block)
    || isProcedurePerformedDuringEncounter(visit,m,QPP424Elements.Regional_Anesthesia)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
    Patients for whom at least one body temperature greater than or equal to 35.5 degrees Celsius (or 95.9 degrees Fahrenheit) '
    was recorded within the 30 minutes immediately before or the 15 minutes immediately after anesthesia end time.
   -------------------------------------------------------------------------------------------------------------------*/


  def getMet(intermediateA: RDD[CassandraRow],patientHistory:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      (
          isAssessmentPerformedDuringEncounter(visit,m,QPP424Elements.Body_Temperature)
      ||
            (
                wasPhysicalPerformedWithInXPeriodOnEncounter(visit,m,AdminElements.Encounter_Date,"startsBefore","MINUTS",30,QPP424Elements.Body_Temperature_Measurement,35.5,"gt",patientHistory)
             && wasPhysicalPerformedWithInXPeriodOnEncounter(visit,m,AdminElements.Encounter_Date,"startsAfter","MINUTS",15,QPP424Elements.Body_Temperature_Measurement,35.5,"gt",patientHistory)
            )
        )
      && isAssessmentPerformedDuringEncounter(visit,m,QPP424Elements.Body_Temp_Not_Met)

    )
  }

  /*-------------------------------------------------------------------------------------------------------------------
  Documentation of one of the following medical reason(s) for not achieving at least 1 body temperature measurement equal
  to or greater than 35.5 degrees Celsius (or 95.9 degrees Fahrenheit) achieved within the 30 minutes immediately before
  or the 15 minutes immediately after anesthesia end time (e.g., Emergency cases, Intentional hypothermia, etc.)
  -------------------------------------------------------------------------------------------------------------------*/

  def getException(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
          isAssessmentPerformedDuringEncounter(visit,m,QPP424Elements.Body_Temp_Medical_Reason)
       || isDiagnosedOnEncounter(visit,m,QPP424Elements.Intentional_Hypothermia)
       || isDiagnosedOnEncounter(visit,m,QPP424Elements.Emergency_Cases)

    )
  }

}
