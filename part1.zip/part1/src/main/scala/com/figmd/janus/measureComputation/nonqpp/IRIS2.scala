package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master.{AdminElements, CalenderUnit, IRIS2Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- IRIS 2
* Measure Title              :- Glaucoma- Intraocular Pressure (IOP) Reduction
* Measure Description        :- Percentage of glaucoma patient visits where their IOP was below a threshold level based on the severity of their diagnosis.
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD, IRIS2Elements.Open_Angle_Glaucoma_Unspecified,
      IRIS2Elements.Low_Tension_Glaucoma,
      IRIS2Elements.Indeterminate_Stage_Glaucoma,
      IRIS2Elements.Absolute_Glaucoma_Blindness,
      IRIS2Elements.Incisional_Glaucoma_Surgery,
      IRIS2Elements.Visual_Acuity_Findings
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()


      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*------------------------------------------------------------------------------
  Total number of visits for patients aged between 40 and 85 years, with a minimum of 4 office visits during the prior 2 years,
  with a glaucoma diagnosis and documentation of the severity of their glaucoma
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryRDD:RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    val countElementList: List[(String,Int)] = countElementWithinMonthsInHistory(patientHistoryRDD,m, 12,IRIS2Elements.Office_Or_Ophthalmological_Services)

    initialRDD.filter(visit =>
      (isAgeBetween(visit, m, 40,86)
        && getEncounterCountFromHistory(visit, m, 3, true,countElementList)
        && isVisitTypeIn(visit, m, IRIS2Elements.Office_Or_Ophthalmological_Services)
        && wasDiagnosedInHistory(visit, m, IRIS2Elements.Open_Angle_Glaucoma_Unspecified, patientHistoryList)
        )
    )
  }

  /*------------------------------------------------------------------------------
  Patients with a diagnosis of low tension glaucoma,
Eyes with a documented severity of indeterminate stage or stage unspecified,
Eyes with absolute glaucoma blindness,
Eyes with a glaucoma incisional surgery within the last 90 days,
Visual acuity findings: Count fingers (CF or FC), Hand motion (HM), Light perception (LP), No light perception (NLP)
   ------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      (wasDiagnosedInHistory(visit, m, IRIS2Elements.Low_Tension_Glaucoma,patientHistoryList)
        && checkEyeElementsInRange(visit,m, IRIS2Elements.Low_Tension_Glaucoma_Eye,IRIS2Elements.Open_Angle_Glaucoma_Unspecified__Eye,IRIS2Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS2Elements.Pigmentary_Glaucoma__Eye,IRIS2Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS2Elements.Chronic_Angle_Closure_Glaucoma__Eye)
        )
        || (wasDiagnosedInHistory(visit, m, IRIS2Elements.Indeterminate_Stage_Glaucoma,patientHistoryList)
        && checkEyeElementsInRange(visit,m, IRIS2Elements.Indeterminate_Stage_Glaucoma__Eye,IRIS2Elements.Open_Angle_Glaucoma_Unspecified__Eye,IRIS2Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS2Elements.Pigmentary_Glaucoma__Eye,IRIS2Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS2Elements.Chronic_Angle_Closure_Glaucoma__Eye)
        )
        || (wasDiagnosedInHistory(visit, m, IRIS2Elements.Absolute_Glaucoma_Blindness,patientHistoryList)
        && checkEyeElementsInRange(visit,m, IRIS2Elements.Absolute_Glaucoma_Blindness_Eye,IRIS2Elements.Open_Angle_Glaucoma_Unspecified__Eye,IRIS2Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS2Elements.Pigmentary_Glaucoma__Eye,IRIS2Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS2Elements.Chronic_Angle_Closure_Glaucoma__Eye)
        )
        || (wasProcedurePerformedBeforeEncounterInXPeriod(visit, m, IRIS2Elements.Incisional_Glaucoma_Surgery,CalenderUnit.DAY,90,patientHistoryList)
        && checkEyeElementsInRange(visit,m, IRIS2Elements.Incisional_Glaucoma_Surgery__Eye,IRIS2Elements.Open_Angle_Glaucoma_Unspecified__Eye,IRIS2Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS2Elements.Pigmentary_Glaucoma__Eye,IRIS2Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS2Elements.Chronic_Angle_Closure_Glaucoma__Eye)
        )
        || (isPhysicalExamPerformed(visit, m, IRIS2Elements.Visual_Acuity_Findings,patientHistoryList)
        && checkEyeElementsInRange(visit,m, IRIS2Elements.Visual_Acuity_Findings__Eye,IRIS2Elements.Open_Angle_Glaucoma_Unspecified__Eye,IRIS2Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS2Elements.Pigmentary_Glaucoma__Eye,IRIS2Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS2Elements.Chronic_Angle_Closure_Glaucoma__Eye)
        )
    )
  }

  /*------------------------------------------------------------------------------
Visits where the eye(s) IOP was below a specified threshold based on the severity of their glaucoma:
Mild stage:  IOP <= 22 mmHg
Moderate stage:  IOP <= 18 mmHg
Severe stage:  IOP <= 15 mmHg
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      (isPhysicalExamPerformedWithResultDuringEncounter(visit, m, IRIS2Elements.Iop__Severe_Stage, 15,"le")
        || (isPhysicalExamPerformedWithResultDuringEncounter(visit, m, IRIS2Elements.Iop__Moderate_Stage, 16,"ge")
        && isPhysicalExamPerformedWithResultDuringEncounter(visit, m, IRIS2Elements.Iop__Moderate_Stage, 18,"le")
        )
        || (isPhysicalExamPerformedWithResultDuringEncounter(visit, m, IRIS2Elements.Iop__Moderate_Stage, 16,"ge")
        && isPhysicalExamPerformedWithResultDuringEncounter(visit, m, IRIS2Elements.Iop__Moderate_Stage, 18,"le")
        )
        || (isPhysicalExamPerformedWithResultDuringEncounter(visit, m, IRIS2Elements.Iop__Mild_Stage, 19,"ge")
        && isPhysicalExamPerformedWithResultDuringEncounter(visit, m, IRIS2Elements.Iop__Mild_Stage, 22,"le")
        )
        )
        && checkEyeElementsInRange(visit,m, IRIS2Elements.Iop__Eye,IRIS2Elements.Open_Angle_Glaucoma_Unspecified__Eye,IRIS2Elements.Primary_Open_Angle_Glaucoma_Eye,IRIS2Elements.Pigmentary_Glaucoma__Eye,IRIS2Elements.Pseudoexfoliation_Glaucoma__Eye,IRIS2Elements.Chronic_Angle_Closure_Glaucoma__Eye)
    )
  }
}