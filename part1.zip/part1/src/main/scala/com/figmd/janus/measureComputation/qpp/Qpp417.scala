
package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP417Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp 417
* Measure Title              :- Rate of Open Repair of Small or Moderate Abdominal Aortic Aneurysms (AAA) Where Patients Are Discharged Alive
* Measure Description        :- Percentage of patients undergoing open repair of small or moderate non-ruptured infrarenal abdominal aortic
*                               aneurysms (AAA) who are discharged alive
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp417 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp417"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Backtracking List
      var patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        QPP417Elements.Diameter_Of_Aortic_Aneurysm_Between_5_5_5_9_Cm,
        QPP417Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa,
        QPP417Elements.Diameter_Of_Aortic_Aneurysm_Of_At_Least_6_Cm,
        QPP417Elements.Diameter_Of_Aortic_Aneurysm,
        QPP417Elements.Symptomatic_Aaas_Requiring_Repair,
        QPP417Elements.Discharge_Within_7_Days,
        QPP417Elements.Discharged_Home,
        QPP417Elements.Transfer_To_Nursing_Facility,
        QPP417Elements.Discharge_Within_7_Days
      )
      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect.toList)
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
          denominatorRDD.cache()
      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate for Met
      val intermediateMet = getSubtractRDD(denominatorRDD, exclusionRDD)
          intermediateMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateMet, metRDD)
          notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------
    Patients aged 18 and older with all elective open repairs of small or moderate asymptomatic AAAs in men with < 6 cm diameter and women with < 5.5 cm diameter AAAs
   ------------------------------------------------------------------------------------------------------------------*/

  def getIpp(rdd:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
      isPatientAdult(visit, m)
      && isProcedurePerformedDuringEncounter(visit, m, QPP417Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa)
    )
  }

  /*---------------------------------------------------------------------------------------------
    For women:
    Aortic aneurysm 5.5 - 5.9 cm maximum diameter on centerline formatted CT or minor diameter on axial formatted CT
    OR
    Aortic aneurysm 6.0 cm or greater maximum diameter on centerline formatted CT or minor diameter on axial formatted CT
    OR
    For men:
    Aortic aneurysm 6.0 cm or greater maximum diameter on centerline formatted CT or minor diameter on axial formatted CT
    OR
    Symptomatic AAAs that required urgent/emergent (non-elective) repair
   ----------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
      (
        isFemale(visit, m)
        && (
          wasAssesmentPerformedOverlapsProcedurePerformedInHistory(visit, m, QPP417Elements.Diameter_Of_Aortic_Aneurysm_Between_5_5_5_9_Cm, QPP417Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, patientHistoryList)
          || wasAssesmentPerformedOverlapsProcedurePerformedInHistory(visit, m, QPP417Elements.Diameter_Of_Aortic_Aneurysm_Of_At_Least_6_Cm, QPP417Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, patientHistoryList)
          || wasAssesmentValueGreaterOrEqualBeforeProcedurePerformed(visit, m, QPP417Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, QPP417Elements.Diameter_Of_Aortic_Aneurysm,"ge",  5.5, patientHistoryList)
        )
      )
      || (
        isMale(visit, m)
          && (
          wasAssesmentPerformedOverlapsProcedurePerformedInHistory(visit, m, QPP417Elements.Diameter_Of_Aortic_Aneurysm_Between_5_5_5_9_Cm, QPP417Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, patientHistoryList)
            || wasAssesmentPerformedOverlapsProcedurePerformedInHistory(visit, m, QPP417Elements.Diameter_Of_Aortic_Aneurysm_Of_At_Least_6_Cm, QPP417Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, patientHistoryList)
            || wasAssesmentValueGreaterOrEqualBeforeProcedurePerformed(visit, m, QPP417Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, QPP417Elements.Diameter_Of_Aortic_Aneurysm,"ge",  6, patientHistoryList)
          )
        )
      || wasAssessmentPerformedBeforeProcedurePerformed(visit, m, QPP417Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, patientHistoryList, QPP417Elements.Symptomatic_Aaas_Requiring_Repair)
    )
  }

  /*----------------------------------------------------------------------------------------
    Patients discharged alive/home following open repair of asymptomatic AAAs in men with < 6 cm diameter and women with < 5.5 cm diameter AAAs
   -----------------------------------------------------------------------------------------*/

  def getMet(intermediateMet: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateMet.filter(visit =>
      (
        isAssessmentPerformed(visit, m, QPP417Elements.Discharge_Within_7_Days, patientHistoryList)
            || wasDiagnosedAfterXDaysProcedure(visit, m, QPP417Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, QPP417Elements.Discharged_Home, 7, patientHistoryList)
            || wasDiagnosedAfterXDaysProcedure(visit, m, QPP417Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, QPP417Elements.Transfer_To_Nursing_Facility, 7, patientHistoryList)
      )
      && ! isAssessmentPerformed(visit, m, QPP417Elements.Discharge_Within_7_Days, patientHistoryList)
    )
  }

}
