package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP470Elements, CalenderUnit}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 470
* Measure Title              :- Average Change In Functional Status Following Total Knee Replacement Surgery
* Measure Description        :- The average change (preoperative to postoperative) in functional status using the Oxford
                                Knee Score (OKS) for patients age 18 and older who had a primary total knee replacement
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp470 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "Qpp470_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP470Elements.Total_Knee_Replacement_Procedure
      , QPP470Elements.Functional_Status_Score_Oks
      , QPP470Elements.Oxford_Knee_Score
      , QPP470Elements.Preoperative_Ok_Score
      , QPP470Elements.Postoperative_Oks_Score
      , QPP470Elements.Total_Knee_Replacement_Procedure
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
          metRDD.cache()
      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
       notMetRDD.cache()
     saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }


  /*------------------------------------------------------------------------------------------------
    	Patients 18 years of age or older as of October 1 of the denominator identification period who had a total knee
    	 replacement procedure performed during the denominator identification period
  ------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 18, CalenderUnit.YEAR)
        && wasProcedurePerformedBeforeStartDateInXMonths(visit, m, QPP470Elements.Total_Knee_Replacement_Procedure, CalenderUnit.MONTH, 3, CalenderUnit.MONTH, 15, patientHistoryList)
    )
  }


  /*------------------------------------------------------------------------------------------------
    All eligible patients whose functional status was measured by the Oxford Knee Score (OKS) patient reported outcome
    tool within three months preoperatively AND at one year (9 to 15 months) postoperatively
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRdd.filter(visit =>
      (
        wasAssessmentPerformedAfterProcedure(visit, m, QPP470Elements.Total_Knee_Replacement_Procedure, patientHistoryList, QPP470Elements.Functional_Status_Score_Oks)
          || (
          wasAssessmentPerformedBeforeProcedureWithResultInXMonth(visit, m, QPP470Elements.Oxford_Knee_Score, QPP470Elements.Preoperative_Ok_Score, QPP470Elements.Total_Knee_Replacement_Procedure, CalenderUnit.MONTH, 3, patientHistoryList)
            && wasAssessmentPerformedAfterProcedureWithResultInBetweenXMonths(visit, m, QPP470Elements.Oxford_Knee_Score, QPP470Elements.Postoperative_Oks_Score, QPP470Elements.Total_Knee_Replacement_Procedure, CalenderUnit.MONTH, 9, CalenderUnit.MONTH, 15, patientHistoryList)
          )
        )
        && !wasAssessmentPerformedAfterProcedure(visit, m, QPP470Elements.Total_Knee_Replacement_Procedure, patientHistoryList, QPP470Elements.Functional_Status_Score_Oks_Ntmt)
    )
  }

}
