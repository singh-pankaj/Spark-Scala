package com.figmd.janus

import com.datastax.spark.connector.CassandraRow
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

trait MeasureUpdate {
    def refresh(sparkSession: SparkSession,rdd:RDD[CassandraRow]): Unit
  }
