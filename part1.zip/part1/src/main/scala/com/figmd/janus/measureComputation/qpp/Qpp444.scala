package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty}
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 444
* Measure Title              :- Medication Management for People with Asthma
* Measure Description        :- The percentage of patients 5-64 years of age during the measurement year who were
*                               identified as having persistent asthma and were dispensed appropriate medications that
*                               they remained on for at least 75% of their treatment period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp444 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp444"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP444Elements.Persistent_Asthma
      , QPP444Elements.Copd
      , QPP444Elements.Emphysema
      , QPP444Elements.Obstructive_Chronic_Bronchitis
      , QPP444Elements.Chronic_Respiratory_Conditions_Fumes_Vapors
      , QPP444Elements.Cystic_Fibrosis
      , QPP444Elements.Acute_Respiratory_Failure
      , QPP444Elements.Asthma_Controller_Medication
      , QPP444Elements.Hospice_Services
      , QPP444Elements.Hospice_Services_Snomedct
      , QPP444Elements.Hospice_Care
      , QPP444Elements.Proportion_Days_Pdc_
      , QPP444Elements.Antibody_Inhibitor
      , QPP444Elements.Antiasthmatic_Combinations
      , QPP444Elements.Inhaled_Steroid_Combinations
      , QPP444Elements.Inhaled_Corticosteroids
      , QPP444Elements.Leukotriene_Modifiers
      , QPP444Elements.Mast_Cell_Stabilizer
      , QPP444Elements.Methylxanthines
      , QPP444Elements.Anti_Interleukin_5
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /*--------------------------------------------------------------------------------------------------------------------
    Patients 5-64 years of age with persistent asthma and a visit during the measurement period
  --------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeBetween(visit, m, 5, CompareOperator.GREATER_EQUAL, 65, CompareOperator.LESS)
        &&
        wasDiagnosisBeforeOrEqualEncounter(visit, m, patientHistoryBroadcastList, QPP444Elements.Persistent_Asthma)
        &&
        isVisitTypeIn(visit, m
          , QPP444Elements.Office_Visit
          , QPP444Elements.Home_Healthcare_Services
          , QPP444Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
          , QPP444Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
          , QPP444Elements.Preventive_Care__Established_Office_Visit__0_To_17
          , QPP444Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
        )
    )
  }


  // Denominator Exclusion criteria
  /*--------------------------------------------------------------------------------------------------------------------
  Diagnosis of COPD, Emphysema, Obstructive Chronic Bronchitis, Chronic Respiratory Conditions Due to Fumes/ Vapors, Cystic Fibrosis, or Acute Respiratory Failure any time during the patient’s history through the end of the measurement year

  Any patients who had no asthma controller medications dispensed during the measurement year

  Patients who use hospice services any time during the measurement period
  --------------------------------------------------------------------------------------------------------------------*/
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      wasDiagnosisBeforeOrEqualEncounter(visit, m, patientHistoryBroadcastList, QPP444Elements.Copd, QPP444Elements.Emphysema, QPP444Elements.Obstructive_Chronic_Bronchitis, QPP444Elements.Chronic_Respiratory_Conditions_Fumes_Vapors, QPP444Elements.Cystic_Fibrosis, QPP444Elements.Acute_Respiratory_Failure)
        ||
        isMedicationOrdered(visit, m, patientHistoryBroadcastList, QPP444Elements.Asthma_Controller_Medications)
        ||
        wasMedicationAdministeredInHistory(visit, m, QPP444Elements.Asthma_Controller_Medication, patientHistoryBroadcastList)
        ||
        isInterventionPerformed(visit, m, QPP444Elements.Hospice_Services, patientHistoryBroadcastList)
        ||
        wasInterventionPerformedOrOrderedInHistory(visit, m, QPP444Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
        ||
        wasInterventionPerformedOrOrderedInHistory(visit, m, QPP444Elements.Hospice_Care, patientHistoryBroadcastList)
    )
  }


  // Numerator criteria
  /*--------------------------------------------------------------------------------------------------------------------
  The number of patients who achieved a proportion of days (PDC) of at least 75% for their asthma controller
  medications during the measurement year
  --------------------------------------------------------------------------------------------------------------------*/
  def getMet(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      (
        (

          isMedicationOrdered(visit, m, patientHistoryBroadcastList, QPP444Elements.Antibody_Inhibitor
            , QPP444Elements.Antiasthmatic_Combinations
            , QPP444Elements.Inhaled_Steroid_Combinations
            , QPP444Elements.Inhaled_Corticosteroids
            , QPP444Elements.Leukotriene_Modifiers
            , QPP444Elements.Mast_Cell_Stabilizer
            , QPP444Elements.Methylxanthines
            , QPP444Elements.Anti_Interleukin_5)

            &&

            wasAssessmentAfterOrConcurrentMedication(visit, m, QPP444Elements.Proportion_Days_Pdc_, patientHistoryBroadcastList, QPP444Elements.Antibody_Inhibitor, QPP444Elements.Antiasthmatic_Combinations, QPP444Elements.Inhaled_Steroid_Combinations, QPP444Elements.Inhaled_Corticosteroids,
              QPP444Elements.Leukotriene_Modifiers,
              QPP444Elements.Mast_Cell_Stabilizer,
              QPP444Elements.Methylxanthines,
              QPP444Elements.Anti_Interleukin_5)

          )
          ||
          isAssessmentPerformed(visit, m, QPP444Elements.Proportion_Of_Days, patientHistoryBroadcastList)
        )
        && !isAssessmentPerformed(visit, m, QPP444Elements.Proportion_Of_Days__Not_Met, patientHistoryBroadcastList)
    )

  }
}