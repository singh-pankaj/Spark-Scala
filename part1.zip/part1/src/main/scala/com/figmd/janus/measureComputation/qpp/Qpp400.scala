package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ MeasureProperty, QPP400Elements}
import com.figmd.janus.util.measure.{MeasureUtilityUpdate, PatientHistoryUtility}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp400
* Measure Title              :- One-Time Screening for Hepatitis C Virus (HCV) for Patients at Risk
* Measure Description        :- Percentage of patients aged 18 years and older with one or more of the following: a history of injection drug use, receipt of a blood transfusion prior to 1992, receiving maintenance hemodialysis, OR birthdate in the years 1945-1965 who received one-time screening for hepatitis C virus (HCV) infection
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- 1
* Measure Developer          :- Vrushali Gholap
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp400 extends MeasureUtilityUpdate with MeasureUpdate{

  val MEASURE_NAME = "Qpp400"
  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistory: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      , QPP400Elements.Outpatient_Consultation
      , QPP400Elements.Home_Healthcare_Services
      , QPP400Elements.Care_Services_In_Long_Term_Residential_Facility
      , QPP400Elements.Nursing_Facility_Visit
      , QPP400Elements.Office_Visit
      , QPP400Elements.History_Of_Blood_Transfusion
      , QPP400Elements.Blood_Transfusion_Before_1992
      , QPP400Elements.Maintenance_Hemodialysis
      , QPP400Elements.History_Of_Injection_Of_Drug
      , QPP400Elements.History_Of_Injection_Drug_Use
      , QPP400Elements.Patients_Born_Between_1945_1965
      , QPP400Elements.Chronic_Hepatitis_C
      , QPP400Elements.Screening_For_Hcv_Infection
      , QPP400Elements.Riba_Test
      , QPP400Elements.Hcv_Rna_Test
      , QPP400Elements.Hcv_Antibody_Test
      , QPP400Elements.Screen_Hcv_Reason_Not_Specified
      , QPP400Elements.Screen_Hcv_Medical_Reason
      , QPP400Elements.Ascites
      , QPP400Elements.Esophageal_Varices_With_Bleeding
      , QPP400Elements.Hepatic_Encephalopathy
      , QPP400Elements.Hepatocellular_Carcinoma
      , QPP400Elements.Limited_Life_Expectancy
      , QPP400Elements.Limited_Life_Expectancy
      , QPP400Elements.Screen_Hcv_Patient_Reason
      , QPP400Elements.Patient_Refusal
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistory.collect().toList)
    // Filter IPP
    val ippRDD = getIppRDD(initialRDD, patientHistoryBroadcastList, patientHistory)
    ippRDD.cache()
    val mostRecentRDD: List[CassandraRow] = mostRecentPatientListOnEncounter(ippRDD)
    val mostRecentpatientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostRecentRDD)

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      //Filter Exclusion
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate for MET
      val intermediateNumerator = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateNumerator.cache()

      // Filter Met
      val metRDD = getMetRDD(intermediateNumerator, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateException = getSubtractRDD(intermediateNumerator, metRDD)
      intermediateException.cache()

      // Filter Exception
      val exceptionRDD = getExceptionRdd(intermediateException, patientHistoryBroadcastList, mostRecentpatientHistoryList)
      exceptionRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      mostRecentpatientHistoryList.destroy()
    }
  }
  /*-------------------------------------------------------------------------------------------------------------------------
ll patients, regardless of age, who are seen twice for any visit or who had at least one preventive visit within the 12 month reporting period who are active injection drug users
----------------------------------------------------------------------------------------------------------------------------*/
  def getIppRDD(rdd: RDD[CassandraRow],patientHistoryList : Broadcast[List[CassandraRow]],patientHistory: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)
    val countRDD = countElement(patientHistory, m ,QPP400Elements.Outpatient_Consultation
                                                  ,QPP400Elements.Home_Healthcare_Services
                                                  ,QPP400Elements.Care_Services_In_Long_Term_Residential_Facility
                                                  ,QPP400Elements.Nursing_Facility_Visit
                                                  ,QPP400Elements.Office_Visit)

    rdd.filter(visit =>
      isPatientAdult(visit,m)
        &&  isVisitTypeIn(visit,m ,QPP400Elements.Annual_Wellness_Visit
                                  ,QPP400Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
                                  ,QPP400Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up)
        && getEncounterCountFromHistory(visit,m,2,true,countRDD)
        && (     isInterventionPerformed(visit,m,QPP400Elements.History_Of_Blood_Transfusion,patientHistoryList)
              || wasProcedurePerformedBeforeEndInXYears(visit,m,QPP400Elements.Blood_Transfusion_Before_1992,26,patientHistoryList)
              || wasProcedurePerformedInHistory(visit,m,QPP400Elements.Maintenance_Hemodialysis,patientHistoryList)
              || isDiagnosed(visit,m,QPP400Elements.History_Of_Injection_Of_Drug,patientHistoryList)
              || wasDiagnosedBeforeEncounter(visit,m,QPP400Elements.History_Of_Injection_Drug_Use,patientHistoryList)
              || isPatientCharacteristic(visit,m,QPP400Elements.Patients_Born_Between_1945_1965,patientHistoryList)
              || isDobAboveOrBelow(visit,m,"1945-01-01","1965-12-31")
           )
        && !isTeleHealthModifier(visit,m,QPP400Elements.Preventive_Care_Services_Initial_Office_Visit_18_And_Up_Telehealth_Modifier
                                        ,QPP400Elements.Preventive_Care_Services___Established_Office_Visit_18_And_Up_Telehealth_Modifier
                                        ,QPP400Elements.Annual_Wellness_Visit_Telehealth_Modifier
                                        ,QPP400Elements.Office_Visit_Telehealth_Modifier
                                        ,QPP400Elements.Nursing_Facility_Visit_Telehealth_Modifier
                                        ,QPP400Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
                                        ,QPP400Elements.Home_Healthcare_Services_Telehealth_Modifier
                                        ,QPP400Elements.Outpatient_Consultation_Telehealth_Modifier)


    )
  }
  /*--------------------------------------------------------------------------------------------------------------------
  Diagnosis for Chronic Hepatitis C
  -------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(rdd: RDD[CassandraRow], patientHistoryList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      wasDiagnosisBeforeOrEqualEncounter(visit,m,patientHistoryList,QPP400Elements.Chronic_Hepatitis_C)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Patients who received screening for HCV infection within the 12 month reporting period
   -------------------------------------------------------------------------------------------------------------------*/


  def getMetRDD(RDD: RDD[CassandraRow], patientHistoryList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    RDD.filter(visit =>
        (   isInterventionPerformed(visit,m,QPP400Elements.Screening_For_Hcv_Infection,patientHistoryList)
          ||(  wasInterventionPerformedBeforeEncounter(visit,m,QPP400Elements.Riba_Test,patientHistoryList)
            && wasInterventionPerformedBeforeEncounter(visit,m,QPP400Elements.Hcv_Rna_Test,patientHistoryList)
            && wasInterventionPerformedBeforeEncounter(visit,m,QPP400Elements.Hcv_Antibody_Test,patientHistoryList)
            )
        )
        && !isInterventionPerformed(visit,m,QPP400Elements.Screen_Hcv_Reason_Not_Specified,patientHistoryList)
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
Documentation of medical reason(s) for not receiving annual screening for HCV infection (e.g., decompensated cirrhosis indicating advanced disease [i.e., ascites, esophageal variceal bleeding, hepatic encephalopathy], hepatocellular carcinoma, waitlist for organ transplant, limited life expectancy, other medical reasons)
Documentation of patient reason(s) for not receiving annual screening for HCV infection (e.g., patient declined, other patient reasons)
  -------------------------------------------------------------------------------------------------------------------*/


  def getExceptionRdd(intermediateException: RDD[CassandraRow], patientHistoryList : Broadcast[List[CassandraRow]],mostRecentpatientHistoryList :Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
         wasInterventionPerformedDuringMostRecentEncounter(visit,m,QPP400Elements.Screen_Hcv_Medical_Reason,patientHistoryList,mostRecentpatientHistoryList)
      || wasDiagnosedDuringMostRecentEncounter(visit,m,QPP400Elements.Ascites,patientHistoryList,mostRecentpatientHistoryList)
      || wasDiagnosedDuringMostRecentEncounter(visit,m,QPP400Elements.Esophageal_Varices_With_Bleeding,patientHistoryList,mostRecentpatientHistoryList)
      || wasDiagnosedDuringMostRecentEncounter(visit,m,QPP400Elements.Hepatic_Encephalopathy,patientHistoryList,mostRecentpatientHistoryList)
      || wasDiagnosedDuringMostRecentEncounter(visit,m,QPP400Elements.Hepatocellular_Carcinoma,patientHistoryList,mostRecentpatientHistoryList)
      || wasDiagnosedDuringMostRecentEncounter(visit,m,QPP400Elements.Limited_Life_Expectancy,patientHistoryList,mostRecentpatientHistoryList)
      || wasDiagnosticStudyPerformedDuringMostRecentEncounter(visit,m,QPP400Elements.Limited_Life_Expectancy,patientHistoryList,mostRecentpatientHistoryList)
      || wasInterventionPerformedDuringMostRecentEncounter(visit,m,QPP400Elements.Screen_Hcv_Patient_Reason,patientHistoryList,mostRecentpatientHistoryList)
      || wasCommunicationDuringMostRecentEncounter(visit,m,QPP400Elements.Patient_Refusal,patientHistoryList,mostRecentpatientHistoryList)

    )
  }
}