package com.figmd.janus.util.measure


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.WebDataMartCreator.global_measure_name
import com.figmd.janus.measureComputation.master._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.joda.time.DateTime



class MeasureUtilityUpdate extends HistoryLookUpUtility {

/*
  /**
    *
    * @param r get visit onEncounter for analysis assessmentPerformed
    * @param measureProperty m
    * @param elementArray get element list as input
    * @return true or false based on assessmentPerformed
    */

  def assessmentPerformed(r: CassandraRow, measureProperty: MeasureProperty, elementArray: Array[String]): Boolean = {
    procedurePerformed(r, measureProperty, elementArray: Array[String])
  }*/


  /**
    *
    * @param r get visit onEncounter for analysis getCHA2DS2_VASc
    * @param m m
    * @param hefa get element 1
    * @param hyper get element 2
    * @param dibtmelts get element 3
    * @param prirstrk get element 4
    * @param vsclr_disease get element 5
    * @param sex get element 6
    * @return true or false based on assessmentPerformed
    */

  def  getCHA2DS2VASc(r: CassandraRow, m:MeasureProperty, hefa: String, hyper: String, dibtmelts: String, prirstrk: String, vsclr_disease: String, sex: String): Int= {
    var chadscore=0
    try {

      val dob = r.getDate("dob")
      val enounterdate = r.getString("encounterdate")

      if(isAgeAbove(r,m,true,75)){chadscore=chadscore+2}
      else if(!r.isNullAt(hefa) && r.getString(hefa).equals("1")){chadscore=chadscore+1}
      else if(isAgeAbove(r,m,true,64) && isAgeBelow(r,m,false,75)){chadscore=chadscore+1}
      else if(!r.isNullAt(hyper) && r.getString(hyper).equals("1")){chadscore=chadscore+1}
      else if(!r.isNullAt(dibtmelts) && r.getString(dibtmelts).equals("1")){chadscore=chadscore+1}
      else if(!r.isNullAt(prirstrk) && r.getString(prirstrk).equals("1")){chadscore=chadscore+2}
      else if(!r.isNullAt(vsclr_disease) && r.getString(vsclr_disease).equals("1")){chadscore=chadscore+1}
      else if(!r.isNullAt(sex) && r.getString(sex).equals("2")){chadscore=chadscore+1}

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:getCHA2DS2_VASc:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        System.exit(0)

      }
    }
    chadscore
  }


  /**
    *
    * @param r get visit onEncounter for analysis isAssessmentLessThan
    * @param measureProperty m
    * @param checkValue get element value from cassendra
    * @param Value get input value
    * @return true or false based on isAssessmentLessThan
    */

  def isAssessmentLessThan(r: CassandraRow, measureProperty: MeasureProperty,checkValue:String, Value: Int): Boolean = {
    val isExist = !r.isNullAt(checkValue) && r.getInt(checkValue)<Value
    //val argsArray:Array[String]=Array(checkValue,Value.toString)
    //measureLogger(r, measureName, conditionType, "chkValueRangeLess", checkValue, isExist,argsArray)

    return isExist;
  }

  /*def encounterPerformed(r: CassandraRow, measureProperty: MeasureProperty, elementArray: Array[String]): Boolean = {
    procedurePerformed(r: CassandraRow, measureProperty, elementArray: Array[String])
  }*/

  def encounterPerformed(r:CassandraRow,measureProperty: MeasureProperty,element:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    isDiagnosedWithInHistory(r,measureProperty,element,patientHistoryList)
  }

  def procedurePerformed(r: CassandraRow, measureProperty: MeasureProperty, elementArray: Seq[String]): Boolean = {
    elementArray.exists(element=>checkElementPresent(r, measureProperty, element))
  }

  /*def unionOf(func: Array[Boolean]): Boolean = {
    func.forall(x => x == true)
  }*/

  /*

    def AND(functionArray: Array[Boolean]): Boolean = {
      var flag = true
      for (element <- functionArray) {
        if (!element) {
          false
        }
      }
      flag
    }


    def OR(functionArray: Array[Boolean]): Boolean = {
      var flag = true
      for (element <- functionArray) {
        if (element) {
          true
        }
      }
      flag
    }
  */



  def ageAtEncounterGreaterThanOrEqualTo2(r: CassandraRow, measureProperty: MeasureProperty): Boolean = {

    var isAgeGreterThan18 = false

    try {

      isAgeGreterThan18 = !r.isNullAt("dob") && !r.isNullAt("encounterdate") && dateUtility.getAge(r.getString("dob"), r.getString("encounterdate")) >= 2
      //  val argsArray: Array[String] = Array(sDate, eDate, compareYears.toString)
      //  measureLogger1(r, measureProperty, "ageGreaterThanOrEquals18", startDateDOB, isExist, argsArray)
      isAgeGreterThan18

    }
    catch {
      case ex: Throwable => println("*** Exception In ***" + ex.getMessage)
    }

    isAgeGreterThan18

  }

  def ageAtEncounterGreaterThanOrEqualTo65(r: CassandraRow, measureProperty: MeasureProperty): Boolean = {

    var isAgeGreterThan65 = false

    try {
      isAgeGreterThan65 = !r.isNullAt("dob") && !r.isNullAt("encounterdate") && dateUtility.getAge(r.getString("dob"), r.getString("encounterdate")) >= 65
      //  val argsArray: Array[String] = Array(sDate, eDate, compareYears.toString)
      //  measureLogger1(r, measureProperty, "ageGreaterThanOrEquals18", startDateDOB, isExist, argsArray)
    }
    catch {
      case ex: Throwable => println("*** Exception In ***" + ex.getMessage)
    }

    isAgeGreterThan65

  }

  def interventionNotPerformedDuringEncounter (r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }

  /*def assesmentPerformed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }*/


  def assessmentPerformed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }

  def interventionPerformed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    procedurePerformed(r: CassandraRow, measureProperty, element)
  }

  def procedurePerformed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }

  /*def interventionPerformedOverlapsEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    procedurePerformed(r: CassandraRow, measureProperty, element)
  }*/

  /*def diagnosis(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }*/

  def medicationActiveOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }

 /* def medicationAdministered(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }*/

  def medicationOrderStartsAfterStartOfDiagnosis(r: CassandraRow, measureProperty: MeasureProperty, medicationElement: String, diagnosisElement: String, noOfDays: Int): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, medicationElement)
  }

  /*def medicationActiveOverlapsMeasurementPeriod(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }*/

  /*def laboratoryTestPerformed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }*/

  /*def laboratoryTestNotPerformed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }*/

  /*def ageLessThan76OnEncounter(r: CassandraRow, measureProperty: MeasureProperty): Boolean = {

    var isAgeGreterThan18 = false

    try {

      isAgeGreterThan18 = !r.isNullAt("dob") && !r.isNullAt("encounterdate") && dateUtility.getAge(r.getString("dob"), r.getString("encounterdate")) < 76
      //  val argsArray: Array[String] = Array(sDate, eDate, compareYears.toString)
      //  measureLogger1(r, measureProperty, "ageGreaterThanOrEquals18", startDateDOB, isExist, argsArray)
      isAgeGreterThan18

    }
    catch {
      case ex: Throwable => println("*** Exception In ***" + ex.getMessage)
    }

    isAgeGreterThan18

  }*/

  def diagnosticStudyPerformed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)

  }


  /*def diagnosisOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)

  }*/

  def diagnosisOverlapsEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)

  }

  /*def diagnosisOverlapsMeasurementPeriod(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)

  }*/

  /*def physicalExamPerformed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)

  }*/


 /* def communicationFromProviderToProvider(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)

  }*/

  /*def communicationFromProviderToProviderNotDone(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    !dataTypeOnEncounter(r: CassandraRow, measureProperty, element)

  }*/

  /*def teleHealth(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    !dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }*/

  def teleHealthModifier(visit: CassandraRow, m: MeasureProperty): Boolean = {
    (
      encounterPerformed(visit, m, "Home Healthcare Services_Telehealth Modifier")
        || encounterPerformed(visit, m, "Nursing Facility Visit_Telehealth Modifier")
        || encounterPerformed(visit, m, "Office Visit_Telehealth Modifier")
        || encounterPerformed(visit, m, "Emergency Department Visit_Telehealth Modifier")
        || encounterPerformed(visit, m, "Domiciliary or rest home visit_Telehealth Modifierr")

      )

  }

  def isVisitTypeIn(visit: CassandraRow, m: MeasureProperty, elementLists: String*): Boolean = {

    elementLists.exists(x=>dataTypeOnEncounter(visit, m, x))

  }

  def encounterPerformed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }

  def interventionOrder(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }


 /* def medicationOrderDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }*/

  def medicationAdministeredDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }

  def medicationNotAdministeredDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    !dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }

  def dataTypeOnEncounter(visit: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit, measureProperty, element) && isDateEqual(visit, measureProperty, element + "_date", "encounterdate")
  }

  /*
  * Function returns whether Patient's Age is 18 year & older i.e. Adult
  * */
  def isPatientAdult(visit: CassandraRow, m: MeasureProperty): Boolean = {
    var flag=false
    try {
      flag =isAgeAbove(visit, m, true)
     }catch {
      case e: Exception => println(">>>>>>>"+e.getMessage)
    }
    flag
  }

  /*Function returns whether
 *Patient's Age is 65 year & older i.e. Elderly
 */
  def isPatientElderly(visit: CassandraRow, m: MeasureProperty): Boolean = {
    isAgeAbove(visit,m,true,65)
  }

  /**
    *
    * @param r cassendra row
    * @param measureProperty measure property
    * @param element element name to be checked
    * @return true or false based on isPOSEncounterNotPerformed
    */

  def isPOSEncounterNotPerformed(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {

    !checkElementPresent(r, measureProperty, element)
  }

  /**
    *
    * @param r cassandra row
    * @param measureProperty measure property
    * @param elementSequence element name to be checked
    * @return returns boolean
    */
  def isTeleHealthEncounterNotPerformed(r: CassandraRow, measureProperty: MeasureProperty, elementSequence: String*): Boolean = {
    elementSequence.exists(element => checkElementPresent(r, measureProperty, element))

  }

  def isInterventionPerformedBefore(r: CassandraRow, m:MeasureProperty, element:String, patientHistoryList: Broadcast[ List[CassandraRow] ], historyElement: String*): Boolean = {

    wasElementPresentBeforeOrEqualOtherElement(r, m, element,CompareOperator.LESS_EQUAL, patientHistoryList, historyElement )
  }

/*  /**
    *
    * @param visit cassendra row
    * @param m measure property
    * @param elementName get history element
    * @param patientHistoryList get history List
    * @return returns boolean
    */
  def isProcedurePerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)
  }*/

  /*
* --Function Name: isPneumococcalVaccineAdministered
* The function would check if a Pneumococcal Vaccine is administered and if it overlaps the measurement period
*/

  /*def isPneumococcalVaccineAdministered(visit: CassandraRow, measureProperty: MeasureProperty, Pneumococcal_Vaccine: String,  patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    checkElementPresent(visit, measureProperty, Pneumococcal_Vaccine) &&
      procedurePerformedStartsBeforeEndOfMeasurementPeriod(visit, measureProperty, Pneumococcal_Vaccine, patientHistoryList)
  }
*/


  /*
* Function would check if intervention is ordered or performed and overlaps the measurement period
* */
  def wasInterventionPerformedOrOrderedInHistory(r: CassandraRow, measureProperty: MeasureProperty, elementName: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    checkElementPresent(r, measureProperty, elementName) && checkElementInHistory(r, measureProperty,elementName,patientHistoryList)
  }

  def isInterventionOrdered(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    checkElementInHistory(visit, m,elementName, patientHistoryList)
  }

  /*def isElementPresentDuringMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[ List[CassandraRow]]): Boolean = {
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)
  }*/

 /* def isDiagnosticStudyPerformed(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList : Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentDuringMeasurementPeriod(visit, m,elementName, patientHistoryList)
  }
*/

 /* def wasProcedurePerformedBefore(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    isAssessmentPerformedBeforeOrEqual(visit, m,elementDate,historyElement, patientHistoryList)
  }*/

 /* def isLaboratoryTestPerformedBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeEncounterDate(visit,m,elementName,patientHistoryList)
  }*/

  def diagnosticStudyPerformed(r: CassandraRow, measureProperty: MeasureProperty, elements: String*): Boolean = {
    elements.exists(element=> dataTypeOnEncounter(r: CassandraRow, measureProperty, element))
  }

 // need to be removed and new function name  isDiagnosedDuringEncounter
  def isDiagnosedWithOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, elements: String*): Boolean = {
    elements.exists(element=>dataTypeOnEncounter(r, measureProperty, element))
  }

  def diagnosticStudyNotDone(r: CassandraRow, measureProperty: MeasureProperty, elements: String*): Boolean = {
    elements.exists(element=> dataTypeOnEncounter(r: CassandraRow, measureProperty, element))
  }

  def isDiagnosedWithBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, element:String, patientHistoryList:Broadcast[List[CassandraRow]], historyElement: String*): Boolean = {
    wasElementPresentBeforeOrEqualOtherElement(r, MeasureProperty, element, CompareOperator.LESS_EQUAL, patientHistoryList,historyElement)
  }

  def isDiagnosedConcurrentWith(r: CassandraRow, measureProperty: MeasureProperty, element1: String, element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }

  def isDiagnosticStudyOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }
  def isDiagnosticStudyConcurrentWith(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }


  def isCommunicationFromProviderToProviderOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }

 /* def isDiagnosisBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r, MeasureProperty, elementDate, historyElement, patientHistoryList)
  }*/

 /* def  isProcedurePerformedAfterOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r, MeasureProperty, elementDate, historyElement, patientHistoryList)
  }
*/

 /* def isProcedurePerformed(visit: CassandraRow, m:MeasureProperty,  historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    isDiagnosedWithInHistory(visit, m,  historyElement, patientHistoryList)
  }
*/



  def isActionNotPerformedWithReasonDuringEncounter(visit: CassandraRow, m:MeasureProperty, element:String ): Boolean ={
    dataTypeOnEncounter(visit: CassandraRow, m, element)
  }

  def isProcedurePerformedDuringEncounter(visit: CassandraRow, m:MeasureProperty, element:String ): Boolean ={
    dataTypeOnEncounter(visit: CassandraRow, m, element)
  }


  def isAssesmentPerformedDuringEncounter(visit: CassandraRow, m:MeasureProperty, element:String ): Boolean ={
    dataTypeOnEncounter(visit: CassandraRow, m, element)
  }

  def isEncounterPerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
   checkElementInHistory(visit, m,elementName, patientHistoryList)
  }

  def isImmunizationAdministeredBeforeEndOfMeasurementPeriod(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementInHistory(visit: CassandraRow, m, elementName,  patientHistoryList)
  }

  def isInterventionPerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementInHistory(visit, m,elementName, patientHistoryList)
  }

  def isInterventionBeforeEnd(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }


  def isMedicationPerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementInHistory(visit, m,elementName, patientHistoryList)

  }

  def wasMedicationPerformedInHistory(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementInHistory(visit, m,elementName, patientHistoryList)
  }

 /* def isInterventionBefore(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }*/

  def isLaboratoryTestPerformed(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementInHistory(visit, m,elementName, patientHistoryList)

  }

  def isPhysicalExamPerformed(r: CassandraRow, MeasureProperty:MeasureProperty, Value:Int, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentBeforeValue(r, MeasureProperty, Value, historyElement, patientHistoryList)
  }

  def isPhysicalExamPerformed(r:CassandraRow,measureProperty:MeasureProperty,element:String,patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(r,measureProperty,element,patientHistoryList)
  }

 /* def isMedicationPerformedConcurrentWith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }*/

/*  def isMedicationActivePerformedConcurrentWith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }*/
 /* def isMedicationAdministeredPerformedConcurrentWith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }*/
  /*def isDiagnosticStudy(r: CassandraRow, measureProperty: MeasureProperty,checkValue:String, value: Int): Boolean = {
    isAssessmentLessThan(r, measureProperty,checkValue, value)
  }*/

  def isEncounterPerformedConcurrentWith(r: CassandraRow, measureProperty: MeasureProperty, element1: String, element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }

 /* def isMedicationOrderNotDonePerformedConcurrentWith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }*/
 /* def isMedicationAdministeredNotDonePerformedConcurrentWith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }*/

 /* def isDiagnosticStudyLessThanValue(r: CassandraRow, measureProperty: MeasureProperty,checkValue:String, Value: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isAssessmentBeforeValue(r, measureProperty,Value,checkValue, patientHistoryList)

  }*/
 /* def isMedicationAdministeredPerformedInHistory(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)

  }*/


  /*def isInterventionOrderBeforeOrEqual(visit: CassandraRow, m: MeasureProperty, elementDate: String,historyElement: String,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {

    isElementPresentBeforeOrEqual(visit, m, elementDate: String, historyElement: String, patientHistoryList)

  }*/

  /*def physicalExamPerformedBeforeOrEqualInMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String,historyElement: String,months: Int,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {

    isElementBeforeOrEqualInMonths(visit, m, elementDate, historyElement, months,patientHistoryList)
  }*/

  def isInterventionOrderNotDoneBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    wasElementBeforeOrEqualInMonths(visit, m, elementDate, historyElement, months, patientHistoryList)

  }

 /* def isDiagnosedBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    isElementBeforeOrEqualInMonths(visit, m, elementDate, historyElement, months, patientHistoryList)

  }*/

 /* def physicalExamPerformedMostRecentResultInBetweenBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, months: Int, ValueStartRange: Double, ValueEndRange: Int, MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {

    ElementMostRecentResultInBetweenBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, months, ValueStartRange, ValueEndRange, MostRecentList)

  }*/

  /*def physicalExamPerformedMostRecentResultInBetweenBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, months: Int, mostRecentElementList:Broadcast[List[CassandraRow]]): Boolean = {

    isElementBeforeOrEqualInMonths(visit, m, elementDate, mostRecentElement, months, mostRecentElementList)
  }*/

  /*def physicalExamPerformedMostRecentResultGreaterOrEqualValueAndBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, months: Int, valueGreaterOrEqual: Double, mostRecentList:Broadcast[List[CassandraRow]]): Boolean = {

    elementMostRecentResultInBetweenBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, valueGreaterOrEqual , months, mostRecentList)
  }*/

  /*def isPhysicalExamPerformedNotDone(visit: CassandraRow, m: MeasureProperty, elements: String* ): Boolean = {
    !procedurePerformed(visit: CassandraRow, m: MeasureProperty, elements)

  }*/

  /*def isDiagnosedBeforeOrEqual(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    isElementPresentBeforeOrEqual(visit, m, elementDate, historyElement,  patientHistoryList)

  }*/

  /**
    * This function verifies if the diagnostic study is performed before encounter
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element name
    * @param patientHistoryList patient history list
    * @return returns true if the diagnostic study is performed before encounter else returns false
    */
  def wasDiagnosticStudyPerformedPerformedBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentBeforeEncounter(visit, m, elementName, patientHistoryList)
  }

  /**
    * This function verifies if the diagnostic study is performed before encounter
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element name
    * @param patientHistoryList patient history list
    * @return returns true if the diagnostic study is performed before encounter else returns false
    */
  def wasDiagnosedBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementPresentBeforeEncounter(visit, m, elementName, patientHistoryList)
  }

  def wasDiagnosticStudyPerformedInHistory(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementInHistory(visit,m,elementName,patientHistoryList)
  }

  /*def interventionOrderWithinOneDayOfEnc(r:CassandraRow,measureProperty:MeasureProperty,element1:String,element2:String,element3:String,days:Int): Boolean ={
    (!r.isNullAt(element1) && !r.isNullAt(element2) && !r.isNullAt(element3)) && checkElementPresent(r,measureProperty,element1) && checkElementPresent(r,measureProperty,element2) && isElementDateStartAfterStartOfWithInDays(r,measureProperty,element1,element3,days)
  }*/

  def isInterventionPerformedBeforeEnd(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }
 /* def isInterventionPerformedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }*/

  /*def isAssessmentValueBeforeOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, checkValue:String, value: Int): Boolean = {
    !r.isNullAt(checkValue) && r.getInt(checkValue)<value
    //val argsArray:Array[String]=Array(checkValue,Value.toString)
    //measureLogger(r, measureName, conditionType, "chkValueRangeLess", checkValue, isExist,argsArray)

  }*/

  /*def isMedicationPerformedBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r, MeasureProperty,elementDate,historyElement, patientHistoryList)
  }*/

 /* def isInterventionPerformedBeforeOrEqualInMonthInHistory(visit: CassandraRow, m: MeasureProperty, historyElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    wasElementAfterOrEqualEndDateInMonths(visit, m,  historyElement, months, patientHistoryList)
  }
*/


  def isPatientTobaccoUser(visit: CassandraRow, m: MeasureProperty, elementName:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasDiagnosedWith(visit, m, elementName, patientHistoryList)

  }


  /*def isPhysicalExamPerformedBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r, MeasureProperty, elementDate, historyElement, patientHistoryList)
  }*/

  /*def isPhysicalExamPerformedConcurrentWith(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }*/
 /* def isMedicationWithBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, elementDate:String, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r, MeasureProperty, elementDate, historyElement, patientHistoryList)
  }*/

 /* def PhysicalExamPerformedMostRecentResultLessValueAndBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, months: Int, valueLess: Double, mostRecentList:List[CassandraRow]): Boolean = {

    elementMostRecentResultLessBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, valueLess , months, mostRecentList)

  }*/

 /* def isEncounterPerformedMeasurementPeriod(r: CassandraRow, m: MeasureProperty, element: String, elementDate: String): Boolean ={
    checkElementPresent(r, m,element)    &&    isDuringMeasurementPeriod(r, m, elementDate)
  }*/

  def isEncounterPerformedOnEncounter(r: CassandraRow, m: MeasureProperty, element: String): Boolean ={
    checkElementPresent(r, m,element)
  }


  /*def isProcedureNotPerformedWithReasonDuringEncounter(r: CassandraRow, m: MeasureProperty, element: String, elementDate: String, elementDate2: String): Boolean ={
    checkElementPresent(r, m, element) &&
      isDateEqual(r, m, elementDate,elementDate2)
  }*/

  def isDiagnosticStudyConcurrentWith(r: CassandraRow, measureProperty: MeasureProperty, element1: String, element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }

   def isCommunicationFromProviderToProviderConcurrent(r: CassandraRow, measureProperty: MeasureProperty, element1: String, element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }

  def isAssessmentValueLessOrEqualDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, checkValue:String, value: Int): Boolean = {
    val isExist = !r.isNullAt(checkValue) && r.getInt(checkValue)<=value
    //val argsArray:Array[String]=Array(checkValue,Value.toString)
    //measureLogger(r, measureName, conditionType, "chkValueRangeLess", checkValue, isExist,argsArray)
    return isExist;
  }

  def isAssessmentPerformedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }

  def InterventionPerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit, m, elementName, patientHistoryList)

  }
  /*def isMedicationTherapyInDays(visit: CassandraRow, m: MeasureProperty,CurrentRowElement:String, element2:String, days:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    startAfterStartOfWithinDaysLessorEqual(visit, m: MeasureProperty,CurrentRowElement, element2,days,patientHistoryList)

  }*/

 /* def isDiagnosedWithStartAfterStart(visit: CassandraRow, m: MeasureProperty,CurrentRowElement:String, element2:String, days:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    startAfterStartOfEncounter(visit,m,CurrentRowElement,element2,patientHistoryList)
  }*/

 /* def isDiagnosedWithinDays(visit: CassandraRow, m: MeasureProperty,CurrentRowElement:String, element2:String, days:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    startAfterStartOfWithinDaysLessorEqual(visit, m: MeasureProperty,CurrentRowElement, element2,days,patientHistoryList)

  }*/
  def isMedicationAdministeredNotDoneOnEncounter(r: CassandraRow, m: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, m, element)
  }



  /*def isInterventionPerformedEqualBeforeEnd(r: CassandraRow, measureProperty: MeasureProperty, historyElement: String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementInHistory(r, measureProperty, historyElement,patientHistoryList)
  }*/

  /*def isLaboratoryTestPerformedDuringEncounter (r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }*/
 /* def isRecentLaboratoryTestResultInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosedWithInHistory(visit, m, elementName, patientHistoryList)

  }*/
 /* def isRecentLaboratoryTestResultMissingInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosedWithInHistory(visit, m, elementName, patientHistoryList)

  }*/

/*  def wasAssessmentNotPerformedInHistory(r: CassandraRow, MeasureProperty: MeasureProperty, historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    isDiagnosedWithEqualInMonths(r, MeasureProperty, historyElement, month, patientHistoryList)
  }*/

  def isRecentLaboratoryTestResultMissing(r: CassandraRow, measureProperty:MeasureProperty, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    patientHistoryList.value.exists(x => !x.isNullAt("element_date") &&
      x.getString("patientuid").equalsIgnoreCase(r.getString("patientuid")) &&
      historyElement.equalsIgnoreCase( x.getString("element")) &&
      (x.isNullAt("elementvalue") )
    )

  }

  def isDiagnosticPerformedNotDoneOnEncounter(visit:CassandraRow,measureProperty:MeasureProperty,diagnosisElement:String): Boolean ={
    !dataTypeOnEncounter(visit: CassandraRow, measureProperty, diagnosisElement)
  }

/*   def isPhysicalExamPerformedDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }*/
 /* def isMedicationOrderStartAfterStartOfLessOrEqualInDays(visit: CassandraRow,m: MeasureProperty, currentRowElement: String, element2: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    startAfterStartOfWithinDaysLessorEqual(visit,m, currentRowElement, element2, days, patientHistoryList)
  }*/



 /* def isDiagnosisOverlapsEncounter(visit:CassandraRow, m:MeasureProperty,elementDate:String, historyElement: String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isElementPresentBeforeOrEqual(visit: CassandraRow, m, elementDate, historyElement, patientHistoryList)
  }
*/

  /**
    * This function verifies if medication is active on encounter
    * @param visit current patient visit
    * @param m measure property
    * @param medicationElement medication element to be checked in current record
    * @return returns true if medication is active on encounter else returns false
    */
  def isMedicationActiveOnEncounter(visit:CassandraRow, m:MeasureProperty,medicationElement:String):Boolean= {
    dataTypeOnEncounter(visit: CassandraRow, m, medicationElement)
  }

  def isMedicationAdministeredOnEncounter(visit:CassandraRow, m:MeasureProperty,element:String):Boolean= {
    dataTypeOnEncounter(visit: CassandraRow, m, element)
  }

  def wasMedicationActiveBeforeEnd(visit:CassandraRow, m:MeasureProperty,elementName:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosisWithBeforeEnd(visit, m, elementName, patientHistoryList)
  }



/*  def isProcedurePerformedDuringEmergencyVisit(visit:CassandraRow, m:MeasureProperty,procedureElement:String, emergencyVisitArrivalDate:String,emergencyVisitDepartureDate:String):Boolean= {

    isElementPresentBetweenTwoDate(visit, m,procedureElement, emergencyVisitArrivalDate,emergencyVisitDepartureDate)

  }*/

  /**
    * This function verifies if diagnostic study is ordered during emergency visit
    * @param visit current patient visit
    * @param m measurement property
    * @param elementDate procedure element name
    * @param edvisitArrivalDate  emergency visit arrival date
    * @param edvisitDepartureDate emergency visit departure date
    * @return returns true if the diagnosis study ordered during emergency visit else returns false
    */

  def isDiagnosticStudyOrderedDuringEmergencyVisit(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {

    checkElementPresent(visit, m, element) &&
      (
        isDateInBetween(visit, m, elementDate, edvisitArrivalDate, edvisitDepartureDate)
          ||
          isDateTimeEqual(visit, m, elementDate, crtclDate)
        )

  }

 /* def isGlasgowComaScaleResultEqualDuringEmergencyVisit(visit:CassandraRow, m:MeasureProperty,procedureElement:String, emergencyVisitArrivalDate:String,emergencyVisitDepartureDate:String,resultValue:Double):Boolean= {

    isElementPresentBetweenTwoDatesAndResultValueEqual(visit:CassandraRow, m:MeasureProperty,procedureElement, emergencyVisitArrivalDate,emergencyVisitDepartureDate,resultValue)

  }*/

  /**
    * This function verifies if the diagnosis is done during emergency visit
    * @param visit current patient visit
    * @param m measurement property
    * @param procedureElement procedure element name
    * @param emergencyVisitArrivalDate  emergency visit arrival date
    * @param emergencyVisitDepartureDate emergency visit departure date
    * @param resultValue result value to be checked
    * @return returns true if the diagnosis is done during emergency visit else returns false
    */

  def isDiagnosedDuringEmergencyVisit(visit:CassandraRow, m:MeasureProperty,procedureElement:String, emergencyVisitArrivalDate:String,emergencyVisitDepartureDate:String,resultValue:Double):Boolean= {

    isElementPresentBetweenTwoDate(visit:CassandraRow, m:MeasureProperty,procedureElement:String, emergencyVisitArrivalDate:String,emergencyVisitDepartureDate:String)

  }


  def wasMedicationActiveInHistory(visit:CassandraRow, m:MeasureProperty, diagnosisElement:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementInHistory(visit, m, diagnosisElement, patientHistoryList)
  }

  /**
    * This function verifies if the assement is performed during emergency visit
    * @param visit
    * @param m measurement property
    * @param procedureElement procedure element name
    * @param emergencyVisitArrivalDate  emergency visit arrival date
    * @param emergencyVisitDepartureDate emergency visit departure date
    * @return returns true if the assessment is performed emergency visit else returns false
    */

  def isAssessmentPerformedDuringEmergencyVisit(visit:CassandraRow, m:MeasureProperty,procedureElement:String, emergencyVisitArrivalDate:String,emergencyVisitDepartureDate:String):Boolean= {

    isElementPresentBetweenTwoDate(visit, m,procedureElement, emergencyVisitArrivalDate,emergencyVisitDepartureDate)

  }

  def wasAssessmentPerformedInHistory(visit:CassandraRow, m:MeasureProperty, diagnosisElement:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementDuringMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, diagnosisElement: String, patientHistoryList)

  }

  def wasDiagnosedBeforeOrEqualEncounter(visit:CassandraRow, m:MeasureProperty, diagnosisElement:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isElementPresentBeforeOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, diagnosisElement: String, patientHistoryList)

  }

/*
  /**
    * this function will check whether Symptom Started During Arrival and Departure of Emergency Department
    * @param visit current visit
    * @param m measure property
    * @param procedureElement procedure element
    * @param emergencyVisitArrivalDate emergency visit arrival date
    * @param emergencyVisitDepartureDate emergency visit departure date
    * @return true if Symptom Started During Arrival and Departure of Emergency Department
    */
  def isSymptomStartedDuringEmergencyVisit(visit:CassandraRow, m:MeasureProperty,procedureElement:String, emergencyVisitArrivalDate:String,emergencyVisitDepartureDate:String):Boolean= {

    isElementPresentBetweenTwoDate(visit, m,procedureElement, emergencyVisitArrivalDate,emergencyVisitDepartureDate)

  }*/
  /**
    *
    * @param visit current visit
    * @param m measure property
    * @param elementDate counseling element
    * @param historyElement1 most recent screening element
    * @param historyElement2 tobacco user
    * @param months month in integer
    * @param patientHistoryMostRecentList patientHistoryMostRecentList
    * @param patientHistoryList patientHistoryList
    * @return
    */
  def wasMedicationNotOrderedAfterTobaccoScreeningUser(visit: CassandraRow, m: MeasureProperty, elementDate: String ,historyElement1: String ,historyElement2: String, months: Int, patientHistoryMostRecentList: Broadcast[List[CassandraRow]],patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasCounselingNotPerformedAfterTobaccoScreeningUser(visit, m, elementDate ,historyElement1 ,historyElement2, months, patientHistoryMostRecentList,patientHistoryList)
  }

  /**
    *  this function will check whether Medication Intoleranced Or Allergied is Before Or EqualEncounter
    * @param visit current current
    * @param m measure property
    * @param element element name
    * @param patientHistoryList patient history list
    * @return true if Medication Intoleranced Or Allergied is Before Or EqualEncounter
    */
  def wasMedicationAllergyBeforeEncounter(visit: CassandraRow, m:MeasureProperty, element: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeOrEqualEncounter(visit, m, element, patientHistoryList)
  }

  def wasMedicationAllergyInHistory(visit: CassandraRow, m:MeasureProperty, element: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
   checkElementInHistory(visit, m, element, patientHistoryList)
  }

  def wasMedicationInToleraneInHistory(visit: CassandraRow, m:MeasureProperty, element: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeOrEqualEncounter(visit, m, element, patientHistoryList)
  }


/*
  /**
    * this function will check whether Medication Ordered NotDone Before Or EqualEncounter
    * @param visit current current
    * @param m measure property
    * @param element element name
    * @param patientHistoryList  patient history list
    * @return true if Medication Ordered NotDone Before Or EqualEncounter
    */
  def wasMedicationOrderedNotDoneBeforeOrEqualEncounter(visit: CassandraRow, m:MeasureProperty,element: String,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeorEqualEncounterDate(visit, m, element, patientHistoryList)
  }*/



  /** this function will check whether Medication Ordered NotDone during measurement period
    * @param visit current current
    * @param m measure property
    * @param elementNames element names
    * @param patientHistoryList patient history list
    * @return true if Medication Ordered NotDone during measurement period
    */
  def isMedicationOrdered(visit: CassandraRow, m: MeasureProperty, patientHistoryList: Broadcast[List[CassandraRow]], elementNames: String*): Boolean = {

    elementNames.exists(elementName => checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList))
  }

/*  /**
    *
    * @param visit                 current current
    * @param measureProperty       measure property
    * @param tobaccoUserElement    tobaccoUserElement
    * @param tobaccoNonUserElement  tobaccoNonUserElement
    * @param medicalReasonElement medicalReasonElement
    * @param patientMostRecentHistoryList patientMostRecentHistoryList
    */
  def isMedicationNotOrderedAfterTobaccoScreeningUser(visit: CassandraRow, measureProperty: MeasureProperty, tobaccoUserElement: String, tobaccoNonUserElement: String, medicalReasonElement: String, patientMostRecentHistoryList: Broadcast[List[CassandraRow]]): Unit ={
    isCounselingNotPerformedAfterTobaccoScreeningUser(visit, measureProperty, tobaccoUserElement, tobaccoNonUserElement, medicalReasonElement, patientMostRecentHistoryList)
  }*/

 /* /**
  This function checks element present and checks element Date is before end date and EyeElement Date is equal to element Date.
    * @param currentVisit       currentvisit  from Cassandra tblencounter
    * @param m                  measure property
    * @param element            Element from tblencounter
    * @param elementDate       ElementDate from tblencounter
    * @param eyeElement        EyeElement that has to be checked
    * @param eyeElementDate    EyeElementDate that has to be checked
    * @return
    */
  def diagnosisStudyConcurrentWith(currentVisit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, eyeElement: String, eyeElementDate: String): Boolean = {
    var endDate: Date = m.quarterEndDate
    (
      (checkElementPresent(currentVisit, m, element) && isDateOverlapsMeasurementPeriod(currentVisit, m, elementDate))
        &&
        (checkElementPresent(currentVisit, m, eyeElement) && isDateEqual(currentVisit, m, eyeElementDate, elementDate))
      )

  }*/

  //  this function checks DiagnosticElementDate DiagnosisElementDate equal.
/*  def isDiagnosticDateConcurrentWithDiagnosisDate(currentVisit: CassandraRow, m: MeasureProperty, diagnosticElementDate: String, diagnosisElementDate: String): Boolean = {
    isDateEqual(currentVisit, m, diagnosticElementDate, diagnosisElementDate)
  }*/

  //  this function checks DiagnosticElement and DiagnosisElement present DiagnosticElementDate DiagnosisElementDate equal.
 /* def isDiagnosticStudyConcurrentWith(currentVisit: CassandraRow, m: MeasureProperty, diagnosticElement: String, diagnosticElementDate: String, diagnosisElement: String, diagnosisElementDate: String): Boolean = {
    checkElementPresent(currentVisit, m, diagnosticElement) &&
      checkElementPresent(currentVisit, m, diagnosisElement) &&
      isDignosticDateconcurrentwithDignoasisDate(currentVisit, m, diagnosticElementDate, diagnosisElementDate)
  }*/
  // to check Patient Characteristic in history whether patient was alive or not
/*  def wasPatientAlive(currentVisit: CassandraRow, measureProperty: MeasureProperty, element: String, historyList: Broadcast[List[CassandraRow]]): Boolean = {
    wasDiagnosedWith(currentVisit, measureProperty, element, historyList)
  }*/
  // this function checks the latest assessment performed in history.
  /*def wasLatestAssessmentPerformed(currentVisit: CassandraRow, measureProperty: MeasureProperty, Element: String, mostRecentAssessmentPerformed: Broadcast[List[CassandraRow]]): Boolean = {
    wasDiagnosedWith(currentVisit, measureProperty, Element, mostRecentAssessmentPerformed)
  }*/


/*
  def medicationAllergyOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }*/

  /*def communicationFromPatientToProviderOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }*/

  def isInfluenzaImmunizationAdministered(visit:CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit, measureProperty, element)
  }

  def isInfluenzaVaccineAdministered(visit: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit:CassandraRow, measureProperty, element)
  }

  def isInfluenzaVaccinationProcedure(visit:CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit:CassandraRow, measureProperty, element)
  }

  def isCommunicationFromPatientToProviderPreviousReceiptOfInfluenzaVaccine(visit: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit:CassandraRow, measureProperty, element)
  }

  def isCommunicationFromPatientToProviderPreviousReceiptOfInfluenzaVaccination(visit: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit:CassandraRow, measureProperty, element)
  }

  // Influenza Exception Function's

  def isCommunicationFromPatientToProviderInfluenzaVaccinationDeclined(visit:CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit, measureProperty, element)
  }

  def isActionNotPerformedWithReasonForInfluenza(visit:CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    checkElementPresent(visit, measureProperty, element)
  }

  def isAllergyToInfluenza(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }

  def isIntoleranceToInfluenza(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }

  def isLaboratoryTestOrder(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }

  def isLaboratoryTestOrder(visit:CassandraRow, m:MeasureProperty, element: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    checkElementDuringMeasurementPeriod(visit, m,  element, patientHistoryList)
  }
/*  /**
    *
    * @param r  cassandra row
    * @param m  measureProperty case class object contains conditionType as method type and measureName as measure name
    * @param elementNameToCheckInHistory element name to check in current row
    * @param elementHistoryResult element name to check in history
    * @param noOfMonths minus number of month from start date
    * @param historyList element history data
    * @return boolean value
    */

  def wasPhysicalExamPerformedDuringLastYear(r: CassandraRow, m:MeasureProperty, elementNameToCheckInHistory: String, elementHistoryResult:String, noOfMonths: Int, historyList:Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    if (historyList.value.length > 0) {
      isExist =wasPhysicalExamPerformedForRetinalDilatedExam(r,m,elementNameToCheckInHistory,elementHistoryResult,12,historyList)
      isExist
    }else isExist
  }*/
/*
  /**
    *  Checking Assesment element in the measurement period
    * @param visit  cassandra row
    * @param m  measureProperty case class object contains conditionType as method type and measureName as measure name
    * @param elementName
    * @param patientHistoryList
    * @return
    */
  def isAssesmentPerformed(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)

  }*/

  /**
    * checking Medication element active before the end of the measurement period.
    * @param visit cassandra row
    * @param m  measureProperty case class object contains conditionType as method type and measureName as measure name
    * @param historyElement
    * @param patientHistoryList
    * @return
    */
  def wasMedicationOrderInHistory(visit: CassandraRow, m:MeasureProperty,  historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementInHistory(visit, m,  historyElement, patientHistoryList)
  }

 /* def isLaboratoryTestPerformedAfter(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosedWithInHistory(visit, m, elementName, patientHistoryList)
  }*/


 /* /**
    * this function check whether Laboratory Test Values is within range in patient history for within no. years from enddate
    * @param visit current visit
    * @param m measure property
    * @param element element name which need to be checked in patient history
    * @param year no. of year back from enddate
    * @param lesserValue is the user given value from which elementvalue must be greater and equal
    * @param greaterValue is the user given value from which elementvalue must be lesser
    * @param patientHistory list of patient history
    * @return true if given Laboratory Test Values is within range for element date within years from enddate
    */
  def wasLaboratoryTestValuesInRangeInHistory(visit: CassandraRow, m: MeasureProperty, element: String, year: Int, lesserValue:Double, greaterValue:Double, patientHistory: Broadcast[List[CassandraRow]]): Boolean = {

    checkElementValuesInRangeInHistory(visit, m, element, year, lesserValue, greaterValue , patientHistory)

  }*/

/*  /**
    * this function check whether Laboratory Test Values Greater Or Equal  to given value in patient history before enddate
    * @param visit current visit
    * @param m measure property
    * @param element element name which need to be checked in patient history
    * @param value is the user given value from which elementvalue must be greater and equal
    * @param patientHistory list of patient history
    * @return true if Laboratory Test Values Greater Or Equal to given value for element date before enddate from patient history
    */
  def wasLaboratoryTestValuesGreaterOrEqualInHistory(visit: CassandraRow, m: MeasureProperty, element: String, value:Double, patientHistory: Broadcast[List[CassandraRow]]): Boolean = {

    checkElementGreaterOrEqualInHistory(visit, m, element, value, patientHistory: Broadcast[List[CassandraRow]])

  }*/
/*
  /**
    * This Function verifies encounter performed in history before end of measurement.
    * @param visit Current visit
    * @param m  Measure Property of that measure
    * @param elementName Element Name to look in patient History.
    * @param patientHistoryList PatientHistory List
    * @return
    */
  def  encounterPerformedBeforeEnd(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosisWithBeforeEnd(visit,m,elementName,patientHistoryList)
  }
*/

/*

  /**
    * This Function verifies encounter performed in history before end of measurement.
    * @param visit Current visit.
    * @param m  Measure Property of the measure.
    * @param historyElement Element Name to look in patient History.
    * @param patientHistoryList PatientHistory List
    * @return
    */
  def isLaboratoryTestPerformedXYearsBeforeEnd(visit: CassandraRow, m: MeasureProperty, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    isProcedurePerformedXYearsInHistory(visit,m,historyElement,noOfYears,patientHistoryList)
  }
*/

  /**
    * This function verifies procedure is performed before end Date.
    * @param visit current visit of the patient.
    * @param m      Measure Property of the measure.
    * @param historyElement  History Element to look in patient History.
    * @param patientHistoryList Patient History List.
    * @return   Returns those patient whose procedure is performed before endOfMeasurement period.
    */
  def isProcedurePerformedBeforeEnd(visit:CassandraRow, m:MeasureProperty,historyElement:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosisWithBeforeEnd(visit, m,historyElement, patientHistoryList)
  }

/*
  def isMedicationActivePerformedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }*/
/*
  /**
    * This function verifies the physical Exam performed in range between start of measurment period and end of measurement period
    * or physical exam result in range between start of measurement period and X months before start of measurement period.
    * @param visit Current visit of the patient.
    * @param m     Measure property of the Measure.
    * @param noOfMonth No. of Month to go back from start of measurement period.
    * @param elementInHistory element that has to be look in History.
    * @param resultElementInHistory Element whose result has to be verified in the range between start of the measurement period and X months before start of the measurement period.
    * @param historyList   Patient history List.
    * @return  return those patient whether their physical exam performed in history or their result in the range between start of the measurement period and X months before start of the measurement period.
    */
  def wasPhysicalExamPerformed(visit: CassandraRow, m: MeasureProperty,noOfMonth: Int,elementInHistory: String,resultElementInHistory: String,historyList: Broadcast[List[CassandraRow]]):Boolean={
    physicalExamPerformedInHistory(visit, m, elementInHistory, historyList) ||
      physicalExamResultInxMonthsHistory(visit, m, resultElementInHistory, noOfMonth, historyList)

  }*/
  def physicalExamPerformedMostRecentResultLessorEqualValueAndBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, valueGreaterOrEqual: Double, mostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    mostRecentElementResultGreatAndBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, valueGreaterOrEqual , month, mostRecentList)

  }

  def physicalExamPerformedMostRecentResultGreaterOrEqualValueAndBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, months: Int, ValueGreaterOrEqual: Double, mostRecentList:Broadcast[List[CassandraRow]]): Boolean = {

    mostRecentElementResultGreatAndBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, ValueGreaterOrEqual , months, mostRecentList)

  }
  def physicalExamPerformedMostRecentBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, months: Int, mostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    mostRecentElementBeforeOrEqualInMonth(visit,m,elementDate, mostRecentElement, months,mostRecentList)
  }


  def isInterventionOrderDoneBeforeOrEqualInMonth(r: CassandraRow, measureProperty:MeasureProperty,firstDate: String, compareDate: String, months:Int, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isDateEqual(r: CassandraRow, measureProperty, firstDate: String, compareDate: String)
  }

 //All the below 5 function has there _ name and duplicate of these function has too be removed
  def isDiagnosedDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, elements: String*): Boolean = {
    elements.exists(element=>dataTypeOnEncounter(r, measureProperty, element))
  }





  /**
    * This function verifies the diagnosisDuringEdorEncounter
    * @param visit Current Visit of the patient.
    * @param m     Measure Property of the Measure.
    * @param element    Element whose Diagnosis is to be checked.
    * @param elementDate       Element Date that has to be checked whether it is equal to other date or it is in between two dates.
    * @param edvisitArrivalDate  edVisitarrivalDate of the patient.
    * @param edvisitDepartureDate edvisitDepartureDate of the patient.
    * @param crtclDate            crtclDate of the patient.
    * @return
    */
  def isDiagnosisDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    checkElementPresent(visit, m, element) &&
      (
        isDateInBetween(visit, m, elementDate, edvisitArrivalDate, edvisitDepartureDate)
          ||
          isDateTimeEqual(visit, m, elementDate, crtclDate)
        )
  }


  /**
    * This function verifies the isLaboratoryTestOrderDuringEDOrCCEncounter
    * @param visit            Current Visit of the patient.
    * @param m                Measure Property of the Measure.
    * @param element          Element whose LaboratoryTestOrder is to be checked.
    * @param elementDate      Element Date that has to be checked whether it is equal to other date or it is in between two dates.
    * @param edvisitArrivalDate  edVisitarrivalDate of the patient.
    * @param edvisitDepartureDate edvisitDepartureDate of the patient.
    * @param crtclDate            crtclDate of the patient.
    * @return
    */
  def isLaboratoryTestOrderDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
   checkElementPresent(visit, m, element) &&
      (
        isDateInBetween(visit, m, elementDate, edvisitArrivalDate, edvisitDepartureDate)
          ||
          isDateTimeEqual(visit, m, elementDate, crtclDate)
        )
  }
/*  def isDiagnosisWithBefore(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
     isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }*/

  def  wasEncounterPerformedInHistory(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit,m,elementName,patientHistoryList)
  }

  def wasLaboratoryTestPerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosedWithInHistory(visit, m,elementName, patientHistoryList)

  }
/*  /**
    * This Function verifies encounter performed in history before end of measurement.
    * @param visit Current visit.
    * @param m  Measure Property of the measure.
    * @param historyElement Element Name to look in patient History.
    * @param patientHistoryList PatientHistory List
    * @return
    */
  def wasLaboratoryTestPerformedXYearsBeforeEnd(visit: CassandraRow, m: MeasureProperty, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    isProcedurePerformedXYearsInHistory(visit,m,historyElement,noOfYears,patientHistoryList)
  }*/

  /**
    * This function checks whether the count of element passed in countElementList is >= the count
    * @param visit            current visit
    * @param m  Measure Property of the measure.
    * @param count            no. of count from which will be compared from countElementList
    * @param countElementList List of patient and count of element
    * @return true if count of element in list is greater or equal to count passed in parameter for that patientuid
    */
  def getEncounterCountFromHistory(visit: CassandraRow, m: MeasureProperty, count: Int, greaterFlag: Boolean, countElementList: List[(String, Int)]): Boolean = {

    greaterFlag match {
      case true => countElementList.exists(r => r._1.equalsIgnoreCase(visit.getString("patientuid")) && r._2 >= count)
      case false => countElementList.exists(r => r._1.equalsIgnoreCase(visit.getString("patientuid")) && r._2 == count)
    }
  }

  def getProcedureCountFromHistory(visit: CassandraRow, m: MeasureProperty, count: Int, greaterFlag: Boolean, countElementList: List[(String, Int)]): Boolean = {

    greaterFlag match {
      case true => countElementList.exists(r => r._1.equalsIgnoreCase(visit.getString("patientuid")) && r._2 >= count)
      case false => countElementList.exists(r => r._1.equalsIgnoreCase(visit.getString("patientuid")) && r._2 == count)
    }
  }
//**************************************************************************************************************************************************

  def isDiagnosedWithBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeOrEqualInMonths(visit, m, elementDate, historyElement, months, patientHistoryList)
  }
   //236,72
  def wasProcedurePerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    checkElementInHistory(visit,m,elementName,patientHistoryList)
  }
   //236,119
  def isInterventionPerformed(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementDuringMeasurementPeriod(visit, m,elementName, patientHistoryList)
  }
   //236
  def isPhysicalExamPerformedDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }
    //236
  def  wasEncounterPerformed(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementDuringMeasurementPeriod(visit,m,elementName,patientHistoryList)
  }

  def isActionNotPerformedWithReason(visit: CassandraRow, m:MeasureProperty, element:String, patientHistory: Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit,m,element,patientHistory)
  }

  def isMedicationAdministeredPerformed(visit: CassandraRow, m:MeasureProperty, element:String, patientHistory: Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit,m,element,patientHistory)
  }
   //236
  def wasDiagnosedInHistory(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementInHistory(visit, m,elementName, patientHistoryList)
  }
   //72,128
   def isDiagnosedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, elements: String*): Boolean = {
     elements.exists(element => dataTypeOnEncounter(r, measureProperty, element))
   }

  //128,119
  def wasInterventionPerformedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    checkElementInHistory(visit,m,elementName,patientHistoryList)
  }

  //128
  def wasPhysicalExamNotPerformedDuringEncounter(r: CassandraRow, MeasureProperty:MeasureProperty, firstDate: String, compareDate: String): Boolean = {
    isDateEqual(r, MeasureProperty, firstDate, compareDate)
  }
   //119
  def wasDiagnosisInHistory(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit, m,elementName, patientHistoryList)
  }

  //119`
  def isEncounterPerformed(visit: CassandraRow, m:MeasureProperty, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit, m,  historyElement, patientHistoryList)
  }

  /** this function check whether immunization was administered before end of measuremnet period
    * @param visit visit
    * @param m measure property
    * @param elementName element which will be checked in history
    * @param patientHistoryList patient history list
    * @return true if element was present in history before end of measurement period
    */
  // QPP 111
  def wasImmunizationAdministeredInHistory(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    val isExist = checkElementPresent(visit, m, elementName) &&  checkElementInHistory(visit, m,elementName,patientHistoryList)
    isExist
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure utility
    * @param patientHistoryList get patient history list
    * @return get patient list based on medical conditions
    */

  def getCountFraminghamCADRiskFactorsInHistory(visit: CassandraRow, m: MeasureProperty, patientHistoryList: Broadcast[List[CassandraRow]]): Int = {
    var counter = 0
    if (procedurePerformedStartsBeforeEndOfMeasurementPeriod(visit, m,PRIME72Elements.Current_Tobacco_Smoker, patientHistoryList))
      counter += 1
    if (procedurePerformedStartsBeforeEndOfMeasurementPeriod(visit, m, PRIME72Elements.Family_History_Chd, patientHistoryList))
      counter += 1
    //HDL_Test
    if (isAssessmentBeforeValue(visit, m, 40,PRIME72Elements.High_Density_Lipoprotein__Hdl_, patientHistoryList))
      counter += 1
    if (procedurePerformedStartsBeforeEndOfMeasurementPeriod(visit, m, PRIME72Elements.Diagnosis_Of_Hypertension, patientHistoryList))
      counter += 1
    //AnPhTh
    if (isDiagnosedWithInHistory(visit, m,PRIME72Elements.Anti_Hypertensive_Pharmacologic_Therapy, patientHistoryList))
      counter += 1
    counter
  }

  def interventionOrderMostRecentBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, mostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    mostRecentElementBeforeOrEqualInMonth(visit,m,elementDate, mostRecentElement, month,mostRecentList)
  }
  def isLaboratoryTestPerformedNotDone(r:CassandraRow,measureProperty:MeasureProperty,labTestElement:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    checkElementDuringMeasurementPeriod(r,measureProperty,labTestElement,patientHistoryList)
  }
  //6
  def isProcedurePerformed(visit: CassandraRow, m:MeasureProperty,  historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit, m,  historyElement, patientHistoryList)
  }

  def isProcedurePerformedBeforeEndOfMeasurementPeriod(visit: CassandraRow, m:MeasureProperty,  historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementInHistory(visit, m,  historyElement, patientHistoryList)
  }

 /* def isMedicationOrder(visit: CassandraRow, m:MeasureProperty, element:String, patientHistory: Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit,m,element,patientHistory)
  }*/

  def isDeviceAppliedBeforeOrEqual(visit: CassandraRow, m:MeasureProperty, element:String, patientHistory: Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementInHistory(visit,m,element,patientHistory)
  }
  def isAssessmentPerformed(visit:CassandraRow, m:MeasureProperty, historyElement: String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementDuringMeasurementPeriod(visit: CassandraRow, m,  historyElement, patientHistoryList)
  }


  /**
    * This Function verifies encounter performed in history before end of measurement.
    * @param visit Current visit.
    * @param m  Measure Property of the measure.
    * @param historyElement Element Name to look in patient History.
    * @param patientHistoryList PatientHistory List
    * @return
    *
    * */
  def wasLaboratoryTestPerformedInXYears(visit: CassandraRow, m: MeasureProperty, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    isProcedurePerformedXYearsInHistory(visit,m,historyElement,noOfYears,patientHistoryList)
  }

  //128

/*  def wasInterventionOrderedInHistory(r: CassandraRow, measureProperty:MeasureProperty, elementDate:String, historyElement: String, patientHistoryList: Broadcast[ List[CassandraRow] ]): Boolean = {
    isAssessmentPerformedBeforeOrEqual(r: CassandraRow, measureProperty:MeasureProperty, elementDate, historyElement: String, patientHistoryList )
  }*/

 /* def wasPhysicalExamNotPerformedDuringEncounter(r: CassandraRow, measureProperty:MeasureProperty,firstDate: String, compareDate: String): Boolean = {
    isDateEqual(r, measureProperty, firstDate, compareDate)
  }*/

 /* def isDiagnosedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, elements: String*): Boolean = {
    elements.exists(element=>dataTypeOnEncounter(r, measureProperty, element))
  }*/

 /* def isMostRecentResultWithinXMonthsInXRange(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, months: Int, MostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    mostRecentElementBeforeOrEqualInMonth(visit,m,elementDate, mostRecentElement, months,MostRecentList)
  }*/

/*
  def isMostRecentResultWithinXMonthsGreaterThanX(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, months: Int, valueGreaterOrEqual: Double, mostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    elementMostRecentResultInBetweenBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, valueGreaterOrEqual , months, mostRecentList)
  }
*/

 /* def isInterventionOrderedInXMonths(r: CassandraRow, MeasureProperty:MeasureProperty,firstDate: String, compareDate: String, months:Int, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    isDateEqual(r: CassandraRow, MeasureProperty, firstDate: String, compareDate: String)
  }*/

  /*def isMostRecentResultWithinXMonthsLessThanX(visit: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, months: Int, valueGreaterOrEqual: Double,mostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    mostRecentElementResultGreatAndBeforeOrEqualInMonth(visit, m, elementDate, mostRecentElement, valueGreaterOrEqual , months, mostRecentList)
  }*/

  /*def isInterventionNotOrderedInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    isElementBeforeOrEqualInMonths(visit, m, elementDate, historyElement, months, patientHistoryList)

  }*/
  /*def wasDiagnosedInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    isElementBeforeOrEqualInMonths(visit, m, elementDate, historyElement, months, patientHistoryList)
  }*/

  // This function verifies the mostRecentLaboratory Test Performed of the Patient during measurement Period.
  def isMostRecentLaboratoryTestValueGreaterOrEqualThanX(visit:CassandraRow, m:MeasureProperty, value:Double, laboratoryTestElement:String, mostRecentPatientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    isElementValueGreaterOrEqualThanX(visit,m,value,laboratoryTestElement,mostRecentPatientHistoryList)
  }

  // This function verifies the mostRecentLaboratory Test Performed of the Patient during measurement Period.
  def isMostRecentLaboratoryTestValueLessThanX(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    checkElementValueDuringMeasurementPeriod(visit, m, elementName, value, flag, patientHistoryList)
  }

 /* //72
  /**
    * This function is used to check if any Laboratory test not done and reason is specified for it
    * @param r cassandra record for the patient
    * @param measureProperty measurement property
    * @param labTestElement labTestElement is the reason for test not done
    * @param patientHistoryList list of patient history data
    * @return returns true if labTestElement reason found else returns false
    */
  def isLaboratoryTestNotDone(r:CassandraRow,measureProperty:MeasureProperty,labTestElement:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    isDiagnosedWithInHistory(r,measureProperty,labTestElement,patientHistoryList)
  }*/





  def isImmunizationAdministeredDuringEncounter(visit: CassandraRow, m:MeasureProperty, element:String ): Boolean ={
  dataTypeOnEncounter(visit, m, element)
}
///IsMedicationOrderDuringEncounter //isMedicationOrderedDuringEncounter
 /* def isMedicationActiveOverlapsEncounter(visit:CassandraRow, m:MeasureProperty,elementDate:String, historyElement: String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isElementPresentBeforeOrEqual(visit: CassandraRow, m, elementDate, historyElement, patientHistoryList)
  }*/

  def isCommunicationDoneFromPatientToProviderDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }
 /* def isMedicationAllergyDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }*/
  def isMedicationActiveDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }

  def isMedicationOrderedOnEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String):Boolean= {
    dataTypeOnEncounter(visit: CassandraRow, m, elementName)
  }

  def isMedicationOrderedDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }
  def wasMedicationOrderedNotDoneInHistory(visit: CassandraRow, m:MeasureProperty,Element: String,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeOrEqualEncounter(visit, m, Element, patientHistoryList)
  }

 /* def isAssessment(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }*/

  def isAssessmentPerformedBeforeEndOfMeasurementPeriod(visit:CassandraRow, m:MeasureProperty,element:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementInHistory(visit: CassandraRow, m, element,  patientHistoryList)
  }
  def isInterventionOrderOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }

 /* def isPhysicalExamPerformedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }*/

  /**
    * this function will check whether Tobacco Cessation Intervention element Done Before EndDate
    * @param visit current visit
    * @param m measure property
    * @param elementName element name which will be searched in history
    * @param patientHistoryList patient history list
    * @return true if tobacco Cessation Intervention element Done Before EndDate
    */
  def TobaccoCessationInterventionDoneBeforeEndDate(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit, m,elementName, patientHistoryList)
  }

/*
  def isDeviceAppliedBefore(visit: CassandraRow, m:MeasureProperty, elementDate:String, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    wasDiagnosedBefore(visit, m, elementDate, historyElement, patientHistoryList )
  }*/


/*
  /**
    * This function verifies the procedure of a patient is performed during emergency encounter.
    * @param visit                Current visit of the patinent.
    * @param m                    Mesaure Property of the measure.
    * @param element              Element that has to be verified during edvisit.
    * @param posElement           place of service  that has to be verified during edvisit.
    * @param edvisitArrivalDate   emergency visit Arrival date of the patient.
    * @param edvisitDepartureDate emergency visit departure  date of the patient.
    * @param crtclDate            Critical Care visit date of the patient.
    * @return                     It will return those patient whose procedure is performed during emergency encounter.
    */
  def isProcedurePerformedDuringEncounter(visit: CassandraRow, m: MeasureProperty, element: String, posElement: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    isDiagnosisDuringEncounter(visit, m, element, posElement, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }*/

  /**
    * This function verifies if the intervention starts before end of measurement period within X period
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement element to be checked in measurement period in history
    * @param calenderUnit represent calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param calenderInterval represents no of calender unit to be checked
    * @param timeCompareOperator represents time compare operators (valid operators are CompareOperator.{GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL})
    * @param leastRecentPatientHistoryList least recent patient history list
    * @return returns true if the intervention starts before end of measurement period within X period else returns false
    */
 def wasInterventionPerformedBeforeEnd(visit: CassandraRow, m: MeasureProperty, procedureElement: String,calenderUnit:String, calenderInterval: Int,timeCompareOperator:String, leastRecentPatientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
   wasElementStartsBeforeEndOfMeasurementPeriodWithinXPeriod(visit,m,procedureElement,calenderUnit,calenderInterval,timeCompareOperator,leastRecentPatientHistoryList)
  }

  /*def wasProcedurePerformedBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeEncounterDate(visit,m,elementName,patientHistoryList)
  }*/

/*  /**
    * This function verifies if the element was diagnosed before or equal to encounter date
    * @param visit current patient visit
    * @param m measure property
    * @param elementDate element date
    * @param historyElement diagnosis element to be checked in History
    * @param patientHistoryList patient History list
    * @return returns true if the element was diagnosed before or equal to encounter date else returns false
    */
  def wasDiagnosedWithBeforeOrEqual(visit: CassandraRow, m:MeasureProperty, elementDate:String, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    wasElementBeforeOrEqualInHistory(visit, m, elementDate, historyElement, patientHistoryList )

  }*/

  def wasProcedurePerformedBeforeOrEqual(visit: CassandraRow, m:MeasureProperty, elementDate:String, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    wasElementBeforeOrEqualInHistory(visit, m, elementDate, historyElement, patientHistoryList )

  }


  def wasAssessmentPerformedBeforeOrEqual(visit: CassandraRow, m:MeasureProperty, elementDate:String, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    wasElementBeforeOrEqualInHistory(visit, m, elementDate, historyElement, patientHistoryList )

  }

  def isInterventionPerformedDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }

  def isAssessmentPerformedDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }
  def isMedicationActiveOrdered(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }

  def isInterventionNotDoneDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }


  /**
    * This function verifies the patient whose result is negative for Retinal Dilated Exam.
    * @param visit  Current Visit of the patient.
    * @param m      Measure Property of the measure.
    * @param elementCheckInHistory Element that has to verified in the history.
    * @param noOfMonths            Number of months that has to be go back in history.
    * @param historyList          Patient histroy list.
    * @return  It will return those patient whose result is negative for Retinal Dilated Exam.
    */
  def wasNegativeResultWithRetinalDilatedExam(visit: CassandraRow, m: MeasureProperty, elementCheckInHistory: String,noOfMonths: Int, flag:String , historyList:Broadcast[List[CassandraRow]]): Boolean = {
    wasPhysicalExamPerformedXForRetinalDilatedExam(visit, m, elementCheckInHistory, noOfMonths,flag, historyList)
  }


  def isDiagnosedWithInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }

  def physicalExamPerformedInHistory(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }

  def isDiagnosisWithBeforeEnd(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit, m, elementName, patientHistoryList)
  }
  def wasDiagnosedWithInHistory(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit, m, elementName, patientHistoryList)
  }

  def isDiagnosticStudyBeforeOrEqual(visit: CassandraRow, m:MeasureProperty, element:String, patientHistoryList:Broadcast[List[CassandraRow]], historyElement: String* ): Boolean = {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, element,CompareOperator.LESS_EQUAL,  patientHistoryList,historyElement )
  }

  def isAssessmentPerformedBeforeOrEqual(visit: CassandraRow, m:MeasureProperty, element:String, patientHistoryList:Broadcast[List[CassandraRow]], historyElement: String*): Boolean = {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, element ,CompareOperator.LESS_EQUAL, patientHistoryList,historyElement )
  }

  /*def isDiagnosedInHistory(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    isElementPresentBeforeOrEqual(visit, m, elementDate, historyElement, patientHistoryList)
  }*/

  def wasProcedurePerformedInHistory(visit: CassandraRow, m:MeasureProperty, element:String, patientHistoryList:Broadcast[List[CassandraRow]], historyElement: String*): Boolean = {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, element,CompareOperator.LESS_EQUAL, patientHistoryList, historyElement)
  }

  def isProcedurePerformedXYearsInHistory(visit: CassandraRow, m: MeasureProperty, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     wasProcedurePerformedInXYears(visit, m: MeasureProperty, historyElement, noOfYears, patientHistoryList)
  }

  def interventionPerformedBeforeEncounterInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String ="encounterdate", histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     wasElementBeforeOrEqualInMonths(visit, m, elementDate, histroyElement, month, patientHistoryList)
  }

  /**
    * This function verifies if element1 is performed during procedure performed of element2
    * @param visit current patient visit
    * @param m measure property
    * @param element1 element1 intervention performed element
    * @param element2 element2 procedure performed element
    * @param element1_date element1_date  intervention performed element date
    * @param element2_date element2_date  procedure element date
    *@return returns true if element1 is ordered during procedure performed of element2
    */
  def isInterventionPerformedDuringProcedurePerformed(visit:CassandraRow,m:MeasureProperty,element1:String,element1_date:String,element2:String,element2_date:String): Boolean ={
    checkNotNull(visit,element1,element1_date,element2,element2_date) && isDateEqual(visit,m,element1_date,element2_date)
}


  /**
    * This function verifies if element1 is ordered during procedure performed of element2
    * @param visit current patient visit
    * @param m measure property
    * @param element1 element1 intervention ordered element
    * @param element2 element2 procedure performed element
    * @param element1_date element1_date  intervention ordered element date
    * @param element2_date element2_date  procedure element date
    * @return returns true if element1 is ordered during procedure performed of element2
    */
  def isInterventionOrderedDuringProcedurePerformed(visit:CassandraRow,m:MeasureProperty,element1:String,element1_date:String,element2:String,element2_date:String): Boolean ={
    checkNotNull(visit,element1,element1_date,element2,element2_date) && isDateEqual(visit,m,element1_date,element2_date)
  }

  def isInterventionPerformedDuringProcedure(visit:CassandraRow,m:MeasureProperty,element1:String,element1_date:String,element2:String,element2_date:String):Boolean={
    checkNotNull(visit,element1,element1_date,element2,element2_date) && isDateEqual(visit,m,element1_date,element2_date)
  }

  /**
    * This function verifies if element1 procedure performed during procedure performed of element2
    * @param visit current patient visit
    * @param m measure property
    * @param element1 element1 intervention ordered element
    * @param element2 element2 procedure performed element
    * @param element1_date element1_date  intervention ordered element date
    * @param element2_date element2_date  procedure element date
    * @return returns true if element1 procedure performed during procedure performed of element2
    */
  def isProcedurePerformedDuringProcedure(visit:CassandraRow,m:MeasureProperty,element1:String,element1_date:String,element2:String,element2_date:String):Boolean={
    checkNotNull(visit,element1,element1_date,element2,element2_date) && isDateEqual(visit,m,element1_date,element2_date)
  }


  /*def isAssessmentPerformedDuringProcedure(visit:CassandraRow,m:MeasureProperty,element1:String,element1_date:String,element2:String,element2_date:String):Boolean={
    isProcedurePerformedDuringProcedure(visit,m,element1,element1_date,element2,element2_date)
  }*/

  /**
    * This function verifies if the element Symptom is active on encounter date
    * @param r current patient visit
    * @param measureProperty  measure property
    * @param element symptom element to be checked
    * @return returns true if Symptom is active on encounter date else returns false
    */
  def isSymptomOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r, measureProperty, element)
  }

  /**
    * This function is uced for checking DiagnosticStudy Performed Before Or Equal EncounterDate
    * @param visit current patient visit
    * @param m measure property
    * @param elementName get DiagnosticStudy element to check
    * @param patientHistoryList get patient History
    * @return
    */

  def wasDiagnosticStudyPerformedBeforeOrEqualEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
     wasElementPresentBeforeOrEqualEncounter(visit, m, elementName, patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property file
    * @param elementDate get Assessment Performed element date
    * @param historyElement get history element list for Assessment Performed
    * @param month get months for minus element date
    * @param patientHistoryList get patient list for Assessment Performed
    * @return return if Assessment Performed Before Or Equal In Months
    */


  def wasAssessmentPerformedBeforeOrEqualInMonth(visit: CassandraRow, m: MeasureProperty, elementDate: String,historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeOrEqualInMonths(visit, m, elementDate, historyElement, month, patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property file
    * @param elementDate get Assessment Performed element date
    * @param historyElement get history element list for Assessment Performed
    * @param month get months for minus element date
    * @param patientHistoryList get patient list for Assessment Performed
    * @return return if Assessment Performed Before Or Equal In Months
    */

  def wasAssessmentPerformedInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String,historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeOrEqualInMonths(visit, m, elementDate, historyElement, month, patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property file
    * @param elementDate get Assessment Performed element date
    * @param historyElement get history element list for Assessment Performed
    * @param month get months for minus element date
    * @param patientHistoryList get patient list for Assessment Performed
    * @return return if Assessment Not Performed Before Or Equal In Months
    */

  def wasAssessmentNotPerformedInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String,historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeOrEqualInMonths(visit, m, elementDate, historyElement, month, patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property file
    * @param elementDate get Assessment Performed element date
    * @param historyElement get history element list for Assessment Performed
    * @param month get months for minus element date
    * @param patientHistoryList get patient list for Assessment Performed
    * @return return if Assessment Performed After Or Equal In Months
    */

  def wasAssessmentPerformedAfterEncounterWithInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String,historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterOrEqualInMonths(visit, m, elementDate, historyElement, month, patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property file
    * @param elementDate get Diagnosed Performed element date
    * @param historyElement get history element list for Diagnosed Performed
    * @param month get months for minus element date
    * @param patientHistoryList get patient list for Diagnosed Performed
    * @return return if Diagnosed In Months
    */

  def wasDiagnosedInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String,historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeOrEqualInMonths(visit, m, elementDate, historyElement, month, patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property file
    * @param elementDate get Diagnosed Performed element date
    * @param historyElement get history element list for Diagnosed Performed
    * @param month get months for minus element date
    * @param patientHistoryList get patient list for Diagnosed Performed
    * @return return if Diagnosed In Months
    */

  def wasDiagnosedAfterEncounterWithInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String,historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterOrEqualInMonths(visit, m, elementDate, historyElement, month, patientHistoryList)
  }

  def wasProcedurePerformedBeforeEncounterInXPeriod(visit: CassandraRow, m: MeasureProperty, histroyElement: String,calenderUnit:String, calenderInterval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentBeforeOrEqualElementInXPeriod(visit: CassandraRow, m: MeasureProperty, histroyElement: String,calenderUnit, calenderInterval: Int, patientHistoryList: Broadcast[List[CassandraRow]])

  }
  def isPhysicalExamPerformedWithResultDuringEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String):Boolean= {
    checkElementValueOnEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String)
  }

  /**
    * This function verifies if negative depression screening is done on encounter date
    * @param visit current patient visit
    * @param m measurement property
    * @param element element name for negative depression screening
    * @return returns true if negative depression screening is done on encounter date else return false
    */
  def isNegativeDepressionScreeningOnEncounter(visit:CassandraRow,m:MeasureProperty,element:String): Boolean ={
    dataTypeOnEncounter(visit,m,element)
  }
/*  def wasAssessmentPerformedAfterDiagnosis(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String*):Boolean= {
     wasElementPresentAfter(visit, m, elementName, patientHistoryList,HistoryelementName.toSeq)
  }*/

/*  def isProcedureOrderWithReasonDuringEDOrCCEncounter(r: CassandraRow, measureProperty: MeasureProperty, elementArray: String*): Boolean = {
    elementArray.exists(element=>checkElementPresent(r, measureProperty, element))

  }*/

/*  def isEncounterOrderDuringEDOrCCEncounter(r: CassandraRow, measureProperty: MeasureProperty, elementArray: String*): Boolean = {
    elementArray.exists(element=>checkElementPresent(r, measureProperty, element))
  }*/


  def wasDeviceAppliedInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit, m, elementName, patientHistoryList)
  }

  def isProcedureOrderDuringEDOrCCEncounter(r: CassandraRow, measureProperty: MeasureProperty, elementArray: String*): Boolean = {
    elementArray.exists(element=>checkElementPresent(r, measureProperty, element))
  }

  def wasDiagnosedWithBeforeOrEqualEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    wasElementPresentBeforeOrEqualEncounter(visit, m, elementName, patientHistoryList)
  }
  def wasProcedurePerformedBeforeOrEqualEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    wasElementPresentBeforeOrEqualEncounter(visit, m, elementName, patientHistoryList)
  }
  def wasAssessmentPerformedBeforeOrEqualEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    wasElementPresentBeforeOrEqualEncounter(visit, m, elementName, patientHistoryList)
  }


  /**
    * This function verifies the diagnosisDuringEdorEncounter
    * @param visit Current Visit of the patient.
    * @param m     Measure Property of the Measure.
    * @param element    Element whose Diagnosis is to be checked.
    * @param elementDate       Element Date that has to be checked whether it is equal to other date or it is in between two dates.
    * @param edvisitArrivalDate  edVisitarrivalDate of the patient.
    * @param edvisitDepartureDate edvisitDepartureDate of the patient.
    * @param crtclDate            crtclDate of the patient.
    * @return
    */
  def isEncounterOrderDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    checkElementPresent(visit, m, element) &&
      (
        isDateInBetween(visit, m, elementDate, edvisitArrivalDate, edvisitDepartureDate)
          ||
          isDateTimeEqual(visit, m, elementDate, crtclDate)
        )
  }

  /**
    * This function verifies the diagnosisDuringEdorEncounter
    * @param visit Current Visit of the patient.
    * @param m     Measure Property of the Measure.
    * @param elementDate       Element Date that has to be checked whether it is equal to other date or it is in between two dates.
    * @param edvisitArrivalDate  edVisitarrivalDate of the patient.
    * @param edvisitDepartureDate edvisitDepartureDate of the patient.
    * @return it return if Procedure Order element during arrival and Departure date
    */
  def isProcedureOrderWithReasonDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String, ListOfElement: String*): Boolean = {

    ListOfElement.exists(element=>checkElementPresent(visit, m, element))&&
      (
        isDateInBetween(visit, m, elementDate, edvisitArrivalDate, edvisitDepartureDate)
        ||
          isDateTimeEqual(visit, m, elementDate, crtclDate)
        )
  }

  /**
    * This function verifies the diagnosisDuringEdorEncounter
    * @param visit Current Visit of the patient.
    * @param m     Measure Property of the Measure.
    * @param element    Element whose Diagnosis is to be checked.
    * @param elementDate       Element Date that has to be checked whether it is equal to other date or it is in between two dates.
    * @param edvisitArrivalDate  edVisitarrivalDate of the patient.
    * @param edvisitDepartureDate edvisitDepartureDate of the patient.
    * @param crtclDate            crtclDate of the patient.
    * @return it return if Procedure Order element during arrival and Departure date
    */
  def isProcedureOrderDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    checkElementPresent(visit, m, element) &&
      (
        isDateInBetween(visit, m, elementDate, edvisitArrivalDate, edvisitDepartureDate)
          ||
          isDateTimeEqual(visit, m, elementDate, crtclDate)
        )
  }


  /**
    *
    * @param visit current visit of patient
    * @param m measurement property
    * @param element get Treatment Completion element
    * @param elementDate  Element Date that has to be checked whether it is equal to other date or it is in between two dates.
    * @param edvisitArrivalDate get patient arrival date
    * @param edvisitDepartureDate get patient departure date
    * @param crtclDate patient cricical care date
    * @return return if Patient LeftBefore Treatment Completion On ED Or CC Encounter
    */
  def isPatientLeftBeforeTreatmentCompletionOnEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }

  /**
    *
    * @param visit current visit of patient
    * @param m measurement property
    * @param element get Treatment Completion element
    * @param elementDate  Element Date that has to be checked whether it is equal to other date or it is in between two dates.
    * @param edvisitArrivalDate get patient arrival date
    * @param edvisitDepartureDate get patient departure date
    * @param crtclDate patient cricical care date
    * @return return if Patient Expired On ED Or CC Encounter
    */

  def isPatientExpiredOnEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }

  /**
    *
    * @param visit current visit of patient
    * @param m measurement property
    * @param patientHistoryList get patient history list for ED or CC Encounter Performed
    * @param elements get ED and CC encounter Date
    * @return retuen if ED or CC Encounter Performed
    */

  def isEDorCCEncounterPerformed(visit:CassandraRow, m:MeasureProperty, patientHistoryList:Broadcast[List[CassandraRow]],elements: String*): Boolean = {
    elements.exists(x=>checkElementDuringMeasurementPeriod(visit, m, x, patientHistoryList))
  }


  /**
    * This function verifies if the assessment for negative pain is performed on encounter
    *
    * @param visit   current patient visit
    * @param m       measure property
    * @param element element name
    * @return returns true if the assessment for negative pain is performed on encounter else returns false
    */
  def isAssessmentPerformedForNegativePainOnEncounter(visit: CassandraRow, m: MeasureProperty, element: String): Boolean = {
    checkNotNull(visit, element, element + "_date") && dataTypeOnEncounter(visit, m, element) && (visit.getDecimal(element) == 0)
  }


  /**
    * This function verifies if the assessment for positive pain is performed on encounter
    * @param visit   current patient visit
    * @param m       measure property
    * @param element element name
    * @param lowerValue  lower value for checking
    * @param higherValue higher value for checking
    * @return returns true if assessment is performed on encounter  and value of the element lies between provided range
    */
  def isAssessmentPerformedForPositivePainOnEncounter(visit: CassandraRow, m: MeasureProperty, element: String,lowerValue:Double,higherValue:Double): Boolean = {
    checkNotNull(visit, element, element + "_date") && dataTypeOnEncounter(visit, m, element) &&  ((visit.getDecimal(element) >= lowerValue) && (visit.getDecimal(element)<= higherValue))
  }

  /**
    * This function will verify if intervention is performed starts after start of other elements
    * @param visit  current patient visit
    * @param m measure property
    * @param elementName intervention element name
    * @param patientHistoryList patient history list
    * @param historyElements history elements
    * @return returns true if intervention is performed starts after start of other elements else returns false
    */
  def wasInterventionPerformedAfterAssessment(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElements: String*):Boolean={
    wasElementPresentAfter(visit, m, elementName, patientHistoryList, historyElements)
  }

  /**
    * This Function verifies the teleHealthModifier for(ov_thmdmod95,hmhlthsrvc_tm,nrsnfcltvst_tm,eddeptvist_tm,csl_638)a patient is performed
    * @param visit Current visit of the patient
    * @param m Measure Property of the measure
    * @return It will return true if the patient is performed
    */
  def isTeleHealthModifier(visit: CassandraRow, m: MeasureProperty,Elements:String*): Boolean = {
    Elements.exists(element=>encounterPerformed(visit, m, element))
  }

  /**
    * This function verifies the Diagnosis of the patient is During Measurement period in history.
    * @param visit Current visit of the patient.
    * @param m Measure Property of the measure
    * @param historyElement history Element that has to be look in the History.
    * @param patientHistoryList Patient history list
    * @return It will return true if the patient is Diagnosed in history during measurement period.
    */
  def isDiagnosis(visit:CassandraRow, m:MeasureProperty, historyElement: String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementDuringMeasurementPeriod(visit, m, historyElement: String,patientHistoryList)
  }


  /**
    * This Function verifies the intervention is done X month before encounter.
    * @param visit Current visit of the patient.
    * @param m Measure Property of the measure
    * @param historyElement history Element that has to be look in the History.
    * @param month   Number of months.
    * @param patientHistoryList Patient history list
    * @return It will return true if the Intervention is performed X month before encounter.
    */
  def wasInterventionXBeforeEncounter(visit: CassandraRow, m: MeasureProperty,historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var encounterDate:String= "encounterdate"
    wasAssessmentPerformedBeforeOrEqualInMonth(visit, m, encounterDate,historyElement, month, patientHistoryList)
  }

  /**
    * This Function verifies the intervention is done X month after encounter.
    * @param visit Current visit of the patient.
    * @param m Measure Property of the measure
    * @param historyElement history Element that has to be look in the History.
    * @param month   Number of months.
    * @param patientHistoryList Patient history list
    * @return It will return true if the Intervention is performed X month after encounter.
    */
  def wasInterventionXAfterEncounter(visit: CassandraRow, m: MeasureProperty, historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    val encounterDate:String= "encounterdate"
    wasAssessmentPerformedInXMonths(visit, m, encounterDate,historyElement, month, patientHistoryList)
  }

  /**
    * This function verifies the Assessment is performed during Emergency visit of the patient
    * @param visit Current visit of the patient.
    * @param m Measure Property of the measure
    * @param element Element whose Assessment is performed
    * @param elementDate Element Date that has to be verified During  edvisitArrivalDate and edvisitDepartureDate
    * @param edvisitArrivalDate edvisitArrivalDate of the patient.
    * @param edvisitDepartureDate  edvisitDepartureDate of the Patient.
    * @param crtclDate     Critical care Date of the Patient.
    * @return It will return true if the Assessment is during Emergency visit of the patient
    */


  def isAssessmentDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }


  /**
    * This function verifies the DiagnosticStudy is performed during Emergency visit of the patient
    * @param visit Current visit of the patient.
    * @param m Measure Property of the measure
    * @param element Element whose Assessment is performed
    * @param elementDate Element Date that has to be verified During  edvisitArrivalDate and edvisitDepartureDate
    * @param edvisitArrivalDate edvisitArrivalDate of the patient.
    * @param edvisitDepartureDate  edvisitDepartureDate of the Patient.
    * @param crtclDate     Critical care Date of the Patient.
    * @return It will return true if the DiagnosticStudy is during Emergency visit of the patient
    */
  def isDiagnosticStudyDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }

  /**
    * This function verifies the SymptomDuring is performed during Emergency visit of the patient
    * @param visit Current visit of the patient.
    * @param m Measure Property of the measure
    * @param element Element whose Assessment is performed
    * @param elementDate Element Date that has to be verified During  edvisitArrivalDate and edvisitDepartureDate
    * @param edvisitArrivalDate edvisitArrivalDate of the patient.
    * @param edvisitDepartureDate  edvisitDepartureDate of the Patient.
    * @param crtclDate     Critical care Date of the Patient.
    * @return It will return true if the SymptomDuring is during Emergency visit of the patient
    */
  def isSymptomDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }


  /**
    * This Verifies the Diagnosis is During emergency visit with severity of the patient.
    * @param visit  Current visit of the patient.
    * @param m      Measure Property of the measure.
    * @param element  Element that has to be verified during Emergency visit.
    * @param elementDate Element Date that has be verified during edVisitArrival Date or edvisitdeparture Date
    * @param severityElement  Severity Element
    * @param edvisitArrivalDate edVisitArrival Date of the patient visit
    * @param edvisitDepartureDate edvisitdeparture Date of the patient visit
    * @param crtclDate            critical care Date of  the patient visit
    * @return It will return true for those patient whose severity is during Diagnosis during Emergency Visit.
    */
  def isDiagnosisDuringEDOrCCSeverity(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String,severityElement:String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {

    val severityElement1:String=severityElement + "_date"

       (  isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
        &&
        isDateEqual(visit, m,elementDate,severityElement1)
        )

  }



  /**
    * This Verifies the emegency Encounter is Perfoemed.
    * @param visit Current visit of the patient
    * @param m      Measure Property of the measure.
    * @param element  Element that has to be verified during Emergency visit
    * @param ReasonElement Reason Element that has to be verified
    * @return It will return those patient whose Emergency visit is encounter due to reason
    */
  def isEncounterPerformedEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, ReasonElement:String): Boolean = {
    ( checkElementPresent(visit, m, element)&&
      checkElementPresent(visit, m, ReasonElement))
  }

  /**
    *
    * @param visit Current visit of the patient
    * @param m Measure Property of the measure.
    * @param currentRowElement get current row Adverse element
    * @param element2 get history Adverse element
    * @param patientHistoryList get patient history list for Adverse Event Procedure
    * @return it return true if Adverse Event Started After End Of X Procedure
    */

  def isAdverseEventStartedAfterEndOfXProcedure(visit: CassandraRow, m: MeasureProperty, currentRowElement: String, element2: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    startAfterStartOfEncounter(visit, m, currentRowElement, element2, patientHistoryList)
  }

  /**
    *
    * @param visit Current visit of the patient
    * @param m Measure Property of the measure.
    * @param histroyElement get patient history element for Procedure Adverse Event
    * @param patientHistoryList get patient history List for Procedure Adverse Event
    * @return it return if Procedure Adverse Event
    */

  def isProcedureAdverseEvent(visit: CassandraRow, m: MeasureProperty, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementDuringMeasurementPeriod(visit, m, histroyElement, patientHistoryList)
  }

  /**
    *
    * @param visit Current visit of the patient
    * @param m  Measure Property of the measure.
    * @param currentRowElement get current row Diagnosed procedure
    * @param element2 get history element for Diagnosed procedure
    * @param patientHistoryList get element History List for Diagnosed procedure
    * @return it return if Diagnosed After End Of Procedure
    */

  def isDiagnosedAfterEndOfXProcedure(visit: CassandraRow, m: MeasureProperty, currentRowElement: String, element2: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    startAfterStartOfEncounter(visit, m, currentRowElement, element2, patientHistoryList)
  }


  //****************************

  def isInterventionOrderedDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }

  def isInterventionPerformedDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }

  def isCommunicationFromPatientToProviderDoneDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }






  def wasProcidurePerformedWithInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     wasElementAfterOrEqualInMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  /**
    * This Function verifies the Sympton During Emergency visit with severity.
    * @param visit  Current visit of the patient.
    * @param m      Measure Property of the measure.
    * @param element  Element that has to be verified during Emergency visit.
    * @param elementDate Element Date that has be verified during edVisitArrival Date or edvisitdeparture Date
    * @param severityElement  Severity Element
    * @param edvisitArrivalDate edVisitArrival Date of the patient visit
    * @param edvisitDepartureDate edvisitdeparture Date of the patient visit
    * @param crtclDate            critical care Date of  the patient visit
    * @return It will return true for those patient whose severity is during Sympton during Emergency Visit.
    */
  def isSymptomDuringEDOrCCSeverity(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, severityElement: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    isDiagnosisDuringEDOrCCSeverity(visit, m, element, elementDate, severityElement, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }
  /**
    * This Function verifies the Medication of the Patient before edVisitDeparture date.
    * @param visit  Current visit of the patient.
    * @param m      Measure Property of the measure.
    * @param element  Element that has to be verified during Emergency visit
    * @param edvisitDepartureDate edvisitdeparture Date of the patient visit
    * @param crtclDate            critical care Date of  the patient visit
    * @return It will return true for those patient whose Medication before Edvisit Departure of the Patient.
    */
  def wasMedicationBeforeEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, edvisitDepartureDate: String, crtclDate: String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasDiagnosedBeforeEDOrCCEncounter(visit, m, element,  edvisitDepartureDate, crtclDate,patientHistoryList )
  }


  def checkPhysicalExamPerformedValue(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    checkElementValueDuringMeasurementPeriod(visit, m, elementName, value, flag, patientHistoryList)
  }


  def wasCommunicationDoneAfterQualifyingCardiacEventsInHistory(visit:CassandraRow, m:MeasureProperty, historyElement1:String,historyElement2:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {

    wasElementPresentAfterOtherElementBeforeEncounter(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String,patientHistoryList: Broadcast[List[CassandraRow]] )
  }

  def wasProcedurePerformedWithinXMonths(r: CassandraRow, m: MeasureProperty, elementDate: String,  month: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEndWithinXMonths(r, m, elementDate,  month , patientHistoryList)
  }


  def wasDiagnosticStudyPerformedWithinXDays(r: CassandraRow, m: MeasureProperty, elementDate: String, days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEndWithinXDays(r, m, elementDate,   days, patientHistoryList)
  }

  def wasInterventionPerformedBeforeEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, CurrentElementDate: String, histroyElementName: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeElementWithinXMonths(visit: CassandraRow, m: MeasureProperty, CurrentElementDate: String, histroyElementName: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def isVisualAcuityPerformedAfterTreatment(visit:CassandraRow, m:MeasureProperty, treatment:String, patientHistoryList:Broadcast[List[CassandraRow]],VisualAcuityElementName:String*):Boolean= {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, treatment,CompareOperator.LESS_EQUAL, patientHistoryList,VisualAcuityElementName)
  }

  def isVisualAcuityPerformedBeforeTreatment(visit:CassandraRow, m:MeasureProperty, VisualAcuityDate:String,patientHistoryList:Broadcast[List[CassandraRow]],TreatmentElementName:String*):Boolean= {
    wasElementPresentAfter(visit, m, VisualAcuityDate, patientHistoryList,TreatmentElementName)
  }

  /**
    *
    * @param visit current visit
    * @param m measure property
    * @param element laboratory test ordered element
    * @param elementDate laboratory test ordered element date
    * @param edvisitArrivalDate ed visit arrival date
    * @param edvisitDepartureDate ed visit departure date
    * @param crtclDate critical care date
    * @return returns true if laboratory test ordered during ed or cc encounter
    */
  def isLaboratoryTestOrderedDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }

  /**
    *
    * @param r patient current visit
    * @param measureProperty measure property
    * @param element Diagnostic Study element
    * @param patientHistoryList patient history element list
    * @return it return if Diagnostic Study Performed during measurement period
    */

  def isDiagnosticStudyPerformed(r: CassandraRow, measureProperty: MeasureProperty, element: String,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    checkElementDuringMeasurementPeriod(r: CassandraRow, measureProperty, element,patientHistoryList)
  }

  /**
    *
    * @param r patient current visit
    * @param measureProperty measure property
    * @param element1 get 1st Diagnoses element
    * @param element2 get 2nd  Diagnoses element
    * @return it return true if are Both Diagnoses On SameDate
    */

  def areDiagnosesOnSameDate(r: CassandraRow, measureProperty: MeasureProperty, element1: String, element2: String): Boolean = {
    isDateEqual(r, measureProperty, element1, element2)
  }



  /**
    * This function verifies if one diagnosis is performed during another diagnosis
    * @param visit current patient visit
    * @param m measure property
    * @param element1 diagnosis element1 to be checked
    * @param element1_date diagnosis element1 to be checked
    * @param element2  diagnosis element2 to be compare with element1
    * @param element2_date diagnosis element2 date to be compare with element1
    * @return returns true if one diagnosis is performed during another diagnosis else returns false
    */
  def isDiagnosisPerformedDuringDiagnosis(visit:CassandraRow,m:MeasureProperty,element1:String,element1_date:String,element2:String,element2_date:String):Boolean={
    checkNotNull(visit,element1,element1_date,element2,element2_date) && isDateEqual(visit,m,element1_date,element2_date)

  }



  /**
    * This function verifies if one physical exam is performed during another another physical exam
    * @param visit current patient visit
    * @param m measure property
    * @param element1 physical exam element1 to be checked
    * @param element1_date physical exam element1 to be checked
    * @param element2  physical exam element2 to be compare with element1
    * @param element2_date physical exam element2 date to be compare with element1
    * @return returns true if one physical exam is performed during another another physical exam
    */
  def isPhysicalExamPerformedDuringPhysicalExam(visit:CassandraRow,m:MeasureProperty,element1:String,element1_date:String,element2:String,element2_date:String): Boolean ={
    checkNotNull(visit,element1,element1_date,element2,element2_date) && isDateEqual(visit,m,element1_date,element2_date)
  }


  /**
    * This function verifies if physical exam is done after X days of procedure performed and element value is less than or equal to compare value provided
    * @param visit current patient visit
    * @param m measure property
    * @param elementName physical exam element name
    * @param value compare value
    * @param historyElement  procedure element in history
    * @param days no of days to be looked after procedure performed
    * @param patientHistoryList patient history list
    * @return returns true if physical exam is done after X days of procedure performed and element value is less than or equal to compare value provided
    */
  def isPhysicalExamValueAfterXProcedureDays(visit: CassandraRow, m: MeasureProperty, elementName: String,value:Double,historyElement: String,days:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    isPhysicalExamPerformedInXDaysAfterProcedure(visit,m,elementName,historyElement,days,patientHistoryList) && (visit.getDecimal(elementName) <=value)
  }


  /**
    * This function verifies if physical exam is done after X days of procedure performed and VA value is less than or equal to compare value provided
    * @param visit current patient visit
    * @param m measure property
    * @param elementName physical exam element name
    * @param historyElement  procedure element in history
    * @param days no of days to be looked after procedure performed
    * @param patientHistoryList patient history list
    * @return returns true if physical exam is done after X days of procedure performed and element value is less than or equal to compare value provided
    */
  def isPhysicalExamAndVAValueAfterXProcedureDays(visit: CassandraRow, m: MeasureProperty, elementName: String,resultElement:String,historyElement: String,days:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    isPhysicalExamPerformedInXDaysAfterProcedure(visit,m,elementName,historyElement,days,patientHistoryList) && checkElementPresent(visit, m ,resultElement)
  }


  /**
    * This function verifies if communication for particular element is done after or equal encounter date
    * @param visit current patient visit
    * @param m measure property
    * @param elementEyeName element name to be verified
    * @param patientHistoryList patient history list
    * @param compareEyeElementNames  eye elements to be checked if present after eye element of current visit
    * @return true if communication for particular eye element is done after or equal encounter date and equal with with other eye element in history
    */

  def isCommunicationAfterOrEqualEncounterWithEye(visit:CassandraRow,m:MeasureProperty,elementEyeName:String,patientHistoryList: Broadcast[List[CassandraRow]],compareEyeElementNames:String*): Boolean ={
    //wasElementPresentAfter(visit,m,elementName,patientHistoryList,Seq(historyElement))
    //checkEyeOnEncounterEqualsWith(visit,m,false,elementEyeName,patientHistoryRDD,compareEyeElementNames)
    checkEyeOnEncounterEqualsWithOtherEye(visit,m,true,elementEyeName,patientHistoryList,compareEyeElementNames)
  }



  /**
    * This function verifies if communication for particular element is not done  after or equal encounter date with some reason
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element name to be verified
    * @param patientHistoryList patient history list
    * @param historyElement to be checked if present after encounter date
    * @return true if communication for particular element is not done  after or equal encounter date with some reason
    */
  def isActionNotPerformedWithReasonAfterOrEqualEncounter(visit:CassandraRow,m:MeasureProperty,elementName:String,patientHistoryList: Broadcast[List[CassandraRow]],historyElement:String): Boolean ={
    wasElementPresentAfterOrEqualEncounter(visit, m, elementName,historyElement, patientHistoryList)
  }


  /**
    *This Function verifies the intervention order is during emergency visit.
    * @param visit  current visit of the patient
    * @param m      measure Property of the measure
    * @param element element that has to be verified during emergency visit.
    * @param elementDate element Date whose date is to be verified during emergency visit.
    * @param edvisitArrivalDate edVisitArrival Date of the patient visit
    * @param edvisitDepartureDate edvisitdeparture Date of the patient visit
    * @param crtclDate critical care Date of  the patient visit
    * @return It will return those patient whose intervention order is during emergency visit.
    */

  def isInterventionOrderDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }



  /**
    *This Function verifies if the patient communication during emergency visit.
    * @param visit  current visit of the patient
    * @param m      measure Property of the measure
    * @param element element that has to be verified during Emergency visit.
    * @param elementDate element Date whose date is to be verified during emergency visit.
    * @param edvisitArrivalDate edVisitArrival Date of the patient visit
    * @param edvisitDepartureDate edvisitdeparture Date of the patient visit
    * @param crtclDate critical care Date of  the patient visit
    * @return It will return true if the communication is during emergency else false.
    */

  def isCommunicationDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }



  /**
    * This function verifies the Diagnostic study performed result less than value.
    * @param visit  current visit of the patient
    * @param m      measure Property of the measure
    * @param element element that has to be verified during Emergency visit.
    * @param value  result value that has to be compared.
    * @param edvisitArrivalDate edVisitArrival Date of the patient visit
    * @param edvisitDepartureDate edvisitdeparture Date of the patient visit
    * @param crtclDate critical care Date of  the patient visit
    * @return It will return those patient whose diagnostic study result is less than specified value else false.
    */

  def isDiagnosticStudyPerformedresultDuringEDorCCLessThanX(visit: CassandraRow, m: MeasureProperty, element: String, value:Float, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    isGCSResultDuringEDorCCLessThanX(visit, m, element, value,edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }


  /**
    * This function verifies those patient whose device is applied before Emergency encounter.
    * @param visit  current visit of the patient
    * @param m      measure Property of the measure
    * @param element element that has to be verified during Emergency visit.
    * @param edvisitDepartureDate edvisitdeparture Date of the patient visit
    * @param crtclDate critical care Date of  the patient visit
    * @param patientHistoryList Patient history list of the patient.
    * @return It will return true if the device is applied before emergency visit else false.
    */

  def wasDeviceAppliedBeforeEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String,edvisitDepartureDate: String, crtclDate: String,patientHistoryList:Broadcast[List[CassandraRow]] ):Boolean={
    wasDiagnosedBeforeEDOrCCEncounter(visit, m, element,edvisitDepartureDate, crtclDate,patientHistoryList)
  }

  /**
    * This function verifies those patient whose medication is done during Emergency visit.
    * @param visit  current visit of the patient
    * @param m      measure Property of the measure
    * @param element element that has to be verified during Emergency visit.
    * @param elementDate element Date whose date is to be verified during emergency visit.
    * @param edvisitArrivalDate edVisitArrival Date of the patient visit
    * @param edvisitDepartureDate edvisitdeparture Date of the patient visit
    * @param crtclDate critical care Date of  the patient visit
    * @return It will return true if medication is during Emergency visit else false.
    */
  def isMedicationDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }


  /*def isProcedurePerformedBeforeEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String,currentElementdate:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
     wasElementPresentAfterStartDateandBeforeEncounter(visit, m, elementName,currentElementdate,patientHistoryList)
  }*/


  /**
    * This function verifies the Diagnostic Study is performed during measurement period.
    * @param visit  current visit of the patient
    * @param m      measure Property of the measure
    * @param elementName element that has to be verified during Emergency visit.e
    * @param patientHistoryList Patient history list
    * @return
    */
  def isDiagnosticStudyDuringMesurementPeriod(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }

  /**
    * This function verifies those patient whose Daignostic Study is before X months before end.
    * @param visit  current visit of the patient
    * @param m      measure Property of the measure
    * @param elementDate Element Date from X months Diagnostic Study is verified.
    * @param months Number of months.
    * @param patientHistoryList Patient History List.
    * @return It will return those patient whose diagnostic Study is before X month before
    */
  def wasDiagnosticStudyBeforeXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, months:Int ,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEndWithinXMonths(visit, m, elementDate, months ,patientHistoryList)
  }




 /* def wasRefractiveSurgeryPerformedwithInXDays(r: CassandraRow, m: MeasureProperty, elementDate: String, days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEndInXDays(r, m, elementDate, days, patientHistoryList)
  }

    def wasPhysicalExamPerformedWithInXDays(r: CassandraRow, m: MeasureProperty, elementDate: String, days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
     wasElementAfterElementDateWithinXDays(r: CassandraRow, m: MeasureProperty, elementDate: String, days: Int, patientHistoryList:Broadcast[List[CassandraRow]])
  }
*/
  /**
    * This Function verifies the Encounter is performed during Ed or CC
    * @param visit  current visit of the patient
    * @param m      measure Property of the measure
    * @param element element that has to be verified during Emergency visit.
    * @param elementDate element Date whose date is to be verified during emergency visit.
    * @param edvisitArrivalDate edVisitArrival Date of the patient visit
    * @param edvisitDepartureDate edvisitdeparture Date of the patient visit
    * @param crtclDate critical care Date of  the patient visit
    * @return It will return true if encounter is performed during Emergency visit.
    */
  def isEncounterPerformedDuringEDorCC (visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }

  def wasProcedurePerformedBeforeEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, CurrentElementDate: String, histroyElementName: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeElementWithinXMonths(visit: CassandraRow, m: MeasureProperty, CurrentElementDate: String, histroyElementName: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasAssessmentPerformedBeforeEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, CurrentElementDate: String, histroyElementName: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeElementWithinXMonths(visit: CassandraRow, m: MeasureProperty, CurrentElementDate: String, histroyElementName: String, month: Int, patientHistoryList)
  }

  def wasDiagnosedBeforeEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, CurrentElementDate: String, histroyElementName: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeElementWithinXMonths(visit: CassandraRow, m: MeasureProperty, CurrentElementDate: String, histroyElementName: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasAssessmentPerformedAfterRecommended(visit:CassandraRow, m:MeasureProperty, elementName:String,historyElementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
     wasElementPresentAfterOrEqualEncounter(visit, m, elementName,historyElementName, patientHistoryList)
  }

  /**
    * tthis function checks element value on encounter satisfy flag criteria with actual value
    * @param visit current visit
    * @param m measure property
    * @param elementName element wose value will be checked
    * @param value value that need to be compared
    * @param flag based on flaf condition of value will be compared like ge for >= etc
    * @return true if element value on encounter satisfy flag criteria with actual value
    */
  def isAssessmentValueOnEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, value: Double, flag:String):Boolean= {
    checkElementValueOnEncounter(visit, m:MeasureProperty, elementName, value, flag)
  }

  /**
    * This function verifies if assessment is performed for screening on encounter
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element name to be screening on encounter date
    * @return returns true if assessment is performed for screening on encounter else returns false
    */
  def isAssessmentPerformedForScreeningOnEncounter(visit:CassandraRow,m:MeasureProperty,elementName:String):Boolean={
    checkNotNull(visit,elementName)
  }


  /**
    * This function verifies if assessment is performed for result on encounter
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element name to be screening on encounter date
    * @return returns true if assessment is performed for result on encounter else returns false
    */
  def isAssessmentPerformedForResultOnEncounter(visit:CassandraRow,m:MeasureProperty,elementName:String):Boolean={
    checkElementPresent(visit,m ,elementName)
  }


  /**
    *  This function verifies whether assesment is recommended on encounter or not
    * @param visit current visit
    * @param measureProperty  measure Property of the measure
    * @param elementName element which will be check
    * @return true if assesment is recommended on encounter
    */
  def isAssessmentRecommended(visit: CassandraRow, measureProperty: MeasureProperty, elementName: String): Boolean = {
    dataTypeOnEncounter(visit, measureProperty, elementName)
  }

  /**
    *
    * @param visit current visit
    * @param m measure Property of the measure
    * @param currentElementDate current row element
    * @param historyElementName history element
    * @param noOfDays no of days before currentElementDate
    * @param value value that need to be checked
    * @param ConditionFlag for value condition like ge >= etc
    * @param patientHistoryList patirnt history
    * @return true if value of element satisfy the condition flag and element is between currentElementDate and currentElementDate - days
    */
  def wasAssessmentValueBeforeEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, historyElementName:String, noOfDays:Int,value: Double, ConditionFlag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementValueBeforeElementWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, historyElementName: String, noOfDays: Int, value: Double, ConditionFlag: String, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param CurrentElementDate patient Communication date
    * @param patientHistoryList patioent history list
    * @param HistoryelementName get communication propvide element in history
    * @return it return if Communication From Provider to Provider After Encounter
    */

  def wasCommunicationFromProvidertoProviderAfterEncounter(visit:CassandraRow, m:MeasureProperty, CurrentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String*):Boolean= {
     wasElementPresentAfter(visit, m, CurrentElementDate, patientHistoryList,HistoryelementName)
  }


  def wasInterventionDoneAfterProcedure(visit:CassandraRow, m:MeasureProperty, CurrentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String*):Boolean= {
    wasElementPresentAfter(visit, m, CurrentElementDate, patientHistoryList,HistoryelementName)
  }

  def wasAssessmentDoneAfterProcedure(visit:CassandraRow, m:MeasureProperty, CurrentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String*):Boolean= {
    wasElementPresentAfter(visit, m, CurrentElementDate, patientHistoryList,HistoryelementName)
  }

  def wasAssessmentNotDoneAfterProcedureWithReasonBeforeEnd(visit:CassandraRow, m:MeasureProperty, CurrentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String*):Boolean= {
    wasElementPresentAfter(visit, m, CurrentElementDate, patientHistoryList,HistoryelementName)
  }

  def wasLaboratoryTestPerformedBeforeEndInXYears(r: CassandraRow, m: MeasureProperty, elementDate: String, years: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEndInXYears(r: CassandraRow, m: MeasureProperty, elementDate: String, years: Int, patientHistoryList:Broadcast[List[CassandraRow]])
  }

  def isLaboratoryTestPerformedValue(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementValueDuringMeasurementPeriod(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String, patientHistoryList: Broadcast[List[CassandraRow]])
  }

 /* /**
    *
    * @param visit current row
    * @param m measure property
    * @param element element from current row
    * @param greaterValue greater value of range
    * @param smallerValue smaller value of range
    * @return returns true is element value in range
    */
  def isAssessmentPerformedResultInRange(visit:CassandraRow, m:MeasureProperty,element: String, greaterValue:Double, smallerValue: Double) = {
    isElementInValueRangeOnEncounter(visit, m, element, greaterValue, smallerValue)
  }*/

  def isAssessmentPerformedResultInRange(visit:CassandraRow, m:MeasureProperty,element: String,smallerValue: Double, greaterValue:Double) = {
    //isElementInValueRangeOnEncounter(visit, m, element, greaterValue, smallerValue)
      checkNotNull(visit,element) && compareTwoValueStatus(visit.getDouble(element),CompareOperator.GREATER_EQUAL_And_LESS_EQUAL,smallerValue,greaterValue)
  }

  /**
    *
    * @param visit current visit
    * @param m measure Property of the measure
    * @param currentElement current row element
    * @param historyElementName history element
    * @param days no of days before currentElementDate
    * @param patientHistoryList patirnt history
    * @return true if element is between currentElementDate and currentElementDate - days
    */
  def wasAssessmentBeforeEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, days:Int, patientHistoryList: Broadcast[List[CassandraRow]],historyElementName:String*): Boolean = {
    wasElementPresentBeforeInXPeriods(visit,m,currentElement,CalenderUnit.DAY,days,CompareOperator.LESS_EQUAL,patientHistoryList,historyElementName)
  }
  /**
    * this function checks is Communication From Provider to Patient done On Encounter
    * @param visit current visit
    * @param measureProperty measure property
    * @param currentElementName  element name
    * @return true if communication From Provider to Patient done On Encounter
    */
  def isCommunicationFromProviderToPatientOnEncounter(visit: CassandraRow, measureProperty: MeasureProperty, currentElementName: String): Boolean = {
    dataTypeOnEncounter(visit, measureProperty, currentElementName)
  }

  def isAssessmentPerformedValue(visit:CassandraRow, m:MeasureProperty, elementName:String, value: Double, flag:String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    checkElementValueDuringMeasurementPeriod(visit, m, elementName, value, flag, patientHistoryList)
  }

  def isMostRecentLaboratoryTestPerformedValue(visit:CassandraRow, m:MeasureProperty, elementName:String, value: Double, flag:String, mostrecentPatientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    checkElementValueDuringMeasurementPeriod(visit, m, elementName, value, flag, mostrecentPatientHistoryList)
  }

  def isLaboratoryTestMostValue(visit:CassandraRow, m:MeasureProperty, MostRecentElement:String, value:Double, flag:String, MostRecentList: Broadcast[List[CassandraRow]]):Boolean= {
    checkElementValueDuringMeasurementPeriod(visit, m, MostRecentElement, value, flag:String, MostRecentList)
  }

  def isDiagnosticStudyPerformedAfter(visit: CassandraRow, m: MeasureProperty,CurrentRowElement:String, element2:String, days:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    startAfterStartOfEncounter(visit,m,CurrentRowElement,element2,patientHistoryList)
  }

  def wasMedicationAdministeredBeforeEndInDays(visit: CassandraRow, m: MeasureProperty, histroyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentBeforeOrEqualEndInDays(visit: CassandraRow, m: MeasureProperty, histroyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def isCommunicationFromProvidertoProviderNotDone(visit:CassandraRow, m:MeasureProperty, historyElement: String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementDuringMeasurementPeriod(visit: CassandraRow, m,  historyElement, patientHistoryList)
  }


/*  def wasProcedurePerformedConcurrent(visit:CassandraRow, m:MeasureProperty, element1:String,LateralElement:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
  wasDiagnosedBeforeEndWithLaterality(visit, m, element1,LateralElement, patientHistoryList)

    }*/

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param interventions sequence of interventions
    * @param patientHistoryList patient history list
    * @param assessments sequence of assessments
    * @return returns true if intervention exists after assessment
    */
  def wasInterventionPerformedAfterAssessmentinHistory(visit:CassandraRow, m:MeasureProperty, interventions:Seq[String],patientHistoryList:Broadcast[List[CassandraRow]],assessments:Seq[String] ):Boolean= {
    interventions.exists(intervention => wasElementPresentAfterOtherElementInHistory(visit, m, intervention,patientHistoryList,assessments))

  }

  /**
    * this function checks whether medication is concurrent is not with other element
    * @param visit current visit
    * @param measureProperty measureProperty
    * @param element1 element fo current row
    * @param element2 element from current row which will be checked aginst element 1
    * @return true if element 1 is concurrent is not with other element 2
    */
  def isMedicationAdministredConcurrentWith(visit: CassandraRow, measureProperty: MeasureProperty, element1: String, element2: String): Boolean = {
    isDateEqual(visit, measureProperty, element1, element2)
  }

  /**
    * this function checks whether Physical Exam Performed is concurrent is not with other element
    * @param visit  current visit
    * @param measureProperty measureProperty
    * @param element1 element fo current row
    * @param element2 element from current row which will be checked aginst element 1
    * @return true if element 1 is concurrent is not with other element 2
    */
  def isPhysicalExamPerformedConcurrentWith(visit: CassandraRow, measureProperty: MeasureProperty, element1: String, element2: String): Boolean = {
    isDateEqual(visit, measureProperty, element1, element2)
  }

  /**
    * This function verifies if diagnosis of element is before other element
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element name
    * @param patientHistoryList patients history list
    * @return returns true if diagnosis of element is before other element else returns false
    */
  def wasDiagnosedBeforeEndOfEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    wasElementPresentBeforeEncounter(visit, m:MeasureProperty, elementName, patientHistoryList:Broadcast[List[CassandraRow]])
  }

  def isInterVentionPerformedValue(visit:CassandraRow, m:MeasureProperty, elementName:String, value: Double, flag:String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    checkElementValueDuringMeasurementPeriod(visit, m, elementName, value, flag, patientHistoryList)
  }


  def isMostRecentInterVentionPerformedValue(visit:CassandraRow, m:MeasureProperty, elementName:String, value: Double, flag:String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    checkElementValueDuringMeasurementPeriod(visit, m, elementName, value, flag, patientHistoryList)
  }



  /**
    *
    * @param visit checks whether laboratory test was performed in X years before start of measurement Period
    * @param m measure property
    * @param elementDate element Date which needs to be chekc in history
    * @param years no of years look back in history from start date
    * @param patientHistoryList patirnt history list
    * @return true if Laboratory test was performed in X years before start of measurement Period
    */
  def wasLaboratoryTestPerformedBeforeInXYears(visit: CassandraRow, m: MeasureProperty, elementDate: String, years: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeStartInXYears(visit, m, elementDate, years, patientHistoryList)
  }

  /**
    * this function check whether Medication Adverse Effect was present before end of measurement period or not
    * @param visit current visit
    * @param m measure property
    * @param elementName element Name
    * @param patientHistoryList patient history list
    * @return true if element was present before end of measurement period
    */
  def wasMedicationAdverseEffectBeforeEnd(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit, m, elementName, patientHistoryList)
  }

  def wasMedicationAdverseEffectInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit, m, elementName, patientHistoryList)
  }

  /**
    * this function check whether Medication Allergy was present before end of measurement period or not
    * @param visit current visit
    * @param m measure property
    * @param elementName element Name
    * @param patientHistoryList patient history list
    * @return true if element was present before end of measurement period
    */
  def wasMedicationAllergyBeforeEnd(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit, m, elementName, patientHistoryList)
  }
  def wasMedicationIntoleranceInHistory(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit, m, elementName, patientHistoryList)
  }
  /**
    * this function check whether Medication Intolerance was present before end of measurement period or not
    * @param visit current visit
    * @param m measure property
    * @param elementName element Name
    * @param patientHistoryList patient history list
    * @return true if element was present before end of measurement period
    */
  def wasMedicationIntoleranceBeforeEnd(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementInHistory(visit, m, elementName, patientHistoryList)
  }


  /**
    * This Function verifies the Laboratory Test value before end of measurement Period
    * @param visit current Visit of the patient.
    * @param m measure property of the measure(mesureId and condition)
    * @param elementName ElementName that has to be look in the history.
    * @param value       Value that has to be verified.
    * @param flag        flag that will define the condition whether to check greater or greaterEqualto condition.
    * @param patientHistoryList Patient history list.
    * @return true if the Laboratory Test value before end of measurement Period satisfy the condition
    */
  def isLaboratoryTestPerformedValueBeforeEnd(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    checkElementValueBeforeEnd(visit, m, elementName, value, flag, patientHistoryList)
  }

  /**
    * this function check whether Laboratory Test Performed Value satisfy the condition and done within X years start  measurement period
    * @param visit current visit
    * @param m measure property
    * @param historyElementName element Name
    * @param years no of years look back from start date
    * @param value that need to be checked
    * @param patientHistoryList patient history list
    * @return true if Laboratory Test Performed Value satisfy the condition and done within X years start  measurement period
    */
  def wasLaboratoryTestPerformedValueBeforeWithinXYears(visit: CassandraRow, m: MeasureProperty, historyElementName:String, years:Int,value: Double, ConditionFlag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementValueBeforeEndWithinXYears(visit, m, historyElementName, years,value, ConditionFlag, patientHistoryList)
  }

  def wasLaboratoryTestPerformedValueBeforeStartWithinXYears (visit: CassandraRow, m: MeasureProperty, historyElementName:String, years:Int,value: Double, ConditionFlag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementValueBeforeStartWithinXYears(visit, m, historyElementName, years,value, ConditionFlag, patientHistoryList)
  }

  /**
    * this function checks whether value of element satisfy the condition flag and element is between startdate  and startDate - years
    * @param visit current visit
    * @param m measure Property of the measure
    * @param historyElementName history element
    * @param years no of days before currentElementDate
    * @param value value that need to be checked
    * @param ConditionFlag for value condition like ge >= etc
    * @param patientHistoryList patient history
    * @return true if value of element satisfy the condition flag and element is between startdate  and startDate - years
    */
  def wasMostRecentLaboratoryTestPerformedValueInXYears(visit: CassandraRow, m: MeasureProperty, historyElementName:String, years:Int,value: Double, ConditionFlag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementValueBeforeEndWithinXYears(visit, m, historyElementName, years,value, ConditionFlag, patientHistoryList)
  }

  /**
    * This function verifies if communication for particular element is done after or equal encounter date
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element name to be verified
    * @param patientHistoryList patient history list
    * @param historyElement to be checked if present after encounter date
    * @return true if communication for particular element is done after or equal encounter date
    */
  def isCommunicationAfterOrEqualEncounter(visit:CassandraRow,m:MeasureProperty,elementName:String,patientHistoryList: Broadcast[List[CassandraRow]],historyElement:String): Boolean ={
    wasElementPresentAfter(visit,m,elementName,patientHistoryList,Seq(historyElement))
  }

 /* def wasAssessmentPerformedValueWithInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int,value: Double,flag :String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementValueBeforeWithinXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int,value: Double,flag :String, patientHistoryList: Broadcast[List[CassandraRow]])
  }
*/
  def wasAssessmentPerformedValueWithInXMonths(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int,value: Double,condFlag :String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementValueBeforeEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int,value: Double,condFlag :String, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasInterVensionPerformedValueWithInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int,value: Double,flag :String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementValueBeforeWithinXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int,value: Double,flag :String, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasInterventionPerformedValueWithInXMonths(visit: CassandraRow, m: MeasureProperty, historyElement: String,value:Double,condFlag:String ,months: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    //wasElementValueBeforeMostRecentEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, element: String,value:Double,flag:String ,months: Int, patientHistoryList:Broadcast[List[CassandraRow]],mostRecentHistoryList:Broadcast[List[CassandraRow]])
    checkElementValueBeforeEncounterWithinXMonths(visit, m,  historyElement, months: Int,value: Double,condFlag , patientHistoryList)
  }

  def wasInterventionPerformedValueBeforeMostRecentEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, element: String,value:Double,flag:String ,months: Int, patientHistoryList:Broadcast[List[CassandraRow]],mostRecentHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementValueBeforeMostRecentEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, element: String,value:Double,flag:String ,months: Int, patientHistoryList:Broadcast[List[CassandraRow]],mostRecentHistoryList:Broadcast[List[CassandraRow]])
  }

/*  def wasInterventionPerformedWithResultElementBeforeMostRecentEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty,historyElement:String,value:String,months:Int ,patientHistoryList:Broadcast[List[CassandraRow]],mostRecentHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
     wasElementBeforeWithResultElementWithinXMonths(visit, m,historyElement,value,months ,patientHistoryList,mostRecentHistoryList)
  }*/

  def wasInterventionPerformedBeforeEncounterWithResultWithinXMonths(visit: CassandraRow, m: MeasureProperty, historyElement: String,historyElementResult: String, months: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasTwoElementEqualBeforeEncounterWithinXMonths(visit, m, historyElement,historyElementResult, months, patientHistoryList)
  }


  def wasAssessmentPerformedBeforeMostRecentEncounterWithinXMonths(r: CassandraRow, m: MeasureProperty, element: String,elementDate: String, months: Int, patientHistoryList:Broadcast[List[CassandraRow]],mostRecentHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
     wasElementBeforeEncounterInXMonths(r: CassandraRow, m: MeasureProperty, element: String,months: Int, patientHistoryList:Broadcast[List[CassandraRow]],mostRecentHistoryList:Broadcast[List[CassandraRow]])
  }

  def wasInterventionPerformedBeforeMostRecentEncounterWithinXMonths(r: CassandraRow, m: MeasureProperty, element: String,elementDate: String, months: Int, patientHistoryList:Broadcast[List[CassandraRow]],mostRecentHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEncounterInXMonths(r: CassandraRow, m: MeasureProperty, element: String,months: Int, patientHistoryList:Broadcast[List[CassandraRow]],mostRecentHistoryList:Broadcast[List[CassandraRow]])
  }

  def wasInterventionPerformedBeforeEncounterInXMonths(visit: CassandraRow, m: MeasureProperty, historyElement: String, calenderUnit: String, calenderInterval:Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentBeforeOrEqualElementInXPeriod(visit: CassandraRow, m: MeasureProperty, historyElement: String, calenderUnit: String, calenderInterval:Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }



  def wasDiagnosedAfterProcedure(visit:CassandraRow, m:MeasureProperty, CurrentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String*):Boolean= {
     wasElementPresentAfter(visit, m, CurrentElementDate, patientHistoryList,HistoryelementName)
  }

  /**
    *This Function verifies immunization is during Emergency visit.
    * @param visit current patient visit
    * @param m measure property of the measure
    * @param element element name to be verified
    * @param elementDate element Date that has to be verified during Emergency visit
    * @param edvisitArrivalDate Edvisit arrival date of the patient.
    * @param edvisitDepartureDate Edvisit Departure date of the patient.
    * @param crtclDate critical care Date of the patient.
    * @return It will return true if the immunization is during Emergency visit.
    */
  def isImmunizationDuringEdOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }

  /**
    * This function verifies if procedure is performed after X months of another procedure.
    * @param visit current patient visit
    * @param m measure property of the measure
    * @param CurrentElement Current Element that has to be verified.
    * @param histElement    history Element that has to be verified in the history
    * @param noOfMonths    number of x months that will go back in the history.
    * @param patientHistoryList Patient history list
    * @return It will return true if procedure is performed after X months of another procedure.
    */
  def wasProcedurePerformedAfterXMonthsOfProcedure(visit:CassandraRow,m:MeasureProperty,CurrentElement:String,histElement:String,noOfMonths:Int,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasProcedurePerformedXMonthsAfterDiagnosis(visit,m,CurrentElement,histElement,noOfMonths,patientHistoryList)
  }


  /**
    * This Function verifies the laboratory test starts after procedure.
    * @param visit Current visit of the patient.
    * @param m Measure Property of the measure
    * @param currentElement Current element that will be verified if it has started after another element.
    * @param histelement history element that has to be verified in history.
    * @param patientHistoryList Patient history list
    * @return It will retrun true of laboratory test started after procedure.
    */
  def isLaboratoryTestStartedAfterProcedure(visit: CassandraRow, m: MeasureProperty, currentElement: String, histelement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    startAfterStartOfEncounter(visit, m, currentElement, histelement, patientHistoryList)
  }

  def wasInterventionPerformedInXMonthsBeforeEncounter(visit: CassandraRow, m: MeasureProperty, histroyElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentBeforeOrEqualEncounterInMonths(visit, m, histroyElement, months, patientHistoryList)

  }

  def wasAssessmentPerformedInXMonthsBeforeEncounter(visit: CassandraRow, m: MeasureProperty, histroyElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentBeforeOrEqualEncounterInMonths(visit, m, histroyElement, months, patientHistoryList)

  }


  /**
    * This function verifies procedure is performed before end Date.
    * @param visit current visit of the patient.
    * @param m Measure Property of the measure.
    * @param historyElement History Element to look in patient History.
    * @param patientHistoryList Patient History List.
    * @return Returns those patient whose procedure is performed before endOfMeasurement period.
    */
  def isDeviceAppliedBeforeEncounter(visit:CassandraRow, m:MeasureProperty,historyElement:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasDiagnosedBeforeEncounter(visit, m,historyElement, patientHistoryList)
  }

  /**
    *
    * @param visit patient visit
    * @param m measure property
    * @param HistoryElement1 patient history element 1
    * @param patientHistoryList patient history list
    * @param HistoryElement2 list of patient history element
    * @return it return if Laboratory Test Order After Diagnosis
    */

  def wasLaboratoryTestOrderAfterDiagnosis(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean= {
    wasElementPresentAfterOtherElementInHistory(visit, m, HistoryElement1,patientHistoryList,HistoryElement2.toSeq )
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property
    * @param currentElement current element date
    * @param months minus months from date
    * @param patientHistoryList patient history list
    * @param mostRecentHistoryList most recent patient history list
    * @return if Dignosis Before Most Recent Encounter
    */

  def wasDignosisBeforeMostRecentEncounter(visit: CassandraRow, m: MeasureProperty, currentElement: String,months: Int, patientHistoryList:Broadcast[List[CassandraRow]],mostRecentHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentBeforeMostRecentElement(visit, m, currentElement,months, patientHistoryList,mostRecentHistoryList)
  }

  /**
    *
    * @param visit current patient vsisit
    * @param m measure property
    * @param currentElement current element
    * @param months minus months from months
    * @param patientHistoryList patient history list
    * @param mostRecentHistoryList most recent element list
    * @return of Assessment Performed Before Most Recent Encounter
    */
  def wasAssessmentPerformedBeforeMostRecentEncounter(visit: CassandraRow, m: MeasureProperty, currentElement: String,months: Int, patientHistoryList:Broadcast[List[CassandraRow]],mostRecentHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentBeforeMostRecentElement(visit, m, currentElement,months, patientHistoryList,mostRecentHistoryList)
  }

  /**
    *
    * @param visit current patient  list
    * @param m measure property
    * @param elementName current element
    * @param patientHistoryList  patient history list
    * @return it Intervention Not Done
    */
  def isInterventionNotDone(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
     checkElementDuringMeasurementPeriod(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]])
  }


  /**
    * This function checks if lab test of element is performed during diagnosis of other element
    * @param visit current visit
    * @param m measure property
    * @param labTestElement alb test element
    * @param labTestElementDate lab test element date
    * @param diagnosisElement diagnosis element name
    * @param diagnosisElementDate diagnosis element date
    * @return returns true if lab test of element is performed during diagnosis of other element else returns false
    */
  def isLaboratoryTestPerformedDuringDiagnosis(visit:CassandraRow,m:MeasureProperty,labTestElement:String,labTestElementDate:String,diagnosisElement:String,diagnosisElementDate:String): Boolean ={
    checkNotNull(visit,labTestElement,labTestElementDate,diagnosisElement,diagnosisElementDate) && isDateEqual(visit,m,labTestElementDate,diagnosisElementDate)
  }

  /**
    * This function checks if assessment of element is performed during diagnosis of other element
    * @param visit current visit
    * @param m measure property
    * @param assessmentElement alb test element
    * @param assessmentElementDate lab test element date
    * @param diagnosisElement diagnosis element name
    * @param diagnosisElementDate diagnosis element date
    * @return returns true if assessment of element is performed during diagnosis of other element else returns false
    */
  def isAssessmentPerformedDuringDiagnosis(visit:CassandraRow,m:MeasureProperty,assessmentElement:String,assessmentElementDate:String,diagnosisElement:String,diagnosisElementDate:String): Boolean ={
    checkNotNull(visit,assessmentElement,assessmentElementDate,diagnosisElement,diagnosisElementDate) && isDateEqual(visit,m,assessmentElementDate,diagnosisElementDate)
  }

  /**
    * This function checks if assessment of element is performed during procedure of other element
    * @param visit current visit
    * @param m measure property
    * @param assessmentElement alb test element
    * @param assessmentElementDate lab test element date
    * @param procedureElement procedure element name
    * @param procedureElementDate procedure element date
    * @return returns true if assessment of element is performed during diagnosis of other element else returns false
    */
  def isAssessmentPerformedDuringProcedure(visit:CassandraRow,m:MeasureProperty,assessmentElement:String,assessmentElementDate:String,procedureElement:String,procedureElementDate:String): Boolean ={
    checkNotNull(visit,assessmentElement,assessmentElementDate,procedureElement,procedureElementDate) &&
      isDateEqual(visit,m,assessmentElementDate,procedureElementDate)
  }

  /**
    * This function checks if the element laboratory test is performed X months before start of diagnosis
    * @param visit current patient visit
    * @param m measure property
    * @param diagnosisElement to be checked on current record
    * @param laboratoryTestElement  history element name
    * @param months no of months to be checked
    * @param patientHistoryList patients history list
    * @return returns true if  the element laboratory test is performed X months before start of diagnosis else returns false
    */
  def isLaboratoryTestPerformedXMonthsBeforeStartOfDiagnosis(visit:CassandraRow,m:MeasureProperty,diagnosisElement:String,laboratoryTestElement:String,months:Int,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    //wasElementScreeningPerformedXMonthsBeforeStartOfDiagnosis(visit,m,currentElementName,currentElementDate,historyElement,noOfMonths,patientHistoryList)
    //wasElementBeforeElementDateWithinXDays(visit, m, currentElementDate,historyElement, noOfMonths, patientHistoryList)

    //wasElementPresentBeforeOrEqualElementInXPeriod(visit, m, historyElement, CalenderUnit.MONTH, noOfMonths, patientHistoryList)
    wasElementPresentBeforeInXPeriods(visit,m,diagnosisElement,CalenderUnit.MONTH,months,CompareOperator.LESS_EQUAL,patientHistoryList,Seq(laboratoryTestElement))
  }

  /**
    * This verifies if assessment performed before start of diagnosis
    * @param visit current patient visit
    * @param m measure property
    * @param diagnosisElement to be checked in current record
    * @param assessmentElement to be checked on history
    * @param months minus months from history element
    * @param patientHistoryList patient history list
    * @return it  return if Assessment Performed X Months Before Start Of Diagnosis
    */

  def isAssessmentPerformedXMonthsBeforeStartOfDiagnosis(visit: CassandraRow, m: MeasureProperty, diagnosisElement: String,assessmentElement:String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
   // wasElementBeforeElementDateWithinXDays(visit, m, elementDate,historyElementName, months, patientHistoryList)
    wasElementPresentBeforeInXPeriods(visit,m,diagnosisElement,CalenderUnit.MONTH,months,CompareOperator.LESS_EQUAL,patientHistoryList,Seq(assessmentElement))
  }


  /**
    * This function verifies the laboratory test is performed on Encounter.
    * @param visit Current visit of the patient
    * @param measureProperty measure property of the measure
    * @param LaboratoryTestElement LaboratoryTestElement that has to be verified on encounter.
    * @return it will return true if laboratory test is performed on encounter.
    */
  def isLaboratoryTestPerformedOnEncounter(visit:CassandraRow, measureProperty: MeasureProperty, LaboratoryTestElement: String): Boolean = {
    dataTypeOnEncounter(visit, measureProperty, LaboratoryTestElement)
  }


  def wasLaboratoryTestPerformedBeforeMedicationInDays(visit: CassandraRow, m: MeasureProperty, elementDate: String,historyElementName:String, days: Int, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    wasElementBeforeElementDateWithinXDays(visit, m, elementDate,historyElementName, days, patientHistoryList)
  }



  /**
    * This function verifies the Diagnosis is performed on encounter .
    * @param visit current visit of the patient.
    * @param measureProperty Measure property of the measure.
    * @param DiagnosisElement Diagnosis element that has to be performed on encounter.
    * @return It will return true if Diagnosis is performed on encounter.
    */
  def isDiagnosisOnEncounter(visit: CassandraRow, measureProperty: MeasureProperty, DiagnosisElement: String): Boolean = {
    dataTypeOnEncounter(visit, measureProperty, DiagnosisElement)
  }

  def wasLaboratoryTestPerformedNotDoneBeforeMedicationInDays(visit:CassandraRow, m:MeasureProperty, currentElement:String,days:Int, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:Seq[String]):Boolean= {
    wasElementPresentBeforeInXPeriods(visit: CassandraRow, m: MeasureProperty, currentElement: String,CalenderUnit.DAY, days: Int,CompareOperator.LESS, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: Seq[String])
  }

  /**
    *
    * @param visit current patient
    * @param m measure property
    * @param elementName element name
    * @param patientHistoryList patient history list
    * @return if Medication Active Before Or Equal Encounter
    */

  def wasMedicationActiveBeforeOrEqualEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isElementPresentBeforeOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList)
  }

  /**
    *
    * @param visit current patient
    * @param m measure property
    * @param elementName current element
    * @param patientHistoryList patient history list
    * @return if Medication Order Not Done Before Or Equal Encounter
    */

  def wasMedicationOrderNotDoneBeforeOrEqualEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isElementPresentBeforeOrEqualEncounter(visit, m, elementName, patientHistoryList)
  }

  /**
    *
    * @param visit current patient
    * @param m measure property
    * @param elementName  currenrt element
    * @param patientHistoryList patient history list
    * @return if is Intervention Order done
    */

  def isInterventionOrder(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementDuringMeasurementPeriod(visit, m,elementName, patientHistoryList)
  }

  /**
    *
    * @param visit current patient
    * @param m measure property
    * @param elementName  current element name
    * @param patientHistoryList patient history list
    * @return if Intervention Recommended to be done
    */

  def isInterventionRecommended(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementDuringMeasurementPeriod(visit, m,elementName, patientHistoryList)
  }

  /**
    *
    * @param visit current patient
    * @param m measure property
    * @param historyElement history element
    * @param patientHistoryList history element list
    * @return if Communication From Provider to Provider
    */

  def isCommunicationFromProvidertoProvider(visit:CassandraRow, m:MeasureProperty, historyElement: String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementDuringMeasurementPeriod(visit: CassandraRow, m,  historyElement, patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property
    * @param elementName current element name
    * @param lowerValue lower value of element
    * @param lowerFlag lower element flag
    * @param higherValue higher value of element
    * @param higherFlag higher element flag
    * @param patientHistoryList patient history element list
    * @return if Laboratory Test Performed Value In Range
    */

  def isLaboratoryTestPerformedValueInRange(visit:CassandraRow, m:MeasureProperty, elementName:String, lowerValue: Double, lowerFlag:String, higherValue:Double , higherFlag :String , patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    checkElementValueInRangeDuringMeasurementPeriod(visit, m, elementName, lowerValue, lowerFlag, higherValue , higherFlag , patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m meassure property
    * @param historyElementName history element name
    * @param years minus years
    * @param lowerValue lower value of element
    * @param lowerFlag lower flag
    * @param higherValue higher value of element
    * @param higherFlag higher flag
    * @param patientHistoryList patient history list
    * @return if Laboratory Test Performed Value In Range Before With in X Years
    */

  def wasLaboratoryTestPerformedValueInRangeBeforeWithinXYears(visit: CassandraRow, m: MeasureProperty, historyElementName:String, years:Int,lowerValue: Double, lowerFlag: String,higherValue: Double, higherFlag: String ,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementValueInRangeBeforeEndWithinXYears(visit, m, historyElementName, years,lowerValue, lowerFlag,higherValue, higherFlag ,patientHistoryList)
  }

  /**
    *
    * @param visit current
    * @param m measure property
    * @param CurrentEncounterDate current encounterdate
    * @param patientHistoryList patient history list
    * @param PatientExpiry patient expire
    * @param Discharge discharge element name
    * @return if Element Present After
    */

  def isPatientExpiredBeforeDischarge(visit:CassandraRow, m:MeasureProperty, CurrentEncounterDate:String, patientHistoryList:Broadcast[List[CassandraRow]],PatientExpiry:Seq[String],Discharge:String*):Boolean= {
    val PatientExpiryElement = PatientExpiry.mkString("")
    wasElementPresentAfter(visit, m, CurrentEncounterDate, patientHistoryList,PatientExpiry) && wasElementPresentAfter(visit, m, PatientExpiryElement, patientHistoryList,Discharge)
  }

  /**
    *
    * @param visit patienrt current visit
    * @param m measure property
    * @param CurrentElementDate current element date
    * @param patientHistoryList patient history list
    * @param historyElementName history element name
    * @return if Diagnosis After Encounter
    */

  def isDiagnosisAfterEncounter(visit:CassandraRow, m:MeasureProperty, CurrentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:String*):Boolean= {
    wasElementPresentAfter(visit, m, CurrentElementDate, patientHistoryList,historyElementName)
  }

  def wasInterventionPerformedBeforeEncounter(visit:CassandraRow, m:MeasureProperty, currentElement:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:String*):Boolean= {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, currentElement,CompareOperator.LESS_EQUAL, patientHistoryList,historyElementName)
  }

  def isCommunicationFromProvideToProviderDoneAfterWithinXDays(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElementName:String ,days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementWithinXDays(visit, m, elementDate, historyElementName ,days, patientHistoryList)
  }

  def wasCommunicationDoneFromProviderToPatientBeforeEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, CurrentElementDate: String, histroyElementName: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeElementWithinXMonths(visit: CassandraRow, m: MeasureProperty, CurrentElementDate: String, histroyElementName: String, month: Int, patientHistoryList)
  }


  def isInterventionPerformedStartsAfterDiagnosis(visit: CassandraRow, m: MeasureProperty, currentElementName: String, historyElementName: String,leastRecentList:Broadcast[List[CassandraRow]],patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    startsAfterStartOf(visit, m, currentElementName, historyElementName,leastRecentList,patientHistoryList,"isInterventionPerformedStartsAfterDiagnosis")
  }


  def isPatientCareExperiencePerformedStartsAfterDiagnosis(visit: CassandraRow, m: MeasureProperty, currentElementName: String, historyElementName: String,leastRecentList:Broadcast[List[CassandraRow]],patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    startsAfterStartOf(visit, m, currentElementName, historyElementName,leastRecentList,patientHistoryList,"isPatientCareExperiencePerformedStartsAfterDiagnosis")
  }

  def wasInterventionPerformedStartsBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String,historyElementName: String, months: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.MONTH, months, CompareOperator.LESS_EQUAL, patientHistoryList)
  }


  def wasPatientCareExperiencePerformedStartsBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String,historyElementName: String, months: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
       wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.MONTH, months, CompareOperator.LESS_EQUAL, patientHistoryList)
  }

  def wasDiagnosticStudyPerformedBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String,historyElementName: String, months: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean =  {

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.MONTH, months, CompareOperator.LESS_EQUAL, patientHistoryList)
  }

  def wasDiagnosticStudyPerformedWithMethodBeforeEncounter(visit: CassandraRow, m: MeasureProperty, element: String,elementDate: String,elementDate1: String, months: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean =  {
    wasElementAfterElementDateWithMethodinXMonths(visit, m, element,elementDate,elementDate, months, patientHistoryList)
  }

  /**
    *
    * @param visit cassandra row
    * @param m     measure property
    * @param elements elements to be checked on current row
    * @return returns true if elements present on current visit
    */
  def isPhysicalExamPerformedDuringXProcedure(visit: CassandraRow, m: MeasureProperty, elements: Seq[String]):Boolean={
    elements.exists(element=>checkElementPresent(visit, m, element))
  }


  def wasInterVentionPerformedBeforeDiagnosis(visit:CassandraRow, m:MeasureProperty, currentElement:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:String*):Boolean= {
    wasElementPresentBeforeOrEqualOtherElement(visit,m, currentElement,CompareOperator.LESS_EQUAL, patientHistoryList,historyElementName)
  }


  def wasDiagnosedInXDaysBeforeEndDate(visit: CassandraRow, m: MeasureProperty, histroyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     wasElementInXDaysBeforeEndDate(visit, m, histroyElement, days, patientHistoryList)
  }

  /**
    *
    * @param visit cassandra row
    * @param m     measure property
    * @param elements elements to be checked on current row
    * @return returns true if elements present on current visit
    */
  def isProcedurePerformedOnXProcedure(visit: CassandraRow, m: MeasureProperty, elements: Seq[String]):Boolean={
    elements.exists(element=>checkElementPresent(visit, m, element))
  }

  def wasLaboratoryTestPerformedValueBeforeOrEqualEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    checkElementValueBeforeOrEqualEncounter(visit, m, elementName, value, flag, patientHistoryList)
  }

  def wasProcedureAfterXProcedureDays(visit:CassandraRow,m:MeasureProperty,elementName:String,elementDate:String,days:Int,patientHistoryList:Broadcast[List[CassandraRow]],historyElement:String): Boolean = {
    wasCommunicationDoneAfterProcedureWithinXDays(visit,m,elementName,elementDate,days,patientHistoryList,historyElement)
  }

  def isMostRecentPhysicalExamPerformedBefore(visit: CassandraRow, m: MeasureProperty, historyElementName: String, currentElement:String, value: Double, flag: String, mostRecentpatientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementValueBeforeElement(visit: CassandraRow, m: MeasureProperty, historyElementName: String, currentElement:String, value: Double, flag: String, mostRecentpatientHistoryList: Broadcast[List[CassandraRow]])
   }

  /*def wasLaboratoryTestOrderedWithinXDaysFromDiagnosis(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElementName:String ,days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementDateWithinXDays(visit, m, elementDate, historyElementName ,days, patientHistoryList)
  }*/

  def isInterVentionPerformedValueDuringEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String):Boolean= {
    checkElementValueOnEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String)
  }

  /**
    *
    * @param visit patient cuurrent visit
    * @param measureProperty measure property
    * @param element  current element
    * @return if Laboratory Test Order During Encounter
    */

  def isLaboratoryTestOrderDuringEncounter (visit: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(visit, measureProperty, element)
  }

  /**
    *
    * @param visit cassandra row
    * @param m measure property
    * @param laboratoryTest element to be checked in X days from element
    * @param diagnosis element from which Future element would be checked
    * @param days number of days
    * @param patientHistoryList patient history list
    * @return returns true if Future element has happened in x days from element
    */

  def wasLaboratoryTestOrderedWithinXDaysFromDiagnosis(visit: CassandraRow, m: MeasureProperty,laboratoryTest:String , diagnosis: String, days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementWithinXDays(visit, m,laboratoryTest, diagnosis, days, patientHistoryList)
  }

  /**
    *
    * @param visit
    * @param m
    * @param histroyElement
    * @param days
    * @param patientHistoryList
    * @return
    */

  def wasProcedurePerformedBeforeEndInDays(visit: CassandraRow, m: MeasureProperty, histroyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentBeforeOrEqualEndInDays(visit, m, histroyElement, days, patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property
    * @param patientHistoryList patient history list
    * @param elementName history element List
    * @return if Surgery Performed performed
    */

  def isSurgeryPerformed(visit:CassandraRow, m:MeasureProperty, patientHistoryList:Broadcast[List[CassandraRow]],elementName:String*):Boolean={
    checkElementDuringMeasurementPeriodListOfElement(visit, m, patientHistoryList,elementName)
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure [property
    * @param historyElement history element
    * @param currentElement current element
    * @param hours mours minus from current element date
    * @param patientHistoryList patient history list
    * @return if Medication Order Before Surgery With in X Hours
    */

  def wasMedicationOrderedBeforeSurgeryWithinXHours(visit: CassandraRow, m: MeasureProperty,historyElement:String ,  hours: Int, patientHistoryList:Broadcast[List[CassandraRow]],currentElement:String*): Boolean = {
    wasElementBeforeElementWithinXHoursCurrentElementList(visit, m,historyElement , hours, patientHistoryList,currentElement)
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure [property
    * @param historyElement history element
    * @param currentElement current element
    * @param hours mours minus from current element date
    * @param patientHistoryList patient history list
    * @return if Assessment Performed Before Surgery With in X Hours
    */

  def wasAssessmentPerformedBeforeSurgeryWithinXHours(visit: CassandraRow, m: MeasureProperty, historyElement: String, hours: Int, patientHistoryList: Broadcast[List[CassandraRow]], currentElement: String*): Boolean = {
    wasElementBeforeElementWithinXHoursCurrentElementList(visit, m, historyElement, hours, patientHistoryList, currentElement)
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure [property
    * @param historyElement history element
    * @param currentElement current element
    * @param hours mours minus from current element date
    * @param patientHistoryList patient history list
    * @return if Medication Administered Before Surgery With in X Hours
    */

  def wasMedicationAdministeredBeforeSurgeryWithinXHours(visit: CassandraRow, m: MeasureProperty, historyElement: String, hours: Int, patientHistoryList: Broadcast[List[CassandraRow]], currentElement: String*): Boolean = {
    wasElementBeforeElementWithinXHoursCurrentElementList(visit, m, historyElement, hours, patientHistoryList, currentElement)
  }


/*
  def wasDiagnosisBeforeSurgery(visit:CassandraRow, m:MeasureProperty, currentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:String*):Boolean= {
     wasElementPresentBefore(visit, m, currentElementDate, patientHistoryList,historyElementName)
  }
*/

  /**
    *
    * @param visit patient current visit
    * @param m measurement property
    * @param historyElement history element
    * @param month minus months from history element
    * @param patientHistoryList patient history list
    * @return if Element Present Start Or Equal With In Months
    */

  def isProcedurePerformedWithinXMonths(visit: CassandraRow, m: MeasureProperty, historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    //wasElementPresentStartOrEqualWithInMonths(visit, m, histroyElement, month, patientHistoryList)
    wasElementPresentAfterStartOfWithinXPeriod(visit,m,"measurement_period_start_date",CalenderUnit.MONTH,month,CompareOperator.LESS_EQUAL,patientHistoryList,historyElement)

  }


  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param currentElement current element date
    * @param patientHistoryList patient history list
    * @param historyElementName history element date
    * @return if Diagnosis Before Surgery
    */

  def isPhysicalExamPerformedBeforeSurgery(visit:CassandraRow, m:MeasureProperty, currentElement:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:String*):Boolean= {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, currentElement,CompareOperator.LESS_EQUAL, patientHistoryList,historyElementName)
  }

  /**
    *
    * @param visit patient current
    * @param m measureutility
    * @param medicationElement current medication element
    * @param patientHistoryList patient history element
    * @return if Medication Administered
    */

  def isMedicationAdministered(visit:CassandraRow, m:MeasureProperty, medicationElement:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementDuringMeasurementPeriod(visit, m, medicationElement, patientHistoryList)

  }

  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param element current element name
    * @param histroyElement patient history element name
    * @param patientHistoryList patient history list
    * @return if Assessment Performed Before X Procedure
    */

  def wasAssessmentPerformedBeforeXProcedure(visit: CassandraRow, m: MeasureProperty, element: String ,histroyElement: String ,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    wasAssessmentPerformedBeforeMedicationActive(visit, m, element ,histroyElement ,patientHistoryList)
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param CurrentElement current element name
    * @param histElement history element name
    * @param noOfDays minus no of days from history
    * @param patientHistoryList patient history list
    * @return if Symptom Days After Procedure
    */


  def wasSymptomDaysAfterProcedure(visit:CassandraRow,m:MeasureProperty,CurrentElement:String,histElement:String,noOfDays:Int,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementAfterElementWithinXDays(visit,m,CurrentElement,histElement,noOfDays,patientHistoryList)
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param CurrentElement current element name
    * @param histElement history element name
    * @param noOfDays minus no of days from history
    * @param patientHistoryList patient history list
    * @return if Intervaention Performed Days After Procedure
    */

  def wasIntervaentionPerformedDaysAfterProcedure(visit:CassandraRow,m:MeasureProperty,CurrentElement:String,histElement:String,noOfDays:Int,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementAfterElementWithinXDays(visit,m,CurrentElement,histElement,noOfDays,patientHistoryList)
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param elementName current element name
    * @param elementDate current element date
    * @param elementValue current element value
    * @param condFlag flags
    * @param patientHistoryList history patient list
    * @param historyElements history element list
    * @return if Diagnostic Study Performed After With Value
    */


  def isDiagnosticStudyPerformedAfterWithValue(visit:CassandraRow,m:MeasureProperty,elementName:String,elementDate:String,elementValue:Double,condFlag:String,patientHistoryList:Broadcast[List[CassandraRow]],historyElements:String): Boolean ={
    wasElementAfterElementAndValueWithinXDays(visit,m,elementName,elementDate,elementValue,condFlag,patientHistoryList,historyElements,"isDiagnosticStudyPerformedAfterWithValue")
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param CurrentElement current element name
    * @param histElement history element name
    * @param noOfDays minus no of days from history
    * @param patientHistoryList patient history list
    * @return if Diagnosis Days After Procedure
    */

  def wasDiagnosisDaysAfterProcedure(visit:CassandraRow,m:MeasureProperty,CurrentElement:String,histElement:String,noOfDays:Int,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementAfterElementWithinXDays(visit,m,CurrentElement,histElement,noOfDays,patientHistoryList)
  }


  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param CurrentElement current element name
    * @param histElement history element name
    * @param noOfDays minus no of days from history
    * @param patientHistoryList patient history list
    * @return if ProcedurePerformedXDaysAfterProcedure
    */

  def wasProcedurePerformedXDaysAfterProcedure(visit:CassandraRow,m:MeasureProperty,CurrentElement:String,histElement:String,noOfDays:Int,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementAfterElementWithinXDays(visit,m,CurrentElement,histElement,noOfDays,patientHistoryList)
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param currentElement current element date
    * @param patientHistoryList patient history list
    * @param historyElementName history list of element
    * @return if Diagnosis Before Diagnostic Study On Encounter
    */

  def wasDiagnosisBeforeDiagnosticStudyOnEncounter(visit:CassandraRow, m:MeasureProperty, currentElement:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:String*):Boolean= {
      wasElementPresentBeforeOrEqualOtherElement(visit, m, currentElement,CompareOperator.LESS_EQUAL, patientHistoryList,historyElementName)
  }

  /**
    *
    * @param visit
    * @param m
    * @param elementName
    * @param value
    * @param flag
    * @param patientHistoryList
    * @return
    */

  def isRecentLaboratoryTestResultGreaterThanValue(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
     checkElementValueDuringMeasurementPeriod(visit, m, elementName, value, flag, patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure utility
    * @param CurrentElementDate current element date
    * @param patientHistoryList patiet history list
    * @param HistoryelementName history element name
    * @return if Diagnosis After Or Concurent With Diagnosis
    */


  def wasDiagnosisAfterOrConcurentWithDiagnosis(visit:CassandraRow, m:MeasureProperty, CurrentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String): Boolean ={
    wasElementPresentAfterOrEqual(visit, m, CurrentElementDate, patientHistoryList,HistoryelementName)
  }

  /**
    *
    * @param visit patient visit
    * @param m measure property
    * @param element element
    * @return if medication Adverse Effect During Encounter
    */

  def medicationAdverseEffectDuringEncounter(visit: CassandraRow, m: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(visit, m, element)
  }

  /**
    *
    * @param visit patient visit
    * @param m measure utility
    * @param elementDate current element date
    * @param histroyElement history element date
    * @param month minus month from history date
    * @param patientHistoryList list of patient history list
    * @return if Medication Administered Before Encounter In X Months
    */
  def wasMedicationAdministeredBeforeEncounterInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String ="encounterdate", histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeOrEqualInMonths(visit, m, elementDate, histroyElement, month, patientHistoryList)
  }


  /**
    * This function verifies if the procedure was performed starts X days after end of procedure
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param historyElement     history element name
    * @param currentElement     current element name
    * @param days               days to be looked after
    * @param patientHistoryList patient history list
    * @return returns true if  the procedure was performed starts X days after end of procedure
    */
  def wasProcedurePerformedStartsXDaysAfterEndOfProcedure(visit: CassandraRow, m: MeasureProperty, historyElement: String, currentElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementWithinXDays(visit, m, historyElement, currentElement, days, patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m  measure property
    * @param element1 element 1
    * @param element2 element 2
    * @param NoOfHours no of hours
    * @param patientHistoryList patient history list
    * @return if Adverse Event Not Stopped In X Hours
    */

  def wasAdverseEventNotStoppedInXHours(visit:CassandraRow,m:MeasureProperty,element1:String,element2:String,NoOfHours:Int,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementInXHours(visit,m,element1,element2,NoOfHours:Int,patientHistoryList)
  }


/*  def wasDiagnosisAfterOrConcurentWithDiagnosis(visit:CassandraRow, m:MeasureProperty, CurrentElement:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String): Boolean ={
    wasElementPresentAfterOrEqual(visit, m, CurrentElement, patientHistoryList,HistoryelementName)
  }*/

  def wasDiagnosisAfterOrConcurentWithProcedure(visit:CassandraRow, m:MeasureProperty, CurrentElement:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String): Boolean ={
    wasElementPresentAfterOrEqual(visit, m, CurrentElement, patientHistoryList,HistoryelementName)
  }

  def wasLaboratoryTestDuringMeasurementPeriod(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }

  def wasProcedureAfterOrConcurrentWithProcedureXmonths(visit: CassandraRow, m: MeasureProperty,elementName:String , historyElementName: String, months: Int, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.MONTH, months, CompareOperator.LESS_EQUAL, patientHistoryList)
  }



  def wasMedicationOrderedBeforeEncounterWithinXHours(visit: CassandraRow, m: MeasureProperty,historyElement:String , hours: Int, patientHistoryList:Broadcast[List[CassandraRow]],currentElement: String*): Boolean = {
    wasElementBeforeElementWithinXHours(visit, m,historyElement, hours, patientHistoryList,currentElement)
  }



  def wasMedicationOrderedBeforeSurgery(visit:CassandraRow, m:MeasureProperty, historyElementName:String, patientHistoryList:Broadcast[List[CassandraRow]],currentElements:String*):Boolean= {

    wasElementPresentBeforeElementList(visit, m: MeasureProperty, historyElementName, patientHistoryList, currentElements)
  }

  def wasDiagnosisBeforeSurgery(visit:CassandraRow, m:MeasureProperty, historyElementName:String, patientHistoryList:Broadcast[List[CassandraRow]],currentElements:String*):Boolean= {

    wasElementPresentBeforeElementList(visit, m: MeasureProperty, historyElementName, patientHistoryList, currentElements)

  }


  /**
    * This function checks if assessment of element is performed during procedure of other element
    * @param visit current visit
    * @param m measure property
    * @param assessmentElementDate lab test element date
    * @param procedureElementDate procedure element name
    * @return returns true if assessment of element is performed during diagnosis of other element else returns false
    */
  def isAssessmentPerformedDuringSurgery(visit:CassandraRow,m:MeasureProperty,assessmentElementDate:String,procedureElementDate:String*): Boolean ={
    checkNotNull(visit,assessmentElementDate) && isDateEqualList(visit,m,assessmentElementDate,procedureElementDate)
  }


  /**
    * This function checks if intervention was performed starts after start of encounter
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element
    * @param historyElementName history element name
    * @param days no of days to be looked after
    * @param patientHistoryList patient history list
    * @return returns true if intervention was performed starts after start of encounter else returns false
    */
  def wasInterventionPerformedStartAfterEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName:String ,days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean=
  {
    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)
  }

  /**
    * This function checks if assessment was performed starts after start of encounter
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element date
    * @param historyElementName history element name
    * @param days no of days to be looked after
    * @param patientHistoryList patient history list
    * @return returns true if assessment was performed starts after start of encounter else returns false
    */
  def wasAssessmentStartsAfterEncounterInXDays(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName:String ,days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)
  }


  /**
    * This function checks if medication was performed starts after start of encounter
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element date
    * @param historyElementName history element name
    * @param days no of days to be looked after
    * @param patientHistoryList patient history list
    * @return returns true if medication was performed starts after start of encounter else returns false
    */
  def wasMedicationStartsAfterEncounterInXDays(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName:String ,days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)
  }



  /**
    * This function checks if medication was performed starts before start of encounter
    * @param visit current patient visit
    * @param m measure property
    * @param currentElement element date
    * @param days no of days to be looked after
    * @param patientHistoryList patient history list
    * @param historyElementName history element name
    * @return returns true if medication was performed starts before start of encounter else returns false
    */
  def wasMedicationStartsBeforeEncounterWithInXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String ,days: Int, patientHistoryList:Broadcast[List[CassandraRow]], historyElementName:String*): Boolean ={

    wasElementPresentBeforeInXPeriods(visit,m,currentElement,CalenderUnit.DAY,days,CompareOperator.LESS_EQUAL,patientHistoryList,historyElementName)
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param elementName current element name
    * @param patientHistoryList history patient list
    * @return if Patient is Expired Before End
    */
  def isPatientExpiredBeforeEnd(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    checkElementInHistory(visit, m, elementName, patientHistoryList)
  }


  /**
    * This function checks if assessment is not performed during EDOrCCEncounter
    * @param visit current patient visit
    * @param m measure property
    * @param element element name
    * @param edvisitArrivalDate emergency visit arrival date
    * @param edvisitDepartureDate emergency visit departure date
    * @param crtclDate critical care evaluation and management date
    * @return returns true if assessment is not performed during EDOrCCEncounter else returns false
    */
  def isAssessmentNotPerformedDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    !checkElementPresent(visit, m, element) &&
      (
        isDateInBetween(visit, m, element+"_date", edvisitArrivalDate, edvisitDepartureDate)
          ||
          isDateTimeEqual(visit, m, element+"_date", crtclDate)
        )
  }


  /**
    * This function checks if intervention is not performed during EDOrCCEncounter
    * @param visit current patient visit
    * @param m measure property
    * @param element element name
    * @param edvisitArrivalDate emergency visit arrival date
    * @param edvisitDepartureDate emergency visit departure date
    * @param crtclDate critical care evaluation and management date
    * @return returns true if intervention is not performed during EDOrCCEncounter else returns false
    */
  def isInterventionNotPerformedDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    !checkElementPresent(visit, m, element) &&
      (
        isDateInBetween(visit, m, element+"_date", edvisitArrivalDate, edvisitDepartureDate)
          ||
          isDateTimeEqual(visit, m, element+"_date", crtclDate)
        )
  }

  /**
    * This function checks if medication is not done during EDOrCCEncounter
    * @param visit current patient visit
    * @param m measure property
    * @param element element name
    * @param edvisitArrivalDate emergency visit arrival date
    * @param edvisitDepartureDate emergency visit departure date
    * @param crtclDate critical care evaluation and management date
    * @return returns true if medication is not done during EDOrCCEncounter else returns false
    */
  def isMedicationOrderNotDoneDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    !checkElementPresent(visit, m, element) &&
      (
        isDateInBetween(visit, m, element+"_date", edvisitArrivalDate, edvisitDepartureDate)
          ||
          isDateTimeEqual(visit, m, element+"_date", crtclDate)
        )
  }


  def wasDiagnosisAfterProcedurePerformed(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean= {
    wasElementPresentAfterOtherElementInHistory(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2.toSeq )

  }


  /**
    * This function checks if medication was active starts before X days
    * @param visit current patient visit
    * @param m measure property
    * @param currentElement current element
    * @param days days to be looked before
    * @param timeCompareOperator valid compare operators are (GREATER,LESS,EQUAL,GREATER_EQUAl,LESS_EQUAL)
    * @param patientHistoryList patient history list
    * @param historyElementName history element name
    * @return returns true if  medication was active starts before X days else returns false
    */
  def  wasMedicationActiveStartsBeforeInXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, days: Int,timeCompareOperator:String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: Seq[String]): Boolean ={
    wasElementPresentBeforeInXPeriods(visit,m,currentElement,CalenderUnit.DAY,days,timeCompareOperator,patientHistoryList,historyElementName)
  }


  /**
    * This function checks if intervention is performed starts after or concurrent with start of other current element
    * @param visit current patient visit
    * @param m measure property
    * @param element element name
    * @param historyElement history element
    * @param patientHistoryList patients history list
    * @return returns true if intervention is performed starts after or concurrent with start of other current element else returns false
    */
  def isInterventionPerformedStartsAfterOrConcurrentWithStartOfElement(visit: CassandraRow, m: MeasureProperty, element: String, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    isElementStartsAfterOrConcurrentWithStartOfHistory(visit,m,element,historyElement,patientHistoryList)
  }


/*

  def isDiagnosischeckElementDuringMeasurementPeriod(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
     checkElementDuringMeasurementPeriod(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]])
  }
*/

  def wasAssessmentPerformedBeforeEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty,  histroyElement: String, month: Int,value: Double,condFlag :String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementValueBeforeEncounterWithinXMonths(visit, m,  histroyElement, month: Int,value: Double,condFlag , patientHistoryList)
  }

  def wasInterventionPerformedBeforeEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEncounterWithinXMonths(visit, m, histroyElement, month, patientHistoryList)
  }

  def isPhysicalExamOrdered(r:CassandraRow,measureProperty:MeasureProperty,element:String,patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(r,measureProperty,element,patientHistoryList)
  }

  /**
    * @param visit cassendra row
    * @param m measure property
    * @param elementName get history element
    * @param patientHistoryList get history List
    * @return true if element present found between measurement period
    */
  def isPatientCharacteristic(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementDuringMeasurementPeriod(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]])

  }

  /**
    * This function checks if the element was first time diagnosed in measurement period
    * @param visit current patient visit
    * @param m measure property
    * @param element element name
    * @param leastRecentPatientHistoryList least recent patient history list
    * @return returns true if  the element was first time diagnosed in measurement period else returns false
    */
  def wasFirstDiagnosed(visit:CassandraRow,m:MeasureProperty, element:String,leastRecentPatientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    checkNotNull(visit,element) && checkElementDuringMeasurementPeriod(visit,m,element,leastRecentPatientHistoryList)
  }

  /**
    * This function checks if the element was first procedure performed in measurement period
    * @param visit current patient visit
    * @param m measure property
    * @param element element name
    * @param leastRecentPatientHistoryList least recent patient history list
    * @return returns true if  the element was first procedure performed in measurement period else returns false
    */
  def wasFirstProcedurePerformed(visit:CassandraRow,m:MeasureProperty, element:String,leastRecentPatientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    checkNotNull(visit,element) && checkElementDuringMeasurementPeriod(visit,m,element,leastRecentPatientHistoryList)
  }


  /**
    * This function checks if occurrence of diagnosis overlaps measurement period
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element name
    * @param patientHistoryList patient history list
    * @return returns true if occurrence  of diagnosis overlaps measurement period else returns false
    */
  def wasOccurrenceOfDiagnosis(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    checkElementInHistory(visit,m,elementName,patientHistoryList)
  }

  /**
    *
    * @param visit
    * @param m
    * @param CurrentElement
    * @param patientHistoryList
    * @param HistoryelementName
    * @return
    */

  def wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit:CassandraRow, m:MeasureProperty, CurrentElement:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String*):Boolean= {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, CurrentElement,CompareOperator.LESS_EQUAL, patientHistoryList,HistoryelementName)
  }



  /**
    *
    * @param visit patient visit
    * @param m measurement period
    * @param CurrentElementDate current element date
    * @param patientHistoryList patient history list
    * @param HistoryelementName history lement list
    * @return if wasInterventionPerformedStartAfterEndOfProcedurePerformed
    */

  def wasInterventionPerformedStartAfterEndOfProcedurePerformed(visit:CassandraRow, m:MeasureProperty, CurrentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String*):Boolean= {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, CurrentElementDate,CompareOperator.LESS_EQUAL, patientHistoryList,HistoryelementName)
  }


  /**
    *
    * @param visit current patient visit
    * @param m measurement period
    * @param CurrentElement current element name
    * @param patientHistoryList patient gistory list
    * @param HistoryelementName history element name
    * @return if Diagnosis Start AfterEndOfProcedurePerformed
    */

  def wasDiagnosisStartAfterEndOfProcedurePerformed(visit:CassandraRow, m:MeasureProperty, CurrentElement:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String*):Boolean= {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, CurrentElement,CompareOperator.LESS_EQUAL, patientHistoryList,HistoryelementName)
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param historyElement history element
    * @param patientHistoryList patient history list
    * @return if encounter not performed during measurement period
    */

  def isEncounterPerformedNotdone(visit: CassandraRow, m:MeasureProperty, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit, m,  historyElement, patientHistoryList)
  }


  /**
    * This function verifies if diagnosis was start within X days of element
    * @param visit current patient visit
    * @param m measure property
    * @param currentElement current element name
    * @param historyElement history element
    * @param days no of days to be looked after
    * @param patientHistoryList patient history list
    * @return returns true if  diagnosis was start within X days of element else returns false
    */
  def wasDiagnosisStartsAfterElementWithinXDays(visit: CassandraRow, m: MeasureProperty,currentElement: String,historyElement:String ,  days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    wasElementAfterElementWithinXDays(visit,m,historyElement,currentElement,days,patientHistoryList)
  }

  /**
    * This function checks if intervention was performed starts after or concurrent with start of laboratory test
    * @param visit current patient visit
    * @param m measure property
    * @param element element name
    * @param historyElement history element
    * @param patientHistoryList patient history list
    * @return returns true if  intervention was performed starts after or concurrent with start of laboratory test else returns false
    */
  def wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit: CassandraRow, m: MeasureProperty, element: String, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    isElementStartsAfterOrConcurrentWithStartOfHistory(visit,m,element,historyElement,patientHistoryList)
  }



  /**
    * This function checks if assessment was performed starts after or concurrent with start of laboratory test
    * @param visit current patient visit
    * @param m measure property
    * @param element element name
    * @param historyElement history element
    * @param patientHistoryList patient history list
    * @return returns true if  assessment was performed starts after or concurrent with start of laboratory test else returns false
    */
  def wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit: CassandraRow, m: MeasureProperty, element: String, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    isElementStartsAfterOrConcurrentWithStartOfHistory(visit,m,element,historyElement,patientHistoryList)
  }


  def wasAssessmentPerformedWithResultBeforeDignosticStudyWithInXHours(visit: CassandraRow, m: MeasureProperty, currentElement:String,historyElement: String,historyElementResult: String, hours: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasTwoElementEqualBeforeEncounterWithinXHours(visit, m, currentElement,historyElement,historyElementResult, hours, patientHistoryList)
  }

  def isDiagnosticStudyOrderedWithReasonDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, reasonElementDate:String,edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    (checkElementPresent(visit, m, element)

      &&  visit.getDateTime(elementDate).equals(visit.getDateTime(reasonElementDate))
      &&
      (
        isDateInBetween(visit, m, elementDate, edvisitArrivalDate, edvisitDepartureDate)
          ||
          isDateTimeEqual(visit, m, elementDate, crtclDate)
        )
      )
  }

  /**
    * This function verifies the procedure ends before X weeks of another procedure.
    * @param visit current patient visit
    * @param m measure property
    * @param element element name
    * @param historyElement history element that has to be check in history
    * @param weeks number of weeks
    * @param patientHistoryList Patient history list
    * @return It will return true if procedure ends before another procedure in X weeks.
    */
  def wasProcedureEndsBeforeProcedureInXWeeks(visit: CassandraRow, m: MeasureProperty, element: String,historyElement: String, weeks: Int, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeElementWithInXWeeks(visit, m, element,historyElement, weeks, patientHistoryList)
  }


  /**
    * The function verifies the physical exam result greater or equal  during emergency visit.
    * @param visit current patient visit
    * @param m measure property
    * @param Element element name
    * @param value   value that has to be checked
    * @param edvisitArrivalDate emergency visit arrival date
    * @param edvisitDepartureDate emergency visit departure date
    * @param crtclDate critical care evaluation and management date
    * @return It will return true if Physical exam result greater or equal during emergency visit else false.
    */

  def isPhysicalExamResultGraterOrEqualXDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, Element: String, value:Float,edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    isMedicationOrderResultDuringEDorCCGreaterThanX(visit, m, Element, value,edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }

  /**
    * This function verifies the laboratory test result greater during emergency visit.
    * @param visit current patient visit
    * @param m measure property
    * @param Element element name
    * @param value   value that has to be checked
    * @param edvisitArrivalDate emergency visit arrival date
    * @param edvisitDepartureDate emergency visit departure date
    * @param crtclDate critical care evaluation and management date
    * @return  it will return true if laboratory test result greater during emergency visit else false.
    */

  def isLaboratoryTestResultGreaterDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, Element: String, value:Float,edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    isresultDuringEDorCCGreaterThanX(visit, m, Element, value,edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }


  /**
    *  This function verifies procedure is in X hours before or concurrent during emergency visit.
    * @param visit   current patient visit
    * @param m       measure property
    * @param histElement history element that has to be verified in histoy
    * @param hours   number of hours
    * @param edvisitArrivalDate emergency visit arrival date
    * @param crtclDate critical care evaluation and management date
    * @return It will return true if procedure is performed before X hours during Emergency visit.
    */
  def wasProcedureInXhoursBeforeOrConcurrentEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, histElement: String, hours:Int,edvisitArrivalDate: String,  crtclDate: String,patientHistoryList:Broadcast[List[CassandraRow]])():Boolean={
    wasElementXhoursBeforeOrConcurrentEDOrCCEncounter(visit, m, histElement, hours,edvisitArrivalDate,  crtclDate,patientHistoryList)
  }

  /**
    * This function verifies the sympton is X hours before or concurrent during emergency visit.
    * @param visit   current patient visit
    * @param m       measure property
    * @param histElement element name
    * @param hours   number of hours
    * @param edvisitArrivalDate emergency visit arrival date
    * @param crtclDate critical care evaluation and management date
    * @return
    */
  def wasSymptomInXhoursBeforeEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, histElement: String, hours:Int,edvisitArrivalDate: String,  crtclDate: String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementXhoursBeforeOfEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, histElement: String, hours:Int,edvisitArrivalDate: String,  crtclDate: String,patientHistoryList:Broadcast[List[CassandraRow]])
  }


  /**
    * This function verifies the medication ia administered before encounter with in X days.
    * @param visit current visit
    * @param m measure Property of the measure
    * @param currentElement current row element
    * @param historyElementName history element
    * @param day no of days before currentElementDate
    * @param patientHistoryList patient history
    * @return true if element is between currentElementDate and currentElementDate - days
    */
  def wasMedicationAdministeredBeforeEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, day:Int, patientHistoryList: Broadcast[List[CassandraRow]],historyElementName:String*): Boolean = {
   wasElementPresentBeforeInXPeriods(visit,m,currentElement,CalenderUnit.DAY,day,CompareOperator.LESS_EQUAL,patientHistoryList,historyElementName)
  }

  /**
    *
    * @param visit current visit
    * @param m measure Property of the measure
    * @param HistoryElement1 history element 1
    * @param patientHistoryList patient history list
    * @param HistoryElement2
    * @return
    */
  def wasInterventionPerformedAfterEncounterinHistory(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean= {
    wasElementPresentAfterOtherElementInHistory(visit, m, HistoryElement1,patientHistoryList,HistoryElement2)

  }

  /**
    *
    * @param visit
    * @param m
    * @param CurrentElement
    * @param histElement
    * @param noOfDays
    * @param patientHistoryList
    * @return
    */
  def wasInterventionPerformedBeforeWithinXDaysOfPatientExpired(visit:CassandraRow,m:MeasureProperty,CurrentElement:String,histElement:String,noOfDays:Int,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    wasDiagnosticStudyBeforeXDaysProcedure(visit,m,CurrentElement,histElement,noOfDays,patientHistoryList)
  }


  def wasInterventionPerformedBeforeXDaysGreaterOfPatientExpired(visit:CassandraRow,m:MeasureProperty,CurrentElement:String,histElement:String,noOfDays:Int,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    wasElementBeforeXDaysGreaterofElement(visit,m,CurrentElement,histElement,noOfDays,patientHistoryList)
  }


  def wasDiagnosisBeforeStartInXMonths(r: CassandraRow, m: MeasureProperty, elementName: String, calenderUnit: String, calenderInterval:Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeStartDateInXPeriod(r: CassandraRow, m: MeasureProperty, elementName: String, calenderUnit: String, calenderInterval:Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  /**
    * This function verifies if the Laboratory test is performed before encounter
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element name
    * @param patientHistoryList patient history list
    * @return returns true if the Laboratory Test is performed before encounter else returns false
    */
  def wasLaboratoryTestPerformedBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementPresentBeforeEncounter(visit, m, elementName, patientHistoryList)
  }


  /**
    * This function checks if procedure was performed ends before start of element
    * @param visit current patient visit
    * @param m measure property
    * @param currentElement current element
    * @param patientHistoryList patient history list
    * @param historyElements history elements
    * @return returns true if  procedure was performed ends before start of element else returns false
    */
  def wasProcedurePerformedEndsBeforeStartOf(visit:CassandraRow, m:MeasureProperty, currentElement:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElements:String*): Boolean ={
    checkNotNull(visit,currentElement,currentElement+"_date") && wasElementPresentBeforeOrEqualOtherElement(visit,m,currentElement,CompareOperator.LESS_EQUAL,patientHistoryList,historyElements)
  }


  /**
    * This function checks if laboratory test performed result compared with provided value  satisfies condition
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element name
    * @param value value to be compare with
    * @param flag comparision flag (valid flags are gt,lt,ge,le,eq)
    * @param patientHistoryList patient history list
    * @return returns true if laboratory test performed result compared with provided value satisfies condition else returns false
    */
  def wasLaboratoryTestPerformedValueBeforeEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    checkElementValueBeforeOrEqualEncounter(visit, m, elementName, value, flag, patientHistoryList)
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param element element from current row
    * @param histroyElement element to be checked in history
    * @param patientHistoryList patient history list
    * @return returns true if history element exists before current element
    */
  def isCommunicationFromProviderToPatientBeforeSurgery(visit: CassandraRow, m: MeasureProperty, element: String, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasInterventionPerfomedBeforeStartOfSurgery(visit, m, element, histroyElement, patientHistoryList)
  }


  /**
    * This function checks if most recent laboratory test performed ends/starts before medication
    * @param visit current patient visit
    * @param m measure property
    * @param medicationElementName medication element name
    * @param labTestPatientHistoryMostRecentList patient history list for most recent lab test
    * @param labTestElementName lab test element name to be looked in history
    * @return returns true if  most recent laboratory test performed ends/starts before medication else returns false
    */
  def wasMostRecentLaboratoryTestPerformedBeforeMedication(visit:CassandraRow, m:MeasureProperty, medicationElementName:String, labTestPatientHistoryMostRecentList:Broadcast[List[CassandraRow]],labTestElementName:String*): Boolean ={
   checkNotNull(visit,medicationElementName,medicationElementName +"_date") && wasElementPresentBeforeOrEqualOtherElement(visit,m,medicationElementName,CompareOperator.LESS_EQUAL,labTestPatientHistoryMostRecentList,labTestElementName)
  }


  /**
    * This function is used for eyes checking values
    * @param visit patient current visit
    * @param m measurement period
    * @param historyElement check first history eye element
    * @param currentElement check element in current tbl encounter
    * @param currentEyeElement check current eye element
    * @param days minus days from history element
    * @param patientHistoryList patient history list for eye element
    * @param historyEyeElement list of history element for eyes checking
    * @return if Element After Element With in X Days Eyes and check element after element with in X days
    */
  def checkEyeElementWithinXDays(visit: CassandraRow, m: MeasureProperty,historyElement:String , currentElement: String,currentEyeElement: String ,days: Int, patientHistoryList:Broadcast[List[CassandraRow]],historyEyeElement:String): Boolean = {
    (wasElementAfterElementWithinXDaysEyes(visit, m,historyElement , currentElement,currentEyeElement ,days, patientHistoryList,historyEyeElement:String)
    &&
    wasElementAfterElementWithinXDays(visit, m,historyElement , currentElement, days, patientHistoryList)
      )

  }

  /**
    * This function verifies the laboratory test result greater during emergency visit.
    * @param visit current patient visit
    * @param m measure property
    * @param Element element name
    * @param value   value that has to be checked
    * @param edvisitArrivalDate emergency visit arrival date
    * @param edvisitDepartureDate emergency visit departure date
    * @param crtclDate critical care evaluation and management date
    * @return  it will return true if laboratory test result greater during emergency visit else false.
    */

  def isLaboratoryTestResultGreaterOrLessDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, Element: String, value:Double,edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String,compareflag:Boolean):Boolean={
    isresultDuringEDorCCGreaterOrLessThanX(visit, m, Element, value,edvisitArrivalDate, edvisitDepartureDate, crtclDate,compareflag)
  }

  /**
    * The function verifies the physical exam result greater or equal  during emergency visit.
    * @param visit current patient visit
    * @param m measure property
    * @param Element element name
    * @param value   value that has to be checked
    * @param edvisitArrivalDate emergency visit arrival date
    * @param edvisitDepartureDate emergency visit departure date
    * @param crtclDate critical care evaluation and management date
    * @return It will return true if Physical exam result greater or equal during emergency visit else false.
    */

  def isPhysicalExamResultGraterOrEqualXDuringEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, Element: String, value:Double,edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    isMedicationOrderResultDuringEDorCCGreaterThanX(visit, m, Element, value,edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }

  /**
    * This function is used for to check Medication Administered performed after diagnosis
    * @param visit current patient visit
    * @param m measure property
    * @param HistoryElement1 history element history element name
    * @param patientHistoryList patient history list name to check mmedication adminisdtraed
    * @param HistoryElement2 2nd history element list name for checking element
    * @return it return if Medication Administered After Diagnosis In History
    */

  def wasMedicationAdministeredAfterDiagnosisInHistory(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean= {
    wasElementPresentAfterOtherElementInHistory(visit, m, HistoryElement1,patientHistoryList,HistoryElement2 )
  }


  /**
    * This function checks if patient characteristic during other encounter element performed
    * @param visit current patient visit
    * @param m measure property
    * @param patientCharacteristicDate pateint characteristic date
    * @param encounterElementDate encounter element date
    * @return returns true if patient characteristic during other encounter element performed else returns false
    */
  def isPatientCharacteristicOnEncounter(visit: CassandraRow, m:MeasureProperty, patientCharacteristicDate: String, encounterElementDate: String): Boolean ={
    isDateEqual(visit,m,patientCharacteristicDate,encounterElementDate)
  }

  /**
    * This function verifies if the patient was transferred X days on or before encounter
    * @param visit current patient visit
    * @param m measure property
    * @param encounterElementDate encounter element date
    * @param transferElementName transfer element name
    * @param days no of days to be looked on or before encounter
    * @param patientHistoryList patient history list
    * @return returns true if the patient was transferred X days on or before encounter else returns false
    */
  def wasPatientTransferredToXDaysOnOrBeforeEncounter(visit: CassandraRow, m: MeasureProperty, encounterElementDate: String, days:Int, patientHistoryList: Broadcast[List[CassandraRow]], transferElementName:String*): Boolean ={
    //checkElementPresentBeforeElementWithinXDays(visit,m,encounterElementDate,transferElementName,noOfDays,patientHistoryList)

    wasElementPresentBeforeInXPeriods(visit,m,encounterElementDate,CalenderUnit.DAY,days,CompareOperator.LESS_EQUAL,patientHistoryList,transferElementName)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property
    * @param elementName current element name
    * @param HistoryElementName history element name
    * @param patientHistoryList patient history list
    * @return if history element is after current element abd before end date
    */
  def wasAssessmentNotDoneAfterProcedureWithReasonBeforeEnd(visit:CassandraRow, m:MeasureProperty, elementName:String,HistoryElementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
     checkElementAfterElementBeforeEndDate(visit, m, elementName,HistoryElementName, patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measurement period
    * @param currentElement current element for encounter
    * @param historyElement history element date compare with encounter date
    * @param historyElementResult history element result
    * @param patientHistoryList patient  element list for encounter
    * @return if Encounter Perform After Encounter with reasion specified element
    */

  def wasEncounterPerformAfterEncounterWithReason(visit: CassandraRow, m: MeasureProperty, currentElement:String,historyElement: String,historyElementResult: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasTwoElementPresentAfterCurrentElement(visit, m, currentElement,historyElement,historyElementResult, patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property
    * @param elementName current element date fot labrotatory
    * @param historyElementName history element name  Laboratory
    * @param days days after element date
    * @param patientHistoryList patient history list for Laboratory
    * @return if wasResultPresentAfterLaboratoryTest
    */

  def wasResultPresentAfterLaboratoryTest(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName:String ,days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {


    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)
  }

  /**
    *
    * @param visit
    * @param m
    * @param elementDate
    * @param historyElementName
    * @param days
    * @param patientHistoryList
    * @return
    */

  def wasResultPresentBeforeLaboratoryTest(visit: CassandraRow, m: MeasureProperty, elementDate: String,historyElementName:String, days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeElementDateWithinXDays(visit, m, elementDate,historyElementName, days, patientHistoryList)
  }

  /**
    *
    * @param visit
    * @param m
    * @param element
    * @param resultElement
    * @param edvisitArrivalDate
    * @param edvisitDepartureDate
    * @param crtclDate
    * @return
    */

  def isLaboratoryTestWithResultDuringEdorCC(visit: CassandraRow, m: MeasureProperty, element: String,  resultElement:String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    isDiagnosisDuringEncounter(visit, m, element,  resultElement, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }


  /**
    * This function checks if intervention performed X days starts after  end of encounter element date(upper date is excluded)
    * @param visit current patient visit
    * @param m measure property
    * @param encounterElement encounter element
    * @param interventionElementName intervention element name
    * @param reasonElement reason element to be checked
    * @param days no of days to be checked after encounter date
    * @param patientHistoryList patients history list
    * @return returns true if intervention performed X days starts after  end of encounter element date else returns false
    */
  def wasInterventionPerformedAfterEncounterWithReason(visit: CassandraRow, m: MeasureProperty, encounterElement: String, interventionElementName:String, reasonElement:String, days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    wasDataTypeStartAfterEndOfXDaysWithReason(visit,m,encounterElement,interventionElementName,reasonElement:String,days,patientHistoryList)
  }

  /**
    * This function checks if the encounter element is performed in within X days of starts after start of measurement period
    * @param visit current patient visit
    * @param m measure property
    * @param encounterName encounter element name
    * @param days no of days to be checked after starts after start of measurement period
    * @param patientHistoryList patient history list
    * @return returns true if  the encounter element is performed in within X days of starts after start of measurement period else returns false
    */
  def isEncounterPerformedInXDays(visit:CassandraRow, m:MeasureProperty, encounterName:String,days:Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    isEventStartsAfterStartMeasurementPeriodWithinXPeriod(visit,m,encounterName,CalenderUnit.DAY,days,CompareOperator.LESS_EQUAL,patientHistoryList)
  }


  /**
    * This function checks if the lab test was performed before encounter within X months
    * @param visit current patient visit
    * @param m measure property
    * @param encounterElementDate encounter element date
    * @param labTestElement lab test element name
    * @param months mo of months to be looked before
    * @param patientHistoryList patient history list
    * @return returns true if  the lab test was performed before encounter within X months else returns false
    */
  def wasLaboratoryTestPerformedBeforeEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, encounterElementDate: String,labTestElement: String, months: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    //wasElementAfterElementDateWithinXPeriod(visit,m,encounterElementDate,labTestElement,CalenderUnit.MONTH,months,patientHistoryList)

    wasElementPresentBeforeInXPeriods(visit,m,encounterElementDate,CalenderUnit.MONTH,months,CompareOperator.LESS_EQUAL,patientHistoryList,Seq(labTestElement))


  }

  /**
    *
    * @param visit
    * @param m
    * @param diagnosisElement
    * @param patientHistoryList
    * @return
    */


  def wasMedicationBeforeorEqualEncounter(visit:CassandraRow, m:MeasureProperty, diagnosisElement:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isElementPresentBeforeOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, diagnosisElement: String, patientHistoryList)
  }

  /**
    *
    * @param visit
    * @param m
    * @param elementName
    * @param month
    * @return
    */


  def isInterventionPerformedAfterDOBWithinXMonths(visit: CassandraRow, m:MeasureProperty,elementName:String,month:Int): Boolean = {

    isEncounterPerformedAfterDOBWithinXMonths(visit,m ,elementName,month)
  }

  /**
    *
    * @param visit
    * @param m
    * @param elementName
    * @param month
    * @return
    */

  def isAssessmentPerformedAfterDOBWithinXMonths(visit: CassandraRow, m:MeasureProperty,elementName:String,month:Int): Boolean = {

    isEncounterPerformedAfterDOBWithinXMonths(visit,m ,elementName,month)
  }

  /**
    *
    * @param visit
    * @param m
    * @param elementName
    * @param patientHistoryList
    * @param HistoryelementName
    * @return
    */


  def isLaboratoryTestPerformAfterEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String*):Boolean= {
    checkElementDuringMeasurementPeriod(visit,m,elementName ,patientHistoryList) && wasElementPresentAfter(visit, m, elementName+"_date", patientHistoryList,HistoryelementName)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property
    * @param currentElementDate current element date
    * @param patientHistoryList patient history list
    * @param historyElementName Laboratory test order element
    * @return if Laboratory Test Order Before
    */


  def wasLaboratoryTestOrderBefore(visit:CassandraRow, m:MeasureProperty, currentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:Seq[String]):Boolean= {
    wasElementPresentBeforeOrEqualOtherElement(visit:CassandraRow, m:MeasureProperty, currentElementDate:String,CompareOperator.LESS_EQUAL, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:Seq[String])
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property
    * @param elementDate current element date
    * @param historyElement history element date
    * @param patientHistoryList patient history list
    * @return if diagnosis before or equals Encounter
    */

  def wasDiagnosisBeforeorEqualEncounter(visit: CassandraRow, m:MeasureProperty, elementDate:String, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    wasElementBeforeOrEqualInHistory(visit, m, elementDate, historyElement, patientHistoryList)
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property
    * @param elementName1 laboratory test element 1
    * @param elementName2 laboratory test element 2
    * @return if Laboratory Test both element on same date
    */

  def isLaboratoryTestConcurrent(visit: CassandraRow, m:MeasureProperty, elementName1:String, elementName2:String): Boolean = {
    isDateEqual(visit,m,elementName1,elementName2)
  }

  /**
    * this function check wheteher two elemnent was equal during mesasurement period
    * @param visit current visit
    * @param m measure property
    * @param inpatientElement history element1
    * @param dischargeElement  history element1
    * @param patientHistoryList patient history list
    * @return true if two elemnent was equal during mesasurement period
    */
  def isEncounterPerformedWithDischargeStatus(visit: CassandraRow, m: MeasureProperty, inpatientElement: String,dischargeElement: String , patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {

    (checkElementDuringMeasurementPeriod(visit, m, dischargeElement, patientHistoryList)&&
      checkElementInHistory(visit, m, inpatientElement, patientHistoryList)
      )
  }



  /**
    *
    * @param visit patient current visit
    * @param m measurement period
    * @param historyElement procedure performed history element
    * @param days days minus from history
    * @param patientHistoryList patient history list for procedure performed
    * @return if procedure performed with After in X days
    */

  def isProcedurePerformedXDaysAfterEncounter(visit: CassandraRow, m: MeasureProperty,historyElement:String ,  days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterEncounterWithinXDays(visit, m,historyElement , days, patientHistoryList)
  }

  /**
    *
    * @param visit patient current visit
    * @param m measurement period
    * @param historyElement procedure performed history element
    * @param days days minus from history
    * @param patientHistoryList patient history list for procedure performed
    * @return if procedure performed with before in X days
    */

  def isProcedurePerformedXDaysBeforeEncounter(visit: CassandraRow, m: MeasureProperty,historyElement:String , days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEncounterWithinXDays(visit, m,historyElement ,  days, patientHistoryList)
  }



  /**
    * This function checks if the data type performed starts before end of measurement period and element result compare with specified value condition
    * @param visit current patient visit
    * @param m measure property
    * @param assessmentElement element name
    * @param assessmentElementValue element value
    * @param compareFlag compare flag (valid flags [lt,gt,le,ge,eq])
    * @param patientHistoryList
    * @return returns true if  the data type performed starts before end of measurement period and element result compare with specified value condition else returns false
    */
  def isAssessmentPerformedStartsBeforeEndWithValue(visit: CassandraRow, m: MeasureProperty, assessmentElement: String,assessmentElementValue:Double,compareFlag:String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    dataTypePerformedStartsBeforeEndOfMeasurementPeriodWithValue(visit,m,assessmentElement,assessmentElementValue,compareFlag,patientHistoryList)
  }

  /**
    * This function verifies if medication is ordered after diagnosis.
    * @param visit Current visit of the patent
    * @param m   measure Property of the measure
    * @param currentElementDate current element date
    * @param patientHistoryList patient history list
    * @param historyElementName history element
    * @return it will return true if medication ordered after diagnosis else false
    */
  def wasMedicationOrderedAfterDiagnosis(visit:CassandraRow, m:MeasureProperty, currentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:String*):Boolean= {
    wasElementPresentAfter(visit,m, currentElementDate, patientHistoryList,historyElementName)
  }

  /**
    * This function verifies the medication is active after medication in x days.
    * @param visit Current visit of the patent
    * @param m   measure Property of the measure
    * @param histelement  first history element
    * @param histelement2  second history element
    * @param NoOfDays     number of days that has to be added
    * @param patientHistoryList patient hsitory list
    * @return it will retur true if medication is active after medication plus X days else false
    */

  def wasMedicationActiveAfterMedicationInXDays(visit:CassandraRow,m:MeasureProperty,histelement:String,histelement2:String,NoOfDays:Int,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementInXDays(visit,m,histelement,histelement2,NoOfDays,patientHistoryList)
  }

  /**
    * This function verifies the medication is before end with x days.
    * @param visit Current visit of the patent
    * @param m   measure Property of the measure
    * @param elementDate medication element date
    * @param month   number of month that has to be added
    * @param patientHistoryList patient history list
    * @return  it will return true if medication was active before end eith x days else fale
    */
  def wasMedicationActiveBeforeEndWithinXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String,  month: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEndWithinXMonths(visit, m, elementDate,  month , patientHistoryList)
  }

  /**
    * This function verifies if Diagnosis is before end  with x days.
    * @param visit Current visit of the patent
    * @param m   measure Property of the measure
    * @param elementDate medication element date
    * @param month   number of month that has to be added
    * @param patientHistoryList patient history list
    * @return  it will return true if Diagnosis was active before end eith x days else fale
    */
  def wasDiagnosisBeforeEndWithinXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String,  month: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEndWithinXMonths(visit, m, elementDate,  month , patientHistoryList)
  }



  /**
    * This function verifies medication is active equal or before start date
    * @param visit current visit of patient
    * @param m       measure Property of the measure
    * @param histElement history element
    * @param patientHistoryList patient history list
    * @return
    */
  def wasMedicationActiveBeforeOrEqualStartDate(visit: CassandraRow, m: MeasureProperty, histElement: String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeOrEqualStartDate(visit, m, histElement,patientHistoryList)
  }

  /**
    * This function verifies if the procedure is performed before end date in x years
    * @param r current visit of patient
    * @param m   measure Property of the measure
    * @param elementDate element date
    * @param years     number of years
    * @param patientHistoryList patient history list
    * @return
    */
  def wasProcedurePerformedBeforeEndInXYears(r: CassandraRow, m: MeasureProperty, elementDate: String, years: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEndInXYears(r: CassandraRow, m: MeasureProperty, elementDate: String, years: Int, patientHistoryList:Broadcast[List[CassandraRow]])
  }

  /**
    * This function verifies encounter performed before end of the measurement period
    * @param visit current visit of patient
    * @param m  measure Property of the measure
    * @param elementName  element name that has to ne verified in history
    * @param patientHistoryList patient history list
    * @return
    */
  def isEncounterPerformedBeforeEnd(visit:CassandraRow, m:MeasureProperty,elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isDiagnosisWithBeforeEnd(visit, m,elementName, patientHistoryList)
  }
  /**
    * this function verifies the if Diagnosis was before or equal to start Date
    * @param visit current visit of the patient
    * @param m Measure property of the measure
    * @param histElement history element that has to be verified in history
    * @param patientHistoryList patient history list
    * @return it will return true if daignosis is before or equal to start Date.
    */
  def wasDiagnosisBeforeOrEqualStartDate(visit: CassandraRow, m: MeasureProperty, histElement: String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeOrEqualStartDate(visit, m, histElement,patientHistoryList)
  }

  /**
    *
    * @param visit
    * @param m
    * @param HistoryElement1
    * @param patientHistoryList
    * @param HistoryElement2
    * @return
    */
  def wasProcedureAfterDiagnosis(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean={
    wasElementPresentAfterOtherElementInHistory(visit, m, HistoryElement1,patientHistoryList,HistoryElement2 )

  }


  def wasMedicationAfterDiagnosis(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean={
    wasElementPresentAfterOtherElementInHistory(visit, m, HistoryElement1,patientHistoryList,HistoryElement2 )
  }
  def wasMedicationStartsAfterEndOfMedication(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean={
    wasElementPresentAfterOtherElementInHistory(visit, m, HistoryElement1,patientHistoryList,HistoryElement2 )
  }

  /**
    * This function checks if diagnosis starts after start of measurement period within X days(measurement end date excluded)
    * @param visit current patient visit
    * @param m measure property
    * @param diagnosisElementName diagnosis element name
    * @param days no of days to be looked after
    * @param patientHistoryList patient history list
    * @return returns true if  starts after start of measurement period within X days else returns false
    */
  def isDiagnosisStartsAfterStartWithinXDays(visit:CassandraRow, m:MeasureProperty, diagnosisElementName:String, days:Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
  isEventStartsAfterStartMeasurementPeriodWithinXPeriod(visit,m,diagnosisElementName,CalenderUnit.DAY,days,CompareOperator.LESS,patientHistoryList)
}


  /**
    * This function checks if the diagnosis was performed before encounter element within X days
    * @param visit current patient visit
    * @param m measure property
    * @param encounterElementDate encounter element date
    * @param diagnosisElementName diagnosis element name to be looked in history
    * @param days no of days to be looked before encounter
    * @param patientHistoryList patient history list
    * @return returns true if  the diagnosis was performed before encounter element within X days else returns false
    */
  def wasDiagnosedBeforeEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, encounterElementDate: String, diagnosisElementName:String, days:Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    //checkElementPresentBeforeElementWithinXDays(visit,m,encounterElementDate,diagnosisElementName,days,patientHistoryList)

    wasElementPresentBeforeInXPeriods(visit,m,encounterElementDate,CalenderUnit.DAY,days,CompareOperator.LESS_EQUAL,patientHistoryList,Seq(diagnosisElementName))
  }

  /**
    * This function checks if encounter starts after start of encounter after X days
    * @param visit current patient visit
    * @param m measure property
    * @param elementName current encounter element date
    * @param historyElementName history encounter element date
    * @param days  no of days to be looked after current encounter
    * @param patientHistoryList patient history list
    * @return returns true if encounter starts after start of encounter after X days else returns false
    */
  def wasEncounterStartsAfterEncounterInXDays(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName:String ,days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)
  }

  /**
    * This function verifies if diagnosis is X days before encounter
    * @param visit current visit of the patient
    * @param m measure proerty of the measure
    * @param historyElement history element
    * @param days number of days
    * @param patientHistoryList patient history list
    * @return It will return true if diagnosis is X days before encounter.
    */
  def wasDiagnosisXDaysBeforeEncounter(visit: CassandraRow, m: MeasureProperty, historyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEncounterWithInXDays(visit, m, historyElement, days, patientHistoryList)
  }

  /**
    * This function verifies if the patient Characteristic Expired
    * @param visit current visit of the patient
    * @param m measure proerty of the measure
    * @param elementName
    * @param historyElementName history element
    * @param days number of days
    * @param patientHistoryList patient history list
    * @return it will return true if patient Characteristic Expired  after X days of Diagnosis
    */
  def wasPatientCharacteristicExpiredAfterXDaysDiagnosis(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    //val elementDate= element+"_date"
    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)

  }

  /**
    * This function verifies diagnostic study performed with result
    * @param visit current visit of the patient
    * @param m measure proerty of the measure
    * @param diagnosticElement  diagnostic element
    * @param resultElement result element
    * @param patientHistoryList patient history list
    * @return it will return true if diagnostic study is performed with result else false.
    */
  def wasDiagnosticStudyPerformedWithResult(visit: CassandraRow, m: MeasureProperty, diagnosticElement: String, resultElement: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementWithResult(visit, m, diagnosticElement, resultElement, patientHistoryList)

  }

  /**
    * This function verifies if encounter is performed after X days of Daignosis
    * @param visit current visit of the patient
    * @param m measure proerty of the measure
    * @param historyElement history element
    * @param days number of days that has to be added
    * @param patientHistoryList patient history list
    * @return it will return true if encounter is performed after x days of daignosis else false
    */
  def wasEncounterPerformedAfterXDaysDiagnosis(visit: CassandraRow, m: MeasureProperty, historyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasEncounterAfterXDaysOfElement(visit, m, historyElement, days, patientHistoryList)

  }

  def wasAssessmentPerformedAfterMedicationWithInXMonths(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.MONTH, month, CompareOperator.LESS_EQUAL, patientHistoryList)


  }

  def isDiagnosisList(visit:CassandraRow, m:MeasureProperty, patientHistoryList:Broadcast[List[CassandraRow]],elementName:String*):Boolean={
    wasElementListPresentDuringMeasurementPeriod(visit:CassandraRow, m:MeasureProperty, patientHistoryList:Broadcast[List[CassandraRow]],elementName:Seq[String])

  }

/*
  def wasProcedurePerformedAfterStartWithInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String,historyElement: String, historyElement1: String ,months: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterStartWithinXMonths(visit, m, elementDate,historyElement, historyElement1 ,months, patientHistoryList)
  }
*/



  def wasDignosisListAfterProcedure(visit:CassandraRow, m:MeasureProperty, CurrentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String*):Boolean= {
    wasElementPresentAfter(visit, m, CurrentElementDate, patientHistoryList,HistoryelementName)
  }

  def isDiagnosisListDuringProcedure(visit: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String*): Boolean = {
    element2.exists(isDateEqual(visit, measureProperty, element1, _))
  }

  def wasCommunicationFromProviderToProviderAfterDiagnosisListWithInXMonths(visit: CassandraRow, m: MeasureProperty, historyElement: String, months: Int, patientHistoryList:Broadcast[List[CassandraRow]],elementName: String*): Boolean = {
    wasElementAfterElementListWithinXMonths(visit, m, historyElement, months, patientHistoryList,elementName)
  }

  def wasAssessmentPerformedAfterDiagnosisListWithInXMonths(visit: CassandraRow, m: MeasureProperty, historyElement: String, months: Int, patientHistoryList:Broadcast[List[CassandraRow]],elementName: String*): Boolean = {
    wasElementAfterElementListWithinXMonths(visit, m, historyElement, months, patientHistoryList,elementName)
  }

  def isDiagnosisListDuringEncounter(visit: CassandraRow, measureProperty: MeasureProperty, elementdate1: String,elementdate2: String*): Boolean = {
    elementdate2.exists(isDateEqual(visit, measureProperty, elementdate1, _))
  }

  def wasEncounterPerformedAfterStartWithInXMonths(visit: CassandraRow, m: MeasureProperty,historyElement: String ,months: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterStartWithinXMonths(visit, m,historyElement ,months, patientHistoryList)
  }

  def isMostRecentAssessmentPerformedwithEncounter(visit: CassandraRow, m: MeasureProperty, historyElement: String,mostRecentElement: String,  patientHistoryList:Broadcast[List[CassandraRow]],mostRecentList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementEqualMostRecentElementDuringMeasurementPeriod(visit, m, historyElement,mostRecentElement,  patientHistoryList,mostRecentList)
  }

  /**
    * This function checks if the patient deceased before intervention
    * @param visit current patient visit
    * @param m measure property
    * @param interventionElement intervention element name
    * @param patientHistoryList patient history list
    * @param deceaseElementName decease element name
    * @return returns true if the patient deceased before intervention else returns false
    */
  def wasPatientDeceasedBeforeInterventionInHistory(visit:CassandraRow, m:MeasureProperty, interventionElement:String, patientHistoryList:Broadcast[List[CassandraRow]],deceaseElementName:String*): Boolean ={
    val interventionElementDate=interventionElement+"_date"
    checkNotNull(visit,interventionElement,interventionElementDate)&& wasElementPresentBeforeOrEqualOtherElement(visit,m,interventionElement,CompareOperator.LESS,patientHistoryList,deceaseElementName)
  }

  def isDiagnosticStudyPerformedInXDaysAfterProcedure(visit: CassandraRow, m: MeasureProperty,historyElement:String , currentElement: String, days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementWithinXDays(visit, m,historyElement, currentElement, days, patientHistoryList)
  }

  /**
    * This function verifies if Diagnosis is done after initial Diagnosis
    * @param visit current visit of the patient
    * @param m measure proerty of the measure
    * @param HistoryElement1 history element1
    * @param patientHistoryList patient history list
    * @param HistoryElement2 history element 2
    * @return it will return true if diagnosis is done after diagnosis else false
    */
  def wasDiagnosisDoneAfterInitialDiagnosis(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean={
    wasElementPresentAfterOtherElementInHistory(visit, m, HistoryElement1,patientHistoryList,HistoryElement2 )

  }

  def wasProcedurePerformedWithResultAfterDiagnosis(visit: CassandraRow, m: MeasureProperty,diagnosisElement: String,procedureElement: String,resultElement: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasDiagnosticStudyWithResultAfterDiagnosis(visit, m, diagnosisElement,procedureElement,resultElement, patientHistoryList)
  }


  def wasLaboratoryTestWithResultAfterDiagnosis(visit: CassandraRow, m: MeasureProperty, LaboratoryTestElement: String, diagnosisElement: String, resultElement: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasInterverntionStudyWithResultAfterMedication(visit, m, LaboratoryTestElement, diagnosisElement, resultElement, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasTransferAfterOrConcurrentProcedure(visit: CassandraRow, m: MeasureProperty,Element:String,AnotherElement:String,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementAfterOrConcurrentAnotherElement(visit, m,Element,AnotherElement,patientHistoryList)
  }

  /**
    * This function verifies if current element starts after element else retuns false
    * @param visit current patient visit
    * @param m measure property
    * @param interventionElement intervention element
    * @param medicationElement medication element name
    * @param mostRecentPatientHistoryList most recent patient history list
    * @return returns true if current element starts after element else retuns false
    */
  def wasElementStartsAfterEndOFMostRecentPatientList(visit:CassandraRow,m:MeasureProperty,interventionElement:String,medicationElement:String,mostRecentPatientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    isCurrentElementStartsAfterEndOf(visit,m,interventionElement,medicationElement,mostRecentPatientHistoryList)
  }


  /**
    * This function verifies if current element starts after X weeks of element
    * @param visit current patient visit
    * @param m measure property
    * @param assessmentElement assessment element
    * @param medicationElement history element name
    * @param weeks no of weeks to be looked after
    * @param mostRecentPatientHistoryList most recent patient history list
    * @return returns true if current element starts after element within week else retuns false
    */
  def wasAssessmentPerformedAfterEndWithinWeeksMostRecentMedication(visit:CassandraRow,m:MeasureProperty,assessmentElement:String,medicationElement:String,weeks:Int,mostRecentPatientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    isCurrentElementStartsAfterEndOfWithinXWeek(visit,m,assessmentElement,medicationElement,weeks,mostRecentPatientHistoryList)
  }

  def wasMedicationAdministeredAfterXDaysDiagnosis(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)

  }

  def isLaboratoryTestPerformedAfterWithinXBusinessDays(visit: CassandraRow, m: MeasureProperty, CurrentElementName: String,HistoryElementName: String,  day:Int,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementWithinXBusinessDays(visit, m, CurrentElementName,HistoryElementName,  day,patientHistoryList)
  }

  def isLaboratoryTestOrderedAfterWithinXBusinessDays(visit: CassandraRow, m: MeasureProperty, CurrentElementName: String,HistoryElementName: String,  day:Int,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementWithinXBusinessDays(visit, m, CurrentElementName,HistoryElementName,  day,patientHistoryList)
  }

  def isPatientBMINormal(visit: CassandraRow, m: MeasureProperty, resultElementName: String, compareFlag: String,value: Double): Boolean = {
    //valueStatus(visit, resultElementName, compareFlag, value)
    checkNotNull(visit,resultElementName) && compareValueStatus(visit.getDouble(resultElementName),compareFlag,value)
  }

  def isPatientBMIOverweight(visit: CassandraRow, m: MeasureProperty, resultElementName: String,  compareFlag: String,value: Double): Boolean = {
    //valueStatus(visit, resultElementName, compareFlag, value)
    checkNotNull(visit,resultElementName) && compareValueStatus(visit.getDouble(resultElementName),compareFlag,value)
  }

  def isPatientBMIUnderweight(visit: CassandraRow, m: MeasureProperty, resultElementName: String,  compareFlag: String,value: Double): Boolean = {
    //valueStatus(visit, resultElementName, compareFlag, value)
    checkNotNull(visit,resultElementName) && compareValueStatus(visit.getDouble(resultElementName),compareFlag,value)
  }


  /**
    * This function checks if value of result element is matching with value provided and compare flag
    * @param visit current patient visit
    * @param m measure property
    * @param resultElementName result element name
    * @param value value to be compare in double
    * @param compareFlag compare flag to be compare with
    * @return returns true if value of result element is matching with value provided and compare flag  else returns false
    */
  def isResultMatching(visit: CassandraRow, m: MeasureProperty, resultElementName: String, value: Double, compareFlag: String): Boolean = {
    //valueStatus(visit, resultElementName, compareFlag, value)
    checkNotNull(visit,resultElementName) && compareValueStatus(visit.getDouble(resultElementName),compareFlag,value)
  }

  /**
    * This function is used to perform assesment is performed before end of the measurement period
    * @param visit current visit of the patient
    * @param m measure property of the measure
    * @param histElement history element
    * @param patientHistoryList patient history list
    * @return it return true if assesment is performed before end of the measurement period.
    */
  def isAssesmentPerformedBeforeEnd(visit:CassandraRow, m:MeasureProperty,histElement:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isDiagnosisWithBeforeEnd(visit, m,histElement, patientHistoryList)
  }

  /**
    * This function verifies if medication is administered before or equal encounter
    * @param visit current visit of the patient
    * @param m Measure property of the measure
    * @param histElement history element
    * @param patientHistoryList patient history list
    * @return it will return true if medication is administered before or equal encounter date.
    */

  def wasMedicationAdministeredBeforeOrEqualEncounter(visit:CassandraRow, m:MeasureProperty, histElement:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    wasElementPresentBeforeOrEqualEncounter(visit, m, histElement, patientHistoryList)
  }

  /**
    * tthis function checks laboratory test value on encounter satisfy flag criteria with actual value
    * @param visit current visit
    * @param m measure property
    * @param elementName element wose value will be checked
    * @param value value that need to be compared
    * @param flag based on flag condition of value will be compared like ge for >= etc
    * @return true if element value on encounter satisfy flag criteria with actual value
    */
  def isLaboratoryTestValueOnEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String, value: Double, flag:String):Boolean= {
    checkElementValueOnEncounter(visit, m:MeasureProperty, elementName, value, flag)
  }


  /**
    * This function verifies diagnosis with Diagnosis in History
    * @param visit current visit
    * @param m measure property
    * @param histElement1 history element 1
    * @param histElement2 history element 2
    * @param patientHistoryList patient history list
    * @return it will return true if Diagnosis is with Diagnosis in history else false.
    */
  def wasDiagnosisWithDiagnosisInHistory(visit: CassandraRow, m: MeasureProperty, histElement1: String, histElement2: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean={
    wasElementWithResult(visit, m, histElement1, histElement2, patientHistoryList)
  }

  /**
    * This function verifies if patient is transfered to another location in history.
    * @param visit current visit
    * @param m measure property
    * @param historyElement history element
    * @param patientHistoryList patient history list
    * @return it will return true if patient is transfered.
    */
  def isTransfered(visit: CassandraRow, m:MeasureProperty,  historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit, m,  historyElement, patientHistoryList)
  }

  /**
    * This function verifies if patient was transfered after history.
    * @param visit current patient visit
    * @param m measure property
    * @param HistoryElement1 history element history element name
    * @param patientHistoryList patient history list name to check mmedication adminisdtraed
    * @param HistoryElement2 2nd history element list name for checking element
    * @return it return if patient is transfered after procedure In History
    */

  def wasTransferedAfterProcedureInHistory(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean= {
    wasElementPresentAfterOtherElementInHistory(visit, m, HistoryElement1,patientHistoryList,HistoryElement2 )
  }

  /**
    * This function verifies if communication starts after diagnosis
    * @param visit current patient visit
    * @param m measure property
    * @param HistoryElement1 history element history element name
    * @param patientHistoryList patient history list name to check mmedication adminisdtraed
    * @param HistoryElement2 2nd history element list name for checking element
    * @return it return if communication starts after diagnosis in history
    */

  def wasCommunicationStartsAfterDiagnosisInHistory(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean= {
    wasElementPresentAfterOtherElementInHistory(visit, m, HistoryElement1,patientHistoryList,HistoryElement2 )
  }


  /**
    * This function verifies if procedure is performed after diagnosis in history.
    * @param visit current patient visit
    * @param m measure property
    * @param HistoryElement1 history element history element name
    * @param patientHistoryList patient history list name to check mmedication adminisdtraed
    * @param HistoryElement2 2nd history element list name for checking element
    * @return it return if procedure is performed after diagnosis in history.
    */

  def wasProcedurePerformedAfterDiagnosisInHistory(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean= {
    wasElementPresentAfterOtherElementInHistory(visit, m, HistoryElement1,patientHistoryList,HistoryElement2 )
  }


  /**
    * This function verifes if patient is transfered after diagnosis
    * @param visit current patient visit
    * @param m measure property
    * @param HistoryElement1 history element history element name
    * @param patientHistoryList patient history list name to check mmedication adminisdtraed
    * @param HistoryElement2 2nd history element list name for checking element
    * @return it return if patient is transfered after diagnosis
    */

  def wasTransferedToAfterDiagnosisInHistory(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean= {
    wasElementPresentAfterOtherElementInHistory(visit, m, HistoryElement1,patientHistoryList,HistoryElement2 )
  }




  /*/** this function will check whether dob lie between start and end of measurement Period
    * @author Pankaj
    * @param visit current cassandra row
    * @param m measurement property
    * @return true if dob lie between start and end of measurement Period
    */
  def isDobWithinMeasurementPeriod(visit: CassandraRow, m: MeasureProperty): Boolean = {
    !visit.isNullAt("dob") && isDateBetween(visit.getDateTime("dob"),new DateTime(m.quarterStartDate),new DateTime(m.quarterEndDate))
  }


  /** this function will check whether dob lie within X Days  after start of measurement Period
    * @author Pankaj
    * @param visit current cassandra row
    * @param m measurement property
    * @param month no of month
    * @return true if dob lie within X Days  after start of measurement Period
    */
  def isDobWithinXDaysAfterMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, month: Int): Boolean = {
    !visit.isNullAt("dob") && isDateBetween(visit.getDateTime("dob"),new DateTime(m.quarterStartDate),new DateTime(m.quarterStartDate).plusMonths(month))
  }


  /** this function will check whether dob lie within X Days  before start of measurement Period
    * @author Pankaj
    * @param visit current cassandra row
    * @param m measurement property
    * @param month no of month
    * @return true if dob lie within X Days  before start of measurement Period
    */
  def isDobWithinXDaysBeforeMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, month: Int): Boolean = {
    !visit.isNullAt("dob") && isDateBetween(visit.getDateTime("dob"),new DateTime(m.quarterStartDate).minusMonths(month),new DateTime(m.quarterStartDate))
  }*/

  /**
    * This function verifies whether Diagnosis is before or equal procedure.
    * @param visit current visit of the patient
    * @param m measure property
    * @param diagnosisElement Diagnosis element
    * @param procedureElement procedure element
    * @param patientHistoryList patient history list
    * @return it will return if diagnosis is before or equal procedure else false.
    */
  def wasDiagnosisBeforeOrEqualProcedure(visit: CassandraRow, m: MeasureProperty,diagnosisElement:String,procedureElement:String,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementOverlapsElement(visit, m,diagnosisElement,procedureElement,patientHistoryList)
  }

  /**
    * This function verifies if medication stars after start of encounter element in X interval
    * @author Hemant
    * @param visit current patient visit
    * @param m measure property
    * @param encounterElementDate current encounter element date
    * @param medicationElement medication element
    * @param reasonElement reason element to be check
    * @param interval no of interval to be checked after
    * @param unit units in (DAY,MONTH,WEEK)
    * @param patientHistoryList
    * @return returns true if medication stars after start of encounter element in X interval else returns false
    */
  def wasMedicationStartsAfterEncounterWithReasonBetweenPeriod(visit: CassandraRow, m: MeasureProperty, encounterElementDate: String, medicationElement: String, reasonElement: String,interval: Int,unit:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    startsAfterStartOfWithReasonBetweenPeriod(visit,m,encounterElementDate,medicationElement,reasonElement,interval,unit,patientHistoryList)
  }


  def isDiagnosisStartsAfterStartWithinXMonths(visit: CassandraRow, m: MeasureProperty, historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     //wasElementPresentStartOrEqualWithInMonths(visit, m, histroyElement, month, patientHistoryList)
    wasElementPresentAfterStartOfWithinXPeriod(visit,m,"measurement_period_start_date",CalenderUnit.MONTH,month,CompareOperator.LESS_EQUAL,patientHistoryList,historyElement)
  }


  def laboratoryTestPerformedOverlapsEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param currentElementName element from current row
    * @param historyElement element to be checked in history
    * @param noOfHours number of hours
    * @param patientHistoryList patient history list
    * @return returns true if medication was administered before procedure within x hours
    */
  def isMedicationAdministeredBeforeProcedureInXHours(visit: CassandraRow, m: MeasureProperty, currentElementName: String, historyElement: String, noOfHours: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasMedicationBeforeXhrOfProcedure(visit, m, currentElementName, historyElement, noOfHours, patientHistoryList)
  }


  /** this function will check whether dob lie within X Days  after start of measurement Period
    * @author Pankaj
    * @param visit current cassandra row
    * @param m measurement property
    * @param month no of month
    * @return true if dob lie within X Days  after start of measurement Period
    */
  def isDobWithinXMonthsAfterMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, elementName:String,month: Int,afterFlag:Boolean): Boolean = {

    checkElementInDateRange(visit, m, elementName,month,afterFlag)

  }



  /** this function will check whether dob lie within X Days  before start of measurement Period
    * @author Pankaj
    * @param visit current cassandra row
    * @param m measurement property
    * @param month no of month
    * @return true if dob lie within X Days  before start of measurement Period
    */
  def isDobWithinXMonthsBeforeMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, elementName:String,month: Int,Flag:Boolean): Boolean = {

    checkElementInDateRange(visit, m, elementName,month,Flag)


  }



  /**
    * This function verifies if medication stars before start of encounter element in X interval
    * @author Hemant
    * @param visit current patient visit
    * @param m measure property
    * @param encounterElementDate current encounter element date
    * @param medicationElement medication element
    * @param reasonElement reason element to be check
    * @param interval no of interval to be checked after
    * @param unit units in (DAY,MONTH,WEEK)
    * @param patientHistoryList
    * @return returns true if medication stars before start of encounter element in X interval else returns false
    */
  def wasMedicationStartsBeforeEncounterWithReasonBetweenPeriod(visit: CassandraRow, m: MeasureProperty, encounterElementDate: String, medicationElement: String, reasonElement: String,interval: Int,unit:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    startsBeforeStartOfWithReasonBetweenPeriod(visit,m,encounterElementDate,medicationElement,reasonElement,interval,unit,patientHistoryList)
  }

  /**
    * This function verifies if transfer to hospital(element) starts after or concurrent with end of encounter
    * @author Hemant
    * @param visit current patient visit
    * @param m measure property
    * @param edccEncounterDate edcc encounter date
    * @param transferToElementName transfer to element name (hospital)
    * @param patientHistoryList patient history list
    * @return returns true if transfer to hospital(element) starts after or concurrent with end of encounter else false
    */
  def wasTransferAfterOrConcurrentEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, edccEncounterDate: String, transferToElementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
  isElementStartsAfterOrConcurrentWithStartOfHistory(visit,m,edccEncounterDate,transferToElementName,patientHistoryList)
}

  /**
    * This function verifies if intervention was performed ends before start of procedure

    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement procedure element name
    * @param patientHistoryList patient history list
    * @param interventionElementNames intervention elements name
    * @return returns true if intervention was performed ends before start of procedure else returns false
    */
  def wasInterventionPerformedEndsBeforeStartOfProcedure(visit:CassandraRow, m:MeasureProperty, procedureElement:String, patientHistoryList:Broadcast[List[CassandraRow]],interventionElementNames:String*): Boolean ={
    checkNotNull(visit,procedureElement,procedureElement+"_date") && wasElementPresentBeforeOrEqualOtherElement(visit,m,procedureElement,CompareOperator.LESS_EQUAL,patientHistoryList,interventionElementNames)
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param currentElement  of current element
    * @param patientHistoryList patient history list
    * @param historyElementName element to be checked before current element
    * @return returns true if intervention was performed before procedure
    */
  def wasInterventionPerformedBeforeProcedure(visit:CassandraRow, m:MeasureProperty, currentElement:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:String*):Boolean= {
    wasElementPresentBeforeOrEqualOtherElement(visit,m, currentElement,CompareOperator.LESS_EQUAL, patientHistoryList,historyElementName)
  }

  /**
    * This function is used for checking Diagnosis Performed Before Or Equal EncounterDate
    * @param visit current patient visit
    * @param m measure property
    * @param diagnoses Diagnosis element
    * @param patientHistoryList  patient History
    * @return
    */

  def wasDiagnosisBeforeOrEqualEncounter(visit:CassandraRow, m:MeasureProperty, patientHistoryList:Broadcast[List[CassandraRow]], diagnoses:String*):Boolean= {
    diagnoses.exists(diagnosis => wasElementPresentBeforeOrEqualEncounter(visit, m, diagnosis, patientHistoryList))
  }

  /**
    * This function verifies the summation of laboratory test result performed before diagnosis and result value compared with provided value.
    * @param visit current visit of the patient
    * @param m measure property
    * @param labTest1 first history lab test
    * @param labTest2 second history lab test
    * @param diagnosisElement  diagnosis element
    * @param compareValue value specified for comparison
    * @param compareFlag compare flag is used to compare the sum with specified value
    * @param patientHistoryList patient history list
    * @return it will return true summation of laboratory test result value compared with provided value else false
    */
  def wasSummationOfLaboratoryTestBeforeDiagnosisWithResultXValue(visit: CassandraRow, m: MeasureProperty, labTest1: String, labTest2: String, diagnosisElement: String, compareValue: Double, compareFlag:String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasSummationOfElementsBeforeElementXValue(visit, m,  labTest1, labTest2,diagnosisElement, compareValue,compareFlag, patientHistoryList)
  }




  def wasInterventionAdverseEventInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeElementWithinXMonths(visit, m, elementDate, histroyElement, month, patientHistoryList)
  }

  def wasInterventionNotPerformedInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeElementWithinXMonths(visit, m, elementDate, histroyElement, month, patientHistoryList)
  }


  def wasPatientCharacteristicInHistory(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentBeforeEncounter(visit, m, elementName, patientHistoryList)
  }


  def wasInterventionPerformedInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeElementWithinXMonths(visit, m, elementDate, histroyElement, month, patientHistoryList)
  }

/*  def wasInterventionPerformedInXMonths(visit: CassandraRow, m:MeasureProperty, elementDate:String, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    wasElementBeforeElementWithinXMonths(visit, m, elementDate, historyElement, month, patientHistoryList)
  }*/

 /* def wasDiagnosisBeforeOrEqualProcedure(visit: CassandraRow, m:MeasureProperty, elementDate:String, historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean = {
    wasElementBeforeOrEqualInHistory(visit, m, elementDate, historyElement, patientHistoryList )

  }*/

  def wasDiagnosisPerformedBeforeProcedure(visit:CassandraRow, m:MeasureProperty, currentElement:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:String*):Boolean= {
    wasElementPresentBeforeOrEqualOtherElement(visit,m, currentElement,CompareOperator.LESS_EQUAL, patientHistoryList,historyElementName)
  }


  /**
    * This function verifies if diagnosed after initial depression medication
    * @param visit current patient visit
    * @param m measurement period
    * @param initialDepresion initial depressi
    * @param diagnosisElementName diagnosis element date
    * @param days no of days to be looked before
    * @param patientHistoryList patient history list
    * @return returns true if else returns false
    */
  def wasDiagnosedAfterEncounterWithInXDays(visit: CassandraRow, m: MeasureProperty, initialDepresion: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]], diagnosisElementName: String*): Boolean ={


    wasElementPresentBeforeInXPeriods(visit,m,initialDepresion,CalenderUnit.DAY,days,CompareOperator.LESS_EQUAL,patientHistoryList,diagnosisElementName)
  }

  /**
    * This function verifies Diagnosis before encounter with result
    * @param visit current patient visit
    * @param m measure property
    * @param histDiagnosisElement history Diagnosis Element
    * @param resultElement result element
    * @param patientHistoryList patient history element
    * @return it will return true if diagnosis is before encounter date with result else false
    */
  def wasDiagnosisBeforeOrEqualEncounterWithResult(visit: CassandraRow, m: MeasureProperty, histDiagnosisElement: String, resultElement: String,  patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeEncounterWithResult(visit, m, histDiagnosisElement, resultElement,  patientHistoryList)

  }

  /**
    *
    * @param visit current visit
    * @param m measure Property of the measure
    * @param HistoryElement1 history element 1
    * @param patientHistoryList patient history list
    * @param HistoryElement2
    * @return
    */
  def wasDiagnosticStudyPerformedAfterEncounterinHistory(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean= {
    wasElementPresentAfterOtherElementInHistory(visit, m, HistoryElement1,patientHistoryList,HistoryElement2)

  }


  /**
    *
    * @param visit current visit
    * @param m measure Property of the measure
    * @param HistoryElement1 history element 1
    * @param patientHistoryList patient history list
    * @param HistoryElement2
    * @return
    */
  def wasPatientCharacteristicAfterEncounterinHistory(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean= {
    wasElementPresentAfterOtherElementInHistory(visit, m, HistoryElement1,patientHistoryList,HistoryElement2)

  }


  /**
    * This function checks if the medication dispensed starts before starts of measurement period with X unit
    *
    * @param visit current patient visit
    * @param m measure property
    * @param medicationElement element name
    * @param interval no of interval to be checked before
    * @param unit units in (DAY,WEEK,MONTH,YEAR)
    * @param patientHistoryList patient history list
    * @return returns true if the event starts after X intervals starts of before measurement period else returns false
    */
def wasMedicationDispensedBeforeOrConcurrentStartWithInDays(visit: CassandraRow, m: MeasureProperty, medicationElement: String, interval: Int,unit:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
  isEventStartsBeforeOperatorMeasurementPeriodWithinXPeriod(visit,m,medicationElement,interval,unit,patientHistoryList,"StartOfMeasurementPeriod")
}

  /**
    * This function verifies if medication dispensed starts after X days start of measurement period
    * @param visit current patient visit
    * @param m measure property
    * @param medicationElement medication Element
    * @param days no of days to be looked after
    * @param patientHistoryList patient history list
    * @return returns true if medication dispensed starts after X days start of measurement period else returns false
    */
  def wasMedicationDispensedStartsAfterStartInXDays(visit: CassandraRow, m: MeasureProperty, medicationElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
  isEventStartsAfterStartMeasurementPeriodWithinXPeriod(visit, m, medicationElement,CalenderUnit.DAY, days,CompareOperator.LESS_EQUAL, patientHistoryList)
}


  /**
    *
    * @param visit current row
    * @param m measure property
    * @param diagnosis diagnosis element
    * @param procedure procedure element
    * @param days number of days
    * @param patientHistoryList patient history list
    * @return returns true if patient was diagnosed before procedure within x number of days
    */
  def wasDiagnosedBeforeProcedureInXDays(visit: CassandraRow, m: MeasureProperty, diagnosis: String, procedure: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementPresentBeforeOtherElementWithinXDays(visit, m, diagnosis, procedure, days, patientHistoryList)
  }

  /**

    *
    * @param visit current row
    * @param m measure property
    * @param intervention diagnosis element
    * @param procedure procedure element
    * @param days number of days
    * @param patientHistoryList patient history list
    * @return returns true if patient was diagnosed before procedure within x number of days
    */
  def wasInterventionPerformedBeforeProcedureInXDays(visit: CassandraRow, m: MeasureProperty, intervention: String, procedure: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementPresentBeforeOtherElementWithinXDays(visit, m, intervention, procedure, days, patientHistoryList)

  }


  def wasProcedurePerformedwithResultBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,unit:String ,interval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasResultElementBetweenEncounterDateWithInXCalender(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,unit:String ,interval: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasEncounterPerformedWithResultWithInXDays(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,unit:String ,interval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasResultElementBetweenEncounterDateWithInXCalender(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,unit:String ,interval: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasPerformedPerformedWithReasonWithInXYear(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,unit:String ,interval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasResultElementBetweenEncounterDateWithInXCalender(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,unit:String ,interval: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }


  def isInterventionPerformedWithResultDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String,resultElement: String): Boolean = {
    (dataTypeOnEncounter(r, measureProperty, element)
    &&
    dataTypeOnEncounter(r, measureProperty, resultElement))
  }

  def wasInterventionPerformedAfterProcedure(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: String*): Boolean = {
    wasElementPresentAfter(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName)
  }


  def wasInterventionPerformedNotDoneAfterProcedure(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: String*): Boolean = {
    wasElementPresentAfter(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName)
  }

  /**
    * patient history list, returns true if intervention was performed after procedure

    * @param visit current row
    * @param m measure property
    * @param intervention diagnosis element
    * @param procedure procedure element
    * @param patientHistoryList
    * @return
    */
  def isInterventionPerformedAfterProcedure(visit: CassandraRow, m: MeasureProperty,intervention: String, procedure: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementPresentAfterOtherElement(visit, m,intervention, procedure, patientHistoryList)
  }

  def wasDiagnositicStudyPerformedBeforeEncounter(visit:CassandraRow, m:MeasureProperty, currentElement:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:String*):Boolean= {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, currentElement,CompareOperator.LESS_EQUAL, patientHistoryList,historyElementName)
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param firstProcedure diagnosis element
    * @param secondProcedure procedure element
    * @param days number of days
    * @param patientHistoryList patient history list
    * @return returns true if patient was diagnosed before procedure within x number of days
    */
  def isProcedurePerformedBeforeOtherProcedureInXDays(visit: CassandraRow, m: MeasureProperty, firstProcedure: String, secondProcedure: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementPresentBeforeOtherElementWithinXDays(visit, m, firstProcedure, secondProcedure, days, patientHistoryList)
  }


  def wasInterventionPerformedAfterXMonthsOfProcedure(visit:CassandraRow,m:MeasureProperty,CurrentElement:String,histElement:String,noOfMonths:Int,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasProcedurePerformedXMonthsAfterDiagnosis(visit,m,CurrentElement,histElement,noOfMonths,patientHistoryList)
  }
  def isDiagnosed(visit: CassandraRow, m:MeasureProperty,  historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit, m,  historyElement, patientHistoryList)
  }

  def wasDiagnosedAfterXDaysProcedure(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)

  }
  def wasProcedurePerformedAfterXDaysProcedure(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)

  }


  def wasAssessmentPerformedBeforeXMonthsEncounter(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEncounterWithinXMonths(visit, m, histroyElement, month, patientHistoryList)
  }

  def wasAssessmentPerformedwithMethodBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,unit:String, interval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasProcedurePerformedwithResultBeforeEncounter(visit, m, elementName1, elementName2,unit ,interval, patientHistoryList)
  }

  def isPatientCharacteristicDuringEncounter(visit: CassandraRow, m:MeasureProperty, element:String ): Boolean ={
    dataTypeOnEncounter(visit: CassandraRow, m, element)
  }

  def wasProcedurePerformedBeforeEncounterWithinXYear(visit: CassandraRow, m: MeasureProperty, histroyElement: String, year: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean =  {
    wasElementBeforeEncounterWithinXYears(visit, m, histroyElement, year, patientHistoryList)
  }


  def isInterventionPerformedDuringIntervention(visit:CassandraRow,m:MeasureProperty,element1:String,element2:String):Boolean={

    checkNotNull(visit,element1,element2) && isDateEqual(visit,m,element1+"_date",element2+"_date")
  }

  def wasMedicationAdministeredInHistory(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementInHistory(visit, m,elementName, patientHistoryList)
  }
  def isProcedureOrdered(visit: CassandraRow, m:MeasureProperty,  historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit, m,  historyElement, patientHistoryList)
  }

  def isProcedurePerformedNotDone(visit: CassandraRow, m:MeasureProperty,  historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit, m,  historyElement, patientHistoryList)
  }
  def isMedicationOrderNotDone(visit: CassandraRow, m:MeasureProperty,  historyElement: String, patientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit, m,  historyElement, patientHistoryList)
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param firstProcedure element to be checked in history
    * @param secondProcedure element from current row
    * @param patientHistoryList patient history list
    * @return returns true if patient was procedure 1 before procedure 2
    */
  def wasProcedurePerformedBeforeOtherProcedure(visit: CassandraRow, m: MeasureProperty, firstProcedure: String, patientHistoryList: Broadcast[List[CassandraRow]], secondProcedure: String*):Boolean={
    wasElementPresentBeforeOrEqualOtherElement(visit, m,firstProcedure,CompareOperator.LESS_EQUAL, patientHistoryList,secondProcedure)
  }

  def wasProcedurePerformedwithResultAfter(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterEncounterwithResultElementEqual(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def isInterventionPerformedDuringProcedure(visit:CassandraRow,m:MeasureProperty,element1:String,element2:String):Boolean={
    checkNotNull(visit,element1,element2) && isDateEqual(visit,m,element1+"_date",element2+"_date")
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param diagnosticStudy element to be checked in history
    * @param procedure element from current row
    * @param patientHistoryList patient history list
    * @return returns true if patient was procedure 1 before procedure 2
    */
  def wasDiagnosticStudyPerformedBeforeProcedure(visit: CassandraRow, m: MeasureProperty, procedure: String, patientHistoryList: Broadcast[List[CassandraRow]],diagnosticStudy: String*):Boolean={
    wasElementPresentBeforeOrEqualOtherElement(visit, m, procedure,CompareOperator.LESS, patientHistoryList,diagnosticStudy)
  }

/*  /**
    *
    * @param visit current row
    * @param m measure property
    * @param diagnosticStudy element to be checked in history
    * @param procedure element from current row
    * @param patientHistoryList patient history list
    * @return returns true if patient was procedure 1 before procedure 2
    */
  def wasDiagnosticStudyPerformedBeforeProcedure(visit: CassandraRow, m: MeasureProperty,diagnosticStudy: String, procedure: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementPresentBeforeOtherElement(visit, m,diagnosticStudy, procedure, patientHistoryList)
  }*/


  def wasCommunicationFromProvidertoProviderAfterOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElement: String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementBeforeEnd(visit, m, elementName, historyElement,patientHistoryList)
  }

  def wasInterventionPerformedWithinXdaysAfterProcedure(visit: CassandraRow, m: MeasureProperty, historyElement: String, currentElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementWithinXDays(visit, m, historyElement, currentElementName, days, patientHistoryList)
  }
  def wasLaboratoryTestPerformedAfterDiagnosis(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentAfterElement(visit, m, elementName, historyElement, patientHistoryList)
  }

  def wasInterventionPerformedAfterOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, historyElement: String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterEncounterBeforeEnd(visit: CassandraRow, m, historyElement ,patientHistoryList)
  }
  def wasInterventionPerformedNotDoneAfterOrEqualEncounter(visit: CassandraRow, m: MeasureProperty,  historyElement: String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterEncounterBeforeEnd(visit: CassandraRow, m,  historyElement,patientHistoryList)
  }
  def wasLaboratoryTestPerformedWithValueAfterDiagnosis(visit: CassandraRow, m: MeasureProperty, historyElementName: String, currentElement: String, value: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementValueAfterElement(visit, m, historyElementName, currentElement, value, flag, patientHistoryList)
  }


  def wasDiagnosisPerformedInXdaysBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeElementDateWithinXDays(visit, m, elementDate,histroyElementName, days, patientHistoryList)
  }



  def wasDiagnosisPerformedInXdaysWithinEncounter(visit: CassandraRow, m: MeasureProperty, currentElement:String,historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    wasElementBeforeElementInXDays(visit, m, currentElement, historyElementName, days, patientHistoryList)
  }


  def wasPatientDischargedAfterXDaysProcedure(visit: CassandraRow, m: MeasureProperty, element: String, historyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    val elementDate= element+"_date"
    wasPatientCharacteristicExpiredAfterXDaysDiagnosis(visit, m, elementDate, historyElement, days, patientHistoryList)
  }


  def wasProcedurePerformedInXdaysWithinEncounter(visit: CassandraRow, m: MeasureProperty, currentElement:String,historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    wasElementBeforeElementInXDays(visit, m, currentElement, historyElementName, days, patientHistoryList)
  }

  def isProcedurePerformedDuringProcedureWithReason(visit:CassandraRow,m:MeasureProperty,element1:String,element2:String,element3:String):Boolean={
    checkNotNull(visit,element1,element2) && isDateEqual(visit,m,element1+"_date",element2+"_date") && isDateEqual(visit,m,element2+"_date",element3+"_date")
  }

  def isProcedurePerformedDuringProcedureWithMethod(visit:CassandraRow,m:MeasureProperty,element1:String,element2:String,element3:String):Boolean={
    checkNotNull(visit,element1,element2) && isDateEqual(visit,m,element1+"_date",element2+"_date") && isDateEqual(visit,m,element2+"_date",element3+"_date")
  }


  def wasProcedurePerformedAfterOrEqualProcedure(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: String*): Boolean = {
     wasElementPresentAfter(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName)
  }



  def wasProcedurePerformedWithMethod(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String,TimeOperator:String ,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    compareTwoElementDuringMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String,TimeOperator:String, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  /**
    * This function verifies if physical exam was performed before or after encounter with specified interval and value
    * @author Hemant
    * @param visit current patient visit
    * @param m measure property
    * @param element element name
    * @param operatorType  operator type (startsBefore,startsAfter)
    * @param unit unit in (MIN,HOUR,DAY,WEEK,MONTH,YEAR)
    * @param interval lower interval to be checked before/after provided as interger type
    * @param historyElement history element name
    * @param result result value
    * @param resultFlag result flag name (le,ge,lt,gt,eq)
    * @param patientHistoryList patient history list
    * @return returns true  if  physical exam was performed before or after encounter with specified interval and value else returns false
    */
  def wasPhysicalPerformedWithInXPeriodOnEncounter(visit:CassandraRow,m:MeasureProperty,element:String,operatorType:String,unit:String,interval:Int,historyElement:String,result:Double,resultFlag:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasPhysicalPerformedWithInPeriodWithValue(visit,m,element,operatorType,unit, interval,historyElement,result,resultFlag ,patientHistoryList)
  }



  /**
    *
    * @param visit current row
    * @param m measure property
    * @param historyElement element to be checked in X hours from encounterDate
    * @param hours number of hours
    * @param patientHistoryList patient history list
    * @return returns true if Future element has happened in x hours from encounterDate
    */
  def isInterventionPerformedAfterEncounterWithinXHours(visit: CassandraRow, m: MeasureProperty, historyElement: String, hours: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterEncounterWithinXHours(visit, m, historyElement, hours, patientHistoryList)
  }


  def isPatientCharacteristicBeforeProcedure(visit: CassandraRow, m: MeasureProperty,procedure: String, patientHistoryList: Broadcast[List[CassandraRow]], patientCharacteristic: String*):Boolean={

    wasElementPresentBeforeOrEqualOtherElement(visit, m,procedure,CompareOperator.LESS_EQUAL,   patientHistoryList,patientCharacteristic)
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param intervention intervention
    * @param diagnosis diagnosis
    * @param patientHistoryList patient history list
    * @return returns true if intervention was ordered after diagnosis
    */
  def isInterventionOrderedAfterDiagnosis(visit: CassandraRow, m: MeasureProperty,intervention: String, diagnosis: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementPresentAfterOtherElement(visit, m,intervention, diagnosis, patientHistoryList)
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param communication communication
    * @param diagnosis diagnosis
    * @param patientHistoryList patient history list
    * @return returns true if communication was ordered after diagnosis
    */
  def isCommunicationFromPatientToProviderDoneAfterDiagnosis(visit: CassandraRow, m: MeasureProperty,communication: String, diagnosis: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementPresentAfterOtherElement(visit, m,communication, diagnosis, patientHistoryList)
  }

  def isDiagnosticStudyPerformedAfterXDiagnosticStudy(visit: CassandraRow, m: MeasureProperty,diagnosticStudy: String,  patientHistoryList: Broadcast[List[CassandraRow]],XdiagnosticStudyElements: String*):Boolean={
    XdiagnosticStudyElements.exists(x => wasElementPresentAfterOtherElement(visit, m, x,diagnosticStudy, patientHistoryList))
  }


  def isDiagnosticStudyPerformedDuringXDiagnosticStudy(visit:CassandraRow,m:MeasureProperty,element1:String,element2:String*): Boolean ={
    element2.exists(x => checkNotNull(visit,element1,x) && isDateEqual(visit,m,element1+"_date",x+"_date"))
  }


  /**
    * This function verifies if intervention was done before death and after encounter performed
    * @param visit current patient visit
    * @param m measure property
    * @param encounterDate encounter date
    * @param beforeElement before element name(death element)
    * @param interventionElement intervention element name
    * @param patientHistoryList patient history list (before element and intervention element must exits in history)
    * @return returns true if  intervention ws done before death and after encounter performed else returns false
    */
  def wasInterventionPerformedDoneInBetweenEvents(visit:CassandraRow,m:MeasureProperty,encounterDate:String,beforeElement:String,interventionElement:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasInterventionPerformedInBetween(visit,m,encounterDate,beforeElement,interventionElement,patientHistoryList)
  }


  /**
    * This function verifies if intervention was not done before death and after encounter performed
    * @param visit current patient visit
    * @param m measure property
    * @param encounterDate encounter date
    * @param beforeElement before element name(death element)
    * @param interventionElement intervention element name
    * @param patientHistoryList patient history list (before element and intervention element must exits in history)
    * @return returns true if  intervention was not done before death and after encounter performed else returns false
    */
  def wasInterventionPerformedNotDoneInBetweenEvents(visit:CassandraRow,m:MeasureProperty,encounterDate:String,beforeElement:String,interventionElement:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasInterventionPerformedInBetween(visit,m,encounterDate,beforeElement,interventionElement,patientHistoryList)
  }

  def isDiagnosticStudyRecommendedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }

  def isDiagnosedDuringDiagnosticStudy(visit:CassandraRow,m:MeasureProperty,element1:String,element2:String*): Boolean ={
    element2.exists(x => checkNotNull(visit,element1,x) && isDateEqual(visit,m,element1+"_date",x+"_date"))
  }

  /**
    * This function verifies if device applied during measurement period
    * @param visit current patient visit
    * @param m measure property
    * @param deviceElementName device element name
    * @param patientHistoryList patient history list
    * @return returns true if device applied during measurement period else return false
    */
  def isDeviceApplied(visit: CassandraRow, m: MeasureProperty, deviceElementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    checkElementDuringMeasurementPeriod(visit,m,deviceElementName,patientHistoryList)
  }


  def wasAssessmentAfterXWeeksofProcedureWithinXMonths(visit: CassandraRow, m: MeasureProperty, procedureElement: String,resultElement: String,assessmentElement: String, month:Int,week:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentWithReasonAfterWeeksBeforeStartwithinXMonths(visit, m , procedureElement,resultElement,assessmentElement, month,week,patientHistoryList)
  }

  def wasAssessmentWithinXWeeksofProcedureWithinXMonths(visit: CassandraRow, m: MeasureProperty, procedureElement: String,resultElement: String,assessmentElement: String, month:Int,week:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentWithReasonWithinWeeksBeforeStartwithinXMonths(visit, m , procedureElement,resultElement,assessmentElement, month,week,patientHistoryList)
  }

  /**
    * This function verifies if one diagnosis is performed during Procedure Performed
    *
    * @param visit         current patient visit
    * @param m             measure property
    * @param element1      diagnosis element1 to be checked
    * @param element1_date diagnosis element1 to be checked
    * @param element2      diagnosis element2 to be compare with element1
    * @param element2_date diagnosis element2 date to be compare with element1
    * @return returns true if one diagnosis is performed during Procedure Performed else returns false
    */
  def isDiagnosisPerformedDuringProcedurePerformed(visit:CassandraRow,m:MeasureProperty,element1:String,element1_date:String,element2:String,element2_date:String):Boolean={
    checkNotNull(visit,element1,element1_date,element2,element2_date) && isDateEqual(visit,m,element1_date,element2_date)

  }

  /**
    * This function verifies if procedure is performed after procedure in X hours
    *
    * @param visit                 current patient visit
    * @param m                     measure property
    * @param procedureElement      element 1
    * @param afterProcedureElement element 2
    * @param NoOfHours             no of hours
    * @param patientHistoryList    patient history list
    * @return if Procedure Performed After Procedure In X Hours
    */

  def wasProcedurePerformedAfterProcedureInXHours(visit:CassandraRow,m:MeasureProperty,procedureElement:String,afterProcedureElement:String,NoOfHours:Int,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementInXHours(visit,m,procedureElement,afterProcedureElement,NoOfHours:Int,patientHistoryList)
  }


  /**
    * This function verifies diagnosis is after procedure is performed in history.
    * @param visit current visit of the patient.
    * @param m Measure property
    * @param HistoryElement1 first history element
    * @param patientHistoryList patient history list
    * @param HistoryElement2 second history element
    * @return it will return true if diagnosis is after procedure performed in history.
    */
  def wasDiagnosisAfterProcedurePerformedInHistory(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean= {
    wasElementPresentAfterOtherElementInHistory(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2.toSeq )

  }

  /**
    * This function verifes if diagnostic study is performed before or equal encounter date with result
    * @param visit current visit of the patient.
    * @param m Measure property
    * @param histElement history element
    * @param value value
    * @param flag flag
    * @param patientHistoryList patient history list
    * @return it will return true if diagnostic study with result is performed before or equal to encounter date.
    */
  def wasDiagnosticStudyPerformedBeforeOrEqualEncounterWithResult(visit: CassandraRow, m: MeasureProperty, histElement: String,value:Double,flag:String,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeOrEqualEncounterWithValue(visit, m, histElement,value,flag,patientHistoryList)
  }

  /**
    * This function verifes the diagnosed is during most recent encounter
    * @param visit current visit of the patient
    * @param m measure property
    * @param DiagnosedElement diagnosed Element from history
    * @param patientHistoryList patient history list
    * @param MostRecentpatientHistoryList Most recent patient history list.
    * @return
    */
  def wasDiagnosedDuringMostRecentEncounter(visit: CassandraRow, m: MeasureProperty, DiagnosedElement: String, patientHistoryList: Broadcast[List[CassandraRow]],MostRecentpatientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementDuringMostRecentEncounter(visit, m, DiagnosedElement, patientHistoryList,MostRecentpatientHistoryList)
  }

  /**
    * This function verifes the Intervention is during most recent encounter
    *
    * @param visit                        current visit of the patient
    * @param m                            measure property
    * @param InterventionElement          Intervention Element from history
    * @param patientHistoryList           patient history list
    * @param MostRecentpatientHistoryList Most recent patient history list.
    * @return
    */
  def wasInterventionPerformedDuringMostRecentEncounter(visit: CassandraRow, m: MeasureProperty, InterventionElement: String, patientHistoryList: Broadcast[List[CassandraRow]],MostRecentpatientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementDuringMostRecentEncounter(visit, m, InterventionElement, patientHistoryList,MostRecentpatientHistoryList)
  }

  /**
    * This function verifes the Patient Characteristic is during most recent encounter
    *
    * @param visit                        current visit of the patient
    * @param m                            measure property
    * @param PatientCharacteristicElement Intervention Element from history
    * @param patientHistoryList           patient history list
    * @param MostRecentpatientHistoryList Most recent patient history list.
    * @return
    */

  def wasPatientCharacteristicDuringMostrecentEncounter(visit: CassandraRow, m: MeasureProperty, PatientCharacteristicElement: String, patientHistoryList: Broadcast[List[CassandraRow]],MostRecentpatientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementDuringMostRecentEncounter(visit, m, PatientCharacteristicElement, patientHistoryList,MostRecentpatientHistoryList)
  }

  def isInterventionPerformedAfterDiagnosticStudy(visit: CassandraRow, m: MeasureProperty,intervention: String, diagnosticStudy: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementPresentAfterOtherElement(visit, m,intervention, diagnosticStudy, patientHistoryList)
  }

  def isDiagnosticStudyPerformedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, element: String): Boolean = {
    dataTypeOnEncounter(r: CassandraRow, measureProperty, element)
  }

/*
  def wasDiagnosedBeforeDiagnosticStudy(visit: CassandraRow, m: MeasureProperty, diagnosticStudy: String, patientHistoryList: Broadcast[List[CassandraRow]],diagnosis: String*):Boolean={
    wasElementPresentBeforeOrEqualOtherElement(visit, m, diagnosticStudy, patientHistoryList,diagnosis)
  }*/

  def wasAssessmentAfterOrConcurrentMedication(visit: CassandraRow, m: MeasureProperty,Element:String,patientHistoryList: Broadcast[List[CassandraRow]],AnotherElements:String*):Boolean={
    AnotherElements.exists(AnotherElement => wasElementAfterOrConcurrentAnotherElement(visit, m,Element,AnotherElement,patientHistoryList))
  }

  def wasDiagnosedBeforeDiagnosticStudy(visit: CassandraRow, m: MeasureProperty, diagnosticStudy: String, patientHistoryList: Broadcast[List[CassandraRow]],diagnosisElements: String*):Boolean={
     wasElementPresentBeforeOrEqualOtherElement(visit, m, diagnosticStudy,CompareOperator.LESS_EQUAL, patientHistoryList,diagnosisElements)
  }


  def wasProcedurePerformedAfterOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    wasElementAfterEncounterBeforeEnd(visit, m, historyElement, patientHistoryList)
  }

  def wasDiagnosticStudyPerformedAfterOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    wasElementAfterEncounterBeforeEnd(visit, m, historyElement, patientHistoryList)
  }


  def wasCommunicationFromProviderToProviderwithSourceAfter(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterEncounterwithResultElementEqual(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasProcedureAfterEncounterWithInXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String,historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterOrEqualInMonths(visit, m, elementDate, historyElement, month, patientHistoryList)
  }

  def isProcedurePerformedWithStopDateDuringEncounter(visit: CassandraRow, measureProperty: MeasureProperty, element: String,elementDate: String): Boolean = {
    checkElementPresent(visit, measureProperty, element) && isDateEqual(visit, measureProperty, elementDate, "encounterdate")
  }


  def wasCommunicationFromProviderToProviderwithSourceBefore(visit: CassandraRow, m: MeasureProperty, ProcedureElement: String,CommunicationElement: String,SourceElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeOtherElementInHistory(visit,m,ProcedureElement,CommunicationElement,SourceElement, patientHistoryList)
  }


  def wasCommunicationFromProviderToProviderwithSourceAfterEncounter(visit: CassandraRow, m: MeasureProperty, currentElement: String,HistoryElement1: String,HistoryElement2: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentWithReasonAfterEncounter(visit,m,currentElement,HistoryElement1,HistoryElement2,patientHistoryList)
  }

  def wasAssessmentPerformedInXMonthsBeforeProcedureWithResult(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String, ResultValueElement: String, monthsforElementName2: Int, monthsTo: Int, monthsFrom: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasProcedurePerformedBeforeStartWithInResultBetweenXMonths(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String, ResultValueElement: String, monthsforElementName2: Int, monthsTo: Int, monthsFrom: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasAssessmentPerformedInXMonthsAfterProcedureWithResult(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,ResultValueElement: String,calenderUnitforElement2: String,intervalForElement2: Int,calenderUnitFormonthsFrom: String,intervalForMonthFrom: Int ,calenderUnitFormonthsTo: String,intervalForMonthTo: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     wasProcedurePerformedAfterStartWithInResultBetweenXMonths(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,ResultValueElement: String,calenderUnitforElement2: String,intervalForElement2: Int,calenderUnitFormonthsFrom: String,intervalForMonthFrom: Int ,calenderUnitFormonthsTo: String,intervalForMonthTo: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasAssessmentPerformedInXWeeksAfterProcedureWithResult(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,ResultValueElement: String,calenderUnitforElement2: String,intervalForElement2: Int,calenderUnitFormonthsFrom: String,intervalForMonthFrom: Int ,calenderUnitFormonthsTo: String,intervalForMonthTo: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasProcedurePerformedAfterStartWithInResultBetweenXMonths(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,ResultValueElement: String,calenderUnitforElement2: String,intervalForElement2: Int,calenderUnitFormonthsFrom: String,intervalForMonthFrom: Int ,calenderUnitFormonthsTo: String,intervalForMonthTo: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasAssessmentPerformedInXMonthsBeforeProcedure(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String, monthsforElementName2: Int, monthsTo: Int, monthsFrom: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasProcedurePerformedBeforeStartBetweenXMonths(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String, monthsforElementName2: Int, monthsTo: Int, monthsFrom: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasAssessmentPerformedInXMonthsAfterProcedure(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,calenderUnitforElement2: String,intervalForElement2: Int,calenderUnitFormonthsFrom: String,intervalForMonthFrom: Int ,calenderUnitFormonthsTo: String,intervalForMonthTo: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasProcedurePerformedAfterStartBetweenXMonths(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,calenderUnitforElement2: String,intervalForElement2: Int,calenderUnitFormonthsFrom: String,intervalForMonthFrom: Int ,calenderUnitFormonthsTo: String,intervalForMonthTo: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasAssessmentPerformedInXWeeksAfterProcedure(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,calenderUnitforElement2: String,intervalForElement2: Int,calenderUnitFormonthsFrom: String,intervalForMonthFrom: Int ,calenderUnitFormonthsTo: String,intervalForMonthTo: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasProcedurePerformedAfterStartBetweenXMonths(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,calenderUnitforElement2: String,intervalForElement2: Int,calenderUnitFormonthsFrom: String,intervalForMonthFrom: Int ,calenderUnitFormonthsTo: String,intervalForMonthTo: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }


  /**
    * This function verifies if procedure performed after diagnosis with in X weeks in history
    * @param visit current visit of the patient
    * @param m measure property of the measure
    * @param HistoryElement1  procedure element in history
    * @param noOfWeeks number of weeks
    * @param patientHistoryList  patient history list
    * @param HistoryElement2 diagnosis element
    * @return it will return true if procedure if performed after diagnosis withIn X weeks in history.
    */
  def wasProcedurePerfiormedAfterDiagnosisWithinXWeeksInHistory(visit: CassandraRow, m: MeasureProperty, HistoryElement1: String, noOfWeeks: Int, patientHistoryList: Broadcast[List[CassandraRow]], HistoryElement2: String*): Boolean = {
    wasElementPresentAfterOtherElementWithinXWeeksInHistory(visit: CassandraRow, m: MeasureProperty, HistoryElement1: String, noOfWeeks: Int, patientHistoryList: Broadcast[List[CassandraRow]], HistoryElement2: Seq[String])
  }

  /**
    * This function verifies if procedure is performed before X days from end
    * @param visit                        current visit of the patient
    * @param m                            measure property
    * @param historyElementName history element name
    * @param days number of days that has to be subtracted from end of the measurement period
    * @param patientHistoryList patient history list.
    * @return
    */
  def wasProcedurePerformedBeforeEndInXDays(visit: CassandraRow, m: MeasureProperty, historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEndInXDays(visit, m, historyElementName, days, patientHistoryList)
  }

  /**
    * This function verifies if procedure was performed during procedure in history
    * @param visit                        current visit of the patient
    * @param m                            measure property
    * @param procedureElement1            first procedure element
    * @param patientHistoryList           patient history list.
    * @param procedureElement2            second procedure element
    * @return
    */
  def wasProcedurePerformedDuringProcedureInHistory(visit: CassandraRow, m: MeasureProperty, procedureElement1: String, patientHistoryList: Broadcast[List[CassandraRow]], procedureElement2: String*): Boolean = {
    wasElementPresentDuringOtherElementInHistory(visit, m, procedureElement1, patientHistoryList, procedureElement2)
  }

  /**
    * This function verifies procedure was performed after X hours of another procedure in history
    *
    * @param visit              current visit of the patient
    * @param m                  measure property
    * @param procedureElement1  first procedure element
    * @param no_of_hours        number of hours
    * @param patientHistoryList patient history list.
    * @param procedureElement2  second procedure element
    * @return
    */
  def wasProcedurePerformedAfterProcedureWithinXHours(visit: CassandraRow, m: MeasureProperty, procedureElement1: String, no_of_hours: Int, patientHistoryList: Broadcast[List[CassandraRow]], procedureElement2: String*): Boolean = {
    wasElementAfterElementListWithinXHours(visit, m, procedureElement1, no_of_hours, patientHistoryList, procedureElement2)
  }

  /**
    * This function verifies if medication was performed during diagnosis in history.
    * @param visit current visit of the patient
    * @param m              masure property of the measure
    * @param medicationElement medication element
    * @param patientHistoryList patient history list
    * @param diagnoisElement diagnosis element
    * @return
    */
  def wasMedicationDuringDiagnosisInHistory(visit: CassandraRow, m: MeasureProperty, medicationElement: String, patientHistoryList: Broadcast[List[CassandraRow]], diagnoisElement: String*): Boolean = {
    wasElementPresentDuringOtherElementInHistory(visit, m, medicationElement, patientHistoryList, diagnoisElement)
  }

  /**
    * This function verifies if interventionElement with result performed during diagnosis
    * @param visit current patient visit
    * @param m measure property
    * @param interventionElement intervention element to be checked
    * @param diagnosisElement diagnosis element to be checked
    * @param operatorType operator type (valid are DURING,AFTER,BEFORE )
    * @param result result of element 1 in double
    * @param resultFlag result flag (valida are ge,gt,lt,le,ge)
    * @param patientHistoryList patient history list
    * @return returns true if  interventionElement with result performed during diagnosis else returns false
    */
  def wasInterventionPerformedWithResultXDuringDiagnosis(visit:CassandraRow,m:MeasureProperty,interventionElement:String,diagnosisElement:String,operatorType:String,result:Double,resultFlag:String,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    wasElement1WithResultPerformedOperatorTypeElement2InHistory(visit,m,interventionElement,diagnosisElement,operatorType,result,resultFlag,patientHistoryList)
  }

  /**
    * This function verifies if medication was ordered before end in X days
    * @param visit current patient visit
    * @param m measure property
    * @param medicationElement medication element name
    * @param interval no of interval to be checked before
    * @param unit unit to checked(valid are YEAR,MONTH,WEEK,DAY,HOUR,MIN)
    * @param patientHistoryList patient history list
    * @return returns true if medication was ordered before end in X days else returns false
    */
  def wasMedicationOrderedBeforeEndInXDays(visit: CassandraRow, m: MeasureProperty, medicationElement: String, interval: Int,unit:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
  isEventStartsBeforeOperatorMeasurementPeriodWithinXPeriod(visit,m,medicationElement,interval,unit,patientHistoryList,"EndOfMeasurementPeriod")
     }

  def wasAssessmentPerformedAfterProcedure(visit: CassandraRow, m: MeasureProperty, CurrentElementDate: String, patientHistoryList: Broadcast[List[CassandraRow]], HistoryelementName: String*): Boolean = {
     wasElementPresentAfter(visit, m, CurrentElementDate, patientHistoryList, HistoryelementName)
  }


  def wasAssessmentPerformedAfterProcedureWithResultInBetweenXMonths(visit: CassandraRow, m: MeasureProperty, element1: String,ResultElement: String, historyElement: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementWithResultInBetweenXPeriodes(visit: CassandraRow, m: MeasureProperty, element1: String,ResultElement: String, historyElement: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }


  def wasAssessmentPerformedBeforeProcedureWithResultInXMonth(visit: CassandraRow, m: MeasureProperty, element1: String,ResultElement: String, historyElement: String,CalenderUnit:String, interval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     wasElementBeforeElementInXPeriodWithResult(visit: CassandraRow, m: MeasureProperty, element1: String,ResultElement: String, historyElement: String,CalenderUnit:String, interval: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasAssessmentPerformedBeforeProcedureWithResultInXWeek(visit: CassandraRow, m: MeasureProperty, element1: String,ResultElement: String, historyElement: String,CalenderUnit:String, interval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeElementInXPeriodWithResult(visit: CassandraRow, m: MeasureProperty, element1: String,ResultElement: String, historyElement: String,CalenderUnit:String, interval: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasAssessmentPerformedAfterProcedureWithResultInBetweenXWeek(visit: CassandraRow, m: MeasureProperty, element1: String,ResultElement: String, historyElement: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementWithResultInBetweenXPeriodes(visit: CassandraRow, m: MeasureProperty, element1: String,ResultElement: String, historyElement: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }


  /**
    * Thi function verifies if medication was active before encounter or not
    * @param visit current patient visit
    * @param m measure property
    * @param encounterDate encounter date
    * @param patientHistoryList patient history list
    * @param medicationElements  medication element names
    * @return returns true if if medication was active before encounter else returns false
    */
  def wasMedicationActiveBeforeEncounter(visit: CassandraRow, m: MeasureProperty, encounterDate: String, patientHistoryList: Broadcast[List[CassandraRow]], medicationElements: String*): Boolean ={
  wasElementPresentBeforeOrEqualOtherElement(visit,m,encounterDate,CompareOperator.LESS_EQUAL,patientHistoryList,medicationElements)
  }

  /**
    * This function verifies if intervention starts after start of diagnosis within X period
    * @param visit current patient visit
    * @param m measure property
    * @param diagnosisElement diagnosis element date
    * @param interventionElement intervention element name
    * @param months no of interval to be checked after
    * @param patientHistoryList patient history list
    * @return returns true if intervention starts after start of diagnosis within X period  else returns false
    */
  def wasInterventionStartsAfterStartOfDiagnosisWithinXPeriod(visit: CassandraRow, m: MeasureProperty, diagnosisElement: String, interventionElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    //wasElementAfterElementDateWithinXPeriod(visit,m,diagnosisElementDate,interventionElement,unit,interval,patientHistoryList)

    wasElementAfterElementDateWithinXPeriod(visit, m, diagnosisElement, interventionElement, CalenderUnit.MONTH, months, CompareOperator.LESS_EQUAL, patientHistoryList)
  }

  /**
    * This function verifies if intervention starts after starts of diagnosis within X period with result
    * @param visit current patient visit
    * @param m measure property
    * @param interventionElement intervention element name to be checked in history
    * @param diagnosisElement diagnosis element name to be checked in current
    * @param result result of intervention element
    * @param resultFlag result flag used to compare result (valid are gt,lt,ge,le,eq)
    * @param calenderUnit used to check after diagnosis element (valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTES)
    * @param calenderInterval no of interval of calenderUnit to be checked
    * @param timeCOperator time operator is used to comapre between two elements
    * @param patientHistoryList patient history list
    * @return returns true if if intervention starts after starts of diagnosis within X period with result else returns false
    */
  def wasInterventionStartsAfterStartOfDiagnosisWithinXPeriodWithResult(visit: CassandraRow, m: MeasureProperty, diagnosisElement: String, interventionElement: String, calenderUnit:String,calenderInterval:Int, result: Double, resultFlag: String,timeCOperator:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElement1WithResultPerformedOperatorTypeElement2InHistoryInXPeriod(visit,m,diagnosisElement,interventionElement,calenderUnit,calenderInterval,result,resultFlag,timeCOperator,patientHistoryList)
  }

  def wasDiagnosisPerformedAfterProcedure(visit: CassandraRow, m: MeasureProperty, HistoryElement1: String, patientHistoryList: Broadcast[List[CassandraRow]], HistoryElement2: String*): Boolean = {
    wasElementPresentAfterOtherElementInHistory(visit: CassandraRow, m: MeasureProperty, HistoryElement1: String, patientHistoryList: Broadcast[List[CassandraRow]], HistoryElement2.toSeq)
  }


  def wasInterventionPerformedfterProcedurePerformedInHistory(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2:String* ):Boolean= {
    wasElementPresentAfterOtherElementInHistory(visit:CassandraRow, m:MeasureProperty, HistoryElement1:String,patientHistoryList:Broadcast[List[CassandraRow]],HistoryElement2.toSeq )

  }

  def isDifferenceInPhysicalExamPerformedInRangeMonths(visit: CassandraRow, m: MeasureProperty, currentElementName:String,histroyElement1: String,histroyElement2: String, valueDifference:Double,lowerMonth: Int,higherMonth: Int, value: Double, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checktwoElementdifferenceInRangeMonths(visit , m, currentElementName,histroyElement1 ,histroyElement2, valueDifference,lowerMonth,higherMonth, patientHistoryList)

  }


  def isDifferenceInPhysicalExamInRangeMonths(visit: CassandraRow, m: MeasureProperty, currentElementName:String,histroyElement: String, valueDifference:Double,lowerMonth: Int,higherMonth: Int, value: Double,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checktwoElementValueDiffInRangeMonths(visit , m , currentElementName ,histroyElement , valueDifference ,lowerMonth ,higherMonth , value , patientHistoryList)

  }

  def isDifferenceInPhysicalExam(visit:CassandraRow,m:MeasureProperty,element1:String,element2:String,resultDiff:Double): Boolean ={
    (checkNotNull(visit,element1,element1+"_date",element2,element2+"_date") && isDateEqual(visit,m,element1+"_date",element2+"_date")
      &&  math.abs(visit.getDouble(element1)- visit.getDouble(element1)) > resultDiff )

  }

  def isAssessmentPerformedWithResult(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String, dataType:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    compareTwoElementDuringMeasurementPeriod(visit, m, historyElement1, historyElement2,dataType:String, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def isAssessmentPerformedWithResultDuringEncounter(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String): Boolean = {

    isDateEqual(visit,m,historyElement1+"_date",historyElement2+"_date") && visit.getDate("encounterdate").equals(visit.getDate(historyElement1+"_date"))
  }

def isInterventionPerformedAfterAssessmentWithInXDays(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

  wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.MONTH, days, CompareOperator.LESS_EQUAL, patientHistoryList)
}

  def isCommunicationFromProviderToPatientOnEncounterNotDone(visit: CassandraRow, measureProperty: MeasureProperty, currentElementName: String): Boolean = {
    dataTypeOnEncounter(visit, measureProperty, currentElementName)
  }

  /**
    * This function verifies whether communication from patient to provider is during most recent encounter or not.
    * @param visit    current visit of the patient
    * @param m         measure property of the element
    * @param communicationElement communication element from patient to provider
    * @param patientHistoryList  paient history list
    * @param MostRecentEncounterpatientList most recent encounter patient list
    * @return it will return true if communication from patient to provider is during most recent encounter
    */
  def wasCommunicationDuringMostRecentEncounter(visit: CassandraRow, m: MeasureProperty, communicationElement:String, patientHistoryList: Broadcast[List[CassandraRow]],MostRecentEncounterpatientList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementDuringMostRecentEncounter(visit, m, communicationElement, patientHistoryList,MostRecentEncounterpatientList)
  }


  /**
    * This function verifies if procedure is performed before X days from end of measurement period
    * @param visit              current visit of the patient
    * @param m                  measure property
    * @param procedureElement   procedure element that has to be verified in history
    * @param days               number of days that has to be stubtracted from end date
    * @param patientHistoryList patient history list
    * @return it will return true if procedure is performed before x days from end of measurement period.
    */
  def wasProcedurePerformedBeforeOrEqualXDaysFromEnd(visit: CassandraRow, m: MeasureProperty, procedureElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeEndInXDays(visit, m, procedureElement, days, patientHistoryList)

  }


  /**
    * This function verifies whether assessment is performed after or equal X days of procedure.
    * @param visit              current visit of the patient
    * @param m                  measure property
    * @param assessmentElement  assessment element that has to be verifies in history
    * @param procedureElement   procedure element
    * @param NoOfDays           number of days that has to be added in procedure element
    * @param patientHistoryList patient history list
    * @return it will return  true if assessment is performed after X days of procedure else false.
    */
  def wasAssessmentPerformedAfterXDaysProcedure(visit: CassandraRow, m: MeasureProperty, assessmentElement: String, procedureElement: String, NoOfDays: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    wasElementAfterElementInXDays(visit, m, assessmentElement, procedureElement, NoOfDays, patientHistoryList)

  }

  /**
    * This function verifies if procedure is performed after or concurrent with diagnosis
    * @param visit              current visit of the patient
    * @param m                  measure property
    * @param procedureElement   procedure element that has to be verifies in history
    * @param patientHistoryList patient history list
    * @param diagnosisElement diagosis element that has to be compared with procedure element
    * @return it will return true if procedure was performed after diagnosis else false.
    */
  def wasProcedurePerformedAfterOrConcurrentDiagnosis(visit: CassandraRow, m: MeasureProperty, procedureElement: String, diagnosisElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterOrConcurrentAnotherElement(visit, m, procedureElement, diagnosisElement, patientHistoryList: Broadcast[List[CassandraRow]])
  }





  /**
    * This function verifies if Diagnosis is performed before X days from end of measurement period
    * @param visit              current visit of the patient
    * @param m                  measure property
    * @param diagnosisElement   Diagnosis element that has to be verified in history
    * @param days               number of days that has to be stubtracted from end date
    * @param patientHistoryList patient history list
    * @return it will return true if procedure is performed before x days from end of measurement period.
    */
  def wasDiagnosisBeforeOrEqualXDaysFromEnd(visit: CassandraRow, m: MeasureProperty, diagnosisElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeOrEqualXDaysFromEnd(visit, m: MeasureProperty,diagnosisElement,days,patientHistoryList)
  }


  /**
    * This function verifies whether diagnosis overlaps diagnosis in history
    * @param visit current visit of the patient
    * @param m      measure property
    * @param diagnosisElement1 first diagnosis element
    * @param diagnosisElement2 second diagnosis element
    * @param patientHistoryList patient history list
    * @return it will return true if diagnosis overlaps diagnosis in history else false
    */
  def wasDiagnosisOverlapsDiagnosisInHistory(visit: CassandraRow, m: MeasureProperty,diagnosisElement1:String,diagnosisElement2:String,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementOverlapsElement(visit, m,diagnosisElement1,diagnosisElement2,patientHistoryList)
  }

  /**
    * This function verifies laboratory test overlaps Diagnosis with result both laboratory and diagnosis are in history
    * @param visit current visit of the patient
    * @param m measure property
    * @param laboratoryElement history laboratory test element
    * @param diagnosisElement  history diagnosis element
    * @param value value of the test
    * @param flag compare flag (valid flags [lt,gt,le,ge,eq])
    * @param patientHistoryList patient history list
    * @return it will return true laboratory test overlaps diagnosis with result else false
    */
  def wasLaboratoryTestOverlapsDiagnosisWithResult(visit: CassandraRow, m: MeasureProperty,laboratoryElement:String,diagnosisElement:String,value:Double,flag:String,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementOverlapsElementWithResultValue(visit, m,laboratoryElement,diagnosisElement,value,flag,patientHistoryList)
  }

  /**
    * This function verifies if the element ends after start of measurement period
    * @param visit current patient visit
    * @param m measure property
    * @param assessmentElementName element to be checked
    * @param calenderUnit calender unit of interval(valida units are YEAR,MONTH,WEEK,DAY,HOUR,MIN)
    * @param interval no of interval to be checked
    * @param patientHistoryList patient history list
    * @return returns true if the element ends after start of measurement period else returns false
    */
  def wasAssessmentPerformedEndsAfterStartOfWithinXPeriod(visit:CassandraRow,m:MeasureProperty,assessmentElementName:String,calenderUnit:String,interval:Int,operatorType:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementEndsOfInXPeriod(visit,m,assessmentElementName,calenderUnit,interval,"endsAfter",patientHistoryList)
  }

  /**
    * This function verifies if the element ends before end of measurement period
    * @param visit current patient visit
    * @param m measure property
    * @param assessmentElementName element to be checked
    * @param calenderUnit calender unit of interval(valida units are YEAR,MONTH,WEEK,DAY,HOUR,MIN)
    * @param interval no of interval to be checked
    * @param patientHistoryList patient history list
    * @return returns true if the element ends before end of measurement period else returns false
    */
  def wasAssessmentPerformedEndsBeforeEndOfWithinXPeriod(visit:CassandraRow,m:MeasureProperty,assessmentElementName:String,calenderUnit:String,interval:Int,operatorType:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementEndsOfInXPeriod(visit,m,assessmentElementName,calenderUnit,interval,"endsBefore",patientHistoryList)
  }

  def wasAssessmentPerformedInXDaysAfterProcedureWithResult(visit: CassandraRow, m: MeasureProperty, assessmentElement: String,procedureElement: String ,resultValue: Double, compareFlag: String,days:Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementAfterElementXDaysWithResult(visit, m, assessmentElement,procedureElement ,resultValue, compareFlag,days, patientHistoryList)
  }

  def wasProcedurePerformedBeforeStartBetweenMonths(visit: CassandraRow, m: MeasureProperty, element1: String, CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     wasElementAfterElementBetweenXPeriod(visit, m, element1, CalenderUnitTo, intervalTo,CalenderUnitFrom, intervalFrom,patientHistoryList)
  }





  /**
    * This function verifies whether diagnostic performed during most recent encounter.
    * @param visit current visit of the patient.
    * @param m measure property
    * @param diagnosticElement diagnostic element
    * @param patientHistoryList patient history list
    * @param mostRecentEncounterpatientList most recent encounter ptient history list
    * @return it will return true if diagnostic study is performed during most recent encounter performed else false
    */
  def  wasDiagnosticStudyPerformedDuringMostRecentEncounter(visit: CassandraRow, m: MeasureProperty, diagnosticElement:String, patientHistoryList: Broadcast[List[CassandraRow]],mostRecentEncounterpatientList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementDuringMostRecentEncounter(visit, m, diagnosticElement, patientHistoryList,mostRecentEncounterpatientList)
  }

  /**
    * This function verifies if the element starts after end within X period
    * @param visit current patient visit
    * @param m measure property
    * @param labTestElementDate lab test element date
    * @param medicationElementName medication element
    * @param timeCOperator time compare operator (valid operators are ge,le,gt,lt,eq)
    * @param calenderUnit calender unit (valid are YEAR,MONTH,WEEK,DAY,HOUR,MINUTES)
    * @param calenderInterval calender interval in integer
    * @param patientHistoryList patient history list
    * @return returns true if the element starts after end within X period else returns false
    */
  def medicationOrderStartsAfterEndOfLabTest(visit:CassandraRow,m:MeasureProperty,labTestElementDate:String,medicationElementName:String,timeCOperator:String,calenderUnit:String,calenderInterval:Int=0,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    wasElementStartsAfterEndWithinXPeriod(visit,m,labTestElementDate,medicationElementName,timeCOperator,calenderUnit,calenderInterval,patientHistoryList)
  }

  def wasAssessmentPerformedAfterProcedureInBetweenXWeek(visit: CassandraRow, m: MeasureProperty, element1: String, historyElement: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     wasElementAfterElementInBetweenXPeriodes(visit: CassandraRow, m: MeasureProperty, element1: String, historyElement: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }

  /**
    * This function verifies if the element starts after end within X period with result
    * @param visit current patient visit
    * @param m measure property
    * @param labTestElement lab test element
    * @param timeCOperator time compare operator (valid operators are ge,le,gt,lt,eq)
    * @param calenderUnit calender unit (valid are YEAR,MONTH,WEEK,DAY,HOUR,MINUTES)
    * @param calenderInterval calender interval in integer
    * @param result result to be checked
    * @param resultCompareFlag result compare flag is used to compare result(le,ge,lt,gt,eq)
    * @param patientHistoryList patient history list
    * @return returns true if the element starts after end within X period  with result else returns false
    */
  def medicationOrderStartsAfterEndOfLabTestWithResult(visit:CassandraRow,m:MeasureProperty,labTestElement:String,timeCOperator:String,calenderUnit:String,calenderInterval:Int=0,result:Double,resultCompareFlag:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementEndsAfterStartWithinXPeriodWithResult(visit,m,labTestElement,timeCOperator,calenderUnit,calenderInterval,result,resultCompareFlag,patientHistoryList)
  }

  /**
    * This function checks if assessment with result starts after or concurrent with other element
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param currentElement           current element name element name
    * @param assessmentElement     assessment element will be looed in history
    * @param result result in double to be checked
    * @param resultCompareFlag result compare flag is used to compare element value result
    * @param patientHistoryList patient history list
    * @return returns true if  assessment with result starts after or concurrent with other element else returns false
    */
  def wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit: CassandraRow, m: MeasureProperty, currentElement: String, assessmentElement: String,result:Double,resultCompareFlag:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    isElementStartsAfterOrConcurrentWithStartOfHistoryWithResult(visit,m,currentElement,assessmentElement,result,resultCompareFlag,patientHistoryList)
  }

  /**
    * This function verifies most recent element is before physical exam
    * @param visit current patient visit
    * @param m measure property
    * @param physicalExamElement physical exam performed
    * @param MostRecentElement most recent  element
    * @param patientHistoryList patient history element
    * @param mostRecentPatientHistoryList msot recent patient histroy element
    * @return
    */

  def wasMostRecentPhysicalExamBeforePhysicalExamPerformed(visit: CassandraRow, m: MeasureProperty, physicalExamElement: String, MostRecentElement: String,patientHistoryList: Broadcast[List[CassandraRow]], mostRecentPatientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasMostRecentElementOverlapsElement(visit, m, physicalExamElement, MostRecentElement, patientHistoryList,mostRecentPatientHistoryList)

  }

  def isInterventionOrderedAfterAssessmentWithInXDays(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)
  }

  def isMedicationOrderedAfterAssessmentWithInXDays(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)
  }

  def isProcedurePerformedAfterAssessmentWithInXDays(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {


    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)
  }

  /**
    * This function checks if the event starts after start of measurement period within X period
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param diagnosisElement       diagnosis element name
    * @param calenderUnit valid calender units are (YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param calenderInterval               no of calender interval to be for calender unit
    * @param patientHistoryList patient history list
    * @return returns true if  the event starts after start of measurement period within X period else returns false
    */
def wasDiagnosisStartsAfterStartOfWithinXPeriod(visit: CassandraRow, m: MeasureProperty, diagnosisElement: String,calenderUnit:String, calenderInterval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
  isEventStartsAfterStartMeasurementPeriodWithinXPeriod(visit,m,diagnosisElement,calenderUnit,calenderInterval,CompareOperator.LESS_EQUAL,patientHistoryList)
}



  /**
    * This function verifies whether assessment is performed before or concurrent with current assessment
    *
    * @param visit                    current visit of the patient
    * @param m                        measure property
    * @param currentAssessmentDate    current assessment element date
    * @param historyAssessmentElement history assessment element
    * @param patientHistoryList       patient history list
    * @return it will return true if assessment is performed before current assessment else false.
    */
  def wasAssessmentPerformedBeforeOrConcurrentwithCurrentAssessment(visit: CassandraRow, m: MeasureProperty, currentAssessmentDate: String, historyAssessmentElement: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeOrEqualInHistory(visit, m, currentAssessmentDate, historyAssessmentElement, patientHistoryList)
  }


  /**
    * This function verifies whether diagnosed is performed before or concurrent with current assessment
    *
    * @param visit                   current visit of the patient
    * @param m                       measure property
    * @param currentAssessmentDate   current assessment element date
    * @param historyDiagnosedElement history diagnosed element
    * @param patientHistoryList      patient history list
    * @return it will return true if assessment is performed before current assessment else false.
    */
  def wasDiagnosedBeforeOrConcurrentWithCurrentAssessment(visit: CassandraRow, m: MeasureProperty, currentAssessmentDate: String, historyDiagnosedElement: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeOrEqualInHistory(visit, m, currentAssessmentDate, historyDiagnosedElement, patientHistoryList)

  }





  /**
    * This function verifies whether most assessment is performed before or concurrent with current assessment
    *
    * @param visit                        current visit of the patient
    * @param m                            measure property
    * @param currentAssessmentDate        current assessment element date
    * @param historyAssessmentElement     history assessment element
    * @param mostRecentpatientHistoryList most patient history list
    * @return it will return true if assessment is performed before current assessment else false.
    */
  def wasMostRecentAssessmentPerformedBeforeOrConcurrentwithCurrentAssessment(visit: CassandraRow, m: MeasureProperty, currentAssessmentDate: String, historyAssessmentElement: String, mostRecentpatientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeOrEqualInHistory(visit, m, currentAssessmentDate, historyAssessmentElement, mostRecentpatientHistoryList)
  }


  /**
    * This function checks if intervention order performed starts before end of encounter
    * @param visit current patient visit
    * @param m measure property
    * @param interventionElement intervention element name
    * @param patientHistoryList patient history list
    * @return returns true if intervention order performed starts before end of encounter else returns false
    */
  def wasInterventionOrderedStartsBeforeEndOfEncounter(visit: CassandraRow, m: MeasureProperty, interventionElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementPresentBeforeOrEqualEncounter(visit,m,interventionElement,patientHistoryList)
  }


  /**
    * This function checks if encounter performed overlaps of encounter
    * @param visit current patient visit
    * @param m measure property
    * @param encounterElement encounter element name
    * @param patientHistoryList patient history list
    * @return returns true if encounter performed overlaps of encounter else returns false
    */
  def wasEncounterPerformedBeforeOrEqualOfEncounter(visit: CassandraRow, m: MeasureProperty, encounterElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementPresentBeforeOrEqualEncounter(visit,m,encounterElement,patientHistoryList)
  }



  def isProcedurePerformedDuringOtherProcedure(visit:CassandraRow,m:MeasureProperty,element1:String,element2:String):Boolean={
    checkNotNull(visit,element1,element2) && isDateEqual(visit,m,element1+"_date",element2+"_date")
  }

  /**
    * This function verifies first medication ordered after or equal diagnosis or before or equal end date.
    * @param visit current visit of the patient
    * @param m measure property
    * @param diagnosisElement diagnosis element from history
    * @param medicationElement medication element
    * @param patientHistoryList patient history list
    * @param firstElementHistoryList first date element history list
    * @return it will return true if first medication ordered is after or equal to diagnosis or before or equal end date.
    */
  def wasFirstMedicationOrderedAfterOrEqualDiagnosisAndBeforeOrEqualEnd(visit:CassandraRow,m:MeasureProperty,diagnosisElement:String,medicationElement:String,patientHistoryList:Broadcast[List[CassandraRow]],firstElementHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementAfterOrEqualFirstElementDateAndBeforeOrEqualEnd(visit,m,diagnosisElement,medicationElement,patientHistoryList,firstElementHistoryList)
  }



  /**
    * This function verifies first medication Administered after or equal diagnosis or before or equal end date.
    * @param visit current visit of the patient
    * @param m measure property
    * @param diagnosisElement diagnosis element from history
    * @param medicationElement medication element
    * @param patientHistoryList patient history list
    * @param firstElementHistoryList first date element history list
    * @return it will return true if first medication Administered is after or equal to diagnosis or before or equal end date.
    */
  def wasFirstMedicationAdministeredAfterOrEqualDiagnosisAndBeforeOrEqualEnd(visit:CassandraRow,m:MeasureProperty,diagnosisElement:String,medicationElement:String,patientHistoryList:Broadcast[List[CassandraRow]],firstElementHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementAfterOrEqualFirstElementDateAndBeforeOrEqualEnd(visit,m,diagnosisElement,medicationElement,patientHistoryList,firstElementHistoryList)

  }


  /**
    * This function verifies whether laboratory test is performed X unit before or after assessment
    *
    * @param visit              current visit of the patient
    * @param m                  measure property
    * @param laboratoryElement  laboratory element
    * @param assessmentElement  assessment element
    * @param interval           number of intervals that has to be added or subtracted according to the conditions
    * @param unit               MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
    * @param patientHistoryList patient history list
    * @return it will return true if laboratory test is performed X months before assessment else false
    */
  def wasLaboratoryTestPerformedInXMonthBeforeAssessment(visit:CassandraRow,m:MeasureProperty,laboratoryElement:String,assessmentElement:String,interval:Int,unit:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeOrEqualXUnitFromCurrent(visit,m,laboratoryElement,assessmentElement,interval,unit,patientHistoryList)

  }





  /**
    * This function verifies whether diagnosed is performed before or concurrent with first medication
    *
    * @param visit                   current visit of the patient
    * @param m                       measure property
    * @param diagnosedElement       history diagnosed element
    * @param firstMedicationElement first medication element
    * @param patientHistoryList      patient history list
    * @return it will return true if diagnosed element is performed before or concurrent with first medication  else false.
    */
  def wasDiagnosedBeforeOrConcurrentWithFirstMedication(visit:CassandraRow,m:MeasureProperty,diagnosedElement:String,firstMedicationElement:String,patientHistoryList:Broadcast[List[CassandraRow]],firstElementHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeOrConcurrentWithFirstElementDate(visit,m,diagnosedElement,firstMedicationElement,patientHistoryList,firstElementHistoryList)

  }


  /**
    * This function verifies whether diagnosed is performed before or concurrent with first medication
    *
    * @param visit                  current visit of the patient
    * @param m                      measure property
    * @param assessmentElement      history assessment Element
    * @param firstMedicationElement first medication element
    * @param patientHistoryList     patient history list
    * @return it will return true if diagnosed element is performed before or concurrent with first medication  else false.
    */
  def wasAssessmentPerformedOrConcurrentWithFirstMedication(visit:CassandraRow,m:MeasureProperty,assessmentElement:String,firstMedicationElement:String,patientHistoryList:Broadcast[List[CassandraRow]],firstElementHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeOrConcurrentWithFirstElementDate(visit,m,assessmentElement,firstMedicationElement,patientHistoryList,firstElementHistoryList)

  }




  /**
    * This function verifies whether MostRecentAssessment is performed before or concurrent with first medication
    *
    * @param visit                        current visit of the patient
    * @param m                            measure property
    * @param assessmentElement            history assessment Element
    * @param firstMedicationElement       first medication element
    * @param mostRecentpatientHistoryList patient history list
    * @return it will return true if diagnosed element is performed before or concurrent with first medication  else false.
    */
  def wasMostRecentAssessmentPerformedBeforeOrConcurrentWithFirstMedication(visit:CassandraRow,m:MeasureProperty,assessmentElement:String,firstMedicationElement:String,mostRecentpatientHistoryList:Broadcast[List[CassandraRow]],firstElementHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeOrConcurrentWithFirstElementDate(visit,m,assessmentElement:String,firstMedicationElement:String,mostRecentpatientHistoryList:Broadcast[List[CassandraRow]],firstElementHistoryList:Broadcast[List[CassandraRow]])

  }



  /**
    * This function verifies whether laboratory test is performed X interval with unit before or after assessment
    *
    * @param visit              current visit of the patient
    * @param m                  measure property
    * @param laboratoryElement  laboratory element
    * @param medicationElement  medication Element
    * @param interval           number of intervals that has to be added or subtracted according to the conditions
    * @param unit               MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
    * @param patientHistoryList patient history list
    * @return it will return true if laboratory test is performed X months before assessment else false
    */
  def wasLaboratoryTestPerformedInXMonthBeforeFirstMedication(visit:CassandraRow,m:MeasureProperty,laboratoryElement:String,medicationElement:String,unit:String,interval:Int,patientHistoryList:Broadcast[List[CassandraRow]],firstElementHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeXUnitWithFirstElementDate(visit,m:MeasureProperty,laboratoryElement:String,medicationElement:String,unit:String,interval:Int,patientHistoryList:Broadcast[List[CassandraRow]],firstElementHistoryList:Broadcast[List[CassandraRow]])

  }

  def wasAssessmentPerformedAfterElementPresentAfter(visit: CassandraRow, m: MeasureProperty, CurrentElementDate: String, patientHistoryList: Broadcast[List[CassandraRow]], HistoryelementName: String*): Boolean = {

     wasElementPresentAfter(visit, m, CurrentElementDate, patientHistoryList, HistoryelementName)
  }




  



  /**
    * This function verifies if the element ends after  starts of measurement period
    * @param visit current patient visit
    * @param m measure property
    * @param assessmentElementName assessment element to be checked in during measurement period
    * @param lowerDateCalenderUnit lower date calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param lowerDateInterval lower calender interval to be checked
    * @param lowerDateTimeCompareOperator time comparator unit (valid units are lt,gt,le,ge,eq )
    * @param higherDateCalenderUnit higher date calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param higherDateInterval higher calender interval to be checked
    * @param higherDateTimeCompareOperator time comparator unit (valid units are lt,gt,le,ge,eq )
    * @param patientHistoryList patient history list
    * @return returns true if the element ends after  starts of measurement period else returns false
    */
  def wasAssessmentPerformedEndsAfterAndBeforeWithinXPeriod(visit: CassandraRow, m: MeasureProperty, assessmentElementName: String,lowerDateCalenderUnit:String, lowerDateInterval: Int,lowerDateTimeCompareOperator:String,higherDateCalenderUnit:String, higherDateInterval: Int,higherDateTimeCompareOperator:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementEndsAfterStartOfWithinXPeriodInMeasurementPeriod(visit,m,assessmentElementName,lowerDateCalenderUnit,lowerDateInterval,lowerDateTimeCompareOperator,higherDateCalenderUnit,higherDateInterval,higherDateTimeCompareOperator,patientHistoryList)
  }

  def wasDiagnosisPerformedEndsBeforeStartOfProcedure(visit:CassandraRow, m:MeasureProperty, procedureElement:String, patientHistoryList:Broadcast[List[CassandraRow]],interventionElementNames:String*): Boolean ={
    checkNotNull(visit,procedureElement,procedureElement+"_date") && wasElementPresentBeforeOrEqualOtherElement(visit,m,procedureElement,CompareOperator.LESS_EQUAL,patientHistoryList,interventionElementNames)
  }


  def wasPhysicalExamsPerformedEndsBeforeStartOfProcedure(visit:CassandraRow, m:MeasureProperty, procedureElement:String, patientHistoryList:Broadcast[List[CassandraRow]],interventionElementNames:String*): Boolean ={
    checkNotNull(visit,procedureElement,procedureElement+"_date") && wasElementPresentBeforeOrEqualOtherElement(visit,m,procedureElement,CompareOperator.LESS_EQUAL,patientHistoryList,interventionElementNames)
  }

  /**
    * This function verifies if diagnosis is X days after encounter/element date
    * @param visit current visit of the patient
    * @param m measure property of the measure
    * @param elementName element/encounter date
    * @param historyElementName history element
    * @param days number of calender interval to be checked
    * @param patientHistoryList patient history list
    * @return It will return true if diagnosis is X days before encounter.
    */
  def wasProcedureStartsAfterEndOfEncounter(visit: CassandraRow, m: MeasureProperty,elementName:String, historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {


    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)
  }

  def wasProcedurePerformedBeforeLumbarDisectomy(visit: CassandraRow, m: MeasureProperty, historyElement: String, calenderUnit: String, calenderInterval:Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentBeforeOrEqualElementInXPeriod(visit, m, historyElement, calenderUnit, calenderInterval, patientHistoryList)
  }

  def WasProcedurePerformStartBeforeXMonths(r: CassandraRow, m: MeasureProperty, elementName: String, calenderUnit: String, calenderInterval:Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeStartDateInXPeriod(r, m, elementName, calenderUnit, calenderInterval, patientHistoryList)
  }



/*
  def wasElementBeforeOtherElementWithInXDays(visit: CassandraRow, m: MeasureProperty, historyElement: String, currentElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementPresentBeforeOtherElementWithinXDays(visit: CassandraRow, m: MeasureProperty, historyElement: String, currentElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }*/

  /**
    * This function verifies if diagnosis was done before or equal to procedure
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement procedure element to be checked in current record
    * @param diagnosisElement diagnosis element to be checked in history
    * @param patientHistoryList patient history list
    * @return returns true if diagnosis was done before or equal to procedure returns false
    */
  def wasDiagnosedBeforeOrEqualProcedure(visit:CassandraRow, m:MeasureProperty, procedureElement:String,diagnosisElement:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isElementPresentBeforeOrEqualElement(visit: CassandraRow, m: MeasureProperty,procedureElement, diagnosisElement, patientHistoryList)

  }

  def isAssessmentPerformedBeforeProcedure(visit: CassandraRow, m: MeasureProperty, currentElement: String, patientHistoryList: Broadcast[List[CassandraRow]],historyElement: String*):Boolean={
    wasElementPresentBeforeOrEqualOtherElement(visit, m, currentElement,CompareOperator.LESS_EQUAL, patientHistoryList,historyElement)
  }

  def isDiagnosticStudyPerformedInXDaysBeforeProcedure(visit: CassandraRow, m: MeasureProperty, historyElement: String, currentElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementPresentBeforeOtherElementWithinXDays(visit, m, historyElement, currentElement, days, patientHistoryList)
  }



  /**
    * This function veriifes whether patient is expired with cause
    * @param visit current visit of the patient
    * @param m measure property of the element
    * @param element current element
    * @param causeElement cause element
    * @return it will return true if patient has expired with cause element else false
    */
  def isPatientExpiredWithCause(visit: CassandraRow, m: MeasureProperty,element:String,causeElement:String):Boolean={
    val elementDate =element+"_date"
    val causeElementDate=causeElement+"_date"
    checkElementPresent(visit,m,element) &&  checkElementPresent(visit,m,causeElement) && isDateEqual(visit,m,elementDate,causeElementDate)
  }

  /**
    * This function verifies element before other element with in X days.
    * @param visit current visit of the patient
    * @param m measure property
    * @param historyElement history element that has to be verified in history
    * @param currentElement current element  that has to be verified
    * @param days number of days that has to be subtracted from current date
    * @param patientHistoryList  patient history list
    * @return it will return true if element is before other element with in X days else false.
    */
  def wasElementBeforeOtherElementWithInXDays(visit: CassandraRow, m: MeasureProperty, historyElement: String, currentElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementPresentBeforeOtherElementWithinXDays(visit, m, historyElement, currentElement, days, patientHistoryList)
  }


  /**
    * This function verifies whether patient died during procedure
    * @param visit   current visit of the patient
    * @param m       measure property of the element
    * @param element current element
    * @param procedureElement procedure element
    * @return it wiil return true if patient dies during procedure else false.
    */
  def isPatientDiedDuringProcedure(visit: CassandraRow, m: MeasureProperty,element:String,procedureElement:String):Boolean={
    isPatientExpiredWithCause(visit, m,element,procedureElement)
  }

  /**
    * This function verifies whether diagnostic study is performed during procedure
    * @param visit current visit of the patient
    * @param m measure property of the measure
    * @param diagnosticElement diagnostic element
    * @param procedureElement procedure element
    * @return it will return true if diagnostic study is performed during procedure else false
    */
  def isDiagnosticStudyPerformedDuringProcedure(visit: CassandraRow, m: MeasureProperty,diagnosticElement:String,procedureElement:String):Boolean={
    val diagnosticElementDate =diagnosticElement+"_date"
    val procedureElementDate=procedureElement+"_date"
    checkElementPresent(visit,m,diagnosticElement) &&  checkElementPresent(visit,m,procedureElement) && isDateEqual(visit,m,diagnosticElementDate,procedureElementDate)

  }



  /**
    * This function verifies whether diagnostic study is performed during procedure
    * @param visit current visit of the patient
    * @param m measure property of the measure
    * @param firstProcedureElement diagnostic element
    * @param secondProcedureElement procedure element
    * @return it will return true if diagnostic study is performed during procedure else false
    */
  def isProcedurePerformedNotDoneDuringOtherProcedure(visit: CassandraRow, m: MeasureProperty, firstProcedureElement:String, secondProcedureElement:String):Boolean={
    isDiagnosticStudyPerformedDuringProcedure(visit, m,firstProcedureElement,secondProcedureElement)
  }


  /**
    * This function verifies whether patient is expired after x interval encounter with cause
    * @param visit current visit of the patient
    * @param m measure property of the measure
    * @param patientCharacteristic  patient characteristic element
    * @param causeElement  cause element that has to same date with patient characteristics element
    * @param unit MONTHS
    * @param interval number of x months
    * @param patientHistoryList patient history list
    * @return  it will return true if patient expired X months after encounter with cause element.
    */
  def isPatientExpiredAfterXMonthsEncounterWithCause(visit: CassandraRow, m: MeasureProperty, patientCharacteristic: String, causeElement: String,unit:String ,interval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasResultElementAfterEncounterDateWithInXCalender(visit: CassandraRow, m: MeasureProperty, patientCharacteristic: String, causeElement: String,unit:String ,interval: Int, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasProcedurePerformedAfterStartWithInXMonths(visit: CassandraRow, m: MeasureProperty,  historyElement: String, interval: Int, unit: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterStartWithinXPeriod(visit, m, historyElement, interval, unit, patientHistoryList)
  }

  def wasInterventionAdverseEventAfterProcedureWithInXDays(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)
  }

  def wasEncounterPerformedWithReasonAfterProcedureWithInXDays(visit: CassandraRow, m: MeasureProperty, elementDate1: String, historyElement: String,resultElement: String, interval: Int, unit: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementWithReasonWithinXPeriod(visit, m, elementDate1, historyElement,resultElement, interval, unit, patientHistoryList)
  }
  def isCommunicationFromProvidertoPatient(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }

  def wasEncounterPerformedAfterProcedureWithInXWeeks(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String, WEEK: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElementName, CalenderUnit.WEEK, WEEK, CompareOperator.LESS_EQUAL, patientHistoryList)
  }



  /**
    * This function verifies if care goal done during encounter
    * @param visit current patient visit
    * @param m measure property
    * @param careGoalElement care goal element name
    * @return returns true if care goal done during encounter else returns false
    */
  def isCareGoalDuringEncounter(visit: CassandraRow, m:MeasureProperty, careGoalElement:String): Boolean ={
    dataTypeOnEncounter(visit,m,careGoalElement)
  }

  def wasDiagnosticStudyPerformedBeforeXDaysFromProcedure(visit: CassandraRow, m: MeasureProperty, currentElement: String, Days: Int, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: Seq[String]):Boolean= {
    wasElementPresentXDaysBeforeOtherElement(visit, m, currentElement, Days, patientHistoryList, historyElementName)
  }

  /**
    * This function verifies if assessment performed before or equal end of procedure
    *
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement represent current element/encounter date
    * @param assessmentElement assessment element to be checked in history
    * @param patientHistoryList patient history list
    * @return returns true if assessment performed before or equal end of procedure else returns false
    */
  def wasAssessmentPerformedBeforeOrEqualProcedure(visit: CassandraRow, m: MeasureProperty, procedureElement: String,assessmentElement:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    isElementPresentBeforeOrEqualElement(visit,m,procedureElement,assessmentElement,patientHistoryList)
  }

  def isDiagnosisOverlapsProcedure(visit: CassandraRow, m: MeasureProperty,diagnosis:String,procedure:String,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementOverlapsElement(visit, m,diagnosis,procedure,patientHistoryList)
  }

   /**
     * This function verifies if assessmentElement with value present before or equal end of of procedureElement
     *
     * @param assessmentElement represents history element name
     * @param result result of history element in double to be checked
     * @param resultCompareFlag history element value  to be compared using result flat with specified value
     * @param patientHistoryList patient history list
     * @return returns true if assessmentElement with value present before or equal end of of procedureElement else returns false
     */
  def wasAssessmentPerformedBeforeOrEqualProcedureWithResult(visit: CassandraRow, m: MeasureProperty, procedureElement: String,assessmentElement:String,result:Double,resultCompareFlag:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    isElementPresentBeforeOrEqualElementWithResult(visit,m,procedureElement,assessmentElement,result,resultCompareFlag,patientHistoryList)
  }

  /**
    * This function verifies if procedure adverse event during other procedure
    * @param visit current patient visit
    * @param m measure property
    * @param procedurePerformedElement procedure performed element
    * @param procedureAdverseElement procedure adversed element
    * @return returns true if procedure adverse event during other procedure else returns false
    */
  def isProcedureAdverseEventDuringProcedure(visit:CassandraRow,m:MeasureProperty,procedurePerformedElement:String,procedureAdverseElement:String): Boolean ={
  checkNotNull(visit,procedurePerformedElement,procedureAdverseElement,procedurePerformedElement+"_date",procedureAdverseElement+"_date") &&
  isDateEqual(visit,m,procedurePerformedElement+"_date",procedureAdverseElement+"_date")
  }

  /**
    * This function verifies if diagnosed done during other procedure
    * @param visit current patient visit
    * @param m measure property
    * @param diagnosisElement diagnosis element (to be looked in current record)
    * @param procedureElement procedure element (to be looked in history record)
    * @return returns true if diagnosed done during other procedure else returns false
    */
  def isDiagnosedDuringProcedure(visit:CassandraRow,m:MeasureProperty,diagnosisElement:String,procedureElement:String): Boolean ={
    checkNotNull(visit,diagnosisElement,procedureElement,diagnosisElement+"_date",procedureElement+"_date") &&
      isDateEqual(visit,m,diagnosisElement+"_date",procedureElement+"_date")
  }

  /**
    * This function verifies if procedure adverse starts after end of procedure performed within X period
    * @param visit current patient visit
    * @param m measure property
    * @param procedurePerformed procedure performed date (to be looked in current record)
    * @param procedureAdverse procedure adverse date(to be looked in history record)
    * @param days calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)

    * @param patientHistoryList patient history list
    * @return returns true if procedure adverse starts after end of procedure performed within X period else returns false
    */
  def isProcedureAdverseEventInXDaysAfterProcedure(visit: CassandraRow, m: MeasureProperty, procedurePerformed: String, procedureAdverse: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={

    wasElementAfterElementDateWithinXPeriod(visit, m, procedurePerformed, procedureAdverse, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)

  }


  def isDiagnosedInXDaysAfterProcedure(visit: CassandraRow, m: MeasureProperty, procedurePerformed: String, diagnosis: String, DAY: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={

    wasElementAfterElementDateWithinXPeriod(visit, m, procedurePerformed, diagnosis, CalenderUnit.DAY, DAY, CompareOperator.LESS_EQUAL, patientHistoryList)
  }



  /**
    * This function verifies if patient expired starts after end of procedure performed  within X period
    * @param visit current patient visit
    * @param m measure property
    * @param procedurePerformed procedure performed date (to be looked in current record)
    * @param patientExpired patient expired date(to be looked in history record)
    * @param days calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param patientHistoryList patient history list
    * @return returns true if procedure performed 1 starts after end of procedure performed 2 within X period else returns false
    */
  def isPatientExpiredInXDaysAfterProcedure(visit: CassandraRow, m: MeasureProperty, procedurePerformed: String, patientExpired: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={

    wasElementAfterElementDateWithinXPeriod(visit, m, procedurePerformed, patientExpired, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)
  }

  /**
    * This function verifies if medication administered before start of procedure
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement procedure element (to be checked in current visit)
    * @param medicationElementName medication element name(to be checked in history visit)
    * @param patientHistoryList patient history list
    * @return returns true if medication administered before start of procedure else returns false
    */
  def wasMedicationAdministeredBeforeStartOfProcedure(visit:CassandraRow,m:MeasureProperty,procedureElement:String,medicationElementName:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    checkNotNull(visit,procedureElement,procedureElement +"_date") && wasElementPresentBeforeOrEqualOtherElement(visit,m,procedureElement,CompareOperator.LESS_EQUAL,patientHistoryList,Seq(medicationElementName))
  }


  /**
    * This function verifies if medication administered not done with reason before start of procedure
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement procedure element (to be checked in current visit)
    * @param medicationElementName medication element name(to be checked in history visit)
    * @param patientHistoryList patient history list
    * @return returns true if medication administered not done with reason before start of procedure else returns false
    */
  def wasMedicationAdministeredNotDoneWithReasonBeforeStartOfProcedure (visit:CassandraRow,m:MeasureProperty,procedureElement:String,medicationElementName:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    checkNotNull(visit,procedureElement,procedureElement +"_date") && wasElementPresentBeforeOrEqualOtherElement(visit,m,procedureElement,CompareOperator.LESS_EQUAL,patientHistoryList,Seq(medicationElementName))
  }

  /**
    * This function verifies if medication administered not done with reason during measurement period
    * @param visit current patient visit
    * @param m measure property
    * @param medicationElementName medication element name(to be checked in history visit)
    * @param patientHistoryList patient history list
    * @return returns true if medication administered not done with reason during measurement period else returns false
    */
  def isMedicationAdministeredNotDoneForReason(visit:CassandraRow,m:MeasureProperty,medicationElementName:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    checkElementDuringMeasurementPeriod(visit,m,medicationElementName,patientHistoryList)
  }

  /**
    * This function verifies if procedure starts after end of encounter
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element name
    * @param procedureElementName procedure element will be checked in history
    * @param patientHistoryList patient history list
    * @return returns true if  procedure starts after end of encounter else returns false
    */
  def wasProcedurePerformedAfterEncounter(visit:CassandraRow, m:MeasureProperty, elementName:String,procedureElementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    wasElementPresentAfterOrEqualEncounter(visit, m, elementName,procedureElementName, patientHistoryList)
  }


  /**
    * This function verifies medication is active order before end date with in X months with dose.
    * @param currentVisit current visit of the element
    * @param m measure property
    * @param medicationActiveElement medication active element
    * @param doseValue dose value
    * @param unit  MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
    * @param interval number of intervals
    * @param compareFlag  compare flag (valid flags [lt,gt,le,ge,eq])
    * @param patientHistoryList patient history list
    * @return return true if medication is active order before end date with in X months with dose else false
    */
  def wasMedicationActiveOrderBeforeEndWithinXMonthswithDose(currentVisit: CassandraRow, m: MeasureProperty, medicationActiveElement: String, doseValue: Double,unit:String,interval:Int, compareFlag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasValueElementePerformedStartsBeforeOrEqualEndOfMeasurementPeriod(currentVisit, m, medicationActiveElement, doseValue,unit,interval, compareFlag, patientHistoryList)
  }




  /**
    *  This function verifies whether procedure is performed  before end  X months
    * @param currentVisit current visit of the element
    * @param m measure property
    * @param procedureElement procedure element
    * @param months number of months
    * @param patientHistoryList patient history list
    * @return it will return procedure is performed before end x months
    */
  def wasProcedurePerformedBeforeEndInXMonths(currentVisit: CassandraRow, m: MeasureProperty, procedureElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeEndWithinXMonths(currentVisit, m, procedureElement, months, patientHistoryList)
  }

  /**
    *  This function verifies whether medication is performed  before end  X months
    * @param currentVisit current visit of the element
    * @param m measure property
    * @param medicationElement medication element
    * @param months number of months
    * @param patientHistoryList patient history list
    * @return it will return procedure is performed before end x months
    */
  def wasMedicationOrderedBeforeEndInXMonths(currentVisit: CassandraRow, m: MeasureProperty, medicationElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeEndWithinXMonths(currentVisit, m, medicationElement, months, patientHistoryList)
  }

/*  /**
    *  This function verifies whether Intervention is performed  before end  X months
    * @param currentVisit current visit of the element
    * @param m measure property
    * @param interventionElement Intervention element
    * @param months number of months
    * @param patientHistoryList patient history list
    * @return it will return procedure is performed before end x months
    */
  def wasInterventionPerformedBeforeEndInXMonths(currentVisit: CassandraRow, m: MeasureProperty, interventionElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeEndWithinXMonths(currentVisit, m, interventionElement, months, patientHistoryList)
  }*/


  def isProcedurePerformedOverlapsMeasurementPeriod(visit: CassandraRow, m: MeasureProperty,patientHistoryList: Broadcast[List[CassandraRow]],historyElement:String*):Boolean={
    isElementOverlapsMeasurementPeriod(visit, m,patientHistoryList,historyElement)
  }

  def isDiagnosisOverlapsMeasurementPeriod(visit: CassandraRow, m: MeasureProperty,patientHistoryList: Broadcast[List[CassandraRow]],historyElement:String*):Boolean={
    isElementOverlapsMeasurementPeriod(visit, m,patientHistoryList,historyElement)
  }

  def isDiagnosisOverlapsEncounter(visit: CassandraRow, m: MeasureProperty,patientHistoryList: Broadcast[List[CassandraRow]],historyElement:String*):Boolean={
    isElementOverlapsEncounterDate(visit, m,patientHistoryList,historyElement)
  }


  /**
    *  This function verifies whether Intervention is not performed due to medical reason performed  before end  X months
    * @param currentVisit current visit of the element
    * @param m measure property
    * @param medicalReasonElement medicalReason Element
    * @param months number of months
    * @param patientHistoryList patient history list
    * @return it will return procedure is performed before end x months
    */
  def wasInterventionPerformedNotDoneStartsBeforeEncounterInXMonths(currentVisit: CassandraRow, m: MeasureProperty, medicalReasonElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeEncounterWithinXMonths(currentVisit, m, medicalReasonElement, months, patientHistoryList)
  }

  /**
    *  This function verifies whether assessment is not performed due to medical reason performed  before end  X months
    * @param currentVisit current visit of the element
    * @param m measure property
    * @param assessmentElement assessment Element
    * @param months number of months
    * @param patientHistoryList patient history list
    * @return it will return procedure is performed before end x months
    */
  def wasAssessmentPerformedBeforeEncounterInXMonths(currentVisit: CassandraRow, m: MeasureProperty, assessmentElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeEncounterWithinXMonths(currentVisit, m, assessmentElement, months, patientHistoryList)
  }


  /**
    *  This function verifies whether Intervention is performed  before end  X months
    * @param currentVisit current visit of the element
    * @param m measure property
    * @param patientCharacteristicElement patientCharacteristic Element
    * @param months number of months
    * @param patientHistoryList patient history list
    * @return it will return procedure is performed before end x months
    */
  def wasPatientCharacteristicBeforeEndInXMonths(currentVisit: CassandraRow, m: MeasureProperty, patientCharacteristicElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeEndWithinXMonths(currentVisit, m, patientCharacteristicElement, months, patientHistoryList)
  }


  /**
    * This function verifies Diagnosis starts before or equal to x months
    * @param currentVisit current visit of the element
    * @param m measure property
    * @param diagnosisElement diagnosis Element
    * @param month number of months that has to be subtracted
    * @param patientHistoryList patient history list
    * @return it will return true if diagnosis starts before or equal to x months.
    */
  def  wasDiagnosisStartsBeforeEndPriorToXMonths(currentVisit: CassandraRow, m: MeasureProperty, diagnosisElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementPresentBeforeOrEqualEndInMonths(currentVisit, m, diagnosisElement, month, patientHistoryList)
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param diagnosis diagnosis element
    * @param procedure procedure element
    * @param days number of days
    * @param patientHistoryList patient history list
    * @return returns true if patient was diagnosed before procedure within x number of days
    */
  def wasDiagnosedBeforeProcedureInXDays(visit: CassandraRow, m: MeasureProperty, procedure: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]], diagnosis: String*): Boolean = {
    diagnosis.exists(x => checkElementPresentBeforeOtherElementWithinXDays(visit, m, x, procedure, days, patientHistoryList))
  }

  /**
    *
    * @param visit
    * @param m
    * @param elementName
    * @param historyElement
    * @param days
    * @param patientHistoryList
    * @return
    */
  def isEncounterPerformedAfterEndOfProcedureInXdays(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={

    wasElementAfterElementDateWithinXPeriod(visit, m, elementName, historyElement, CalenderUnit.DAY, days, CompareOperator.LESS_EQUAL, patientHistoryList)

  }

  /**
    *
    * @param visit patient visit
    * @param m measure property
    * @param historyElement1 history element one
    * @param historyElement2 history element two
    * @param TimeOperator time operator After, Before or Equals
    * @param patientHistoryList patient history list
    * @return if
    */

  def isProcedurePerformedWithMethod(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String, TimeOperator:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     compareTwoElementDuringMeasurementPeriod(visit, m, historyElement1, historyElement2, TimeOperator, patientHistoryList)
  }



  def isDiagnosticStudyPerformedWithResultDuringProcedure(visit:CassandraRow,m:MeasureProperty,diagnosisElement:String,procedureElement:String,ResulElement:String): Boolean ={
    checkNotNull(visit,diagnosisElement,procedureElement,diagnosisElement+"_date",procedureElement+"_date") &&
      (isDateEqual(visit,m,diagnosisElement+"_date",procedureElement+"_date")
       &&
      isDateEqual(visit,m,diagnosisElement+"_date",ResulElement+"_date"))

  }

  def isDiagnosticStudyPerformedAfterProcedure(visit: CassandraRow, m: MeasureProperty, patientHistoryList: Broadcast[List[CassandraRow]], procedure: String,diagnosticStudyElements: String*):Boolean={
    diagnosticStudyElements.exists(x => wasElementPresentAfterOtherElement(visit, m,x, procedure, patientHistoryList))
  }

  /**
    * This function verifies if the patient transferred during Ed or CC
    * @param visit  current visit of the patient
    * @param m      measure Property of the measure
    * @param element patient  transfer element that has to be verified during Emergency visit.
    * @param elementDate patient  transfer Date whose date is to be verified during emergency visit.
    * @param edvisitArrivalDate edVisitArrival Date of the patient visit
    * @param edvisitDepartureDate edvisitdeparture Date of the patient visit
    * @param crtclDate critical care Date of  the patient visit
    * @return returns true if  the patient transferred during Ed or CC else returns false
    */
  def isPatientTransferredDuringEDorCC(visit:CassandraRow, m:MeasureProperty, element:String,elementDate:String, edvisitArrivalDate:String, edvisitDepartureDate:String,crtclDate:String):Boolean={
    isDiagnosisDuringEDOrCCEncounter(visit, m, element, elementDate, edvisitArrivalDate, edvisitDepartureDate, crtclDate)
  }


/*
  def isPatientAliveBeforeDischarge(visit:CassandraRow, m:MeasureProperty, CurrentEncounterDate:String, patientHistoryList:Broadcast[List[CassandraRow]],PatientExpiry:Seq[String],Discharge:String*):Boolean= {
    val PatientExpiryElement = PatientExpiry.mkString
    wasElementPresentAfter(visit, m, CurrentEncounterDate, patientHistoryList,PatientExpiry) &&
    wasElementPresentAfter(visit, m, PatientExpiryElement, patientHistoryList,Discharge)
  }
*/


  def wasPatientExpiredAfterProcedure(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: String*): Boolean = {
    wasElementPresentAfter(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName)
  }


  def wasPatientExpiredDuringEncounter(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String,dataType:String ,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    compareTwoElementInHistory(visit, m, historyElement1, historyElement2,dataType ,patientHistoryList)
  }
  /**
    *  This function verifies whether assessment is not performed due to medical reason performed  before end  X months
    * @param visit current visit of the element
    * @param m measure property
    * @param assessmentElement assessment Element
    * @param historyElementResult result element
    * @param month number of months
    * @param patientHistoryList patient history list
    * @return it will return procedure is performed before end x months
    */
  def wasAssessmentPerformedBeforeEncounterInXMonthswithresult(visit: CassandraRow, m: MeasureProperty, assessmentElement: String, month: Int, historyElementResult: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasTwoElementEqualBeforeEncounterWithinXMonths(visit, m, assessmentElement, historyElementResult, month, patientHistoryList)
  }


  def wasPhysicalExamPerformedInXYearsWithResultValue(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,reasonElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     wasElementBeforeElementWithReasonInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,reasonElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }


  /**
    * This function verifies if the element starts before end of measurement period within X period
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement element to be checked in measurement period in history
    * @param calenderUnit represent calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param calenderInterval represents no of calender unit to be checked
    * @param timeCompareOperator represents time compare operators (valid operators are CompareOperator.{GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL})
    * @param leastRecentPatientHistoryList least recent patient history list
    * @return returns true if the element starts before end of measurement period within X period else returns false
    */
def wasFirstProcedurePerformedWithinXPeriodBeforeEnd(visit: CassandraRow, m: MeasureProperty, procedureElement: String,calenderUnit:String, calenderInterval: Int,timeCompareOperator:String, leastRecentPatientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
  wasElementStartsBeforeEndOfMeasurementPeriodWithinXPeriod(visit,m,procedureElement,calenderUnit,calenderInterval,timeCompareOperator,leastRecentPatientHistoryList)
}

  /**
    * This function verifies if the lab test2  ends after end of lab test1 within X period with result
    * @param visit current patient visit
    * @param m measure property
    * @param labTestElement1 lab test element to be checked in current record
    * @param labTestElement2 lab test element to be checked in history record
    * @param timeCOperator time compare operator (valid operators are CompareOperator.{GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL})
    * @param calenderUnit calender unit (valid are YEAR,MONTH,WEEK,DAY,HOUR,MINUTES)
    * @param calenderInterval calender interval in integer
    * @param result result to be checked
    * @param resultCompareFlag result compare flag is used to compare result(le,ge,lt,gt,eq)
    * @param patientHistoryList patient history list
    * @return returns true if the lab test2  ends after end of lab test1 within X period with result else returns false
    */
  def wasLabTestEndsAfterEndOfLabTestWithResultWithPeriod(visit:CassandraRow,m:MeasureProperty,labTestElement1:String,labTestElement2:String,timeCOperator:String,calenderUnit:String,calenderInterval:Int=0,result:Double,resultCompareFlag:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    val labTestElementDate= if(!labTestElement1.equalsIgnoreCase(AdminElements.Encounter_Date)) labTestElement1+"_date" else AdminElements.Encounter_Date
    checkNotNull(visit,labTestElement1,labTestElementDate) && wasElementEndsAfterEndWithinXPeriodWithResult(visit,m,labTestElementDate,labTestElement2,timeCOperator,calenderUnit,calenderInterval,result,resultCompareFlag,patientHistoryList)
  }



  def isInterventionOrderedWithReasonAfterEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,historyElement1: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]) : Boolean = {
     wasElementAfterElementWithReasonInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,historyElement1: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def isInterventionOrderedAfterEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     wasElementAfterElementInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasPhysicalExamPerformedInXYears(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }


  /**
    *
    * @param visit patient current  visit
    * @param m measure property
    * @param currentElement current element name
    * @param historyElement history element list for medication
    * @param CalenderUnit calender Unit months,years,days
    * @param interval interval based on condition e.g. 1,2,3
    * @param patientHistoryList patient history list for medication order patient
    * @return if isMedicationOrderedWithReasonAfterEncounterWithinXDays
    */

  def isMedicationOrderedWithReasonAfterEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }



  def isLaboratoryTestWithReasonAfterEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }


  def isDiagnosticStudyWithReasonAfterEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def isDiagnosisOverlapsEncounterFirst(visit: CassandraRow, m: MeasureProperty,leastRecentpatientHistoryList: Broadcast[List[CassandraRow]],historyElements: String*):Boolean={
    isFirsElementOverlapsEncounterDate(visit, m,leastRecentpatientHistoryList,historyElements)
  }

  def isAssesmentPerformedDuringFirstDiagnosis(visit: CassandraRow, m: MeasureProperty,historyElement1: String,patientHistoryList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList: Broadcast[List[CassandraRow]],historyElements: String*):Boolean={
    wasElementFirstDateDuringOtherElementDateInHistory(visit, m,historyElement1,patientHistoryList,leastRecentpatientHistoryList,historyElements)
  }

  def isLaboratoryTestOrderDuringFirstDiagnosis(visit: CassandraRow, m: MeasureProperty,historyElement1: String,patientHistoryList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList: Broadcast[List[CassandraRow]],historyElements: String*):Boolean={
    wasElementFirstDateDuringOtherElementDateInHistory(visit, m,historyElement1,patientHistoryList,leastRecentpatientHistoryList,historyElements)
  }

  def isPatientCharacteristicDuringFirstDiagnosis(visit: CassandraRow, m: MeasureProperty,historyElement1: String,patientHistoryList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList: Broadcast[List[CassandraRow]],historyElements: String*):Boolean={
    wasElementFirstDateDuringOtherElementDateInHistory(visit, m,historyElement1,patientHistoryList,leastRecentpatientHistoryList,historyElements)
  }

  def isCommunicationFromPatientToProviderDoneDuringFirstDiagnosis(visit: CassandraRow, m: MeasureProperty,historyElement1: String,patientHistoryList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList: Broadcast[List[CassandraRow]],historyElements: String*):Boolean={
    wasElementFirstDateDuringOtherElementDateInHistory(visit, m,historyElement1,patientHistoryList,leastRecentpatientHistoryList,historyElements)
  }

  def isDiagnosisOverlapsFirstDiagnosis(visit: CassandraRow, m: MeasureProperty,historyElement1: String,patientHistoryList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList: Broadcast[List[CassandraRow]],historyElements: String*):Boolean={
    wasElementDateOverlapsOtherElementFirstDateInHistory(visit, m,historyElement1,patientHistoryList,leastRecentpatientHistoryList,historyElements)
  }



  def getDiagnoisisCountBeforeEncounter(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement1: String ,CalendarUnit:String,Interval:Int,count:Int,countFlag:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementCountBeforeElement(visit, m, currentElement, historyElement1 ,CalendarUnit,Interval,count,countFlag,patientHistoryList)
  }

  def wasAssessmentPerformedBeforeWithinXPeriod(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String,CalendarUnit:String ,interval:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    compareTwoElementInHistoryInXPeriod(visit, m, historyElement1, historyElement2,CalendarUnit ,interval,patientHistoryList)
  }

  /**
    *  This function verifies whether Intervention is performed  before end  X months
    * @param currentVisit current visit of the element
    * @param m measure property
    * @param interventionElement Intervention element
    * @param months number of months
    * @param patientHistoryList patient history list
    * @return it will return procedure is performed before end x months
    */
  def wasInterventionPerformedBeforeEndInXMonths(currentVisit: CassandraRow, m: MeasureProperty, interventionElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeEndWithinXMonths(currentVisit, m, interventionElement, months, patientHistoryList)
  }

  /**
    *
    * @param visit patient current  visit
    * @param m measure property
    * @param currentElement current element name
    * @param historyElement history element list for medication
    * @param CalenderUnit calender Unit months,years,days
    * @param interval interval based on condition e.g. 1,2,3
    * @param patientHistoryList patient history list for Intervention Ordered patient
    * @return if isInterventionOrderedNotDoneWithReasonAfterEncounterWithinXDays
    */

  def isInterventionOrderedNotDoneWithReasonAfterEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkNotNull(visit,currentElement,currentElement+"_date") &&
    wasElementAfterElementInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]])

  }


  /**
    *
    * @param visit patient current  visit
    * @param m measure property
    * @param currentElement current element name
    * @param historyElement history element list for medication
    * @param CalenderUnit calender Unit months,years,days
    * @param interval interval based on condition e.g. 1,2,3
    * @param patientHistoryList patient history list for MedicationOrdered  patient
    * @return if isMedicationOrderedNotDoneWithReasonAfterEncounterWithinXDays
    */

  def isMedicationOrderedNotDoneWithReasonAfterEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkNotNull(visit,currentElement,currentElement+"_date") &&
    wasElementAfterElementInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }


  /**
    *
    * @param visit patient current  visit
    * @param m measure property
    * @param currentElement current element name
    * @param historyElement history element list for medication
    * @param CalenderUnit calender Unit months,years,days
    * @param interval interval based on condition e.g. 1,2,3
    * @param patientHistoryList patient history list for Laboratory  patient
    * @return if isLaboratoryTestNotDoneWithReasonAfterEncounterWithinXDays
    */

  def isLaboratoryTestNotDoneWithReasonAfterEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkNotNull(visit,currentElement,currentElement+"_date") &&
    wasElementAfterElementInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }


  /**
    *
    * @param visit patient current  visit
    * @param m measure property
    * @param currentElement current element name
    * @param historyElement history element list for medication
    * @param CalenderUnit calender Unit months,years,days
    * @param interval interval based on condition e.g. 1,2,3
    * @param patientHistoryList patient history list for DiagnosticStudy  patient
    * @return if isDiagnosticStudyNotDoneWithReasonAfterEncounterWithinXDays
    */

  def isDiagnosticStudyNotDoneWithReasonAfterEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkNotNull(visit,currentElement,currentElement+"_date") &&
    wasElementAfterElementInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }

  /**
    * This function verifies the intervention is after in between X period.
    * @param visit current visit of the patient
    * @param currentElementName current element
    * @param unit MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
    * @param lowerInterval lower interval of period
    * @param higherInterval higher interval of period
    * @param patientHistoryList patient history list
    * @param historyElements history elements
    * @return it will return true if intervention is performed in between x period.
    */
  def wasInterventionPerformedAfterInBetweenXPeriod(visit:CassandraRow,m: MeasureProperty,currentElementName:String,unit:String,lowerInterval:Int,higherInterval:Int,patientHistoryList:Broadcast[List[CassandraRow]],historyElements:String*):Boolean={
    wasElementIsInBetweenXPeriod(visit,m,currentElementName,unit,lowerInterval,higherInterval,patientHistoryList,historyElements)
  }

  /**
    * This function verifies whether assessment is performed with result before encounter
    * @param visit current visit of the patient
    * @param m measure Property of the measure
    * @param currentElementName current element name
    * @param flag   This flag is used for current element and history element "AFTERorEQUAL","AFTER","Before","BEFOREorEQUAL","EQUAL"
    * @param assessmentElement history element (Assessment Element)
    * @param resultElement result element
    * @param patientHistoryList patient history list
    * @return it will return true if
    */
  def wasAssessmentPerformedwithResultStartBeforeEncounter(visit: CassandraRow, m: MeasureProperty, currentElementName:String,flag:String,assessmentElement: String, resultElement: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementPresentDuringOtherElementBeforeCurrentElement(visit, m,currentElementName,flag, assessmentElement, resultElement, patientHistoryList)
  }


  /**
    * This function verifies if assessment is performed with result
    * @param visit current visit of the patient
    * @param m measure Property of the measure
    * @param currentElementName current Element Name
    * @param unit MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
    * @param flag This flag is used for current element and history element "AFTERorEQUAL","AFTER","Before","BEFOREorEQUAL","EQUAL"
    * @param lowerInterval  number of intervals(lower interval)
    * @param higherInterval number of intervals(higher interval)
    * @param historyElement1 first history element
    * @param historyElement2 second history element
    * @param patientHistoryList patient history list
    * @return it will return true if element is present between other element after current element name.
    */
  def wasAssessmentPerformedwithResultAfterCurrentElementinBetweenXPeriod(visit: CassandraRow, m: MeasureProperty, currentElementName: String, unit: String, flag: String, lowerInterval: Int, higherInterval: Int, historyElement1: String, historyElement2: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    wasElementPresentBetweenOtherElementAfterCurrentElement(visit, m, currentElementName, unit, flag, lowerInterval, higherInterval,  historyElement1, historyElement2, patientHistoryList)
  }






  def isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit:CassandraRow,m:MeasureProperty,Element1:String,Element2:String,ResultElement:String): Boolean ={
    checkNotNull(visit,Element1,Element2,Element1+"_date",Element2+"_date",ResultElement,ResultElement+"_date") && isDateEqual(visit,m,Element1+"_date",Element2+"_date") && isDateEqual(visit,m,ResultElement+"_date",Element2+"_date")

  }

  def wasProcedurePerformedBeforeStartDateInXPeriod(visit: CassandraRow, m: MeasureProperty, elementName: String, calenderUnit: String, calenderInterval:Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementBeforeStartDateInXPeriod(visit, m, elementName, calenderUnit, calenderInterval, patientHistoryList)
  }

  def wasAssessmentPerformedAfterProcedureInBetweenXPeriodes(visit: CassandraRow, m: MeasureProperty, element1: String, historyElement: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementInBetweenXPeriodes(visit, m, element1, historyElement,CalenderUnitTo, intervalTo,CalenderUnitFrom, intervalFrom,patientHistoryList)
  }

  /*def wasAssessmentPerformedXMonthsBeforeStartOfProcedure(visit:CassandraRow,m:MeasureProperty,currentElementName:String,currentElementDate:String,historyElement:String,noOfMonths:Int,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
    wasElementScreeningPerformedXMonthsBeforeStartOfDiagnosis(visit,m,currentElementName,currentElementDate,historyElement,noOfMonths,patientHistoryList)
  }*/

  def isPhysicalExamNotDoneForReasonDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, element1: String,element2: String,element3: String): Boolean = {
    (
    dataTypeOnEncounter(r, measureProperty, element1)
   && dataTypeOnEncounter(r, measureProperty, element2)
   && dataTypeOnEncounter(r, measureProperty, element3)
      )

  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property
    * @param PhyicalExamElement physicalexam performed element
    * @param flag according to requirement mentioned flag gt,lt,eq
    * @param compareValue1 compare value for element one
    * @param compareValue2 comper value for element two
    * @return if return if phycical exam performed
    */
  def wasPhysicalExamPerformedOnEncounterRange(visit: CassandraRow, m: MeasureProperty, PhyicalExamElement: String,flag: String,compareValue1: Double,compareValue2: Double):Boolean={
    compareTwoValueStatus(visit.getDouble(PhyicalExamElement): Double, flag: String, compareValue1: Double,compareValue2: Double)
  }

  /**
    *
    * @param visit current visit of patient
    * @param m measure property
    * @param currentElement medication current element date
    * @param patientHistoryList medication order patient history list
    * @param historyElementName medication history element name
    * @return if medication order before or equals encountre date
    */

  def wasMedicationOrderBeforeOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, currentElement: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: String*): Boolean = {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, currentElement,
      CompareOperator.LESS_EQUAL, patientHistoryList, historyElementName)
  }




  /**
    * This function verifies if the medication starts after  end of  of current element / encounter date
    * @param visit current patient visit
    * @param m measure property
    * @param trusBiopsyElement represents current element name/ encounter date to be checked in current element
    * @param medicationElement represents history element to be checked in history
    * @param lowerDateCalenderUnit lower date calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param lowerDateInterval lower calender interval to be checked
    * @param lowerDateTimeCompareOperator time comparator unit (valid units are {GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL})
    * @param higherDateCalenderUnit higher date calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param higherDateInterval higher calender interval to be checked
    * @param higherDateTimeCompareOperator time comparator unit (valid units are CompareOperator.{GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL})
    * @param patientHistoryList patient history list
    * @return returns true if the medication starts after  end of  of current element / encounter date else returns false
    */
def wasMedicationOrderedStartsAfterEndOfWithinXPeriod(visit: CassandraRow, m: MeasureProperty,trusBiopsyElement:String, medicationElement: String,lowerDateCalenderUnit:String, lowerDateInterval: Int,lowerDateTimeCompareOperator:String,higherDateCalenderUnit:String, higherDateInterval: Int,higherDateTimeCompareOperator:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
  wasElementStartsAfterEndOfWithinXPeriod(visit,m,trusBiopsyElement, medicationElement,lowerDateCalenderUnit,lowerDateInterval,lowerDateTimeCompareOperator,higherDateCalenderUnit,higherDateInterval,higherDateTimeCompareOperator,patientHistoryList )
}

  /**
    * This function verifies if the diagnosis starts after  end of  of current element / encounter date
    * @param visit current patient visit
    * @param m measure property
    * @param trusBiopsyElement represents current element name/ encounter date to be checked in current element
    * @param diagnosisElement represents history element to be checked in history
    * @param lowerDateCalenderUnit lower date calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param lowerDateInterval lower calender interval to be checked
    * @param lowerDateTimeCompareOperator time comparator unit (valid units are {GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL})
    * @param higherDateCalenderUnit higher date calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param higherDateInterval higher calender interval to be checked
    * @param higherDateTimeCompareOperator time comparator unit (valid units are CompareOperator.{GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL})
    * @param patientHistoryList patient history list
    * @return returns true if the diagnosis starts after  end of  of current element / encounter date else returns false
    */
  def wasDiagnosisDoneStartsAfterEndOfWithinXPeriod(visit: CassandraRow, m: MeasureProperty,trusBiopsyElement:String, diagnosisElement: String,lowerDateCalenderUnit:String, lowerDateInterval: Int,lowerDateTimeCompareOperator:String,higherDateCalenderUnit:String, higherDateInterval: Int,higherDateTimeCompareOperator:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementStartsAfterEndOfWithinXPeriod(visit,m,trusBiopsyElement, diagnosisElement,lowerDateCalenderUnit,lowerDateInterval,lowerDateTimeCompareOperator,higherDateCalenderUnit,higherDateInterval,higherDateTimeCompareOperator,patientHistoryList )
  }


  /**
    * This function verifies if the communication starts after  end of  of current element / encounter date
    * @param visit current patient visit
    * @param m measure property
    * @param trusBiopsyElement represents current element name/ encounter date to be checked in current element
    * @param communicationElement represents history element to be checked in history
    * @param lowerDateCalenderUnit lower date calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param lowerDateInterval lower calender interval to be checked
    * @param lowerDateTimeCompareOperator time comparator unit (valid units are {GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL})
    * @param higherDateCalenderUnit higher date calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param higherDateInterval higher calender interval to be checked
    * @param higherDateTimeCompareOperator time comparator unit (valid units are CompareOperator.{GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL})
    * @param patientHistoryList patient history list
    * @return returns true if the communication starts after  end of  of current element / encounter date else returns false
    */
  def wasCommunicationDoneStartsAfterEndOfWithinXPeriod(visit: CassandraRow, m: MeasureProperty,trusBiopsyElement:String, communicationElement: String,lowerDateCalenderUnit:String, lowerDateInterval: Int,lowerDateTimeCompareOperator:String,higherDateCalenderUnit:String, higherDateInterval: Int,higherDateTimeCompareOperator:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementStartsAfterEndOfWithinXPeriod(visit,m,trusBiopsyElement, communicationElement,lowerDateCalenderUnit,lowerDateInterval,lowerDateTimeCompareOperator,higherDateCalenderUnit,higherDateInterval,higherDateTimeCompareOperator,patientHistoryList )
  }

 /* /**
    * This function verifies if diagnostic study performed starts before start of procedure
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement procedure element name to be checked in current record
    * @param patientHistoryList patient history list
    * @param diagnosticStudyElement diagnostic study element to be checked in history
    * @return returns true if diagnostic study performed starts before start of procedure else returns false
    */
  def diagnosticStudyPerformedStartsBeforeStartOfProcedure(visit:CassandraRow,m:MeasureProperty,procedureElement:String,patientHistoryList: Broadcast[List[CassandraRow]],diagnosticStudyElement:String*): Boolean ={
    wasElementPresentBeforeOrEqualOtherElement(visit,m,procedureElement,patientHistoryList,diagnosticStudyElement)
  }*/

  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param patientHistoryList medication order patient history list
    * @param historyElementName medication order element name
    * @return if medication Order Before Start date of measurement period
    */

  def wasMedicationOrderBefore(visit: CassandraRow, m: MeasureProperty,  patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: String*): Boolean = {
    wasElementPresentBeforeStartDate(visit, m,  patientHistoryList, historyElementName)
  }

  /**
    * This function verifies if lab test performed during procedure with method
    * @param visit current patient visit
    * @param m measure property
    * @param labTestElement to be checked on current visit
    * @param procedureElement to be checked on current visit
    * @param methodElementName to be checked on current visit
    * @return returns true if lab test performed during procedure with method else returns false
    */
  def isLabTestPerformedDuringProcedureWithMethod(visit:CassandraRow,m:MeasureProperty,labTestElement:String,procedureElement:String,methodElementName:String): Boolean ={
    Seq(labTestElement,procedureElement,methodElementName).forall(element=>dataTypeOnEncounter(visit,m,element))
  }

  /**
    * This function verifies if intervention performed during procedure with method and intervention result will be compared
    * @param visit current patient visit
    * @param m measure property
    * @param interventionElement to be checked on current visit
    * @param procedureElement to be checked on current visit
    * @param methodElementName to be checked on current visit
    * @param result result to be compared
    * @param resultFlag result flag is used in comparison of result of intervention and specified result value
    * @return returns true if intervention performed during procedure with method and intervention result will be compared else returns false
    */
  def isInterventionPerformedWithResultDuringProcedureWithMethod(visit:CassandraRow,m:MeasureProperty,interventionElement:String,procedureElement:String,methodElementName:String,result:Double,resultFlag:String): Boolean ={
    Seq(interventionElement,procedureElement,methodElementName).forall(element=>dataTypeOnEncounter(visit,m,element)) && compareValueStatus(visit.getDouble(interventionElement),resultFlag,result)
  }


  /**
    * This function verifies if diagnosis performed during procedure with method
    * @param visit current patient visit
    * @param m measure property
    * @param diagnosisElement to be checked on current visit
    * @param procedureElement to be checked on current visit
    * @param methodElementName to be checked on current visit
    * @return returns true if diagnosis performed during procedure with method else returns false
    */
  def isDiagnosisDuringProcedureWithMethod(visit:CassandraRow,m:MeasureProperty,diagnosisElement:String,procedureElement:String,methodElementName:String): Boolean ={
    Seq(diagnosisElement,procedureElement,methodElementName).forall(element=>dataTypeOnEncounter(visit,m,element))
  }

  /**
    * This function verifies if diagnostic study performed during procedure with method
    * @param visit current patient visit
    * @param m measure property
    * @param diagnosticStudyElement to be checked on current visit
    * @param procedureElement to be checked on current visit
    * @param methodElementName to be checked on current visit
    * @return returns true if diagnostic study performed during procedure with method else returns false
    */
  def isDiagnosticStudyPerformedDuringProcedureWithMethod(visit:CassandraRow,m:MeasureProperty,diagnosticStudyElement:String,procedureElement:String,methodElementName:String): Boolean ={
    Seq(diagnosticStudyElement,procedureElement,methodElementName).forall(element=>dataTypeOnEncounter(visit,m,element))
  }


  /**
    * This function verifies if procedure performed during encounter with method
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement to be checked on current visit
    * @param methodElementName to be checked on current visit
    * @return returns true if procedure performed during encounter with method else returns false
    */
  def isProcedurePerformedWithMethodDuringEncounter(visit:CassandraRow,m:MeasureProperty,procedureElement:String,methodElementName:String): Boolean ={
    Seq(procedureElement,methodElementName).forall(element=>dataTypeOnEncounter(visit,m,element))
  }


  /**
    * This function verifies if diagnostic study performed during procedure with method and intervention result will be compared
    * @param visit current patient visit
    * @param m measure property
    * @param diagnosticStudyElement to be checked on current visit
    * @param procedureElement to be checked on current visit
    * @param methodElementName to be checked on current visit
    * @param result result to be compared
    * @param resultFlag result flag is used in comparison of result of intervention and specified result value
    * @return returns true if diagnostic study performed during procedure with method and intervention result will be compared else returns false
    */
  def isDiagnosticStudyPerformedWithResultDuringProcedureWithMethod(visit:CassandraRow,m:MeasureProperty,diagnosticStudyElement:String,procedureElement:String,methodElementName:String,result:Double,resultFlag:String): Boolean ={
    Seq(diagnosticStudyElement,procedureElement,methodElementName).forall(element=>dataTypeOnEncounter(visit,m,element)) && compareValueStatus(visit.getDouble(diagnosticStudyElement),resultFlag,result)
  }

  /**
    * This function verifies if assessment performed during procedure with method and intervention result will be compared
    * @param visit current patient visit
    * @param m measure property
    * @param assessmentElement to be checked on current visit
    * @param procedureElement to be checked on current visit
    * @param methodElementName to be checked on current visit
    * @param result result to be compared
    * @param resultFlag result flag is used in comparison of result of intervention and specified result value
    * @return returns true if assessment performed during procedure with method and intervention result will be compared else returns false
    */
  def isAssessmentPerformedDuringProcedureWithMethod(visit:CassandraRow,m:MeasureProperty,assessmentElement:String,procedureElement:String,methodElementName:String,result:Double,resultFlag:String): Boolean ={
    Seq(assessmentElement,procedureElement,methodElementName).forall(element=>dataTypeOnEncounter(visit,m,element)) && compareValueStatus(visit.getDouble(assessmentElement),resultFlag,result)
  }

  /**
    * This function verifies if procedure performed during measurement period and procedure element date is equal with method element date
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement to be checked during measurement period
    * @param methodElement to be checked on current record
    * @param patientHistoryList patient history list
    * @return returns true if procedure performed during measurement period and procedure element date is equal with method element date else returns false
    */
  def isProcedurePerformedWithMethod(visit:CassandraRow,m:MeasureProperty,procedureElement:String,methodElement:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    checkElementDuringMeasurementPeriod(visit, m, procedureElement,patientHistoryList ) && isDateEqual(visit,m,procedureElement+"_date",methodElement+"_date")
  }

  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param elementName communication element name
    * @param patientHistoryList patient history list for communication provider
    * @return if isCommunicationFromProviderToPatient
    */

  def isCommunicationFromProviderToPatientNotDone(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
     checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }



  /**
    *
    * @param visit patient current visit
    * @param m measure property
    * @param elementName communication element name
    * @param patientHistoryList patient history list for communication provider
    * @return if isCommunicationFromProviderToPatient
    */

  def isCommunicationFromPatientToProvider(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }

  def isDiagnosedBeforeProcedure(visit:CassandraRow, m:MeasureProperty, currentElement:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:String*):Boolean= {
    wasElementPresentBeforeOrEqualOtherElement(visit,m, currentElement,CompareOperator.LESS_EQUAL, patientHistoryList,historyElementName)
  }


  /**
    * This function verifies if medication starts before end of other procedure and medication distinct count is compared with count specified
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement element to be checked in current record
    * @param countValue count value to be compared
    * @param compareFlag used to compare count value with value specified
    * @param patientHistoryList patient history list
    * @param medicationElement elements to be checked in history
    * @return returns true if medication starts before end of other procedure and medication distinct count is compared with count specified else returns false
    */

  def countOfMedicationStartsBeforeEndOfProcedure(visit: CassandraRow, m: MeasureProperty, procedureElement: String, countValue: Double,compareFlag: String, patientHistoryList: Broadcast[List[CassandraRow]],medicationElement:String*): Boolean ={
    countOfElementStartsBeforeEndOfOtherElement(visit,m,procedureElement,countValue,compareFlag,patientHistoryList,medicationElement)
  }


  def wasProcedurePerformedInHistoryBeforeXPeriodFromOtherProcedure(visit: CassandraRow, m: MeasureProperty, currentElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]], historyElements: String*): Boolean = {
    historyElements.exists(historyElement => wasElementPresentInHistoryBeforeXPeriodFromOtherElement(visit, m, currentElement, historyElement,CalenderUnit, interval,patientHistoryList))
  }

  /**
    * This function verifies the age of the patient on first date of the element.
    * @param visit patient current  visit
    * @param m measure property
    * @param firstDateElement  first Date Element form history
    * @param compareYears age years that has to be compared
    * @param flag CompareOperator from element master
    * @param firstPatientHistoryList first date patient history list
    * @return it will return true if age on the history element is according to compare years else false
    */
  def wasAgeonFirstDate(visit: CassandraRow, m: MeasureProperty,firstDateElement:String,compareYears:Int,flag:String,firstPatientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasAgeOnHistoryDate(visit, m,firstDateElement,compareYears,flag,firstPatientHistoryList)
  }


  def isProcedurePerformedBeforeOtherProcedureInXYears(visit: CassandraRow, m: MeasureProperty, currentElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]], historyElements: String*): Boolean = {
    historyElements.exists(historyElement => wasElementBeforeElementInXPeriodes(visit, m, currentElement, historyElement,CalenderUnit, interval,patientHistoryList))
  }

  def isDignosedBeforeProcedureInXYears(visit: CassandraRow, m: MeasureProperty, currentElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]], historyElements: String*): Boolean = {
    historyElements.exists(historyElement => wasElementBeforeElementInXPeriodes(visit, m, currentElement, historyElement,CalenderUnit, interval,patientHistoryList))
  }

  def isDignosedAfterProcedureInXYears(visit: CassandraRow, m: MeasureProperty, currentElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]], historyElements: String*): Boolean = {
    historyElements.exists(historyElement => wasElementAfterElementInXPeriodes(visit, m, currentElement, historyElement,CalenderUnit, interval,patientHistoryList))
  }

  def isProcedurePerformedAfterOtherProcedureInXYears(visit: CassandraRow, m: MeasureProperty, currentElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]], historyElements: String*): Boolean = {
    historyElements.exists(historyElement => wasElementAfterElementInXPeriodes(visit, m, currentElement, historyElement,CalenderUnit, interval,patientHistoryList))

  }

  /**
    * this function return true if no of DAYS , WEEK etc result will be ls,gt etc after lookup from consecutive list based on flag condition
    * @param visit Cassandra visit
    * @param m  measure property
    * @param medicationElement medication start element
    * @param result no of DAY,WEEK etc that need to checked in list
    * @param resultFlag like ge lt etc
    * @param CommulativeList list which conatin cummulative list
    * @return true if no of DAYS WEEK etc result will be ls,gt etc after lookup from consecutive list based on flag condition
    */
  def getConsecutiveResult(visit: CassandraRow,m: MeasureProperty,medicationElement:String,result: Double,resultFlag:String,CommulativeList: Broadcast[List[(String,String, Double)]]):Boolean={

    CommulativeList.value.exists(x => x._1.equals(visit.getString("patentuid")) && x._2.equals(medicationElement) && compareValueStatus(x._3,resultFlag,result))

  }


  /**
    * this function return true if no of DAYS , WEEK etc result will be ls,gt etc after lookup from consecutive list based on flag condition
    * @param visit Cassandra visit
    * @param m  measure property
    * @param medicationElement medication start element
    * @param result no of DAY,WEEK etc that need to checked in list
    * @param resultFlag like ge lt etc
    * @param ConsecutiveList list which conatin cummulative list
    * @return true if no of DAYS WEEK etc result will be ls,gt etc after lookup from consecutive list based on flag condition
    */
  def getCommulativeResult(visit: CassandraRow,m: MeasureProperty,medicationElement:String,result: Double,resultFlag:String,ConsecutiveList:Broadcast[List[(String,String, Double)]]):Boolean={
    ConsecutiveList.value.exists(x => x._1.equals(visit.getString("patentuid")) && x._2.equals(medicationElement) && compareValueStatus(x._3,resultFlag,result))
  }


  def isDiagnosticStudyPerformedWithResultConcurrent(visit:CassandraRow,m:MeasureProperty,Element1:String,Element2:String,ResultElement1:String,ResultElement2:String): Boolean ={
    checkNotNull(visit,Element1,Element2,Element1+"_date",Element2+"_date",ResultElement1,ResultElement1+"_date") && isDateEqual(visit,m,Element1+"_date",Element2+"_date") && isDateEqual(visit,m,ResultElement1+"_date",Element1+"_date") && isDateEqual(visit,m,ResultElement2+"_date",Element2+"_date")

  }

  def isProcedurePerformedWithResultDuingDiagnosticStudyWithMethod(visit:CassandraRow,m:MeasureProperty,Element1:String,Element2:String,ResultElement1:String,ResultElement2:String): Boolean ={
    checkNotNull(visit,Element1,Element2,Element1+"_date",Element2+"_date",ResultElement1,ResultElement1+"_date") && isDateEqual(visit,m,Element1+"_date",Element2+"_date") && isDateEqual(visit,m,ResultElement1+"_date",Element1+"_date") && isDateEqual(visit,m,ResultElement2+"_date",Element2+"_date")

  }

  def isDiagnosticStudyPerformedWithMethod(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String, TimeOperator:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    compareTwoElementDuringMeasurementPeriod(visit, m, historyElement1, historyElement2, TimeOperator, patientHistoryList)

  }


  def isProcedurePerformedBeforeOtherProcedureInXYears(visit: CassandraRow, m: MeasureProperty, currentElement: String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]], historyElements: String*): Boolean = {
    historyElements.exists(historyElement => wasElementBeforeElementInXPeriodes(visit, m, currentElement, historyElement,CalenderUnit.YEAR, interval,patientHistoryList))
  }

  def isDignosedBeforeProcedureInXYears(visit: CassandraRow, m: MeasureProperty, currentElement: String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]], historyElements: String*): Boolean = {
    historyElements.exists(historyElement => wasElementBeforeElementInXPeriodes(visit, m, currentElement, historyElement,CalenderUnit.YEAR, interval,patientHistoryList))
  }

  def isDignosedAfterProcedureInXYears(visit: CassandraRow, m: MeasureProperty, currentElement: String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]], historyElements: String*): Boolean = {
    historyElements.exists(historyElement => wasElementAfterElementInXPeriodes(visit, m, currentElement, historyElement,CalenderUnit.YEAR, interval,patientHistoryList))
  }

  def isProcedurePerformedAfterOtherProcedureInXYears(visit: CassandraRow, m: MeasureProperty, currentElement: String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]], historyElements: String*): Boolean = {
    historyElements.exists(historyElement => wasElementAfterElementInXPeriodes(visit, m, currentElement, historyElement,CalenderUnit.YEAR, interval,patientHistoryList))
  }

  def wasProcedurePerformedInHistoryBeforeXPeriodFromOtherProcedure(visit: CassandraRow, m: MeasureProperty, currentElement: String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]], historyElements: String*): Boolean = {
    historyElements.exists(historyElement => wasElementPresentInHistoryBeforeXPeriodFromOtherElement(visit, m, currentElement, historyElement,CalenderUnit.YEAR, interval,patientHistoryList))
  }

  def isInterventionPerformedFirstDuringMeasurementPeriod(visit: CassandraRow, m:MeasureProperty, leastRecentpatientHistoryList:Broadcast[List[CassandraRow]], historyElements: String*): Boolean ={
    historyElements.exists(historyElement => checkElementDuringMeasurementPeriod(visit, m,  historyElement, leastRecentpatientHistoryList))
  }

  def isCommunicationDoneFromProvidertoProviderAfterInterventionFirst(visit: CassandraRow, m: MeasureProperty,leastRecentElements: Seq[String],patientHistoryList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList: Broadcast[List[CassandraRow]],historyElements: String*):Boolean={
    leastRecentElements.exists(l => wasFirstElementDateAfterOtherElementDateInHistory(visit, m,l,patientHistoryList,leastRecentpatientHistoryList,historyElements))
  }

  def wasAssessmentPerformedBeforeMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, patientHistoryList: Broadcast[List[CassandraRow]], historyElements: String*): Boolean = {
    historyElements.exists(historyElement => wasElementPresentBeforeStartOfMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, historyElement: String,patientHistoryList: Broadcast[List[CassandraRow]]))
  }

  def wasMedicationAdministeredBeforeSurgerytInXHours(visit: CassandraRow, m: MeasureProperty, currentElement: Seq[String], calenderUnit:String, calenderInterval: Int, timeCompareOperator:String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: String*): Boolean = {
    currentElement.exists(element => wasElementPresentBeforeInXPeriods(visit, m, element, calenderUnit, calenderInterval, timeCompareOperator, patientHistoryList, historyElementName))
  }

  def isImmunizationAdministered(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
       checkElementDuringMeasurementPeriod(visit, m, elementName, patientHistoryList)
  }

  def isInterventionPerformedOnEncounter(r: CassandraRow, measureProperty: MeasureProperty, elements: String*): Boolean = {
    elements.exists(element => dataTypeOnEncounter(r, measureProperty, element))
  }

  /**
    * This function verifies laboratory test is performed before or equal on encounter.
    * @param visit current visit of the patient.
    * @param m measure property
    * @param laboratoryElement laboratory test element
    * @param patientHistoryList patient history list
    * @return it will return true if laboratory test is performed before or equal on encounter else false.
    */
  def wasLaboratoryTestPerformedBeforeOrEqualEncounter(visit:CassandraRow, m:MeasureProperty, laboratoryElement:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean= {
    isElementPresentBeforeOrEqualEncounter(visit: CassandraRow, m, laboratoryElement, patientHistoryList)
  }

  //QPP434 functions

  def wasProcedurePerformedBeforeOrEqualEndInMonths(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentBeforeOrEqualEndInMonths(visit, m, histroyElement, month, patientHistoryList)
  }


  def wasDiagnosisEqualWithProcedureInHistory(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String, dataType:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    compareTwoElementInHistory(visit, m, historyElement1, historyElement2,dataType, patientHistoryList)
  }

  /**
    * This function verifies if procedure is performed after X months of another procedure.
    * @param visit current patient visit
    * @param m measure property of the measure
    * @param CurrentElement Current Element that has to be verified.
    * @param histElement    history Element that has to be verified in the history
    * @param noOfMonths    number of x months that will go back in the history.
    * @param patientHistoryList Patient history list
    * @return It will return true if procedure is performed after X months of another procedure.
    */
  def wasDiagnosedAfterXMonthsOfProcedure(visit:CassandraRow,m:MeasureProperty,CurrentElement:String,histElement:String,noOfMonths:Int,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasProcedurePerformedXMonthsAfterDiagnosis(visit,m,CurrentElement,histElement,noOfMonths,patientHistoryList)
  }


  /**
    * This function verifies if procedure is performed after X months of another procedure.
    * @param visit current patient visit
    * @param m measure property of the measure
    * @param CurrentElement Current Element that has to be verified.
    * @param histElement    history Element that has to be verified in the history
    * @param noOfMonths    number of x months that will go back in the history.
    * @param patientHistoryList Patient history list
    * @return It will return true if procedure is performed after X months of another procedure.
    */
  def wasPatientCharacteristicAfterXMonthsOfProcedure(visit:CassandraRow,m:MeasureProperty,CurrentElement:String,histElement:String,noOfMonths:Int,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    wasProcedurePerformedXMonthsAfterDiagnosis(visit,m,CurrentElement,histElement,noOfMonths,patientHistoryList)
  }


  //QPP445 Function



  def wasPatientCharacteristicAfterOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, historyElement: String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterEncounterBeforeEnd(visit: CassandraRow, m, historyElement, patientHistoryList)
  }

  def wasPatientCharacteristicAfterEncounterWithinXPeriod(visit: CassandraRow, m: MeasureProperty, elementName: String,lowerDateCalenderUnit:String, lowerDateInterval: Int,lowerDateTimeCompareOperator:String,higherDateCalenderUnit:String, higherDateInterval: Int,higherDateTimeCompareOperator:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementEndsAfterStartOfWithinXPeriodInMeasurementPeriod(visit, m, elementName,lowerDateCalenderUnit, lowerDateInterval,lowerDateTimeCompareOperator,higherDateCalenderUnit, higherDateInterval,higherDateTimeCompareOperator,patientHistoryList)
  }


  def wasPatientCharacteristicEqualEncounterInHistory(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String,dataType: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    compareTwoElementInHistory(visit, m, historyElement1, historyElement2,dataType, patientHistoryList)
  }


  //446 Functions
  def isPatientExpired(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    checkElementDuringMeasurementPeriod(visit:CassandraRow, m:MeasureProperty, elementName:String, patientHistoryList:Broadcast[List[CassandraRow]])
  }

  def isPatientExpiredBeforeDischarge(visit:CassandraRow, m:MeasureProperty, CurrentEncounterDate:String, patientHistoryList:Broadcast[List[CassandraRow]],PatientExpiry:String,Discharge:String*):Boolean= {
    val xc = PatientExpiry.mkString("")
    wasElementPresentAfter(visit, m, CurrentEncounterDate, patientHistoryList,Seq(PatientExpiry)) && wasElementPresentAfter(visit, m, xc, patientHistoryList,Discharge)
  }


  def isPatientExpiredAfterDischarge(visit:CassandraRow, m:MeasureProperty, CurrentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],historyElementName:String*):Boolean= {
    wasElementPresentAfter(visit, m, CurrentElementDate, patientHistoryList,historyElementName)
  }

  def isPatientExpiredAfterProcedureWithInXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementInXPeriodes(visit, m, currentElement, historyElement,CalenderUnit, interval,patientHistoryList)
  }

  def wasProcedurePerformedBeforeStartDateInXMonths(visit: CassandraRow, m: MeasureProperty, element1: String, CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementBetweenXPeriod(visit, m, element1, CalenderUnitTo, intervalTo,CalenderUnitFrom, intervalFrom,patientHistoryList)
  }

  def isTransferTo(visit:CassandraRow, m:MeasureProperty, element: String, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    checkElementDuringMeasurementPeriod(visit, m,  element, patientHistoryList)
  }

  def isCommunicationBeforeMedicationAndAssessment(visit: CassandraRow,m: MeasureProperty,communicationElement:String,assessmentElement:String,medicationElement:String,result: Double,resultFlag:String,CommulativeList: Broadcast[List[(String,String, Double)]], patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={

    (( getConsecutiveResult(visit,m,medicationElement,result,resultFlag,CommulativeList) &&

      compareTwoElementDuringMeasurementPeriod(visit,m,communicationElement,medicationElement,TimeOperator.BEFORE,patientHistoryList))

      ||  compareTwoElementDuringMeasurementPeriod(visit,m,communicationElement,assessmentElement,TimeOperator.BEFORE,patientHistoryList))
  }

  /**
    * This function verifies if the element starts after end within X period with result
    * @param visit current patient visit
    * @param m measure property
    * @param labTestElement lab test element
    * @param timeCompareOperator time compare operator (valid operators are ge,le,gt,lt,eq)
    * @param calenderUnit calender unit (valid are YEAR,MONTH,WEEK,DAY,HOUR,MINUTES)
    * @param calenderInterval calender interval in integer
    * @param result result to be checked
    * @param resultCompareFlag result compare flag is used to compare result(le,ge,lt,gt,eq)
    * @param patientHistoryList patient history list
    * @return returns true if the element starts after end within X period with result else returns false
    */
  def wasLabTestEndsAfterStartWithinPeriodWithResult(visit:CassandraRow,m:MeasureProperty,labTestElement:String,timeCompareOperator:String,calenderUnit:String,calenderInterval:Int=0,result:Double,resultCompareFlag:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementEndsAfterStartWithinXPeriodWithResult(visit,m,labTestElement,timeCompareOperator,calenderUnit,calenderInterval,result,resultCompareFlag,patientHistoryList)
  }


  /**
    * This function verifies if medication  overlaps procedure
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement to be checked in current record
    * @param patientHistoryList patient history list
    * @param medicationElement to be checked in history record
    * @return returns true if medication  overlaps procedure else returns false
    */
  def wasMedicationBeforeEqualProcedure(visit: CassandraRow, m:MeasureProperty,procedureElement :String, patientHistoryList: Broadcast[ List[CassandraRow] ], medicationElement: String*): Boolean = {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, procedureElement,CompareOperator.LESS_EQUAL, patientHistoryList, medicationElement )
  }


  /**
    * This function verifies diagnosis during procedure .
    * @param visit current patient visit
    * @param m measure property
    * @param diagnosisElement diagnosis element
    * @param procedureElement precedure element
    * @param patientHistoryList patient hoistory list of the patient
    * @return it will return true diagnosis during procedure else false
    */
  def wasDaignosisDuringProcedure(visit: CassandraRow, m: MeasureProperty, diagnosisElement: String, procedureElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasDiagnosedBeforeEndWithLaterality(visit, m, diagnosisElement, procedureElement, patientHistoryList)
  }

  def wasInterventionPerformedAfterOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentAfterOrEqualEncounter(visit, m, elementName, historyElement, patientHistoryList)
  }

  /**
    * This function checks if medication was active starts before X days
    * @param visit current patient visit
    * @param m measure property
    * @param currentElement current elementwasMedicationActiveEndsBeforeInXDays
    * @param days days to be looked before
    * @param timeCompareOperator valid compare operators are (GREATER,LESS,EQUAL,GREATER_EQUAl,LESS_EQUAL)
    * @param patientHistoryList patient history list
    * @param historyElementName history element name
    * @return returns true if  medication was active starts before X days else returns false
    */
  def  wasMedicationActiveEndsBeforeInXDays(visit: CassandraRow, m: MeasureProperty, currentElement: String, days: Int,timeCompareOperator:String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: Seq[String]): Boolean ={
    wasElementPresentBeforeInXPeriods(visit,m,currentElement,CalenderUnit.DAY,days,timeCompareOperator,patientHistoryList,historyElementName)
  }



  def isLaboratoryTestPerformedBeforeWithinXDays(visit: CassandraRow, m: MeasureProperty, CurrentElementName: String,HistoryElementName: String,  day:Int,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    checkElementPresentBeforeOtherElementWithinXDays(visit, m, HistoryElementName, CurrentElementName, day, patientHistoryList)
  }



  def isLaboratoryTestPerformedAfterWithinXDays(visit: CassandraRow, m: MeasureProperty, CurrentElementName: String,HistoryElementName: String,  day:Int,patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementWithinXDays(visit, m, HistoryElementName, CurrentElementName, day, patientHistoryList)
  }


  def wasEncounterPerformed(visit:CassandraRow, m:MeasureProperty, patientHistoryList:Broadcast[List[CassandraRow]],elementNames:String*):Boolean={
    elementNames.exists(elementName => checkElementDuringMeasurementPeriod(visit,m,elementName,patientHistoryList))
  }

  def isInterventionPerformedOverlapsMeasurementPeriod(visit: CassandraRow, m: MeasureProperty,patientHistoryList: Broadcast[List[CassandraRow]],historyElement:String*):Boolean={
    isElementOverlapsMeasurementPeriod(visit, m,patientHistoryList,historyElement)
  }


  def wasAssessmentPerformedAfterDiagnosis(visit: CassandraRow, m: MeasureProperty, HistoryElement1: String, patientHistoryList: Broadcast[List[CassandraRow]], HistoryElement2: String*): Boolean = {
    wasElementPresentAfterOtherElementInHistory(visit: CassandraRow, m: MeasureProperty, HistoryElement1: String, patientHistoryList: Broadcast[List[CassandraRow]], HistoryElement2.toSeq)

  }

  def wasInterventionOrdered(visit:CassandraRow, m:MeasureProperty, patientHistoryList:Broadcast[List[CassandraRow]],elementNames:String*):Boolean={
    elementNames.exists(elementName => checkElementDuringMeasurementPeriod(visit,m,elementName,patientHistoryList))
  }


  /**
    * This function verifies if the physical exam performed result value greater or equal to desired result value on current encounter.
    * @param visit   current visit of the patient
    * @param m       Measure property of the measure
    * @param element Element whose result has to be verified
    * @param value   Required value that has to be compared.
    * @return It will return true whose physical exam performed value greater or equal on encounter else false.
    */
  def isPhysicalExamPerformedValueGreaterOrEqualOnEncounter(visit: CassandraRow, m: MeasureProperty, element: String, value: Double): Boolean = {
  dataTypeOnEncounter(visit,m,element) && compareValueStatus(visit.getDouble(element),CompareOperator.GREATER_EQUAL,value)
  }

  /**
    * This function verifies physical exam performed X period retinal dialted exam with result.
    * @param visit current visit of the patient
    * @param m measure property
    * @param physicalExamPerformed  physical exam performed
    * @param resultElement result element
    * @param NoOfMonth number of months that has to be look back.
    * @param comperatorOperator comperator operator like ge le lt gt etc.
    * @param flag  flag like ge le lt gt etc.
    * @param HistoryList patient history list
    * @return it will return true if physical exam performed X period dialted exam with result.
    */
  def wasPhysicalExamPerformedXPeriodForRetinalDilatedExamWithResult(visit: CassandraRow, m: MeasureProperty, physicalExamPerformed: String, resultElement:String, NoOfMonth: Int,comperatorOperator:String,flag:String, HistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementXPeriodConcurrentWithResult(visit, m, physicalExamPerformed, resultElement, NoOfMonth,comperatorOperator,flag, HistoryList)
  }

  def wasProcedurePerformedBeforeStartInXYears(visit: CassandraRow, m: MeasureProperty, procedureElement: String, interval: Int,unit:String,flag:String,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementBeforeStartDateXPeriod(visit, m, procedureElement, interval,unit,flag,patientHistoryList)
  }

  def wasAssessmentPerformedwithResultAfterEncounterinBetweenXPeriod(visit: CassandraRow, m: MeasureProperty, currentElementName: String, unit: String, flag: String, lowerInterval: Int, higherInterval: Int, historyElement1: String, historyElement2: String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    wasElementPresentBetweenOtherElementBeforeCurrentElement(visit, m, currentElementName, unit, flag, lowerInterval, higherInterval,  historyElement1, historyElement2, patientHistoryList)
  }

  def isLaboratoryTestPerformedWithValueDuringMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, laboratoryTest: String, laboratoryTestResult: String, value: Double, flag:String, mostRecentPatientHistoryList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    isMostRecentResultValueDuringMeasurementPeriod(visit, m, laboratoryTest, laboratoryTestResult, value, flag, mostRecentPatientHistoryList, patientHistoryList)
  }

  def wasEncounterPeformedAfterEncounter(visit:CassandraRow, m:MeasureProperty, CurrentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String*):Boolean= {
    wasElementPresentAfter(visit, m, CurrentElementDate, patientHistoryList,HistoryelementName)
  }


  def wasAssessmentDuringProcedureInHistory(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String,dataType:String ,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    compareTwoElementInHistory(visit, m, historyElement1, historyElement2,dataType ,patientHistoryList)
  }


  def wasProcedureDuringProcedureInHistory(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String,dataType:String ,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    compareTwoElementInHistory(visit, m, historyElement1, historyElement2,dataType ,patientHistoryList)
  }

  def wasDiagnosticStudyPerformedWithValue(visit: CassandraRow, m: MeasureProperty, elementName: String, value: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    checkElementValueDuringMeasurementPeriod(visit, m, elementName, value, flag, patientHistoryList)
  }



  def wasCarePlanAfterDiagnosisWithinXPeriod(visit: CassandraRow, m: MeasureProperty, element1: String,ResultElement: String, historyElement: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementWithResultInBetweenXPeriodes(visit: CassandraRow, m: MeasureProperty, element1: String,ResultElement: String, historyElement: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]])
  }


  def isDiagnosticStudyDuringCarePlanInHistory(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String,dataType:String ,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    compareTwoElementInHistory(visit, m, historyElement1, historyElement2,dataType ,patientHistoryList)
  }


  def wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit: CassandraRow, m: MeasureProperty, element1: String, historyElement: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementInBetweenXPeriodes(visit, m, element1, historyElement,CalenderUnitTo, intervalTo,CalenderUnitFrom, intervalFrom,patientHistoryList)
  }





  /**
    * This function checks if diagnosis element starts after start of measurement period and date is equal with diagnosisEyeElement
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param                          diagnosisEyeElement daignosis eye element
    * @param diagnosisElement     history element which will be checked in history
    *                           @param calenderUnit  valid units are CalenderUnits.x
    * @param calenderInterval              no of calender units to be checked after
    *                                      @param  timeCOperator valid time operators are CompareOperator.x
    * @param patientHistoryList list of patient history
    * @return returns true if diagnosis element starts after start of measurement period and date is equal with diagnosisEyeElement else returns false
    */
def wasDiagnosisStartsAfterStartOfInXPeriod(visit: CassandraRow, m: MeasureProperty,diagnosisEyeElement:String, calenderUnit:String, calenderInterval: Int,timeCOperator:String,patientHistoryList: Broadcast[List[CassandraRow]],diagnosisElement: String): Boolean ={
checkNotNull(visit,diagnosisEyeElement,diagnosisElement) &&
  wasElementPresentAfterStartOfWithinXPeriod(visit,m,"measurement_period_start_date",calenderUnit,calenderInterval,timeCOperator,patientHistoryList,diagnosisElement) &&
  isDateEqual(visit,m,diagnosisEyeElement+"_date",diagnosisElement+"_date")
}


  /**
    * This function checks if physical exam performed starts after start of medication and date is equal with medication
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param                          physicalExamEyeElement physical exam eye element
    * @param physicalExamElement     history element which will be checked in history
    *                           @param calenderUnit  valid units are CalenderUnits.x
    * @param calenderInterval              no of calender units to be checked after
    *                                      @param  timeCOperator valid time operators are CompareOperator.x
    * @param patientHistoryList list of patient history
    * @return returns true if diagnosis element starts after start of measurement period and date is equal with diagnosisEyeElement else returns false
    */
  def wasPhysicalExamPerformedStartsAfterStartOfMedicationInXPeriod(visit: CassandraRow, m: MeasureProperty,medicationElement:String,physicalExamEyeElement:String, calenderUnit:String, calenderInterval: Int,timeCOperator:String,patientHistoryList: Broadcast[List[CassandraRow]],physicalExamElement: String): Boolean ={
    checkNotNull(visit,physicalExamEyeElement,physicalExamElement) &&
      wasElementPresentAfterStartOfWithinXPeriod(visit,m,medicationElement,calenderUnit,calenderInterval,timeCOperator,patientHistoryList,physicalExamElement) &&
      isDateEqual(visit,m,physicalExamEyeElement+"_date",physicalExamElement+"_date")
  }

  /**
    * This function verifies if physical exam performed starts before start of diagnosis
    * @param r current patient visit
    * @param m measurement property
    * @param diagnosisElement to be checked in current record
    * @param patientHistoryList patient history list
    * @param physicalExamPerformed  to be checked in history
    * @return returns true  if physical exam performed starts before start of diagnosis else returns false
    */
  def wasPhysicalExamPerformedStartsBeforeStartOfDiagnosis(r: CassandraRow, m:MeasureProperty, diagnosisElement:String, patientHistoryList: Broadcast[ List[CassandraRow] ], physicalExamPerformed: String*): Boolean = {

    wasElementPresentBeforeOrEqualOtherElement(r, m, diagnosisElement,CompareOperator.LESS_EQUAL, patientHistoryList, physicalExamPerformed )
  }

  /**
    * This function checks if diagnosis element starts after start of medication within X period else returns false
    *
    * @param visit current visit
    * @param m measure property
    * @param diagnosisElement history element which will be checked in history
    * @param medicationElement to be checked in current record
    * @param calenderUnit valid units are CalenderUnits.x
    * @param calenderInterval no of calender units to be checked after
    * @param timeCOperator valid time operators are CompareOperator.x
    * @param patientHistoryList list of patient history
    * @return returns true if diagnosis element starts after start of medication within X period else returns false
    */
  def wasDiagnosisStartsAfterStartOfMedicationInXPeriod(visit: CassandraRow, m: MeasureProperty,medicationElement:String,calenderUnit:String, calenderInterval: Int,timeCOperator:String,patientHistoryList: Broadcast[List[CassandraRow]],diagnosisElement: String): Boolean ={
    checkNotNull(visit,medicationElement,medicationElement+"_date") &&
      wasElementPresentAfterStartOfWithinXPeriod(visit,m,medicationElement,calenderUnit,calenderInterval,timeCOperator,patientHistoryList,diagnosisElement)
  }
  def isMostRecentLaboratoryTestPerformed(visit:CassandraRow,measureProperty:MeasureProperty,laboratoryTest:String,mostRecentPatientHistoryList:Broadcast[List[CassandraRow]] ): Boolean ={
    checkElementDuringMeasurementPeriod(visit,measureProperty,laboratoryTest,mostRecentPatientHistoryList)
  }

  def wasDiagnosedAfterStartOfMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, patientHistoryList: Broadcast[List[CassandraRow]], diagnoses: String*): Boolean ={
    diagnoses.exists(diagnosis => wasElementPresentAfterStartDate(visit: CassandraRow, m: MeasureProperty, diagnosis: String, patientHistoryList: Broadcast[List[CassandraRow]]))
  }


  /**
    * This function verifies the diagnosis is after X period after procedure
    * @param visit current visit of the patient
    * @param m measure property
    * @param procedureElement that has to checked in the current visit
    * @param period number of days that has to be add in the procedure element
    * @param patientHistoryList patient history list
    * @param historyElement that has to be verified in the history
    * @return it will return true if diagnosis is after X period from current date else false.
    */
  def wasDiagnosisAfterXPeriodProcedure(visit: CassandraRow, m: MeasureProperty,procedureElement:String,period:Int,flag:String,patientHistoryList: Broadcast[List[CassandraRow]],historyElement:String*):Boolean= {
    checkNotNull(visit,procedureElement,procedureElement+"_date") &&
      wasElementBeforeXPeriodCurrentElement(visit, m,flag,procedureElement,period,patientHistoryList,historyElement)
  }

  def wasAssesmentPerformedOverlapsProcedurePerformedInHistory(visit: CassandraRow, m: MeasureProperty,diagnosisElement1:String,diagnosisElement2:String,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    wasElementOverlapsElement(visit, m,diagnosisElement1,diagnosisElement2,patientHistoryList)
  }

  def wasAssesmentValueGreaterOrEqualBeforeProcedurePerformed(visit: CassandraRow, m: MeasureProperty, currentElement: String, histElement: String, flag: String, value: Double, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasInterventionValueGreaterOrEqualBeforeProcedurePerformed(visit: CassandraRow, m: MeasureProperty, currentElement: String, histElement: String, flag: String, value: Double, patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasAssessmentPerformedBeforeProcedurePerformed(visit:CassandraRow, m:MeasureProperty, CurrentElementDate:String, patientHistoryList:Broadcast[List[CassandraRow]],HistoryelementName:String*):Boolean= {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, CurrentElementDate,CompareOperator.LESS, patientHistoryList,HistoryelementName)
  }

  def wasMedicationAdministeredWithEyeAfterDiagnosis(visit: CassandraRow, m: MeasureProperty,medicationElement:String,medicationEye:String,calenderUnit:String, calenderInterval: Int,timeCOperator:String,patientHistoryList: Broadcast[List[CassandraRow]],diagnosisElement: String): Boolean ={
    checkNotNull(visit,medicationElement,medicationElement+"_date") &&
      wasElementPresentAfterStartOfWithinXPeriodWithResult(visit,m,medicationElement,medicationEye,calenderUnit,calenderInterval,timeCOperator,patientHistoryList,diagnosisElement)
  }

  def wasPhysicalExamPerformedAfterEncounterBetweenXPeriodes(visit: CassandraRow, m: MeasureProperty, element1: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementBetweenXPeriod(visit, m, element1,CalenderUnitTo, intervalTo,CalenderUnitFrom, intervalFrom,patientHistoryList)
  }


  def wasPhysicalExamPerformedBeforeAndAfterEncounter(visit: CassandraRow, m: MeasureProperty, currentElement:String,histroyElement: String,
                                                      lowerCalenderUnit: String,lowerInterval: Int,higherCalenderUnit: String,HigherInterval: Int,
                                                      valueDifference:Double, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    CheckEyeElementValueDiffInBeforeAndAfterEncounter(visit, m, currentElement,histroyElement,
      lowerCalenderUnit,lowerInterval,higherCalenderUnit,HigherInterval,
      valueDifference, patientHistoryList)
  }


  def isPhysicalExamPerformedAfterWithinXDays(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElementName:String ,days: Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementWithinXDays(visit, m, elementDate, historyElementName ,days, patientHistoryList)
  }


  def wasPhysicalExamPerformedAfterEncounterBetweenXPeriodesWithValues(visit: CassandraRow, m: MeasureProperty, element1: String,element2: String,flag:String,value:Double ,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterEncounterBetweenXPeriodes(visit, m, element1,element2,flag,value ,CalenderUnitTo, intervalTo,CalenderUnitFrom, intervalFrom,patientHistoryList)
  }



  /**
    *
    * @param visit patient current visit
    * @param m measurement property
    * @param historyElement history element
    * @param month minus months from history element
    * @param patientHistoryList patient history list
    * @return if Element Present Start Or Equal With In Months
    */

  def isDiagnosedWithinXMonths(visit: CassandraRow, m: MeasureProperty, historyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    //wasElementPresentStartOrEqualWithInMonths(visit, m, histroyElement, month, patientHistoryList)
    wasElementPresentAfterStartOfWithinXPeriod(visit,m,"measurement_period_start_date",CalenderUnit.MONTH,month,CompareOperator.LESS_EQUAL,patientHistoryList,historyElement)

  }



  def isMedicalBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, element:String, patientHistoryList:Broadcast[List[CassandraRow]], historyElement: String*): Boolean = {
    wasElementPresentBeforeOrEqualOtherElement(r, MeasureProperty, element, CompareOperator.LESS_EQUAL, patientHistoryList,historyElement)
  }
  def isProcedureBeforeOrEqual(r: CassandraRow, MeasureProperty:MeasureProperty, element:String, patientHistoryList:Broadcast[List[CassandraRow]], historyElement: String*): Boolean = {
    wasElementPresentBeforeOrEqualOtherElement(r, MeasureProperty, element, CompareOperator.LESS_EQUAL, patientHistoryList,historyElement)
  }

  def getEncounterCountInBetweenFromHistory(visit: CassandraRow, m: MeasureProperty, countFrom: Int,countTO: Int, countElementList: List[(String, Int)]): Boolean = {


    countElementList.exists(r => r._1.equalsIgnoreCase(visit.getString("patientuid")) && r._2 >= countFrom && r._2 <= countTO )

  }

  def  wasPhysicalExamPresentBeforeFirstAndAfterMostElementInHistory(visit: CassandraRow, m: MeasureProperty, eyeElement:String,patientHistoryList: Broadcast[List[CassandraRow]],leastRecentList: Broadcast[List[CassandraRow]],mostRecentList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementPresentBeforeFirstAndAfterMostElementInHistory(visit, m, eyeElement,patientHistoryList,leastRecentList,mostRecentList)
  }


  def isPhysicalExamPerformedValue(visit:CassandraRow, m:MeasureProperty, elementName:String, value:Double, flag:String, patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    checkElementValueDuringMeasurementPeriod(visit, m, elementName, value, flag, patientHistoryList)
  }


  def wasVaccinatedXTimes(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String, calenderUnit: String, startDays: Int, endDays: Int, count: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    ElementCountAfterDobBetweenXDays(visit: CassandraRow, m: MeasureProperty, historyElement1, historyElement2, calenderUnit, startDays, endDays, count, patientHistoryList)
  }

  def wasDiagnosedInXDaysAfterBirthDate(visit: CassandraRow, m: MeasureProperty,  historyElementName: String, calenderUnit:String, calenderInterval: Int, CompareOperator:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    wasElementAfterElementDateWithinXPeriod(visit, m, AdminElements.Date_of_Birth, historyElementName, calenderUnit, calenderInterval, CompareOperator, patientHistoryList)
  }

  def  wasImmunizationPerformedInXDaysAfterBirthDate(visit: CassandraRow, m: MeasureProperty, historyElementName: String, calenderUnit:String, calenderInterval: Int, CompareOperator:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    wasElementAfterElementDateWithinXPeriod(visit, m, AdminElements.Date_of_Birth, historyElementName, calenderUnit, calenderInterval, CompareOperator, patientHistoryList)
  }

  def wasProcedurePerformedInXDaysAfterBirthDate(visit: CassandraRow, m: MeasureProperty,  historyElementName: String, calenderUnit:String, calenderInterval: Int, CompareOperator:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    wasElementAfterElementDateWithinXPeriod(visit, m, AdminElements.Date_of_Birth, historyElementName, calenderUnit, calenderInterval, CompareOperator, patientHistoryList)
  }

  def wasLaboratoryTestWithResultInXDaysAfterBirthDate(visit: CassandraRow, m: MeasureProperty,  historyElementName: String, calenderUnit:String, calenderInterval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementDateWithinXPeriod(visit, m,AdminElements.Date_of_Birth, historyElementName, calenderUnit, calenderInterval, "eq", patientHistoryList: Broadcast[List[CassandraRow]])
  }

  def wasLaboratoryTestWithResultInXDaysAfterBirthDate(visit: CassandraRow, m: MeasureProperty,  historyElementName: String, result:Double, resultFlag:String, calenderUnit:String, calenderInterval: Int, patientHistoryList: Broadcast[List[CassandraRow]]) :Boolean ={
    wasElementAfterElementDateWithResultWithinXPeriod(visit, m, AdminElements.Date_of_Birth, historyElementName, result, resultFlag, calenderUnit, calenderInterval, patientHistoryList)
  }

  def wasMedicationAfterEncounterBetweenXPeriodes(visit: CassandraRow, m: MeasureProperty, element1: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementBetweenXPeriod(visit, m, element1,CalenderUnitTo, intervalTo,CalenderUnitFrom, intervalFrom,patientHistoryList)
  }

  /**
    * This function verifies if physical exam performed starts before start of refractive surgery
    * @param visit current patient visit
    * @param m measure property
    * @param refractiveElement refractive element
    * @param refractiveEyeElement refractive eye element
    * @param patientHistoryList patient history list
    * @param physicalExamElement to be checked in history
    * @return returns true if physical exam performed starts before start of refractive surgery else returns false
    */
  def wasPhysicalExamPerformedStartsBeforeStartOfRefractiveSurgery(visit:CassandraRow,m:MeasureProperty,refractiveElement:String,refractiveEyeElement:String,patientHistoryList: Broadcast[List[CassandraRow]],physicalExamElement:String*): Boolean ={
  checkNotNull(visit,refractiveElement,refractiveElement+"_date") &&
    wasElementPresentBeforeOrEqualOtherElement(visit,m,refractiveElement,CompareOperator.LESS_EQUAL,patientHistoryList,physicalExamElement) &&
  isDateEqual(visit,m,refractiveElement+"_date",refractiveEyeElement+"_date")
}

  def isLabTestPerformed(visit:CassandraRow,measureProperty:MeasureProperty,patientHistoryList: Broadcast[List[CassandraRow]],labTestElements:String*): Boolean ={
    labTestElements.exists(labTestElement =>checkElementDuringMeasurementPeriod(visit,measureProperty,labTestElement,patientHistoryList))
  }

  def wasMedicationAdministeredBeforeEncounterWithinXHours(visit: CassandraRow, m: MeasureProperty, medicationElement: String, hours: Int, patientHistoryList: Broadcast[List[CassandraRow]], encounterElement: String*): Boolean = {
    wasElementBeforeElementWithinXHoursCurrentElementList(visit, m, medicationElement, hours, patientHistoryList, encounterElement)
  }


  /**
    * This function verifies if physical exam performed starts after start of refractive surgery
    * @param visit current patient visit
    * @param m measure property
    * @param refractiveElement refractive element
    * @param actualEyeElement actual eye element
    * @param calenderUnit
    * @param calenderInterval
    * @param patientHistoryList patient history list
    * @param physicalExamElement to be checked in history
    * @return returns true if physical exam performed starts after start of refractive surgery else returns false
    */
  def wasPhysicalExamPerformedStartsAfterStartOfRefractiveSurgery(visit:CassandraRow,m:MeasureProperty,refractiveElement:String,actualEyeElement:String,calenderUnit:String,calenderInterval:Int,patientHistoryList: Broadcast[List[CassandraRow]],physicalExamElement:String): Boolean ={
    checkNotNull(visit,refractiveElement,refractiveElement+"_date") &&
      wasElementPresentAfterStartOfWithinXPeriod(visit,m,refractiveElement,calenderUnit,calenderInterval,CompareOperator.LESS_EQUAL,patientHistoryList,physicalExamElement) &&
      isDateEqual(visit,m,refractiveElement+"_date",actualEyeElement+"_date")
  }



  /**
    * This function verifies if refractive surgery performed before quarter end date in X days
    * @param visit current patient visit
    * @param m measure property
    * @param refractiveElement refractive element
    * @param refractiveEyeElement refractive eye element
    * @param calenderInterval
    * @param patientHistoryList patient history list
    * @return returns true if refractive surgery performed before quarter end date in X days else returns false
    */
  def wasSurgeryPerformedBeforeEndInXDays(visit:CassandraRow,m:MeasureProperty,refractiveElement:String,refractiveEyeElement:String,calenderInterval:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    checkNotNull(visit,refractiveElement,refractiveElement+"_date") &&
      isProcedurePerformedXDaysBeforeEnd(visit,m,refractiveElement,calenderInterval) &&
      isDateEqual(visit,m,refractiveElement+"_date",refractiveEyeElement+"_date")
  }


  /**
    * This function gives the list and count of the particular patientuid before or equal to the end of the measurement period.
    * @param historyRdd history record of the patient
    * @param m measure property
    * @param element element whose count has to be checked.
    * @return it will give the list of patientuid and their count.
    */
  def countElementBeforeOrEqualEnd(historyRdd: RDD[CassandraRow], m: MeasureProperty, element: String*): List[(String, Int)] = {
    val countRdd = historyRdd.filter(r =>
      dateStatus(r.getDateTime(2),m.quarterEndDate,CompareOperator.LESS_EQUAL)
        && element.toList.contains(r.getString(1).toLowerCase()))
      .map(z => (z.getString("patientuid"), 1)).reduceByKey(_ + _)
      .collect().toList
    countRdd
  }

  def areBothDiagnosesOnSameDate(visit: CassandraRow, measureProperty: MeasureProperty, element1: String, element2: String): Boolean = {
    isDateEqual(visit, measureProperty, element1 + "date", element2 + "_date")
  }

  def isCommunicationFromProvidertoProviderNotdoneAfterOrEqualEncounter(visit:CassandraRow,m:MeasureProperty,elementName:String,patientHistoryList: Broadcast[List[CassandraRow]],historyElement:String): Boolean ={
    wasElementPresentAfterOrEqualEncounter(visit, m, elementName,historyElement, patientHistoryList)
  }
  def  wasCommunicationFromProvidertoProviderAfterOrEqualDiagnosisAndBeforeEnd(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElement: String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementAfterElementBeforeEnd(visit, m, elementName, historyElement,patientHistoryList)
  }

  def wasCommunicationFromPatientToProviderAfterDiagnosisListWithInXMonths(visit: CassandraRow, m: MeasureProperty, historyElement: String, months: Int, patientHistoryList:Broadcast[List[CassandraRow]],elementName: String*): Boolean = {
    wasElementAfterElementListWithinXMonths(visit, m, historyElement, months, patientHistoryList,elementName)
  }


  /**
    * This function verifies the procedure is performed after or equal diagnosis before or equal end Date.
    * @param visit current visit of the patient
    * @param m measure property
    * @param diagnosisElement diagnosis element
    * @param procedureElement procedure element
    * @param patientHistoryList patient history list
    * @return it will return true if procedure is after or equal diagnosis and before  end
    */
   def wasProcedurePerformedAfterOrEqualDiagnosisAndBeforeOrEqualEnd(visit:CassandraRow,m:MeasureProperty,diagnosisElement:String,procedureElement:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
     wasElementAfterOrEqualElementDateAndBeforeOrEqualEnd(visit,m,diagnosisElement,procedureElement,patientHistoryList)
   }

  def isMedicationIntoleranceDuringEncounter(visit: CassandraRow, m:MeasureProperty, elements:String*): Boolean ={
    elements.exists(element => dataTypeOnEncounter(visit: CassandraRow, m, element))
  }

  def isMedicationAllergyDuringEncounter(r: CassandraRow, measureProperty: MeasureProperty, elements: String*): Boolean = {
    elements.exists(element => dataTypeOnEncounter(r: CassandraRow, measureProperty, element))
  }



  /**
    * This function verifies if medication ordered after medication within X period
    * @param visit current patient visit
    * @param m measure property
    * @param medicationElements medication elements
    * @param calendarUnit valid calender units are CalenderUnit.x
    * @param calendarInterval no of interval to be checked
    * @param patientHistoryList patient history list
    * @return returns true if medication ordered after medication within X period else returns false
    */
def wasMedicationOrderedAfterMedicationWithinXPeriod(visit:CassandraRow, m:MeasureProperty, medicationElements:Seq[String], calendarUnit:String, calendarInterval:Int, patientHistoryList:Broadcast[List[CassandraRow]]): Boolean ={
  medicationElements.exists(medicationElement=>wasMedicationOrderedAfterMedicationWithinXPeriod(visit, m, medicationElement, calendarUnit, calendarInterval, patientHistoryList:Broadcast[List[CassandraRow]],medicationElement))
}

  /**
    * This function verifies physical exam performed X period retinal dialted exam with result.
    * @param visit current visit of the patient
    * @param m measure property
    * @param assessmentPerformed   performed
    * @param resultElement result element
    * @param NoOfMonth number of months that has to be look back.
    * @param comperatorOperator comperator operator like ge le lt gt etc.
    * @param flag  flag like ge le lt gt etc.
    * @param HistoryList patient history list
    * @return it will return true if assessment performed X period dialted exam with result.
    */
  def wasAssessmentPerformedXPeriodForRetinalDilatedExamWithResult(visit: CassandraRow, m: MeasureProperty, assessmentPerformed: String, resultElement:String, NoOfMonth: Int,comperatorOperator:String,flag:String, HistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasElementXPeriodConcurrentWithResult(visit, m, assessmentPerformed, resultElement, NoOfMonth,comperatorOperator,flag, HistoryList)
  }




  /** This Function verifies the Assessment performed of patient for Retinal Dilated.
   *
    * @param visit current visit of the patient.
    * @param m   Measure Property of the measure.
    * @param assessmentElement assessment element
    * @param NoOfMonth No of months that has to be go back
    * @param flag      comperator flag
    * @param HistoryList   Patient History List.
    * @return  This Function verifies those patient whose Retinal dialted Exam is performed in a range between start of the measurement period and start date minus no. of months
    */
  def wasAssessmentPerformedXForRetinalDilatedExam(visit: CassandraRow, m: MeasureProperty, assessmentElement: String, NoOfMonth: Int,flag:String,HistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    wasPhysicalExamPerformedXForRetinalDilatedExam(visit, m, assessmentElement, NoOfMonth,flag ,HistoryList)
  }


  /**
    * This function checks if encounterElement is present in future between  procedure  element's date range
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement to be checked in current record
    * @param encounterElement to be checked in future
    * @param daysInterval1 days1 to be looked after
    * @param daysInterval2 days2 to be looked after
    * @param patientHistoryBroadcastList patient history broadcast list
    * @return returns true if encounterElement is present in future between  procedure  element's date range else returns false
    */
  def wasEncounterPerformedAfterProcedureWithinRange(visit:CassandraRow,m:MeasureProperty,procedureElement:String,encounterElement:String,daysInterval1:Int,daysInterval2:Int,patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementPresentInFutureOfHistoryElementBetweenRange(visit,m,procedureElement,encounterElement,daysInterval1,daysInterval2,patientHistoryBroadcastList)
  }


  /**
    * This function checks if interventionElement is present in future between  procedureElement's date range
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement to be checked in current record
    * @param interventionElement to be checked in future
    * @param daysInterval1 days1 to be looked after
    * @param daysInterval2 days2 to be looked after
    * @param patientHistoryBroadcastList patient history broadcast list
    * @return returns true if interventionElement is present in future between  procedureElement's date range else returns false
    */
  def wasInterventionPerformedAfterProcedureWithinRange(visit:CassandraRow,m:MeasureProperty,procedureElement:String,interventionElement:String,daysInterval1:Int,daysInterval2:Int,patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementPresentInFutureOfHistoryElementBetweenRange(visit,m,procedureElement,interventionElement,daysInterval1,daysInterval2,patientHistoryBroadcastList)
  }

  /**
    * This function checks if procedureElement2 is present in future between  procedureElement1's date range
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement1 to be checked in current record
    * @param procedureElement2 to be checked in future
    * @param daysInterval1 days1 to be looked after
    * @param daysInterval2 days2 to be looked after
    * @param patientHistoryBroadcastList patient history broadcast list
    * @return returns true if procedureElement2 is present in future between  procedureElement1's date range else returns false
    */
  def wasProcedurePerformedAfterProcedureWithinRange(visit:CassandraRow,m:MeasureProperty,procedureElement1:String,procedureElement2:String,daysInterval1:Int,daysInterval2:Int,patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementPresentInFutureOfHistoryElementBetweenRange(visit,m,procedureElement1,procedureElement2,daysInterval1,daysInterval2,patientHistoryBroadcastList)
  }

  /**
    * This function checks if diagnosedElement is present in future between  procedure  element's date range
    * @param visit current patient visit
    * @param m measure property
    * @param procedureElement to be checked in current record
    * @param diagnosedElement to be checked in future
    * @param daysInterval1 days1 to be looked after
    * @param daysInterval2 days2 to be looked after
    * @param patientHistoryBroadcastList patient history broadcast list
    * @return returns true if diagnosedElement is present in future between  procedure  element's date range else returns false
    */
  def wasDiagnosedAfterProcedureWithinRange(visit:CassandraRow,m:MeasureProperty,procedureElement:String,diagnosedElement:String,daysInterval1:Int,daysInterval2:Int,patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): Boolean ={
    wasElementPresentInFutureOfHistoryElementBetweenRange(visit,m,procedureElement,diagnosedElement,daysInterval1,daysInterval2,patientHistoryBroadcastList)
  }

}
