package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp425
* Measure Title              :- Photodocumentation of Cecal Intubation
* Measure Description        :- The rate of screening and surveillance colonoscopies for which photodocumentation of at least two landmarks of
                                cecal intubation is performed to establish a complete examination
*
* Calculation Implementation :- Procedure-specific(Visit-Specific)
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Sawant
*
** Commented GIQUIC related code,need to uncomment in future
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp425 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp425"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession,initialRDD,
     QPP425Elements.Screening_Or_Surveillance_Colonoscopy_73_74
     ,QPP425Elements.Post_Surgical_Anatomy_Rh_Ir
     ,QPP425Elements.Post_Surgical_Anatomy
     ,QPP425Elements.Photo_Documentation_Of_Cecal_Intubation_Not_Met

    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      // Eligible IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  /*-------------------------------------------------------------------------------------------------------------------------
  Patients for whom a screening or surveillance colonoscopy was performed
  * ----------------------------------------------------------------------------------------------------------------------------*/
  //IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
     (     isProcedurePerformedDuringEncounter(visit, m, QPP425Elements.Screening_Or_Surveillance_Colonoscopy)
        && !isEncounterPerformed(visit, m, QPP425Elements.Screening_Or_Surveillance_Colonoscopy_73_74, patientHistoryBroadcastList)
     )//IPP upto here only : without GIQUIC
       /*
     ||
     (
        (    isDiagnosticStudyPerformedWithMethod(visit,m,QPP425Elements.Colonoscopy_Type,QPP425Elements.Colon_Cancer_Screening)
          || isDiagnosticStudyPerformedWithMethod(visit,m,QPP425Elements.Colonoscopy_Type,QPP425Elements.Surveillance)
        )
        &&
        (    isDiagnosticStudyPerformedWithResultConcurrent(visit,m,QPP425Elements.Bowel_Prep_Quality,QPP425Elements.Colonoscopy_Type,QPP425Elements.Adequate,QPP425Elements.Colon_Cancer_Screening)
          || isDiagnosticStudyPerformedWithResultConcurrent(visit,m,QPP425Elements.Bowel_Prep_Quality,QPP425Elements.Colonoscopy_Type,QPP425Elements.Adequate,QPP425Elements.Surveillance)
        )
     )*/
    )
  }
  /*-------------------------------------------------------------------------------------------------------------------------
  Documentation of post-surgical anatomy (e.g., right hemicolectomy, ileocecal resection, etc.)
* ----------------------------------------------------------------------------------------------------------------------------*/
  // Denominator Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
    (   wasProcedurePerformedEndsBeforeStartOf(visit,m,QPP425Elements.Screening_Or_Surveillance_Colonoscopy,patientHistoryBroadcastList,QPP425Elements.Post_Surgical_Anatomy_Rh_Ir)
     || isProcedurePerformed(visit, m, QPP425Elements.Post_Surgical_Anatomy, patientHistoryBroadcastList)
     || isDiagnosisPerformedDuringProcedurePerformed(visit,m,QPP425Elements.No_Cecum,QPP425Elements.No_Cecum_Date,QPP425Elements.Screening_Or_Surveillance_Colonoscopy,QPP425Elements.Screening_Or_Surveillance_Colonoscopy_Date)
    )//Exclusion upto here only : without GIQUIC (GIQUIC element has datatype issue integer/Decimal, we need tinyInt datatype)
     /*
   ||
   (
      (  isProcedurePerformedWithResultDuingDiagnosticStudyWithMethod(visit,m,QPP425Elements.Time_Between_Insertion_And_Reaching_Cecum,QPP425Elements.Colonoscopy_Type,QPP425Elements.No_Cecum,QPP425Elements.Colon_Cancer_Screening)
      || isProcedurePerformedWithResultDuingDiagnosticStudyWithMethod(visit,m,QPP425Elements.Time_Between_Insertion_And_Reaching_Cecum,QPP425Elements.Colonoscopy_Type,QPP425Elements.No_Cecum,QPP425Elements.Surveillance)
      || isProcedurePerformedWithResultDuingDiagnosticStudyWithMethod(visit,m,QPP425Elements.Time_Between_Insertion_And_Reaching_Cecum,QPP425Elements.Colonoscopy_Type,QPP425Elements.Hemicolectomy,QPP425Elements.Colon_Cancer_Screening)
      || isProcedurePerformedWithResultDuingDiagnosticStudyWithMethod(visit,m,QPP425Elements.Time_Between_Insertion_And_Reaching_Cecum,QPP425Elements.Colonoscopy_Type,QPP425Elements.Hemicolectomy,QPP425Elements.Surveillance)
      )
    ||
      (  isProcedurePerformedWithResultDuingDiagnosticStudyWithMethod(visit,m,QPP425Elements.Withdrawal_Time_From_Cecum,QPP425Elements.Colonoscopy_Type,QPP425Elements.No_Cecum,QPP425Elements.Colon_Cancer_Screening)
      || isProcedurePerformedWithResultDuingDiagnosticStudyWithMethod(visit,m,QPP425Elements.Withdrawal_Time_From_Cecum,QPP425Elements.Colonoscopy_Type,QPP425Elements.No_Cecum,QPP425Elements.Surveillance)
      || isProcedurePerformedWithResultDuingDiagnosticStudyWithMethod(visit,m,QPP425Elements.Withdrawal_Time_From_Cecum,QPP425Elements.Colonoscopy_Type,QPP425Elements.Hemicolectomy,QPP425Elements.Colon_Cancer_Screening)
      || isProcedurePerformedWithResultDuingDiagnosticStudyWithMethod(visit,m,QPP425Elements.Withdrawal_Time_From_Cecum,QPP425Elements.Colonoscopy_Type,QPP425Elements.Hemicolectomy,QPP425Elements.Surveillance)
      )
   ) */
   )
  }
  /*-------------------------------------------------------------------------------------------------------------------------
   Number of patients undergoing screening or surveillance colonoscopy who have photodocumentation of at least two
   landmarks of cecal intubation to establish a complete examination
 * ----------------------------------------------------------------------------------------------------------------------------*/
  // Numerator Criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
    (
         isProcedurePerformedDuringEncounter(visit, m, QPP425Elements.Photo_Documentation_Of_Cecal_Intubation)
            // || Count >= 2 : "Procedure, Performed: Photodocumentation of Cecal Landmarks" during "Procedure, Performed: Screening or Surveillance Colonoscopy"
      && !isProcedurePerformed(visit, m, QPP425Elements.Photo_Documentation_Of_Cecal_Intubation_Not_Met, patientHistoryBroadcastList)
    ) //Met upto here only : without GIQUIC (GIQUIC element has datatype issue integer/Decimal, we need tinyInt datatype)
     /*
   ||
    (
      (
        (    isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Ileocecal_Valve_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Colon_Cancer_Screening)
         ||  isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Ileocecal_Valve_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Surveillance)
        )
        &&
        (    isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Appendiceal_Orifice_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Colon_Cancer_Screening)
         ||  isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Appendiceal_Orifice_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Surveillance)
        )
      )
      ||
      (
        (    isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Ileocecal_Valve_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Colon_Cancer_Screening)
         ||  isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Ileocecal_Valve_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Surveillance)
        )
        &&
        (    isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Terminal_Ileum_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Colon_Cancer_Screening)
         ||  isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Terminal_Ileum_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Surveillance)
        )
      )
      ||
      (
        (    isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Appendiceal_Orifice_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Colon_Cancer_Screening)
         ||  isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Appendiceal_Orifice_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Surveillance)
        )
        &&
        (    isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Terminal_Ileum_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Colon_Cancer_Screening)
         ||  isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Terminal_Ileum_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Surveillance)
        )
      )
      ||
      (
        (    isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Terminal_Ileum_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Colon_Cancer_Screening)
         ||  isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Terminal_Ileum_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Surveillance)
        )
        &&
        (    isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Appendiceal_Orifice_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Colon_Cancer_Screening)
         ||  isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Appendiceal_Orifice_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Surveillance)
        )
        &&
        (    isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Ileocecal_Valve_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Colon_Cancer_Screening)
         ||  isDiagnosticStudyPerformedConcurrentWithDignosticMethod(visit,m,QPP425Elements.Ileocecal_Valve_Photographed,QPP425Elements.Colonoscopy_Type,QPP425Elements.Surveillance)
        )
      )
    ) */
  )
  }
}
