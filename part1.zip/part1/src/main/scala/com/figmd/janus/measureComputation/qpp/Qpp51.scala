package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP51Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP51
* Measure Title              :- Chronic Obstructive Pulmonary Disease (COPD): Spirometry Evaluation
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of COPD who had spirometry results documented
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp51 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP51"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP51Elements.Chronic_Obstructive_Pulmonary_Disease
      , QPP51Elements.Spirometry_Results_Documented_And_Reviewed
      , QPP51Elements.Fev1__Fvc_Lnc
      , QPP51Elements.Fev1
      , QPP51Elements.Fev1__Fvc
      , QPP51Elements.Fev1_Lnc
      , QPP51Elements.Spirometry_Reason_Not_Specified
      , QPP51Elements.Spirometry_Medical_Reason
      , QPP51Elements.Medical_Reason
      , QPP51Elements.Patient_Reason
      , QPP51Elements.Spirometry_Patient_Reason
      , QPP51Elements.Spirometry_System_Reason
      , QPP51Elements.System_Reason
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exceptions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateRDD = getSubtractRDD(denominatorRDD,metRDD)
      intermediateRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateRDD, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  /*
  All patients aged 18 and older with a diagnosis of COPD
  */

  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
      isPatientAdult(visit,m)
        && isEncounterPerformedOnEncounter(visit,m, QPP51Elements.Office_Visit)
        && wasDiagnosedInHistory(visit, m, QPP51Elements.Chronic_Obstructive_Pulmonary_Disease,patientHistoryBroadcastList)
        && !isEncounterPerformedOnEncounter(visit,m, QPP51Elements.Office_Visit_Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP51Elements.Pos_02)
    )
  }

  //Patients with documented spirometry results in the medical record (FEV1 and FEV1/FVC)

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        wasDiagnosticStudyPerformedInHistory(visit,m,QPP51Elements.Spirometry_Results_Documented_And_Reviewed,patientHistoryBroadcastList)
        &&(
               wasDiagnosticStudyPerformedInHistory(visit,m,QPP51Elements.Fev1,patientHistoryBroadcastList)
            || wasDiagnosticStudyPerformedInHistory(visit,m,QPP51Elements.Fev1_Lnc,patientHistoryBroadcastList)
            || wasDiagnosticStudyPerformedInHistory(visit,m,QPP51Elements.Fev1__Fvc,patientHistoryBroadcastList)
            || wasDiagnosticStudyPerformedInHistory(visit,m,QPP51Elements.Fev1__Fvc_Lnc,patientHistoryBroadcastList)
          )
      )&& ! wasDiagnosticStudyPerformedInHistory(visit,m,QPP51Elements.Spirometry_Reason_Not_Specified,patientHistoryBroadcastList)
    )
  }
  /*
Documentation of medical reason(s) for not documenting and reviewing spirometry results.
OR
Documentation of patient reason(s) for not documenting and reviewing spirometry results.
OR
Documentation of system reason(s) for not documenting and reviewing spirometry results.
   */

  def getException(intermedaiateRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermedaiateRdd.filter(visit =>
      wasDiagnosticStudyPerformedInHistory(visit,m,QPP51Elements.Spirometry_Medical_Reason,patientHistoryBroadcastList)
      || wasDiagnosticStudyPerformedInHistory(visit,m,QPP51Elements.Medical_Reason,patientHistoryBroadcastList)
      || wasDiagnosticStudyPerformedInHistory(visit,m,QPP51Elements.Spirometry_Patient_Reason,patientHistoryBroadcastList)
      || wasDiagnosticStudyPerformedInHistory(visit,m,QPP51Elements.Patient_Reason,patientHistoryBroadcastList)
      || wasDiagnosticStudyPerformedInHistory(visit,m,QPP51Elements.Spirometry_System_Reason,patientHistoryBroadcastList)
      || wasDiagnosticStudyPerformedInHistory(visit,m,QPP51Elements.System_Reason,patientHistoryBroadcastList)
    )

  }

}
