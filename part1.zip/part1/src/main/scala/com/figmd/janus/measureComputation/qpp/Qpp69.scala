package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP130Elements, QPP69Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.qpp.Qpp130.{EXCEPTION, MEASURE_NAME, isActionNotPerformedWithReasonDuringEncounter}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp69
* Measure Title              :- Hematology: Multiple Myeloma: Treatment with Bisphosphonates
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of multiple myeloma, not in remission, who were prescribed or received intravenous bisphosphonate therapy within the 12 month reporting period
* Calculation Implementation :- Patient Specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp69 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp69"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP


    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      //getPatientHistoryList
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        QPP69Elements.Bisphosphonate_Intravenous_Therapy_Cpt,
        QPP69Elements.Intravenous_Bisphosphonate_Therapy,
        QPP69Elements.Iv_Bisphosphonate_Therapy_Reason_Not_Specified
      ).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()


      val intermediateA = getSubtractRDD(denominatorRDD, metRDD)
      intermediateA.cache()


      val exceptionRDD = getException(intermediateA, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()
      //

      // Filter Exceptions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      isPatientAdult(visit, m)
        &&
        isVisitTypeIn(visit, m,
          QPP69Elements.Office_Visit,
          QPP69Elements.Outpatient_Consultation
        )
        && isDiagnosedOnEncounter(visit, m, QPP69Elements.Multiple_Myeloma)
        && !isVisitTypeIn(visit, m,
        QPP69Elements.Office_Visit_Telehealth_Modifier,
        QPP69Elements.Outpatient_Consultation_Telehealth_Modifier
      )
        & !isVisitTypeIn(visit, m, QPP69Elements.Pos_02)
    )
  }


  // Numerator criteria
  /* Patients who were prescribed or received intravenous bisphosphonate therapy within the 12 month reporting period */

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        isInterventionPerformed(visit, m, QPP69Elements.Bisphosphonate_Intravenous_Therapy_Cpt, patientHistoryBroadcastList)
          ||
          isMedicationOrdered(visit, m, patientHistoryBroadcastList, QPP69Elements.Intravenous_Bisphosphonate_Therapy)
          ||
          isMedicationAdministered(visit, m, QPP69Elements.Intravenous_Bisphosphonate_Therapy, patientHistoryBroadcastList)
        )
        && !isInterventionPerformed(visit, m, QPP69Elements.Iv_Bisphosphonate_Therapy_Reason_Not_Specified, patientHistoryBroadcastList)
    )
  }


  /*Documentation of medical reason(s) for not prescribing bisphosphonates (eg, patients who do not have bone
  disease, patients with dental disease, patients with renal insufficiency.
  OR
  Documentation of patient reason(s) for not prescribing bisphosphonates.
  */

  def getException(intermediateRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateRdd.filter(visit =>

      (isDiagnosedWithInHistory(visit, m, QPP69Elements.Renal_Insufficiency, patientHistoryBroadcastList)
        || isDiagnosedWithInHistory(visit, m, QPP69Elements.Dental_Disease, patientHistoryBroadcastList)
        )
        || !isInterventionPerformedOnEncounter(visit, m, QPP69Elements.Iv_Bisphosphonate_Therapy_Patient_Reason)
        || !isInterventionPerformedOnEncounter(visit, m, QPP69Elements.Iv_Bisphosphonate_Therapy_Medical_Reason)
        || !isDiagnosedWithInHistory(visit, m, QPP69Elements.Bone_Disease, patientHistoryBroadcastList)

    )
  }
}
