package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, MeasureProperty, QPP402Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 402
* Measure Title              :- Tobacco Use and Help with Quitting Among Adolescents
* Measure Description        :- The percentage of adolescents 12 to 20 years of age with a primary care visit during the
*                               measurement year for whom tobacco use status was documented and received help with quitting
*                               if identified as a tobacco user
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp402 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp402"


  //Patient History List
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()


      val getPatientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        QPP402Elements.Advice_To_Quit_Smoking_Or_Tobacco_Use,
        QPP402Elements.Assistance_With_Or_Referral_Cessation_Programs,
        QPP402Elements.Cessation_Counselling,
        QPP402Elements.Currently_Tobacco_Non_User,
        QPP402Elements.Enrollment_In_Cessation_Programs,
        QPP402Elements.Tobacco_Assessment_Reason_Not_Specified,
        QPP402Elements.Tobacco_Non_User,
        QPP402Elements.Tobacco_Use_Cessation_Counseling,
        QPP402Elements.Tobacco_Use_Screening,
        QPP402Elements.Tobacco_User_And_Tobacco_Cessation,
        QPP402Elements.Tobacco_User)
      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryRDD.collect().toList)


      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()


      //Filter Not Met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  // IPP-Denominator criteria
  /*-------------------------------------------------------------------------------------------------------------------
    All patients aged 12-20 years with a visit during the measurement period
-------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 12)
        &&
        isAgeBelow(visit, m, false, 21)
        &&
        isVisitTypeIn
        (visit, m,
          QPP402Elements.Office_Visit,
          QPP402Elements.Health___Behavioral_Assessment___Individual,
          QPP402Elements.Health_And_Behavioral_Assessment__Reassessment,
          QPP402Elements.Health_And_Behavioral_Assessment___Initial,
          QPP402Elements.Ophthalmological_Services,
          QPP402Elements.Annual_Wellness_Visit,
          QPP402Elements.Psychoanalysis,
          QPP402Elements.Psych_Visit___Diagnostic_Evaluation,
          QPP402Elements.Smoking_And_Tobacco_Use_Cessation_Counseling_Visit,
          QPP402Elements.Psychotherapy_For_Crisis,
          QPP402Elements.Psych_Visit___Psychotherapy,
          QPP402Elements.Occupational_Therapy_Evaluation
        )
    )
  }

  // Numerator criteria
  /*-------------------------------------------------------------------------------------------------------------------
 	Patients who were screened for tobacco use at least once within 18 months (during the measurement period or the six
 	months prior to the measurement period) AND who received tobacco cessation counseling intervention if identified
 	as a tobacco user
-------------------------------------------------------------------------------------------------------------------*/
  def getMet(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (
        wasInterventionPerformedBeforeEnd(visit, m, QPP402Elements.Tobacco_User_And_Tobacco_Cessation, CalenderUnit.MONTH, 18, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
          ||
          (
            wasPatientTobaccoUserWithinXMonths(visit, m, QPP402Elements.Tobacco_Use_Screening, QPP402Elements.Tobacco_User, 18, patientHistoryBroadcastList)
              &&
              (
                wasInterventionPerformedBeforeEnd(visit, m, QPP402Elements.Advice_To_Quit_Smoking_Or_Tobacco_Use, CalenderUnit.MONTH, 18, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
                  ||
                  wasInterventionPerformedBeforeEnd(visit, m, QPP402Elements.Assistance_With_Or_Referral_Cessation_Programs, CalenderUnit.MONTH, 18, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
                  ||
                  wasInterventionPerformedBeforeEnd(visit, m, QPP402Elements.Cessation_Counselling, CalenderUnit.MONTH, 18, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
                  ||
                  wasInterventionPerformedBeforeEnd(visit, m, QPP402Elements.Enrollment_In_Cessation_Programs, CalenderUnit.MONTH, 18, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
                  ||
                  wasInterventionPerformedBeforeEnd(visit, m, QPP402Elements.Tobacco_Use_Cessation_Counseling, CalenderUnit.MONTH, 18, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
                )
            )
          ||
          wasInterventionPerformedBeforeEnd(visit, m, QPP402Elements.Currently_Tobacco_Non_User, CalenderUnit.MONTH, 18, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
          ||
          wasPatientTobaccoUserWithinXMonths(visit, m, QPP402Elements.Tobacco_Use_Screening, QPP402Elements.Tobacco_Non_User, 18, patientHistoryBroadcastList)
        )
        &&
        !wasInterventionPerformedBeforeEnd(visit, m, QPP402Elements.Tobacco_Assessment_Reason_Not_Specified, CalenderUnit.MONTH, 18, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
    )
  }
}