package com.figmd.janus.util.measure

import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator
import com.figmd.janus.measureComputation.master.MeasureProperty
import com.figmd.janus.util.application.InputStorageTypeHelper


object PatientHistoryUtility {

  def medication_Active_Till_Encounter(visit: CassandraRow, m: MeasureProperty,medicationElement : String): Unit =
  {
    getPatientHistory(visit.getString("patientId"), medicationElement)

  }

  def medication_Active_Till_Encounter(visit: CassandraRow, m: MeasureProperty): Unit =
  {

  }

  def getPatientHistory(patientId : String, element :String): Boolean =
  {
    val columns = Seq("el")
    val paramSpeChar = InputStorageTypeHelper.getWhereParamSpeChar()
    val whereCql = s"patientuid=$paramSpeChar and element=$paramSpeChar"
    val newRdd = InputStorageTypeHelper.getInputRDD("webdatamart", "patient_history", columns, whereCql, patientId, element)
    var elementCount =newRdd.count()
    if(elementCount > 0)
    {
      true
    }
    else
    {
      false
    }

  }








}
