package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP192Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 192
* Measure Title              :- Cataracts: Complications within 30 Days Following Cataract Surgery Requiring Additional Surgical Procedures
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of uncomplicated
                                cataract who had cataract surgery and had any of a specified list of surgical procedures
                                in the 30 days following cataract surgery which would indicate the occurrence of any of
                                the following major complications: retained nuclear fragments, endophthalmitis,
                                dislocated or wrong power IOL, retinal detachment, or wound dehiscence
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp192 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp192"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession,initialRDD
      ,QPP192Elements.Removal_Of_Lens__56__55_Grp
      ,QPP192Elements.Use_Of_Systemic_Sympathetic_Alpha_1a_Antagonist_Medication_For_Treatment_Of_Prostatic_Hypertrophy
      ,QPP192Elements.Systemic_Sympathetic_Alpha_1a_Antagonist_Medication_Grp
      ,QPP192Elements.Ocular_Complications_Impacting_Surgery
      ,QPP192Elements.Prior_Pars_Plana_Vitrectomy
      ,QPP192Elements.Ocular_Complication_Impacting_Cataract_Surgery_Outcome_Eye
      ,QPP192Elements.Cataract_Surgery_Eye
      ,QPP192Elements.Cataract_Surgery
      ,QPP192Elements.Surgical_Procedure__Met_Grp
      ,QPP192Elements.Major_Complication_Post_Cataract_Surgery
      ,QPP192Elements.Major_Complication_Post_Cataract_Surgery_Eye
      ,QPP192Elements.Surgical_Procedure__Not_Met_Grp
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryRDD,patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      /*exclusion RDD*/
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*------------------------------------------------------------------------------
  All patients aged 18 years and older who had cataract surgery and no significant ocular conditions impacting the
  surgical complication rate
   ------------------------------------------------------------------------------*/

  def getIpp(rdd: RDD[CassandraRow], patientHistoryRDD:RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)


    rdd.filter(visit =>
      isPatientAdult(visit,m)
        &&  isProcedurePerformedDuringEncounter(visit,m,QPP192Elements.Cataract_Surgery)
        &&  !isEncounterPerformed(visit,m,QPP192Elements.Removal_Of_Lens__56__55_Grp,patientHistoryBroadcastList)
    )
  }

  /*------------------------------------------------------------------------------
    Patients with documentation of the presence of one or more of the significant ocular conditions that impact the
    surgical complication rate prior to date of cataract surgery which is still active at the time of the cataract
    surgery are excluded from the measure calculation.
    Significant ocular conditions that impact the surgical complication rate such as:-
    Acute and Subacute Iridocyclitis, Adhesions and Disruptions of Iris and Ciliary Body, Anomalies of Pupillary
    Function, Aphakia and Other Disorders of Lens,Burn Confined to Eye and Adnexa, Cataract Secondary to Ocular Disorders,
    Cataract, Congenital,Cataract, Mature or Hypermature, Cataract, Posterior Polar, Central Corneal Ulcer, Certain
    Types of Iridocyclitis, Chronic Iridocyclitis, Cloudy Cornea,Corneal Edema, Corneal Opacity and Other Disorders of
    Cornea, Cysts of Iris, Ciliary Body, and Anterior Chamber, Enophthalmos, Glaucoma, Hereditary Corneal Dystrophies,
    High Hyperopia, Hypotony of Eye, Injury to Optic Nerve and Pathways, Open Wound of Eyeball, Pathologic Myopia,
    Posterior Lenticonus, Prior Pars Plana Vitrectomy, Pseudoexfoliation Syndrome, Retrolental Fibroplasias, Traumatic
    Cataract, Use of Systemic Sympathetic Alpha-1a Antagonist Medication for Treatment of Prostatic Hypertrophy,
    Uveitis, Vascular Disorders of Iris and Ciliary Body.
   ------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      (
        wasMedicationBeforeorEqualEncounter(visit,m,QPP192Elements.Use_Of_Systemic_Sympathetic_Alpha_1a_Antagonist_Medication_For_Treatment_Of_Prostatic_Hypertrophy,patientHistoryBroadcastList)
          || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP192Elements.Systemic_Sympathetic_Alpha_1a_Antagonist_Medication_Grp,patientHistoryBroadcastList)
          || wasMedicationBeforeorEqualEncounter(visit,m,QPP192Elements.Ocular_Complications_Impacting_Surgery,patientHistoryBroadcastList)
          || wasProcedurePerformedBeforeOrEqualEncounter(visit,m,QPP192Elements.Prior_Pars_Plana_Vitrectomy,patientHistoryBroadcastList)
        )
        && checkEyeElementBeforeDiagnosisEyesElement(visit,m, QPP192Elements.Ocular_Complication_Impacting_Cataract_Surgery_Outcome_Eye,patientHistoryBroadcastList,QPP192Elements.Cataract_Surgery_Eye)
    )
  }

  /*------------------------------------------------------------------------------
    Patients who had one or more specified operative procedures for any of the following major complications within
    30 days following cataract surgery: retained nuclear fragments, endophthalmitis, dislocated or wrong power IOL,
    retinal detachment, or wound dehiscence
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      (   wasAssessmentPerformedAfterRecommended(visit,m,QPP192Elements.Cataract_Surgery,QPP192Elements.Surgical_Procedure__Met_Grp,patientHistoryBroadcastList)
        ||
        checkEyeElementWithinXDays(visit,m
          ,QPP192Elements.Major_Complication_Post_Cataract_Surgery,QPP192Elements.Cataract_Surgery
          ,QPP192Elements.Cataract_Surgery_Eye,30,patientHistoryBroadcastList,QPP192Elements.Major_Complication_Post_Cataract_Surgery_Eye)

        )
        && !wasAssessmentDoneAfterProcedure(visit,m,QPP192Elements.Cataract_Surgery,patientHistoryBroadcastList,QPP192Elements.Surgical_Procedure__Not_Met_Grp)
    )
  }
}