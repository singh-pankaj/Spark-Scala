package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP407Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 407
* Measure Title              :- Appropriate Treatment of Methicillin-Susceptible Staphylococcus Aureus (MSSA) Bacteremia
* Measure Description        :- Percentage of patients with sepsis due to MSSA bacteremia who received beta-lactam antibiotic (e.g. Nafcillin, Oxacillin or Cefazolin) as definitive therapy
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp407 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp407"



  //Patient History List
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryRDD = getPatientHistory(sparkSession,initialRDD,
      QPP407Elements.Sepsis_Due_To_Mssa,
      QPP407Elements.Beta_Lactam_Antibiotic_Grp,
      QPP407Elements.Appropriate_Treatment_Of_Mssa_Beta_Lactam_Antibiotic_Grp,
      QPP407Elements.Beta_Anti_Medical_Reason,
      QPP407Elements.Beta_Lactam_Antibiotic_Documented_Medical_Reason,
      QPP407Elements.Allergy_To_Medication,
      QPP407Elements.Mssa_Beta_Lactam_Antibiotics_Grp
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession,initialRDD,ippRDD,MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()
      val intermediateRDD = getSubtractRDD(denominatorRDD,metRDD)
      intermediateRDD.cache()
      // Filter Denominator Exception
      val exceptionRDD = getException(intermediateRDD, patientHistoryBroadcastList)
      exceptionRDD.cache()

      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateRDD, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  // IPP-Denominator criteria
  def getIpp(rdd: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)
    rdd.filter(visit =>
      isPatientAdult(visit, m)
      && (isDiagnosisOnEncounter(visit, m, QPP407Elements.Sepsis_Due_To_Mssa)
          || wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP407Elements.Sepsis_Due_To_Mssa, patientHistoryList)
        )
      && isVisitTypeIn(visit, m, QPP407Elements.Discharge_Services___Hospital_Inpatient_Same_Day_Discharge,
        QPP407Elements.Hospital_Inpatient_Visit___Initial,
        QPP407Elements.Hospital_Observation_Care___Initial_Grp,
        QPP407Elements.Subsequent_Hospital_Care_Grp,
        QPP407Elements.Critical_Care_Grp)
    )
  }

  // Numerator criteria
  def getMet(ippRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      (isMedicationAdministered(visit, m, QPP407Elements.Beta_Lactam_Antibiotic_Grp, patientHistoryList)
        || wasMedicationDuringDiagnosisInHistory(visit, m, QPP407Elements.Sepsis_Due_To_Mssa, patientHistoryList, QPP407Elements.Appropriate_Treatment_Of_Mssa_Beta_Lactam_Antibiotic_Grp))
      && !isMedicationAdministered(visit, m, QPP407Elements.Beta_Anti_Reason_Not_Specified, patientHistoryList)
    )
  }


  // Denominator Exceptions criteria
  def getException(ippRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,EXCEPTION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      !isMedicationAdministered(visit, m, QPP407Elements.Beta_Anti_Medical_Reason, patientHistoryList)
      || wasMedicationDuringDiagnosisInHistory(visit, m, QPP407Elements.Sepsis_Due_To_Mssa, patientHistoryList, QPP407Elements.Beta_Lactam_Antibiotic_Documented_Medical_Reason)
      || wasMedicationDuringDiagnosisInHistory(visit, m, QPP407Elements.Sepsis_Due_To_Mssa, patientHistoryList, QPP407Elements.Allergy_To_Medication)
      || wasMedicationDuringDiagnosisInHistory(visit, m, QPP407Elements.Sepsis_Due_To_Mssa, patientHistoryList, QPP407Elements.Mssa_Beta_Lactam_Antibiotics_Grp)

    )
  }

}