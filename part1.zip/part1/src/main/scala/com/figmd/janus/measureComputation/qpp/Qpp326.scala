
package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP326Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 326
* Measure Title              :- Atrial Fibrillation and Atrial Flutter: Chronic Anticoagulation Therapy
* Measure Description        :- "Percentage of patients aged 18 years and older with nonvalvular atrial fibrillation (AF) or atrial flutter who were
                                prescribed warfarin OR another FDA-approved oral anticoagulant drug for the prevention of thromboembolism during
                                the measurement period"
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp326 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp326"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP326Elements.Nonvalvular_Atrial_Fibrillation_Or_Atrial_Flutter
      , QPP326Elements.Pneumonia
      , QPP326Elements.Hyperthyroidism
      , QPP326Elements.Cardiac_Surgery
      , QPP326Elements.Transient_Or_Reversible_Cause_Of_Af
      , QPP326Elements.Hospice_Services_Snomedct
      , QPP326Elements.Hospice_Care
      , QPP326Elements.Palliative_Care
      , QPP326Elements.Palliative_Care_Encounter
      , QPP326Elements.Prescription_For_Warfarin
      , QPP326Elements.Prescription_For_Warfarin_Documentation_Grp
      , QPP326Elements.Warfarin_Prescription
      , QPP326Elements.Presc_Warf_Reason_Not_Specified).collect.toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      // Filter notEligible
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      // Filter Intermediate for Met
      val intermediateMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateException = getSubtractRDD(intermediateMet, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateException)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
   All patients aged 18 years and older with a diagnosis of nonvalvular AF or atrial flutter
   who do not have a documented CHA2DS2-VASc risk score of 0 or 1
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m
        , QPP326Elements.Home_Healthcare_Services
        , QPP326Elements.Care_Services_In_Long_Term_Residential_Facility
        , QPP326Elements.Initial_Nursing_Facility
        , QPP326Elements.Nursing_Facility_Visit
        , QPP326Elements.Emergency_Department_Visit
        , QPP326Elements.Office_Visit)
        && wasDiagnosedWithBeforeOrEqualEncounter(visit, m, QPP326Elements.Nonvalvular_Atrial_Fibrillation_Or_Atrial_Flutter, patientHistoryBroadcastList)
        && !isTeleHealthEncounterNotPerformed(visit, m
        , QPP326Elements.Nursing_Facility_Visit_Telehealth_Modifier
        , QPP326Elements.Office_Visit_Telehealth_Modifier
        , QPP326Elements.Domiciliary_Or_Rest_Home_Visit_Telehealth_Modifier
        , QPP326Elements.Initial_Nursing_Facility_Telehealth_Modifiers
        , QPP326Elements.Emergency_Department_Visit_Telehealth_Modifier
        , QPP326Elements.Home_Healthcare_Services_Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP326Elements.Pos_02)
    )
  }

  /*---------------------------------------------------------------------------------------------
   Patient with transient or reversible cause of AF (e.g., pneumonia, hyperthyroidism, pregnancy,
   cardiac surgery) OR Patients who are receiving comfort care only OR Documentation of
   CHA2DS2-VASc risk score of 0 or 1.
   ----------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        wasDiagnosedWithBeforeOrEqualEncounter(visit, m, QPP326Elements.Pneumonia, patientHistoryBroadcastList)
          || wasDiagnosedWithBeforeOrEqualEncounter(visit, m, QPP326Elements.Hyperthyroidism, patientHistoryBroadcastList)
          || isDiagnosedDuringEncounter(visit, m, QPP326Elements.Pregnancy)
          || wasProcedurePerformedBeforeOrEqualEncounter(visit, m, QPP326Elements.Cardiac_Surgery, patientHistoryBroadcastList)
          || wasAssessmentPerformedBeforeOrEqualEncounter(visit, m, QPP326Elements.Transient_Or_Reversible_Cause_Of_Af, patientHistoryBroadcastList)
        )
        ||
        (
          wasInterventionPerformedInHistory(visit, m, QPP326Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
            || wasInterventionPerformedInHistory(visit, m, QPP326Elements.Hospice_Care, patientHistoryBroadcastList)
            || wasInterventionPerformedInHistory(visit, m, QPP326Elements.Palliative_Care, patientHistoryBroadcastList)
            || wasInterventionPerformedInHistory(visit, m, QPP326Elements.Palliative_Care_Encounter, patientHistoryBroadcastList)
          )
        || isInterventionPerformedDuringEncounter(visit, m, QPP326Elements.Comfort_Care)
        || getCHA2DS2VASc(visit, m
        , QPP326Elements.Heart_Failure
        , QPP326Elements.Hypertension
        , QPP326Elements.Diabetes_Mellitus
        , QPP326Elements.Prior_Stroke
        , QPP326Elements.Vascular_Disease
        , AdminElements.Sex) <= 1
        || isAssessmentPerformedDuringEncounter(visit, m, QPP326Elements.Cha2ds2_Vasc_Hcpcs)
        || isAssessmentValueLessOrEqualDuringEncounter(visit, m, QPP326Elements.Cha2ds2_Vasc_Risk_Score, 1)
    )
  }

  /*----------------------------------------------------------------------------------------
   Patients with nonvalvular AF or atrial flutter for whom warfarin or another FDA-approved
   oral anticoagulant was prescribed
   -----------------------------------------------------------------------------------------*/

  def getMet(intermediateMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateMet.filter(visit =>
      (
        isInterventionPerformed(visit, m, QPP326Elements.Prescription_For_Warfarin, patientHistoryBroadcastList)
          || isAssessmentPerformed(visit, m, QPP326Elements.Prescription_For_Warfarin_Documentation_Grp, patientHistoryBroadcastList)
          || isMedicationActiveOrdered(visit, m, QPP326Elements.Warfarin_Prescription, patientHistoryBroadcastList)
        )
        && !isInterventionPerformed(visit, m, QPP326Elements.Presc_Warf_Reason_Not_Specified, patientHistoryBroadcastList)
    )
  }

  /*---------------------------------------------------------------------------------------------------------------------------------------------
    Documentation of medical reason(s) for not prescribing warfarin OR another FDA-approved anticoagulant (e.g., atrial appendage device in place)
    OR
    Documentation of patient reason(s) for not prescribing warfarin OR another FDA-approved oral anticoagulant that is FDA-approved
    for the prevention of thromboembolism (e.g., patient choice of having atrial appendage device placed)
    OR
    Documentation of system reason(s) for not prescribing warfarin OR another FDA-approved anticoagulation
    due to patient being currently enrolled in a clinical trial related to AF/atrial flutter treatment
   ---------------------------------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateException: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>

      isInterventionNotDoneDuringEncounter(visit, m, QPP326Elements.Presc_Warf_Medical_Reason)
        || isInterventionNotDoneDuringEncounter(visit, m, QPP326Elements.Medical_Reason)
        || isInterventionNotDoneDuringEncounter(visit, m, QPP326Elements.Presc_Warf_Patient_Reason)
        || isInterventionNotDoneDuringEncounter(visit, m, QPP326Elements.Patient_Reason)
        || isInterventionNotDoneDuringEncounter(visit, m, QPP326Elements.Af_System_Reason)
        || isInterventionNotDoneDuringEncounter(visit, m, QPP326Elements.System_Reason)
    )
  }
}
