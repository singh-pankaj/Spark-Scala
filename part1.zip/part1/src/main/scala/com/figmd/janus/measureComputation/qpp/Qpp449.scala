package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP449Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 449
* Measure Title              :- HER2 Negative or Undocumented Breast Cancer Patients Spared Treatment with HER2-Targeted Therapies
* Measure Description        :- Percentage of female patients (aged 18 years and older) with breast cancer who are human
                                epidermal growth factor receptor 2 (HER2)/neu negative who are not administered HER2-targeted therapies
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp449 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp449"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP449Elements.Breast_Cancer
      , QPP449Elements.Her_2_Negative_Or_Undocumented_Unknown
      , QPP449Elements.Her_2_Undocumented_Unknown
      , QPP449Elements.Her_2_Negative
      , QPP449Elements.Single_Probe_Average_Her2
      , QPP449Elements.Dual_Probe_Her2_Cep17
      , QPP449Elements.Transfer_To_Practice_After_Initiation_Of_Chemotherapy
      , QPP449Elements.Transferred_To_Practice_After_Initial_Chemotherapy
      , QPP449Elements.Transfer_To_Practice
      , QPP449Elements.Her2_Targeted_Therapies__Met
      , QPP449Elements.Her2_Targeted_Therapies
      , QPP449Elements.Her2_Targeted_Therapies__Not_Met
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      val denominatorRDD=ippRDD
      denominatorRDD.cache()
      /*exclusion RDD*/
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*------------------------------------------------------------------------------
    Adult women with breast cancer that are HER2 negative or HER2 undocumented
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val countElementList: List[(String, Int)] = countElementWithinMonthsInHistory(patientHistoryRDD, m, 12, QPP449Elements.Office_Visit)


    initialRDD.filter(visit =>
      isFemale(visit, m)
        && isPatientAdult(visit, m)
        && wasDiagnosedBeforeEncounter(visit, m, QPP449Elements.Breast_Cancer, patientHistory)
        && getEncounterCountFromHistory(visit, m, 2, true, countElementList)
        &&
        (
          isAssessmentPerformed(visit, m, QPP449Elements.Her_2_Negative_Or_Undocumented_Unknown, patientHistory)
            || isLaboratoryTestOrder(visit, m, QPP449Elements.Her_2_Undocumented_Unknown, patientHistory)
            || isLaboratoryTestOrder(visit, m, QPP449Elements.Her_2_Negative, patientHistory)
            || isLaboratoryTestPerformedValue(visit, m, QPP449Elements.Single_Probe_Average_Her2, 4.0, "lt", patientHistory)
            || isLaboratoryTestPerformedValue(visit, m, QPP449Elements.Dual_Probe_Her2_Cep17, 2.0, "lt", patientHistory)
          )

    )

  }

  /*------------------------------------------------------------------------------
   Patient transferred to practice after initiation of chemotherapy
   ------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      isTransferTo(visit, m, QPP449Elements.Transfer_To_Practice_After_Initiation_Of_Chemotherapy, patientHistory)
        || isTransferTo(visit, m, QPP449Elements.Transferred_To_Practice_After_Initial_Chemotherapy, patientHistory)
        || isTransferTo(visit, m, QPP449Elements.Transfer_To_Practice, patientHistory)
    )
  }

  /*------------------------------------------------------------------------------
   HER2-targeted therapies not administered during the initial course of treatment
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      isMedicationActiveOrdered(visit, m, QPP449Elements.Her2_Targeted_Therapies__Met, patientHistoryList)
        && !(
        isMedicationActiveOrdered(visit, m, QPP449Elements.Her2_Targeted_Therapies, patientHistoryList)
          || isMedicationActiveOrdered(visit, m, QPP449Elements.Her2_Targeted_Therapies__Not_Met, patientHistoryList)
        )
    )

  }
}