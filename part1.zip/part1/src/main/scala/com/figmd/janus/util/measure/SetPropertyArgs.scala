package com.figmd.janus.util.measure

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

import com.datastax.spark.connector.{CassandraRow, ColumnName}
import com.figmd.janus.{MeasureUpdate, MedianTrait}
import com.figmd.janus.WebDataMartCreator._
import com.figmd.janus.util.application._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.DateTime
import com.figmd.janus.util.application.BigTableUtility.toCassandraRowRDD

class SetPropertyArgs(args: Array[String]) {

  /*
    val credentials = new BasicAWSCredentials("AKIAJC2BI34Q3U2RAHKA","TAgxUwck8azCQFSufpC+UW6d/c7Puh7HB2GShRY2")
    val s3Client = AmazonS3ClientBuilder.standard()
      .withCredentials(new AWSStaticCredentialsProvider(credentials))
      .build()

    val s3Object = s3Client.getObject(new GetObjectRequest(args(0),args(1)))
    val myData = Source.fromInputStream(s3Object.getObjectContent).getLines.filter(l => !l.startsWith("#")).toArray

    for(property<- myData){
      val sp = property.split("=")
      val key = sp(0)
      val value = sp(1)
      prop.setProperty(key,value)
      //println(key+" ++>>>> "+ApplicationConfig.prop.getProperty(key))
    }
  */


  /*
    prop.setProperty("wf_id", args(0))
    prop.setProperty("postgresHostName", args(1))
    prop.setProperty("postgresHostPort", args(2))
    prop.setProperty("postgresConfigDatabaseName", args(3))
    prop.setProperty("postgresHostUserName", args(4))
    prop.setProperty("postgresUserPass", args(5))
    prop.setProperty("equal_measure_list", args(6))
    prop.setProperty("num_executors", args(7))
    prop.setProperty("executor_cores", args(8))
    prop.setProperty("executor_memory", args(9))
    prop.setProperty("keyspace_datamart", args(10))
    prop.setProperty("keyspace_datamart_table_name", args(11))
    prop.setProperty("keyspace_webdatamart", args(12))
    prop.setProperty("cassandra_host", args(13))
    prop.setProperty("cassandra_port", args(14))
    prop.setProperty("spark_master_url", args(15))
    prop.setProperty("measure_computation_output_path", args(16))
    prop.setProperty("mode", args(17))
    prop.setProperty("postgresManagementDatabaseName", args(18))
    prop.setProperty("wfType", args(19))
    prop.setProperty("DateRange", args(20))
    prop.setProperty("cms_measure_list", args(21))
    prop.setProperty("qpp_measure_list", args(22))
    prop.setProperty("nonqpp_measure_list", args(23))
    prop.setProperty("practice_id_list", args(24))
    prop.setProperty("median_measure_list", args(25))
    prop.setProperty("patientHistory", args(26))
  */


  /*prop.setProperty("wf_id", "wf_id_test")
  prop.setProperty("postgresHostName", "10.89.80.6")
  prop.setProperty("postgresHostPort", "5432")
  prop.setProperty("postgresConfigDatabaseName", "config_db")
  prop.setProperty("postgresManagementDatabaseName", "aaomgt")
  prop.setProperty("postgresHostUserName", "postgres")
  prop.setProperty("postgresUserPass", "figmd@123")
  prop.setProperty("num_executors", "3")
  prop.setProperty("executor_cores", "3")
  prop.setProperty("executor_memory", "4G")
  prop.setProperty("keyspace_datamart","")
  //prop.setProperty("keyspace_datamart","testcases")//acepnonqpp1718 acep2018 acep_aug_2018, acc_2018 aao_2018 abfm_2018
  prop.setProperty("keyspace_datamart_table_name", "")
  //prop.setProperty("keyspace_datamart_table_name", args(1))
  //tblencounter_nonqpp, tblencounter_qpp tblencounter_mat
  prop.setProperty("keyspace_webdatamart", "test_data")

  prop.setProperty("patientHistory", "abfm_patient_history") //tblencounter_nonqpp
  prop.setProperty("cassandra_port", "9042")
  prop.setProperty("measure_computation_output_path", "hdfs://ip-10-20-201-103.us-gov-west-1.compute.internal:8020/tmp/cms")

  prop.setProperty("cassandra_host", "10.20.201.152") //10.20.201.152

  //prop.setProperty("mode","cluster")
  //prop.setProperty("spark_master_url","yarn")

  prop.setProperty("spark_master_url", "local[*]")
  prop.setProperty("mode", "client")

  prop.setProperty("wfType", "REGULAR")
  prop.setProperty("DateRange", "[2018-01-01~2018-12-31]")
  prop.setProperty("practice_id_list", "NA") //31f659ea-994b-4570-9180-f302c7ce5fae,6fab4a70-6e66-4676-a507-3562c5b7cd39
  prop.setProperty("median_measure_list", "NA")
  prop.setProperty("log_file", "/tmp/CMS/logger")

  prop.setProperty("input_storage_type", "bigtable")
  prop.setProperty("bigtable_tblencounter", "abfm_encounter")
  prop.setProperty("bigtable_patient_history", "abfm_patient_history")
  prop.setProperty("bigtable_tblencounter_catalog", "gs://sparkmigrate/measure/bigTableCatalog/ABFMCatalog_sahil.txt")
  prop.setProperty("bigtable_patient_history_catalog", "gs://sparkmigrate/measure/bigTableCatalog/patient_history_catalog.txt")*/

  //#############################################################################################################################################

  /* if config file to be read from Google Storage*/

  GSUtility.readGSConfigFile(args)



  var queueId=""
  yarn_queue="default"
  if(args.length>1){
    if(!args(1).isEmpty) {
      queueId = args(1).substring(1)
      println("queueId::::" + queueId)
      if (queueId != "0")
        yarn_queue = args(1)

      queueId = args(1).substring(1)
      // Global Validation function
    }
  }
  else {
    queueId="0"
  }

  commandLineArgumentValidation()
  prop.setProperty("measure_list",prop.getProperty("Q"+queueId+".measurelist"))


  //#############################################################################################################################################

  prop.setProperty("keyspace_datamart_table_name_emergencydept_master", "emergencydept_master")
  prop.setProperty("table_name_measure_master", "janus_measure_master")

  //Set debug mode
  prop.setProperty("debugMode", "1") // 3: For Save, 1 For Count

  //#############################################################################################################################################


  //practice list for measure computation
  if (prop.getProperty("practice_id_list") != "NA" && prop.getProperty("practice_id_list") != "")
    prop.setProperty("practiceListCondition", "and practiceuid in(" + prop.getProperty("practice_id_list") + ")")
  else
    prop.setProperty("practiceListCondition", "")

  measure_list=prop.getProperty("measure_list")

  println("Measure List:::" + measure_list)

  /******************************************************************************************************************************************
  // command line arguments validation check
  ******************************************************************************************************************************************/
  def commandLineArgumentValidation(): Unit = {
    if (args.length<1) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0002", "CRITICAL", "Please give config  command line argument file path and que name.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("wf_id")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0002", "CRITICAL", "Argument workflow id should not null.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("postgresHostName")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0003", "CRITICAL", "Postgres host ip should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("postgresHostPort")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0004", "CRITICAL", "Postgres host port should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("postgresConfigDatabaseName")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0005", "CRITICAL", "config database name should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("postgresHostUserName")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0006", "CRITICAL", "Postgres host user name should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("postgresUserPass")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0007", "CRITICAL", "Postgres host user password should not empty.", "FAIL")
      System.exit(-1)
    }
   /* if (!prop.containsKey("keyspace_datamart")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0008", "CRITICAL", "cassandra datamart keyspace name should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("keyspace_datamart_table_name")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0009", "CRITICAL", "cassandra datamart table name should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("keyspace_webdatamart")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0010", "CRITICAL", "cassandra web datamart keyspace name should not empty.", "FAIL")
      System.exit(-1)
    }*/

    if (!prop.containsKey("cassandra_host")) {
      println("cassandra host ip should not empty.")
      postgresUtility.insertIntoProcessDetails(measure_list, "W0011", "CRITICAL", "cassandra host ip should not empty.", "FAIL")
      System.exit(-1)
    }
/*    if (!prop.containsKey("cassandra_port")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0012", "CRITICAL", "cassandra host port should not empty.", "FAIL")
      System.exit(-1)
    }*/
    if (!prop.containsKey("spark_master_url")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0013", "CRITICAL", "spark master should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("measure_computation_output_path")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0014", "CRITICAL", "measure computation output path should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("mode")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0015", "CRITICAL", "spark mode should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("postgresManagementDatabaseName")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0016", "CRITICAL", "management database name should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("wfType")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0017", "CRITICAL", "workflow type should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("DateRange")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0018", "CRITICAL", "measure computation date range should not empty.", "FAIL")
      System.exit(-1)
    }
    if (!prop.containsKey("patientHistory")) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0019", "CRITICAL", "patient history talble name should not empty.", "FAIL")
      System.exit(-1)
    }
    if ((!prop.containsKey("Q"+queueId+".measurelist") || prop.getProperty("Q"+queueId+".measurelist").equalsIgnoreCase("NA"))) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0020", "CRITICAL", "Measure list should not empty.", "FAIL")
      System.exit(-1)
    }


  }

  def getEncounterAsRDD(columns: Seq[String], whereCql: String, whereValues: Any*): RDD[CassandraRow] = {
    return InputStorageTypeHelper.getInputRDD(prop.getProperty("keyspace_datamart"), prop.getProperty("keyspace_datamart_table_name"), columns, whereCql, whereValues: _*)
  }


  def executeMeasure(spark: SparkSession, wfType: String): Unit = {

    val fileUtility = new FileUtility()
    var dateFormat = fileUtility.getProperty("date.format")
    var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateFormat)
    var measureUtilityObj = new MeasureUtility()
    //    val measure_list = postgresUtility.fetchMeasureFromMgmt(prop.getProperty("measure_list"))

    val measure_list = prop.getProperty("measure_list")

    var date_str = prop.getProperty("DateRange")

    var month_end_date_list = ""

    if (!date_str.isEmpty) {
      //Golbal RDD
      //val rdd = new CassandraUtility().getCassandraRDD(spark)

      var date_range_arr = date_str.trim.substring(1, date_str.length - 1).split(",")
      //loop for rolling-non rolling
      for (date_range <- date_range_arr) {
        println("Measurement Period::::::::::::::" + date_range)
        val measure_start_time = Calendar.getInstance.getTime

        var date_arr = date_range.split("~")
        var quarterStartDate = date_arr(0).trim
        var quarterEndDate = date_arr(1).trim
        var quarterStartDateFormatted = SIMPLE_DATE_FORMAT.parse(date_arr(0).trim)
        var quarterEndDateFormatted = SIMPLE_DATE_FORMAT.parse(date_arr(1).trim)

        prop.setProperty("quarterStartDate", quarterStartDate.toString)
        prop.setProperty("quarterEndDate", quarterEndDate.toString)
        globalStartDate = new DateTime(SIMPLE_DATE_FORMAT.parse(prop.getProperty("quarterStartDate")))
        globalEndDate = new DateTime(SIMPLE_DATE_FORMAT.parse(prop.getProperty("quarterEndDate")))


       // println("quarterStartDate:::::::::::::::" + prop.getProperty("quarterStartDate"))
       // println("quarterEndDate:::::::::::::::" + prop.getProperty("quarterEndDate"))

        val measurementPeriodDF= getTblencouterDF( quarterStartDate, quarterEndDate)

        if (!measure_list.equalsIgnoreCase("NA") && !measure_list.equalsIgnoreCase("")) {
          var arr_measures = measure_list.split(",");
          arr_measures.foreach(measure => {
            var fullname =""
            global_measure_name = measure
            if(!measure.isEmpty && measure.startsWith("Ecqm")) {
              fullname = "com.figmd.janus.measureComputation.ecqm." + measure + "$"
            }
            if(!measure.isEmpty && measure.startsWith("Qpp")) {
              fullname = "com.figmd.janus.measureComputation.qpp." + measure + "$"
            }
            if(!measure.isEmpty && !measure.startsWith("Qpp") && !measure.startsWith("Ecqm")) {
              fullname = "com.figmd.janus.measureComputation.nonqpp." + measure + "$"
            }
            measureCall(spark, measure, measurementPeriodDF, fullname, quarterStartDate, quarterEndDate)
          })
        }

        println(wfType + " Measure refresh Start Time : " + measure_start_time)
        println(wfType + " Measure refresh End Time  : " + Calendar.getInstance.getTime)
      }
      var measureUtilityObj1 = new MeasureUtility()
      var log_file = measureUtilityObj1.logfilename
      //fileUtility.loggerFileUtility(log_file, wf_id, wfType)

      // CASANDRA DELETION
      //deleteFromCassandra(spark, median_measure_list, date_str)
    }
  }

  def measureCall(spark: SparkSession, measure: String,measurementPeriodDF:DataFrame , fullName: String, quarterStartDate: String, quarterEndDate: String): Unit = {
    //  val fullname = "com.figmd.janus.measureComputation.equalMeasures.CMS" + measure.substring(1) + "$"

    val startDateTime = quarterStartDate + " 00:00:00"
    val endDateTime = quarterEndDate + " 00:00:00"
    println(fullName)
    var measureUtilityObj = new MeasureUtility()
    val clazz = Class.forName(fullName);
    val measureObj = clazz.getField("MODULE$").get(classOf[MeasureUpdate]).asInstanceOf[MeasureUpdate]
    var columnRef = measureUtilityObj.getFieldList(measure)
    val filteredDF= measurementPeriodDF.select(columnRef.head, columnRef.tail:_*)
    val measurementPeriodRdd=toCassandraRowRDD(filteredDF).cache()


    /*    val paramSpecChar = InputStorageTypeHelper.getWhereParamSpeChar()
        var measurementPeriodRdd: RDD[CassandraRow] = null

        if (InputStorageTypeHelper.getStorageType() == StorageTypes.CASSANDRA) {
          measurementPeriodRdd = getEncounterAsRDD(columnRef, s"encounterdate>=$paramSpecChar and encounterdate<=$paramSpecChar " + prop.getProperty("practiceListCondition"),
            quarterStartDateFormatted, quarterEndDateFormatted).cache()
        } else if (InputStorageTypeHelper.getStorageType() == StorageTypes.BIGTABLE) {
          /* working code for epoch
          newRdd = getEncounterAsRDD(columnRef, s"encounterdate>=$paramSpecChar and encounterdate<=$paramSpecChar " + prop.getProperty("practiceListCondition"),
                      quarterStartDateFormatted.getTime/1000, quarterEndDateFormatted.getTime/1000)
          */
          //TODO: check filter of date as string -ideally it should be added to part of rowkey and then pattern mattching should be used on rowkey?
          measurementPeriodRdd = getEncounterAsRDD(columnRef, s"encounterdate>='$paramSpecChar' and encounterdate<='$paramSpecChar' " + prop.getProperty("practiceListCondition"),
                                      startDateTime, endDateTime).cache()
        }*/

    //val newRdd = rdd.select(columnRef.map(ColumnName(_)): _*).where(s"encounterdate>=? and encounterdate<=? " + prop.getProperty("practiceListCondition"), quarterStartDateFormatted, quarterEndDateFormatted)
    measureObj.refresh(spark, measurementPeriodRdd)
    //measurementPeriodRdd.unpersist()
  }

  def getTblencouterDF(quarterStartDate: String, quarterEndDate: String): DataFrame = {
    val paramSpecChar = InputStorageTypeHelper.getWhereParamSpeChar()
    val startDateTime = quarterStartDate + " 00:00:00"
    val endDateTime = quarterEndDate + " 00:00:00"

//    var measureList=getMeasuresListAll()

    var measureUtilityObj = new MeasureUtility()
    var columnRef = measureUtilityObj.getElementsList(measure_list).split(",").toSet.toSeq

    //TODO:  filter of date as string
    BigTableUtility.getCassandraRowsDF(sparkSql, prop.getProperty("bigtable_tblencounter"),columnRef, s"encounterdate>='$paramSpecChar' and encounterdate<='$paramSpecChar' " + prop.getProperty("practiceListCondition"),
      startDateTime, endDateTime).cache()
  }

  def deleteFromCassandra(spark: SparkSession, median_measure_list: String, date_str: String): Unit = {
    val cassandraUtility = new CassandraUtility
    var listPatientIds = cassandraUtility.fetchPatientFromAllMeasureOutPut(spark)
    println(":::::::::::::::::::::" + listPatientIds(0))
    println(":::::::::::::::::::::" + listPatientIds(1))
    if (!median_measure_list.equalsIgnoreCase("NA") && !median_measure_list.equalsIgnoreCase("")) {
      // cassandraUtility.deleteFromWebdatamartMedian(spark, measure_list, date_str)
    }
    else {
      cassandraUtility.deleteFromWebdatamart(spark, measure_list, listPatientIds, date_str)
    }
    //      postgresUtility.tinPracticeMapping(spark)
    //      postgresUtility.practiceSubPracticeMapping(spark)
  }

  def chkValidWFType(): Unit = {
    if (prop.getProperty("wfType").isEmpty) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0001", "CRITICAL", "Argument workflow type should not null, Values may be QR,QNR,MR,MNR,QCNR.", "FAIL")
      System.exit(-1)
    }
  }

  def validateMeasureList(): Unit = {
    if (measure_list.isEmpty) {
      postgresUtility.insertIntoProcessDetails(measure_list, "W0001", "CRITICAL", "No measure provided for computation Or measure not found in master table", "FAIL")
      System.exit(-1)
    }
  }

}
