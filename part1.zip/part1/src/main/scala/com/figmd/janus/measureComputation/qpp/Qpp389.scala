package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP389Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 389
* Measure Title              :- Cataract Surgery: Difference between Planned and Final Refraction
* Measure Description        :- Percentage of patients aged 18 years and older who had cataract surgery performed and who achieved a final refraction within +/- 1.0 diopters of their planned (target) refraction
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp389 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp389"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP389Elements.Planned_Refraction,
      QPP389Elements.Cataract_Surgery,
      QPP389Elements.Cataract_Surgery_Date,
      QPP389Elements.Cataract_Surgery_Modifiers,
      QPP389Elements.Final_Refraction,
      QPP389Elements.Planned___Final_Refraction_______1_0_Diopter,
      QPP389Elements.Planned_And_Final_Refraction_Not_Met_Date
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //All patients aged 18 years and older who had cataract surgery
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && wasProcedurePerformedWithinXMonths(visit, m, QPP389Elements.Cataract_Surgery_Date, 9, patientHistoryBroadcastList)
        && !isProcedurePerformed(visit, m, QPP389Elements.Cataract_Surgery_Modifiers, patientHistoryBroadcastList)

    )


  }


  //Patients who achieved a final refraction (spherical equivalent) +/- 1.0 diopters of their planned (target) refraction (spherical equivalent) within 90 days following cataract surgery.
  // The refraction planned and final refraction values should correspond to the eye that underwent the cataract procedure
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        isDiagnosticStudyOnEncounter(visit, m, QPP389Elements.Planned_And_Final_Refraction_In_Diopters)
          || (
          (
            isDiagnosticStudyBeforeOrEqual(visit, m, QPP389Elements.Cataract_Surgery, patientHistoryBroadcastList, QPP389Elements.Planned_Refraction)
              && checkEyeOnEncounterEqualsWithOtherEye(visit, m, true, QPP389Elements.Planned_Refraction_Eye, patientHistoryBroadcastList, Seq(QPP389Elements.Cataract_Surgery_Eye))
            )
            &&
            (
              isDiagnosticStudyPerformedInXDaysAfterProcedure(visit, m, QPP389Elements.Final_Refraction, QPP389Elements.Cataract_Surgery, 90, patientHistoryBroadcastList)
                && checkEyeOnEncounterEqualsWithOtherEye(visit, m, true, QPP389Elements.Final_Refraction_Eye, patientHistoryBroadcastList, Seq(QPP389Elements.Cataract_Surgery_Eye, QPP389Elements.Planned_Refraction_Eye))

              )
            && isDiagnosisAfterEncounter(visit, m, QPP389Elements.Final_Refraction, patientHistoryBroadcastList, QPP389Elements.Planned___Final_Refraction_______1_0_Diopter)

          )
        )
        && !isDiagnosticStudyOnEncounter(visit, m, QPP389Elements.Planned_And_Final_Refraction_Not_Met)

    )
  }


}