package com.figmd.janus.util.measure

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator
import com.figmd.janus.WebDataMartCreator.{globalEndDate, global_measure_name, prop}
import com.figmd.janus.measureComputation.master.{AdminElements, CompareOperator, MeasureProperty}
import com.figmd.janus.util.application.InputStorageTypeHelper
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.joda.time._

import scala.collection.mutable.ListBuffer


class HistoryLookUpUtility extends MeasureUtility {


  //getPatientHistory Elements
  def getPatientHistory(sparkSession: SparkSession, rdd: RDD[CassandraRow], Element: String*): RDD[CassandraRow] = {
    var element: List[String] = Element.toList

    var IPP_PatientRDDPair: RDD[(String, Int)] = rdd.map(l => (l.getString("patientuid"),1)).distinct()
   // val IPP_PatientRDDPair: RDD[(String, Int)] = IPP_PatientRDD.map(r => (r, 1)).distinct()
    val columnRef = Seq("patientuid", "element", "element_date", "elementvalue")
    val patientRddPair: RDD[(String, CassandraRow)] = InputStorageTypeHelper.getInputRDD(prop.getProperty("keyspace_datamart"), prop.getProperty("patientHistory"), columnRef)
      .filter(r => element.contains(r.getString(1))).map(r => (r.getString("patientuid"), r))
    //println("Patient RDD count: " + patientRDD.count())
    //val patientRddPair: RDD[(String, CassandraRow)] = patientRDD.map(r => (r.getString("patientuid"), r))
    val historyRDDPair: RDD[(String, (CassandraRow, Int))] = patientRddPair.join(IPP_PatientRDDPair)
    val historyRDD = historyRDDPair.map(r => r._2._1).cache()
    //println("History RDD count: " + historyRDD.count)
    historyRDD
  }


  /**
    * This function checks if element date starts after or concurrent with start of history
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param element            element name
    * @param historyElement     history element name
    * @param patientHistoryList patient history list
    * @return returns true if  element date starts after or concurrent with start of history else returns false
    */
  def isElementStartsAfterOrConcurrentWithStartOfHistory(visit: CassandraRow, m: MeasureProperty, element: String, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      val elementDate = if(element.equalsIgnoreCase("encounterdate")) "encounterdate" else element + "_date"
      val elementsNotNull = checkNotNull(visit, element, elementDate)
      if (elementsNotNull && patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>  historyElement.equalsIgnoreCase(hvisit.getString(1))
          && (hvisit.getDateTime(2).isAfter(visit.getDateTime(elementDate)) ||
          hvisit.getDateTime(2).isEqual(visit.getDateTime(elementDate))
          )
        )
        val argsArray: Array[String] = Array(element, historyElement)
        measureLogger(visit, m, "isElementStartsAfterOrConcurrentWithStartOfHistory", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementStartsAfterOrConcurrentWithStartOfHistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
//        //System.exit(0)
      }
    }

    return isExist
  }


  /**
    *
    * @param visit       Current Cassandra Row from Tblencounter
    * @param m           Measure Name and Measure Condition
    * @param elementName CondtnsComplctngPrgnancy
    * @param historyList Patient History List
    * @return
    */
  def wasDiagnosedWith(visit: CassandraRow, m: MeasureProperty, elementName: String, historyList: Broadcast[List[CassandraRow]]): Boolean = {

    var isExist = false
    if (historyList.value.nonEmpty) {
      try {
        isExist = historyList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit => (
           histvisit.getString(1).equalsIgnoreCase(elementName)))
        val argsArray: Array[String] = Array(elementName)
        measureLogger(visit, m, "wasDiagnosedWith", elementName, isExist, argsArray)
      }
      catch {
        case e: Exception => {
         // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasDiagnosedWith:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
//          //System.exit(0)
        }
      }
    }
    isExist
  }


  def wasPhysicalExamPerformedForRetinalDilatedExam(visit: CassandraRow, m: MeasureProperty, ElementNameToCheckInHistory: String, elementhistoryResult: String, NoOfMonth: Int, HistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {

      if (HistoryList.value.nonEmpty) {
//        val endDate = m.quarterEndDate
//        val PreviousDate = m.quarterEndDate
        isExist = HistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>
            histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
            &&
            (
              histvisit.getString(1).equalsIgnoreCase(ElementNameToCheckInHistory)
                ||
                histvisit.getString(1).equalsIgnoreCase(elementhistoryResult)
              )
            &&
            (histvisit.getDateTime(2).isAfter(m.quarterEndDate) &&
              histvisit.getDateTime(2).isBefore(m.quarterEndDate) || histvisit.getDateTime(2).isEqual(m.quarterEndDate.minusMonths(NoOfMonth)) ||
              histvisit.getDateTime(2).isEqual(m.quarterEndDate)
              ))
      }
      val argsArray: Array[String] = Array(ElementNameToCheckInHistory,elementhistoryResult,NoOfMonth.toString)
      measureLogger(visit, m, "wasPhysicalExamPerformedForRetinalDilatedExam", ElementNameToCheckInHistory, isExist, argsArray)
    }
    catch {
      case e: Exception => {
       // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPhysicalExamPerformedForRetinalDilatedExam:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
//        //System.exit(0)
      }
    }

    isExist
  }


  /**
    *
    * @param visit              cassendra row
    * @param m                  measure property
    * @param Value              get value from user
    * @param histroyElement     get history element
    * @param patientHistoryList get history List
    * @return true or false based on isAssessmentBeforeValue
    */

  def isAssessmentBeforeValue(visit: CassandraRow, m: MeasureProperty, Value: Int, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x => !x.isNullAt(3) &&
           x.getString(1).equalsIgnoreCase(histroyElement) &&
          x.getInt(3) < Value
        )
      }
      val argsArray: Array[String] = Array(histroyElement,Value.toString)
      measureLogger(visit, m, "isAssessmentBeforeValue", histroyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
       // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentBeforeValue:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
////System.exit(0)
      }
    }
    isExist

  }

  /**
    *
    * @param visit              cassendra row
    * @param m                  measure property
    * @param elementName        get history element
    * @param result
    * @param patientHistoryList get history List
    * @return
    */
  def isAssessmentAfterValue(visit: CassandraRow, m: MeasureProperty, elementName: String, result: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
//        var startDate = m.quarterStartDate
//        var endDate = m.quarterEndDate

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x => !x.isNullAt(3) &&
          ((x.getDateTime(2).isBefore( m.quarterEndDate) && x.getDateTime(2).isAfter(m.quarterStartDate)) || x.getDateTime(2).isEqual(m.quarterStartDate) || x.getDateTime(2).isEqual(m.quarterEndDate)) &&
           x.getString(1).equalsIgnoreCase(elementName) &&
          x.getInt(3) > result
        )
      }

      val argsArray: Array[String] = Array(elementName,result.toString)
      measureLogger(visit, m, "isAssessmentAfterValue", elementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
       // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentAfterValue:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        ////System.exit(0)
      }
    }
    isExist
  }


  /** PARENT function
    * G
    *
    * @param visit              cassendra row
    * @param m                  measure property
    * @param elementName        get history element
    * @param patientHistoryList get history List
    * @return
    */
  def checkElementInHistory(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>
                      x.getString(1).equalsIgnoreCase(elementName) &&
          /*(x.getDateTime(2).isBefore(m.quarterEndDate) || x.getDateTime(2).isEqual(m.quarterEndDate))
          &&*/
          dateStatus(x.getDateTime(2),m.quarterEndDate,CompareOperator.LESS_EQUAL)
        )
      }
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "checkElementInHistory", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
       // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementInHistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        ////System.exit(0)

      }
    }
    isExist
  }


  /** PARENT function
    * G
    *
    * @param visit              cassendra row
    * @param m                  measure property
    * @param elementName        get history element
    * @param patientHistoryList get history List
    * @return
    */
  def checkElementDuringMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
//        val startDate = m.quarterStartDate
//        val endDate = m.quarterEndDate
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getString(1).equalsIgnoreCase(elementName) &&
          ((x.getDateTime(2).isAfter(m.quarterStartDate) && x.getDateTime(2).isBefore(m.quarterEndDate)) ||
            x.getDateTime(2).isEqual(m.quarterStartDate) || x.getDateTime(2).isEqual(m.quarterEndDate))
        )
      }
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "checkElementDuringMeasurementPeriod", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
       // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementDuringMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /** PARENT function
    * G
    *
    * @param visit              cassendra row
    * @param m                  measure property
    * @param patientHistoryList get history element
    * @param elementName        get history List
    * @return
    */
  def checkElementDuringMeasurementPeriodListOfElement(visit: CassandraRow, m: MeasureProperty, patientHistoryList: Broadcast[List[CassandraRow]], elementName: Seq[String]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
//        val startDate = m.quarterStartDate
//        val endDate = m.quarterEndDate
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           elementName.exists(y => y.contains(x.getString(1)))
          &&
          ((x.getDateTime(2).isAfter(m.quarterStartDate) && x.getDateTime(2).isBefore(m.quarterEndDate)) ||
            x.getDateTime(2).isEqual(m.quarterStartDate) || x.getDateTime(2).isEqual(m.quarterEndDate))
        )
      }
      val argsArray: Array[String] = Array(elementName.toString())
      measureLogger(visit, m, "checkElementDuringMeasurementPeriodListOfElement", elementName.toString(), isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementDuringMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function gives first Date of the element in history.
    *
    * @param historyRDD  Patient History RDD
    * @param ElementDate ElementDate whose First Date has to be calculate in History
    * @return List of Cassandra Row that contains all the elements date concurrent with first date.
    */

  def minDate(historyRDD: RDD[CassandraRow], Element: String, ElementDate: String): List[CassandraRow] = {
    /*val minDateElements = historyRDD.filter(l => !l.isNullAt(1) && !l.isNullAt(2) && l.getString(1).equalsIgnoreCase(Element))
      .map(l => (l.getString("patientuid"), l.getDate(2))).reduceByKey((x, y) => if (x.before(y)) x else y).collect()
    historyRDD.filter(r => minDateElements.contains((r.getString("patientuid"), r.getDate(2)))).collect.toList*/

    historyRDD.filter(l =>
      l.getString(1).equalsIgnoreCase(Element))
      .map(l => (l.getString(0), l))
      .reduceByKey((x, y) => if (x.getDate(2).before(y.getDate(2))) x else y).map(r=>r._2)
      .collect().toList

  }

  /** PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param elementName        element name whose date will be checked
    * @param patientHistoryList list of patient history
    * @return true if element is already present before encounter Date
    */
  def wasElementPresentBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equalsIgnoreCase(elementName)
          && x.getDate(2).before(visit.getDate("encounterdate"))
        )
      }
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "wasElementPresentBeforeEncounter", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param elementName        element name whose date will be checked
    * @param patientHistoryList list of patient history
    * @return true if element is already present before encounter Date
    */
  def wasElementPresentBeforeOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getString(1).equalsIgnoreCase(elementName)
          && (
          x.getDate(2).before(visit.getDate("encounterdate")) ||
            x.getDate(2).equals(visit.getDate("encounterdate"))
          )
        )
      }
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "wasElementPresentBeforeOrEqualEncounter", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentBeforeOrEqualEncounter:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    *
    * @param r         r is cassandra row to be used for condition check
    * @param ippEye    ippEye is the base element
    * @param otherEyes otherEyes is the condition element to be checked with
    * @return returns true result based on cassandra row pass condition else returns false
    */

  def checkEyeElementsInRange(r: CassandraRow, m: MeasureProperty, ippEye: String, otherEyes: String*): Boolean = {
    val eyeCondCriterias1 = Array(3, 4)
    val eyeCondCriterias2 = Array(1, 2, 3, 4)

    def returnEyeValue(cr: CassandraRow, element: String): Any = {
      if (cr.isNullAt(element)) null else cr.getString(element).toInt
    }

    val ippEye1 = returnEyeValue(r, ippEye)
    otherEyes.forall(eye => {
      val conditionEye = returnEyeValue(r, eye)
      (conditionEye == ippEye1) || (eyeCondCriterias1.contains(conditionEye) && eyeCondCriterias2.contains(ippEye1)) || (eyeCondCriterias2.contains(conditionEye) && eyeCondCriterias1.contains(ippEye1)) || conditionEye == null || ippEye1 == null
    })
  }


  /**
    *
    * @param currentVisit CurrentVisit come From CassandraRow
    * @param m            Measure condition and Measure Name
    * @param Element      Element(Dialysis Services)which has to be check in history.
    * @param historyList  List of All the Element that will require in the measure
    * @return Boolean
    */
  //"Procedure, Performed: Dialysis Services"
  def procedurePerformedStartsBeforeEndOfMeasurementPeriod(currentVisit: CassandraRow, m: MeasureProperty, Element: String, historyList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    if (historyList.value.nonEmpty) {
      try {
//        val endDate = m.quarterEndDate
        isExist = historyList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(currentVisit.getString("patientuid")))
          .exists(histvisit => (
           (histvisit.getString(1).equalsIgnoreCase(Element) && histvisit.getDateTime(2).isBefore(m.quarterEndDate))
          ))
        val argsArray: Array[String] = Array(Element, m.quarterEndDate.toString())
        measureLogger(currentVisit, m, "procedurePerformedStartsBeforeEndOfMeasurementPeriod", Element, isExist, argsArray)
      }
      catch {
        case e: Exception =>
       //   postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:procedurePerformedStartsBeforeEndOfMeasurementPeriod:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)

      }
    }
    isExist
  }

  def isDiagnosedWithEqualInMonths(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        //val endDate = m.quarterEndDate
//        val end_Date = m.quarterEndDate
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         x.getString(1).equalsIgnoreCase(histroyElement)
            &&
            (
              x.getDateTime(2).isBefore(m.quarterEndDate.minusMonths(month))
                ||
                x.getDateTime(2).isEqual(m.quarterEndDate.minusMonths(month))
              )
        )
        val argsArray: Array[String] = Array(histroyElement,month.toString, m.quarterEndDate.toString)
        measureLogger(visit, m, "isDiagnosedWithEqualInMonths", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isDiagnosedWithEqualInMonths:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  def wasElementBeforeOrEqualInMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          histroyElement.equalsIgnoreCase(x.getString(1))
            && (visit.getDateTime(elementDate).minusMonths(month).isBefore(x.getDateTime(2))
            || visit.getDateTime(elementDate).minusMonths(month).isEqual(x.getDateTime(2)))
        )
        val argsArray: Array[String] = Array(histroyElement,month.toString)
        measureLogger(visit, m, "wasElementBeforeOrEqualInMonths", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception =>
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementBeforeOrEqualInMonths:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

    }
    isExist
  }

  def wasElementAfterOrEqualInMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>

           histroyElement.equalsIgnoreCase(x.getString(1))

            && (visit.getDateTime(elementDate).minusMonths(month).isAfter(x.getDateTime(2))
            || visit.getDateTime(elementDate).minusMonths(month).isEqual(x.getDateTime(2)))
        )
        val argsArray: Array[String] = Array(histroyElement,elementDate, month.toString)
        measureLogger(visit, m, "wasElementAfterOrEqualInMonths", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementAfterOrEqualInMonths:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    *
    * @param r                 CurrentVisit RDD coming from tblencounter
    * @param m                 Measure condition and Measure Name
    * @param elementDate       Element which has to be check in current.
    * @param mostRecentElement Element which has to be check in mostrecent.
    * @param ValueStartRange   Element Start value which has to be check in most recent .
    * @param ValueEndRange     Element end value which has to be check in most recent .
    * @param month             no of months minus from current
    * @param MostRecentList    list of most recent elements
    * @return true if value found with in range in most recent list
    */


  def elementMostRecentResultInBetweenBeforeOrEqualInMonth(r: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, ValueStartRange: Double, ValueEndRange: Double, month: Int, MostRecentList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (MostRecentList.value.nonEmpty) {
        isExist = MostRecentList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(x => !x.isNullAt(3)
              && mostRecentElement.equalsIgnoreCase(x.getString(1))
            && ((x.getDateTime(2).isBefore(r.getDateTime(elementDate)) && x.getDateTime(2).isAfter(r.getDateTime(elementDate).minusMonths(month)))
            || x.getDateTime(2).equals(r.getDateTime(elementDate)) || x.getDateTime(2).isAfter(r.getDateTime(elementDate).minusMonths(month)))
            && (x.getDouble(3) >= ValueStartRange && x.getDouble(3) < ValueEndRange)
        )
        val argsArray: Array[String] = Array(mostRecentElement,elementDate,month.toString,ValueStartRange.toString(),ValueEndRange.toString())
        measureLogger(r, m, "elementMostRecentResultInBetweenBeforeOrEqualInMonth", mostRecentElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:elementMostRecentResultInBetweenBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  def elementMostRecentResultInBetweenBeforeOrEqualInMonth(r: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, ValueGreaterOrEqual: Double, month: Int, MostRecentList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (MostRecentList.value.nonEmpty) {
        isExist = MostRecentList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(x => !x.isNullAt(3)

            && mostRecentElement.equalsIgnoreCase(x.getString(1))

            && (r.getDateTime(elementDate).minusMonths(month).isBefore(x.getDateTime(2))
            || r.getDateTime(elementDate).minusMonths(month).isEqual(x.getDateTime(2)))

            && x.getDouble(3) >= ValueGreaterOrEqual
        )
        val argsArray: Array[String] = Array(mostRecentElement,elementDate,month.toString,ValueGreaterOrEqual.toString)
        measureLogger(r, m, "ElementMostRecentResultInBetweenBeforeOrEqualInMonth", mostRecentElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultInBetweenBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /*
  * @ param MappingElement RDD whose Element Date has to be mapped with most Recent Date.
  * @ historyElement RDD whose Element Date has to be calaulated the most Recent Date.
  * @return it will return RDD[CassandraRow]
  * */
  def mostRecentAssessmentPerformed(historyRDD: RDD[CassandraRow], patientUid: String, Element: String, MEASURE_NAME: String): List[CassandraRow] = {
    /*val mostRecentElements = historyRDD.filter(l => !l.isNullAt(1) && !l.isNullAt(2) && l.getString(1).equalsIgnoreCase(Element))
      .map(l => (l.getString("patientuid"), l.getDate(2)))
      .reduceByKey((x, y) => if (x.after(y)) x else y).collect()
    historyRDD.filter(r => mostRecentElements.contains((r.getString("patientuid"), r.getDate(2)))).collect().toList*/

    historyRDD.filter(l =>
      l.getString(1).equalsIgnoreCase(Element))
      .map(l => (l.getString(0), l))
      .reduceByKey((x, y) => if (x.getDate(2).after(y.getDate(2))) x else y).map(r=>r._2)
      .collect().toList
  }

/*
  //isElementBeforeOrEqualInMonthsBeforeEndOfMeasurementPeriod
  /** PARENT Function
    * check element date after substracting given months from the end date
    *
    * @param r                  current cassendra row
    * @param m                  measure property
    * @param histroyElement     checking history element after end date
    * @param month              substract given month in end date
    * @param patientHistoryList check element in patient history list
    * @return if check element date after substracting given months from the end date
    */
  def wasElementAfterOrEqualEndDateInMonths(r: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        val endDate: Date = m.quarterEndDate
        val end_date = new DateTime(endDate)
        isExist = patientHistoryList.value.exists(x =>
          !x.isNullAt(2)

            && r.getString("patientuid").equals(x.getString("patientuid"))

            && histroyElement.equalsIgnoreCase(x.getString(1))

            && (end_date.minusMonths(month).isAfter(x.getDateTime(2))
            || end_date.minusMonths(month).isEqual(x.getDateTime(2)))
        )
      }
      val argsArray: Array[String] = Array(month.toString)
      measureLogger(r, m, "encounterPerformedStartBeforeEndOfMeasurementPeriod", histroyElement.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:encounterPerformedStartBeforeEndOfMeasurementPeriod:" + e.printStackTrace(), "FAIL")
       loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }*/

  def elementMostRecentResultLessBeforeOrEqualInMonth(r: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, ValueLess: Double, month: Int, MostRecentList: List[CassandraRow]): Boolean = {
    var isExist = false
    try {
      if (MostRecentList.length > 0) {
        isExist = MostRecentList.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(x => !x.isNullAt(3)

            && mostRecentElement.equalsIgnoreCase(x.getString(1))

            && (r.getDateTime(elementDate).minusMonths(month).isBefore(x.getDateTime(2))
            || r.getDateTime(elementDate).minusMonths(month).isEqual(x.getDateTime(2)))

            && x.getDouble(3) < ValueLess
        )
      }
      val argsArray: Array[String] = Array(mostRecentElement,elementDate,month.toString, ValueLess.toString)
      measureLogger(r, m, "elementMostRecentResultLessBeforeOrEqualInMonth", mostRecentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    *
    * @param r                  current cassandra row
    * @param m                  MeasureProperty
    * @param currentRowelement  element of cureent row
    * @param element2           element whose date will be compared current row
    * @param days               within how many days element2 will be performed after currentRowelement
    * @param patientHistoryList patient history
    * @return whether element2 performed within <=days after currentRowelement performed
    */

  def startAfterStartOfWithinDaysLessorEqual(r: CassandraRow, m: MeasureProperty, currentRowelement: String, element2: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid")))
        .exists(x =>
           element2.toLowerCase.equals(x.getString(1).toLowerCase)
          && (r.getDateTime(currentRowelement).plusDays(days).isBefore(x.getDateTime(2))
          || r.getDateTime(currentRowelement).plusDays(days).isEqual(x.getDateTime(2)))
      )
      val argsArray: Array[String] = Array(currentRowelement,element2, days.toString)
      measureLogger(r, m, "startAfterStartOfWithinDaysLessorEqual", element2.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
     //   postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:startAfterStartOfWithinDaysLessorEqual:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    *
    * @param r                  current cassandra row
    * @param m                  MeasureProperty
    * @param currentRowelement  element of current row
    * @param element2           element whose date will be compared current row
    * @param patientHistoryList patient history
    * @return whether element2 performed after element1
    */
  def startAfterStartOfEncounter(r: CassandraRow, m: MeasureProperty, currentRowelement: String, element2: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(x =>
          !r.isNullAt(currentRowelement)

            && element2.equalsIgnoreCase(x.getString(1)) &&
            x.getDateTime(2).isAfter(r.getDateTime(currentRowelement))
        )
        val argsArray: Array[String] = Array(currentRowelement,element2)
        measureLogger(r, m, "startAfterStartOfEncounter", currentRowelement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
     //   postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:startAfterStartOfEncounter:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    *
    * @param r                  cassendra row
    * @param m                  measure property
    * @param histroyElement1    get 1st history element
    * @param histroyElement2    get 2nd history element
    * @param month              get number of month
    * @param patientHistoryList get patient history list
    * @return yes and no based on  isTobaccoUseScreeningNonUserWithin24Months
    */

  def isTobaccoUseScreeningNonUserWithin24Months(r: CassandraRow, m: MeasureProperty, histroyElement1: String, histroyElement2: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      //val endDate = m.quarterEndDate
//      val end_Date = m.quarterEndDate
      isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(x =>
       histroyElement1.equalsIgnoreCase(x.getString(1)).equals(histroyElement2.equalsIgnoreCase(x.getString(1)))
          && (
          (x.getDateTime(2).isBefore(m.quarterEndDate) && x.getDateTime(2).isAfter(m.quarterEndDate.minusMonths(month))) ||
            (x.getDateTime(2).equals(m.quarterEndDate.minusMonths(month)) || x.getDateTime(2).isEqual(m.quarterEndDate))
          )
      )
      val argsArray: Array[String] = Array(histroyElement1, histroyElement2, month.toString)
      measureLogger(r, m, "isTobaccoUseScreeningNonUserWithin24Months", histroyElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
     //   postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isTobaccoUseScreeningNonUserWithin24Months:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * this function check whether element present between Emergency_Visit_Arrival_Date and visit Emergency_Visit_Departure_Date
    *
    * @param m                              measure property
    * @param element                        procedure element
    * @param Emergency_Visit_Arrival_Date   emergency visit arrival date
    * @param Emergency_Visit_Departure_Date emergency visit departure date
    * @return true if element present between Emergency_Visit_Arrival_Date and Emergency_Visit_Departure_Date
    */
  def isElementPresentBetweenTwoDate(visit: CassandraRow, m: MeasureProperty, element: String, Emergency_Visit_Arrival_Date: String, Emergency_Visit_Departure_Date: String): Boolean = {
    var isExist = false
    try {
      isExist = (!visit.isNullAt(element) && !visit.isNullAt(Emergency_Visit_Arrival_Date) && !visit.isNullAt(Emergency_Visit_Departure_Date) &&

        ((visit.getDateTime(element + "_date").isBefore(visit.getDateTime(Emergency_Visit_Departure_Date))
          && visit.getDateTime(element + "_date").isAfter(visit.getDateTime(Emergency_Visit_Arrival_Date)))

          || visit.getDateTime(element + "_date").equals(visit.getDateTime(Emergency_Visit_Departure_Date))

          || visit.getDateTime(element + "_date").equals(visit.getDateTime(Emergency_Visit_Arrival_Date)))
        )
      val argsArray: Array[String] = Array(element, Emergency_Visit_Arrival_Date, Emergency_Visit_Departure_Date)
      measureLogger(visit, m, "isElementPresentBetweenTwoDate", m.quarterStartDate.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isTobaccoUseScreeningNonUserWithin24Months:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * this function check whether element present between Emergency_Visit_Arrival_Date and visit Emergency_Visit_Departure_Date and check result value also
    *
    * @param visit                          current visit
    * @param m                              measure property
    * @param element                        procedure element
    * @param Emergency_Visit_Arrival_Date   emergency visit arrival date
    * @param Emergency_Visit_Departure_Date emergency visit departure date
    * @return true ifelement present between Emergency_Visit_Arrival_Date and visit visit Emergency_Visit_Departure_Date and check result value also
    */

  def isElementPresentBetweenTwoDatesAndResultValueEqual(visit: CassandraRow, m: MeasureProperty, element: String, Emergency_Visit_Arrival_Date: String, Emergency_Visit_Departure_Date: String, resultValue: Double): Boolean = {
    var isExist = false
    try {

      isExist = (!visit.isNullAt(element) && !visit.isNullAt(Emergency_Visit_Arrival_Date) && !visit.isNullAt(Emergency_Visit_Departure_Date) &&

        ((visit.getDateTime(element + "_date").isBefore(visit.getDateTime(Emergency_Visit_Departure_Date))
          && visit.getDateTime(element + "_date").isAfter(visit.getDateTime(Emergency_Visit_Arrival_Date)))

          || visit.getDateTime(element + "_date").equals(visit.getDateTime(Emergency_Visit_Arrival_Date))

          || visit.getDateTime(element + "_date").equals(visit.getDateTime(Emergency_Visit_Departure_Date)))

        && visit.getDouble(element) == resultValue
        )
      val argsArray: Array[String] = Array(element, Emergency_Visit_Arrival_Date, Emergency_Visit_Departure_Date)
      measureLogger(visit, m, "isElementPresentBetweenTwoDatesAndResultValueEqual", m.quarterStartDate.toString, isExist, argsArray)

    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBetweenTwoDatesAndResultValueEqual:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

 /* /**
    *
    * @param visit                        current visit
    * @param m                            measure property
    * @param elementDate                  counseling element
    * @param histroyElement1              most recent screening element
    * @param histroyElement2              tobacco user
    * @param month                        month in integer
    * @param patientHistoryMostRecentList patientHistoryMostRecentList
    * @param patientHistoryList           patientHistoryList
    * @return
    */

  def wasCounselingNotPerformedAfterTobaccoScreeningUser(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement1: String, histroyElement2: String, month: Int, patientHistoryMostRecentList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

//    val end_Date = m.quarterEndDate
    var isExist = false
    try {
      isExist = patientHistoryMostRecentList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          visit.getDateTime(elementDate).isBefore(m.quarterEndDate)
          && histroyElement1.equalsIgnoreCase(x.getString(1))
          && (
          (x.getDateTime(2).isBefore(m.quarterEndDate) && x.getDateTime(2).isAfter(m.quarterEndDate.minusMonths(month)))
            || x.getDateTime(2).isEqual(m.quarterEndDate.minusMonths(month)) || x.getDateTime(2).isEqual(m.quarterEndDate))
          &&
          patientHistoryList.value.filter(histRow=>histRow.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
            .exists(y =>
            histroyElement2.equalsIgnoreCase(y.getString(1))
            && y.getDateTime(2).isEqual(x.getDateTime(2))

          )

          && (visit.getDateTime(elementDate).isAfter(x.getDateTime(2)) || visit.getDateTime(elementDate).isEqual(x.getDateTime(2)))


      )
      val argsArray: Array[String] = Array(elementDate,histroyElement1, histroyElement2,month.toString)
      measureLogger(visit, m, "wasCounselingNotPerformedAfterTobaccoScreeningUser", elementDate, isExist, argsArray)


    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasCounselingNotPerformedAfterTobaccoScreeningUser:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist

  }*/

  /**
    *
    * @param visit                        current visit
    * @param m                            measure property
    * @param elementDate                  counseling element
    * @param histroyElement1              most recent screening element
    * @param histroyElement2              tobacco user
    * @param month                        month in integer
    * @param patientHistoryMostRecentList patientHistoryMostRecentList
    * @param patientHistoryList           patientHistoryList
    * @return
    */

  def wasCounselingNotPerformedAfterTobaccoScreeningUser(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement1: String, histroyElement2: String, month: Int, patientHistoryMostRecentList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    //    val end_Date = m.quarterEndDate
    var isExist = false
    try {
      isExist = patientHistoryMostRecentList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).filter(x =>
        visit.getDateTime(elementDate).isBefore(m.quarterEndDate)
          && histroyElement1.equalsIgnoreCase(x.getString(1))
          && (
          (x.getDateTime(2).isBefore(m.quarterEndDate) && x.getDateTime(2).isAfter(m.quarterEndDate.minusMonths(month)))
            || x.getDateTime(2).isEqual(m.quarterEndDate.minusMonths(month)) || x.getDateTime(2).isEqual(m.quarterEndDate)))
        .exists(row=>
          patientHistoryList.value.filter(histRow=>histRow.getString(0).equalsIgnoreCase(row.getString("patientuid")))
            .exists(y =>
              histroyElement2.equalsIgnoreCase(y.getString(1))
                && y.getDateTime(2).isEqual(row.getDateTime(2))
            )
          && (visit.getDateTime(elementDate).isAfter(row.getDateTime(2)) || visit.getDateTime(elementDate).isEqual(row.getDateTime(2)))


      )
      val argsArray: Array[String] = Array(elementDate,histroyElement1, histroyElement2,month.toString)
      measureLogger(visit, m, "wasCounselingNotPerformedAfterTobaccoScreeningUser", elementDate, isExist, argsArray)


    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasCounselingNotPerformedAfterTobaccoScreeningUser:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist

  }


  /**
    * $TobaccoUseScreeningUser
    * "Assessment, Performed: Tobacco Use Screening" satisfies all:
    * Most Recent: <= 24 month(s) starts before end of "Measurement Period"
    * (result: Tobacco User)
    *
    * @param visit                 current visit
    * @param m                     measure property
    * @param tobaccoUserElement    tobaccoUserElement
    * @param tobaccoNonUserElement tobaccoNonUserElement
    * @param month                 minus number of month
    * @param patientHistoryList    most recent history list
    * @return
    */

  def tobaccoUseScreeningUser(visit: CassandraRow, m: MeasureProperty, tobaccoUserElement: String, tobaccoNonUserElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): List[CassandraRow] = {
   // val endDate = m.quarterEndDate
//    val end_Date = m.quarterEndDate
    var isExistListOfCassandraRow = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).filter(x =>
       (tobaccoUserElement.equalsIgnoreCase(x.getString(1))
        || tobaccoNonUserElement.equalsIgnoreCase(x.getString(1)))
        && (x.getDateTime(2).isBefore(m.quarterEndDate) && x.getDateTime(2).isAfter(m.quarterEndDate.minusMonths(month))) ||
        x.getDateTime(2).equals(m.quarterEndDate.minusMonths(month)) || x.getDateTime(2).isEqual(m.quarterEndDate)
    )
    isExistListOfCassandraRow
  }


  /**
    * This function will return list of most recent data from patient history
    *
    * @param historyRDD History RDD
    * @param elements    element of which most recent record we need
    * @return list of cassandra row will contains patient most recent element record
    */
  def mostRecentPatientList(historyRDD: RDD[CassandraRow], elements: String*): List[CassandraRow] = {

   /* val mostRecentElements = historyRDD.filter(l => Element.contains(l.getString(1)))

      .map(l => ((l.getString("patientuid"), l.getString(1)), l.getDate(2)))

      .reduceByKey((x, y) => if (x.after(y)) x else y)

      .collect().toList

    val mostRecentList = historyRDD.filter(r => mostRecentElements.exists(x => x._1._1.equalsIgnoreCase(r.getString("patientuid"))

      && x._1._2.equalsIgnoreCase(r.getString(1))

      && x._2.equals(r.getDate(2)))).collect().toList

    mostRecentList*/



    historyRDD.filter(l =>
      elements.contains(l.getString(1)))
      .map(l => ((l.getString(0), l.getString(1)), l))
      .reduceByKey((x, y) => if (x.getDate(2).after(y.getDate(2))) x else y).map(r=>r._2)
      .collect().toList

  }

  def mostRecentPatientListSeq(historyRDD: RDD[CassandraRow], elements: Seq[String]): List[CassandraRow] = {

   /* val mostRecentElements = historyRDD.filter(l =>  Element.contains(l.getString(1)))

      .map(l => ((l.getString("patientuid"), l.getString(1)), l.getDate(2)))

      .reduceByKey((x, y) => if (x.after(y)) x else y)

      .collect().toList

    val mostRecentList = historyRDD.filter(r => mostRecentElements.exists(x => x._1._1.equalsIgnoreCase(r.getString("patientuid"))

      && x._1._2.equalsIgnoreCase(r.getString(1))

      && x._2.equals(r.getDate(2)))).collect().toList

    mostRecentList*/


    historyRDD.filter(l =>
      elements.contains(l.getString(1)))
      .map(l => ((l.getString(0), l.getString(1)), l))
      .reduceByKey((x, y) => if (x.getDate(2).after(y.getDate(2))) x else y).map(r=>r._2)
      .collect().toList

  }


  /**
    * This function will return list of most recent data from patient history
    *
    * @param historyRDD History RDD
    * @param elements    element of which most recent record we need
    * @return list of cassandra row will contains patient most recent element record
    */
  def mostRecentPatientListAfterElement(visit: CassandraRow, elementDate: String, historyRDD: RDD[CassandraRow], elements: String*): List[CassandraRow] = {

   /* val mostRecentElements = historyRDD.filter(l =>  Element.contains(l.getString(1)) && l.getDate(2).after(visit.getDate(elementDate)))

      .map(l => ((l.getString("patientuid"), l.getString(1)), l.getDate(2)))

      .reduceByKey((x, y) => if (x.after(y)) x else y)

      .collect().toList

    val mostRecentList = historyRDD.filter(r => mostRecentElements.exists(x => x._1._1.equalsIgnoreCase(r.getString("patientuid"))

      && x._1._2.equalsIgnoreCase(r.getString(1))

      && x._2.equals(r.getDate(2)))).collect().toList

    mostRecentList*/

    historyRDD.filter(l =>
      elements.contains(l.getString(1)) && l.getDate(2).after(visit.getDate(elementDate)))
      .map(l => ((l.getString(0), l.getString(1)), l))
      .reduceByKey((x, y) => if (x.getDate(2).after(y.getDate(2))) x else y).map(r=>r._2)
      .collect().toList

  }


  /**
    * This function will return list of most recent data from patient history
    *
    * @param rdd current RDD
    * @return list of cassandra row will contains patient most recent element record on current Encounter
    */
  def mostRecentPatientListOnEncounter(rdd: RDD[CassandraRow]): List[CassandraRow] = {

   /* val mostRecentRdd = RDD.filter(l => !l.isNullAt("patientuid") && !l.isNullAt("encounterdate"))

      .map(l => (l.getString("patientuid"), l.getDate("encounterdate")))

      .reduceByKey((x, y) => if (x.after(y)) x else y)

      .collect().toList

    val mostRecentEncounter = RDD.filter(r => mostRecentRdd.exists(x => x._1.equalsIgnoreCase(r.getString("patientuid"))

      && x._2.equals(r.getDate("encounterdate")))).collect().toList

    mostRecentEncounter*/


    rdd.filter(l => !l.isNullAt("patientuid") && !l.isNullAt("encounterdate"))

      .map(l => (l.getString("patientuid"),l))

      .reduceByKey((x, y) => if (x.getDate("encounterdate").after(y.getDate("encounterdate"))) x else y).map(r=>r._2)

      .collect().toList
  }


  /**
    * this function will check whether element present before or equal end of measurement period
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param elementName        element name
    * @param patientHistoryList patient history
    * @return true if element present before or equal end of measurement period
    */
  def isElementPresentBeforeOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>
            x.getString(1).equalsIgnoreCase(elementName)
              &&
              dateStatus(x.getDateTime(2),visit.getDateTime("encounterdate"),CompareOperator.LESS_EQUAL)
          )
      }
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "isElementPresentBeforeOrEqualEncounter", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasTobaccoCessationInterventionDone:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * $tobaccoUseScreeningUserDuringMeasure
    * "Assessment, Performed: Tobacco Use Screening" satisfies all:
    * Most Recent: DuringMeasurement Period"
    * (result: Tobacco User OR Tobacco NonUser)
    *
    * @param visit                        current visit
    * @param m                            measure property
    * @param tobaccoUserElement           tobaccoUserElement
    * @param tobaccoNonUserElement        tobaccoNonUserElement
    * @param patientMostRecentHistoryList most recent history list
    * @return
    */

  def isTobaccoUsesScreeningUser(visit: CassandraRow, m: MeasureProperty, tobaccoUserElement: String, tobaccoNonUserElement: String, patientMostRecentHistoryList: Broadcast[List[CassandraRow]]): List[CassandraRow] = {
    val end_Date = m.quarterEndDate
    val start_Date = m.quarterStartDate
    val tobaccoUseScreeningUserOrNonUser = patientMostRecentHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
      .filter(x =>
        (
          tobaccoUserElement.equalsIgnoreCase(x.getString(1))
            ||
            tobaccoNonUserElement.equalsIgnoreCase(x.getString(1))
          )
        && ((x.getDateTime(2).isBefore(end_Date) && x.getDateTime(2).isAfter(start_Date)) ||
        x.getDateTime(2).equals(start_Date) || x.getDateTime(2).isEqual(end_Date))
    )
    tobaccoUseScreeningUserOrNonUser
  }

  //  /**
  //    *  $TobaccoCessationIntervention starts after or concurrent with start of $TobaccoUseScreeningUser
  //    * $TobaccoCessationIntervention =
  //    * Union of:
  //    * "Intervention, Performed: Tobacco Use Cessation Counseling"
  //    * "Medication, Order: Tobacco Use Cessation Pharmacotherapy"
  //    * "Medication, Active: Tobacco Use Cessation Pharmacotherapy"
  //    *  $TobaccoUseScreeningUser
  //    *  "Assessment, Performed: Tobacco Use Screening" satisfies all:
  //    *  Most Recent: During  "Measurement Period"
  //    * (result: Tobacco User)
  /**
    * @param visit                        current visit
    * @param MeasureProperty              measure property
    * @param tobaccoUserElement           tobaccoUserElement
    * @param tobaccoNonUserElement        tobaccoNonUserElement
    * @param toUsCeCo                     Tobacco Use Cessation Counseling
    * @param toUsCePh                     Tobacco Use Cessation Pharmacotherapy
    * @param patientMostRecentHistoryList most recent history list
    * @return
    */

  def isTobaccoCessationInterventionDone(visit: CassandraRow, MeasureProperty: MeasureProperty, tobaccoUserElement: String, tobaccoNonUserElement: String, toUsCeCo: String, toUsCePh: String, patientMostRecentHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    val tobaccoUseScreeningUser1 = isTobaccoUsesScreeningUser(visit, MeasureProperty, tobaccoUserElement, tobaccoNonUserElement, patientMostRecentHistoryList)

    patientMostRecentHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
      toUsCeCo.equalsIgnoreCase(x.getString(1))
        && (x.getDateTime(2).equals(tobaccoUseScreeningUser1.map(y => y.getDateTime(2)).toList(0)) ||
        x.getDateTime(2).isAfter(tobaccoUseScreeningUser1.map(y => y.getDateTime(2)).toList(0)))
    ) ||
      patientMostRecentHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          toUsCePh.equalsIgnoreCase(x.getString(1))
          &&
          (x.getDateTime(2).equals(tobaccoUseScreeningUser1.map(y => y.getDateTime(2)).toList(0)) ||
            x.getDateTime(2).isAfter(tobaccoUseScreeningUser1.map(y => y.getDateTime(2)).toList(0)))

      )



  }

  /**
    * $CounselingNotPerformed starts after or concurrent with start of $TobaccoUseScreeningUser
    * $CounselingNotPerformed
    * "Intervention, Performed not done: Medical Reason" for "Tobacco Use Cessation Counseling" starts before end of "Measurement Period"
    * * $TobaccoUseScreeningUser
    * * "Assessment, Performed: Tobacco Use Screening" satisfies all:
    * * Most Recent: During "Measurement Period"
    * * (result: Tobacco User)
    *
    * @param visit                        current visit
    * @param MeasureProperty              measure property
    * @param tobaccoUserElement           tobaccoUserElement
    * @param tobaccoNonUserElement        tobaccoNonUserElement
    * @param medicalReasonElement         medicalReasonElement
    * @param patientMostRecentHistoryList most recent history list
    * @return
    */

  def isCounselingNotPerformedAfterTobaccoScreeningUser(visit: CassandraRow, MeasureProperty: MeasureProperty, tobaccoUserElement: String, tobaccoNonUserElement: String, medicalReasonElement: String, patientMostRecentHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    val tobaccoUseScreeningUser1 = isTobaccoUsesScreeningUser(visit, MeasureProperty, tobaccoUserElement, tobaccoNonUserElement, patientMostRecentHistoryList)

    patientMostRecentHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
        medicalReasonElement.equalsIgnoreCase(x.getString(1))
        && (x.getDateTime(2).equals(tobaccoUseScreeningUser1.map(y => y.getDateTime(2)).toList(0)) ||
        x.getDateTime(2).isAfter(tobaccoUseScreeningUser1.map(y => y.getDateTime(2)).toList(0))
        )
    )
  }

  /**
    * This function check IOP - Moderate Stage.
    *
    * @param currentvisit       currentvisit from tblencounter on which computation has to be done.
    * @param m                  measureproperty
    * @param currentelement     currentelement that has to be checked
    * @param currentelementDate currentelement_Date that has to be checked
    * @param compareDate        Compare_Date that has to be compare currentelementDate
    * @param lowervalue         lowervalue of Moderate Stage.
    * @param uppervalue         uppervalue of Moderate Stage.
    * @return
    */
  def isIOPModerateStage(currentvisit: CassandraRow, m: MeasureProperty, currentelement: String, currentelementDate: String, compareDate: String, lowervalue: Double = 16, uppervalue: Double = 18): Boolean = {
    var isExist = false
    try {
      isExist = !checkNull(currentvisit, m, currentelement) &&
        isDateEqual(currentvisit, m, currentelementDate, compareDate) &&
        (currentvisit.getDouble(currentelement) >= lowervalue && currentvisit.getDouble(currentelement) <= uppervalue)

      val argsArray: Array[String] = Array(currentelement, currentelementDate,lowervalue.toString,uppervalue.toString)
      measureLogger(currentvisit, m, "isIOPMildStage", currentelement, isExist, argsArray)


    }
    catch {
      case e: Exception => {
     //   postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isIOPModerateStage:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }

    }
    isExist
  }

  /**
    * This function check IOP - Mild Stage.
    *
    * @param currentvisit       currentvisit from tblencounter on which computation has to be done.
    * @param m                  measureproperty
    * @param currentelement     currentelement that has to be checked
    * @param currentelementDate currentelement_Date that has to be checked
    * @param compareDate        Compare_Date that has to be compare currentelementDate
    * @param lowervalue         lowervalue of Mild Stage.
    * @param uppervalue         uppervalue of Mild Stage.
    * @return
    */
  def isIOPMildStage(currentvisit: CassandraRow, m: MeasureProperty, currentelement: String, currentelementDate: String, compareDate: String, lowervalue: Double = 19, uppervalue: Double = 22): Boolean = {
    var isExist = false
    try {
      isExist =
        (
          !checkNull(currentvisit, m, currentelement)
            &&
            isDateEqual(currentvisit, m, currentelementDate, compareDate)
            &&
            (
              currentvisit.getInt(currentelement) >= lowervalue
                &&
                currentvisit.getInt(currentelement) <= uppervalue
              )
          )

      val argsArray: Array[String] = Array(currentelement,currentelementDate, lowervalue.toString,uppervalue.toString)
      measureLogger(currentvisit, m, "isIOPMildStage", currentelement, isExist, argsArray)


    }
    catch {
      case e: Exception => {
       // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isIOPMildStage:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function check IOP - Severe Stage.
    *
    * @param currentvisit       currentvisit from tblencounter on which computation has to be done.
    * @param m                  measureproperty
    * @param currentelement     currentelement that has to be checked
    * @param currentelementDate currentelement_Date that has to be checked
    * @param compareDate        Compare_Date that has to be compare currentelementDate
    * @param lowervalue         lowervalue of Severe Stage.
    * @return
    */

  def isIOPSevereStage(currentvisit: CassandraRow, m: MeasureProperty, currentelement: String, currentelementDate: String, compareDate: String, lowervalue: Double = 15): Boolean = {
    var isExist = false
    try {
      isExist =
        (
          !checkNull(currentvisit, m, currentelement)
            &&
            isDateEqual(currentvisit, m, currentelementDate, compareDate)
            &&
            currentvisit.getDouble(currentelement) >= lowervalue

          )
      val argsArray: Array[String] = Array(currentelement,currentelementDate, compareDate,lowervalue.toString)
      measureLogger(currentvisit, m, "isIOPSevereStage", currentelement, isExist, argsArray)



    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isIOPSevereStage:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * //  This function checks Best corrected visual Acuity with in 90 days from the currentElement_Date.
    *
    * @param currentvisit        currentvisit from tblencounter on which computation has to be done.
    * @param m                   measureproperty
    * @param Element             history Element
    * @param currentElement_Date CurrentElement_ date from tblencounter
    * @param ElementHistList     history Element list from Patient history List.
    * @param noofDays            no of days before that has to be checked.
    */

  def isBestCorrectedVisualAcuityValuewithin90days(currentvisit: CassandraRow, m: MeasureProperty, Element: String, currentElement_Date: String, noofDays: Int = 90, ElementHistList: Broadcast[List[CassandraRow]]): Boolean = {

    val elementValue: Array[String] = Array("20/10", "20/11", "20/12", "20/13", "20/14", "20/15", "20/16", "20/17", "20/18", "20/19", "20/2", "20/20", "20/21", "20/22", "20/23", "20/24", "20/25", "20/26", "20/28", "20/29", "20/3", "20/30", "20/31", "20/32", "20/33", "20/34", "20/35", "20/36", "20/37", "20/38", "20/39", "20/4", "20/5", "20/6", "20/7", "20/8", "20/9", "20/40")
    var isExist = false
    if (ElementHistList.value.nonEmpty) {
      try {

        isExist = ElementHistList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(currentvisit.getString("patientuid")))
          .exists(histvist => !histvist.isNullAt(3) &&
          histvist.getString(1).equalsIgnoreCase(Element) &&
          (!currentvisit.isNullAt(currentElement_Date)
            &&
            (
              currentvisit.getDateTime(currentElement_Date).minusDays(noofDays).equals(histvist.getDateTime(2))
                ||
                currentvisit.getDateTime(currentElement_Date).minusDays(noofDays).isAfter(histvist.getDateTime(2))
              )
            )
          &&
          elementValue.contains(histvist.getString(3))
        )
        val argsArray: Array[String] = Array(Element, currentElement_Date,noofDays.toString)
        measureLogger(currentvisit, m, "isBestCorrectedVisualAcuityValuewithin90days", Element, isExist, argsArray)


      }
      catch {
        case e: Exception => {
        //  postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isBestCorrectedVisualAcuityValuewithin90days:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist
  }


  /**
    * this function check whether value is given within range in patient history for within no. years from enddate
    *
    * @param visit          current visit
    * @param m              measure property
    * @param element        element name which need to be checked in patient history
    * @param year           no. of year back from enddate
    * @param lesserValue    is the user given value from which elementvalue must be greater and equal
    * @param greaterValue   is the user given value from which elementvalue must be lesser
    * @param patientHistory list of patient history
    * @return true if given value is within range for element date within years from enddate
    */
  def checkElementValuesInRangeInHistory(visit: CassandraRow, m: MeasureProperty, element: String, year: Int, lesserValue: Double, greaterValue: Double, patientHistory: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistory.value.nonEmpty) {
       // val endDate = m.quarterEndDate
//        val end_date = m.quarterEndDate

        isExist = patientHistory.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !x.isNullAt(3)
          && x.getString(1).equalsIgnoreCase(element)
          && (x.getDateTime(2).isAfter(m.quarterEndDate.minusYears(year)) || x.getDateTime(2).isEqual(m.quarterEndDate.minusYears(year)))
          && x.getDouble(3) <= greaterValue
          && x.getDouble(3) > lesserValue
        )
      }
      val argsArray: Array[String] = Array(element, year.toString,lesserValue.toString,greaterValue.toString)
      measureLogger(visit, m, "checkElementValuesInRangeInHistory", element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementValuesInRangeInHistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * this function check whether value is greater than or equal to given value in patient history before enddate
    *
    * @param visit          current visit
    * @param m              measure property
    * @param element        element name which need to be checked in patient history
    * @param value          is the user given value from which elementvalue must be greater and equal
    * @param patientHistory list of patient history
    * @return true if given value is greater than or equal to given value for element date before enddate from patient history
    */
  def checkElementGreaterOrEqualInHistory(visit: CassandraRow, m: MeasureProperty, element: String, value: Double, patientHistory: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistory.value.nonEmpty) {
        //val endDate = m.quarterEndDate
//        val end_date = m.quarterEndDate

        isExist = patientHistory.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).
          exists(x => !x.isNullAt(3)
          && x.getString(1).equalsIgnoreCase(element)
          && x.getDateTime(2).isBefore(m.quarterEndDate)
          && x.getDouble(3) >= value
        )
      }
      val argsArray: Array[String] = Array(element,value.toString)
      measureLogger(visit, m, "checkElementValuesInRangeInHistory", element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
     //0   postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementValuesInRangeInHistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This Function verifies physical exam performed before end of Measurement period.
    *
    * @param visit                  Current visit of the patient.
    * @param m                      Measure Property of the Measure.
    * @param resultElementInHistory Element whose result is to be verified in the period between start of measurement period  and start of measurement period before 12 months.
    * @param NoOfMonth              Number of Months.
    * @param HistoryList            Patient History List.
    * @return
    */
  def physicalExamResultInxMonthsHistory(visit: CassandraRow, m: MeasureProperty, resultElementInHistory: String, NoOfMonth: Int, HistoryList: Broadcast[List[CassandraRow]]): Boolean = {

//    val start_Date = m.quarterStartDate
    var isExist = false

    if (HistoryList.value.nonEmpty) {
      try {

        isExist = HistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>

            histvisit.getString(1).equalsIgnoreCase(resultElementInHistory)
            &&
            (
              (
                histvisit.getDateTime(2).isAfter(m.quarterStartDate.minusMonths(NoOfMonth))
                  &&
                  histvisit.getDateTime(2).isBefore(m.quarterStartDate)
                )

                || histvisit.getDateTime(2).equals(m.quarterStartDate)
              )
        )
        val argsArray: Array[String] = Array(resultElementInHistory, NoOfMonth.toString)
        measureLogger(visit, m, "physicalExamResultInxMonthsHistory", resultElementInHistory, isExist, argsArray)
      }
      catch {
        case e: Exception => {
        //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:physicalExamResultInxMonthsHistory:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist

  }


  def mostRecentElementResultGreatAndBeforeOrEqualInMonth(r: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, ValueStartRange: Double, month: Int, MostRecentList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (MostRecentList.value.nonEmpty) {

        isExist = MostRecentList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid")))
          .exists(x => !x.isNullAt(3)

            && mostRecentElement.equalsIgnoreCase(x.getString(1))

            && (r.getDateTime(elementDate).minusMonths(month).isBefore(x.getDateTime(2))
            || r.getDateTime(elementDate).minusMonths(month).isEqual(x.getDateTime(2)))

            && (x.getDouble(3) >= ValueStartRange)
        )

      }
      val argsArray: Array[String] = Array(elementDate,mostRecentElement, ValueStartRange.toString,month.toString)
      measureLogger(r, m, "mostRecentElementResultGreatAndBeforeOrEqualInMonth", mostRecentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentPerformedinHistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    return isExist

  }


  //
  //function for isDateOverlapsMeasurementPeriod ( used in this function DiagnosisStudyConcurrentwith)
  def isDateOverlapsMeasurementPeriod(r: CassandraRow, m: MeasureProperty, checkDate: String): Boolean = {
    var isExist = false
    //var endDate = m.quarterEndDate

    try {
      var eDate = convertDateToDDMMYYYY(m.quarterEndDate.toString)
      isExist = !r.isNullAt(checkDate) && (r.getDateTime(checkDate).isBefore(m.quarterEndDate) || r.getDateTime(checkDate).isEqual(m.quarterEndDate))
      val argsArray: Array[String] = Array(checkDate, eDate)
      measureLogger(r, m, "isDateOverlapsMeasurementPeriod", checkDate.toString, isExist, argsArray)
      isExist
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDateOverlapsMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    *
    * @param r                 most recent patient
    * @param m                 measures
    * @param elementDate       get element date
    * @param mostRecentElement get most recent element
    * @param month             get input as months
    * @param MostRecentList    get most recent element
    * @return yes and no based on mostRecentElementBeforeOrEqualInMonth
    */


  def mostRecentElementBeforeOrEqualInMonth(r: CassandraRow, m: MeasureProperty, elementDate: String, mostRecentElement: String, month: Int, MostRecentList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    if (MostRecentList.value.nonEmpty) {
      try {
        isExist = MostRecentList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid")))
          .exists(x =>
          mostRecentElement.equalsIgnoreCase(x.getString(1))
            && (r.getDateTime(elementDate).minusMonths(month).isBefore(x.getDateTime(2))
            || r.getDateTime(elementDate).minusMonths(month).isEqual(x.getDateTime(2)))
        )
        val argsArray: Array[String] = Array(mostRecentElement, elementDate.toString,month.toString)
        measureLogger(r, m, "mostRecentElementBeforeOrEqualInMonth", elementDate.toString, isExist, argsArray)
      }
      catch {
        case e: Exception => {
       //   postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:mostRecentElementBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }

      }
    }
    isExist
  }

  /**
    * This function verifies the null in history.
    *
    * @param visit         visit of the patient.
    * @param checkElements Element that has to be cheked.
    * @return
    */
  def isNotNullInhistory(visit: CassandraRow, checkElements: String*): Boolean = {
    var isExist = false
    try {
      isExist = checkElements.forall(element => !visit.isNullAt(element))
      val argsArray: Array[String] = Array(checkElements.mkString(","))
      //measureLogger(visit,,  "mostRecentElementBeforeOrEqualInMonth", checkElements.mkString(","), isExist, argsArray)
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isNullInhistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  def wasProcedurePerformedXYearsInHistory(visit: CassandraRow, m: MeasureProperty, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    val End_Date = m.quarterEndDate
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>
          histvisit.getString(1).equalsIgnoreCase(historyElement)
          &&
          (
            (histvisit.getDateTime(2).isBefore(End_Date) && histvisit.getDateTime(2).isAfter(End_Date.minusYears(noOfYears)))
              ||
              histvisit.getDateTime(2).equals(End_Date) || histvisit.getDateTime(2).equals(End_Date)
            )
        )
        val argsArray: Array[String] = Array(historyElement, noOfYears.toString)
        measureLogger(visit, m, "wasProcedurePerformedXYearsInHistory", historyElement, isExist, argsArray)

      }

    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:wasProcedurePerformedXYearsInHistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /** PARENT Function
    * this function will give list of patientuid and count of all the element passed in arugment from historyRDD within measurement Period
    *
    * @param historyRdd history RDD
    * @param element    elements of which we need count patient wise
    * @return List of patientuid and count of element passed in parameter
    */

  def countElement(historyRdd: RDD[CassandraRow], m: MeasureProperty, element: String*): List[(String, Int)] = {

    val countRdd = historyRdd.filter(r =>

      ((r.getDateTime(2).isAfter(m.quarterStartDate) && r.getDateTime(2).isBefore(m.quarterEndDate)) || r.getDateTime(2).isEqual(m.quarterEndDate) || r.getDateTime(2).isEqual(m.quarterStartDate))

        && element.toList.contains(r.getString(1).toLowerCase()))

      .map(z => (z.getString("patientuid"), 1)).reduceByKey(_ + _)

      .collect().toList

    countRdd
  }

  //*************************************************************************************************************************************************************
  //*************************************************************************************************************************************************************
  //*************************************************************************************************************************************************************

  /**
    * 236,
    *
    * @param Visit       CurrentVisit RDD coming from tblencounter
    * @param m           Measure condition and Measure Name
    * @param Element     Element which has to be check in history.
    * @param historyList List of History Element
    * @param NoOfMonths  No of Months to be added in the start Date
    * @return Boolean
    */
  def wasDiagnosedInFirstXMonths(Visit: CassandraRow, m: MeasureProperty, Element: String, historyList: Broadcast[List[CassandraRow]], NoOfMonths: Int = 6): Boolean = {
    var isExist = false
    if (historyList.value.nonEmpty) {
//      var StartDate = m.quarterStartDate
//      var EndDate = m.quarterEndDate

      val ForwardDate = m.quarterStartDate

      try {
        isExist = historyList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(Visit.getString("patientuid")))
          .exists(histvisit =>  histvisit.getString(1).equalsIgnoreCase(Element)
          && (histvisit.getDateTime(2).isBefore(ForwardDate.plusMonths(NoOfMonths))
          || histvisit.getDate(2).equals(ForwardDate.plusMonths(NoOfMonths)))
        )
        val argsArray: Array[String] = Array(Element, m.quarterEndDate.toString)
        measureLogger(Visit, m, "wasDiagnosedInFirstXMonths", Element, isExist, argsArray)
      }
      catch {
        case e: Exception => {
        //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasDiagnosedInFirstXMonths:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist

  }

  //236
  def isDiastolicBPSystolicBPPerformedOnEncounter(currentVisit: CassandraRow, measureProperty: MeasureProperty, Element1: String, Element2: String, Element1Date: String, Element2Date: String, Lower: Double, Upper: Double): Boolean = {
    var isExist = false
    try {
      isExist = (!currentVisit.isNullAt(Element1) && isDateEqual(currentVisit, measureProperty, Element1Date, "encounterdate") && currentVisit.getDouble(Element1) < Upper) &&
        (!currentVisit.isNullAt(Element2) && isDateEqual(currentVisit, measureProperty, Element2Date, "encounterdate") && currentVisit.getDouble(Element2) < Lower)
      val argsArray: Array[String] = Array(Element1, Upper.toString, Element2, Lower.toString,Element1Date,Element2Date)
      measureLogger(currentVisit, measureProperty, "isDiastolicBPSystolicBPPerformedOnEncounter", Element1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isDiastolicBPSystolicBPPerformedOnEncounter:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    *
    * This function verifies that History element is present in the range between end of MeasurementPeriod and endDate minus noOfyear.
    *
    * @param visit              Current Visit of the patient.
    * @param m                  Measure Property of the measure.
    * @param historyElement     History Element that has to be look in the Patient History Table.
    * @param noOfYears          Number of Year that has to be subtracted from endOfmeasurement Period(endDate).
    * @param patientHistoryList Patient History List.
    * @return It will return whether the procedure of a patient is performed in the range between end of MeasurementPeriod and endDate minus noOfyear.
    */
  def wasProcedurePerformedInXYears(visit: CassandraRow, m: MeasureProperty, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
//    val endDate = m.quarterEndDate
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(histvisit =>
           histvisit.getString(1).equalsIgnoreCase(historyElement)
          &&
          (
            (histvisit.getDateTime(2).isBefore(m.quarterEndDate) && histvisit.getDateTime(2).isAfter(m.quarterEndDate.minusYears(noOfYears)))
              ||
              histvisit.getDateTime(2).equals(m.quarterEndDate) || histvisit.getDateTime(2).equals(m.quarterEndDate.minusYears(noOfYears))
            )
        )
        val argsArray: Array[String] = Array(historyElement, noOfYears.toString)
        measureLogger(visit, m, "wasProcedurePerformedInXYears", historyElement, isExist, argsArray)

      }

    }
    catch {
      case e: Exception => {
     //   postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:wasProcedurePerformedInXYears:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This is renamed function and renamed from  isAssessmentBeforeValue
    * This function verifies the assessment is performed less than a value.
    *
    * @param visit              current visit of the patient.
    * @param m                  measure property of the measure.
    * @param Value              value that is to be compared
    * @param histroyElement     history element that has to be verified in the history.
    * @param patientHistoryList patient history list .
    * @return true or false based on isAssessmentPerformedLessThanX
    */

  def isElementValueGreaterThanX(visit: CassandraRow, m: MeasureProperty, Value: Double, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x => !x.isNullAt(3) &&
           x.getString(1).equalsIgnoreCase(histroyElement) &&
          x.getDouble(3) > Value
        )
      }
      val argsArray: Array[String] = Array(histroyElement,Value.toString)
      measureLogger(visit, m, "isElementValueGreaterThanX", histroyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentPerformedLessThanX:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This is renamed function and renamed from  isAssessmentBeforeValue
    * This function verifies the assessment is performed less than a value.
    *
    * @param visit              current visit of the patient.
    * @param m                  measure property of the measure.
    * @param Value              value that is to be compared
    * @param histroyElement     history element that has to be verified in the history.
    * @param patientHistoryList patient history list .
    * @return true or false based on isAssessmentPerformedLessThanX
    */

  def isElementValueGreaterOrEqualThanX(visit: CassandraRow, m: MeasureProperty, Value: Double, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x => !x.isNullAt(3) &&
          x.getString(1).equalsIgnoreCase(histroyElement) &&
          x.getDouble(3) >= Value
        )
      }
      val argsArray: Array[String] = Array(histroyElement,Value.toString)
      measureLogger(visit, m, "isElementValueGreaterOrEqualThanX", histroyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentPerformedLessThanX:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

/*

  def isElementPresentBeforeOrEqual(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    //val elementDate:String = if(!element.equalsIgnoreCase("encounterdate")) element+"_date" else element
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.exists(x =>
          !visit.isNullAt(elementDate)
            && !x.isNullAt(2)
            && visit.getString("patientuid").equals(x.getString("patientuid"))

            && histroyElement.equalsIgnoreCase(x.getString(1)) &&

            (x.getDateTime(2).isBefore(visit.getDateTime(elementDate)) ||
              x.getDateTime(2).isEqual(visit.getDateTime(elementDate))
              )

        )

        val argsArray: Array[String] = Array(histroyElement, visit.getString(elementDate))
        measureLogger(visit, m, "isAssessmentPerformed", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        println("" + e.getMessage)
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentPerformed:" + e.printStackTrace(), "FAIL")
       loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }

    return isExist

  }
*/


  /** PARENT Function
    * This Function verifies the assessment of a patient is performed  greater than value.
    *
    * @param visit              current Visit of the patient.
    * @param m                  measure property of the measure(mesureId and condition)
    * @param elementName        ElementName that has to be look in the history.
    * @param value              Value that has to be verified.
    * @param flag               flag that will define the condition whether to check greater or greaterEqualto condition.
    * @param patientHistoryList Patient history list.
    * @return
    */
  def checkElementValueDuringMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, elementName: String, value: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
//        var startDate = m.quarterStartDate
//        var endDate = m.quarterEndDate

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !x.isNullAt(3) &&
            x.getString(1).equalsIgnoreCase(elementName)
            &&
            (
              (x.getDateTime(2).isBefore(m.quarterEndDate) && x.getDateTime(2).isAfter(m.quarterStartDate))
                ||
                x.getDateTime(2).isEqual(m.quarterStartDate) || x.getDateTime(2).isEqual(m.quarterEndDate)
              )
            && compareValueStatus(x.getDouble(3), flag, value))

      }

      val argsArray: Array[String] = Array(elementName, value.toString, flag)
      measureLogger(visit, m, "checkElementValueDuringMeasurementPeriod", elementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementValueDuringMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /** PARENT Function
    * this function returns true history element found within X period from encounter date
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param historyElement     history element which will be checked for overlaps encounter date
    * @param calenderUnit calender unit
    * @param calenderInterval               no. of interval before encounter date
    * @param patientHistoryList list of patient history
    * @return true if history element found within X period from encounter date
    */
  def wasElementPresentBeforeOrEqualElementInXPeriod(visit: CassandraRow, m: MeasureProperty, historyElement: String, calenderUnit: String, calenderInterval:Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val higherDate=visit.getDateTime("encounterdate")
    val lowerDate=lowerCalenderDate(higherDate,calenderUnit,calenderInterval)

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           historyElement.equalsIgnoreCase(x.getString(1))
            && checkDateInDateRange(x.getDateTime(2),lowerDate,higherDate,"ge","le")
        )
        val argsArray: Array[String] = Array(historyElement, calenderUnit ,calenderInterval.toString)
        measureLogger(visit, m, "wasElementPresentBeforeOrEqualEncounterInXPeriod", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentBeforeOrEqualEncounterInXPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * this function will give list of patientuid and count of all the element passed in arugment from historyRDD within months before start of measurement Period
    *
    * @param historyRdd history RDD
    * @param m          measure property
    * @param months     no. of months looks back from start of measurement Period
    * @param element    elements of which we need count patient wise
    * @return List of patientuid and count of element passed in paramete
    */
  def countElementWithinMonthsInHistory(historyRdd: RDD[CassandraRow], m: MeasureProperty, months: Int, element: String*): List[(String, Int)] = {

    val startDate = m.quarterStartDate
    val endDate = m.quarterEndDate

    val countRdd = historyRdd.filter(r =>

      ((r.getDateTime(2).isAfter(startDate.minusMonths(months)) && r.getDateTime(2).isBefore(startDate))
        || r.getDateTime(2).isEqual(startDate.minusMonths(months)) || r.getDateTime(2).isEqual(startDate))

        && element.toList.contains(r.getString(1).toLowerCase()))

      .map(z => (z.getString("patientuid"), 1)).reduceByKey(_ + _)

      .collect().toList

    countRdd
  }


  /**
    * This Function verifies the assessment of a patient  is performed before encounterDate greater,lesser,greaterEqualto and lesserEqualto than required value.
    *
    * @param visit              current Visit of the patient.
    * @param m                  measure property of the measure(measureId and condition)
    * @param value              value that has to verified with the element value.
    * @param elementName        Element Name that has to be look in the history.
    * @param flag               flag that will define the condition whether to check greater or greaterEqualto condition.
    * @param patientHistoryList Patient history list.
    * @return It will return those patient whose MostRecent Laboratory Test result value in a range between endDate and endDate before X years.
    */
  def isAssessmentLessThanBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, value: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          !visit.isNullAt("encounterdate")
          &&
          !x.isNullAt(3)
          &&
          x.getString(1).equalsIgnoreCase(elementName)
          &&
          x.getDateTime(2).isBefore(visit.getDateTime("encounterdate"))
          && compareValueStatus(x.getDouble(3), flag, value))

      }

      val argsArray: Array[String] = Array(elementName, value.toString,flag)
      measureLogger(visit, m, "isAssessmentLessThanBeforeEncounter", elementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentLessThanBeforeEncounter:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit                        current Visit of the patient.
    * @param m                            measure property of the measure(measureId and condition)
    * @param histroyElement1              histroyElement1 Name that has to be look in the history.
    * @param histroyElement2              histroyElement2 Name that has to be look in the history.
    * @param month                        Month minus from end date
    * @param patientHistoryMostRecentList most recent Patient history list.
    * @param patientHistoryList           Patient history list.
    * @return It will return if Patient Tobacco NonUser Within 24Months
    */
  def wasPatientTobaccoNonUserWithin24Months(visit: CassandraRow, m: MeasureProperty, histroyElement1: String, histroyElement2: String, month: Int, patientHistoryMostRecentList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    var isExist = false
//    val end_Date = m.quarterEndDate
    try {
      isExist = patientHistoryMostRecentList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
        histroyElement1.equalsIgnoreCase(x.getString(1))
          && (
          (x.getDateTime(2).isBefore(m.quarterEndDate) && x.getDateTime(2).isAfter(m.quarterEndDate.minusMonths(month)))

            || x.getDateTime(2).isEqual(m.quarterEndDate.minusMonths(month)) || x.getDateTime(2).isEqual(m.quarterEndDate))
          &&
          patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
            .exists(y => !y.isNullAt(2)
            && histroyElement2.equalsIgnoreCase(y.getString(1))
            && y.getDateTime(2).isEqual(x.getDateTime(2))
          )
      )
      val argsArray: Array[String] = Array(histroyElement1,histroyElement2, month.toString)
      measureLogger(visit, m, "wasPatientTobaccoNonUserWithin24Months", histroyElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPatientTobaccoNonUserWithin24Months:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit                        current Visit of the patient.
    * @param m                            measure property of the measure(measureId and condition)
    * @param histroyElement1              histroyElement1 Name that has to be look in the history.
    * @param histroyElement2              histroyElement2 Name that has to be look in the history.
    * @param month                        Month minus from end date
    * @param patientHistoryMostRecentList most recent Patient history list.
    * @param patientHistoryList           Patient history list.
    * @return It will return if Patient Tobacco User Within 24Months
    */
  def wasPatientTobaccoUserWithin24Months(visit: CassandraRow, m: MeasureProperty, histroyElement1: String, histroyElement2: String, month: Int, patientHistoryMostRecentList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val end_Date = m.quarterEndDate
    try {
      isExist = patientHistoryMostRecentList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         histroyElement1.equalsIgnoreCase(x.getString(1))
          && (
          (x.getDateTime(2).isBefore(m.quarterEndDate) && x.getDateTime(2).isAfter(m.quarterEndDate.minusMonths(month)))

            || x.getDateTime(2).isEqual(m.quarterEndDate.minusMonths(month)) || x.getDateTime(2).isEqual(m.quarterEndDate))
          &&
          patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
            .exists(y => !y.isNullAt(2)
            && histroyElement2.equalsIgnoreCase(y.getString(1))
            && y.getDateTime(2).isEqual(x.getDateTime(2))
          )
      )
      val argsArray: Array[String] = Array(histroyElement1, histroyElement2,month.toString)
      measureLogger(visit, m, "wasPatientTobaccoUserWithin24Months", histroyElement1, isExist, argsArray)
    }

    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPatientTobaccoUserWithin24Months:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit                        current Visit of the patient.
    * @param m                            measure property of the measure(measureId and condition)
    * @param histroyElement1              histroyElement1 Name that has to be look in the history.
    * @param histroyElement2              histroyElement2 Name that has to be look in the history.
    * @param month                        Month minus from end date
    * @param patientHistoryMostRecentList most recent Patient history list.
    * @param patientHistoryList           Patient history list.
    * @return It will return if Patient tobacco Cessation Intervention Done After Tobacco Screening User
    */

  def tobaccoCessationInterventionDoneAfterTobaccoScreeningUser(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement1: String, histroyElement2: String, month: Int, patientHistoryMostRecentList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val end_Date = m.quarterEndDate
    try {
      isExist = patientHistoryMostRecentList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         histroyElement1.equalsIgnoreCase(x.getString(1))
          && (
          (x.getDateTime(2).isBefore(m.quarterEndDate) && x.getDateTime(2).isAfter(m.quarterEndDate.minusMonths(month)))

            || x.getDateTime(2).isEqual(m.quarterEndDate.minusMonths(month)) || x.getDateTime(2).isEqual(m.quarterEndDate))
          &&
          patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
            .exists(y =>   histroyElement2.equalsIgnoreCase(y.getString(1))
            && y.getDateTime(2).isEqual(x.getDateTime(2))
          )
          && (visit.getDateTime(elementDate).isAfter(x.getDateTime(2)) || visit.getDateTime(elementDate).isEqual(x.getDateTime(2)))
      )
      val argsArray: Array[String] = Array(histroyElement1, month.toString)
      measureLogger(visit, m, "TobaccoCessationInterventionDoneAfterTobaccoScreeningUser", histroyElement2, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPatientTobaccoUserWithin24Months:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit              current Visit of the patient.
    * @param m                  measure property of the measure(measureId and condition)
    * @param elementName        histroyElement Name that has to be look in the history.
    * @param patientHistoryList Patient history list.
    * @return It will return true if Influenza element was present Period Last Five Month In History
    */
  def wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    val year = m.quarterStartDate.getYear- 1
    val sdf = new SimpleDateFormat(dateFormat)
    val sDate: Date = sdf.parse(year + "-08-01")
    val eDate: Date = sdf.parse(year + "-12-31")
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>
           x.getString(1).equalsIgnoreCase(elementName)
          &&
          ((x.getDate(2).after(sDate) && x.getDate(2).before(eDate)) ||
            (x.getDate(2).equals(sDate) || x.getDate(2).equals(eDate)))
        )
      }

      val argsArray: Array[String] = Array(elementName, sDate.toString, eDate.toString)
      measureLogger(visit, m, "wasDuringInfluenzaPeriodLastFiveMonthInHistory", elementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
     //   postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDuringInfluenzaPeriodLastFiveMonthInHistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit              current Visit of the patient.
    * @param m                  measure property of the measure(measureId and condition)
    * @param elementName        histroyElement Name that has to be look in the history.
    * @param patientHistoryList Patient history list.
    * @return It will return true if Influenza element was present Period Last Five Month In History
    */
  def wasDuringInfluenzaPeriodLastThreeMonthInHistory(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    val year = m.quarterStartDate.getYear- 1
    val sdf = new SimpleDateFormat(dateFormat)
    val sDate: Date = sdf.parse(year + "-10-01")
    val eDate: Date = sdf.parse(year + "-12-31")
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>
           x.getString(1).equalsIgnoreCase(elementName)
          &&
          ((x.getDate(2).after(sDate) && x.getDate(2).before(eDate)) ||
            (x.getDate(2).equals(sDate) || x.getDate(2).equals(eDate)))
        )
      }

      val argsArray: Array[String] = Array(elementName, sDate.toString, eDate.toString)
      measureLogger(visit, m, "wasDuringInfluenzaPeriodLastThreeMonthInHistory", elementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //   postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDuringInfluenzaPeriodLastFiveMonthInHistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    *
    *
    * This Function verifies the mostRecent Physical Exam performed  of a patient  is performed before another Element greater,lesser,greaterEqualto and lesserEqualto than required value.
    *
    * @param visit                        current Visit of the patient.
    * @param m                            measure property of the measure(measureId and condition)
    * @param value                        value that has to verified with the element value.
    * @param historyElementName           Element Name that has to be look in the history.
    * @param currentElement               Current element whose date has to be compared.
    * @param flag                         flag that will define the condition whether to check greater or greaterEqualto condition.
    * @param mostRecentpatientHistoryList Patient history list.
    * @return It will return those patient whose Test result value before another ElementDate.
    */
  //isMostRecentPhysicalExamPerformedBefore
  def checkElementValueBeforeElement(visit: CassandraRow, m: MeasureProperty, historyElementName: String, currentElement: String, value: Double, flag: String, mostRecentpatientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (mostRecentpatientHistoryList.value.nonEmpty) {
        val currentElementDate = currentElement + "_date"

        isExist = mostRecentpatientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !x.isNullAt(3) &&
          !visit.isNullAt(currentElement) && !visit.isNullAt(currentElementDate)
          &&
          x.getString(1).equalsIgnoreCase(historyElementName)
          &&
          x.getDateTime(2).isBefore(visit.getDateTime(currentElementDate))
          &&
          compareValueStatus(x.getDouble(3), flag, value))

      }

      val argsArray: Array[String] = Array(currentElement,historyElementName, value.toString,flag)
      measureLogger(visit, m, "checkElementValueBeforeElement", currentElement, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isMostRecentPhysicalExamPerformedBefore:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit              current Visit of the patient.
    * @param m                  measure property of the measure(measureId and condition)
    * @param histroyElement     Element Name that has to be look in the history.
    * @param month              Month minus from end date
    * @param patientHistoryList Patient history list.
    * @return It will return true if Assessment was Not Performed In History
    */

  def wasAssessmentNotPerformedInHistory(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        //val endDate: Date = globalEndDate
//        val end_Date = m.quarterEndDate
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equalsIgnoreCase(histroyElement)
            &&
            (
              x.getDateTime(2).isBefore(m.quarterEndDate)
                ||
                x.getDateTime(2).isEqual(m.quarterEndDate)
              )
            &&
            (
              x.getDateTime(2).isAfter(m.quarterEndDate.minusMonths(month))
                ||
                x.getDateTime(2).isEqual(m.quarterEndDate.minusMonths(month))
              )
        )
        val argsArray: Array[String] = Array(histroyElement,month.toString)
        measureLogger(visit, m, "wasAssessmentNotPerformedInHistory", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAssessmentNotPerformedInHistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit              cassendra row
    * @param m                  property
    * @param elementDate        get date fromuser
    * @param histroyElement     get date fromuser
    * @param patientHistoryList get date fromuser
    * @return true or false based on  wasDiagnosedBefore
    */

  def wasDiagnosedBefore(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>
          histroyElement.equalsIgnoreCase(x.getString(1)) &&
          x.getDateTime(2).isBefore(visit.getDateTime(elementDate))

        )
      }
      val argsArray: Array[String] = Array(elementDate,histroyElement)
      measureLogger(visit, m, "wasDiagnosedBefore", elementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasDiagnosedBefore:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    *
    * @param visit                        current Visit of the patient.
    * @param m                            measure property of the measure(measureId and condition)
    * @param histroyElement1              histroyElement1 Name that has to be look in the history.
    * @param histroyElement2              histroyElement2 Name that has to be look in the history.
    * @param month                        Month minus from end date
    * @param patientHistoryMostRecentList most recent Patient history list.
    * @param patientHistoryList           Patient history list.
    * @return It will return if Patient Tobacco User Within XMonths
    */
  def wasPatientTobaccoUserWithinXMonths(visit: CassandraRow, m: MeasureProperty, histroyElement1: String, histroyElement2: String, month: Int, patientHistoryMostRecentList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val end_Date = m.quarterEndDate
    try {
      isExist = patientHistoryMostRecentList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
        .exists(x =>
         histroyElement1.equalsIgnoreCase(x.getString(1))
          && (
          (x.getDateTime(2).isBefore(m.quarterEndDate) && x.getDateTime(2).isAfter(m.quarterEndDate.minusMonths(month)))

            || x.getDateTime(2).isEqual(m.quarterEndDate.minusMonths(month)) || x.getDateTime(2).isEqual(m.quarterEndDate))
          &&
          patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
            .exists(y =>
             histroyElement2.equalsIgnoreCase(y.getString(1))

            && y.getDateTime(2).isEqual(x.getDateTime(2))
          )
      )
      val argsArray: Array[String] = Array(histroyElement1, histroyElement2,month.toString)
      measureLogger(visit, m, "wasPatientTobaccoUserWithinXMonths", histroyElement1, isExist, argsArray)
    }

    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPatientTobaccoUserWithinXMonths:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /** PARENT Function
    * This function verifies if one element was before or equal to element date
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param elementDate        element date to be compare with encounter date
    * @param historyElement     element to be checked on history
    * @param patientHistoryList patient history list
    * @return returns true if element was
    */

  def wasElementBeforeOrEqualInHistory(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          historyElement.equalsIgnoreCase(x.getString(1)) &&
          historyElement.equalsIgnoreCase(x.getString(1)) &&
          (x.getDateTime(2).isBefore(visit.getDateTime(elementDate)) ||
            x.getDateTime(2).isEqual(visit.getDateTime(elementDate))
            )
        )
      }
      val argsArray: Array[String] = Array(elementDate,historyElement)
      measureLogger(visit, m, "wasElementBeforeOrEqualInHistory", elementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementBeforeOrEqualInHistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit                        current Visit of the patient.
    * @param m                            measure property of the measure(measureId and condition)
    * @param histroyElement1              histroyElement1 Name that has to be look in the history.
    * @param histroyElement2              histroyElement2 Name that has to be look in the history.
    * @param patientHistoryMostRecentList most recent Patient history list.
    * @param patientHistoryList           Patient history list.
    * @return returns true if on most recent date elements "Diastolic Blood Pressure" and "Systolic Blood Pressure" are not null.
    */
  def mostRecentPhysicalExamPerforrmedDuringEncounter(visit: CassandraRow, m: MeasureProperty, histroyElement1: String, histroyElement2: String, patientHistoryMostRecentList: List[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val end_Date = m.quarterEndDate
    try {
      isExist = patientHistoryMostRecentList.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         histroyElement1.equalsIgnoreCase(x.getString(1))
          && (
          (x.getDateTime(2).isBefore(m.quarterEndDate) || x.getDateTime(2).isEqual(m.quarterEndDate))
            &&
            patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
              .exists(y => !y.isNullAt(2)
                        &&
               histroyElement2.equalsIgnoreCase(y.getString(1))

              && y.getDateTime(2).isEqual(x.getDateTime(2))
            )
          ))
      val argsArray: Array[String] = Array(histroyElement1,histroyElement2)
      measureLogger(visit, m, "mostRecentPhysicalExamPerforrmedDuringEncounter", histroyElement1, isExist, argsArray)
    }

    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:mostRecentPhysicalExamPerforrmedDuringEncounter:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit               current visit
    * @param m                   measure property
    * @param elementDate         counselling element
    * @param histroyElement1     most recent screening element
    * @param histroyElement2     tobacco user
    * @param day                 day in integer
    * @param patientHistoryList1 patientHistoryList1
    * @param patientHistoryList2 patientHistoryList2
    * @return
    */

  def interventionOrderWithinOneDayofEncounter(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement1: String, histroyElement2: String, day: Int, patientHistoryList1: Broadcast[List[CassandraRow]], patientHistoryList2: Broadcast[List[CassandraRow]]): Boolean = {

//    val end_Date = m.quarterEndDate
    var isExist = false
    try {
      isExist = patientHistoryList1.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>

       histroyElement1.equalsIgnoreCase(x.getString(1))

          &&

          patientHistoryList2.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
            .exists(y =>  histroyElement2.equalsIgnoreCase(y.getString(1))

            && y.getDateTime(2).isEqual(x.getDateTime(2))

          )

          && (

          x.getDateTime(2).isEqual(visit.getDateTime(elementDate)) || x.getDateTime(2).isBefore(visit.getDateTime(elementDate).plusDays(day))
          )


      )

      val argsArray: Array[String] = Array( elementDate,histroyElement1, histroyElement2,day.toString)
      measureLogger(visit, m, "interventionOrderWithinOneDayofEncounter", elementDate, isExist, argsArray)


    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:interventionOrderWithinOneDayofEncounter:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * This function verifies that History element is present in the range between encounterDate and encounterDate minus noOfyear.
    *
    * @param visit              Current Visit of the patient.
    * @param m                  Measure Property of the measure.
    * @param elementDate        element date from current visit
    * @param historyElement     History Element that has to be look in the Patient History Table.
    * @param noOfYears          Number of Year that has to be subtracted from endOfmeasurement Period(endDate).
    * @param patientHistoryList Patient History List.
    * @return It will return whether the physical exam of a patient was performed in the range between encounterDate and encounterDate minus noOfyear.
    */
  def physicalExamPerformedNotDoneSysDiasWithinOneYearBeforeElement(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, noOfYears: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(histvisit =>
          histvisit.getString(1).equalsIgnoreCase(historyElement)
          &&
          (
            (histvisit.getDateTime(2).isBefore(visit.getDateTime(elementDate)) && histvisit.getDateTime(2).isAfter(visit.getDateTime(elementDate).minusYears(noOfYears)))
              ||
              histvisit.getDateTime(2).equals(visit.getDateTime(elementDate)) || histvisit.getDateTime(2).equals(visit.getDateTime(elementDate).minusYears(noOfYears))
            )
        )
        val argsArray: Array[String] = Array(elementDate, historyElement, noOfYears.toString)
        measureLogger(visit, m, "physicalExamPerformedNotDoneSysDiasWithinOneYearBeforeElement", elementDate, isExist, argsArray)

      }
    }
    catch {
      case e: Exception => {
     //   postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:physicalExamPerformedNotDoneSysDiasWithinOneYearBeforeElement:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit               current visit
    * @param m                   measure property
    * @param histroyElement1     element
    * @param histroyElement2     element to be checked in range
    * @param day                 day in integer
    * @param patientHistoryList1 patientHistoryList1
    * @param patientHistoryList2 patientHistoryList2
    * @return returns true if historyelement2 is in between historyelement1_date and (historyelement1_date + 1 day)
    */

  def isReasonElementPresentWithinDayAfterElement(visit: CassandraRow, m: MeasureProperty, histroyElement1: String, histroyElement2: String, day: Int, patientHistoryList1: Broadcast[List[CassandraRow]], patientHistoryList2: Broadcast[List[CassandraRow]]): Boolean = {

    var isExist = false
    try {
      isExist = patientHistoryList1.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>

       histroyElement1.equalsIgnoreCase(x.getString(1))

          &&

          patientHistoryList2.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
            .exists(y =>  histroyElement2.equalsIgnoreCase(y.getString(1))

            && (
            y.getDateTime(2).isEqual(x.getDateTime(2))
              ||
              y.getDateTime(2).isBefore(x.getDateTime(2).plusDays(day))
            )

          )


      )

      val argsArray: Array[String] = Array(histroyElement1, histroyElement2,day.toString)
      measureLogger(visit, m, "isReasonElementPresentWithinDayAfterElement", histroyElement1, isExist, argsArray)


    }
    catch {
      case e: Exception => {
     //   postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:IsReasonElementPresentWithinDayAfterElement:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This Function verifies the physical exam performed of patient for Retinal Dilated.
    *
    * @param visit                 current visit of the patient.
    * @param m                     Measure Property of the measure.
    * @param ElementCheckInHistory Element that has to be verified in the history.
    * @param NoOfMonth             No of months that has to be go back from start date.
    * @param flag                  comperator operator
    * @param HistoryList           Patient History List.
    * @return This Function verifies those patient whose Retinal dialted Exam is performed in a range between start of the measurement period and start date minus no. of months.
    */
  def wasPhysicalExamPerformedXForRetinalDilatedExam(visit: CassandraRow, m: MeasureProperty, ElementCheckInHistory: String, NoOfMonth: Int,flag:String ,HistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    var isExist = false

    try {
      if (HistoryList.value.nonEmpty) {
        //var sDate = m.quarterStartDate

//        val startDate = m.quarterStartDate

        isExist = HistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(histvisit =>
          histvisit.getString(1).equalsIgnoreCase(ElementCheckInHistory)
          &&
          /*(
            (
              histvisit.getDateTime(2).isAfter( m.quarterStartDate.minusMonths(NoOfMonth))
                &&
                histvisit.getDateTime(2).isBefore( m.quarterStartDate)
              )
              ||
              histvisit.getDateTime(2).isEqual( m.quarterStartDate.minusMonths(NoOfMonth))
              ||
              histvisit.getDateTime(2).isEqual( m.quarterStartDate)

            )*/
            compareTimeOperator(histvisit.getDateTime(2),m.quarterStartDate.minusMonths(NoOfMonth),m.quarterStartDate,flag)
        )
      }
      val argsArray: Array[String] = Array(ElementCheckInHistory, NoOfMonth.toString)
      measureLogger(visit, m, "wasPhysicalExamPerformedXForRetinalDilatedExam", ElementCheckInHistory, isExist, argsArray)
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPhysicalExamPerformedXForRetinalDilatedExam:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }

    isExist
  }

  /**
    *
    * @param visit
    * @param m
    * @param histroyElement1
    * @param histroyElement2
    * @param month
    * @param patientHistoryList
    * @return
    */
  def wasPatientTobaccoUserWithinXMonths(visit: CassandraRow, m: MeasureProperty, histroyElement1: String, histroyElement2: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val end_Date = m.quarterEndDate
    try {

      isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
        .exists(x =>
        histroyElement1.equalsIgnoreCase(x.getString(1))

          && (
          (x.getDateTime(2).isBefore(m.quarterEndDate) && x.getDateTime(2).isAfter(m.quarterEndDate.minusMonths(month)))

            || x.getDateTime(2).isEqual(m.quarterEndDate.minusMonths(month)) || x.getDateTime(2).isEqual(m.quarterEndDate))


          && patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(y => histroyElement2.equalsIgnoreCase(y.getString(1))

          && x.getDateTime(2).equals(y.getDateTime(2)))


      )
      val argsArray: Array[String] = Array(histroyElement1, histroyElement2,month.toString)
      measureLogger(visit, m, "wasPatientTobaccoUserWithinXMonthswasPatientTobaccoUserWithinXMonths", histroyElement1, isExist, argsArray)
    }

    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPatientTobaccoUserWithinXMonths:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /** PARENT Function
    * This function verifies if any adverse event happened with patient continued even after X hours
    *
    * @param visit              current visit of the patient
    * @param m                  Measure property of the measure
    * @param element1           Ischemic Stroke_Stop date time
    * @param element2           Ischemic Stroke_Start date time
    * @param NoOfHours          number of hours to check after element2
    * @param patientHistoryList Patient History List
    * @return returns true if any adverse event happened with patient continued even after X hours
    */


  def wasElementAfterElementInXHours(visit: CassandraRow, m: MeasureProperty, element1: String, element2: String, NoOfHours: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
        .exists(x =>

        x.getString(1).equalsIgnoreCase(element1)
        &&
        patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>

            y.getString(1).equalsIgnoreCase(element2) &&
            (
              x.getDateTime(2).equals(y.getDateTime(2).plusHours(NoOfHours))
                ||
                x.getDateTime(2).isAfter(y.getDateTime(2).plusHours(NoOfHours))
              )


        )
      )
      val argsArray: Array[String] = Array(element1, element2,NoOfHours.toString)
      measureLogger(visit, m, "wasElementAfterElementInXHours", element1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAdverseEventNotStoppedWithinXHours:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }

  /**
    * PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param elementName        element name whose date will be checked
    * @param patientHistoryList list of patient history
    * @return true if element is already present After encounter Date
    */
  def wasElementPresentAfterOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        val elementDate = if(!elementName.equalsIgnoreCase(AdminElements.Encounter_Date)) visit.getDateTime( elementName + "_date") else visit.getDateTime(AdminElements.Encounter_Date)
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>
         x.getString(1).equalsIgnoreCase(historyElement)
          && dateStatus(x.getDateTime(2),elementDate,CompareOperator.GREATER_EQUAL)
        )
      }
      val argsArray: Array[String] = Array(elementName, historyElement)
      measureLogger(visit, m, "wasElementPresentAfterOrEqualEncounter", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentBeforeOrEqualEncounter:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /** PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param currentElement element name whose date will be checked
    * @param compareOperator mention compare operator only {LESS_EQUAL or LESS}
    * @param historyElementName history list
    * @return true if element is already present before another element
    */
  def wasElementPresentBeforeOrEqualOtherElement(visit: CassandraRow, m: MeasureProperty, currentElement: String,compareOperator :String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: Seq[String]): Boolean = {

    val elementDate= if (currentElement.equalsIgnoreCase(AdminElements.Encounter_Date)) AdminElements.Encounter_Date else currentElement+"_date"
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         historyElementName.exists(y => x.getString(1).equalsIgnoreCase(y)
          && dateStatus(x.getDateTime(2),visit.getDateTime(elementDate),compareOperator)
        )

        )
      }
      val argsArray: Array[String] = Array(currentElement, compareOperator)
      measureLogger(visit, m, "wasElementPresentBeforeOrEqualOtherElement", currentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /** PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param patientHistoryList list of patient history
    * @return true if element is already present after another element
    */
  def wasElementPresentAfter(visit: CassandraRow, m: MeasureProperty, CurrentElementDate: String, patientHistoryList: Broadcast[List[CassandraRow]], HistoryelementName: Seq[String]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>
          HistoryelementName.exists(y => x.getString(1).equalsIgnoreCase(y)
          && x.getDate(2).after(visit.getDate(CurrentElementDate))
        )
          // && x.getDate(2).after(visit.getDate(HistoryelementName))


        )
      }
      val argsArray: Array[String] = Array(CurrentElementDate)
      measureLogger(visit, m, "wasElementPresentAfter", CurrentElementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function will return most recent list of patient records for each patient having element name being checked
    *
    * @param m                 current patient visit
    * @param elementName       element name for which most recent ot be calculated
    * @param patientHistoryRDD patient history rdd
    * @return returns most recent list of patient records for each patient having element name being checked
    */
  def mostRecentPhysicalExamPerformed(m: MeasureProperty, elementName: String, patientHistoryRDD: RDD[CassandraRow]): Array[CassandraRow] = {

//    val startDate = m.quarterStartDate
//    val endDate = m.quarterEndDate

   /* val mostRecentElements = patientHistoryRDD.filter(x =>  x.getString(1).equalsIgnoreCase(elementName) &&
      ((x.getDateTime(2).isAfter(m.quarterStartDate) && x.getDateTime(2).isBefore(m.quarterEndDate)) || x.getDateTime(2).isEqual(m.quarterStartDate) || x.getDateTime(2).isEqual(m.quarterEndDate))
    ).map(l => ((l.getString("patientuid"), l.getString(1)), l.getDateTime(2)))
      .reduceByKey((x, y) => if (x.isAfter(y)) x else y).collect()

    val mostRecentList = patientHistoryRDD.filter(r => mostRecentElements.exists(x => x._1._1.equalsIgnoreCase(r.getString("patientuid")) && x._1._2.equalsIgnoreCase(r.getString(1))
      && x._2.equals(r.getDate(2))
    )).collect()

    mostRecentList*/


    patientHistoryRDD.filter(l =>
      elementName.equalsIgnoreCase(l.getString(1)) &&
        ((l.getDateTime(2).isAfter(m.quarterStartDate) && l.getDateTime(2).isBefore(m.quarterEndDate)) || l.getDateTime(2).isEqual(m.quarterStartDate) || l.getDateTime(2).isEqual(m.quarterEndDate))
        )
      .map(l => ((l.getString(0), l.getString(1)), l))
      .reduceByKey((x, y) => if (x.getDate(2).after(y.getDate(2))) x else y).map(r=>r._2)
      .collect()
  }

  /**
    * This function will return first/least recent list of patient records for each patient having element name being checked
    *
    * @param m                 current patient visit
    * @param elementName       element name for which most recent ot be calculated
    * @param patientHistoryRDD patient history rdd
    * @return returns most recent list of patient records for each patient having element name being checked
    */
  def firstPhysicalExamPerformed(m: MeasureProperty, elementName: String, patientHistoryRDD: RDD[CassandraRow]): Array[CassandraRow] = {

//    val startDate = m.quarterStartDate
//    val endDate = m.quarterEndDate

  /*  val firstRecentElements = patientHistoryRDD.filter(x => checkNotNull(x, "patientuid") && x.getString(1).equalsIgnoreCase(elementName) &&
      ((x.getDateTime(2).isAfter(m.quarterStartDate) && x.getDateTime(2).isBefore(m.quarterEndDate)) || x.getDateTime(2).isEqual(m.quarterStartDate) || x.getDateTime(2).isEqual(m.quarterEndDate))
    ).map(l => ((l.getString("patientuid"), l.getString(1)), l.getDateTime(2)))
      .reduceByKey((x, y) => if (x.isBefore(y)) x else y).collect()

    val firstRecentElementList = patientHistoryRDD.filter(r => firstRecentElements.exists(x => x._1._1.equalsIgnoreCase(r.getString("patientuid")) && x._1._2.equalsIgnoreCase(r.getString(1))
      && x._2.equals(r.getDate(2))
    )).collect()

    firstRecentElementList*/


    patientHistoryRDD.filter(l =>
      elementName.equalsIgnoreCase(l.getString(1)) &&
        ((l.getDateTime(2).isAfter(m.quarterStartDate) && l.getDateTime(2).isBefore(m.quarterEndDate)) || l.getDateTime(2).isEqual(m.quarterStartDate) || l.getDateTime(2).isEqual(m.quarterEndDate))
    )
      .map(l => ((l.getString(0), l.getString(1)), l))
      .reduceByKey((x, y) => if (x.getDate(2).before(y.getDate(2))) x else y).map(r=>r._2)
      .collect()
  }

  /** PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param patientHistoryList list of patient history
    * @return true if element is already present after another element
    */
  def wasElementPresentAfterOtherElementInHistory(visit: CassandraRow, m: MeasureProperty, HistoryElement1: String, patientHistoryList: Broadcast[List[CassandraRow]], HistoryElement2: Seq[String]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getString(1).equalsIgnoreCase(HistoryElement1)
          &&
          patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
              HistoryElement2.exists(y => y.equalsIgnoreCase(z.getString(1)) && x.getDate(2).after(z.getDate(2)))))

      }
      val argsArray: Array[String] = Array(HistoryElement1)
      measureLogger(visit, m, "wasElementPresentAfterOtherElementInHistory", HistoryElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }




  /**
    * This function verifies that the patient was transferred within 6 hours
    *
    * @param visit              current visit of the patient
    * @param m                  Measure property of the measure
    * @param element1           Acute care element
    * @param element2           Emergency Department Visit arrival element
    * @param element3           Critical care element
    * @param NoOfHours          No of hours that has to be look before from current encounter.
    * @param patientHistoryList Patient History List
    * @return returns true if patient was transferred within 6 hours
    */


  def wasPatientTransferedFromAcuteCareWithinXHours(visit: CassandraRow, m: MeasureProperty, element1: String, element2: String, element3: String, NoOfHours: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         x.getString(1).equalsIgnoreCase(element1)
        &&
        (
          (
            visit.getDateTime(element2 + "_date").minusHours(NoOfHours).equals(x.getDateTime(2))
              ||
              visit.getDateTime(element2 + "_date").equals(x.getDateTime(2))
              ||
              (
                x.getDateTime(2).isBefore(visit.getDateTime(element2 + "date"))
                  &&
                  x.getDateTime(2).isAfter(visit.getDateTime(element2 + "date").minusHours(NoOfHours))
                )
            )
            ||
            (
              visit.getDateTime(element3 + "_date").minusHours(NoOfHours).equals(x.getDateTime(2))
                ||
                visit.getDateTime(element3 + "_date").equals(x.getDateTime(2))
                ||
                (
                  x.getDateTime(2).isBefore(visit.getDateTime(element3 + "date"))
                    &&
                    x.getDateTime(2).isAfter(visit.getDateTime(element3 + "date").minusHours(NoOfHours))
                  )
              )
          )

      )
      val argsArray: Array[String] = Array(element1, element2, element3,NoOfHours.toString)
      measureLogger(visit, m, "wasPatientTransferedFromAcuteCareWithinXHours",element1 , isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function verifies if the element is null or 0
    *
    * @param r            current visit of the patient
    * @param m            measure property of the measure
    * @param checkElement element to be checked if null or 0
    * @return returns true if the element value is null or 0 else returns true
    */

  def checkNull(r: CassandraRow, m: MeasureProperty, checkElement: String): Boolean = {
    var isExist = false
    try {
      isExist = r.isNullAt(checkElement) || r.getString(checkElement).equals("0") || r.getString(checkElement).equalsIgnoreCase("null")
      val argsArray: Array[String] = Array(checkElement)
      measureLogger(r, m, "checkNull", checkElement, isExist, argsArray)

    }
    catch {
      case e: Exception => {
       // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:checkNull:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  def checkNotNull(r: CassandraRow, elements: String*): Boolean = {
    !elements.exists(element => r.isNullAt(element))
  }

  /**
    *
    * @param r           patient current row
    * @param m           measure property
    * @param element get element date
    * @param months
    * @param patientHistoryList
    * @return
    */

  def wasElementBeforeEndWithinXMonths(r: CassandraRow, m: MeasureProperty, element: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val end_Date = m.quarterEndDate
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(x =>

              x.getString(1).equalsIgnoreCase(element)

            && ((m.quarterEndDate.minusMonths(months).isBefore(x.getDateTime(2)) && m.quarterEndDate.isAfter(x.getDateTime(2)))

            || m.quarterEndDate.minusMonths(months).isEqual(x.getDateTime(2)) || m.quarterEndDate.isEqual(x.getDateTime(2)))
        )
      }
      val argsArray: Array[String] = Array(element,months.toString)
      measureLogger(r, m, "wasElementBeforeEndWithinXMonths", element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * This Function verifies the Diagnosis of the Patient before edVisitDeparture date in history.
    *
    * @param visit                Current visit of the patient.
    * @param m                    Measure Property of the measure.
    * @param element              Element that has to be verified during Emergency visit.
    * @param edvisitDepartureDate edvisitdeparture Date of the patient visit
    * @param crtclDate            critical care Date of  the patient visit
    * @return It will return true for those patient whose Diagnosis before Edvisit Departure of the Patient.
    */
  def wasDiagnosedBeforeEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, edvisitDepartureDate: String, crtclDate: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>
          checkElementPresent(visit, m, element)  &&
            histvisit.getString(1).equalsIgnoreCase(visit.getString(element))
            &&
            (
              !visit.isNullAt(edvisitDepartureDate) && !visit.isNullAt(crtclDate) &&
                (
                  histvisit.getDateTime(2).isBefore(visit.getDateTime(edvisitDepartureDate)) || histvisit.getDateTime(2).equals(visit.getDateTime(edvisitDepartureDate)))
                || (histvisit.getDateTime(2).isBefore(visit.getDateTime(crtclDate)) || histvisit.getDateTime(2).equals(visit.getDateTime(crtclDate))
                )
              )
        )
        val argsArray: Array[String] = Array(element,edvisitDepartureDate,crtclDate)
        measureLogger(visit, m, "wasDiagnosedBeforeEDOrCCEncounter", element, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * this function checks whether histroyElement date is before within some months from elementDate
    *
    * @param visit              current cassandra visit
    * @param m                  measure property
    * @param elementDate        element date which comes from current visit
    * @param histroyElement     history element
    * @param month              no of months which will be look back from element Date
    * @param patientHistoryList patient history list
    * @return true if histroyElement date is before within some months from elementDate
    */
  def wasElementBeforeElementWithinXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val lowerDate = visit.getDateTime(elementDate).minusMonths(month)
    val higherDate = visit.getDateTime(elementDate)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>

           histroyElement.equalsIgnoreCase(x.getString(1))

            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

        )

        val argsArray: Array[String] = Array(elementDate,histroyElement,month.toString)
        measureLogger(visit, m, "wasElementBeforeElementWithinXMonths", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementBeforeOrEqualInMonths:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * this function check whether historyElement1 is after historyElement2 before encounterdate
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param historyElement1    element 1 which will be after HistoryElement2 in history
    * @param historyElement2    element which wikk be compared from  HistoryElement1
    * @param patientHistoryList element 2 which will be compared from element 1
    * @return true if historyElement1 is after historyElement2 before encounterdate
    */
  def wasElementPresentAfterOtherElementBeforeEncounter(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getDate(2).before(visit.getDate("encounterdate"))
          && x.getString(1).equalsIgnoreCase(historyElement1)
          &&
          patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
              z.getDate(2).before(visit.getDate("encounterdate"))
              && x.getString(1).equalsIgnoreCase(historyElement2)
              && x.getDate(2).after(z.getDate(2))))

      }
      val argsArray: Array[String] = Array(historyElement1,historyElement2)
      measureLogger(visit, m, "wasElementPresentAfterOtherElementBeforeEncounter", historyElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * PARENT function
    *
    * @param r                  current visit
    * @param m                  measure property
    * @param elementDate        get element check between
    * @param days               minus days in in element
    * @param patientHistoryList get patient history list
    * @return
    */


  def wasElementBeforeEndWithinXDays(r: CassandraRow, m: MeasureProperty, elementDate: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val end_Date = m.quarterEndDate
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(x =>

             r.getString("patientuid").equals(x.getString("patientuid"))

            && ((m.quarterEndDate.minusDays(days).isBefore(x.getDateTime(2)) && m.quarterEndDate.isAfter(x.getDateTime(2)))

            || m.quarterEndDate.minusDays(days).isEqual(x.getDateTime(2)) || m.quarterEndDate.isEqual(x.getDateTime(2)))
        )
      }
      val argsArray: Array[String] = Array( elementDate,days.toString)
      measureLogger(r, m, "wasElementBeforeEndWithinXDays", elementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /** PARENT Function
    * This Function verifies the element value on current encounter
    *
    * @param visit       current Visit of the patient.
    * @param m           measure property of the measure(mesureId and condition)
    * @param elementName ElementName that has to be look in the history.
    * @param value       Value that has to be verified.
    * @param flag        flag that will define the condition whether to check greater or greaterEqualto condition.
    * @return
    */
  def checkElementValueOnEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, value: Double, flag: String): Boolean = {
    var isExist = false
    val elementDate = elementName+"_date"
    try {

      isExist = !visit.isNullAt(elementName) && !visit.isNullAt(elementDate) && isDateEqual(visit,m,elementDate,AdminElements.Encounter_Date) &&
        compareValueStatus(visit.getDouble(elementName), flag, value)
      val argsArray: Array[String] = Array(elementName, value.toString, flag)
      measureLogger(visit, m, "checkElementValueOnEncounter", elementName, isExist, argsArray)
    }

    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementValueDuringMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function verifies if physical exam performed in X days after procedure
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param elementName        element
    * @param historyElement     procedure performed element name in history
    * @param days               no of days to be looked after
    * @param patientHistoryList patient history list
    * @return returns true if physical exam performed in X days after procedure else returns false
    */
  def isPhysicalExamPerformedInXDaysAfterProcedure(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {

      val element_date = elementName + "_date"

      if(checkNotNull(visit, elementName, element_date) && patientHistoryList.value.nonEmpty){
          val startDate = visit.getDateTime(element_date)
          val endDate = visit.getDateTime(element_date).plus(days)

          isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
            historyElement.equalsIgnoreCase(x.getString(1))

              && (x.getDateTime(2).isAfter(startDate) || x.getDateTime(2).isEqual(startDate))
              && (x.getDateTime(2).isBefore(endDate) || x.getDateTime(2).isEqual(endDate)))

      }


      val argsArray: Array[String] = Array(elementName,historyElement, days.toString)
      measureLogger(visit, m, "isPhysicalExamPerformedInXDaysAfterProcedure", elementName, isExist, argsArray)
    }

    catch {
      case e: Exception => {
       // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isPhysicalExamPerformedInXDaysAfterProcedure:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function verifies if physical exam performed in X days after procedure
    *
    * @param visit             current patient visit
    * @param m                 measure property
    * @param elementName       element
    * @param historyElements   procedure performed element name in history
    * @param days              no of days to be looked after
    * @param patientHistoryRDD patient history list
    * @return returns true if physical exam performed in X days after procedure else returns false
    */
  def wasProcedureEyeEqualsWithInXDaysAfter(visit: CassandraRow, m: MeasureProperty, elementName: String, days: Int, patientHistoryRDD: RDD[CassandraRow], historyElements: String*): Boolean = {
    var isExist = false
    try {

      val element_date = elementName + "_date"
      val notNullElements = checkNotNull(visit, elementName, element_date)

      notNullElements match {
        case true => {
          val startDate = visit.getDateTime(element_date)
          val endDate = visit.getDateTime(element_date).plus(days)
          /* val patientHistoryRecords= getHistoryRecordsBetweenPeriods(visit,patientHistoryList,historyElement,startDate,endDate)
           isExist=patientHistoryRecords.exists(x => x.getDate(2).after(visit.getDate(element_date)) )*/

          val patientHistoryRecords = getHistoryRecordsBetweenPeriods(visit, patientHistoryRDD, startDate, endDate, historyElements)
          isExist = checkEyeOnEncounterEqualsWith(visit, m, false, elementName, patientHistoryRecords, historyElements)

        }
        case false =>
      }

      val argsArray: Array[String] = Array(elementName, days.toString)
      measureLogger(visit, m, "wasProcedureEyeEqualsWithInXDaysAfter", elementName, isExist, argsArray)
    }

    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasProcedureEyeEqualsWithInXDaysAfter:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function verifies the Encounter is performed after edVisitArrival or Critical Date.
    *
    * @param visit              current visit of the patient.
    * @param m                  Measure Property of the measure.
    * @param element            Element that has to be verified during Emergency visit.
    * @param edvisitArrivalDate edvisitArrivalDate of the patient.
    * @param crtclDate          critical care Date of  the patient visit
    * @param patientHistoryList Patient history List
    * @return It will return true if
    */
  def wasEncounterPerformedAfterEDorCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, edvisitArrivalDate: String, crtclDate: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = true

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>
          checkElementPresent(visit, m, element) &&
                        histvisit.getString(1).equalsIgnoreCase(visit.getString(element))
            &&
            (
              !visit.isNullAt(edvisitArrivalDate) && !visit.isNullAt(crtclDate) &&
                (
                  histvisit.getDateTime(2).isAfter(visit.getDateTime(edvisitArrivalDate)) || histvisit.getDateTime(2).equals(visit.getDateTime(edvisitArrivalDate)))
                || (histvisit.getDateTime(2).isAfter(visit.getDateTime(crtclDate)) || histvisit.getDateTime(2).equals(visit.getDateTime(crtclDate))
                )
              )
        )
        val argsArray: Array[String] = Array(element,edvisitArrivalDate,crtclDate)
        measureLogger(visit, m, "wasEncounterPerformedAfterEDorCCEncounter", element, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param elementName        element name whose date will be checked
    * @param patientHistoryList list of patient history
    * @return true if element is already present After encounter Date
    */
  def wasElementPresentAfterStartDateAndBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, currentElementdate: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
//    val start_date = m.quarterStartDate
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !x.isNullAt(2) &&
           x.getString(1).equalsIgnoreCase(elementName)
          &&
          (x.getDateTime(2).isAfter(m.quarterStartDate) &&
            x.getDateTime(2).isBefore(visit.getDateTime(currentElementdate)))
        )

      }
      val argsArray: Array[String] = Array(elementName,currentElementdate)
      measureLogger(visit, m, "wasElementPresentAfterStartDateAndBeforeEncounter", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentBeforeOrEqualEncounter:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param historyElementName get element check between
    * @param days               minus days in in element
    * @param patientHistoryList get patient history list
    * @return
    */

  def wasElementBeforeEndInXDays(visit: CassandraRow, m: MeasureProperty, historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val end_Date = m.quarterEndDate
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
            x.getString(1).equalsIgnoreCase(historyElementName)

            && (m.quarterEndDate.minusDays(days).isAfter(x.getDateTime(2))

            || m.quarterEndDate.minusMonths(days).isEqual(x.getDateTime(2)))
        )
      }
      val argsArray: Array[String] = Array(historyElementName,days.toString)
      measureLogger(visit, m, "wasElementBeforeEndInXDays", historyElementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    * PARENT function
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param elementDate        get element check between
    * @param days               minus days in in element
    * @param patientHistoryList get patient history list
    * @return if
    */


  def wasElementBeforeElementDateWithinXDays(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    //val end_Date = new DateTime(m.quarterEndDate)
    val lowerDate = visit.getDateTime(elementDate).minusDays(days)
    val higherDate = visit.getDateTime(elementDate)

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>

          !x.isNullAt(2)
                       && x.getString(1).equalsIgnoreCase(historyElementName)
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
        )
      }
      val argsArray: Array[String] = Array(days.toString, elementDate)
      measureLogger(visit, m, "wasElementBeforeElementDateWithinXDays", elementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    * This function verifies the Diagnosis with other condition
    *
    * @param visit              current visit of the patient.
    * @param m                  Measure Property of the measure.
    * @param element1           Diagnosis Element that has to be verified during Emergency visit.
    * @param LateralElement     condition element with that element1 has to be compared.
    * @param patientHistoryList Patient History list
    * @return It will return true whose condition element is concurent with diagnosis element else false.
    */

  def wasDiagnosedBeforeEndWithLaterality(visit: CassandraRow, m: MeasureProperty, element1: String, LateralElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
//        var startDate = m.quarterStartDate
//        var endDate = m.quarterEndDate

        isExist = patientHistoryList.value.filter(x => x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(element1)
          && (x.getDateTime(2).isBefore(m.quarterEndDate) || x.getDateTime(2).isEqual(m.quarterEndDate)))
          .exists(x => patientHistoryList.value.exists(y =>
            y.getString("patientuid").equalsIgnoreCase(x.getString("patientuid"))
              && y.getString(1).equalsIgnoreCase(LateralElement)
              && y.getDate(2).equals(x.getDate(2))))

      }
      val argsArray: Array[String] = Array(LateralElement, element1)
      measureLogger(visit, m, "wasDiagnosedBeforeEndWithLaterality", element1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist
  }


  /**
    * This function verifies  visual Acuity with in x Days from the Refractive Surgery.
    *
    * @param currentvisit    currentvisit from tblencounter on which computation has to be done.
    * @param m               measureproperty of the measure
    * @param histElement     Element that has to verified in history.
    * @param currentElement  CurrentElement from tblencounter
    * @param ElementHistList history Element list from Patient history List.
    * @param noOfDays        no of days before that has to be checked.
    */

  def wasCorrectedVisualAcuityValueGreaterXDays(currentvisit: CassandraRow, m: MeasureProperty, histElement: String, currentElement: String, noOfDays: Int, visualAcuityResult: Array[String], ElementHistList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val currentElement_Date = currentElement + "_date"
    if (ElementHistList.value.nonEmpty) {
      try {

        isExist = ElementHistList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(currentvisit.getString("patientuid")))
          .exists(histvist => !histvist.isNullAt(3) &&
          histvist.getString(1).equalsIgnoreCase(histElement) &&
          (!currentvisit.isNullAt(currentElement_Date)
            &&
            (
              currentvisit.getDateTime(currentElement_Date).plusDays(noOfDays).isEqual(histvist.getDateTime(2))
                ||
                currentvisit.getDateTime(currentElement_Date).plusDays(noOfDays).isBefore(histvist.getDateTime(2))
              )
            )
          &&
          visualAcuityResult.contains(histvist.getString(3))
        )
        val argsArray: Array[String] = Array(histElement, noOfDays.toString, currentElement)
        measureLogger(currentvisit, m, "wasCorrectedVisualAcuityValueGreaterXDays", currentElement, isExist, argsArray)

      }
      catch {
        case e: Exception => {
        //  postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:wasCorrectedVisualAcuityValueGreaterXDays:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist
  }

  /**
    * This function verifies those patient whose procedure is performed concurrent with diagnosis in history.
    *
    * @param visit              Current visit of the patient
    * @param m                  Masure Property of the measure
    * @param histElement        History element that has to be compared with current Element
    * @param currentElement     Current element
    * @param patientHistoryList patient history list.
    * @return
    */
  def isProcedurePerformedWasConcurrentWith(visit: CassandraRow, m: MeasureProperty, histElement: String, currentElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (!visit.isNullAt(currentElement) && patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(histVisit => !histVisit.isNullAt(3)
            && histVisit.getString(1).equalsIgnoreCase(histElement)
            && histVisit.getString(3).equals(visit.getString(currentElement)))
      }
      val argsArray: Array[String] = Array(currentElement, histElement)
      measureLogger(visit, m, "isProcedurePerformedWasConcurrentWith", histElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function verifies if the on encounter eye element is overlapping measurement period and eye element is similar with other eye element
    *
    * @param visit                  current patient visit
    * @param m                      measure property
    * @param elementEyeName         eye element to be verified
    * @param patientHistoryRDD      patient history list
    * @param compareEyeElementNames compared eye element names
    * @return returns true if  the on encounter eye element is overlapping measurement period and eye element is similar with other eye element else returns false
    */
  def checkEyeOnEncounterEqualsWith(visit: CassandraRow, m: MeasureProperty, checkBeforeElement: Boolean, elementEyeName: String, patientHistoryRDD: RDD[CassandraRow], compareEyeElementNames: Seq[String]): Boolean = {
    val startDateEndDate = checkBeforeElement match {
      case true => (m.quarterStartDate, visit.getDateTime(elementEyeName + "_date"))
      case false => (visit.getDateTime(elementEyeName + "_date"), m.quarterEndDate)
    }


    val patientHistoryRDDInDuring = getHistoryRecordsBetweenPeriods(visit, patientHistoryRDD, startDateEndDate._1, startDateEndDate._2, compareEyeElementNames).cache()
    val eyeCondCriterias1 = Array(3, 4)
    val eyeCondCriterias2 = Array(1, 2, 3, 4)

    def returnEyeValue(element: String): Any = {
      val mostRecentEyeList = checkBeforeElement match {
        case true => mostRecentPhysicalExamPerformed(m, element, patientHistoryRDDInDuring).filter(r => r.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
        case false => firstPhysicalExamPerformed(m, element, patientHistoryRDDInDuring).filter(r => r.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
      }

      if (!mostRecentEyeList.isEmpty ) mostRecentEyeList(0).getString(3).toInt else null
    }

    val ippEye1 = if (visit.isNullAt(elementEyeName)) null else visit.getString(elementEyeName).toInt

    compareEyeElementNames.forall(eye => {
      val conditionEye = returnEyeValue(eye)
      (conditionEye == ippEye1) || (eyeCondCriterias1.contains(conditionEye) && eyeCondCriterias2.contains(ippEye1)) || (eyeCondCriterias2.contains(conditionEye) && eyeCondCriterias1.contains(ippEye1)) || conditionEye == null || ippEye1 == null
    })

  }




  /**
    * This function verifies if the on encounter eye element is overlapping measurement period and eye element is similar with other eye element
    *
    * @param visit                  current patient visit
    * @param m                      measure property
    * @param elementEyeName         eye element to be verified
    * @param patientHistoryList      patient history list
    * @param compareEyeElementNames compared eye element names
    * @return returns true if  the on encounter eye element is overlapping measurement period and eye element is similar with other eye element else returns false
    */
  def checkEyeOnEncounterEqualsWithOtherEye(visit: CassandraRow, m: MeasureProperty, checkBeforeElement: Boolean, elementEyeName: String, patientHistoryList: Broadcast[List[CassandraRow]], compareEyeElementNames: Seq[String]): Boolean = {
    val eyeCondCriterias1 = Array(3, 4)
    val eyeCondCriterias2 = Array(1, 2, 3, 4)

    def returnEyeValue(element: String): Any = {
      val filterRecord:Any = checkBeforeElement match {
        case true => patientHistoryList.value.filter(histRow => {
          histRow.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) &&
            histRow.getString(1).equalsIgnoreCase(element) &&
            histRow.getDateTime(2).isBefore(visit.getDateTime(2))
        }).lastOption.getOrElse("")
        case false => patientHistoryList.value.filter(histRow => {
          histRow.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) &&
            histRow.getString(1).equalsIgnoreCase(element) &&
            histRow.getDateTime(2).isAfter(visit.getDateTime(2))
        }).headOption.getOrElse("")

      }
      if (filterRecord.isInstanceOf[CassandraRow]) filterRecord.asInstanceOf[CassandraRow].getString(3).toInt else null
    }

    val ippEye1 = if (visit.isNullAt(elementEyeName)) null else visit.getString(elementEyeName).toInt

    compareEyeElementNames.forall(eye => {
      val conditionEye = returnEyeValue(eye)
      (conditionEye == ippEye1) || (eyeCondCriterias1.contains(conditionEye) && eyeCondCriterias2.contains(ippEye1)) || (eyeCondCriterias2.contains(conditionEye) && eyeCondCriterias1.contains(ippEye1)) || conditionEye == null || ippEye1 == null
    })

  }

  /**
    * This function returns patient history records between two periods
    *
    * @param visit             current patient visit
    * @param patientHistoryRDD patient history RDD
    * @param startDate         start date of the patient history
    * @param endDate           end date of  the patient history
    * @return patient history between two period
    */
  def getHistoryRecordsBetweenPeriods(visit: CassandraRow, patientHistoryRDD: RDD[CassandraRow], startDate: DateTime, endDate: DateTime, historyElements: Seq[String]): RDD[CassandraRow] = {
    val historyRDD = patientHistoryRDD.filter(r => visit.getString("patientuid").equalsIgnoreCase(r.getString("patientuid")) && (r.getDateTime(2).isAfter(startDate) || r.getDateTime(2).isEqual(startDate)) && (r.getDateTime(2).isBefore(endDate) || r.getDateTime(2).isEqual(endDate)) && historyElements.exists(element => element.equalsIgnoreCase(r.getString(1))))
    historyRDD
  }

  /**
    *
    * @param visit              current visit
    * @param m                  measure Property of the measure
    * @param currentElementDate current row element
    * @param historyElementName history element
    * @param noOfDays           no of days before currentElementDate
    * @param value              value that need to be checked
    * @param Flag      for value condition like ge >= etc
    * @param patientHistoryList patirnt history
    * @return true if value of element satisfy the condition flag and element is between currentElementDate and currentElementDate - days
    */
  def checkElementValueBeforeElementWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, historyElementName: String, noOfDays: Int, value: Double, Flag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

        val lowerDate = visit.getDateTime(currentElementDate).minusDays(noOfDays)
        val higherDate = visit.getDateTime(currentElementDate)

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !x.isNullAt(3) &&
           !visit.isNullAt(currentElementDate) && !visit.isNullAt(currentElementDate)
          && x.getString(1).equalsIgnoreCase(historyElementName)

          && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

          && compareValueStatus(x.getDouble(3), Flag, value))

      }

      val argsArray: Array[String] = Array(historyElementName, value.toString)
      measureLogger(visit, m, "checkElementValueBeforeElementWithinXDays", historyElementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isMostRecentPhysicalExamPerformedBefore:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    *
    * @param r                  patient current visit
    * @param m                  measure property
    * @param elementName        get element check between
    * @param years              minus years in in element
    * @param patientHistoryList get patient history list
    * @return it return of Element before end of X in years
    */

  def wasElementBeforeEndInXYears(r: CassandraRow, m: MeasureProperty, elementName: String, years: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val endDate = m.quarterEndDate
    val lowerDate = m.quarterEndDate.minusYears(years)
    val higherDate = m.quarterEndDate
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(x =>
           x.getString(1).equals(r.getString(elementName))
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

        )
      }
      val argsArray: Array[String] = Array(elementName, years.toString)
      measureLogger(r, m, "wasElementBeforeEndInXYears", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /*/**
    *
    * @param visit              current visit
    * @param m                  measure Property of the measure
    * @param currentElementDate current row element
    * @param historyElementName history element
    * @param noOfDays           no of days before currentElementDate
    * @param patientHistoryList patirnt history
    * @return true if element is between currentElementDate and currentElementDate - days
    */
  def checkElementPresentBeforeElementWithinXDays(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, historyElementName: String, noOfDays: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

        val lowerDate = visit.getDateTime(currentElementDate).minusDays(noOfDays)
        val higherDate = visit.getDateTime(currentElementDate)

        isExist = patientHistoryList.value.exists(x => !x.isNullAt("patientuid") && !x.isNullAt(1) && !x.isNullAt(2)

          && !visit.isNullAt(currentElementDate) && !visit.isNullAt(currentElementDate)

          && x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))

          && x.getString(1).equalsIgnoreCase(historyElementName)

          && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
        )

      }


      val argsArray: Array[String] = Array(historyElementName, currentElementDate.toString)
      measureLogger(visit, m, "checkElementValueBeforeElementWithinXDays", historyElementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isMostRecentPhysicalExamPerformedBefore:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }
*/
  /** PARENT Function
    * this function retirn true history element found within X days from end date
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param histroyElement     history element whichh will be checked for overlaps end date
    * @param days               no. of days overslaps from encounter date
    * @param patientHistoryList list of patient history
    * @return true if history element found Overlaps X days from end date
    */
  def wasElementPresentBeforeOrEqualEndInDays(visit: CassandraRow, m: MeasureProperty, histroyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val endDate = m.quarterEndDate
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         histroyElement.equalsIgnoreCase(x.getString(1))
            && (m.quarterEndDate.minusDays(days).isBefore(x.getDateTime(2))
            || m.quarterEndDate.minusDays(days).isEqual(x.getDateTime(2)))
        )
        val argsArray: Array[String] = Array(histroyElement, days.toString)
        measureLogger(visit, m, "wasElementPresentBeforeOrEqualEndInDays", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentOverlapsEncounterInDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function verifies if refractive surgery performed within X days
    *
    * @param visit             current patient visit
    * @param m                 measure property
    * @param elementName       element name
    * @param noOfDays          no of days to be looked before
    * @param patientHistoryRDD patients history list
    * @return returns true if refractive surgery performed within X days else returns false
    */
  def wasProcedureEyeEqualsWithInXDaysBefore(visit: CassandraRow, m: MeasureProperty, elementName: String, elementDate: String, noOfDays: Int, patientHistoryRDD: RDD[CassandraRow], historyElements: String*): Boolean = {
    var isExist = false
    try {
      if (!patientHistoryRDD.isEmpty()) {
        val startDate: DateTime = m.quarterStartDate
        val endDate: DateTime = m.quarterEndDate.minus(noOfDays)

        val patientHistoryRecords = getHistoryRecordsBetweenPeriods(visit, patientHistoryRDD, startDate, endDate, historyElements)
        isExist = checkEyeOnEncounterEqualsWith(visit, m, true, elementName, patientHistoryRecords, historyElements)
        //isExist = patientHistoryRecords.exists(r=> elementName.equalsIgnoreCase(r.getString(1)) )
      }

      val argsArray: Array[String] = Array(elementName, elementDate.toString, noOfDays.toString)
      measureLogger(visit, m, "wasProcedureEyeEqualsWithInXDaysBefore", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasProcedureEyeEqualsWithInXDaysBefore:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function verifies if physical exam performed after another physical element  and value between two specified value
    *
    * @param visit current patient visit
    * @param elementName to be checked in current record
    * @param m measure property
    * @param patientHistoryList patient history list
    * @param lowerValue lower value
    * @param higherValue higher value
    * @param historyElement to be checked in history
    * @return returns true if physical exam performed after another physical element  and value between two specified value else returns false
    */
  def isPhysicalExamPerformedValueBetween(visit: CassandraRow, elementName: String, m: MeasureProperty, lowerValue: Double, higherValue: Double,patientHistoryList: Broadcast[List[CassandraRow]], historyElement: String): Boolean = {
    var isExist = false
    val element_date = elementName + "_date"
    try {
      if (checkNotNull(visit, elementName, element_date) && patientHistoryList.value.nonEmpty) {

        patientHistoryList.value.filter(histRow => !histRow.isNullAt(3) &&
            histRow.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) &&
            histRow.getString(1).equalsIgnoreCase(elementName) &&
            dateStatus(histRow.getDateTime(2), visit.getDateTime(2), CompareOperator.GREATER_EQUAL)
            && compareTwoValueStatus(histRow.getDouble(3), CompareOperator.GREATER_EQUAL_And_LESS_EQUAL, lowerValue, higherValue)

        )

        val argsArray: Array[String] = Array(historyElement,elementName,lowerValue.toString,higherValue.toString)
        measureLogger(visit, m, "isPhysicalExamPerformedValueBetween", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isPhysicalExamPerformedValueBetween:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function gives list of all elements with respect to the first date of the Element.
    *
    * @param historyRDD Patient History RDD
    * @return List of Cassandra Row that contains all the elements date concurrent with first date.
    */

  def getHistoryOnMinDateOfElement(historyRDD: RDD[CassandraRow], m: MeasureProperty, element: String): List[CassandraRow] = {
//    val startDate = m.quarterStartDate
//    val endDate = m.quarterEndDate
   /* val minDateElements = historyRDD.filter(row =>  row.getString(1).equalsIgnoreCase(Element)
      && (row.getDateTime(2).isAfter(m.quarterStartDate) && row.getDateTime(2).isBefore(m.quarterEndDate)) || row.getDateTime(2).isEqual(m.quarterStartDate)
      || row.getDateTime(2).isEqual(m.quarterEndDate))
      .map(l => (l.getString("patientuid"), l.getDate(2))).reduceByKey((x, y) => if (x.before(y)) x else y).collect()
    historyRDD.filter(r => minDateElements.contains((r.getString("patientuid"), r.getDate(2)))).collect.toList*/

    historyRDD.filter(l =>
      element.contains(l.getString(1))
        && (l.getDateTime(2).isAfter(m.quarterStartDate) && l.getDateTime(2).isBefore(m.quarterEndDate)) || l.getDateTime(2).isEqual(m.quarterStartDate)
        || l.getDateTime(2).isEqual(m.quarterEndDate)
    )
      .map(l => (l.getString(0), l))
      .reduceByKey((x, y) => if (x.getDate(2).before(y.getDate(2))) x else y).map(r=>r._2)
      .collect().toList

  }

  /**
    * This function gives list of all elements with respect to the most recent date of the Element during measurement period from history.
    *
    * @param historyRDD Patient History RDD
    * @return List of Cassandra Row that contains all the elements date concurrent with first date during measurement period from history.
    */
  def getHistoryMostRecentDateOfElement(historyRDD: RDD[CassandraRow], m: MeasureProperty, element: String): List[CassandraRow] = {
//    val startDate = m.quarterStartDate
//    val endDate = m.quarterEndDate
    /*val mostRecentElements = historyRDD.filter(row =>  row.getString(1).equalsIgnoreCase(Element)
      && (row.getDateTime(2).isAfter(m.quarterStartDate) && row.getDateTime(2).isBefore(m.quarterEndDate)) || row.getDateTime(2).isEqual(m.quarterStartDate)
      || row.getDateTime(2).isEqual(m.quarterEndDate))

      .map(l => (l.getString("patientuid"), l.getDate(2)))
      .reduceByKey((x, y) => if (x.after(y)) x else y).collect()
    historyRDD.filter(r => mostRecentElements.contains((r.getString("patientuid"), r.getDate(2)))).collect().toList*/


    historyRDD.filter(l =>
      element.contains(l.getString(1))
        && (l.getDateTime(2).isAfter(m.quarterStartDate) && l.getDateTime(2).isBefore(m.quarterEndDate)) || l.getDateTime(2).isEqual(m.quarterStartDate)
        || l.getDateTime(2).isEqual(m.quarterEndDate)
    )
      .map(l => (l.getString(0), l))
      .reduceByKey((x, y) => if (x.getDate(2).after(y.getDate(2))) x else y).map(r=>r._2)
      .collect().toList
  }

  /**
    * This function verifies the physical Exam performed on the same day with first or most recent list during measurement period from history.
    *
    * @param visit                     Current visit of the patient.
    * @param m                         Measure property of the measure.
    * @param element                   Element that has to be verified in the
    * @param FirstOrMostRecentDateList First or most recent Date list from the history.
    * @return
    */
  def wasPhysicalExamPerformedOnSameDay(visit: CassandraRow, m: MeasureProperty, element: String, FirstOrMostRecentDateList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (FirstOrMostRecentDateList.value.nonEmpty) {
        isExist = FirstOrMostRecentDateList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(histvisit =>  (    histvisit.getString(1).equalsIgnoreCase(element)))
        val argsArray: Array[String] = Array(element)
        measureLogger(visit, m, "wasPhysicalExamPerformedOnSameDay", element, isExist, argsArray)
      }

    }
    catch {
      case e: Exception =>
        loggerObj.error(e.getMessage)
        //System.exit(0)

    }
    isExist
  }


  /**
    *
    * @param r                  patient current visit
    * @param m                  measure property
    * @param historyElement     get element check between startdate and startdate - years
    * @param years              minus years in in element
    * @param patientHistoryList get patient history list
    * @return it return of Element before end of X in years
    */

  def wasElementBeforeStartInXYears(r: CassandraRow, m: MeasureProperty, historyElement: String, years: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    var isExist = false
//    val startDate = m.quarterStartDate
    val lowerDate = m.quarterStartDate.minusYears(years)
    val higherDate = m.quarterStartDate

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(x =>
             x.getString(1).equalsIgnoreCase(historyElement)
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
        )

      }
      val argsArray: Array[String] = Array(historyElement, years.toString)
      measureLogger(r, m, "wasElementBeforeStartInXYears", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /** PARENT Function
    * This Function verifies the value of element before end of measurement Period
    *
    * @param visit              current Visit of the patient.
    * @param m                  measure property of the measure(mesureId and condition)
    * @param elementName        ElementName that has to be look in the history.
    * @param value              Value that has to be verified.
    * @param flag               flag that will define the condition whether to check greater or greaterEqualto condition.
    * @param patientHistoryList Patient history list.
    * @return true if element value satisfy codition before end of measurement Period
    */
  def checkElementValueBeforeEnd(visit: CassandraRow, m: MeasureProperty, elementName: String, value: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
//        val endDate = m.quarterEndDate

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>  !x.isNullAt(3)
                   && x.getString(1).equalsIgnoreCase(elementName)

          && (x.getDateTime(2).isBefore(m.quarterEndDate) || x.getDateTime(2).isEqual(m.quarterEndDate))

          && compareValueStatus(x.getDouble(3), flag, value)
        )

      }

      val argsArray: Array[String] = Array(elementName, value.toString, flag)
      measureLogger(visit, m, "checkElementValueBeforeEnd", elementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementValueDuringMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * this function checks whether value of element satisfy the condition flag and element is between startdate  and startDate - years
    *
    * @param visit              current visit
    * @param m                  measure Property of the measure
    * @param historyElementName history element
    * @param years              no of days before currentElementDate
    * @param value              value that need to be checked
    * @param ConditionFlag      for value condition like ge >= etc
    * @param patientHistoryList patient history
    * @return true if value of element satisfy the condition flag and element is between startdate  and startDate - years
    */
  def checkElementValueBeforeEndWithinXYears(visit: CassandraRow, m: MeasureProperty, historyElementName: String, years: Int, value: Double, ConditionFlag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

//        val startDate = m.quarterEndDate
        val lowerDate = m.quarterEndDate.minusYears(years)
        val higherDate = m.quarterEndDate

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x => !x.isNullAt(3)
          && x.getString(1).equalsIgnoreCase(historyElementName)

          && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

          && compareValueStatus(x.getDouble(3), ConditionFlag, value))

      }


      val argsArray: Array[String] = Array(historyElementName, years.toString,value.toString)
      measureLogger(visit, m, "checkElementValueBeforeEndWithinXYears", historyElementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isMostRecentPhysicalExamPerformedBefore:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  def checkElementValueBeforeStartWithinXYears(visit: CassandraRow, m: MeasureProperty, historyElementName: String, years: Int, value: Double, ConditionFlag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

//        val startDate = m.quarterStartDate
        val lowerDate = m.quarterStartDate.minusYears(years)
        val higherDate = m.quarterStartDate

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x => !x.isNullAt(3)
        && x.getString(1).equalsIgnoreCase(historyElementName)
          && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
          && compareValueStatus(x.getDouble(3), ConditionFlag, value))

      }


      val argsArray: Array[String] = Array(historyElementName, years.toString,value.toString,ConditionFlag)
      measureLogger(visit, m, "checkElementValueBeforeStartWithinXYears", historyElementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isMostRecentPhysicalExamPerformedBefore:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

 /* /**
    * PARENT function
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param elementDate1        get element check between
    * @param historyElement     history element name
    * @param interval             no of interval to be looked after
    * @param unit unit to be checked (valid units are YEAR,MONTH,WEEK,DAY,HOUR )
    * @param patientHistoryList get patient history list
    * @return
    */


  def wasElementAfterElementDateWithinXPeriod(visit: CassandraRow, m: MeasureProperty, elementDate1: String, historyElement: String, interval: Int,unit:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementDate= if(elementDate1.equalsIgnoreCase("encounterdate")) "encounterdate" else elementDate1
    val lowerDate = visit.getDateTime(elementDate)

    val higherDate = higherCalenderDate(visit.getDateTime(elementDate),unit,interval)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.exists(x =>

          !x.isNullAt(2)

            && visit.getString("patientuid").equals(x.getString("patientuid"))

            && x.getString(1).equalsIgnoreCase(historyElement)

            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
        )
      }
      //val argsArray: Array[String] = Array(interval.toString, elementDate)
      //measureLogger(visit, m, "wasElementAfterElementDateWithinXMonths", elementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }*/

  /**
    * PARENT function
    *
    * @param r                  current visit
    * @param m                  measure property
    * @param months             minus days in in element
    * @param patientHistoryList get patient history list
    * @return it return check history element between most recent history element values and check values flags
    */


  def wasElementAfterElementDateValueWithinXMonths(r: CassandraRow, m: MeasureProperty, element: String, value: Double, flag: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]], mostRecentHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (mostRecentHistoryList.value.nonEmpty) {
        isExist = mostRecentHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(mostRecent =>
          mostRecent.getString(1).equalsIgnoreCase(element) &&
            patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(hvisit =>
              !hvisit.isNullAt(3)
                && hvisit.getString(1).equalsIgnoreCase(element) &&
                isDateBetween(hvisit.getDateTime(2), mostRecent.getDateTime(2).minusMonths(months), mostRecent.getDateTime(2))
                &&

                compareValueStatus(hvisit.getDouble(3), flag, value)
            )

        )

      }
      val argsArray: Array[String] = Array(element,value.toString, flag.toString, months.toString)
      measureLogger(r, m, "wasElementAfterElementDateValueWithinXMonths", element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    *
    * @param elementValue
    * @param flag
    * @param value1
    * @param value2
    * @return
    */

  def compareStatusBetweenValue(elementValue:Double, flag: String, value1: Double, value2: Double): Boolean = {
    //var elementValue = visit.getDouble(3)
    var status: Boolean = flag match {
      case "ge&le" => elementValue >= value1 && elementValue <= value2
      case "gt&lt" => elementValue > value1 && elementValue < value2
      case "ge&lt" => elementValue >= value1 && elementValue < value2
      case "gt&le" => elementValue > value1 && elementValue <= value2
      case "eq" => elementValue == value1 && elementValue == value2
    }
    status
  }

  /**
    * PARENT function
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param months             minus days in in element
    * @param patientHistoryList get patient history list
    * @return it return if
    */


  def wasElementValueBeforeMostRecentEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, element: String, value: Double, flag: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]], mostRecentHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    //val end_Date = new DateTime(m.quarterEndDate)
    try {
      if (mostRecentHistoryList.value.nonEmpty) {
        isExist = mostRecentHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(mostRecent =>

           mostRecent.getString(1).equalsIgnoreCase(element) &&

            patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>
              !hvisit.isNullAt(3)
                && hvisit.getString(1).equalsIgnoreCase(element) &&
                isDateBetween(hvisit.getDateTime(2), mostRecent.getDateTime(2).minusMonths(months), mostRecent.getDateTime(2))
                &&
                compareValueStatus(hvisit.getDouble(3), flag, value))


        )

      }
      val argsArray: Array[String] = Array(element,months.toString, value.toString, flag.toString)
      measureLogger(visit, m, "wasElementValueBeforeMostRecentEncounterWithinXMonths", element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    *
    * @param visit              patient current row
    * @param m                  measure property
    * @param historyElement     get element date
    * @param months             minus month from  element date
    * @param patientHistoryList get patient history list
    * @return it return if element is before another element and with in x months
    */

  def wasElementBeforeWithResultElementWithinXMonths(visit: CassandraRow, m: MeasureProperty, historyElement: String, value: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]], mostRecentHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (mostRecentHistoryList.value.nonEmpty) {
        isExist = mostRecentHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(mostRecent =>

         mostRecent.getString(1).equalsIgnoreCase(historyElement) &&

            patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>
              !hvisit.isNullAt(3)
&&
                hvisit.getString(1).equalsIgnoreCase(historyElement) &&

                isDateBetween(hvisit.getDateTime(2), mostRecent.getDateTime(2).minusMonths(months), mostRecent.getDateTime(2))

                && hvisit.getString(3).equalsIgnoreCase(value)
            )
        )


      }
      val argsArray: Array[String] = Array(historyElement, value,months.toString)
      measureLogger(visit, m, "wasElementBeforeWithResultElementWithinXMonths", value, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * PARENT function
    *
    * @param r                  current visit
    * @param m                  measure property
    * @param months             minus days in in element
    * @param patientHistoryList get patient history list
    * @return
    */


  def wasElementBeforeEncounterInXMonths(r: CassandraRow, m: MeasureProperty, historyElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]], mostRecentHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (mostRecentHistoryList.value.nonEmpty) {
        isExist = mostRecentHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(mostRecent =>
           mostRecent.getString(1).equalsIgnoreCase(historyElement) &&

            patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(hvisit =>
             hvisit.getString(1).equalsIgnoreCase(historyElement) &&

                isDateBetween(hvisit.getDateTime(2), mostRecent.getDateTime(2).minusMonths(months), mostRecent.getDateTime(2))
            )
        )
      }
      val argsArray: Array[String] = Array(historyElement, months.toString)
      measureLogger(r, m, "wasElementBeforeEncounterInXMonths", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /** PARENT Function
    * this function retirn true history element found within X Months from encounter date
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param histroyElement     history element whichh will be checked for overlaps encounter date
    * @param months             no. of Months overslaps from encounter date
    * @param patientHistoryList list of patient history
    * @return true if history element found within X days from encounter date
    */
  def wasElementPresentBeforeOrEqualEncounterInMonths(visit: CassandraRow, m: MeasureProperty, histroyElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           histroyElement.equalsIgnoreCase(x.getString(1))
            && (visit.getDateTime("encounterdate").minusMonths(months).isBefore(x.getDateTime(2))
            || visit.getDateTime("encounterdate").minusMonths(months).isEqual(x.getDateTime(2)))
        )
        val argsArray: Array[String] = Array(histroyElement, months.toString)
        measureLogger(visit, m, "wasElementPresentBeforeOrEqualEncounterInMonths", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentOverlapsEncounterInDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function checks if the diagnostic is after element and element compared with value provide
    *
    * @param visit               current patient visit
    * @param m                   measure  period
    * @param elementName         element name
    * @param elementDate         element date
    * @param elementValue        compare element value
    * @param condFlag            condition flag
    * @param patientHistoryList  patient history list
    * @param historyElements     history elements    *
    * @param wrapperFunctionName wrapper Function Name for Logger
    * @return returns true if the diagnostic is after element and element compared with value provide else returns false
    */
  def wasElementAfterElementAndValueWithinXDays(visit: CassandraRow, m: MeasureProperty, elementName: String, elementDate: String, elementValue: Double, condFlag: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElements: String, wrapperFunctionName: String): Boolean = {
    var isExist = false
    val elementsNotNull = checkNotNull(visit, elementName, elementDate)

    if (elementsNotNull) {
      try {
        if (patientHistoryList.value.nonEmpty) {
          isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
            .exists(hvisit => !hvisit.isNullAt(3) && historyElements.equalsIgnoreCase(hvisit.getString(1))
            && visit.getDate(elementDate).after(hvisit.getDate(2))
            && compareValueStatus(hvisit.getDouble(3), condFlag, elementValue))

        }

        val argsArray: Array[String] = Array(elementName, elementDate, elementValue.toString())
        measureLogger(visit, m, wrapperFunctionName, elementDate, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isDiagnosticStudyPerformedAfterWithValue:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)

        }
      }
    }
    isExist
  }

  /**
    * This function verifies if the communication is done after x procedure days
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param elementName        Procedure element name
    * @param elementDate        Procedure element date
    * @param days               no of days
    * @param patientHistoryList patient history list
    * @param historyElement     Communication element name
    * @return returns true if the communication is done after x procedure days else returns false
    */
  def wasCommunicationDoneAfterProcedureWithinXDays(visit: CassandraRow, m: MeasureProperty, elementName: String, elementDate: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]], historyElement: String): Boolean = {
    var isExist = false

    val elementsNotNull = checkNotNull(visit, elementName, elementDate)
    if (elementsNotNull) {
      try {

        if (patientHistoryList.value.nonEmpty) {
          isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
            .exists(hvisit =>  historyElement.equalsIgnoreCase(hvisit.getString(1))
            && isDateBetween(hvisit.getDateTime(2), visit.getDateTime(elementDate), visit.getDateTime(elementDate).plusDays(days))
          )
        }
        val argsArray: Array[String] = Array(historyElement, days.toString, elementName)
        measureLogger(visit, m, "wasCommunicationDoneAfterProcedureWithinXDays", historyElement, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasCommunicationDoneAfterProcedureWithinXDays:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)

        }
      }
    }
    isExist
  }

  /**
    * This function checks if the most recent physical exam performed element is before with other other physical exam performed
    *
    * @param visit                        current patient visit
    * @param m                            measure property
    * @param historyElementName           history element name
    * @param currentElementDate           current element date
    * @param mostRecentPatientHistoryList most recent patient history list
    * @return true  if the most recent physical exam performed element is before with other other physical exam performed
    */
  def isMostRecentPhysicalExamPerformedBefore(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, historyElementName: String, mostRecentPatientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (mostRecentPatientHistoryList.value.nonEmpty) {
        isExist = mostRecentPatientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !visit.isNullAt(currentElementDate)
          && x.getString(1).equalsIgnoreCase(historyElementName)
          && x.getDateTime(2).isBefore(visit.getDateTime(currentElementDate))
        )
      }

      val argsArray: Array[String] = Array(currentElementDate, historyElementName)
      measureLogger(visit, m, "isMostRecentPhysicalExamPerformedBefore", historyElementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isMostRecentPhysicalExamPerformedBefore:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function checks if the most recent physical exam performed element is concurrent with other other physical exam perfomred
    *
    * @param visit                        current patient visit
    * @param m                            measure property
    * @param historyElementName           history element name
    * @param currentElement               current element
    * @param currentElementDate           current element date
    * @param mostRecentPatientHistoryList most recent patient history list
    * @return true  if the most recent physical exam performed element is concurrent with other other physical exam performed else returns false
    */
  def isMostRecentPhysicalExamPerformedConcurrent(visit: CassandraRow, m: MeasureProperty, historyElementName: String, currentElement: String, currentElementDate: String, mostRecentPatientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (mostRecentPatientHistoryList.value.nonEmpty) {
        isExist = mostRecentPatientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>
          !visit.isNullAt(currentElement) && !visit.isNullAt(currentElementDate)
          && x.getString(1).equalsIgnoreCase(historyElementName)
          && x.getDateTime(2).isEqual(visit.getDateTime(currentElementDate))
        )
      }

      val argsArray: Array[String] = Array(currentElement, historyElementName, currentElementDate)
      measureLogger(visit, m, "isMostRecentPhysicalExamPerformedConcurrent", historyElementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isMostRecentPhysicalExamPerformedConcurrent:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * PARENT function
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param months             minus days in in element
    * @param patientHistoryList get patient history list
    * @return it return history element is present before most recent element
    */

  def wasElementPresentBeforeMostRecentElement(visit: CassandraRow, m: MeasureProperty, currentElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]], mostRecentHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (mostRecentHistoryList.value.nonEmpty) {
        isExist = mostRecentHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(mostRecent =>

           visit.getString("patientuid").equals(mostRecent.getString("patientuid"))

            && mostRecent.getString(1).equalsIgnoreCase(currentElement) &&

            patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(Hvisit =>
              Hvisit.getString(1).equalsIgnoreCase(currentElement)

                && (Hvisit.getDate(2).before(mostRecent.getDate(2))
                ||
                Hvisit.getDate(2).equals(mostRecent.getDate(2)))
            )
        )

      }
      val argsArray: Array[String] = Array(currentElement,months.toString)
      measureLogger(visit, m, "wasElementPresentBeforeMostRecentElement", currentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * This function verifies the Immunization is X weeks before Ed or CC Encounter
    *
    * @param visit              current visit of the patient.
    * @param m                  Measure property of the Measure
    * @param Element            Element that has to be verified for procedure.
    * @param edvisitArrivalDate EdArrival Date of the patient
    * @param crtclrDate         Critcal Care Visit date of the patient.
    * @param noOfWeeks          Number of weeks that will go back in history
    * @param patientHistoryList patient history list
    * @return It will return true if immunization is done before X weeks emergency visit.
    */

  def isImmunizationBeforeXWeeksEdOrCcEncounter(visit: CassandraRow, m: MeasureProperty, Element: String, edvisitArrivalDate: String, crtclrDate: String, noOfWeeks: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvist =>
          histvist.getString(1).equalsIgnoreCase(Element)
            && (

            (
              histvist.getDateTime(2).isBefore(visit.getDateTime(crtclrDate)) && histvist.getDateTime(2).isAfter(visit.getDateTime(crtclrDate).minusWeeks(noOfWeeks))
                || histvist.getDateTime(2).isEqual(visit.getDateTime(crtclrDate)) || histvist.getDateTime(2).isEqual(visit.getDateTime(crtclrDate).minusWeeks(noOfWeeks))
              )
              ||
              (
                histvist.getDateTime(2).isBefore(visit.getDateTime(edvisitArrivalDate)) && histvist.getDateTime(2).isAfter(visit.getDateTime(edvisitArrivalDate).minusWeeks(noOfWeeks))
                  || histvist.getDateTime(2).isEqual(visit.getDateTime(edvisitArrivalDate)) || histvist.getDateTime(2).isEqual(visit.getDateTime(edvisitArrivalDate).minusWeeks(noOfWeeks))
                )

            )

        )
      }
      val argsArray: Array[String] = Array(Element,edvisitArrivalDate, crtclrDate,noOfWeeks.toString)
      measureLogger(visit, m, "isImmunizationBeforeXWeeksEdOrCcEncounter", Element, isExist, argsArray)
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }

  /**
    * This function verifies the Diagnostic Study before X days of procedure.
    *
    * @param visit              current visit of the patient.
    * @param m                  Measure property of the Measure
    * @param CurrentElement     Element that has to be verified for procedure.
    * @param histElement        History element with that current element has to be compared.
    * @param noOfDays           Number of days that will go back in history
    * @param patientHistoryList patient history list
    * @return
    */
  def wasDiagnosticStudyBeforeXDaysProcedure(visit: CassandraRow, m: MeasureProperty, CurrentElement: String, histElement: String, noOfDays: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val CurrentElementDate = CurrentElement + "_date"
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvist =>
          histvist.getString(1).equalsIgnoreCase(histElement)
            && !visit.isNullAt(CurrentElement)
            &&
            (
              histvist.getDateTime(2).isBefore(visit.getDateTime(CurrentElementDate)) && histvist.getDateTime(2).isAfter(visit.getDateTime(CurrentElementDate).minusDays(noOfDays))
                || histvist.getDateTime(2).isEqual(visit.getDateTime(CurrentElementDate)) || histvist.getDateTime(2).isEqual(visit.getDateTime(CurrentElementDate).minusDays(noOfDays))
              )

        )
      }
      val argsArray: Array[String] = Array(CurrentElement, noOfDays.toString, histElement)
      measureLogger(visit, m, "wasDiagnosticStudyBeforeXDaysProcedure", CurrentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * This function  verifies the procedure is performed x months after Diagnosis.
    *
    * @param visit              current visit of the patient.
    * @param m                  Measure property of the Measure
    * @param CurrentElement     Element that has to be verified for procedure.
    * @param histElement        History element with that current element has to be compared.
    * @param noOfMonths         number of months that will go back in history
    * @param patientHistoryList patient history list
    * @return
    */
  def wasProcedurePerformedXMonthsAfterDiagnosis(visit: CassandraRow, m: MeasureProperty, CurrentElement: String, histElement: String, noOfMonths: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val CurrentElementDate = CurrentElement + "_date"
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvist =>
          histvist.getString(1).equalsIgnoreCase(histElement)
            && !visit.isNullAt(CurrentElement)
            &&
            (
              histvist.getDateTime(2).isBefore(visit.getDateTime(CurrentElementDate)) && histvist.getDateTime(2).isAfter(visit.getDateTime(CurrentElementDate).plusMonths(noOfMonths))
                ||
                histvist.getDateTime(2).isEqual(visit.getDateTime(CurrentElementDate)) || histvist.getDateTime(2).isEqual(visit.getDateTime(CurrentElementDate).plusMonths(noOfMonths))
              )
        )
      }
      val argsArray: Array[String] = Array(CurrentElement, noOfMonths.toString, histElement)
      measureLogger(visit, m, "wasProcedurePerformedXMonthsAfterDiagnosis", CurrentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }




  /**
    * This function verifies if current medication is done after x days of other medication
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param currentElementName current medication name
    * @param currentElementDate current medication date
    * @param noOfDays           no of days to be checked after
    * @param historyElement     medication to be checked after in history
    * @param patientHistoryList patient history list
    * @return returns true if current medication is done after x days of other medication else retuns false
    */
  def wasMedicationStartsAfterEndOfXDaysOfMedication(visit: CassandraRow, m: MeasureProperty, currentElementName: String, currentElementDate: String, noOfDays: Int, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementsNotNull = checkNotNull(visit, currentElementName, currentElementDate)
    if (elementsNotNull) {
      try {
        if (patientHistoryList.value.nonEmpty) {
//          val startDate = m.quarterStartDate
//          val endDate = m.quarterEndDate
          isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hVisit =>
            historyElement.equalsIgnoreCase(hVisit.getString(1))
            && isDateBetween(hVisit.getDateTime(2), m.quarterStartDate, m.quarterEndDate)
            && visit.getDateTime(currentElementDate).isAfter(hVisit.getDateTime(2).plusDays(noOfDays))
          )
        }

        val argsArray: Array[String] = Array(currentElementName, currentElementDate, noOfDays.toString, historyElement)
        measureLogger(visit, m, "wasMedicationStartsAfterEndOfXDaysOfMedication", historyElement, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasMedicationStartsAfterEndOfXDaysOfMedication:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist
  }

  /**
    * This Function verifies the Medication is peformed after or equal X hours of procedure performed.
    *
    * @param visit              current patient visit
    * @param m                  measure property of the measure
    * @param currentElementName current element name
    * @param historyElement     History Element that has be verified in the history.
    * @param noOfHours          number of hours that has to be go back.
    * @param patientHistoryList patient history List
    * @return It will return true if the medication is after
    */
  def wasMedicationBeforeXhrOfProcedure(visit: CassandraRow, m: MeasureProperty, currentElementName: String, historyElement: String, noOfHours: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val currentElementDate = currentElementName + "_date"
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hVisit => checkNotNull(visit, currentElementName, currentElementDate)
          && hVisit.getString(1).equalsIgnoreCase(historyElement) &&
          ((hVisit.getDateTime(2).isAfter(visit.getDateTime(currentElementDate).minusHours(noOfHours))
            && hVisit.getDateTime(2).isBefore(visit.getDateTime(currentElementDate)))
            ||
            hVisit.getDateTime(2).isEqual(visit.getDateTime(currentElementDate))
            ||
            hVisit.getDateTime(2).isEqual(visit.getDateTime(currentElementDate).minusHours(noOfHours)))
        )
      }

      val argsArray: Array[String] = Array(historyElement, noOfHours.toString, currentElementName)
      measureLogger(visit, m, "wasMedicationBeforeXhrOfProcedure", currentElementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function checks if the element screening is performed X months before start of diagnosis
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param currentElementName current element name
    * @param currentElementDate current element date
    * @param historyElement     history element name
    * @param noOfMonths         no of months to be checked
    * @param patientHistoryList patients history list
    * @return returns true if  the element screening is performed X months before start of diagnosis else returns false
    */
  def wasElementScreeningPerformedXMonthsBeforeStartOfDiagnosis(visit: CassandraRow, m: MeasureProperty, currentElementName: String, currentElementDate: String, historyElement: String, noOfMonths: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementsNotNull = checkNotNull(visit, currentElementName, currentElementDate)
    if (elementsNotNull) {
      try {
        if (patientHistoryList.value.nonEmpty) {
          isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hVisit =>
            historyElement.equalsIgnoreCase(hVisit.getString(1))
            && ((visit.getDateTime(currentElementDate).isAfter(hVisit.getDateTime(2).minusMonths(noOfMonths)) ||
            visit.getDateTime(currentElementDate).isEqual(hVisit.getDateTime(2).minusMonths(noOfMonths)))
            && visit.getDateTime(currentElementDate).isBefore(hVisit.getDateTime(2)))
          )
        }


        val argsArray: Array[String] = Array(currentElementName, currentElementDate,noOfMonths.toString, historyElement)
        measureLogger(visit, m, "wasElementScreeningPerformedXMonthsBeforeStartOfDiagnosis", historyElement, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementScreeningPerformedXMonthsBeforeStartOfDiagnosis:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist
  }

  /**
    * this function checks whether histroyElement date is before within some months from elementDate
    *
    * @param visit              current cassandra visit
    * @param m                  measure property
    * @param elementDate        element date which comes from current visit
    * @param histroyElement     history element
    * @param month              no of months which will be look back from element Date
    * @param patientHistoryList patient history list
    * @return true if wasElementValueBeforeWithinXMonths date is before within some months from elementDate
    */
  def wasElementValueBeforeWithinXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, histroyElement: String, month: Int, value: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val lowerDate = visit.getDateTime(elementDate).minusMonths(month)
    val higherDate = visit.getDateTime(elementDate)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          !x.isNullAt(3)
           && histroyElement.equalsIgnoreCase(x.getString(1))
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
            && compareValueStatus(x.getDouble(3), flag, value)
        )

        val argsArray: Array[String] = Array(elementDate,histroyElement,month.toString,value.toString,flag)
        measureLogger(visit, m, "wasElementValueBeforeWithinXMonths", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        //System.exit(0)
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementValueBeforeWithinXMonths:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }


  /** PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param currentElement     element name whose date will be checked
    * @param calenderUnit valid calender unis are (YEAR,MONTH,DAY,HOUR,MINUTE)
    * @param calenderInterval used with calender unit
    * @param timeCompareOperator valid operators are {CompareOperator.{GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL}
    * @param patientHistoryList list of patient history
    * @return true if element is already present before another element
    */
  def wasElementPresentBeforeInXPeriods(visit: CassandraRow, m: MeasureProperty, currentElement: String, calenderUnit:String, calenderInterval: Int, timeCompareOperator:String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: Seq[String]): Boolean = {
    var isExist = false
    try {
      //val currentElementDate = currentElement + "_date"

      val currentElementDate= if (currentElement.equalsIgnoreCase(AdminElements.Encounter_Date)) AdminElements.Encounter_Date else currentElement+"_date"

      if (patientHistoryList.value.nonEmpty) {
        val higherDate=visit.getDateTime(currentElementDate)
        val lowerDate=lowerCalenderDate(higherDate,calenderUnit,calenderInterval)
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histRow =>
           // && x.getString(1).equalsIgnoreCase(historyElementName)
          // && x.getDate(2).before(visit.getDate(currentElementDate))
           historyElementName.exists(element => histRow.getString(1).equalsIgnoreCase(element)
          && compareTimeOperator(histRow.getDateTime(2),lowerDate,higherDate,timeCompareOperator)
         )
        )
      }
      val argsArray: Array[String] = Array(currentElementDate,calenderUnit,calenderInterval.toString,timeCompareOperator)
      measureLogger(visit, m, "wasElementPresentBeforeInXPeriods", currentElementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentBeforeInXPeriods:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /** PARENT Function
    * This Function verifies the assessment of a patient is performed  greater than value.
    *
    * @param visit              current Visit of the patient.
    * @param m                  measure property of the measure(mesureId and condition)
    * @param elementName        ElementName that has to be look in the history.
    * @param lowerValue         Value that has to be verified.
    * @param lowerFlag          flag that will define the condition whether to check greater or greaterEqualto condition.
    * @param patientHistoryList Patient history list.
    * @return
    */
  def checkElementValueInRangeDuringMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, elementName: String, lowerValue: Double, lowerFlag: String, higherValue: Double, higherFlag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
//        var startDate = m.quarterStartDate
//        var endDate = m.quarterEndDate

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !x.isNullAt("patientuid") && !x.isNullAt(1) && !x.isNullAt(2)
          &&
          !x.isNullAt(3)
          &&
          x.getString(1).equalsIgnoreCase(elementName)
          && isDateBetween(x.getDateTime(2), m.quarterStartDate, m.quarterEndDate)
          && (compareValueStatus(x.getDouble(3), lowerFlag, lowerValue)) && compareValueStatus(x.getDouble(3), higherFlag, higherValue))
      }

      val argsArray: Array[String] = Array(elementName, lowerValue.toString, lowerFlag ,higherValue.toString,higherFlag)
      measureLogger(visit, m, "checkElementValueInRangeDuringMeasurementPeriod", elementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementValueDuringMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * this function checks whether value of element satisfy the condition flag and element is between startdate  and startDate - years
    *
    * @param visit              current visit
    * @param m                  measure Property of the measure
    * @param historyElementName history element
    * @param years              no of days before currentElementDate
    * @param lowerValue         value that need to be checked
    * @param lowerFlag          for value condition like ge >= etc
    * @param patientHistoryList patient history
    * @return true if value of element satisfy the condition flag and element is between startdate  and startDate - years
    */
  def checkElementValueInRangeBeforeEndWithinXYears(visit: CassandraRow, m: MeasureProperty, historyElementName: String, years: Int, lowerValue: Double, lowerFlag: String, higherValue: Double, higherFlag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

//        val startDate = m.quarterStartDate
        val lowerDate = m.quarterStartDate.minusYears(years)
        val higherDate = m.quarterStartDate

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x => !x.isNullAt(3)
          && x.getString(1).equalsIgnoreCase(historyElementName)
          && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
          && (compareValueStatus(x.getDouble(3), lowerFlag, lowerValue)) && compareValueStatus(x.getDouble(3), higherFlag, higherValue))

      }

      val argsArray: Array[String] = Array(historyElementName, years.toString,lowerValue.toString,lowerFlag,higherValue.toString,higherFlag)
      measureLogger(visit, m, "checkElementValueInRangeBeforeEndWithinXYears", historyElementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isMostRecentPhysicalExamPerformedBefore:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }
/*

 /**
    * PARENT function
    * This function verifies if element was after element date within X period
    * @param visit              current visit
    * @param m                  measure property
    * @param elementDate        get element check between
    * @param calenderInterval   no of calender units to be looked after
    * @param calenderUnit  represents calender unit(valid units are  YEAR,MONTH,WEEK,DAY,MINUTES)
    * @param patientHistoryList get patient history list
    * @return returns true if element was after element date within X period else returns false
    */


  def wasElementAfterElementDateWithinXPeriod(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElementName: String, calenderUnit:String, calenderInterval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val lowerDate = visit.getDateTime(elementDate)
    val higherDate = higherCalenderDate(lowerDate,calenderUnit,calenderInterval)

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.exists(x =>

          !x.isNullAt(2)

            && visit.getString("patientuid").equals(x.getString("patientuid"))

            && x.getString(1).equalsIgnoreCase(historyElementName)

            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
        )

      }
      //val argsArray: Array[String] = Array(calenderInterval.toString, elementDate)
      //measureLogger(visit, m, "wasElementAfterElementDateWithinXDays", elementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }
*/


  def wasLaboratoryTestPerformedBeforeMedication(visit: CassandraRow, m: MeasureProperty, currentElement: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: String*): Boolean = {
    wasElementPresentBeforeOrEqualOtherElement(visit, m, currentElement,CompareOperator.LESS_EQUAL,patientHistoryList, historyElementName)
  }

  def wasMedicationAdministeredAfterDiagnosis(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: String*): Boolean = {
    wasElementPresentAfter(visit, m, currentElementDate, patientHistoryList, historyElementName)
  }

  /**
    * This function will return list of least recent data from patient history
    *
    * @param historyRDD History RDD
    * @param elements    element of which most recent record we need
    * @return list of cassandra row will contains patient least recent element record
    */
  def leastRecentPatientList(historyRDD: RDD[CassandraRow], elements: String*): List[CassandraRow] = {

   /* val leastRecentElements = historyRDD.filter(l =>
       Element.contains(l.getString(1)))

      .map(l => ((l.getString("patientuid"), l.getString(1)), l.getDate(2)))

      .reduceByKey((x, y) => if (x.before(y)) x else y)

      .collect().toList

    val mostRecentList = historyRDD.filter(r => leastRecentElements.exists(x => x._1._1.equalsIgnoreCase(r.getString("patientuid"))

      && x._1._2.equalsIgnoreCase(r.getString(1))

      && x._2.equals(r.getDate(2)))).collect().toList

    mostRecentList*/

    historyRDD.filter(l =>
      elements.contains(l.getString(1)))
      .map(l => ((l.getString(0), l.getString(1)), l))
      .reduceByKey((x, y) => if (x.getDate(2).before(y.getDate(2))) x else y).map(r=>r._2)
      .collect().toList

  }


  /**
    * This function verifies if element is performed starts after start of other element
    *
    * @param visit               current patient visit
    * @param m                   measure property
    * @param currentElementName  current element name
    * @param historyElementName  history element name
    * @param leastRecentList
    * @param patientHistoryList  patient history list
    * @param wrapperFunctionName wrapper calling function name
    * @return returns true if element is performed starts after start of other element else returns false
    */
  def startsAfterStartOf(visit: CassandraRow, m: MeasureProperty, currentElementName: String, historyElementName: String, leastRecentList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]], wrapperFunctionName: String): Boolean = {
    var isExist = false
    val elementsNotNull = checkNotNull(visit, currentElementName)
    if (elementsNotNull) {
      try {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hVisit =>
          historyElementName.equalsIgnoreCase(hVisit.getString(1))

          &&
          leastRecentList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(r =>
           r.getString(1).equalsIgnoreCase(currentElementName)
            && r.getDateTime(2).isBefore(hVisit.getDateTime(2)))
        )
        val argsArray: Array[String] = Array(historyElementName, currentElementName)
        measureLogger(visit, m, wrapperFunctionName, historyElementName, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", s"Function Exception:$wrapperFunctionName:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist
  }




  /*/**
    * PARENT function
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param elementDate        get element check between
    * @param historyElement     hostory element name
    * @param months             minus days in in element
    * @param patientHistoryList get patient history list
    * @return
    */


  def wasElementAfterElementDateWithinXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, historyElement1: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    //val end_Date = new DateTime(m.quarterEndDate)
    val lowerDate = visit.getDateTime(elementDate).minusMonths(months)
    val higherDate = visit.getDateTime(elementDate)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.exists(x =>

          !x.isNullAt(2)

            && visit.getString("patientuid").equals(x.getString("patientuid"))

            && x.getString(1).equalsIgnoreCase(historyElement)

            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

            && x.getString(1).equalsIgnoreCase(historyElement1)
        )
      }
      val argsArray: Array[String] = Array(months.toString, elementDate)
      measureLogger(visit, m, "wasElementAfterElementDateWithinXMonths", elementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }
*/
  def wasMedicationAfterXhrOfProcedure(visit: CassandraRow, m: MeasureProperty, currentElementName: String, historyElement: String, noOfHours: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val currentElementDate = currentElementName + "_date"
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(hVisit => checkNotNull(visit, currentElementName, currentElementDate)
          && hVisit.getString(1).equalsIgnoreCase(historyElement) &&
          ((hVisit.getDateTime(2).isBefore(visit.getDateTime(currentElementDate).plusHours(noOfHours))
            && hVisit.getDateTime(2).isAfter(visit.getDateTime(currentElementDate)))
            ||
            hVisit.getDateTime(2).isEqual(visit.getDateTime(currentElementDate))
            ||
            hVisit.getDateTime(2).isEqual(visit.getDateTime(currentElementDate).plusHours(noOfHours)))
        )
      }

      val argsArray: Array[String] = Array(historyElement, noOfHours.toString, currentElementName)
      measureLogger(visit, m, "wasMedicationAfterXhrOfProcedure", currentElementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist

  }

  /**
    *
    * @param visit              current row
    * @param m                  measure property
    * @param histroyElement     element to be checked before end date
    * @param days               number of days
    * @param patientHistoryList patient history list
    * @return returns true if patient was diagnosed before x days from end date
    */
  def wasElementInXDaysBeforeEndDate(visit: CassandraRow, m: MeasureProperty, histroyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val endDate = m.quarterEndDate
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
            histroyElement.equalsIgnoreCase(x.getString(1))
            && (
            x.getDateTime(2).isBefore(endDate.minusDays(days))
              ||
              x.getDateTime(2).isEqual(endDate.minusDays(days))
            )

        )
        val argsArray: Array[String] = Array(histroyElement, days.toString)
        measureLogger(visit, m, "wasElementInXDaysBeforeEndDate", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementInXDaysBeforeEndDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /** PARENT Function
    * This Function verifies the assessment of a patient is performed  greater than value.
    *
    * @param visit              current Visit of the patient.
    * @param m                  measure property of the measure(mesureId and condition)
    * @param elementName        ElementName that has to be look in the history.
    * @param value              Value that has to be verified.
    * @param flag               flag that will define the condition whether to check greater or greaterEqualto condition.
    * @param patientHistoryList Patient history list.
    * @return
    */
  def checkElementValueBeforeOrEqualEncounter(visit: CassandraRow, m: MeasureProperty, elementName: String, value: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          !x.isNullAt(3)
          &&
          x.getString(1).equalsIgnoreCase(elementName)
          && (x.getDate(2).before(visit.getDate("encounterdate"))
          || x.getDate(2).equals(visit.getDate("encounterdate")))

          && compareValueStatus(x.getDouble(3), flag, value)
        )

      }

      val argsArray: Array[String] = Array(elementName, value.toString, flag)
      measureLogger(visit, m, "checkElementValueBeforeOrEqualEncounter", elementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementValueDuringMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * //PARENT FUNCTION
    *
    * @param visit              cassandra row
    * @param m                  measure property
    * @param historyElement     element to be checked in X days from element
    * @param currentElement     element from which Future element would be checked
    * @param days               number of days
    * @param patientHistoryList patient history list
    * @return returns true if Future element has happened in x days from element
    */

  def wasElementAfterElementWithinXDays(visit: CassandraRow, m: MeasureProperty, historyElement: String, currentElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>

            x.getString(1).equalsIgnoreCase(historyElement)

            && isDateBetween(x.getDateTime(2), visit.getDateTime(currentElement + "_date"), visit.getDateTime(currentElement + "_date").plusDays(days))
        )

      }
      val argsArray: Array[String] = Array(historyElement, days.toString, currentElement)
      measureLogger(visit, m, "wasElementAfterElementWithinXDays", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementAfterElementWithinXDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    * //PARENT FUNCTION
    *
    * @param visit              cassandra row
    * @param m                  measure property
    * @param historyElement     element to be checked in X hours from element
    * @param currentElement     element from which Future element would be checked
    * @param hours              number of days
    * @param patientHistoryList patient history list
    * @return returns true if Future element has happened in x hours from element
    */


  def wasElementBeforeElementWithinXHours(visit: CassandraRow, m: MeasureProperty, historyElement: String, currentElement: String, hours: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val lowerDate = visit.getDateTime(currentElement).minusHours(hours)
    val higherDate = visit.getDateTime(currentElement)

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         x.getString(1).equalsIgnoreCase(historyElement)
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
        )

      }
      val argsArray: Array[String] = Array(historyElement, hours.toString, currentElement)
      measureLogger(visit, m, "wasElementBeforeElementWithinXHours", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementAfterElementWithinXDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    *
    * @param visit              current row
    * @param m                  measure property
    * @param element            element from current row
    * @param histroyElement1    element to be checked in history before current element
    * @param histroyElement2    element to be checked in history before current element
    * @param historyElement3    element to be checked in history before current element
    * @param patientHistoryList patient history list
    * @return returns true if history element1 along with history element 2 and history element 3 is before current element
    */
  def wasAssessmentPerformedBeforeMedicationActive(visit: CassandraRow, m: MeasureProperty, element: String, histroyElement1: String, histroyElement2: String, historyElement3: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
       /* visit.getString("patientuid").equals(x.getString("patientuid"))

          &&*/ histroyElement1.equalsIgnoreCase(x.getString(1))
          &&
          patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(x.getString("patientuid"))).exists(y => !y.isNullAt(2)
            &&
           /* y.getString("patientuid").equals(x.getString("patientuid"))
            &&*/ histroyElement2.equalsIgnoreCase(y.getString(1))
            &&
            patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(x.getString("patientuid"))).exists(z => !z.isNullAt(2)
              && /*z.getString("patientuid").equals(x.getString("patientuid"))
              &&*/ historyElement3.equalsIgnoreCase(z.getString(1))
              && y.getDateTime(2).isEqual(x.getDateTime(2))
              && z.getDateTime(2).isEqual(x.getDateTime(2))
            )
          )
          &&  x.getDateTime(2).isBefore(visit.getDateTime(element + "_date"))

      )
      val argsArray: Array[String] = Array(histroyElement1, histroyElement2, historyElement3, element)
      measureLogger(visit, m, "wasAssessmentPerformedBeforeMedicationActive", histroyElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isAssessmentPerformedBeforeMedicationActive:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /** PARENT Function
    * this function returns true history element found within X months from end date
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param histroyElement     history element which will be checked for overlaps end date
    * @param month              no. of days overlaps from encounter date
    * @param patientHistoryList list of patient history
    * @return true if history element found Overlaps X days from end date
    */
  def wasElementPresentBeforeOrEqualEndInMonths(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val endDate = m.quarterEndDate
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         histroyElement.equalsIgnoreCase(x.getString(1))
            &&
          ((x.getDateTime(2).isBefore(endDate.minusMonths(month)))
            ||
            (x.getDateTime(2).isEqual(endDate.minusMonths(month)))
        ))
        val argsArray: Array[String] = Array(histroyElement, month.toString)
        measureLogger(visit, m, "wasElementPresentBeforeOrEqualEndInMonths", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentOverlapsEncounterInDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

 /* /** PARENT Function
    * this function retirn true history element found within X months from end date
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param histroyElement     history element which will be checked for overlaps end date
    * @param month              no. of days overslaps from encounter date
    * @param patientHistoryList list of patient history
    * @return true if history element found Overlaps X days from end date
    */
  def wasElementPresentStartOrEqualWithInMonths(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val lowerDate = m.quarterStartDate
    val higherDate = lowerDate.plusMonths(month)

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.exists(x =>

          !x.isNullAt(2)

            && visit.getString("patientuid").equals(x.getString("patientuid"))

            && histroyElement.equalsIgnoreCase(x.getString(1))

            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

        )
        val argsArray: Array[String] = Array(histroyElement, month.toString)
        measureLogger(visit, m, "wasElementPresentStartOrEqualWithInMonths", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentOverlapsEncounterInDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

*/








  /** PARENT Function
    * This function checks if history element starts after start of other element
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param element valid inputs are(AdminElements.Encounter_Date,AdminElements.Measurement_Period_Start_Date or element date)
    * @param historyElement     history element which will be checked in history
    * @param calenderUnit  valid units are CalenderUnits.x
    * @param calenderInterval              no of calender units to be checked after
    *                                      @param  timeCOperator valid time operators are CompareOperator.x
    * @param patientHistoryList list of patient history
    * @return returns true if history element starts after start of other element else returns false
    */
  def wasElementPresentAfterStartOfWithinXPeriod(visit: CassandraRow, m: MeasureProperty,element:String, calenderUnit:String, calenderInterval: Int,timeCOperator:String,patientHistoryList: Broadcast[List[CassandraRow]],historyElement: String): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {

        val (lowerDate,higherDate)= element match {
          case AdminElements.Encounter_Date => (visit.getDateTime(AdminElements.Encounter_Date),higherCalenderDate(visit.getDateTime(AdminElements.Encounter_Date),calenderUnit,calenderInterval))
          case "measurement_period_start_date"=> (m.quarterStartDate,higherCalenderDate(m.quarterStartDate,calenderUnit,calenderInterval))
          case _ => (visit.getDateTime(element+"_date"),higherCalenderDate(visit.getDateTime(element+"_date"),calenderUnit,calenderInterval))
        }

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histRow =>
           historyElement.equalsIgnoreCase(histRow.getString(1))
            && compareTimeOperator(histRow.getDateTime(2),lowerDate,higherDate,timeCOperator)

        )
        val argsArray: Array[String] = Array(historyElement, calenderInterval.toString,calenderUnit,element)
        measureLogger(visit, m, "wasElementPresentAfterStartOfWithinXPeriod", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentAfterStartOfWithinXPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param element            element from current row
    * @param histroyElement1    element to be checked in history before current element
    * @param patientHistoryList patient history list
    * @return returns true if history element was before current element
    */
  def wasAssessmentPerformedBeforeMedicationActive(visit: CassandraRow, m: MeasureProperty, element: String, histroyElement1: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         histroyElement1.equalsIgnoreCase(x.getString(1))
          && (x.getDateTime(2).isBefore(visit.getDateTime(element + "_date"))
          || x.getDateTime(2).isEqual(visit.getDateTime(element + "_date")))
      )
      val argsArray: Array[String] = Array(histroyElement1, element)
      measureLogger(visit, m, "wasAssessmentPerformedBeforeMedicationActive", element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAssessmentPerformedBeforeMedicationActive:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param element            element from current row
    * @param histroyElement1    element to be checked in history before current element
    * @param patientHistoryList patient history list
    * @return returns true if history element was before current element
    */
  def wasCommunicationDoneFromPatientToProviderBeforeMedicationActive(visit: CassandraRow, m: MeasureProperty, element: String, histroyElement1: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         histroyElement1.equalsIgnoreCase(x.getString(1))
          && (x.getDateTime(2).isBefore(visit.getDateTime(element + "_date"))
          || x.getDateTime(2).isEqual(visit.getDateTime(element + "_date")))
      )
      val argsArray: Array[String] = Array(histroyElement1, element)
      measureLogger(visit, m, "wasCommunicationDoneFromPatientToProviderBeforeMedicationActive", element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasCommunicationDoneFromPatientToProviderBeforeMedicationActive:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /** PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param patientHistoryList list of patient history
    * @return true if element is already present after another element or equal
    */
  def wasElementPresentAfterOrEqual(visit: CassandraRow, m: MeasureProperty, CurrentElement: String, patientHistoryList: Broadcast[List[CassandraRow]], HistoryelementName: String): Boolean = {
    var isExist = false
    val CurrentElementDate = CurrentElement + "_date"
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         x.getString(1).equalsIgnoreCase(HistoryelementName)
          && (x.getDate(2).after(visit.getDate(CurrentElementDate)) ||
          x.getDate(2).equals(visit.getDate(CurrentElementDate)))
        )
      }
      val argsArray: Array[String] = Array(HistoryelementName, CurrentElement)
      measureLogger(visit, m, "wasElementPresentAfterOrEqual", CurrentElementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }




  /**
    * This function verifies if the encounter  performed starts X days in future
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param historyElement     history element name
    * @param currentElement     current element name
    * @param days               days to be looked after
    * @param patientHistoryList patient history list
    * @return returns true if the encounter  performed starts X days in future else returns false
    */
  def isEncounterPerformedXDaysInFuture(visit: CassandraRow, m: MeasureProperty, historyElement: String, currentElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
             x.getString(1).equalsIgnoreCase(historyElement)
            && isDateBetween(x.getDateTime(2), visit.getDateTime(currentElement + "_date").minusDays(days), visit.getDateTime(currentElement + "_date"))
        )

      }
      val argsArray: Array[String] = Array(historyElement, days.toString, currentElement)
      measureLogger(visit, m, "isEncounterPerformedXDaysInFuture", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isEncounterPerformedXDaysInFuture:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }




  /** PARENT Function
    * This function verifies if any adverse event happened with patient continued even after X hours
    *
    * @param visit              current visit of the patient
    * @param m                  Measure property of the measure
    * @param historyElement           Ischemic Stroke_Stop date time
    * @param currentElement           Ischemic Stroke_Start date time
    * @param NoOfHours          number of hours to check after element2
    * @param patientHistoryList Patient History List
    * @return returns true if any adverse event happened with patient continued even after X hours
    */


  def wasElementBeforeElementInXHours(visit: CassandraRow, m: MeasureProperty, historyElement: String, NoOfHours: Int, patientHistoryList: Broadcast[List[CassandraRow]],currentElement: Seq[String]): Boolean = {
    var isExist = false

    try {
      isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
        /*visit.getString("patientuid").equalsIgnoreCase(x.getString("patientuid"))
        &&*/
        x.getString(1).equalsIgnoreCase(historyElement)
        &&
        patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
         /* visit.getString("patientuid").equalsIgnoreCase(y.getString("patientuid"))
            &&*/
            currentElement.exists(z=>
            y.getString(1).equalsIgnoreCase(z)
              &&
            (
              x.getDateTime(2).equals(y.getDateTime(2).minusHours(NoOfHours))
                ||
                x.getDateTime(2).isBefore(y.getDateTime(2).minusHours(NoOfHours))
              ) )

        )
        )

      val argsArray: Array[String] = Array(historyElement,NoOfHours.toString)
      measureLogger(visit, m, "wasElementBeforeElementInXHours", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAdverseEventNotStoppedWithinXHours:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }

  /**
    * This function verifies the Sum of two laboratory test result less or equal to value.
    *
    * @param visit                        current visit of the patient.
    * @param m                            Measure Property of the measure.
    * @param currentelement               current element whose date has to be compared
    * @param labtest1                     first laboratory test in history
    * @param labtest2                     second laboratory test in history
    * @param MostRecentPatientHistoryList mostrecent patient history list
    * @return It will return true if the result of two lab test is less or equal to value else false.
    */

  def wasLaboratoryTestLessThanEqualXvalue(visit: CassandraRow, m: MeasureProperty, currentelement: String, labtest1: String, labtest2: String, value: Int, MostRecentPatientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val currentDate = currentelement + "_date"

    try {
      if (MostRecentPatientHistoryList.value.nonEmpty) {
        isExist = MostRecentPatientHistoryList.value.filter(histvist =>
          histvist.getString(0).equalsIgnoreCase(visit.getString("patientuid"))
          && histvist.getString(1).equalsIgnoreCase(labtest1) &&
          (histvist.getDate(2).before(visit.getDate(currentDate)) || histvist.getDate(2).equals(visit.getDate(currentDate)))
        ).exists(row => MostRecentPatientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(row.getString("patientuid")))
          .exists(y => !y.isNullAt(3) &&
           y.getString(1).equalsIgnoreCase(labtest2)
            && (y.getDate(2).before(visit.getDate(currentDate)) || y.getDate(2).equals(visit.getDate(currentDate)))
            && ((row.getInt(3) + (y.getInt(3))) <= value)
        )
        )

      }
      val argsArray: Array[String] = Array(labtest1, labtest2, value.toString, currentelement)
      measureLogger(visit, m, "wasLaboratoryTestLessThanEqualXvalue", currentelement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist
  }

  /** PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param currentElements element name whose date will be checked
    * @param patientHistoryList list of patient history
    * @return true if element is already present before another element
    */
  def wasElementPresentBeforeElementList(visit: CassandraRow, m: MeasureProperty, historyElementName: String, patientHistoryList: Broadcast[List[CassandraRow]], currentElements: Seq[String]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histRow =>
        /*  histRow.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          // && x.getString(1).equalsIgnoreCase(historyElementName)
          // && x.getDate(2).before(visit.getDate(currentElementDate))
          &&*/ histRow.getString(1).equalsIgnoreCase(historyElementName)
          && currentElements.exists(element=>histRow.getDate(2).before(visit.getDate(element+"_date")))
        )
      }
      val argsArray: Array[String] = Array(historyElementName)
      measureLogger(visit, m, "wasElementPresentBefore", historyElementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  def wasElementBeforeElementWithinXHours(visit: CassandraRow, m: MeasureProperty, historyElement: String, hours: Int, patientHistoryList: Broadcast[List[CassandraRow]], currentElement: Seq[String]): Boolean = {
    var isExist = false

    val DateTimeBetween = currentElement.map(z => (visit.getDateTime(z).minusHours(hours), visit.getDateTime(z)))

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
               x.getString(1).equalsIgnoreCase(historyElement)

            && DateTimeBetween.exists(c => isDateBetween(x.getDateTime(2), c._1, c._2))

        )

      }
      val argsArray: Array[String] = Array(historyElement, hours.toString)
      measureLogger(visit, m, "wasElementBeforeElementWithinXHours", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementAfterElementWithinXDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * PARENT function
    * This function verifies the element date lies between element date and element date plus number of months.
    *
    * @param visit              current visit of the patient
    * @param m                  measure property of the measur
    * @param element            element date that has to be compared with history element date.
    * @param historyElement     history element name
    * @param months             number of months that has to be added in the element date.
    * @param patientHistoryList list of history records of the patient
    * @return It will return true if element is after another element plus X days.
    */


  def wasElementAfterElementWithinXMonths(visit: CassandraRow, m: MeasureProperty, element: String, historyElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementDate = element + "_date"
    val lowerDate = visit.getDateTime(elementDate)
    val higherDate = visit.getDateTime(elementDate).plusMonths(months)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         x.getString(1).equalsIgnoreCase(historyElement)
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
        )
      }
      val argsArray: Array[String] = Array(historyElement, element,months.toString)
      measureLogger(visit, m, "wasElementAfterElementWithinXMonths", element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    *
    * @param visit              patient current visit
    * @param m                  measure property
    * @param elementName        get element check between
    * @param months             minus years in in element
    * @param patientHistoryList get patient history list
    * @return it return of Element before end of X in years
    */

  def wasElementBeforeStartWithInXMonths(visit: CassandraRow, m: MeasureProperty, elementName: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val startDate = m.quarterStartDate
    val lowerDate = m.quarterStartDate.minusMonths(months)
    val higherDate = m.quarterStartDate
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>
 isDateBetween(hvisit.getDateTime(2), lowerDate, higherDate)

        )
      }
      val argsArray: Array[String] = Array(elementName, months.toString)
      measureLogger(visit, m, "wasElementBeforeStartWithInXMonths", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * PARENT function
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param elementDate        get element check between
    * @param historyElement     hostory element name
    * @param historyElement1    hostory element name
    * @param months             minus days in in element
    * @param patientHistoryList get patient history list
    * @return
    */


  def wasElementAfterElementDateWithMethodinXMonths(visit: CassandraRow, m: MeasureProperty, elementDate: String, historyElement: String, historyElement1: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    //val end_Date = new DateTime(m.quarterEndDate)
    val lowerDate = visit.getDateTime(elementDate).minusMonths(months)
    val higherDate = visit.getDateTime(elementDate)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getString(1).equalsIgnoreCase(historyElement)
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
          &&
            patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
               x.getString(1).equalsIgnoreCase(historyElement1))
        )
      }
      val argsArray: Array[String] = Array(months.toString, elementDate)
      measureLogger(visit, m, "wasElementAfterElementDateWithMethodinXMonths", elementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  def wasTwoElementEqualBeforeEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, historyElement: String, historyElementResult: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val lowerDate = visit.getDateTime("encounterdate").minusMonths(months)
    val higherDate = visit.getDateTime("encounterdate")
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>

         x.getString(1).equalsIgnoreCase(historyElement)

            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

            && patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(y => !x.isNullAt(2)



            && y.getString(1).equalsIgnoreCase(historyElementResult)

            && x.getDate(2).equals(y.getDate(2))
          )


        )
      }
      val argsArray: Array[String] = Array(historyElement, historyElementResult,months.toString)
      measureLogger(visit, m, "wasElementAfterElementWithinXMonths", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * this function checks whether histroyElement date is before within some months from elementDate
    *
    * @param visit              current cassandra visit
    * @param m                  measure property
    * @param histroyElement     history element
    * @param month              no of months which will be look back from element Date
    * @param patientHistoryList patient history list
    * @return true if wasElementValueBeforeWithinXMonths date is before within some months from elementDate
    */
  def checkElementValueBeforeEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, value: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val lowerDate = visit.getDateTime("encounterdate").minusMonths(month)
    val higherDate = visit.getDateTime("encounterdate")
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>

          !x.isNullAt(3)
            && histroyElement.equalsIgnoreCase(x.getString(1))

            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
            &&
            compareValueStatus(x.getDouble(3), flag, value)
        )

        val argsArray: Array[String] = Array(histroyElement,month.toString,value.toString,flag)
        measureLogger(visit, m, "checkElementValueBeforeEncounterWithinXMonths", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        //System.exit(0)
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementValueBeforeWithinXMonths:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    * this function checks whether histroyElement date is before within some months from elementDate
    *
    * @param visit              current cassandra visit
    * @param m                  measure property
    * @param histroyElement     history element
    * @param month              no of months which will be look back from element Date
    * @param patientHistoryList patient history list
    * @return true if histroyElement date is before within some months from elementDate
    */
  def wasElementBeforeEncounterWithinXMonths(visit: CassandraRow, m: MeasureProperty, histroyElement: String, month: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val lowerDate = visit.getDateTime("encounterdate").minusMonths(month)
    val higherDate = visit.getDateTime("encounterdate")
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
 histroyElement.equalsIgnoreCase(x.getString(1))

            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

        )

        val argsArray: Array[String] = Array(histroyElement,month.toString)
        measureLogger(visit, m, "wasElementBeforeEncounterWithinXMonths", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
       // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementBeforeOrEqualInMonths:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function returns patient history records between two periods
    *
    * @param patientHistoryRDD patient history RDD
    * @param m                 start date of the patient history
    * @return patient history between two period e.g.
    */
  def getPatientHistoryRDDBetweenPeriods(patientHistoryRDD: RDD[CassandraRow], m: MeasureProperty, historyElements: String*): RDD[CassandraRow] = {
    //var elements: List[String] = historyElements.toList
//    val startDate = m.quarterStartDate
//    val endDate = m.quarterEndDate
    val historyRDD = patientHistoryRDD.filter(hvisit => (hvisit.getDateTime(2).isAfter(m.quarterStartDate) ||
      hvisit.getDateTime(2).isEqual(m.quarterStartDate)) && (hvisit.getDateTime(2).isBefore(m.quarterEndDate)
      || hvisit.getDateTime(2).isEqual(m.quarterEndDate))
      && historyElements.contains(hvisit.getString(1))

    )
    historyRDD
  }

  /**
    *
    * @param visit
    * @param m
    * @param currentElementDate
    * @param historyElementDate
    * @param patientHistoryList
    * @param historyElementList
    * @return
    */


  def wasInterventionPerformedStartAfterEndOfProcedurePerformedSatisfiedAll(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, historyElementDate: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElementList: Seq[String]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         x.getString(1).equalsIgnoreCase(historyElementDate)
          && x.getDate(2).before(visit.getDate(currentElementDate))

          && historyElementList.forall(y => x.getString(1).equalsIgnoreCase(y))
        )
      }
      val argsArray: Array[String] = Array(currentElementDate,historyElementDate)
      measureLogger(visit, m, "wasInterventionPerformedStartAfterEndOfProcedurePerformedSatisfiedAll", currentElementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  def wasTwoElementEqualBeforeEncounterWithinXHours(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String, historyElementResult: String, hours: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val lowerDate = visit.getDateTime(currentElement + "_date").minusHours(hours)
    val higherDate = visit.getDateTime(currentElement + "_date")
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>

       x.getString(1).equalsIgnoreCase(historyElement)


            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

            && patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(y => !x.isNullAt(2)
           && y.getString(1).equalsIgnoreCase(historyElementResult)

            && x.getDate(2).equals(y.getDate(2))
          )


        )
      }
      val argsArray: Array[String] = Array(historyElement, historyElement,hours.toString)
      measureLogger(visit, m, "wasTwoElementEqualBeforeEncounterWithinXHours", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * This function checks if Element is before X days greater of an element.
    *
    * @param visit              current visit of the patient.
    * @param m                  Measure property of the Measure
    * @param CurrentElement     Element that has to be verified for procedure.
    * @param histElement        History element with that current element has to be compared.
    * @param noOfDays           Number of days that will go back in history
    * @param patientHistoryList patient history list
    * @return
    */
  def wasElementBeforeXDaysGreaterofElement(visit: CassandraRow, m: MeasureProperty, CurrentElement: String, histElement: String, noOfDays: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val CurrentElementDate = CurrentElement + "_date"
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvist =>
          histvist.getString(1).equalsIgnoreCase(histElement)
            && !visit.isNullAt(CurrentElement)
            &&
            (
              histvist.getDateTime(2).isBefore(visit.getDateTime(CurrentElementDate).minusDays(noOfDays))
                | histvist.getDateTime(2).isEqual(visit.getDateTime(CurrentElementDate).minusDays(noOfDays))
              )

        )
      }
      val argsArray: Array[String] = Array(CurrentElement, noOfDays.toString, histElement)
      measureLogger(visit, m, "wasElementBeforeXDaysGreaterofElement", CurrentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * This function verifies the element is before X weeks another element.
    *
    * @param visit              current visit of the patient
    * @param m                  Measure property of the measure
    * @param element            current element whose date has to be compared with history date element.
    * @param historyElement     History Element
    * @param weeks              Number of weeks that has to be subtracted from current element date.
    * @param patientHistoryList Paitent History list
    * @return It will return true if one element is before X weeks of another element.
    */
  def wasElementBeforeElementWithInXWeeks(visit: CassandraRow, m: MeasureProperty, element: String, historyElement: String, weeks: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementDate = element + "_date"
    val lowerDate = visit.getDateTime(elementDate).minusWeeks(weeks)
    val higherDate = visit.getDateTime(elementDate)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equalsIgnoreCase(historyElement)
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
        )
      }
      val argsArray: Array[String] = Array(element,historyElement, weeks.toString, element)
      measureLogger(visit, m, "wasElementBeforeElementWithInXWeeks", element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist


  }

  /**
    *
    * @param r                  patient current visit
    * @param m                  measure property
    * @param elementName        get element check between
    * @param calenderUnit             minus years in in element
    * @param patientHistoryList get patient history list
    * @return it return of Element before end of X in years
    */

  def wasElementBeforeStartDateInXPeriod(r: CassandraRow, m: MeasureProperty, elementName: String, calenderUnit: String, calenderInterval:Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val higherDate = m.quarterStartDate
    val lowerDate = lowerCalenderDate(m.quarterStartDate,calenderUnit,calenderInterval)

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(r.getString("patientuid"))).exists(x =>

         x.getString(1).equals(r.getString(elementName))

            &&checkDateInDateRange(x.getDateTime(2),lowerDate,higherDate,"ge","le")

        )
      }
      val argsArray: Array[String] = Array(elementName, calenderUnit,calenderInterval.toString)
      measureLogger(r, m, "wasElementBeforeStartDateInXPeriod", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    *
    * @param visit              current row
    * @param m                  measure property
    * @param element            element to be checked
    * @param days               days
    * @param patientHistoryList patient history list
    * @return returns true if current element was previously diagnosed within x days from current diagnosis
    */
  def wasCurrentElementDiagnosisPreviouslyDiagniosedWithinXDays(visit: CassandraRow, m: MeasureProperty, element: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           element.equalsIgnoreCase(x.getString(1))
            && isDateBetween(x.getDateTime(2), visit.getDateTime(element + "_date").minusDays(days), visit.getDateTime(element + "_date"))

        )

        val argsArray: Array[String] = Array(element,days.toString)
        measureLogger(visit, m, "wasCurrentElementDiagnosisPreviouslyDiagniosedWithinXDays", element, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasCurrentElementDiagnosisPreviouslyDiagniosedWithinXDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit              current row
    * @param m                  measure property
    * @param element            element from current row
    * @param histroyElement     element to be checked in history
    * @param patientHistoryList patient history list
    * @return returns true if history element exists before current element
    */
  def wasInterventionPerfomedBeforeStartOfSurgery(visit: CassandraRow, m: MeasureProperty, element: String, histroyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          histroyElement.equalsIgnoreCase(x.getString(1))
            && (x.getDateTime(2).isBefore(visit.getDateTime(element + "_date"))
            || x.getDateTime(2).isEqual(visit.getDateTime(element + "_date")))
        )
        val argsArray: Array[String] = Array(element,histroyElement)
        measureLogger(visit, m, "wasInterventionPerfomedBeforeStartOfSurgery", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasInterventionPerfomedBeforeStartOfSurgery:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * //PARENT FUNCTION
    *
    * @param visit              cassandra row
    * @param m                  measure property
    * @param historyElement     element to be checked in X days from element
    * @param currentElement     element from which Future element would be checked
    * @param days               number of days
    * @param patientHistoryList patient history list
    * @return returns true if Future element has happened in x days from element
    */


  def wasElementAfterElementWithinXDaysEyes(visit: CassandraRow, m: MeasureProperty, historyElement: String, currentElement: String, currentEyeElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]], historyEyeElement: String): Boolean = {
    var isExist = false

    val eyeCondCriterias1 = Array(3, 4)
    val eyeCondCriterias2 = Array(1, 2, 3, 4)

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>

          !x.isNullAt(3)

            && x.getString(1).equalsIgnoreCase(historyElement)

            && isDateBetween(x.getDateTime(2), visit.getDateTime(currentElement + "_date"), visit.getDateTime(currentElement + "_date").plusDays(days))


            && (


            (eyeCondCriterias1.contains(x.getString(3)) && eyeCondCriterias2.contains(currentEyeElement))
              ||
              (eyeCondCriterias2.contains(x.getString(3)) && eyeCondCriterias1.contains(currentEyeElement))
              ||
              (x.isNullAt(2))
              ||
              (currentEyeElement == null)
            ))


      }
      val argsArray: Array[String] = Array(historyElement, days.toString, currentElement,currentEyeElement)
      measureLogger(visit, m, "wasElementAfterElementWithinXDays", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementAfterElementWithinXDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /** PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param currentEyeElement  element name whose date will be checked
    * @param patientHistoryList list of patient history
    * @return true if element is already present before another element
    */
  def checkEyeElementBeforeDiagnosisEyesElement(visit: CassandraRow, m: MeasureProperty, currentEyeElement: String, patientHistoryList: Broadcast[List[CassandraRow]], historyElement: String): Boolean = {
    val eyeCondCriterias1 = Array(3, 4)
    val eyeCondCriterias2 = Array(1, 2, 3, 4)
    var isExist = false
    val historyElementDate = historyElement + "_date"
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         x.getString(1).equalsIgnoreCase(historyElement)
          && x.getDate(2).before(visit.getDate(historyElementDate))
          &&
          (
            (eyeCondCriterias1.contains(x.getString(3)) && eyeCondCriterias2.contains(currentEyeElement))
              || (eyeCondCriterias2.contains(x.getString(3)) && eyeCondCriterias1.contains(currentEyeElement))
              || x.isNullAt(3)
              || (currentEyeElement == null)
            )
        )
      }
      val argsArray: Array[String] = Array(currentEyeElement,historyElement)
      measureLogger(visit, m, "checkEyeElementBeforeDiagnosisEyesElement", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * This function verifies element is  X hours before Emergency visit.
    *
    * @param visit              Current visit of the patient.
    * @param m                  Measure Property of the measure.
    * @param histElement        Element that has to be verified in history.
    * @param edvisitArrivalDate Edvisit Arrival Date of the patient.
    * @param crtclDate          Critical Care visit Date of the patient.
    * @return It will return true if element is before X hours or concurrent with edvisitArrivalDate or crtclDate else false
    */
  def wasElementXhoursBeforeOrConcurrentEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, histElement: String, hours: Int, edvisitArrivalDate: String, crtclDate: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {

      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>

            histvisit.getString(1).equalsIgnoreCase(histElement)
            &&
            (
              !visit.isNullAt(crtclDate) && !visit.isNullAt(edvisitArrivalDate) &&
                (
                  (histvisit.getDateTime(2).isBefore(visit.getDateTime(edvisitArrivalDate)) && histvisit.getDateTime(2).isAfter(visit.getDateTime(edvisitArrivalDate).minusHours(hours)))
                    ||
                    (histvisit.getDateTime(2).equals(visit.getDateTime(edvisitArrivalDate).minusHours(hours)) || histvisit.getDateTime(2).isEqual(visit.getDateTime(edvisitArrivalDate)))
                  )
                ||
                (
                  (histvisit.getDateTime(2).isBefore(visit.getDateTime(crtclDate)) && histvisit.getDateTime(2).isAfter(visit.getDateTime(crtclDate).minusHours(hours)))
                    ||
                    (histvisit.getDateTime(2).equals(visit.getDateTime(crtclDate).minusHours(hours)) || histvisit.getDateTime(2).isEqual(visit.getDateTime(crtclDate)))
                  )
              )
        )


        val argsArray: Array[String] = Array(histElement, hours.toString, edvisitArrivalDate, crtclDate)
        measureLogger(visit, m, "wasElementXhoursBeforeOrConcurrentEDOrCCEncounter", histElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * This function verifies if patient is encountered X hours before emergency visit.
    *
    * @param visit              Current visit of the patient.
    * @param m                  Measure Property of the measure.
    * @param histElement        Element that has to be verified in history
    * @param edvisitArrivalDate Edvisit Arrival Date of the patient.
    * @param crtclDate          Critical Care visit Date of the patient.
    * @param patientHistoryList patient history list of the patient
    * @return It will return true if the patient is encountered x hours before emergency visit else false
    */
  def wasElementXhoursBeforeOfEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, histElement: String, hours: Int, edvisitArrivalDate: String, crtclDate: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {

      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>

            histvisit.getString(1).equalsIgnoreCase(histElement)
            &&
            (
              !visit.isNullAt(crtclDate) && !visit.isNullAt(edvisitArrivalDate) &&
                (
                  histvisit.getDateTime(2).isBefore(visit.getDateTime(edvisitArrivalDate).minusHours(hours))
                    ||
                    histvisit.getDateTime(2).equals(visit.getDateTime(edvisitArrivalDate).minusHours(hours))
                  )
                ||
                (
                  histvisit.getDateTime(2).isBefore(visit.getDateTime(crtclDate))
                    ||
                    histvisit.getDateTime(2).equals(visit.getDateTime(crtclDate).minusHours(hours))
                  )
              )
        )


        val argsArray: Array[String] = Array(histElement, hours.toString, edvisitArrivalDate, crtclDate)
        measureLogger(visit, m, "wasElementXhoursBeforeOfEDOrCCEncounter", histElement, isExist, argsArray)
      }
    }

    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This Function verifies if procedure is performed before emergency visit
    *
    * @param visit              Current visit of the patient.
    * @param m                  Measure Property of the measure.
    * @param histElement        Element that has to be verified in history.
    * @param edvisitArrivalDate Edvisit Arrival Date of the patient.
    * @param crtclDate          Critical Care visit Date of the patient.
    * @param patientHistoryList patient history list of the patient
    * @return
    */
  def wasProcedurePerformedBeforeEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, histElement: String, edvisitArrivalDate: String, crtclDate: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = true

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>

            histvisit.getString(1).equalsIgnoreCase(histElement)
            &&
            (
              !visit.isNullAt(edvisitArrivalDate) && !visit.isNullAt(crtclDate)
                &&
                (histvisit.getDateTime(2).isBefore(visit.getDateTime(edvisitArrivalDate)) || histvisit.getDateTime(2).isEqual(visit.getDateTime(edvisitArrivalDate)))
                ||
                (histvisit.getDateTime(2).isBefore(visit.getDateTime(crtclDate)) || histvisit.getDateTime(2).isEqual(visit.getDateTime(crtclDate)))
              )
        )
        val argsArray: Array[String] = Array(histElement, edvisitArrivalDate, crtclDate)
        measureLogger(visit, m, "wasProcedurePerformedBeforeEDOrCCEncounter", histElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * This function verifies the result of the patient.
    *
    * @param visit                Current visit of the patient.
    * @param m                    Measure Property of the measure.
    * @param Element              Element whose result is to be verified
    * @param edvisitArrivalDate   Edvisit Arrival Date of the patient.
    * @param edvisitDepartureDate EdVisit Departure Date of the patient.
    * @param crtclDate            Critical Care visit Date of the patient.
    * @return It will return true if the GCS value is less than required value else false
    */
  def isresultDuringEDorCCGreaterOrLessThanX(visit: CassandraRow, m: MeasureProperty, Element: String, value: Double, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String, compareflag: Boolean): Boolean = {
    var isExist = false
    val ElementDate: String = Element + "_date"
    try {

      isExist = (
        (checkElementPresent(visit, m, Element) &&
          (
            isDateInBetween(visit, m, ElementDate, edvisitArrivalDate, edvisitDepartureDate)
              ||
              isDateTimeEqual(visit, m, ElementDate, crtclDate)
            )
          )
          &&
          (
            !visit.isNullAt(Element) &&
              (if (compareflag) (visit.getFloat(Element) > value) else (visit.getFloat(Element) < value))
            )
        )
      val argsArray: Array[String] = Array(Element, value.toString,edvisitArrivalDate,edvisitDepartureDate,crtclDate)
      measureLogger(visit, m, "isresultDuringEDorCCGreaterThanX", Element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /** PARENT function
    * G
    *
    * @param visit              cassendra row
    * @param m                  measure property
    * @param elementName        get history element
    * @param HistoryElementName historyElementName
    * @param patientHistoryList get history List
    * @return
    */
  def checkElementAfterElementBeforeEndDate(visit: CassandraRow, m: MeasureProperty, elementName: String, HistoryElementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    val elementNameDate = elementName + "_date"
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

        var endDate = m.quarterEndDate
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
        x.getString(1).equalsIgnoreCase(HistoryElementName) &&
          ((x.getDateTime(2).isAfter(visit.getDateTime(elementNameDate)) && x.getDateTime(2).isBefore(endDate)) ||
            x.getDateTime(2).isEqual(visit.getDateTime(elementNameDate)) || x.getDateTime(2).isEqual(endDate))
        )
      }
      val argsArray: Array[String] = Array(elementName,HistoryElementName)
      measureLogger(visit, m, "checkElementAfterElementBeforeEndDate", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementAfterElementBeforeEndDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  def wasTwoElementPresentAfterCurrentElement(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String, historyElementResult: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
             x.getString(1).equalsIgnoreCase(historyElement)
            && x.getDateTime(2).isBefore(visit.getDateTime(currentElement))
            && patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(y => !y.isNullAt(2)
            && y.getString(1).equalsIgnoreCase(historyElementResult)
            && x.getDate(2).equals(y.getDate(2))
          )


        )
      }
      val argsArray: Array[String] = Array(historyElement, historyElement)
      measureLogger(visit, m, "wasTwoElementPresentAfterCurrentElement", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  def getEncounterCount(visit: CassandraRow, m: MeasureProperty, count: Int, greaterFlag: Boolean, countElementList: Array[(String, String, Int)]): Boolean = {

    greaterFlag match {
      case true => countElementList.exists(r => r._1.equalsIgnoreCase(visit.getString("patientuid")) && r._3 >= count)
      case false => countElementList.exists(r => r._1.equalsIgnoreCase(visit.getString("patientuid")) && r._3 == count)
    }
  }


  /**
    * This function verifies the Intervention value is greater or Equal before Procedure peformed.
    *
    * @param visit              Current visit of the patient.
    * @param m                  Measure Property of the measure.
    * @param currentElement     current Element
    * @param histElement        history element
    * @param flag               Flage based on requirement ge,gt,lt,le,eq
    * @param value              value that has to be verified
    * @param patientHistoryList patient history list
    * @return
    */
  def wasInterventionValueGreaterOrEqualBeforeProcedurePerformed(visit: CassandraRow, m: MeasureProperty, currentElement: String, histElement: String, flag: String, value: Double, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val currentElementDate = currentElement + "_date"
    try {

      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>
          isNotNullInhistory(histvisit,  "elementvalue") &&
           histvisit.getString(1).equalsIgnoreCase(histElement)
            &&
            (
              histvisit.getDateTime(2).isBefore(visit.getDateTime(currentElementDate))
                ||
                histvisit.getDateTime(2).isEqual(visit.getDateTime(currentElementDate))
              )
            &&
            compareValueStatus(histvisit.getDouble(3), flag, value)

        )


        val argsArray: Array[String] = Array(histElement, currentElement, value.toString,flag)
        measureLogger(visit, m, "wasInterventionValueGreaterOrEqualBeforeProcedurePerformed", histElement, isExist, argsArray)
      }
    }

    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist


  }

  /**
    * //PARENT FUNCTION
    *
    * @param visit              cassandra row
    * @param m                  measure property
    * @param historyElement     element to be checked in X hours from element
    * @param hours              number of days
    * @param patientHistoryList patient history list
    * @param currentElement     element from which Future element would be checked
    * @return returns true if Future element has happened in x hours from element
    */


  def wasElementBeforeElementWithinXHoursCurrentElementList(visit: CassandraRow, m: MeasureProperty, historyElement: String, hours: Int, patientHistoryList: Broadcast[List[CassandraRow]], currentElement: Seq[String]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
               x.getString(1).equalsIgnoreCase(historyElement) &&
            currentElement.exists(y => x.getString(1).equalsIgnoreCase(y)
             && isDateBetween(x.getDateTime(2), (visit.getDateTime(y + "_date").minus(hours)), (visit.getDateTime(y + "_date"))))
        )
        val argsArray: Array[String] = Array(currentElement.toString(),historyElement)
        measureLogger(visit, m, "wasElementBeforeElementWithinXHoursCurrentElementList", historyElement, isExist, argsArray)
      }

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementAfterElementWithinXDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    * This function checks if the data type starts after end of within X days(upper boundary date excluded)
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param currentElementName element name
    * @param historyElementName history element name
    * @param reasonElement reason element to be checked
    * @param days               no of days to be checked after
    * @param patientHistoryList patients history list
    * @return return true if  the data type starts after end of within X days else returns false
    */
  def wasDataTypeStartAfterEndOfXDaysWithReason(visit: CassandraRow, m: MeasureProperty, currentElementName: String, historyElementName: String,reasonElement:String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementDate = currentElementName + "_date"
    //val end_Date = new DateTime(m.quarterEndDate)
    val lowerDate = visit.getDateTime(elementDate)
    val higherDate = visit.getDateTime(elementDate).plusDays(days)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hVisit =>
            hVisit.getString(1).equalsIgnoreCase(historyElementName)
            && ((hVisit.getDateTime(2).isAfter(lowerDate) ||
            hVisit.getDateTime(2).isEqual(lowerDate))
            && hVisit.getDateTime(2).isBefore(higherDate)
            )
            && patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hReasonVist =>
            hReasonVist.getString(1).equalsIgnoreCase(reasonElement)
              && hVisit.getDateTime(2).isEqual(hReasonVist.getDateTime(2))
          )
        )

      }
      val argsArray: Array[String] = Array(historyElementName, days.toString, currentElementName)
      measureLogger(visit, m, "wasDataTypeStartAfterEndOfXDaysWithReason", elementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasDataTypeStartAfterEndOfXDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    * This function verifies if the communication is done after procedure within X months
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param elementName        Procedure element name
    * @param elementDate        Procedure element date
    * @param months             no of months to be looked after
    * @param patientHistoryList patient history list
    * @param historyElement     Communication element name
    * @return returns true if the communication is done after procedure within X months else returns false
    */
  def wasCommunicationDoneAfterProcedureWithinXMonths(visit: CassandraRow, m: MeasureProperty, elementName: String, elementDate: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]], historyElement: String): Boolean = {
    var isExist = false

    val elementsNotNull = checkNotNull(visit, elementName, elementDate)
    if (elementsNotNull) {
      try {

        if (patientHistoryList.value.nonEmpty) {
          isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
            .exists(hVisit =>  historyElement.equalsIgnoreCase(hVisit.getString(1))
            && isDateBetween(hVisit.getDateTime(2), visit.getDateTime(elementDate), visit.getDateTime(elementDate).plusMonths(months))
          )
        }
        val argsArray: Array[String] = Array(historyElement, elementName, months.toString)
        measureLogger(visit, m, "wasCommunicationDoneAfterProcedureWithinXMonths", historyElement, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasCommunicationDoneAfterProcedureWithinXMonths:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)

        }
      }
    }
    isExist
  }

  /**
    * This function checks if the event starts after X periods starts of measurement period
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param elementName        element name
    * @param calenderUnit valid calender units are (YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param calenderInterval               no of calender interval to be for calender unit
    * @param timeCompareOperator valida operators are {LESS,GREATER,LESS_EQUAL,GREATER_EQUAL,EQUAL}
    * @param patientHistoryList patient history list
    * @return returns true if  the event starts after X period starts of measurement period else returns false
    */
  def isEventStartsAfterStartMeasurementPeriodWithinXPeriod(visit: CassandraRow, m: MeasureProperty, elementName: String,calenderUnit:String, calenderInterval: Int,timeCompareOperator:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val lowerDate = m.quarterStartDate
    val higherDate = higherCalenderDate(lowerDate,calenderUnit,calenderInterval)

      try {

        if (patientHistoryList.value.nonEmpty) {
          isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
            .exists(hVisit =>  hVisit.getString(1).equalsIgnoreCase(elementName)
            && compareTimeOperator(hVisit.getDateTime(2), lowerDate, higherDate,timeCompareOperator)
          )
        }
        val argsArray: Array[String] = Array(elementName, calenderUnit,calenderInterval.toString)
        measureLogger(visit, m, "isEventStartsAfterStartMeasurementPeriodWithinXPeriod", elementName, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isEventStartsAfterStartMeasurementPeriodWithinXPeriod:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)

        }
      }

    isExist
  }




  /**
    * //PARENT FUNCTION
    *
    * @param visit              cassandra row
    * @param m                  measure property
    * @param historyElement     element to be checked in X days from element
    * @param days               number of days
    * @param patientHistoryList patient history list
    * @return returns true if Future element has happened in x days from element
    */


  def wasElementAfterEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, historyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equalsIgnoreCase(historyElement)
           && isDateBetween(x.getDateTime(2), visit.getDateTime("encounterdate"), visit.getDateTime("encounterdate").plusDays(days))
        )

      }
      val argsArray: Array[String] = Array(historyElement, "encounterdate", days.toString)
      measureLogger(visit, m, "wasElementAfterEncounterWithinXDays", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementAfterElementWithinXDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * //PARENT FUNCTION
    *
    * @param visit              cassandra row
    * @param m                  measure property
    * @param historyElement     element to be checked in X days from element
    * @param days               number of days
    * @param patientHistoryList patient history list
    * @return returns true if Future element has happened in x days from element
    */


  def wasElementBeforeEncounterWithinXDays(visit: CassandraRow, m: MeasureProperty, historyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getString(1).equalsIgnoreCase(historyElement)
          && isDateBetween(x.getDateTime(2), visit.getDateTime("encounterdate").minusDays(days), visit.getDateTime("encounterdate"))
        )

      }
      val argsArray: Array[String] = Array(historyElement, "encounterdate", days.toString)
      measureLogger(visit, m, "wasElementBeforeEncounterWithinXDays", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementAfterElementWithinXDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * This function verifies the Diagnosis is before encounter and diagnostic study performed with result on diagnosis.
    *
    * @param visit              current visit of the patient.
    * @param m                  Measure Property of the measure.
    * @param diagnosisElement   Diagnosis Element that has to be verified during Emergency visit.
    * @param DiagnosticElement  Diagnostic Study element
    * @param resultElement      result element
    * @param patientHistoryList Patient History list
    * @return It will return true whose condition element is concurent with diagnosis element else false.
    */

  def wasDiagnosticStudyWithResultAfterDiagnosis(visit: CassandraRow, m: MeasureProperty, diagnosisElement: String, DiagnosticElement: String, resultElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).filter(x =>
          x.getString(1).equalsIgnoreCase(diagnosisElement)
          && (
          x.getDateTime(2).isBefore(visit.getDateTime("encounterdate"))
            ||
            x.getDateTime(2).isEqual(visit.getDateTime("encounterdate"))
          )
        ).exists(x => patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(x.getString("patientuid"))).filter(y =>
         y.getString(1).equalsIgnoreCase(DiagnosticElement)
            &&
            (
              y.getDateTime(2).isAfter(x.getDateTime(2))
                ||
                y.getDateTime(2).isEqual(x.getDateTime(2)))
        )
          .exists(z => patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(z.getString("patientuid"))).exists(a =>
               a.getString(1).equalsIgnoreCase(resultElement)
              && a.getDateTime(2).isEqual(z.getDateTime(2))
          )
          )
        )

      }
      val argsArray: Array[String] = Array(DiagnosticElement, resultElement, diagnosisElement)
      measureLogger(visit, m, "wasDiagnosticStudyWithResultAfterDiagnosis", DiagnosticElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist
  }


  /**
    * This function checks if the data type performed starts before end of measurement period and element result compare with specified value condition
    *
    * @param currentVisit current patient visit
    * @param m            measure property
    * @param element      element name
    * @param elementValue element value
    * @param compareFlag  compare flag (valid flags [lt,gt,le,ge,eq])
    * @param patientHistoryList
    * @return returns true if  the data type performed starts before end of measurement period and element result compare with specified value condition else returns false
    */
  def dataTypePerformedStartsBeforeEndOfMeasurementPeriodWithValue(currentVisit: CassandraRow, m: MeasureProperty, element: String, elementValue: Double, compareFlag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    if (patientHistoryList.value.nonEmpty) {
      try {
//        val endDate = m.quarterEndDate
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(currentVisit.getString("patientuid"))).exists(histVisit => (!histVisit.isNullAt(3) &&
           (histVisit.getString(1).equalsIgnoreCase(element) && histVisit.getDateTime(2).isBefore(m.quarterEndDate))
          && compareValueStatus(histVisit.getDouble(3), compareFlag, elementValue))
        )

        val argsArray: Array[String] = Array(element, elementValue.toString,compareFlag)
        measureLogger(currentVisit, m, "dataTypePerformedStartsBeforeEndOfMeasurementPeriodWithValue", element, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:dataTypePerformedStartsBeforeEndOfMeasurementPeriodWithValue:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist
  }

  /**
    * This function verifies the element is after another element plus number days in history.
    *
    * @param visit              current visit of the patient.
    * @param m                  Measure Property of the measure.
    * @param histelement        first history element
    * @param histelement2       second history element
    * @param NoOfDays           number of days that has to be added
    * @param patientHistoryList patient history list
    * @return it will return true if element is after another element plus number of days else false
    */
  def wasElementAfterElementInXDays(visit: CassandraRow, m: MeasureProperty, histelement: String, histelement2: String, NoOfDays: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
        x.getString(1).equalsIgnoreCase(histelement)
        &&
        patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
          y.getString(1).equalsIgnoreCase(histelement2) &&
            (
              x.getDateTime(2).isEqual(y.getDateTime(2).plusDays(NoOfDays))
                ||
                x.getDateTime(2).isAfter(y.getDateTime(2).plusDays(NoOfDays))
              )


        )
      )
      val argsArray: Array[String] = Array(histelement, NoOfDays.toString, histelement2)
      measureLogger(visit, m, "wasElementAfterElementInXDays", "EmergencyVisit", isExist, argsArray)
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    * This function verifies the element is before start Date.
    *
    * @param visit              Current visit of the patient.
    * @param m                  Measure Property of the measure
    * @param histElement        element that has to be verified in history
    * @param patientHistoryList patient history list
    * @return it will return true if element is before start date else false
    */
  def wasElementBeforeOrEqualStartDate(visit: CassandraRow, m: MeasureProperty, histElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val startDate = m.quarterStartDate

    try {

      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>
            histvisit.getString(1).equalsIgnoreCase(histElement)
            &&
            (
              histvisit.getDateTime(2).isBefore(m.quarterStartDate)
                ||
                histvisit.getDateTime(2).isEqual(m.quarterStartDate)
              )


        )
        val argsArray: Array[String] = Array(histElement)
        measureLogger(visit, m, "wasElementBeforeOrEqualStartDate", histElement, isExist, argsArray)
      }
    }

    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function verifies the Intervention is after medication and Intervention result on medication.
    *
    * @param visit               current visit of the patient.
    * @param m                   Measure Property of the measure.
    * @param InterventionElement Diagnosis Element that has to be verified during Emergency visit.
    * @param MedicationElement   Diagnostic Study element
    * @param resultElement       result element
    * @param patientHistoryList  Patient History list
    * @return It will return true whose condition element is concurent with Intervention element else false.
    */

  def wasInterverntionStudyWithResultAfterMedication(visit: CassandraRow, m: MeasureProperty, InterventionElement: String, MedicationElement: String, resultElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(x =>
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(InterventionElement)

        ).exists(x => patientHistoryList.value.filter(y =>
          y.getString("patientuid").equalsIgnoreCase(x.getString("patientuid"))
            && y.getString(1).equalsIgnoreCase(MedicationElement)
            &&
            x.getDateTime(2).isAfter(y.getDateTime(2))
        )
          .exists(z => patientHistoryList.value.exists(a =>
            a.getString("patientuid").equalsIgnoreCase(x.getString("patientuid"))
              && a.getString(1).equalsIgnoreCase(resultElement)
              && a.getDateTime(2).isEqual(z.getDateTime(2))
          )
          )
        )

      }
      val argsArray: Array[String] = Array(InterventionElement, resultElement, MedicationElement)
      measureLogger(visit, m, "wasInterverntionStudyWithResultAfterMedication", InterventionElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist
  }

  /**
    * This function verifies the physical Exam performed after start of measurement period and before encounter Date.
    *
    * @param visit              Current visit of the patient.
    * @param m                  measure properties of the measure
    * @param historyElement     element that has to be verifies in history
    * @param patientHistoryList patient history list.
    * @return It will return true if physical exam performed after start of the measurement period till encounter.
    */
  def wasPhysicalExamPerformedBeforeEncounter(visit: CassandraRow, m: MeasureProperty, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val startDate = m.quarterStartDate

    try {

      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>

            histvisit.getString(1).equalsIgnoreCase(historyElement)
            &&
            (
              (histvisit.getDateTime(2).isAfter(m.quarterStartDate) && histvisit.getDateTime(2).isBefore(visit.getDateTime("encounterdate")))
                ||
                histvisit.getDateTime(2).isEqual(m.quarterStartDate)
                ||
                histvisit.getDateTime(2).isEqual(visit.getDateTime("encounterdate")))


        )
        val argsArray: Array[String] = Array(historyElement)
        measureLogger(visit, m, "wasPhysicalExamPerformedBeforeEncounter", historyElement, isExist, argsArray)
      }
    }

    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    *
    *
    *
    * @param patientHistoryMostRecentList
    * @param patientHistoryList
    * @param days
    * @return
    */

  def mostRecentBeforeInXDays(patientHistoryMostRecentList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[RDD[CassandraRow]], days: Int): List[CassandraRow] = {
    {
      val rc = patientHistoryList.value.filter(r =>

        patientHistoryMostRecentList.value.exists(x =>

          r.getString("patientuid").equals(x.getString("patientuid"))

            && r.getString(1).equalsIgnoreCase(x.getString(1))

            && r.getDateTime(2).isBefore(x.getDateTime(2).minusDays(days))))

      val listOfElement = patientHistoryMostRecentList.value.map(r => r.getString(1))

      mostRecentPatientListSeq(rc: RDD[CassandraRow], listOfElement)

    }

  }

  /**
    * PARENT function
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param patientHistoryList get patient history list
    * @return it return if
    */

  def wasAssessmentPerformedValueDuringMostRecent(visit: CassandraRow, m: MeasureProperty, historyelement: String, value: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]], mostRecentOrSecondMostHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val historyelementDate = historyelement + "_date"

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(hvisit => !hvisit.isNullAt(3) &&
             hvisit.getString(1).equalsIgnoreCase(historyelement) &&

            mostRecentOrSecondMostHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
              .exists(msvisit =>
              !msvisit.isNullAt(2)

                && msvisit.getString(1).equalsIgnoreCase(historyelement)

                && msvisit.getString(2).equalsIgnoreCase(historyelementDate)

                &&

                compareValueStatus(hvisit.getDouble(3), flag, value))


        )

      }
      val argsArray: Array[String] = Array(historyelement.toString, value.toString,flag)
      measureLogger(visit, m, "wasAssessmentPerformedValueDuringMostRecent", historyelementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    * PARENT function
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param patientHistoryList get patient history list
    * @return it return if
    */

  def wasAssessmentPerformedWithInRangeValueDuringMostRecent(visit: CassandraRow, m: MeasureProperty, historyelement: String, value1: Double, value2: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]], mostRecentOrSecondMostHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val historyelementDate = historyelement + "_date"

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>

          !hvisit.isNullAt(3)
            && hvisit.getString(1).equalsIgnoreCase(historyelement) &&
            mostRecentOrSecondMostHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(msvisit =>
              !msvisit.isNullAt(2)
                && msvisit.getString(1).equalsIgnoreCase(historyelement)

                && msvisit.getString(2).equalsIgnoreCase(historyelementDate)

                &&

                compareStatusBetweenValue(hvisit.getDouble(3), flag, value1, value2)
            )

        )

      }
      val argsArray: Array[String] = Array(historyelement, value1.toString, value2.toString,flag)
      measureLogger(visit, m, "wasAssessmentPerformedWithInRangeValueDuringMostRecent", historyelementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * PARENT function
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param patientHistoryList get patient history list
    * @return it return if
    */

  def wasAssessmentPerformedMostRecent(visit: CassandraRow, m: MeasureProperty, historyelement: String, patientHistoryList: Broadcast[List[CassandraRow]], mostRecentOrSecondMostHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val historyelementDate = historyelement + "_date"

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>

          !hvisit.isNullAt(2)
             && hvisit.getString(1).equalsIgnoreCase(historyelement) &&
            mostRecentOrSecondMostHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(msvisit =>
              !msvisit.isNullAt(2)
               && msvisit.getString(1).equalsIgnoreCase(historyelement)
                && msvisit.getString(2).equalsIgnoreCase(historyelementDate)

            )

        )

      }
      val argsArray: Array[String] = Array(historyelement)
      measureLogger(visit, m, "wasAssessmentPerformedMostRecent", historyelementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    *
    * @param visit                             current patient Visit
    * @param m                                 measure property
    * @param historyElement                    history element
    * @param days                              minus days from history date
    * @param patientHistoryList                patinet history list
    * @param mostRecentOrSecondMostHistoryList mostRecent or secondMostRecent History list depend on requirement
    * @return if EncounterPerformedInXDaysBeforeMostRecentEncounter
    */

  def isEncounterPerformedInXDaysBeforeMostRecentEncounter(visit: CassandraRow, m: MeasureProperty, historyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]], mostRecentOrSecondMostHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val historyElementDate = historyElement + "_date"

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>
             hvisit.getString(1).equalsIgnoreCase(historyElement) &&
            mostRecentOrSecondMostHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(msvisit =>
                hvisit.getString(1).equalsIgnoreCase(historyElement)
                && (hvisit.getDateTime(2).isBefore(msvisit.getDateTime(2).minusDays(days))
                ||
                hvisit.getDateTime(2).isEqual(msvisit.getDateTime(2).minusDays(days))
                )
            )

        )

      }
      val argsArray: Array[String] = Array(historyElement, days.toString)
      measureLogger(visit, m, "isEncounterPerformedInXDaysBeforeMostRecentEncounter", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * This function verifies the element is before encounter date before X days.
    *
    * @param visit              current visit of the patient
    * @param m                  measure property of the measure.
    * @param historyElement     history element that has to be verifies
    * @param days               number of days that has to be subtracted form encounter date
    * @param patientHistoryList patient history list of the patient
    * @return it will return true if element is X days before encounter date else false
    */
  def wasElementBeforeEncounterWithInXDays(visit: CassandraRow, m: MeasureProperty, historyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    val isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        val isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>

            histvisit.getString(1).equalsIgnoreCase(historyElement)
            &&
            (
              (histvisit.getDateTime(2).isAfter(visit.getDateTime("encounterdate").minusDays(days))
                && histvisit.getDateTime(2).isBefore(visit.getDateTime("encounterdate")))
                ||
                histvisit.getDateTime(2).isEqual(visit.getDateTime("encounterdate").minusDays(days))
              ))

        val argsArray: Array[String] = Array(historyElement, days.toString)
        measureLogger(visit, m, "wasElementBeforeEncounterWithInXDays", historyElement, isExist, argsArray)
      }
    }

    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function verifies the element with Result
    *
    * @param visit              current visit of the patient.
    * @param m                  Measure Property of the measure.
    * @param histElement1       history element 1
    * @param histElement2       result Element
    * @param patientHistoryList Patient History list
    * @return It will return true whose Result  is concurent with history element element else false.
    */

  def wasElementWithResult(visit: CassandraRow, m: MeasureProperty, histElement1: String, histElement2: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).filter(x =>
       x.getString(1).equalsIgnoreCase(histElement1))
          .exists(x => patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(x.getString("patientuid"))).exists(y =>
         y.getString(1).equalsIgnoreCase(histElement2)
              && y.getDate(2).equals(x.getDate(2))))

      }
      val argsArray: Array[String] = Array(histElement1, histElement2)
      measureLogger(visit, m, "wasElementWithResult", histElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist
  }

  /**
    * This function verifies if encounter is performed after X Days after element.
    *
    * @param visit              current visit of the patient
    * @param m                  Measure Property of the measure.
    * @param historyElement     history element that has to be verifies in history
    * @param days               number of days that has to be added in the element d
    * @param patientHistoryList patient history list
    * @return it will return true if encounter is performed after x days of history element else false
    */

  def wasEncounterAfterXDaysOfElement(visit: CassandraRow, m: MeasureProperty, historyElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>
            histvisit.getString(1).equalsIgnoreCase(historyElement)
            &&
            visit.getDateTime("encounterdate").isAfter(histvisit.getDateTime(2).plusMonths(days))

        )

        val argsArray: Array[String] = Array(days.toString, historyElement)
        measureLogger(visit, m, "wasEncounterAfterXDaysOfElement", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }

    }
    isExist
  }


  /** PARENT function
    * G
    *
    * @param visit              cassendra row
    * @param m                  measure property
    * @param elementName        get history element
    * @param patientHistoryList get history List
    * @return
    */
  def wasElementListPresentDuringMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, patientHistoryList: Broadcast[List[CassandraRow]], elementName: Seq[String]): Boolean = {
    var isExist = false
    val lowerDate = m.quarterStartDate
    val higherDate = m.quarterEndDate
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         elementName.exists(_.equalsIgnoreCase(x.getString(1)))
          && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

        )
      }
      val argsArray: Array[String] = Array(elementName.toString())
      measureLogger(visit, m, "wasElementPresentDuringMeasurementPeriod", elementName.toString(), isExist, argsArray)
    }

    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementDuringMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * PARENT function
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param months             minus days in in element
    * @param patientHistoryList get patient history list
    * @return it return check history element between
    */

  def wasElementAfterStartWithinXMonths(visit: CassandraRow, m: MeasureProperty,  historyElement: String,  months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val lowerDate = m.quarterStartDate
    val higherDate = m.quarterStartDate.plusMonths(months)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equalsIgnoreCase(historyElement)
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

        )
      }
      val argsArray: Array[String] = Array(months.toString, historyElement)
      measureLogger(visit, m, "wasElementAfterStartWithinXMonths", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  def wasElementAfterElementListWithinXMonths(visit: CassandraRow, m: MeasureProperty, historyElement: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]], elementName: Seq[String]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
             x.getString(1).equalsIgnoreCase(historyElement)
            && elementName.exists(r => isDateBetween(x.getDateTime(2), visit.getDateTime(r + "_date"), visit.getDateTime(r + "_date").plusMonths(months)))
        )
      }
      val argsArray: Array[String] = Array(months.toString, historyElement)
      measureLogger(visit, m, "wasElementAfterElementListWithinXMonths", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  def wasElementEqualMostRecentElementDuringMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, historyElement1: String, mostRecentElement: String, patientHistoryList: Broadcast[List[CassandraRow]], mostRecentList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = mostRecentList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
             x.getString(1).equalsIgnoreCase(historyElement1)

            && patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(y => !y.isNullAt(2)
            && y.getString(1).equalsIgnoreCase(mostRecentElement)

            && x.getDate(2).equals(y.getDate(2))
          )


        )
      }
      val argsArray: Array[String] = Array(historyElement1, mostRecentElement)
      measureLogger(visit, m, "wasElementEqualMostRecentElementDuringMeasurementPeriod", mostRecentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    *
    * @param visit current patient visit
    * @param m measurement period
    * @param elementName1 procudere element1
    * @param elementName2 procudere element2
    * @param elementName3 Procedure Result Element One
    * @param months month minus from element
    * @param patientHistoryList Procedure element list
    * @return
    */

  def wasProcedurePerformedwithReasonAndResultBeforeEncounter(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String, elementName3: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>
            hvisit.getString(1).equals(elementName1)
            && isDateBetween(hvisit.getDateTime(2), visit.getDateTime("encounterdate").minusMonths(months), visit.getDateTime("encounterdate"))
            &&
            patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>
                  hvisit.getString(1).equals(elementName2)
                && isDateBetween(hvisit.getDateTime(2), visit.getDateTime("encounterdate").minusMonths(months), visit.getDateTime("encounterdate"))
                &&
                patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit1 =>
                   hvisit.getString(1).equals(elementName3)

                    && isDateBetween(hvisit1.getDateTime(2), visit.getDateTime("encounterdate").minusMonths(months), visit.getDateTime("encounterdate"))

                    && hvisit.getDate(2).equals(hvisit1.getDate(2))
                )))
      }
      val argsArray: Array[String] = Array(elementName1,elementName2,elementName3, months.toString)
      measureLogger(visit, m, "wasProcedurePerformedwithReasonAndResultBeforeEncounter", elementName1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }




  def wasResultElementBetweenEncounterDateWithInXCalender(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,unit:String ,interval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>
           hvisit.getString(1).equals(visit.getString(elementName1))
            && isDateBetween(hvisit.getDateTime(2), lowerCalenderDate(visit.getDateTime("encounterdate"), unit, interval), visit.getDateTime("encounterdate"))
            &&
            patientHistoryList.value.filter(histVisit=>histVisit.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit1 =>
             hvisit.getString(1).equals(visit.getString(elementName2))
                && isDateBetween(hvisit1.getDateTime(2), lowerCalenderDate(visit.getDateTime("encounterdate"), unit, interval), visit.getDateTime("encounterdate"))

                && hvisit.getDate(2).equals(hvisit1.getDate(2))


            ))
      }
      val argsArray: Array[String] = Array(elementName1,elementName2, unit,interval.toString)
      measureLogger(visit, m, "wasResultElementBetweenEncounterDateWithInXCalender", elementName1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * This function verifies the visual Acuity with result after X days of procedure
    *
    * @param visit               current visit of the patient
    * @param m                   Measure property of the measure
    * @param physicalExamElement Physical exam element that has to be verified in history
    * @param procedureElement    procedure element that has to be verified
    * @param resultElement       result element that has to be concurrent with physical exam
    * @param days                number of days that has to be added
    * @param patientHistoryList  patient history list
    * @return it will return true if visual acuity with result after  X days of procedure.
    */
  def wasBestVisualAucityWithResulAfterXDaysProcedure(visit: CassandraRow, m: MeasureProperty, physicalExamElement: String, procedureElement: String, resultElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(x =>  x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(physicalExamElement)

        ).exists(x => patientHistoryList.value.filter(y =>
          y.getString("patientuid").equalsIgnoreCase(x.getString("patientuid"))
            && y.getString(1).equalsIgnoreCase(procedureElement)
            &&
            ((x.getDateTime(2).isAfter(y.getDateTime(2).plusDays(days))
              && x.getDateTime(2).isBefore(y.getDateTime(2))) ||
              x.getDateTime(2).isEqual(y.getDateTime(2).plusDays(days))
              ||
              x.getDateTime(2).isEqual(y.getDateTime(2))
              )
        )
          .exists(z => patientHistoryList.value.exists(a =>
            a.getString("patientuid").equalsIgnoreCase(x.getString("patientuid"))
              && a.getString(1).equalsIgnoreCase(resultElement)
              && a.getDateTime(2).isEqual(z.getDateTime(2))
          )
          )
        )

      }
      val argsArray: Array[String] = Array(physicalExamElement, resultElement, procedureElement,days.toString)
      measureLogger(visit, m, "wasBestVisualAucityAfterXDaysProcedure", physicalExamElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist


  }

  /**
    * This function verifies element is after or concurrent another element
    *
    * @param visit              current visit of the patient
    * @param m                  Measure property of the measure
    * @param Element            element that has to be verifies
    * @param AnotherElement     another element
    * @param patientHistoryList patient history list
    * @return It will return true element after another element else false
    */
  def wasElementAfterOrConcurrentAnotherElement(visit: CassandraRow, m: MeasureProperty, Element: String, AnotherElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(x =>  x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(Element)

        ).exists(x => patientHistoryList.value.exists(y =>
          y.getString("patientuid").equalsIgnoreCase(x.getString("patientuid"))
            && y.getString(1).equalsIgnoreCase(AnotherElement)
            &&
            ((x.getDateTime(2).isAfter(y.getDateTime(2))
              ||
              x.getDateTime(2).isEqual(y.getDateTime(2))
              )
              )
        )
        )
      }
      val argsArray: Array[String] = Array(Element, AnotherElement)
      measureLogger(visit, m, "wasElementAfterOrConcurrentAnotherElement", Element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist
  }



  def wasProcedurePerformedwithReasonAndResultBefore(visit: CassandraRow, m: MeasureProperty,elementName1:String,elementName2:String,elementName3:String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false


//    val startDate = m.quarterStartDate
//    val endDate = m.quarterEndDate

    try {
      if (patientHistoryList.value.nonEmpty) {


        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>
          !hvisit.isNullAt(2)
             && hvisit.getString(1).equals(visit.getString(elementName1))
            && isDateBetween(hvisit.getDateTime(2), m.quarterStartDate, m.quarterEndDate)
            &&
            patientHistoryList.value.exists(hvisit1 =>
             visit.getString("patientuid").equals(hvisit1.getString("patientuid"))
                && hvisit1.getString(1).equals(visit.getString(elementName2))
                &&
                hvisit.getDateTime(2).isEqual(hvisit1.getDateTime(2))
                && isDateBetween(hvisit1.getDateTime(2), m.quarterStartDate, m.quarterEndDate)
                &&
                patientHistoryList.value.exists(hvisit2 =>
                visit.getString("patientuid").equals(hvisit2.getString("patientuid"))

                    && hvisit2.getString(1).equals(visit.getString(elementName3))

                    && isDateBetween(hvisit2.getDateTime(2), m.quarterStartDate, m.quarterEndDate)
                    &&
                    hvisit1.getDateTime(2).isEqual(hvisit2.getDateTime(2))


                )))

        val argsArray: Array[String] = Array(elementName1,elementName2,elementName3, months.toString)
        measureLogger(visit, m, "wasProcedurePerformedwithReasonAndResultBeforeEncounter", elementName1, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }



  /**
    *
    * @param visit              patient current visit
    * @param m                  measure property
    * @param months             minus years in in element
    * @param patientHistoryList get patient history list
    * @return it return of Element before end of X in years
    */

  def wasProcedurePerformedwithResultBefore(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val startDate = m.quarterStartDate
//    val endDate = m.quarterEndDate


    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>
          hvisit.getString(1).equals(visit.getString(elementName1))
            &&
            isDateBetween(hvisit.getDateTime(2), m.quarterStartDate, m.quarterEndDate)
            &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit1 =>
               hvisit.getString(1).equals(visit.getString(elementName2))
                    &&
               isDateBetween(hvisit.getDateTime(2), m.quarterStartDate, m.quarterEndDate)
            ))
      }
      val argsArray: Array[String] = Array(elementName1,elementName2, months.toString)
      measureLogger(visit, m, "wasProcedurePerformedwithResultBefore", elementName1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    * This function verifies the intervention is during diagnosis and intervention result on diagnosis.
    *
    * @param visit               current visit of the patient.
    * @param m                   Measure Property of the measure.
    * @param interventionElement intervention element name to be checked.
    * @param diagnosisElement    diagnostic element name
    * @param resultElement       result element
    * @param patientHistoryList  patient history list
    * @return returns true if condition element is concurrent with intervention element else false.
    */

  def wasInterventionPerformedWithResultDuringDiagnosis(visit: CassandraRow, m: MeasureProperty, interventionElement: String, diagnosisElement: String, resultElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(x =>  x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(interventionElement)

        ).exists(x => patientHistoryList.value.filter(y =>
          y.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
            && y.getString(1).equalsIgnoreCase(diagnosisElement)
            &&
            x.getDateTime(2).isEqual(y.getDateTime(2))
        )
          .exists(z => patientHistoryList.value.exists(a =>
            a.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
              && a.getString(1).equalsIgnoreCase(resultElement)
              && a.getDateTime(2).isEqual(z.getDateTime(2))
          )
          )
        )

      }
      val argsArray: Array[String] = Array(interventionElement, resultElement, diagnosisElement)
      measureLogger(visit, m, "wasInterventionPerformedWithResultDuringDiagnosis", interventionElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist
  }


  /**
    * This function verifies if current element starts after element else returns false
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param currentElement     current element
    * @param historyElement     history element name
    * @param patientHistoryList patient history list
    * @return returns true if  current element starts after element
    */
  def isCurrentElementStartsAfterEndOf(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val currentElementDate = currentElement + "_date"
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(hVist =>
          hVist.getString(1).equalsIgnoreCase(historyElement)
            && visit.getDateTime(currentElementDate).isAfter(hVist.getDateTime(2))
        )

        val argsArray: Array[String] = Array(currentElement, historyElement)
        measureLogger(visit, m, "wasElementStartsAfterEndOf", currentElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function verifies if current element starts after X weeks of element
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param currentElement     current element
    * @param historyElement     history element name
    * @param weeks              no of weeks to be looked after
    * @param patientHistoryList patient history list
    * @return returns true if  current element starts after element  else returns false
    */
  def isCurrentElementStartsAfterEndOfWithinXWeek(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String, weeks: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val currentElementDate = currentElement + "_date"
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(hVist =>
          hVist.getString(1).equalsIgnoreCase(historyElement)
            && ((visit.getDateTime(currentElementDate).isAfter(hVist.getDateTime(2)) || visit.getDateTime(currentElementDate).isEqual(hVist.getDateTime(2)))
            &&
            (visit.getDateTime(currentElementDate).isBefore(hVist.getDateTime(2).plusWeeks(weeks)) || visit.getDateTime(currentElementDate).isEqual(hVist.getDateTime(2).plusWeeks(weeks)))
            )
        )

        val argsArray: Array[String] = Array(currentElement, historyElement,weeks.toString)
       measureLogger(visit, m, "isCurrentElementStartsAfterEndOfWithinXWeek", currentElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  def getBusinessDaysDifference(lowerDate: Date, higherDate: Date): Int = {


    def isBusinessDays(cal: Calendar): Boolean = {

      val HolidayList: Array[String] = Array("2019-01-01", "2019-01-21", "2019-02-18", "2019-05-27", "2019-07-04", "2019-09-02", "2019-10-14", "2019-11-11", "2019-11-28", "2019-12-25")
      if (

        (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)
          ||
          HolidayList.contains(cal.get(Calendar.YEAR) + "-" + cal.get(Calendar.MONTH) + "-" + cal.get(Calendar.DATE))

      ) false else true
    }


    var count = 0
    val cal1 = Calendar.getInstance()
    cal1.setTime(lowerDate)

    val cal2 = Calendar.getInstance()
    cal2.setTime(higherDate)

    while (cal1.before(cal2)) {
      if (isBusinessDays(cal1) && isBusinessDays(cal2)) {
        cal1.add(Calendar.DATE, +1)
        count = count + 1
      }
      cal1.add(Calendar.DATE, +1)
    }

    count

  }


  def wasElementAfterElementWithinXBusinessDays(visit: CassandraRow, m: MeasureProperty, currentElementName: String, HistoryElementName: String, day: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    val currentElementDate=  currentElementName.toLowerCase match {
      case "encounterdate" |"sperecep_date" |"specsignout" => currentElementName
      case _ => currentElementName+"_date"
    }

    patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
        x.getString(1).equalsIgnoreCase(HistoryElementName)
        && x.getDate(2).after(visit.getDate(currentElementDate))
        && getBusinessDaysDifference(visit.getDate(currentElementDate), x.getDate(2)) <= day
    )
  }

  /**
    * This function verifies the Medication after X Months of Diagnosis
    * @param visit current visit of the patient
    * @param m Measure property of the measure
    * @param Medication Medication element that has to be verified in history
    * @param Diagnosis  Diagnosis element that has to be verified
    * @param months number of months that has to be added
    * @param patientHistoryList patient history list
    * @return it will return true if Medication after  X Months of Diagnosis.
    */
  def wasMedicationAfterXMonthsDiagnosis(visit: CassandraRow, m: MeasureProperty,Medication:String,Diagnosis:String,months:Int,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(x =>  x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(Medication)

        ).exists(x => patientHistoryList.value.exists(y =>
          y.getString("patientuid").equalsIgnoreCase(x.getString("patientuid"))
            && y.getString(1).equalsIgnoreCase(Diagnosis)
            &&
            ((x.getDateTime(2).isAfter(y.getDateTime(2).plusMonths(months))
              && x.getDateTime(2).isBefore(y.getDateTime(2)))
              ||
              x.getDateTime(2).isEqual(y.getDateTime(2).plusMonths(months))
              ||
              x.getDateTime(2).isEqual(y.getDateTime(2))
              )
        )
        )
      }
      val argsArray: Array[String] = Array(Medication,months.toString, Diagnosis)
      measureLogger(visit, m, "wasMedicationAfterXMonthsDiagnosis", Medication, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist


  }

  /**
    * This function returns history records for elements for tbl patient records in ascending order
    * @param tblRDD tbl RDD to checked in history
    * @param patientHistoryList patient history list
    * @param elements elements
    * @return returns list of history records for elements for tbl patient records in ascending order
    */
  def getElementsSortedRecords(tblRDD:RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]],elements:String*): List[CassandraRow] ={
    val tblPatientUIdList=tblRDD.map(r=>r.getString("patientuid")).distinct().collect()
    patientHistoryList.value.filter(r=>tblPatientUIdList.contains(r.getString("patientuid")) && elements.exists(ele=>ele.equalsIgnoreCase(r.getString(1)))).sortWith((x,y)=>x.getDateTime(2).isBefore(y.getDateTime(2)))
  }


  /**
    * This function returns true if immunization count between two birth days is equal to the provided count
    * @param visit current patient visit
    * @param m measure property
    * @param dobDate dob of the patient
    * @param elementName element name
    * @param firstBirthDay first birth day(ex: 10)
    * @param secondBirthDay second birth day(ex : 13)
    * @param immunizationCount immunization count
    * @param patientHistoryList patient history list
    * @return returns true if  immunization count between two birth days is equal to the provided count else returns false
    */
  def isImmunizationCountMatchingBetweenTwoBirthdays(visit:CassandraRow,m:MeasureProperty,dobDate:String,elementName:String,firstBirthDay:Int,secondBirthDay:Int,immunizationCount:Long,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    var isExist=false
    val startDate= visit.getDateTime(dobDate).plusYears(firstBirthDay)
    val endDate= visit.getDateTime(dobDate).plusYears(secondBirthDay)
    val elementDate=elementName+"_date"
    try {
      if (patientHistoryList.value.nonEmpty) {
        val resultCount=patientHistoryList.value.filter(histvisit => {
            histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) &&
            elementName.equalsIgnoreCase(histvisit.getString(1)) &&
            isDateBetween(histvisit.getDateTime(elementDate), startDate, endDate)
        }).length


        isExist= (resultCount== immunizationCount)


        val argsArray: Array[String] = Array(elementName,dobDate,firstBirthDay.toString,secondBirthDay.toString,immunizationCount.toString)
         measureLogger(visit, m, "isImmunizationCountMatchingBetweenTwoBirthdays", elementName, isExist, argsArray)
      }
    }

    catch {
      case e:Exception=>{
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function checks if interval between two immunization is equals or greater than provided interval
    * @param visit current patient visit
    * @param m measure property
    * @param dobDate dob of the patient
    * @param elementName element name
    * @param firstBirthDay first birth day(ex: 10)
    * @param secondBirthDay second birth day(ex : 13)
    * @param daysGap days gaps to be checks between immunization interval
    * @param patientHistoryList patient history list
    * @return returns true if interval between two immunization is equals or greater than provided interval else returns false
    */
  def isImmunizationIntervalMatchingBetweenTwoBirthdays(visit:CassandraRow,m:MeasureProperty,dobDate:String,elementName:String,firstBirthDay:Int,secondBirthDay:Int,daysGap:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    var isExist=false
    val startDate= visit.getDateTime(dobDate).plusYears(firstBirthDay)
    val endDate= visit.getDateTime(dobDate).plusYears(secondBirthDay)
    val elementDate=elementName+"_date"
    try {
      if (patientHistoryList.value.nonEmpty) {
        val resultPatientList=patientHistoryList.value.filter(histvisit => {
            histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) &&
            elementName.equalsIgnoreCase(histvisit.getString(1)) &&
            isDateBetween(histvisit.getDateTime(elementDate), startDate, endDate)
        })

        isExist= !resultPatientList.sliding(2).map { case Seq(x, y, _*) =>
          dateStatus(y.getDateTime(2),x.getDateTime(2).plusDays(daysGap),"ge")
        }.exists(_ == false)


        val argsArray: Array[String] = Array(elementName,dobDate,firstBirthDay.toString,secondBirthDay.toString,daysGap.toString)
         measureLogger(visit, m, "isImmunizationIntervalMatchingBetweenTwoBirthdays", elementName, isExist, argsArray)
      }
    }

    catch {
      case e:Exception=>{
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function verifies one histElement1 in history overlaps histElement2 in history
    * @param visit current visit of the patient
    * @param m measure property of the measure
    * @param histElement1  first history element
    * @param histElement2 second history element
    * @param patientHistoryList patient history element
    * @return it will return true if first element overlaps second element
    */
  def wasElementOverlapsElement(visit: CassandraRow, m: MeasureProperty,histElement1:String,histElement2:String,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(x =>  x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(histElement1)
        ).exists(x => patientHistoryList.value.exists(y =>
          y.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
            && y.getString(1).equalsIgnoreCase(histElement2)
            &&
            (
              x.getDateTime(2).isBefore(y.getDateTime(2))
                ||
                x.getDateTime(2).isEqual(y.getDateTime(2))
              )
        )
        )
      }
      val argsArray: Array[String] = Array(histElement1, histElement2)
      measureLogger(visit, m, "wasElementOverlapsElement", histElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist


  }



  /**
    * This function verifies if element starts before starts of element date within X interval period
    * @param visit current patient visit
    * @param m measure property
    * @param currentElementDate current element date
    * @param historyElement1 history element name
    * @param reasonElement reason element name
    * @param calenderInterval interval to be checked in integer
    * @param calenderUnit unit to be checked(ex: DAY,WEEK,MONTH,HOUR,YEAR)
    * @param patientHistoryList patient history list
    * @return returns true if  element starts before starts of element date within X interval period else returns false
    */
  def startsBeforeStartOfWithReasonBetweenPeriod(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, historyElement1: String, reasonElement: String,calenderInterval: Int,calenderUnit:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false


    val endDate=visit.getDateTime(currentElementDate)
    val startDate:DateTime=lowerCalenderDate(endDate,calenderUnit,calenderInterval)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(hvisit => visit.getString("patientuid").equals(hvisit.getString("patientuid"))
            && hvisit.getString(1).equals(visit.getString(historyElement1))
            && isDateBetween(hvisit.getDateTime(2),startDate, endDate)
        ).exists(l=>
          patientHistoryList.value.exists(hvisit => l.getString("patientuid").equals(hvisit.getString("patientuid"))
              && hvisit.getString(1).equals(visit.getString(reasonElement))
              && isDateBetween(hvisit.getDateTime(2),startDate, endDate)
              && l.getDateTime(2).isEqual(hvisit.getDateTime(2))
          ))
      }
      val argsArray: Array[String] = Array(historyElement1,currentElementDate,reasonElement, calenderInterval.toString,calenderUnit)
      measureLogger(visit, m, "startsBeforeStartOfWithReasonBetweenPeriod", reasonElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:startsAfterStartOfWithReason:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }





  /**
    * This function verifies if element starts after starts of element date within X interval period
    * @param visit current patient visit
    * @param m measure property
    * @param currentElementDate current element date
    * @param historyElement1 history element name
    * @param reasonElement reason element name
    * @param calenderInterval interval to be checked in integer
    * @param calenderUnit unit to be checked(ex: YEAR,MONTH,DAY,WEEK,HOUR,MINUTE)
    * @param patientHistoryList patient history list
    * @return returns true if  element starts after starts of element date within X interval period else returns false
    */
  def startsAfterStartOfWithReasonBetweenPeriod(visit: CassandraRow, m: MeasureProperty, currentElementDate: String, historyElement1: String, reasonElement: String,calenderInterval: Int,calenderUnit:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val endDate:DateTime=higherCalenderDate(visit.getDateTime(currentElementDate),calenderUnit,calenderInterval)
    val startDate=visit.getDateTime(currentElementDate)

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(hvisit =>
           visit.getString("patientuid").equals(hvisit.getString("patientuid"))
            && hvisit.getString(1).equals(visit.getString(historyElement1))
            && isDateBetween(hvisit.getDateTime(2),startDate, endDate)
        ).exists(l=>
          patientHistoryList.value.exists(hvisit =>
             l.getString("patientuid").equals(hvisit.getString("patientuid"))
              && hvisit.getString(1).equals(visit.getString(reasonElement))
              && isDateBetween(hvisit.getDateTime(2),startDate, endDate)
              && l.getDateTime(2).isEqual(hvisit.getDateTime(2))
          ))
      }
      val argsArray: Array[String] = Array(historyElement1, currentElementDate,calenderUnit,calenderInterval.toString)
      measureLogger(visit, m, "startsAfterStartOfWithReasonBetweenPeriod", reasonElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:startsAfterStartOfWithReason:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  def isInterventionPerformedWasConcurrentWith(visit: CassandraRow, m: MeasureProperty, histElement: String, currentElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(histVisit =>

          isNotNullInhistory(histVisit,  "elementvalue")

            && !visit.isNullAt(currentElement)
            && histVisit.getString(1).equalsIgnoreCase(histElement)

            && histVisit.getString(3).equals(visit.getString(currentElement)))
      }
      val argsArray: Array[String] = Array(currentElement, histElement)
      measureLogger(visit, m, "isInterventionPerformedWasConcurrentWith", histElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function verifies the sum of two laboratory test result is compare to provided value.
    *
    * @param visit              current visit of the patient.
    * @param m                  Measure Property of the measure.
    * @param labtest1           first laboratory test in history
    * @param labtest2           second laboratory test in history
    * @param element            element whose date has to be compared
    * @param compareValue value to be compare
    * @param compareFlag compare flag is used to compare sum value with compare value
    * @param patientHistoryList patient history list
    * @return It will return true if the sum of two laboratory test result is compare to provided value else false.
    */

  def wasSummationOfElementsBeforeElementXValue(visit: CassandraRow, m: MeasureProperty, labtest1: String, labtest2: String, element: String, compareValue: Double,compareFlag:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false


      try {
        if (patientHistoryList.value.nonEmpty) {
          isExist = patientHistoryList.value.filter(x =>  x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
            && x.getString(1).equalsIgnoreCase(element)

          ).exists(row => patientHistoryList.value.filter(y =>
            y.getString("patientuid").equalsIgnoreCase(row.getString("patientuid"))
              && y.getString(1).equalsIgnoreCase(labtest1)
              &&
              dateStatus(y.getDateTime(2),row.getDateTime(2),"le")
          )
            .exists(z => patientHistoryList.value.exists(a =>
              a.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
                && a.getString(1).equalsIgnoreCase(labtest2)
                &&
                dateStatus(a.getDateTime(2),row.getDateTime(2),"le")
                &&
                compareValueStatus((a.getDouble(3) + row.getDouble(3)),compareFlag,compareValue)
            )
            )
          )

        }
        val argsArray: Array[String] = Array(labtest1, labtest2, compareValue.toString, element)
        measureLogger(visit, m, "wasSummationOfElementsBeforeElementXValue", element, isExist, argsArray)

      }
      catch {
        case e: Exception => {
          loggerObj.error(e.getMessage)
          //System.exit(0)

        }
      }

      isExist
    }


  def isDiagnosisPerformedWasConcurrentWith(visit:CassandraRow, m:MeasureProperty, histElement:String,currentElement:String, patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    var isExist=false
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(histVisit =>

          isNotNullInhistory(histVisit,"elementvalue")

            && !visit.isNullAt(currentElement)
             && histVisit.getString(1).equalsIgnoreCase(histElement)
            && histVisit.getString(3).equals(visit.getString(currentElement)))
      }
      val argsArray: Array[String] = Array(currentElement, histElement)
      measureLogger(visit, m, "isDiagnosisPerformedWasConcurrentWith", histElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * this function verifies element before encounter date with result in history
    * @param visit              current visit of the patient.
    * @param m                  Measure Property of the measure.
    * @param histElement1 history element
    * @param resultElement result element
    * @param patientHistoryList patient history list
    * @return it will return true if element is before encounter with result.
    */
  def wasElementBeforeEncounterWithResult(visit: CassandraRow, m: MeasureProperty, histElement1: String, resultElement: String,  patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(x =>  x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(histElement1)
          &&
          (
            x.getDateTime(2).isBefore(visit.getDateTime("encounterdate"))
              ||
              x.getDateTime(2).isEqual(visit.getDateTime("encounterdate"))
            )

        ).exists(x => patientHistoryList.value.exists(y =>
          y.getString("patientuid").equalsIgnoreCase(x.getString("patientuid"))
            && y.getString(1).equalsIgnoreCase(resultElement)
            &&
            y.getDateTime(2).isEqual( x.getDateTime(2))
        )

        )
      }
      val argsArray: Array[String] = Array(histElement1, resultElement)
      measureLogger(visit, m, "wasElementBeforeEncounterWithResult", histElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist

  }

  /**
    * This function checks if the event starts after X intervals starts of before measurement period
    *
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element name
    * @param calenderInterval no of interval to be checked before
    * @param calenderUnit units in (DAY,WEEK,MONTH,YEAR,HOUR,MINUTE)
    * @param patientHistoryList patient history list
    * @param operatorType valid type are (StartOfMeasurementPeriod,EndOfMeasurementPeriod)
    * @return returns true if the event starts after X intervals starts of before measurement period else returns false
    */
  def isEventStartsBeforeOperatorMeasurementPeriodWithinXPeriod(visit: CassandraRow, m: MeasureProperty, elementName: String, calenderInterval: Int,calenderUnit:String, patientHistoryList: Broadcast[List[CassandraRow]],operatorType:String): Boolean = {
    var isExist = false

      val startDate= operatorType match{
        case "StartOfMeasurementPeriod" =>m.quarterStartDate
        case "EndOfMeasurementPeriod" =>m.quarterEndDate
      }

    val lowerDate= lowerCalenderDate(startDate,calenderUnit,calenderInterval)

    val higherDate=m.quarterStartDate

    val elementsNotNull = checkNotNull(visit, elementName)
    if (elementsNotNull) {
      try {

        if (patientHistoryList.value.nonEmpty) {
          isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
            .exists(hVisit =>
             hVisit.getString(1).equalsIgnoreCase(elementName)
            && isDateBetween(hVisit.getDateTime(2), lowerDate, higherDate)
          )
        }
        val argsArray: Array[String] = Array(elementName, calenderUnit,calenderInterval.toString)
        measureLogger(visit, m, "isEventStartsBeforeStartMeasurementPeriodWithinXPeriod", elementName, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isEventStartsBeforeStartMeasurementPeriodWithinXPeriod:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)

        }
      }
    }
    isExist
  }



  def wasDiagnosisDoneAfterProcedureWithinXDays(visit: CassandraRow, m: MeasureProperty, elementName: String, elementDate: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]], historyElement: String): Boolean = {
    var isExist = false

    val elementsNotNull = checkNotNull(visit, elementName, elementDate)
    if (elementsNotNull) {
      try {

        if (patientHistoryList.value.nonEmpty) {
          isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
            .exists(hvisit =>  historyElement.equalsIgnoreCase(hvisit.getString(1))
            && isDateBetween(hvisit.getDateTime(2), visit.getDateTime(elementDate), visit.getDateTime(elementDate).plusDays(days))
          )
        }
        val argsArray: Array[String] = Array(historyElement, days.toString, elementName)
        measureLogger(visit, m, "wasDiagnosisDoneAfterProcedureWithinXDays", historyElement, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasCommunicationDoneAfterProcedureWithinXDays:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)

        }
      }
    }
    isExist
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param historyElement element to be checked in history
    * @param currentElement element from current row
    * @param days number of days
    * @param patientHistoryList patient history list
    * @return returns true if history element was present before current element's date
    */
  def checkElementPresentBeforeOtherElementWithinXDays(visit: CassandraRow, m: MeasureProperty, historyElement: String, currentElement: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>  !visit.isNullAt(currentElement) && !visit.isNullAt(currentElement+"_date")
          && x.getString(1).equalsIgnoreCase(historyElement)
          && isDateBetween(x.getDateTime(2), visit.getDateTime(currentElement+"_date").minusDays(days), visit.getDateTime(currentElement+"_date"))
        )

      }


      val argsArray: Array[String] = Array(historyElement, currentElement,days.toString)
      measureLogger(visit, m, "checkElementPresentBeforeOtherElementWithinXDays", days.toString, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementPresentBeforeOtherElementWithinXDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param historyElement element to be checcked after other element
    * @param currentElement element from current row
    * @param patientHistoryList patient history list
    * @return returns true if element is present after other element
    */
  def wasElementPresentAfterOtherElement(visit: CassandraRow, m: MeasureProperty,historyElement: String, currentElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getString(1).equalsIgnoreCase(historyElement)
          && x.getDate(2).after(visit.getDate(currentElement+"_date"))
        )
      }
      val argsArray: Array[String] = Array(historyElement, currentElement)
      measureLogger(visit, m, "wasElementPresentAfterOtherElement", currentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentAfterOtherElement:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }



  def wasDiagnosticStudyValueGreaterOrEqualBeforeProcedurePerformed(visit: CassandraRow, m: MeasureProperty, currentElement: String, histElement: String, flag: String, value: Double, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val currentElementDate = currentElement + "_date"
    try {

      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>
          isNotNullInhistory(histvisit,  "elementvalue") &&
             histvisit.getString(1).equalsIgnoreCase(histElement)
            &&
            (
              histvisit.getDateTime(2).isBefore(visit.getDateTime(currentElementDate))
                ||
                histvisit.getDateTime(2).isEqual(visit.getDateTime(currentElementDate))
              )
            &&
            compareValueStatus(histvisit.getDouble(3), flag, value)

        )


        val argsArray: Array[String] = Array(histElement, currentElement, value.toString,flag)
        measureLogger(visit, m, "wasDiagnosticStudyValueGreaterOrEqualBeforeProcedurePerformed", histElement, isExist, argsArray)
      }
    }

    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist


  }

  /**
    * This function checks if Element is before X days greater of an element.
    *
    * @param visit              current visit of the patient.
    * @param m                  Measure property of the Measure
    * @param CurrentElement     Element that has to be verified for procedure.
    * @param histElement        History element with that current element has to be compared.
    * @param noOfDays           Number of days that will go back in history

    * @return
    */
  def wasEDEncounterPerformedXdaysBefore(visit: CassandraRow, m: MeasureProperty, CurrentElement: String, histElement: String, noOfDays: Int,edvisitArrivalDate:String,edvisitDepartureDate:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    //val CurrentElementDate = CurrentElement + "_date"
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(histvist =>
           histvist.getString(1).equalsIgnoreCase(histElement)
            && !visit.isNullAt(CurrentElement)
            &&
            (
              histvist.getDateTime(2).isBefore(visit.getDateTime("encounterdate").minusDays(noOfDays))
               || histvist.getDateTime(2).isEqual(visit.getDateTime("encounterdate").minusDays(noOfDays))
              )
          &&
            isDateInBetween(visit, m, histElement,edvisitArrivalDate,edvisitDepartureDate)

        )
      }
      val argsArray: Array[String] = Array(CurrentElement, noOfDays.toString, histElement,edvisitArrivalDate,edvisitDepartureDate)
      measureLogger(visit, m, "wasEDEncounterPerformedXdaysBefore", CurrentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * this function checks whether histroyElement date is before within some year from elementDate
    *
    * @param visit              current cassandra visit
    * @param m                  measure property
    * @param histroyElement     history element
    * @param year              no of year which will be look back from element Date
    * @param patientHistoryList patient history list
    * @return true if histroyElement date is before within some months from elementDate
    */
  def wasElementBeforeEncounterWithinXYears(visit: CassandraRow, m: MeasureProperty, histroyElement: String, year: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val lowerDate = visit.getDateTime("encounterdate").minusYears(year)
    val higherDate = visit.getDateTime("encounterdate")
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           histroyElement.equalsIgnoreCase(x.getString(1))

            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

        )

        val argsArray: Array[String] = Array(year.toString)
        measureLogger(visit, m, "wasElementBeforeEncounterWithinXYears", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementBeforeOrEqualInMonths:" + e.printStackTrace(), "FAIL")

        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /*/**
    *
    * @param visit current row
    * @param m measure property
    * @param historyElement element to be checked before other element
    * @param currentElement element from current row
    * @param patientHistoryList patient history list
    * @return returns true if element is present before other element
    */
  def wasElementPresentBeforeOtherElement(visit: CassandraRow, m: MeasureProperty,historyElement: String, currentElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.exists(x => !x.isNullAt(2) && !x.isNullAt("patientuid") &&
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(historyElement)
          && x.getDateTime(2).isBefore(visit.getDateTime(currentElement+"_date"))
        )
      }
      val argsArray: Array[String] = Array(historyElement, currentElement)
      measureLogger(visit, m, "wasElementPresentBeforeOtherElement", currentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentBeforeOtherElement:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }*/

  /**
    *
    * @param visit              patient current visit
    * @param m                  measure property
    * @param months             minus years in in element
    * @param patientHistoryList get patient history list
    * @return it return of Element before end of X in years
    */

  def wasElementAfterEncounterwithResultElementEqual(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String, months: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val startDate = m.quarterStartDate
    val endDate = m.quarterEndDate


    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>
            hvisit.getString(1).equals(visit.getString(elementName1))
            &&
            hvisit.getDateTime(2).isAfter(visit.getDateTime("encounterdate"))

            &&

            isDateBetween(hvisit.getDateTime(2), startDate, endDate)

            &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit1 =>
             hvisit1.getString(1).equals(visit.getString(elementName2))

                &&

                hvisit1.getDateTime(2).isAfter(visit.getDateTime("encounterdate"))

                &&
                hvisit.getDateTime(2).isEqual(hvisit1.getDateTime(2))

            ))
      }
      val argsArray: Array[String] = Array(elementName1, elementName2,months.toString)
      measureLogger(visit, m, "wasElementAfterEncounterwithResultElementEqual", elementName1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  def wasElementPresentAfterElement(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElement: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementDate = elementName + "_date"
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getString(1).equalsIgnoreCase(historyElement)
          && x.getDate(2).after(visit.getDate(elementDate))
        )


      }
      val argsArray: Array[String] = Array(elementName, historyElement)
      measureLogger(visit, m, "wasElementPresentAfterElement", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentBeforeOrEqualEncounter:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }




  def wasElementAfterEncounterBeforeEnd(visit: CassandraRow, m: MeasureProperty,  historyElement: String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val startDate = m.quarterStartDate
//    val endDate = m.quarterEndDate
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equalsIgnoreCase(historyElement)

          && isDateBetween(x.getDateTime(2),m.quarterStartDate, m.quarterEndDate)
          && x.getDate(2).after(visit.getDate("encounterdate"))

        )
      }
      val argsArray: Array[String] = Array(historyElement)
      measureLogger(visit, m, "wasElementAfterEncounterBeforeEnd", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementDuringMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }



  def checkElementValueAfterElement(visit: CassandraRow, m: MeasureProperty, historyElementName: String, currentElement: String, value: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        val currentElementDate = currentElement + "_date"

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !x.isNullAt(3) &&
          !visit.isNullAt(currentElement) && !visit.isNullAt(currentElementDate)
          &&
          x.getString(1).equalsIgnoreCase(historyElementName)
          &&
          x.getDateTime(2).isAfter(visit.getDateTime(currentElementDate))
          &&
          compareValueStatus(x.getDouble(3), flag, value))

      }

      val argsArray: Array[String] = Array(historyElementName,currentElement, value.toString,flag)
      measureLogger(visit, m, "checkElementValueAfterElement", historyElementName, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isMostRecentPhysicalExamPerformedBefore:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  def wasElementAfterElementBeforeEnd(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElement: String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val startDate = m.quarterStartDate
//    val endDate = m.quarterEndDate
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x => !x.isNullAt(2) && !x.isNullAt("patientuid")

                  && x.getString(1).equalsIgnoreCase(historyElement)

          && isDateBetween(x.getDateTime(2),visit.getDateTime(elementName+"_date"),m.quarterEndDate)
          && x.getDate(2).after(visit.getDate(elementName+"_date"))

        )
      }
      val argsArray: Array[String] = Array(elementName,historyElement)
      measureLogger(visit, m, "wasElementAfterElementBeforeEnd", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
       // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementDuringMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  def wasElementBeforeElementInXDays(visit: CassandraRow, m: MeasureProperty, currentElement:String,historyElementName: String, days: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementDate = visit.getDateTime(currentElement+"_date")
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
             x.getString(1).equalsIgnoreCase(historyElementName)

            && (elementDate.minusDays(days).isBefore(x.getDateTime(2))

            || elementDate.minusDays(days).isEqual(x.getDateTime(2)))
        )
      }
      val argsArray: Array[String] = Array(currentElement,days.toString, historyElementName)
      measureLogger(visit, m, "wasElementBeforeElementInXDays", historyElementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }



  /**
    * This function verifies one histElement1 in history overlaps histElement2 in history
    *
    * @param visit              current visit of the patient
    * @param m                  measure property of the measure
    * @param histElement1       first history element
    * @param histElement2       second history element
    * @param value              value that has be compared
    * @param flag               compare flag (valid flags [lt,gt,le,ge,eq])
    * @param patientHistoryList patient history element
    * @return it will return true if first element overlaps second element
    */
  def wasElementOverlapsElementWithResultValue(visit: CassandraRow, m: MeasureProperty, histElement1: String, histElement2: String, value: Double, flag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(x => !x.isNullAt(3) && x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(histElement1)
        ).exists(x => patientHistoryList.value.exists(y =>
          y.getString("patientuid").equalsIgnoreCase(x.getString("patientuid"))
            && y.getString(1).equalsIgnoreCase(histElement2)
            &&
            (
              x.getDateTime(2).isBefore(y.getDateTime(2))
                ||
                x.getDateTime(2).isEqual(y.getDateTime(2))
              )
            &&
            compareValueStatus(x.getDouble(3), flag, value))

        )
      }
      val argsArray: Array[String] = Array(histElement1, histElement2, value.toString,flag)
      measureLogger(visit, m, "wasElementOverlapsElementWithResultValue", histElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist


  }

  /**
    * This function verifies if physical exam was performed before or after encounter with specified interval and value
    * @author Hemant
    * @param visit current patient visit
    * @param m measure property
    * @param element element name
    * @param operatorType  operator type (startsBefore,startsAfter)
    * @param unit unit in (MIN,HOUR,DAY,WEEK,MONTH,YEAR)
    * @param interval lower interval to be checked before/after provided as interger type
    * @param historyElement history element name
    * @param value result value
    * @param valueFlag result flag name (le,ge,lt,gt,eq)
    * @param patientHistoryList patient history list
    * @return returns true if physical exam was performed before or after encounter with specified interval and value else returns false
    */
  def wasPhysicalPerformedWithInPeriodWithValue(visit:CassandraRow,m:MeasureProperty,element:String,operatorType:String,unit:String,interval:Int,historyElement:String,value:Double,valueFlag:String,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false

    val elementDate=element+"Date"
    val (lowerDate,higherDate) = operatorType match{
      case "startsBefore" => (lowerCalenderDate(visit.getDateTime(elementDate),unit,interval),visit.getDateTime(elementDate))
      case "startsAfter"=>(visit.getDateTime(elementDate),higherCalenderDate(visit.getDateTime(elementDate),unit,interval))
    }

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(hvisit => !hvisit.isNullAt(3)
          && hvisit.getString(1).equalsIgnoreCase(historyElement)
          && isDateBetween(hvisit.getDateTime(2),lowerDate,higherDate)
          && compareValueStatus(hvisit.getDouble(3), valueFlag, value)

        )

      }

      val argsArray: Array[String] = Array(unit,operatorType,interval.toString,value.toString)
       measureLogger(visit, m, "wasPhysicalPerformedWithInPeriodWithValue", element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasPhysicalPerformedWithInPeriodWithValue:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function verifies if element is before or equal encounter date.
    * @param visit              current visit of the patient
    * @param m                  measure property of the measure
    * @param histElement        history element
    * @param value              value that has to be compared
    * @param flag               Flage based on requirement ge,gt,lt,le,eq
    * @param patientHistoryList patient history list
    * @return it will return if element is before or equal to encounter date with value
    */
  def wasElementBeforeOrEqualEncounterWithValue(visit: CassandraRow, m: MeasureProperty, histElement: String,value:Double,flag:String,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !x.isNullAt(3)
          && x.getString(1).equalsIgnoreCase(histElement)
          && (x.getDateTime(2).isBefore(visit.getDateTime("encounterdate"))
          || x.getDateTime(2).isEqual(visit.getDateTime("encounterdate")))
          && compareValueStatus(x.getDouble(3), flag, value)
        )
      }
      val argsArray: Array[String] = Array(histElement,value.toString)
      measureLogger(visit, m, "wasElementBeforeEncounterWithValue", histElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist


  }

  /**
    * //PARENT FUNCTION
    *
    * @param visit              cassandra row
    * @param m                  measure property
    * @param historyElement     element to be checked in X hours from encounterDate
    * @param hours               number of days
    * @param patientHistoryList patient history list
    * @return returns true if Future element has happened in x hours from encounterDate
    */


  def wasElementAfterEncounterWithinXHours(visit: CassandraRow, m: MeasureProperty, historyElement: String, hours: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         x.getString(1).equalsIgnoreCase(historyElement)

            && isDateBetween(x.getDateTime(2), visit.getDateTime("encounterdate"), visit.getDateTime("encounterdate").plusHours(hours))
        )

      }
      val argsArray: Array[String] = Array(historyElement, hours.toString)
      measureLogger(visit, m, "wasElementAfterEncounterWithinXHours", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementAfterEncounterWithinXHours:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /** PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param patientHistoryList list of patient history
    * @return true if element is already present after another element
    */
  def wasElementBeforeOtherElementInHistory(visit: CassandraRow, m: MeasureProperty, HistoryElement1: String,HistoryElement2: String,HistoryElement3: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getString(1).equalsIgnoreCase(HistoryElement1)
          &&
          patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
            !x.isNullAt(2) && !y.isNullAt("patientuid") &&
            y.getString(1).equalsIgnoreCase(HistoryElement2)
          &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
                !z.isNullAt(2) && !z.isNullAt("patientuid")
                  && z.getString(1).equalsIgnoreCase(HistoryElement3)
          &&
             (y.getDateTime(2).isBefore(x.getDateTime(2)) &&

                  z.getDateTime(2).isBefore(x.getDateTime(2)) &&

                  y.getDateTime(2).isEqual(z.getDateTime(2)))

            )))

      }
      val argsArray: Array[String] = Array(HistoryElement1,HistoryElement2,HistoryElement3)
      measureLogger(visit, m, "wasElementBeforeOtherElementInHistory", HistoryElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /** PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param patientHistoryList list of patient history
    * @return true if element is already present after another element
    */
  def wasElementPresentWithReasonAfterEncounter(visit: CassandraRow, m: MeasureProperty, currentElement: String,HistoryElement1: String,HistoryElement2: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {

      val elementdate= if (currentElement.equalsIgnoreCase("encounterdate")) "encounterdate" else currentElement

      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
      x.getString(1).equalsIgnoreCase(HistoryElement1)
          &&
              patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
                !z.isNullAt(2) &&
                  z.getString(1).equalsIgnoreCase(HistoryElement2)
                  &&
                  (visit.getDateTime(elementdate).isAfter(x.getDateTime(2)) &&

                    visit.getDateTime(elementdate).isAfter(x.getDateTime(2)) &&

                    x.getDateTime(2).isEqual(z.getDateTime(2)))


              ))

      }
      val argsArray: Array[String] = Array(currentElement,HistoryElement1,HistoryElement2)
      measureLogger(visit, m, "wasElementPresentWithReasonAfterEncounter", HistoryElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }




  /**
    * This function checks if element is present in future between  history element's date range
    * @param visit current patient visit
    * @param m measure property
    * @param currentElement current element name
    * @param historyElement history element name
    * @param calendarInterval1 no of intervals to be looked after
    * @param calendarInterval2 no of intervals to be looked after
    * @param patientHistoryList patient history list
    * @return returns true if element is present in future between  history element's date range else returns false
    */
  def wasElementPresentInFutureOfHistoryElementBetweenRange(visit:CassandraRow,m:MeasureProperty,currentElement:String,historyElement:String,calendarInterval1:Int,calendarInterval2:Int,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false

    try {
      if (checkNotNull(visit,currentElement,currentElement+"_date") && patientHistoryList.value.nonEmpty) {
        val currentDate=visit.getDateTime(currentElement+"_date")
        val lowerDate= currentDate.plusDays(calendarInterval1)
        val higherDate= currentDate.plusDays(calendarInterval2)
        isExist = patientHistoryList.value.filter(histRow => histRow.getString(0).equalsIgnoreCase(visit.getString("patientuid"))).exists(histRow=>
        histRow.getString(1).equalsIgnoreCase(historyElement)   &&
          isDateBetween(histRow.getDateTime(2),lowerDate,higherDate)
        )
      }
      val argsArray: Array[String] = Array(historyElement,currentElement,calendarInterval1.toString,calendarInterval2.toString)
      measureLogger(visit, m, "wasElementPresentInFutureOfHistoryElementBetweenRange", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist
  }


  /**
    * This function verifies if encounter count greater than specified X within X days
    * @param visit current patient visit
    * @param m measure property
    * @param historyElement1 history element 1
    * @param historyElement2 history element 2
    * @param days days to be looked before
    * @param count count to be compare
    * @param patientHistoryList patient history list
    * @return returns true if encounter count greater than specified else returns false
    */
  def wasCountGreaterThanXWithinXDays(visit:CassandraRow,m:MeasureProperty,historyElement1:String,historyElement2:String,days:Int,count:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(x =>
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(historyElement1)
          &&
          patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
            !y.isNullAt(2)
              && y.getDate(2).before(visit.getDate("encounterdate"))
              && x.getString(1).equalsIgnoreCase(historyElement2)
              && isDateBetween(y.getDateTime(2),x.getDateTime(2).minusDays(days),x.getDateTime(2))
          )
        ).length>count

        val argsArray: Array[String] = Array(historyElement1,historyElement2,count.toString,days.toString)
        measureLogger(visit, m, "wasCountGreaterThanXWithinXDays", historyElement1, isExist, argsArray)



      }

    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasCountGreaterThanXWithinXDays:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function verifies if intervention was performed between element/encounterdate and other element
    * @author Hemant
    * @param visit current patient visit
    * @param m measure property
    * @param currentElement current element name
    * @param historyElement1 history element1
    * @param historyElement2 history element2 (Count > 1 : "Encounter, Performed: Emergency Department Visit" <= 30 day(s) starts before end of $Expired_Union
    *                             e.g. element1 is equal to $Expired_Union and Element2 equal to Encounter, Performed: Emergency Department Visit )
    * @param patientHistoryList patient history list
    * @return returns true if  intervention was performed between element/encounterdate and other element else returns false
    */
  def wasInterventionPerformedInBetween(visit:CassandraRow,m:MeasureProperty,currentElement:String,historyElement1:String,historyElement2:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    var isExist = false
    val currentDate= if(currentElement.equalsIgnoreCase("encounterdate")) visit.getDateTime("encounterdate") else visit.getDateTime(currentElement+"_date")
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getString(1).equalsIgnoreCase(historyElement1)
          && x.getDateTime(2).isAfter(currentDate)
          &&
          patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
               z.getDate(2).before(visit.getDate("encounterdate"))
              && x.getString(1).equalsIgnoreCase(historyElement2)
              && isDateBetween(z.getDateTime(2),currentDate,x.getDateTime(2))
          )
        )

      }
      val argsArray: Array[String] = Array(currentElement,historyElement1,historyElement2)
      measureLogger(visit, m, "wasInterventionPerformedInBetween", historyElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasInterventionPerformedInBetween:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }



  def wasElementPresentWithReasonAfterWeeksBeforeStartwithinXMonths(visit: CassandraRow, m: MeasureProperty, HistoryElement1: String,HistoryElement2: String,HistoryElement3: String, month:Int,week:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try
        if (patientHistoryList.value.nonEmpty) {

          isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equalsIgnoreCase(HistoryElement1)
            && isDateBetween(x.getDateTime(2),m.quarterStartDate.minusMonths(month),m.quarterStartDate)
            &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
                 z.getString(1).equalsIgnoreCase(HistoryElement2)
                && (z.getDateTime(2).isAfter(x.getDateTime(2).plusWeeks(week))
                || z.getDateTime(2).isEqual(x.getDateTime(2).plusWeeks(week)))

                &&
                patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
                    y.getString(1).equalsIgnoreCase(HistoryElement3)
                    && y.getDateTime(2).isEqual(z.getDateTime(2))

                )))

          val argsArray: Array[String] = Array(HistoryElement1,HistoryElement2,HistoryElement3,month.toString,week.toString)
          measureLogger(visit, m, "wasElementPresentWithReasonAfterWeeksBeforeStartwithinXMonths", HistoryElement1, isExist, argsArray)
        }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  def wasElementPresentWithReasonWithinWeeksBeforeStartwithinXMonths(visit: CassandraRow, m: MeasureProperty, HistoryElement1: String,HistoryElement2: String,HistoryElement3: String, month:Int,week:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try
        if (patientHistoryList.value.nonEmpty) {

          isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equalsIgnoreCase(HistoryElement1)
            && isDateBetween(x.getDateTime(2),m.quarterStartDate.minusMonths(month),m.quarterStartDate)
            &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
z.getString(1).equalsIgnoreCase(HistoryElement2)
                && isDateBetween(z.getDateTime(2),x.getDateTime(2),z.getDateTime(2).minusWeeks(week))
                &&
                patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
                    y.getString(1).equalsIgnoreCase(HistoryElement3)
                    && y.getDateTime(2).isEqual(z.getDateTime(2))

                )))

          val argsArray: Array[String] = Array(HistoryElement1,HistoryElement2,HistoryElement3,month.toString,week.toString)
          measureLogger(visit, m, "wasElementPresentWithReasonWithinWeeksBeforeStartwithinXMonths", HistoryElement1, isExist, argsArray)
        }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    * This function verifies the Element Date is equal to most recent encounterdate
    * @param visit              current visit of the patient
    * @param m                  measure property of the measure
    * @param histElement1       history element
    * @param patientHistoryList patient history list
    * @param MostRecentpatientHistoryList mostrecent encounter list
    * @return it wiil return true  if element date is before most recent encounterdate
    */
  def wasElementDuringMostRecentEncounter(visit: CassandraRow, m: MeasureProperty, histElement1: String, patientHistoryList: Broadcast[List[CassandraRow]],MostRecentpatientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(x => x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(histElement1)
        ).exists(x => MostRecentpatientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(x.getString("patientuid"))).exists(y =>
              x.getDateTime(2).isEqual(y.getDateTime("encounterdate"))
              )

        )
      }
      val argsArray: Array[String] = Array(histElement1)
      measureLogger(visit, m, "wasElementDuringMostRecentEncounter", histElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist

  }

  /**
    * this function will give list of patientuid and count of all the element passed in arugment from historyRDD within months before first date of other element
    *
    * @param historyRdd history RDD
    * @param m          measure property
  @param firstDateList first Date list
    * @param months     no. of months looks back from first Date
    * @param element    elements of which we need count patient wise
    * @return List of patientuid and count of element passed in parameter
    */
  def countElementBeforeFirstOtherElementWithinXMonthsInHistory(historyRdd: RDD[CassandraRow],firstDateList: Broadcast[List[CassandraRow]], m: MeasureProperty, months: Int, element: String): List[(String, Int)] = {
    historyRdd.filter(r=> firstDateList.value.exists(x=>
      r.getString(1).equalsIgnoreCase(element)
        && (r.getDateTime(2).isBefore(x.getDateTime(2))
        && r.getDateTime(2).isAfter(x.getDateTime(2).minusMonths(months)))
        ||
        r.getDateTime(2).isEqual(x.getDateTime(2))
        ||
        r.getDateTime(2).isEqual(x.getDateTime(2).minusMonths(months)
        ))
    ) .map(z => (z.getString("patientuid"), 1)).reduceByKey(_ + _).collect.toList

  }





  def wasElementBeforeFirstOccurenceOfElementWithInXmonth(visit: CassandraRow, m: MeasureProperty,months:Int, histElement1: String,leastRecentpatientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false
    val Start_date= m.quarterStartDate
    try {
      if (leastRecentpatientHistoryList.value.nonEmpty) {
        isExist = leastRecentpatientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>  x.getString(1).equalsIgnoreCase(histElement1)
          &&
          ((x.getDateTime(2).isAfter(Start_date.minusMonths(months)) && x.getDateTime(2).isBefore(Start_date))
            || x.getDateTime(2).isEqual(Start_date.minusMonths(months)) || x.getDateTime(2).isEqual(Start_date))

        )

      }
      val argsArray: Array[String] = Array(histElement1,months.toString)
       measureLogger(visit, m, "wasElementBeforeFirstOccurenceOfElementWithInXmonth", histElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist



  }

  /**
    * This function verifies whether  element is present during other element in history.
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param HistoryElement1 first history element
    * @param patientHistoryList patient history list
    * @param HistoryElement2 second history element
    * @return
    */
  def wasElementPresentDuringOtherElementInHistory(visit: CassandraRow, m: MeasureProperty, HistoryElement1: String, patientHistoryList: Broadcast[List[CassandraRow]], HistoryElement2: Seq[String]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equalsIgnoreCase(HistoryElement1)
          &&
          patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
            !z.isNullAt(2)
              && HistoryElement2.exists(y => y.equalsIgnoreCase(z.getString(1)) && x.getDate(2).equals(z.getDate(2)))))

      }

      val argsArray: Array[String] = Array(HistoryElement1)
      measureLogger(visit, m, "wasElementPresentDuringOtherElementInHistory", HistoryElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentDuringOtherElementInHistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function verifies element after element X hours
    * @param visit              current visit
    * @param m                  measure Property
    * @param historyElement     history element
    * @param no_of_hours        number of hours
    * @param patientHistoryList patient history list
    * @param elementName        element name in history
    * @return
    */
  def wasElementAfterElementListWithinXHours(visit: CassandraRow, m: MeasureProperty, historyElement: String, no_of_hours: Int, patientHistoryList: Broadcast[List[CassandraRow]], elementName: Seq[String]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
               x.getString(1).equalsIgnoreCase(historyElement)

            && elementName.exists(r => isDateBetween(x.getDateTime(2), visit.getDateTime(r + "_date"), visit.getDateTime(r + "_date").plusHours(no_of_hours)))

        )
      }
      val argsArray: Array[String] = Array( historyElement,no_of_hours.toString)
      measureLogger(visit, m, "wasElementAfterElementListWithinXHours", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * This function verifies element is present after other element with In X weeks in history
    *
    * @param visit              current visit of the patient
    * @param m                  measure propertt
    * @param HistoryElement1    first history element
    * @param noOfWeeks          number of weeks that has to be subtracted
    * @param patientHistoryList patient history list
    * @param HistoryElement2    second history element
    * @return
    */
  def wasElementPresentAfterOtherElementWithinXWeeksInHistory(visit: CassandraRow, m: MeasureProperty, HistoryElement1: String, noOfWeeks: Int, patientHistoryList: Broadcast[List[CassandraRow]], HistoryElement2: Seq[String]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getString(1).equalsIgnoreCase(HistoryElement1)
          &&
          patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
               HistoryElement2.exists(y => y.equalsIgnoreCase(z.getString(1))
              && ((x.getDate(2).after(z.getDate(2) )
              && x.getDateTime(2).isBefore(z.getDateTime(2).minusWeeks(noOfWeeks)))
              || x.getDate(2).equals(z.getDate(2)) || x.getDateTime(2).isEqual(z.getDateTime(2).minusWeeks(noOfWeeks)))
            )))

      }
      val argsArray: Array[String] = Array(HistoryElement1,noOfWeeks.toString)
      measureLogger(visit, m, "wasElementPresentAfterOtherElementWithinXWeeksInHistory", HistoryElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentAfterOtherElementWithinXWeeksInHistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }



  /**
    *
    * @param visit                  patient current visit
    * @param m                  measure property
    * @param elementName        get element check between
    * @param months             minus years in in element
    * @param patientHistoryList get patient history list
    * @return it return of Element before end of X in years
    */

  def wasElementBeforeStartInXMonthsWithResult(visit: CassandraRow, m: MeasureProperty, elementName: String, months: Int,ResultValue: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val startDate = m.quarterStartDate
    val lowerDate = startDate.minusMonths(months)
    val higherDate = startDate
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
             x.getString(1).equals(visit.getString(elementName))
                  &&
          patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
             x.getString(1).equals(visit.getString(elementName))

            && x.getString(1).equals(visit.getString(ResultValue))

            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

        )
        )
      }
      val argsArray: Array[String] = Array(elementName, months.toString,ResultValue)
      measureLogger(visit, m, "wasElementBeforeStartInXMonthsWithResult", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    * This function verifies if element1 with result performed with operator type element2 in history
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param historyElement1    history element1
    * @param historyElement2    history element2
    * @param operatorType       operator type (valid are DURING,AFTER,BEFORE )
    * @param result             result of element 1 in double
    * @param resultFlag         result flag (valida are ge,gt,lt,le,ge)
    * @param patientHistoryList patient history list
    * @return returns true if  element1 with result performed with operator type element2 in history else returns false
    */
  def wasElement1WithResultPerformedOperatorTypeElement2InHistory(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String, operatorType: String, result: Double, resultFlag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>  x.getString(1).equalsIgnoreCase(historyElement1)
          && patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y => {
          val elementStatus =
            y.getString(1).equalsIgnoreCase(historyElement2)

          val operatorStatus = operatorType match {
            case "DURING" => x.getDateTime(2).isEqual(y.getDateTime(2))
            case "AFTER" => x.getDateTime(2).isAfter(y.getDateTime(2))
            case "BEFORE" => x.getDateTime(2).isBefore(y.getDateTime(2))
          }

          val valueCheck = compareValueStatus(x.getDouble(3), resultFlag, result)
          elementStatus && operatorStatus && valueCheck
        })
        )
      }
      val argsArray: Array[String] = Array(historyElement1,historyElement2,operatorType,result.toString)
      measureLogger(visit, m, "wasElement1WithResultPerformedOperatorTypeElement2InHistory", historyElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist

  }

  /**
    *
    * @param visit                  patient current visit
    * @param m                  measure property
    * @param elementName2        get element check between
    * @param monthsTo             minus months in in element
    * @param monthsFrom             minus months in in element
    * @param patientHistoryList get patient history list
    * @return it return of Element before end of X in years
    */

  def wasProcedurePerformedBeforeStartWithInResultBetweenXMonths(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String, ResultValueElement: String, monthsforElementName2: Int, monthsTo: Int, monthsFrom: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    // val startDate = m.quarterStartDate
    val lowerDate = m.quarterStartDate.minusMonths(monthsFrom)
    val higherDate = m.quarterStartDate.minusMonths(monthsTo)

    val lowerDateForElementName2 = m.quarterStartDate.minusMonths(monthsforElementName2)
    val higherDateForElementName2 = m.quarterStartDate
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equals(visit.getString(elementName1))

            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
            &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
                 y.getString(1).equals(visit.getString(elementName2))
                &&
                patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
                   z.getString(1).equals(visit.getString(elementName2))

                    && z.getString(1).equals(visit.getString(ResultValueElement))

                    &&
                    y.getDateTime(2).isBefore(x.getDateTime(2).plusMonths(monthsforElementName2))

                )

            ))

      }
      val argsArray: Array[String] = Array(elementName1,elementName2,ResultValueElement.toString, monthsTo.toString,monthsFrom.toString,monthsforElementName2.toString)
      measureLogger(visit, m, "wasProcedurePerformedBeforeStartBetweenMonths", elementName1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    *
    * @param visit
    * @param m
    * @param elementName1
    * @param elementName2
    * @param ResultValueElement
    * @param calenderUnitforElement2
    * @param intervalForElement2
    * @param calenderUnitFormonthsFrom
    * @param intervalForMonthFrom
    * @param calenderUnitFormonthsTo
    * @param intervalForMonthTo
    * @param patientHistoryList
    * @return
    */
  def wasProcedurePerformedAfterStartWithInResultBetweenXMonths(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,ResultValueElement: String,calenderUnitforElement2: String,intervalForElement2: Int,calenderUnitFormonthsFrom: String,intervalForMonthFrom: Int ,calenderUnitFormonthsTo: String,intervalForMonthTo: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val lowerDate = lowerCalenderDate(m.quarterStartDate,calenderUnitFormonthsFrom,intervalForMonthFrom)
    val higherDate = lowerCalenderDate(m.quarterStartDate,calenderUnitFormonthsTo,intervalForMonthTo)
  try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equals(visit.getString(elementName1))
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
            &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
               y.getString(1).equals(visit.getString(elementName2))
                &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
                   z.getString(1).equals(visit.getString(elementName2))
                    && z.getString(1).equals(visit.getString(ResultValueElement))
                    &&
                    y.getDateTime(2).isAfter(higherCalenderDate(x.getDateTime(2),calenderUnitforElement2,intervalForElement2))

                )

            ))

      }
      val argsArray: Array[String] = Array(elementName1,elementName2,ResultValueElement: String,calenderUnitforElement2.toString,intervalForElement2.toString,calenderUnitFormonthsFrom)
      measureLogger(visit, m, "wasProcedurePerformedAfterStartWithInResultBetweenXMonths", elementName1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    *
    * @param visit
    * @param m
    * @param element1
    * @param ResultElement
    * @param historyElement
    * @param CalenderUnit
    * @param interval
    * @param patientHistoryList
    * @return
    */


  def wasElementBeforeElementInXPeriodWithResult(visit: CassandraRow, m: MeasureProperty, element1: String, ResultElement: String, historyElement: String, CalenderUnit:String, interval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false


    try {
      isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
      x.getString(1).equalsIgnoreCase(element1)
        &&
        patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
          y.getString(1).equalsIgnoreCase(historyElement)
            &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
            z.getString(1).equalsIgnoreCase(ResultElement) &&
            (
              x.getDateTime(2).equals(lowerCalenderDate(y.getDateTime(2), CalenderUnit, interval))

                              ||
                x.getDateTime(2).isBefore(lowerCalenderDate(y.getDateTime(2), CalenderUnit, interval))
              )
              &&
            (
              x.getDateTime(2).equals(z.getDateTime(2))
            )
        )


        )
      )
      val argsArray: Array[String] = Array(element1, ResultElement,historyElement, CalenderUnit, interval.toString)
      measureLogger(visit, m, "wasElementBeforeElementInXMonth", element1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAdverseEventNotStoppedWithinXHours:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }



  def wasElementAfterElementWithResultInBetweenXPeriodes(visit: CassandraRow, m: MeasureProperty, element1: String,ResultElement: String, historyElement: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
      x.getString(1).equalsIgnoreCase(element1)
        &&
        patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
          y.getString(1).equalsIgnoreCase(historyElement)
            &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
              z.getString(1).equalsIgnoreCase(ResultElement)
                &&
                 (
                  x.getDateTime(2).equals(z.getDateTime(2))
                  )
                && isDateBetween(z.getDateTime(2), lowerCalenderDate(z.getDateTime(2), CalenderUnitFrom, intervalFrom),higherCalenderDate(z.getDateTime(2), CalenderUnitTo, intervalTo)

            )


        )
      ))
      val argsArray: Array[String] = Array(element1, ResultElement,historyElement,CalenderUnitTo,intervalTo.toString,CalenderUnitFrom,intervalFrom.toString)
      measureLogger(visit, m, "wasAssessmentPerformedAfterProcedureWithResultInBetweenXMonths", element1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAdverseEventNotStoppedWithinXHours:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }


  def checktwoElementdifferenceInRangeMonths(visit: CassandraRow, m: MeasureProperty, currentElementName:String,histroyElement1: String,histroyElement2: String, valueDifference:Double,lowerMonth: Int,higherMonth: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val lowerDate = visit.getDateTime(currentElementName+"_date").plusMonths(lowerMonth)
    val higherDate = visit.getDateTime(currentElementName+"_date").plusMonths(higherMonth)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x => !x.isNullAt(3) &&
           histroyElement1.equalsIgnoreCase(x.getString(1))
              && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
            &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
                 histroyElement2.equalsIgnoreCase(x.getString(1))
                && isDateBetween(z.getDateTime(2), lowerDate, higherDate)
                && z.getDateTime(2).isEqual(x.getDateTime(2))
                && math.abs(z.getDouble(3) - z.getDouble(3)) > valueDifference

            )

        )

        val argsArray: Array[String] = Array(currentElementName,histroyElement1,histroyElement2,valueDifference.toString,lowerMonth.toString,higherMonth.toString)
        measureLogger(visit, m, "checktwoElementdifferenceInRangeMonths", histroyElement1, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        //System.exit(0)
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementValueBeforeWithinXMonths:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }


  def checktwoElementValueDiffInRangeMonths(visit: CassandraRow, m: MeasureProperty, currentElementName:String,histroyElement: String, valueDifference:Double,lowerMonth: Int,higherMonth: Int, value: Double,  patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val lowerDate = visit.getDateTime(currentElementName+"_date").plusMonths(lowerMonth)
    val higherDate = visit.getDateTime(currentElementName+"_date").plusMonths(higherMonth)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x => !x.isNullAt(3) &&

          !x.isNullAt(2)

            &&  histroyElement.equalsIgnoreCase(x.getString(1))

            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

            && x.getDouble(3) >= value

            && math.abs(x.getDouble(3) - visit.getDouble(currentElementName)) > valueDifference

        )

        val argsArray: Array[String] = Array(currentElementName,histroyElement,valueDifference.toString,lowerMonth.toString,higherMonth.toString,value.toString)
        measureLogger(visit, m, "checktwoElementValueDiffInRangeMonths", currentElementName, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        //System.exit(0)
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementValueBeforeWithinXMonths:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }


  /**
    * This function verifies element before or equal from X days from end of the measurement period.
    * @param visit current visit of the patient
    * @param m measure property
    * @param histroyElement history element
    * @param days number of days that has to be subtracted from end
    * @param patientHistoryList patient history list
    * @return
    */

  def wasElementBeforeOrEqualXDaysFromEnd(visit: CassandraRow, m: MeasureProperty,histroyElement:String,days:Int,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean={
    var isExist = false

    val higherDate = m.quarterEndDate.minusDays(days)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(histvisit =>
           histroyElement.equalsIgnoreCase(histvisit.getString(1))
            &&
            (
              histvisit.getDateTime(2).isBefore(higherDate)
                ||
                histvisit.getDateTime(2).isEqual(higherDate)
              )
        )

        val argsArray: Array[String] = Array(histroyElement,days.toString)
             measureLogger(visit, m, "wasElementBeforeOrEqualXDaysFromEnd", histroyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        //System.exit(0)
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementValueBeforeWithinXMonths:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    * This Function is used for checking one element Between Calender Unit
    * @param visit current patient visit
    * @param m measure property
    * @param element1 element name
    * @param CalenderUnitTo calender unitTo {YEAR,MONTH,DATE,HOUR,WEEK}
    * @param intervalTo mentioned interval in numbers
    * @param CalenderUnitFrom calender unit FROM {YEAR,MONTH,DATE,HOUR,WEEK}
    * @param intervalFrom mentioned interval in numbers
    * @param patientHistoryList patient history list
    * @return it true when Element between calender Unit
    */


  def wasElementAfterElementBetweenXPeriod(visit: CassandraRow, m: MeasureProperty, element1: String, CalenderUnitTo:String, intervalTo: Int, CalenderUnitFrom:String, intervalFrom: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
            x.getString(1).equalsIgnoreCase(element1)
                && isDateBetween(x.getDateTime(2), lowerCalenderDate(x.getDateTime(2), CalenderUnitFrom, intervalFrom),higherCalenderDate(x.getDateTime(2), CalenderUnitTo, intervalTo)
        ))
      val argsArray: Array[String] = Array(element1, CalenderUnitTo,intervalTo.toString,CalenderUnitFrom.toString,intervalFrom.toString)
      measureLogger(visit, m, "wasElementAfterElementBetweenXPeriod", element1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAdverseEventNotStoppedWithinXHours:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }



  /**
    * This function verifies if the element ends before end of measurement period or ends after start of measurement period
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element to be checked
    * @param calenderUnit calender unit of interval(valida units are YEAR,MONTH,WEEK,DAY,HOUR,MIN)
    * @param interval no of interval to be checked
    * @param operatorType valid operator type are(endsBefore,endsAfter)
    * @param patientHistoryList patient history list
    * @return returns true if the element ends before end of measurement period or ends after start of measurement period  else returns false
    */
  def wasElementEndsOfInXPeriod(visit:CassandraRow,m:MeasureProperty,elementName:String,calenderUnit:String,interval:Int,operatorType:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    var isExist = false

    val (lowerDate,higherDate) = operatorType match{
      case "endsBefore" => (lowerCalenderDate(m.quarterEndDate,calenderUnit,interval),m.quarterEndDate)
      case "endsAfter"=>(m.quarterStartDate,higherCalenderDate(m.quarterStartDate,calenderUnit,interval))
    }

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         elementName.equalsIgnoreCase(x.getString(1))
            && (dateStatus(x.getDateTime(2),lowerDate,"ge") &&
                dateStatus(x.getDateTime(2),higherDate,"lt")
              )
        )

        val argsArray: Array[String] = Array(elementName,interval.toString,calenderUnit,operatorType)
         measureLogger(visit, m, "wasElementEndsOfInXPeriod", elementName, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        //System.exit(0)
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementEndsAfterStartOf:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    * This function verifies if element is after x days of another element with result
    * @param visit current visit of the patient
    * @param m measure propety
    * @param element1 first element
    * @param element2 second element
    * @param resultValue  value that has to be compared
    * @param compareFlag  compare flag (valid flags [lt,gt,le,ge,eq])
    * @param days         number of days that has to be added
    * @param patientHistoryList patient history list
    * @return it will return true if element is after X days of another element with result
    */
  def wasElementAfterElementXDaysWithResult(visit: CassandraRow, m: MeasureProperty, element1: String,element2: String ,resultValue: Double, compareFlag: String,days:Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val higherDate = m.quarterEndDate.plusDays(days)
    try {
      if (patientHistoryList.value.nonEmpty) {

        val endDate = m.quarterEndDate
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(histVisit =>  !histVisit.isNullAt(3)
          && histVisit.getString(1).equalsIgnoreCase(element1)
          &&
          patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
            .exists(y =>
            y.getString(1).equalsIgnoreCase(element2)
            &&
            (
              histVisit.getDateTime(2).isAfter(y.getDateTime(2))
                ||
                histVisit.getDateTime(2).isEqual(y.getDateTime(2))
              )
          )

          &&
          compareValueStatus(histVisit.getDouble(3), compareFlag, resultValue))


        val argsArray: Array[String] = Array( element1,element2, resultValue.toString,compareFlag,days.toString)
         measureLogger(visit, m, "wasElementAfterElementXDaysWithResult", element1, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:dataTypePerformedStartsBeforeEndOfMeasurementPeriodWithValue:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /**
    *
    * @param visit                  patient current visit
    * @param m                  measure property
    * @param elementName2        get element check between
    * @param monthsTo             minus months in in element
    * @param monthsFrom             minus months in in element
    * @param patientHistoryList get patient history list
    * @return it return of Element before end of X in years
    */

  def wasProcedurePerformedBeforeStartBetweenXMonths(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String, monthsforElementName2: Int, monthsTo: Int, monthsFrom: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    // val startDate = m.quarterStartDate
    val lowerDate = m.quarterStartDate.minusMonths(monthsFrom)
    val higherDate = m.quarterStartDate.minusMonths(monthsTo)

      try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>
           x.getString(1).equals(visit.getString(elementName1))
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
            &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
              !y.isNullAt(2)
                && y.getString(1).equals(visit.getString(elementName2))
                &&
                y.getDateTime(2).isBefore(x.getDateTime(2).plusMonths(monthsforElementName2))
            ))

      }
      val argsArray: Array[String] = Array(elementName1, elementName2,monthsforElementName2.toString,monthsTo.toString,monthsFrom.toString)
      measureLogger(visit, m, "wasProcedurePerformedBeforeStartBetweenXMonths", elementName1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }



  def wasProcedurePerformedAfterStartBetweenXMonths(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,calenderUnitforElement2: String,intervalForElement2: Int,calenderUnitFormonthsFrom: String,intervalForMonthFrom: Int ,calenderUnitFormonthsTo: String,intervalForMonthTo: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false


    val lowerDate = lowerCalenderDate(m.quarterStartDate,calenderUnitFormonthsFrom,intervalForMonthFrom)
    val higherDate = lowerCalenderDate(m.quarterStartDate,calenderUnitFormonthsTo,intervalForMonthTo)


    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equals(visit.getString(elementName1))
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
            &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
               y.getString(1).equals(visit.getString(elementName2))
                 &&
               y.getDateTime(2).isAfter(higherCalenderDate(x.getDateTime(2),calenderUnitforElement2,intervalForElement2))



            ))

      }
      val argsArray: Array[String] = Array(elementName1,elementName2,calenderUnitforElement2,intervalForElement2.toString,calenderUnitFormonthsFrom,intervalForMonthFrom.toString,calenderUnitFormonthsTo,intervalForMonthTo.toString)
      measureLogger(visit, m, "wasProcedurePerformedAfterStartBetweenXMonths", elementName1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  def wasElementAfterEncounterBetweenXPeriodes(visit: CassandraRow, m: MeasureProperty, element1: String,element2: String,flag:String,value:Double,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementdate= if (element2.equalsIgnoreCase("encounterdate")) "encounterdate" else element2
    val elementdate1=visit.getDateTime(elementdate)

    try {
      isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x => !x.isNullAt(3) &&
        x.getString(1).equalsIgnoreCase(element1)
        &&
        patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
         y.getDateTime(2).isAfter(elementdate1)
        &&
        isDateBetween(x.getDateTime(2), lowerCalenderDate(y.getDateTime(2), CalenderUnitFrom, intervalFrom),higherCalenderDate(y.getDateTime(2), CalenderUnitTo, intervalTo))
          &&
          compareValueStatus(x.getDouble(3), flag, value)



      ))
      val argsArray: Array[String] = Array(element1, element2,flag,value.toString,intervalTo.toString,CalenderUnitFrom,intervalFrom.toString)
      measureLogger(visit, m, "wasElementAfterEncounterBetweenXPeriodes", "EmergencyVisit", isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAdverseEventNotStoppedWithinXHours:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }

  /**
    * This function verifies if the element starts after end within X period
    * @param visit current patient visit
    * @param m measure property
    * @param currentElementDate current element date
    * @param historyElement history element
    * @param timeCOperator time compare operator (valid operators are ge,le,gt,lt,eq)
    * @param calenderUnit calender unit (valid are YEAR,MONTH,WEEK,DAY,HOUR,MINUTES)
    * @param calenderInterval calender interval in integer
    * @param patientHistoryList patient history list
    * @return returns true if the element starts after end within X period else returns false
    */
  def wasElementStartsAfterEndWithinXPeriod(visit:CassandraRow,m:MeasureProperty,currentElementDate:String,historyElement:String,timeCOperator:String,calenderUnit:String,calenderInterval:Int=0,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    var isExist = false
    val lowerDate=  visit.getDateTime(currentElementDate)
    //lowerCalenderDate(visit.getDateTime(currentElementDate),calenderUnit,calenderInterval)
    val higherDate= higherCalenderDate(visit.getDateTime(currentElementDate),calenderUnit,calenderInterval)
    try {
      if (patientHistoryList.value.nonEmpty) {

        // val endDate: Date = m.quarterEndDate
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(histVisit =>
             histVisit.getString(1).equalsIgnoreCase(historyElement)
            && compareTimeOperator(histVisit.getDateTime(2),lowerDate,higherDate,timeCOperator)
        )

        val argsArray: Array[String] = Array( currentElementDate,historyElement,timeCOperator,calenderUnit,calenderInterval.toString)
         measureLogger(visit, m, "wasElementStartsAfterEndWithinXPeriod", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:dataTypePerformedStartsBeforeEndOfMeasurementPeriodWithValue:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit
    * @param m
    * @param element1
    * @param historyElement
    * @param CalenderUnitTo
    * @param intervalTo
    * @param CalenderUnitFrom
    * @param intervalFrom
    * @param patientHistoryList
    * @return
    */

  def wasElementAfterElementInBetweenXPeriodes(visit: CassandraRow, m: MeasureProperty, element1: String, historyElement: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
      x.getString(1).equalsIgnoreCase(element1)
        &&
        patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
             y.getString(1).equalsIgnoreCase(historyElement)
            && isDateBetween(y.getDateTime(2), lowerCalenderDate(y.getDateTime(2), CalenderUnitFrom, intervalFrom),higherCalenderDate(y.getDateTime(2), CalenderUnitTo, intervalTo)


          )


            )
        )
      val argsArray: Array[String] = Array(element1, historyElement,CalenderUnitTo,CalenderUnitTo.toString,CalenderUnitFrom,intervalFrom.toString)
      measureLogger(visit, m, "wasElementAfterElementInBetweenXPeriodes", element1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAdverseEventNotStoppedWithinXHours:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }


  /**
    * This function verifies if the element starts after end within X period with result
    * @param visit current patient visit
    * @param m measure property
    * @param historyElement history element
    * @param timeCOperator time compare operator (valid operators are ge,le,gt,lt,eq)
    * @param calenderUnit calender unit (valid are YEAR,MONTH,WEEK,DAY,HOUR,MINUTES)
    * @param calenderInterval calender interval in integer
    * @param result result to be checked
    * @param resultCompareFlag result compare flag is used to compare result(le,ge,lt,gt,eq)
    * @param patientHistoryList patient history list
    * @return returns true if the element starts after end within X period  with result else returns false
    */
  def wasElementEndsAfterStartWithinXPeriodWithResult(visit:CassandraRow,m:MeasureProperty,historyElement:String,timeCOperator:String,calenderUnit:String,calenderInterval:Int=0,result:Double,resultCompareFlag:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    var isExist = false
    val lowerDate=  m.quarterStartDate
    val higherDate= higherCalenderDate(m.quarterStartDate,calenderUnit,calenderInterval)
    try {
      if (patientHistoryList.value.nonEmpty) {

        // val endDate: Date = m.quarterEndDate
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(histVisit => !histVisit.isNullAt(3) &&
           histVisit.getString(1).equalsIgnoreCase(historyElement)
            && compareTimeOperator(histVisit.getDateTime(2),lowerDate,higherDate,timeCOperator)
            && compareValueStatus(histVisit.getDouble(3),resultCompareFlag,result)
        )

        val argsArray: Array[String] = Array(historyElement,timeCOperator,calenderUnit,calenderInterval.toString,result.toString,resultCompareFlag.toString)
         measureLogger(visit, m, "wasElementEndsAfterStartWithinXPeriodWithResult", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:dataTypePerformedStartsBeforeEndOfMeasurementPeriodWithValue:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure ment period
    * @param currentElement current element name
    * @param historyElement patient history element name
    * @param CalenderUnit Calender unit e.g. months, years, days etc
    * @param interval specified interval in numbers e.g. 1 , 2 or 3
    * @param patientHistoryList patient history element list
    * @return raturn element after with in periodes
    */

  def wasElementAfterElementInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    val currentElementDate = visit.getDateTime(currentElement+"_date")
    var isExist = false

    try {
      isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
             y.getString(1).equalsIgnoreCase(historyElement)
            && isDateBetween(y.getDateTime(2), currentElementDate,higherCalenderDate(currentElementDate, CalenderUnit, interval)
          )


      )
      val argsArray: Array[String] = Array(currentElement,historyElement,CalenderUnit, interval.toString)
      measureLogger(visit, m, "wasElementAfterElementInXPeriodes", currentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAdverseEventNotStoppedWithinXHours:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }

  /**
    * This function checks if element date with result starts after or concurrent with other element
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param element            element name
    * @param historyElement     history element name
    * @param result result in double to be checked
    * @param resultCompareFlag result compare flag is used to compare element value result
    * @param patientHistoryList patient history list
    * @return returns true if  element date with result starts after or concurrent with other element else returns false
    */
  def isElementStartsAfterOrConcurrentWithStartOfHistoryWithResult(visit: CassandraRow, m: MeasureProperty, element: String, historyElement: String,result:Double,resultCompareFlag:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      val elementDate = if(element.equalsIgnoreCase("encounterdate")) "encounterdate" else element + "_date"
      val elementsNotNull = checkNotNull(visit, element, elementDate)
      if (elementsNotNull && patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(hvisit => !hvisit.isNullAt(3)
          && historyElement.equalsIgnoreCase(hvisit.getString(1))
          && (hvisit.getDateTime(2).isAfter(visit.getDateTime(elementDate)) ||
          hvisit.getDateTime(2).isEqual(visit.getDateTime(elementDate))
          )
          && compareValueStatus(hvisit.getDouble(3),resultCompareFlag,result)
        )
        val argsArray: Array[String] = Array(element, historyElement,result.toString,resultCompareFlag)
       measureLogger(visit, m, "isElementStartsAfterOrConcurrentWithStartOfHistoryWithResult", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementStartsAfterOrConcurrentWithStartOfHistory:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function verifies one mostrecent histElement1 in history overlaps histElement2 in history
    *
    * @param visit              current visit of the patient
    * @param m                  measure property of the measure
    * @param histElement1       first history element
    * @param histElement2       second history element
    * @param patientHistoryList patient history element
    * @return it will return true if first element overlaps second element
    */
  def wasMostRecentElementOverlapsElement(visit: CassandraRow, m: MeasureProperty, histElement1: String, histElement2: String, patientHistoryList: Broadcast[List[CassandraRow]],MostRecentpatientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(x =>  x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(histElement1)
        ).exists(x => MostRecentpatientHistoryList.value.exists(y =>
          y.getString("patientuid").equalsIgnoreCase(x.getString("patientuid"))
            && y.getString(1).equalsIgnoreCase(histElement2)
            &&
            (
              x.getDateTime(2).isBefore(y.getDateTime(2))
                ||
                x.getDateTime(2).isEqual(y.getDateTime(2))
              )
        )
        )
      }
      val argsArray: Array[String] = Array(histElement1, histElement2)
      measureLogger(visit, m, "wasMostRecentElementOverlapsElement", histElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist

  }


  /**
    * This function verifies if element1 with result performed with operator type element2 in history and with X period
    *
    * @param visit              current patient visit
    * @param m                  measure property
    * @param currentElementName    current element name
    * @param historyElement element name
    * @param result             result of element 1 in double
    * @param resultFlag         result flag (valida are ge,gt,lt,le,ge)
    * @param calenderUnit valid calender units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE
    * @param calenderInterval no of interval to be checked
    * @param timeCOperator time operator is compare two elements(valid operators are ge,le,gt,lt,eq)
    * @param patientHistoryList patient history list
    * @return returns true if  if element1 with result performed with operator type element2 in history and with X period else returns false
    */
  def wasElement1WithResultPerformedOperatorTypeElement2InHistoryInXPeriod(visit: CassandraRow, m: MeasureProperty, currentElementName: String, historyElement: String, calenderUnit:String,calenderInterval:Int, result: Double, resultFlag: String,timeCOperator:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val lowerDate= visit.getDateTime(currentElementName+"_date")
    val higherDate= higherCalenderDate(lowerDate,calenderUnit,calenderInterval)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !x.isNullAt(3)
          && x.getString(1).equalsIgnoreCase(historyElement)
          && compareTimeOperator(x.getDateTime(2),lowerDate,higherDate,timeCOperator)
          && compareValueStatus(x.getDouble(3),resultFlag,result)
        )
      }
      val argsArray: Array[String] = Array(currentElementName,historyElement, calenderUnit,calenderInterval.toString, result.toString, resultFlag,timeCOperator)
      measureLogger(visit, m, "wasElement1WithResultPerformedOperatorTypeElement2InHistoryInXPeriod", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }

    isExist

  }




  /**
    * This function verifies first date element is after or equal to another element and before or equal to end of the measurement period.
    * @param visit current visit of the patient
    * @param m measure property
    * @param historyElement element from the history
    * @param firstDateElement first date element
    * @param patientHistoryList patient history list
    * @param firstElementHistoryList first date element history list
    * @return it will return true if  first date element is after or equal to another element and before or equal to end of the measurement period else false.
    */
  def wasElementAfterOrEqualFirstElementDateAndBeforeOrEqualEnd(visit:CassandraRow,m:MeasureProperty,historyElement:String,firstDateElement:String,patientHistoryList:Broadcast[List[CassandraRow]],firstElementHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    var isExist =false
    val higherDate = m.quarterEndDate
    try {
      if (patientHistoryList.value.nonEmpty) {

        val endDate = m.quarterEndDate
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(histVisit =>
            histVisit.getString(1).equalsIgnoreCase(historyElement)
            &&
            firstElementHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
              .exists(y => y.getString(1).equalsIgnoreCase(firstDateElement)
              &&
              isDateBetween(y.getDateTime(2),histVisit.getDateTime(2),higherDate))
        )

        val argsArray: Array[String] = Array(historyElement,firstDateElement)
        measureLogger(visit, m, "wasElementAfterOrEqualFirstElementDateAndBeforeOrEqualEnd", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist

  }

  /**
    * this function verifies whether element is before or after x interval from current
    * @param visit current visit of the patient
    * @param m measure property
    * @param historyElement   history element
    * @param currentElement current element
    * @param interval    number of intervals that has to be added or subtracted according to the conditions
    * @param unit         MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
    * @param patientHistoryList  patient history list
    * @return
    */
  def wasElementBeforeOrEqualXUnitFromCurrent(visit:CassandraRow,m:MeasureProperty,historyElement:String,currentElement:String,interval:Int,unit:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    var isExist =false

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(histVisit =>
            histVisit.getString(1).equalsIgnoreCase(historyElement)
            && isDateBetween(histVisit.getDateTime(2),lowerCalenderDate(visit.getDateTime(currentElement+"_date"),unit,interval),visit.getDateTime(currentElement+"_date"))
        )
        val argsArray: Array[String] = Array(historyElement,historyElement)
            measureLogger(visit, m, "wasElementBeforeOrEqualXUnitFromCurrent", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function verifies first date element is before or equal to first date of the element.
    * @param visit current visit of the patient
    * @param m measure property
    * @param historyElement element from the history
    * @param firstDateElement first date element
    * @param patientHistoryList patient history list
    * @param firstElementHistoryList first date element history list
    * @return it will return true if  first date element is after or equal to another element and before or equal to end of the measurement period else false.
    */
  def wasElementBeforeOrConcurrentWithFirstElementDate(visit:CassandraRow,m:MeasureProperty,historyElement:String,firstDateElement:String,patientHistoryList:Broadcast[List[CassandraRow]],firstElementHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    var isExist =false
    val higherDate = m.quarterEndDate
    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(histVisit =>
            histVisit.getString(1).equalsIgnoreCase(historyElement)
            &&
            firstElementHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
              .exists(y =>
              y.getString(1).equalsIgnoreCase(firstDateElement)
              &&
              (
                histVisit.getDateTime(2).isBefore(y.getDateTime(2))
                  ||
                  histVisit.getDateTime(2).isEqual(y.getDateTime(2))
                )
            )
        )

        val argsArray: Array[String] = Array(historyElement,firstDateElement,historyElement)
         measureLogger(visit, m, "wasElementBeforeOrConcurrentWithFirstElementDate", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist

  }


  /**
    * This function verifies element before X interval with unit from first element date
    * @param visit current visit of the patient
    * @param m measure property
    * @param historyElement history element
    * @param firstDateElement first date
    * @param unit MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
    * @param interval number of intervals
    * @param patientHistoryList patient history list
    * @param firstElementHistoryList first element history list
    * @return
    */

  def wasElementBeforeXUnitWithFirstElementDate(visit:CassandraRow,m:MeasureProperty,historyElement:String,firstDateElement:String,unit:String,interval:Int,patientHistoryList:Broadcast[List[CassandraRow]],firstElementHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    var isExist =false
    val higherDate = m.quarterEndDate
    try {
      if (patientHistoryList.value.nonEmpty) {


        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(histVisit =>
            histVisit.getString(1).equalsIgnoreCase(historyElement)
            &&
            firstElementHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
              .exists(y =>  y.getString(1).equalsIgnoreCase(firstDateElement)
              &&
              isDateBetween(histVisit.getDateTime(2),lowerCalenderDate(y.getDateTime(2),unit,interval),y.getDateTime(2))
            )
        )

        val argsArray: Array[String] = Array(historyElement,firstDateElement,unit,interval.toString)
        measureLogger(visit, m, "wasElementBeforeXUnitWithFirstElementDate", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist

  }

  /**
    * This function verifies if the element ends after  starts of measurement period
    * @param visit current patient visit
    * @param m measure property
    * @param elementName element to be checked in during measurement period
    * @param lowerDateCalenderUnit lower date calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param lowerDateInterval lower calender interval to be checked
    * @param lowerDateTimeCompareOperator time comparator unit (valid units are lt,gt,le,ge,eq )
    * @param higherDateCalenderUnit higher date calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param higherDateInterval higher calender interval to be checked
    * @param higherDateTimeCompareOperator time comparator unit (valid units are lt,gt,le,ge,eq )
    * @param patientHistoryList patient history list
    * @return returns true if the element ends after  starts of measurement period else returns false
    */
  def wasElementEndsAfterStartOfWithinXPeriodInMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, elementName: String,lowerDateCalenderUnit:String, lowerDateInterval: Int,lowerDateTimeCompareOperator:String,higherDateCalenderUnit:String, higherDateInterval: Int,higherDateTimeCompareOperator:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    var isExist = false
    val lowerDate=higherCalenderDate(m.quarterStartDate, lowerDateCalenderUnit, lowerDateInterval)
    val higherDate=higherCalenderDate(m.quarterStartDate, higherDateCalenderUnit, higherDateInterval)
    try {
      isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
        .exists(x =>
       x.getString(1).equalsIgnoreCase(elementName)
        &&
        compareTimeOperator(x.getDateTime(2),lowerDate,higherDate,lowerDateTimeCompareOperator)
        && compareTimeOperator(x.getDateTime(2),lowerDate,higherDate,higherDateTimeCompareOperator)
        )
    val argsArray: Array[String] = Array(elementName, lowerDateCalenderUnit,lowerDateInterval.toString,lowerDateTimeCompareOperator,higherDateCalenderUnit, higherDateInterval.toString,higherDateTimeCompareOperator)
      measureLogger(visit, m, "wasElementEndsAfterStartOfWithinXPeriodInMeasurementPeriod", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAssessmentPerformedEndsAfterAndBeforeWithinXPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }




  /**
    * this function will check whether element present before or equal end of other element
    *
    * @param visit current patient visit
    * @param m measure property
    * @param currentElementName represent current element/encounter date
    * @param historyElement history element name
    * @param patientHistoryList patient history list
    * @return true if element present before or equal end of of other element
    */
  def isElementPresentBeforeOrEqualElement(visit: CassandraRow, m: MeasureProperty, currentElementName: String,historyElement:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementDateTmp=if(!currentElementName.equalsIgnoreCase("encounterdate")) currentElementName+"_date" else currentElementName
    val elementsNotNull= checkNotNull(visit,currentElementName,elementDateTmp)
    try {
      if (elementsNotNull && patientHistoryList.value.nonEmpty) {
        val elementDate= visit.getDateTime(elementDateTmp)
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getString(1).equalsIgnoreCase(historyElement)
          && dateStatus(x.getDateTime(2),elementDate,"le")
        )
      }
      val argsArray: Array[String] = Array(currentElementName,historyElement)
      measureLogger(visit, m, "isElementPresentBeforeOrEqualElement", currentElementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeOrEqualElement:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist;
  }

  /**
    * This function checks if interval between two immunization is equals or greater than provided interval
    * @param visit current patient visit
    * @param m measure property
    * @param dobDate dob of the patient
    * @param immunizationElement2 immunization element2
    * @param immunizationElement1 immunization element1
    * @param firstBirthDay first birth day(ex: 10)
    * @param secondBirthDay second birth day(ex : 13)
    * @param daysGap days gaps to be checks between immunization1 and  immunization2 interval
    * @param patientHistoryList patient history list
    * @return returns true if interval between two immunization is equals or greater than provided interval else returns false
    */
  def isImmunizationIntervalBetweenTwoImmunizationMatchingBetweenTwoBirthdays(visit:CassandraRow,m:MeasureProperty,dobDate:String,immunizationElement1:String,immunizationElement2:String,firstBirthDay:Int,secondBirthDay:Int,daysGap:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    var isExist=false
    val startDate= visit.getDateTime(dobDate).plusYears(firstBirthDay)
    val endDate= visit.getDateTime(dobDate).plusYears(secondBirthDay)
    val immunizationElement1Date=immunizationElement1+"_date"
    val immunizationElement2Date=immunizationElement2+"_date"
    try {
      if (patientHistoryList.value.nonEmpty) {
        val resultPatientList=patientHistoryList.value.filter(histvisit => {
            histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) &&
            ( immunizationElement1.equalsIgnoreCase(histvisit.getString(1))|| immunizationElement2.equalsIgnoreCase(histvisit.getString(1))) &&
            (isDateBetween(histvisit.getDateTime(immunizationElement1Date), startDate, endDate) || isDateBetween(histvisit.getDateTime(immunizationElement2Date), startDate, endDate))
        })

        isExist= !resultPatientList.sliding(2).map { case Seq(x, y, _*) =>
          (y.getString(1).equalsIgnoreCase(immunizationElement2) && x.getString(1).equalsIgnoreCase(immunizationElement1)) &&
          dateStatus(y.getDateTime(2),x.getDateTime(2).plusDays(daysGap),"ge")
        }.exists(_ == false)



        val argsArray: Array[String] = Array(immunizationElement1,dobDate,immunizationElement2,firstBirthDay.toString,secondBirthDay.toString,daysGap.toString)
         measureLogger(visit, m, "isImmunizationIntervalBetweenTwoImmunizationMatchingBetweenTwoBirthdays", immunizationElement2, isExist, argsArray)
      }
    }

    catch {
      case e:Exception=>{
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }



  /**
    * This function verifies element1 is concurrent with element2 and both element after encounterdate with in X interval with unit
    * @param visit current visit of the patient
    * @param m measure property of the measure
    * @param elementName1 first element
    * @param elementName2 second element
    * @param unit  MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
    * @param interval number of intervals
    * @param patientHistoryList patient history list
    * @return
    */
  def wasResultElementAfterEncounterDateWithInXCalender(visit: CassandraRow, m: MeasureProperty, elementName1: String, elementName2: String,unit:String ,interval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(hvisit =>
            !visit.isNullAt("encounterdate")
            && visit.getString("patientuid").equals(hvisit.getString("patientuid"))
            && hvisit.getString(1).equalsIgnoreCase(elementName1)
            && isDateBetween(hvisit.getDateTime(2), visit.getDateTime("encounterdate"),higherCalenderDate(visit.getDateTime("encounterdate"), unit, interval))
        ).exists(hvisit=>
          patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit1 =>
            hvisit1.getString(1).equals(elementName2)
              && isDateBetween(hvisit1.getDateTime(2),  visit.getDateTime("encounterdate"),higherCalenderDate(visit.getDateTime("encounterdate"), unit, interval))
              && hvisit.getDate(2).equals(hvisit1.getDate(2))
          )
        )
      }
      val argsArray: Array[String] = Array(elementName1,elementName2, interval.toString)
      measureLogger(visit, m, "wasResultElementAfterEncounterDateWithInXCalender", elementName1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }



  def wasElementAfterStartWithinXPeriod(visit: CassandraRow, m: MeasureProperty,  historyElement: String, interval: Int, unit: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    // val elementDate = if (elementDate1.equalsIgnoreCase("encounterdate")) "encounterdate" else elementDate1
    val lowerDate = m.quarterStartDate

    val higherDate = higherCalenderDate(m.quarterStartDate, unit, interval)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         x.getString(1).equalsIgnoreCase(historyElement)
         && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
        )
      }
      val argsArray: Array[String] = Array(historyElement,interval.toString, unit)
      measureLogger(visit, m, "wasElementAfterStartWithinXPeriod", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  def wasElementAfterElementWithReasonWithinXPeriod(visit: CassandraRow, m: MeasureProperty, elementDate1: String, historyElement: String,resultElement: String, interval: Int, unit: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementDate = if (elementDate1.equalsIgnoreCase("encounterdate")) "encounterdate" else elementDate1
    val lowerDate = visit.getDateTime(elementDate)

    val higherDate = higherCalenderDate(visit.getDateTime(elementDate), unit, interval)
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
            x.getString(1).equalsIgnoreCase(historyElement)
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
            && patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
              y.getString(1).equalsIgnoreCase(resultElement)
              && x.getDate(2).equals(y.getDate(2))
          )
        )
      }
      val argsArray: Array[String] = Array(historyElement,elementDate1,interval.toString, elementDate,resultElement,unit)
      measureLogger(visit, m, "wasElementAfterElementWithReasonWithinXPeriod", elementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param currentElement element from current row
    * @param Days number of days
    * @param patientHistoryList patient history list
    * @param historyElementName element to be checked before x days from current element in history
    * @return returns true if history element exists before (current element date - X days)
    */
  def wasElementPresentXDaysBeforeOtherElement(visit: CassandraRow, m: MeasureProperty, currentElement: String, Days: Int, patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: Seq[String]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(hvisit =>
          historyElementName.exists(y => hvisit.getString(1).equalsIgnoreCase(y)
          && hvisit.getDateTime(2).isBefore(visit.getDateTime(currentElement + "_date").minusDays(Days))
        )
        )
      }
      val argsArray: Array[String] = Array(historyElementName.toString,currentElement,Days.toString)
      measureLogger(visit, m, "wasElementPresentXDaysBeforeOtherElement", currentElement , isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentXDaysBeforeOtherElement:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function verifies if element with value present before or equal end of other element
    *
    * @param visit current patient visit
    * @param m measure property
    * @param currentElementName represent current element/encounter date
    * @param historyElement history element name
    * @param result result of history element in double to be checked
    * @param resultCompareFlag history element value  to be compared using result flat with specified value
    * @param patientHistoryList patient history list
    * @return returns true if element with value present before or equal end of of other element else returns false
    */
  def isElementPresentBeforeOrEqualElementWithResult(visit: CassandraRow, m: MeasureProperty, currentElementName: String,historyElement:String,result:Double,resultCompareFlag:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementDateTmp=if(!currentElementName.equalsIgnoreCase("encounterdate")) currentElementName+"_date" else currentElementName
    val elementsNotNull= checkNotNull(visit,currentElementName,elementDateTmp)
    try {
      if (elementsNotNull && patientHistoryList.value.nonEmpty) {
        val elementDate= visit.getDateTime(elementDateTmp)
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !x.isNullAt(3) &&
          x.getString(1).equalsIgnoreCase(historyElement)
          && dateStatus(x.getDateTime(2),elementDate,"le")
          && compareValueStatus(x.getDouble(3),resultCompareFlag,result)
        )
      }
      val argsArray: Array[String] = Array(currentElementName,historyElement,result.toString,resultCompareFlag)
      measureLogger(visit, m, "isElementPresentBeforeOrEqualElementWithResult", currentElementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeOrEqualElement:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist;
  }






  /**
    * this function check wheteher two elemnent was equal In History  period
    *
    * @param visit              current visit
    * @param m                  measure property
    * @param historyElement1    history element1
    * @param historyElement2    history element1
    * @param patientHistoryList patient history list
    * @return true if two elemnent was equal during mesasurement period
    */
  def compareTwoElementInHistory(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String, dataType:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equalsIgnoreCase(historyElement1)

            && patientHistoryList.value.exists(y =>  visit.getString("patientuid").equals(y.getString("patientuid"))

            && y.getString(1).equalsIgnoreCase(historyElement2)
            &&
            //&& x.getDateTime(2).isAfter(y.getDateTime(2))

            dataTypeOperator(x.getDateTime(2),y.getDateTime(2) ,dataType)
          )


        )
      }
      val argsArray: Array[String] = Array(historyElement1, historyElement2,dataType)
      measureLogger(visit, m, "compareTwoElementInHistory", historyElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    *
    * @param visit current patient visit
    * @param m measure property
    * @param historyElement1 history element one
    * @param historyElement2 History element two
    * @param TimeOperator    time Operator is used for identified diff between two history date TimeOperator.AFTER, TimeOperator.BEFORE, TimeOperator.EQUAL
    * @param patientHistoryList patient History list for history element
    * @return if diff between two date in History  based on Time operator
    *
    */
  def compareTwoElementDuringMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String, TimeOperator:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val lowerDate = m.quarterStartDate
    val higherDate = m.quarterEndDate

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
            x.getString(1).equalsIgnoreCase(historyElement1)

            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)

            && patientHistoryList.value.exists(y => visit.getString("patientuid").equals(y.getString("patientuid"))

            && y.getString(1).equalsIgnoreCase(historyElement2)

            /*&& isDateBetween(y.getDateTime(2), lowerDate, higherDate)*/
            &&

            dataTypeOperator(x.getDateTime(2),y.getDateTime(2) ,TimeOperator)
          )


        )
      }
      val argsArray: Array[String] = Array(historyElement1, historyElement2,TimeOperator)
      measureLogger(visit, m, "compareTwoElementDuringMeasurementPeriod", historyElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }



 //*****************************************************************************************************************************************


  def getgap(gapList: ListBuffer[(String, (DateTime, DateTime))],gapUnit:String,gap:Int,elementUnit:String,elementStart:String):List[(String,String,Double)]={

    var cummulativeList = new ListBuffer[(String, (DateTime, DateTime))]()

    val xc = gapList.toList.groupBy(_._1).map(r => (r._1,r._2))

    xc.foreach(z =>
    {
      val xs = z._2.toList
      val length = z._2.toList.length
      var last = z._2.toList.tail
      var lastelement2:DateTime = null
      z._2.toList.reverse.take(1).foreach(r => {
        lastelement2 = new DateTime(r._2._2)
      })

      val indexed = xs.zipWithIndex

      var startdate:DateTime = null
      var enddate:DateTime = null
      var count:Int = 0

      z._2.toList.take(1).foreach( r => {
        startdate = new DateTime(r._2._1)
        enddate = new DateTime(r._2._2)
        count=1
      }
      )

      for (xa <- indexed) {

        if(length ==1){
          cummulativeList.append((z._1,(new DateTime(startdate),new DateTime(enddate))))
        }
        if(length > 1) {
          if (count !=1) {

            if (getDatesDifferenceInXUnit(enddate,new DateTime(xa._1._2._1),gapUnit) > gap) {
              cummulativeList.append((z._1,(new DateTime(startdate),new DateTime(enddate))))
              startdate= new DateTime(xa._1._2._1)
              enddate= new DateTime(xa._1._2._2)
            }

            if (getDatesDifferenceInXUnit(enddate,new DateTime(xa._1._2._1),gapUnit) < (gap+1)) {
              enddate = new DateTime(xa._1._2._2)
            }

            if(getDatesDifferenceInXUnit(enddate,new DateTime(xa._1._2._1),gapUnit) <(gap+1) && enddate.equals(lastelement2)){
              cummulativeList.append((z._1,(new DateTime(startdate),new DateTime(enddate))))
            }
          }
          count = count +1
        }
      }
    })

    cummulativeList.toList.map(r => (r._1,elementStart,getDatesDifferenceInXUnit(r._2._1,r._2._2,elementUnit)))

  }
  /**
    * This function verifies whether element is before or equal X unit with interval.
    * @param currentVisit current patient visit
    * @param m            measure property
    * @param element      element name
    * @param elementValue element value
    * @param unit  MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
    * @param interval number of intervals
    * @param compareFlag  compare flag (valid flags [lt,gt,le,ge,eq])
    * @param patientHistoryList patient history list
    * @return returns true if  the data type performed starts before end of measurement period and element result compare with specified value condition else returns false
    */
  def wasValueElementePerformedStartsBeforeOrEqualEndOfMeasurementPeriod(currentVisit: CassandraRow, m: MeasureProperty, element: String, elementValue: Double,unit:String,interval:Int, compareFlag: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val endDate = m.quarterEndDate
    if (patientHistoryList.value.nonEmpty) {
      try {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(currentVisit.getString("patientuid"))).exists(histVisit => (
          isNotNullInhistory(histVisit,"elementvalue")
            && histVisit.getString(1).equalsIgnoreCase(element) &&
            isDateBetween(histVisit.getDateTime(2),lowerCalenderDate(endDate,unit,interval),endDate)
            && compareValueStatus(histVisit.getDouble(3), compareFlag, elementValue))
        )

        val argsArray: Array[String] = Array(element, elementValue.toString,unit,interval.toString, compareFlag)
                measureLogger(currentVisit, m, "wasValueElementePerformedStartsBeforeOrEqualEndOfMeasurementPeriod", element, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:dataTypePerformedStartsBeforeEndOfMeasurementPeriodWithValue:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param patientHistoryList patient history list
    * @param historyElement element to be checked in history
    * @return returns true if element date overlaps measurement period
    */
  def isElementOverlapsMeasurementPeriod(visit: CassandraRow, m: MeasureProperty,patientHistoryList: Broadcast[List[CassandraRow]],historyElement:Seq[String]):Boolean={
    var isExist = false
    try {
       if (patientHistoryList.value.nonEmpty) {
         val endDate = m.quarterEndDate
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => historyElement.exists(y => x.getString(1).equalsIgnoreCase(y)
          && x.getDateTime(2).isBefore(endDate) && visit.getDateTime(historyElement+"_date").equals(endDate)

       )
        )
      }
      val argsArray: Array[String] = Array(historyElement.toString)
      measureLogger(visit, m, "isElementOverlapsMeasurementPeriod", historyElement.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param patientHistoryList patient history list
    * @param historyElements element to be checked in history
    * @return returns true if element date before encounter date (in history table) as well as on encounter date (in tblencounter)
    */
  def isElementOverlapsEncounterDate(visit: CassandraRow, m: MeasureProperty,patientHistoryList: Broadcast[List[CassandraRow]],historyElements:Seq[String]):Boolean={
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(historyRow => historyElements.exists(historyElement => historyRow.getString(1).equalsIgnoreCase(historyElement)
          && historyRow.getDate(2).before(visit.getDate(AdminElements.Encounter_Date)) && visit.getDate(historyElement+"_date").equals(visit.getDate(AdminElements.Encounter_Date))
        )
        )
      }
      val argsArray: Array[String] = Array(historyElements.toString)
      measureLogger(visit, m, "isElementOverlapsEncounterDate", historyElements.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }



  /**
    *
    * @param visit current patient visit
    * @param m measure ment period
    * @param currentElement current element name
    * @param historyElement patient history element name
    * @param CalenderUnit Calender unit e.g. months, years, days etc
    * @param interval specified interval in numbers e.g. 1 , 2 or 3
    * @param patientHistoryList patient history element list
    * @return raturn element Before with in periodes
    */

  def wasElementBeforeElementInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    val currentDate = visit.getDateTime(currentElement+"_date")
    var isExist = false

    try {
      isExist =  patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
        .exists(y =>
          y.getString(1).equalsIgnoreCase(historyElement)
          && isDateBetween(y.getDateTime(2), lowerCalenderDate(currentDate, CalenderUnit, interval), currentDate)
      )
      val argsArray: Array[String] = Array(currentElement, historyElement,CalenderUnit, interval.toString)
      measureLogger(visit, m, "wasElementBeforeElementInXPeriodes", currentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAdverseEventNotStoppedWithinXHours:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }



  /**
    *
    * @param visit current patient visit
    * @param m measure ment period
    * @param currentElement current element name
    * @param historyElement patient history element name
    * @param CalenderUnit Calender unit e.g. months, years, days etc
    * @param interval specified interval in numbers e.g. 1 , 2 or 3
    * @param patientHistoryList patient history element list
    * @return raturn element Before with in periodes
    */

  def wasElementBeforeElementWithReasonInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,reasonElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
        x.getString(1).equalsIgnoreCase(currentElement)
        &&
        patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
            y.getString(1).equalsIgnoreCase(historyElement)
            && isDateBetween(y.getDateTime(2), lowerCalenderDate(x.getDateTime(2), CalenderUnit, interval), x.getDateTime(2))
               &&
            y.getString(1).equalsIgnoreCase(reasonElement)


        )
      )
      val argsArray: Array[String] = Array(currentElement, historyElement,reasonElement: String,CalenderUnit, interval.toString)
      measureLogger(visit, m, "wasElementBeforeElementWithReasonInXPeriodes", currentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAdverseEventNotStoppedWithinXHours:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }



  /**
    * This function verifies if the element starts before end of measurement period within X period
    * @param visit current patient visit
    * @param m measure property
    * @param historyElement element to be checked in measurement period in history
    * @param calenderUnit represent calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param calenderInterval represents no of calender unit to be checked
    * @param timeCompareOperator represents time compare operators (valid operators are CompareOperator.{GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL})
    * @param patientHistoryList patient history list
    * @return returns true if the element starts before end of measurement period within X period else returns false
    */
  def wasElementStartsBeforeEndOfMeasurementPeriodWithinXPeriod(visit: CassandraRow, m: MeasureProperty, historyElement: String,calenderUnit:String, calenderInterval: Int,timeCompareOperator:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
//        val higherDate: DateTime = m.quarterEndDate
        val lowerDate:DateTime= lowerCalenderDate(m.quarterEndDate,calenderUnit,calenderInterval)
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(histRow =>
          historyElement.equalsIgnoreCase(histRow.getString(1))
            && (compareTimeOperator(histRow.getDateTime(2),lowerDate,m.quarterEndDate,timeCompareOperator) &&
          dateStatus(histRow.getDateTime(2),m.quarterEndDate,CompareOperator.LESS)
            )
        )
      }
      val argsArray: Array[String] = Array(historyElement,calenderInterval.toString,timeCompareOperator)
      measureLogger(visit, m, "wasElementStartsBeforeEndOfMeasurementPeriodWithinXPeriod", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementStartsBeforeEndOfMeasurementPeriodWithinXPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }





  /**
    * This function verifies if the element ends after end within X period with result
    * @param visit current patient visit
    * @param m measure property
    * @param currentElementDate current element date
    * @param historyElement history element
    * @param timeCOperator time compare operator (valid operators are ge,le,gt,lt,eq)
    * @param calenderUnit calender unit (valid are YEAR,MONTH,WEEK,DAY,HOUR,MINUTES)
    * @param calenderInterval calender interval in integer
    * @param result result to be checked
    * @param resultCompareFlag result compare flag is used to compare result(le,ge,lt,gt,eq)
    * @param patientHistoryList patient history list
    * @return returns true if the element ends after end within X period  with result else returns false
    */
  def wasElementEndsAfterEndWithinXPeriodWithResult(visit:CassandraRow,m:MeasureProperty,currentElementDate:String,historyElement:String,timeCOperator:String,calenderUnit:String,calenderInterval:Int=0,result:Double,resultCompareFlag:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {

        val lowerDate=  visit.getDateTime(currentElementDate)
        val higherDate= higherCalenderDate(lowerDate,calenderUnit,calenderInterval)

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(histRow =>
           !histRow.isNullAt(3)
            && histRow.getString(1).equalsIgnoreCase(historyElement)
            && compareTimeOperator(histRow.getDateTime(2),lowerDate,higherDate,timeCOperator)
            && compareValueStatus(histRow.getDouble(3),resultCompareFlag,result)
        )

        val argsArray: Array[String] = Array(currentElementDate,historyElement,timeCOperator,calenderUnit,calenderInterval.toString,result.toString,resultCompareFlag )
         measureLogger(visit, m, "wasElementEndsAfterEndWithinXPeriodWithResult", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementEndsAfterEndWithinXPeriodWithResult:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }



  /**
    *
    * @param visit current patient visit
    * @param m measure ment period
    * @param currentElement current element name
    * @param historyElement patient history element name
    * @param CalenderUnit Calender unit e.g. months, years, days etc
    * @param interval specified interval in numbers e.g. 1 , 2 or 3
    * @param patientHistoryList patient history element list
    * @return raturn element after with in periodes
    */

  def wasElementAfterElementWithReasonInXPeriodes(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,historyElement1: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
       x.getString(1).equalsIgnoreCase(historyElement)
        &&
        patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y =>
           y.getString(1).equalsIgnoreCase(historyElement1)
            &&
            y.getString(2).equalsIgnoreCase(x.getString(2))
            && isDateBetween(visit.getDateTime(currentElement), x.getDateTime(2),higherCalenderDate(x.getDateTime(2), CalenderUnit, interval)
          )
        )
      )
      val argsArray: Array[String] = Array(currentElement, historyElement , historyElement1,CalenderUnit, interval.toString)
      measureLogger(visit, m, "wasElementAfterElementWithReasonInXPeriodes", currentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAdverseEventNotStoppedWithinXHours:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }

  def isFirsElementOverlapsEncounterDate(visit: CassandraRow, m: MeasureProperty,leastRecentpatientHistoryList: Broadcast[List[CassandraRow]],historyElements: Seq[String]):Boolean={
    var isExist = false

    try {
      if (leastRecentpatientHistoryList.value.nonEmpty) {
        isExist = leastRecentpatientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => historyElements.exists(historyElement => x.getString(1).equalsIgnoreCase(historyElement)
          && x.getDate(2).before(visit.getDate(AdminElements.Encounter_Date))
          && visit.getDate(historyElement+"_date").equals(visit.getDate(AdminElements.Encounter_Date))
        )
        )

      }
      val argsArray: Array[String] = Array(historyElements.toString)
      measureLogger(visit, m, "isFirsElementOverlapsEncounterDate", historyElements.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }
  /*/**
    *
    * @param visit current row
    * @param m measure property
    * @param leastRecentpatientHistoryList least recent patient history list
    * @param historyElements sequence of history element names (for checking least recent date)
    * @return returns true if any element from sequence of history element names overlaps encounterDate
    */
  def isFirsElementOverlapsEncounterDate(visit: CassandraRow, m: MeasureProperty,leastRecentpatientHistoryList: Broadcast[List[CassandraRow]],historyElements: Seq[String]):Boolean={
    var isExist = false

    try {
      if (leastRecentpatientHistoryList.value.nonEmpty) {
        isExist = leastRecentpatientHistoryList.value.exists(x => isNotNullInhistory(x, "patientuid", 1, 2)
          && x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && historyElements.exists(historyElement => x.getString(1).equalsIgnoreCase(historyElement)
          && x.getDate(2).before(visit.getDate(AdminElements.Encounter_Date))
          && visit.getDate(historyElement+"_date").equals(visit.getDate(AdminElements.Encounter_Date))
        )
        )

      }
      val argsArray: Array[String] = Array(historyElements.toString)
      measureLogger(visit, m, "isFirsElementOverlapsEncounterDate", historyElements.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }
*/

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param historyElement1 element's name (least recent date)
    * @param patientHistoryList patient history list
    * @param leastRecentpatientHistoryList least recent patient history list
    * @param historyElements sequence of elements to be checked in history
    * @return returns true if least recent date of historyElement1 is equal to any of the historyElements (seq) date in history table
    */
  def wasElementFirstDateDuringOtherElementDateInHistory(visit: CassandraRow, m: MeasureProperty,historyElement1: String,patientHistoryList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList: Broadcast[List[CassandraRow]],historyElements: Seq[String]):Boolean={
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(historyRow =>
            leastRecentpatientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(historyRow.getString("patientuid")))
              .exists(x =>
                historyElements.exists(historyElement =>
                  historyRow.getString(1).equalsIgnoreCase(historyElement) &&

                    x.getString(1).equalsIgnoreCase(historyElement1)
                    &&
                    x.getDateTime(historyElement1+"_date").equals(historyRow.getDateTime(historyElement+"_date"))
                )
            )
        )



      }
      val argsArray: Array[String] = Array(historyElement1)
      measureLogger(visit, m, "wasElementFirstDateDuringOtherElementDateInHistory", historyElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    *
    * @param visit current row
    * @param m measure property
    * @param historyElement1 element's name (least recent date)
    * @param patientHistoryList patient history list
    * @param leastRecentpatientHistoryList least recent patient history list
    * @param historyElements sequence of elements to be checked in history
    * @return returns true if least recent date of historyElement1 overlaps any of the historyElements (seq) date in history table
    */
  def wasElementDateOverlapsOtherElementFirstDateInHistory(visit: CassandraRow, m: MeasureProperty,historyElement1: String,patientHistoryList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList: Broadcast[List[CassandraRow]],historyElements: Seq[String]):Boolean={
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(historyRow =>
            leastRecentpatientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(historyRow.getString("patientuid"))).exists(x =>
                historyElements.exists(historyElement =>
                  historyRow.getString(1).equalsIgnoreCase(historyElement) &&

                    x.getString(1).equalsIgnoreCase(historyElement1)
                    &&
                    historyRow.getDateTime(historyElement+"_date").isBefore(x.getDateTime(historyElement1+"_date"))
                    &&
                    x.getDateTime(historyElement1+"_date").equals(historyRow.getDateTime(historyElement+"_date"))
                )
            )
        )



      }
      val argsArray: Array[String] = Array(historyElement1)

      measureLogger(visit, m, "wasElementDateOverlapsOtherElementFirstDateInHistory", historyElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    * This function verifies whether the element was present is in between lower and upper Interval of the current element
    * @param visit current visit of the patient
    * @param currentElementName current visit element
    * @param unit  MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
    * @param lowerInterval number of intervals
    * @param higherInterval number of intervals
    * @param patientHistoryList patient history list
    * @param historyElements history element
    * @return it will return true if element is in between X period else false.
    */
  def wasElementIsInBetweenXPeriod(visit:CassandraRow,m: MeasureProperty,currentElementName:String,unit:String,lowerInterval:Int,higherInterval:Int,patientHistoryList:Broadcast[List[CassandraRow]],historyElements:Seq[String]):Boolean={
    var isExist = false
    val elementDateTmp=if(!currentElementName.equalsIgnoreCase(AdminElements.Encounter_Date)) currentElementName+"_date" else AdminElements.Encounter_Date
    val elementsNotNull= checkNotNull(visit,currentElementName,elementDateTmp)
    if (patientHistoryList.value.nonEmpty ) {
      try {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(histVisit => (
          historyElements.exists(element=>histVisit.getString(1).equalsIgnoreCase(element))
            && isDateBetween(histVisit.getDateTime(2),lowerCalenderDate(visit.getDateTime(elementDateTmp),unit,lowerInterval),higherCalenderDate(visit.getDateTime(elementDateTmp),unit,higherInterval))
          ))
         val argsArray: Array[String] = Array( currentElementName,unit,lowerInterval.toString,higherInterval.toString)
          measureLogger(visit, m, "wasElementIsInBetweenXPeriod", currentElementName, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist
  }

  def compareTwoElementInHistoryInXPeriod(visit: CassandraRow, m: MeasureProperty, historyElement1: String, historyElement2: String,CalendarUnit:String ,interval:Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
            x.getString(1).equalsIgnoreCase(historyElement1)
            && patientHistoryList.value.exists(y => !y.isNullAt(2)

            && visit.getString("patientuid").equals(y.getString("patientuid"))

            && y.getString(1).equalsIgnoreCase(historyElement2)

            && isDateBetween(y.getDateTime(2), lowerCalenderDate(x.getDateTime(2), CalendarUnit, interval), x.getDateTime(2))

          )

        )
      }
      val argsArray: Array[String] = Array(historyElement1, historyElement2,CalendarUnit,interval.toString)
      measureLogger(visit, m, "compareTwoElementInHistoryInXPeriod", historyElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }






  def checkElementCountBeforeElement(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement1: String ,CalendarUnit:String,Interval:Int,count:Int,countFlag:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {

        val totalcount = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).count(x =>
             visit.getString(1).equalsIgnoreCase(historyElement1)
            && x.getDateTime(2).isBefore(lowerCalenderDate(visit.getDateTime(2),CalendarUnit,Interval)))
            isExist = compareValueStatus(totalcount,countFlag,count)

      }
      val argsArray: Array[String] = Array(historyElement1, currentElement,CalendarUnit,Interval.toString,count.toString,countFlag)
      measureLogger(visit, m, "checkElementCountBeforeElement", currentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    *
    * @param visit current row
    * @param m measure property
    * @param leastRecentElements sequence of least recent elements
    * @param patientHistoryList patient history list
    * @param leastRecentpatientHistoryList least recent patient history list
    * @param historyElements sequence of history elements
    * @return returns true if any element from the first sequence (leastRecentElements) is after any element from second sequence (historyElements)
    */
  def wasFirstElementDateAfterOtherElementDateInHistory(visit: CassandraRow, m: MeasureProperty,leastRecentElements: Seq[String],patientHistoryList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList: Broadcast[List[CassandraRow]],historyElements: Seq[String]):Boolean={
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(historyRow =>
            leastRecentpatientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(historyRow.getString("patientuid"))).exists(x =>
              leastRecentElements.exists(leastRecentElement =>
                x.getString(1).equalsIgnoreCase(leastRecentElement)
                  &&
                  historyElements.exists(historyElement =>
                    historyRow.getString(1).equalsIgnoreCase(historyElement)
                      &&
                      x.getDateTime(leastRecentElement+"_date").isAfter(historyRow.getDateTime(historyElement+"_date"))
                      &&
                      x.getDateTime(leastRecentElement+"_date").equals(historyRow.getDateTime(historyElement+"_date"))
                  )
              )
            )
        )

      }
      val argsArray: Array[String] = Array(leastRecentElements.toString,historyElements.toString)
      measureLogger(visit, m, "wasFirstElementDateAfterOtherElementDateInHistory", historyElements.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    * This function gives the list of records between two date range  X intervals from end date
    *
    * @param rdd       rdd of records
    * @param m         measure property
    * @param unit      MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
    * @param interval1 number of intervals(upper interval)
    * @param interval2 number of intervals(lower interval)
    * @param elements  number of elements that has to be verified in the history
    * @return it will return those records that will lie in between two date range  X intervals from end date
    */

  def patientListInXMonthRangeFromEnd(rdd: RDD[CassandraRow], m: MeasureProperty, unit: String, interval1: Int, interval2: Int, elements: String*): List[CassandraRow] = {
    val end_Date = m.quarterEndDate
    rdd.filter(r => elements.exists(Element =>
      (r.getString(1).equalsIgnoreCase(Element)))
      &&
      isDateBetween(r.getDateTime(2), lowerCalenderDate(end_Date, unit, interval1: Int), lowerCalenderDate(end_Date, unit, interval2: Int))).collect().toList
  }


  /**
    * This function verifies the difference of visits in X days
    *
    * @param visit               current visit of the patient
    * @param m         measure property
    * @param days                number of days that has to be added
    * @param patientHistoryList1 first patientHistory list of the patient
    * @param patienthistorylist2 second patienthistory list of the patient
    * @param historyElements     history elements
    * @return
    */
  def wasDifferenceOfVisitinXDays(visit: CassandraRow,m: MeasureProperty, days: Int, patientHistoryList1: Broadcast[List[CassandraRow]], patienthistorylist2: Broadcast[List[CassandraRow]], historyElements: String*): Boolean = {
    var isExist = false
    if (patientHistoryList1.value.nonEmpty && patienthistorylist2.value.nonEmpty) {
      try {
        isExist = patientHistoryList1.value.filter(histVisit => (
        visit.getString("patientuid").equalsIgnoreCase(histVisit.getString("patientuid"))
            && historyElements.exists(element => histVisit.getString(1).equalsIgnoreCase(element))
          )).exists(historyrow => patienthistorylist2.value.exists(histvisit2 => histvisit2.getString("patientuid").equalsIgnoreCase(historyrow.getString("patientuid"))
          && (histvisit2.getDateTime(2).isAfter(historyrow.getDateTime(2).plusDays(days))
          ||
          histvisit2.getDateTime(2).isEqual(historyrow.getDateTime(2).plusDays(days))
          )
        )
        )

         val argsArray: Array[String] = Array(historyElements.toString,days.toString)
          measureLogger(visit, m, "wasDifferenceOfVisitinXDays", historyElements.toString, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist
  }

/*
  /**
    * This function verifies whether the element was present is in between lower and upper Interval of the current element
    *
    * @param visit              current visit of the patient
    * @param m         measure property
    * @param currentElementName current visit element
    * @param unit               MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
    * @param lowerInterval      number of intervals
    * @param higherInterval     number of intervals
    * @param patientHistoryList patient history list
    * @param historyElements    history element
    * @return it will return true if element is in between X period else false.
    */
  def wasElementIsInBetweenXPeriod(visit: CassandraRow,m: MeasureProperty, currentElementName: String, unit: String, lowerInterval: Int, higherInterval: Int, patientHistoryList: Broadcast[List[CassandraRow]], historyElements: Seq[String]): Boolean = {
    var isExist = false
    val elementDateTmp = if (!currentElementName.equalsIgnoreCase(AdminElements.Encounter_Date)) currentElementName + "_date" else AdminElements.Encounter_Date
    val elementsNotNull = checkNotNull(visit, currentElementName, elementDateTmp)
    if (patientHistoryList.value.nonEmpty) {
      try {
        isExist = patientHistoryList.value.exists(histVisit => (
          isNotNullInhistory(histVisit, "patientuid", 1, 2, 3)
            && visit.getString("patientuid").equalsIgnoreCase(histVisit.getString("patientuid"))
            && historyElements.exists(element => histVisit.getString(1).equalsIgnoreCase(element))
            && isDateBetween(histVisit.getDateTime(2), lowerCalenderDate(visit.getDateTime(elementDateTmp), unit, lowerInterval), higherCalenderDate(visit.getDateTime(elementDateTmp), unit, higherInterval))
          ))
         //val argsArray: Array[String] = Array(currentElementName)
         // measureLogger(visit, m, "wasElementIsInBetweenXPeriod", currentElementName, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }

    isExist
  }*/


  /**
    * This function verifies whether element is performed with result before current Element
    * @param visit current visit of the patient
    * @param m measure Property of the measure
    * @param currentElementName current element name
    * @param flag   This flag is used for current element and history element "AFTERorEQUAL","AFTER","Before","BEFOREorEQUAL","EQUAL"
    * @param historyElement1 history element
    * @param historyElement2 history element
    * @param patientHistoryList patient history list
    * @return it will return true if element was present during other element before current element.
    */
  def wasElementPresentDuringOtherElementBeforeCurrentElement(visit: CassandraRow, m: MeasureProperty,currentElementName:String,flag:String,historyElement1: String, historyElement2: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementDateTmp = if (!currentElementName.equalsIgnoreCase(AdminElements.Encounter_Date)) currentElementName + "_date" else AdminElements.Encounter_Date
    val elementsNotNull = checkNotNull(visit, currentElementName, elementDateTmp)
    if (patientHistoryList.value.nonEmpty) {
      try {
        isExist = patientHistoryList.value.filter(x =>
          x.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && x.getString(1).equalsIgnoreCase(historyElement1)
          && dateStatus(x.getDateTime(2),visit.getDateTime(elementDateTmp),flag )
        ).exists(histrow =>
          patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(histrow.getString("patientuid"))).exists(z =>
          histrow.getString(1).equalsIgnoreCase(historyElement2)
              && dateStatus(z.getDateTime(2),visit.getDateTime(elementDateTmp),flag )
              && dateStatus(histrow.getDateTime(2),z.getDateTime(2),flag )
          ))
        val argsArray: Array[String] = Array(currentElementName,historyElement1,historyElement2,flag)
        measureLogger(visit, m, "wasElementPresentDuringOtherElementBeforeCurrentElement", currentElementName, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist
  }

  /**
    * This function verifies the element is present between other element after current element.
    * @param visit current visit of the patient
    * @param m measure Property of the measure
    * @param currentElementName current Element Name
    * @param unit MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
    * @param flag This flag is used for current element and history element "AFTERorEQUAL","AFTER","Before","BEFOREorEQUAL","EQUAL"
    * @param lowerInterval  number of intervals(lower interval)
    * @param higherInterval number of intervals(higher interval)
    * @param historyElement1 first history element
    * @param historyElement2 second history element
    * @param patientHistoryList patient history list
    * @return it will return true if element is present between other element after current element name.
    */
  def wasElementPresentBetweenOtherElementAfterCurrentElement(visit: CassandraRow, m: MeasureProperty,currentElementName:String,unit:String,flag:String,lowerInterval:Int, higherInterval: Int, historyElement1: String, historyElement2: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementDateTmp = if (!currentElementName.equalsIgnoreCase(AdminElements.Encounter_Date)) currentElementName + "_date" else AdminElements.Encounter_Date
    val elementsNotNull = checkNotNull(visit, currentElementName, elementDateTmp)
    if (patientHistoryList.value.nonEmpty) {
      try {
        isExist=patientHistoryList.value.filter(histvisit=>
          histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && histvisit.getString(1).equalsIgnoreCase(historyElement1)
          && isDateBetween(histvisit.getDateTime(2), lowerCalenderDate(visit.getDateTime(elementDateTmp), unit, lowerInterval), higherCalenderDate(visit.getDateTime(elementDateTmp), unit, higherInterval))
        ).exists(histrow =>
          patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(z =>
             histrow.getString(1).equalsIgnoreCase(historyElement2)
              && isDateBetween(z.getDateTime(2), lowerCalenderDate(visit.getDateTime(elementDateTmp), unit, lowerInterval), higherCalenderDate(visit.getDateTime(elementDateTmp), unit, higherInterval))
              && dateStatus(histrow.getDateTime(2),z.getDateTime(2),flag )
          ))
          val argsArray: Array[String] = Array(currentElementName,unit,flag,lowerInterval.toString, higherInterval.toString, historyElement1, historyElement2)
             measureLogger(visit, m, "wasElementPresentBetweenOtherElementAfterCurrentElement", currentElementName, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist
  }





  /**
    * This function verifies if the element starts after  end of  of current element / encounter date
    * @param visit current patient visit
    * @param m measure property
    * @param currentElement represents current element name/ encounter date to be checked in current element
    * @param historyElement represents history element to be checked in history
    * @param lowerDateCalenderUnit lower date calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param lowerDateInterval lower calender interval to be checked
    * @param lowerDateTimeCompareOperator time comparator unit (valid units are {GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL})
    * @param higherDateCalenderUnit higher date calender unit(valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE)
    * @param higherDateInterval higher calender interval to be checked
    * @param higherDateTimeCompareOperator time comparator unit (valid units are CompareOperator.{GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL})
    * @param patientHistoryList patient history list
    * @return returns true if the element starts after  end of  of current element / encounter date else returns false
    */
  def wasElementStartsAfterEndOfWithinXPeriod(visit: CassandraRow, m: MeasureProperty, currentElement:String, historyElement: String, lowerDateCalenderUnit:String, lowerDateInterval: Int, lowerDateTimeCompareOperator:String, higherDateCalenderUnit:String, higherDateInterval: Int, higherDateTimeCompareOperator:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean ={
    var isExist = false
    val elementDate=if(currentElement.equalsIgnoreCase(AdminElements.Encounter_Date)) AdminElements.Encounter_Date else currentElement+"_date"

    try {
      if (checkNotNull(visit,currentElement,elementDate) && patientHistoryList.value.nonEmpty) {
        val lowerDate=visit.getDateTime(elementDate)
        val higherDate=higherCalenderDate(lowerDate, higherDateCalenderUnit, higherDateInterval)

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         x.getString(1).equalsIgnoreCase(historyElement)
          &&
          compareTimeOperator(x.getDateTime(2), lowerDate, higherDate, lowerDateTimeCompareOperator)
          && compareTimeOperator(x.getDateTime(2), lowerDate, higherDate, higherDateTimeCompareOperator)
        )
      }
      val argsArray: Array[String] = Array(currentElement, historyElement,lowerDateCalenderUnit, lowerDateInterval.toString, lowerDateTimeCompareOperator, higherDateCalenderUnit, higherDateInterval.toString, higherDateTimeCompareOperator)
      measureLogger(visit, m, "wasElementStartsAfterEndOfWithinXPeriod", currentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasAssessmentPerformedEndsAfterAndBeforeWithinXPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /** PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param patientHistoryList list of patient history
    * @return true if element is already present before measurement Period Start Date
    */
  def wasElementPresentBeforeStartDate(visit: CassandraRow, m: MeasureProperty,  patientHistoryList: Broadcast[List[CassandraRow]], historyElementName: Seq[String]): Boolean = {

    val startDate = m.quarterStartDate
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
        historyElementName.exists(y => x.getString(1).equalsIgnoreCase(y)
          && x.getDateTime(2).isBefore(startDate))

        )
      }
      val argsArray: Array[String] = Array(historyElementName.toString)
      measureLogger(visit, m, "wasElementPresentBeforeStartDate", historyElementName.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function verifies if element starts before end of other element and elements distinct count is compared with count specified
    * @param currentVisit current patient visit
    * @param m measure property
    * @param currentElement element to be checked in current record
    * @param countValue count value to be compared
    * @param compareFlag used to compare count value with value specified
    * @param patientHistoryList patient history list
    * @param historyElements elements to be checked in history
    * @return returns true if element starts before end of other element and elements distinct count is compared with count specified else returns false
    */
  def countOfElementStartsBeforeEndOfOtherElement(currentVisit: CassandraRow, m: MeasureProperty, currentElement: String, countValue: Double,compareFlag: String, patientHistoryList: Broadcast[List[CassandraRow]],historyElements:Seq[String]): Boolean = {
    var isExist = false
    val currentElementDate= if(currentElement.equalsIgnoreCase(AdminElements.Encounter_Date)) AdminElements.Encounter_Date else currentElement+"_date"
    if (checkNotNull(currentVisit,currentElement,currentElementDate) && patientHistoryList.value.nonEmpty) {
      try {
        val count = patientHistoryList.value.filter(histRow => (
           currentVisit.getString("patientuid").equalsIgnoreCase(histRow.getString("patientuid"))
             && historyElements.exists(
              historyElement=> histRow.getString(1).equalsIgnoreCase(historyElement) &&
             dateStatus(histRow.getDateTime(2),currentVisit.getDateTime(currentElementDate),CompareOperator.LESS)
           )

          )).map(r=>r.getString(1)).distinct.length

        isExist= compareValueStatus(count,compareFlag,countValue)
        val argsArray: Array[String] = Array(historyElements.mkString(","),currentElement, countValue.toString)
               measureLogger(currentVisit, m, "countOfElementStartsBeforeEndOfOtherElement", currentElement, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:countOfElementStartsBeforeEndOfOtherElement:" + e.printStackTrace(), "FAIL")
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param currentElement current element name
    * @param historyElement history element name
    * @param CalenderUnit Calender unit e.g. months, years, days etc
    * @param interval specified interval in numbers e.g. 1 , 2 or 3
    * @param patientHistoryList patient history list
    * @return returns true if history element exists before (current element date - X periods)
    */
  def wasElementPresentInHistoryBeforeXPeriodFromOtherElement(visit: CassandraRow, m: MeasureProperty, currentElement: String, historyElement: String,CalenderUnit:String, interval: Int,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    try {
      isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(historyRow =>
         historyRow.getString(1).equalsIgnoreCase(historyElement)
          &&
          (historyRow.getDateTime(2).isBefore(lowerCalenderDate(visit.getDateTime(currentElement + "_date"), CalenderUnit, interval))
            ||
            historyRow.getDateTime(2).isEqual(lowerCalenderDate(visit.getDateTime(currentElement + "_date"), CalenderUnit, interval)))
      )

      val argsArray: Array[String] = Array(historyElement,currentElement, interval.toString, CalenderUnit.toString)
      measureLogger(visit, m, "wasElementPresentInHistoryBeforeXPeriodFromOtherElement", currentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentInHistoryBeforeXPeriodFromOtherElement:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }

  /**
    * This function verifies the age of the patient on the element date from the patient history table
    * @param visit current visit of the patient
    * @param m measure property of the measure
    * @param historyElement history element
    * @param compareYears age years that has to be compared
    * @param flag CompareOperator from element master
    * @param patientHistoryList history list of the patient
    * @return it will return true if age on the history element is according to compare years else false
    */
  def wasAgeOnHistoryDate(visit: CassandraRow, m: MeasureProperty,historyElement:String,compareYears:Int,flag:String,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    var isExist = false
    try {
      if(patientHistoryList.value.nonEmpty){
        isExist= patientHistoryList.value.filter(histRow =>
             checkNotNull(visit,"dob")  &&
            histRow.getString("patientuid").equals(visit.getString("patientuid")) &&
            histRow.getString(1).equalsIgnoreCase(historyElement))
          .exists(histRow => checkAgeStatus(visit ,histRow,flag,compareYears))
      }
            val argsArray: Array[String] = Array(historyElement,compareYears.toString,flag )
            measureLogger(visit, m, "wasAgeOnHistoryDate", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }

  /**
    *  this function return consecutive list of patient , medication startdate, duration between medication_startdate and medication_enddate
    * @param patientHistoryRDD patient history
    * @param m measure property
    * @param MedicationList Medication list of pair of medication start date and medication end date in form List((medication_start , medication_end))
    * @param MedicationDuration medication duration is the unit like DAY,WEEK in which difference between medication start and end date will be calculated
    * @param CalendarUnit like MONTH,YEAR that will be looked before or after the start of measurement Period
    * @param interval no of CAlenderUnit like 6 Months we want to look back from start of measurement period
    * @param gap no of days that will be ignored between medication end date and medication start date while calculating consecutive logic
    * @param timeOperator during for measuremenet period , "before" and "after" before and after the start of measurement period
    * @return consecutive list of patient , medication startdate, duration between medication_startdate and medication_enddate
    */

  def consecutive(patientHistoryRDD: RDD[CassandraRow], m:MeasureProperty,MedicationList:List[(String,String)],MedicationDuration:String,CalendarUnit: String,interval:Int,gapUnit:String,gap:Int,timeOperator:String): List[(String,String, Double)]= {

    var FinalEndDate:DateTime = null

    def filterDate(visit: CassandraRow, elementDate: String, timeOperator: String): Boolean = {
      var time = false
      if (timeOperator.equalsIgnoreCase("before")) {
        time = isDateBetween(visit.getDateTime(elementDate), lowerCalenderDate(m.quarterStartDate, CalendarUnit, interval), m.quarterStartDate)
      }
      if (timeOperator.equalsIgnoreCase("after")) {
        time = isDateBetween(visit.getDateTime(elementDate), m.quarterStartDate, higherCalenderDate(m.quarterStartDate, CalendarUnit, interval))
      }
      if (timeOperator.equalsIgnoreCase("during")) {
        time = isDateBetween(visit.getDateTime(elementDate), m.quarterStartDate, m.quarterEndDate)
      }
      time
    }

    if(timeOperator.equalsIgnoreCase("before")){
      FinalEndDate = m.quarterStartDate
    }
    if(timeOperator.equalsIgnoreCase("after")){
      FinalEndDate =  higherCalenderDate(m.quarterStartDate, CalendarUnit, interval)
    }
    if(timeOperator.equalsIgnoreCase("during")){
      FinalEndDate = m.quarterEndDate
    }


    var consecutiveList = new ListBuffer[(String, (DateTime, DateTime))]()
    var con = new ListBuffer[List[(String, String ,Double)]]()
    var finallist = new ListBuffer[(String, String ,Double)]()

    MedicationList.foreach(m => {
      var MedicationStartName = m._1
      var MedicationEndName = m._2


      val xc = patientHistoryRDD.filter(x => x.getString(1).equals(MedicationStartName) || x.getString(1).equals(MedicationEndName))
        .filter(a => filterDate(a,"element_date",timeOperator))
        .map(r => (r.getString("patientuid"),(r.getString(1),r.getDate(2).getTime))).groupByKey()
        .map(x => (x._1,x._2.toArray.sortBy(r => r._2))).collect()


      xc.foreach(r => {
        var startdate:DateTime = null
        var startdate2:DateTime = null
        var enddate:DateTime = null

        var last = r._2.toList.tail
        var lastelementType:String = null
        var lastelementdate:DateTime = null
        r._2.toList.reverse.take(1).foreach(r => {
          lastelementType = r._1
          lastelementdate = new DateTime(r._2)
        })

        r._2.foreach(x => {

          if (x._1.contains(MedicationStartName) && startdate == null) {
            startdate = new DateTime(x._2)
          }

          else if (x._1.contains(MedicationStartName) && startdate != null && startdate2 == null) {
            enddate = new DateTime(x._2)
            consecutiveList.append((r._1, (startdate, enddate)))
            startdate=  new DateTime(x._2)
            startdate2 = null
            enddate = null
          }

          else if (x._1.contains(MedicationEndName) && enddate == null  ) {
            enddate = new DateTime(x._2)
            consecutiveList.append((r._1, (startdate, enddate)))
            startdate = null
            enddate = null

          }

          if( x._1.equals(lastelementType) && lastelementType.equals(MedicationStartName) && lastelementdate.equals( new DateTime(x._2))){
            startdate = new DateTime(x._2)
            consecutiveList.append((r._1, (startdate, FinalEndDate)))
          }

        } )
      } )

      con.append(getgap(consecutiveList,gapUnit,gap,MedicationDuration,MedicationStartName))
    }
    )

    con.toList.foreach(x => x.foreach( r=> finallist.append((r._1,r._2,r._3))))

    finallist.toList

  }

  /**
    *
    * this function return cUMULATIVE list of patient , medication startdate, sum of duration between medication_startdate and medication_enddate
    * @param patientHistoryRDD patient history RDD
    * @param m measure property
    * @param MedicationList Medication list of pair of medication start date and medication end date in form List((medication_start , medication_end))
    * @param MedicationDuration medication duration is the unit like DAY,WEEK in which difference between medication start and end date will be calculated
    * @param CalendarUnit like MONTH,YEAR that will be looked before or after the start of measurement Period
    * @param interval  no of CalenderUnit like 6 Months we want to look back from start of measurement period
    * @param timeOperator during for measuremenet period , "before" and "after" before and after the start of measurement period
    * @return list of patient , medication startdate, duration between medication_startdate and medication_enddate
    */
  def cumulative(patientHistoryRDD: RDD[CassandraRow], m:MeasureProperty,MedicationList:List[(String,String)],MedicationDuration:String,CalendarUnit: String,interval:Int,timeOperator:String): List[(String,String, Double)]= {

    var FinalEndDate:DateTime = null

    def filterDate(visit: CassandraRow, elementDate: String, timeOperator: String): Boolean = {
      var time = false
      if (timeOperator.equalsIgnoreCase("before")) {
        time = isDateBetween(visit.getDateTime(elementDate), lowerCalenderDate(m.quarterStartDate, CalendarUnit, interval), m.quarterStartDate)
      }
      if (timeOperator.equalsIgnoreCase("after")) {
        time = isDateBetween(visit.getDateTime(elementDate), m.quarterStartDate, higherCalenderDate(m.quarterStartDate, CalendarUnit, interval))
      }
      if (timeOperator.equalsIgnoreCase("during")) {
        time = isDateBetween(visit.getDateTime(elementDate), m.quarterStartDate, m.quarterEndDate)
      }
      time
    }

    if(timeOperator.equalsIgnoreCase("before")){
      FinalEndDate = m.quarterStartDate
    }
    if(timeOperator.equalsIgnoreCase("after")){
      FinalEndDate =  higherCalenderDate(m.quarterStartDate, CalendarUnit, interval)
    }
    if(timeOperator.equalsIgnoreCase("during")){
      FinalEndDate = m.quarterEndDate
    }

    var cumulativeList = new ListBuffer[((String,String), (DateTime, DateTime))]()


    MedicationList.foreach(m => {
      var MedicationStartName = m._1
      var MedicationEndName = m._2

      val xc = patientHistoryRDD.filter(x => filterDate(x,"element_date",timeOperator) &&
        (x.getString(1).equals(MedicationStartName) || x.getString(1).equals(MedicationEndName)))
        .map(r => (r.getString("patientuid"),(r.getString(1),r.getDate(2).getTime))).groupByKey()
        .map(x => (x._1,x._2.toArray.sortBy(r => r._2))).collect()

      xc.foreach(r => {

        var startdate:DateTime = null
        var startdate2:DateTime = null
        var enddate:DateTime = null

        var last = r._2.toList.tail
        var lastelementType:String = null
        var lastelementdate:DateTime = null
        r._2.toList.reverse.take(1).foreach(r => {
          lastelementType = r._1
          lastelementdate = new DateTime(r._2)
        })

        r._2.foreach(x => {

          if (x._1.contains(MedicationStartName) && startdate == null) {
            startdate = new DateTime(x._2)
          }

          else if (x._1.contains(MedicationStartName) && startdate != null && startdate2 == null) {
            enddate = new DateTime(x._2)
            cumulativeList.append(((r._1,MedicationStartName), (startdate, enddate)))
            startdate=  new DateTime(x._2)
            startdate2 = null
            enddate = null
          }

          else if (x._1.contains(MedicationEndName) && enddate == null  ) {
            enddate = new DateTime(x._2)
            cumulativeList.append(((r._1,MedicationStartName), (startdate, enddate)))
            startdate = null
            enddate = null
          }

          if( x._1.equals(lastelementType) && lastelementType.equals(MedicationStartName) && lastelementdate.equals( new DateTime(x._2))){
            startdate = new DateTime(x._2)
            cumulativeList.append(((r._1,MedicationStartName) ,(startdate, FinalEndDate)))
          }

        } )
      } )


    })

    val conn = cumulativeList.map(r => (r._1, getDatesDifferenceInXUnit(r._2._1, r._2._2, MedicationDuration))).toList.groupBy(r => r._1).mapValues(_.map(_._2).reduce(_ + _))
    conn.map(r => (r._1._1,r._1._2,r._2)).toList


  }


  /**
    *
    * @param visit current row
    * @param m measure property
    * @param historyElement1 element's name (least recent date)
    * @param patientHistoryList patient history list
    * @param leastRecentpatientHistoryList least recent patient history list
    * @param historyElements sequence of elements to be checked in history
    * @return returns true if least recent date of historyElement1 is after or equal to any of the historyElements (seq) date in history table
    */
  def wasFirstElementDateAfterOtherElementDateInHistory(visit: CassandraRow, m: MeasureProperty,historyElement1: String,patientHistoryList:Broadcast[List[CassandraRow]],leastRecentpatientHistoryList: Broadcast[List[CassandraRow]],historyElements: Seq[String]):Boolean={
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(historyRow =>
             leastRecentpatientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(historyRow.getString("patientuid"))).exists(x =>
                 historyElements.exists(historyElement =>
                  historyRow.getString(1).equalsIgnoreCase(historyElement) &&
                    x.getString(1).equalsIgnoreCase(historyElement1)
                    &&
                    (x.getDateTime(historyElement1+"_date").isAfter(historyRow.getDateTime(historyElement+"_date"))
                      ||
                      x.getDateTime(historyElement1+"_date").isEqual(historyRow.getDateTime(historyElement+"_date")))
                )
            )
        )



      }
      val argsArray: Array[String] = Array(historyElement1,historyElements.toString)
      measureLogger(visit, m, "wasFirstElementDateAfterOtherElementDateInHistory", historyElement1, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }


  /**
    * This function gives the patientuid and count
    * @param patientHistoryList patienthistory list
    * @param element1 first history element
    * @param element2 second history element
    * @return
    */
  def countElementEqualTwoDate(patientHistoryList: Broadcast[List[CassandraRow]],element1:String,element2:String):List[(String,Int)]={
    patientHistoryList.value.filter(row=>
      row.getString(1).equalsIgnoreCase(element1)
    ).filter(r=>patientHistoryList.value.exists(row=>row.getString("patientuid").equalsIgnoreCase(r.getString("patientuid"))
      && row.getString(1).equalsIgnoreCase(element2)
      && row.getDateTime(2).isEqual(r.getDateTime(2))
    )).groupBy(r=>r.getString("patientuid")).mapValues(_.size).toList
  }

  /**
    * This function is used for to checking Eye element value before or after encounter
    * @param visit current patient visit
    * @param m measure property
    * @param currentElement current eye element name
    * @param histroyElement history eye element name
    * @param lowerCalenderUnit lower calender unit for month, days, year etc
    * @param lowerInterval lower interval value
    * @param higherCalenderUnit highet calender unit for month, days, year etc
    * @param HigherInterval higher interval value
    * @param valueDifference specified eye value diff
    * @param patientHistoryList eye patient history list
    * @return return id eye before and after value of encounter
    */


  def CheckEyeElementValueDiffInBeforeAndAfterEncounter(visit: CassandraRow, m: MeasureProperty, currentElement:String,histroyElement: String, lowerCalenderUnit: String,lowerInterval: Int,higherCalenderUnit: String,HigherInterval: Int, valueDifference:Double, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val elementDate= if (currentElement.equalsIgnoreCase(AdminElements.Encounter_Date)) visit.getDateTime(AdminElements.Encounter_Date) else visit.getDateTime(currentElement+"_date")

    try {
      if (patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !x.isNullAt(3) &&
        histroyElement.equalsIgnoreCase(x.getString(1))
            && isDateBetween(x.getDateTime(2), lowerCalenderDate(elementDate, lowerCalenderUnit, lowerInterval), higherCalenderDate(elementDate, higherCalenderUnit, HigherInterval))
            &&
            patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(y => !y.isNullAt(3) &&
             y.getDateTime(2).isBefore(elementDate)
            && math.abs(x.getDouble(3) - y.getDouble(3)) > valueDifference

        )
            )


        val argsArray: Array[String] = Array(currentElement.toString,histroyElement,lowerCalenderUnit,lowerInterval.toString,higherCalenderUnit,HigherInterval.toString, valueDifference.toString)
        measureLogger(visit, m, "CheckEyeElementValueDiffInBeforeAndAfterEncounter", currentElement.toString, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        //System.exit(0)
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:CheckEyeElementValueDiffInBeforeAndAfterEncounter:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param historyElement element to be checked in history
    * @param patientHistoryList patient history list
    * @return returns true if element exists before start date of measurement period
    */
  def wasElementPresentBeforeStartOfMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, historyElement: String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val measurementPeriodStartDate = m.quarterStartDate
    try {
      isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(historyRow =>
         historyRow.getString(1).equalsIgnoreCase(historyElement)
          &&
          historyRow.getDateTime(2).isBefore(measurementPeriodStartDate)
      )

      val argsArray: Array[String] = Array(historyElement)
      measureLogger(visit, m, "wasElementPresentBeforeStartOfMeasurementPeriod",historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentBeforeStartOfMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }


  /**
    * PARENT function
    * This function verifies if element was after element date within X period
    * @param visit              current visit
    * @param m                  measure property
    * @param elementName        get element check between
    * @param calenderInterval   no of calender units to be looked after
    * @param calenderUnit  represents calender unit(valid units are  YEAR,MONTH,WEEK,DAY,MINUTES,HOUR)
    * @param CompareOperator valid operators are (LESS,LESS_EQUAL,GREATER,GREATER_EQUAL,EQUAL)
    * @param patientHistoryList  patient history list
    * @return returns true if element was after element date within X period else returns false
    */
  def wasElementAfterElementDateWithinXPeriod(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String, calenderUnit:String, calenderInterval: Int, CompareOperator:String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val elementDate= if(elementName.equalsIgnoreCase(AdminElements.Encounter_Date)) AdminElements.Encounter_Date else if(elementName.equalsIgnoreCase(AdminElements.Date_of_Birth)) AdminElements.Date_of_Birth  else elementName+"_date"


    try {
      if (checkNotNull(visit,elementName,elementDate) && patientHistoryList.value.nonEmpty) {
        val lowerDate = visit.getDateTime(elementDate)
        val higherDate = higherCalenderDate(lowerDate,calenderUnit,calenderInterval)
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
         x.getString(1).equalsIgnoreCase(historyElementName)
            && compareTimeOperator(x.getDateTime(2), lowerDate, higherDate,CompareOperator)
            )

      }
      val argsArray: Array[String] = Array(elementName,historyElementName,calenderUnit,calenderInterval.toString, elementDate,CompareOperator)
      measureLogger(visit, m, "wasElementAfterElementDateWithinXPeriod", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }




  /**
    * This function verifies the age of the patient on the element date from the patient history table
    * @param visit current visit of the patient
    * @param m measure property of the measure
    * @param historyElement history element
    * @param CalenderUnit mentioned Calender Unit [YEAR,MONTH,DAY]
    * @param CalenderInterval calender Unit Interval in number
    * @param CompareOperator compare operator [GREATER,LESS,GREATER_EQUAL,LESS_EQUAL]
    * @param compareYears compare years in numbers
    * @param patientHistoryList patient history list
    * @return it will return true if age on the history element is according to compare years else false
    */
  def wasAgeBeforeXPeriod(visit: CassandraRow, m: MeasureProperty,historyElement:String,CalenderUnit:String,CalenderInterval:Int,CompareOperator:String,compareYears:Int,patientHistoryList: Broadcast[List[CassandraRow]]):Boolean= {
    var isExist = false
    try {
      if(patientHistoryList.value.nonEmpty){
        val endDate = m.quarterEndDate
        isExist= patientHistoryList.value.filter(histRow =>
             checkNotNull(visit,"dob")  &&
            histRow.getString("patientuid").equals(visit.getString("patientuid")) &&
            histRow.getString(1).equalsIgnoreCase(historyElement) &&
            endDate.isBefore(lowerCalenderDate(histRow.getDateTime(2), CalenderUnit, CalenderInterval))

        )
          .exists(histRow => checkAgeStatus(visit ,histRow,CompareOperator,compareYears))
      }
            val argsArray: Array[String] = Array(historyElement,CalenderUnit,CalenderInterval.toString,CompareOperator,compareYears.toString)
            measureLogger(visit, m, "wasAgeBeforeXPeriod", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }




  /**
    * This function returns patient records records between two periods
    *
    * @param patientRDD patient  RDD
    * @param m                 measurement period
    * @param calenderUnit valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE
    * @param calenderInterval no of calender units to be checked
    * @param calculateOnStartDate if true upper date will be calculated on m.quarterStartDate else on quarterEndDate
    * @return patient records between two period
    */
  def getPatientRDDBetweenPeriodsInMeasurementPeriod(patientRDD: RDD[CassandraRow], m: MeasureProperty,calenderUnit:String,calenderInterval:Int,calculateOnStartDate:Boolean): RDD[CassandraRow] = {

    val (startDate,endDate)= calculateOnStartDate match{
      case true=> (m.quarterStartDate,higherCalenderDate(m.quarterStartDate,calenderUnit,calenderInterval))
      case false=> (m.quarterStartDate,lowerCalenderDate(m.quarterEndDate,calenderUnit,calenderInterval))
    }

    patientRDD.filter(visit=> !visit.isNullAt(AdminElements.Encounter_Date) && isDateBetween(visit.getDateTime(AdminElements.Encounter_Date),startDate,endDate))
  }


  /**
    * This Function verifies the physical exam performed of patient for Retinal Dilated.
    *
    * @param visit                  current visit of the patient.
    * @param m                      Measure Property of the measure.
    * @param element                Element that has to be verified in the history.
    * @param resultElement          result element that has to be concurrent with element
    * @param NoOfMonth              No of months that has to be go back from start date.
    * @param comperatorOperator     comperator operator that has to be compared.
    * @param HistoryList            Patient History List.
    * @return it will return those element is performed in a range between start of the measurement period and start date minus no. of months and concurrent with result.
    */
  def wasElementXPeriodConcurrentWithResult(visit: CassandraRow, m: MeasureProperty, element: String, resultElement:String, NoOfMonth: Int,comperatorOperator:String,flag:String, HistoryList: Broadcast[List[CassandraRow]]): Boolean = {

    var isExist = false
//    val startDate = m.quarterStartDate
    try {
      if (HistoryList.value.nonEmpty) {
        isExist = HistoryList.value.filter(histvisit =>  histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && histvisit.getString(1).equalsIgnoreCase(element)
          && compareTimeOperator(histvisit.getDateTime(2),m.quarterStartDate.minusMonths(NoOfMonth),m.quarterStartDate,comperatorOperator)
        ).exists(row=>HistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(row.getString("patientuid")))
          .exists(histvisit=>
          histvisit.getString(1).equalsIgnoreCase(resultElement)
          && compareTimeOperator(histvisit.getDateTime(2),m.quarterStartDate.minusMonths(NoOfMonth),m.quarterStartDate,comperatorOperator)
          && dateStatus(histvisit.getDateTime(2),row.getDateTime(2),flag)
        )
        )
      }
      val argsArray: Array[String] = Array(element, NoOfMonth.toString,resultElement)
      measureLogger(visit, m, "wasElementXPeriodConcurrentWithResult", element, isExist, argsArray)
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }

    isExist
  }


  /**
    * This function verifies element before start Date with X period.
    *
    * @param visit              current visit of the patient
    * @param m                  measure property of the measure
    * @param element            element that has to be verified in history.
    * @param interval           number of years that has to be subtracted from start date.
    * @param flag               flag that will define the condition whether to check greater or greaterEqualto condition.
    * @param unit               valid units are YEAR,MONTH,WEEK,DAY,HOUR,MINUTE
    * @param patientHistoryList patient history list
    * @return it will return true if element is before start date with  X period.
    */
  def wasElementBeforeStartDateXPeriod(visit: CassandraRow, m: MeasureProperty, element: String, interval: Int,unit:String,flag:String,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
//    val startDate = m.quarterStartDate
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(histvisit =>   histvisit.getString(1).equalsIgnoreCase(element)
          && dateStatus(histvisit.getDateTime(2),lowerCalenderDate(m.quarterStartDate,unit,interval),flag)
        )
      }
      val argsArray: Array[String] = Array(element, interval.toString)
      measureLogger(visit, m, "wasElementBeforeStartDateXPeriod", element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  def wasElementPresentBetweenOtherElementBeforeCurrentElement(visit: CassandraRow, m: MeasureProperty,currentElementName:String,unit:String,flag:String,lowerInterval:Int, higherInterval: Int, historyElement1: String, historyElement2: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    val elementDateTmp = if (!currentElementName.equalsIgnoreCase(AdminElements.Encounter_Date)) currentElementName + "_date" else AdminElements.Encounter_Date
    if (checkNotNull(visit, currentElementName, elementDateTmp) && patientHistoryList.value.nonEmpty) {
      try {
        isExist=patientHistoryList.value.filter(histvisit=>
          histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
          && histvisit.getString(1).equalsIgnoreCase(historyElement1)
          && isDateBetween(histvisit.getDateTime(2), lowerCalenderDate(visit.getDateTime(elementDateTmp), unit, lowerInterval), higherCalenderDate(visit.getDateTime(elementDateTmp), unit, higherInterval))
        ).exists(histrow =>
          patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(histrow.getString("patientuid")))
            .exists(z =>
             histrow.getString(1).equalsIgnoreCase(historyElement2)
              && isDateBetween(z.getDateTime(2), lowerCalenderDate(visit.getDateTime(elementDateTmp), unit, lowerInterval), higherCalenderDate(visit.getDateTime(elementDateTmp), unit, higherInterval))
              && dateStatus(histrow.getDateTime(2),z.getDateTime(2),flag )
          ))
        val argsArray: Array[String] = Array(historyElement1)
        measureLogger(visit, m, "wasElementPresentBetweenOtherElementBeforeCurrentElement", historyElement1, isExist, argsArray)
      }
      catch {
        case e: Exception => {
          loggerObj.error(e.getMessage)
          //System.exit(0)
        }
      }
    }
    isExist
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param element1 most recent element (test) during measurement period
    * @param element2 element (result value) during measurement period
    * @param value value to be compared
    * @param flag comparator flag
    * @param mostRecentPatientHistoryList most recent patient history list
    * @param patientHistoryList patient history list
    * @return returns true if most recent date of element1 exists during measurement period with value of element2 as per value parameter and flag passed as parameters
    */
  def isMostRecentResultValueDuringMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, element1: String, element2: String, value: Double, flag:String, mostRecentPatientHistoryList: Broadcast[List[CassandraRow]], patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {

//    val measurementPeriodStartDate =m.quarterStartDate
//    val measurementPeriodEndDate = m.quarterEndDate
    var isExist = false
    try {
      isExist = mostRecentPatientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
           x.getString(1).equalsIgnoreCase(element1)
          && isDateBetween(x.getDateTime(2),m.quarterStartDate,m.quarterEndDate)

          && patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
             .exists(y => !y.isNullAt(3) &&
           y.getString(1).equalsIgnoreCase(element2)
            && y.getDateTime(2).isEqual(x.getDateTime(2))
            && compareValueStatus(y.getDouble(3), flag, value))
      )

      val argsArray: Array[String] = Array(element1, element2, value.toString)
      measureLogger(visit, m, "isMostRecentResultValueDuringMeasurementPeriod", value.toString, isExist, argsArray)


    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isMostRecentResultValueDuringMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }




/*  def test(visit: CassandraRow, m: MeasureProperty, checkBeforeElement: Boolean, elementEyeName: String, patientHistoryList: Broadcast[List[CassandraRow]], compareEyeElementNames: Seq[String]): Boolean = {
    val eyeCondCriterias1 = Array(3, 4)
    val eyeCondCriterias2 = Array(1, 2, 3, 4)

    def returnEyeValue(element: String): Any = {
      val filterRecord:Any = checkBeforeElement match {
        case true => patientHistoryList.value.filter(histRow => {
          histRow.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) &&
            histRow.getString(1).equalsIgnoreCase(element) &&
            histRow.getDateTime(2).isBefore(visit.getDateTime(2))
        }).lastOption.getOrElse("")
        case false => patientHistoryList.value.filter(histRow => {
          histRow.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) &&
            histRow.getString(1).equalsIgnoreCase(element) &&
            histRow.getDateTime(2).isAfter(visit.getDateTime(2))
        }).headOption.getOrElse("")

      }
      if (filterRecord.isInstanceOf[CassandraRow]) filterRecord.asInstanceOf[CassandraRow].getString(3).toInt else null
    }

    val ippEye1 = if (visit.isNullAt(elementEyeName)) null else visit.getString(elementEyeName).toInt

    compareEyeElementNames.forall(eye => {
      val conditionEye = returnEyeValue(eye)
      (conditionEye == ippEye1) || (eyeCondCriterias1.contains(conditionEye) && eyeCondCriterias2.contains(ippEye1)) || (eyeCondCriterias2.contains(conditionEye) && eyeCondCriterias1.contains(ippEye1)) || conditionEye == null || ippEye1 == null
    })

  }*/



  def wasElementPresentBeforeFirstAndAfterMostElementInHistory(visit: CassandraRow, m: MeasureProperty, eyeElement:String,patientHistoryList: Broadcast[List[CassandraRow]],leastRecentList: Broadcast[List[CassandraRow]],mostRecentList: Broadcast[List[CassandraRow]]): Boolean = {
    val eyeCondCriterias1 = Array(3, 4)
    val eyeCondCriterias2 = Array(1, 2, 3, 4)

    var isExist = false
    val measurementPeriodStartDate = m.quarterStartDate
    try {
      isExist = patientHistoryList.value.exists(historyRow => !historyRow.isNullAt(3) &&
          visit.getString("patientuid").equalsIgnoreCase(historyRow.getString("patientuid"))
          &&
          historyRow.getString(1).equalsIgnoreCase(eyeElement)
           &&
          patientHistoryList.value.exists(historyRow1 =>
          visit.getString("patientuid").equalsIgnoreCase(historyRow1.getString("patientuid"))
          &&
          historyRow1.getString(1).equalsIgnoreCase(eyeElement)
          &&
          leastRecentList.value.exists(leastRow=> !leastRow.isNullAt(3) &&
            leastRow.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
            &&
              visit.getDateTime(2).isBefore(leastRow.getDateTime(2))
             &&
              mostRecentList.value.exists(mostRow=>
                mostRow.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))
              &&
              visit.getDateTime(2).isAfter(mostRow.getDateTime(2))
              &&
              (
                (eyeCondCriterias1.contains(leastRow.getString(3)) && eyeCondCriterias2.contains(historyRow.getString(3)))
                  || (eyeCondCriterias2.contains(leastRow.getString(3)) && eyeCondCriterias1.contains(historyRow.getString(3)))
                  || leastRow.isNullAt(3) || historyRow.isNullAt(3)
              )
               &&
                 (
                   (eyeCondCriterias1.contains(mostRow.getString(3)) && eyeCondCriterias2.contains(historyRow.getString(3)))
                    || (eyeCondCriterias2.contains(mostRow.getString(3)) && eyeCondCriterias1.contains(historyRow.getString(3)))
                    || leastRow.isNullAt(3) || historyRow.isNullAt(3)

                 ))

       )
      ) )

      val argsArray: Array[String] = Array(eyeElement)
      measureLogger(visit, m, "wasElementPresentBeforeStartOfMeasurementPeriod",eyeElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentBeforeStartOfMeasurementPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist

  }

/*
  /**
    * This function verifies if the on encounter eye element is  is similar with other eye element
    *
    * @param visit                  current patient visit
    * @param m                      measure property
    * @param elementEyeName         eye element to be verified
    * @param patientHistoryList      patient history list
    * @param compareEyeElementNames compared eye element names
    * @return returns true if the on encounter eye element is  is similar with other eye element else returns false
    */
def checkEyeOnEncounterEqualsWithOtherEye(visit: CassandraRow, m: MeasureProperty, elementEyeName: String, patientHistoryList: Broadcast[List[CassandraRow]], compareEyeElementNames: Seq[String]): Boolean ={
  val eyeCondCriterias1 = Array(3, 4)
  val eyeCondCriterias2 = Array(1, 2, 3, 4)

  def returnEyeValue(element: String): Any = {
    val filterRecord:Any = patientHistoryList.value.filter(histRow => {
      histRow.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")) &&
        histRow.getString(1).equalsIgnoreCase(element) &&
        histRow.getDateTime(2).isBefore(visit.getDateTime(2))
    }).lastOption.getOrElse("")

    if (filterRecord.isInstanceOf[CassandraRow]) filterRecord.asInstanceOf[CassandraRow].getString(3).toInt else null
  }

  val ippEye1 = if (visit.isNullAt(elementEyeName)) null else visit.getString(elementEyeName).toInt

  compareEyeElementNames.forall(eye => {
    val conditionEye = returnEyeValue(eye)
    (conditionEye == ippEye1) || (eyeCondCriterias1.contains(conditionEye) && eyeCondCriterias2.contains(ippEye1)) || (eyeCondCriterias2.contains(conditionEye) && eyeCondCriterias1.contains(ippEye1)) || conditionEye == null || ippEye1 == null
  })
}
*/

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param elementName element names to checked after start date
    * @param patientHistoryList patient history list
    * @return returns true if element exists after start date
    */
  def wasElementPresentAfterStartDate(visit: CassandraRow, m: MeasureProperty, elementName: String, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getString("element").equalsIgnoreCase(elementName)
          &&
          x.getDateTime("element_date").isAfter(m.quarterStartDate)
        )

      }
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "wasElementPresentAfterStartDate", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentBeforeOrEqualEncounter:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        System.exit(0)
      }
    }
    isExist
  }

  /**
    *
    * @param visit current row
    * @param m measure property
    * @param procedureInHistory procedure to be checked in history
    * @param patientHistoryList patient history list
    * @param currentProcedures procedures from current visit
    * @return returns true if procedureInHistory exists before any of currentProcedures
    */
  def wasProcedurePerformedBeforeOtherProcedures(visit: CassandraRow, m: MeasureProperty, procedureInHistory: String, patientHistoryList: Broadcast[List[CassandraRow]], currentProcedures: Seq[String]): Boolean = {

    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
          x.getString("element").equalsIgnoreCase(procedureInHistory)
          && currentProcedures.exists(y => dateStatus(x.getDateTime("element_date"),visit.getDateTime(y+"date"),CompareOperator.LESS_EQUAL))

        )
      }
      val argsArray: Array[String] = Array(procedureInHistory, currentProcedures.toString)
      measureLogger(visit, m, "wasProcedurePerformedBeforeOtherProcedures", procedureInHistory, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasProcedurePerformedBeforeOtherProcedures:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function verifies element is before X period of current element
    * @param visit current visit of the patient.
    * @param m measure property
    * @param flag This flag is used for current element and history element "AFTERorEQUAL","AFTER","Before","BEFOREorEQUAL","EQUAL"
    * @param currentElement current element that has to be compared with history element
    * @param numberDays number of days that has to be add in the current element
    * @param patientHistoryList patient history list
    * @param historyElement history element
    * @return
    */
  def wasElementBeforeXPeriodCurrentElement(visit: CassandraRow, m: MeasureProperty,flag:String,currentElement:String,numberDays:Int,patientHistoryList: Broadcast[List[CassandraRow]],historyElement: Seq[String]):Boolean= {
    var isExist = false
    try {

      if (patientHistoryList.value.nonEmpty) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(histVisit =>

            historyElement.exists(element => histVisit.getString("element").equalsIgnoreCase(element))
            && dateStatus(histVisit.getDateTime("element_date"), visit.getDateTime(currentElement + "_date").plusDays(numberDays), flag)
        )
      }
       val argsArray: Array[String] = Array(currentElement)
       measureLogger(visit, m, "wasElementBeforeXPeriodCurrentElement", currentElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {

        loggerObj.error(e.getMessage)
        System.exit(0)

      }
    }
    isExist
  }

  def wasElementPresentAfterStartOfWithinXPeriodWithResult(visit: CassandraRow, m: MeasureProperty,element:String, result:String,calenderUnit:String, calenderInterval: Int,timeCOperator:String,patientHistoryList: Broadcast[List[CassandraRow]],historyElement: String): Boolean = {
    var isExist = false

    try {
      if (patientHistoryList.value.nonEmpty) {

        val (lowerDate,higherDate)= element match {
          case AdminElements.Encounter_Date => (visit.getDateTime(AdminElements.Encounter_Date),higherCalenderDate(visit.getDateTime(AdminElements.Encounter_Date),calenderUnit,calenderInterval))
          case "measurement_period_start_date"=> (m.quarterStartDate,higherCalenderDate(m.quarterStartDate,calenderUnit,calenderInterval))
          case _ => (visit.getDateTime(element+"_date"),higherCalenderDate(visit.getDateTime(element+"_date"),calenderUnit,calenderInterval))
        }

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(histRow =>
           historyElement.equalsIgnoreCase(histRow.getString("element"))
            && compareTimeOperator(histRow.getDateTime(2),lowerDate,higherDate,timeCOperator)
            &&  patientHistoryList.value.exists(x =>  visit.getString("patientuid").equals(histRow.getString("patientuid"))
            && x.getString("element").equals(result)
            && x.getDate("element_date").equals(histRow.getDate("element_date"))
          )

        )
        val argsArray: Array[String] = Array(historyElement, calenderInterval.toString,calenderUnit,element)
        measureLogger(visit, m, "wasElementPresentAfterStartOfWithinXPeriodWithResult", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentAfterStartOfWithinXPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  def wasElementAfterElementDateWithResultElementWithinXPeriod(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String,ResultElement:String, calenderUnit:String, calenderInterval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val elementDate= if(elementName.equalsIgnoreCase(AdminElements.Encounter_Date)) AdminElements.Encounter_Date else if(elementName.equalsIgnoreCase(AdminElements.Date_of_Birth)) AdminElements.Date_of_Birth  else elementName+"_date"

    try {
      if (checkNotNull(visit,elementName,elementDate) && patientHistoryList.value.nonEmpty) {
        val lowerDate = visit.getDateTime(elementDate)
        val higherDate = higherCalenderDate(lowerDate,calenderUnit,calenderInterval)
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid"))).exists(x =>
            x.getString(1).equalsIgnoreCase(historyElementName)
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
            //   && compareTimeOperator(x.getDateTime(2), lowerDate, higherDate,CompareOperator)
            &&  patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
              .exists(x =>  x.getString("element").equals(ResultElement)
            && x.getDate("element_date").equals(x.getDate("element_date"))
          ) )

      }
      val argsArray: Array[String] = Array(elementName,historyElementName,calenderUnit,calenderInterval.toString, elementDate)
      measureLogger(visit, m, "wasElementAfterElementDateWithResultElementWithinXPeriod", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  def wasElementAfterElementDateWithResultWithinXPeriod(visit: CassandraRow, m: MeasureProperty, elementName: String, historyElementName: String,result:Double, resultFlag:String,calenderUnit:String, calenderInterval: Int, patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    val elementDate= if(elementName.equalsIgnoreCase(AdminElements.Encounter_Date)) AdminElements.Encounter_Date else if(elementName.equalsIgnoreCase(AdminElements.Date_of_Birth)) AdminElements.Date_of_Birth  else elementName+"_date"

    try {
      if (checkNotNull(visit,elementName,elementDate) && patientHistoryList.value.nonEmpty) {
        val lowerDate = visit.getDateTime(elementDate)
        val higherDate = higherCalenderDate(lowerDate,calenderUnit,calenderInterval)
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>
            x.getString(1).equalsIgnoreCase(historyElementName)
            && isDateBetween(x.getDateTime(2), lowerDate, higherDate)
            &&  compareValueStatus(x.getDouble("elementvalue"),resultFlag,result)
        )
      }
      val argsArray: Array[String] = Array(elementName,historyElementName,calenderUnit,calenderInterval.toString, elementDate)
      measureLogger(visit, m, "wasElementAfterElementDateWithResultWithinXPeriod", elementName, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:ElementMostRecentResultLessBeforeOrEqualInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  def ElementCountAfterDobBetweenXDays(visit: CassandraRow, m: MeasureProperty,historyElement1:String,historyElement2:String, calenderUnit:String, startDays: Int,endDays:Int,count:Int ,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false

    var Count =0

    try {
      if (patientHistoryList.value.nonEmpty) {

        val dob=visit.getDateTime("dob")
        val lowerDate=higherCalenderDate(dob,calenderUnit,startDays)
        val higherDate=higherCalenderDate(dob,calenderUnit,endDays)

        Count = patientHistoryList.value.filter(r => r.getString("patientuid").equals(visit.getString("patientuid"))
          && (r.getString("element").contains(historyElement1) || r.getString("element").contains(historyElement2))
          && isDateBetween(r.getDateTime(""),lowerDate,higherDate)

        ).size
        isExist = (Count >= count)
        val argsArray: Array[String] = Array(historyElement1, historyElement2,calenderUnit,calenderUnit,startDays.toString,endDays.toString,count.toString)
        measureLogger(visit, m, "ElementCountAfterDobBetweenXDays", historyElement1, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentAfterStartOfWithinXPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


  /** PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param currentEyeElement  element name whose date will be checked
    * @param patientHistoryList list of patient history
    * @return true if element is already present before another element
    */
  def checkEyeElementAfterEncounterEyeElementBetweenXPeriods(visit: CassandraRow, m: MeasureProperty, currentEyeElement: String,CalenderUnitTo:String, intervalTo: Int,CalenderUnitFrom:String, intervalFrom: Int, patientHistoryList: Broadcast[List[CassandraRow]], historyElement: String): Boolean = {
    val eyeCondCriterias1 = Array(3, 4)
    val eyeCondCriterias2 = Array(1, 2, 3, 4)
    var isExist = false
    val historyElementDate = historyElement + "_date"
    val currentEyeElementDate = currentEyeElement + "_date"
    try {
      if (patientHistoryList.value.length > 0) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !x.isNullAt("element_date") &&
            x.getString("element").equalsIgnoreCase(historyElement)
          && ((visit.getDateTime(currentEyeElementDate).isAfter(x.getDateTime("element_date")) || visit.getDateTime(currentEyeElementDate).isEqual(x.getDateTime("element_date")))
          && isDateBetween(x.getDateTime("element_date"), lowerCalenderDate(x.getDateTime("element_date"), CalenderUnitFrom, intervalFrom),higherCalenderDate(x.getDateTime("element_date"), CalenderUnitTo, intervalTo)
        ))
          &&
           (
            (eyeCondCriterias1.contains(x.getString("elementvalue")) && eyeCondCriterias2.contains(currentEyeElement))
              || (eyeCondCriterias2.contains(x.getString("elementvalue")) && eyeCondCriterias1.contains(currentEyeElement))
              || x.isNullAt("elementvalue")
              || (currentEyeElement == null)

            )


        )
      }
      val argsArray: Array[String] = Array(currentEyeElement)
      measureLogger(visit, m, "checkEyeElementAfterEncounterEyeElementInXDays", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        System.exit(0)
      }
    }
    isExist
  }

  /** PARENT Function
    *
    * @param visit              current Cassandra row
    * @param m                  measure Property
    * @param currentEyeElement  element name whose date will be checked
    * @param patientHistoryList list of patient history
    * @return true if element is already present before another element
    */
  def checkEyeElementAfterEncounterEyeElementInXDays(visit: CassandraRow, m: MeasureProperty, currentEyeElement: String,noOFDays  : Int , patientHistoryList: Broadcast[List[CassandraRow]], historyElement: String): Boolean = {
    val eyeCondCriterias1 = Array(3, 4)
    val eyeCondCriterias2 = Array(1, 2, 3, 4)
    var isExist = false
    val historyElementDate = historyElement + "_date"
    val currentEyeElementDate = currentEyeElement + "_date"
    try {
      if (patientHistoryList.value.length > 0) {
        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x => !x.isNullAt("element_date") &&
           x.getString("element").equalsIgnoreCase(historyElement)
          && ((visit.getDateTime(currentEyeElementDate).isAfter(x.getDateTime("element_date")) || visit.getDateTime(currentEyeElementDate).isEqual(x.getDateTime("element_date")))
          &&
          (visit.getDateTime(currentEyeElementDate).isBefore(x.getDateTime("element_date").plusWeeks(noOFDays)) || visit.getDateTime(currentEyeElementDate).isEqual(x.getDateTime("element_date").plusWeeks(noOFDays)))
          )
          &&
           (

            (eyeCondCriterias1.contains(x.getString("elementvalue")) && eyeCondCriterias2.contains(currentEyeElement))
              || (eyeCondCriterias2.contains(x.getString("elementvalue")) && eyeCondCriterias1.contains(currentEyeElement))
              || x.isNullAt("elementvalue")
              || (currentEyeElement == null)

            )


        )
      }
      val argsArray: Array[String] = Array(currentEyeElement)
      measureLogger(visit, m, "checkEyeElementAfterEncounterEyeElementInXDays", historyElement, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementPresentBeforeEncounterDate:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        System.exit(0)
      }
    }
    isExist
  }

  def wasVaccinatedInSequence(visit: CassandraRow, m: MeasureProperty,historyElement1:List[String],historyElement2:List[String], historyElement3: List[String] ,calenderUnit:String, interval :Int, compareOpertor:String , startDays: Int,endDays:Int ,patientHistoryList: Broadcast[List[CassandraRow]]): Boolean = {
    var isExist = false
    var Count =0
    try {
      if (patientHistoryList.value.nonEmpty) {

        val dob=visit.getDateTime("dob")
        val lowerDate=higherCalenderDate(dob,calenderUnit,startDays)
        val higherDate=higherCalenderDate(dob,calenderUnit,endDays)

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
          .exists(x =>  historyElement1.contains((x.getString("element")))

          && isDateBetween(x.getDateTime(""),lowerDate,higherDate)

          && patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
            .exists(y =>  historyElement2.contains(y.getString("element"))
          && isDateBetween(y.getDateTime(""),lowerDate,higherDate)

          && patientHistoryList.value.filter(histvisit => histvisit.getString("patientuid").equalsIgnoreCase(visit.getString("patientuid")))
              .exists(z =>  historyElement3.contains(z.getString("element"))
          && isDateBetween(z.getDateTime(""),lowerDate,higherDate)


          && dateStatus(x.getDateTime("element_date"),higherCalenderDate(y.getDateTime(""),calenderUnit,interval),compareOpertor )

          && dateStatus(x.getDateTime("element_date"),higherCalenderDate(y.getDateTime(""),calenderUnit,interval),compareOpertor )

        ))


        )

        val argsArray: Array[String] = Array(historyElement1.toString(), historyElement2.toString(),calenderUnit,calenderUnit,startDays.toString,endDays.toString)
        measureLogger(visit, m, "wasVaccinatedInSequence", historyElement1.toString(), isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:wasElementPresentAfterStartOfWithinXPeriod:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }







  /**
    * This function verifies history element is after or equal to another element and before or equal to end of the measurement period.
    * @param visit current visit of the patient
    * @param m measure property
    * @param historyElement element from the history
    * @param currentElement current element
    * @param patientHistoryList patient history list
    * @return it will return true if history element is after or equal to another element and before or equal to end of the measurement period else false.
    */
  def wasElementAfterOrEqualElementDateAndBeforeOrEqualEnd(visit:CassandraRow,m:MeasureProperty,historyElement:String,currentElement:String,patientHistoryList:Broadcast[List[CassandraRow]]):Boolean={
    var isExist =false
    try {
      if (checkNotNull(visit,currentElement,currentElement+"_date") && patientHistoryList.value.nonEmpty) {

        isExist = patientHistoryList.value.filter(histvisit => histvisit.getString(0).equalsIgnoreCase(visit.getString("patientuid")))
          .exists(histVisit =>
            histVisit.getString(1).equalsIgnoreCase(historyElement)
              &&
             isDateBetween(histVisit.getDateTime(2),visit.getDateTime(currentElement+"_date"), m.quarterEndDate))


        val argsArray: Array[String] = Array(historyElement,currentElement)
        measureLogger(visit, m, "wasElementAfterOrEqualElementDateAndBeforeOrEqualEnd", historyElement, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist

  }


  /**
    * This function verifies if medication1 ordered after medication2 within X period
    * @param visit current patient visit
    * @param m measure property
    * @param medicationElement1 to be checked in history record
    * @param calendarUnit valid calender units are CalenderUnit.x
    * @param calendarInterval no of interval to be checked
    * @param patientHistoryList patient history list
    * @param medicationElement2 to be checked in history
    * @return returns true if medication1 ordered after medication2 within X period else returns false
    */
  def wasMedicationOrderedAfterMedicationWithinXPeriod(visit: CassandraRow, m: MeasureProperty, medicationElement1: String, calendarUnit: String, calendarInterval: Int, patientHistoryList: Broadcast[List[CassandraRow]], medicationElement2: String): Boolean = {
    var isExist = false
    try {
      if (patientHistoryList.value.nonEmpty) {
        val currentPatientHistoryRecords = patientHistoryList.value.filter(histRow => histRow.getString(0).equalsIgnoreCase(visit.getString("patientuid"))
          && isDateBetween(histRow.getDateTime(2), m.quarterStartDate, m.quarterEndDate))
        isExist = currentPatientHistoryRecords.exists(histRow1 =>
              histRow1.getString(1).equalsIgnoreCase(medicationElement1)
              &&
              currentPatientHistoryRecords.exists(histRow2 => histRow2.getString(1).equalsIgnoreCase(medicationElement2)
                &&
              dateStatus(histRow1.getDateTime(2), histRow2.getDateTime(2), CompareOperator.GREATER_EQUAL)
              )
          )
        val argsArray: Array[String] = Array(medicationElement1, calendarInterval.toString, calendarUnit, medicationElement2)
        measureLogger(visit, m, "wasMedicationOrderedAfterMedicationWithinXPeriod", medicationElement2, isExist, argsArray)
      }
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }





}




