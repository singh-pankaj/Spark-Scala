package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 455
* Measure Title              :- Percentage of Patients Who Died from Cancer Admitted to the Intensive Care Unit (ICU)
*                               in the Last 30 Days of Life
* Measure Description        :- Percentage of patients who died from cancer admitted to the ICU in the last 30 days of life
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp455 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp455"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
    QPP455Elements.Cancer,
    QPP455Elements.Icu_Admission,
    QPP455Elements.Expired
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD=ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(denominatorRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP Criteria
  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val encounterCountList: List[(String,Int)] = countElement(patientHistoryRDD ,m
      , QPP455Elements.Office_Visit
    )

    initialRDD.filter(visit =>
      wasDiagnosisInHistory(visit, m, QPP455Elements.Cancer, patientHistoryList)
      &&
      getEncounterCountFromHistory(visit,m,2,true,encounterCountList)
      &&
        (
          isPatientCharacteristicDuringEncounter(visit, m, QPP455Elements.Death_Due_To_Cancer)
          ||
          isPatientExpiredWithCause(visit, m, QPP455Elements.Expired,QPP455Elements.Cancer )

        )
    )
  }



  // Numerator Criteria
  def getMet(metRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    metRDD.filter(visit =>
      (
        isVisitTypeIn(visit, m, QPP455Elements.Admission_To_Icu)
        ||
        wasElementBeforeOtherElementWithInXDays(visit, m, QPP455Elements.Icu_Admission, QPP455Elements.Expired, 30, patientHistoryList)
        )
      &&
      !isVisitTypeIn(visit, m, QPP455Elements.No_Admission_To_Icu)

    )
  }



}
