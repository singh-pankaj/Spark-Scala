package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master
import com.figmd.janus.measureComputation.master._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{QPP14Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 14
* Measure Title              :- Age-Related Macular Degeneration (AMD): Dilated Macular Examination
* Measure Description        :- Percentage of patients aged 50 years and older with a diagnosis of age-related macular degeneration (AMD)who
                                had a dilated macular examination performed which included documentation of the presence or absence of macular
                                thickening or geographic atrophy or hemorrhage AND the level of macular degeneration severity during one or more
                                office visits within 12 months
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp14 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp14"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patient_history_list = getPatientHistory(sparkSession, initialRDD,
      QPP14Elements.Exudative_Senile_Macular_Degeneration,
      QPP14Elements.Macular_Degeneration_Senile_Unspecified,
      QPP14Elements.Nonexudative_Senile_Macular_Degeneration,
      QPP14Elements.Macular_Exam_Eye, QPP14Elements.Macular_Hemorrhage_Eye,
      QPP14Elements.Geographic_Atrophy_Eye,
      QPP14Elements.Macular_Thickening_Eye,
      QPP14Elements.Macular_Degeneration_Severity_Eye,
      QPP14Elements.Dilated_Macular_Exam_Reason_Not_Specified,
      QPP14Elements.Medical_Reason,
      QPP14Elements.Patient_Reason,
      QPP14Elements.Dilated_Macular_Exam_Patient_Reason,
      QPP14Elements.Dilated_Macular_Exam_Medical_Reason
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible RDD
      val denominatorRDD = ippRDD

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateA, patientHistoryList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }


  //All patients aged 50 years and older with a diagnosis of AMD
  def getIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
                          isAgeAbove(visit, m, true,50)
                      &&  isVisitTypeIn(visit,m,QPP14Elements.Office_Visit,
                                                QPP14Elements.Care_Services_In_Long_Term_Residential_Facility,
                                                QPP14Elements.Ophthalmological_Services,
                                                QPP14Elements.Nursing_Facility_Visit
                                      )
                      && (
                           wasDiagnosedInHistory(visit, m, QPP14Elements.Exudative_Senile_Macular_Degeneration,patientHistoryList)
                        || wasDiagnosedInHistory(visit, m, QPP14Elements.Macular_Degeneration_Senile_Unspecified,patientHistoryList)
                        || wasDiagnosedInHistory(visit, m, QPP14Elements.Nonexudative_Senile_Macular_Degeneration,patientHistoryList)
                      )
                      && (
                           isDiagnosedConcurrentWith(visit, m, QPP14Elements.Amd_Eye, QPP14Elements.Exudative_Senile_Macular_Degeneration)
                        || isDiagnosedConcurrentWith(visit, m, QPP14Elements.Amd_Eye, QPP14Elements.Macular_Degeneration_Senile_Unspecified)
                        || isDiagnosedConcurrentWith(visit, m, QPP14Elements.Amd_Eye, QPP14Elements.Nonexudative_Senile_Macular_Degeneration)

                      )
                      &&
                        ! isTeleHealthModifier(visit,m,
                          QPP14Elements.Office_Visit_Telehealth_Modifier,
                          QPP14Elements.Nursing_Facility_Visit_Telehealth_Modifier,
                          QPP14Elements.Ophthalmological_Services_Telehealth_Modifier,
                          QPP14Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier_Date
                      )

                      &&  isPOSEncounterNotPerformed(visit, m, QPP14Elements.Pos_02)

                  )
  }

  //Patients who had a dilated macular examination performed which included documentation of the presence or
  //absence of macular thickening or geographic atrophy or hemorrhage AND the level of macular degeneration severity
  //during one or more office visits within 12 months
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        (
              (
                   isProcedurePerformedDuringEncounter(visit, m, QPP14Elements.Macular_Exam)
                && checkEyeOnEncounterEqualsWithOtherEye(visit, m,true, QPP14Elements.Macular_Exam_Eye,patientHistoryList,Seq(QPP14Elements.Amd_Eye))

              )
            &&
            (
                (
                     isDiagnosedDuringEncounter(visit, m, QPP14Elements.Macular_Hemorrhage)
                  && checkEyeOnEncounterEqualsWithOtherEye(visit, m,true, QPP14Elements.Macular_Hemorrhage_Eye,patientHistoryList,Seq(QPP14Elements.Amd_Eye))
                )
                ||
                (
                     isDiagnosedDuringEncounter(visit, m, QPP14Elements.Geographic_Atrophy)
                  && checkEyeOnEncounterEqualsWithOtherEye(visit, m,true, QPP14Elements.Geographic_Atrophy_Eye,patientHistoryList,Seq(QPP14Elements.Amd_Eye))

                )
                ||
                (
                      isDiagnosedDuringEncounter(visit, m, QPP14Elements.Macular_Thickening)
                  && checkEyeOnEncounterEqualsWithOtherEye(visit, m,true, QPP14Elements.Macular_Thickening_Eye,patientHistoryList,Seq(QPP14Elements.Amd_Eye))

                )
            )
            && isDiagnosticStudyOnEncounter(visit, m, QPP14Elements.Macular_Degeneration_Severity)
            && checkEyeOnEncounterEqualsWithOtherEye(visit, m,true, QPP14Elements.Macular_Degeneration_Severity_Eye,patientHistoryList,Seq(QPP14Elements.Amd_Eye))

        )
        || isProcedurePerformedDuringEncounter(visit, m, QPP14Elements.Dilated_Macular_Exam)

      ) && !(isProcedurePerformed(visit, m, QPP14Elements.Dilated_Macular_Exam_Reason_Not_Specified, patientHistoryList))


    )

  }

//Documentation of medical reason(s) for not performing a dilated macular examination.
//OR
//Documentation of patient reason(s) for not performing a dilated macular examination.
  def getExceptionRDD(intermedaiateRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow]  = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermedaiateRdd.filter(visit =>
                                 isProcedurePerformed(visit, m, QPP14Elements.Medical_Reason,patientHistoryList)
                              || isProcedurePerformed(visit, m, QPP14Elements.Patient_Reason,patientHistoryList)

                              || wasProcedurePerformedBeforeOrEqualEncounter(visit,m,QPP14Elements.Dilated_Macular_Exam_Patient_Reason,patientHistoryList)
                              || wasProcedurePerformedBeforeOrEqualEncounter(visit,m,QPP14Elements.Dilated_Macular_Exam_Medical_Reason,patientHistoryList)

                          )


  }
}