package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty}
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 439
* Measure Title              :- Age Appropriate Screening Colonoscopy
* Measure Description        :- The percentage of patients greater than 85 years of age who received a screening
*                               colonoscopy from January 1 to December 31.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp439 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp439"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {


      // Filter denominator Exclusions
      val denominatorExclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //eligible initial population RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val patientHistoryList = getPatientHistory(sparkSession, ippRDD
        , QPP439Elements.History_Of_Colorectal_Cancer
        , QPP439Elements.Medical_Reason_For_Colonoscopy
        , QPP439Elements.Incomplete_Inadequate_Prep_Colonoscopy_439
        , QPP439Elements.Gi_Tract_Illness_Signs_Symptoms
        , QPP439Elements.High_Risk_Colonoscopy
        , QPP439Elements.Follow_Up_Previously_Diagnosed_Advance_Lesions
        , QPP439Elements.Absence_Of_Colorectal_Cancer_Or_Valid_Medical_Reasons
        , QPP439Elements.Colonoscopy_Performed_Not_Met
        , QPP439Elements.Screening_Colonoscopy
      )

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList.collect().toList)

      //Met initialRDD
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)

      //exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, denominatorExclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }


  // IPP-Denominator criteria
  /*-------------------------------------------------------------------------------------------------------------------
   Colonoscopy examinations performed on patients greater than 85 years of age during the encounter period.
  -------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      (
        isAgeAbove(visit, m, false, 85)
          &&
          isProcedurePerformedDuringEncounter(visit, m, QPP439Elements.Screening_Colonoscopy)
        )
        && !isVisitTypeIn(visit, m, QPP439Elements.Colonoscopy_52_53_73_74)
    )
  }


  // Numerator criteria
  /*-------------------------------------------------------------------------------------------------------------------
  All patients greater than 85 years of age included in the denominator who did NOT have a history of colorectal cancer
  or a valid medical reason for the colonoscopy, including: iron deficiency anemia, lower gastrointestinal bleeding,
  Crohn’s Disease (i.e. regional enteritis), familial adenomatous polyposis, Lynch Syndrome (i.e., hereditary nonpolyposis
  colorectal cancer), inflammatory bowel disease, ulcerative colitis, abnormal findings of gastrointestinal tract, or
  changes in bowel habits. Colonoscopy examinations performed for screening purposes only.
  -------------------------------------------------------------------------------------------------------------------*/
  def getMet(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      (
        isProcedurePerformed(visit, m, QPP439Elements.Absence_Of_Colorectal_Cancer_Or_Valid_Medical_Reasons, patientHistoryBroadcastList)
          ||
          !(
            wasDiagnosticStudyPerformedBeforeOrEqualEncounter(visit, m, QPP439Elements.History_Of_Colorectal_Cancer, patientHistoryBroadcastList)
              ||
              wasDiagnosticStudyPerformedBeforeOrEqualEncounter(visit, m, QPP439Elements.Medical_Reason_For_Colonoscopy, patientHistoryBroadcastList)
              ||
              wasDiagnosticStudyPerformedBeforeOrEqualEncounter(visit, m, QPP439Elements.Incomplete_Inadequate_Prep_Colonoscopy_439, patientHistoryBroadcastList)
              ||
              wasAssessmentPerformedBeforeOrEqualEncounter(visit, m, QPP439Elements.Gi_Tract_Illness_Signs_Symptoms, patientHistoryBroadcastList)
              ||
              wasAssessmentPerformedBeforeOrEqualEncounter(visit, m, QPP439Elements.High_Risk_Colonoscopy, patientHistoryBroadcastList)
              ||
              wasAssessmentPerformedBeforeOrEqualEncounter(visit, m, QPP439Elements.Follow_Up_Previously_Diagnosed_Advance_Lesions, patientHistoryBroadcastList)
            )
        )
        &&
        !(
          isProcedurePerformed(visit, m, QPP439Elements.Colonoscopy_Performed_Not_Met, patientHistoryBroadcastList)
            ||
            isProcedurePerformed(visit, m, QPP439Elements.Screening_Colonoscopy, patientHistoryBroadcastList)
          )

    )
  }
}
