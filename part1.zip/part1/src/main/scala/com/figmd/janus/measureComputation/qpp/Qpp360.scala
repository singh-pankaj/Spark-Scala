package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP360Elements}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{ MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp360
* Measure Title              :- Optimizing Patient Exposure to Ionizing Radiation: Count of Potential High Dose Radiation Imaging Studies: Computed Tomography (CT) and Cardiac Nuclear Medicine Studies.
* Measure Description        :- Percentage of computed tomography (CT) and cardiac nuclear medicine (myocardial perfusion studies) imaging reports for all patients, regardless of age, that document a count of known previous CT (any type of CT) and cardiac nuclear medicine (myocardial perfusion) studies that the patient has received in the 12-month period prior to the current study.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp360 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp360"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      QPP360Elements.Computed_Tomography,
      QPP360Elements.Ct_And_Cardiac_Nuclear_Medicine__Date,
      QPP360Elements.Ct_Study,
      QPP360Elements.Cardiac_Nuclear_Medicine_Study,
      QPP360Elements.Ct_Medicine_Reason_Not_Specified
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //eligible RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  //All final reports for patients, regardless of age, undergoing a CT procedure, during measurement period.
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
                        isProcedurePerformed(visit,m,QPP360Elements.Computed_Tomography,patientHistoryBroadcastList)
    )
  }


  //CT and cardiac nuclear medicine (myocardial perfusion studies) imaging reports that document a count of known previous CT (any type of CT)
  // and cardiac nuclear medicine (myocardial perfusion) studies that the patient has received in the 12-month period prior to the current study
  def getMet(intermediateA: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
                                    (
                                          isProcedurePerformedDuringProcedure(visit,m,QPP360Elements.Ct_And_Cardiac_Nuclear_Medicine,QPP360Elements.Ct_And_Cardiac_Nuclear_Medicine__Date,QPP360Elements.Computed_Tomography,QPP360Elements.Computed_Tomography_Date)
                                      ||
                                          (
                                                isAssessmentPerformedDuringProcedure(visit,m,QPP360Elements.Ct_Study,QPP360Elements.Ct_Study_Date,QPP360Elements.Computed_Tomography,QPP360Elements.Computed_Tomography_Date)
                                            &&  isAssessmentPerformedDuringProcedure(visit,m,QPP360Elements.Cardiac_Nuclear_Medicine_Study,QPP360Elements.Cardiac_Nuclear_Medicine_Study_Date,QPP360Elements.Computed_Tomography,QPP360Elements.Computed_Tomography_Date)
                                          )
                                    )
                                    && isProcedurePerformedDuringProcedure(visit,m,QPP360Elements.Ct_Medicine_Reason_Not_Specified,QPP360Elements.Ct_Medicine_Reason_Not_Specified_Date,QPP360Elements.Computed_Tomography,QPP360Elements.Computed_Tomography_Date)


    )
  }

}
