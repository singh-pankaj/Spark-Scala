import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP145Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 145
* Measure Title              :- Radiology: Exposure Dose Indices or Exposure Time and Number of Images Reported for
*                               Procedures Using Fluoroscopy
* Measure Description        :- Final reports for procedures using fluoroscopy that document radiation exposure indices,
*                               or exposure time and number of fluorographic images (if radiation exposure indices are not available)
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp145 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp145"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        QPP145Elements.Skin_Dose_Mapping,
        QPP145Elements.Peak_Skin_Dose__Psd_,
        QPP145Elements.Reference_Air_Kerma,
        QPP145Elements.Kerma_Area_Product__Pka_,
        QPP145Elements.Dose_Area_Product__Dap_,
        QPP145Elements.Exposure_Time,
        QPP145Elements.Fluorographic_Images)

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
    //Filter Denominator Exclusion
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
        // Filter Met
    val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
    metRDD.cache()

    // Filter Denominator Exception
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exceptionRDD.cache()

    //Filter Not Met
    val notMetRDD = getSubtractRDD(ippRDD, metRDD)
    notMetRDD.cache()


    saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      }
  }

  // IPP-Denominator criteria
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      isProcedurePerformedDuringEncounter(visit, m, QPP145Elements.Fluoroscopy)
    )
  }


  // Numerator criteria
  def getMet(metRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    metRDD.filter(visit =>
      (
      isAssessmentPerformedDuringProcedure(visit, m,
      QPP145Elements.Report_For_Procedures_Using_Fluoroscopy,
      QPP145Elements.Report_For_Procedures_Using_Fluoroscopy_Date,
      QPP145Elements.Fluoroscopy,
      QPP145Elements.Fluoroscopy_Date)
      ||
      wasInterventionDoneAfterProcedure(visit, m,
      QPP145Elements.Fluoroscopy_Date,patientHistoryBroadcastList,
      QPP145Elements.Skin_Dose_Mapping,
      QPP145Elements.Peak_Skin_Dose__Psd_,
      QPP145Elements.Reference_Air_Kerma,
      QPP145Elements.Kerma_Area_Product__Pka_,
      QPP145Elements.Dose_Area_Product__Dap_
      )
      ||
      (
        wasInterventionDoneAfterProcedure(visit, m,QPP145Elements.Fluoroscopy_Date,patientHistoryBroadcastList,QPP145Elements.Exposure_Time)
        &&
        wasInterventionDoneAfterProcedure(visit, m,QPP145Elements.Fluoroscopy_Date,patientHistoryBroadcastList,QPP145Elements.Fluorographic_Images)
      )
    )
      &&
        !isAssessmentPerformedDuringProcedure(visit, m,
          QPP145Elements.Radiation_Reason_Not_Specified,
          QPP145Elements.Radiation_Reason_Not_Specified_Date,
          QPP145Elements.Fluoroscopy,
          QPP145Elements.Fluoroscopy_Date)
    )
  }
}
