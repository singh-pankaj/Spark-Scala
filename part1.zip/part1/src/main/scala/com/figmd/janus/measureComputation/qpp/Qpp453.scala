package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP453Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 453
* Measure Title              :- Percentage of Patients Who Died from Cancer Receiving Chemotherapy in the Last 14 Days of Life (lower score – better)
* Measure Description        :- Percentage of patients who died from cancer receiving chemotherapy in the last 14 days of life
* Calculation Implementation :- Patient Specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp453 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp453"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP453Elements.Office_Visit,
      QPP453Elements.Cancer,
      QPP453Elements.Chemotherapy_Received,
      QPP453Elements.Chemotherapy,
      QPP453Elements.Chemotherapy_Received__Not_Met
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      val denominatorRDD=ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      //      exclusionRDD.cache()

      // Filter Intermediate A
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()
      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()
      // Filter Intermediate B
      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()
      // Filter Denominator Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      //      exceptionRDD.cache()
      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()
      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val officeVisits = countElement(patientHistoryRDD, m, QPP453Elements.Office_Visit)

    initialRDD.filter(visit =>
      wasDiagnosedInXDaysBeforeEndDate(visit, m, QPP453Elements.Cancer, 0, patientHistoryList)
        && getEncounterCountFromHistory(visit, m, 2, true, officeVisits)
        && isVisitTypeIn(visit, m, QPP453Elements.Death_Due_To_Cancer, QPP453Elements.Patient_Deceased_Cancer)
    )
  }

  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        isMedicationAdministered(visit, m, QPP453Elements.Chemotherapy_Received, patientHistoryList)
          || (
          wasMedicationAdministeredBeforeEncounterWithinXDays(visit, m, QPP453Elements.Patient_Deceased_Cancer_Date, 14, patientHistoryList, QPP453Elements.Chemotherapy)
            || wasMedicationAdministeredBeforeEncounterWithinXDays(visit, m, QPP453Elements.Death_Due_To_Cancer_Date, 14, patientHistoryList, QPP453Elements.Chemotherapy)
          )
        )
        && !isMedicationAdministered(visit, m, QPP453Elements.Chemotherapy_Received__Not_Met, patientHistoryList)

    )
  }

}
