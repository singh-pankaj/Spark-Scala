package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP243Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 243
* Measure Title              :- Cardiac Rehabilitation Patient Referral from an Outpatient Setting
* Measure Description        :- Percentage of patients evaluated in an outpatient setting who within the previous 12 months have experienced an acute myocardial infarction (MI),
*                               coronary artery bypass graft (CABG) surgery, a percutaneous coronary intervention (PCI), cardiac valve surgery, or cardiac transplantation,
*                               or who have chronic stable angina (CSA) and have not already participated in an early outpatient cardiac rehabilitation/secondary prevention (CR) program
*                               for the qualifying event/diagnosis who were referred to a CR program
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp243 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp243"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP243Elements.Cardiac_Event,
      QPP243Elements.Qualifying_Cardiac_Event,
      QPP243Elements.Cardiac_Transplantation,
      QPP243Elements.Percutaneous_Coronary_Interventions,
      QPP243Elements.Cardiac_Valve_Surgery,
      QPP243Elements.Coronary_Artery_Bypass_Graft_Surgery,
      QPP243Elements.Acute_Myocardial_Infarction,
      QPP243Elements.Chronic_Stable_Angina,
      QPP243Elements.Previous_Cardiac_Rehabilitation_For_Qualifying_Cardiac_Event_Completed,
      QPP243Elements.Previous_Cardiac_Rehabilitation
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateB = ippRDD.subtract(metRDD)
      intermediateB.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateB, patientHistoryBroadcastList)
      exceptionRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit => isPatientAdult(visit, m)
      && isVisitTypeIn(visit, m, QPP243Elements.Office_Visit, QPP243Elements.Annual_Wellness_Visit)
      && (
      wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP243Elements.Cardiac_Event, 12, patientHistoryBroadcastList)
        || wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP243Elements.Qualifying_Cardiac_Event, 12, patientHistoryBroadcastList)
        || wasProcedurePerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP243Elements.Cardiac_Transplantation, 12, patientHistoryBroadcastList)
        || wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP243Elements.Percutaneous_Coronary_Interventions, 12, patientHistoryBroadcastList)
        || wasProcedurePerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP243Elements.Cardiac_Valve_Surgery, 12, patientHistoryBroadcastList)
        || wasProcedurePerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP243Elements.Coronary_Artery_Bypass_Graft_Surgery, 12, patientHistoryBroadcastList)
        || wasDiagnosedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP243Elements.Acute_Myocardial_Infarction, 12, patientHistoryBroadcastList)
        || wasDiagnosedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP243Elements.Chronic_Stable_Angina, 12, patientHistoryBroadcastList)
      )
      && (
      !isVisitTypeIn(visit, m, QPP243Elements.Office_Visit_Telehealth_Modifier, QPP243Elements.Annual_Wellness_Visit_Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP243Elements.Pos_02)
      )
    )
  }


  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ipp.filter(visit =>
      (
        isCommunicationFromProviderToProviderOnEncounter(visit, m, QPP243Elements.Referral_To_Cardiac_Rehabilitation)
          || isCommunicationFromProviderToProviderOnEncounter(visit, m, QPP243Elements.Referral_To_Cardiac_Rehabilitation)
          || isCommunicationFromProviderToProviderOnEncounter(visit, m, QPP243Elements.Cardiac_Rehabilitation)
          || isCommunicationFromProviderToProviderOnEncounter(visit, m, QPP243Elements.Cardiac_Rehabilitation)
        ) && !isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP243Elements.Ref_Card_Rehab_Reason_Not_Specified)
    )
  }

  def getException(intermediateRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateRdd.filter(visit =>
      isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP243Elements.Ref_Card_Rehab_Medical_Reason)
        || isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP243Elements.Medical_Reason_Cr)
        || isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP243Elements.Ref_Card_Rehab_System_Reason)
        || isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP243Elements.System_Reason_Cr)
        || wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP243Elements.Previous_Cardiac_Rehabilitation_For_Qualifying_Cardiac_Event_Completed, 12, patientHistoryBroadcastList)
        || wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP243Elements.Previous_Cardiac_Rehabilitation, 12, patientHistoryBroadcastList)
    )
  }


}
