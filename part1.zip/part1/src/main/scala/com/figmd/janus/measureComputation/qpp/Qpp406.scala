package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP406Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp 406
* Measure Title              :- Appropriate Follow-up Imaging for Incidental Thyroid Nodules in Patients
* Measure Description        :- Percentage of final reports for computed tomography (CT), CT angiography (CTA) or magnetic resonance imaging
                              (MRI) or magnetic resonance angiogram (MRA) studies of the chest or neck for patients aged 18 years and older with
                              no known thyroid disease with a thyroid nodule < 1.0 cm noted incidentally with follow-up imaging recommended.
* Calculation Implementation :- Procedure specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp406 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp406"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP406Elements.Imaging_Chest_Or_Neck,
      QPP406Elements.Thyroid_Nodule,
      QPP406Elements.Incidental_Thyroid_Nodule,
      QPP406Elements.Follow_Up_For_Imaging

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateRdd = getSubtractRDD(denominatorRDD, metRDD)

      // Filter not Exception
      val exceptionRDD = getException(intermediateRdd)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRdd, exceptionRDD)
      notMetRDD.cache()
      //

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  // IPP-Denominator criteria
  /* All final reports for CT, CTA, MRI or MRA studies of the chest or neck or ultrasound of the neck for patients aged 18 and older with a thyroid nodule < 1.0 cm noted.*/

  def getIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isPatientAdult(visit, m)
        && isDiagnosticStudyPerformedOnEncounter(visit, m, QPP406Elements.Imaging_Chest_Or_Neck)
        && ((isDiagnosticStudyPerformedDuringXDiagnosticStudy(visit, m, QPP406Elements.Imaging_Chest_Or_Neck, QPP406Elements.Thyroid_Nodule)
        && checkElementValueDuringMeasurementPeriod(visit, m, QPP406Elements.Thyroid_Nodule, 1.0, "lt", patientHistoryList)
        )
        ||
        (isDiagnosticStudyPerformedAfterXDiagnosticStudy(visit, m, QPP406Elements.Imaging_Chest_Or_Neck, patientHistoryList, QPP406Elements.Thyroid_Nodule)
          && checkElementValueDuringMeasurementPeriod(visit, m, QPP406Elements.Thyroid_Nodule, 1.0, "lt", patientHistoryList)
          )
        )
          ||
          (isDiagnosticStudyPerformedDuringXDiagnosticStudy(visit, m, QPP406Elements.Imaging_Chest_Or_Neck,  QPP406Elements.Incidental_Thyroid_Nodule)
            || isDiagnosticStudyPerformedAfterXDiagnosticStudy(visit, m, QPP406Elements.Imaging_Chest_Or_Neck, patientHistoryList,QPP406Elements.Incidental_Thyroid_Nodule)
            )
        )

  }


  // Numerator criteria
  /* Final reports for CT, CTA MRI or MRA of the chest or neck or ultrasound of the neck with follow-up imaging recommended for reports with a thyroid nodule < 1.0 cm noted.*/

  def getMet(ipp: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ipp.filter(visit =>
      (
        isInterventionPerformedOnEncounter(visit, m, QPP406Elements.Follow_Up_Imaging)
          || isInterventionPerformedAfterDiagnosticStudy(visit, m, QPP406Elements.Follow_Up_For_Imaging, QPP406Elements.Imaging_Chest_Or_Neck, patientHistoryList)
        )
        && !isInterventionPerformedOnEncounter(visit, m, QPP406Elements.Follow_Up_Image_Not_Met)
    )
  }

  // Exception criteria
  /* Documentation of medical reason(s) for recommending follow-up imaging (e.g., patient has multiple endocrine neoplasia, patient has cervical lymphadenopathy, other medical reason(s)) */

  def getException(intermediate: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediate.filter(visit =>
      isInterventionPerformedOnEncounter(visit, m, QPP406Elements.Follow_Up_Image_Medical_Reason)
        || isInterventionPerformedOnEncounter(visit, m, QPP406Elements.Follow_Up_Image_Documented_Medical_Reason))
  }

}
