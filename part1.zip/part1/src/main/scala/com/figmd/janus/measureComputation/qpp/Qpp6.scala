package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP6Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 006
* Measure Title              :- Coronary Artery Disease (CAD): Antiplatelet Therapy
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of coronary artery disease (CAD) seen within a 12 month period
                                who were prescribed aspirin or clopidogrel
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp6 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp6"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // val patientHistory:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistory)

    //Backtracking List
    val PatientHistoryList = getPatientHistory(sparkSession,initialRDD,
      QPP6Elements.Aspirin_Or_Clopidogrel_Met,
      QPP6Elements.Aspirin_Or_Clopidogrel,
      QPP6Elements.Asp_Clo_Reason_Not_Specified).collect.toList;
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(PatientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exceptions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val intermediateB = ippRDD.subtract(metRDD)
      intermediateB.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateB)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }


  /* IPP : All patients aged 18 years and older with a diagnosis of coronary artery disease seen within a 12 month period  */


  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
      isPatientAdult(visit,m)
        && isDiagnosedDuringEncounter(visit, m, QPP6Elements.Coronary_Artery_Disease)
        && isVisitTypeIn(visit, m, QPP6Elements.Office_Visit,
        QPP6Elements.Nursing_Facility_Visit,
        QPP6Elements.Care_Services_In_Long_Term_Residential_Facility,
        QPP6Elements.Home_Healthcare_Services,
        QPP6Elements.Outpatient_Consultation
      )
        && ! isTeleHealthEncounterNotPerformed(visit, m, QPP6Elements.Office_Visit_Telehealth_Modifier,
        QPP6Elements.Nursing_Facility_Visit_Telehealth_Modifier,
        QPP6Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier,
        QPP6Elements.Home_Healthcare_Services_Telehealth_Modifier,
        QPP6Elements.Outpatient_Consultation_Telehealth_Modifier
      )
        && isPOSEncounterNotPerformed(visit, m, QPP6Elements.Pos_02)
    )

  }

  /* Met : Patients who were prescribed aspirin or clopidogrel */

  def getMet(ipp: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    ipp.filter(visit =>
      (isAssessmentPerformed(visit, m,QPP6Elements.Aspirin_Or_Clopidogrel_Met,patientHistoryList)
        || wasMedicationActiveInHistory(visit, m, QPP6Elements.Aspirin_Or_Clopidogrel, patientHistoryList)
        || isMedicationOrderedDuringEncounter(visit, m, QPP6Elements.Aspirin_Or_Clopidogrel)
        )
        && !isMedicationOrdered(visit, m, patientHistoryList, QPP6Elements.Asp_Clo_Reason_Not_Specified)
    )
  }

/* Exception :
Documentation of medical reason(s) for not prescribing aspirin or clopidogrel (eg, allergy, intolerance,receiving other thienopyridine therapy, receiving warfarin therapy, bleeding coagulation disorders, other medical reasons)
Documentation of patient reason(s) for not prescribing aspirin or clopidogrel (eg, patient declined, other patient reasons)
Documentation of system reason(s) for not prescribing aspirin or clopidogrel (eg, lack of drug availability, other reasons attributable to the health care system)
 */

  def getExceptionRDD(intermedaiateRdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermedaiateRdd.filter(visit =>
      (
        isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP6Elements.Asp_Clo_Medical_Reason)
          || isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP6Elements.Asp_Clo_Patient_Reason)
          || isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP6Elements.Asp_Clo_System_Reason)
          || isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP6Elements.Medical_Reason)
          || isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP6Elements.System_Reason)
        )
        ||
        (
          isMedicationActiveDuringEncounter(visit, m, QPP6Elements.Antiplatelet_Therapy)
            || isMedicationActiveDuringEncounter(visit, m, QPP6Elements.Warfarin)
            || isDiagnosedDuringEncounter(visit, m, QPP6Elements.Bleeding_Disorder)
            || isMedicationAllergyDuringEncounter(visit, m, QPP6Elements.Allergy_To_Medication)
            || isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP6Elements.Patient_Refusal)
            || isMedicationAllergyDuringEncounter(visit, m, QPP6Elements.Aspirin_Or_Clopidogrel_Allergy)
            || isMedicationAllergyDuringEncounter(visit, m, QPP6Elements.Allergy_Aspirin_Or_Clopidogrel)
            || isMedicationOrderedDuringEncounter(visit, m, QPP6Elements.Lack_Of_Drug_Availibility)
          )

    )
  }
}
