package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP146Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp146
* Measure Title              :- Radiology: Inappropriate Use of “Probably Benign” Assessment Category in Screening Mammograms
* Measure Description        :- Percentage of final reports for screening mammograms that are classified as “probably benign”
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp146 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp146"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP146Elements.Incomplete_Additional_Evaluation,

      QPP146Elements.Mammogram_Category_Probably_Benign,
      QPP146Elements.Probably_Benign,
      QPP146Elements.Negative,
      QPP146Elements.Benign,
      QPP146Elements.Suspicious,
      QPP146Elements.Highly_Suggestive_Of_Malignancy,
      QPP146Elements.Known_Biopsy_Proven_Malignancy,
      QPP146Elements.Mammogram_Assessment_Category

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exceptions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()


      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //All final reports for screening mammograms
  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
            isDiagnosisOnEncounter(visit,m,QPP146Elements.Screening_Mammogram)
        &&  isProcedurePerformedDuringEncounter(visit,m,QPP146Elements.Mammography_Screening)

    )
  }


  //Final reports classified as “probably benign”
  def getMet(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
              wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit,m,QPP146Elements.Mammography_Screening,patientHistoryBroadcastList,QPP146Elements.Probably_Benign)
          ||  wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit,m,QPP146Elements.Mammography_Screening,patientHistoryBroadcastList,QPP146Elements.Mammogram_Category_Probably_Benign)

        )
        && !
        (
                wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit,m,QPP146Elements.Mammography_Screening,patientHistoryBroadcastList,QPP146Elements.Incomplete_Additional_Evaluation)
            ||  wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit,m,QPP146Elements.Mammography_Screening,patientHistoryBroadcastList,QPP146Elements.Negative)
            ||  wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit,m,QPP146Elements.Mammography_Screening,patientHistoryBroadcastList,QPP146Elements.Benign)
            ||  wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit,m,QPP146Elements.Mammography_Screening,patientHistoryBroadcastList,QPP146Elements.Suspicious)
            ||  wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit,m,QPP146Elements.Mammography_Screening,patientHistoryBroadcastList,QPP146Elements.Highly_Suggestive_Of_Malignancy)
            ||  wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit,m,QPP146Elements.Mammography_Screening,patientHistoryBroadcastList,QPP146Elements.Known_Biopsy_Proven_Malignancy)
            ||  wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit,m,QPP146Elements.Mammography_Screening,patientHistoryBroadcastList,QPP146Elements.Mammogram_Assessment_Category)

          )
    )
  }



}