package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP282Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 282
* Measure Title              :- Dementia: Functional Status Assessment
* Measure Description        :- Percentage of patients with dementia for whom an assessment of functional status* was
*                               performed at least once in the last 12 months
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp282 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp282"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Backtracking List
      val patientHistoryList = getPatientHistory(sparkSession, ippRDD
        , QPP282Elements.Functional_Status_Assessment_G
      ).collect.toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)


      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exclusion
      val exceptionRDD = getExceptionRdd(metRDD, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(metRDD, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP - Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isDiagnosedOnEncounter(visit, m, QPP282Elements.Dementia)
        &&
        isVisitTypeIn(visit, m
          , QPP282Elements.Office_Visit
          , QPP282Elements.Behavioral_Neuropsych_Assessment
          , QPP282Elements.Home_Healthcare_Services
          , QPP282Elements.Health___Behavioral_Assessment___Individual
          , QPP282Elements.Health_And_Behavioral_Assessment__Reassessment
          , QPP282Elements.Health_And_Behavioral_Assessment___Initial
          , QPP282Elements.Psych_Visit___Diagnostic_Evaluation
          , QPP282Elements.Care_Services_In_Long_Term_Residential_Facility
          , QPP282Elements.Nursing_Facility_Visit
          , QPP282Elements.Psych_Visit___Psychotherapy
          , QPP282Elements.Occupational_Therapy_Evaluation
          , QPP282Elements.Chronic_Care_Management
          , QPP282Elements.Advance_Care_Planning
          , QPP282Elements.Individual_Physician_Supervision
          , QPP282Elements.Hospital_Inpatient_Visit_Subsequent
          , QPP282Elements.Inpatient_Consultation
          , QPP282Elements.Discharge_Services___Hospital_Inpatient
          , QPP282Elements.Hospital_Inpatient_Visit___Initial
          , QPP282Elements.Health_And_Behavior_Intervention
        )

        && !isTeleHealthModifier(visit, m
        , QPP282Elements.Behavioral_Neuropsych_Assessment
        , QPP282Elements.Nursing_Facility_Visit_Telehealth_Modifier
        , QPP282Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
        , QPP282Elements.Psych_Visit___Diagnostic_Evaluation_Telehealth_Modifier
        , QPP282Elements.Health_And_Behavioral_Assessment__Initial_Telehealth_Modifier
        , QPP282Elements.Health_And_Behavioral_Assessment_Reassessment_Telehealth_Modifier
        , QPP282Elements.Health_And_Behavioral_Assessment___Individual_Telehealth_Modifier
        , QPP282Elements.Home_Healthcare_Services_Telehealth_Modifier
        , QPP282Elements.Occupational_Therapy_Evaluation_Telehealth_Modifier
        , QPP282Elements.Office_Visit_Telehealth_Modifier
        , QPP282Elements.Psych_Visit___Psychotherapy_Telehealth_Modifier
        , QPP282Elements.Chronic_Care_Management_Telehealth_Modifier
        , QPP282Elements.Advance_Care_Planning_Telehealth_Modifier
        , QPP282Elements.Individual_Physician_Supervision_Telehealth_Modifier
        , QPP282Elements.Hospital_Inpatient_Visit_Subsequent_Telehealth_Modifier
        , QPP282Elements.Inpatient_Consultation_Telehealth_Modifier
        , QPP282Elements.Discharge_Services___Hospital_Inpatient_Telehealth_Modifier
        , QPP282Elements.Hospital_Inpatient_Visit___Initial_Telehealth_Modifier
        , QPP282Elements.Health_And_Behavior_Intervention_Telehealth_Modifier
      )
        && isPOSEncounterNotPerformed(visit, m, QPP282Elements.Pos_02)

    )

  }


  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        (
          wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP282Elements.Functional_Status_Assessment_G, 12, patientHistoryBroadcastList)
          )
          ||
          isAssessmentPerformedOnEncounter(visit, m, QPP282Elements.Functional_Status_Assessment_G)
        )
        && !isAssessmentPerformedOnEncounter(visit, m, QPP282Elements.Functional_Status_Reason_Not_Specified)

    )
  }

  // Exception Criteria
  def getExceptionRdd(intermediateException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      isAssessmentPerformedOnEncounter(visit, m, QPP282Elements.Assessment_Of_Functional_Status_Medical_Reason)
        ||
        isAssessmentPerformedOnEncounter(visit, m, QPP282Elements.Functional_Status_Reason_Not_Specified)
    )

  }

}
