package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{ MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 385
* Measure Title              :- Adult Primary Rhegmatogenous Retinal Detachment Surgery: Visual Acuity Improvement Within 90 Days of Surgery
* Measure Description        :- Patients aged 18 years and older who had surgery for primary rhegmatogenous retinal detachment and
*                               achieved an improvement in their visual acuity, from their preoperative level, within 90 days of surgery in the operative eye
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp385 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp385"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP385Elements.Primary_Rhegmatogenous_Retinal_Detachment,
      QPP385Elements.Visual_Acuity,
      QPP385Elements.Visual_Acuity_Improvement,
      QPP385Elements.Visual_Acuity_Eye
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    val patientHistoryRdd = getPatientHistory(sparkSession, initialRDD,
      QPP385Elements.Primary_Rhegmatogenous_Retinal_Detachment,
      QPP385Elements.Visual_Acuity,
      QPP385Elements.Visual_Acuity_Improvement,
      QPP385Elements.Visual_Acuity_Eye
    )

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRdd, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //eligible RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  //Patients aged 18 years and older who had surgery for primary rhegmatogenous retinal detachment
  def getIpp(initialRDD: RDD[CassandraRow], patienthistoryRdd: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
                            isPatientAdult(visit, m)
                        &&  isPhysicalExamPerformedBeforeSurgery(visit,m,QPP385Elements.Primary_Rhegmatogenous_Retinal_Detachment,patientHistoryBroadcastList,QPP385Elements.Visual_Acuity)
                        &&  isProcedurePerformedWithinXMonths(visit, m,QPP385Elements.Primary_Rhegmatogenous_Retinal_Detachment,9,patientHistoryBroadcastList)
                        &&  isPhysicalExamPerformedInXDaysAfterProcedure(visit,m,QPP385Elements.Primary_Rhegmatogenous_Retinal_Detachment,QPP385Elements.Visual_Acuity,90,patientHistoryBroadcastList)
                      //  &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,QPP385Elements.Primary_Rhegmatogenous_Retinal_Detachment_Eye,patientHistoryBroadcastList,QPP385Elements.Visual_Acuity_Eye)

                    )
  }

  //Surgical procedures that included the use of silicone oil
  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
                                isMedicationAdministeredOnEncounter(visit,m,QPP385Elements.Surgical_Procedures_Silicone_Oil_Use)
                            ||  isMedicationAdministeredOnEncounter(visit,m,QPP385Elements.Silicone_Oil)

                        )
  }

  //Patients who achieved an improvement in their visual acuity, from their preoperative level, within 90 days of surgery in the operative eye
  def getMet(intermediateA: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
                                (
                                        isPhysicalExamPerformedDuringEncounter(visit,m,QPP385Elements.Improvement_In_Visual_Acuity)
                                    ||  isPhysicalExamPerformedInXDaysAfterProcedure(visit,m,QPP385Elements.Primary_Rhegmatogenous_Retinal_Detachment,QPP385Elements.Visual_Acuity_Improvement,90,patientHistoryBroadcastList)
                                  )

                              )
  }

}
