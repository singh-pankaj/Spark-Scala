package com.figmd.janus.measureComputation.nonqpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp401
* Measure Title              :- Hepatitis C: Screening for Hepatocellular Carcinoma (HCC) in Patients with Cirrhosis
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of chronic hepatitis C
*                               cirrhosis who underwent imaging with either ultrasound, contrast enhanced CT or MRI for
*                               hepatocellular carcinoma (HCC) at least once within the 12 month submission period
* Calculation Implementation :- Patient Specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp401 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp401"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP401Elements.Cirrhosis
      , QPP401Elements.Chronic_Hepatitis_C
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect.toList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession,initialRDD,ippRDD,MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD)
      metRDD.cache()

      // Filter Exclusion
      val exceptionRDD = getExceptionRdd(metRDD)
      exceptionRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(metRDD, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }

  // IPP - Denominator criteria
  def getIpp(rdd: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m , QPP401Elements.Office_Visit)
        && wasDiagnosisInHistory(visit, m, QPP401Elements.Cirrhosis, patientHistory)
        && wasDiagnosisInHistory(visit, m, QPP401Elements.Chronic_Hepatitis_C, patientHistory)
    )

  }

  // Numerator Criteria
  def getMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
          isProcedurePerformedDuringEncounter(visit, m, QPP401Elements.Abdominal_Imaging_Hcc)
      ||  isProcedurePerformedDuringEncounter(visit, m, QPP401Elements.Abdominal_Imaging)
      ||  isProcedurePerformedDuringEncounter(visit, m, QPP401Elements.Ultrasound)
      ||  isProcedurePerformedDuringEncounter(visit, m, QPP401Elements.Contrast_Mri)
      ||  isProcedurePerformedDuringEncounter(visit, m, QPP401Elements.Contrast_Enhanced_Ct)
      )
      &&  !isProcedurePerformedDuringEncounter(visit, m, QPP401Elements.Abdominal_Imaging_Not_Met)
    )
  }

  //Exception criteria
  def getExceptionRdd(intermediateException: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      isProcedurePerformedDuringEncounter(visit, m, QPP401Elements.Abdominal_Imaging_Medical_Reason)
      ||
      isProcedurePerformedDuringEncounter(visit, m, QPP401Elements.Patient_Reason_Hcc)
    )
  }

}






