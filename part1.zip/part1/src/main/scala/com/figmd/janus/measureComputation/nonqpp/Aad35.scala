package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, AAD35Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD 35
* Measure Title              :- Biopsy: Use of Biopsy Site Photos or Directional Diagrams Prior to Surgery
* Measure Description        :- Proportion of biopsies by the clinician consistent with a cutaneous basal cell carcinoma
                                or squamous cell carcinoma (to include in situ disease) for whom a biopsy site photo or
                                detailed directional diagram was made available to the operating provider (may be the
                                same as the biopsying provider) prior to surgery.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Aad35 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "Aad35"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, rdd,
      AAD35Elements.Cutaneous_Scc_Or_Bcc,
      AAD35Elements.Referral_To_Operating_Provider,
      AAD35Elements.Destruction_Of_Malignant_Lesion,
      AAD35Elements.Surgical_Treatment_For_Cutaneous_Scc_Or_Bcc,
      AAD35Elements.Excision_Grp,
      AAD35Elements.Mohs_Microscopic_Technique,
      AAD35Elements.Referral_To_Operating_Provider,
      AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,
      AAD35Elements.Biopsy_Tracking_System,
      AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    // Filter IPP
    val ippRDD = getIpp(rdd, patientHistoryList)
    ippRDD.cache()

    // Filter Met
    val metRDD = getMet(ippRDD, patientHistoryList)
    // metRDD.cache()

    // Filter not met
    val notMetRDD = getSubtractRDD(ippRDD, metRDD)
    notMetRDD.cache()
    //

    saveToWebDM(rdd, ippRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
  }


  /*------------------------------------------------------------------------------------------------
   All cutaneous biopsies by the clinician consistent with cutaneous basal or squamous cell carcinoma (including in situ
    disease) that the clinician treated with an excision, electrodesiccation, curettage, cryosurgery, or Mohs surgery,
    or referred to another clinician to perform one of these procedures.
  ------------------------------------------------------------------------------------------------*/

  def getIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isProcedurePerformedDuringEncounter(visit,m,AAD35Elements.Cutaneous_Biopsy_Grp)
        && wasDiagnosedAfterProcedure(visit,m,AdminElements.Encounter_Date,patientHistoryList,AAD35Elements.Cutaneous_Scc_Or_Bcc)
        &&
        (
          wasAssessmentPerformedAfterDiagnosis(visit,m,AAD35Elements.Cutaneous_Scc_Or_Bcc,patientHistoryList,AAD35Elements.Referral_To_Operating_Provider)
            || wasAssessmentPerformedAfterDiagnosis(visit,m,AAD35Elements.Cutaneous_Scc_Or_Bcc,patientHistoryList,AAD35Elements.Destruction_Of_Malignant_Lesion)
            || wasAssessmentPerformedAfterDiagnosis(visit,m,AAD35Elements.Cutaneous_Scc_Or_Bcc,patientHistoryList,AAD35Elements.Surgical_Treatment_For_Cutaneous_Scc_Or_Bcc)
            || wasAssessmentPerformedAfterDiagnosis(visit,m,AAD35Elements.Cutaneous_Scc_Or_Bcc,patientHistoryList,AAD35Elements.Excision_Grp)
            || wasAssessmentPerformedAfterDiagnosis(visit,m,AAD35Elements.Cutaneous_Scc_Or_Bcc,patientHistoryList,AAD35Elements.Mohs_Microscopic_Technique)
          )
    )
  }


  /*------------------------------------------------------------------------------------------------
   Number of cutaneous biopsies by the clinician consistent with basal cell carcinoma or squamous cell carcinoma (to include
   in situ disease) that the clinician treated with an excision, electrodesiccation, curettage, cryosurgery or Mohs surgery,
   or referred to another clinician to perform one of these procedures for which a biopsy site photo or detailed
   directional diagram was made available to the operating provider prior to surgical treatment for use in his or her
   pre-op evaluation.
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRdd.filter(visit =>
      (
        wasCommunicationFromProviderToProviderwithSourceAfterEncounter(visit,m,AAD35Elements.Cutaneous_Biopsy_Grp,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Biopsy_Tracking_System,patientHistoryList)
          ||  wasCommunicationFromProviderToProviderwithSourceAfterEncounter(visit,m,AAD35Elements.Cutaneous_Biopsy_Grp,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram,patientHistoryList)
        )
        &&
        (
          wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Referral_To_Operating_Provider,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Biopsy_Tracking_System,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Referral_To_Operating_Provider,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Destruction_Of_Malignant_Lesion,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Biopsy_Tracking_System,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Destruction_Of_Malignant_Lesion,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Surgical_Treatment_For_Cutaneous_Scc_Or_Bcc,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Biopsy_Tracking_System,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Surgical_Treatment_For_Cutaneous_Scc_Or_Bcc,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Excision_Grp,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Biopsy_Tracking_System,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Excision_Grp,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Mohs_Microscopic_Technique,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Biopsy_Tracking_System,patientHistoryList)
            ||  wasCommunicationFromProviderToProviderwithSourceBefore(visit,m,AAD35Elements.Mohs_Microscopic_Technique,AAD35Elements.Availability_Of_Biopsy_Site_Photo_Or_Diagram,AAD35Elements.Methods_Of_Providing_Photo_Or_Diagram,patientHistoryList)

          )
    )
  }

}
