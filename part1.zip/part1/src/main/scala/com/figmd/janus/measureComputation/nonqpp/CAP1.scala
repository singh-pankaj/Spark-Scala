package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CAP1
* Measure Title              :- Turn-Around Time (TAT) - Standard biopsies
* Measure Description        :- Percentage of final pathology reports for biopsies that meet the maximum 2 business day turnaround time (TAT)
 *                              requirement (Report Date – Accession Date ≤ 2 business days).
*
* Calculation Implementation :- visit-specific (procedure-specific)
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Sawant
----------------------------------------------------------------------------------------------------------------------------*/

object CAP1 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "CAP1"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    var patient_history_list = getPatientHistory(sparkSession,initialRDD,
      CAP1Elements.Specimen_Accession_Date,
      CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_,
      CAP1Elements.Ihc_Or_Molecular_Studies_Or_Special_Stains,
      CAP1Elements.Specimen_Verification_Date,
      CAP1Elements.Pathology_Report_Verified,
      CAP1Elements.Report_Verification_Not_Met,
      CAP1Elements.Skin_Excision_With_Margin,
      CAP1Elements.Confirm_Case_Required_Consultation,
      CAP1Elements.Consultation_Catii
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)
    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryList)
    ippRDD.cache()

  if(checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

    // denominator RDD
    val denominatorRDD = ippRDD
    denominatorRDD.cache()

    // Filter Exclusions
    val exclusionRDD = getExclusionRDD(ippRDD, patientHistoryList)
    exclusionRDD.cache()

    val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMetRDD(intermediateA, patientHistoryList)
    metRDD.cache()

    // Filter Exceptions
    val intermediateB = getSubtractRDD(intermediateA, metRDD)
    intermediateB.cache()

    val exceptionRDD = getExceptionRDD(intermediateB, patientHistoryList)
    exceptionRDD.cache()

    // Filter not Met
    val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    patientHistoryList.destroy()
  }
  }
  /*-------------------------------------------------------------------------------------------------------------------------
   *  All final pathology reports for patients, regardless of age, who undergo a biopsy
   * (any biopsy; eg., CPT 88305, HCPCS code G0416), including those with special stains, immunohistochemistry (IHC), or molecular studies).
   * ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>

      (   isLaboratoryTestOrder(visit,m,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_,patientHistoryList)
        || (    isLaboratoryTestOrder(visit,m,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_,patientHistoryList)
        && isLaboratoryTestOrder(visit,m,CAP1Elements.Ihc_Or_Molecular_Studies_Or_Special_Stains,patientHistoryList)
        )
        )
        && (  wasLaboratoryTestOrderBefore(visit,m,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_,patientHistoryList,Seq(CAP1Elements.Specimen_Accession_Date))
        || (   wasLaboratoryTestOrderBefore(visit,m,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_,patientHistoryList,Seq(CAP1Elements.Specimen_Accession_Date))
        && wasLaboratoryTestOrderBefore(visit,m,CAP1Elements.Ihc_Or_Molecular_Studies_Or_Special_Stains,patientHistoryList,Seq(CAP1Elements.Specimen_Accession_Date))
        )
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
 Biopsy associated with any other specimen type (i.e., CPT: 88307, 88309, 99300, 88304).
 * Cytopathology cases (ie., Cell blocks) (CPT©: 88173, 88112).
 * Cases requiring decalcification (CPT 88311).
 * ----------------------------------------------------------------------------------------------------------------------------*/
  def getExclusionRDD(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
        ( isLaboratoryTestConcurrent(visit,m,CAP1Elements.Special_Handling_Cases_Grp,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_)
        ||  (  isLaboratoryTestConcurrent(visit,m,CAP1Elements.Special_Handling_Cases_Grp,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_)
        && isLaboratoryTestConcurrent(visit,m,CAP1Elements.Special_Handling_Cases_Grp,CAP1Elements.Ihc_Or_Molecular_Studies_Or_Special_Stains)
        )
        )
        || ( isLaboratoryTestConcurrent(visit,m,CAP1Elements.Confirm_More_Than_Just_Standard_88305_Biopsy_Ies__Were_Received,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_)
        ||  (  isLaboratoryTestConcurrent(visit,m,CAP1Elements.Confirm_More_Than_Just_Standard_88305_Biopsy_Ies__Were_Received,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_)
        && isLaboratoryTestConcurrent(visit,m,CAP1Elements.Confirm_More_Than_Just_Standard_88305_Biopsy_Ies__Were_Received,CAP1Elements.Ihc_Or_Molecular_Studies_Or_Special_Stains)
        )
        )
        || ( isLaboratoryTestConcurrent(visit,m,CAP1Elements.Cases_With_Special_Handling,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_)
        ||  (  isLaboratoryTestConcurrent(visit,m,CAP1Elements.Cases_With_Special_Handling,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_)
        && isLaboratoryTestConcurrent(visit,m,CAP1Elements.Cases_With_Special_Handling,CAP1Elements.Ihc_Or_Molecular_Studies_Or_Special_Stains)
        )
        )
    )

  }
  /*-------------------------------------------------------------------------------------------------------------------------
    Final pathology report for biopsies in the laboratory/hospital information system with result verified
    and reported by the laboratory, available to the requesting physician(s) within 2 business days.
   * ----------------------------------------------------------------------------------------------------------------------------*/
  def getMetRDD(intermediateA: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      //Laboratory Test, Performed: Specimen Verification Date" <= 2 day(s) starts after end of "Laboratory Test, Order: Specimen Accession Date"

      (    isLaboratoryTestPerformedAfterWithinXBusinessDays(visit,m,CAP1Elements.Specimen_Accession_Date,CAP1Elements.Specimen_Verification_Date,2,patientHistoryList)
        || isLaboratoryTestPerformAfterEncounter(visit,m,CAP1Elements.Pathology_Report_Verified,patientHistoryList,CAP1Elements.Specimen_Accession_Date)
        )
        &&   !(   isLaboratoryTestPerformAfterEncounter(visit,m,CAP1Elements.Report_Verification_Not_Met,patientHistoryList,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_)
        ||  (  isLaboratoryTestPerformAfterEncounter(visit,m,CAP1Elements.Report_Verification_Not_Met,patientHistoryList,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_)
        && isLaboratoryTestPerformAfterEncounter(visit,m,CAP1Elements.Report_Verification_Not_Met,patientHistoryList,CAP1Elements.Ihc_Or_Molecular_Studies_Or_Special_Stains)
        )
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Cases requiring intra-departmental or extra-departmental consultation.
  Skin excisions with margins coded as 88305.
   * ----------------------------------------------------------------------------------------------------------------------------*/
  def getExceptionRDD(intermediateB: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermediateB.filter(visit=>
      (      isLaboratoryTestConcurrent(visit,m,CAP1Elements.Skin_Excision_With_Margin,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_)
        ||  (  isLaboratoryTestConcurrent(visit,m,CAP1Elements.Skin_Excision_With_Margin,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_)
        && isLaboratoryTestConcurrent(visit,m,CAP1Elements.Skin_Excision_With_Margin,CAP1Elements.Ihc_Or_Molecular_Studies_Or_Special_Stains)
        )
        )
        || (   isCommunicationFromProviderToProviderConcurrent(visit,m,CAP1Elements.Confirm_Case_Required_Consultation,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_)
        ||  (  isCommunicationFromProviderToProviderConcurrent(visit,m,CAP1Elements.Confirm_Case_Required_Consultation,CAP1Elements.Confirm_Specimen_Is_A_Biopsy__88305_)
        && isCommunicationFromProviderToProviderConcurrent(visit,m,CAP1Elements.Confirm_Case_Required_Consultation,CAP1Elements.Ihc_Or_Molecular_Studies_Or_Special_Stains)
        )
        )

        ||     isCommunicationFromProvidertoProvider(visit,m,CAP1Elements.Consultation_Catii,patientHistoryList)

    )
  }

}
