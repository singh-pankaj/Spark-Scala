package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP146Elements, QPP217Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp217
* Measure Title              :- Functional Status Change for Patients with Knee Impairments
* Measure Description        :- A patient-reported outcome measure of risk-adjusted change in functional status for patients aged 14 years+ with
                                knee impairments. The change in functional status (FS) is assessed using the Knee FS patient-reported outcome
                                measure (PROM) (©Focus on Therapeutic Outcomes, Inc.). The measure is adjusted to patient characteristics
                                known to be associated with FS outcomes (risk adjusted) and used as a performance measure at the patient level, at
                                the individual clinician, and at the clinic level to assess quality. The measure is available as a computer adaptive test,
                                for reduced patient burden, or a short form (static survey)
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better qualityHigher Score indicat
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp217 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp217"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP217Elements.Follow_Up_Visit,
      QPP217Elements.Evaluation_Complete,
      QPP217Elements.Fsa_Knee_Reason_Not_Specified,
      QPP217Elements.Fsa_Knee_Patient_Not_Eligible,
      QPP217Elements.Chiropractic_Manipulative_Treatment,
      QPP217Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,
      QPP217Elements.Physical_Therapy,
      QPP217Elements.Occupational_Therapy,
      QPP217Elements.Discharge_After_Physical_Therapy,
      QPP217Elements.Discharge_After_Occupational_Therapy,
      QPP217Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score,
      QPP217Elements.Patients_Functional_Status_Score_At_Admission,
      QPP217Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,
      QPP217Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission,
      QPP217Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score,
      QPP217Elements.Patients_Functional_Status_Change_Score,
      QPP217Elements.Predicted_Functional_Status_Change_Score,
      QPP217Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission,
      QPP217Elements.Fsa_Knee,
      QPP217Elements.Foto_s_Status_Survey


    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exceptions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()


      // Filter Exceptions
      val exceptionRDD = getException(intermediateA, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*
  All patients aged 65 years and older who have a history of falls (history of falls is defined as 2 or more falls in
  the past year or any fall with injury in the past year). Documentation of patient reported history of falls is sufficient
   */

  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isAgeAbove(visit, m, true, 14)
        && (
        isEncounterPerformedWithDischargeStatus(visit, m, QPP217Elements.Physical_Therapy, QPP217Elements.Discharge_After_Physical_Therapy, patientHistoryBroadcastList)
          || isEncounterPerformedWithDischargeStatus(visit, m, QPP217Elements.Occupational_Therapy, QPP217Elements.Discharge_After_Occupational_Therapy, patientHistoryBroadcastList)
        )
        && isDiagnosisOnEncounter(visit, m, QPP217Elements.Functional_Deficit_Knee)
    )
  }

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        (
          (
            isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Physical_Therapy)
              && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.Fsa_Knee_Patient_Refusal)
            )
            ||
            (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Occupational_Therapy)
                && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.Fsa_Knee_Patient_Refusal)
              )
            ||
            (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Follow_Up_Visit)
                && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.Fsa_Knee_Patient_Refusal)
              )
            || (
            isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Chiropractic_Manipulative_Treatment)
              && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.Fsa_Knee_Patient_Refusal)
            )
            || (
            isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Physical_Therapy)
              && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.Fsa_Knee_Patient_Refusal)
            )
            || (
            isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy)
              && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.Fsa_Knee_Patient_Refusal)
            )
            || (
            isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Evaluation_Complete)
              && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.Fsa_Knee_Patient_Refusal)
            )
          )
          ||
          (
            (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Physical_Therapy)
                && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.Patient_Refusal)
              )
              ||
              (
                isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Occupational_Therapy)
                  && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.Patient_Refusal)
                )
              ||
              (
                isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Follow_Up_Visit)
                  && isCommunicationFromProviderToPatientOnEncounter(visit, m, QPP217Elements.Patient_Refusal)
                )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Chiropractic_Manipulative_Treatment)
                && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.Patient_Refusal)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Physical_Therapy)
                && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.Patient_Refusal)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy)
                && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.Patient_Refusal)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Evaluation_Complete)
                && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.Patient_Refusal)
              )
            )
          ||
          (
            (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Physical_Therapy)
                && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Unable_To_Complete_The_Foto_Knee_Intake_Prom)
              )
              ||
              (
                isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Occupational_Therapy)
                  && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Unable_To_Complete_The_Foto_Knee_Intake_Prom)
                )
              ||
              (
                isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Follow_Up_Visit)
                  && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Unable_To_Complete_The_Foto_Knee_Intake_Prom)
                )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Chiropractic_Manipulative_Treatment)
                && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Unable_To_Complete_The_Foto_Knee_Intake_Prom)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Physical_Therapy)
                && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Unable_To_Complete_The_Foto_Knee_Intake_Prom)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy)
                && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Unable_To_Complete_The_Foto_Knee_Intake_Prom)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Evaluation_Complete)
                && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Unable_To_Complete_The_Foto_Knee_Intake_Prom)
              )
            )
          ||
          (
            (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Physical_Therapy)
                && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.An_Adequate_Proxy_Is_Not_Available)
              )
              ||
              (
                isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Occupational_Therapy)
                  && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.An_Adequate_Proxy_Is_Not_Available)
                )
              ||
              (
                isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Follow_Up_Visit)
                  && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.An_Adequate_Proxy_Is_Not_Available)
                )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Chiropractic_Manipulative_Treatment)
                && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.An_Adequate_Proxy_Is_Not_Available)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Physical_Therapy)
                && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.An_Adequate_Proxy_Is_Not_Available)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy)
                && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.An_Adequate_Proxy_Is_Not_Available)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Evaluation_Complete)
                && isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP217Elements.An_Adequate_Proxy_Is_Not_Available)
              )
            )
          ||
          (
            (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Physical_Therapy)
                && isDiagnosisOnEncounter(visit, m, QPP217Elements.Severe_Mental_Incapacity_Or_Language_Incompatibility)
              )
              ||
              (
                isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Occupational_Therapy)
                  && isDiagnosisOnEncounter(visit, m, QPP217Elements.Severe_Mental_Incapacity_Or_Language_Incompatibility)
                )
              ||
              (
                isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Follow_Up_Visit)
                  && isDiagnosisOnEncounter(visit, m, QPP217Elements.Severe_Mental_Incapacity_Or_Language_Incompatibility)
                )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Chiropractic_Manipulative_Treatment)
                && isDiagnosisOnEncounter(visit, m, QPP217Elements.Severe_Mental_Incapacity_Or_Language_Incompatibility)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Physical_Therapy)
                && isDiagnosisOnEncounter(visit, m, QPP217Elements.Severe_Mental_Incapacity_Or_Language_Incompatibility)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy)
                && isDiagnosisOnEncounter(visit, m, QPP217Elements.Severe_Mental_Incapacity_Or_Language_Incompatibility)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Evaluation_Complete)
                && isDiagnosisOnEncounter(visit, m, QPP217Elements.Severe_Mental_Incapacity_Or_Language_Incompatibility)
              )
            )
        )
        || (
        (
          (
            isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Physical_Therapy)
              && isDiagnosisOnEncounter(visit, m, QPP217Elements.Blindness)
            )
            ||
            (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Occupational_Therapy)
                && isDiagnosisOnEncounter(visit, m, QPP217Elements.Blindness)
              )
            ||
            (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Follow_Up_Visit)
                && isDiagnosisOnEncounter(visit, m, QPP217Elements.Blindness)
              )
            || (
            isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Chiropractic_Manipulative_Treatment)
              && isDiagnosisOnEncounter(visit, m, QPP217Elements.Blindness)
            )
            || (
            isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Physical_Therapy)
              && isDiagnosisOnEncounter(visit, m, QPP217Elements.Blindness)
            )
            || (
            isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy)
              && isDiagnosisOnEncounter(visit, m, QPP217Elements.Blindness)
            )
            || (
            isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Evaluation_Complete)
              && isDiagnosisOnEncounter(visit, m, QPP217Elements.Blindness)
            )
          )
          ||
          (
            (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Physical_Therapy)
                && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Illiteracy)
              )
              ||
              (
                isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Occupational_Therapy)
                  && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Illiteracy)
                )
              ||
              (
                isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Follow_Up_Visit)
                  && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Illiteracy)
                )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Chiropractic_Manipulative_Treatment)
                && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Illiteracy)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Physical_Therapy)
                && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Illiteracy)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy)
                && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Illiteracy)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Evaluation_Complete)
                && isPatientCharacteristicDuringEncounter(visit, m, QPP217Elements.Illiteracy)
              )
            )
          ||
          (
            (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Physical_Therapy)
                && isDiagnosisOnEncounter(visit, m, QPP217Elements.Psychotic_Disorder_Or_Related_Condition)
              )
              ||
              (
                isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Occupational_Therapy)
                  && isDiagnosisOnEncounter(visit, m, QPP217Elements.Psychotic_Disorder_Or_Related_Condition)
                )
              ||
              (
                isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Follow_Up_Visit)
                  && isDiagnosisOnEncounter(visit, m, QPP217Elements.Psychotic_Disorder_Or_Related_Condition)
                )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Chiropractic_Manipulative_Treatment)
                && isDiagnosisOnEncounter(visit, m, QPP217Elements.Psychotic_Disorder_Or_Related_Condition)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Physical_Therapy)
                && isDiagnosisOnEncounter(visit, m, QPP217Elements.Psychotic_Disorder_Or_Related_Condition)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy)
                && isDiagnosisOnEncounter(visit, m, QPP217Elements.Psychotic_Disorder_Or_Related_Condition)
              )
              || (
              isEncounterPerformedOnEncounter(visit, m, QPP217Elements.Evaluation_Complete)
                && isDiagnosisOnEncounter(visit, m, QPP217Elements.Psychotic_Disorder_Or_Related_Condition)
              )
            )


        )
    )
  }


  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>

      (
        (
          wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score, 0, "gt", patientHistoryBroadcastList)
            || wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score, 0, "lt", patientHistoryBroadcastList)
            || wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score, 0, "eq", patientHistoryBroadcastList)
          )
          ||
          (
            isAssessmentPerformedDuringProcedure(visit, m, QPP217Elements.Patients_Functional_Status_Score_At_Admission, QPP217Elements.Patients_Functional_Status_Score_At_Admission_Date, QPP217Elements.Physical_Therapy, QPP217Elements.Physical_Therapy_Date)
              && isAssessmentPerformedDuringProcedure(visit, m, QPP217Elements.Patients_Functional_Status_Score_At_Discharge, QPP217Elements.Patients_Functional_Status_Score_At_Discharge_Date, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Discharge_After_Physical_Therapy_Date)
              && wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission, patientHistoryBroadcastList)
              && (
              isAssessmentPerformedDuringProcedure(visit, m, QPP217Elements.Predicted_Functional_Status_Change_Score, QPP217Elements.Predicted_Functional_Status_Change_Score_Date, QPP217Elements.Physical_Therapy, QPP217Elements.Physical_Therapy_Date)
                || isAssessmentPerformedDuringProcedure(visit, m, QPP217Elements.Predicted_Functional_Status_Change_Score, QPP217Elements.Predicted_Functional_Status_Change_Score_Date, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Discharge_After_Physical_Therapy_Date)

              )
              && wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score, patientHistoryBroadcastList)

            )
          ||
          (
            wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Patients_Functional_Status_Change_Score, patientHistoryBroadcastList)
              && wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Predicted_Functional_Status_Change_Score, patientHistoryBroadcastList)
              && wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission, patientHistoryBroadcastList)
            )
          || wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Fsa_Knee, patientHistoryBroadcastList)


        )
        ||

        (
          (
            wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score, 0, "gt", patientHistoryBroadcastList)
              || wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score, 0, "lt", patientHistoryBroadcastList)
              || wasAssessmentPerformedWithScoreStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Risk_Adjusted_Functional_Status_Change_Residual_Score, 0, "eq", patientHistoryBroadcastList)
            )
            ||
            (
              isAssessmentPerformedDuringProcedure(visit, m, QPP217Elements.Patients_Functional_Status_Score_At_Admission, QPP217Elements.Patients_Functional_Status_Score_At_Admission_Date, QPP217Elements.Occupational_Therapy, QPP217Elements.Occupational_Therapy_Date)
                && isAssessmentPerformedDuringProcedure(visit, m, QPP217Elements.Patients_Functional_Status_Score_At_Discharge, QPP217Elements.Patients_Functional_Status_Score_At_Discharge_Date, QPP217Elements.Discharge_After_Occupational_Therapy, QPP217Elements.Discharge_After_Occupational_Therapy_Date)
                && wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy, QPP217Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission, patientHistoryBroadcastList)
                && (
                isAssessmentPerformedDuringProcedure(visit, m, QPP217Elements.Predicted_Functional_Status_Change_Score, QPP217Elements.Predicted_Functional_Status_Change_Score_Date, QPP217Elements.Occupational_Therapy, QPP217Elements.Occupational_Therapy_Date)
                  || isAssessmentPerformedDuringProcedure(visit, m, QPP217Elements.Predicted_Functional_Status_Change_Score, QPP217Elements.Predicted_Functional_Status_Change_Score_Date, QPP217Elements.Discharge_After_Occupational_Therapy, QPP217Elements.Discharge_After_Occupational_Therapy_Date)

                )
                && wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy, QPP217Elements.Patients_Fs_Change_Score___Predicted_Fs_Change_Score, patientHistoryBroadcastList)

              )
            ||
            (
              wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy, QPP217Elements.Patients_Functional_Status_Change_Score, patientHistoryBroadcastList)
                && wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy, QPP217Elements.Predicted_Functional_Status_Change_Score, patientHistoryBroadcastList)
                && wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy, QPP217Elements.Patients_Fss_At_Discharge___Patients_Fss_At_Admission, patientHistoryBroadcastList)
              )
            || wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy, QPP217Elements.Fsa_Knee, patientHistoryBroadcastList)


          )
          && !(
          wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Fsa_Knee_Reason_Not_Specified, patientHistoryBroadcastList)
            || wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy, QPP217Elements.Fsa_Knee_Reason_Not_Specified, patientHistoryBroadcastList)
            || wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Evaluation_Complete, QPP217Elements.Fsa_Knee_Reason_Not_Specified, patientHistoryBroadcastList)

          )
    )
  }

  def getException(intermediateRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateRdd.filter(visit =>
      (
        (
          wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Physical_Therapy, QPP217Elements.Fsa_Knee_Patient_Not_Eligible, patientHistoryBroadcastList)
            || wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Occupational_Therapy, QPP217Elements.Fsa_Knee_Patient_Not_Eligible, patientHistoryBroadcastList)
            || wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Follow_Up_Visit, QPP217Elements.Fsa_Knee_Patient_Not_Eligible, patientHistoryBroadcastList)
            || wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Chiropractic_Manipulative_Treatment, QPP217Elements.Fsa_Knee_Patient_Not_Eligible, patientHistoryBroadcastList)

          )
          ||
          (
            wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Physical_Therapy, QPP217Elements.Foto_s_Status_Survey, patientHistoryBroadcastList)
              || wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Occupational_Therapy, QPP217Elements.Foto_s_Status_Survey, patientHistoryBroadcastList)
              || wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Follow_Up_Visit, QPP217Elements.Foto_s_Status_Survey, patientHistoryBroadcastList)
              || wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Chiropractic_Manipulative_Treatment, QPP217Elements.Foto_s_Status_Survey, patientHistoryBroadcastList)

            )

        )
        ||
        (
          (
            wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Fsa_Knee_Patient_Not_Eligible, patientHistoryBroadcastList)
              || wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy, QPP217Elements.Fsa_Knee_Patient_Not_Eligible, patientHistoryBroadcastList)
              || wasAssessmentPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Evaluation_Complete, QPP217Elements.Fsa_Knee_Patient_Not_Eligible, patientHistoryBroadcastList)


            )
            ||
            (
              wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Physical_Therapy, QPP217Elements.Foto_s_Status_Survey, patientHistoryBroadcastList)
                || wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Discharge_After_Occupational_Therapy, QPP217Elements.Foto_s_Status_Survey, patientHistoryBroadcastList)
                || wasInterventionPerformedStartsAfterOrConcurrentWithStartOf(visit, m, QPP217Elements.Evaluation_Complete, QPP217Elements.Foto_s_Status_Survey, patientHistoryBroadcastList)


              )

          )
    )

  }

}

