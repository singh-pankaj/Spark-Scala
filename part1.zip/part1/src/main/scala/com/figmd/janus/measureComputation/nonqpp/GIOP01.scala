package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{GIOP01Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- GIOP 01
* Measure Title              :- Glucocorticoid-induced Osteoporosis (GIOP): Osteoporosis Risk Assessment for Patients Taking Glucocorticoids
* Measure Description        :- Percentage of patients aged 50 and older who are newly started on an oral glucocorticoid for at least 90 days
*                               in the year prior to the measurement period who have had a standardized osteoporotic fracture risk assessment
*                               or dual x-ray absorptiometry within 1 year after starting an oral glucocorticoid.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object GIOP01 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "GIOP01"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patient_history_rdd = getPatientHistory(sparkSession, initialRDD,
      GIOP01Elements.Outpatient_Consultation,
      GIOP01Elements.Office_Visit,
      GIOP01Elements.Nursing_Facility_Visit,
      GIOP01Elements.Face_To_Face_Interaction,
      GIOP01Elements.Home_Healthcare_Services,
      GIOP01Elements.Care_Services_In_Long_Term_Residential_Facility,
      GIOP01Elements.Oral_Glucocorticoid,
      GIOP01Elements.Frax_Major_Osteoporotic_Fracture_Risk_Assessment,
      GIOP01Elements.Dxa_Scan,
      GIOP01Elements.Antiresorptive_Agent,
      GIOP01Elements.Anabolic_Agent)
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_rdd.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patient_history_rdd, patientHistoryList)
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Filter denominator Exclusions
      val denominatorRDD = getDenominat(sparkSession, ippRDD, patient_history_rdd, patientHistoryList)
      denominatorRDD.cache()

      // Filter denominator Exclusions
      val denominatorExclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      denominatorExclusionRDD.cache()

      //eligible initial population RDD
      val intermediateRDD = getSubtractRDD(denominatorRDD, denominatorExclusionRDD)

      // Filter Intermediate Met
      val intermediateB = getMet(sparkSession, intermediateRDD, patient_history_rdd, patientHistoryList)
      intermediateB.cache()

      // Filter Numerator Exclusion
      val exceptionRDD = getExceptionRdd(intermediateB, patientHistoryList)

      //Met initialRDD
      val metRDD = getSubtractRDD(intermediateB, exceptionRDD)

      // Filter not met
      val intermediateC = getSubtractRDD(intermediateB, metRDD)
      val notMetRDD = getSubtractRDD(intermediateC, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, denominatorExclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  *All patients age 50 and older who have had at least two office based encounters during the measurement period.
  *-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patienthistoryRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)


    val encounterCountList: List[(String, Int)] = countElement(patienthistoryRdd, m, GIOP01Elements.Outpatient_Consultation,
      GIOP01Elements.Office_Visit,
      GIOP01Elements.Nursing_Facility_Visit,
      GIOP01Elements.Face_To_Face_Interaction,
      GIOP01Elements.Home_Healthcare_Services,
      GIOP01Elements.Care_Services_In_Long_Term_Residential_Facility)

    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 50)
        && isVisitTypeIn(visit, m, GIOP01Elements.Outpatient_Consultation,
        GIOP01Elements.Office_Visit,
        GIOP01Elements.Nursing_Facility_Visit,
        GIOP01Elements.Face_To_Face_Interaction,
        GIOP01Elements.Home_Healthcare_Services,
        GIOP01Elements.Care_Services_In_Long_Term_Residential_Facility)
        && getEncounterCountFromHistory(visit, m, 2, true, encounterCountList)

    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   Equals initial population who are newly started on an oral glucocorticoid for at least 90 days in the year prior to the measurement period.
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getDenominat(spark:SparkSession, rdd: RDD[CassandraRow], patienthistoryRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    val leastList = spark.sparkContext.broadcast(leastRecentPatientList(patienthistoryRdd, GIOP01Elements.Oral_Glucocorticoid))
    val oralGCountList: List[(String, Int)] = countElementWithinMonthsInHistory(patienthistoryRdd, m, 12, GIOP01Elements.Oral_Glucocorticoid)

    rdd.filter(visit =>
      getEncounterCountFromHistory(visit, m, 90, true, oralGCountList)
      && wasElementBeforeFirstOccurenceOfElementWithInXmonth(visit, m, 12, GIOP01Elements.Oral_Glucocorticoid, leastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  * Patients who have had a standardized osteoporotic fracture risk assessment or dual x-ray absorptiometry within 1 year after starting an oral glucocorticoid.
  * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
  def getMet(spark:SparkSession, rdd: RDD[CassandraRow], patienthistoryRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    val leastList = spark.sparkContext.broadcast(leastRecentPatientList(patienthistoryRdd, GIOP01Elements.Oral_Glucocorticoid))
    val fraxCountList = countElementBeforeFirstOtherElementWithinXMonthsInHistory(patienthistoryRdd, leastList, m, 12, GIOP01Elements.Frax_Major_Osteoporotic_Fracture_Risk_Assessment)
    val daxCountList = countElementBeforeFirstOtherElementWithinXMonthsInHistory(patienthistoryRdd, leastList, m, 12, GIOP01Elements.Dxa_Scan)


    rdd.filter(visit =>
      getEncounterCountFromHistory(visit, m, 90, true, fraxCountList)
      || getEncounterCountFromHistory(visit, m, 90, true, daxCountList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  * Patients taking an anti-resorptive or anabolic agent during the measurement period.
  *----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- */
  def getExceptionRdd(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      isMedicationActiveOrdered(visit, m, GIOP01Elements.Antiresorptive_Agent, patientHistoryList)
      || isMedicationActiveOrdered(visit, m, GIOP01Elements.Anabolic_Agent, patientHistoryList)
    )
  }

}
