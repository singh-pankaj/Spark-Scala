package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, AAO26Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAO 26
* Measure Title              :- Otitis Media with Effusion: Assessment of Tympanic Membrane Mobility
* Measure Description        :- Percentage of patient visits for those patients aged 2 months through 12 years with a diagnosis of
* 								              OME with assessment of tympanic membrane mobility with pneumatic otoscopy or tympanometry.
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/

object AAO26 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO26"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //filter denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exceptions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD)
      metRDD.cache()

      val intermediateRDD = ippRDD.subtract(metRDD)
      intermediateRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateRDD)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }

  }

/*
Percentage of patients visits for those patients aged 2 months through 12 years with a diagnosis of OME with assessment of tympanic membrane mobility with pneumatic otoscopy or tympanometry.
 */
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
      isAgeAboveInMonth(visit, m, true,2)
      && isAgeBelow(visit, m, false, 13)
      && isVisitTypeIn(visit, m, AAO26Elements.Office_Visit,
                              AAO26Elements.Outpatient_Consultation,
                              AAO26Elements.Preventive_Care__Established_Office_Visit__0_To_17,
                              AAO26Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17)
      && isDiagnosedOnEncounter(visit, m, AAO26Elements.Diagnosis_Of_Otitis_Media_With_Effusion)

    )
  }
//Patient visits with assessment of tympanic membrane mobility with pneumatic otoscopy or tympanometry.
  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        isInterventionPerformedOnEncounter(visit, m, AAO26Elements.Assessment_Of_Tympanic_Membrane_Mobility)
        || isInterventionPerformedOnEncounter(visit, m, AAO26Elements.Assessment_Tympanic_Membrane_Mobility)
      ))
  }
/*
Documentation of medical reason(s) for not assessing tympanic membrane mobility with pneumatic otoscopy or tympanometry.

Documentation of patient reason(s) for not assessing tympanic membrane mobility with pneumatic otoscopy or tympanometry.
 */

  def getException(intermediateRdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermediateRdd.filter(visit =>
      isInterventionNotDoneDuringEncounter(visit,m,AAO26Elements.Assessment_Of_Tympanic_Membrane_Mobility_Medical_Reason)
      || isInterventionNotDoneDuringEncounter(visit,m,AAO26Elements.Medical_Reason_Tympanic_Membrane_Mobility)
      || isInterventionNotDoneDuringEncounter(visit,m, AAO26Elements.Assessment_Of_Tympanic_Membrane_Mobiltiy_Patient_Reason)
      || isInterventionNotDoneDuringEncounter(visit,m,AAO26Elements.Patient_Reason_Tympanic_Membrane)
        )
  }

}

