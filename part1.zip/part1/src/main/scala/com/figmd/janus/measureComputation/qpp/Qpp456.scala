package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements,  MeasureProperty, QPP456Elements}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp456
* Measure Title              :- Percentage of Patients Who Died From Cancer Not Admitted To Hospice (lower score – better)
* Measure Description        :- Percentage of patients who died from cancer not admitted to hospice
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp456 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "QPP456"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patinetHistoryRDD = getPatientHistory(sparkSession, initialRDD, QPP456Elements.Office_Visit)


    var patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP456Elements.Cancer,
      QPP456Elements.Office_Visit,
      QPP456Elements.Hospice_Care_Not_Done,
      QPP456Elements.Hospice_Care_G,
      QPP456Elements.Hospice_Care_Services,
      QPP456Elements.Death_Cancer,
      QPP456Elements.Death_Due_To_Cancer
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patinetHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
          // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD,exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  //Patients who died from cancer
  def getIpp(initialRDD: RDD[CassandraRow], patineHistoryRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val countElementList: List[(String, Int)] = countElement(patineHistoryRDD, m, QPP456Elements.Office_Visit)

    initialRDD.filter(visit =>
      wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP456Elements.Cancer, patientHistoryList)
        && getEncounterCountFromHistory(visit, m, 2, true, countElementList)
        &&
        (
          isPatientCharacteristic(visit, m, QPP456Elements.Death_Cancer, patientHistoryList)
            || isPatientCharacteristic(visit, m, QPP456Elements.Death_Due_To_Cancer, patientHistoryList)
          )
    )
  }

  //Patients not admitted to hospice
  def getMet(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        wasInterventionPerformedNotDoneInBetweenEvents(visit, m, AdminElements.Encounter_Date, QPP456Elements.Death_Cancer, QPP456Elements.Hospice_Care_Not_Done, patientHistoryList)
          || wasInterventionPerformedNotDoneInBetweenEvents(visit, m, AdminElements.Encounter_Date, QPP456Elements.Death_Due_To_Cancer, QPP456Elements.Hospice_Care_Not_Done, patientHistoryList)
        )
        && !(
        wasInterventionPerformedDoneInBetweenEvents(visit, m, AdminElements.Encounter_Date, QPP456Elements.Death_Cancer, QPP456Elements.Hospice_Care_G, patientHistoryList)
          || wasInterventionPerformedDoneInBetweenEvents(visit, m, AdminElements.Encounter_Date, QPP456Elements.Death_Cancer, QPP456Elements.Hospice_Care_Services, patientHistoryList)
        )
    )
  }

}
