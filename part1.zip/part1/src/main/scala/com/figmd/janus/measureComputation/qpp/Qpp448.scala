package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP192Elements, QPP448Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 448
* Measure Title              :- Appropriate Workup Prior to Endometrial Ablation
* Measure Description        :- Percentage of women, aged 18 years and older, who undergo endometrial sampling or
                                hysteroscopy with biopsy and results documented before undergoing an endometrial ablation
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp448 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp448"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP448Elements.Endometrial_Ablation_Id
      , QPP448Elements.Endometrial_Ablation
      , QPP448Elements.Endometrial_Ablation_Pcs
      , QPP448Elements.Endometrial_Sampling_And_Hysteroscopy
      , QPP448Elements.Endometrial_Sampling_Or_Hysteroscopy_With_Biopsy
      , QPP448Elements.Endo_Samp_Or_Hystero_Not_Met
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      val denominatorRDD=ippRDD
      denominatorRDD.cache()
      /*exclusion RDD*/
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*------------------------------------------------------------------------------
    All women aged 18 years and older who undergo an endometrial ablation procedure during the measurement year
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)


    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isFemale(visit, m)
        && (
        isProcedurePerformedDuringEncounter(visit, m, QPP448Elements.Endometrial_Ablation)
          || isProcedurePerformedDuringEncounter(visit, m, QPP448Elements.Endometrial_Ablation_Pcs)
        )

    )
  }

  /*------------------------------------------------------------------------------
     Women who had an endometrial ablation procedure during the year prior to the index date (exclusive of the index date)
   ------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      isProcedurePerformed(visit, m, QPP448Elements.Endometrial_Ablation_Id, patientHistoryList)
        || wasProcedurePerformedBeforeEncounterWithinXYear(visit, m, QPP448Elements.Endometrial_Ablation, 1, patientHistoryList)
        || wasProcedurePerformedBeforeEncounterWithinXYear(visit, m, QPP448Elements.Endometrial_Ablation_Pcs, 1, patientHistoryList)
    )
  }

  /*------------------------------------------------------------------------------
    Women who received endometrial sampling or hysteroscopy with biopsy and results documented during the year
    prior to the index date (exclusive of the index date) of the endometrial ablation
   ------------------------------------ ------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        wasProcedurePerformedBeforeEncounterWithinXYear(visit, m, QPP448Elements.Endometrial_Sampling_And_Hysteroscopy, 1, patientHistoryList)
          || wasProcedurePerformedBeforeEncounterWithinXYear(visit, m, QPP448Elements.Endometrial_Sampling_Or_Hysteroscopy_With_Biopsy, 1, patientHistoryList)
        )
        && !wasProcedurePerformedBeforeEncounterWithinXYear(visit, m, QPP448Elements.Endo_Samp_Or_Hystero_Not_Met, 1, patientHistoryList)
    )
  }
}