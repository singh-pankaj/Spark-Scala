package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.{Measure, MeasureUpdate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, ACEP25Elements}
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}
/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACEP 25
* Measure Title              :- Tobacco Use: Screening and Cessation Intervention for Patients with Asthma and COPD
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of asthma or COPD seen
*                               in the ED who were screened for tobacco use during any ED encounter AND who received
*                               tobacco cessation intervention if identified as a tobacco user
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/
object Acep25 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Acep25"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, initialRDD,
      ACEP25Elements.Limited_Life_Expectancy,
      ACEP25Elements.Tobacco_Use_Cessation_Pharmacotherapy).collect.toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //filter denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }

  }

//All patients aged 18 years and older with a diagnosis of asthma or COPD seen in the ED
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit => isPatientAdult(visit,m)
        && isVisitTypeIn(visit, m,
        ACEP25Elements.Critical_Care_Evaluation_And_Management,
        ACEP25Elements.Emergency_Department_Visit)
        && isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP25Elements.Asthma, ACEP25Elements.Chronic_Obstructive_Pulmonary_Disease, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP25Elements.Critical_Care_Evaluation_And_Management_Date)
    )

  }

//Patients who were screened for tobacco use during any ED encounter AND who received tobacco cessation intervention if identified as a tobacco user

  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      (
        isAssessmentDuringEDOrCCEncounter(visit, m, ACEP25Elements.Tobacco_Use_Screening, ACEP25Elements.Tobacco_Use_Screening_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP25Elements.Critical_Care_Evaluation_And_Management_Date)
        && isAssessmentDuringEDOrCCEncounter(visit, m, ACEP25Elements.Tobacco_Non_User, ACEP25Elements.Tobacco_Non_User_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP25Elements.Critical_Care_Evaluation_And_Management_Date)
      ) ||
        (
          (
            isAssessmentDuringEDOrCCEncounter(visit, m, ACEP25Elements.Tobacco_Use_Screening, ACEP25Elements.Tobacco_Use_Screening_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP25Elements.Critical_Care_Evaluation_And_Management_Date)
            && isAssessmentDuringEDOrCCEncounter(visit, m, ACEP25Elements.Tobacco_User, ACEP25Elements.Tobacco_User_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP25Elements.Critical_Care_Evaluation_And_Management_Date)
          )
          &&
          (
                 isInterventionPerformedDuringEDOrCCEncounter(visit, m, ACEP25Elements.Tobacco_Use_Cessation_Counseling, ACEP25Elements.Tobacco_Use_Cessation_Counseling_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP25Elements.Critical_Care_Evaluation_And_Management_Date)
              || wasMedicationActiveInHistory(visit,m, ACEP25Elements.Tobacco_Use_Cessation_Pharmacotherapy,patientHistoryList)
              || isMedicationOrdered(visit, m,patientHistoryList, ACEP25Elements.Tobacco_Use_Cessation_Pharmacotherapy)
          )
       )
    )
  }
//Documented medical reason(s) for not screening for tobacco use OR for not providing tobacco cessation intervention for patients identified as tobacco users (eg, limited life expectancy, other medical reasons)
  def getExceptionRDD(intermediateRdd: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCEPTION, globalStartDate, globalEndDate)

    intermediateRdd.filter(visit =>
      wasDiagnosedInHistory(visit,m, ACEP25Elements.Limited_Life_Expectancy,patientHistoryList)
        || isAssessmentNotPerformedDuringEDOrCCEncounter(visit,m, ACEP25Elements.Medical_Reason, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP25Elements.Critical_Care_Evaluation_And_Management_Date)
        || isInterventionNotPerformedDuringEDOrCCEncounter(visit,m, ACEP25Elements.Medical_Reason, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP25Elements.Critical_Care_Evaluation_And_Management_Date)
        || isMedicationOrderNotDoneDuringEDOrCCEncounter(visit,m, ACEP25Elements.Medical_Reason, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP25Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }

}







