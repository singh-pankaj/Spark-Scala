package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.IRIS24Elements
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.MeasureProperty
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- IRIS 24
* Measure Title              :- Refractive Surgery:  Postoperative correction within +/- 0.5 Diopter of the Intended Correction
* Measure Description        :- Percentage of patients with a postoperative spherical equivalent (SE) within +/- 0.5 Diopter (D) of the intended correction or SE
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/
object IRIS24  extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "IRIS24"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      IRIS24Elements.Myopia,
      IRIS24Elements.Refractive_Surgery_1,
      IRIS24Elements.Refractive_Surgery__Eye,
      IRIS24Elements.Actual_Refraction__Eye,
      IRIS24Elements.Actual_Refraction)

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList,patient_history_list)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

    // denominator RDD
    val denominatorRDD = ippRDD
    denominatorRDD.cache()

    // Filter Exclusions
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter Met
    val metRDD = getMet(ippRDD, patientHistoryList)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getSubtractRDD(ippRDD, metRDD)
    notMetRDD.cache()

    saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }

  }

  //All patients aged 18 years or greater and diagnosis of myopia and receiving refractive surgery treatment
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]],patient_history_list:RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit=>
      isAgeAbove(visit, m, true)
      &&
        (isProcedurePerformedDuringEncounter(visit,m,IRIS24Elements.Refractive_Surgery_1)||
          (
            isProcedurePerformedDuringEncounter(visit,m,IRIS24Elements.Refractive_Surgery_3)
            &&
            isProcedurePerformedDuringEncounter(visit,m,IRIS24Elements.Refractive_Surgery_Keywords)
          )
        )

      &&
        (
          wasDiagnosisInHistory(visit, m, IRIS24Elements.Myopia, patientHistoryList)
          &&
          isDiagnosedConcurrentWith(visit,m,IRIS24Elements.Myopia__Eye,IRIS24Elements.Myopia)
        )
      &&
        wasProcedureEyeEqualsWithInXDaysBefore(visit,m,IRIS24Elements.Refractive_Surgery_1,"",30,patient_history_list,IRIS24Elements.Refractive_Surgery__Eye)
      &&
          wasProcedureEyeEqualsWithInXDaysAfter(visit,m,IRIS24Elements.Refractive_Surgery_1,30,patient_history_list,IRIS24Elements.Actual_Refraction__Eye,
            IRIS24Elements.Actual_Refraction)
    )
  }

  //Patients receiving refractive surgery with a postoperative spherical equivalent (SE) within +/- 0.5 Diopter (D) of the intended correction or SE within 30 days
  def getMet(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    rdd.filter(visit=>
      isPhysicalExamPerformedValueBetween(visit,IRIS24Elements.Difference_In_Refraction,m,-0.5,0.5,patientHistoryList,IRIS24Elements.Actual_Refraction)
    )
  }
}
