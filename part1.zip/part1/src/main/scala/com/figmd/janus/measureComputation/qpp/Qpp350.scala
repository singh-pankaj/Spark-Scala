package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP350Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 350
* Measure Title              :- Total Knee Replacement: Shared Decision-Making: Trial of Conservative (Nonsurgical) Therapy
* Measure Description        :- Percentage of patients regardless of age undergoing a total knee replacement with documented shared decisionmaking with discussion of conservative (non-surgical) therapy (e.g., non-steroidal anti-inflammatory drug (NSAIDs), analgesics, weight loss, exercise, injections) prior to the procedure
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp350 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp350"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP350Elements.Shared_Decision_Making_Approach,
      QPP350Elements.Shared_Decision_Making,
      QPP350Elements.Total_Knee_Replacement
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)


    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
          metRDD.cache()

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()
      //
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>

      isProcedurePerformedDuringEncounter(visit, m, QPP350Elements.Total_Knee_Replacement)
    )

  }


  // Numerator criteria
  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    ipp.filter(visit =>
      (
        isInterventionPerformedOnEncounter(visit, m, QPP350Elements.Shared_Decision_Making)
          ||
          wasInterventionPerformedBeforeProcedure(visit, m, QPP350Elements.Total_Knee_Replacement, patientHistoryBroadcastList, QPP350Elements.Shared_Decision_Making_Approach)
        )
        && !isInterventionPerformedDuringProcedure(visit, m, QPP350Elements.Total_Knee_Replacement, QPP350Elements.Total_Knee_Replacement_Date, QPP350Elements.Shared_Decision_Reason_Not_Specified, QPP350Elements.Shared_Decision_Reason_Not_Specified_Date)
    )
  }


}
