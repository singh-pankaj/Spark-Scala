package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, ECQM124V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 124
* Measure Title              :- Cervical Cancer Screening
* Measure Description        :- Percentage of women 21-64 years of age who were screened for cervical cancer using
                                either of the following criteria:
                                Women age 21-64 who had cervical cytology performed every 3 years
                                Women age 30-64 who had cervical cytology/human papillomavirus (HPV) co-testing performed every 5 years"
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score equals better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm124V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm124V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession,initialRDD
      ,ECQM124V7Elements.Encounter_Inpatient
      ,ECQM124V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care
      ,ECQM124V7Elements.Discharged_To_Home_For_Hospice_Care
      ,ECQM124V7Elements.Hospice_Care_Ambulatory
      ,ECQM124V7Elements.Hysterectomy_With_No_Residual_Cervix
      ,ECQM124V7Elements.Congenital_Abscence_Of_Cervix
      ,ECQM124V7Elements.Pap_Test
      ,ECQM124V7Elements.Hpv_Test
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryRDD,patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession,initialRDD ,ippRDD, MEASURE_NAME)) {


      //Filter Eligable IPP

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

     // val EligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      /*exclusion RDD*/
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*------------------------------------------------------------------------------
    Women 23-64 years of age with a visit during the measurement period
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryRDD:RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)


    initialRDD.filter(visit =>
         isAgeBetween(visit,m,23,CompareOperator.GREATER_EQUAL,64,CompareOperator.LESS)
        && isFemale(visit,m)
        && isVisitTypeIn(visit,m
        ,ECQM124V7Elements.Office_Visit
        ,ECQM124V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
        ,ECQM124V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
        ,ECQM124V7Elements.Home_Healthcare_Services)
    )
  }

  /*------------------------------------------------------------------------------
    Women who had a hysterectomy with no residual cervix or a congenital absence of  cervix.
    Exclude patients whose hospice care overlaps the measurement period.
   ------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>

           isEncounterPerformedWithDischargeStatus(visit,m,ECQM124V7Elements.Encounter_Inpatient,ECQM124V7Elements.Discharged_To_Home_For_Hospice_Care,patientHistoryList)
        || isEncounterPerformedWithDischargeStatus(visit,m,ECQM124V7Elements.Encounter_Inpatient,ECQM124V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,patientHistoryList)
        || isInterventionOrder(visit,m,ECQM124V7Elements.Hospice_Care_Ambulatory,patientHistoryList)
        || wasInterventionPerformedInHistory(visit,m,ECQM124V7Elements.Hospice_Care_Ambulatory,patientHistoryList)
        || wasProcedurePerformedInHistory(visit,m,ECQM124V7Elements.Hysterectomy_With_No_Residual_Cervix,patientHistoryList)
        || wasDiagnosedInHistory(visit,m,ECQM124V7Elements.Congenital_Abscence_Of_Cervix,patientHistoryList)

    )
  }

  /*------------------------------------------------------------------------------
    Women with one or more screenings for cervical cancer. Appropriate screenings are defined by any one of the following criteria:
    - Cervical cytology performed during the measurement period or the two years prior to the measurement period for
      women who are at least 21 years old at the time of the test
    - Cervical cytology/human papillomavirus (HPV) co-testing performed during the measurement period or the four years
      prior to the measurement period for women who are at least 30 years old at the time of the test
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      wasLaboratoryTestPerformedBeforeEndInXYears(visit,m,ECQM124V7Elements.Pap_Test,3,patientHistoryList)
        ||
        (
                wasAgeBeforeXPeriod(visit,m,ECQM124V7Elements.Pap_Test,CalenderUnit.YEAR,5,CompareOperator.GREATER_EQUAL,30,patientHistoryList)
            &&  wasLaboratoryTestPerformedBeforeEndInXYears(visit,m,ECQM124V7Elements.Pap_Test,5,patientHistoryList)
            &&  (
            wasResultPresentAfterLaboratoryTest(visit,m,ECQM124V7Elements.Pap_Test,ECQM124V7Elements.Hpv_Test,1,patientHistoryList)
              || wasResultPresentBeforeLaboratoryTest(visit,m,ECQM124V7Elements.Pap_Test,ECQM124V7Elements.Hpv_Test,1,patientHistoryList)
            )
          )
    )
  }
}