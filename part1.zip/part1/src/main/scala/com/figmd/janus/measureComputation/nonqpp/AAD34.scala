package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AAD34Elements, AdminElements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD 33
* Measure Title              :- Basal Cell Carcinoma/Squamous Cell Carcinoma: Surgical Safety Post-Operative Bleeding
* Measure Description        :- Percentage of patients seen for bleeding or hematoma within 15 days of a surgical encounter for BCC/SCC and intervention required.
* Calculation Implementation :- Procedure Specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object AAD34 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAD34"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession,initialRDD,
     AAD34Elements.Postoperative_Infection,
      AAD34Elements.Superficial_Incision,
      AAD34Elements.Removal_Of_Foreign_Body,
      AAD34Elements.Incision_And_Or_With_Drainage,
      AAD34Elements.Signs_Of_Infection,
      AAD34Elements.Superficial_Incision
    ).collect.toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Filter denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
  /*    val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      notEligibleRDD.cache()
*/
      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMetRdd(intermediateA, patientHistoryList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()
    }

  }

  // IPP criteria
  def getIpp(initialRDD:RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
    isDiagnosisOnEncounter(visit, m, AAD34Elements.Bcc_Or_Scc_Grp)
      && isProcedurePerformedDuringEncounter(visit, m, AAD34Elements.Scalpel_Based_Surgery_Grp)
    )
  }

  // Met criteria
  def getMetRdd(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      wasDiagnosisDaysAfterProcedure(visit, m, AAD34Elements.Scalpel_Based_Surgery_Grp, AAD34Elements.Postoperative_Infection, 15, patientHistoryList)
      || wasProcedurePerformedXDaysAfterProcedure(visit, m, AAD34Elements.Scalpel_Based_Surgery_Grp, AAD34Elements.Superficial_Incision, 15, patientHistoryList)
      || wasProcedurePerformedXDaysAfterProcedure(visit, m, AAD34Elements.Scalpel_Based_Surgery_Grp, AAD34Elements.Removal_Of_Foreign_Body, 15, patientHistoryList)
      || wasProcedurePerformedXDaysAfterProcedure(visit, m, AAD34Elements.Scalpel_Based_Surgery_Grp, AAD34Elements.Incision_And_Or_With_Drainage, 15, patientHistoryList)
      || ( wasSymptomDaysAfterProcedure(visit, m, AAD34Elements.Scalpel_Based_Surgery_Grp, AAD34Elements.Signs_Of_Infection, 15, patientHistoryList)
          && wasIntervaentionPerformedDaysAfterProcedure(visit, m, AAD34Elements.Scalpel_Based_Surgery_Grp, AAD34Elements.Superficial_Incision, 15, patientHistoryList)
      )
    )
  }
}
