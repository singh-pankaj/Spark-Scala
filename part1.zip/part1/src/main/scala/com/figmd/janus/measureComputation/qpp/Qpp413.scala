package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP413Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp 413
* Measure Title              :- Door to Puncture Time for Endovascular Stroke Treatment
* Measure Description        :- Percentage of patients undergoing endovascular stroke treatment who have a door to puncture time of less than two hours
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp413 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp413"



  //Patient History List
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP413Elements.Endovascular_Stroke_Treatment,
      QPP413Elements.Ischemic_Stroke_Gr,
      QPP413Elements.Institution_Transfer,
      QPP413Elements.Hospitalized_Patient_New_Cva,
      QPP413Elements.Door_To_Puncture_Time,
      QPP413Elements.Dtp_Time_Start,
      QPP413Elements.Dtp_Time_End
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      //Filter Denominator Exclusion
      val exclusionRDD = getExclusion(denominatorRDD,patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateRdd = getSubtractRDD(denominatorRDD,exclusionRDD)
      intermediateRdd.cache()
      // Filter Met
      val metRDD = getMet(intermediateRdd, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Denominator Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateRdd, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
All patients with CVA undergoing endovascular stroke treatment during measurement period.
----------------------------------------------------------------------------------------------------------------------------*/

  // IPP-Denominator criteria
  def getIpp(rdd: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)
    rdd.filter(visit =>
      wasProcedureAfterDiagnosis(visit, m, QPP413Elements.Endovascular_Stroke_Treatment, patientHistoryList, QPP413Elements.Ischemic_Stroke_Gr)
      && isProcedurePerformed(visit, m, QPP413Elements.Endovascular_Stroke_Treatment, patientHistoryList)
      )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Patients who are transferred from one institution to another with a known diagnosis of CVA for endovascular stroke treatment
OR
Hospitalized patients with newly diagnosed CVA considered for endovascular stroke treatment
----------------------------------------------------------------------------------------------------------------------------*/

  // Denominator Exclusion criteria
  def getExclusion(ippRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      isTransfered(visit, m, QPP413Elements.Institution_Transfer, patientHistoryList)
      || isDiagnosis(visit, m, QPP413Elements.Hospitalized_Patient_New_Cva, patientHistoryList)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Patients with CVA undergoing endovascular stroke treatment who have a door to puncture time of less than 2 hours
----------------------------------------------------------------------------------------------------------------------------*/

  // Numerator criteria
  def getMet(ippRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      isProcedurePerformed(visit, m, QPP413Elements.Door_To_Puncture_Time, patientHistoryList)
      && (
        wasProcedurePerformedAfterProcedureInXHours(visit, m, QPP413Elements.Dtp_Time_Start, QPP413Elements.Dtp_Time_End, 2, patientHistoryList)
        && isProcedurePerformedDuringProcedure(visit, m, QPP413Elements.Endovascular_Stroke_Treatment, QPP413Elements.Endovascular_Stroke_Treatment_Date, QPP413Elements.Dtp_Time_End, QPP413Elements.Dtp_Time_End_Date)
      )
      && !isInterventionPerformedDuringProcedurePerformed(visit, m, QPP413Elements.Dtp_Time_Reason_Not_Specified, QPP413Elements.Dtp_Time_Reason_Not_Specified_Date, QPP413Elements.Endovascular_Stroke_Treatment, QPP413Elements.Endovascular_Stroke_Treatment_Date)
    )
  }
}