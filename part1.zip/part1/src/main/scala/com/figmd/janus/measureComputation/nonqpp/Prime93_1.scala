package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CompareOperator, MeasureProperty, PRIME93Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- PRIME 93_1
* Measure Title              :- Preventive Care and Screening: Risk-Stratified Cholesterol -Fasting Low Density Lipoprotein (LDL-C)
* Measure Description        :- Percentage of patients aged 20 through 79 years who had a fasting LDL-C test performed and whose
                                risk-stratified fasting LDL-C is at or below the recommended LDL-C goal.
* Calculation Implementation :- Patient Specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 3
* Measure Stratum No.        :- 1
* Measure Stratification     :- 3
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/


object Prime93_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Prime93_1"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val getPatientHistoryList: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD,
      PRIME93Elements.Ldl_Code,
      PRIME93Elements.Total_Cholesterol,
      PRIME93Elements.High_Density_Lipoprotein__Hdl_,
      PRIME93Elements.Triglycerides,
      PRIME93Elements.Acute_Myocardial_Infarction,
      PRIME93Elements.Hemorrhagic_Stroke,
      PRIME93Elements.Ischemic_Stroke,
      PRIME93Elements.Ischemic_Vascular_Disease,
      PRIME93Elements.Coronary_Artery_Disease_No_Mi,
      PRIME93Elements.Diabetes,
      PRIME93Elements.Abdominal_Aortic_Aneurysm,
      PRIME93Elements.Atherosclerosis_And_Peripheral_Arterial_Disease,
      PRIME93Elements.Pci,
      PRIME93Elements.Carotid_Intervention,
      PRIME93Elements.Cabg_Surgeries,
      PRIME93Elements.Framingham_Coronary_Heart_Disease_10_Year_Risk,
      PRIME93Elements.Palliative_Care)

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val mostRecentRDD = mostRecentPatientList(getPatientHistoryList: RDD[CassandraRow], PRIME93Elements.Ldl_Code)
      val mostRecentpatientList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostRecentRDD)


      // Eligible IPP
      val denominatorRDD = getEligibleIpp(ippRDD, patientHistoryList)
      denominatorRDD.cache()

      /*val notEligibleRDD = ippRDD.subtract(eligibleRdd)
    eligibleRdd.cache()*/

      // Filter Exclusions
      val exclusionRDD = getExclusionRDD(denominatorRDD, patientHistoryList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()
      // Filter Met
      val metRDD = getMetRDD(intermediateForMet, patientHistoryList, mostRecentpatientList)
      metRDD.cache()
      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
      mostRecentpatientList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : All patients 20 through 79 years of age before the beginning of the measurement period
----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeBetween(visit, m, 20, 80)
        && isVisitTypeIn(visit, m, PRIME93Elements.Cholesterol_Measure_Encounter_Codes)
    )
  }

  /*----------------------------------------------------------------------------------------------------------------------------
Denominator 1: (High Risk)
All patients aged 20 through 79 years who had a fasting LDL-C or a calculated LDL-C test performed during the measurement period and have CHD or CHD Risk Equivalent OR 10 year Framingham risk > 20%.
----------------------------------------------------------------------------------------------------------------------------*/

  def getEligibleIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      (isLaboratoryTestPerformed(visit, m, PRIME93Elements.Ldl_Code, patientHistoryList)
        || (isLaboratoryTestPerformed(visit, m, PRIME93Elements.Total_Cholesterol, patientHistoryList)
        && isLaboratoryTestPerformed(visit, m, PRIME93Elements.High_Density_Lipoprotein__Hdl_, patientHistoryList)
        && isLaboratoryTestPerformed(visit, m, PRIME93Elements.Triglycerides, patientHistoryList)
        )
        )
        &&
        (
          (wasDiagnosedInHistory(visit, m, PRIME93Elements.Acute_Myocardial_Infarction, patientHistoryList)
            || wasDiagnosedInHistory(visit, m, PRIME93Elements.Hemorrhagic_Stroke, patientHistoryList)
            || wasDiagnosedInHistory(visit, m, PRIME93Elements.Ischemic_Stroke, patientHistoryList)
            || wasDiagnosedInHistory(visit, m, PRIME93Elements.Ischemic_Vascular_Disease, patientHistoryList)
            || wasDiagnosedInHistory(visit, m, PRIME93Elements.Coronary_Artery_Disease_No_Mi, patientHistoryList)
            || wasDiagnosedInHistory(visit, m, PRIME93Elements.Diabetes, patientHistoryList)
            || wasDiagnosedInHistory(visit, m, PRIME93Elements.Abdominal_Aortic_Aneurysm, patientHistoryList)
            || wasDiagnosedInHistory(visit, m, PRIME93Elements.Atherosclerosis_And_Peripheral_Arterial_Disease, patientHistoryList)
            || wasProcedurePerformedInHistory(visit, m, PRIME93Elements.Pci, patientHistoryList)
            || wasProcedurePerformedInHistory(visit, m, PRIME93Elements.Carotid_Intervention, patientHistoryList)
            || wasProcedurePerformedInHistory(visit, m, PRIME93Elements.Cabg_Surgeries, patientHistoryList)
            )
            || isAssessmentPerformedValue(visit, m, PRIME93Elements.Framingham_Coronary_Heart_Disease_10_Year_Risk, 20, CompareOperator.GREATER, patientHistoryList)
          )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Denominator Exclusions :
Patients who have an active diagnosis of pregnancy
OR
Patients who are receiving palliative care
 ----------------------------------------------------------------------------------------------------------------------------*/

  def getExclusionRDD(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      (isInterventionOrdered(visit, m, PRIME93Elements.Palliative_Care, patientHistoryList)
        || isDiagnosedOnEncounter(visit, m, PRIME93Elements.Pregnancy_Dx)
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Numerator 1:
Patients whose most recent fasting LDL-C test result is in good control, defined as <100 mg/dL
----------------------------------------------------------------------------------------------------------------------------*/

  def getMetRDD(rdd: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]], mostRecentpatientList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isMostRecentLaboratoryTestPerformedValue(visit, m, PRIME93Elements.Ldl_Code, 100, CompareOperator.LESS, mostRecentpatientList)
    )
  }


}
