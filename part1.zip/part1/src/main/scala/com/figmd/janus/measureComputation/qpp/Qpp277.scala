package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP277Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 277
* Measure Title              :- Sleep Apnea: Severity Assessment at Initial Diagnosis
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of obstructive sleep apnea who had an apnea hypopnea index (AHI) or a respiratory disturbance index (RDI) measured at the time of initial diagnosis
* Calculation Implementation :- Patient specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp277 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp277"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP


    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP277Elements.Obstructive_Sleep_Apnea,
      QPP277Elements.Ahi_Or_Rdi,
      QPP277Elements.Apnea_Hypopnea_Index__Ahi_,
      QPP277Elements.Respiratory_Disturbance_Index,
      QPP277Elements.Apnea_Hypopnea_Index,
      QPP277Elements.Respiratory_Disturbance_Index_Rdi,
      QPP277Elements.Ahi_Or_Rdi_Reason_Not_Specified,
      QPP277Elements.Psychiatric_Disease,
      QPP277Elements.Dementia,
      QPP277Elements.Test_Ordered_Not_Completed,
      QPP277Elements.Insurance_Coverage,
      QPP277Elements.Patient_Declined,
      QPP277Elements.Financial
    )

    val leastRecentElementBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastRecentPatientList(patientHistoryRDD, QPP277Elements.Obstructive_Sleep_Apnea))


    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val ippRDD = getIpp(initialRDD, leastRecentElementBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList, leastRecentElementBroadcastList)
      metRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, metRDD)
      intermediateA.cache()


      // Filter Exceptions
      val exceptionRDD = getException(intermediateA, patientHistoryBroadcastList, leastRecentElementBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()
      //
      // Filter Exceptions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      leastRecentElementBroadcastList.destroy()
    }

  }


  // IPP-Denominator criteria
  /* All patients aged 18 years and older with an initial diagnosis of sleep apnea */

  def getIpp(initialRDD: RDD[CassandraRow], leastRecentElementBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        isDiagnosisOverlapsEncounterFirst(visit, m, leastRecentElementBroadcastList, QPP277Elements.Obstructive_Sleep_Apnea)
        &&
        isVisitTypeIn(visit, m, QPP277Elements.Office_Visit,
          QPP277Elements.Nursing_Facility_Visit,
          QPP277Elements.Home_Healthcare_Services,
          QPP277Elements.Care_Services_In_Long_Term_Residential_Facility
        )
        &&
        !isVisitTypeIn(visit, m, QPP277Elements.Office_Visit_Telehealth_Modifier,
          QPP277Elements.Nursing_Facility_Visit_Telehealth_Modifier,
          QPP277Elements.Home_Healthcare_Services_Telehealth_Modifier,
          QPP277Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
        )
        && !isVisitTypeIn(visit, m, QPP277Elements.Pos_02)
    )
  }


  // Numerator criteria
  /*Patients who had an apnea hypopnea index (AHI) or a respiratory disturbance index (RDI) measured at the time of initial diagnosis */

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], leastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isAssessmentPerformed(visit, m, QPP277Elements.Ahi_Or_Rdi, patientHistoryBroadcastList)
        ||
        isAssesmentPerformedDuringFirstDiagnosis(visit, m, QPP277Elements.Obstructive_Sleep_Apnea, patientHistoryBroadcastList, leastList, QPP277Elements.Apnea_Hypopnea_Index,
          QPP277Elements.Respiratory_Disturbance_Index)
        ||
        isAssesmentPerformedDuringFirstDiagnosis(visit, m, QPP277Elements.Obstructive_Sleep_Apnea, patientHistoryBroadcastList, leastList, QPP277Elements.Apnea_Hypopnea_Index__Ahi_,
          QPP277Elements.Respiratory_Disturbance_Index_Rdi)
        || !isAssessmentPerformed(visit, m, QPP277Elements.Ahi_Or_Rdi_Reason_Not_Specified, patientHistoryBroadcastList)
    )


  }

  /*Documentation of reason(s) for not measuring an apnea hypopnea index (AHI) or a respiratory disturbance index (RDI) at the time of initial diagnosis (e.g., psychiatric
disease, dementia, patient declined, financial, insurance coverage, test ordered but not yet completed)  */

  def getException(intermediateRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], leastRecentElementBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateRDD.filter(visit =>

      isDiagnosisOverlapsFirstDiagnosis(visit, m, QPP277Elements.Obstructive_Sleep_Apnea, patientHistoryBroadcastList, leastRecentElementBroadcastList, QPP277Elements.Psychiatric_Disease, QPP277Elements.Dementia)
        ||
        (isLaboratoryTestOrderDuringFirstDiagnosis(visit, m, QPP277Elements.Obstructive_Sleep_Apnea, patientHistoryBroadcastList, leastRecentElementBroadcastList, QPP277Elements.Test_Ordered_Not_Completed)
          || isPatientCharacteristicDuringFirstDiagnosis(visit, m, QPP277Elements.Obstructive_Sleep_Apnea, patientHistoryBroadcastList, leastRecentElementBroadcastList, QPP277Elements.Insurance_Coverage, QPP277Elements.Financial)
          || !isCommunicationFromPatientToProviderDoneDuringFirstDiagnosis(visit, m, QPP277Elements.Obstructive_Sleep_Apnea, patientHistoryBroadcastList, leastRecentElementBroadcastList, QPP277Elements.Patient_Declined)
          )
        || isAssessmentPerformed(visit, m, QPP277Elements.Ahi_Or_Rdi_Reason_Not_Specified, patientHistoryBroadcastList)
    )
  }


}
