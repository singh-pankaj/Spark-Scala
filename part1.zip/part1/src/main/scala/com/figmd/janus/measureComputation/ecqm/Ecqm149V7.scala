package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ECQM149V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.ecqm.Ecqm144V7_2.{MEASURE_NAME, checkEmptyIPPRDD}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 149v7
* Measure Title              :- Dementia: Cognitive Assessment
* Measure Description        :- Percentage of patients, regardless of age, with a diagnosis of dementia for whom an
*                               assessment of cognition is performed and the results reviewed at least once within
*                               a 12-month period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Rishikesh patil
----------------------------------------------------------------------------------------------------------------------------*/
object Ecqm149V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm149V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      ECQM149V7Elements.Standardized_Tools_For_Assessment_Of_Cognition,
      ECQM149V7Elements.Cognitive_Assessment,
      ECQM149V7Elements.Patient_Reason,
      ECQM149V7Elements.Dementia___Mental_Degenerations,
      ECQM149V7Elements.Psych_Visit___Diagnostic_Evaluation,
      ECQM149V7Elements.Nursing_Facility_Visit,
      ECQM149V7Elements.Care_Services_In_Long_Term_Residential_Facility,
      ECQM149V7Elements.Home_Healthcare_Services,
      ECQM149V7Elements.Psych_Visit___Psychotherapy,
      ECQM149V7Elements.Behavioral_Neuropsych_Assessment,
      ECQM149V7Elements.Occupational_Therapy_Evaluation,
      ECQM149V7Elements.Office_Visit,
      ECQM149V7Elements.Outpatient_Consultation
    )

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //Denominator
      val denominatorRDD=ippRDD
      denominatorRDD.cache()

      //Filter notEligibleRDD
      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Intermediate A
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Intermediate B
      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      // Filter Denominator Exception
      val exceptionRDD = getException(intermediateB, patientHistoryList)
      exceptionRDD.cache()

      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()


       saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow], patienthistoryRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val encounterCountList: List[(String, Int)] = countElement(patienthistoryRdd, m,
      ECQM149V7Elements.Psych_Visit___Diagnostic_Evaluation,
      ECQM149V7Elements.Nursing_Facility_Visit,
      ECQM149V7Elements.Care_Services_In_Long_Term_Residential_Facility,
      ECQM149V7Elements.Home_Healthcare_Services,
      ECQM149V7Elements.Psych_Visit___Psychotherapy,
      ECQM149V7Elements.Behavioral_Neuropsych_Assessment,
      ECQM149V7Elements.Occupational_Therapy_Evaluation,
      ECQM149V7Elements.Office_Visit,
      ECQM149V7Elements.Outpatient_Consultation)

    initialRDD.filter(visit =>
      getEncounterCountFromHistory(visit, m, 2, true, encounterCountList)
        &&
        wasDiagnosedBeforeEncounter(visit, m, ECQM149V7Elements.Dementia___Mental_Degenerations, patientHistoryList)

    )
  }

  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    var m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      wasAssessmentPerformedInXMonthsBeforeEncounter(visit, m, ECQM149V7Elements.Standardized_Tools_For_Assessment_Of_Cognition, 12, patientHistoryList)
        ||
        wasInterventionPerformedInXMonthsBeforeEncounter(visit, m, ECQM149V7Elements.Cognitive_Assessment, 12, patientHistoryList)
    )
  }


  // Denominator Exception criteria
  def getException(intermediateB: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    var m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateB.filter(visit =>
      isAssessmentPerformedOnEncounter(visit, m, ECQM149V7Elements.Patient_Reason)
        ||
        isInterventionPerformedOnEncounter(visit, m, ECQM149V7Elements.Patient_Reason)
    )


  }


}
