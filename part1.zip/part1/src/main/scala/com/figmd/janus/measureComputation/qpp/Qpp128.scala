package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP128Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 128
* Measure Title              :- Preventive Care and Screening: Body Mass Index (BMI) Screening and Follow-Up Plan
* Measure Description        :- Percentage of patients aged 18 years and older with a BMI documented during the current encounter or during the previous twelve months
*                               AND with a BMI outside of normal parameters, a follow-up plan is documented during the encounter or during the previous twelve months of the current encounter
                                Normal Parameters:       Age 18 years and older BMI => 18.5 and < 25 kg/m2
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp128 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp128"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD,
      QPP128Elements.Palliative_Care,
      QPP128Elements.Palliative_Care_Encounter,
      QPP128Elements.Patient_Reason_Refused,
      QPP128Elements.Bmi_Loinc_Value,
      QPP128Elements.Bmi_Normal,
      QPP128Elements.Above_Normal_Follow_Up,
      QPP128Elements.Referrals_Where_Weight_Assessment_May_Occur,
      QPP128Elements.Above_Normal_Medications,
      QPP128Elements.Medical_Or_Other_Reason_Not_Done,
      QPP128Elements.Bmi_Follow_Up_Patient_Not_Eligible,
      QPP128Elements.Bmi_Follow_Up_Medical_Reason,
      QPP128Elements.Nutritional_Deficiency,
      QPP128Elements.Urgent_Or_Emergent_Medical_Situation,
      QPP128Elements.Dementia,
      QPP128Elements.Confusion,
      QPP128Elements.Mental_Illness,
      QPP128Elements.Physical_Disability,
      QPP128Elements.Medical_Conditions
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()


      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateRDD = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateRDD.cache()

      val metRDD = getMet(sparkSession: SparkSession, intermediateRDD, patientHistoryRDD, patientHistoryBroadcastList)
      metRDD.cache()


      val intermediateA = getSubtractRDD(intermediateRDD, metRDD)
      intermediateA.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateA, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not mate
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryBroadcastList.destroy()
    }

  }

  //All patients 18 and older on the date of the encounter with at least one eligible encounter during the measurement period

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m, QPP128Elements.Bmi_Encounter_Code_Set)
        && !isVisitTypeIn(visit, m, QPP128Elements.Bmi_Encounter__Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP128Elements.Pos_02)
    )
  }

  /*
  A patient is not eligible if one or more of the following reasons are documented:
  1. Patients receiving palliative care on the date of the current encounter or any time prior to the current
  encounter
  2. Patients who are pregnant on the date of the current encounter or any time during the measurement period prior to the current encounter
  3. BMI not documented, documentation the patient is not eligible for BMI calculation.
  4. BMI is documented as being outside of normal limits, follow-up plan is not documented, documentation the patient is not eligible
  5.Patients who refuse measurement of height and/or weight or refuse follow-up on the date of the current encounter or any time during the measurement period prior to the current encounter
   */

  def getExclusionRdd(eligibleRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    eligibleRdd.filter(visit =>
      (
        wasEncounterPerformedInHistory(visit, m, QPP128Elements.Palliative_Care_Encounter, patientHistoryBroadcastList)
          || wasInterventionPerformedOrOrderedInHistory(visit, m, QPP128Elements.Palliative_Care, patientHistoryBroadcastList)
          || wasPhysicalExamNotPerformedDuringEncounter(visit, m, AdminElements.Encounter_Date, QPP128Elements.Patient_Reason_Refused_Date)
          || isDiagnosedOnEncounter(visit, m, QPP128Elements.Pregnancy_Dx)
          || wasInterventionPerformedBeforeEncounter(visit, m, QPP128Elements.Bmi_Follow_Up_Patient_Not_Eligible, patientHistoryBroadcastList)
          || isPhysicalExamPerformedDuringEncounter(visit, m, QPP128Elements.Bmi_Documentation_Patient_Not_Eligible)
          || wasPhysicalExamPerformedBeforeEncounter(visit, m, QPP128Elements.Bmi_Documentation_Patient_Not_Eligible, patientHistoryBroadcastList)
        )
    )
  }

  /*
  Patients with a documented BMI during the encounter or during the previous twelve months,
  AND when the BMI is outside of normal parameters, a follow-up plan is documented during
  the encounter or during the previous twelve months of the current encounter.
   */

  def getMet(sparkSession: SparkSession, intermidiateRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)


    intermidiateRDD.filter(visit =>
      (
        isPatientBMINormal(visit, m, QPP128Elements.Bmi_Loinc_Value, "ge", 18.5)
          &&
          isPatientBMINormal(visit, m, QPP128Elements.Bmi_Loinc_Value, "lt", 25)

          || isPhysicalExamPerformedDuringEncounter(visit, m, QPP128Elements.Bmi_Normal)
          ||
          (

            isPatientBMIOverweight(visit, m, QPP128Elements.Bmi_Loinc_Value, "ge", 25)
              &&
              (
                isInterventionOrderOnEncounter(visit, m, QPP128Elements.Above_Normal_Follow_Up)
                  || isInterventionOrderOnEncounter(visit, m, QPP128Elements.Referrals_Where_Weight_Assessment_May_Occur)
                  || isMedicationOrderedOnEncounter(visit, m, QPP128Elements.Above_Normal_Medications)
                )
              || isInterventionOrderOnEncounter(visit, m, QPP128Elements.Above_Normal_Follow_Up_G)
            )
          ||
          (
            isPatientBMIOverweight(visit, m, QPP128Elements.Bmi_Loinc_Value, "lt", 18.5)

              &&
              (
                isInterventionOrderOnEncounter(visit, m, QPP128Elements.Below_Normal_Follow_Up)
                  || isInterventionOrderOnEncounter(visit, m, QPP128Elements.Referrals_Where_Weight_Assessment_May_Occur)
                  || isMedicationOrderedOnEncounter(visit, m, QPP128Elements.Below_Normal_Medications)
                )
              || isInterventionOrderOnEncounter(visit, m, QPP128Elements.Below_Normal_Follow_Up_G)
            )
        )
        && !(
        isInterventionOrderOnEncounter(visit, m, QPP128Elements.Bmi_Follow_Up_Reason_Not_Specified)
          || isPhysicalExamPerformedDuringEncounter(visit, m, QPP128Elements.Bmi_Documentation_Reason_Not_Specified)
        )
    )


  }

  /*
  BMI is documented as being outside of normal limits, follow-up plan is not completed for documented reason

  Patients with a documented Medical Reason:
  * Elderly Patients (65 or older) for whom weight reduction/weight gain would complicate other underlying health conditions such as the following examples:
       *Illness or physical disability
       *Mental illness, dementia, confusion
       *Nutritional deficiency, such as Vitamin/mineral deficiency

  * Patients in an urgent or emergent medical situation where time is of the essence and to delay treatment would jeopardize the patient's health status
   */

  def getException(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP128Elements.Medical_Or_Other_Reason_Not_Done, 12, patientHistoryBroadcastList)
          ||
          wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP128Elements.Bmi_Follow_Up_Medical_Reason, 12, patientHistoryBroadcastList)
          ||
          (
            isPatientElderly(visit, m)
              &&

              (
                wasDiagnosedInXMonths(visit, m, AdminElements.Encounter_Date, QPP128Elements.Nutritional_Deficiency, 12, patientHistoryBroadcastList)
                  || wasDiagnosedInXMonths(visit, m, AdminElements.Encounter_Date, QPP128Elements.Dementia, 12, patientHistoryBroadcastList)
                  || wasDiagnosedInXMonths(visit, m, AdminElements.Encounter_Date, QPP128Elements.Confusion, 12, patientHistoryBroadcastList)
                  || wasDiagnosedInXMonths(visit, m, AdminElements.Encounter_Date, QPP128Elements.Mental_Illness, 12, patientHistoryBroadcastList)
                  || wasDiagnosedInXMonths(visit, m, AdminElements.Encounter_Date, QPP128Elements.Physical_Disability, 12, patientHistoryBroadcastList)
                  || wasDiagnosedInXMonths(visit, m, AdminElements.Encounter_Date, QPP128Elements.Medical_Conditions, 12, patientHistoryBroadcastList))

            )
          || wasDiagnosedInXMonths(visit, m, AdminElements.Encounter_Date, QPP128Elements.Urgent_Or_Emergent_Medical_Situation, 12, patientHistoryBroadcastList)

        )
    )
  }
}



