package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.ecqm.Ecqm144V7_2.{MEASURE_NAME, checkEmptyIPPRDD}
import com.figmd.janus.measureComputation.master.{ECQM127V7Elements,  MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ECQM 127
* Measure Title              :- Pneumococcal Vaccination Status for Older Adults
* Measure Description        :- Percentage of patients 65 years of age and older who have ever received a pneumococcal vaccine
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm127V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm127V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      //getPatientHistoryList
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        ECQM127V7Elements.Discharged_To_Home_For_Hospice_Care,
        ECQM127V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
        ECQM127V7Elements.Hospice_Care_Ambulatory,
        ECQM127V7Elements.Pneumococcal_Vaccine,
        ECQM127V7Elements.Pneumococcal_Vaccine_Administered,
        ECQM127V7Elements.History_Of_Pneumococcal_Vaccine).collect().toList

      val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      //metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }


  // IPP-Denominator criteria
  /* Patients 65 years of age and older with a visit during the measurement period  */

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientElderly(visit, m)
        &&
        isVisitTypeIn(visit, m,
          ECQM127V7Elements.Office_Visit,
          //ECQM127V7Elements.Face_To_Face_Interaction,
          ECQM127V7Elements.Annual_Wellness_Visit,
          ECQM127V7Elements.Home_Healthcare_Services
          //ECQM127V7Elements.Preventive_Care_Services_Established_Office_Visit_18_and_Up,
          //ECQM127V7Elements.Preventive_Care_Services_Initial_Office_Visit_18_and_Up
        )
    )
  }


  // Denominator Exclusion criteria
  /* Exclude patients whose hospice care overlaps the measurement period   */

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isEncounterPerformedInHistory(visit, m, ECQM127V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        ||
        isEncounterPerformedInHistory(visit, m, ECQM127V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        ||
        wasInterventionPerformedOrOrderedInHistory(visit, m, ECQM127V7Elements.Hospice_Care_Ambulatory, patientHistoryList)
    )
  }


  // Numerator criteria
  /* Patients who have ever received a pneumococcal vaccination */

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      isImmunizationAdministeredBeforeEndOfMeasurementPeriod(visit, m, ECQM127V7Elements.Pneumococcal_Vaccine, patientHistoryList)
        ||
        isProcedurePerformedBeforeEndOfMeasurementPeriod(visit, m, ECQM127V7Elements.Pneumococcal_Vaccine_Administered, patientHistoryList)
        ||
        isAssessmentPerformedBeforeEndOfMeasurementPeriod(visit, m, ECQM127V7Elements.History_Of_Pneumococcal_Vaccine, patientHistoryList)
    )
  }

}