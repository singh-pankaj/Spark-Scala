package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ECQM 144
* Measure Title              :- Heart Failure (HF): Beta-Blocker Therapy for Left Ventricular Systolic Dysfunction (LVSD)
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of heart failure (HF)
*                               with a current or prior left ventricular ejection fraction (LVEF) < 40% who were prescribed
*                               beta-blocker therapy either within a 12-month period when seen in the outpatient
*                               setting OR at each hospital discharge
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 1
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm144V7_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm144V7_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , ECQM144V7Elements.Care_Services_In_Long_Term_Residential_Facility
      , ECQM144V7Elements.Home_Healthcare_Services
      , ECQM144V7Elements.Nursing_Facility_Visit
      , ECQM144V7Elements.Office_Visit
      , ECQM144V7Elements.Outpatient_Consultation
      , ECQM144V7Elements.Patient_Provider_Interaction
      , ECQM144V7Elements.Ejection_Fraction
      , ECQM144V7Elements.Moderate_Or_Severe_Lvsd
      , ECQM144V7Elements.Left_Ventricular_Systolic_Dysfunction
      , ECQM144V7Elements.Moderate_Or_Severe
      , ECQM144V7Elements.Beta_Blocker_Therapy_For_Lvsd
      , ECQM144V7Elements.Heart_Rate
      , ECQM144V7Elements.Heart_Rate_2
      , ECQM144V7Elements.Medical_Reason
      , ECQM144V7Elements.Patient_Reason
      , ECQM144V7Elements.System_Reason_2018
      , ECQM144V7Elements.Arrhythmia
      , ECQM144V7Elements.Hypotension
      , ECQM144V7Elements.Asthma
      , ECQM144V7Elements.Allergy_To_Beta_Blocker_Therapy
      , ECQM144V7Elements.Intolerance_To_Beta_Blocker_Therapy
      , ECQM144V7Elements.Bradycardia
      , ECQM144V7Elements.Beta_Blocker_Therapy_Ingredient
      , ECQM144V7Elements.Atrioventricular_Block
      , ECQM144V7Elements.Atrioventricular_Block
      , ECQM144V7Elements.Cardiac_Pacer_In_Situ
      , ECQM144V7Elements.Cardiac_Pacer
    )

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {


      // Eligible IPP
      val denominatorRDD = getEligibleIpp(ippRDD, patientHistoryList)

      // Filter Exclusions
      /*val notEligibleRDD = ippRDD.subtract(eligibleRdd)
      eligibleRdd.cache()*/

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val intermediate = getSubtractRDD(denominatorRDD, metRDD)
      intermediate.cache()

      val exceptionRDD = getExceptionRDD(sparkSession, intermediate, patientHistoryRDD, patientHistoryList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediate, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }


  // IPP Criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    var m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val encounterCountList: List[(String, Int)] = countElement(patientHistoryRDD, m
      , ECQM144V7Elements.Care_Services_In_Long_Term_Residential_Facility
      , ECQM144V7Elements.Home_Healthcare_Services
      , ECQM144V7Elements.Nursing_Facility_Visit
      , ECQM144V7Elements.Office_Visit
      , ECQM144V7Elements.Outpatient_Consultation
      , ECQM144V7Elements.Patient_Provider_Interaction

    )

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        getEncounterCountFromHistory(visit, m, 2, true, encounterCountList)
        &&
        wasDiagnosedBeforeEncounter(visit, m, ECQM144V7Elements.Heart_Failure, patientHistoryList)
    )
  }

  // Denominator Criteria
  def getEligibleIpp(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      wasDiagnosticStudyPerformedBeforeOrEqualEncounterWithResult(visit, m, ECQM144V7Elements.Ejection_Fraction, 40, "le", patientHistoryList)
        ||
        wasDiagnosisBeforeOrEqualEncounter(visit, m, patientHistoryList, ECQM144V7Elements.Moderate_Or_Severe_Lvsd)
        ||
        wasDiagnosisBeforeOrEqualEncounterWithResult(visit, m, ECQM144V7Elements.Left_Ventricular_Systolic_Dysfunction, ECQM144V7Elements.Moderate_Or_Severe, patientHistoryList)
    )
  }


  // Numerator Criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      wasMedicationActiveBeforeOrEqualEncounter(visit, m, ECQM144V7Elements.Beta_Blocker_Therapy_For_Lvsd, patientHistoryList)
    )
  }


  //Denominator Exception Criteria
  def getExceptionRDD(spark: SparkSession, intermediate: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    val mostRecentHF = spark.sparkContext.broadcast(getHistoryMostRecentDateOfElement(patientHistoryRDD, m, ECQM144V7Elements.Heart_Rate_2))

    intermediate.filter(visit =>
      (
        wasMostRecentPhysicalExamBeforePhysicalExamPerformed(visit, m, ECQM144V7Elements.Heart_Rate, ECQM144V7Elements.Heart_Rate_2, patientHistoryList, mostRecentHF)
          &&
          isPhysicalExamPerformedWithResultDuringEncounter(visit, m, ECQM144V7Elements.Heart_Rate, 50, "lt")
          &&
          isPhysicalExamPerformedWithResultDuringEncounter(visit, m, ECQM144V7Elements.Heart_Rate_2, 50, "lt")
        )
        ||
        (
          isMedicationOrderNotDone(visit, m, ECQM144V7Elements.Medical_Reason, patientHistoryList)
            ||
            isMedicationOrderNotDone(visit, m, ECQM144V7Elements.Patient_Reason, patientHistoryList)
            ||
            isMedicationOrderNotDone(visit, m, ECQM144V7Elements.System_Reason_2018, patientHistoryList)
          )
        ||
        (
          wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Arrhythmia, patientHistoryList)
            ||
            wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Hypotension, patientHistoryList)
            ||
            wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Asthma, patientHistoryList)
            ||
            wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Allergy_To_Beta_Blocker_Therapy, patientHistoryList)
            ||
            wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Intolerance_To_Beta_Blocker_Therapy, patientHistoryList)
            ||
            wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Bradycardia, patientHistoryList)
            ||
            wasMedicationAllergyInHistory(visit, m, ECQM144V7Elements.Beta_Blocker_Therapy_Ingredient, patientHistoryList)
          )
        ||
        (
          wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Atrioventricular_Block, patientHistoryList)
            &&
            !wasDiagnosisBeforeOrEqualEncounter(visit, m, patientHistoryList, ECQM144V7Elements.Cardiac_Pacer_In_Situ)
            &&
            !wasDiagnosisBeforeOrEqualEncounter(visit, m, patientHistoryList, ECQM144V7Elements.Cardiac_Pacer)
          )
    )
  }
}