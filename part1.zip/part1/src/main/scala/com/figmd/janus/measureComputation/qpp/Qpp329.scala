
package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP329Elements, TimeOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 329
* Measure Title              :- Adult Kidney Disease: Catheter Use at Initiation of Hemodialysis
* Measure Description        :- "Percentage of patients aged 18 years and older with a diagnosis of End Stage Renal Disease (ESRD)
                                 who initiate maintenance hemodialysis during the measurement period, whose mode of vascular access is a catheter at the
                                 time maintenance hemodialysis is initiated
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure.
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp329 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp329"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP329Elements.Maintenance_Hemodialysis,
      QPP329Elements.End_Stage_Renal_Disease,
      QPP329Elements.Approved_Qualified_Transplant_Program,
      QPP329Elements.Scheduled_Kidney_Transplant,
      QPP329Elements.Palliative_Dialysis_Catheter,
      QPP329Elements.Living_Donor_Kidney_Transplant,
      QPP329Elements.Palliative_Dialysis,
      QPP329Elements.Catheter,
      QPP329Elements.Catheter_As_Vascular_Access,
      QPP329Elements.Vas_Access_Not_Met,
      QPP329Elements.Follow_Up_Nephrologist,
      QPP329Elements.Vascular_Access_Documentation).collect.toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Filter notEligible
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      // Filter Intermediate for Met
      val intermediateMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateException = getSubtractRDD(intermediateMet, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateException, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
Initial Population : All patients aged 18 years and older with a diagnosis of ESRD who initiate maintenance hemodialysis during the measurement period
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD:RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
       isPatientAdult(visit,m)
    && isVisitTypeIn(visit,m,QPP329Elements.Monthly_Esrd_Services)
    && wasDiagnosedInHistory(visit,m,QPP329Elements.End_Stage_Renal_Disease,patientHistoryBroadcastList)
    && isProcedurePerformed(visit,m,QPP329Elements.Maintenance_Hemodialysis,patientHistoryBroadcastList)

    )
  }

  /*---------------------------------------------------------------------------------------------
Denominator Exclusions : Patient is undergoing palliative dialysis with a catheter
OR
Patient approved by a qualified transplant program and scheduled to receive a living donor kidney transplant
   ----------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
         isProcedurePerformed(visit,m,QPP329Elements.Palliative_Dialysis_Catheter,patientHistoryBroadcastList)
      || wasProcedurePerformedWithMethod(visit,m,QPP329Elements.Palliative_Dialysis,QPP329Elements.Catheter,TimeOperator.EQUAL, patientHistoryBroadcastList)
      || isProcedurePerformed(visit,m,QPP329Elements.Living_Donor_Kidney_Transplant,patientHistoryBroadcastList)
      || (
              isInterventionPerformed(visit,m,QPP329Elements.Approved_Qualified_Transplant_Program,patientHistoryBroadcastList)
           && isInterventionPerformed(visit,m,QPP329Elements.Scheduled_Kidney_Transplant,patientHistoryBroadcastList)
         )

    )
  }

  /*----------------------------------------------------------------------------------------
Numerator : Patients whose mode of vascular access is a catheter at the time maintenance hemodialysis is initiated
   -----------------------------------------------------------------------------------------*/

  def getMet(intermediateMet: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateMet.filter(visit =>
      (   isProcedurePerformed(visit,m,QPP329Elements.Catheter_As_Vascular_Access,patientHistoryBroadcastList)
       || isProcedurePerformedDuringProcedureWithMethod(visit,m,QPP329Elements.Vascular_Access,QPP329Elements.Catheter,QPP329Elements.Maintenance_Hemodialysis)
      )
    && !isProcedurePerformed(visit,m,QPP329Elements.Vas_Access_Not_Met,patientHistoryBroadcastList)
    && !(    isProcedurePerformedDuringProcedureWithReason(visit,m,QPP329Elements.Vascular_Access,QPP329Elements.Vas_Access_Medical_Reason,QPP329Elements.Maintenance_Hemodialysis)
          || isProcedurePerformedDuringProcedureWithReason(visit,m,QPP329Elements.Vascular_Access,QPP329Elements.Vas_Access_Patient_Reason,QPP329Elements.Maintenance_Hemodialysis)
          || isProcedurePerformedDuringProcedureWithReason(visit,m,QPP329Elements.Vascular_Access,QPP329Elements.System_Reason,QPP329Elements.Maintenance_Hemodialysis)
        )
    && !isInterventionPerformed(visit,m,QPP329Elements.Follow_Up_Nephrologist,patientHistoryBroadcastList)
    )
  }


  /*---------------------------------------------------------------------------------------------------------------------------------------------
Denominator Exceptions : Documentation of reasons for patient initiating maintenance hemodialysis with a catheter as the mode of vascular access
(e.g.,patient has a maturing AVF/AVG, time-limited trial of hemodialysis, other medical reasons, patient declined AVF/AVG, other patient reasons,
patient followed by reporting nephrologist for fewer than 90 days, other system reasons)
   ---------------------------------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateException:RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCEPTION,globalStartDate,globalEndDate)

    intermediateException.filter(visit =>
         isProcedurePerformed(visit,m,QPP329Elements.Vascular_Access_Documentation,patientHistoryBroadcastList)
      || isProcedurePerformedDuringProcedureWithReason(visit,m,QPP329Elements.Vascular_Access,QPP329Elements.Vas_Access_Medical_Reason,QPP329Elements.Maintenance_Hemodialysis)
      || isProcedurePerformedDuringProcedureWithReason(visit,m,QPP329Elements.Vascular_Access,QPP329Elements.Vas_Access_Patient_Reason,QPP329Elements.Maintenance_Hemodialysis)
      || isProcedurePerformedDuringProcedureWithReason(visit,m,QPP329Elements.Vascular_Access,QPP329Elements.System_Reason,QPP329Elements.Maintenance_Hemodialysis)
      || isInterventionPerformed(visit,m,QPP329Elements.Follow_Up_Nephrologist,patientHistoryBroadcastList)
    )
  }
}
