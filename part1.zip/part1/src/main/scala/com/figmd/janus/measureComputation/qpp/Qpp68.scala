package com.figmd.janus.measureComputation.qpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 68
* Measure Title              :- Hematology: Myelodysplastic Syndrome (MDS): Documentation of Iron Stores in Patients Receiving Erythropoietin Therapy
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of myelodysplastic syndrome (MDS)
                                who are receiving erythropoietin therapy with documentation of iron stores within 60 days prior to initiating erythropoietin therapy
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp68 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp68"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      , QPP68Elements.Erythropoietin_Therapy
      , QPP68Elements.Erythropoetin
      , QPP68Elements.Documentation_Of_Iron_Stores
      , QPP68Elements.Iron_Stores
      , QPP68Elements.Iron_Stores_Reason_Not_Specified
      , QPP68Elements.Iron_Stores_System_Reason)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateA = getSubtractRDD(ippRDD, metRDD)
      intermediateA.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateA, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  All patients aged 18 years and older with a diagnosis of myelodysplastic syndrome (MDS) who are receiving erythropoietin therapy
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(rdd:RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
          isPatientAdult(visit,m)
      &&  isVisitTypeIn(visit,m
              ,QPP68Elements.Office_Visit
              ,QPP68Elements.Outpatient_Consultation)
      &&  isDiagnosedDuringEncounter(visit,m,QPP68Elements.Myelodysplastic_Syndrome)
      &&  (   isMedicationAdministeredPerformed(visit,m,QPP68Elements.Erythropoietin_Therapy,patientHistoryBroadcastList)
           || isMedicationAdministeredPerformed(visit,m,QPP68Elements.Erythropoetin,patientHistoryBroadcastList)
          )
      && ! isTeleHealthModifier(visit,m
               ,QPP68Elements.Office_Visit_Telehealth_Modifier
               ,QPP68Elements.Outpatient_Consultation_Telehealth_Modifier)
      &&  isPOSEncounterNotPerformed(visit,m,QPP68Elements.Pos_02)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Patients with documentation of iron stores within 60 days prior to initiating erythropoietin therapy
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
     (    wasLaboratoryTestPerformedBeforeMedicationInDays(visit,m,QPP68Elements.Erythropoietin_Therapy_Date,QPP68Elements.Documentation_Of_Iron_Stores,60,patientHistoryBroadcastList)
      ||  wasLaboratoryTestPerformedBeforeMedicationInDays(visit,m,QPP68Elements.Erythropoietin_Therapy_Date,QPP68Elements.Iron_Stores,60,patientHistoryBroadcastList)
      ||  wasLaboratoryTestPerformedBeforeMedicationInDays(visit,m,QPP68Elements.Erythropoetin__Date,QPP68Elements.Documentation_Of_Iron_Stores,60,patientHistoryBroadcastList)
      ||  wasLaboratoryTestPerformedBeforeMedicationInDays(visit,m,QPP68Elements.Erythropoetin__Date,QPP68Elements.Iron_Stores,60,patientHistoryBroadcastList)
     )
      && ! wasLaboratoryTestPerformedBeforeMedicationInDays(visit,m,QPP68Elements.Erythropoietin_Therapy_Date,QPP68Elements.Iron_Stores_Reason_Not_Specified,60,patientHistoryBroadcastList)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Documentation of system reason(s) for not documenting iron stores prior to initiating erythropoietin therapy
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    rdd.filter(visit =>
      wasLaboratoryTestPerformedBeforeMedicationInDays(visit,m,QPP68Elements.Erythropoietin_Therapy_Date,QPP68Elements.Iron_Stores_System_Reason,60,patientHistoryBroadcastList)
    )
  }
}

