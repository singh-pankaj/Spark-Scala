package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP404Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 404
* Measure Title              :- Anesthesiology Smoking Abstinence
* Measure Description        :- The percentage of current smokers who abstain from cigarettes prior to anesthesia on the day of elective surgery or procedure
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp404 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp404"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP404Elements.Surgery_Elective,
      QPP404Elements.Elective_Surgery,
      QPP404Elements.Anesthesia_For_Elective_Surgery,
      QPP404Elements.Current_Smoker,
      QPP404Elements.Pipe_Tobacco_Smoker,
      QPP404Elements.Cigarette_Smoker,
      QPP404Elements.Cigar_Smoker,
      QPP404Elements.E_Cigarette_Or_Marijuana_Smoker,
      QPP404Elements.Abstinence_From_Smoking,
      QPP404Elements.Abstinence_Smoking,
      QPP404Elements.Exhaled_Carbon_Monoxide_Level_Ppm
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(denominatorRDD, metRDD)
      notMetRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /* All patients aged 18 years and older who are evaluated in preparation for elective surgical, diagnostic, or pain procedure requiring anesthesia services in settings that include routine screening for smoking status prior to the day of the surgery or procedure with instruction to abstain from smoking on the day of surgery or procedure.*/

  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isPatientAdult(visit, m)
        && wasProcedurePerformedBeforeOtherProcedures(visit, m, QPP404Elements.Anesthesia_For_Elective_Surgery, patientHistoryBroadcastList, Seq(QPP404Elements.Surgery_Elective,QPP404Elements.Elective_Surgery))
        && isProcedurePerformed(visit, m, QPP404Elements.Anesthesia_For_Elective_Surgery, patientHistoryBroadcastList)
        && isPatientCharacteristicBeforeProcedure(visit, m, QPP404Elements.Anesthesia_For_Elective_Surgery, patientHistoryBroadcastList, QPP404Elements.Current_Smoker,
        QPP404Elements.Pipe_Tobacco_Smoker,
        QPP404Elements.Cigarette_Smoker,
        QPP404Elements.Cigar_Smoker,
        QPP404Elements.E_Cigarette_Or_Marijuana_Smoker
      )
        &&
        (isProcedurePerformedBeforeOtherProcedureInXDays(visit, m, QPP404Elements.Preoperative_Instruction_From_Anesthesiologist, QPP404Elements.Surgery_Elective, 1, patientHistoryBroadcastList)
          || isProcedurePerformedBeforeOtherProcedureInXDays(visit, m, QPP404Elements.Preoperative_Instruction_From_Anesthesiologist, QPP404Elements.Elective_Surgery, 1, patientHistoryBroadcastList)
          )
        || (isProcedurePerformedBeforeOtherProcedureInXDays(visit, m, QPP404Elements.Preoperative_Instruction_Anesthesiologist, QPP404Elements.Surgery_Elective, 1, patientHistoryBroadcastList)
        || isProcedurePerformedBeforeOtherProcedureInXDays(visit, m, QPP404Elements.Preoperative_Instruction_Anesthesiologist, QPP404Elements.Elective_Surgery, 1, patientHistoryBroadcastList)
        )
    )
  }


  // Numerator criteria
  /* Current smokers and who abstained from smoking prior to anesthesia on the day of surgery or procedure. */

  def getMet(ipp: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ipp.filter(visit =>
      (
        isInterventionPerformedDuringProcedure(visit, m, QPP404Elements.Abstinence_From_Smoking, QPP404Elements.Surgery_Elective)
          || isInterventionPerformedDuringProcedure(visit, m, QPP404Elements.Abstinence_From_Smoking, QPP404Elements.Elective_Surgery)
        )
        ||
        (wasInterventionPerformedBeforeProcedure(visit, m, QPP404Elements.Anesthesia_For_Elective_Surgery, patientHistoryBroadcastList, QPP404Elements.Abstinence_Smoking)
          || wasDiagnosticStudyPerformedBeforeProcedure(visit, m, QPP404Elements.Anesthesia_For_Elective_Surgery, patientHistoryBroadcastList, QPP404Elements.Exhaled_Carbon_Monoxide_Level_Ppm)
          )
          && !wasInterventionPerformedBeforeProcedure(visit, m, QPP404Elements.Anesthesia_For_Elective_Surgery, patientHistoryBroadcastList, QPP404Elements.Abstinence_Not_Met)

    )
  }
}
