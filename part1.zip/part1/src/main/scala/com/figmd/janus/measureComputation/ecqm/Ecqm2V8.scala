package com.figmd.janus.measureComputation.ecqm


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.ecqm.Ecqm144V7_2.{MEASURE_NAME, checkEmptyIPPRDD}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- eCQM 2v8
* Measure Title              :- Preventive Care and Screening: Screening for Depression and Follow-Up Plan
* Measure Description        :- Percentage of patients aged 12 years and older screened for depression on the date of the encounter using
                                an age appropriate standardized depression screening tool AND if positive, a follow-up plan is documented on the date of the positive screen.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- NA
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm2V8 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm2V8"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistory: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      , ECQM2V8Elements.Depression_Diagnosis
      , ECQM2V8Elements.Bipolar_Diagnosis
      , ECQM2V8Elements.Additional_Evaluation_For_Depression___Adolescent
      , ECQM2V8Elements.Referral_For_Depression_Adolescent
      , ECQM2V8Elements.Depression_Medications___Adolescent
      , ECQM2V8Elements.Follow_Up_For_Depression___Adolescent
      , ECQM2V8Elements.Suicide_Risk_Assessment
      , ECQM2V8Elements.Additional_Evaluation_For_Depression___Adult
      , ECQM2V8Elements.Referral_For_Depression_Adult
      , ECQM2V8Elements.Depression_Medications___Adult
      , ECQM2V8Elements.Follow_Up_For_Depression___Adult
      , ECQM2V8Elements.Adult_Depression_Screening
      , ECQM2V8Elements.Adolescent_Depression_Screening)

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistory.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Eligible IPP
      //val eligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exclusions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateB, patientHistoryList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  All patients aged 12 years and older at the beginning of the measurement period with at least one eligible encounter during the measurement period
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 12)
        && isVisitTypeIn(visit, m, ECQM2V8Elements.Depression_Screening__Encounter_Codes)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Patients with an active diagnosis for depression or a diagnosis of bipolar disorder
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getExclusion(intermediateA: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      wasDiagnosisBeforeorEqualEncounter(visit, m, ECQM2V8Elements.Depression_Screening__Encounter_Codes_Date, ECQM2V8Elements.Depression_Diagnosis, patienthistoryList)
        || wasDiagnosisBeforeorEqualEncounter(visit, m, ECQM2V8Elements.Depression_Screening__Encounter_Codes_Date, ECQM2V8Elements.Bipolar_Diagnosis, patienthistoryList)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Patients screened for depression on the date of the encounter using an age appropriate standardized tool AND if positive,
  a follow-up plan is documented on the date of the positive screen
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (isAssessmentPerformedWithResultDuringEncounter(visit, m, ECQM2V8Elements.Adolescent_Depression_Screening, ECQM2V8Elements.Negative_Depression_Screening)
        && isAgeBelow(visit, m, false, 18)
        )
        || (isAssessmentPerformedWithResultDuringEncounter(visit, m, ECQM2V8Elements.Adolescent_Depression_Screening, ECQM2V8Elements.Positive_Depression_Screening)
        && (isInterventionPerformedAfterAssessmentWithInXDays(visit, m, ECQM2V8Elements.Adolescent_Depression_Screening, ECQM2V8Elements.Additional_Evaluation_For_Depression___Adolescent, 1, patienthistoryList)
        || isInterventionOrderedAfterAssessmentWithInXDays(visit, m, ECQM2V8Elements.Adolescent_Depression_Screening, ECQM2V8Elements.Referral_For_Depression_Adolescent, 1, patienthistoryList)
        || isMedicationOrderedAfterAssessmentWithInXDays(visit, m, ECQM2V8Elements.Adolescent_Depression_Screening, ECQM2V8Elements.Depression_Medications___Adolescent, 1, patienthistoryList)
        || isInterventionPerformedAfterAssessmentWithInXDays(visit, m, ECQM2V8Elements.Adolescent_Depression_Screening, ECQM2V8Elements.Follow_Up_For_Depression___Adolescent, 1, patienthistoryList)
        || isProcedurePerformedAfterAssessmentWithInXDays(visit, m, ECQM2V8Elements.Adolescent_Depression_Screening, ECQM2V8Elements.Suicide_Risk_Assessment, 1, patienthistoryList)
        )
        && isAgeBelow(visit, m, false, 18)
        )
        || (isAssessmentPerformedWithResultDuringEncounter(visit, m, ECQM2V8Elements.Adult_Depression_Screening, ECQM2V8Elements.Negative_Depression_Screening)
        && isAgeAbove(visit, m, true, 18)
        )
        || (isAssessmentPerformedWithResultDuringEncounter(visit, m, ECQM2V8Elements.Adult_Depression_Screening, ECQM2V8Elements.Positive_Depression_Screening)
        && (isInterventionPerformedAfterAssessmentWithInXDays(visit, m, ECQM2V8Elements.Adult_Depression_Screening, ECQM2V8Elements.Additional_Evaluation_For_Depression___Adult, 1, patienthistoryList)
        || isInterventionOrderedAfterAssessmentWithInXDays(visit, m, ECQM2V8Elements.Adult_Depression_Screening, ECQM2V8Elements.Referral_For_Depression_Adult, 1, patienthistoryList)
        || isMedicationOrderedAfterAssessmentWithInXDays(visit, m, ECQM2V8Elements.Adult_Depression_Screening, ECQM2V8Elements.Depression_Medications___Adult, 1, patienthistoryList)
        || isInterventionPerformedAfterAssessmentWithInXDays(visit, m, ECQM2V8Elements.Adult_Depression_Screening, ECQM2V8Elements.Follow_Up_For_Depression___Adult, 1, patienthistoryList)
        || isProcedurePerformedAfterAssessmentWithInXDays(visit, m, ECQM2V8Elements.Adult_Depression_Screening, ECQM2V8Elements.Suicide_Risk_Assessment, 1, patienthistoryList)
        )
        && isAgeAbove(visit, m, true, 18)
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Patient Reason(s)
  Patient refuses to participate
  OR
  Medical Reason(s)
  Patient is in an urgent or emergent situation where time is of the essence and to delay treatment would jeopardize the patient's health status
  OR
  Situations where the patient's functional capacity or motivation to improve may impact the accuracy of results of standardized depression assessment tools.
  For example: certain court appointed cases or cases of delirium
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateA: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      ((isAssessmentPerformedDuringEncounter(visit, m, ECQM2V8Elements.Medical_Or_Other_Reason_Not_Done)
        || isAssessmentPerformedDuringEncounter(visit, m, ECQM2V8Elements.Patient_Reason_Refused)
        )
        && !isAssessmentPerformed(visit, m, ECQM2V8Elements.Adult_Depression_Screening, patienthistoryList)
        )
        ||
        ((isAssessmentPerformedDuringEncounter(visit, m, ECQM2V8Elements.Medical_Or_Other_Reason_Not_Done)
          || isAssessmentPerformedDuringEncounter(visit, m, ECQM2V8Elements.Patient_Reason_Refused)
          )
          && !isAssessmentPerformed(visit, m, ECQM2V8Elements.Adolescent_Depression_Screening, patienthistoryList)
          )
    )
  }
}

