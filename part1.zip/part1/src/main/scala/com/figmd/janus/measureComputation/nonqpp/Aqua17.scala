package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AQUA17Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AQUA 17
* Measure Title              :- Non Muscle Invasive Bladder Cancer: Initiation of BCG 3 months of diagnosis of high grade T1 bladder cancer and/or CIS
* Measure Description        :- Percentage of patients who initiate BCG treatment within 3 months of diagnosis of highâ€grade T1 bladder cancer and/or CIS.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/
object Aqua17 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Aqua17"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patienthistoryRdd = getPatientHistory(sparkSession, initialRDD,
      AQUA17Elements.Bladder_Cancer_T1,
      AQUA17Elements.Carcinoma_In_Situ,
      AQUA17Elements.Non_Urothelial_Histology,
      AQUA17Elements.Bcg_Treatment,
      AQUA17Elements.Chemotherapy_Onset,
      AQUA17Elements.Radical_Cystectomy,
      AQUA17Elements.Bcg_Treatment
    )

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistoryRdd.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusion
      val exclusionRDD = getExclusion(ippRDD, patientHistoryList)

      //Filter notEligibleRDD
      val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      notEligibleRDD.cache()

      // Filter Intermediate A
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Intermediate B
      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      // Filter Denominator Exception
      val exceptionRDD = getException(intermediateB, patientHistoryList)
      exceptionRDD.cache()

      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }


  // IPP criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      (wasDiagnosisAfterOrConcurentWithDiagnosis(visit, m, AQUA17Elements.Bladder_Cancer, patientHistoryList, AQUA17Elements.Bladder_Cancer_T1)
        || wasDiagnosisAfterOrConcurentWithDiagnosis(visit, m, AQUA17Elements.Bladder_Cancer, patientHistoryList, AQUA17Elements.Carcinoma_In_Situ))
        && (
        wasDiagnosisAfterOrConcurentWithProcedure(visit, m, AQUA17Elements.Transurethral_Resection_For_Bladder_Tumor, patientHistoryList, AQUA17Elements.Bladder_Cancer_T1)
          || wasDiagnosisAfterOrConcurentWithProcedure(visit, m, AQUA17Elements.Transurethral_Resection_For_Bladder_Tumor, patientHistoryList, AQUA17Elements.Carcinoma_In_Situ)
        )
      && isProcedurePerformedDuringEncounter(visit, m, AQUA17Elements.Transurethral_Resection_For_Bladder_Tumor)
    )
  }


  // Exclusion criteria
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      wasLaboratoryTestDuringMeasurementPeriod(visit, m, AQUA17Elements.Non_Urothelial_Histology, patientHistoryList)
    )
  }


  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      wasProcedurePerformedAfterXMonthsOfProcedure(visit, m,
        AQUA17Elements.Transurethral_Resection_For_Bladder_Tumor, AQUA17Elements.Bcg_Treatment, 3, patientHistoryList)

    )
  }

  // Denominator Exception criteria
  def getException(intermediateB: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    var m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateB.filter(visit =>
      (wasProcedurePerformedXMonthsAfterDiagnosis(visit, m, AQUA17Elements.Bladder_Cancer, AQUA17Elements.Chemotherapy_Onset, 3, patientHistoryList)
        ||
        wasProcedurePerformedXMonthsAfterDiagnosis(visit, m, AQUA17Elements.Bladder_Cancer, AQUA17Elements.Radical_Cystectomy, 3, patientHistoryList))
      || wasProcedureEndsBeforeProcedureInXWeeks(visit, m, AQUA17Elements.Transurethral_Resection_For_Bladder_Tumor, AQUA17Elements.Bcg_Treatment, 6, patientHistoryList)
    )
  }
}
