package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{IRIS23Elements, MeasureProperty, QPP112Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- IRIS 23
* Measure Title              :- Refractive Surgery: Patients with a postoperative uncorrected visual acuity (UCVA) of 20/20 or better
* Measure Description        :- Percentage of patients with an uncorrected visual acuity (UCVA) of 20/20 or better within 30 days
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/
object IRIS23 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "IRIS23"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      IRIS23Elements.Myopia,
      IRIS23Elements.Myopia__Eye,
      IRIS23Elements.Refractive_Surgery__Eye,
      IRIS23Elements.Un_Corrected_Right_Eye_Va_Value,
      IRIS23Elements.Un_Corrected_Left_Eye_Va_Value
    ).collect().toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    val Correct_VA_Values: Array[String] = Array("20/10", "20/11", "20/12", "20/13", "20/14", "20/15", "20/16", "20/17", "20/18", "20/19", "20/2", "20/20", "20/3", "20/4", "20/5", "20/6", "20/7", "20/8", "20/9")

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList, Correct_VA_Values)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()
    }
  }

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
         &&
        (
        wasDiagnosedWithInHistory(visit, m, IRIS23Elements.Myopia, patientHistoryList)
            &&
        wasDiagnosedBeforeEndWithLaterality(visit, m, IRIS23Elements.Myopia, IRIS23Elements.Myopia__Eye, patientHistoryList)
      )
        && (isProcedurePerformedXDaysBeforeEnd(visit, m, IRIS23Elements.Refractive_Surgery_1, 30)
              || (isProcedurePerformedXDaysBeforeEnd(visit, m, IRIS23Elements.Refractive_Surgery_Keywords, 30)
                  && isProcedurePerformedXDaysBeforeEnd(visit, m, IRIS23Elements.Refractive_Surgery_3, 30)))

        && isProcedurePerformedWasConcurrentWith(visit, m, IRIS23Elements.Myopia__Eye, IRIS23Elements.Refractive_Surgery__Eye, patientHistoryList)
    )

  }


  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]],Correct_VA_Values: Array[String]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>

      (wasCorrectedVisualAcuityValueGreaterXDays(visit, m ,IRIS23Elements.Un_Corrected_Right_Eye_Va_Value, IRIS23Elements.Refractive_Surgery_1, 30, Correct_VA_Values, patientHistoryList)
        || (
        wasCorrectedVisualAcuityValueGreaterXDays(visit, m ,IRIS23Elements.Un_Corrected_Right_Eye_Va_Value, IRIS23Elements.Refractive_Surgery_Keywords, 30, Correct_VA_Values, patientHistoryList) &&
          wasCorrectedVisualAcuityValueGreaterXDays(visit, m ,IRIS23Elements.Un_Corrected_Right_Eye_Va_Value, IRIS23Elements.Refractive_Surgery_3, 30, Correct_VA_Values, patientHistoryList)
      ))
      || (wasCorrectedVisualAcuityValueGreaterXDays(visit, m ,IRIS23Elements.Un_Corrected_Left_Eye_Va_Value, IRIS23Elements.Refractive_Surgery_1, 30,Correct_VA_Values, patientHistoryList)
        || (
        wasCorrectedVisualAcuityValueGreaterXDays(visit, m ,IRIS23Elements.Un_Corrected_Left_Eye_Va_Value, IRIS23Elements.Refractive_Surgery_Keywords, 30, Correct_VA_Values, patientHistoryList) &&
          wasCorrectedVisualAcuityValueGreaterXDays(visit, m ,IRIS23Elements.Un_Corrected_Left_Eye_Va_Value, IRIS23Elements.Refractive_Surgery_3, 30, Correct_VA_Values, patientHistoryList)
        ))
    )
  }
}

