package com.figmd.janus.util.measure

import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import java.time.{LocalDateTime, Period, ZoneId}
import java.util.{Date, Properties}
import java.time.{Instant, LocalDate}

import org.joda.time._
import com.datastax.spark.connector.{CassandraRow, _}
import com.figmd.janus.WebDataMartCreator
import com.figmd.janus.WebDataMartCreator.{global_measure_name, prop}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.application._
import org.apache.hadoop.fs.FileSystem
import org.apache.log4j._
import org.apache.spark.rdd.RDD
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.apache.spark.storage.StorageLevel

import scala.reflect.internal.util.TableDef.Column


class MeasureUtility  extends Serializable {


  @transient lazy val dateUtility = new DateUtility();
  @transient lazy val fileUtility = new FileUtility();
  @transient lazy val sparkUtility = new SparkUtility()
  @transient lazy val hdfsConf = FileSystem.get(sparkUtility.getSparkContext().sparkContext.hadoopConfiguration)
  @transient lazy val postgresUtilityObj = new PostgreUtility()
  @transient lazy val wfType = prop.getProperty("wfType")

  @transient lazy val DATE_TIME_FORMAT_EEE = DateTimeFormatter.ofPattern(fileUtility.getProperty("date.format.eee"))
  @transient lazy val DATE_FORMAT = DateTimeFormatter.ofPattern(fileUtility.getProperty("date.format.dd.mm.yyyy"))
  @transient lazy val DATE_FORMATTER = DateTimeFormatter.ofPattern(fileUtility.getProperty("date.format.dd.mm.yyyy"))
  @transient lazy val DATE_TIME_MSECS_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")

  //    var logfilename =""
  lazy val logfilename = fileUtility.getProperty("file.output.path.log")
  //  log4j.appender.rolling.file=${spark.yarn.app.container.log.dir}/spark.log
  @transient lazy val loggerObj: Logger = Logger.getLogger(this.getClass.getName)
  var dateFormat = fileUtility.getProperty("date.format")
  var dateTimeFormat = fileUtility.getProperty("date.time.format")
  var logFile = prop.getProperty("measure_computation_output_path");
  @transient lazy val registry =  prop.getProperty("registry").trim
  final var IPP = "IPP"
  final var MET = "MET"
  final var EXCEPTION = "EXCEPTION"
  final var EXCLUSION = "EXCLUSION"
  final var ELIGIBLE = "ELIGIBLE"
  var message = "";
  var str = "1" + "~"

  //non Log4j
 /* var propobj: Properties = new Properties()
  propobj = fileUtility.getPropertyLog4j()*/


  //Log4j
  val propobj: Properties = new Properties()
  propobj.setProperty("log4j.reset","true")
  propobj.setProperty("log4j.rootLogger","WARN,file")
  propobj.setProperty("log4j.appender.file","org.apache.log4j.FileAppender")
  propobj.setProperty("log4j.appender.file.File","/tmp/CMS/logger_test")
  propobj.setProperty("log4j.appender.file.ImmediateFlush","true")
  propobj.setProperty("log4j.appender.file.Threshold","WARN")
  propobj.setProperty("log4j.appender.file.layout","org.apache.log4j.PatternLayout")
  propobj.setProperty("log4j.appender.file.layout.ConversionPattern","%m%n")
  propobj.setProperty("log4j.appender.file.File", logfilename)


  PropertyConfigurator.configure(propobj)


  var SIMPLE_DATE_FORMAT = new SimpleDateFormat(dateTimeFormat)
  var currentDateTime = LocalDateTime.now().format(DATE_TIME_MSECS_FORMATTER)

/*  val globalStartDate: Date = SIMPLE_DATE_FORMAT.parse("2018-01-01")
  val globalEndDate: Date = SIMPLE_DATE_FORMAT.parse("2018-12-31")
  val globalStartDate1: String ="2018-01-01"
  val globalEndDate1: String ="2018-12-31"*/

  def convertDateToDDMMYYYY(dateString: String): String = {
    //println("::::::::::::::::::::::::::::::::"+dateString)
    LocalDateTime.parse(dateString, DATE_TIME_FORMAT_EEE).format(DATE_FORMAT)
  }

  def convertDateToDDMMYYYY(inputDate: LocalDate): String = {
    return inputDate.format(DATE_FORMATTER)
  }


  def checkEmptyIPPRDD(sparkSession: SparkSession, rdd:RDD[CassandraRow],  ippRdd:RDD[CassandraRow],MeasureName:String): Boolean ={
    if (ippRdd.isEmpty) {
      val emptyRdd = sparkSession.sparkContext.emptyRDD[CassandraRow]
      saveToWebDM(rdd, ippRdd, emptyRdd, emptyRdd, emptyRdd, emptyRdd, emptyRdd, MeasureName)
      false
    }
    else
      true
  }

  /**
    * This function verifies the age of the patient is above the required age.
    * @param r              current visit of the patient.
    * @param measureProperty Measure property of the measure.
    * @param equalFlag      It is used for the greaterorequalto Or greater condition
    * @param compareYears   Number of years to that we have to compare.
    * @return
    */
  def isAgeAbove(r: CassandraRow, measureProperty: MeasureProperty,equalFlag:Boolean, compareYears: Int = 18): Boolean = {
    var isExist = false
    try {
      val start_Date = returnDate(r, "dob")
      val end_Date = returnDate(r, "encounterdate")

      var ageDiffYears: Int = 0
      if (start_Date._1 != null && end_Date._1 != null) {
        ageDiffYears = Years.yearsBetween(start_Date._1, end_Date._1).getYears
        if (equalFlag)
          isExist = ageDiffYears >= compareYears
        else
          isExist = ageDiffYears > compareYears
      }

      val argsArray: Array[String] = Array(start_Date._2, end_Date._2, compareYears.toString)
      measureLogger(r, measureProperty, "isAgeAbove", "dob", isExist, argsArray)

    }
    catch {
      case e: Exception => {
        println("ERROR::::"+e.printStackTrace)
        // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeAbove:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }

/*

  /**
    * This function verifies if the age is above 18 years on quarter start date and quarter end date
    * @param r current patient visit
    * @param m measure property
    * @param equalFlag equal flag
    * @param compareYears compare years
    * @return returns true if  the age is above 18 years on quarter start date and quarter end date else returns false
    */
  def isAgeAboveOnOrBefore(r: CassandraRow, m: MeasureProperty,equalFlag:Boolean,checkOnQuarterStartDate:Boolean, compareYears: Int = 18): Boolean ={
    var isExist = false
    try {
      val start_Date = returnDateFromEpoch(r, "dob")
      val endDateCalculatedOn= if(checkOnQuarterStartDate) m.quarterStartDate else m.quarterEndDate
      val end_Date = (endDateCalculatedOn.toInstant.atZone(ZoneId.systemDefault()).toLocalDate(), convertDateToDDMMYYYY(endDateCalculatedOn.toString))
      var ageDiffYears: Int = 0
      if (start_Date._1 != null && end_Date._1 != null) {
        ageDiffYears = Period.between(start_Date._1, end_Date._1).getYears
        if (equalFlag)
          isExist = ageDiffYears >= compareYears
        else
          isExist = ageDiffYears > compareYears
      }

      val argsArray: Array[String] = Array(start_Date._2, end_Date._2, compareYears.toString)
      measureLogger(r, m, "isAgeAboveOnOrBefore", "dob", isExist, argsArray)

    }
    catch {
      case e: Exception => {
        println("ERROR::::"+e.printStackTrace)
        // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeAboveOnOrBefore:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }
*/

  def getEpoch(inputDate: String): Long = {
    return SIMPLE_DATE_FORMAT.parse(inputDate).getTime/1000
  }

  def getLocalDates(r: CassandraRow, field: String): (LocalDate, String) = {
    if(InputStorageTypeHelper.getStorageType == StorageTypes.CASSANDRA) {
      return (r.getDate(field).toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), convertDateToDDMMYYYY(r.getDate(field).toString))
    } else if(InputStorageTypeHelper.getStorageType() == StorageTypes.BIGTABLE) {
        val inputLocalDate = Instant.ofEpochSecond(getEpoch(r.getString(field))).atZone(ZoneId.systemDefault()).toLocalDate()
        return (inputLocalDate, null)

      /* Working code for epoch
      val inputLocalDate = Instant.ofEpochSecond((r.getInt(field)).toLong.longValue()).atZone(ZoneId.systemDefault()).toLocalDate()
      return (inputLocalDate, convertDateToDDMMYYYY(inputLocalDate))
      */

    } else {
//      throw new UnsupportedOperationException(s"Unsupported Storage Type $storageType for date conversion")
      val inputLocalDate = Instant.ofEpochSecond(getEpoch(r.getString(field))).atZone(ZoneId.systemDefault()).toLocalDate()
      return (inputLocalDate, null)
    }
  }
/*

  //For cassandra
  def getLocalDatesFromEpoch(r: CassandraRow, field: String): (LocalDate, String) = {
    if(InputStorageTypeHelper.getStorageType == StorageTypes.CASSANDRA) {
      return (r.getDate(field).toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), convertDateToDDMMYYYY(r.getDate(field).toString))
    } else if(InputStorageTypeHelper.getStorageType() == StorageTypes.BIGTABLE) {
      //DOB is defined as string in catalog but it contains epoch values - TODO: need to fix in DM
      val inputLocalDate = Instant.ofEpochSecond((r.getString(field)).toLong.longValue()).atZone(ZoneId.systemDefault()).toLocalDate()
      return (inputLocalDate, null)
    } else {
//      throw new UnsupportedOperationException(s"Unsupported Storage Type $storageType for date conversion")
      val inputLocalDate = Instant.ofEpochSecond((r.getString(field)).toLong.longValue()).atZone(ZoneId.systemDefault()).toLocalDate()
      return (inputLocalDate, null)

    }
  }
*/

/*
  def returnDate1(r: CassandraRow, field: String): (LocalDate, String) = {
    r.isNullAt(field) match {
      case false => getLocalDates(r, field)
      case true => (null, null)
    }
  }
*/

  def returnDate(r: CassandraRow, field: String): (DateTime, String) = {
    r.isNullAt(field) match {
      //case false => (r.getDate(field).toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), convertDateToDDMMYYYY(r.getDate(field).toString))
      case false => (r.getDateTime(field), field)
      case true => (null, field)
    }
  }


/*
  /**
    * For cassandra still it considers date in string format as
    * in case of bigtable implementation dob is being populated as epoch instead of string
    * TODO: need to change in CDRTODM as String to keep consistent for casandra and bigtable.
    */
  def returnDateFromEpoch(r: CassandraRow, field: String): (LocalDate, String) = {
    r.isNullAt(field) match {
      case false => getLocalDatesFromEpoch(r, field)
      case true => (null, null)
    }
  }*/
  /*
* @param r as cassandra row
* @param measureProperty case class object contains conditionType as method type and measureName as measure name
* @param startDateDOB as privious date
* @param endDateEncounter as latest date
* @param checkValue as vlaue to check with cassandra value
* @return function return boolean value
* Check age diff is less to given age argument
* */
  def isAgeBelow(r: CassandraRow, measureProperty: MeasureProperty,equalFlag:Boolean, compareYears: Int = 18): Boolean = {
    var isExist = false
    try {

      val start_Date = returnDate(r, "dob")
      val end_Date = returnDate(r, "encounterdate")

      var ageDiffYears: Int = 0
      if (start_Date._1 != null && end_Date._1 != null) {
        ageDiffYears = Years.yearsBetween(start_Date._1, end_Date._1).getYears
        if (equalFlag)
          isExist = ageDiffYears <= compareYears
        else
          isExist = ageDiffYears < compareYears
      }

      val argsArray: Array[String] = Array(start_Date._2, end_Date._2, compareYears.toString)
      measureLogger(r, measureProperty, "isAgeBelow", "dob", isExist, argsArray)

    }
    catch {
      case e: Exception => {
        println(e.printStackTrace())
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeBelow:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }


  def isDateBetween(comparisonDate:DateTime,lowerDate:DateTime, higherDate:DateTime):Boolean={

    (comparisonDate.isAfter(lowerDate) && comparisonDate.isBefore(higherDate) ) || comparisonDate.isEqual(lowerDate) || comparisonDate.isEqual(higherDate)
  }


  def convertDateToYYYYDDMM(dateString: String): String = {
    //println("::::::::::::::::::::::::::::::::"+dateString)
    LocalDateTime.parse(dateString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
  }


  // check element present
  def checkElementPresent(visit: CassandraRow, m: MeasureProperty, elementName: String): Boolean = {

    var isElementExist = false

    try {
      isElementExist = !visit.isNullAt(elementName) && visit.getString(elementName).equalsIgnoreCase("1")
      val argsArray: Array[String] = Array(elementName)
      measureLogger(visit, m, "checkElementPresent", elementName, isElementExist, argsArray)
    } catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:checkElementPresent:" + e.printStackTrace(), "FAIL")
        println(e.getMessage)
       // System.exit(0)
      }
    }

    isElementExist;

  }
  //Function for isAgeBetween
  def isAgeBetween(r: CassandraRow, m:MeasureProperty,compareYears1: Double, compareYears2: Double): Boolean = {
    var isExist = false
    try {
     /* var encounterDate = ""
      if (!r.isNullAt("encounterdate")) {
        encounterDate = convertDateToDDMMYYYY(r.getDate("encounterdate").toString)
      } else {
        encounterDate = ""
      }
      var dobDate = ""
      if (!r.isNullAt("dob")) {
        dobDate = convertDateToDDMMYYYY(r.getDate("dob").toString)
      } else {
        dobDate = ""
      }*/
     /* val start_Date = r.getDateTime("dob")
      val end_Date = r.getDateTime("encounterdate")
      val AgeDiffYears = Years.yearsBetween(start_Date, end_Date).getYears

      isExist = !r.isNullAt("dob") && !r.isNullAt("encounterdate") && ((AgeDiffYears > compareYears1 && AgeDiffYears < compareYears2) || AgeDiffYears == compareYears1)
//      val argsArray: Array[String] = Array(dobDate, encounterDate, compareYears1.toString, compareYears2.toString)
val argsArray: Array[String] = Array("dob", "encounterdate", compareYears1.toString, compareYears2.toString)
      measureLogger(r, m, "isAgeBetween", dobDate, isExist, argsArray)
*/


      val start_Date = returnDate(r, "dob")
      val end_Date = returnDate(r, "encounterdate")

      var ageDiffYears: Int = 0
      if (start_Date._1 != null && end_Date._1 != null) {
        ageDiffYears = Years.yearsBetween(start_Date._1, end_Date._1).getYears
          isExist = ((ageDiffYears > compareYears1 && ageDiffYears < compareYears2) || ageDiffYears == compareYears1)
      }

      val argsArray: Array[String] = Array(start_Date._2, end_Date._2,compareYears1.toString, compareYears2.toString)
      measureLogger(r, m, "isAgeBelow", "dob", isExist, argsArray)



    }
    catch {
      case e: Exception => {
      //  postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeBetween:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }
/*

  /**
    * This function verifies if the patient's age is between two range
    * @param r current patient visit
    * @param m measure property
    * @param lowerAge lower age
    * @param lowerAgeCompareFlag valid lower age flags CompareOperator.{GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL}
    * @param upperAge upper age
    * @param upperAgeCompareFlag valid upper age flag CompareOperator.{GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL}
    * @return returns true if if the patient's age is between two range else returns false
    */
  def isAgeBetween(r: CassandraRow, m:MeasureProperty,lowerAge: Double,lowerAgeCompareFlag:String, upperAge: Double,upperAgeCompareFlag:String): Boolean = {
    var isExist = false
    try {
      var encounterDate = ""
      if (!r.isNullAt("encounterdate")) {
        encounterDate = convertDateToDDMMYYYY(r.getDate("encounterdate").toString)
      } else {
        encounterDate = ""
      }
      var dobDate = ""
      if (!r.isNullAt("dob")) {
        dobDate = convertDateToDDMMYYYY(r.getDate("dob").toString)
      } else {
        dobDate = ""
      }
      val start_Date = r.getDateTime("dob")
      val end_Date = r.getDateTime("encounterdate")
      val ageDiffYears = Years.yearsBetween(start_Date, end_Date).getYears

      isExist = !r.isNullAt("dob") && !r.isNullAt("encounterdate") && (compareValueStatus(ageDiffYears,lowerAgeCompareFlag,lowerAge) && compareValueStatus(ageDiffYears,upperAgeCompareFlag,upperAge))
      val argsArray: Array[String] = Array(dobDate, encounterDate, lowerAge.toString, upperAge.toString)
      measureLogger(r, m, "isAgeBetween", dobDate, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeBetween:" + e.printStackTrace(), "FAIL")

      }
    }
    isExist
  }
*/

 /* def checknull(r: CassandraRow, m:MeasureProperty, checkElement: String): Boolean = {
    var isExist = false
    try {
      isExist = r.isNullAt(checkElement) || r.getString(checkElement) == "0" || r.getString(checkElement).equals("0") || r.getString(checkElement).equalsIgnoreCase("null")
      val argsArray: Array[String] = Array(checkElement)
      measureLogger(r, m, "checknull", checkElement, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:checknull:" + e.printStackTrace(), "FAIL")

      }
    }
    isExist
  }*/


 /* // function for isElementDateStartAfterStartOfWithInDays
  def isElementDateStartAfterStartOfWithInDays(r: CassandraRow, m:MeasureProperty, checkDate: String, compareDate: String, no_of_Days: Int): Boolean = {
    var isExist = false
    try {
      var cDate = ""
      if (!r.isNullAt(compareDate)) {
        cDate = convertDateToDDMMYYYY(r.getDate(compareDate).toString)
      } else {
        cDate = compareDate
      }

      isExist = !r.isNullAt(checkDate) && !r.isNullAt(compareDate) && !r.isNullAt(checkDate) && ((
        r.getDateTime(checkDate).isBefore(r.getDateTime(compareDate).plusDays(no_of_Days)) &&
          r.getDateTime(checkDate).isAfter(r.getDateTime(compareDate))
        ) || r.getDateTime(checkDate).equals(r.getDateTime(compareDate).plusDays(no_of_Days)) || r.getDate(checkDate).equals(r.getDate(compareDate))
        )
      val argsArray: Array[String] = Array(checkDate, cDate, cDate, no_of_Days.toString)
      measureLogger(r, m, "isElementDateStartAfterStartOfWithInDays", checkDate, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isElementDateStartAfterStartOfWithInDays:" + e.printStackTrace(), "FAIL")

      }
    }
    isExist
  }*/




  // function for isDateEqual
  def isDateEqual(r: CassandraRow, m:MeasureProperty, firstDate: String, compareDate: String): Boolean = {
    var isExist = false
    try {
     /* var cDate = ""
      if (!r.isNullAt(compareDate)) {
        cDate = convertDateToDDMMYYYY(r.getDate(compareDate).toString)
      } else {
        cDate = compareDate
      }
      var fDate = ""
      if (!r.isNullAt(firstDate)) {
        fDate = convertDateToDDMMYYYY(r.getDate(firstDate).toString)
      } else {
        fDate = firstDate
      }*/

      isExist = !r.isNullAt(firstDate) && !r.isNullAt(compareDate) && (r.getDateTime(firstDate).getYear.equals(r.getDateTime(compareDate).getYear) && r.getDateTime(firstDate).getMonthOfYear.equals(r.getDateTime(compareDate).getMonthOfYear) && r.getDateTime(firstDate).getDayOfMonth.equals(r.getDateTime(compareDate).getDayOfMonth))


      /*val argsArray: Array[String] = Array(fDate, cDate)*/
      val argsArray: Array[String] = Array(firstDate, compareDate)
      measureLogger(r, m, "isDateEqual", firstDate, isExist, argsArray)

    }
    catch {
      case e: Exception =>
        //  postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDateEqual:" + e.printStackTrace(), "FAIL")

        loggerObj.error(e.getMessage)
      //System.exit(0)}
    }
    isExist;
  }


  def isDateEqualList(r: CassandraRow, m:MeasureProperty, firstDate: String, compareDate: Seq[String]): Boolean = {

    compareDate.exists( z => !r.isNullAt(firstDate) && !z.isEmpty && r.getDate(z).equals(r.getDate(firstDate)))
  }

  //  def measureLogger(r: CassandraRow, measureName: String, conditionType: String, conditionName: String, elementName: String, status: Boolean, description : String): Unit = {
  //    try {
  //      //var logStr=""+measureName +"~"+quarterEndDate +"~"+wfType +"~"+r.getString("practiceuid")+"~"+ r.getString("patientuid")+"~"+ r.getString("visituid") + "~" + conditionType + "~" + conditionName + "~" + elementName + "~" + status + "~" + description
  //      var logStr = "" + measureName + "~" + r.getString("practiceuid") + "~" + r.getString("patientuid") + "~" + r.getString("visituid") + "~" + conditionType + "~" + conditionName + "~" + elementName + "~" + status + "~" + description
  //      //loggerObj.warn(logStr)
  //    }
  //    catch {
  //      case e: Exception => println(e.printStackTrace)
  //    }
  //  }

  def measureLogger(r: CassandraRow, m: MeasureProperty, functionName: String, elementName: String, status: Boolean, arr: Array[String]): Unit = {
    try {
 /*      val description = messageMap(functionName + "_" + status).format(arr: _*)
       val logStr = "" +  m.MeasureName + "~" + r.getString("practiceuid") + "~" + r.getString("patientuid") + "~" + r.getString("visituid") + "~" + m.ConditionType + "~" + functionName + "~" + elementName + "~" + status + "~" + description
       //val logStr = "" + m.ConditionType + "~" + functionName + "~" + elementName + "~" + status + "~" + description
       loggerObj.warn(logStr)
  */  }
    catch {
      case e: Exception => println(e.printStackTrace())
      //System.exit(0)
    }

    /*
        if(File(fileUtility.getProperty("file.output.path.log") ).exists)
        File(fileUtility.getProperty("file.output.path.log") ).appendAll(r.getString("practiceuid")+"~"+ measureName +"~"+r.getString("patientuid")+"~"+ r.getString("visituid") + "~" + conditionType + "~" + conditionName + "~" + elementName + "~" + status + "~" + description  + "\n")
        else {
          File(fileUtility.getProperty("file.output.path.log") ).createFile()
          File(fileUtility.getProperty("file.output.path.log") ).appendAll(r.getString("practiceuid")+"~"+ measureName +"~"+r.getString("patientuid")+"~"+ r.getString("visituid") + "~" + conditionType + "~" + conditionName + "~" + elementName + "~" + status + "~" + description  + "\n")
        }
    */


    // log.info(r.getString("practiceuid") + "," + r.getString("patientuid") + "," + r.getString("visituid") + "," + measureName + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description)

    /*      val file=File(logFile)

           if (file.exists)
             file.appendAll(r.getString("practiceuid") + "~" +measureName + "~" +r.getString("patientuid") + "~" +r.getString("visituid") + "~" +conditionType + "~" +conditionName + "~" +elementName + "~" +status + "~" +description + "\n")
           else{
             file.createFile(true)
             file.appendAll(r.getString("practiceuid") + "~" +measureName + "~" +r.getString("patientuid") + "~" +r.getString("visituid") + "~" +conditionType + "~" +conditionName + "~" +elementName + "~" +status + "~" +description + "\n")
           }*/


    //hdfsConf.append(new org.apache.hadoop.fs.Path(fileUtility.getProperty("file.output.path")+"/"+measureName+"/"+measureName+".log")).writeBytes(r.getString("practiceuid")+","+ measureName +","+r.getString("patientuid")+","+ r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description  + "\n")

    //        @transient lazy val hdfs= FileSystem.get(new SparkUtility().getSparkContext().sparkContext.hadoopConfiguration)


    /*
            val path=new org.apache.hadoop.fs.Path(fileUtility.getProperty("file.output.path")+"/"+measureName+"/"+measureName+".log")
            //@transient lazy val oStream=hdfsConf.create(path)
            //oStream.writeUTF(r.getString("practiceuid")+","+ measureName +","+r.getString("patientuid")+","+ r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description  + "\n")
            //logarray.add(r.getString("practiceuid")+","+ measureName +","+r.getString("patientuid")+","+ r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description  + "\n")
            if(hdfsConf.isFile(path))
              hdfsConf.append(path).writeBytes(r.getString("practiceuid") + "," + measureName + "," + r.getString("patientuid") + "," + r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description + "\n")
            else {
              hdfsConf.create(path)
              hdfsConf.append(path).writeBytes(r.getString("practiceuid") + "," + measureName + "," + r.getString("patientuid") + "," + r.getString("visituid") + "," + conditionType + "," + conditionName + "," + elementName + "," + status + "," + description + "\n")
            }*/

  }


  def getFieldList(measureName: String): Seq[String] = {
    //val elements = fileUtility.getProperty("measure." + measureName + ".element.select");
    val elements = getElements(measureName)
    elements.split(",").toSeq
  }

  // get element with Admin Element

  def getElements(measureName: String): String = {
    import scala.reflect.runtime.universe

    val packageName = "com.figmd.janus.measureComputation.master"

    val measure = measureName.split("_")(0).toUpperCase
    val materElementObject = s"${measure}Elements"

    val runtimeMirror = universe.runtimeMirror(getClass.getClassLoader)
    val adminElement = runtimeMirror.staticModule(s"$packageName.AdminElements")
    val adminObj = runtimeMirror.reflectModule(adminElement).instance

    val module = runtimeMirror.staticModule(s"$packageName.${materElementObject}")
    val obj = runtimeMirror.reflectModule(module).instance

    val adminElements = adminObj.getClass.getDeclaredFields
    val elements = obj.getClass.getDeclaredFields
    var selectproperties = "practiceid,serviceprovideruid,locationid,patientuid,visitid,gender,dob,encounterdate,firstname,midname,lastname,mrn,ssn"



    var pass = ""
    adminElements.foreach(field => {
      field.setAccessible(true)
      val element = field.get(adminObj)
      if(!element.isInstanceOf[String] || element.toString.isEmpty || (element.toString=="") || (element.toString.contains("com.figmd.janus")))
        pass = pass + "," + element.toString
      else
        selectproperties  = selectproperties + "," + element
    })

    elements.foreach(field => {
      field.setAccessible(true)
      val element = field.get(obj)
      if(!element.isInstanceOf[String] || element.toString.isEmpty || (element.toString=="") || (element.toString.contains("com.figmd.janus")))
        pass = pass + "," + element.toString
      else
        selectproperties  = selectproperties + "," + element
    })

    selectproperties
  }

  def getElementsList(measures: String): String = {
    import scala.reflect.runtime.universe

    val packageName = "com.figmd.janus.measureComputation.master"

    val measureNames =measures.split(",")


    val runtimeMirror = universe.runtimeMirror(getClass.getClassLoader)
    val adminElement = runtimeMirror.staticModule(s"$packageName.AdminElements")
    val adminObj = runtimeMirror.reflectModule(adminElement).instance
    val adminElements = adminObj.getClass.getDeclaredFields
    var selectproperties = "practiceid,serviceprovideruid,locationid,patientuid,visitid,gender,dob,encounterdate,firstname,midname,lastname,mrn,ssn"
    var pass = ""
    adminElements.foreach(field => {
      field.setAccessible(true)
      val element = field.get(adminObj)
      if (!element.isInstanceOf[String] || element.toString.isEmpty || (element.toString == "") || (element.toString.contains("com.figmd.janus")))
        pass = pass + "," + element.toString
      else
        selectproperties = selectproperties + "," + element
    })


    for( measureName <- measureNames) {
      val measure = measureName.split("_")(0).toUpperCase
      val materElementObject = s"${measure}Elements"
      val module = runtimeMirror.staticModule(s"$packageName.${materElementObject}")
      val obj = runtimeMirror.reflectModule(module).instance
      val elements = obj.getClass.getDeclaredFields

      elements.foreach(field => {
        field.setAccessible(true)
        val element = field.get(obj)
        if (!element.isInstanceOf[String] || element.toString.isEmpty || (element.toString == "") || (element.toString.contains("com.figmd.janus")))
          pass = pass + "," + element.toString
        else
          selectproperties = selectproperties + "," + element
      })
    }
    selectproperties
  }

  def getNotMet(ippRDD: RDD[CassandraRow], metRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    ippRDD.subtract(metRDD)
  }

  def getSubtractRDD(firstRDD: RDD[CassandraRow], secondRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    firstRDD.subtract(secondRDD)
  }

  def getExceptionRdd(exceptionRDD: RDD[CassandraRow], notMetRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    exceptionRDD.subtract(notMetRDD)
  }

  def getNotMetWithoutException(notMetRDD: RDD[CassandraRow], exceptionRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    notMetRDD.subtract(exceptionRDD)
  }

 /* def getSubtractRDD(firstRDD: RDD[CassandraRow], secoundRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    firstRDD.subtract(secoundRDD)
  }*/

  def isIppEqualsEligible: Boolean = {
    if (fileUtility.getProperty("isIPPequalsEligible").equalsIgnoreCase("true")) {
      true;
    }
    else {
      false;
    }
  }

  def getIPPString(): String = {
    str + "1" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0"
  }

  def saveToWebDM(rdd: RDD[CassandraRow], ippRDD: RDD[CassandraRow], denominatorRDD: RDD[CassandraRow], exclusionRDD: RDD[CassandraRow], metRDD: RDD[CassandraRow], exceptionRDD: RDD[CassandraRow], notMetRDD: RDD[CassandraRow], measureId: String): Unit = {
    try {
      var quarterEndDate = prop.getProperty("quarterEndDate").trim

      if (WebDataMartCreator.debugMode == 1) {
        println("*********************************************************")
        println(" " + measureId + " *** Total Visits       ***" + rdd.count())
        println(" " + measureId + " *** IPP                ***" + ippRDD.count())
        println(" " + measureId + " *** Denominator        ***" + denominatorRDD.count())
        println(" " + measureId + " *** Exclusion          ***" + exclusionRDD.count())
        println(" " + measureId + " *** Met                ***" + metRDD.count())
        println(" " + measureId + " *** Exception          ***" + exceptionRDD.count())
        println(" " + measureId + " *** NotMet             ***" + notMetRDD.count())

        //        if (!rdd.isEmpty())             println(" " + measureId + " *** rdd          ***" + rdd.count()) else println("CMS " + measureId + " *** rdd          ***0")
        //        if (!ippRDD.isEmpty())          println(" " + measureId + " *** IPP          ***" + ippRDD.count()) else println(" " + measureId + " *** IPP          ***0")
        //        if (!notEligibleRDD.isEmpty())  println(" " + measureId + " *** notEligibleRDD          ***" + notEligibleRDD.count()) else println(" " + measureId + " *** notEligibleRDD          ***0")
        //        if (!exclusionRDD.isEmpty())    println(" " + measureId + " *** exclusionRDD          ***" + exclusionRDD.count()) else println(" " + measureId + " *** exclusionRDD          ***0")
        //        if (!exceptionRDD.isEmpty())    println(" " + measureId + " *** exceptionRDD ***" + exceptionRDD.count()) else println(" " + measureId + " *** exceptionRDD ***0")
        //        if (!metRDD.isEmpty())          println(" " + measureId + " *** metRDD       ***" + metRDD.count()) else println(" " + measureId + " *** metRDD       ***0")
        //        if (!notMetRDD.isEmpty())       println(" " + measureId + " *** notMetRDD    ***" + notMetRDD.count()) else println(" " + measureId + " *** notMetRDD    ***0")
        println("*********************************************************")
      }
      else if (WebDataMartCreator.debugMode == 0) {
        var path = new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId + "/" + quarterEndDate)

        if (hdfsConf.isDirectory(path))
          hdfsConf.delete(path, true)

        if (!denominatorRDD.isEmpty()) denominatorRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getNotEligiblePopulationString()).cache().saveAsTextFile(path + "/notEligible")
        if (!exclusionRDD.isEmpty()) exclusionRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getExclusionString()).cache().saveAsTextFile(path + "/exclusion")
        if (!metRDD.isEmpty()) metRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getMetString()).cache().saveAsTextFile(path + "/met")
        if (!exceptionRDD.isEmpty()) exceptionRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getExceptionString()).cache().saveAsTextFile(path + "/exception")
        if (!notMetRDD.isEmpty()) notMetRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getNotMetString()).cache().saveAsTextFile(path + "/notMet")

        //      notEligibleRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getNotEligiblePopulationString()).cache().saveAsTextFile(path + "/notEligible")
        //      exclusionRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getExclusionString()).cache().saveAsTextFile(path + "/exclusion")
        //      metRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getMetString()).cache().saveAsTextFile(path + "/met")
        //      exceptionRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getExceptionString()).cache().saveAsTextFile(path + "/exception")
        //      notMetRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getNotMetString()).cache().saveAsTextFile(path + "/notMet")
        //        postgresUtilityObj.insertIntoProcessDetails(measureId, "", "", "Measure computation done successfully", "PASS")
      }
      else if (WebDataMartCreator.debugMode == 3) {
        //        if (!rdd.isEmpty())             println(" " + measureId + " *** rdd          ***" + rdd.count()) else println("CMS " + measureId + " *** rdd          ***0")
        //        if (!ippRDD.isEmpty())          println(" " + measureId + " *** IPP          ***" + ippRDD.count()) else println(" " + measureId + " *** IPP          ***0")
        //        if (!notEligibleRDD.isEmpty())  println(" " + measureId + " *** notEligibleRDD          ***" + notEligibleRDD.count()) else println(" " + measureId + " *** notEligibleRDD          ***0")
        //        if (!exclusionRDD.isEmpty())    println(" " + measureId + " *** exclusionRDD          ***" + exclusionRDD.count()) else println(" " + measureId + " *** exclusionRDD          ***0")
        //        if (!exceptionRDD.isEmpty())    println(" " + measureId + " *** exceptionRDD ***" + exceptionRDD.count()) else println(" " + measureId + " *** exceptionRDD ***0")
        //        if (!metRDD.isEmpty())          println(" " + measureId + " *** metRDD       ***" + metRDD.count()) else println(" " + measureId + " *** metRDD       ***0")
        //        if (!notMetRDD.isEmpty())       println(" " + measureId + " *** notMetRDD    ***" + notMetRDD.count()) else println(" " + measureId + " *** notMetRDD    ***0")
        println("*********************************************************")

        val schema = StructType(
          List(
            StructField("practice_id", StringType, true),
            StructField("provider_id", StringType, true),
            StructField("location_id", StringType, true),
            StructField("patient_uid", StringType, true),
            StructField("visit_uid", StringType, true),
            StructField("gender", StringType, true),
            StructField("dob", StringType, true),
            StructField("visit_dt", StringType, true),
            StructField("firstname", StringType, true),
            StructField("midname", StringType, true),
            StructField("lastname", StringType, true),
            StructField("mrn", StringType, true),
            StructField("ssn", StringType, true),
            StructField("measure_id", StringType, true),
            StructField("initial_population", StringType, true),
            StructField("denom", StringType, true),
            StructField("denom_exclusion", StringType, true),
            StructField("num", StringType, true),
            StructField("denom_exception", StringType, true),
            StructField("notmet", StringType, true),
            StructField("num_exclusion", StringType, true),
            StructField("num_exception", StringType, true),
            StructField("result", StringType, true)
          ))

        val spark = sparkUtility.getSparkContext()

        import  spark.sqlContext.implicits._

        val result: Int = 0
        val denominatorRdd = denominatorRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getNotEligiblePopulationString() + '~' + result)
        val exclusionRdd = exclusionRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getExclusionString() + '~' + result)
        val metRdd = metRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getMetString() + '~' + result)
        val exceptionRdd = exceptionRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getExceptionString() + '~' + result)
        val notMetRdd = notMetRDD.map(l => generateCSVString(l, measureId, quarterEndDate) + '~' + getNotMetString() + '~' + result)

        val denominatorDF = spark.sqlContext.createDataFrame(
          denominatorRdd.map(r => org.apache.spark.sql.Row.fromSeq(r.split("~"))),
          schema
        ).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        val exclusionDF = spark.sqlContext.createDataFrame(
          exclusionRdd.map(r => org.apache.spark.sql.Row.fromSeq(r.split("~"))),
          schema
        ).persist(StorageLevel.MEMORY_AND_DISK_SER_2)


        val metDF = spark.sqlContext.createDataFrame(
          metRdd.map(r => org.apache.spark.sql.Row.fromSeq(r.split("~"))),
          schema
        ).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        val exceptionDF = spark.sqlContext.createDataFrame(
          exceptionRdd.map(r => org.apache.spark.sql.Row.fromSeq(r.split("~"))),
          schema
        ).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        val notMetDF = spark.sqlContext.createDataFrame(
          notMetRdd.map(r => org.apache.spark.sql.Row.fromSeq(r.split("~"))),
          schema
        ).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        val outputDF = denominatorDF.union(exclusionDF).union(metDF).union(exceptionDF).union(notMetDF)
        saveOutput(outputDF)
        //      notEligibleRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getNotEligiblePopulationString()).cache().saveAsTextFile(path + "/notEligible")
        //      exclusionRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getExclusionString()).cache().saveAsTextFile(path + "/exclusion")
        //      metRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getMetString()).cache().saveAsTextFile(path + "/met")
        //      exceptionRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getExceptionString()).cache().saveAsTextFile(path + "/exception")
        //      notMetRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getNotMetString()).cache().saveAsTextFile(path + "/notMet")
        //        postgresUtilityObj.insertIntoProcessDetails(measureId, "", "", "Measure computation done successfully", "PASS")
      }
    else {
        var path = new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId + "/" + quarterEndDate)

        if (hdfsConf.isDirectory(path))
          hdfsConf.delete(path, true)

        if (!ippRDD.isEmpty()) ippRDD.map(l => l.toString()).cache().saveAsTextFile(path + "/ipp")
        if (!denominatorRDD.isEmpty()) denominatorRDD.map(l => l.toString()).cache().saveAsTextFile(path + "/noteligible")
        if (!exclusionRDD.isEmpty()) exclusionRDD.map(l => l.toString()).cache().saveAsTextFile(path + "/exclusion")
        if (!metRDD.isEmpty()) metRDD.map(l => l.toString()).cache().saveAsTextFile(path + "/met")
        if (!exceptionRDD.isEmpty()) exceptionRDD.map(l => l.toString()).cache().saveAsTextFile(path + "/exception")
        if (!notMetRDD.isEmpty()) notMetRDD.map(l => l.toString()).cache().saveAsTextFile(path + "/notmet")

      }

      ippRDD.unpersist(true);
      metRDD.unpersist(true);
      notMetRDD.unpersist(true);
      exceptionRDD.unpersist(true);
      denominatorRDD.unpersist(true);
      exclusionRDD.unpersist(true);

    }
    catch {
      case e: Exception => {
        println("ERROR:" + e)
     //   postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:saveToWebDM:" + e.getMessage, "FAIL")
        loggerObj.error(e.getMessage)
       // System.exit(0)

      }
    }
  }

  def saveOutput(outputDF: DataFrame): Unit = {

    val summaryDetailsByPracticeDF  = outputDF.withColumn("rowkey",
          functions.concat_ws("|", functions.lit(registry), outputDF.col("practice_id"), outputDF.col("measure_id"), outputDF.col("visit_dt"), outputDF.col("visit_uid")))
      .withColumn("created_dt", functions.lit(currentDateTime))
      .withColumn("updated_dt", functions.lit(currentDateTime))

    val summaryDetailsByProviderDF  = outputDF.withColumn("rowkey",
      functions.concat_ws("|", functions.lit(registry), outputDF.col("provider_id"), outputDF.col("practice_id"), outputDF.col("measure_id"), outputDF.col("visit_dt"), outputDF.col("visit_uid")))
      .withColumn("created_dt", functions.lit(currentDateTime))
      .withColumn("updated_dt", functions.lit(currentDateTime))

    val summaryDetailsByLocation  = outputDF.withColumn("rowkey",
      functions.concat_ws("|", functions.lit(registry), outputDF.col("location_id"), outputDF.col("practice_id"), outputDF.col("measure_id"), outputDF.col("visit_dt"), outputDF.col("visit_uid")))
      .withColumn("created_dt", functions.lit(currentDateTime))
      .withColumn("updated_dt", functions.lit(currentDateTime))

    val summaryDetailsByMeasure  = outputDF.withColumn("rowkey",
              functions.concat_ws("|", functions.lit(registry), outputDF.col("measure_id"), outputDF.col("practice_id"), outputDF.col("visit_dt"), outputDF.col("visit_uid")))
      .withColumn("created_dt", functions.lit(currentDateTime))
      .withColumn("updated_dt", functions.lit(currentDateTime))

//    summaryDetailsByPracticeDF.printSchema()

    //practice_id|measure|encounter_date|visit_uid
    BigTableUtility.createAndSave("summary_details_by_practice","scorecard","rowkey", summaryDetailsByPracticeDF)
    BigTableUtility.createAndSave("summary_details_by_provider","scorecard","rowkey", summaryDetailsByProviderDF)
    BigTableUtility.createAndSave("summary_details_by_location","scorecard","rowkey", summaryDetailsByLocation)
    BigTableUtility.createAndSave("summary_details_by_measure","scorecard","rowkey", summaryDetailsByMeasure)
  }

  def getMetString(): String = {
    str + "1" + "~" + "0" + "~" + "1" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0"
  }

  def getNotMetString(): String = {
    str + "1" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "1" + "~" + "0" + "~" + "0"
  }


  /*  def saveToWebDM(notEligibleRDD: RDD[CassandraRow], exclusionRDD: RDD[CassandraRow], metRDD: RDD[CassandraRow], exceptionRDD: RDD[CassandraRow], notMetRDD: RDD[CassandraRow], measureId: String): Unit = {
      var quarterEndDate = prop.getProperty("quarterEndDate").trim

      var path = new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId + "/" + quarterEndDate)
      if (hdfsConf.isDirectory(path))
        hdfsConf.delete(path, true)

      notEligibleRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getNotEligiblePopulationString()).cache().saveAsTextFile(path + "/notEligible")
      exclusionRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getExclusionString()).cache().saveAsTextFile(path + "/exclusion")
      metRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getMetString()).cache().saveAsTextFile(path + "/met")
      exceptionRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getExceptionString()).cache().saveAsTextFile(path + "/exception")
      notMetRDD.map(l => (if (l.isNullAt(0)) "" else l.columnValues(0)) + "~" + (if (l.isNullAt(1)) "" else l.columnValues(1)) + "~" + (if (l.isNullAt(2)) "" else l.columnValues(2)) + "~" + (if (l.isNullAt(3)) "" else l.columnValues(3)) + "~" + (if (l.isNullAt(4)) "" else l.columnValues(4)) + "~" + (if (l.isNullAt(5)) "" else l.columnValues(5)) + "~" + (if (l.isNullAt(6)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(6).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(7)) "0000-00-00 00:00:00.000000+0000" else LocalDateTime.parse(l.columnValues(7).toString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" + (if (l.isNullAt(8)) "" else l.columnValues(8)) + "~" + (if (l.isNullAt(9)) "" else l.columnValues(9)) + "~" + (if (l.isNullAt(10)) "" else l.columnValues(10)) + "~" + (if (l.isNullAt(11)) "" else l.columnValues(11)) + "~" + measureId + "~" + quarterEndDate + "~" + getNotMetString()).cache().saveAsTextFile(path + "/notMet")
    }*/

  def getExceptionString(): String = {
    str + "1" + "~" + "0" + "~" + "0" + "~" + "1" + "~" + "0" + "~" + "0" + "~" + "0"
  }

  def getNotEligiblePopulationString(): String = {
    str + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0"
  }

  //  def deletePriviousBatch(): Unit =
  //  {
  //    val hdfs= FileSystem.get(new SparkUtility().getSparkContext().sparkContext.hadoopConfiguration)
  //    if(hdfs.isDirectory(new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType)))
  //      hdfs.delete(new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType),true)
  //    println("Deleted directory path: "+prop.getProperty("measure_computation_output_path") + "/" + wfType)
  //    hdfs.close()
  //  }

  def getExclusionString(): String = {
    str + "1" + "~" + "1" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0"
  }

  def generateCSVString(r: CassandraRow, measureId: String, quarterEndDate: String): String = {
    try {
      val dFormat = "yyyy-MM-dd HH:mm:ssZ"
      val defaultValue = "0000-00-00 00:00:00.000000Z"
      //    val dFormat="EEE MMM dd HH:mm:ss zzz yyyy"
      //    val defaultValue="0000-00-00 00:00:00.000000+0000"

      (if (r.isNullAt("practiceid")) "" else r.getString("practiceid")) + "~" +
        (if (r.isNullAt("serviceprovideruid")) "" else r.getString("serviceprovideruid")) + "~" +
        (if (r.isNullAt("locationid")) "" else r.getString("locationid")) + "~" +
        (if (r.isNullAt("patientuid")) "" else r.getString("patientuid")) + "~" +
        (if (r.isNullAt("visitid")) "" else r.getString("visitid")) + "~" +
        //(if (r.isNullAt("visituid")) "" else r.getString("visituid")) + "~" +
        (if (r.isNullAt("gender")) "" else r.getString("gender")) + "~" +
        (if (r.isNullAt("dob")) defaultValue else r.getString("dob")) + "~" +
        (if (r.isNullAt("encounterdate")) defaultValue else r.getString("encounterdate")) + "~" +
        //(if (r.isNullAt("dob")) defaultValue else LocalDateTime.parse(r.getString("dob").toString, DateTimeFormatter.ofPattern(dFormat)).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" +
        //if (r.isNullAt("encounterdate")) defaultValue else LocalDateTime.parse(r.getString("encounterdate").toString, DateTimeFormatter.ofPattern(dFormat)).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))) + "~" +
        (if (r.isNullAt("firstname")) "" else r.getString("firstname")) + "~" +
        (if (r.isNullAt("midname")) "" else r.getString("midname")) + "~" +
        (if (r.isNullAt("lastname")) "" else r.getString("lastname")) + "~" +
        (if (r.isNullAt("mrn")) "" else r.getString("mrn")) + "~" +
        (if (r.isNullAt("ssn")) "" else r.getString("ssn")) + "~" +
        measureId

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:generateCSVString:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
       // System.exit(0)

       ""
      }
    }

  }



  def convertDateToYYYYDDMM1(dateString: String): String = {
    //println("::::::::::::::::::::::::::::::::"+dateString)
    LocalDateTime.parse(dateString, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
  }






  /*def saveRDD(MEASURE_NAME:String,ippRDD:RDD[CassandraRow],locationRDD:RDD[(AnyRef,Double,Int)]): Unit ={
    println("CMS " + MEASURE_NAME)
    if (WebDataMartCreator.debugMode == 1) {
      println("CMS " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
      println("CMS " + MEASURE_NAME + " *** locationRdd    ***" + locationRDD.count())
    }
    else {
      saveToWebDM_median(locationRDD, MEASURE_NAME)
      postgresUtilityObj.insertIntoProcessDetails(MEASURE_NAME, "", "", "Measure computation done successfully", "PASS")
    }

    locationRDD.unpersist(true);
  }
*/



  def saveRDD(MEASURE_NAME: String, ippRDD: RDD[(AnyRef, AnyRef, AnyRef, Double)], practiceRDD: RDD[(AnyRef, Double, Int)],
              locationRDD: RDD[(AnyRef, AnyRef, Double, Int)]
              , providerRDD: RDD[(AnyRef, AnyRef, Double, Int)], providerLocationRDD: RDD[(AnyRef, AnyRef, AnyRef, Double, Int)]): Unit = {
    try {
      if (WebDataMartCreator.debugMode == 1) {
        println("CMS " + MEASURE_NAME + " *** IPP          ***" + ippRDD.count())
        println("CMS " + MEASURE_NAME + " *** practiceRDD    ***" + practiceRDD.count())
        println("CMS " + MEASURE_NAME + " *** locationRdd    ***" + locationRDD.count())
        println("CMS " + MEASURE_NAME + " *** ProviderRdd    ***" + providerRDD.count())
        println("CMS " + MEASURE_NAME + " *** Provider+locationRdd   ***" + providerLocationRDD.count())
      }
      else {
        saveToWebDM_MD(practiceRDD, locationRDD, providerRDD, providerLocationRDD, MEASURE_NAME)
        postgresUtilityObj.insertIntoProcessDetails(MEASURE_NAME, "", "", "Measure computation done successfully", "PASS")
      }

      practiceRDD.unpersist(true);
      locationRDD.unpersist(true);
      providerRDD.unpersist(true);
      providerLocationRDD.unpersist(true);
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:saveRDD:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
       // System.exit(0)

      }
    }
  }

  def saveToWebDM_MD(practiceRDD: RDD[(AnyRef, Double, Int)]
                     , locationRDD: RDD[(AnyRef, AnyRef, Double, Int)],
                     providerRDD: RDD[(AnyRef, AnyRef, Double, Int)], providerLocationRDD: RDD[(AnyRef, AnyRef, AnyRef, Double, Int)],
                     measureId: String): Unit = {
    try {
      var quarterEndDate = prop.getProperty("quarterEndDate").trim
      var wfType = prop.getProperty("wfType").trim


      var path = new org.apache.hadoop.fs.Path(prop.getProperty("measure_computation_output_path") + "/" + wfType + "/" + measureId + "/" + quarterEndDate)
      if (hdfsConf.isDirectory(path))
        hdfsConf.delete(path, true)

      practiceRDD.filter(r => if (r._1 != "") true else false).map(l => if (l._1 != "" && l._2 != "" && l._3 != "") {
        l._1 + "~" + l._2 + "~" + l._3 + "~" + measureId + "~" + quarterEndDate + "~" + wfType
      }).cache().saveAsTextFile(path + "/practice")
      locationRDD.filter(r => if (r._1 != "") true else false).map(l => if (l._1 != "" && l._2 != "" && l._3 != "" && l._4 != "") {
        l._1 + "~" + l._2 + "~" + l._3 + "~" + l._4 + "~" + measureId + "~" + quarterEndDate + "~" + wfType
      }).cache().saveAsTextFile(path + "/location")
      providerRDD.filter(r => if (r._1 != "") true else false).map(l => if (l._1 != "" && l._2 != "" && l._3 != "" && l._4 != "") {
        l._1 + "~" + l._2 + "~" + l._3 + "~" + l._4 + "~" + measureId + "~" + quarterEndDate + "~" + wfType
      }).cache().saveAsTextFile(path + "/provider")
      providerLocationRDD.filter(r => if (r._1 != "") true else false).map(l => if (l._1 != "" && l._2 != "" && l._3 != "" && l._4 != "" && l._5 != "") {
        l._1 + "~" + l._2 + "~" + l._3 + "~" + l._4 + "~" + l._5 + "~" + measureId + "~" + quarterEndDate + "~" + wfType
      }).cache().saveAsTextFile(path + "/providerlocation")
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:saveToWebDM_MD:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
       // System.exit(0)

      }
    }
  }


/*  def checkElementCountGreaterOrEqualElementCount(r: CassandraRow,m:MeasureProperty, ElementPresentCount: Int,  elements: String*): Boolean = {
    var count = 0
    for (eCounter <- 0 until  elements.length) {
      if (checkElementPresent(r, m, elements(eCounter))) {
        count = count + 1
      }
    }
    if (count >= ElementPresentCount) {
      true
    } else false
  }*/

  // function for isDuringInfluenzaPeriodFirstThreeMonth
  def isDuringInfluenzaPeriodFirstThreeMonth(r: CassandraRow, m:MeasureProperty, elementName: String): Boolean = {
    var isExist=false
    try {

      val year = m.quarterStartDate.getYear
      val sdf = new SimpleDateFormat("yyyy-MM-dd")
      val sDate: Date = sdf.parse(year + "-01-01")
      val eDate: Date = sdf.parse(year + "-03-31")

      isExist = !r.isNullAt(elementName) && (
        (sDate.before(eDate) || sDate.equals(eDate)) &&
          ((r.getDate(elementName).after(sDate) && r.getDate(elementName).before(eDate)) ||
            (r.getDate(elementName).equals(sDate) || r.getDate(elementName).equals(eDate)))
        )

      val argsArray: Array[String] = Array(elementName, sDate.toString, eDate.toString)
      measureLogger(r, m, "isDuringInfluenzaPeriodFirstThreeMonth", sDate.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDuringInfluenzaPeriodFirstThreeMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
       // System.exit(0)

      }
    }
    isExist
  }


  // function for isDuringInfluenzaPeriodLastThreeMonth
  def isDuringInfluenzaPeriodLastThreeMonth(r: CassandraRow, m:MeasureProperty, elementName: String): Boolean = {
    try {
      val year = m.quarterStartDate.getYear
      val sdf = new SimpleDateFormat("yyyy-MM-dd")
      val sDate: Date = sdf.parse(year + "-10-01")
      val eDate: Date = sdf.parse(year + "-12-31")

      val status = !r.isNullAt(elementName) && (
        (sDate.before(eDate) || sDate.equals(eDate)) &&
          (
            (r.getDate(elementName).after(sDate) && r.getDate(elementName).before(eDate))
              ||
              r.getDate(elementName).equals(sDate) || r.getDate(elementName).equals(eDate)
            )
        )

      val argsArray: Array[String] = Array(elementName, sDate.toString, eDate.toString)
      measureLogger(r, m, "isDuringInfluenzaPeriodLastThreeMonth", sDate.toString, status, argsArray)

      return status;
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDuringInfluenzaPeriodLastThreeMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
       // System.exit(0)
        false
      }
    }

  }


  // function for isDuringInfluenzaPeriodLastFiveMonth
  def isDuringInfluenzaPeriodLastFiveMonth(r: CassandraRow, m:MeasureProperty, elementName: String): Boolean = {
var status= false
    try {
      val year = m.quarterStartDate.getYear
      val sdf = new SimpleDateFormat(dateFormat)
      val sDate: Date = sdf.parse(year + "-08-01")
      val eDate: Date = sdf.parse(year + "-12-31")

       status = !r.isNullAt(elementName) && (
        (sDate.before(eDate) || sDate.equals(eDate)) &&
          ((r.getDate(elementName).after(sDate) && r.getDate(elementName).before(eDate)) ||
            (r.getDate(elementName).equals(sDate) || r.getDate(elementName).equals(eDate)))
        )
      val argsArray: Array[String] = Array(elementName, sDate.toString, eDate.toString)
      measureLogger(r, m, "isDuringInfluenzaPeriodLastFiveMonth", sDate.toString, status, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDuringInfluenzaPeriodLastFiveMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
       // System.exit(0)

      }
    }
    status
  }


  def isDuringInfluenzaPeriodAfterFirstThreeMonth(r: CassandraRow, m:MeasureProperty, elementName: String): Boolean = {
    var isExist=false
    try {

      val year = m.quarterStartDate.getYear
      val sdf = new SimpleDateFormat("yyyy-MM-dd")
      val sDate: Date = sdf.parse(year + "-04-01")
     // val eDate: Date = sdf.parse(year + "-04-01")


      isExist = !r.isNullAt(elementName) && (sDate.after(sDate) || sDate.equals(sDate))



      val argsArray: Array[String] = Array(elementName, sDate.toString, sDate.toString)
      measureLogger(r, m, "isDuringInfluenzaPeriodAfterFirstThreeMonth", sDate.toString, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDuringInfluenzaPeriodAfterFirstThreeMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }



  /**
    *This function verifies the gender is female.
    * @param visit current visit of the patient.
    * @param m Measure Property of the measure.
    * @return
    */
  def isFemale(visit: CassandraRow, m: MeasureProperty): Boolean = {
    var isElementExist = false
    try {
      isElementExist= !visit.isNullAt("sex") && visit.getString("sex").equalsIgnoreCase("2")
    } catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isFemale:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isElementExist;
  }
  /**
    *This function verifies the gender is isMale.
    * @param visit current visit of the patient.
    * @param m Measure Property of the measure.
    * @return
    */
  def isMale(visit: CassandraRow, m: MeasureProperty): Boolean = {
    var isElementExist = false
    try {
      isElementExist= !visit.isNullAt("sex") && visit.getString("sex").equalsIgnoreCase("1")
    } catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isMale:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isElementExist;
  }

/*  /**
    *
    * @param rdd history rdd
    * @param m measure name and condition type
    * @param elementCount number of element count
    * @param elementNames name of elements
    * @return
    */
  def countElement(rdd: RDD[CassandraRow], m: MeasureProperty,elementCount: Int,elementNames: Seq[String]): Array[String] = {
    val patientVisit:Array[String]=rdd.filter(r=> {
      elementNames.filter(element => !r.isNullAt(element)).size>0
    }).map(r=>(r.getString("patientuid"),1)).reduceByKey((x,y)=>x+y).filter(r=>r._2 >= elementCount).map(r=>r._1).collect()
    patientVisit
  }*/

  /**
    *
    * @param r   Current visit of the patient
    * @param measureProperty Measure Property of the measure
    * @param equalFlag  Equal flag is for checking the condition greaterorEqual or greater condition.
    * @param compareMonth number of months that to be compared.
    * @return
    */
  def isAgeAboveInMonth(r: CassandraRow, measureProperty: MeasureProperty,equalFlag:Boolean, compareMonth: Int): Boolean = {
    var isExist = false

    try {
   /*   var eDate = ""
      if (!r.isNullAt("encounterdate")) {
        eDate = convertDateToDDMMYYYY(r.getDate("encounterdate").toString)
      } else {
        eDate = "encounterdate"
      }
      var sDate = ""
      if (!r.isNullAt("dob")) {
        sDate = convertDateToDDMMYYYY(r.getDate("dob").toString)
      } else {
        sDate = "dob"
      }

      if(equalFlag)
        isExist = !r.isNullAt("dob") && !r.isNullAt("encounterdate") && dateUtility.getMonthDiff(r.getDate("dob"),r.getDate("encounterdate")) >= compareMonth

      else
        isExist = !r.isNullAt("dob") && !r.isNullAt("encounterdate") && dateUtility.getMonthDiff(r.getDate("dob"),r.getDate("encounterdate")) > compareMonth
        */

      val start_Date = returnDate(r, "dob")
      val end_Date = returnDate(r, "encounterdate")

      var ageDiffMonths: Int = 0
      if (start_Date._1 != null && end_Date._1 != null) {
        ageDiffMonths = Months.monthsBetween(start_Date._1, end_Date._1).getMonths
        if (equalFlag)
          isExist = ageDiffMonths >= compareMonth
        else
          isExist = ageDiffMonths > compareMonth
      }

      val argsArray: Array[String] = Array(start_Date._2, end_Date._2, compareMonth.toString)
      measureLogger(r, measureProperty, "isAgeAboveInMonth", "dob", isExist, argsArray)
      
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeAboveInMonth:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

  def isDateInBeween(visit:CassandraRow,m:MeasureProperty,elementDate:String,edvisitArrivalDate:String,edvisitDepartureDate:String):Boolean={
    var isExist= false
    try{
      isExist = !visit.isNullAt(elementDate) && !visit.isNullAt(edvisitArrivalDate) && !visit.isNullAt(edvisitArrivalDate) &&
        (
          visit.getDateTime(elementDate).equals(visit.getDateTime(edvisitArrivalDate)) || visit.getDateTime(elementDate).equals(visit.getDateTime(edvisitDepartureDate))
            ||
            (
              visit.getDateTime(elementDate).isAfter(visit.getDateTime(edvisitArrivalDate)) && visit.getDateTime(elementDate).isBefore(visit.getDateTime(edvisitDepartureDate))
              )
          )
      val argsArray: Array[String] = Array(elementDate,edvisitArrivalDate,edvisitDepartureDate)
      measureLogger(visit, m, "isAgeBetween", elementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDateInBeween:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    *
    * @param visit current patient visit
    * @param m measure property
    * @param element1 get element 1
    * @param value get element value
    * @return yes nad no based on isPhysicalExamPerformedValueLessThanOnEncounter
    */

  def isPhysicalExamPerformedValueLessThanOnEncounter(visit:CassandraRow, m:MeasureProperty,element1:String,value:Double):Boolean= {
    if ( !visit.isNullAt(element1) && visit.getDouble(element1) < value && isDateEqual(visit, m, element1+"_date", "encounterdate") )
      true
    else
      false
  }

  //Function needs to add in the measureutility.
  // function for isDateEqual
  def isDateTimeEqual(r: CassandraRow, m:MeasureProperty, firstDate: String, compareDate: String): Boolean = {
    var isExist = false
    try {
     /* var cDate = ""
      if (!r.isNullAt(compareDate)) {
        cDate = convertDateToDDMMYYYY(r.getDate(compareDate).toString)
      } else {
        cDate = compareDate
      }
      var fDate = ""
      if (!r.isNullAt(firstDate)) {
        fDate = convertDateToDDMMYYYY(r.getDate(firstDate).toString)
      } else {
        fDate = firstDate
      }*/

      isExist = !r.isNullAt(firstDate) && !r.isNullAt(compareDate) && (r.getDateTime(firstDate).equals(r.getDateTime(compareDate)))


      val argsArray: Array[String] = Array(firstDate, compareDate)
      measureLogger(r, m, "isDateTimeEqual", firstDate, isExist, argsArray)

    }
    catch {
      case e: Exception => {
       // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDateTimeEqual:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist;
  }

/*  /**
    * This function verifies the Blood pressure of the patient is in control on the current encounter.
    * @param currentVisit    Current visit of the patient.
    * @param measureProperty Measure property of the Measure
    * @param Element1        Element1 whose value  has to be verified.
    * @param Element2        Element2 whose value  has to be verified.
    * @param lowerValue      Lower value with that Element1 value has to be verified.
    * @param upperValue      Upper value with that Element2 value has to be verified.
    * @return This function will return those patient whose element value is less than
    */
  def  isBloodPressureInControl(currentVisit: CassandraRow, measureProperty: MeasureProperty, Element1: String,Element2: String, lowerValue: Double, upperValue: Double): Boolean = {
    var isExist = false
    try{
      val Element1Date=Element1+"_date"
      val Element2Date=Element2+"_date"

      isExist= (!currentVisit.isNullAt(Element1) && isDateEqual(currentVisit,measureProperty,Element1Date,"encounterdate") && currentVisit.getDouble(Element1)<upperValue ) &&
        (  !currentVisit.isNullAt(Element2)  &&  isDateEqual(currentVisit,measureProperty,Element2Date,"encounterdate")  &&  currentVisit.getDouble(Element2)< lowerValue)

      val argsArray: Array[String] = Array(Element1,upperValue.toString,Element2,lowerValue.toString)
      measureLogger(currentVisit, measureProperty, "isBloodPressureInControl",Element1,isExist,argsArray)
    }
    catch {
      case e: Exception => {
        postgresUtilityObj.insertIntoProcessDetails(WebDataMartCreator.global_measure_name, "W0000", "CRITICAL", "Function Exception:isBloodPressureInControl:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist
  }*/

  /**
    * This function verifies the isDiagnosisDuringEncounter
    * @param visit                Current Visit of the patient.
    * @param m                    Measure Property of the Measure.
    * @param element              Element whose LaboratoryTestOrder is to be checked.
    * @param edvisitArrivalDate   edVisitarrivalDate of the patient.
    * @param edvisitDepartureDate edvisitDepartureDate of the patient.
    * @param crtclDate            crtclDate of the patient.
    * @return
    */
  def isDiagnosisDuringEncounter(visit: CassandraRow, m: MeasureProperty, element: String,  posElement:String, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {

    val elementDate:String=element+"_date"
    val posElementDate:String = posElement+"_date"

    (
      (checkElementPresent(visit, m, element) &&

        (
          isDateInBeween(visit, m, elementDate, edvisitArrivalDate, edvisitDepartureDate)
            ||
            isDateTimeEqual(visit, m, elementDate, crtclDate)
          )
        )

        &&

        (checkElementPresent(visit, m, posElement) &&

          (
            isDateInBeween(visit, m, posElementDate, edvisitArrivalDate, edvisitDepartureDate)
              ||
              isDateTimeEqual(visit, m, posElementDate, crtclDate)
            )
          )
      )

  }


/*

  def AND(function1:Boolean, function2:Boolean):Boolean= {

   function1 && function2

  }
*/



/*

  /**
    * This Function verifies the Diagnosis of the Patient before edVisitDeparture date.
    * @param visit  Current visit of the patient.
    * @param m      Measure Property of the measure.
    * @param element  Element that has to be verified during Emergency visit.
    * @param elementDate Element Date that has be verified during edVisitArrival Date or edvisitdeparture Date
    * @param edvisitDepartureDate edvisitdeparture Date of the patient visit
    * @param crtclDate            critical care Date of  the patient visit
    * @return It will return true for those patient whose Diagnosis before Edvisit Departure of the Patient.
    */
  def isDiagnosedOverlapsEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, element: String, elementDate: String, edvisitDepartureDate: String, crtclDate: String): Boolean = {
    var isExist= false
    try {
      isExist =
        checkElementPresent(visit, m, element) &&
          (
            !visit.isNullAt(elementDate) && !visit.isNullAt(edvisitDepartureDate) &&
              ( visit.getDateTime(elementDate).isBefore(visit.getDateTime(edvisitDepartureDate)) || visit.getDateTime(elementDate).equals(visit.getDateTime(edvisitDepartureDate)))
              ||(visit.getDateTime(elementDate).isBefore(visit.getDateTime(crtclDate)) || visit.getDateTime(elementDate).equals(visit.getDateTime(crtclDate)))
            )

      val argsArray: Array[String] = Array(element)
      measureLogger(visit, m, "isDiagnosedOverlapsEDOrCCEncounter",element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        System.exit(0)
      }
    }
    isExist
  }*/

  /**
    * This function verifies the element date is in between edvisitArrivalDate and edvisitDepartureDate
    * @param visit current patient visit
    * @param m measurement property
    * @param elementDate element date
    * @param edvisitArrivalDate emergency arrival date of the patient visit
    * @param edvisitDepartureDate emergency departure date of the patient visit
    * @return returns true if element date is in between edvisitArrivalDate and edvisitDepartureDate else returns false.
    */

  def isDateInBetween(visit: CassandraRow, m: MeasureProperty, elementDate: String, edvisitArrivalDate: String, edvisitDepartureDate: String): Boolean = {
    var isExist = false
    try {
      isExist = !visit.isNullAt(elementDate) && !visit.isNullAt(edvisitArrivalDate) && !visit.isNullAt(edvisitArrivalDate) &&
        (
          visit.getDateTime(elementDate).equals(visit.getDateTime(edvisitArrivalDate)) || visit.getDateTime(elementDate).equals(visit.getDateTime(edvisitDepartureDate))
            ||
            (
              visit.getDateTime(elementDate).isAfter(visit.getDateTime(edvisitArrivalDate)) && visit.getDateTime(elementDate).isBefore(visit.getDateTime(edvisitDepartureDate))
              )
          )
      val argsArray: Array[String] = Array(elementDate, edvisitArrivalDate, edvisitDepartureDate)
      measureLogger(visit, m, "isDateInBetween", elementDate, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isDateInBetween:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist
  }

  /**
    *
    * This function verifies the GCS result of the patient.
    * @param visit  Current visit of the patient.
    * @param m      Measure Property of the measure.
    * @param element Element whose result is to be verified
    * @param edvisitArrivalDate  Edvisit Arrival Date of the patient.
    * @param edvisitDepartureDate EdVisit Departure Date of the patient.
    * @param crtclDate Critical Care visit Date of the patient.
    * @return  It will return true if the GCS value is less than required value else false
    */
  def isGCSResultDuringEDorCCLessThanX(visit: CassandraRow, m: MeasureProperty, element: String, value:Float, edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    var isExist = false
    val ElementDate:String = element+"_date"
    try{

      isExist= (
        (checkElementPresent(visit, m, element) &&
          (
            isDateInBetween(visit, m, ElementDate, edvisitArrivalDate, edvisitDepartureDate)
              ||
              isDateTimeEqual(visit, m, ElementDate, crtclDate)
            )
          )
          &&
          (
            !visit.isNullAt(element) && (visit.getFloat(element)<value)
            )
        )
      val argsArray: Array[String] = Array(element,value.toString)
      measureLogger(visit, m, "isGCSResultDuringEDorCCLessThanX", element, isExist, argsArray)
    }
    catch {
      case e:Exception=>{
        loggerObj.error(e.getMessage)
       // System.exit(0)
      }
    }
    isExist
  }

  /**
    * This function verifies Medication Order result value grater or equal.
    * @param visit current visit of the patient
    * @param m      Measure Property of the measure
    * @param Element   Element that has to be verified during Emergency visit.
    * @param value      value with that result has to be compared.
    * @param edvisitArrivalDate edVisitArrival Date of the patient visit
    * @param edvisitDepartureDate edvisitdeparture Date of the patient visit
    * @param crtclDate critical care Date of  the patient visit
    * @return it will return true if the result value is greater or equal to desired result else false
    */
  def isMedicationOrderResultDuringEDorCCGreaterThanX(visit: CassandraRow, m: MeasureProperty, Element: String, value:Double,edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    var isExist = false
    val ElementDate:String = Element+"_date"
    try{

      isExist= (
        (checkElementPresent(visit, m, Element) &&
          (
            isDateInBetween(visit, m, ElementDate, edvisitArrivalDate, edvisitDepartureDate)
              ||
              isDateTimeEqual(visit, m, ElementDate, crtclDate)
            )
          )
          &&
          (
            !visit.isNullAt(Element) && (visit.getFloat(Element)>=value)
            )
        )
      val argsArray: Array[String] = Array(Element,value.toString)
      measureLogger(visit, m, "isMedicationOrderResultDuringEDorCCGreaterThanX", Element, isExist, argsArray)
    }
    catch {
      case e:Exception=>{
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist

  }

 /* def isAgeAboveBeforeStart(r: CassandraRow, m:MeasureProperty, equalFlag:Boolean,compareYears: Double): Boolean = {
    var isExist = false
    try {
      val dob_Date = r.getDate("dob").toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
      val start_Date = m.quarterStartDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()


      val AgeInYears = math.abs(Period.between(dob_Date, start_Date).getYears)
      if(equalFlag) { isExist = compareYears >= AgeInYears}
      else { isExist = compareYears > AgeInYears }
      val argsArray: Array[String] = Array(start_Date.toString)
      measureLogger(r, m, "isAgeAboveBeforeStart", dob_Date.toString, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeGreaterOrEqual:" + e.printStackTrace(), "FAIL")
        println(e.getMessage)
        System.exit(0)
      }
    }
    isExist
  }*/


  /**
    * This function verifies if the age is below compareAgeInterval for calenderUnit(YEAR,MONTH,WEEK,DAY) on or before quarter start date
    * @param r current patient visit
    * @param m measure property
    * @param equalFlag equal flag
    * @param compareAgeInterval compare age interval
    * @param calenderUnit valid calender units are (YEAR,MONTH,WEEK,DAY)
    * @return returns true if the age is below compareAgeInterval for calenderUnit(YEAR,MONTH,WEEK,DAY) on or before quarter start date else returns false
    */

  def isAgeBelowBeforeStart(r: CassandraRow, m:MeasureProperty, equalFlag:Boolean,compareAgeInterval: Double,calenderUnit:String): Boolean = {
    var isExist = false
    try {

      /*val start_Date = (r.getDateTime(AdminElements.Date_of_Birth), convertDateToDDMMYYYY(r.getDateTime(AdminElements.Date_of_Birth).toString))
      val end_Date = (m.quarterStartDate, convertDateToDDMMYYYY(m.quarterStartDate.toString))*/

      val start_Date = (r.getDateTime(AdminElements.Date_of_Birth), AdminElements.Date_of_Birth)
      val end_Date = (m.quarterStartDate, m.quarterStartDate.toString)
      var ageDiff: Int = 0
      if (start_Date._1 != null && end_Date._1 != null) {


        calenderUnit match {
          case CalenderUnit.YEAR => ageDiff = Years.yearsBetween(start_Date._1, end_Date._1).getYears
          case CalenderUnit.MONTH => ageDiff = Months.monthsBetween(start_Date._1, end_Date._1).getMonths
          case CalenderUnit.WEEK => ageDiff = Weeks.weeksBetween(start_Date._1, end_Date._1).getWeeks
          case CalenderUnit.DAY => ageDiff = Days.daysBetween(start_Date._1, end_Date._1).getDays
        }
        if (equalFlag)
          isExist = ageDiff <= compareAgeInterval
        else
          isExist = ageDiff < compareAgeInterval
      }

      val argsArray: Array[String] = Array(start_Date._2,end_Date._2,compareAgeInterval.toString)
      measureLogger(r, m, "isAgeBelowBeforeStart", start_Date._2, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeBelowBeforeStart:" + e.printStackTrace(), "FAIL")
        println(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }

 /* /**
    *
    * @param visit current row
    * @param m measure property
    * @param element element from current row
    * @param greaterValue greater value of range
    * @param smallerValue smaller value of range
    * @return returns true is element value in range
    */
  def isElementInValueRangeOnEncounter(visit:CassandraRow, m:MeasureProperty,element: String, greaterValue:Double, smallerValue: Double):Boolean= {
    var isExist = false
    try {

      var isExist = visit.getDouble(element) >= smallerValue && visit.getDouble(element) <= greaterValue

      val argsArray: Array[String] = Array(element,greaterValue.toString,smallerValue.toString)
      measureLogger(visit, m, "isElementInValueRangeOnEncounter", element, isExist, argsArray)
    }

    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        System.exit(0)
      }
    }
    isExist
  }*/





  /**
    * This function verifies the procedure is performed on encounter before x days from end of the measurement period.
    * @param visit Current visit of the patient.
    * @param m measurement property of the measure.
    * @param element Element whose procedure is verified on encounter.
    * @param noOfDays Number of days that has to be subtracted from end of the measurement period.
    * @return It will return true if procedure is performed before X days from measurement period else false.
    */
  def isProcedurePerformedXDaysBeforeEnd(visit: CassandraRow, m: MeasureProperty, element: String,noOfDays:Int):Boolean={
    var isExist =false
   // val endDate: DateTime = m.quarterEndDate
    val elementDate=element+"_date"
    //val End_date = new DateTime(endDate)
    try{
      isExist= !visit.isNullAt(elementDate) && (visit.getDateTime(elementDate).isBefore(m.quarterEndDate.minusDays(noOfDays)) || visit.getDateTime(elementDate).isEqual(m.quarterEndDate.minusDays(noOfDays)))
      val argsArray: Array[String] = Array(element,noOfDays.toString)
      measureLogger(visit, m, "isProcedurePerformedXDaysBeforeEnd", element, isExist, argsArray)
    }
    catch{
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }

    }
    isExist

  }

/*  /**
    * This function verifies if the physical exam performed result value greater or equal to desired result value on current encounter.
    * @param visit   current visit of the patient
    * @param m       Measure property of the measure
    * @param element Element whose result has to be verified
    * @param value   Required value that has to be compared.
    * @return It will return true whose physical exam performed value greater or equal on encounter else false.
    */
  def isPhysicalExamPerformedValueGreaterOrEqualOnEncounter(visit: CassandraRow, m: MeasureProperty, element: String, value: Double): Boolean = {
    var isExist = false
    try {
      isExist = !visit.isNullAt(element) && visit.getDouble(element) >= value && isDateEqual(visit, m, element + "_date", "encounterdate")
      val argsArray: Array[String] = Array(element,value.toString)
    measureLogger(visit, m, "isPhysicalExamPerformedValueGreaterOrEqualOnEncounter", element, isExist, argsArray)
    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        System.exit(0)
      }
    }
    isExist
  }*/
  /**
    * This function verifies if the age is above compareAgeInterval for calenderUnit(YEAR,MONTH,WEEK,DAY) on or before quarter start date
    * @param r current patient visit
    * @param m measure property
    * @param equalFlag equal flag
    * @param compareAgeInterval compare age interval
    * @param calenderUnit valid calender units are (YEAR,MONTH,WEEK,DAY)
    * @return returns true if the age is above compareAgeInterval for calenderUnit(YEAR,MONTH,WEEK,DAY) on or before quarter start date else returns false
    */
  def isAgeAboveBeforeStart(r: CassandraRow, m: MeasureProperty, equalFlag:Boolean, compareAgeInterval: Int = 18,calenderUnit:String): Boolean ={
    var isExist = false
    try {
      val start_Date = (r.getDateTime(AdminElements.Date_of_Birth), convertDateToDDMMYYYY(r.getDateTime(AdminElements.Date_of_Birth).toString))
      val end_Date = (m.quarterStartDate, convertDateToDDMMYYYY(m.quarterStartDate.toString))
      var ageDiff: Int = 0
      if (start_Date._1 != null && end_Date._1 != null) {

        calenderUnit match {
          case CalenderUnit.YEAR => ageDiff = Years.yearsBetween(start_Date._1, end_Date._1).getYears
          case CalenderUnit.MONTH => ageDiff = Months.monthsBetween(start_Date._1, end_Date._1).getMonths
          case CalenderUnit.WEEK => ageDiff = Weeks.weeksBetween(start_Date._1, end_Date._1).getWeeks
          case CalenderUnit.DAY => ageDiff = Days.daysBetween(start_Date._1, end_Date._1).getDays
        }
        if (equalFlag)
          isExist = ageDiff >= compareAgeInterval
        else
          isExist = ageDiff > compareAgeInterval
      }

      val argsArray: Array[String] = Array(start_Date._2, end_Date._2, compareAgeInterval.toString)
      measureLogger(r, m, "isAgeAboveBeforeStart", "dob", isExist, argsArray)

    }
    catch {
      case e: Exception => {
        println("ERROR::::"+e.printStackTrace)
        // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeAboveBeforeStart:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }


  /**
    * This function verifies that first date is before X hours another date.
    * @param r  current visit of the patient.
    * @param m  Measure property of the measure.
    * @param firstDate  first Date that has to compared with another date.
    * @param compareDate Compare Date that will be compared with first date.
    * @param no_of_hours number of hours that will be subtracted from compare date.
    * @return It will return true if dateTime difference in two date is X hours
    */
  def isDateTimeBetweenLessXHours(r: CassandraRow, m:MeasureProperty, firstDate: String, compareDate: String, no_of_hours: Int): Boolean = {
    var isExist = false
    try {
     /* var cDate = ""
      if (!r.isNullAt(compareDate)) {
        cDate = convertDateToDDMMYYYY(r.getDate(compareDate).toString)
      } else {
        cDate = compareDate
      }
      var fDate = ""
      if (!r.isNullAt(firstDate)) {
        fDate = convertDateToDDMMYYYY(r.getDate(firstDate).toString)
      } else {
        fDate = firstDate
      }*/

      isExist = !r.isNullAt(firstDate) && !r.isNullAt(compareDate) && (r.getDateTime(firstDate).equals(r.getDateTime(compareDate).minusHours(no_of_hours))
        || r.getDateTime(firstDate).isAfter(r.getDateTime(compareDate).minusHours(no_of_hours)))


      /*val argsArray: Array[String] = Array(fDate, cDate,no_of_hours.toString)
      measureLogger(r, m, "isDateTimeBetweenLessXHours", fDate, isExist, argsArray)*/
      val argsArray: Array[String] = Array(firstDate, compareDate,no_of_hours.toString)
      measureLogger(r, m, "isDateTimeBetweenLessXHours", firstDate, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        loggerObj.error(e.getMessage)
        //System.exit(0)

      }
    }
    isExist;
  }


 /* /**
    * This function checks if age is above or equals X months at measurement period
    * @param visit current patient visit
    * @param m measure property
    * @param equalFlag if equalFlag true then checks greaterThanOrEqual else checks greater than
    * @param compareMonths compare age in Month unit
    * @return returns true if age is above or equals X months at measurement period else returns false
    */
  def isAgeAboveXInMonthsBeforeStart(visit: CassandraRow, m: MeasureProperty,equalFlag:Boolean,compareMonths: Double=3): Boolean ={
    var isExist = false
    try {
      val start_Date = returnDate(visit, "dob")
      val end_Date = (new DateTime(m.quarterStartDate), convertDateToDDMMYYYY(m.quarterStartDate.toString))
      var ageDiffMonths: Double = 0
      if (start_Date._1 != null && end_Date._1 != null) {
        ageDiffMonths = Months.monthsBetween(start_Date._1, end_Date._1).getMonths
        if (equalFlag)
          isExist = ageDiffMonths >= compareMonths
        else
          isExist = ageDiffMonths > compareMonths
      }

      val argsArray: Array[String] = Array(start_Date._2, end_Date._2, compareMonths.toString)
      measureLogger(visit, m, "isAgeAboveXInMonthBeforeStart", "dob", isExist, argsArray)

    }
    catch {
      case e: Exception => {
        println("ERROR::::"+e.printStackTrace)
        // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeAboveXInMonthBeforeStart:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }*/

  /**
    *
    * This function verifies the result of the patient.
    * @param visit  Current visit of the patient.
    * @param m      Measure Property of the measure.
    * @param Element Element whose result is to be verified
    * @param edvisitArrivalDate  Edvisit Arrival Date of the patient.
    * @param edvisitDepartureDate EdVisit Departure Date of the patient.
    * @param crtclDate Critical Care visit Date of the patient.
    * @return  It will return true if the GCS value is less than required value else false
    */
  def isresultDuringEDorCCGreaterThanX(visit: CassandraRow, m: MeasureProperty, Element: String, value:Float,edvisitArrivalDate: String, edvisitDepartureDate: String, crtclDate: String):Boolean={
    var isExist = false
    val ElementDate:String = Element+"_date"
    try{

      isExist= (
        (checkElementPresent(visit, m, Element) &&
          (
            isDateInBetween(visit, m, ElementDate, edvisitArrivalDate, edvisitDepartureDate)
              ||
              isDateTimeEqual(visit, m, ElementDate, crtclDate)
            )
          )
          &&
          (
            !visit.isNullAt(Element) && (visit.getFloat(Element)>value)
            )
        )
      val argsArray: Array[String] = Array(Element,value.toString)
      measureLogger(visit, m, "isresultDuringEDorCCGreaterThanX", Element, isExist, argsArray)
    }
    catch {
      case e:Exception=>{
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }



 /* /**
    *
    * This function verifies if patient is encountered X hours before emergency visit.
    * @param visit  Current visit of the patient.
    * @param m      Measure Property of the measure.
    * @param Element Element whose result is to be verified
    * @param edvisitArrivalDate  Edvisit Arrival Date of the patient.
    * @param crtclDate Critical Care visit Date of the patient.
    * @return  It will return true if the patient is encountered x hours before emergency visit else false
    */
  def isElementXhoursBeforeOfEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, Element: String, hours:Int,edvisitArrivalDate: String,  crtclDate: String):Boolean={
    var isExist = false
    val ElementDate:String = Element+"_date"
    try{

      isExist=
        checkElementPresent(visit, m, Element) &&
          (
            !visit.isNullAt(ElementDate)  && !visit.isNullAt(edvisitArrivalDate) &&
              (
                visit.getDateTime(ElementDate).isBefore(visit.getDateTime(edvisitArrivalDate).minusHours(hours))
                  ||
                  visit.getDateTime(ElementDate).equals(visit.getDateTime(edvisitArrivalDate).minusHours(hours))
                )
              ||(
              visit.getDateTime(ElementDate).isBefore(visit.getDateTime(crtclDate).minusHours(hours))
                ||
                visit.getDateTime(ElementDate).equals(visit.getDateTime(crtclDate).minusHours(hours))
              )
            )

      val argsArray: Array[String] = Array(Element,hours.toString,edvisitArrivalDate,crtclDate)
      measureLogger(visit, m, "isElementXhoursBeforeOfEDOrCCEncounter", Element, isExist, argsArray)
    }
    catch {
      case e:Exception=>{
        loggerObj.error(e.getMessage)
        System.exit(0)
      }
    }
    isExist
  }*/

/*  /**
    *
    * This function verifies element is X hours before emergency visit.
    * @param visit  Current visit of the patient.
    * @param m      Measure Property of the measure.
    * @param Element Element whose result is to be verified
    * @param edvisitArrivalDate  Edvisit Arrival Date of the patient.
    * @param crtclDate Critical Care visit Date of the patient.
    * @return  It will return true if the GCS value is less than required value else false
    */
  def isElementXhoursBeforeOrConcurrentEDOrCCEncounter(visit: CassandraRow, m: MeasureProperty, Element: String, hours:Int,edvisitArrivalDate: String,  crtclDate: String):Boolean={
    var isExist = false
    val ElementDate:String = Element+"_date"
    try{

      isExist=
        checkElementPresent(visit, m, Element) &&
          (
            !visit.isNullAt(ElementDate)  && !visit.isNullAt(edvisitArrivalDate) &&
              ( (visit.getDateTime(ElementDate).isBefore(visit.getDateTime(edvisitArrivalDate)) && visit.getDateTime(ElementDate).isAfter(visit.getDateTime(edvisitArrivalDate).minusHours(hours)) )
                || visit.getDateTime(ElementDate).equals(visit.getDateTime(edvisitArrivalDate).minusHours(hours)) || visit.getDateTime(ElementDate).isEqual(visit.getDateTime(edvisitArrivalDate)) )
              ||
              (
                (visit.getDateTime(ElementDate).isBefore(visit.getDateTime(crtclDate)) && visit.getDateTime(ElementDate).isAfter(visit.getDateTime(crtclDate).minusHours(hours)))
                  ||
                  visit.getDateTime(ElementDate).equals(visit.getDateTime(crtclDate).minusHours(hours)) || visit.getDateTime(ElementDate).isEqual(visit.getDateTime(crtclDate))
                )
            )

      val argsArray: Array[String] = Array(Element,hours.toString,edvisitArrivalDate,crtclDate)
      measureLogger(visit, m, "isElementXhoursBeforeOrConcurrentEDOrCCEncounter", Element, isExist, argsArray)
    }
    catch {
      case e:Exception=>{
        loggerObj.error(e.getMessage)
        System.exit(0)
      }
    }
    isExist
  }*/

  def countElementByProvider(rdd: RDD[CassandraRow], m: MeasureProperty, elementNames: String*): Array[(String,String,Int)] = {
    val patientVisit = rdd.map(x => ((x.getString("patientuid"),x.getString("serviceprovideruid")), elementNames.toList.map(z => if (!x.isNullAt(z)) 1 else 0).reduce(_ + _)))
      .reduceByKey(_ + _)
      .map(r=>(r._1._1,r._1._2,r._2))
      .collect()

    patientVisit


  }

  // this funcction filter premet rdd on criteria where premet count > 50% IPPCount based on patientuid and serviceprovider
  def getQualifingRDD(ippCount:Array[(String,String,Int)] , preMetCount :Array[(String,String,Int)] , PreMetRdd: RDD[CassandraRow]):RDD[CassandraRow]={

    val xc = preMetCount.filter( r => ippCount.exists( z => r._1.equalsIgnoreCase(z._1) && r._2.equalsIgnoreCase(z._2) && (r._3.toDouble > (z._3.toDouble/2)) ))

    PreMetRdd.filter( r => xc.exists(z => z._1.equals(r.getString("patientuid")) && z._2.equals(r.getString("serviceprovideruid")) ))


  }


/*  def isDobAfterStartWithinXMonths(visit: CassandraRow, m:MeasureProperty,month:Int): Boolean = {
    var isExist = false
    try {

      isExist = visit.isNullAt("dob") && isDateBetween(visit.getDateTime("dob"),new DateTime(m.quarterStartDate), new DateTime(m.quarterStartDate).plusMonths(month))

      val argsArray: Array[String] = Array(month.toString)
      measureLogger(visit, m, "isDobAfterStartWithinXMonths", month.toString, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeGreaterOrEqual:" + e.printStackTrace(), "FAIL")
        println(e.getMessage)
        System.exit(0)
      }
    }
    isExist
  }*/


  def isEncounterPerformedAfterDOBWithinXMonths(visit: CassandraRow,m:MeasureProperty, elementName:String,month:Int): Boolean = {
    var isExist = false
    try {

      isExist = visit.isNullAt("dob") && isDateBetween(visit.getDateTime(elementName+"_date"),visit.getDateTime("dob"), visit.getDateTime("dob").plusMonths(month))

      val argsArray: Array[String] = Array(elementName,month.toString)
      measureLogger(visit, m, "isEncounterPerformedAfterDOBWithinXMonths", month.toString, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isEncounterPerformedAfterDOBWithinXMonths:" + e.printStackTrace(), "FAIL")
        println(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }


/*  def isDobBeforeStartWithinXMonths(visit: CassandraRow, m:MeasureProperty, month:Int): Boolean = {
    var isExist = false
    try {

      isExist = visit.isNullAt("dob") && isDateBetween(visit.getDateTime("dob"),new DateTime(m.quarterStartDate).minusMonths(month), new DateTime(m.quarterStartDate))

      val argsArray: Array[String] = Array(month.toString)
      measureLogger(visit, m, "isDobBeforeStartWithinXMonths", month.toString, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeGreaterOrEqual:" + e.printStackTrace(), "FAIL")
        println(e.getMessage)
        System.exit(0)
      }
    }
    isExist
  }*/





  /*def valueStatus(visit: CassandraRow, resultElementName: String, compareFlag: String, value: Double): Boolean = {
    val elementValue = visit.getDouble(resultElementName)
    val status: Boolean = compareFlag match {
      case "ge" => elementValue >= value
      case "gt" => elementValue > value
      case "lt" => elementValue < value
      case "le" => elementValue <= value
      case "eq" => elementValue == value
    }
    status
  }*/

  def checkElementInDateRange(visit: CassandraRow, m: MeasureProperty, elementName:String,month: Int,afterFlag:Boolean): Boolean = {

    if(afterFlag)
      isDateBetween(visit.getDateTime(elementName),m.quarterStartDate,m.quarterStartDate.plusMonths(month))
     // dateStatus(visit.getDateTime(elementName),new DateTime(m.quarterStartDate).plusMonths(month) ,"le")
    else
      isDateBetween(visit.getDateTime(elementName),m.quarterStartDate.minusMonths(month),m.quarterStartDate)
      //dateStatus(visit.getDateTime(elementName),new DateTime(m.quarterStartDate).minusMonths(month) ,"ge")

  }

  def dateStatus(comparisonDate:DateTime,date:DateTime ,flag: String): Boolean = {

    val status: Boolean = flag match {
      case CompareOperator.GREATER_EQUAL => comparisonDate.isAfter(date) || comparisonDate.isEqual(date)
      case CompareOperator.GREATER => comparisonDate.isAfter(date)
      case CompareOperator.LESS => comparisonDate.isBefore(date)
      case CompareOperator.LESS_EQUAL => comparisonDate.isBefore(date) || comparisonDate.isEqual(date)
      case CompareOperator.EQUAL => comparisonDate.isEqual(date)
    }
    status
  }

/*
  /**
    * This function verifies if the age of the patient is equal to the provided age interval.
    * @param r              current visit of the patient.
    * @param measureProperty measure property of the measure.
    * @param compareInterval   no of interval to be compared.
    * @param unit in (YEAR,MONTH,DAY)
    * @return returns true if the age of the patient is equal to the provided age interval else returns false
    */
  def isAgeEqual(r: CassandraRow, measureProperty: MeasureProperty,compareInterval: Int = 18,unit:String): Boolean = {
    var isExist = false
    try {
      val start_Date = returnDate(r, "dob")
      val end_Date = returnDate(r, "encounterdate")
      var ageDiff: Int = 0
      if (start_Date._1 != null && end_Date._1 != null) {
        ageDiff =   unit match {
          case CalenderUnit.YEAR => Years.yearsBetween(start_Date._1, end_Date._1).getYears
          case CalenderUnit.MONTH => Months.monthsBetween(start_Date._1, end_Date._1).getMonths
          case CalenderUnit.DAY=> Days.daysBetween(start_Date._1, end_Date._1).getDays
          case CalenderUnit.WEEK=> Weeks.weeksBetween(start_Date._1, end_Date._1).getWeeks
        }
        isExist = (ageDiff == compareInterval)
      }

      //val argsArray: Array[String] = Array(start_Date._2, end_Date._2, compareYears.toString)
      // measureLogger(r, measureProperty, "isAgeEqual", "dob", isExist, argsArray)

    }
    catch {
      case e: Exception => {
        println("ERROR::::"+e.printStackTrace)
        // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeEqual:" + e.printStackTrace(), "FAIL")
      }
    }
    isExist;
  }
*/


  /**
    * This function verifies if the age of the patient is equal to the provided age interval on start of measurement period
    * @param r current patient visit
    * @param m measure property
    * @param compareInterval compare intervals
    * @param unit in (YEAR,MONTH,DAY)
    * @return returns true if  the age of the patient is equal to the provided age interval  on start of measurement period else returns false
    */
  def isAgeEqualBeforeEnd(r: CassandraRow, m: MeasureProperty,compareInterval: Int = 18,unit:String): Boolean ={
    var isExist = false
    try {
      val start_Date = (r.getDateTime(AdminElements.Date_of_Birth), convertDateToDDMMYYYY(r.getDateTime(AdminElements.Date_of_Birth).toString))
      val end_Date = (m.quarterStartDate, convertDateToDDMMYYYY(m.quarterStartDate.toString))
      var ageDiff: Int = 0
      if (start_Date._1 != null && end_Date._1 != null) {
        ageDiff =   unit match {
          case CalenderUnit.YEAR => Years.yearsBetween(start_Date._1, end_Date._1).getYears
          case CalenderUnit.MONTH => Months.monthsBetween(start_Date._1, end_Date._1).getMonths
          case CalenderUnit.DAY=> Days.daysBetween(start_Date._1, end_Date._1).getDays
          case CalenderUnit.WEEK => Weeks.weeksBetween(start_Date._1, end_Date._1).getWeeks
        }
        isExist = (ageDiff == compareInterval)
      }

      val argsArray: Array[String] = Array(start_Date._2, end_Date._2, compareInterval.toString)
      measureLogger(r, m, "isAgeEqualBeforeEnd", "dob", isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //println("ERROR::::"+e.printStackTrace)
        // postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeEqualBeforeEnd:" + e.printStackTrace(), "FAIL")

        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist;
  }

  /**
    * This function verifies dob of the patient is above or below according to the required condition.
    * @param visit current visit of the patient
    * @param m measure property of the measure
    * @param startDate start date to that dob of the patient is compared and it has to be in the format (yyyy-MM-dd)
    * @param endDate  end date to that dob of the patient is compared and it has to be in the format (yyyy-MM-dd)
    * @return
    */
  def isDobAboveOrBelow(visit:CassandraRow,m:MeasureProperty,startDate:String,endDate:String):Boolean={
    val sDate =new DateTime(SIMPLE_DATE_FORMAT.parse(startDate))
    val eDate= new DateTime(SIMPLE_DATE_FORMAT.parse(endDate))
    var isExist = false
    try {
      isExist =  isDateBetween(visit.getDateTime("dob"),sDate, eDate)
      val argsArray: Array[String] = Array("dob",startDate,endDate)
      measureLogger(visit, m, "isDobAboveOrBelow", "dob", isExist, argsArray)
    }
    catch {
      case e: Exception => {
        println(e.getMessage)
       // System.exit(0)
      }
    }
    isExist
  }

  /**
    * PARENT Function
    *
    * @param elementValue CurrentElement Value
    * @param flag  Flage based on requirement ge,gt,lt,le,eq
    * @param compareValue check range value
    * @return it return based on value range
    */

  def compareValueStatus(elementValue: Double, flag: String, compareValue: Double): Boolean = {
    //var elementValue = visit.getDouble("elementvalue")
    var status: Boolean = flag match {
      case CompareOperator.GREATER_EQUAL => elementValue >= compareValue
      case CompareOperator.GREATER => elementValue > compareValue
      case CompareOperator.LESS => elementValue < compareValue
      case CompareOperator.LESS_EQUAL => elementValue <= compareValue
      case CompareOperator.EQUAL => elementValue == compareValue
    }
    status
  }


  /**
    * PARENT Function
    *
    * @param elementValue CurrentElement Value
    * @param flag  Flage based on requirement ge,gt,lt,le,eq
    * @param compareValue1 check range value for value one
    * @param compareValue2 check range value for value 2
    * @return it return based on value range
    */

  def compareTwoValueStatus(elementValue: Double, flag: String, compareValue1: Double,compareValue2: Double): Boolean = {
    //var elementValue = visit.getDouble("elementvalue")
    var status: Boolean = flag match {
      case CompareOperator.GREATER_EQUAL_And_LESS_EQUAL => elementValue >= compareValue1 && elementValue <= compareValue1
      case CompareOperator.GREATER_EQUAL_And_LESS => elementValue >= compareValue1 &&  elementValue < compareValue1
      case CompareOperator.GREATER_And_LESS_EQUAL => elementValue > compareValue1 && elementValue <= compareValue1
      case CompareOperator.GREATER_And_LESS => elementValue > compareValue1 && elementValue < compareValue1
      case CompareOperator.EQUAL => elementValue == compareValue1 && elementValue == compareValue1

    }
    status
  }


  def compareTimeOperator(compareDate:DateTime,lowerDate:DateTime,higherDate:DateTime,timeOperator:String):Boolean={

    timeOperator match {
      case CompareOperator.GREATER => dateStatus(compareDate,lowerDate,CompareOperator.GREATER)
      case CompareOperator.LESS=> checkDateInDateRange(compareDate,lowerDate,higherDate,CompareOperator.GREATER_EQUAL,CompareOperator.LESS)
      case CompareOperator.LESS_EQUAL=> checkDateInDateRange(compareDate,lowerDate,higherDate,CompareOperator.GREATER_EQUAL,CompareOperator.LESS_EQUAL)
      case CompareOperator.GREATER_EQUAL=> dateStatus(compareDate,lowerDate,CompareOperator.GREATER_EQUAL)
      case CompareOperator.EQUAL=> dateStatus(compareDate,lowerDate,CompareOperator.EQUAL)
      case TimeOperator.AFTERorEQUAL => dateStatus(compareDate,higherDate,CompareOperator.GREATER_EQUAL)
      case TimeOperator.BEFOREorEQUAL=> dateStatus(compareDate,higherDate,CompareOperator.LESS_EQUAL)
      case TimeOperator.BEFORE=> dateStatus(compareDate,lowerDate,CompareOperator.LESS)
    }
  }


  def checkDateInDateRange( comparisonDate:DateTime,lowerDate:DateTime,higherDate:DateTime,lowerFlag:String,higherFlag:String): Boolean = {
    dateStatus(comparisonDate,lowerDate ,lowerFlag) && dateStatus(comparisonDate,higherDate ,higherFlag)
  }


  def dataTypeOperator(comparisonDate:DateTime, compereDate:DateTime, flag: String): Boolean = {

    val status: Boolean = flag match {
      case "AFTERorEQUAL" => comparisonDate.isAfter(compereDate) || comparisonDate.isEqual(compereDate)
      case "AFTER" => comparisonDate.isAfter(compereDate)
      case "Before" => comparisonDate.isBefore(compereDate)
      case "BEFOREorEQUAL" => comparisonDate.isBefore(compereDate) || comparisonDate.isEqual(compereDate)
      case "EQUAL" => comparisonDate.isEqual(compereDate)
    }
    status
  }


  def getDatesDifferenceInXUnit(lowerElementDate: DateTime, higherElementDate: DateTime, unit: String): Double = {

    val lowerDate: Double = unit match {
      case "MINUTE" => Minutes.minutesBetween(lowerElementDate, higherElementDate).getMinutes
      case "HOUR" => Hours.hoursBetween(lowerElementDate, higherElementDate).getHours
      case "DAY" => Days.daysBetween(lowerElementDate, higherElementDate).getDays
      case "WEEK" => Weeks.weeksBetween(lowerElementDate, higherElementDate).getWeeks
      case "MONTH" => Months.monthsBetween(lowerElementDate, higherElementDate).getMonths
      case "YEAR" => Years.yearsBetween(lowerElementDate, higherElementDate).getYears

    }

    lowerDate

  }

  def lowerCalenderDate(elementDate: DateTime, unit: String, interval: Int): DateTime = {
    //val elementdate= if (elementDate.equalsIgnoreCase("encounterdate")) "encounterdate" else elementDate
    val lowerDate:DateTime= unit match {
      case CalenderUnit.MINUTE => elementDate.minusMinutes(interval)
      case CalenderUnit.HOUR => elementDate.minusHours(interval)
      case CalenderUnit.DAY =>elementDate.minusDays(interval)
      case CalenderUnit.WEEK => elementDate.minusWeeks(interval)
      case CalenderUnit.MONTH => elementDate.minusMonths(interval)
      case CalenderUnit.YEAR => elementDate.minusYears(interval)

    }

    lowerDate
  }

  def higherCalenderDate(elementDate: DateTime, unit: String, interval: Int): DateTime = {

    //val elementdate= if (elementDate.equalsIgnoreCase("encounterdate")) "encounterdate" else elementDate
    val higherDate:DateTime= unit match {
      case CalenderUnit.MINUTE => elementDate.plusMinutes(interval)
      case CalenderUnit.HOUR => elementDate.plusHours(interval)
      case CalenderUnit.DAY =>elementDate.plusDays(interval)
      case CalenderUnit.WEEK => elementDate.plusWeeks(interval)
      case CalenderUnit.MONTH => elementDate.plusMonths(interval)
      case CalenderUnit.YEAR => elementDate.plusYears(interval)
    }

    higherDate
  }

 /* /**
    *
    * @param visit current patient visit
    * @param m measure utility
    * @param EncounterElementforBP encounter element for  bp
    * @param PhyicalExamElement physical exam element for result
    * @param flag flag for status Gt,Lt etc
    * @param compareValue compare value between two status
    * @return if physical exam performed on encounter
    */

  def wasPhysicalExamPerformedWithResult(visit: CassandraRow, m: MeasureProperty, EncounterElementforBP: String,PhyicalExamElement: Double,flag:String,compareValue: Double):Boolean={
    (
    checkElementPresent(visit, m, EncounterElementforBP)

    &&
    compareValueStatus(PhyicalExamElement, flag: String, compareValue: Double)
      )

  }*/

  def checkAgeStatus(currentvisit :CassandraRow,hsitoryVisit:CassandraRow,flag:String,compareYears:Int):Boolean={
    var isExist = flag match {
      case CompareOperator.GREATER_EQUAL => Years.yearsBetween(currentvisit.getDateTime("dob"), hsitoryVisit.getDateTime("element_date")).getYears >= compareYears
      case CompareOperator.LESS_EQUAL => Years.yearsBetween(currentvisit.getDateTime("dob"), hsitoryVisit.getDateTime("element_date")).getYears <= compareYears
      case CompareOperator.GREATER => Years.yearsBetween(currentvisit.getDateTime("dob"), hsitoryVisit.getDateTime("element_date")).getYears > compareYears
      case CompareOperator.LESS => Years.yearsBetween(currentvisit.getDateTime("dob"), hsitoryVisit.getDateTime("element_date")).getYears < compareYears
      case CompareOperator.EQUAL => Years.yearsBetween(currentvisit.getDateTime("dob"), hsitoryVisit.getDateTime("element_date")).getYears == compareYears
    }
    isExist
  }

  /**
    * This function verifies if the patient's age is between two range
    * @param r current patient visit
    * @param m measure property
    * @param lowerAge lower age
    * @param lowerAgeCompareFlag valid lower age flags CompareOperator.{GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL}
    * @param upperAge upper age
    * @param upperAgeCompareFlag valid upper age flag CompareOperator.{GREATER,LESS,GREATER_EQUAL,LESS_EQUAL,EQUAL}
    * @return returns true if if the patient's age is between two range else returns false
    */
  def isAgeBetweenBeforeStart(r: CassandraRow, m:MeasureProperty,lowerAge: Double,lowerAgeCompareFlag:String, upperAge: Double,upperAgeCompareFlag:String): Boolean = {
    var isExist = false
    try {

      val start_Date = r.getDateTime("dob")
      val end_Date =  m.quarterStartDate
      val ageDiffYears = Years.yearsBetween(start_Date, end_Date).getYears

      isExist = !r.isNullAt("dob")  && (compareValueStatus(ageDiffYears,lowerAgeCompareFlag,lowerAge) && compareValueStatus(ageDiffYears,upperAgeCompareFlag,upperAge))
      val argsArray: Array[String] = Array(start_Date.toString, end_Date.toString(), lowerAge.toString, upperAge.toString)
      measureLogger(r, m, "isAgeBetweenBeforeStart", start_Date.toString, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //  postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeBetweenBeforeStart:" + e.printStackTrace(), "FAIL")
        loggerObj.error(e.getMessage)
        //System.exit(0)
      }
    }
    isExist
  }



  /**
    *
    * @param visit current row
    * @param m measure property
    * @param lowerAge lower age of the range
    * @param lowerAgeCompareFlag comparator flag
    * @param upperAge upper age of the range
    * @param upperAgeCompareFlag comparator flag
    * @param ageOnDate valid ageOnDate are AdminElements.Encounter_Date, any elemnt's date (Elementmaster.ElementXDate); default value = m.quarterStartdate
    * @return returns true if age is within passed range on ageOnDate parameter
    */
  def isAgeBetween(visit: CassandraRow, m:MeasureProperty,lowerAge: Double,lowerAgeCompareFlag:String, upperAge: Double,upperAgeCompareFlag:String, ageOnDate: String = "m.quarterStartDate"): Boolean = {
    var isExist = false
    try {

      val endDate = ageOnDate  match {

        case AdminElements.Encounter_Date =>  visit.getDateTime(AdminElements.Encounter_Date)
        case "m.quarterStartDate" => m.quarterStartDate
        case _ => visit.getDateTime(ageOnDate+"_date")
      }

      isExist = !visit.isNullAt(AdminElements.Date_of_Birth) &&
        (
          compareValueStatus(Years.yearsBetween(visit.getDateTime(AdminElements.Date_of_Birth), endDate).getYears,lowerAgeCompareFlag,lowerAge)
            && compareValueStatus(Years.yearsBetween(visit.getDateTime(AdminElements.Date_of_Birth), endDate).getYears,upperAgeCompareFlag,upperAge)
          )


      val argsArray: Array[String] = Array(ageOnDate.toString, lowerAge.toString, upperAge.toString)
      measureLogger(visit, m, "isAgeBetween", ageOnDate.toString, isExist, argsArray)

    }
    catch {
      case e: Exception => {
        //postgresUtilityObj.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", "Function Exception:isAgeBetween:" + e.printStackTrace(), "FAIL")

        loggerObj.error(e.getMessage)
       // System.exit(0)
      }
    }
    isExist
  }















}