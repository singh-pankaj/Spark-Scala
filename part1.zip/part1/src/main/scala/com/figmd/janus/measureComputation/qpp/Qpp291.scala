package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP23Elements, QPP291Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 111
* Measure Title              :- Perioperative Care: Venous Thromboembolism (VTE) Prophylaxis (When Indicated in ALL Patients)
* Measure Description        :- Percentage of surgical patients aged 18 years and older undergoing procedures for which venous thromboembolism (VTE) prophylaxis is indicated in all patients, who had an order for Low Molecular Weight Heparin(LMWH), Low- Dose Unfractionated Heparin(LDUH), adjusted-dose warfarin, fondaparinux or mechanical prophylaxis to be given within 24 hours prior to incision time or within 24 hours after surgery end time.
* Calculation Implementation :-
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp291 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp291"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP

    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //getPatientHistoryList
      val patientHistoryList = getPatientHistory(sparkSession, ippRDD,
        QPP291Elements.Cognitive_Impairment_Dysfunction_Assessment,
        QPP291Elements.Screening_Tool_For_Cognitive_Assessment,
        QPP291Elements.Referral_To_Neuropsychologist,
        QPP291Elements.Cognitive_Impairment_Or_Dysfunction_Assessment_Rsnns).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      //    metRDD.cache()

      // Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()
      //


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, denominatorRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isDiagnosedOnEncounter(visit, m, QPP291Elements.Parkinson_s_Disease)
        &&
        isVisitTypeIn(visit, m, QPP291Elements.Inpatient_Consultation,
          QPP291Elements.Discharge_Services___Hospital_Inpatient,
          QPP291Elements.Subsequent_Hospital_Care,
          QPP291Elements.Hospital_Inpatient_Visit___Initial,
          QPP291Elements.Office_Visit,
          QPP291Elements.Nursing_Facility_Visit
        )
        && !isVisitTypeIn(visit, m, QPP291Elements.Pos_02)
        && !isVisitTypeIn(visit, m, QPP291Elements.Inpatient_Consultation_Telehealth_Modifier,
        QPP291Elements.Discharge_Services___Hospital_Inpatient_Telehealth_Modifier,
        QPP291Elements.Subsequent_Hospital_Care_Telehealth_Modifier,
        QPP291Elements.Hospital_Inpatient_Visit___Initial_Telehealth_Modifier,
        QPP291Elements.Office_Visit_Telehealth_Modifier,
        QPP291Elements.Nursing_Facility_Visit_Telehealth_Modifier
      )
    )
  }

  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        (wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP291Elements.Cognitive_Impairment_Or_Dysfunction_Assessment, 12, patientHistoryBroadcastList)
          ||
          wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP291Elements.Screening_Tool_For_Cognitive_Assessment, 12, patientHistoryBroadcastList)
          ||
          wasCommunicationDoneFromProviderToPatientBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP291Elements.Screening_Tool_For_Cognitive_Assessment, 12, patientHistoryBroadcastList)
          )
          && !wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP291Elements.Cognitive_Impairment_Or_Dysfunction_Assessment_Rsnns, 12, patientHistoryBroadcastList)
        )
    )
  }

}

