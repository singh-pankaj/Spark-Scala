package com.figmd.measures.test.measure

import com.datastax.spark.connector.{CassandraRow, toNamedColumnRef}
import com.figmd.janus.WebDataMartCreator
import com.figmd.janus.WebDataMartCreator.prop
import com.figmd.janus.util.application.{CassandraUtility, FileUtility, SparkUtility}
import com.figmd.janus.util.measure.MeasureUtility
import org.apache.spark.rdd.RDD
import org.scalatest.{BeforeAndAfter, FunSuite, Ignore}

class Measure_TestUtility extends FunSuite with BeforeAndAfter with Serializable {

  WebDataMartCreator.debugMode = 2
  val MEASURE_NAME = "Qpp130"
  val keyspaceName = "test_data"
  val patientHistoryTableName = "patient_history_qpp130"
  val tblEncounterName = "tblencounter_qpp130"
  val wfType = "MIPS"
  val qppMeasureList = "M130"
  val nonqppMeasureList = "NA"
  val equalMeasureList = "NA"
  val cmsMeasureList = "NA"
  val measureComputationOutputPath = "file:///tmp/Test/"
  val logFile = "/tmp/CMS/logger"
  val mu = new MeasureUtility()

  WebDataMartCreator.main(Array(keyspaceName, patientHistoryTableName, tblEncounterName, wfType, qppMeasureList, equalMeasureList, cmsMeasureList, nonqppMeasureList, measureComputationOutputPath, logFile))
  val spark = new SparkUtility().getSparkContext()
  val path = prop.getProperty("measure_computation_output_path") + "/" + prop.getProperty("wfType") + "/" + MEASURE_NAME + "/" + prop.getProperty("quarterEndDate")
  var inputCassandraRDD: RDD[CassandraRow] = spark.sparkContext.emptyRDD[CassandraRow]
  var eligibleRDD = spark.sparkContext.emptyRDD[String]
  var expectedIPPRDD = spark.sparkContext.emptyRDD[CassandraRow]
  var expectedEligibleRDD = spark.sparkContext.emptyRDD[CassandraRow]
  var expectedExclusionRDD = spark.sparkContext.emptyRDD[CassandraRow]
  var expectedExceptionRDD = spark.sparkContext.emptyRDD[CassandraRow]
  var expectedMetRDD = spark.sparkContext.emptyRDD[CassandraRow]
  var measureId = ""


  before {
    if (!nonqppMeasureList.equalsIgnoreCase("NA"))
      measureId = nonqppMeasureList
    else if (!qppMeasureList.equalsIgnoreCase("NA"))
      measureId = qppMeasureList
    else if (!equalMeasureList.equalsIgnoreCase("NA"))
      measureId = equalMeasureList
    else
      measureId = cmsMeasureList
    val cols = new FileUtility().getProperty(s"measure.$measureId.element.select").split(",").map(field => toNamedColumnRef(field))
    inputCassandraRDD = new CassandraUtility().getCassandraRDD(spark,prop.getProperty("keyspace_datamart"), prop.getProperty("keyspace_datamart_table_name")).select(cols: _*)
  }

  test("itShouldValidateCorrectIPP") {
    var ippRDD = spark.sparkContext.emptyRDD[String]
    if (mu.hdfsConf.exists(new org.apache.hadoop.fs.Path(path + "/ipp")))
      ippRDD = spark.sparkContext.textFile(path + "/ipp").cache()
    val ippRDDCount = ippRDD.count()
    val ippFilterList: Array[String] = Array("IPP Eligible", "Exclusion Eligible", "Numerator Eligible", "Exception Eligible", "Not Met").map(x => x.toLowerCase)
    expectedIPPRDD = inputCassandraRDD.filter(r => ippFilterList.contains(r.getString("performance").toLowerCase)).cache()
    var newExpectedIPPRDD = spark.sparkContext.emptyRDD[String]
    if (!expectedIPPRDD.isEmpty()) {
      newExpectedIPPRDD = expectedIPPRDD.map(l => l.toString())
    }
    val expectedMetRDDCount = expectedIPPRDD.count()
    val misMatchRDD = getMisMatchRecords(ippRDD, newExpectedIPPRDD).cache()

    var assertResult = true
    if (!misMatchRDD.isEmpty()) {
      assertResult = false
    }
    println("Ipp Count :: " + ippRDDCount + " Expected Count :: " + expectedMetRDDCount + " Mismatching Count :: " + misMatchRDD.count())
    if (!assertResult) {
      printMisMatchRecords("IPP", expectedIPPRDD, misMatchRDD)
    }
    misMatchRDD.unpersist()

    assert(assertResult)
  }


  test("itShouldValidateCorrectEligible") {

    if (mu.hdfsConf.exists(new org.apache.hadoop.fs.Path(path + "/noteligible")))
      eligibleRDD = spark.sparkContext.textFile(path + "/noteligible").cache()
    val eligibleRDDCount = eligibleRDD.count()
    val eligiblePresent = !eligibleRDD.filter(r => r.contains("Denominator Eligible")).isEmpty()
    val eligibleFilterList: Array[String] = (eligiblePresent match {
      case true => Array("Denominator Eligible", "Exclusion Eligible", "Numerator Eligible", "Exception Eligible", "Not Met")
      case false => Array("IPP Eligible", "Exclusion Eligible", "Numerator Eligible", "Exception Eligible", "Not Met")
    }).map(x => x.toLowerCase)

    expectedEligibleRDD = inputCassandraRDD.filter(r => eligibleFilterList.contains(r.getString("performance").toLowerCase)).cache()
    var newEligibleRDD = spark.sparkContext.emptyRDD[String]
    if (!expectedEligibleRDD.isEmpty()) {
      newEligibleRDD = expectedEligibleRDD.map(l => l.toString())
    }
    val expectedEligibleRDDCount = expectedEligibleRDD.count()
    val misMatchRDD = getMisMatchRecords(eligibleRDD, newEligibleRDD).cache()
    var assertResult = true
    if (!misMatchRDD.isEmpty()) {
      assertResult = false
    }
    println("Eligible Count :: " + eligibleRDDCount + " Expected Count :: " + expectedEligibleRDDCount + " Mismatching Count :: " + misMatchRDD.count())
    if (!assertResult) {
      printMisMatchRecords("Eligible", expectedEligibleRDD, misMatchRDD)
    }
    misMatchRDD.unpersist()

    assert(assertResult)
  }

  test("itShouldValidateCorrectExclusion") {

    var exclusionRDD = spark.sparkContext.emptyRDD[String]
    if (mu.hdfsConf.exists(new org.apache.hadoop.fs.Path(path + "/exclusion")))
      exclusionRDD = spark.sparkContext.textFile(path + "/exclusion").cache()
    val exclusionRDDCount = exclusionRDD.count()
    expectedExclusionRDD = inputCassandraRDD.filter(r => r.getString("performance").equalsIgnoreCase("Exclusion Eligible")).cache()
    var newExclusionRDD = spark.sparkContext.emptyRDD[String]
    if (!expectedExclusionRDD.isEmpty()) {
      newExclusionRDD = expectedExclusionRDD.map(l => l.toString())
    }
    val expectedExclusionRDDCount = expectedExclusionRDD.count()
    val misMatchRDD = getMisMatchRecords(exclusionRDD, newExclusionRDD).cache()
    var assertResult = true
    if (!misMatchRDD.isEmpty()) {
      assertResult = false
    }

    println("Exclusion Count :: " + exclusionRDDCount + " Expected Count :: " + expectedExclusionRDDCount + " Mismatching Count :: " + misMatchRDD.count())

    if (!assertResult) {
      printMisMatchRecords("Exclusion", expectedExclusionRDD, misMatchRDD)
    }
    misMatchRDD.unpersist()
    assert(assertResult)
  }

  test("itShouldValidateCorrectMet") {

    var metRDD = spark.sparkContext.emptyRDD[String]
    if (mu.hdfsConf.exists(new org.apache.hadoop.fs.Path(path + "/met")))
      metRDD = spark.sparkContext.textFile(path + "/met").cache()

    val metRDDCount = metRDD.count()
    val metFilterList: Array[String] = Array("Numerator Eligible").map(x => x.toLowerCase)
    expectedMetRDD = inputCassandraRDD.filter(r => metFilterList.contains(r.getString("performance").toLowerCase)).cache()
    var newExpectedMetRDD = spark.sparkContext.emptyRDD[String]
    if (!expectedMetRDD.isEmpty()) {
      newExpectedMetRDD = expectedMetRDD.map(l => l.toString())
    }
    val expectedMetRDDCount = expectedMetRDD.count()
    val misMatchRDD = getMisMatchRecords(metRDD, newExpectedMetRDD).cache()
    var assertResult = true
    if (!misMatchRDD.isEmpty()) {
      assertResult = false
    }
    println("Met Count :: " + metRDDCount + " Expected Count :: " + expectedMetRDDCount + " Mismatching Count :: " + misMatchRDD.count())
    if (!assertResult) {
      printMisMatchRecords("Met", expectedMetRDD, misMatchRDD)
    }
    misMatchRDD.unpersist()
    assert(assertResult)
  }


  test("itShouldValidateCorrectException") {

    var exceptionRDD = spark.sparkContext.emptyRDD[String]
    if (mu.hdfsConf.exists(new org.apache.hadoop.fs.Path(path + "/exception")))
      exceptionRDD = spark.sparkContext.textFile(path + "/exception").cache()
    val exceptionRDDCount = exceptionRDD.count()
    val exceptionFilterList: Array[String] = Array("Exception Eligible").map(x => x.toLowerCase)
    expectedExceptionRDD = inputCassandraRDD.filter(r => exceptionFilterList.contains(r.getString("performance").toLowerCase)).cache()
    var newExpectedExceptionRDD = spark.sparkContext.emptyRDD[String]
    if (!expectedExceptionRDD.isEmpty()) {
      newExpectedExceptionRDD = expectedExceptionRDD.map(l => l.toString())
    }
    val expectedExceptionRDDCount = expectedExceptionRDD.count()
    val misMatchRDD = getMisMatchRecords(exceptionRDD, newExpectedExceptionRDD).cache()
    var assertResult = true
    if (!misMatchRDD.isEmpty()) {
      assertResult = false
    }

    println("Exception Count :: " + exceptionRDDCount + " Expected Count :: " + expectedExceptionRDDCount + " Mismatching Count :: " + misMatchRDD.count())
    if (!assertResult) {
      printMisMatchRecords("Exception", expectedExceptionRDD, misMatchRDD)

    }

    misMatchRDD.unpersist()
    assert(assertResult)
  }


  test("itShouldValidateCorrectNotMet") {

    var notMetRDD = spark.sparkContext.emptyRDD[String]

    if (mu.hdfsConf.exists(new org.apache.hadoop.fs.Path(path + "/notmet")))
      notMetRDD = spark.sparkContext.textFile(path + "/notmet").cache()

    val notMetRDDCount = notMetRDD.count()
    val eligiblePresent = !eligibleRDD.filter(r => r.contains("Denominator Eligible")).isEmpty()
    val unionRDD = expectedExclusionRDD.union(expectedMetRDD).union(expectedExceptionRDD)
    val expectedNotMetRDD: RDD[CassandraRow] = (eligiblePresent match {
      case true => expectedEligibleRDD.subtract(unionRDD)
      case false => expectedIPPRDD.subtract(unionRDD)
    }).cache()

    var newNotMetRDD = spark.sparkContext.emptyRDD[String]
    if (!expectedNotMetRDD.isEmpty()) {
      newNotMetRDD = expectedNotMetRDD.map(l => l.toString())
    }
    val expectedNotMetRDDCount = expectedNotMetRDD.count()
    val misMatchRDD = getMisMatchRecords(notMetRDD, newNotMetRDD).cache()
    var assertResult = true
    if (!misMatchRDD.isEmpty()) {
      assertResult = false
    }

    println("Not Met Count :: " + notMetRDDCount + " Expected Count :: " + expectedNotMetRDDCount + " Mismatching Count :: " + misMatchRDD.count())
    if (!assertResult) {
      printMisMatchRecords("Not Met", expectedNotMetRDD, misMatchRDD)
    }

    misMatchRDD.unpersist()
    assert(assertResult)
  }


  def getMisMatchRecords(rdd1: RDD[String], rdd2: RDD[String]): RDD[String] = {
    if (rdd1.subtract(rdd2).count() > 0) rdd1.subtract(rdd2) else rdd2.subtract(rdd1)
  }

  def printMisMatchRecords(recordType: String, expectedRDD: RDD[CassandraRow], misMatchRDD: RDD[String]): Unit = {
    println(s"***** Expected $recordType Records *****")
    expectedRDD.foreach(r => println(r.getString("visituid")))
    println(s"***** $recordType mismatch records *****")
    misMatchRDD.foreach(r => println(r.split("visituid: ")(1).split(",")(0)))
  }

}