package com.figmd.measures.test.functions

import java.text.SimpleDateFormat
import java.time.LocalDate

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.WebDataMartCreator.prop
import com.figmd.janus.measureComputation.master.{ MeasureProperty}
import com.figmd.janus.util.application.SparkUtility
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import com.figmd.measures.test.utils.TestUtil
import com.figmd.measures.test.utils.TestUtil._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.joda.time.DateTime
import org.scalatest.FunSuite
import org.scalatest.{Matchers, _}

class HistoryLookUpUtility_Test extends FunSuite with Matchers {

  val sdf=new SimpleDateFormat("yyyy-MM-dd")
  val m = MeasureProperty("ABC", "XYZ",new DateTime(sdf.parse("2018-01-01")),new DateTime(sdf.parse("2018-12-31")))
  prop.setProperty("quarterStartDate", "2018-01-01")
  prop.setProperty("quarterEndDate", "2018-12-31")
  val mu: MeasureUtilityUpdate = new MeasureUtilityUpdate()
  val hu = new HistoryLookUpUtility()
  val historyLookUp = new HistoryLookUpUtility()



  //  WebDataMartCreator.prop.setProperty("quarterStartDate", "01-01-2018")
  //  WebDataMartCreator.prop.setProperty("quarterEndDate", "01-06-2018")

  test("ItShouldReturnTrue_isAssessmentLessThanValue") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-03-01 00:00:00.00", "elementvalue" -> "10"))
    ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-03-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))

    assert(historyLookUp.isAssessmentBeforeValue(visit1, m, 11, "mere", patientHistory) == true)
  }

  test("ItShouldReturnFalse_isAssessmentLessThanValue") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-03-01 00:00:00.00", "elementvalue" -> "11")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "mere", "element_date" -> "2018-03-02 00:00:00.00", "elementvalue" -> "12"))))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-03-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))

    assert(historyLookUp.isAssessmentBeforeValue(visit1, m, 11, "mere", patientHistory) == false)
  }

  test("ItShouldReturnTrue_wasDiagnosedWith") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-03-04 00:00:00.00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "mere", "element_date" -> "2018-03-03 00:00:00.00", "elementvalue" -> "10")) ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-03-03 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))

    assert(historyLookUp.wasDiagnosedWith(visit1, m, "mere", patientHistory) == true)
  }

  test("ItShouldReturnFalse_wasDiagnosedWith") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "meretest", "element_date" -> "2018-03-04 00:00:00.00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "meretest", "element_date" -> "2018-03-03 00:00:00.00", "elementvalue" -> "10"))))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-03-03 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    assert(historyLookUp.wasDiagnosedWith(visit1, m, "mere", patientHistory) == false)
  }

  test("ItShouldReturnTrue_isAssessmentBeforeValue") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-03-01 00:00:00.00", "elementvalue" -> "10")) ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-03-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    
    assert(historyLookUp.isAssessmentBeforeValue(visit1, m, 11, "mere", patientHistory) == true)
  }

  test("ItShouldReturnFalse_isAssessmentBeforeValue") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-03-01 00:00:00.00", "elementvalue" -> "11")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "mere", "element_date" -> "2018-03-02 00:00:00.00", "elementvalue" -> "12"))  ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-03-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))

    assert(historyLookUp.isAssessmentBeforeValue(visit1, m, 11, "mere", patientHistory) == false)
  }

  test("ItShouldReturnTrue_isAssessmentAfterValue") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-01 00:00:00.00", "elementvalue" -> "15")) ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-02-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))

    assert(historyLookUp.isAssessmentAfterValue(visit1, m, "mere", 10, patientHistory) == true)

  }

  test("ItShouldReturnFalse_isAssessmentAfterValue") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-01 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2019-02-01 00:00:00.00", "elementvalue" -> "15")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2017-02-01 00:00:00.00", "elementvalue" -> "15"))))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-02-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))

    assert(historyLookUp.isAssessmentAfterValue(visit1, m, "mere", 10, patientHistory) == false)
  }


 /*  test("ItShouldReturnTrue_isLaboratoryTestPerformedAfter") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-01-03 00:00:00.00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "mere", "element_date" -> "2018-03-03 00:00:00.00", "elementvalue" -> "10"))))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-01-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))

    assert(mu.isLaboratoryTestPerformedAfter(visit1, m, "mere", patientHistory) == true)
  }*/

  /*test("ItShouldReturnFalse_isLaboratoryTestPerformedAfter") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "meretest", "element_date" -> "2018-01-03 00:00:00.00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "meretest", "element_date" -> "2018-03-03 00:00:00.00", "elementvalue" -> "10"))))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-01-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))

    assert(mu.isLaboratoryTestPerformedAfter(visit1, m, "mere", patientHistory) == false)
  }*/

  /*test("ItShouldReturnTrue_isRecentLaboratoryTestResultGreaterThanValue") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-01 00:00:00.00", "elementvalue" -> "15"))  ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-02-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))

    assert(historyLookUp.isRecentLaboratoryTestResultGreaterThanValue(visit1, m, 10, "mere", patientHistory) == true)
  }


  test("ItShouldReturnFalse_isRecentLaboratoryTestResultGreaterThanValue") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-01 00:00:00.00", "elementvalue" -> "5")) ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-02-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    val historyLookUp = new HistoryLookUpUtility()

    assert(historyLookUp.isRecentLaboratoryTestResultGreaterThanValue(visit1, m, 10, "mere", patientHistory) == false)
  }
*/
/*  test("ItShouldReturnTrue_wasDignoasisProcedurePerformedXDaysInHistory") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-03-05 00:00:00.00", "elementvalue" -> "15"))    ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-03-06 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    val m = com.figmd.janus.measureComputation.master.MeasureProperty(null, null)
    assert(historyLookUp.wasDignoasisProcedurePerformedXDaysInHistory(visit1, m, "mere_date", "mere", 1, patientHistory) == true)
  }

  test("ItShouldReturnFalse_wasDignoasisProcedurePerformedXDaysInHistory") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-03-06 00:00:00.00", "elementvalue" -> "15")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-03-07 00:00:00.00", "elementvalue" -> "15"))  ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-03-06 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    val historyLookUp = new HistoryLookUpUtility()
    val m = com.figmd.janus.measureComputation.master.MeasureProperty(null, null)
    assert(historyLookUp.wasDignoasisProcedurePerformedXDaysInHistory(visit1, m, "mere_date", "mere", 90, patientHistory) == false)
  }*/

/*  test("ItShouldReturnTrue_isProcedurePerformed92DaysFromEndDate") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-01-01 00:00:00.00", "elementvalue" -> "15"))    ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-01-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    val m = com.figmd.janus.measureComputation.master.MeasureProperty(null, null)
    assert(historyLookUp.isProcedurePerformed92DaysFromEndDate(visit1, m, "mere", patientHistory) == true)
   }

  test("ItShouldReturnFalse_isProcedurePerformed92DaysFromEndDate") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2017-01-01 00:00:00.00", "elementvalue" -> "15"))    ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-01-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    val m = com.figmd.janus.measureComputation.master.MeasureProperty(null, null)
    assert(historyLookUp.isProcedurePerformed92DaysFromEndDate(visit1, m, "mere", patientHistory) == false)
  }*/

/*  test("ItShouldReturnTrue_isPhysicalExamPerformedVisualAcuity") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-01-01 00:00:00.00", "elementvalue" -> "15")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-01-03 00:00:00.00", "elementvalue" -> "15")) ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-01-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-01-02 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    val m = com.figmd.janus.measureComputation.master.MeasureProperty(null, null)
    assert(historyLookUp.isPhysicalExamPerformedVisualAcuity(visit2, m, "mere", "mere_date", patientHistory, 1) == true)
  }

  test("ItShouldReturnFalse_isPhysicalExamPerformedVisualAcuity") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-01-01 00:00:00.00", "elementvalue" -> "15")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-01-03 00:00:00.00", "elementvalue" -> "15")) ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-01-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-01-02 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    val m = com.figmd.janus.measureComputation.master.MeasureProperty(null, null)
    assert(historyLookUp.isPhysicalExamPerformedVisualAcuity(visit2, m, "mere", "mere_date", patientHistory, 1) == true)
  }*/

  test("ItShouldReturnTrue_ElementMostRecentResultInBetweenBeforeOrEqualInMonth") {
    val MostRecentpatientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "ABCDEF", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 145)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "EFGHIJ", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 110)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 90))
    )
    ) //val
     val MostRecentpatienthistoryRDD = TestUtil.spark.sparkContext.broadcast(MostRecentpatientHistoryRDD.collect().toList)
    val visit = CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "ABCDEF" -> "1", "elementdate" -> "2018-05-19 00:00:00.000+00:00"))
    assert(hu.elementMostRecentResultInBetweenBeforeOrEqualInMonth(visit, m, "elementdate", "ABCDEF", 100, 170, 12, MostRecentpatienthistoryRDD) === true)
  }

  test("ItShouldReturnFalse_ElementMostRecentResultInBetweenBeforeOrEqualInMonth") {
    val MostRecentpatientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "ABCDEF", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 175)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "EFGHIJ", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 85)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 90))
    )
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "ABCDEF" -> "1", "elementdate" -> "2018-05-19 00:00:00.000+00:00"))
    val MostRecentpatienthistoryRDD = TestUtil.spark.sparkContext.broadcast(MostRecentpatientHistoryRDD.collect().toList)

    assert(hu.elementMostRecentResultInBetweenBeforeOrEqualInMonth(visit, m, "elementdate", "ABCDEF", 100, 170, 12, MostRecentpatienthistoryRDD) === false)
  }

  test("ItShouldReturnTrue_isDiagnosedWithEqualBeforeEnd") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-01-03 00:00:00.00", "elementvalue" -> "15"))    ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-01-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-01-02 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))

    assert(historyLookUp.checkElementInHistory(visit2, m, "mere", patientHistory) == true)

  }


  test("ItShouldReturnFalse_isDiagnosedWithEqualBeforeEnd1") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "meretest", "element_date" -> "2019-01-03 00:00:00.00", "elementvalue" -> "15"))    ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2019-01-01 00:00:00.00", "ed_visit_arrival" -> "2019-04-01 01:00:00.00", "ed_visit_departure" -> "2019-04-01 03:00:00.00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "mere" -> "1", "mere_date" -> "2018-01-02 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))

    assert(historyLookUp.checkElementInHistory(visit1, m, "mere", patientHistory) == false) //*
  }

  prop.setProperty("quarterStartDate", "2018-01-01")
  prop.setProperty("quarterEndDate", "2018-03-31")


  test("ItShouldReturnTrue_isElementPresentBeforeEncounterDate") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "merea", "element_date" -> "2018-05-01 00:00:00.00"))
    ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "encounterdate" -> "2018-05-03 00:00:00.00"))

    assert(historyLookUp.wasElementPresentBeforeEncounter(visit1, m, "mere", patientHistory) == true)
  }

  test("ItShouldReturnFalse_isElementPresentBeforeEncounterDate") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "merea", "element_date" -> "2018-05-01 00:00:00.00"))
    ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "encounterdate" -> "2018-05-01 00:00:00.00"))
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P3", "encounterdate" -> "2018-04-01 00:00:00.00"))

    assert(historyLookUp.wasElementPresentBeforeEncounter(visit2, m, "mere", patientHistory) == false)
    assert(historyLookUp.wasElementPresentBeforeEncounter(visit3, m, "mere", patientHistory) == false)
  }

  test("ItShouldReturnTrue_isElementPresentBeforeorEqualEncounterDate") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "merea", "element_date" -> "2018-05-01 00:00:00.00"))
    ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "encounterdate" -> "2018-05-03 00:00:00.00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "encounterdate" -> "2018-05-01 00:00:00.00"))

    assert(historyLookUp.isElementPresentBeforeOrEqualEncounter(visit1, m, "mere", patientHistory) == true)
    assert(historyLookUp.isElementPresentBeforeOrEqualEncounter(visit2, m, "mere", patientHistory) == true)
  }

  test("ItShouldReturnFalse_isElementPresentBeforeorEqualEncounterDate") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "merea", "element_date" -> "2018-05-01 00:00:00.00"))
    ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P3", "encounterdate" -> "2018-04-01 00:00:00.00"))

    assert(historyLookUp.isElementPresentBeforeOrEqualEncounter(visit3, m, "mere", patientHistory) == false)
  }

  test("ItShouldReturnTrue_isElementPresentBetweenTwoDate") {
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-04-01 02:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "mere" -> "1", "mere_date" -> "2018-04-01 01:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 04:00:00.00"))
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P3", "mere" -> "1", "mere_date" -> "2018-04-01 03:00:00.00", "ed_visit_arrival" -> "2018-04-01 00:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))

    assert(historyLookUp.isElementPresentBetweenTwoDate(visit1, m, "mere", "ed_visit_arrival", "ed_visit_departure") == true)
    assert(historyLookUp.isElementPresentBetweenTwoDate(visit2, m, "mere", "ed_visit_arrival", "ed_visit_departure") == true)
    assert(historyLookUp.isElementPresentBetweenTwoDate(visit3, m, "mere", "ed_visit_arrival", "ed_visit_departure") == true)
  }

  test("ItShouldReturnFalse_isElementPresentBetweenTwoDate") {
    val visit4 = CassandraRow.fromMap(Map("patientuid" -> "P4", "mere" -> "1", "mere_date" -> "2018-04-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 02:00:00.00"))
    val visit5 = CassandraRow.fromMap(Map("patientuid" -> "P5", "mere" -> "1", "mere_date" -> "2018-04-01 05:00:00.00", "ed_visit_arrival" -> "2018-04-01 00:00:00.00", "ed_visit_departure" -> "2018-04-01 04:00:00.00"))

    assert(historyLookUp.isElementPresentBetweenTwoDate(visit4, m, "mere", "ed_visit_arrival", "ed_visit_departure") == false)
    assert(historyLookUp.isElementPresentBetweenTwoDate(visit5, m, "mere", "ed_visit_arrival", "ed_visit_departure") == false)
  }


  test("ItShouldReturnTrue_isElementPresentBetweenTwoDatesAndResultValueEqual") {

    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "10", "mere_date" -> "2018-04-01 02:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P3", "mere" -> "14", "mere_date" -> "2018-04-01 03:00:00.00", "ed_visit_arrival" -> "2018-04-01 00:00:00.00", "ed_visit_departure" -> "2018-04-01 03:00:00.00"))

    assert(historyLookUp.isElementPresentBetweenTwoDatesAndResultValueEqual(visit1, m, "mere", "ed_visit_arrival", "ed_visit_departure", 10) == true)
    assert(historyLookUp.isElementPresentBetweenTwoDatesAndResultValueEqual(visit3, m, "mere", "ed_visit_arrival", "ed_visit_departure", 14) == true)
  }

  test("ItShouldReturnFalse_isElementPresentBetweenTwoDatesAndResultValueEqual") {

    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "mere" -> "12.3", "mere_date" -> "2018-04-01 01:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 04:00:00.00"))
    val visit4 = CassandraRow.fromMap(Map("patientuid" -> "P4", "mere" -> "16", "mere_date" -> "2018-04-01 00:00:00.00", "ed_visit_arrival" -> "2018-04-01 01:00:00.00", "ed_visit_departure" -> "2018-04-01 02:00:00.00"))
    val visit5 = CassandraRow.fromMap(Map("patientuid" -> "P5", "mere" -> "1", "mere_date" -> "2018-04-01 05:00:00.00", "ed_visit_arrival" -> "2018-04-01 00:00:00.00", "ed_visit_departure" -> "2018-04-01 04:00:00.00"))

    assert(historyLookUp.isElementPresentBetweenTwoDatesAndResultValueEqual(visit2, m, "mere", "ed_visit_arrival", "ed_visit_departure", 12.5) == false)
    assert(historyLookUp.isElementPresentBetweenTwoDatesAndResultValueEqual(visit4, m, "mere", "ed_visit_arrival", "ed_visit_departure", 11) == false)
    assert(historyLookUp.isElementPresentBetweenTwoDatesAndResultValueEqual(visit5, m, "mere", "ed_visit_arrival", "ed_visit_departure", 0) == false)
  }


/*  test("ItShouldReturnTrue_wasprocedureperformedwithin24month") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2016-03-31 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hype", "element_date" -> "2016-03-30 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "mere", "element_date" -> "2016-04-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "mere", "element_date" -> "2018-04-01 00:00:00.00"))
    ))

    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)

    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1"))
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P3", "mere" -> "1"))
    val historyLookUp = new HistoryLookUpUtility()
    val m = MeasureProperty(null, null)
    assert(historyLookUp.wasprocedureperformedwithin24month(visit1, m, "mere", patientHistory) == true)
    assert(historyLookUp.wasprocedureperformedwithin24month(visit3, m, "mere", patientHistory) == true)

    }

  test("ItShouldReturnFalse_wasprocedureperformedwithin24month") {

    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2016-03-31 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hype", "element_date" -> "2016-03-30 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "mere", "element_date" -> "2016-04-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "mere", "element_date" -> "2018-04-01 00:00:00.00"))
    ))

    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)

    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "hype" -> "1"))
    val visit4 = CassandraRow.fromMap(Map("patientuid" -> "P4", "mere" -> "1"))
    val historyLookUp = new HistoryLookUpUtility()
    val m = MeasureProperty(null, null)
    assert(historyLookUp.wasprocedureperformedwithin24month(visit2, m, "hype", patientHistory) == false)
    assert(historyLookUp.wasprocedureperformedwithin24month(visit4, m, "mere", patientHistory) == false)

  }*/

  test("ItShouldReturnTrue_wasPhysicalExamPerformedForRetinalDilatedExam") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "hype", "element_date" -> "2018-02-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "mere", "element_date" -> "2018-01-31 00:00:00.00"))    ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "hype" -> "1", "mere" -> "1"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "hype" -> "1", "mere" -> "1"))
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P3", "hype" -> "1", "mere" -> "1"))
    val historyLookUp = new HistoryLookUpUtility()

    assert(historyLookUp.wasPhysicalExamPerformedForRetinalDilatedExam(visit1, m, "hype", "mere", 2, patientHistory) == true)
    assert(historyLookUp.wasPhysicalExamPerformedForRetinalDilatedExam(visit2, m, "mere", "", 2, patientHistory) == true)
  }

  test("ItShouldReturnFalse_wasPhysicalExamPerformedForRetinalDilatedExam") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "mere", "element_date" -> "2018-01-30 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "mere", "element_date" -> "2018-02-01 00:00:00.00"))   ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P3", "hype" -> "1", "mere" -> "1"))
    val visit4 = CassandraRow.fromMap(Map("patientuid" -> "P4", "hype" -> "1", "mere" -> "1"))
    val historyLookUp = new HistoryLookUpUtility()

    assert(historyLookUp.wasPhysicalExamPerformedForRetinalDilatedExam(visit3, m, "hype", "mere", 2, patientHistory) == false)
    assert(historyLookUp.wasPhysicalExamPerformedForRetinalDilatedExam(visit4, m, "", "", 2, patientHistory) == false)
  }

  test("ItShouldReturnTrue_isElementBeforeOrEqualInMonths") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-01 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "mere", "element_date" -> "2018-04-01 00:00:00.00"))    ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-04-01 00:00:00.00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "mere" -> "1", "mere_date" -> "2018-04-01 00:00:00.00"))
    val historyLookUp = new HistoryLookUpUtility()

    assert(historyLookUp.wasElementBeforeOrEqualInMonths(visit1, m, "mere_date", "mere", 2, patientHistory) == true)
    assert(historyLookUp.wasElementBeforeOrEqualInMonths(visit2, m, "mere_date", "mere", 3, patientHistory) == true)
  }

  test("ItShouldReturnFalse_isElementBeforeOrEqualInMonths") {

    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "mere", "element_date" -> "2018-01-31 00:00:00.00")),
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "mere", "element_date" -> "2017-12-31 00:00:00.00"))
    ))
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-04-01 00:00:00.00"))
    val visit4 = CassandraRow.fromMap(Map("patientuid" -> "P2", "mere" -> "1", "mere_date" -> "2018-04-01 00:00:00.00"))
    val historyLookUp = new HistoryLookUpUtility()

    assert(historyLookUp.wasElementBeforeOrEqualInMonths(visit3, m, "mere_date", "mere", 2, patientHistory) == false)
    assert(historyLookUp.wasElementBeforeOrEqualInMonths(visit4, m, "mere_date", "mere", 3, patientHistory) == false)


  }

/*  test("ItShouldReturnTrue_recentLaboratoryTestResultInHistory") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2016-04-01 00:00:00.00", "elementvalue" -> "2")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2015-03-31 00:00:00.00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2015-05-30 00:00:00.00", "elementvalue" -> "2")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "mere", "element_date" -> "2015-03-15 00:00:00.00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "mere", "element_date" -> "2018-03-31 00:00:00.00", "elementvalue" -> "16")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "mere", "element_date" -> "2010-08-10 00:00:00.00", "elementvalue" -> "10"))
    ))
    val historyLookUp = new HistoryLookUpUtility()
    val ExpectedRDD: List[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2016-04-01 00:00:00.00", "elementvalue" -> "2")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "mere", "element_date" -> "2015-03-15 00:00:00.00", "elementvalue" -> "10"))
    )).collect().toList
    assert(historyLookUp.recentLaboratoryTestResultInHistory(HistoryRDD, "mere", "mere_date", 2, 15) == ExpectedRDD)
    val x = historyLookUp.recentLaboratoryTestResultInHistory(HistoryRDD, "mere", "mere_date", 2, 15)
    x.foreach(println)

  }*/


/*  test("ItShouldReturnTrue_isElementValuelessInMostRecentList") {
    val MostRecentList: List[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2016-05-01 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "hype", "element_date" -> "2015-03-31 00:00:00.00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "ele", "element_date" -> "2015-05-30 00:00:00.00", "elementvalue" -> "2"))
    )).collect().toList
    val historyLookUp = new HistoryLookUpUtility()
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-04-01 00:00:00.00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "ele" -> "1", "ele_date" -> "2018-05-30 00:00:00.00"))
    val m = MeasureProperty(null, null)
    assert(historyLookUp.isElementValuelessInMostRecentList(visit1, m, "mere", 2, 6, MostRecentList) == true)
    assert(historyLookUp.isElementValuelessInMostRecentList(visit2, m, "ele", 3, 3, MostRecentList) == true)

     }

  test("ItShouldReturnFalse_isElementValuelessInMostRecentList") {
    val MostRecentList: List[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "mere", "element_date" -> "2016-05-01 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "hype", "element_date" -> "2015-03-31 00:00:00.00", "elementvalue" -> "1"))
    )).collect().toList
    val historyLookUp = new HistoryLookUpUtility()
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P3", "mere" -> "1", "mere_date" -> "2018-04-01 00:00:00.00"))
    val visit4 = CassandraRow.fromMap(Map("patientuid" -> "P4", "hype" -> "1", "ele_date" -> "2018-05-30 00:00:00.00"))
    val m = MeasureProperty(null, null)
    assert(historyLookUp.isElementValuelessInMostRecentList(visit3, m, "mere", 2, 4, MostRecentList) == false)
    assert(historyLookUp.isElementValuelessInMostRecentList(visit4, m, "hype", 3, 1, MostRecentList) == false)

      }*/


  test("ItShouldReturnTrue_checkElementValuesInRangeInHistory") {
    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2016-05-01 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "ele", "element_date" -> "2015-05-30 00:00:00.00", "elementvalue" -> "6"))
    ))

    val historyLookUp = new HistoryLookUpUtility()
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)

    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-04-01 00:00:00.00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "ele" -> "1", "ele_date" -> "2018-05-30 00:00:00.00"))

    assert(historyLookUp.checkElementValuesInRangeInHistory(visit1, m, "mere", 2, 5, 10, patientHistory) == true)
    assert(historyLookUp.checkElementValuesInRangeInHistory(visit2, m, "ele", 3, 5, 7, patientHistory) == true)
  }


  test("ItShouldReturnFalse_checkElementValuesInRangeInHistory") {

    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "mere", "element_date" -> "2016-05-01 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "ele", "element_date" -> "2015-05-30 00:00:00.00", "elementvalue" -> "2"))
    ))

    val historyLookUp = new HistoryLookUpUtility()
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)

    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P3", "mere" -> "1", "mere_date" -> "2018-04-01 00:00:00.00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P4", "ele" -> "1", "ele_date" -> "2018-05-30 00:00:00.00"))



    assert(historyLookUp.checkElementValuesInRangeInHistory(visit1, m, "mere", 2, 6, 10, patientHistory) == false)
    assert(historyLookUp.checkElementValuesInRangeInHistory(visit2, m, "ele", 3, 5, 2, patientHistory) == false)

  }


  test("ItShouldReturnTrue_checkElementGreaterOrEqualInHistory_True") {

    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-03-30 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "ele", "element_date" -> "2018-03-30 00:00:00.00", "elementvalue" -> "6"))
    ))

    val historyLookUp = new HistoryLookUpUtility()
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)

    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-04-01 00:00:00.00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "ele" -> "1", "ele_date" -> "2018-05-30 00:00:00.00"))


    assert(historyLookUp.checkElementGreaterOrEqualInHistory(visit1, m, "mere", 2, patientHistory) == true)
    assert(historyLookUp.checkElementGreaterOrEqualInHistory(visit2, m, "ele", 6, patientHistory) == true)

  }

  test("ItShouldReturnFalse_checkElementGreaterOrEqualInHistory") {

    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "mere", "element_date" -> "2018-03-30 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "ele", "element_date" -> "2018-03-31 00:00:00.00", "elementvalue" -> "6"))
    ))

    val historyLookUp = new HistoryLookUpUtility()
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)

    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P3", "mere" -> "1", "mere_date" -> "2018-04-01 00:00:00.00"))
    val visit4 = CassandraRow.fromMap(Map("patientuid" -> "P4", "ele" -> "1", "ele_date" -> "2018-05-30 00:00:00.00"))


    assert(historyLookUp.checkElementGreaterOrEqualInHistory(visit3, m, "mere", 7, patientHistory) == false)
    assert(historyLookUp.checkElementGreaterOrEqualInHistory(visit4, m, "ele", 6, patientHistory) == false)


  }


  test("ItShouldReturnTrue_isPatientTobaccoNonUserWithin24Months") {

    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-30 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-30 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "hype", "element_date" -> "2018-02-01 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hype", "element_date" -> "2018-03-01 00:00:00.00", "elementvalue" -> "6")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hype", "element_date" -> "2018-06-01 00:00:00.00", "elementvalue" -> "6"))

    ))

    val MostRecentRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-01 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "ele", "element_date" -> "2018-03-30 00:00:00.00", "elementvalue" -> "6"))
    ))


    val historyLookUp = new HistoryLookUpUtility()
    val patientHistory = TestUtil.spark.sparkContext.broadcast(HistoryRDD.collect().toList)
    val mostrecentList = (MostRecentRDD.collect().toList)

    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "mere" -> "1", "mere_date" -> "2018-04-01 00:00:00.00"))
    //  val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "ele" -> "1","ele_date" -> "2018-05-30 00:00:00.00"))

    //assert(historyLookUp.isPatientTobaccoNonUserWithin24Months(visit1, m, "mere", "hype", 2, mostrecentList, patientHistory) == true)
    // assert(historyLookUp.isPatientTobaccoNonUserWithin24Months(visit1,m,"mere","",2,mostrecentList,patientHistory) == true)

  }



 /* //This is for the True case of the procedurePerformedStartsBeforeEndOfMeasurementPeriod
  test("ItShouldReturnTrueprocedurePerformedStartsBeforeEndOfMeasurementPeriod") {
    val patientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "ELMNT", "element_date" -> "2017-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d7", "element" -> "ELMNT", "element_date" -> "2017-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    ))
    val visit = CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "1", "elementdate" -> "2018-08-19 00:00:00.000+00:00"))
    assert(hu.procedurePerformedStartsBeforeEndOfMeasurementPeriod(visit, m, "ELMNT", "element_date", TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === true)
  }
  //This is for the False case of the procedurePerformedStartsBeforeEndOfMeasurementPeriod
  test("ItShouldReturnFalseprocedurePerformedStartsBeforeEndOfMeasurementPeriod") {
    val patientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "ELMNT", "element_date" -> "2017-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d7", "element" -> "ELMNT", "element_date" -> "2017-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    ))
    val visit = CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AB", "element" -> "1", "elementdate" -> "2018-08-19 00:00:00.000+00:00"))
    assert(hu.procedurePerformedStartsBeforeEndOfMeasurementPeriod(visit, m, "ELMNT", "element_date", TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === false)
  }*/

  //This is for the True case of the isDiagnosedWithEqualInMonths
  test("ItShouldreturnTrueForisDiagnosedWithEqualInMonths") {
    val patientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "ELMNT", "element_date" -> "2017-04-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d7", "element" -> "ELMNT", "element_date" -> "2017-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    ))
    val visit = CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "1", "elementdate" -> "2018-08-19 00:00:00.000+00:00"))
    assert(hu.isDiagnosedWithEqualInMonths(visit, m, "ELMNT", 10, TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === true)
  }

  //This is for the False case of the isDiagnosedWithEqualInMonths
  test("ItShouldreturnFalseForisDiagnosedWithEqualInMonths") {
    val patientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "ELMNT", "element_date" -> "2017-04-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d7", "element" -> "ELMNT", "element_date" -> "2017-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    ))
    val visit = CassandraRow.fromMap(Map("patientuid" -> "BI9UA8A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "1", "elementdate" -> "2018-08-19 00:00:00.000+00:00"))
    assert(hu.isDiagnosedWithEqualInMonths(visit, m, "ELMNT", 18, TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === false)
  }

  //This is for the True case of the ElementMostRecentResultInBetweenBeforeOrEqualInMonth
  test("ItShouldReturnTrueElementMostRecentResultInBetweenBeforeOrEqualInMonth") {
    val MostRecentpatientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "ABCDEF", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 145)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "EFGHIJ", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 110)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 90))
    )
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "1", "elementdate" -> "2018-08-19 00:00:00.000+00:00"))
    assert(hu.elementMostRecentResultInBetweenBeforeOrEqualInMonth(visit, m, "element", "ABCDEF", 120, 12,  TestUtil.spark.sparkContext.broadcast(MostRecentpatientHistoryRDD.collect().toList)) === true)
  }

  //This is for the False case of the ElementMostRecentResultInBetweenBeforeOrEqualInMonth
  test("ItShouldReturnFalseElementMostRecentResultInBetweenBeforeOrEqualInMonth") {
    val MostRecentpatientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "ABCDEF", "element_date" -> "2017-07-19 00:00:00.000+00:00", "elementvalue" -> 95)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "EFGHIJ", "element_date" -> "2017-07-19 00:00:00.000+00:00", "elementvalue" -> 85)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2017-07-19 00:00:00.000+00:00", "elementvalue" -> 92))
    )
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "1", "elementdate" -> "2018-08-19 00:00:00.000+00:00"))
    assert(hu.elementMostRecentResultInBetweenBeforeOrEqualInMonth(visit, m, "element", "EFGHIJ", 120, 12,  TestUtil.spark.sparkContext.broadcast(MostRecentpatientHistoryRDD.collect().toList)) === false)
  }

  //This is for the True case of the ElementMostRecentResultInBetweenBeforeOrEqualInMonth
  test("ItShouldReturnTrueElementMostRecentResultInBetweenBeforeOrEqualInMonthInRange") {
    val MostRecentpatientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "ABCDEF", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 145)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "EFGHIJ", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 110)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 90))
    )
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "ABCDEF" -> "1", "elementdate" -> "2018-05-19 00:00:00.000+00:00"))
    assert(hu.elementMostRecentResultInBetweenBeforeOrEqualInMonth(visit, m, "elementdate", "ABCDEF", 100, 170, 12, TestUtil.spark.sparkContext.broadcast(MostRecentpatientHistoryRDD.collect().toList)) === true)
  }

  //This is for the False case of the ElementMostRecentResultInBetweenBeforeOrEqualInMonth
  test("ItShouldReturnFalseElementMostRecentResultInBetweenBeforeOrEqualInMonthInRange") {
    val MostRecentpatientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "ABCDEF", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 175)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "EFGHIJ", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 85)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 90))
    )
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "ABCDEF" -> "1", "elementdate" -> "2018-05-19 00:00:00.000+00:00"))
    assert(hu.elementMostRecentResultInBetweenBeforeOrEqualInMonth(visit, m, "elementdate", "ABCDEF", 100, 170, 12, TestUtil.spark.sparkContext.broadcast(MostRecentpatientHistoryRDD.collect().toList)) === false)
  }

  // This is for the True case of the IOPmoderateStage
  test("ItShouldreturnTrueForIOPModerateStage") {
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> 17.5, "elementDate" -> "2018-05-03 00:00:00.00", "element2" -> "1", "element2Date" -> "2018-05-03 00:00:00.00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> 20.5, "elementDate" -> "2018-05-05 00:00:00.00", "element2" -> "1", "element2Date" -> "2018-05-05 00:00:00.00"))
    assert(hu.isIOPModerateStage(visit1, m, "element", "elementDate", "element2Date") === true)
    assert(hu.isIOPModerateStage(visit2, m, "element", "elementDate", "element2Date", 19, 22) === true)


  }
  // This is for the False case of the IOPmoderateStage
  test("ItShouldreturnFalseForIOPModerateStage") {
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> 15, "elementDate" -> "2018-05-03 00:00:00.00", "element2" -> "1", "element2Date" -> "2018-05-03 00:00:00.00"))
    val visit4 = CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> 14.8, "elementDate" -> "2018-05-03 00:00:00.00", "element2" -> "1", "element2Date" -> "2018-05-05 00:00:00.00"))
    val historyLookUp = new HistoryLookUpUtility()
    assert(hu.isIOPModerateStage(visit3, m, "element", "elementDate", "element2Date", 16, 18) === false)
    assert(hu.isIOPModerateStage(visit4, m, "element", "elementDate", "element2Date", 16, 18) === false)

  }

  // This is for the True case of the IOPMildStage
  test("ItShouldreturnTrueForIOPMildStage") {
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> 20.25, "elementDate" -> "2018-05-03 00:00:00.00", "element2" -> "1", "element2Date" -> "2018-05-03 00:00:00.00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> 21.22, "elementDate" -> "2018-05-03 00:00:00.00", "element2" -> "1", "element2Date" -> "2018-05-03 00:00:00.00"))
    assert(hu.isIOPMildStage(visit1, m, "element", "elementDate", "element2Date") === true)
    assert(hu.isIOPMildStage(visit2, m, "element", "elementDate", "element2Date") === true)

  }
  // This is for the False case of the IOPMildStage
  test("ItShouldreturnFalseForIOPMildStage") {
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> 15, "elementDate" -> "2018-05-03 00:00:00.00", "element2" -> "1", "element2Date" -> "2018-05-03 00:00:00.00"))
    val visit4 = CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> 14.8, "elementDate" -> "2018-05-03 00:00:00.00", "element2" -> "1", "element2Date" -> "2018-05-05 00:00:00.00"))
    val historyLookUp = new HistoryLookUpUtility()
    assert(hu.isIOPMildStage(visit3, m, "element", "elementDate", "element2Date") === false)
    assert(hu.isIOPMildStage(visit4, m, "element", "elementDate", "element2Date") === false)

  }





/*
  test("ItShouldReturnTrueIfEncounterPerformedBeforeEndOfMeasurementPeriod") {
    val patientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d7", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d8", "element" -> "hedsc9", "element_date" -> "2016-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    ))
    val visit = CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d7", "element" -> "hiofpnva", "hiofpnva_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    val actualResult = hu.encounterPerformedStartBeforeEndOfMeasurementPeriod(visit, m, "hiofpnva", "2015-08-19", TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList))
    assert(actualResult === true)
  }


  test("ItShouldReturnFalseIfEncounterPerformedNotBeforeEndOfMeasurementPeriod") {
    val patientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d7", "element" -> "hiofpnva", "element_date" -> "2019-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d8", "element" -> "hedsc9", "element_date" -> "2016-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    ))
    val visitAfterMeasurementPeriod = CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d7", "element" -> "hiofpnva", "hiofpnva_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    val actualResultAfterMeasurementPeriod = hu.encounterPerformedStartBeforeEndOfMeasurementPeriod(visitAfterMeasurementPeriod, m, "History_Of_Pneumococcal_Vaccine", "2015-08-19", TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList))

    val visitNotMatchingElementName = CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d7", "element" -> "hiofpnva", "hiofpnva_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    val actualResultNotMatchingElementName = hu.encounterPerformedStartBeforeEndOfMeasurementPeriod(visitNotMatchingElementName, m, "Abdominal_Pain", "2015-08-19", TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList))

    val visitNotMatchingPatientId = CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d9", "element" -> "hiofpnva", "hiofpnva_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    val actualResultNotMatchingPatientId = hu.encounterPerformedStartBeforeEndOfMeasurementPeriod(visitNotMatchingPatientId, m, "Abdominal_Pain", "2015-08-19", TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList))

    assert(actualResultAfterMeasurementPeriod === false)
    assert(actualResultNotMatchingElementName === false)
    assert(actualResultNotMatchingPatientId === false)
  }
*/

  /*test("ItShouldReturnTrueIfAssessmentIsPerformed") {
    val patientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d7", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d8", "element" -> "hedsc9", "element_date" -> "2016-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    ))
    val visit = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d7", "visituid" ->"V1", "element" -> "hiofpnva", "hiofpnva_date" -> "2018-08-19 00:00:00.000+00:00"))
    val actualResult = mu.isAssessmentPerformedBefore(visit, m, ElementMaster.History_Of_Pneumococcal_Vaccine, ElementMaster.History_Of_Pneumococcal_Vaccine, TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList))
    assert(actualResult === true)
  }


  test("ItShouldReturnFalseIfAssessmentIsNotPerformed") {
    val patientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d7", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d8", "element" -> "hedsc9", "element_date" -> "2016-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    ))
    val visitElementNameNotMatch = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d7", "visituid" ->"V1", "element" -> "hiofpnva", "hiofpnva_date" -> "2018-08-19 00:00:00.000+00:00"))
    val actualResultElementNameNotMatch = mu.isAssessmentPerformedBefore(visitElementNameNotMatch, m, ElementMaster.History_Of_Pneumococcal_Vaccine, ElementMaster.Abnormal_Hba1c, TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList))

    val visitPatientIdNotMatch = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "6058b7cb-8eee-41fb-a7bf-6e7ca335f6d8", "visituid" ->"V1", "element" -> "hiofpnva", "hiofpnva_date" -> "2018-08-19 00:00:00.000+00:00"))
    val actualResultPatientIdNotMatch = mu.isAssessmentPerformedBefore(visitPatientIdNotMatch, m, ElementMaster.History_Of_Pneumococcal_Vaccine, ElementMaster.History_Of_Pneumococcal_Vaccine, TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList))
    assert(actualResultElementNameNotMatch === false)
    assert(actualResultPatientIdNotMatch === false)
  }
*/
  test("ItShouldReturnMostRecentAssessmentPerformed") {
    val patientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hedsc9", "element_date" -> "2016-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    ))
    val expectedResult = List(CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-08-19 00:00:00.000+00:00", "elementvalue" -> "1")))
    //val actualResult = hu.mostRecentAssessmentPerformed(patientHistoryRDD, "P2", ElementMaster.History_Of_Pneumococcal_Vaccine, "ECqm167")
    //assert(actualResult === expectedResult)
  }




/*
  test("ItShouldReturnTrueIfElementCountGreaterThanEqualNoOfElementPresentDuringMeasurePeriod") {
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P2", "element1" -> "1", "element1_date" -> "2018-01-19 00:00:00.000+00:00", "element2" -> "1", "element2_date" -> "2018-02-19 00:00:00.000+00:00", "element3" -> "1", "element3_date" -> "2018-04-19 00:00:00.000+00:00", "element4" -> "1", "element4_date" -> "2018-03-31 00:00:00.000+00:00"))
    val actualResultCountGreater = hu.checkElementCountGreaterOrEqualElementPresentCountAndMeasurePeriod(visit1, m, 2, "element1", "element2", "element3")

    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "element1" -> "1", "element1_date" -> "2018-01-01 00:00:00.000+00:00", "element2" -> "1", "element2_date" -> "2018-02-19 00:00:00.000+00:00", "element3" -> "1", "element3_date" -> "2018-04-19 00:00:00.000+00:00"))
    val actualResultCountEqual = hu.checkElementCountGreaterOrEqualElementPresentCountAndMeasurePeriod(visit2, m, 2, "element1", "element2", "element3")
    assert(actualResultCountGreater === true)
    assert(actualResultCountEqual === true)
  }


  test("ItShouldReturnFalseIfElementCountNotGreaterThanEqualNoOfElementPresentDuringMeasurePeriod") {

    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P2", "element1" -> "1", "element1_date" -> "2018-01-01 00:00:00.000+00:00", "element2" -> "1", "element2_date" -> "2017-04-19 00:00:00.000+00:00", "element3" -> "1", "element3_date" -> "2017-04-19 00:00:00.000+00:00"))
    val actualResult1 = hu.checkElementCountGreaterOrEqualElementPresentCountAndMeasurePeriod(visit1, m, 2, "element1", "element2", "element3")

    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "element1" -> "1", "element1_date" -> "2017-01-01 00:00:00.000+00:00", "element2" -> "1", "element2_date" -> "2018-02-19 00:00:00.000+00:00", "element3" -> "1", "element3_date" -> "2017-04-19 00:00:00.000+00:00"))
    val actualResult2 = hu.checkElementCountGreaterOrEqualElementPresentCountAndMeasurePeriod(visit2, m, 2, "element1", "element2", "element3")
    assert(actualResult1 === false)
    assert(actualResult2 === false)
  }
*/

 /* test("ItShouldReturnTrueIfElementDateIsBeforeMonthOfMeasurementPeriod") {
    val patientHistoryRDD: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-02-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hedsc9", "element_date" -> "2018-02-28 00:00:00.000+00:00", "elementvalue" -> "1"))
    )
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P2", "hiofpnva" -> "1", "hiofpnva_date" -> "2018-02-19 00:00:00.000+00:00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P3", "hiofpnva" -> "1", "hiofpnva_date" -> "2018-02-28 00:00:00.000+00:00"))
    val actualResultEndDateAfterDate = hu.wasElementAfterOrEqualEndDateInMonths(visit1, m, "hiofpnva", 1, TestUtil.spark.sparkContext.broadcast(patientHistoryRDD))
    //val actualResultEndDateEqualDate= hu.isElementBeforeOrEqualInMonthsBeforeEndOfMeasurementPeriod(visit2,m,"hedsc9",1,sparkContext.broadcast(patientHistoryRDD))
    assert(actualResultEndDateAfterDate === true)
    //assert(actualResultEndDateEqualDate===true)
  }*/


 /* test("ItShouldReturnFalseIfElementDateIsBeforeMonthOfMeasurementPeriod") {
    val patientHistoryRDD: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2019-03-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hedsc9", "element_date" -> "2019-03-28 00:00:00.000+00:00", "elementvalue" -> "1"))
    )
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P2", "hiofpnva" -> "1", "hiofpnva_date" -> "2018-02-19 00:00:00.000+00:00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P3", "hiofpnva" -> "1", "hiofpnva_date" -> "2018-02-28 00:00:00.000+00:00"))
    val actualResult1 = hu.wasElementAfterOrEqualEndDateInMonths(visit1, m, "hiofpnva10", 1, TestUtil.spark.sparkContext.broadcast(patientHistoryRDD))
    val actualResult2 = hu.wasElementAfterOrEqualEndDateInMonths(visit2, m, "hedsc9", 1, TestUtil.spark.sparkContext.broadcast(patientHistoryRDD))
    assert(actualResult1 === false)
    assert(actualResult2 === false)
  }*/

  test("ItShouldReturnTrueIfMostRecentResultWithinMonthValueIsLessThanSpecified") {
    val mostRecentResultList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-03-19 00:00:00.000+00:00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hedsc9", "element_date" -> "2018-03-28 00:00:00.000+00:00", "elementvalue" -> "30"))
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "P2", "hiofpnva" -> "1", "hiofpnva_date" -> "2018-03-19 00:00:00.000+00:00"))
    val actualResult = hu.elementMostRecentResultLessBeforeOrEqualInMonth(visit, m, "hiofpnva_date", "hiofpnva", 40, 1, mostRecentResultList)
    assert(actualResult === true)
  }


  test("ItShouldReturnFalseIfMostRecentResultWithinMonthValueIsNotLessThanSpecified") {
    val mostRecentResultList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-03-19 00:00:00.000+00:00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hedsc9", "element_date" -> "2018-03-28 00:00:00.000+00:00", "elementvalue" -> "30"))
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "P2", "hiofpnva" -> "1", "hiofpnva_date" -> "2018-03-19 00:00:00.000+00:00"))
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P2", "hiofpnva" -> "1", "hiofpnva_date" -> "2018-05-19 00:00:00.000+00:00"))
    val actualResultWithLessValue = hu.elementMostRecentResultLessBeforeOrEqualInMonth(visit, m, "hiofpnva_date", "hiofpnva", 5, 1, mostRecentResultList)
    val actualResultWithEqualValue = hu.elementMostRecentResultLessBeforeOrEqualInMonth(visit, m, "hiofpnva_date", "hiofpnva", 10, 1, mostRecentResultList)
    val actualResultDateInMonth = hu.elementMostRecentResultLessBeforeOrEqualInMonth(visit, m, "hiofpnva_date", "hiofpnva", 10, 1, mostRecentResultList)
    assert(actualResultWithLessValue === false)
    assert(actualResultWithEqualValue === false)
    assert(actualResultDateInMonth === false)
  }
  test("ItShouldReturnTrueIfHistoryElementStartsAfterCurrentVisit") {
    val historyResultList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-03-24 00:00:00.000+00:00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hedsc9", "element_date" -> "2018-03-28 00:00:00.000+00:00", "elementvalue" -> "30"))
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "P2", "hiofpnva" -> "1", "hiofpnva_date" -> "2018-03-19 00:00:00.000+00:00"))
    val actualResult = hu.startAfterStartOfWithinDaysLessorEqual(visit, m, "hiofpnva_date", "hiofpnva", 2, TestUtil.spark.sparkContext.broadcast(historyResultList))
    val actualResult1 = hu.startAfterStartOfWithinDaysLessorEqual(visit, m, "hiofpnva_date", "hiofpnva", 5, TestUtil.spark.sparkContext.broadcast(historyResultList))
    assert(actualResult === true)
    assert(actualResult1 === true)
  }

  test("ItShouldReturnFalseIfHistoryElementNotStartsAfterCurrentVisit") {
    val historyResultList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-03-19 00:00:00.000+00:00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hedsc9", "element_date" -> "2018-03-28 00:00:00.000+00:00", "elementvalue" -> "30"))
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "P2", "hiofpnva" -> "1", "hiofpnva_date" -> "2018-03-19 00:00:00.000+00:00"))
    val actualResult = hu.startAfterStartOfWithinDaysLessorEqual(visit, m, "hiofpnva_date", "hiofpnva", 2, TestUtil.spark.sparkContext.broadcast(historyResultList))
    assert(actualResult === false)
  }

  test("ItShouldReturnTrueHistoryElementStartsAfterCurrentElement") {
    val historyResultList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-03-24 00:00:00.000+00:00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hedsc9", "element_date" -> "2018-03-28 00:00:00.000+00:00", "elementvalue" -> "30"))
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "P2", "hiofpnva" -> "1", "hiofpnva_date" -> "2018-03-19 00:00:00.000+00:00"))
    val actualResult = hu.startAfterStartOfEncounter(visit, m, "hiofpnva_date", "hiofpnva", TestUtil.spark.sparkContext.broadcast(historyResultList))
    assert(actualResult === true)

  }


  test("ItShouldReturnFalseHistoryElementNotStartsAfterCurrentElement") {
    val historyResultList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-03-15 00:00:00.000+00:00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hedsc9", "element_date" -> "2018-03-28 00:00:00.000+00:00", "elementvalue" -> "30"))
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "P2", "hiofpnva" -> "1", "hiofpnva_date" -> "2018-03-19 00:00:00.000+00:00"))
    val actualResult = hu.startAfterStartOfEncounter(visit, m, "hiofpnva_date", "hiofpnva", TestUtil.spark.sparkContext.broadcast(historyResultList))
    assert(actualResult === false)
  }
/*  test("ItShouldReturnTrueIfLaboratoryTestResultLessToSpecifiedValue") {
    val mostRecentResultList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-03-19 00:00:00.000+00:00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hedsc9", "element_date" -> "2017-03-31 00:00:00.000+00:00", "elementvalue" -> "30"))
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "P2", "hiofpnva" -> "1", "hiofpnva_date" -> "2018-03-19 00:00:00.000+00:00"))
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P3", "hedsc9" -> "1", "hedsc9_date" -> "2018-03-19 00:00:00.000+00:00"))
    val actualResult = hu.getRecentLaboratoryTestResultValueLess(visit, m, "hiofpnva", 1, 40, mostRecentResultList)
    val actualResult1 = hu.getRecentLaboratoryTestResultValueLess(visit1, m, "hedsc9", 2, 31, mostRecentResultList)
    assert(actualResult === true)
    assert(actualResult1 === true)
  }

  test("ItShouldReturnFalseIfLaboratoryTestResultNotLessToSpecifiedValue") {
    val mostRecentResultList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-03-19 00:00:00.000+00:00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hedsc9", "element_date" -> "2015-03-31 00:00:00.000+00:00", "elementvalue" -> "30"))
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "P2", "hiofpnva" -> "1", "hiofpnva_date" -> "2018-03-19 00:00:00.000+00:00"))
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P3", "hedsc9" -> "1", "hedsc9_date" -> "2018-03-19 00:00:00.000+00:00"))
    val actualResult = hu.getRecentLaboratoryTestResultValueLess(visit, m, "hiofpnva", 1, 5, mostRecentResultList)
    val actualResult1 = hu.getRecentLaboratoryTestResultValueLess(visit, m, "hiofpnva", 1, 10, mostRecentResultList)
    val actualResult2 = hu.getRecentLaboratoryTestResultValueLess(visit1, m, "hedsc9", 1, 31, mostRecentResultList)
    assert(actualResult === false)
    assert(actualResult1 === false)
    assert(actualResult2 === false)
  }*/
 /* test("itShouldReturnMostRecentElementList") {
    val patientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hiofpnva", "element_date" -> "2016-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    ))
    val expectedResult = List(CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hiofpnva", "element_date" -> "2016-08-19 00:00:00.000+00:00", "elementvalue" -> "1")))
    val actualResult = hu.mostRecentElementList(patientHistoryRDD, ElementMaster.History_Of_Pneumococcal_Vaccine)
    assert(actualResult === expectedResult)
  }
*/
  test("itShouldReturnMostRecentElementList") {

    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-01 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-02 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hype", "element_date" -> "2018-05-03 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hype", "element_date" -> "2019-05-03 00:00:00.00", "elementvalue" -> "5"))
    ))

    val expectedResult: List[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-05-02 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hype", "element_date" -> "2019-05-03 00:00:00.00", "elementvalue" -> "5"))
    )).collect().toList

    assert(hu.mostRecentPatientList(HistoryRDD,"mere","hype") == expectedResult)

  }

  test("itShouldReturnLeastRecentElementList") {
    val patientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hiofpnva", "element_date" -> "2016-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    ))
    val expectedResult = List(CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "1")),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "hiofpnva", "element_date" -> "2016-08-19 00:00:00.000+00:00", "elementvalue" -> "1")))
    //val actualResult = hu.minDate(patientHistoryRDD, ElementMaster.History_Of_Pneumococcal_Vaccine, ElementMaster.History_Of_Pneumococcal_Vaccine_Date)
    //assert(actualResult === expectedResult)
  }
  test("ItShouldReturnTrueIfEyeElementIsWithinRange") {
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P2", "diabret_eye" -> "1", "macexm_eye" -> "1", "lvlsvrretf_eye" -> "1", "macedf_eye" -> "1", "hiofpnva_date" -> "2018-03-19 00:00:00.000+00:00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "diabret_eye" -> null, "macexm_eye" -> null, "lvlsvrretf_eye" -> "1", "macedf_eye" -> "1", "hiofpnva_date" -> "2018-03-19 00:00:00.000+00:00"))
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P2", "diabret_eye" -> null, "macexm_eye" -> null, "lvlsvrretf_eye" -> "1", "macedf_eye" -> "3", "hiofpnva_date" -> "2018-03-19 00:00:00.000+00:00"))
    val visit4 = CassandraRow.fromMap(Map("patientuid" -> "P2", "diabret_eye" -> null, "macexm_eye" -> null, "lvlsvrretf_eye" -> "4", "macedf_eye" -> "2", "hiofpnva_date" -> "2018-03-19 00:00:00.000+00:00"))
    //val actualResult1 = hu.checkEyeElementsInRange(visit1,m, ElementMaster.Diabetic_Retinopathy__Eye, ElementMaster.Macular_Exam_Eye, ElementMaster.Level_Of_Severity_Of_Retinopathy_Findings_Eye, ElementMaster.Macular_Edema_Findings__Eye)
    //val actualResult2 = hu.checkEyeElementsInRange(visit2,m, ElementMaster.Diabetic_Retinopathy__Eye, ElementMaster.Macular_Exam_Eye)
    //val actualResult3 = hu.checkEyeElementsInRange(visit3,m, ElementMaster.Diabetic_Retinopathy__Eye, ElementMaster.Level_Of_Severity_Of_Retinopathy_Findings_Eye)
    //val actualResult4 = hu.checkEyeElementsInRange(visit4,m, ElementMaster.Diabetic_Retinopathy__Eye, ElementMaster.Level_Of_Severity_Of_Retinopathy_Findings_Eye)
    //assert(actualResult1 === true)
    //assert(actualResult2 === true)
    //assert(actualResult3 === true)
    //assert(actualResult4 === true)
  }


  test("ItShouldReturnFalseIfEyeElementIsNotWithinRange") {
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "diabret_eye" -> 0, "macexm_eye" -> 1))
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P2", "diabret_eye" -> 5, "macexm_eye" -> 4))
    //val actualResult2 = hu.checkEyeElementsInRange(visit2,m, ElementMaster.Diabetic_Retinopathy__Eye, ElementMaster.Macular_Exam_Eye)
    //val actualResult3 = hu.checkEyeElementsInRange(visit3,m, ElementMaster.Diabetic_Retinopathy__Eye, ElementMaster.Macular_Exam_Eye)
    //assert(actualResult2 === false)
    //assert(actualResult3 === false)
  }
/*  test("ItShouldReturnNoOfRecordCountForElementInHistory") {

    val patientHistoryList: List[CassandraRow] = List(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "toussc", "element_date" -> "2015-09-09 00:00:00.000+00:00", "elementvalue" -> "10")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2015-08-19 00:00:00.000+00:00", "elementvalue" -> "20")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-10-19 00:00:00.000+00:00", "elementvalue" -> "40")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-11-19 00:00:00.000+00:00", "elementvalue" -> "40")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2019-05-25 00:00:00.000+00:00", "elementvalue" -> "40"))
    )
    val visit = CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "hiofpnva", "element_date" -> "2018-08-19 00:00:00.000+00:00", "elementvalue" -> "1"))
    val actualResult = hu.numberOfEncounterPerformedCountinHistory(visit, m, 3, TestUtil.spark.sparkContext.broadcast(patientHistoryList), "hiofpnva")
    assert(actualResult === 2)
  }*/
  //  This is for the True case for Physical Exam performed in History.
/*
  test("ItShouldReturnTruephysicalExamPerfomedInHistory"){
    val patientHistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "test", "element_date" -> "2018-09-19 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "XYZUIO", "element_date" -> "2018-05-19 00:00:00.000+00:00", "elementvalue" -> 20)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 400))
    )
    )
    val visit = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "visituid" ->"V1","test" -> "1", "element_date" -> "2018-08-19 00:00:00.000+00:00"))
    assert(hu.physicalExamPerfomedInHistory(visit, m,"test",spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === true)
  }

  //  This is for the false case for Physical Exam performed in History.
  test("ItShouldReturnFalsephysicalExamPerfomedInHistory"){
    val patientHistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "DIAELMNT", "element_date" -> "2018-09-19 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "XYZUIO", "element_date" -> "2018-05-19 00:00:00.000+00:00", "elementvalue" -> 20)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 400))
    )
    )
    val visit = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "visituid" ->"V1","element" -> "1", "element_date" -> "2018-08-19 00:00:00.000+00:00"))
    assert(hu.physicalExamPerfomedInHistory(visit, m,"ABCDEF",spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === false)
  }
*/

  //  This is for the True case for physicalExamResultInxMonthsHistory.
  test("ItShouldReturnTruephysicalExamResultInxMonthsHistory"){
    val patientHistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "DIAELMNT", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "XYZUIO", "element_date" -> "2017-05-19 00:00:00.000+00:00", "elementvalue" -> 20)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 400))
    )
    )
    val visit = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "visituid" ->"V1","element" -> "1", "element_date" -> "2018-08-19 00:00:00.000+00:00"))
    assert(hu.physicalExamResultInxMonthsHistory(visit, m,"DIAELMNT",12,spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === true)
  }


  //  This is for the False case for physicalExamResultInxMonthsHistory.
  test("ItShouldReturnFalsephysicalExamResultInxMonthsHistory"){
    val patientHistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "DIAELMNT", "element_date" -> "2015-09-19 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "XYZUIO", "element_date" -> "2014-05-20 00:00:00.000+00:00", "elementvalue" -> 20)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2011-08-11 00:00:00.000+00:00", "elementvalue" -> 400))
    )
    )
    val visit = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "visituid" ->"V1","element" -> "1", "element_date" -> "2018-08-19 00:00:00.000+00:00"))
    assert(hu.physicalExamResultInxMonthsHistory(visit, m,"DIAELMNT",12,spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === false)
  }

  // This is for the True case for wasVisitedWithinLast72Hours
/*  test("ItShouldReturnTrue_wasVisitedWithinLast72Hours"){
    val patientHistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "Crctlcare", "element_date" -> "2017-12-30 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "EMergenCY", "element_date" -> "2017-12-31 00:00:00.000+00:00", "elementvalue" -> 20)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 4)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "Crctlcare", "element_date" -> "2017-12-30 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "B12D78A0-A0CB-0007-ABTY-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2017-12-30 00:00:00.000+00:00", "elementvalue" -> 10))
    )
    )
    val visit = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "visituid" ->"V1","element" -> "1", "encounterdate" -> "2018-01-01 00:00:00.000+00:00"))
    assert(hu.wasVisitedWithinLast72Hours(visit, m,"Crctlcare","EMergenCY",72,spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === true)
  }

  // This is for the False case for wasVisitedWithinLast72Hours
  test("ItShouldReturnFalse_wasVisitedWithinLast72Hours"){
    val patientHistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "Crctlcare", "element_date" -> "2017-12-30 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "EMergenCY", "element_date" -> "2017-12-31 00:00:00.000+00:00", "elementvalue" -> 20)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 4)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "Crctlcare", "element_date" -> "2017-12-28 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "B12D78A0-A0CB-0007-ABTY-F9CFCF4C76AE", "element" -> "DIAELMNT", "element_date" -> "2017-12-30 00:00:00.000+00:00", "elementvalue" -> 10))
    )
    )
    val visit = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "visituid" ->"V1","element" -> "1", "encounterdate" -> "2018-01-01 00:00:00.000+00:00"))
    assert(hu.wasVisitedWithinLast72Hours(visit, m,"Crctlcare","EMergenCY",72,spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === false)
  }*/

  // This is for the true case for isAssessmentPerformedinHistory
/*  test("ItShouldReturnTrue_isAssessmentPerformedinHistory"){
    val patientHistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "Crctlcare", "element_date" -> "2017-09-30 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "EMergenCY", "element_date" -> "2017-01-01 00:00:00.000+00:00", "elementvalue" -> 20)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT",  "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 4)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "Crctlcare", "element_date" -> "2017-12-28 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "B12D78A0-A0CB-0007-ABTY-F9CFCF4C76AE", "element" -> "DIAELMNT",  "element_date" -> "2017-12-30 00:00:00.000+00:00", "elementvalue" -> 10))
    )
    )
    val visit = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "visituid" ->"V1","element" -> "1", "encounterdate" -> "2018-05-15 00:00:00.000+00:00"))
    val visit1 = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "B12D78A0-A0CB-0007-ABTY-F9CFCF4C76AE", "visituid" ->"V1","element" -> "1", "encounterdate" -> "2018-06-05 00:00:00.000+00:00"))
    assert(hu.isAssessmentPerformedinHistory(visit, m,"Crctlcare",spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === true)
    assert(hu.isAssessmentPerformedinHistory(visit1, m,"DIAELMNT",spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === true)
  }

  // This is for the false case for isAssessmentPerformedinHistory
  test("ItShouldReturnFalse_isAssessmentPerformedinHistory"){
    val patientHistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "", "element_date" -> "2017-09-30 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "EMergenCY", "element_date" -> "2017-01-01 00:00:00.000+00:00", "elementvalue" -> 20)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT",  "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 4)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "FJKHLKG", "element_date" -> "2017-12-28 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "B12D78A0-A0CB-0007-ABTY-F9CFCF4C76AE", "element" -> "DIAELMNT",  "element_date" -> "2017-12-30 00:00:00.000+00:00", "elementvalue" -> 10))
    )
    )
    val visit = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "visituid" ->"V1","element" -> "1", "encounterdate" -> "2018-05-15 00:00:00.000+00:00"))
    val visit1 = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "visituid" ->"V1","element" -> "1", "encounterdate" -> "2018-06-05 00:00:00.000+00:00"))
    assert(hu.isAssessmentPerformedinHistory(visit, m,"Crctlcare",spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === false)
    assert(hu.isAssessmentPerformedinHistory(visit1, m,"DIAELMNT",spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === false)
  }*/

  test("ItShouldReturnTrue_wasDuringInfluenzaPeriodLastFiveMonthInHistory"){

    val patientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "ele", "element_date" -> "2017-08-01 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "ele", "element_date" -> "2017-09-02 00:00:00.000+00:00", "elementvalue" -> 20)),
      CassandraRow.fromMap(Map("patientuid" -> "P3", "element" -> "ele",  "element_date" -> "2017-12-31 00:00:00.000+00:00", "elementvalue" -> 4)),
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "ele", "element_date" -> "2017-07-30 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "P5", "element" -> "ele",  "element_date" -> "2018-01-01 00:00:00.000+00:00", "elementvalue" -> 10))
    )
    )
    val visit1 = CassandraRow.fromMap(Map("patientuid" -> "P1", "visituid" ->"V1","ele" -> "1", "ele_date" -> "2018-04-04 00:00:00.000+00:00"))
    val visit2 = CassandraRow.fromMap(Map("patientuid" -> "P2", "visituid" ->"V1","ele" -> "1", "ele_date" -> "2018-04-04 00:00:00.000+00:00"))
    val visit3 = CassandraRow.fromMap(Map("patientuid" -> "P2", "visituid" ->"V1","ele" -> "1", "ele_date" -> "2018-04-04 00:00:00.000+00:00"))
    assert(hu.wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit1, m,"ele",TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === true)
    assert(hu.wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit2, m,"ele",TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === true)
    assert(hu.wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit3, m,"ele",TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === true)

  }

  test("ItShouldReturnFalse_wasDuringInfluenzaPeriodLastFiveMonthInHistory"){

    val patientHistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P4", "element" -> "ele", "element_date" -> "2017-07-30 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "P5", "element" -> "ele",  "element_date" -> "2018-01-01 00:00:00.000+00:00", "elementvalue" -> 10))
    )
    )

    val visit4 = CassandraRow.fromMap(Map("patientuid" -> "P4", "visituid" ->"V1","ele" -> "1", "ele_date" -> "2018-04-04 00:00:00.000+00:00"))
    val visit5 = CassandraRow.fromMap(Map("patientuid" -> "P5", "visituid" ->"V1","ele" -> "1", "ele_date" -> "2018-04-04 00:00:00.000+00:00"))
    assert(hu.wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit4, m,"ele",TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === false)
    assert(hu.wasDuringInfluenzaPeriodLastFiveMonthInHistory(visit5, m,"ele",TestUtil.spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === false)

  }

  // This is for the true case for ItShouldReturnTrue_isMostRecentPhysicalExamPerformedBefore
  test("ItShouldReturnTrueAndFalse_isMostRecentPhysicalExamPerformedBefore"){
    val patientHistoryRDD: RDD[CassandraRow] = spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "hRate2", "element_date" -> "2015-06-30 00:00:00.000+00:00", "elementvalue" -> 150)),
      CassandraRow.fromMap(Map("patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "element" -> "EMergenCY", "element_date" -> "2017-01-01 00:00:00.000+00:00", "elementvalue" -> 20)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "DIAELMNT",  "element_date" -> "2017-09-19 00:00:00.000+00:00", "elementvalue" -> 135)),
      CassandraRow.fromMap(Map("patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "element" -> "FJKHLKG", "element_date" -> "2017-12-28 00:00:00.000+00:00", "elementvalue" -> 10)),
      CassandraRow.fromMap(Map("patientuid" -> "B12D78A0-A0CB-0007-ABTY-F9CFCF4C76AE", "element" -> "DIAELMNT",  "element_date" -> "2017-12-30 00:00:00.000+00:00", "elementvalue" -> 10))
    )
    )
    val visit = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "B18D78A0-A0CB-4965-AEA4-F9CFCF4C76AD", "visituid" ->"V1","hRate" -> "1", "hRate_date" -> "2018-10-15 00:00:00.000+00:00"))
    val visit1 = CassandraRow.fromMap(Map("practiceuid"->"practice1","patientuid" -> "A18D78A0-A0CB-4965-AEA4-F9CFCF4C76AE", "visituid" ->"V1","hRate" -> "1", "hRate_date" -> "2018-06-05 00:00:00.000+00:00"))
    assert(mu.isMostRecentPhysicalExamPerformedBefore(visit, m,"hRate2","hRate",160,"lt",spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === true)
    assert(mu.isMostRecentPhysicalExamPerformedBefore(visit1, m,"FJKHLKG","hRate",130,"ge",spark.sparkContext.broadcast(patientHistoryRDD.collect().toList)) === false)
  }

  test("ItshouldreturnList_countElement") {

    val HistoryRDD: RDD[CassandraRow] = TestUtil.spark.sparkContext.parallelize(Seq(
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2017-12-31 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-02 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "mere", "element_date" -> "2018-02-02 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P1", "element" -> "hype", "element_date" -> "2018-02-02 00:00:00.00", "elementvalue" -> "5")),
      CassandraRow.fromMap(Map("patientuid" -> "P2", "element" -> "chk", "element_date" -> "2018-02-02 00:00:00.00", "elementvalue" -> "5"))
    ))

    val rddCount = historyLookUp.countElement(HistoryRDD,m,"mere","hype","chk")

    val expectedList : List[(String, Int)] = List(("P2",1),("P1",3))

    assert(rddCount === expectedList)

  }
}
