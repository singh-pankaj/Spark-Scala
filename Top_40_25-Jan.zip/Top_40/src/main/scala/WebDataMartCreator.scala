package com.figmd.janus

import java.time.LocalDate
import java.util.{Calendar, Date, Properties}

import com.figmd.janus.util.application._
import com.figmd.janus.util.measure.SetPropertyArgs
import com.google.common.base.Throwables
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{SQLContext, SparkSession}
import org.joda.time.DateTime

import scala.collection.immutable.HashMap

object WebDataMartCreator extends Serializable {

  @transient lazy val postgresUtility = new PostgreUtility()
  val prop = new Properties
  val start_date = Calendar.getInstance.getTime
  var debugMode = 0
  var wf_id = ""
  var quarter_end_date = ""
  var measure_list = ""
  var global_measure_name = ""
  var practiceListCondition = ""
  var action_name = "Measure_Computation"
  var globalStartDate: DateTime = null
  var globalEndDate: DateTime = null
  var yarn_queue="default"

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  //Logger.getLogger("myLogger").setLevel(Level.OFF)
  var spark: SparkSession = null
  var sparkSql: SQLContext = null
  var tableCatalogMap: HashMap[String, String] = HashMap.empty[String, String]

  def initTableCatalogMap(encounterTable: String, encounterCatalogFile: String, patientHistoryTable: String, patientHistoryCatalogFile: String,
                          summaryByPracticeTable: String, summaryByPracticeCatalogFile: String , summaryByProviderTable: String, summaryByProviderCatalogFile: String,
                          summaryByLocationTable: String, summaryByLocationCatalogFile: String , summaryByMeasureTable: String, summaryByMeasureCatalogFile: String): Unit = {
    //println("Mapping " + encounterTable + " table with " + encounterCatalogFile + " catalog file:")
    //println("Mapping " + patientHistoryTable + " table with " + patientHistoryCatalogFile + " catalog file:")
    tableCatalogMap += (encounterTable -> encounterCatalogFile)
    tableCatalogMap += (patientHistoryTable -> patientHistoryCatalogFile)
    tableCatalogMap += (summaryByPracticeTable -> summaryByPracticeCatalogFile)
    tableCatalogMap += (summaryByProviderTable -> summaryByProviderCatalogFile)
    tableCatalogMap += (summaryByLocationTable -> summaryByLocationCatalogFile)
    tableCatalogMap += (summaryByMeasureTable -> summaryByMeasureCatalogFile)
  }

  def main(args: Array[String]) {
    try {
      println("Start Time : " + start_date)

      // set all command line objectinto property object
      val setPropObj = new SetPropertyArgs(args)
      val wfType = prop.getProperty("wfType")
      wf_id = prop.getProperty("wf_id")
      debugMode = prop.getProperty("debugMode").toInt
      //val currentDate = LocalDate.now()

      //val Date = LocalDate.parse("2018-10-01")
      //println("DATE::::::::::::::::::::" + currentDate)
      //prop.setProperty("DateRange", new DateRangeSelector().selectRange(prop.getProperty("wfType"), currentDate))

      //check wf_type notempty
      setPropObj.chkValidWFType()

      val sparkUtility = new SparkUtility()
      spark = sparkUtility.getSparkContext()
      spark.sparkContext.setLogLevel("ERROR")
      //val dateUtility = new DateUtility()
      sparkSql = spark.sqlContext
      println("Configured input storage type: " + prop.getProperty("input_storage_type") + ", " + prop.getProperty("input_storage_type"))
      //initTableCatalogMap(prop.getProperty("bigtable_tblencounter"), prop.getProperty("bigtable_tblencounter_catalog"), prop.getProperty("bigtable_patient_history"), prop.getProperty("bigtable_patient_history_catalog"))

      initTableCatalogMap(prop.getProperty("bigtable_tblencounter"), prop.getProperty("bigtable_tblencounter_catalog"),
        prop.getProperty("bigtable_patient_history"), prop.getProperty("bigtable_patient_history_catalog"),
        prop.getProperty("bigtable_WDM_practice_table"), prop.getProperty("bigtable_WDM_practice_table_catalog"),
        prop.getProperty("bigtable_WDM_provider_table"), prop.getProperty("bigtable_WDM_provider_table_catlog"),
        prop.getProperty("bigtable_WDM_location_table"), prop.getProperty("bigtable_WDM_location_table_catalog"),
        prop.getProperty("bigtable_WDM_measure_table"), prop.getProperty("bigtable_WDM_measure_table_catalog"))

      InputStorageTypeHelper.init(spark, sparkSql, prop.getProperty("input_storage_type"))

      //measure_list=postgresUtility.fetchMeasureFromMgmt(measure_list)

      setPropObj.validateMeasureList()

      //Execute each measure sequentially
      setPropObj.executeMeasure(spark, wfType)

    //  println("Measure refresh Start Time : " + start_date)
    //  println("Measure refresh End Time  : " + Calendar.getInstance.getTime)
      //var emailUtility  = new EmailUtility("sagar.kulkarni2007@gmail.com","","","sagar.kulkarni2007@gmail.com","Test","Hi","smtp.gmail.com")
      //emailUtility.sendMessage
    }
    catch {
      case e: Exception => {
        println(e.printStackTrace())
        postgresUtility.insertIntoProcessDetails(global_measure_name, "W0000", "CRITICAL", Throwables.getStackTraceAsString(e), "FAIL")
        System.exit(-1)
      }
    }
  }
}
