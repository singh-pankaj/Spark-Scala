package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AUGS8Elements, CompareOperator, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Augs8
* Measure Title               :- Documentation of weight loss counseling prior to surgery for stress urinary incontinence procedures for obese women
* Measure Description         :- Percentage of obese patients having documented weight loss counseling prior to undergoing anti-urinary incontinence procedures.
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.RASURE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/

object Augs8 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "Augs8"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,AUGS8Elements.Bmi_Loinc_Value,
      AUGS8Elements.Weight_Loss_Counseling
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population : Number of obese patients (BMI > 30) having any anti-urinary incontinence surgical procedure.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
           isFemale(visit,m)
        && isPhysicalExamPerformedwithValueBeforeProcedure(visit,m,AUGS8Elements.Anti_Urinary_Incontinence_Surgery,30,CompareOperator.GREATER,patientHistoryBroadcastList,AUGS8Elements.Bmi_Loinc_Value)
        && isProcedurePerformedDuringEncounter(visit,m,AUGS8Elements.Anti_Urinary_Incontinence_Surgery) // it is Procedure-Specific measure hence checking procedure on Encounter instead of during measurement period.

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator : The number of obese patients (BMI > 30) having documented weight loss counseling prior to undergoing anti-urinary incontinence procedures.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            wasInterventionPerformedEndsBeforeStartOfProcedure(visit,m,AUGS8Elements.Anti_Urinary_Incontinence_Surgery,patientHistoryBroadcastList,AUGS8Elements.Weight_Loss_Counseling)


    )
  }

}
