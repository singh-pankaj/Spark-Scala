package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AQUA21Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AQUA21
* Measure Title               :- Appropriate Management of Obstructive Azoospermia
* Measure Description         :- Percentage of obstructive azoospermia patients managed appropriately.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- PRIYANKA CHAVAN
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :-
--------------------------------------------------------------------------------------------------------------------------*/

object AQUA21 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "AQUA21"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,AQUA21Elements.Obstructive_Azoospermia
      ,AQUA21Elements.Biopsy_Aspiration
      ,AQUA21Elements.Referral_To_Male_Reproductive_Specialist
      ,AQUA21Elements.Epididymal_Aspiration
      ,AQUA21Elements.Cryopreservation_For_Ivf
      ,AQUA21Elements.Testicular_Biopsy_Needle_Open
      ,AQUA21Elements.Vasal_Or_Vaso_Epididymal_Reconstruction
      ,AQUA21Elements.Transurethral_Resection_Of_Ejaculatory_Duct
      ,AQUA21Elements.Congenital_Bilateral_Absence_Of_Vas_Deferens
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
             isMale(visit,m)
        &&   wasDiagnosedInHistory(visit,m,AQUA21Elements.Obstructive_Azoospermia,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        (
          (
                  isProcedurePerformed(visit,m,AQUA21Elements.Biopsy_Aspiration,patientHistoryBroadcastList)
              &&  isCommunicationFromProvidertoProvider(visit,m,AQUA21Elements.Referral_To_Male_Reproductive_Specialist,patientHistoryBroadcastList)
          )
          ||
          (
                  isProcedurePerformed(visit,m,AQUA21Elements.Epididymal_Aspiration,patientHistoryBroadcastList)
              &&  isProcedurePerformed(visit,m,AQUA21Elements.Cryopreservation_For_Ivf,patientHistoryBroadcastList)
          )
          ||
          (
                  isProcedurePerformed(visit,m,AQUA21Elements.Testicular_Biopsy_Needle_Open,patientHistoryBroadcastList)
              &&  isProcedurePerformed(visit,m,AQUA21Elements.Cryopreservation_For_Ivf,patientHistoryBroadcastList)
          )
          ||  isProcedurePerformed(visit,m,AQUA21Elements.Vasal_Or_Vaso_Epididymal_Reconstruction,patientHistoryBroadcastList)
          ||  isProcedurePerformed(visit,m,AQUA21Elements.Transurethral_Resection_Of_Ejaculatory_Duct,patientHistoryBroadcastList)
        )
        &&  !isDiagnosis(visit,m,AQUA21Elements.Congenital_Bilateral_Absence_Of_Vas_Deferens,patientHistoryBroadcastList)
    )
  }

}
