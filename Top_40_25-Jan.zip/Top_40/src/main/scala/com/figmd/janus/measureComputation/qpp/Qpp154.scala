package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP154Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp154
* Measure Title              :- Falls: Risk Assessment
* Measure Description        :- Percentage of patients aged 65 years and older with a history of falls that had a risk assessment for falls completed within 12 months
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp154 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp154"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP154Elements.History_Of_Single_Fall_With_Injury,
      QPP154Elements.History_Of_Falls_Without_Injury,
      QPP154Elements.Falls_History,
      QPP154Elements.Hospice_Services,
      QPP154Elements.Hospice_Care,
      QPP154Elements.Falls_Risk_Assessment,
      QPP154Elements.Balance_Gait_Assessment_Gr,
      QPP154Elements.Medication_Side_Effects,
      QPP154Elements.Vision_Assessment,
      QPP154Elements.Home_Fall_Hazards_Assessment,
      QPP154Elements.Systolic_Loinc,
      QPP154Elements.Diastolic_Loinc,
      QPP154Elements.Standing_Posture,
      QPP154Elements.Supine_Posture,
      QPP154Elements.Falls_Risk_Assessment_Reason_Not_Specified,
      QPP154Elements.Fall_Risk_Assessment_Medical_Reason,
      QPP154Elements.Patient_Not_Ambulatory,
      QPP154Elements.Patient_Not_Ambulatory_Kywrd
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exceptions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val intermediateRDD = getSubtractRDD(ippRDD, metRDD)
      intermediateRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }

  /*
  All patients aged 65 years and older who have a history of falls (history of falls is defined as 2 or more falls in
  the past year or any fall with injury in the past year). Documentation of patient reported history of falls is sufficient
   */

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientElderly(visit, m)
        && isVisitTypeIn(visit, m, QPP154Elements.Initial_Preventive_Physical_Examination
        , QPP154Elements.Annual_Wellness_Visit
        , QPP154Elements.Home_Healthcare_Services
        , QPP154Elements.Care_Services_In_Long_Term_Residential_Facility
        , QPP154Elements.Nursing_Facility_Visit
        , QPP154Elements.Office_Visit
        , QPP154Elements.Audiology_Visit
        , QPP154Elements.Physical_Therapy_Evaluation_Cpt
        , QPP154Elements.Re_Evaluation_Of_Physical_Therapy_Cpt
        , QPP154Elements.Occupational_Therapy_Cpt
        , QPP154Elements.Occupational_Therapy_Re_Evalution_Cpt)

        &&
        (
          isAssessmentPerformedOnEncounter(visit, m, QPP154Elements.History_Of_Falls)
            || wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.History_Of_Single_Fall_With_Injury, 12, patientHistoryBroadcastList)
            || wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.History_Of_Falls_Without_Injury, 12, patientHistoryBroadcastList)
            ||
            (
              wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.History_Of_Falls_Without_Injury, 12, patientHistoryBroadcastList)
                && wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Falls_History, 12, patientHistoryBroadcastList)
              )
          ))
  }


  //Hospice services for patient provided any time during the measurement period
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      isInterventionBeforeEnd(visit, m, QPP154Elements.Hospice_Services, patientHistoryBroadcastList)
        || isInterventionBeforeEnd(visit, m, QPP154Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
        || isInterventionPerformed(visit, m, QPP154Elements.Hospice_Care, patientHistoryBroadcastList)
    )
  }

  //Patients who had a risk assessment for falls completed within 12 months
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Falls_Risk_Assessment, 12, patientHistoryBroadcastList)
          || (
          wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Balance_Gait_Assessment_Gr, 12, patientHistoryBroadcastList)
            && (
            wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Medication_Side_Effects, 12, patientHistoryBroadcastList)
              || wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Vision_Assessment, 12, patientHistoryBroadcastList)
              || wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Home_Fall_Hazards_Assessment, 12, patientHistoryBroadcastList)
              ||
              (
                wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Systolic_Loinc, 12, patientHistoryBroadcastList)
                  && wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Diastolic_Loinc, 12, patientHistoryBroadcastList)
                  && wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Standing_Posture, 12, patientHistoryBroadcastList)
                  && wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Supine_Posture, 12, patientHistoryBroadcastList)
                )
            )
          )
        ) && !wasAssessmentPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Falls_Risk_Assessment_Reason_Not_Specified, 12, patientHistoryBroadcastList)
    )
  }


  /*

  Documentation of medical reason(s) for not completing a risk assessment for falls (i.e., patient is not ambulatory, bed
  ridden, immobile, confined to chair, wheelchair bound, dependent on helper pushing wheelchair, independent in wheelchair
  or minimal help in wheelchair
   */
  def getException(intermediateRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateRdd.filter(visit =>
      (
        wasAssessmentNotPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Fall_Risk_Assessment_Medical_Reason, 12, patientHistoryBroadcastList)
          || wasAssessmentNotPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Patient_Not_Ambulatory, 12, patientHistoryBroadcastList)
          || wasAssessmentNotPerformedInXMonths(visit, m, AdminElements.Encounter_Date, QPP154Elements.Patient_Not_Ambulatory_Kywrd, 12, patientHistoryBroadcastList)
        ))
  }

}
