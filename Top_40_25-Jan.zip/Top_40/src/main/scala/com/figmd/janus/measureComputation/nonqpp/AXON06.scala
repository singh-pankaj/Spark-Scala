
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AXON06
* Measure Title               :- Parkinson's: Querying About Symptoms of Autonomic Dysfunction for Patients with Parkinson’s Disease With Follow-Up
* Measure Description         :- Percentage of all patients with a diagnosis of PD (or caregivers, as appropriate) who
*                                were queried about symptoms of autonomic dysfunction* in the past 12 months and if autonomic
 *                               dysfunction identified had appropriate follow-up.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- NA
* Measure Developer           :- Aanchal.Rai
* Initial GIT Version/Tag(CRA):- 1.7
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object AXON06 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "AXON06"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,Axon06Elements.Symptoms_Of_Autonomic_Dysfunction_Present
      ,Axon06Elements.Follow_Up
      ,Axon06Elements.Autonomic_Dysfunction_Present
      ,Axon06Elements.Querying_About_Symptoms_Of_Autonomic_Dysfunction
      ,Axon06Elements.Present
      ,Axon06Elements.Absent
      ,Axon06Elements.Absence_Of_Autonomic_Dysfunction
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//IPP
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
     isDiagnosedDuringEncounter(visit, m, Axon06Elements.Parkinson_s_Disease)
     &&
     isVisitTypeIn(visit, m,Axon06Elements.Evaluation_And_Management,Axon06Elements.Nursing_Facility_Visit,Axon06Elements.Outpatient_Consultation,Axon06Elements.Home_Healthcare_Services,
                   Axon06Elements.Care_Services_In_Long_Term_Residential_Facility,Axon06Elements.Office_Visit)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//Numerator
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
     (   wasAssessmentPerformedBeforeEncounterInXMonths(visit, m, Axon06Elements.Symptoms_Of_Autonomic_Dysfunction_Present, 12, patientHistoryBroadcastList)
         &&
         wasInterventionPerformedAfterAssessment(visit,m,Axon06Elements.Follow_Up,patientHistoryBroadcastList,Axon06Elements.Symptoms_Of_Autonomic_Dysfunction_Present)
         &&
         wasInterventionPerformedBeforeEncounterWithinXMonths(visit,m,Axon06Elements.Follow_Up,12,patientHistoryBroadcastList)
     )
      ||
     (   wasAssessmentPerformedBeforeEncounterInXMonths(visit, m, Axon06Elements.Autonomic_Dysfunction_Present, 12, patientHistoryBroadcastList)
         &&
         wasInterventionPerformedAfterAssessment(visit,m,Axon06Elements.Follow_Up,patientHistoryBroadcastList,Axon06Elements.Autonomic_Dysfunction_Present)
         &&
         wasInterventionPerformedBeforeEncounterWithinXMonths(visit,m,Axon06Elements.Follow_Up,12,patientHistoryBroadcastList)
     )
      ||
     (   wasAssessmentPerformedBeforeEncounterInXMonthswithresult(visit,m,Axon06Elements.Querying_About_Symptoms_Of_Autonomic_Dysfunction,12, Axon06Elements.Present,patientHistoryBroadcastList)
         &&
         wasInterventionPerformedAfterAssessmentWithResult(visit, m, Axon06Elements.Follow_Up,Axon06Elements.Present,Axon06Elements.Querying_About_Symptoms_Of_Autonomic_Dysfunction,patientHistoryBroadcastList)
         &&
         wasInterventionPerformedBeforeEncounterWithinXMonths(visit,m,Axon06Elements.Follow_Up,12,patientHistoryBroadcastList)
      )
      ||
       wasAssessmentPerformedBeforeEncounterInXMonthswithresult(visit,m,Axon06Elements.Querying_About_Symptoms_Of_Autonomic_Dysfunction,12,Axon06Elements.Absent,patientHistoryBroadcastList)
      ||
       wasAssessmentPerformedBeforeEncounterInXMonths(visit, m, Axon06Elements.Absence_Of_Autonomic_Dysfunction, 12, patientHistoryBroadcastList)
    )
  }

}
