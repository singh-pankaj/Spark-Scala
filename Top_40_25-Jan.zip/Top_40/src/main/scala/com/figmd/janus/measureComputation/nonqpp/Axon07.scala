import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Axon 07
* Measure Title               :- Falls: Falls screening (aggregation of AAN disease specific falls measures)
* Measure Description         :- Percentage of patients with Parkinson’s disease, multiple sclerosis, distal symmetric
*                                polyneuropathy, ALS, epilepsy, dementia who were screened for falls at least annually
*                                and counseling provided on falls prevention for those with 2 or more falls or 1 fall with injury.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- Rishikesh Patil
* Initial GIT Version/Tag(CRA):- 1.8
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object Axon07 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Axon07"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , Axon07Elements.Falls_Screening
      , Axon07Elements.Two_Or_More_Falls_Or_1_Fall_With_Injury
      , Axon07Elements.One_Fall_Or_No_Fall
      , Axon07Elements.Unable_To_Respond
      , Axon07Elements.Cognitive_Impairment_1
      , Axon07Elements.Patient_Not_Ambulatory
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  //IPP Criteria
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>

      isVisitTypeIn(visit, m
        , Axon07Elements.Care_Services_In_Long_Term_Residential_Facility
        , Axon07Elements.Home_Healthcare_Services
        , Axon07Elements.Nursing_Facility_Visit
        , Axon07Elements.Outpatient_Consultation
        , Axon07Elements.Evaluation_And_Management_Physician_Visit
        , Axon07Elements.Home_Care_Visit
        , Axon07Elements.Physical_Examination
        , Axon07Elements.Office_Visit
      )
    &&
        (
          isDiagnosedDuringEncounter(visit, m, Axon07Elements.Multiple_Sclerosis)
          ||
          isDiagnosedDuringEncounter(visit, m, Axon07Elements.Parkinson_s_Disease)
          ||
          isDiagnosedDuringEncounter(visit, m, Axon07Elements.Epilepsy)
          ||
          isDiagnosedDuringEncounter(visit, m, Axon07Elements.Distal_Symmetric_Polyneuropathy)
          ||
          isDiagnosedDuringEncounter(visit, m, Axon07Elements.Dementia)
          ||
          isDiagnosedDuringEncounter(visit, m, Axon07Elements.Amyotrophic_Lateral_Sclerosis)
        )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  //Numerator Criteria
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
    (
      isAssessmentPerformedWithResultDuringEncounter(visit, m, Axon07Elements.Falls_Screening, Axon07Elements.Two_Or_More_Falls_Or_1_Fall_With_Injury)
      &&
      isInterventionPerformedDuringEncounter(visit, m, Axon07Elements.Counseling_For_Falls)
    )
      ||
      isAssessmentPerformedWithResultDuringEncounter(visit, m, Axon07Elements.Falls_Screening, Axon07Elements.One_Fall_Or_No_Fall)
      ||
      isAssessmentPerformedDuringEncounter(visit, m, Axon07Elements.Query_For_Falls)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

  -----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      (
        isPatientCharacteristicDuringEncounter(visit, m, Axon07Elements.Unable_To_Respond)
        &&
        isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, Axon07Elements.Informant_Unavailable)
      )
      ||
      (
       wasPatientCharacteristicInHistory(visit, m, Axon07Elements.Unable_To_Respond, patientHistoryBroadcastList)
       &&
       wasDiagnosisInHistory(visit, m, Axon07Elements.Cognitive_Impairment_1, patientHistoryBroadcastList)
      )
      ||
      wasPatientCharacteristicInHistory(visit, m, Axon07Elements.Patient_Not_Ambulatory, patientHistoryBroadcastList)
      ||
      isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, Axon07Elements.Patient_Declines)
      ||
      isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, Axon07Elements.Patient_Declined)
    )
  }
}