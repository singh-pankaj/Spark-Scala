package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CAP3_2
* Measure Title              :- Cancer Protocol and Turnaround Time for Invasive Carcinoma of Renal Tubular Origin
* Measure Description        :- Percentage of all eligible kidney resections specimens:
                                Partial Nephrectomy
                                Total Nephrectomy
                                Radical Nephrectomy
                                for which all required data elements of the Cancer Protocol are included
                                AND meet the maximum 4 business day turnaround time (TAT) requirement (Report Date – Accession Date ≤ 4 business days).
*
* Calculation Implementation :- visit-specific (procedure-specific)
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 2
* Measure Stratification     :- NA
* The overall performance score is a weighted average of: (Performance 1 x 70%)+(Performance 2 x 30%)
* Measure Developer          :- Priyanka Sawant
----------------------------------------------------------------------------------------------------------------------------*/
object CAP3_2 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "CAP3_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      CAP3Elements.Surgical_Pathology_Accession_Number
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

     if(checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // denominator RDD
      val denominatorRDD = ippRDD
       denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRDD(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMetRDD(intermediateA, patientHistoryList)
      metRDD.cache()

      // val exceptionRDD = getExceptionRDD(intermediateB, patientHistoryList)
      // exceptionRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }
  }
  /*-------------------------------------------------------------------------------------------------------------------------
 All final pathology reports for eligible kidney resection cases that require the use of a CAP cancer protocol.
 CPT®: 88307
 AND
 Any of the ICD 10 codes:
 C64: malignant neoplasm of kidney, except renal pelvis
 C64.1: malignant neoplasm of right kidney, except renal pelvis
 C64.2: malignant neoplasm of left kidney, except renal pelvis
 C64.9: malignant neoplasm of unspecified kidney, except renal pelvis
  * ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      wasProcedurePerformedInHistory(visit,m,CAP3Elements.Surgical_Pathology_Accession_Number,patientHistoryList)
        &&  wasDiagnosisBeforeorEqualEncounter(visit, m, CAP3Elements.Confirm_Renal_Tubular_Carcinoma_Resection_Date, CAP2Elements.Surgical_Pathology_Accession_Number, patientHistoryList)
    )
  }
  /*-------------------------------------------------------------------------------------------------------------------------
1.Biopsy procedures
2.Wilms tumors
3.Tumors of urothelial origin
Lymphoma and Sarcoma
* ----------------------------------------------------------------------------------------------------------------------------*/
  def getExclusionRDD(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
            isLaboratoryTestConcurrent(visit,m,CAP3Elements.Biopsy_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
        ||  isDiagnosedConcurrentWith(visit,m,CAP3Elements.Lymphoma_And_Sarcoma_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
        ||  isDiagnosedConcurrentWith(visit,m,CAP3Elements.Urothelial_And_Wilms_Tumor_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
        ||  isLaboratoryTestConcurrent(visit,m,CAP3Elements.Biopsy_Or_Lymphoma_Or_Wilms_Tumor_Date,CAP3Elements.Surgical_Pathology_Accession_Number_Date)
    )
  }
  /*-------------------------------------------------------------------------------------------------------------------------
Rate 2: Final pathology report in the laboratory/hospital information system with result verified and reported by the laboratory, available to the requesting physician(s) within 4 business days.
* ----------------------------------------------------------------------------------------------------------------------------*/
  def getMetRDD(intermediateA: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    //AND: "Laboratory Test, Order: Specimen Verification Date" <= 4 day(s) starts after start of "Laboratory Test, Order: Specimen Accession Date"
    intermediateA.filter(visit =>
      isLaboratoryTestOrderedAfterWithinXBusinessDays(visit,m,CAP3Elements.Specimen_Accession_Date,CAP3Elements.Specimen_Verification_Date,4,patientHistoryList)
    )
  }
}