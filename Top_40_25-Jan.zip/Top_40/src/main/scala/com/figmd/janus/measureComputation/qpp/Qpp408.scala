package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Qpp408
* Measure Title               :- Opioid Therapy Follow-up Evaluation
* Measure Description         :- All patients 18 and older prescribed opiates for longer than six weeks duration who had a follow-up
                                 evaluation conducted at least every three months during Opioid Therapy documented in the medical record.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.7
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.7
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp408 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp408"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
              ,QPP408Elements.Opioid_Medication
              ,QPP408Elements.Opiates_Prescribed
              ,QPP408Elements.Hospice_Services
              ,QPP408Elements.Hospice_Care
              ,QPP408Elements.Hospice_Services_Snomedct
              ,QPP408Elements.Opioid_Therapy_Follow_Up
              ,QPP408Elements.Opioid_Evaluation
              ,QPP408Elements.Adherence_To_Prescribed_Therapies
              ,QPP408Elements.Presence_Of_Adverse_Events
              ,QPP408Elements.Progress_Toward_Achieving_Therapeutic_Goals
              ,QPP408Elements.Documentation_Of_Level_Of_Functioning
              ,QPP408Elements.Documentation_Of_Pain_Intensity
              ,QPP408Elements.Opioid_Therapy_Follow_Up_Not_Met
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(sparkSession,initialRDD, patientHistoryBroadcastList,patientHistoryRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients 18 and older prescribed opiates for longer than six weeks durationAll patients 18 an
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(sparkSession: SparkSession,initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],patientHistoryRDD:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    val MedicationList:List[(String,String)] = List((QPP408Elements.Opioid_Medication,QPP408Elements.Opioid_Medication_End_Date))

    val MedicationResult=cumulative(patientHistoryRDD, m,MedicationList,CalenderUnit.WEEK,CalenderUnit.MONTH,9,TimeOperator.AFTER)

    val MedicationResultBroadcastList: Broadcast[List[(String,String,Double)]] = sparkSession.sparkContext.broadcast(MedicationResult)

    initialRDD.filter(
      visit =>
              isPatientAdult(visit,m)
          &&  isVisitTypeIn(visit,m
                  ,QPP408Elements.Office_Visit
                  ,QPP408Elements.Nursing_Facility_Visit
                  ,QPP408Elements.Care_Services_In_Long_Term_Residential_Facility
                  ,QPP408Elements.Home_Healthcare_Services)
          && getCommulativeResult(visit,m,QPP408Elements.Opioid_Medication,6,CompareOperator.GREATER,MedicationResultBroadcastList)
          &&  ! isTeleHealthModifier(visit,m
                  ,QPP408Elements.Office_Visit_Telehealth_Modifier
                  ,QPP408Elements.Nursing_Facility_Visit_Telehealth_Modifier
                  ,QPP408Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
                  ,QPP408Elements.Home_Healthcare_Services_Telehealth_Modifier)
          && isPOSEncounterNotPerformed(visit,m,QPP408Elements.Pos_02)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who were in hospice at any time during the performance period.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
            isProcedurePerformed(visit,m,QPP408Elements.Hospice_Services,patientHistoryBroadcastList)
        ||  wasProcedurePerformedInHistory(visit,m,QPP408Elements.Hospice_Care,patientHistoryBroadcastList)
        ||  wasProcedurePerformedInHistory(visit,m,QPP408Elements.Hospice_Services_Snomedct,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who had a follow-up evaluation conducted at least every three months during opioid therapy
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (  isInterventionPerformed(visit,m,QPP408Elements.Opioid_Therapy_Follow_Up,patientHistoryBroadcastList)
        ||  isInterventionPerformed(visit,m,QPP408Elements.Opioid_Evaluation,patientHistoryBroadcastList)
        ||  (    wasAssessmentPerformedAfterMedicationWithInXMonths(visit,m,QPP408Elements.Opioid_Medication,QPP408Elements.Adherence_To_Prescribed_Therapies,3,patientHistoryBroadcastList)
              && wasAssessmentPerformedAfterMedicationWithInXMonths(visit,m,QPP408Elements.Opioid_Medication,QPP408Elements.Presence_Of_Adverse_Events,3,patientHistoryBroadcastList)
              && wasAssessmentPerformedAfterMedicationWithInXMonths(visit,m,QPP408Elements.Opioid_Medication,QPP408Elements.Progress_Toward_Achieving_Therapeutic_Goals,3,patientHistoryBroadcastList)
              && wasAssessmentPerformedAfterMedicationWithInXMonths(visit,m,QPP408Elements.Opioid_Medication,QPP408Elements.Documentation_Of_Level_Of_Functioning,3,patientHistoryBroadcastList)
              && wasAssessmentPerformedAfterMedicationWithInXMonths(visit,m,QPP408Elements.Opioid_Medication,QPP408Elements.Documentation_Of_Pain_Intensity,3,patientHistoryBroadcastList)
            )
      )
        && ! isInterventionPerformed(visit,m,QPP408Elements.Opioid_Therapy_Follow_Up_Not_Met,patientHistoryBroadcastList)
    )
  }

}