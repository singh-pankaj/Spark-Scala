package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 250
* Measure Title              :- Radical Prostatectomy Pathology Reporting
* Measure Description        :- Percentage of radical prostatectomy pathology reports that include the pT category,
                                the pN category, the Gleason score and a statement about margin status
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp250 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp250"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,QPP250Elements.Malignant_Neoplasm_Of_Prostate).collect.toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Exclusion
      val exclusionRDD = getExclusion(ippRDD)
      exclusionRDD.cache()

      val intermediateNumerator = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateNumerator.cache()

      // Filter Met
      val metRDD = getMet(intermediateNumerator)
      metRDD.cache()

      // Filter Intermediate
      val intermediateException = getSubtractRDD(intermediateNumerator, metRDD)
      intermediateException.cache()

      // Filter Exclusion
      val exceptionRDD = getExceptionRdd(intermediateException)
      exceptionRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }

  /*--------------------------------------------------------------------------------------------------------------------
    All radical prostatectomy surgical pathology examinations performed during the measurement period for prostate cancer patients
   -------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isDiagnosedWithBeforeOrEqual(visit, m, QPP250Elements.Surgical_Pathology_Exam, patientHistoryBroadcastList, QPP250Elements.Malignant_Neoplasm_Of_Prostate)
        && isLaboratoryTestOrderDuringEncounter(visit, m, QPP250Elements.Surgical_Pathology_Exam)

    )

  }

  /*--------------------------------------------------------------------------------------------------------------------
 	Specimen site other than anatomic location of prostate
 -------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>

      isLaboratoryTestOrderDuringEncounter(visit, m, QPP250Elements.Non_Prostate_Specimen_Site)
        && isLaboratoryTestOrderDuringEncounter(visit, m, QPP250Elements.Specimen_Site)
    )

  }

  /*--------------------------------------------------------------------------------------------------------------------
   Radical Prostatectomy reports that include the pT category, the pN category, Gleason score and a statement
   about margin status
   -------------------------------------------------------------------------------------------------------------------*/


  def getMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        isLaboratoryTestOrderDuringEncounter(visit, m, QPP250Elements.Appropriate_Documentation__Prostate_Cancer_)
          || (
          isLaboratoryTestOrderDuringEncounter(visit, m, QPP250Elements.Documentation_Of_Pn_Category)
            && isLaboratoryTestOrderDuringEncounter(visit, m, QPP250Elements.Documentation_Of_Pt_Category)
            && isLaboratoryTestOrderDuringEncounter(visit, m, QPP250Elements.Gleason_Score)
            && isLaboratoryTestOrderDuringEncounter(visit, m, QPP250Elements.Statement_About_Margin_Status)
          )
          || isLaboratoryTestOrderDuringEncounter(visit, m, QPP250Elements.Prostate_Cancer_Documentation)
        )
        && !isLaboratoryTestOrderDuringEncounter(visit, m, QPP250Elements.Appropriate_Doc__Prostate_Cancer__Reason_Not_Specified)
    )

  }


  /*--------------------------------------------------------------------------------------------------------------------
  Documentation of medical reason(s) for not including pT category, pN category, Gleason score and statement about
  margin status in the pathology report (e.g., specimen originated from other malignant neoplasms, transurethral
  resections of the prostate (TURP), or secondary site prostatic carcinomas)
   -------------------------------------------------------------------------------------------------------------------*/


  def getExceptionRdd(intermediateException: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      isLaboratoryTestOrderDuringEncounter(visit, m, QPP250Elements.Appropriate_Doc__Prostate_Cancer__Medical_Reason)
        || isProcedurePerformedDuringEncounter(visit, m, QPP250Elements.Transurethral_Resections_Of_The_Prostate)
        || isDiagnosedOnEncounter(visit, m, QPP250Elements.Secondary_Site_Prostatic_Carcinomas)
        || isDiagnosticStudyOnEncounter(visit, m, QPP250Elements.Specimen_Originated_From_Other_Malignant_Neoplasms)
    )
  }

}






