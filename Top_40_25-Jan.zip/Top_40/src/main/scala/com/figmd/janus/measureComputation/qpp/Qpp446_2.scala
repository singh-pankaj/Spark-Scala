package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP446Elements, CalenderUnit}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 446
* Measure Title              :- Operative Mortality Stratified by the Five STS-EACTS Mortality Categories
* Measure Description        :- Percent of patients undergoing index pediatric and/or congenital heart surgery who die,
                                 including both 1) all deaths occurring during the hospitalization in which the procedure was performed,
                                 even if after 30 days (including patients transferred to other acute care facilities), and 2) those
                                 deaths occurring after discharge from the hospital, but within 30 days of the procedure, stratified by the
                                 five STAT Mortality Levels, a multi-institutional validated complexity stratification tool.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 2
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp446_2 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp446_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP446Elements.Sts_Eacts
      , QPP446Elements.Patient_Died
      , QPP446Elements.Cardiac_Operations_Sts
      , QPP446Elements.Discharge
      , QPP446Elements.Death_Post_Procedure
      , QPP446Elements.Death_Post_Procedure_Not_Met
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    // Filter Exclusions

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()


      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  /*----------------------------------------------------------------------------------------------------------------
  * This measure is procedure specific and calculation on active procedure so we have checked only those procedure
  * are active ie. ipp checked on encounterdate
  ----------------------------------------------------------------------------------------------------------------*/


  /*--------------------------------------------------------------------------------------------------------------------
  Reporting Criteria 2 : Patients who undergo pediatric and/or congenital heart surgery that experience death 30 days post procedure
  --------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      (
        isDiagnosedOnEncounter(visit, m, QPP446Elements.Atrial_Septal_Defect)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Ventricular_Septal_Defect)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Atrioventricular_Canal_Defect)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Aortopulmonary_Window)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Truncus_Arteriosus)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Partial_Anomalous_Pulmonary_Venous_Connection)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Total_Anomalous_Pulmonary_Venous_Connection)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Cor_Tritriatum)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Pulmonary_Venous_Stenosis)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Tetralogy_Of_Fallot)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Pulmonary_Atresia)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Tricuspid_Valve_Disease_And_Ebstein_s_Anomaly)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Right_Ventricular_Outflow_Tract__Rvot__Obstruction_And_Or_Pulmonary_Stenosis)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Pulmonary_Valve_Disease)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Aortic_Valve_Disease)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Sinus_Of_Valsalva_Fistula_Aneurysm)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Left_Ventricular_To_Aorta_Tunnel)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Mitral_Valve_Disease)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Hypoplastic_Left_Heart_Syndrome)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Shone_s_Syndrome)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Single_Ventricle)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Congenitally_Correction_Of_The_Great_Arteries__Tga_)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Transposition_Of_The_Great_Arteries)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Double_Outlet_Right_Ventricle)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Double_Outlet_Left_Ventricle)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Coarctation_Of_Aorta_And_Aortic_Arch_Hypoplasia)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Coronary_Artery_Anomalies)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Interrupted_Arch)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Patent_Ductus_Arteriosus)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Vascular_Rings_And_Slings)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Aortic_Aneurysm)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Tracheal_Disorder)
          || isDiagnosedOnEncounter(visit, m, QPP446Elements.Pectus_Excavatum)
        )
        && isProcedurePerformedDuringEncounter(visit, m, QPP446Elements.Cardiac_Operations_Sts)
        && isAssessmentPerformed(visit, m, QPP446Elements.Sts_Eacts, patientHistoryBroadcastList)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------
  NUMERATOR (REPORTING CRITERIA  2):
  Those deaths occurring after discharge from the hospital, but within 30 days of the procedure, stratified by the five
  STAT Mortality Levels, a multi-institutional validated complexity stratification tool
  -------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (
        isPatientExpired(visit, m, QPP446Elements.Death_Post_Procedure, patientHistoryBroadcastList)
          ||
          (
            isPatientExpiredAfterDischarge(visit, m, QPP446Elements.Discharge, patientHistoryBroadcastList, QPP446Elements.Patient_Died)
              && isPatientExpiredAfterProcedureWithInXDays(visit, m, QPP446Elements.Cardiac_Operations_Sts, QPP446Elements.Patient_Died, CalenderUnit.DAY, 30, patientHistoryBroadcastList)

            )

        )
        && !isPatientExpired(visit, m, QPP446Elements.Death_Post_Procedure_Not_Met, patientHistoryBroadcastList)
    )
  }

}
