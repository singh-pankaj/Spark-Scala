package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AAO14Elements, CalenderUnit, CompareOperator, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO14
* Measure Title               :- Bell's Palsy: Inappropriate Use of Antiviral Monotherapy
* Measure Description         :- Percentage of patients age 16 years and older with a diagnosis of new-onset Bell’s palsy
*                                within the past 3 months who were prescribed antiviral therapy without concurrent systemic
*                                steroid therapy for the treatment of Bell’s palsy.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Lower Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.6
----------------------------------------------------------------------------------------------------------------------------*/

object AAO14 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "AAO14"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Patients age 16 years and older with a diagnosis of new onset Bell’s palsy within the past 3 months.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
          isAgeAbove(visit, m, true, 16)
        &&
          isVisitTypeIn(visit, m
            , AAO14Elements.Inpatient_Consultation
            , AAO14Elements.Discharge_Services___Hospital_Inpatient
            , AAO14Elements.Subsequent_Hospital_Care
            , AAO14Elements.Hospital_Inpatient_Visit___Initial
            , AAO14Elements.Discharge_Services__Observation_Care
            , AAO14Elements.Subsequent_Observation_Care
            , AAO14Elements.Hospital_Observation_Care___Initial
            , AAO14Elements.Office_Consultation
            , AAO14Elements.Office_Visit
            , AAO14Elements.Office_Or_Other_Outpatient_Visit
            , AAO14Elements.Nursing_Facility_Visit
          )
        &&
          (
              isDiagnosedWithBeforeOrEqualInMonth(visit, m, AAO14Elements.Inpatient_Consultation, AAO14Elements.Bells_Palsy, 3, patientHistoryBroadcastList)
            ||
              isDiagnosedWithBeforeOrEqualInMonth(visit, m, AAO14Elements.Discharge_Services___Hospital_Inpatient, AAO14Elements.Bells_Palsy, 3, patientHistoryBroadcastList)
            ||
              isDiagnosedWithBeforeOrEqualInMonth(visit, m, AAO14Elements.Subsequent_Hospital_Care, AAO14Elements.Bells_Palsy, 3, patientHistoryBroadcastList)
            ||
              isDiagnosedWithBeforeOrEqualInMonth(visit, m, AAO14Elements.Hospital_Inpatient_Visit___Initial, AAO14Elements.Bells_Palsy, 3, patientHistoryBroadcastList)
            ||
              isDiagnosedWithBeforeOrEqualInMonth(visit, m, AAO14Elements.Discharge_Services__Observation_Care, AAO14Elements.Bells_Palsy, 3, patientHistoryBroadcastList)
            ||
              isDiagnosedWithBeforeOrEqualInMonth(visit, m, AAO14Elements.Subsequent_Observation_Care, AAO14Elements.Bells_Palsy, 3, patientHistoryBroadcastList)
            ||
              isDiagnosedWithBeforeOrEqualInMonth(visit, m, AAO14Elements.Hospital_Observation_Care___Initial, AAO14Elements.Bells_Palsy, 3, patientHistoryBroadcastList)
            ||
              isDiagnosedWithBeforeOrEqualInMonth(visit, m, AAO14Elements.Office_Consultation, AAO14Elements.Bells_Palsy, 3, patientHistoryBroadcastList)
            ||
              isDiagnosedWithBeforeOrEqualInMonth(visit, m, AAO14Elements.Office_Visit, AAO14Elements.Bells_Palsy, 3, patientHistoryBroadcastList)
            ||
              isDiagnosedWithBeforeOrEqualInMonth(visit, m, AAO14Elements.Office_Or_Other_Outpatient_Visit, AAO14Elements.Bells_Palsy, 3, patientHistoryBroadcastList)
            ||
              isDiagnosedWithBeforeOrEqualInMonth(visit, m, AAO14Elements.Nursing_Facility_Visit, AAO14Elements.Bells_Palsy, 3, patientHistoryBroadcastList)
          )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Patients who were prescribed antiviral therapy alone within 3 months of diagnosis without concurrent
    systemic steroid therapy for the treatment of Bell’s palsy.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
          isMedicationOrderedAfterDiagnosisWithInXPeriods(visit, m, AAO14Elements.Antiviral_Therapy, AAO14Elements.Bells_Palsy, CalenderUnit.MONTH, 3, patientHistoryBroadcastList)
      && !
          (
              isMedicationOrderedAfterMedicationWithInXPeriods(visit, m, AAO14Elements.Antiviral_Therapy, AAO14Elements.Systemic_Steroid_Therapy, CalenderUnit.WEEK, 1, patientHistoryBroadcastList)
            ||
              isMedicationOrderedAfterMedicationWithInXPeriods(visit, m, AAO14Elements.Systemic_Steroid_Therapy, AAO14Elements.Antiviral_Therapy, CalenderUnit.WEEK, 1, patientHistoryBroadcastList)
          )
    )
  }

}