package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP364Elements,CalenderUnit}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 364
* Measure Title              :- Optimizing Patient Exposure to Ionizing Radiation: Appropriateness: Follow-up CT Imaging
                                for Incidentally Detected Pulmonary Nodules According to Recommended Guidelines
* Measure Description        :- Percentage of final reports for CT imaging studies with a finding of an incidental
                                pulmonary nodule for patients aged 35 years and older that contain an impression or
                                conclusion that includes a recommended interval and modality for follow-up (e.g., type
                                of imaging or biopsy) or for no follow-up, and source of recommendations (e.g., guidelines such
                                as Fleischner Society, American Lung Association, American College of Chest Physicians).
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp364 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp364"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //eligible RDD
      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate RDD
      val intermediateException = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  /*-----------------------------------------------------------------------------------------
   All final reports for CT imaging studies with a finding of an incidental pulmonary nodule for patients aged 35 years
   and older.
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
         isAgeAbove(visit,m,true,35)
      && isProcedurePerformedDuringEncounter(visit,m,QPP364Elements.Ct_Imaging_Study)
      && isDiagnosedOnEncounter(visit,m,QPP364Elements.Pulmonary_Nodule)
    )
  }

  /*------------------------------------------------------------------------------------------------
   Patients with an active diagnosis or history of cancer (except basal cell and squamous cell skin carcinoma),
   patients who are heavy tobacco smokers, lung cancer screening patients
   ------------------------------------------------------------------------------------------------*/

  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
        wasAssessmentPerformedBeforeOrEqualEncounter(visit,m,QPP364Elements.Lung_Cancer_Screening_Key,patientHistoryBroadcastList)
     || wasAssessmentPerformedBeforeOrEqualEncounter(visit,m,QPP364Elements.Heavy_Tobacco_Smokers,patientHistoryBroadcastList)
     || wasAssessmentPerformedBeforeOrEqualEncounter(visit,m,QPP364Elements.Cancer_Lung_Cancer_Screening_Smoker,patientHistoryBroadcastList)
     || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP364Elements.All_Cancer_Except_Squamous_And_Basal_Cell_Carcinoma_Of_Skin,patientHistoryBroadcastList)
    )

  }

  /*------------------------------------------------------------------------------------------------
   Final reports that contain an impression or conclusion that includes a recommended interval and modality for follow-up
   (e.g., type of imaging or biopsy) or for no follow-up, and source of recommendations (e.g., guidelines such as
   Fleischner Society, American Lung Association, American College of Chest Physicians).
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
    (
         isInterventionPerformed(visit,m,QPP364Elements.Follow_Up_Recommendations,patientHistoryBroadcastList)
      ||
           (
               isDiagnosed(visit,m,QPP364Elements.Solid_Non_Calcified_Nodule_1,patientHistoryBroadcastList)
            && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,6,"lt",patientHistoryBroadcastList)
            && isPatientCharacteristic(visit,m,QPP364Elements.Low_Risk,patientHistoryBroadcastList)
            && isDiagnosed(visit,m,QPP364Elements.Grade_1c,patientHistoryBroadcastList)
           )
      ||
           (
                isDiagnosed(visit,m,QPP364Elements.Solid_Non_Calcified_Nodule_1,patientHistoryBroadcastList)
             && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,6,"gt",patientHistoryBroadcastList)
             && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,8,"lt",patientHistoryBroadcastList)
             && isPatientCharacteristic(visit,m,QPP364Elements.Low_Risk,patientHistoryBroadcastList)
             && isDiagnosed(visit,m,QPP364Elements.Grade_1c,patientHistoryBroadcastList)
             && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up,CalenderUnit.MONTH,6,CalenderUnit.MONTH,12,patientHistoryBroadcastList)
           )
      ||
           (
                  isDiagnosed(visit,m,QPP364Elements.Solid_Nodule,patientHistoryBroadcastList)
               && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,6,"lt",patientHistoryBroadcastList)
               && isPatientCharacteristic(visit,m,QPP364Elements.Low_Risk,patientHistoryBroadcastList)
               && isDiagnosed(visit,m,QPP364Elements.Grade_2a,patientHistoryBroadcastList)
               && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up,CalenderUnit.MONTH,6,CalenderUnit.MONTH,12,patientHistoryBroadcastList)
             )
      ||
           (
                isDiagnosed(visit,m,QPP364Elements.Solid_Non_Calcified_Nodule_1,patientHistoryBroadcastList)
             && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,6,"gt",patientHistoryBroadcastList)
             && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,8,"lt",patientHistoryBroadcastList)
             && isPatientCharacteristic(visit,m,QPP364Elements.Low_Risk,patientHistoryBroadcastList)
             && isDiagnosed(visit,m,QPP364Elements.Grade_1b,patientHistoryBroadcastList)
             && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up_Occurrence_A,CalenderUnit.MONTH,6,CalenderUnit.MONTH,12,patientHistoryBroadcastList)
             && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up_Occurrence_B,CalenderUnit.MONTH,18,CalenderUnit.MONTH,24,patientHistoryBroadcastList)
           )
      ||
           (
                  isDiagnosed(visit,m,QPP364Elements.Solid_Non_Calcified_Nodule_1,patientHistoryBroadcastList)
               && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,8,"gt",patientHistoryBroadcastList)
               && isDiagnosed(visit,m,QPP364Elements.Grade_1b,patientHistoryBroadcastList)
               &&
                    (
                      (
                         isDiagnosticStudyPerformed(visit,m,QPP364Elements.Positron_Emission_Tomography__Pet_,patientHistoryBroadcastList)
                      && isDiagnosticStudyPerformed(visit,m,QPP364Elements.Ct_Imaging_Study,patientHistoryBroadcastList)
                        )
                     || (
                        (
                              isDiagnosticStudyPerformed(visit,m,QPP364Elements.Positron_Emission_Tomography__Pet_,patientHistoryBroadcastList)
                            && isDiagnosticStudyPerformed(visit,m,QPP364Elements.Ct_Imaging_Study,patientHistoryBroadcastList)
                        )
                       || isAssessmentPerformed(visit,m,QPP364Elements.Lung_Biopsy,patientHistoryBroadcastList)
                      )
                    )

               && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up_Occurrence_A,CalenderUnit.MONTH,3,CalenderUnit.MONTH,4,patientHistoryBroadcastList)

             )
      ||
           (
                  isDiagnosed(visit,m,QPP364Elements.Multiple_Solid_Non_Calcified_Nodule,patientHistoryBroadcastList)
               && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,6,"lt",patientHistoryBroadcastList)
               && isDiagnosed(visit,m,QPP364Elements.Grade_2b,patientHistoryBroadcastList)
            )
      ||
           (
                  isDiagnosed(visit,m,QPP364Elements.Pure_Ground_Glass_Nodules,patientHistoryBroadcastList)
               && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,6,"ge",patientHistoryBroadcastList)
               && isDiagnosed(visit,m,QPP364Elements.Grade_1b,patientHistoryBroadcastList)
               && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up_Occurrence_B,CalenderUnit.MONTH,18,CalenderUnit.MONTH,24,patientHistoryBroadcastList)
               &&
                  (
                       isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Ct_Imaging_Study,QPP364Elements.Follow_Up_Occurrence_B,"EQUAL",patientHistoryBroadcastList)
                    || isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Positron_Emission_Tomography__Pet_,QPP364Elements.Follow_Up_Occurrence_B,"EQUAL",patientHistoryBroadcastList)
                  )

           )
      ||
           (
                  isDiagnosed(visit,m,QPP364Elements.Solitary_Pure_Ground_Glass_Nodule,patientHistoryBroadcastList)
               && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,6,"lt",patientHistoryBroadcastList)
               && isDiagnosed(visit,m,QPP364Elements.Grade_1b,patientHistoryBroadcastList)
           )
      ||
           (
                  isDiagnosed(visit,m,QPP364Elements.Pure_Ground_Glass_Nodules,patientHistoryBroadcastList)
               && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,6,"ge",patientHistoryBroadcastList)
               && isDiagnosed(visit,m,QPP364Elements.Grade_1b,patientHistoryBroadcastList)
               && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up_Occurrence_A,CalenderUnit.MONTH,3,CalenderUnit.MONTH,6,patientHistoryBroadcastList)
               && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up_Occurrence_B,CalenderUnit.MONTH,18,CalenderUnit.MONTH,24,patientHistoryBroadcastList)
               &&

                 (
                        isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Ct_Imaging_Study,QPP364Elements.Follow_Up_Occurrence_B,"EQUAL",patientHistoryBroadcastList)
                     || isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Positron_Emission_Tomography__Pet_,QPP364Elements.Follow_Up_Occurrence_B,"EQUAL",patientHistoryBroadcastList)
                   )
               &&
                   (
                          isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Ct_Imaging_Study,QPP364Elements.Follow_Up_Occurrence_C,"EQUAL",patientHistoryBroadcastList)
                       || isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Positron_Emission_Tomography__Pet_,QPP364Elements.Follow_Up_Occurrence_C,"EQUAL",patientHistoryBroadcastList)
                     )

           )
      ||
           (
             isDiagnosed(visit,m,QPP364Elements.Part_Solid_Nodule_1,patientHistoryBroadcastList)
               && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,6,"lt",patientHistoryBroadcastList)
               && isDiagnosed(visit,m,QPP364Elements.Grade_1c,patientHistoryBroadcastList)
             )
      ||
           (
                  isDiagnosed(visit,m,QPP364Elements.Part_Solid_Nodule_1,patientHistoryBroadcastList)
               && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,6,"gt",patientHistoryBroadcastList)
               && isPatientCharacteristic(visit,m,QPP364Elements.High_Risk,patientHistoryBroadcastList)
               && isDiagnosed(visit,m,QPP364Elements.Grade_1b,patientHistoryBroadcastList)
               && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up_Occurrence_A,CalenderUnit.MONTH,6,CalenderUnit.MONTH,12,patientHistoryBroadcastList)
               && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up_Occurrence_B,CalenderUnit.YEAR,3,CalenderUnit.YEAR,4,patientHistoryBroadcastList)
               && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up_Occurrence_C,CalenderUnit.YEAR,5,CalenderUnit.YEAR,6,patientHistoryBroadcastList)
               && isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Ct_Imaging_Study,QPP364Elements.Follow_Up_Occurrence_A,"EQUAL",patientHistoryBroadcastList)
             )
      ||
           (
                  isDiagnosed(visit,m,QPP364Elements.Part_Solid_Nodule_1,patientHistoryBroadcastList)
               && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,8,"gt",patientHistoryBroadcastList)
               && isDiagnosed(visit,m,QPP364Elements.Grade_1b,patientHistoryBroadcastList)
               && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up_Occurrence_A,CalenderUnit.MONTH,3,CalenderUnit.MONTH,6,patientHistoryBroadcastList)

              &&
                    (
                        isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Ct_Imaging_Study,QPP364Elements.Follow_Up_Occurrence_A,"EQUAL",patientHistoryBroadcastList)
                     || isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Positron_Emission_Tomography__Pet_,QPP364Elements.Follow_Up_Occurrence_A,"EQUAL",patientHistoryBroadcastList)
                     || isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Lung_Biopsy,QPP364Elements.Follow_Up_Occurrence_A,"EQUAL",patientHistoryBroadcastList)
                     || isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Lung_Resection,QPP364Elements.Follow_Up_Occurrence_A,"EQUAL",patientHistoryBroadcastList)
                    )
             )
      ||
           (
                  isDiagnosed(visit,m,QPP364Elements.Multiple_Sub_Solid_Lung_Nodule,patientHistoryBroadcastList)
               && wasDiagnosticStudyPerformedWithValue(visit,m,QPP364Elements.Nodule_Size,6,"lt",patientHistoryBroadcastList)
               && isDiagnosed(visit,m,QPP364Elements.Grade_1c,patientHistoryBroadcastList)
               && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up_Occurrence_A,CalenderUnit.MONTH,6,CalenderUnit.MONTH,12,patientHistoryBroadcastList)
               && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up_Occurrence_B,CalenderUnit.YEAR,3,CalenderUnit.YEAR,4,patientHistoryBroadcastList)
               && wasCarePlanAfterDiagnosisInBetweenXPeriodes(visit,m,QPP364Elements.Pulmonary_Nodule ,QPP364Elements.Follow_Up_Occurrence_C,CalenderUnit.YEAR,5,CalenderUnit.YEAR,6,patientHistoryBroadcastList)
               &&
                    (
                           isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Ct_Imaging_Study,QPP364Elements.Follow_Up_Occurrence_B,"EQUAL",patientHistoryBroadcastList)
                        || isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Positron_Emission_Tomography__Pet_,QPP364Elements.Follow_Up_Occurrence_B,"EQUAL",patientHistoryBroadcastList)
                      )
                &&
                    (
                           isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Ct_Imaging_Study,QPP364Elements.Follow_Up_Occurrence_C,"EQUAL",patientHistoryBroadcastList)
                        || isDiagnosticStudyDuringCarePlanInHistory(visit,m,QPP364Elements.Positron_Emission_Tomography__Pet_,QPP364Elements.Follow_Up_Occurrence_C,"EQUAL",patientHistoryBroadcastList)
                      )
           )
    )
   && !isInterventionPerformed(visit,m,QPP364Elements.Follow_Up_Reason_Not_Specified,patientHistoryBroadcastList)
    )

  }

  /*-----------------------------------------------------------------------------------------------------------------
    	Documentation of medical reason(s) for not including a recommended interval and modality for follow-up or for no
    	follow-up, and source of recommendations (e.g., patients with unexplained fever, immunocompromised patients who
    	are at risk for infection)
   -----------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermediateException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow]  = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateException.filter(visit =>
         isInterventionPerformed(visit,m,QPP364Elements.Follow_Up_Medical_Reason,patientHistoryBroadcastList)
      || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP364Elements.Malignancy_Metastasize,patientHistoryBroadcastList)
      || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP364Elements.Immunocompromised_Conditions,patientHistoryBroadcastList)
      || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP364Elements.Unexplained_Fever,patientHistoryBroadcastList)
    )

  }

}
