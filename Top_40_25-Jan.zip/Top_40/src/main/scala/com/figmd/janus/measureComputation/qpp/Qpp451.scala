package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP451Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp451
* Measure Title              :- RAS (KRAS and NRAS) Gene Mutation Testing Performed for Patients with Metastatic Colorectal Cancer
*                               who receive Anti-epidermal Growth Factor Receptor (EGFR) Monoclonal Antibody Therapy
* Measure Description        :- Percentage of adult patients (aged 18 or over) with metastatic colorectal cancer who receive
*                               anti-epidermal growth factor receptor monoclonal antibody therapy for whom RAS (KRAS and NRAS)
*                               gene mutation testing was performed
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Vrushali Gholap
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp451 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp451"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistory: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      , QPP451Elements.Office_Visit
      , QPP451Elements.Colon_Or_Rectum_Cancer
      , QPP451Elements.Metastatic_Disease
      , QPP451Elements.Metastatic_Cancer
      , QPP451Elements.Anti_Egfr_Moab_Therapy
      , QPP451Elements.Egfr_Inhibitor
      , QPP451Elements.Kras_Gene_Mutation__Met
      , QPP451Elements.Kras_Gene_Mutation
      , QPP451Elements.Kras_Gene_Mutation__Not_Met
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistory.collect().toList)

    val mostRecentRDD: List[CassandraRow] = mostRecentPatientList(patientHistory, QPP451Elements.Kras_Gene_Mutation)
    val mostRecentPatienthistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostRecentRDD)


    // Filter IPP
    val ippRDD = getIppRDD(initialRDD, patientHistoryBroadcastList, patientHistory)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      val denominatorRDD=ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMetRDD(denominatorRDD, patientHistoryBroadcastList, mostRecentPatienthistoryList)
      metRDD.cache()

      // Filter Denominator Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not Met

      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()
      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD,exceptionRDD , notMetRDD, MEASURE_NAME)
      mostRecentPatienthistoryList.destroy()
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Adult patients with metastatic colorectal cancer who receive anti-EGFR monoclonal antibody therapy
  ----------------------------------------------------------------------------------------------------------------------------*/
  def getIppRDD(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], patientHistory: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    val countRDD = countElement(patientHistory, m, QPP451Elements.Office_Visit)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && getEncounterCountFromHistory(visit, m, 2, true, countRDD)
        && isDiagnosedWithBeforeOrEqual(visit, m, QPP451Elements.Office_Visit, patientHistoryList, QPP451Elements.Colon_Or_Rectum_Cancer)
        && isDiagnosedWithBeforeOrEqual(visit, m, QPP451Elements.Office_Visit, patientHistoryList, QPP451Elements.Metastatic_Disease
        , QPP451Elements.Metastatic_Cancer)
        && wasMedicationAdministeredAfterDiagnosis(visit, m, QPP451Elements.Colon_Or_Rectum_Cancer_Date, patientHistoryList, QPP451Elements.Anti_Egfr_Moab_Therapy, QPP451Elements.Egfr_Inhibitor)
        && (isMedicationAdministered(visit, m, QPP451Elements.Anti_Egfr_Moab_Therapy, patientHistoryList)
        || isMedicationAdministered(visit, m, QPP451Elements.Egfr_Inhibitor, patientHistoryList)
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
   RAS (KRAS and NRAS) gene mutation testing performed before initiation of anti-EGFR MoAb
   ----------------------------------------------------------------------------------------------------------------------------*/

  def getMetRDD(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], mostRecentPatienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      (isLaboratoryTestPerformed(visit, m, QPP451Elements.Kras_Gene_Mutation__Met, patientHistoryList)
        || wasMostRecentLaboratoryTestPerformedBeforeMedication(visit, m, QPP451Elements.Egfr_Inhibitor, mostRecentPatienthistoryList, QPP451Elements.Kras_Gene_Mutation)
        || wasMostRecentLaboratoryTestPerformedBeforeMedication(visit, m, QPP451Elements.Anti_Egfr_Moab_Therapy, mostRecentPatienthistoryList, QPP451Elements.Kras_Gene_Mutation)
        )
        && !isLaboratoryTestPerformed(visit, m, QPP451Elements.Kras_Gene_Mutation__Not_Met, patientHistoryList)
    )
  }
}
