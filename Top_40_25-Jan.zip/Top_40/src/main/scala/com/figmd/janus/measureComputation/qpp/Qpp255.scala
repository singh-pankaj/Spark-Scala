package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP255Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 255
* Measure Title              :- RH Immunoglobulin (Rhogam) for Rh-Negative Pregnant Women at Risk of Fetal Blood Exposure
* Measure Description        :- Percentage of Rh-negative pregnant women aged 14-50 years at risk of fetal blood exposure who
*                               receive Rh-Immunoglobulin (Rhogam) in the emergency department (ED).
* Calculation Implementation :- Episode-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp255 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp255"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        QPP255Elements.Rh_Immunoglobulin_Ordered
      )

      // val patient_history_list = patient_history_RDD.collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Intermediate A
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA)
      metRDD.cache()

      // Filter Intermediate B
      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      // Filter Denominator Exception
      val exceptionRDD = getException(intermediateB, patientHistoryBroadcastList)
      exceptionRDD.cache()

      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeBetween(visit, m, 14, 51)
        && (
        isFemale(visit, m)
          && isDiagnosedDuringEncounter(visit, m, QPP255Elements.High_Risk_Pregnancy_Complications)
          && isDiagnosedDuringEncounter(visit, m, QPP255Elements.Rh_Negative)
        )
        && isVisitTypeIn(visit, m, QPP255Elements.Emergency_Department_Visit, QPP255Elements.Critical_Care)
        && isEncounterOrderDuringEDOrCCEncounter(visit, m, QPP255Elements.Pos_23, QPP255Elements.Pos_23_Date, AdminElements.Emergency_Visit_Arrival_Date,
        AdminElements.Emergency_Visit_Departure_Date, QPP255Elements.Critical_Care_Date)

    )
  }


  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        isAssessmentDuringEDOrCCEncounter(visit, m, QPP255Elements.Pos_23, QPP255Elements.Rh_Immunoglobulin_Ordered_G, AdminElements.Emergency_Visit_Arrival_Date,
          AdminElements.Emergency_Visit_Departure_Date, QPP255Elements.Critical_Care_Date)
          || isImmunizationDuringEdOrCCEncounter(visit, m, QPP255Elements.Pos_23, QPP255Elements.Rh_Immunoglobulin_Ordered, AdminElements.Emergency_Visit_Arrival_Date,
          AdminElements.Emergency_Visit_Departure_Date, QPP255Elements.Critical_Care_Date)
        )
        && !isAssessmentDuringEDOrCCEncounter(visit, m, QPP255Elements.Pos_23, QPP255Elements.Rh_Order_Reason_Not_Specified, AdminElements.Emergency_Visit_Arrival_Date,
        AdminElements.Emergency_Visit_Departure_Date, QPP255Elements.Critical_Care_Date)
    )
  }


  // Denominator Exception criteria
  def getException(intermediateB: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateB.filter(visit =>
      isAssessmentDuringEDOrCCEncounter(visit, m, QPP255Elements.Pos_23, QPP255Elements.Rh_Order_Patient_Reason, AdminElements.Emergency_Visit_Arrival_Date,
        AdminElements.Emergency_Visit_Departure_Date, QPP255Elements.Critical_Care_Date)
        ||
        isImmunizationBeforeXWeeksEdOrCcEncounter(visit, m, QPP255Elements.Rh_Immunoglobulin_Ordered, AdminElements.Emergency_Visit_Arrival_Date, QPP255Elements.Critical_Care_Date, 12, patientHistoryBroadcastList)
        || isCommunicationDuringEDOrCCEncounter(visit, m, QPP255Elements.Pos_23, QPP255Elements.Patient_Refused, AdminElements.Emergency_Visit_Arrival_Date,
        AdminElements.Emergency_Visit_Departure_Date, QPP255Elements.Critical_Care_Date)
    )
  }
}