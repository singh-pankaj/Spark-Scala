package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP410
* Measure Title              :- Psoriasis: Clinical Response to Systemic Medications
* Measure Description        :- Percentage of psoriasis vulgaris patients receiving systemic medication who meet minimal
*                               physician-or patient reported disease activity levels.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.5
* Latest GIT Version/Tag(CRA) :- 1.6
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp410 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp410"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,QPP410Elements.Office_Visit_Telehealth_Modifier
      ,QPP410Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
      ,QPP410Elements.Home_Healthcare_Services_Telehealth_Modifier
      ,QPP410Elements.Annual_Wellness_Visit_Telehealth_Modifier
      ,QPP410Elements.Outpatient_Consultation_Telehealth_Modifier
      ,QPP410Elements.Pos_02
      ,QPP410Elements.Assessment_Of_Psoriasis_Disease_Activity_Using_Physician_Global_Assessment__Pga_
      ,QPP410Elements.Assessment_Of_Psoriasis_Disease_Activity_Using_Body_Surface_Index__Bsa_
      ,QPP410Elements.Assessment_Of_Psoriasis_Disease_Activity_Using_Psoriasis_Area_And_Severity_Index__Pasi_
      ,QPP410Elements.Assessment_Of_Psoriasis_Disease_Activity_Using_Dermatology_Life_Quality_Index__Dlqi_
      ,QPP410Elements.Systemic_Medications
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
          isDiagnosedOnEncounter(visit, m, QPP410Elements.Plaque_Psoriasis__Psoriasis_Vulgaris_)
        &&
          isVisitTypeIn(visit, m
          , QPP410Elements.Office_Visit
          , QPP410Elements.Care_Services_In_Long_Term_Residential_Facility
          , QPP410Elements.Home_Healthcare_Services
          , QPP410Elements.Annual_Wellness_Visit
          , QPP410Elements.Outpatient_Consultation
        )
        &&
        (
            wasMedicationAdministeredInHistory(visit, m, QPP410Elements.Systemic_Medications, patientHistoryBroadcastList)
          ||
            wasMedicationAdministeredInHistory(visit, m, QPP410Elements.Systemic_Medications_Hcpcs, patientHistoryBroadcastList)
          )
        && !
          isVisitTypeIn(visit, m
          , QPP410Elements.Office_Visit_Telehealth_Modifier
          , QPP410Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
          , QPP410Elements.Home_Healthcare_Services_Telehealth_Modifier
          , QPP410Elements.Annual_Wellness_Visit_Telehealth_Modifier
          , QPP410Elements.Outpatient_Consultation_Telehealth_Modifier
          , QPP410Elements.Pos_02
        )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      (
          isInterventionPerformed(visit, m, QPP410Elements.Psoriasis_Assessment_Using_Tools, patientHistoryBroadcastList)
        ||
          isInterVentionPerformedValue(visit, m, QPP410Elements.Assessment_Of_Psoriasis_Disease_Activity_Using_Physician_Global_Assessment__Pga_, 2, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
        ||
          isInterVentionPerformedValue(visit, m, QPP410Elements.Assessment_Of_Psoriasis_Disease_Activity_Using_Body_Surface_Index__Bsa_, 3, CompareOperator.LESS, patientHistoryBroadcastList)
        ||
          isInterVentionPerformedValue(visit, m, QPP410Elements.Assessment_Of_Psoriasis_Disease_Activity_Using_Psoriasis_Area_And_Severity_Index__Pasi_, 3, CompareOperator.LESS, patientHistoryBroadcastList)
        ||
          isInterVentionPerformedValue(visit, m, QPP410Elements.Assessment_Of_Psoriasis_Disease_Activity_Using_Dermatology_Life_Quality_Index__Dlqi_, 5, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
        )
        && ! isInterventionPerformed(visit, m, QPP410Elements.Assessment_Not_Met, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      (
          isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP410Elements.Psoriasis_Assessment_Patient_Reason)
        ||
          isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, QPP410Elements.Psoriasis_Assessment_Reason)
        ||
          medicationAdverseEffectDuringEncounter(visit, m, QPP410Elements.Psoriasis_Assessment_Medical_Reason)
        ||
          isInterventionPerformedOnEncounter(visit, m, QPP410Elements.Patient_Declined)
        ||
          wasMedicationAdministeredBeforeEncounterInXMonths(visit, m, QPP410Elements.Systemic_Medications_Date, QPP410Elements.Systemic_Medications, 5, patientHistoryBroadcastList)
        ||
          isMedicationGapLessThanXWeeks(visit, m, QPP410Elements.Systemic_Medications_Date, QPP410Elements.Oral_Systemics_Or_Biologics_Stop_Date, CalenderUnit.MONTH, 6, 28, patientHistoryBroadcastList)
      )
    )
  }


}