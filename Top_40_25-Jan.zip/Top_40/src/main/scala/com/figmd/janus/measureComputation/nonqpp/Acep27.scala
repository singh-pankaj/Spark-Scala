package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ACEP27Elements, AdminElements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Acep27
* Measure Title              :- Sepsis Management: Septic Shock: Antibiotics Ordered
* Measure Description        :- Percentage of emergency department visits for patients aged 18 years and older with septic shock who had an order for antibiotics during the emergency department visit
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Acep27 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Acep27"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      AdminElements.Emergency_Visit_Arrival_Date,
      AdminElements.Emergency_Visit_Departure_Date,
      ACEP27Elements.Critical_Care_Evaluation_And_Management_Date,
      ACEP27Elements.Acute_Care_Or_Inpatient_Facility
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //filter denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA)
      metRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()

    }
  }

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        /*&& isEDorCCEncounterPerformed(visit, m, patientHistoryList, AdminElements.Emergency_Visit_Arrival_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management)
        && (isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP27Elements.Septic_Shock, ACEP27Elements.Septic_Shock_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
        || (isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP27Elements.Sepsis, ACEP27Elements.Sepsis_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
        && isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP27Elements.Acute_Hypotension, ACEP27Elements.Acute_Hypotension_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
        )
        ||
        ( wasDiagnosedBeforeEDOrCCEncounter(visit, m, ACEP27Elements.Infection, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date, patientHistoryList)
          && isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP27Elements.Acute_Hypotension, ACEP27Elements.Acute_Hypotension_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
          )
        )*/
    )
  }


  def getExclusion(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>

      wasPatientTransferedFromAcuteCareWithinXHours(visit, m, ACEP27Elements.Acute_Care_Or_Inpatient_Facility, AdminElements.Emergency_Visit_Arrival_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management, 6, patientHistoryList)
        ||
        (isPatientLeftBeforeTreatmentCompletionOnEDOrCCEncounter(visit, m, ACEP27Elements.Left_Before_Treatment_Completion, ACEP27Elements.Left_Before_Treatment_Completion_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
          || isPatientExpiredOnEDOrCCEncounter(visit, m, ACEP27Elements.Patient_Expired, ACEP27Elements.Patient_Expired_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
          )
        ||
        (
          isInterventionOrderedDuringEDOrCCEncounter(visit, m, ACEP27Elements.Comfort_Measures, ACEP27Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
            || isInterventionPerformedDuringEDOrCCEncounter(visit, m, ACEP27Elements.Comfort_Measures, ACEP27Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
            || isCommunicationFromPatientToProviderDoneDuringEDOrCCEncounter(visit, m, ACEP27Elements.Declined_Sepsis_Care, ACEP27Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP27Elements.Cardiac_Arrest, ACEP27Elements.Cardiac_Arrest_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP27Elements.Second_And_Third_Degree_Burn, ACEP27Elements.Second_And_Third_Degree_Burn_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP27Elements.Seizure, ACEP27Elements.Seizure_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP27Elements.Gastrointestinal_Hemorrhage, ACEP27Elements.Gastrointestinal_Hemorrhage_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP27Elements.Hemorrhagic_Stroke, ACEP27Elements.Hemorrhagic_Stroke_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP27Elements.Ischemic_Stroke, ACEP27Elements.Ischemic_Stroke_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP27Elements.Myocardial_Infarction, ACEP27Elements.Myocardial_Infarction_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP27Elements.Toxicological_Emergency, ACEP27Elements.Toxicological_Emergency_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP27Elements.Trauma, ACEP27Elements.Trauma_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP27Elements.Critical_Care_Evaluation_And_Management_Date)

          )
    )
  }


  def getMet(ippRdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRdd.filter(visit => isLaboratoryTestOrder(visit, m, ACEP27Elements.Iv_Antibiotics_For_Sepsis))

  }

}
