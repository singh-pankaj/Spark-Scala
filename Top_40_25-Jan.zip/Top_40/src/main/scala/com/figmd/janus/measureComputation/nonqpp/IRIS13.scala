package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- IRIS 13
* Measure Title              :- Diabetic Macular Edema - Loss of Visual Acuity
* Measure Description        :- Percentage of patients with a diagnosis of diabetic macular edema with a loss of less than 3 Snellen lines
*                               (which is equivalent to less than 0.3 logMAR) within the past 12 months.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/
object IRIS13 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "IRIS13"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryList = getPatientHistory(sparkSession,initialRDD,
      IRIS13Elements.Visual_Acuity,
      IRIS13Elements.Visual_Acuity_Eye,
      IRIS13Elements.Diabetic_Macular_Edema,
      IRIS13Elements.Diabetic_Macular_Edema_Eye,
      IRIS13Elements.Ophthalmic_Complications_Of_Diabetic_Retinopathy,
      IRIS13Elements.Ophthalmic_Complications_Of_Diabetic_Retinopathy_Eye).collect().toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }
  }

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit => isPatientAdult(visit, m)
              && wasDiagnosedInHistory(visit, m, IRIS13Elements.Diabetic_Macular_Edema, patientHistoryList)
              && (
                    isVisualAcuityPerformedBeforeTreatment(visit,m,IRIS13Elements.Visual_Acuity_Date, patientHistoryList,IRIS13Elements.Anti_Vegf_Agents,IRIS13Elements.Laser_Photocoagulation)
                 && isVisualAcuityPerformedBeforeTreatment(visit,m,IRIS13Elements.Visual_Acuity_Date, patientHistoryList,IRIS13Elements.Intravitreal_Injection,IRIS13Elements.Laser_Photocoagulation)
                 )
      //$Treatment = Union of: (Intersection of: ("Medication, Administered: Anti-VEGF Agents" && "Procedure, Performed: Intravitreal Injection") || "Procedure, Performed: Laser Photocoagulation")
              && (
                    (
                      isMedicationAdministeredOnEncounter(visit,m,IRIS13Elements.Anti_Vegf_Agents)
                   && isProcedurePerformedDuringEncounter(visit,m,IRIS13Elements.Intravitreal_Injection)
                    )
                   ||  isProcedurePerformedDuringEncounter(visit,m,IRIS13Elements.Laser_Photocoagulation)
                 )
              && (
                     isVisualAcuityPerformedAfterTreatment(visit,m,IRIS13Elements.Visual_Acuity, patientHistoryList,IRIS13Elements.Anti_Vegf_Agents,IRIS13Elements.Laser_Photocoagulation)
                  && isVisualAcuityPerformedAfterTreatment(visit,m,IRIS13Elements.Visual_Acuity, patientHistoryList,IRIS13Elements.Intravitreal_Injection,IRIS13Elements.Laser_Photocoagulation)
                 )
    )

  }
  def getExclusion(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      wasDiagnosedInHistory(visit, m, IRIS13Elements.Ophthalmic_Complications_Of_Diabetic_Retinopathy, patientHistoryList))
  }
  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      checkPhysicalExamPerformedValue(visit, m,  IRIS13Elements.Loss_Of_Visual_Acuity,0.3,"gt",patientHistoryList))
  }
}

