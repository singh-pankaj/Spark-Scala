package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{AdminElements, CalenderUnit, MeasureProperty, QPP433Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 433
* Measure Title              :- Proportion of Patients Sustaining a Bowel Injury at the time of any Pelvic Organ Prolapse Repair
* Measure Description        :- Percentage of patients undergoing surgical repair of pelvic organ prolapse that is
                                complicated by a bowel injury at the time of index surgery that is recognized
                                intraoperatively or within 30 days after surgery
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp433 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp433"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP433Elements.Posterior_Or_Anterior_Or_Apical_Pelvic_Organ_Prolapse_Surgery
      , QPP433Elements.Bowel_Injury
      , QPP433Elements.Bowel_Injury_Not_Met
      , QPP433Elements.Bowel_Injury_Medical_Reason
      , QPP433Elements.Planned_Resection_Re_Anastomosis_Of_Bowel
      , QPP433Elements.Injury_Medical_Reason
      , QPP433Elements.Expired
      , QPP433Elements.Non_Medical_Cuases
      , QPP433Elements.Patient_Died_Bowel_Injury
      , QPP433Elements.Gynecologic_Other_Pelvic_Malignancy
    ).collect().toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      val denominatorRDD=ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate RDD
      val intermediateException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
   	All patients undergoing anterior, posterior or apical pelvic organ prolapse (POP) surgery
   -----------------------------------------------------------------------------------------*/

  def getIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    rdd.filter(visit =>
        isFemale(visit,m)
      && isProcedurePerformedDuringEncounter(visit,m,QPP433Elements.Posterior_Or_Anterior_Or_Apical_Pelvic_Organ_Prolapse_Surgery)
      && wasProcedurePerformedBeforeOrEqualEndInMonths(visit,m,QPP433Elements.Posterior_Or_Anterior_Or_Apical_Pelvic_Organ_Prolapse_Surgery,1,patientHistoryList)
    )
  }

  /*------------------------------------------------------------------------------------------------
   The number of patients undergoing prolapse repair who sustain a bowel injury that necessitates repair either
    intraoperatively or within 30 days after surgery
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
         isProcedurePerformed(visit,m,QPP433Elements.Bowel_Injury,patientHistoryList)
      || isProcedurePerformedDuringEncounter(visit,m,QPP433Elements.Bowel_Injury)
      || wasProcedurePerformedAfterXMonthsOfProcedure(visit,m,QPP433Elements.Posterior_Or_Anterior_Or_Apical_Pelvic_Organ_Prolapse_Surgery,QPP433Elements.Bowel_Injury,1,patientHistoryList)
        )
      && !isProcedurePerformed(visit,m,QPP433Elements.Bowel_Injury_Not_Met,patientHistoryList)
    )

  }

  /*-----------------------------------------------------------------------------------------------------------------
   Documented medical reasons for not reporting bowel injury (e.g. gynecologic or other pelvic malignancy documented,
   planned (e.g. not due to an unexpected bowel injury) resection and/or  re-anastomosis of bowel, or patient death
   from non-medical causes not related to surgery, patient died during procedure without evidence of bowel injury)
   -----------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermediateException: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow]  = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateException.filter(visit =>
        isProcedurePerformedDuringEncounter(visit,m,QPP433Elements.Bowel_Injury_Medical_Reason)
     || wasProcedurePerformedAfterXMonthsOfProcedure(visit,m,QPP433Elements.Posterior_Or_Anterior_Or_Apical_Pelvic_Organ_Prolapse_Surgery,QPP433Elements.Bowel_Injury_Medical_Reason,1,patientHistoryList)
     || isProcedurePerformedDuringEncounter(visit,m,QPP433Elements.Planned_Resection_Re_Anastomosis_Of_Bowel)
     || wasProcedurePerformedAfterXMonthsOfProcedure(visit,m,QPP433Elements.Posterior_Or_Anterior_Or_Apical_Pelvic_Organ_Prolapse_Surgery,QPP433Elements.Planned_Resection_Re_Anastomosis_Of_Bowel,1,patientHistoryList)
     || isDiagnosedOnEncounter(visit,m,QPP433Elements.Injury_Medical_Reason)
     || wasDiagnosedAfterXMonthsOfProcedure(visit,m,QPP433Elements.Posterior_Or_Anterior_Or_Apical_Pelvic_Organ_Prolapse_Surgery,QPP433Elements.Injury_Medical_Reason,1,patientHistoryList)
     || isPatientExpiredWithCause(visit,m,QPP433Elements.Expired,QPP433Elements.Non_Medical_Cuases)
     || isPatientExpiredAfterXMonthsEncounterWithCause(visit,m,QPP433Elements.Expired,QPP433Elements.Non_Medical_Cuases,CalenderUnit.MONTH,1,patientHistoryList)
     || isPatientExpiredWithCause(visit,m,QPP433Elements.Expired,QPP433Elements.Patient_Died_Bowel_Injury)
     || isDiagnosedWithBeforeOrEqual(visit,m,AdminElements.Encounter_Date,patientHistoryList,QPP433Elements.Gynecologic_Other_Pelvic_Malignancy)

    )

  }

}
