
package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.ecqm.Ecqm144V7_2.{MEASURE_NAME, checkEmptyIPPRDD}
import com.figmd.janus.measureComputation.master.{CalenderUnit, ECQM74V8Elements, MeasureProperty, CompareOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- eCQM 74v8
* Measure Title              :- Primary Caries Prevention Intervention as Offered by Primary Care Providers, including Dentists
* Measure Description        :- Percentage of children, age 0-20 years, who received a fluoride varnish application during the measurement period
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 2
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm74V8_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm74V8_2"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Backtracking List
      val getPatientHistoryList = getPatientHistory(sparkSession, ippRDD
        , ECQM74V8Elements.Encounter_Inpatient
        , ECQM74V8Elements.Discharged_To_Home_For_Hospice_Care
        , ECQM74V8Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care
        , ECQM74V8Elements.Hospice_Care_Ambulatory
        , ECQM74V8Elements.Fluoride_Varnish_Application_For_Children).collect.toList
      val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

      val denominatorRDD = ippRDD
      denominatorRDD.cache()


      // Eligible IPP
      //val eligibleRdd = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exclusions
      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Children, age 0-20 years, with a visit during the measurement period
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeBetweenBeforeStart(visit, m, 12, CompareOperator.GREATER_EQUAL, 20, CompareOperator.LESS)
        && isVisitTypeIn(visit, m
        , ECQM74V8Elements.Preventive_Care__Established_Office_Visit__0_To_17
        , ECQM74V8Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17
        , ECQM74V8Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
        , ECQM74V8Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
        , ECQM74V8Elements.Office_Visit
        , ECQM74V8Elements.Clinical_Oral_Evaluation)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Exclude patients who were in hospice care during the measurement year
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isEncounterPerformedWithDischargeStatus(visit, m, ECQM74V8Elements.Encounter_Inpatient, ECQM74V8Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        || isEncounterPerformedWithDischargeStatus(visit, m, ECQM74V8Elements.Encounter_Inpatient, ECQM74V8Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        || isInterventionOrder(visit, m, ECQM74V8Elements.Hospice_Care_Ambulatory, patientHistoryList)
        || isInterventionPerformedInHistory(visit, m, ECQM74V8Elements.Hospice_Care_Ambulatory, patientHistoryList)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Children who receive a fluoride varnish application
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      isProcedurePerformed(visit, m, ECQM74V8Elements.Fluoride_Varnish_Application_For_Children, patientHistoryList)
    )
  }
}
