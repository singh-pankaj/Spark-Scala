package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, QPP473Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.joda.time.DateTime

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- QPP_473_1
* Measure Title               :- Average Change in Leg Pain Following Lumbar Fusion Surgery
* Measure Description         :- The average change (preoperative to one year postoperative) in leg pain for patients 18 years of age or older who had a lumbar fusion procedure
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SHREYA_ASHTEKAR_FIGMD_COM
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object QPP_473_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP_473_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP473Elements.Leg_Pain_Vas,
      QPP473Elements.Leg_Pain_Measurement,
      QPP473Elements.Pre_Operative_Vas_Score,
      QPP473Elements.Post_Operative_Vas_Score,
      QPP473Elements.Leg_Pain_Vas_Not_Met
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)



    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population-
Patients 18 years of age or older as of October 1 of the denominator identification period who had a lumbar fusion procedure performed during the denominator identification period
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val tempStartDate = new DateTime(globalStartDate).minusMonths(15)
    val tempEndDate = new DateTime(globalStartDate).minusMonths(3).minusDays(1)
    val m = MeasureProperty(MEASURE_NAME, IPP, tempStartDate, tempEndDate)
    initialRDD.filter(
      visit =>
        isPatientAdult(visit,m)
          && isProcedurePerformedDuringEncounter(visit,m,QPP473Elements.Lumbar_Fusion)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exclusions-
Patients with a diagnosis of lumbar spine region cancer or lumbar spine region fracture or lumbar spine region infection or lumbar idiopathic or congenital scoliosis at the time of the procedure
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        isDiagnosedDuringProcedure(visit,m,QPP473Elements.Lumbar_Idiopathic_Or_Congenital_Scoliosis,QPP473Elements.Lumbar_Fusion)
        ||
        isDiagnosedDuringProcedure(visit,m,QPP473Elements.Lumbar_Spine_Region_Infection,QPP473Elements.Lumbar_Fusion)
        ||
        isDiagnosedDuringProcedure(visit,m,QPP473Elements.Lumbar_Spine_Region_Fracture,QPP473Elements.Lumbar_Fusion)
        ||
        isDiagnosedDuringProcedure(visit,m,QPP473Elements.Lumbar_Spine_Region_Cancer,QPP473Elements.Lumbar_Fusion)
        ||
        isAssessmentPerformedDuringProcedure(visit,m,QPP473Elements.Lumbar_Cancer_Infection_Scoliosis_Fracture,QPP473Elements.Lumbar_Cancer_Infection_Scoliosis_Fracture_Date,QPP473Elements.Lumbar_Fusion,QPP473Elements.Lumbar_Fusion_Date)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator-
All eligible patients whose leg pain was measured by the Visual Analog Scale (VAS) within three months preoperatively AND at one year (9 to 15 months) postoperatively
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
        wasAssessmentPerformedAfterProcedure(visit,m,QPP473Elements.Lumbar_Fusion,patientHistoryBroadcastList,QPP473Elements.Leg_Pain_Vas)
          ||
          (
              (
                wasAssessmentPerformedBeforeProcedureWithMethodInXMonth(visit,m,QPP473Elements.Lumbar_Fusion,QPP473Elements.Visual_Analog_Scale,QPP473Elements.Leg_Pain_Measurement,CalenderUnit.MONTH,3,patientHistoryBroadcastList)
                &&
                wasAssessmentPerformedInXMonthsBeforeEncounter(visit,m,QPP473Elements.Pre_Operative_Vas_Score,3,patientHistoryBroadcastList)
               //procedure checked on encounter in ipp
              )
              &&
              (
                wasAssessmentPerformedAfterProcedureWithMethodInXMonth(visit,m,QPP473Elements.Lumbar_Fusion,QPP473Elements.Visual_Analog_Scale,QPP473Elements.Leg_Pain_Measurement,CalenderUnit.MONTH,9,CalenderUnit.MONTH,15,patientHistoryBroadcastList)
                &&
                wasAssessmentPerformedInXMonthsBeforeEncounter(visit,m,QPP473Elements.Post_Operative_Vas_Score,9,patientHistoryBroadcastList)
                //procedure checked on encounter in ipp
              )
            )
        )
        &&
        !wasAssessmentPerformedAfterProcedure(visit,m,QPP473Elements.Lumbar_Fusion,patientHistoryBroadcastList,QPP473Elements.Leg_Pain_Vas_Not_Met)
    )
  }

}