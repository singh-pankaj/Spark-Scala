package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, QPP420Elements,TimeOperator}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 420
* Measure Title              :- Varicose Vein Treatment with Saphenous Ablation
* Measure Description        :- Percentage of patients treated for varicose veins (CEAP C2-S) who are treated with
                                saphenous ablation (with or without adjunctive tributary treatment) that report an
                                improvement on a disease specific patient reported outcome survey instrument after treatment.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp420 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp420"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patienthistoryRdd = getPatientHistory(sparkSession, initialRDD
      , QPP420Elements.Varicose_Veins
      , QPP420Elements.Saphenous_Ablation
      //,QPP420Elements.Baseline_Outcome_Survey
      //,QPP420Elements.Baseline_Outcome_Survey_Score
      , QPP420Elements.Venous_Insufficiency_Epidemiological_And_Economic_Study_Quality_Of_Life
      , QPP420Elements.Baseline_Veines_Qol_Score
      , QPP420Elements.Chronic_Venous_Insufficiency_Questionnaire
      , QPP420Elements.Baseline_Civiq_Score
      , QPP420Elements.Aberdeen_Varicose_Veins_Questionnaire
      , QPP420Elements.Baseline_Avvq_Score
      , QPP420Elements.Specific_Quality_Of_Life_And_Outcome_Response___Venous
      , QPP420Elements.Baseline_Sqor_V_Score
      , QPP420Elements.Outcome_Survey_Score_Improved_1
      , QPP420Elements.Outcome_Survey_Score_Improved_2
      , QPP420Elements.Venous_Insufficiency_Epidemiological_And_Economic_Study_Quality_Of_Life
      , QPP420Elements.Veines_Qol_Score
      , QPP420Elements.Civiq_Score
      , QPP420Elements.Avvq_Score
      , QPP420Elements.Sqor_V_Score_Date
      , QPP420Elements.Improved_Outcome_Not_Met
      , QPP420Elements.Improved_Outcome_Patient_Ineligible
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistoryRdd.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
     // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()
      // Filter Intermediate B
      val intermediateB = getSubtractRDD(denominatorRDD, metRDD)
      intermediateB.cache()
      // Filter Denominator Exception
      val exceptionRDD = getException(intermediateB, patientHistoryBroadcastList)
      exceptionRDD.cache()

      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  /*-------------------------------------------------------------------------------------------------------------------
  All patients who are treated for varicose veins with saphenous ablation and who receive an outcomes survey before and
  3-6 months after treatment.
  -------------------------------------------------------------------------------------------------------------------*/
  def getIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP420Elements.Varicose_Veins,patientHistoryList)
      &&
        (
          //   wasAssessmentPerformedwithResultStartBeforeEncounter(visit,m,QPP420Elements.Saphenous_Ablation,TimeOperator.BEFORE,QPP420Elements.Baseline_Outcome_Survey,QPP420Elements.Baseline_Outcome_Survey_Score,patientHistoryList)
           wasAssessmentPerformedwithResultStartBeforeEncounter(visit,m,QPP420Elements.Saphenous_Ablation,TimeOperator.BEFORE,QPP420Elements.Venous_Insufficiency_Epidemiological_And_Economic_Study_Quality_Of_Life,QPP420Elements.Baseline_Veines_Qol_Score,patientHistoryList)
          || wasAssessmentPerformedwithResultStartBeforeEncounter(visit,m,QPP420Elements.Saphenous_Ablation,TimeOperator.BEFORE,QPP420Elements.Chronic_Venous_Insufficiency_Questionnaire,QPP420Elements.Baseline_Civiq_Score,patientHistoryList)
          || wasAssessmentPerformedwithResultStartBeforeEncounter(visit,m,QPP420Elements.Saphenous_Ablation,TimeOperator.BEFORE,QPP420Elements.Aberdeen_Varicose_Veins_Questionnaire,QPP420Elements.Baseline_Avvq_Score,patientHistoryList)
          || wasAssessmentPerformedwithResultStartBeforeEncounter(visit,m,QPP420Elements.Saphenous_Ablation,TimeOperator.BEFORE,QPP420Elements.Specific_Quality_Of_Life_And_Outcome_Response___Venous,QPP420Elements.Baseline_Sqor_V_Score,patientHistoryList)
          )
      && isProcedurePerformedDuringEncounter(visit,m,QPP420Elements.Saphenous_Ablation)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------
  Patients whose outcome survey score improved when assessed 3-6 months following treatment.
  -------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
          wasInterventionPerformedAfterInBetweenXPeriod(visit,m,QPP420Elements.Saphenous_Ablation,CalenderUnit.MONTH,3,6,patientHistoryList,QPP420Elements.Outcome_Survey_Score_Improved_1
                                                                                                                                                               ,QPP420Elements.Outcome_Survey_Score_Improved_2)
      ||  (
               wasAssessmentPerformedwithResultAfterEncounterinBetweenXPeriod(visit,m,QPP420Elements.Saphenous_Ablation,CalenderUnit.MONTH,"AFTER",3,6,QPP420Elements.Venous_Insufficiency_Epidemiological_And_Economic_Study_Quality_Of_Life,QPP420Elements.Veines_Qol_Score,patientHistoryList)
            || wasAssessmentPerformedwithResultAfterEncounterinBetweenXPeriod(visit,m,QPP420Elements.Saphenous_Ablation,CalenderUnit.MONTH,"AFTER",3,6,QPP420Elements.Chronic_Venous_Insufficiency_Questionnaire,QPP420Elements.Civiq_Score,patientHistoryList)
            || wasAssessmentPerformedwithResultAfterEncounterinBetweenXPeriod(visit,m,QPP420Elements.Saphenous_Ablation,CalenderUnit.MONTH,"AFTER",3,6,QPP420Elements.Aberdeen_Varicose_Veins_Questionnaire,QPP420Elements.Avvq_Score,patientHistoryList)
            || wasAssessmentPerformedwithResultAfterEncounterinBetweenXPeriod(visit,m,QPP420Elements.Saphenous_Ablation,CalenderUnit.MONTH,"AFTER",3,6,QPP420Elements.Specific_Quality_Of_Life_And_Outcome_Response___Venous,QPP420Elements.Sqor_V_Score_Date,patientHistoryList)
            )
        )
      && !wasInterventionPerformedAfterInBetweenXPeriod(visit,m,QPP420Elements.Saphenous_Ablation,CalenderUnit.MONTH,3,6,patientHistoryList,QPP420Elements.Improved_Outcome_Not_Met)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------
  Patient survey results not available.
  -------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateB: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    var m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateB.filter(visit =>
         wasInterventionPerformedAfterInBetweenXPeriod(visit,m,QPP420Elements.Saphenous_Ablation,CalenderUnit.MONTH,3,6,patientHistoryList,QPP420Elements.Improved_Outcome_Patient_Ineligible
                                                                                                                                                                  ,QPP420Elements.Outcome_Survey_Result)

    )
  }
}
