package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CompareOperator, MeasureProperty, QPP324Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


/*--------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 324
* Measure Title              :- Cardiac Stress Imaging Not Meeting Appropriate Use Criteria: Testing in Asymptomatic, Low-Risk Patients.
* Measure Description        :- Percentage of all stress single-photon emission computed tomography (SPECT) myocardial perfusion imaging (MPI),
                                stress echocardiogram (ECHO), cardiac computed tomography angiography (CCTA), and cardiovascular magnetic resonance (CMR) performed in asymptomatic,
                                low coronary heart disease (CHD) risk patients 18 years and older for initial detection and risk assessment
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp324 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp324"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //Backtracking List
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP324Elements.Cardiac_Stress_Imaging,
      QPP324Elements.Detection_Low_Chd_Risk,
      QPP324Elements.Framingham_Risk_Score,
      QPP324Elements.Low_Chd_Risk_Assessment,
      QPP324Elements.Detection_Low_Chd_Reason).collect.toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    //  Filter IPP-
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

    val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    denominatorRDD.cache()

    // Exclusion
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exclusionRDD.cache()

    // Filter Met
    val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
    metRDD.cache()

    val intermediateB = getSubtractRDD(ippRDD, metRDD)
    intermediateB.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exceptionRDD.cache()

    // Filter not met
    val notMetRDD = getSubtractRDD(ippRDD, intermediateB)
    notMetRDD.cache()

    saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    patientHistoryBroadcastList.destroy()
  }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : All instances of stress single-photon emission computed tomography (SPECT) myocardial perfusion imaging (MPI),
stress echocardiogram (ECHO), cardiac computed tomography angiography (CCTA), or cardiac magnetic resonance (CMR) performed
on patients aged 18 years and older during the performance period.
----------------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isProcedurePerformed(visit, m, QPP324Elements.Cardiac_Stress_Imaging, patientHistoryBroadcastList)
    )

  }


  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Number of stress SPECT MPI, stress echo, CCTA, or CMR primarily performed for asymptomatic,
low CHD risk patients for initial detection and risk assessment.
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      wasAssessmentPerformedBeforeOrEqualProcedure(visit, m, QPP324Elements.Cardiac_Stress_Imaging, QPP324Elements.Detection_Low_Chd_Risk, patientHistoryBroadcastList)
        || wasAssessmentPerformedBeforeOrEqualProcedureWithResult(visit, m, QPP324Elements.Cardiac_Stress_Imaging, QPP324Elements.Framingham_Risk_Score, 10, CompareOperator.LESS_EQUAL, patientHistoryBroadcastList)
        || wasAssessmentPerformedBeforeOrEqualProcedure(visit, m, QPP324Elements.Cardiac_Stress_Imaging, QPP324Elements.Low_Chd_Risk_Assessment, patientHistoryBroadcastList)
        && !wasAssessmentPerformedBeforeOrEqualProcedure(visit, m, QPP324Elements.Cardiac_Stress_Imaging, QPP324Elements.Detection_Low_Chd_Reason, patientHistoryBroadcastList)
    )
  }

}
