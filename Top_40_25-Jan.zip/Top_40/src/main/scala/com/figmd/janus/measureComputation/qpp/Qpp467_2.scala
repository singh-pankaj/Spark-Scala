package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{ MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp467
* Measure Title              :- Developmental Screening in the First Three Years of Life
* Measure Description        :- The percentage of children screened for risk of developmental, behavioral and social delays using a standardized
                                screening tool in the 12 months preceding or on their first, second, or third birthday. This is a composite measure of
                                screening in the first three years of life that includes three, age-specific indicators assessing whether children are
                                screened in the 12 months preceding or on their first, second or third birthday
* Calculation Implementation :- visit-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 2
* Measure Stratification     :- 3
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp467_2 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp467_2"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //eligible RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      var patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        QPP467Elements.Screening_For_Development_Behavioral_Social,
        QPP467Elements.Assessment_Using_Ages_And_Stages_Questionnaire,
        QPP467Elements.Assessment_Using_Ages_And_Stages_Questionnaire_3rd_Edition,
        QPP467Elements.Assessment_Using_Battelle_Developmental_Inventory_Screening_Tool,
        QPP467Elements.Assessment_Using_Bayley_Infant_Neuro_Developmental_Screen,
        QPP467Elements.Assessment_Using_Brigance_Screens_Ii,
        QPP467Elements.Assessment_Using_Child__Development_Inventory__Cdi_,
        QPP467Elements.Assessment_Using_Infant__Development_Inventory,
        QPP467Elements.Assessment_Using_Parents_Evaluation_Developmental_Status__Peds_,
        QPP467Elements.Assessment_Using_Parents_Evaluation_Of_Developmental_Status___Developmental_Milestones,
        QPP467Elements.Screening_Not_Done_For_Developmental
      )

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //All patients who turn 1, 2 or 3 years of age between January 1 and December 31 of the performance period
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)
    rdd.filter(visit =>
      isAgeAboveBeforeStart(visit,m,false,1,CalenderUnit.YEAR)
        &&    isAgeEqualBeforeEnd(visit,m,2,CalenderUnit.YEAR)
        &&    isVisitTypeIn(visit,m,QPP467Elements.Office_Visit)
        &&    !isTeleHealthModifier(visit,m,QPP467Elements.Office_Visit_Telehealth_Modifier)
        &&    isPOSEncounterNotPerformed(visit,m,QPP467Elements.Pos_02)
    )
  }

  //Children who were screened for risk of developmental, behavioral and social delays using a standardized tool.
  def getMet(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      (
        isAssesmentPerformedDuringEncounter(visit,m,QPP467Elements.Screening_For_Development_Behavioral_Social)
          ||  (
          isAssesmentPerformedBeforeEnd(visit,m,QPP467Elements.Assessment_Using_Ages_And_Stages_Questionnaire,patientHistoryList)
            ||  isAssesmentPerformedBeforeEnd(visit,m,QPP467Elements.Assessment_Using_Ages_And_Stages_Questionnaire_3rd_Edition,patientHistoryList)
            ||  isAssesmentPerformedBeforeEnd(visit,m,QPP467Elements.Assessment_Using_Battelle_Developmental_Inventory_Screening_Tool,patientHistoryList)
            ||  isAssesmentPerformedBeforeEnd(visit,m,QPP467Elements.Assessment_Using_Bayley_Infant_Neuro_Developmental_Screen,patientHistoryList)
            ||  isAssesmentPerformedBeforeEnd(visit,m,QPP467Elements.Assessment_Using_Brigance_Screens_Ii,patientHistoryList)
            ||  isAssesmentPerformedBeforeEnd(visit,m,QPP467Elements.Assessment_Using_Child__Development_Inventory__Cdi_,patientHistoryList)
            ||  isAssesmentPerformedBeforeEnd(visit,m,QPP467Elements.Assessment_Using_Infant__Development_Inventory,patientHistoryList)
            ||  isAssesmentPerformedBeforeEnd(visit,m,QPP467Elements.Assessment_Using_Parents_Evaluation_Developmental_Status__Peds_,patientHistoryList)
            ||  isAssesmentPerformedBeforeEnd(visit,m,QPP467Elements.Assessment_Using_Parents_Evaluation_Of_Developmental_Status___Developmental_Milestones,patientHistoryList)

          )

        )
        &&  isAssessmentPerformed(visit,m,QPP467Elements.Screening_Not_Done_For_Developmental,patientHistoryList)
    )
  }

}