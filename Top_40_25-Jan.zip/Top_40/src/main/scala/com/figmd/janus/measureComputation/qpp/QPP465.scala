
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- QPP465
* Measure Title               :- Uterine Artery Embolization Technique: Documentation of Angiographic Endpoints and Interrogation of Ovarian Arteries
* Measure Description         :- The percentage of patients with documentation of angiographic endpoints of embolization AND the documentation of
                                 embolization strategies in the presence of unilateral or bilateral absent uterine arteries
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- NA
* Measure Developer           :- Aanchal.Rai
* Initial GIT Version/Tag(CRA):- 1.8
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object QPP465 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "QPP465"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,QPP465Elements.Leiomyomas_Or_Adenomyosis

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD )
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
   IPP -- All patients undergoing uterine artery embolization for leiomyomas and/or adenomyosis
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isFemale(visit, m)
      &&
      wasDiagnosedBeforeOrEqualProcedure(visit,m,QPP465Elements.Vascular_Embolization,QPP465Elements.Leiomyomas_Or_Adenomyosis,patientHistoryBroadcastList)
      &&
      isProcedurePerformedDuringEncounter(visit,m,QPP465Elements.Vascular_Embolization)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Numerator -- Number of patients undergoing uterine artery embolization for symptomatic leiomyomas and/or adenomyosis in
  whom embolization endpoints are documented separately for each embolized vessel AND ovarian artery
  angiography or embolization performed in the presence of variant uterine artery anatomy.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      ( isAssessmentPerformedDuringEncounter(visit,m,QPP465Elements.Embolization_Documented)
        ||
         (
            isAssessmentPerformedDuringEncounter(visit,m,QPP465Elements.Embolization_Endpoints)
            &&
             (
               isAssessmentPerformedDuringEncounter(visit,m,QPP465Elements.Ovarian_Artery_Angiography)
               ||
               isAssessmentPerformedDuringEncounter(visit,m,QPP465Elements.Variant_Uterine_Artery_Anatomy)
             )
         )
      )

      && !isAssessmentPerformedDuringEncounter(visit,m,QPP465Elements.Embolization_Not_Documented)

    )
  }

}
