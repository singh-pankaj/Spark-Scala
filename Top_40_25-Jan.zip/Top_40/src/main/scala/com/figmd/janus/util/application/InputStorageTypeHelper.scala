package com.figmd.janus.util.application

import com.datastax.spark.connector.CassandraRow
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SQLContext, SparkSession}

object StorageTypes extends Enumeration {
  type storageType = Value
  val CASSANDRA, BIGTABLE = Value
}

object InputStorageTypeHelper {
  // default storage type is BIGTABLE
  var storageType = StorageTypes.BIGTABLE
  var spark:SparkSession =null
  var sparkSql: SQLContext = null

  def init(spark:SparkSession, sparkSql: SQLContext, storageType: String) {
    this.spark = spark
    this.sparkSql = sparkSql
    this.storageType = StorageTypes.withName(storageType.toUpperCase)
  }

  def getStorageType(): StorageTypes.Value = {
    return storageType
  }

  /*
  def getInputRDD(keySpace: String, tableName: String): RDD[CassandraRow] = {
    var rdd: RDD[CassandraRow] = null
    storageType match {
      case "cassandra" => rdd = spark.sparkContext.cassandraTable(keySpace, tableName)
      case "bigtable" => rdd = new BigTableUtility().getCassandraRDD(sparkSql, tableName)
      case _ => throw new UnsupportedOperationException(s"Unsupported Storage Type $storageType")
    }

    return rdd
  }*/


  /**
    *
    * @param keySpace: Specify keyspace for source cassandra table. This is required only if Input Storage type is cassandra
    * @param tableName: Specify source table name
    * @param columns: Specify list of columns
    * @param whereCql
    * @param whereValues
    * @return
    */
  def getInputRDD(keySpace: String, tableName: String, columns: Seq[String], whereCql: String, whereValues: Any*): RDD[CassandraRow] = {
    var rdd: RDD[CassandraRow] = null
    storageType match {
      case StorageTypes.CASSANDRA => rdd = new CassandraUtility().getCassandraRDD(spark, keySpace, tableName, columns, whereCql, whereValues: _*)
      case StorageTypes.BIGTABLE => rdd = BigTableUtility.getCassandraRowsRDD(sparkSql, tableName, columns, whereCql, whereValues: _*)
      case _ => throw new UnsupportedOperationException(s"Unsupported Storage Type $storageType")
    }

    return rdd
  }


  def getInputRDD(keySpace: String, tableName: String, columns: Seq[String]): RDD[CassandraRow] = {
    var rdd: RDD[CassandraRow] = null
    storageType match {
      case StorageTypes.CASSANDRA => rdd = new CassandraUtility().getCassandraRDD(spark, keySpace, tableName, columns)
      case StorageTypes.BIGTABLE => rdd = BigTableUtility.getCassandraRowsRDD(sparkSql, tableName, columns)
      case _ => throw new UnsupportedOperationException(s"Unsupported Storage Type $storageType")
    }

    return rdd
  }

  /*




    //TODO: added for testing - cassandra will not work for this
    def getInputRDD(keySpace: String, tableName: String): RDD[CassandraRow] = {
      var rdd: RDD[CassandraRow] = null
      storageType match {
        case StorageTypes.CASSANDRA => rdd = new CassandraUtility().getCassandraRDD(spark, keySpace, tableName)
        case StorageTypes.BIGTABLE => rdd = BigTableUtility.getCassandraRowsRDD(sparkSql, tableName)
        case _ => throw new UnsupportedOperationException(s"Unsupported Storage Type $storageType")
      }

      return rdd
    }

    def getInputDF(keySpace: String, tableName: String): DataFrame = {
      var inputDF: DataFrame = null
      storageType match {
        case StorageTypes.CASSANDRA => inputDF = new CassandraUtility().getCassandraDF(spark, keySpace, tableName)
        case StorageTypes.BIGTABLE => inputDF = BigTableUtility.getBigTableDF(sparkSql, tableName)
      }

      return inputDF
    }
  */

  /**
    * This method returns character required to specify dynamic parameter in where clause based on storage type (i.e.
    * Cassandra or BigTable
    */
  def getWhereParamSpeChar(): String = {
    var paramSpecChar = "?"
    storageType match {
      case StorageTypes.CASSANDRA => paramSpecChar = "&"
      case StorageTypes.BIGTABLE => paramSpecChar = "%s"
      case _ => throw new UnsupportedOperationException(s"Unsupported Storage Type $storageType")
    }

    return paramSpecChar
  }
}
