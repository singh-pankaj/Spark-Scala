package com.figmd.janus.util.application

import com.datastax.spark.connector.{CassandraRow, CassandraRowMetadata}
import org.apache.spark.sql.Row

class SparkRowToCassandraRow(columnNames: String) extends Serializable {
  val columnNamesAsSeq = columnNames.split(",").toSeq

  def map(inputRow: Row): CassandraRow = {
    return new CassandraRow(CassandraRowMetadata.fromColumnNames(columnNamesAsSeq),
      toIndexedSeq(inputRow.toSeq))
  }

  def toIndexedSeq(inputSeq: Seq[Any]): IndexedSeq[AnyRef] = {
    var outputSeq: IndexedSeq[AnyRef] = IndexedSeq()
    inputSeq.toStream.foreach(v => (outputSeq = outputSeq :+ v.asInstanceOf[AnyRef]))
    return outputSeq
  }
}
