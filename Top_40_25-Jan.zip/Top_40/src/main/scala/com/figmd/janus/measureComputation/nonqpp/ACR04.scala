package com.figmd.janus.measureComputation.nonqpp
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ACR04Elements, AdminElements, CalenderUnit, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACR 04
* Measure Title              :- Advanced: Tuberculosis (TB) Test Prior to First Course Biologic Therapy
* Measure Description        :- Percentage of patients 18 years and older with a diagnosis of rheumatoid arthritis that are newly prescribed a biologic therapy during the measurement period and whose medical record indicates tuberculosis testing in the 12 months preceding the biologic prescription.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Vrushali Gholap
----------------------------------------------------------------------------------------------------------------------------*/

object ACR04 extends MeasureUtilityUpdate with MeasureUpdate{
  val MEASURE_NAME = "ACR 04"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD,
      ACR04Elements.Active_Rheumatoid_Arthritis,
      ACR04Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_
    )
    val patienthistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    val leastRecentRDD: List[CassandraRow] = leastRecentPatientList(patientHistoryRDD, ACR04Elements.Active_Rheumatoid_Arthritis
      , ACR04Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_)

    val leastRecentPatienthistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(leastRecentRDD)

    // Filter IPP
    val ippRDD = getIppRDD(initialRDD, leastRecentPatienthistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Eligible IPP
      val denominatorRDD = getDenominatorRDDD(ippRDD, patienthistoryList)
      denominatorRDD.cache()


      // Filter Met
      val metRDD = getMetRDD(denominatorRDD, patienthistoryList)
      metRDD.cache()
      // Filter not Met

      val notMetRDD = getSubtractRDD(denominatorRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD, metRDD, sparkSession.sparkContext.emptyRDD, notMetRDD, MEASURE_NAME)
      patienthistoryList.unpersist()
      leastRecentPatienthistoryList.unpersist()


    }
  }
/*-------------------------------------------------------------------------------------------------------------------------
  Patients 18 years and older with a diagnosis of rheumatoid arthritis who are seen for at least one face-to-face encounter for RA.
----------------------------------------------------------------------------------------------------------------------------*/
  def getIppRDD(initialRDD: RDD[CassandraRow],leastRecentPatienthistoryList :Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)


    initialRDD.filter(visit =>
           isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
        && isVisitTypeIn(visit,m, ACR04Elements.Outpatient_Consultation,
                                  ACR04Elements.Nursing_Facility_Visit,
                                  ACR04Elements.Office_Visit,
                                  ACR04Elements.Home_Healthcare_Services,
                                  ACR04Elements.Care_Services_In_Long_Term_Residential_Facility,
                                  ACR04Elements.Face_To_Face_Interaction)
        && wasFirstDiagnosed(visit,m,ACR04Elements.Active_Rheumatoid_Arthritis,leastRecentPatienthistoryList)
    )
  }
  /*-------------------------------------------------------------------------------------------------------------------------
    Equals Initial Population who are newly started on biologic therapy during the measurement period.
  ----------------------------------------------------------------------------------------------------------------------------*/
  def getDenominatorRDDD(rdd: RDD[CassandraRow],patienthistoryList :Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

//Used encounterdate instead of elements in $Encounter thus code reduced.
    rdd.filter(visit => isMedicationOrderedOnEncounter(visit,m,ACR04Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_)
      && !wasMedicationAdministeredBeforeEncounterInXMonths(visit,m,"encounterdate",ACR04Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_,12,patienthistoryList)

    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Any record of TB testing documented or performed (PPD, IFN-gamma release assays, or other appropriate method) in the medical record in the 12 months preceding the biologic prescription.
----------------------------------------------------------------------------------------------------------------------------*/
  def getMetRDD(rdd: RDD[CassandraRow],patienthistoryList :Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      wasLaboratoryTestPerformedBeforeEncounterWithinXMonths(visit,m,"encounterdate",ACR04Elements.Tb_Screening,12,patienthistoryList)
      || wasLaboratoryTestPerformedBeforeEncounterWithinXMonths(visit,m,"encounterdate",ACR04Elements.Positive_Screening_Results_Of_Tb,12,patienthistoryList)
    )
  }

}

