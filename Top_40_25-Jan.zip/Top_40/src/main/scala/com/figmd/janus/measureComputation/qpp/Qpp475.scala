package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Qpp475
* Measure Title               :- Zoster (Shingles) Vaccination
* Measure Description         :- The percentage of patients aged 50 years and older who have had the Shingrix zoster (shingles) vaccinationThe percent
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp475 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp475"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,QPP475Elements.Patient_Immunocompromised
      ,QPP475Elements.High_Doses_Of_Immunosuppressive_Therapy
      ,QPP475Elements.Immunocompromised_Conditions
      ,QPP475Elements.Immunosuppressive_Medication
      ,QPP475Elements.Shingles_Vaccination
      ,QPP475Elements.Shingles_Vaccine_G
      ,QPP475Elements.Shingles_Vaccine_Not_Met
      ,QPP475Elements.Shingles_Vaccine_Patient_Reason)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val FirstVaccRDD = minDate(patientHistoryRDD,QPP475Elements.Shingles_Vaccination,QPP475Elements.Shingles_Vaccination_Date)
    val leastDateHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(FirstVaccRDD)


    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList,leastDateHistoryList)
      metRDD.cache()

      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList,leastDateHistoryList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients aged 50 years and older with an encounter.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
            isAgeAbove(visit,m,true,50)
        &&  isVisitTypeIn(visit,m
              ,QPP475Elements.Office_Visit
              ,QPP475Elements.Home_Healthcare_Services
              ,QPP475Elements.Care_Services_In_Long_Term_Residential_Facility
              ,QPP475Elements.Initial_Preventive_Examination
              ,QPP475Elements.Annual_Wellness_Visit
              ,QPP475Elements.Transitional_Care_Management_Services_Cpt)
      &&  ! isTeleHealthEncounterPerformed(visit,m
                    ,QPP475Elements.Office_Visit_Telehealth_Modifier
                    ,QPP475Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
                    ,QPP475Elements.Home_Healthcare_Services_Telehealth_Modifier
                    ,QPP475Elements.Transitional_Care_Management_Telehealth_Modifier
                    ,QPP475Elements.Initial_Preventive_Physical_Examination_Telehealth_Modifier
                    ,QPP475Elements.Annual_Wellness_Visit_Telehealth_Modifier)
      &&  isPOSEncounterNotPerformed(visit,m,QPP475Elements.Pos_02)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patient pregnancy
OR
Patient immunocompromised
OR
Patients receiving high doses of immunosuppressive therapy
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
            isAssessmentPerformed(visit,m,QPP475Elements.Patient_Immunocompromised,patientHistoryBroadcastList)
        ||  isAssessmentPerformed(visit,m,QPP475Elements.High_Doses_Of_Immunosuppressive_Therapy,patientHistoryBroadcastList)
        ||  isAssessmentPerformedDuringEncounter(visit,m,QPP475Elements.Patient_Pregnancy)
        ||  isDiagnosed(visit,m,QPP475Elements.Immunocompromised_Conditions,patientHistoryBroadcastList)
        ||  isMedicationActive(visit,m,QPP475Elements.Immunosuppressive_Medication,patientHistoryBroadcastList)
        ||  isDiagnosisOnEncounter(visit,m,QPP475Elements.Pregnancy)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who have had a full course of the Shingrix zoster (shingles) vaccination ever documented in the medical
record
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],leastDateHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
          isAssessmentPerformed(visit,m,QPP475Elements.Shingles_Vaccine_G,patientHistoryBroadcastList)
      &&  wasSecondImmunizationAdministeredAfterFirstImmunizationWithInRange(visit,m,QPP475Elements.Shingles_Vaccination,2,6,patientHistoryBroadcastList,leastDateHistoryList)
      && ! isAssessmentPerformed(visit,m,QPP475Elements.Shingles_Vaccine_Not_Met,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Shingrix vaccine was not administered for reasons
documented by clinician (e.g. patient administered
vaccine other than Shingrix, patient allergy or other
medical reasons, patient declined or other patient
reasons, vaccine not available or other system
reasons)
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],leastDateHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      (   isAssessmentPerformed(visit,m,QPP475Elements.Shingles_Vaccine_Patient_Reason,patientHistoryBroadcastList)
      ||  isImmunizationAllergyDuringImmunizationAdministered(visit,m,QPP475Elements.Vaccines_Allergy,QPP475Elements.Shingles_Vaccination)
      ||  isImmunizationAdministeredDuringImmunizationAdministered(visit,m,QPP475Elements.Vaccinations_Other_Than_Shingrix,QPP475Elements.Shingles_Vaccination)
      ||  isDiagnosisDuringImmunizationAdministered(visit,m,QPP475Elements.Medical_Reason,QPP475Elements.Shingles_Vaccination)
      ||  isImmunizationAdministeredNotDoneDuringImmunizationAdministered(visit,m,QPP475Elements.Patient_Reason,QPP475Elements.Shingles_Vaccination)
      ||  isImmunizationAdministeredNotDoneDuringImmunizationAdministered(visit,m,QPP475Elements.System_Reason,QPP475Elements.Shingles_Vaccination)
      )
   || (   wasFirstImmunizationAdministeredBeforeEndInXMonths(visit,m,QPP475Elements.Shingles_Vaccination,5,leastDateHistoryList)
       && wasSecondImmunizationAdministeredAfterFirstImmunizationAndBeforeEnd(visit,m,QPP475Elements.Shingles_Vaccination,patientHistoryBroadcastList,leastDateHistoryList)
      )
    )
  }
}

