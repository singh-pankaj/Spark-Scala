package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP471Elements,CalenderUnit,CompareOperator}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 471
* Measure Title              :- Average Change in Functional Status Following Lumbar Discectomy/Laminotomy Surgery
* Measure Description        :- The average change (preoperative to postoperative) in functional status using the Oswestry
                                Disability Index (ODI version 2.1a) for patients age 18 and older who had lumbar
                                discectomy/laminotomy procedure
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp471 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "Qpp471_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP471Elements.Lumbar_Disectomy__Laminotomy
      , QPP471Elements.Additional_Spine_Procedure_On_Lumbar_Discectomy_Laminotomy
      , QPP471Elements.Additional_Spinal_Procedure
      , QPP471Elements.Functional_Status_Measurement_Oswestry_Diablity_Index
      , QPP471Elements.Oswestry_Disability_Index_Tool
      , QPP471Elements.Preoperative_Odi_Score
      , QPP471Elements.Postoperative_Odi_Score
      , QPP471Elements.Functional_Status_Measurement_Oswestry_Disability_Not_Met
      ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      val denominatorRDD = ippRDD
          denominatorRDD.cache()
      // Filter Exclusion
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)
          exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
          intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
       metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()
      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  /*------------------------------------------------------------------------------------------------
    Patients 18 years of age or older as of January 1 of the denominator identification period who had a lumbar
    discectomy/laminotomy procedure for a diagnosis of disc herniation performed during the denominator identification period
  ------------------------------------------------------------------------------------------------*/

  def getIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
           isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
        && WasProcedurePerformStartBeforeXMonths(visit,m,QPP471Elements.Lumbar_Disectomy__Laminotomy,CalenderUnit.MONTH,12,patientHistoryList)
    )
  }


  /*------------------------------------------------------------------------------------------------
  Patient had any additional spine procedures performed on the same date as the lumbar discectomy/laminotomy
------------------------------------------------------------------------------------------------*/

  def getExclusion(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
        wasAssessmentDuringProcedureInHistory(visit,m,QPP471Elements.Additional_Spine_Procedure_On_Lumbar_Discectomy_Laminotomy,QPP471Elements.Lumbar_Disectomy__Laminotomy,CompareOperator.EQUAL,patientHistoryList)
     || wasProcedureDuringProcedureInHistory(visit,m,QPP471Elements.Additional_Spinal_Procedure,QPP471Elements.Lumbar_Disectomy__Laminotomy,CompareOperator.EQUAL,patientHistoryList)
    )
  }


  /*------------------------------------------------------------------------------------------------
    All eligible patients whose functional was measured by using the Oswestry Disability Index (ODI version 2.1a) patient
    reported outcome tool within three months preoperatively AND at three months (6 to 20 weeks) postoperatively
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRdd.filter(visit =>
      (
        wasAssessmentPerformedAfterProcedure(visit,m,QPP471Elements.Lumbar_Disectomy__Laminotomy,patientHistoryList,QPP471Elements.Functional_Status_Measurement_Oswestry_Diablity_Index)
          ||
          (
                wasAssessmentPerformedBeforeProcedureWithResultInXMonth(visit,m,QPP471Elements.Oswestry_Disability_Index_Tool,QPP471Elements.Preoperative_Odi_Score,QPP471Elements.Lumbar_Disectomy__Laminotomy,CalenderUnit.MONTH,3,patientHistoryList)
            &&  wasAssessmentPerformedAfterProcedureWithResultInBetweenXMonths(visit,m,QPP471Elements.Oswestry_Disability_Index_Tool,QPP471Elements.Postoperative_Odi_Score,QPP471Elements.Lumbar_Disectomy__Laminotomy,CalenderUnit.WEEK,6,CalenderUnit.WEEK,20,patientHistoryList)
          )
        )
        && !wasAssessmentPerformedAfterProcedure(visit,m,QPP471Elements.Functional_Status_Measurement_Oswestry_Disability_Not_Met,patientHistoryList,QPP471Elements.Lumbar_Disectomy__Laminotomy)
    )
  }

}
