package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 428
* Measure Title              :- Pelvic Organ Prolapse: Preoperative Assessment of Occult Stress Urinary Incontinence
* Measure Description        :- Percentage of patients undergoing appropriate preoperative evaluation of stress urinary
*                               incontinence prior to pelvic organ prolapse surgery per ACOG/AUGS/AUA guidelines.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp428 extends MeasureUtilityUpdate with MeasureUpdate  {

  val MEASURE_NAME = "Qpp428"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

   // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //getPatientHistoryList
      val patientHistoryRDD = getPatientHistory(sparkSession,ippRDD
        , QPP428Elements.History_Of_Incontinence_And_Its_Character_G
        , QPP428Elements.Pelvic_Organ_Prolapse_Surgery
        , QPP428Elements.Documentation_Of_Urinalysis_G
        , QPP428Elements.Testing_For_Stress_Incontinence
      )
      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
          denominatorRDD.cache()
      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Intermediate A
      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate B
      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      // Filter Denominator Exception
      val exceptionRDD = getException(intermediateB)
      exceptionRDD.cache()

      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }


  // IPP-Denominator criteria
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    rdd.filter(visit =>
      isFemale(visit,m)
      &&
      isProcedurePerformedDuringEncounter(visit,m,QPP428Elements.Pelvic_Organ_Prolapse_Surgery)
    )
  }




  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        isAssessmentPerformedDuringProcedure(visit, m
          , QPP428Elements.Preoperative_Assessment
          , QPP428Elements.Preoperative_Assessment_Date
          , QPP428Elements.Pelvic_Organ_Prolapse_Surgery
          , QPP428Elements.Pelvic_Organ_Prolapse_Surgery_Date
        )
          ||
          (
            isDiagnosisOnEncounter(visit, m, QPP428Elements.History_Of_Incontinence_And_Its_Character_G)
              &&
              wasDiagnosisPerformedEndsBeforeStartOfProcedure(visit, m
                , QPP428Elements.Pelvic_Organ_Prolapse_Surgery
                , patientHistoryList
                , QPP428Elements.History_Of_Incontinence_And_Its_Character_G
              )
              &&
              (
                isInterventionPerformedOnEncounter(visit, m, QPP428Elements.Documentation_Of_Urinalysis_G)
                  &&
                  wasInterventionPerformedEndsBeforeStartOfProcedure(visit, m
                    , QPP428Elements.Pelvic_Organ_Prolapse_Surgery
                    , patientHistoryList
                    , QPP428Elements.Documentation_Of_Urinalysis_G
                  )
                )
              &&
              (
                isPhysicalExamPerformedDuringEncounter(visit, m, QPP428Elements.Testing_For_Stress_Incontinence)
                  &&
                  wasPhysicalExamsPerformedEndsBeforeStartOfProcedure(visit, m
                    , QPP428Elements.Pelvic_Organ_Prolapse_Surgery
                    , patientHistoryList
                    , QPP428Elements.Testing_For_Stress_Incontinence
                  )
                )
            )
        )
        && !isAssessmentPerformedDuringProcedure(visit, m
        , QPP428Elements.Preoperative_Assessment_Reason_Not_Specified
        , QPP428Elements.Preoperative_Assessment_Reason_Not_Specified_Date
        , QPP428Elements.Pelvic_Organ_Prolapse_Surgery
        , QPP428Elements.Pelvic_Organ_Prolapse_Surgery_Date
      )
    )
  }


  // Denominator Exception criteria
  def getException(intermediateB: RDD[CassandraRow]): RDD[CassandraRow] = {
    var m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateB.filter(visit =>
      isAssessmentPerformedDuringProcedure(visit, m
        , QPP428Elements.Pre_Operative_Assess_Medical_Reason
        , QPP428Elements.Pre_Operative_Assess_Medical_Reason_Date
        , QPP428Elements.Pelvic_Organ_Prolapse_Surgery
        , QPP428Elements.Pelvic_Organ_Prolapse_Surgery_Date
      )
      ||
      isDiagnosisListDuringProcedure(visit, m, QPP428Elements.Gynecologic_Or_Pelvic_Malignancy, QPP428Elements.Pelvic_Organ_Prolapse_Surgery)
    )


  }
}