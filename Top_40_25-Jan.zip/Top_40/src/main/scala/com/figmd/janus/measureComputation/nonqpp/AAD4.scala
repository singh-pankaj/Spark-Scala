package com.figmd.janus.measureComputation.nonqpp
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AAD4Elements, CalenderUnit, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD4
* Measure Title              :- Basal Cell Carcinoma/Squamous Cell Carcinoma: Mohs Surgery for Squamous Cell Carcinoma in Situ or Keratoacanthoma Type Squamous Cell Carcinoma 1 cm or Smaller on the Trunk
* Measure Description        :- The percentage of immune‐competent patients with pathologically‐proven primary squamous carcinoma in situ (SCCis) lesions of any size on the trunk (chest, back, abdomen) or
* Keratoacanthoma type squamous cell carcinoma (SCC‐KA) lesions 1 cm or smaller on the trunk (chest, back, abdomen) who are treated with Mohs surgery.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/

object AAD4 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAD4"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      AAD4Elements.Mohs_Surgery_Grp,
      AAD4Elements.Ssc_Ka_Lesions_Size,
      AAD4Elements.Cutaneous_Biopsy_Of_Trunk_Grp,
      AAD4Elements.Squamous_Cell_Carcinoma_Of_The_Trunk_Grp,
      AAD4Elements.Keratoacanthoma_Scc,
      AAD4Elements.Scc_Insitu,
      AAD4Elements.Immunocompromised_Conditions,
      AAD4Elements.Hiv,
      AAD4Elements.Organ_Transplant,
      AAD4Elements.Hematologic_Malignancy_Grp,
      AAD4Elements.Active_Pharmacologic_Immunosuppression,
      AAD4Elements.Basal_Cell_Nevus_Syndrome,
      AAD4Elements.Muir_Torre_Syndrome,
      AAD4Elements.Xeroderma_Pigmentosus_Grp,
      AAD4Elements.Li_Fraumeni_Syndrome,
      AAD4Elements.Bazex_Syndrome,
      AAD4Elements.History_Of_Tumor_In_Area_Of_Radiation_Grp).collect().toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter denominator Exclusions
      val denominatorExclusionRDD = getDenominatorExclusionRdd(ippRDD, patientHistoryList)
      denominatorExclusionRDD.cache()

      //eligible initial population RDD
      val intermediateA = getSubtractRDD(ippRDD, denominatorExclusionRDD)

      // Filter Intermediate Met
      val intermediateB = getMet(intermediateA, patientHistoryList)
      intermediateB.cache()

      // Filter Numerator Exclusion
      val numeratorExclusionRDD = getNumeratorExclusionRdd(intermediateB, patientHistoryList)

      //Met
      val metRDD = getSubtractRDD(intermediateB, numeratorExclusionRDD)

      // Filter not met
      val intermediateC = getSubtractRDD(intermediateB, metRDD)
      val notMetRDD = getSubtractRDD(intermediateC, numeratorExclusionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, denominatorExclusionRDD, metRDD, numeratorExclusionRDD, notMetRDD, MEASURE_NAME)
    }

  }

  //All pathologically-proven primary superficial basal cell carcinoma (BCC) lesions on the trunk (chest, back, abdomen) on immune-competent patients treated by the provider within the reporting period.
  //Ages 18 and older at the start of the measurement period
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit=>
      isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
      &&
      wasProcedurePerformedInHistory(visit,m,AAD4Elements.Cutaneous_Biopsy_Of_Trunk_Grp,patientHistoryList)
      &&(
        wasDiagnosedAfterProcedure(visit,m,AAD4Elements.Squamous_Cell_Carcinoma_Of_The_Trunk_Grp_Date,patientHistoryList,AAD4Elements.Cutaneous_Biopsy_Of_Trunk_Grp)
          &&
        wasDiagnosedInHistory(visit,m,AAD4Elements.Squamous_Cell_Carcinoma_Of_The_Trunk_Grp,patientHistoryList)
        )
    )
  }

  /*Patients whose immune system is compromised by disease or active treatment of disease.

    Examples of immunocompromised patients include but are not limited to HIV, organ transplant, hematologic malignancy, or pharmacologic immunosuppression.

    • Patients who have a genetic syndrome that increases their risk for skin cancer due to decreased immune response or abnormalities in the skin cell cycle.

    Examples of genetic syndromes include but are not limited to Basal Cell Nevus Syndrome, Muir Torre Syndrome, Xeroderma Pigmentosus, Li Fraumeni Syndrome, and Bazex Syndrome.

    • Tumors in areas of previous radiation therapy.
  */
  def getDenominatorExclusionRdd(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    rdd.filter(visit=>
      wasDiagnosedWithInHistory(visit,m,AAD4Elements.Immunocompromised_Conditions,patientHistoryList)
      || wasDiagnosedWithInHistory(visit,m,AAD4Elements.Hiv,patientHistoryList)
      || wasDiagnosedWithInHistory(visit,m,AAD4Elements.Organ_Transplant,patientHistoryList)
      || wasDiagnosedWithInHistory(visit,m,AAD4Elements.Hematologic_Malignancy_Grp,patientHistoryList)
      || wasDiagnosedWithInHistory(visit,m,AAD4Elements.Active_Pharmacologic_Immunosuppression,patientHistoryList)
      || wasDiagnosedWithInHistory(visit,m,AAD4Elements.Basal_Cell_Nevus_Syndrome,patientHistoryList)
      || wasDiagnosedWithInHistory(visit,m,AAD4Elements.Muir_Torre_Syndrome,patientHistoryList)
      || wasDiagnosedWithInHistory(visit,m,AAD4Elements.Xeroderma_Pigmentosus_Grp,patientHistoryList)
      || wasDiagnosedWithInHistory(visit,m,AAD4Elements.Li_Fraumeni_Syndrome,patientHistoryList)
      || wasDiagnosedWithInHistory(visit,m,AAD4Elements.Bazex_Syndrome,patientHistoryList)
      || wasDiagnosedWithInHistory(visit,m,AAD4Elements.History_Of_Tumor_In_Area_Of_Radiation_Grp,patientHistoryList)
    )
  }

  /*Number of patients with pathologically‐proven primary SCCis or SCC‐KA lesions of the trunk treated by the provider utilizing Mohs surgery [CPT 17313].*/
  def getMet(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    rdd.filter(visit=>
      (
        wasDiagnosedAfterProcedure(visit,m,AAD4Elements.Mohs_Surgery_Grp,patientHistoryList,AAD4Elements.Squamous_Cell_Carcinoma_Of_The_Trunk_Grp,AAD4Elements.Scc_Insitu)
        &&
        (
          wasDiagnosedAfterProcedure(visit,m,AAD4Elements.Scc_Insitu,patientHistoryList,AAD4Elements.Cutaneous_Biopsy_Of_Trunk_Grp,AAD4Elements.Scc_Insitu)
          && wasDiagnosedInHistory(visit,m,AAD4Elements.Scc_Insitu,patientHistoryList)
        )
      )
      ||
      (
        (
          wasElementPresentAfter(visit,m,AAD4Elements.Mohs_Surgery_Grp_Date,patientHistoryList,Seq(AAD4Elements.Squamous_Cell_Carcinoma_Of_The_Trunk_Grp,AAD4Elements.Keratoacanthoma_Scc))
          &&
          isDiagnosticStudyPerformedAfterWithValue(visit,m,AAD4Elements.Mohs_Surgery_Grp,AAD4Elements.Mohs_Surgery_Grp_Date,1,"lt",patientHistoryList,AAD4Elements.Ssc_Ka_Lesions_Size)
          &&
          wasDiagnosedAfterProcedure(visit,m,AAD4Elements.Mohs_Surgery_Grp,patientHistoryList,AAD4Elements.Squamous_Cell_Carcinoma_Of_The_Trunk_Grp,AAD4Elements.Keratoacanthoma_Scc)
        )
        &&
        (
          isDiagnosticStudyPerformedAfterWithValue(visit,m,AAD4Elements.Cutaneous_Biopsy_Of_Trunk_Grp,AAD4Elements.Cutaneous_Biopsy_Of_Trunk_Grp_Date,1,"lt",patientHistoryList,AAD4Elements.Ssc_Ka_Lesions_Size)
          &&
            (isDiagnosis(visit,m,AAD4Elements.Keratoacanthoma_Scc,patientHistoryList)
            && isDiagnosticStudyPerformed(visit,m,AAD4Elements.Ssc_Ka_Lesions_Size,patientHistoryList)
            )
        )
      )
    )
  }

  /*• Squamous cell carcinoma in situ (SCCis) tumors that have pathologically documented areas of dermal invasion, or dermal invasion is found on any stage if Mohs surgery is performed.

  Examples of pathology report documentation for this exclusion include but are not limited to:

  1) Pathology report states that it cannot exclude a deeper or more aggressive tumor histology for any reason other than because it is a partial biopsy sample
  2) Pathology report states that there is a collision tumor with another tumor that has a more aggressive histology*/
  def getNumeratorExclusionRdd(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    rdd.filter(visit=>
      wasDiagnosedAfterProcedure(visit,m,AAD4Elements.Dermal_Invasion_Date,patientHistoryList,AAD4Elements.Mohs_Surgery_Grp)
    )
  }

  }
