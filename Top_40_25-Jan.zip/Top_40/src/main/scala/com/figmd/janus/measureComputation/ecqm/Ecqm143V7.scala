package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ECQM143V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ECQM 143
* Measure Title              :- Primary Open-Angle Glaucoma (POAG): Optic Nerve Evaluation
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of primary open-angle glaucoma (POAG) who have an optic nerve head evaluation during one or more office visits within 12 months
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm143V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm143V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP


    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val metRDD = getMet(ippRDD)
      metRDD.cache()
      // Filter Met

      val intermediateA = getSubtractRDD(ippRDD, metRDD)
      intermediateA.cache()

      val exceptionRDD = getExceptionRDD(intermediateA)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()


      //val notEligible = sparkSession.sparkContext.emptyRDD[CassandraRow]
      val exclusionRdd = sparkSession.sparkContext.emptyRDD[CassandraRow]

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRdd, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


    }
  }


  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 18)
        && (isDiagnosedWithOnEncounter(visit, m, ECQM143V7Elements.Primary_Open_Angle_Glaucoma)
        && areBothDiagnosesOnSameDate(visit, m, ECQM143V7Elements.Primary_Open_Angle_Glaucoma_Eye, ECQM143V7Elements.Primary_Open_Angle_Glaucoma)
        && isVisitTypeIn(visit, m, ECQM143V7Elements.Ophthalmological_Services,
        ECQM143V7Elements.Ophthalmological_Services,
        ECQM143V7Elements.Nursing_Facility_Visit,
        ECQM143V7Elements.Office_Visit,
        ECQM143V7Elements.Outpatient_Consultation)
        )
    )
  }


  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>

      diagnosticStudyPerformed(visit, m, ECQM143V7Elements.Cup_To_Disc_Ratio)
        && areBothDiagnosesOnSameDate(visit, m, ECQM143V7Elements.Cup_To_Disc_Ratio__Eye, ECQM143V7Elements.Cup_To_Disc_Ratio)
        && checkEyeElementsInRange(visit, m, ECQM143V7Elements.Primary_Open_Angle_Glaucoma_Eye, ECQM143V7Elements.Cup_To_Disc_Ratio__Eye)
        && diagnosticStudyPerformed(visit, m, ECQM143V7Elements.Optic_Disc_Exam_For_Structural_Abnormalities)
        && checkEyeElementsInRange(visit, m, ECQM143V7Elements.Optic_Disc_Exam_For_Structural_Abnormalities__Eye, ECQM143V7Elements.Primary_Open_Angle_Glaucoma_Eye, ECQM143V7Elements.Cup_To_Disc_Ratio__Eye)
    )
  }

  def getExceptionRDD(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateA.filter(visit => (
      isDiagnosticPerformedNotDoneOnEncounter(visit, m, ECQM143V7Elements.Optic_Disc_Exam_For_Structural_Abnormalities)
        && isDiagnosticPerformedNotDoneOnEncounter(visit, m, ECQM143V7Elements.Cup_To_Disc_Ratio))
    )
  }
}