package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, ECQM52V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 52
* Measure Title              :-HIV/AIDS: Pneumocystis Jiroveci Pneumonia (PCP) Prophylaxis
* Measure Description        :- Percentage of patients aged 6 weeks and older with a diagnosis of HIV/AIDS who were prescribed Pneumocystis jiroveci pneumonia (PCP) prophylaxis
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 3
* Measure Stratification     :- 3
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm52V7_3 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm52V7_3"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val getPatientHistoryList = getPatientHistory(sparkSession, initialRDD,
      ECQM52V7Elements.Hiv_1,
      ECQM52V7Elements.Office_Visit,
      ECQM52V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up,
      ECQM52V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up,
      ECQM52V7Elements.Preventive_Care__Established_Office_Visit__0_To_17,
      ECQM52V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,
      ECQM52V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,
      ECQM52V7Elements.Outpatient_Consultation,
      ECQM52V7Elements.Encounter_Inpatient,
      ECQM52V7Elements.Discharged_To_Home_For_Hospice_Care,
      ECQM52V7Elements.Cd4__Count,
      ECQM52V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care,
      ECQM52V7Elements.Hospice_Care_Ambulatory,
      ECQM52V7Elements.Pneumocystis_Jiroveci_Pneumonia__Pcp__Prophylaxis,
      ECQM52V7Elements.Dapsone_And_Pyrimethamine,
      ECQM52V7Elements.Leucovorin
    )
    val least_recent_patient_history = leastRecentPatientList(getPatientHistoryList, ECQM52V7Elements.Hiv_1)
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList.collect().toList)
    val least_patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(least_recent_patient_history)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList, least_patientHistoryList)
    ippRDD.cache()


    //eligible RDD
    val denominatorRDD = ippRDD
    denominatorRDD.cache()

    // Filter Exclusions
    val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
    exclusionRDD.cache()

    // Filter Intermediate RDD
    val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA, patientHistoryList)
    metRDD.cache()

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA, metRDD)
    notMetRDD.cache()

    saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    patientHistoryList.destroy()
    least_patientHistoryList.destroy()
  }

  //Initial Population 3: All patients aged 6 weeks to 12 months with a diagnosis of HIV who had at least two visits during the measurement year, with at least 90 days in between each visit
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], least_patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 6, CalenderUnit.WEEK)
        && isAgeBelowBeforeStart(visit, m, false, 1, CalenderUnit.WEEK)
        && wasFirstDiagnosed(visit, m, ECQM52V7Elements.Hiv_1, least_patientHistoryList)
        && (
        wasEncounterAfterXDaysOfElement(visit, m, ECQM52V7Elements.Office_Visit, 90, patientHistoryList)
          || wasEncounterAfterXDaysOfElement(visit, m, ECQM52V7Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up, 90, patientHistoryList)
          || wasEncounterAfterXDaysOfElement(visit, m, ECQM52V7Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up, 90, patientHistoryList)
          || wasEncounterAfterXDaysOfElement(visit, m, ECQM52V7Elements.Preventive_Care__Established_Office_Visit__0_To_17, 90, patientHistoryList)
          || wasEncounterAfterXDaysOfElement(visit, m, ECQM52V7Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17, 90, patientHistoryList)
          || wasEncounterAfterXDaysOfElement(visit, m, ECQM52V7Elements.Outpatient_Consultation, 90, patientHistoryList)

        )

    )

  }


  //Exclude patients whose hospice care overlaps the measurement periodExclude patients whose
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isEncounterPerformedWithDischargeStatus(visit, m, ECQM52V7Elements.Encounter_Inpatient, ECQM52V7Elements.Discharged_To_Home_For_Hospice_Care, patientHistoryList)
        || isEncounterPerformedWithDischargeStatus(visit, m, ECQM52V7Elements.Encounter_Inpatient, ECQM52V7Elements.Discharged_To_Health_Care_Facility_For_Hospice_Care, patientHistoryList)
        || wasInterventionPerformedInHistory(visit, m, ECQM52V7Elements.Hospice_Care_Ambulatory, patientHistoryList)


    )
  }

  //Numerator 3: Patients who were prescribed Pneumocystis jiroveci pneumonia (PCP) prophylaxis at the time of diagnosis of HIV
  def getMet(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      isMedicationOrderedAfterAssessmentWithInXDays(visit, m, ECQM52V7Elements.Hiv_1, ECQM52V7Elements.Pneumocystis_Jiroveci_Pneumonia__Pcp__Prophylaxis, 1, patientHistoryList)


    )


  }


}


