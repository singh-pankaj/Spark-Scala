package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP390Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


/*--------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 390
* Measure Title              :- Hepatitis C: Discussion and Shared Decision Making Surrounding Treatment Options
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of hepatitis C with whom a physician or other
                                qualified healthcare professional reviewed the range of treatment options appropriate to their genotype and
                                demonstrated a shared decision making approach with the patient. To meet the measure, there must be
                                documentation in the patient record of a discussion between the physician or other qualified healthcare professional and the patient that includes all of the following: treatment choices appropriate to genotype, risks and benefits, evidence of effectiveness, and patient preferences toward treatment.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp390 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp390"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP390Elements.Chronic_Hepatitis_C,
      QPP390Elements.Hep_C_Treatment_Discussion,
      QPP390Elements.Risks_And_Benefits,
      QPP390Elements.Risk_Assessment,
      QPP390Elements.Counseling_Benefits,
      QPP390Elements.Evidence_Of_Effectiveness,
      QPP390Elements.Patient_Preferences,
      QPP390Elements.Treatment_Choices,
      QPP390Elements.Hep_C_Treatment_Discussion_Not_Met,
      QPP390Elements.Antivirals_For_Hepatits_C,
      QPP390Elements.Patient_Unable_To_Participate,
      QPP390Elements.Physical_Disability,
      QPP390Elements.Psychotic_Disorder_Or_Related_Condition,
      QPP390Elements.Active_Substance_Abuse,
      QPP390Elements.Hep_C_Treatment_Discussion_Medical_Reason,
      QPP390Elements.Medical_Reason,
      QPP390Elements.Patient_Reason_Refused).collect.toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)


    //  Filter IPP-
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateB = getSubtractRDD(ippRDD, metRDD)
      intermediateB.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateB, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }
  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : All patients aged 18 years and older with a diagnosis of chronic hepatitis C
----------------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
         isPatientAdult(visit,m)
      && isVisitTypeIn(visit,m,QPP390Elements.Office_Visit)
      && isDiagnosisOverlapsEncounter(visit,m,patientHistoryBroadcastList,QPP390Elements.Chronic_Hepatitis_C)
    )

  }


  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Patients with whom a physician or other qualified healthcare professional reviewed the range of treatment options
appropriate to their genotype and demonstrated a shared decision making approach with the patient
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(ipp: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    ipp.filter(visit =>
         isCommunicationFromProvidertoPatient(visit,m,QPP390Elements.Hep_C_Treatment_Discussion,patientHistoryBroadcastList)
      || (
              isCommunicationFromProvidertoPatient(visit,m,QPP390Elements.Risks_And_Benefits,patientHistoryBroadcastList)
           || (
                   isCommunicationFromProvidertoPatient(visit,m,QPP390Elements.Risk_Assessment,patientHistoryBroadcastList)
                && isCommunicationFromProvidertoPatient(visit,m,QPP390Elements.Counseling_Benefits,patientHistoryBroadcastList)
              )
           || isCommunicationFromProvidertoPatient(visit,m,QPP390Elements.Evidence_Of_Effectiveness,patientHistoryBroadcastList)
           || isCommunicationFromProvidertoPatient(visit,m,QPP390Elements.Patient_Preferences,patientHistoryBroadcastList)
           || isCommunicationFromProvidertoPatient(visit,m,QPP390Elements.Treatment_Choices,patientHistoryBroadcastList)

         )
      && !isCommunicationFromProvidertoPatient(visit,m,QPP390Elements.Hep_C_Treatment_Discussion_Not_Met,patientHistoryBroadcastList)
    )
  }



  /*--------------------------------------------------------------------------------------------------------------------------
Denominator Exceptions : Documentation of medical or patient reason(s) for not discussing treatment options.
Medical reasons: Patient is not a candidate for treatment due to advanced physical or mental health comorbidity (including active substance use);
currently receiving antiviral treatment; successful antiviral treatment (with sustained virologic response) prior to reporting period; other documented medical reasons.
Patient reasons: Patient unable or unwilling to participate in the discussion or other patient reasons.
----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermedaiateRdd: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermedaiateRdd.filter(visit =>
         wasMedicationOrderBeforeOrEqualEncounter(visit,m,QPP390Elements.Antivirals_For_Hepatits_C,patientHistoryBroadcastList)
      || wasMedicationOrderBefore(visit,m,patientHistoryBroadcastList,QPP390Elements.Antivirals_For_Hepatits_C)
      || isInterventionPerformed(visit,m,QPP390Elements.Patient_Unable_To_Participate,patientHistoryBroadcastList)
      || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP390Elements.Physical_Disability,patientHistoryBroadcastList)
      || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP390Elements.Psychotic_Disorder_Or_Related_Condition,patientHistoryBroadcastList)
      || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP390Elements.Active_Substance_Abuse,patientHistoryBroadcastList)
      || isCommunicationFromProvidertoPatient(visit,m,QPP390Elements.Hep_C_Treatment_Discussion_Medical_Reason,patientHistoryBroadcastList)
      || isDiagnosed(visit,m,QPP390Elements.Medical_Reason,patientHistoryBroadcastList)
      || isCommunicationFromPatientToProvider(visit,m,QPP390Elements.Patient_Reason_Refused,patientHistoryBroadcastList)

    )
  }
}


