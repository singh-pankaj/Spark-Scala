package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, CompareOperator, MeasureProperty, QPP474Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Qpp474
* Measure Title               :- Ischemic Vascular Disease Use of Aspirin or Anti-platelet Medication
* Measure Description         :- The percentage of patients 18-75 years of age who had a diagnosis of ischemic vascular
                                 disease (IVD) and were on daily aspirin or anti-platelet medication during the performance
                                 period, unless allowed contraindications or exceptions are present
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SANKET.DHAPTE
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_ACC_NonQPP_1.7
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp474 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp474"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,QPP474Elements.Ischemic_Vascular_Disease
      ,QPP474Elements.Permanent_Nursing_Home_Resident_G_Grp
      ,QPP474Elements.Hospice_Or_Palliative_Care_Grp
      ,QPP474Elements.Patient_Deceased_G_Grp
      ,QPP474Elements.Urgent_Care_Visits_G_Grp
      ,QPP474Elements.Permanent_Nursing_Home_Resident
      ,QPP474Elements.Palliative_Care
      ,QPP474Elements.Hospice_Care
      ,AdminElements.Expired
      ,QPP474Elements.Aspirin_Or_Another_Antiplatelet_Documented_Reason_Grp
      ,QPP474Elements.Aspirin_Or_Antiplatelets_Medications
      ,QPP474Elements.Asprin_Or_Antiplatelet_Not_Met_Grp
      ,QPP474Elements.Aspirin_Or_Another_Antiplatelet_Documented_Reason_Grp
      ,QPP474Elements.Non_Steroidal_Anti_Inflammatory_Drug__Nsaids_
      ,QPP474Elements.Systolic_Blood_Pressure
      ,QPP474Elements.Diastolic_Blood_Pressure
      ,QPP474Elements.Allergy_To_Medication_Grp
      ,QPP474Elements.Drug_Drug_Interaction
      ,QPP474Elements.Gi_Bleeding
      ,QPP474Elements.Intracranial_Bleeding_Grp
      ,QPP474Elements.Gastroesophageal_Reflux_Disease
      ,QPP474Elements.Oral_Anticoagulant_Medications

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Patients 18 years or older at the start of the performance period AND less than 76 years at the end of the
    performance period
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
          isAgeBetween(visit,m,18,CompareOperator.GREATER_EQUAL,76,CompareOperator.LESS)
      &&  isVisitTypeIn(visit,m
                                ,QPP474Elements.Office_Visit
                                ,QPP474Elements.Periodic_Preventive_Medicine_Evaluation_Grp)
      &&  wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP474Elements.Ischemic_Vascular_Disease,patientHistoryBroadcastList)
      &&  !isTeleHealthModifier(visit,m
                                ,QPP474Elements.Office_Visit_Telehealth_Modifier
                                ,QPP474Elements.Periodic_Preventive_Medicine_Evaluation_Telehealth_Modifier)
      &&  isPOSEncounterNotPerformed(visit,m,QPP474Elements.Pos_02)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Patient was a permanent nursing home resident at any time during the performance period
    OR
    Patient was in hospice or receiving palliative care at any time during the performance period
    OR
    Patient died prior to the end of the performance period
    OR
    Patient had only urgent care visits during the performance period
  -----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
         isAssessmentPerformed(visit,m,QPP474Elements.Permanent_Nursing_Home_Resident_G_Grp,patienthistoryList)
      || isAssessmentPerformed(visit,m,QPP474Elements.Hospice_Or_Palliative_Care_Grp,patienthistoryList)
      || isAssessmentPerformed(visit,m,QPP474Elements.Patient_Deceased_G_Grp,patienthistoryList)
      || isAssessmentPerformed(visit,m,QPP474Elements.Urgent_Care_Visits_G_Grp,patienthistoryList)
      || isEncounterPerformed(visit,m,QPP474Elements.Permanent_Nursing_Home_Resident,patienthistoryList)
      || isProcedurePerformed(visit,m,QPP474Elements.Palliative_Care,patienthistoryList)
      || isProcedurePerformed(visit,m,QPP474Elements.Hospice_Care,patienthistoryList)
      || isPatientCharacteristic(visit,m,AdminElements.Expired,patienthistoryList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients with documentation that the patient was on daily aspirin or anti-platelet medication during the performance
  period, unless allowed contraindications or exceptions are present.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
          isAssessmentPerformed(visit,m,QPP474Elements.Aspirin_Or_Another_Antiplatelet_Documented_Reason_Grp,patienthistoryList)
       || isMedicationActiveOrdered(visit,m,QPP474Elements.Aspirin_Or_Antiplatelets_Medications,patienthistoryList)
      )
   && isAssessmentPerformed(visit,m,QPP474Elements.Asprin_Or_Antiplatelet_Not_Met_Grp,patienthistoryList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Prescribed anticoagulant medication during the
    performance period, history of GI bleeding, history of
    intracranial bleeding, bleeding disorder and specific
    provider documented reasons: allergy to aspirin or
    anti-platelets, use of non-steroidal anti-inflammatory
    agents, drug-drug interaction, uncontrolled
    hypertension > 180/110 mmHg or gastroesophageal
    reflux disease
  -----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
         isAssessmentPerformed(visit,m,QPP474Elements.Aspirin_Or_Another_Antiplatelet_Documented_Reason_Grp,patienthistoryList)
      || isMedicationActiveOrdered(visit,m,QPP474Elements.Non_Steroidal_Anti_Inflammatory_Drug__Nsaids_,patienthistoryList)
      ||
           (
               checkPhysicalExamPerformedValue(visit,m,QPP474Elements.Systolic_Blood_Pressure,180,CompareOperator.GREATER,patienthistoryList)
             && checkPhysicalExamPerformedValue(visit,m,QPP474Elements.Diastolic_Blood_Pressure,110,CompareOperator.GREATER,patienthistoryList)
         )
      || isMedicationActiveOrdered(visit,m,QPP474Elements.Allergy_To_Medication_Grp,patienthistoryList)
      || isMedicationActiveOrdered(visit,m,QPP474Elements.Drug_Drug_Interaction,patienthistoryList)
      || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP474Elements.Gi_Bleeding,patienthistoryList)
      || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP474Elements.Intracranial_Bleeding_Grp,patienthistoryList)
      || wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP474Elements.Gastroesophageal_Reflux_Disease,patienthistoryList)
      || wasMedicationOrderNotDoneBeforeOrEqualEncounter(visit,m,QPP474Elements.Oral_Anticoagulant_Medications,patienthistoryList)
    )
  }
}
