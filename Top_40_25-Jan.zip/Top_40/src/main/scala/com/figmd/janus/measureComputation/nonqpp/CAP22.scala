

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAP22
* Measure Title               :- Turn-Around Time (TAT) - Standard biopsies
* Measure Description         :- Percentage of final pathology reports for biopsies that meet the maximum 2 business day turnaround time (TAT) requirement (Report Date – Accession Date ≤ 2 business days).
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- NA
* Measure Developer           :- Aanchal.Rai
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.8
----------------------------------------------------------------------------------------------------------------------------*/

object CAP22 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "CAP22"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      CAP22Elements.Specimen_Accession_Date,
      CAP22Elements.Specimen_Accession_Date,
      CAP22Elements.Consultation_CATII,
      CAP22Elements.Specimen_Verification_Date
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD )
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//IPP
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      wasLaboratoryTestPerformedBeforeEncounter(visit,m,CAP22Elements.Specimen_Accession_Date,patientHistoryBroadcastList)
      &&
      (
      isLaboratoryTestPerformedOnEncounter(visit,m, CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
      ||
        (
          isLaboratoryTestPerformedOnEncounter(visit,m, CAP22Elements.Confirm_Specimen_Is_A_Biopsy_88305)
          &&
          isLaboratoryTestPerformedOnEncounter(visit,m, CAP22Elements.IHC_Or_Molecular_Studies_Or_Special_Stains)
        )
      )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//Exclusion
  -----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        isLaboratoryTestPerformedOnEncounter(visit,m,CAP22Elements.Special_Handling_Cases_Grp)
        ||
        isLaboratoryTestPerformedOnEncounter(visit,m,CAP22Elements.Confirm_More_Than_Just_Standard_88305_Biopsy_Ies_Were_Received)
        ||
        isLaboratoryTestPerformedOnEncounter(visit,m,CAP22Elements.Cases_With_Special_Handling)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//Numerator
 -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
        isLaboratoryTestPerformedAfterWithinXDays(visit,m,CAP22Elements.Specimen_Verification_Date,CAP22Elements.Specimen_Accession_Date,2,patienthistoryList)
      ||
        wasLaboratoryTestPerformedAfterDiagnosis(visit,m,CAP22Elements.Pathology_Report_Verified,CAP22Elements.Specimen_Accession_Date,patienthistoryList)
        )
      &&
      ! wasLaboratoryTestPerformedAfterDiagnosis(visit,m,CAP22Elements.Report_Verification_Not_Met,CAP22Elements.Specimen_Accession_Date,patienthistoryList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
//Exception
 -----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>

     isLaboratoryTestPerformedOnEncounter(visit,m,CAP22Elements.Skin_Excision_With_Margin)
    ||
     isCommunicationFromProviderToProviderOnEncounter(visit,m,CAP22Elements.Confirm_Case_Required_Consultation)
    ||
     isCommunicationFromProvidertoProvider(visit,m,CAP22Elements.Consultation_CATII,patienthistoryList)

    )
  }
}
