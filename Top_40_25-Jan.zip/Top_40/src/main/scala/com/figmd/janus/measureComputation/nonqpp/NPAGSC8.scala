package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, NPAGSC8Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- NPAGSC8
* Measure Title               :- Complication Following Percutaneous Spine-Related Procedure
* Measure Description         :- Proportion of patients undergoing percutaneous spine-related procedures who have a complication
*                                (specifically, CSF leak, deep venous thrombosis [DVT], pulmonary embolism [PE], myocardial infarction [MI], stroke, procedure related infection or unexpected new neurological deficit) in the 30-day post-procedure period.
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SHREYA_ASHTEKAR_FIGMD_COM
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object NPAGSC8 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "NPAGSC8"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      NPAGSC8Elements.Spine_Symptoms,
      NPAGSC8Elements.Percutaneous_Spine_Related_Procedure,
      NPAGSC8Elements.Procedure_Related_Infection,
      NPAGSC8Elements.Csf_Leak,
      NPAGSC8Elements.Deep_Venous_Thrombosis,
      NPAGSC8Elements.Myocardial_Infarction,
      NPAGSC8Elements.Procedure_Related_Infection,
      NPAGSC8Elements.Stroke,
      NPAGSC8Elements.Unexpected_New_Neurological_Deficit
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)



    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    //if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    //}
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population:
Percentage of patients diagnosed with spine symptoms undergoing percutaneous spineâ€related procedures.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    val filteredRDD = getPatientRDDBetweenPeriodsInMeasurementPeriod(initialRDD, m, CalenderUnit.MONTH, 1, false)
    filteredRDD.filter(visit =>
      (
          wasDiagnosisBeforeorEqualEncounter(visit,m,NPAGSC8Elements.Spine_Symptoms,NPAGSC8Elements.Percutaneous_Spine_Related_Procedure,patientHistoryBroadcastList)
          &&
          wasDiagnosisStartsBeforeEndPriorToXMonths(visit,m,NPAGSC8Elements.Spine_Symptoms,1,patientHistoryBroadcastList)
      )
      &&
      (
          isProcedurePerformedDuringEncounter(visit,m,NPAGSC8Elements.Percutaneous_Spine_Related_Procedure)
          &&
          wasProcedurePerformedBeforeEndInXMonths(visit,m,NPAGSC8Elements.Percutaneous_Spine_Related_Procedure,1,patientHistoryBroadcastList)
          &&
          wasProcedureAfterDiagnosis(visit,m,NPAGSC8Elements.Percutaneous_Spine_Related_Procedure,patientHistoryBroadcastList,NPAGSC8Elements.Spine_Symptoms)
      )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator:
Number of patients undergoing percutaneous spine-related procedures who have a complication (specifically, CSF leak, deep venous thrombosis [DVT],
pulmonary embolism [PE], myocardial infarction [MI], stroke, procedure related infection or unexpected new neurological deficit) in the 30-day post-procedure period.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        isDiagnosedInXDaysAfterProcedure(visit,m,NPAGSC8Elements.Percutaneous_Spine_Related_Procedure,NPAGSC8Elements.Procedure_Related_Infection,30,patientHistoryBroadcastList)
        &&
        isDiagnosedInXDaysAfterProcedure(visit,m,NPAGSC8Elements.Percutaneous_Spine_Related_Procedure,NPAGSC8Elements.Csf_Leak,30,patientHistoryBroadcastList)
        &&
        isDiagnosedInXDaysAfterProcedure(visit,m,NPAGSC8Elements.Percutaneous_Spine_Related_Procedure,NPAGSC8Elements.Deep_Venous_Thrombosis,30,patientHistoryBroadcastList)
        &&
        isDiagnosedInXDaysAfterProcedure(visit,m,NPAGSC8Elements.Percutaneous_Spine_Related_Procedure,NPAGSC8Elements.Myocardial_Infarction,30,patientHistoryBroadcastList)
        &&
        isDiagnosedInXDaysAfterProcedure(visit,m,NPAGSC8Elements.Percutaneous_Spine_Related_Procedure,NPAGSC8Elements.Procedure_Related_Infection,30,patientHistoryBroadcastList)
        &&
        isDiagnosedInXDaysAfterProcedure(visit,m,NPAGSC8Elements.Percutaneous_Spine_Related_Procedure,NPAGSC8Elements.Stroke,30,patientHistoryBroadcastList)
        &&
        isDiagnosedInXDaysAfterProcedure(visit,m,NPAGSC8Elements.Percutaneous_Spine_Related_Procedure,NPAGSC8Elements.Unexpected_New_Neurological_Deficit,30,patientHistoryBroadcastList)
    )
  }
}