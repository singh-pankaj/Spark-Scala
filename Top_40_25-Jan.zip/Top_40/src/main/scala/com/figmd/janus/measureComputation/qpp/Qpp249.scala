package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP249Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 249
* Measure Title              :- Barrett’s Esophagus
* Measure Description        :- Percentage of esophageal biopsy reports that document the presence of Barrett’s mucosa that also include a statement about dysplasia
* Calculation Implementation :- Procedure-Specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp249 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp249"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP249Elements.Barrett_s_Esophagus,
      QPP249Elements.Level_Iv___Surgical_Pathology_Examination,
      QPP249Elements.Dysplasia
    )

    //val patientHistoryList = patientHistoryRDD.collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusion(ippRDD)
      exclusionRDD.cache()


      // Filter Intermediate A
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate B
      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      // Filter Denominator Exception
      val exceptionRDD = getException(intermediateB)
      exceptionRDD.cache()

      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }


  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      wasDiagnosisBeforeDiagnosticStudyOnEncounter(visit, m, QPP249Elements.Level_Iv___Surgical_Pathology_Examination, patientHistoryBroadcastList, QPP249Elements.Barrett_s_Esophagus)
    )
  }


  // Exclusion criteria
  def getExclusion(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      isLaboratoryTestPerformedOnEncounter(visit, m, QPP249Elements.Non_Esophageal_Specimen_Site)
        || isLaboratoryTestPerformedOnEncounter(visit, m, QPP249Elements.Specimen_Site_Other_Than_Anatomic_Location_Of_Esophagus)
    )
  }

  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (isLaboratoryTestPerformed(visit, m, QPP249Elements.Dysplasia, patientHistoryBroadcastList)
        || (
        isLaboratoryTestPerformedOnEncounter(visit, m, QPP249Elements.Barrett_s_Mucosa)
          && (
          isLaboratoryTestPerformedOnEncounter(visit, m, QPP249Elements.Dysplasia_Present)
            || isLaboratoryTestPerformedOnEncounter(visit, m, QPP249Elements.Dysplasia_Absent)
            || isLaboratoryTestPerformedOnEncounter(visit, m, QPP249Elements.Dysplasia_Indefinite)
          )
        )
        ) && !isLaboratoryTestPerformedOnEncounter(visit, m, QPP249Elements.Dysplasia_Reason_Not_Specified)
    )
  }


  // Denominator Exception criteria
  def getException(intermediateB: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateB.filter(visit =>

      !isLaboratoryTestPerformedOnEncounter(visit, m, QPP249Elements.Dysplasia_Medical_Reason)
        || (isDiagnosticStudyOnEncounter(visit, m, QPP249Elements.Absence_Of_Intestinal_Metaplasia)
        || isDiagnosisOnEncounter(visit, m, QPP249Elements.Malignant_Neoplasm_Of_Esophagus))
    )


  }
}

