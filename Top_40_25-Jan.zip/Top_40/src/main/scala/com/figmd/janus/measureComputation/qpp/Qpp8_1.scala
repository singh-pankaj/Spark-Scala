package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{AdminElements,  MeasureProperty, QPP8Elements}
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 8
* Measure Title              :- Heart Failure (HF): Beta-Blocker Therapy for Left Ventricular Systolic Dysfunction (LVSD)
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of heart failure (HF) with a current or prior left ventricular ejection fraction (LVEF) < 40%
*                               who were prescribed beta-blocker therapy either within a 12-month period when seen in the outpatient setting OR at each hospital discharge
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- A
* Measure Stratification     :- 2
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp8_1 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp8_1"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patient_history_list = getPatientHistory(sparkSession, initialRDD,
      QPP8Elements.Ejection_Fraction,
      QPP8Elements.Moderate_Or_Severe,
      QPP8Elements.Left_Ventricular_Systolic_Dysfunction,
      QPP8Elements.Left_Ventricular_Ejection_Fraction,
      QPP8Elements.Beta_Blocker_Therapy_For_Lvsd,
      QPP8Elements.Arrhythmia,
      QPP8Elements.Hypotension,
      QPP8Elements.Asthma,
      QPP8Elements.Allergy_To_Beta_Blocker_Therapy,
      QPP8Elements.Intolerance_To_Beta_Blocker_Therapy,
      QPP8Elements.Bradycardia,
      QPP8Elements.Beta_Blocker_Therapy_Ingredient

    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD, QPP8Elements.Office_Visit,
      QPP8Elements.Outpatient_Consultation,
      QPP8Elements.Nursing_Facility_Visit,
      QPP8Elements.Care_Services_In_Long_Term_Residential_Facility,
      QPP8Elements.Home_Healthcare_Services,
      QPP8Elements.Patient_Provider_Interaction)

    val historyRDD = getPatientHistory(sparkSession, initialRDD, QPP8Elements.Heart_Rate_2
    )

    val most_recent_patientLit = mostRecentPatientList(historyRDD, QPP8Elements.Heart_Rate_2)

    val mostRecentElementBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(most_recent_patientLit)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //eligible RDD
      val denominatorRDD = getdenominatorRDD(ippRDD, patientHistoryList)

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getexceptionRDD(intermediateA, patientHistoryList, mostRecentElementBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryList.destroy()
      mostRecentElementBroadcastList.destroy()
    }
  }
//SUBMISSION CRITERIA 1: ALL PATIENTS WITH A DIAGNOSIS OF HF SEEN IN THE OUTPATIENT SETTING
  def getIpp(rdd: RDD[CassandraRow],patientHistoryRDD:RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    val countElementList: List[(String,Int)] = countElement(patientHistoryRDD,m,
                                                                                QPP8Elements.Office_Visit,
                                                                                QPP8Elements.Outpatient_Consultation,
                                                                                QPP8Elements.Nursing_Facility_Visit,
                                                                                QPP8Elements.Care_Services_In_Long_Term_Residential_Facility,
                                                                                QPP8Elements.Home_Healthcare_Services,
                                                                                QPP8Elements.Patient_Provider_Interaction
                                                            )
    rdd.filter(visit =>
                              isPatientAdult (visit, m)
                          &&  isDiagnosisOnEncounter(visit,m,QPP8Elements.Heart_Failure)
                          &&  getEncounterCountFromHistory(visit,m,2, true,countElementList)
                          &&  isVisitTypeIn(visit,m,QPP8Elements.Care_Services_In_Long_Term_Residential_Facility,
                                                    QPP8Elements.Home_Healthcare_Services,
                                                    QPP8Elements.Nursing_Facility_Visit,
                                                    QPP8Elements.Office_Visit,
                                                    QPP8Elements.Outpatient_Consultation,
                                                    QPP8Elements.Patient_Provider_Interaction
                                            )
                          &&  ! isTeleHealthModifier(visit,m,
                                                              QPP8Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier,
                                                              QPP8Elements.Nursing_Facility_Visit_Telehealth_Modifier,
                                                              QPP8Elements.Office_Visit_Telehealth_Modifier,
                                                              QPP8Elements.Outpatient_Consultation_Telehealth_Modifier,
                                                              QPP8Elements.Home_Healthcare_Services_Telehealth_Modifier
                                                    )
                          &&	isPOSEncounterNotPerformed(visit,m,QPP8Elements.Pos_02)
             )
  }

  //Equals Initial Population with a current or prior LVEF <40%
  def getdenominatorRDD(ippRDD: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>

      (


        (
               wasDiagnosticStudyPerformedBeforeOrEqualEncounterWithResult(visit,m,QPP8Elements.Ejection_Fraction,40,"lt",patientHistoryList)
            || wasDiagnosedBeforeEndOfEncounter(visit,m,QPP8Elements.Moderate_Or_Severe,patientHistoryList)
            || wasDiagnosedBeforeEndOfEncounter(visit,m,QPP8Elements.Left_Ventricular_Systolic_Dysfunction,patientHistoryList)
          )
          ||
          wasDiagnosticStudyPerformedBeforeOrEqualEncounter(visit,m,QPP8Elements.Left_Ventricular_Ejection_Fraction,patientHistoryList)
        )

    )
  }

//SUBMISSION CRITERIA 1: Patients who were prescribed beta-blocker therapy within a 12 month period when seen in the outpatient setting
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>

                                (
                                       isMedicationOrderedDuringEncounter(visit, m, QPP8Elements.Beta_Blocker_Therapy_For_Lvsd)
                                    || wasMedicationActiveInHistory(visit, m, QPP8Elements.Beta_Blocker_Therapy_For_Lvsd, patientHistoryList)
                                    || isMedicationAdministeredOnEncounter(visit, m, QPP8Elements.Beta_Blocker_Therapy_G)
                                  )
                                  &&
                                  ! isMedicationAdministeredNotDoneOnEncounter(visit,m,QPP8Elements.Beta_Blocker_Therapy_Not_Met)


                              )

  }


//Beta-Blocker Therapy for LVEF < 40% not prescribed for reasons documented by
// the clinician (e.g., low blood pressure, fluid overload, asthma, patients recently treated with an intravenous positive inotropic agent, allergy, intolerance, other medical reasons, patient declined, other patient reasons,
// or other reasons attributable to the healthcare system)
  def getexceptionRDD(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]],mostRecentElementBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>

                                (
                                        isMostRecentPhysicalExamPerformedBefore(visit, m, QPP8Elements.Heart_Rate, QPP8Elements.Heart_Rate_2 ,mostRecentElementBroadcastList)
                                    &&  isPhysicalExamPerformedValueLessThanOnEncounter(visit, m, QPP8Elements.Heart_Rate, 50) //rebase or check
                                    &&  isPhysicalExamPerformedValueLessThanOnEncounter(visit, m, QPP8Elements.Heart_Rate_2, 50)
                                  )
                                  ||
                                  (
                                          isMedicationOrderedOnEncounter(visit, m, QPP8Elements.Medical_Reason)
                                      ||  isMedicationOrderedOnEncounter(visit, m, QPP8Elements.Patient_Reason)
                                      ||  isMedicationOrderedOnEncounter(visit, m, QPP8Elements.System_Reason_2018)
                                    )
                                  ||
                                  (
                                         isDiagnosisOverlapsEncounter(visit, m,patientHistoryList, QPP8Elements.Arrhythmia )
                                      || isDiagnosisOverlapsEncounter(visit, m, patientHistoryList,QPP8Elements.Hypotension )
                                      || isDiagnosisOverlapsEncounter(visit, m, patientHistoryList,QPP8Elements.Asthma )
                                      || isDiagnosisOverlapsEncounter(visit, m, patientHistoryList,QPP8Elements.Allergy_To_Beta_Blocker_Therapy )
                                      || wasMedicationInToleraneInHistory(visit, m, QPP8Elements.Beta_Blocker_Exception, patientHistoryList)
                                      || isDiagnosisOverlapsEncounter(visit, m,patientHistoryList, QPP8Elements.Intolerance_To_Beta_Blocker_Therapy  )
                                      || isDiagnosisOverlapsEncounter(visit, m, patientHistoryList,QPP8Elements.Bradycardia)
                                      || wasMedicationAllergyBeforeEncounter(visit, m, QPP8Elements.Beta_Blocker_Therapy_Ingredient,  patientHistoryList)
                                    )
                                  ||
                                  (
                                         isDiagnosisOverlapsEncounter(visit, m, patientHistoryList,QPP8Elements.Atrioventricular_Block  )
                                      && !wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP8Elements.Cardiac_Pacer_In_Situ, patientHistoryList)
                                      && !isDeviceAppliedBeforeEncounter(visit, m, QPP8Elements.Cardiac_Pacer, patientHistoryList)
                                    )
                                  ||
                                  isMedicationAdministeredNotDoneOnEncounter(visit,m,QPP8Elements.Beta_Blocker_Therapy__Documented_Reasons)

                              )



  }

}