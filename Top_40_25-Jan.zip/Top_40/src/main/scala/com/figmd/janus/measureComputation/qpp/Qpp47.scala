package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP47Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 047
* Measure Title              :- Advance Care Plan
* Measure Description        :- Percentage of patients aged 65 years and older who have an advance care plan or surrogate decision maker documented in the
                                medical record or documentation in the medical record that an advance care plan was discussed but the patient did not wish
                                or was not able to name a surrogate decision maker or provide an advance care plan
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp47 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp47"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD, QPP47Elements.Hospice_Services,
        QPP47Elements.Hospice_Services_Snomedct,
        QPP47Elements.Hospice_Care,
        QPP47Elements.Documentation_Of_Advance_Care_Plan_Or_Surrogate_Decision_Maker,
        QPP47Elements.Documentation_Of_Advance_Care_Plan,
        QPP47Elements.Advance_Care_Reason_Not_Specified)
      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      /*exclusion RDD*/
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*------------------------------------------------------------------------------
  All patients aged 65 years and older
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
      (isAgeAbove(visit,m,true,65)
        && isVisitTypeIn(visit, m, QPP47Elements.Subsequent_Hospital_Care,
        QPP47Elements.Annual_Wellness_Visit,
        QPP47Elements.Home_Healthcare_Services,
        QPP47Elements.Care_Services_In_Long_Term_Residential_Facility,
        QPP47Elements.Nursing_Facility_Visit,
        QPP47Elements.Discharge_Services___Hospital_Inpatient_Same_Day_Discharge,
        QPP47Elements.Hospital_Inpatient_Visit___Initial,
        QPP47Elements.Hospital_Observation_Care___Initial,
        QPP47Elements.Office_Visit,
        QPP47Elements.Critical_Care,
        QPP47Elements.Initial_Preventive_Physical_Examination)
        && isPOSEncounterNotPerformed(visit,m,QPP47Elements.Pos_23)
        )
    )
  }

  /*------------------------------------------------------------------------------
  Hospice services received by patient any time during the measurement period
   ------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      isInterventionPerformed(visit,m,QPP47Elements.Hospice_Services,patientHistoryList)
        || (   wasInterventionPerformedInHistory(visit,m,QPP47Elements.Hospice_Services_Snomedct,patientHistoryList)
        || wasInterventionPerformedInHistory(visit,m,QPP47Elements.Hospice_Care,patientHistoryList)
        )
    )
  }

  /*------------------------------------------------------------------------------
  Patients who have an advance care plan or surrogate decision maker documented in the medical record
  or documentation in the medical record that an advance care plan was discussed but patient did not wish
  or was not able to name a surrogate decision maker or provide an advance care plan
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      ( wasInterventionPerformedInHistory(visit,m,QPP47Elements.Documentation_Of_Advance_Care_Plan_Or_Surrogate_Decision_Maker,patientHistoryList)
        || wasInterventionPerformedInHistory(visit,m,QPP47Elements.Documentation_Of_Advance_Care_Plan,patientHistoryList))
        && ! isInterventionPerformedDuringEncounter(visit,m,QPP47Elements.Advance_Care_Reason_Not_Specified)
    )
  }
}