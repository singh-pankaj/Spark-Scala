package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ACR03Elements, CalenderUnit, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACR 03
* Measure Title              :- Advanced: Disease-Modifying Anti-Rheumatic Drug (DMARD) Therapy for Active Rheumatoid Arthritis (RA)
* Measure Description        :- Percentage of patients 18 years and older with active rheumatoid arthritis who are treated with a disease-modifying anti-rheumatic drug (DMARD) during the measurement period.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Vrushali Gholap
----------------------------------------------------------------------------------------------------------------------------*/
object ACR03 extends MeasureUtilityUpdate with MeasureUpdate {

val MEASURE_NAME = "ACR03"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistory: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD,
      ACR03Elements.Active_Rheumatoid_Arthritis,
      ACR03Elements.Hiv,
      ACR03Elements.Face_To_Face_Interaction,
      ACR03Elements.Home_Healthcare_Services,
      ACR03Elements.Care_Services_In_Long_Term_Residential_Facility,
      ACR03Elements.Office_Visit,
      ACR03Elements.Nursing_Facility_Visit,
      ACR03Elements.Outpatient_Consultation,
      ACR03Elements.Documentation_Of_Inactive_Rheumatoid_Arthritis
    )


    val patienthistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistory.collect().toList)

    // Filter IPP
    val ippRDD = getIppRDD(initialRDD, patienthistoryList, patientHistory: RDD[CassandraRow])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Eligible IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRDD(denominatorRDD, patienthistoryList)
      exclusionRDD.cache()

      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMetRDD(intermediateA)
      metRDD.cache()
      // Filter not Met

      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD, notMetRDD, MEASURE_NAME)
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
   Patient age 18 years and older with a diagnosis of rheumatoid arthritis seen for two or more face-to-face encounters for RA with the same clinician during the measurement period.
   ----------------------------------------------------------------------------------------------------------------------------*/

  def getIppRDD(initialRDD: RDD[CassandraRow],patienthistoryList :Broadcast[List[CassandraRow]],patientHistory : RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    val countRDD = countElement(patientHistory, m,  ACR03Elements.Face_To_Face_Interaction,
                                                    ACR03Elements.Home_Healthcare_Services,
                                                    ACR03Elements.Care_Services_In_Long_Term_Residential_Facility,
                                                    ACR03Elements.Office_Visit,
                                                    ACR03Elements.Nursing_Facility_Visit,
                                                    ACR03Elements.Outpatient_Consultation)

    initialRDD.filter(visit =>
          isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
       && getEncounterCountFromHistory(visit,m,2, true, countRDD)
       && wasDiagnosedBeforeOrEqualEncounter(visit,m,ACR03Elements.Active_Rheumatoid_Arthritis,patienthistoryList)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
 Patients with a diagnosis of HIV or patients who are pregnant or patients with inactive RA.
 ----------------------------------------------------------------------------------------------------------------------------*/

  def getExclusionRDD(eligibleRdd: RDD[CassandraRow], patienthistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    eligibleRdd.filter(visit =>
         wasDiagnosedInHistory(visit, m, ACR03Elements.Hiv, patienthistoryList)
      || isDiagnosedOnEncounter(visit, m, ACR03Elements.Pregnancy)
      || wasDiagnosedInHistory(visit,m,ACR03Elements.Documentation_Of_Inactive_Rheumatoid_Arthritis,patienthistoryList)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
 Patient received a DMARD.
 ----------------------------------------------------------------------------------------------------------------------------*/

  def getMetRDD(rdd: RDD[CassandraRow]): RDD[CassandraRow] =
  {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
   rdd.filter(visit =>
        isMedicationAdministeredOnEncounter(visit,m,ACR03Elements.Non_Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_)
     || isMedicationOrderedOnEncounter(visit,m,ACR03Elements.Non_Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_)
     || isMedicationActiveDuringEncounter(visit,m,ACR03Elements.Non_Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_)
     || isMedicationAdministeredOnEncounter(visit,m,ACR03Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_)
     || isMedicationOrderedOnEncounter(visit,m,ACR03Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_)
     || isMedicationActiveDuringEncounter(visit,m,ACR03Elements.Biologic_Disease_Modifying_Antirheumatic_Drugs__Dmards_)
   )
  }

}
