package com.figmd.janus.measureComputation.nonqpp
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AAD5Elements, CalenderUnit, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD5
* Measure Title              :- Biopsy Reporting Time – Clinician to Patient
* Measure Description        :- Percentage of patients with skin biopsy specimens with a diagnosis of cutaneous basal or squamous cell carcinoma (including in situ disease) who are notified of their final biopsy pathology findings within less than or equal to 14 days from the time the biopsy was performed.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/

object AAD5 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAD5"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patient_history_list = getPatientHistory(sparkSession, initialRDD,
      AAD5Elements.Final_Biopsy_Pathology_Findings_Grp,
      AAD5Elements.Cutaneous_Biopsy_Grp,
      AAD5Elements.Cutaneous_Scc_Or_Bcc,
      AAD5Elements.Excision_Grp
    ).collect().toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //eligible initial population RDD
     // val notEligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter denominator Exclusions
      val denominatorExclusionRDD = getDenominatorExclusionRdd(ippRDD, patientHistoryList)
      denominatorExclusionRDD.cache()

      //eligible initial population RDD
      val intermediateA = getSubtractRDD(ippRDD, denominatorExclusionRDD)

      // Filter Intermediate Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, denominatorExclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()
    }

  }

  /*Ages: 18 and older at the start of the measurement period.
  Patient with Diagnosis: Diagnosis of basal cell carcinoma OR Diagnosis of squamous cell carcinoma OR Diagnosis of carcinoma of the skin in situ.
  Event: Cutaneous biopsy/ biopsies that are performed during the measurement period.*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit=>
      isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
      && wasDiagnosedAfterProcedure(visit,m,AAD5Elements.Cutaneous_Scc_Or_Bcc,patientHistoryList,AAD5Elements.Cutaneous_Biopsy_Grp)
      && wasProcedurePerformedInHistory(visit,m,AAD5Elements.Cutaneous_Biopsy_Grp,patientHistoryList)
    )
  }

  /*Pathology reports for tissue specimens produced from excision
  */
  def getDenominatorExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit=> wasProcedurePerformedInHistory(visit,m,AAD5Elements.Excision_Grp,patientHistoryList))
  }

  /*The number of patients in the denominator who are informed of their final biopsy pathology findings within less than or equal to 14 days from the time the biopsy was performed.

  Acceptable communication methods include:
• Directly speaking with the patient or a person designated by the patient to discuss this lab result
• Documented telephone message or voice mail regarding the availability of lab result
• Mailer/fax sent to the patient indicating the availability of lab result or discussing the diagnosis itself
• Any HIPAA secure electronic communication with the patient discussing the diagnosis*/
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit=>
      wasCommunicationDoneAfterProcedureWithinXDays(visit,m,AAD5Elements.Cutaneous_Biopsy_Grp,AAD5Elements.Cutaneous_Biopsy_Grp_Date,14,patientHistoryList,AAD5Elements.Final_Biopsy_Pathology_Findings_Grp)
    )
  }



}
