package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ECQM132V7Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 132v7
* Measure Title              :- Cataracts: Complications within 30 Days Following Cataract Surgery Requiring Additional Surgical Procedures
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of uncomplicated cataract
                                who had cataract surgery and had any of a specified list of surgical procedures in the
                                30 days following cataract surgery which would indicate the occurrence of any of the
                                following major complications: retained nuclear fragments, endophthalmitis, dislocated
                                or wrong power IOL, retinal detachment, or wound dehiscence
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm132V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm132V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , ECQM132V7Elements.Prior_Pars_Plana_Vitrectomy
      , ECQM132V7Elements.Use_Of_Systemic_Sympathetic_Alpha_1a_Antagonist_Medication_For_Treatment_Of_Prostatic_Hypertrophy
      , ECQM132V7Elements.Ocular_Complications_Impacting_Surgery
      , ECQM132V7Elements.Cataract_Surgery_Eye
      , ECQM132V7Elements.Ocular_Complication_Impacting_Cataract_Surgery_Outcome_Eye
      , ECQM132V7Elements.Major_Complication_Post_Cataract_Surgery
      , ECQM132V7Elements.Cataract_Surgery
      , ECQM132V7Elements.Major_Complication_Post_Cataract_Surgery_Eye
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Eligable IPP

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // //val eligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      /*exclusion RDD*/
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*------------------------------------------------------------------------------
    All patients aged 18 years and older who had cataract surgery and did not meet any exclusion criteria
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)


    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isProcedurePerformedDuringEncounter(visit, m, ECQM132V7Elements.Cataract_Surgery)

    )
  }

  /*------------------------------------------------------------------------------
    Patients with any one of a specified list of significant ocular conditions that impact the surgical complication rate
   ------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (
        wasProcedurePerformedBeforeOrEqualEncounter(visit, m, ECQM132V7Elements.Prior_Pars_Plana_Vitrectomy, patientHistoryList)
          || wasMedicationActiveBeforeOrEqualEncounter(visit, m, ECQM132V7Elements.Use_Of_Systemic_Sympathetic_Alpha_1a_Antagonist_Medication_For_Treatment_Of_Prostatic_Hypertrophy, patientHistoryList)
          || wasDiagnosedBeforeOrEqualEncounter(visit, m, ECQM132V7Elements.Ocular_Complications_Impacting_Surgery, patientHistoryList)
        )
        && checkEyeElementBeforeDiagnosisEyesElement(visit, m, ECQM132V7Elements.Cataract_Surgery_Eye, patientHistoryList, ECQM132V7Elements.Ocular_Complication_Impacting_Cataract_Surgery_Outcome_Eye)

    )
  }

  /*------------------------------------------------------------------------------
    Patients who had one or more specified operative procedures for any of the following major complications within
    30 days following cataract surgery: retained nuclear fragments, endophthalmitis, dislocated or wrong power IOL,
    retinal detachment, or wound dehiscence
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      checkEyeElementWithinXDays(visit, m
        , ECQM132V7Elements.Major_Complication_Post_Cataract_Surgery, ECQM132V7Elements.Cataract_Surgery
        , ECQM132V7Elements.Cataract_Surgery_Eye, 30, patientHistoryList, ECQM132V7Elements.Major_Complication_Post_Cataract_Surgery_Eye)
    )
  }
}