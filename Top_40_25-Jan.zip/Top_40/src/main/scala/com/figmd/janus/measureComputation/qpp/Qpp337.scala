package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master.{AdminElements, CalenderUnit, MeasureProperty, QPP337Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 337
* Measure Title              :- Psoriasis: Tuberculosis (TB) Prevention for Patients with Psoriasis, Psoriatic Arthritis
                                and Rheumatoid Arthritis on a Biological Immune Response Modifier
* Measure Description        :- Percentage of patients, regardless of age, with Psoriasis, Psoriatic Arthritis and
                                Rheumatoid Arthritis on a Biological Immune Response Modifier whose providers are
                                ensuring active tuberculosis prevention either through yearly negative standard
                                tuberculosis screening tests or are reviewing the patient’s history to determine
                                if they have had appropriate management for a recent or prior positive test
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score equals better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp337 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp337"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP337Elements.Biologic_Immune_Response_Modifier_Grp
      , QPP337Elements.Biologic_Immune_Response_Modifiers
      , QPP337Elements.Initials_Of_Clinician_Prescribed_The_Biologic
      , QPP337Elements.Initials_Of_Clinician_That_Administered_The_Tb_Test
      , QPP337Elements.Initials_Of_Clinician_That_Performed_Skin_Test
      , QPP337Elements.Mantoux_Test
      , QPP337Elements.Mantoux_Test_Negative
      , QPP337Elements.Mantoux_Test_Positive
      , QPP337Elements.Ct_Scan
      , QPP337Elements.History_Of_Tuberculosis
      , QPP337Elements.Negative_Imaging
      , QPP337Elements.Chest_X_Ray
      , QPP337Elements.History_Of_Tuberculosis
      , QPP337Elements.Negative_Imaging
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      denominatorRDD.cache()

      // Filter Intermediate RDD
      val intermediateException = getSubtractRDD(ippRDD, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryBroadcastList.destroy()
    }
  }

  /*------------------------------------------------------------------------------
     All patients, regardless of age, with a diagnosis of psoriasis and/or psoriatic arthritis and/or rheumatoid
     arthritis who are on a biologic immune response modifier
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryRDD:RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)


    initialRDD.filter(visit =>
      (
          isDiagnosedOnEncounter(visit,m,QPP337Elements.Psoriasis_Or_Psoriatic_Arthritis)
       || isDiagnosedOnEncounter(visit,m,QPP337Elements.Rheumatoid_Arthritis)
      )
    && isVisitTypeIn(visit,m
                            ,QPP337Elements.Office_Visit
                            ,QPP337Elements.Outpatient_Consultation
                            ,QPP337Elements.Initial_Preventive_Physical_Examination_Grp
                     )
    &&
        (
            (
                wasMedicationActiveBeforeOrEqualStartDate(visit,m,QPP337Elements.Biologic_Immune_Response_Modifier_Grp,patientHistoryList)
             || wasMedicationActiveBeforeOrEqualStartDate(visit,m,QPP337Elements.Biologic_Immune_Response_Modifiers,patientHistoryList)
            )
        ||  (
                isAssessmentPerformed(visit,m,QPP337Elements.Biologic_Immune_Response_Modifier_Grp,patientHistoryList)
             || isMedicationOrdered(visit,m,patientHistoryList,QPP337Elements.Biologic_Immune_Response_Modifiers)
            )
        )
    && isPOSEncounterNotPerformed(visit,m,QPP337Elements.Pos_02_Date)
    && !isTeleHealthModifier(visit,m
                                    ,QPP337Elements.Office_Visit_Telehealth_Modifier
                                    ,QPP337Elements.Outpatient_Consultation_Telehealth_Modifier
                                    ,QPP337Elements.Initial_Preventive_Physical_Examination_Telehealth_Modifier

                            )
    )
  }




  /*------------------------------------------------------------------------------
    Patients who have a documented negative annual TB screening or have documentation of the management of a positive
    TB screening test with no evidence of active tuberculosis, confirmed through use of radiographic imaging (i.e., chest x-ray, CT)
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      isLaboratoryTestOrder(visit,m,QPP337Elements.Screening_Of_Tuberculosis,patientHistoryList)
    ||
     (
      (
        (
            wasInterventionPerformedBeforeEncounterWithinXMonths(visit,m,QPP337Elements.Initials_Of_Clinician_Prescribed_The_Biologic,12,patientHistoryList)
         && wasInterventionPerformedBeforeEncounterWithinXMonths(visit,m,QPP337Elements.Initials_Of_Clinician_That_Administered_The_Tb_Test,12,patientHistoryList)
         && wasInterventionPerformedBeforeEncounterWithinXMonths(visit,m,QPP337Elements.Initials_Of_Clinician_That_Performed_Skin_Test,12,patientHistoryList)
        )
        &&
          (
            wasProcedurePerformedwithResultBeforeEncounter(visit,m
                                                                    ,QPP337Elements.Mantoux_Test
                                                                    ,QPP337Elements.Mantoux_Test_Negative,CalenderUnit.MONTH,12,patientHistoryList)
          ||
              (
                wasProcedurePerformedwithResultBeforeEncounter(visit,m
                                                                  ,QPP337Elements.Mantoux_Test
                                                                  ,QPP337Elements.Mantoux_Test_Positive,CalenderUnit.MONTH,12,patientHistoryList)
                    &&
                      (
                            wasProcedurePerformedwithReasonAndResultBeforeEncounter(visit,m
                                                                                        ,QPP337Elements.Ct_Scan
                                                                                        ,QPP337Elements.History_Of_Tuberculosis
                                                                                        ,QPP337Elements.Negative_Imaging,12,patientHistoryList)
                        ||  wasProcedurePerformedwithReasonAndResultBeforeEncounter(visit,m
                                                                                            ,QPP337Elements.Chest_X_Ray
                                                                                            ,QPP337Elements.History_Of_Tuberculosis
                                                                                            ,QPP337Elements.Negative_Imaging,12,patientHistoryList)
                      )
              )
          )
      )
    ||
        (
          (
                 isInterventionPerformed(visit,m,QPP337Elements.Initials_Of_Clinician_Prescribed_The_Biologic,patientHistoryList)
              && isInterventionPerformed(visit,m,QPP337Elements.Initials_Of_Clinician_That_Administered_The_Tb_Test,patientHistoryList)
              && isInterventionPerformed(visit,m,QPP337Elements.Initials_Of_Clinician_That_Performed_Skin_Test,patientHistoryList)
            )
            &&
            (
              wasProcedurePerformedwithResultBeforeEncounter(visit,m
                                                                    ,QPP337Elements.Mantoux_Test
                                                                    ,QPP337Elements.Mantoux_Test_Negative,CalenderUnit.MONTH,12,patientHistoryList)
                ||
                (
                  wasProcedurePerformedwithResultBefore(visit,m
                                                                ,QPP337Elements.Mantoux_Test
                                                                ,QPP337Elements.Mantoux_Test_Positive,12,patientHistoryList)
                    &&
                    (
                       wasProcedurePerformedwithReasonAndResultBefore(visit,m
                                                                              ,QPP337Elements.Ct_Scan
                                                                              ,QPP337Elements.History_Of_Tuberculosis
                                                                              ,QPP337Elements.Negative_Imaging,12,patientHistoryList)
                        ||  wasProcedurePerformedwithReasonAndResultBefore(visit,m
                                                                                  ,QPP337Elements.Chest_X_Ray
                                                                                  ,QPP337Elements.History_Of_Tuberculosis
                                                                                  ,QPP337Elements.Negative_Imaging,12,patientHistoryList)
                    )
                  )
              )
          )
       )
    && !isAssessmentPerformed(visit,m,QPP337Elements.Tb_Screening_Not_Met,patientHistoryList)
    )

  }

  /*------------------------------------------------------------------------------
   Documentation of patient reasons(s) for not having records of negative or managed positive TB screen
   (e.g., patient does not return for Mantoux (PPD) skin test evaluation)
   ------------------------------------------------------------------------------*/

  def getException(intermediateA: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
        isLaboratoryTestOrder(visit,m,QPP337Elements.Tb_Screen_Patient_Reason_Grp,patientHistoryList)
     || isLaboratoryTestOrder(visit,m,QPP337Elements.No_Return_Mantoux__Ppd__Skin_Test_Evaluation_Grp,patientHistoryList)
    )

  }
}

