package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP357Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 357
* Measure Title              :- Surgical Site Infection (SSI)
* Measure Description        :- Percentage of patients aged 18 years and older who had a surgical site infection (SSI).
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/



object  Qpp357  extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp357"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patienthistory = getPatientHistory(sparkSession,initialRDD
      ,QPP357Elements.General_Surgery
      ,QPP357Elements.Surgical_Site_Infection
      ,QPP357Elements.Signs_Or_Symptoms_Of_Infection
      ,QPP357Elements.Ssi_Not_Met
    ).collect().toList

    val patientHistoryBroadcastList:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistory)



    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      //Filter notEligibleRDD
      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      denominatorRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //Filter exceptionRDD
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Not Met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  /*----------------------------------------------------------------------------------------------------------------
  * This measure is procedure specific and calculation on active procedure so we have checked only those procedure
  * are active ie. ipp checked on encounterdate
  ----------------------------------------------------------------------------------------------------------------*/


  /*--------------------------------------------------------------------------------------------------------------------
  Patients aged 18 years and older who have undergone a surgical procedure.
    --------------------------------------------------------------------------------------------------------------------*/


  def getIpp(rdd: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
        isPatientAdult(visit,m)
        && 
        isProcedurePerformedDuringEncounter(visit,m,QPP357Elements.General_Surgery)
          &&
        wasProcedurePerformedBeforeEndInDays(visit,m,QPP357Elements.General_Surgery,30,patientHistoryBroadcastList)
    )

  }



  /*-------------------------------------------------------------------------------------------------------------------
   	Number of patients with a surgical site infection.
  -------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
       (
          wasProcedureAfterXProcedureDays(visit,m,QPP357Elements.General_Surgery,QPP357Elements.General_Surgery_Date,30,patientHistoryBroadcastList,QPP357Elements.Surgical_Site_Infection)
          || 
          wasProcedureAfterXProcedureDays(visit,m,QPP357Elements.General_Surgery,QPP357Elements.General_Surgery_Date,30,patientHistoryBroadcastList,QPP357Elements.Signs_Or_Symptoms_Of_Infection)
        )
            && 
            !wasProcedureAfterXProcedureDays(visit,m,QPP357Elements.General_Surgery,QPP357Elements.General_Surgery_Date,30,patientHistoryBroadcastList,QPP357Elements.Ssi_Not_Met)
    )
  }

}
