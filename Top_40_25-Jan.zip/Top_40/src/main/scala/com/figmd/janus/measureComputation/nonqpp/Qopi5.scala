package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{QOPI5Elements, MeasureProperty, _}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QOPI 5
* Measure Title              :- Chemotherapy administered to patients with metastatic solid tumor with performance status of 3, 4, or undocumented
* Measure Description        :- Percentage of adult patients with metastatic solid tumors and performance status of 3, 4, or undocumented who receive chemotherapy (Lower score - Better)
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object Qopi5 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "QOPI15"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QOPI5Elements.Tumor_Staging,
      QOPI5Elements.M_Stage_M1,
      QOPI5Elements.M_Stage_M1a,
      QOPI5Elements.M_Stage_M1b,
      QOPI5Elements.M_Stage_M1c,

      QOPI5Elements.Cancer_Stage_Iv,
      QOPI5Elements.Cancer_Stage_Iva,
      QOPI5Elements.Cancer_Stage_Ivb,
      QOPI5Elements.Cancer_Stage_Ivc,

      QOPI5Elements.Hodgkins_Disease,
      QOPI5Elements.Intent_Of_Chemotherapy,
      QOPI5Elements.Intent_Non_Curative,
      QOPI5Elements.Leukemia,
      QOPI5Elements.Neoplasm_Of_Placenta,
      QOPI5Elements.Ecog_Performance_Status,
      QOPI5Elements.Non_Hodgkins_Lymphoma,
      QOPI5Elements.Patient_Provider_Interaction,
      QOPI5Elements.Testicular_Cancer,
      QOPI5Elements.Anti_Neoplastic_Agents,
      QOPI5Elements.Ecog_Result,
      QOPI5Elements.Karnofsky_Performance_Status,
      QOPI5Elements.Karnofsky_Result


    )

    val mostrecentpatientHistoryList = mostRecentPatientList(patientHistoryRDD, QOPI5Elements.Anti_Neoplastic_Agents)
    val mostrecentpatientHistoryBrodcastList = sparkSession.sparkContext.broadcast(mostrecentpatientHistoryList)

    val patient_history_list = patientHistoryRDD.collect().toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible RDD
      val denominatorRDD = getEligibleRdd(ippRDD, patientHistoryList)
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(denominatorRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList, mostrecentpatientHistoryBrodcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
      mostrecentpatientHistoryBrodcastList.destroy()
    }

  }

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && wasDiagnosedInHistory(visit, m, QOPI5Elements.Cancer, patientHistoryList)
        && isVisitTypeIn(visit, m, QOPI5Elements.Office_Visit,
        QOPI5Elements.Patient_Provider_Interaction
      )
    )
  }

  def getEligibleRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>

      (
        wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI5Elements.Cancer, QOPI5Elements.Tumor_Staging, QOPI5Elements.M_Stage_M1, patientHistoryList)
          || wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI5Elements.Cancer, QOPI5Elements.Tumor_Staging, QOPI5Elements.M_Stage_M1a, patientHistoryList)
          || wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI5Elements.Cancer, QOPI5Elements.Tumor_Staging, QOPI5Elements.M_Stage_M1b, patientHistoryList)
          || wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI5Elements.Cancer, QOPI5Elements.Tumor_Staging, QOPI5Elements.M_Stage_M1c, patientHistoryList)

        )
        ||
        (

          wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI5Elements.Cancer, QOPI5Elements.Tumor_Staging, QOPI5Elements.Cancer_Stage_Iv, patientHistoryList)
            || wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI5Elements.Cancer, QOPI5Elements.Tumor_Staging, QOPI5Elements.Cancer_Stage_Iva, patientHistoryList)
            || wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI5Elements.Cancer, QOPI5Elements.Tumor_Staging, QOPI5Elements.Cancer_Stage_Ivb, patientHistoryList)
            || wasProcedurePerformedWithResultAfterDiagnosis(visit, m, QOPI5Elements.Cancer, QOPI5Elements.Tumor_Staging, QOPI5Elements.Cancer_Stage_Ivc, patientHistoryList)

          )
          &&
          (
            wasInterventionPerformedWithResultDuringDiagnosis(visit, m, QOPI5Elements.Cancer, QOPI5Elements.Intent_Of_Chemotherapy, QOPI5Elements.Intent_Undocumented, patientHistoryList)
              || wasInterventionPerformedWithResultDuringDiagnosis(visit, m, QOPI5Elements.Cancer, QOPI5Elements.Intent_Of_Chemotherapy, QOPI5Elements.Intent_Non_Curative, patientHistoryList)
            )
          && wasMedicationAdministeredAfterDiagnosis(visit, m, QOPI5Elements.Cancer, patientHistoryList, QOPI5Elements.Anti_Neoplastic_Agents)

    )


  }

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      wasDiagnosedInHistory(visit, m, QOPI5Elements.Leukemia, patientHistoryList)
        || wasDiagnosedInHistory(visit, m, QOPI5Elements.Testicular_Cancer, patientHistoryList)
        || wasDiagnosedInHistory(visit, m, QOPI5Elements.Hodgkins_Disease, patientHistoryList)
        || wasDiagnosedInHistory(visit, m, QOPI5Elements.Non_Hodgkins_Lymphoma, patientHistoryList)
        || wasDiagnosedInHistory(visit, m, QOPI5Elements.Neoplasm_Of_Placenta, patientHistoryList)
        || wasDiagnosedInHistory(visit, m, QOPI5Elements.Trophoblastic_Neoplasm, patientHistoryList)

    )
  }


  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], mostrecentpatientHistoryBrodcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (

        (
          wasAssessmentPerformedAfterEndWithinWeeksMostRecentMedication(visit, m, QOPI5Elements.Ecog_Performance_Status, QOPI5Elements.Anti_Neoplastic_Agents, 2, mostrecentpatientHistoryBrodcastList)
          )
          ||
          (
            (

              isResultMatching(visit, m, QOPI5Elements.Ecog_Result, 3, "eq")
                && wasElementStartsAfterEndOFMostRecentPatientList(visit, m, QOPI5Elements.Ecog_Result, QOPI5Elements.Anti_Neoplastic_Agents, mostrecentpatientHistoryBrodcastList)

              )
              ||
              (
                isResultMatching(visit, m, QOPI5Elements.Ecog_Result, 4, "eq")
                  && wasElementStartsAfterEndOFMostRecentPatientList(visit, m, QOPI5Elements.Ecog_Result, QOPI5Elements.Anti_Neoplastic_Agents, mostrecentpatientHistoryBrodcastList)

                )
            )
        )
        ||
        (
          (

            wasAssessmentPerformedAfterEndWithinWeeksMostRecentMedication(visit, m, QOPI5Elements.Karnofsky_Performance_Status, QOPI5Elements.Anti_Neoplastic_Agents, 2, mostrecentpatientHistoryBrodcastList)
            )
            ||
            (
              isAssessmentPerformedResultInRange(visit, m, QOPI5Elements.Karnofsky_Result, 10, 50)

                && wasAssessmentPerformedAfterEndWithinWeeksMostRecentMedication(visit, m, QOPI5Elements.Karnofsky_Result, QOPI5Elements.Anti_Neoplastic_Agents, 2, mostrecentpatientHistoryBrodcastList)
              )

          )
    )


  }
}