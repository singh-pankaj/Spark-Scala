package com.figmd.janus.measureComputation.nonqpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Axon11
* Measure Title              :- DSP: Diabetes/Pre-Diabetes Screening for Patients with DSP
* Measure Description        :- Percentage of patients age 18 years and older with a diagnosis of distal symmetric polyneuropathy who had screening tests for
* diabetes (eg fasting blood sugar test, a hemoglobin A1C, or a 2 hour Glucose Tolerance Test) reviewed, requested or ordered when seen for an initial evaluation for distal symmetric polyneuropathy.
* Calculation Implementation :- Patient Specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/


object Axon11 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Axon11"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, initialRDD
      ,Axon11Elements.Distal_Symmetric_Polyneuropathy
      ,Axon11Elements.Screening_For_Diabetes
      ,Axon11Elements.Diabetes_Screening
      ,Axon11Elements.Screening_For_Diabetes_Medical_Reason
      ,Axon11Elements.Screening_For_Diabetes_System_Reason
    ).collect.toList
    val patientHistory: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistory)
    ippRDD.cache()

   if(checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

     // Eligible IPP
     val denominatorRDD = ippRDD
     denominatorRDD.cache()

     //Filter Exclusion
     val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

     // Filter Met
     val metRDD = getMet(ippRDD, patientHistory)
     metRDD.cache()

     // Filter Exclusion
     val exceptionRDD = getExceptionRdd(metRDD, patientHistory)
     exceptionRDD.cache()


     // Filter not met
     val notMetRDD = getSubtractRDD(metRDD, exceptionRDD)
     notMetRDD.cache()

     saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
     patientHistory.destroy()
   }


  }

  /*--------------------------------------------------------------------------------------------------------------------
    All patients age 18 years and older with a diagnosis of distal symmetric polyneuropathy.
   -------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isDiagnosedOnEncounter(visit, m, Axon11Elements.Distal_Symmetric_Polyneuropathy)
        && isVisitTypeIn(visit, m
        , Axon11Elements.Care_Services_In_Long_Term_Residential_Facility
        , Axon11Elements.Home_Care_Visit
        , Axon11Elements.Office_Visit
        , Axon11Elements.Nursing_Facility_Visit
        , Axon11Elements.Home_Healthcare_Services
        , Axon11Elements.Outpatient_Consultation
        , Axon11Elements.Evaluation_And_Management
      )

    )

  }

  /*--------------------------------------------------------------------------------------------------------------------
  Patients who had screening tests for diabetes (eg, fasting blood sugar test, hemoglobin A1C, or a 2 hour Glucose Tolerance Test)
  reviewed, requested, or ordered when seen for an initial evaluation for distal symmetric polyneuropathy.
   -------------------------------------------------------------------------------------------------------------------*/


  def getMet(ippRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (isLaboratoryTestPerformedDuringDiagnosis(visit, m, Axon11Elements.Screening_For_Diabetes,Axon11Elements.Screening_For_Diabetes_Date,Axon11Elements.Distal_Symmetric_Polyneuropathy,Axon11Elements.Distal_Symmetric_Polyneuropathy_Date)
      ||isLaboratoryTestPerformedXMonthsBeforeStartOfDiagnosis(visit, m,Axon11Elements.Screening_For_Diabetes,Axon11Elements.Distal_Symmetric_Polyneuropathy,12,patientHistory)
      )
      ||
      (isLaboratoryTestPerformedDuringDiagnosis(visit, m, Axon11Elements.Diabetes_Screening,Axon11Elements.Diabetes_Screening_Date,Axon11Elements.Distal_Symmetric_Polyneuropathy,Axon11Elements.Distal_Symmetric_Polyneuropathy_Date)
        ||isLaboratoryTestPerformedXMonthsBeforeStartOfDiagnosis(visit, m,Axon11Elements.Diabetes_Screening,Axon11Elements.Distal_Symmetric_Polyneuropathy,12,patientHistory)
      )
    )
  }


  /*--------------------------------------------------------------------------------------------------------------------
  •Documentation of a medical reason for not reviewing, requesting or ordering diabetes screening tests (eg patient has a diagnosis of diabetes, patient has a known medical condition to cause neuropathy, patient had previous diabetes screening)
  •Documentation of a patient reason for not reviewing, requesting or ordering diabetes screening tests (eg patient declines to undergo testing)
  •Documentation of a system reason for not reviewing, requesting or ordering diabetes screening tests (eg patient does not have insurance to pay for testing)
   -------------------------------------------------------------------------------------------------------------------*/


  def getExceptionRdd(intermediateException: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      wasDiagnosedInHistory(visit, m, Axon11Elements.Screening_For_Diabetes,patientHistory)
      ||
        (isAssessmentPerformedXMonthsBeforeStartOfDiagnosis(visit, m,Axon11Elements.Screening_For_Diabetes_Medical_Reason,Axon11Elements.Distal_Symmetric_Polyneuropathy,12,patientHistory)
        ||isAssessmentPerformedDuringDiagnosis(visit, m, Axon11Elements.Screening_For_Diabetes_Medical_Reason,Axon11Elements.Screening_For_Diabetes_Medical_Reason_Date,Axon11Elements.Distal_Symmetric_Polyneuropathy,Axon11Elements.Distal_Symmetric_Polyneuropathy_Date)
        )
      ||
        (isAssessmentPerformedXMonthsBeforeStartOfDiagnosis(visit, m,Axon11Elements.Screening_For_Diabetes_System_Reason,Axon11Elements.Distal_Symmetric_Polyneuropathy,12,patientHistory)
          ||isAssessmentPerformedDuringDiagnosis(visit, m, Axon11Elements.Screening_For_Diabetes_System_Reason,Axon11Elements.Screening_For_Diabetes_System_Reason_Date,Axon11Elements.Distal_Symmetric_Polyneuropathy,Axon11Elements.Distal_Symmetric_Polyneuropathy_Date)
        )
    )
  }

}






