package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP419Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 419
* Measure Title              :- Overuse of Imaging for the Evaluation of Primary Headache
* Measure Description        :- Percentage of patients for whom imaging of the head (CT or MRI) is obtained
                                for the evaluation of primary headache when clinical indications are not present
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/



object  Qpp419  extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp419"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryRDD = getPatientHistory(sparkSession,initialRDD,QPP419Elements.Primary_Headache).collect().toList
    val patientHistoryBroadcastList:Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)
    // Filter IPP
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
        ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Met
      val metRDD = getMet(denominatorRDD)
      metRDD.cache()

      // Filter Intermediate
      val intermediateException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateException)


      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  /*--------------------------------------------------------------------------------------------------------------------
  All patients seen for evaluation of primary headache
  --------------------------------------------------------------------------------------------------------------------*/


  def getIpp(rdd: RDD[CassandraRow],patientHistory:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>

          wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP419Elements.Primary_Headache,patientHistory)
      &&  isVisitTypeIn(visit,m
                               ,QPP419Elements.Office_Visit
                               ,QPP419Elements.Office_Or_Other_Outpatient_Consultation_Services)
      &&  isAssessmentPerformedOnEncounter(visit,m,QPP419Elements.No_Indication_For_Head_Imaging_G)
      &&  !isSymptomOnEncounter(visit,m,QPP419Elements.No_Indication_For_Head_Imaging)
      &&  !isTeleHealthEncounterPerformed(visit,m
                                                    ,QPP419Elements.Office_Visit_Telehealth_Modifier
                                                    ,QPP419Elements.Office_Or_Other_Outpatient_Consultation_Services_Telehealth_Services)
      &&  isPOSEncounterNotPerformed(visit,m,QPP419Elements.Pos_02)
    )

  }

  /*--------------------------------------------------------------------------------------------------------------------
   Patients for whom imaging of the head (Computed Tomography (CT) or Magnetic Resonance Imaging (MRI)) is obtained for
   the evaluation of primary headache when clinical indications are not present
   -------------------------------------------------------------------------------------------------------------------*/


  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
         (
             isDiagnosticStudyOnEncounter(visit,m,QPP419Elements.Head_Ct_Mri_Performed)
          || isAssessmentPerformedOnEncounter(visit,m,QPP419Elements.Head_Imaging_Performed)
         )
      && (
             isDiagnosticStudyOnEncounter(visit,m,QPP419Elements.Head_Imaging_Not_Performed)
          || isAssessmentPerformedOnEncounter(visit,m,QPP419Elements.Head_Imaging_Not_Performed)
         )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------
  Documentation of patients with primary headache diagnosis and imaging other than CT or MRI obtained
  Documentation of System reason(s) for obtaining imaging of the head (CT or MRI)
  (i.e., needed as part of a clinical trial; other clinician ordered the study)
  -------------------------------------------------------------------------------------------------------------------*/

  def getException(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
        isAssessmentPerformedOnEncounter(visit,m,QPP419Elements.Other_Head_Imaging)
     || isDiagnosticStudyOnEncounter(visit,m,QPP419Elements.Other_Head_Imaging_Performed)
     || isDiagnosticStudyOnEncounter(visit,m,QPP419Elements.Advanced_Brain_Imaging_System_Reason)
    )
  }

}
