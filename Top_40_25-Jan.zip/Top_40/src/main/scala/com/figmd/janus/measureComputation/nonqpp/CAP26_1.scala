package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CAP26Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAP26_1
* Measure Title               :- Cancer Protocol and Turnaround Time for Hepatocellular Carcinoma
* Measure Description         :- Percentage of all eligible hepatocellular carcinoma specimens:
                                - Hepatic resection
                                - Partial hepatic resection
                                - Complete hepatic resection
                                for which all required data elements of the Cancer Protocol are included
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- None
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.6
----------------------------------------------------------------------------------------------------------------------------*/

object CAP26_1 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "CAP26_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
        , CAP26Elements.Confirm_Hepatocellular_Carcinoma_Resection
        , CAP26Elements.Hepatocellular_Carcinoma_Kw
        , CAP26Elements.Surgical_Pathology_Accession_Number
        , CAP26Elements.Consultation_Catii
        , CAP26Elements.Surgical_Pathology_Accession_Number_Date
        , CAP26Elements.Confirm_Case_Required_Consultation
        , CAP26Elements.Confirm_Case_Required_Consultation_Date
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All final pathology reports for eligible hepatocellular carcinoma cases that require the use of a CAP cancer protocol.
CPT®: 88307 or 88309
AND
Any of the ICD 10 codes:
C22.0: liver cell carcinoma
C22.7: other specified carcinomas of liver
C22.8: malignant neoplasm of liver, primary unspecified as to type
C22.9: malignant neoplasm of liver, not specified as primary or secondary
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      (
          isDiagnosisOverlapsProcedure(visit, m, CAP26Elements.Confirm_Hepatocellular_Carcinoma_Resection,
                              CAP26Elements.Surgical_Pathology_Accession_Number, patientHistoryBroadcastList)
        ||
          isDiagnosisOverlapsProcedure(visit, m, CAP26Elements.Hepatocellular_Carcinoma_Kw,
                              CAP26Elements.Surgical_Pathology_Accession_Number, patientHistoryBroadcastList)
      )
      &&
        isLaboratoryTestOrder(visit, m, CAP26Elements.Surgical_Pathology_Accession_Number, patientHistoryBroadcastList)
    )
  }

/*-----------------------------------------------------------------------------------------------------------------------
1.Biopsy procedures
2.Cholangiocarcinoma
3.Mixed hepatocellular-cholangiocarcinoma
4.Hepatoblastoma
5.Lymphoma Sarcoma
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        (
            isDiagnosisListDuringLaboratoryTest(visit, m, CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Liver_Cell_Carcinoma)
          &&
            isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Biopsy, CAP26Elements.Biopsy_Date,
                CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        )
        ||
          isDiagnosisListDuringLaboratoryTest(visit, m, CAP26Elements.Surgical_Pathology_Accession_Number
              , CAP26Elements.Mixed_Hepatocellular_Cholangiocarcinoma
              , CAP26Elements.Hepatoblastoma
              , CAP26Elements.Cholangiocarcinoma
              , CAP26Elements.Lymphoma_And_Sarcoma
              , CAP26Elements.Angiosarcoma_Of_Liver
              , CAP26Elements.Other_Sarcomas_Of_Liver
              , CAP26Elements.Malignant_Neoplasm_Of_Extrahepatic_Bile_Duct_Gp
              , CAP26Elements.Secondary_Malignant_Neoplasm_Of_Liver_And_Intrahepatic_Bile_Duct
              , CAP26Elements.Intrahepatic_Bile_Duct_Carcinoma
          )
        ||
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Biopsy, CAP26Elements.Biopsy_Date,
                CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        ||
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Biopsy_Or_Cholangiocarcinoma,
                CAP26Elements.Biopsy_Or_Cholangiocarcinoma_Date, CAP26Elements.Surgical_Pathology_Accession_Number,
                CAP26Elements.Surgical_Pathology_Accession_Number_Date)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All eligible cases containing all of the required elements found in the current CAP hepatocellular carcinoma protocol. Optional data (marked with a “+” in the CAP cancer protocol) is not required but may be present.
The current protocol, the required elements include:
- Procedure
- Tumor Characteristics
- Histologic Type
- Histologic Grade
- Tumor Extension
- Margins
- Vascular Invasion
- Regional Lymph Nodes
- Pathologic Stage Classification (pTNM, AJCC 8th Edition)
* If an item is not applicable, an “N/A” listing is required.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
        (
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Procedure_Documented, CAP26Elements.Procedure_Documented_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Tumor_Focality, CAP26Elements.Tumor_Focality_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Tumor_Site_Documented, CAP26Elements.Tumor_Site_Documented_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Tumor_Size_Documented, CAP26Elements.Tumor_Size_Documented_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Histologic_Type_Documented, CAP26Elements.Histologic_Type_Documented_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Histologic_Grade_Documented,
              CAP26Elements.Histologic_Grade_Documented_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Tumor_Extension_Documented,
              CAP26Elements.Tumor_Extension_Documented_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Margins_Documented, CAP26Elements.Margins_Documented_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Vascular_Invasion_Documented,
              CAP26Elements.Vascular_Invasion_Documented_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Regional_Lymph_Nodes, CAP26Elements.Regional_Lymph_Nodes_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Pathologic_Stage_Classification,
              CAP26Elements.Pathologic_Stage_Classification_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Fibrolamellar_Carcinoma_Documented,
              CAP26Elements.Fibrolamellar_Carcinoma_Documented_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        &&
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Treatment_Effect_Documented,
              CAP26Elements.Treatment_Effect_Documented_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
        )
        ||
          isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Hepatocellular_Carcinoma_Protocol,
              CAP26Elements.Hepatocellular_Carcinoma_Protocol_Date,
              CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
      )
      && !
        isLaboratoryTestPerformedDuringLaboratoryTest(visit, m, CAP26Elements.Hepatocellular_Protocol_Not_Met,
            CAP26Elements.Hepatocellular_Protocol_Not_Met_Date,
            CAP26Elements.Surgical_Pathology_Accession_Number, CAP26Elements.Surgical_Pathology_Accession_Number_Date)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Cases requiring intra-departmental or extra-departmental consultation.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
          isCommunicationFromProvidertoProvider(visit, m, CAP26Elements.Consultation_Catii, patientHistoryBroadcastList)
        ||
          isCommunicationFromProviderToProviderDuringLaboratoryTest(visit, m, CAP26Elements.Surgical_Pathology_Accession_Number,
                CAP26Elements.Surgical_Pathology_Accession_Number_Date,
                CAP26Elements.Confirm_Case_Required_Consultation, CAP26Elements.Confirm_Case_Required_Consultation_Date,
                patientHistoryBroadcastList)
    )
  }

}

