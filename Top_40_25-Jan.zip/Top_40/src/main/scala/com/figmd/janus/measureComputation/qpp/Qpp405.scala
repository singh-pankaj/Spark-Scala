package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP405Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp 405
* Measure Title              :- Appropriate Follow-up Imaging for Incidental Abdominal Lesions
* Measure Description        :- Percentage of final reports for abdominal imaging studies for asymptomatic patients aged 18 years and older with one or more of the following noted incidentally with follow‐up imaging recommended:
                                • Liver lesion ≤ 0.5 cm
                                • Cystic kidney lesion < 1.0 cm
                                • Adrenal lesion ≤ 1.0 cm
* Calculation Implementation :- Procedure specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp405 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp405"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP405Elements.Abdominal_Imaging,
      QPP405Elements.Cystic_Kindney_Lesion,
      QPP405Elements.Adrenal_Lesion

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateRdd = getSubtractRDD(denominatorRDD, metRDD)

      // Filter not Exception
      val exceptionRDD = getException(intermediateRdd, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRdd, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }


  // IPP-Denominator criteria
  /* All final reports for abdominal imaging studies for patients aged 18 years and older with one or more of the following noted: Liver lesion ≤ 0.5 cm, Cystic kidney lesion < 1.0 cm or Adrenal lesion ≤ 1.0 cm */

  def getIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isPatientAdult(visit, m)
        && isDiagnosticStudyPerformedOnEncounter(visit, m, QPP405Elements.Abdominal_Imaging)
        && ((isDiagnosticStudyPerformedDuringXDiagnosticStudy(visit, m, QPP405Elements.Abdominal_Imaging, QPP405Elements.Liver_Lesion, QPP405Elements.Cystic_Kindney_Lesion, QPP405Elements.Adrenal_Lesion)
        || isDiagnosticStudyPerformedAfterXDiagnosticStudy(visit, m, QPP405Elements.Abdominal_Imaging, patientHistoryList,QPP405Elements.Cystic_Kindney_Lesion, QPP405Elements.Adrenal_Lesion)
        )
        &&
        (
          checkElementValueDuringMeasurementPeriod(visit, m, QPP405Elements.Liver_Lesion, 0.5, "le", patientHistoryList)
            && checkElementValueDuringMeasurementPeriod(visit, m, QPP405Elements.Cystic_Kindney_Lesion, 1.0, "lt", patientHistoryList)
            && checkElementValueDuringMeasurementPeriod(visit, m, QPP405Elements.Adrenal_Lesion, 1.0, "le", patientHistoryList)
          )
        || isDiagnosticStudyPerformedOnEncounter(visit, m, QPP405Elements.Incidental_Finding)
        )
    )
  }


  // Numerator criteria
  /* Final reports for abdominal imaging studies with follow-up imaging recommended. */

  def getMet(ipp: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ipp.filter(visit =>
      (
        isDiagnosticStudyRecommendedOnEncounter(visit, m, QPP405Elements.Follow_Up_Imaging_1)
          || isDiagnosticStudyRecommendedOnEncounter(visit, m, QPP405Elements.Follow_Up_Imaging_2)
        )
        && !isDiagnosticStudyRecommendedOnEncounter(visit, m, QPP405Elements.Follw_Up_Image_Not_Met)
    )
  }

  // Exception criteria
  /* Documentation of medical reason(s) that follow-up imaging is indicated (e.g., patient has a known malignancy that can metastasize, other medical reason(s) such as fever in an immunocompromised patient) */

  def getException(intermediate: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediate.filter(visit =>
      (
        isDiagnosticStudyRecommendedOnEncounter(visit, m, QPP405Elements.Follow_Up_Image_Medical_Reason)
          || isDiagnosticStudyRecommendedOnEncounter(visit, m, QPP405Elements.Medical_Reason_Follow_Up_Image)
          || (isDiagnosedDuringDiagnosticStudy(visit, m, QPP405Elements.Abdominal_Imaging, QPP405Elements.Malignancy_Metastasize, QPP405Elements.Immunocompromised_Fever)
          || wasDiagnosedBeforeDiagnosticStudy(visit, m, QPP405Elements.Abdominal_Imaging,patientHistoryList, QPP405Elements.Malignancy_Metastasize, QPP405Elements.Immunocompromised_Fever)
          )
        )
    )

  }

}
