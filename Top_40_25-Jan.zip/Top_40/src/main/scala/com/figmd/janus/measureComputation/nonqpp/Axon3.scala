package com.figmd.janus.measureComputation.nonqpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Axon 3
* Measure Title              :- Depression and Anxiety Screening for Patients with Epilepsy
* Measure Description        :- Percentage of patients with a diagnosis of epilepsy who were screened for depression and anxiety.
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/


object Axon3 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Axon3"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, initialRDD
      , Axon03Elements.Epilepsy
    ).collect.toList

    val patientHistory: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistory)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val eligiblePopulation = ippRDD

      //Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD)
      metRDD.cache()

      val intermediate = getSubtractRDD(ippRDD, metRDD)
      intermediate.cache()

      // Filter Exclusion
      val exceptionRDD = getExceptionRdd(intermediate, patientHistory)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediate, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, ippRDD, eligiblePopulation, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistory.destroy()


    }
  }

  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit,m,true,12)
        && isVisitTypeIn(visit, m
        , Axon03Elements.Office_Visit
        , Axon03Elements.Outpatient_Consultation
        , Axon03Elements.Depression_Diagnosis
        , Axon03Elements.Anxiety_Disorders
      )
        && wasDiagnosisInHistory(visit, m, Axon03Elements.Epilepsy, patientHistory)
    )
  }


  // Numerator criteria
  def getMet(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (
        isAssessmentPerformedOnEncounter(visit, m, Axon03Elements.Depression_Screening)
          &&
          isAssessmentPerformedOnEncounter(visit, m, Axon03Elements.Anxiety_Screening)
        )
        ||
        isAssessmentPerformedOnEncounter(visit, m, Axon03Elements.Depression_And_Anxiety_Screening)
    )
  }


  // Exception Criteria
  def getExceptionRdd(intermediateException: RDD[CassandraRow], patientHistory: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      isCommunicationDoneFromPatientToProviderDuringEncounter(visit, m, Axon03Elements.Patient_Declines_For_Anxiety_And_Depression_Screening)
        ||
        (
          wasDiagnosisInHistory(visit, m, Axon03Elements.Depression_Diagnosis, patientHistory)
            //isDiagnosisOverlapsEncounter(visit,m, patientHistory,Axon03Elements.Depression_Diagnosis)
            ||
            wasDiagnosisInHistory(visit, m, Axon03Elements.Anxiety_Disorders, patientHistory)
          )
    )
  }

}






