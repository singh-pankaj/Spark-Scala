package com.figmd.janus.measureComputation.nonqpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, _}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 166
* Measure Title              :- Sepsis Management: Septic Shock: Lactate Level Measurement
* Measure Description        :- Percentage of emergency department visits for patients aged 18 years and older with septic shock who had an order for a serum lactate level during the emergency department visit
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sagar Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Acep26 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "ACEP26"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      AdminElements.Emergency_Visit_Arrival_Date,
      AdminElements.Emergency_Visit_Departure_Date,
      ACEP26Elements.Critical_Care_Evaluation_And_Management_Date,
      ACEP26Elements.Acute_Care_Or_Inpatient_Facility
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //filter denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusion(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA)
      metRDD.cache()


      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)

      patientHistoryList.unpersist()
    }
  }


  // IPP-Denominator criteria
  /* All emergency department visits for patients aged 18 years and older with septic shock */

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isEDorCCEncounterPerformed(visit, m, patientHistoryList, AdminElements.Emergency_Visit_Arrival_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management)
        && isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP26Elements.Septic_Shock, ACEP26Elements.Septic_Shock_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
        || (isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP26Elements.Sepsis, ACEP26Elements.Sepsis_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
        && isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP26Elements.Acute_Hypotension, ACEP26Elements.Acute_Hypotension_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
        )
        ||
        (  isDiagnosisDuringEDOrCCEncounter(visit, m,ACEP26Elements.Infection,ACEP26Elements.Infection_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
           && isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP26Elements.Acute_Hypotension, ACEP26Elements.Acute_Hypotension_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
          )
    )
  }


  /*
  EXclusion Criteria : Patients with any of the following :
     - Transferred into the emergency department from another acute care facility or other in-patient hospital setting
     - Left before treatment was complete
     - Died during the emergency department visit
     - Cardiac arrest within the emergency department visit
     - Patient or surrogate decision maker declined care
     - Advanced directives present in patient medical record for comfort care
     - Toxicological emergencies
     - Burn
     - Seizures
     - Secondary diagnosis of:
          - Gastrointestinal bleeding
          - Stroke
          - Acute myocardial infarction
          - Acute trauma
   */


  def getExclusion(rdd: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>

      wasPatientTransferedFromAcuteCareWithinXHours(visit, m, ACEP26Elements.Acute_Care_Or_Inpatient_Facility, AdminElements.Emergency_Visit_Arrival_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management, 6, patientHistoryList)
        ||
        (isPatientLeftBeforeTreatmentCompletionOnEDOrCCEncounter(visit, m, ACEP26Elements.Left_Before_Treatment_Completion, ACEP26Elements.Left_Before_Treatment_Completion_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
          || isPatientExpiredOnEDOrCCEncounter(visit, m, ACEP26Elements.Patient_Expired, ACEP26Elements.Patient_Expired_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
          )
        ||
        (
          isInterventionOrderedDuringEDOrCCEncounter(visit, m, ACEP26Elements.Comfort_Measures,ACEP26Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
            || isInterventionPerformedDuringEDOrCCEncounter(visit, m, ACEP26Elements.Comfort_Measures,ACEP26Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
            || isCommunicationFromPatientToProviderDoneDuringEDOrCCEncounter(visit, m, ACEP26Elements.Declined_Sepsis_Care,ACEP26Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP26Elements.Cardiac_Arrest,ACEP26Elements.Cardiac_Arrest_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP26Elements.Second_And_Third_Degree_Burn,ACEP26Elements.Second_And_Third_Degree_Burn_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP26Elements.Seizure,ACEP26Elements.Seizure_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP26Elements.Gastrointestinal_Hemorrhage,ACEP26Elements.Gastrointestinal_Hemorrhage_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP26Elements.Hemorrhagic_Stroke,ACEP26Elements.Hemorrhagic_Stroke_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP26Elements.Ischemic_Stroke,ACEP26Elements.Ischemic_Stroke_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP26Elements.Myocardial_Infarction,ACEP26Elements.Myocardial_Infarction_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP26Elements.Toxicological_Emergency,ACEP26Elements.Toxicological_Emergency_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP26Elements.Trauma,ACEP26Elements.Trauma_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP26Elements.Critical_Care_Evaluation_And_Management_Date)

          )
    )
  }


  // Numerator criteria
  /* Emergency department visits for patients who had an order for a serum lactate level during the emergency department visit */

  def getMet(ippRdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRdd.filter(visit => isLaboratoryTestOrder(visit, m, ACEP26Elements.Serum_Lactate_Order))
//END
  }

}
