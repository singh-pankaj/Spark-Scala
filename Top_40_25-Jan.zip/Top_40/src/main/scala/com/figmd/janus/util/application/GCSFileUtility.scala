package com.figmd.janus.util.application

import java.io.{BufferedReader, InputStreamReader}

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path

//TODO: Take care of exceptions like FileNotFound, etc.
object GCSFileUtility {

  /*!
   * Use this function for small files as it will return content as array of string
   */
  def getFileAsArray(hadoopConf: Configuration, fileName: String) = {
    val inputFilePath = new Path(fileName)
    val hadoopFileSystem = inputFilePath.getFileSystem(hadoopConf)
    val br: BufferedReader = new BufferedReader(new InputStreamReader(hadoopFileSystem.open(inputFilePath)))
    val data = br.lines().toArray
    br.close()
  }

  def readFile(hadoopConf: Configuration, fileName: String): Array[String] = {
    val inputFilePath = new Path(fileName)
    val hadoopFileSystem = inputFilePath.getFileSystem(hadoopConf)
    val br: BufferedReader = new BufferedReader(new InputStreamReader(hadoopFileSystem.open(inputFilePath)))

    /*
     * Conversion from Java Stream to Scala Stream is experimental in 2.11 and hence doing conversion manually
     */
    val data = br.lines().toArray
    br.close()
    var outputData1 = data.toStream.map(line => line.toString).toArray
    return outputData1
  }

  def createFile(hadoopConf: Configuration, outputFilePath: String, msg: String): Unit = {
    val outFilePath = new Path(outputFilePath)
    val hadoopFileSystem = outFilePath.getFileSystem(hadoopConf)
    val fos = hadoopFileSystem.create(outFilePath)
    fos.write(msg.getBytes)
    fos.close()
  }
}
