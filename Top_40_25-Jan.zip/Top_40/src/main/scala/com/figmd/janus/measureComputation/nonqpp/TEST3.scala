package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty,TEST3Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- TEST3
* Measure Title               :- Cerumen Impaction: Treatment
* Measure Description         :- Percentage of patients with cerumen impaction who receive treatment with at least one
                                 appropriate intervention
* Calculation Implementation  :- Visit-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- SANKET.DHAPTE
* Initial GIT Version/Tag(CRA):- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object TEST3 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "TEST3"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
                                                                        ,TEST3Elements.Irrigation
                                                                        ,TEST3Elements.Cerumen_Removal
                                                                        ,TEST3Elements.Cerumenolytics
                                                                        ,TEST3Elements.Otolaryngologist_As_A_Clinician_Or_Service
                                                                        ,TEST3Elements.Referrals_Where_Management_Of_Cerumen_Impaction_May_Occur
                                              )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients over 6 months of age with cerumen impaction seen for an ambulatory visit.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
         isAgeAboveInMonth(visit,m,true,6)
      && isVisitTypeIn(visit,m,TEST3Elements.Ambulatory_Visit)
      && isDiagnosedOnEncounter(visit,m,TEST3Elements.Cerumen_Impaction)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    Patients where a method to alleviate cerumen impaction was attempted and linked to an ambulatory
    visit for cerumen impaction.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
         isProcedurePerformed(visit,m,TEST3Elements.Irrigation,patientHistoryBroadcastList)
      || isProcedurePerformed(visit,m,TEST3Elements.Cerumen_Removal,patientHistoryBroadcastList)
      || isMedicationActiveOrdered(visit,m,TEST3Elements.Cerumenolytics,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients referred for management by another provider.
  ----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
         isEncounterPerformed(visit,m,TEST3Elements.Otolaryngologist_As_A_Clinician_Or_Service,patientHistoryBroadcastList)
      || isInterventionPerformed(visit,m,TEST3Elements.Referrals_Where_Management_Of_Cerumen_Impaction_May_Occur,patientHistoryBroadcastList)
    )
  }
}