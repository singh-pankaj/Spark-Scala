
package com.figmd.janus.measureComputation.qpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.qpp.Qpp431.{getEncounterCountFromHistory, wasInterventionPerformedBeforeEncounterInXMonths}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 431
* Measure Title              :- Preventive Care and Screening: Unhealthy Alcohol Use: Screening & Brief Counseling
* Measure Description        :- Percentage of patients aged 18 years and older who were screened for unhealthy alcohol use using a systematic screening method
                                at least once within the last 24 months AND who received brief counseling if identified as an unhealthy alcohol user.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp431 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp431"
  val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      , QPP431Elements.Health_Risk_Assessment
      , QPP431Elements.Annual_Wellness_Visit
      , QPP431Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
      , QPP431Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
      , QPP431Elements.Preventive_Care_Services___Group_Counseling
      , QPP431Elements.Preventive_Care_Services_Individual_Counseling
      , QPP431Elements.Preventive_Care_Services___Other
      , QPP431Elements.Psychoanalysis
      , QPP431Elements.Health_And_Behavioral_Assessment___Initial
      , QPP431Elements.Health_And_Behavioral_Assessment__Reassessment
      , QPP431Elements.Health___Behavioral_Assessment___Individual
      , QPP431Elements.Occupational_Therapy_Evaluation
      , QPP431Elements.Medical_Nutrition_Therapy
      , QPP431Elements.Psych_Visit
      , QPP431Elements.Office_Visit
      , QPP431Elements.Unhealthy_Alcohol_Screening_And_Counselling
      , QPP431Elements.Identification_Not_Unhealthy_Alcohol_User
      , QPP431Elements.Audit
      , QPP431Elements.Single_Question_Screening
      , QPP431Elements.Number_Of_Drinks_Per_Drinking_Day
      , QPP431Elements.Number_Of_Drinks_Per_Drinking_Day_Keywords
      , QPP431Elements.Audit_C_Grouping
      , QPP431Elements.Screening_For_Unhealthy_Alcohol_Use
      , QPP431Elements.Unhealthy_Alcohol_User
      , QPP431Elements.Brief_Counseling_For_Unhealthy_Alcohol_Use
      , QPP431Elements.Not_Unhealthy_Alcohol_User
      , QPP431Elements.Alcohol_Reason_Not_Specified
      , QPP431Elements.Limited_Life_Expectancy
      , QPP431Elements.Unhealthy_Alcohol_Medical_Reason)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val patientHistoryList1 = countElement(patientHistoryRDD, m
      , QPP431Elements.Health_Risk_Assessment
      , QPP431Elements.Annual_Wellness_Visit
      , QPP431Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
      , QPP431Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
      , QPP431Elements.Preventive_Care_Services___Group_Counseling
      , QPP431Elements.Preventive_Care_Services_Individual_Counseling
      , QPP431Elements.Preventive_Care_Services___Other
      , QPP431Elements.Psychoanalysis
      , QPP431Elements.Health_And_Behavioral_Assessment___Initial
      , QPP431Elements.Health_And_Behavioral_Assessment__Reassessment
      , QPP431Elements.Health___Behavioral_Assessment___Individual
      , QPP431Elements.Occupational_Therapy_Evaluation
      , QPP431Elements.Medical_Nutrition_Therapy
      , QPP431Elements.Psych_Visit
      , QPP431Elements.Office_Visit)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]], patientHistoryList1)
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      //    exclusionRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateA = getSubtractRDD(ippRDD, metRDD)
      intermediateA.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateA, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  All patients aged 18 years and older seen for at least two visits or at least one preventive visit during the measurement period.
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], patientHistoryList1: List[(String, Int)]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && (getEncounterCountFromHistory(visit, m, 1, true, patientHistoryList1)
        || getEncounterCountFromHistory(visit, m, 2, true, patientHistoryList1)
        )
        && !isTeleHealthModifier(visit, m
        , QPP431Elements.Health_Risk_Assessment_Telehealth_Modifier
        , QPP431Elements.Preventive_Care_Services___Established_Office_Visit_18_And_Up_Telehealth_Modifier
        , QPP431Elements.Preventive_Care_Services_Initial_Office_Visit_18_And_Up_Telehealth_Modifier
        , QPP431Elements.Preventive_Care_Services___Group_Counseling_Telehealth_Modifier
        , QPP431Elements.Preventive_Care_Services_Individual_Counseling_Telehealth_Modifier
        , QPP431Elements.Annual_Wellness_Visit_Telehealth_Modifier
        , QPP431Elements.Preventive_Care_Services___Other_Telehealth_Modifier
        , QPP431Elements.Psych_Visit_Telehealth_Modifier
        , QPP431Elements.Health_And_Behavioral_Assessment___Individual_Telehealth_Modifier
        , QPP431Elements.Health_And_Behavioral_Assessment_Reassessment_Telehealth_Modifier
        , QPP431Elements.Health_And_Behavioral_Assessment__Initial_Telehealth_Modifier_Date
        , QPP431Elements.Psychoanalysis_Telehealth_Modifier
        , QPP431Elements.Office_Visit_Telehealth_Modifier
        , QPP431Elements.Medical_Nutrition_Therapy_Telehealth_Modifier
        , QPP431Elements.Occupational_Therapy_Evaluation_Telehealth_Modifier)
        && isPOSEncounterNotPerformed(visit, m, QPP431Elements.Pos_02)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Patients who were screened for unhealthy alcohol use using a systematic screening method at least once within the last 24 months
  AND who received brief counseling if identified as an unhealthy alcohol user
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (    wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, QPP431Elements.Unhealthy_Alcohol_Screening_And_Counselling, 24, patientHistoryBroadcastList)
        || wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, QPP431Elements.Identification_Not_Unhealthy_Alcohol_User, 24, patientHistoryBroadcastList)
        || ((   wasAssessmentPerformedValueWithInXMonths(visit, m, QPP431Elements.Audit, 24, 8, CompareOperator.GREATER_EQUAL, patientHistoryBroadcastList)
            || (  wasAssessmentPerformedValueWithInXMonths(visit, m, QPP431Elements.Single_Question_Screening, 24, 2, CompareOperator.GREATER_EQUAL, patientHistoryBroadcastList)
                  && (  (   isMale(visit, m)
                        && (   wasInterventionPerformedValueWithInXMonths(visit, m, QPP431Elements.Number_Of_Drinks_Per_Drinking_Day,  5, CompareOperator.GREATER_EQUAL,24, patientHistoryBroadcastList)
                            || wasInterventionPerformedValueWithInXMonths(visit, m, QPP431Elements.Number_Of_Drinks_Per_Drinking_Day_Keywords,  5, CompareOperator.GREATER_EQUAL,24, patientHistoryBroadcastList)
                           )
                        )
                      || ( (    isFemale(visit, m)
                             || isAgeAbove(visit, m, false, 65)
                            )
                         && (     wasInterventionPerformedValueWithInXMonths(visit, m, QPP431Elements.Number_Of_Drinks_Per_Drinking_Day,  4, CompareOperator.GREATER_EQUAL,24, patientHistoryBroadcastList)
                               || wasInterventionPerformedValueWithInXMonths(visit, m, QPP431Elements.Number_Of_Drinks_Per_Drinking_Day_Keywords,  4, CompareOperator.GREATER_EQUAL,24, patientHistoryBroadcastList)
                            )
                         )
                     )
              )
            || (    isMale(visit, m)
                 && wasAssessmentPerformedValueWithInXMonths(visit, m, QPP431Elements.Audit_C_Grouping, 24, 4, CompareOperator.GREATER_EQUAL, patientHistoryBroadcastList)
               )
            || (    isFemale(visit, m)
                 && wasAssessmentPerformedValueWithInXMonths(visit, m, QPP431Elements.Audit_C_Grouping, 24, 3, CompareOperator.GREATER_EQUAL, patientHistoryBroadcastList)
               )
            || wasInterventionPerformedBeforeEncounterWithResultWithinXMonths(visit, m, QPP431Elements.Screening_For_Unhealthy_Alcohol_Use, QPP431Elements.Unhealthy_Alcohol_User, 24, patientHistoryBroadcastList)
           )
          && wasInterventionPerformedBeforeEncounterWithinXMonths(visit, m, QPP431Elements.Brief_Counseling_For_Unhealthy_Alcohol_Use, 24, patientHistoryBroadcastList)
         )
      || wasInterventionPerformedBeforeEncounterWithResultWithinXMonths(visit, m, QPP431Elements.Screening_For_Unhealthy_Alcohol_Use, QPP431Elements.Not_Unhealthy_Alcohol_User, 24, patientHistoryBroadcastList)
      || (    wasAssessmentPerformedValueWithInXMonths(visit, m, QPP431Elements.Audit, 24, 8, CompareOperator.LESS, patientHistoryBroadcastList)
           || (   wasAssessmentPerformedValueWithInXMonths(visit, m, QPP431Elements.Single_Question_Screening, 24, 2, CompareOperator.LESS, patientHistoryBroadcastList)
              && (  ( isMale(visit, m)
                      && (   wasInterventionPerformedValueWithInXMonths(visit, m, QPP431Elements.Number_Of_Drinks_Per_Drinking_Day,  5, CompareOperator.GREATER_EQUAL,24, patientHistoryBroadcastList)
                          || wasInterventionPerformedValueWithInXMonths(visit, m, QPP431Elements.Number_Of_Drinks_Per_Drinking_Day_Keywords,  5, CompareOperator.GREATER_EQUAL,24, patientHistoryBroadcastList)
                         )
                    )
                 || ( (    isFemale(visit, m)
                        || isAgeAbove(visit, m, false, 65)
                      )
                     && (   wasInterventionPerformedValueWithInXMonths(visit, m, QPP431Elements.Number_Of_Drinks_Per_Drinking_Day,  4, CompareOperator.GREATER_EQUAL,24, patientHistoryBroadcastList)
                         || wasInterventionPerformedValueWithInXMonths(visit, m, QPP431Elements.Number_Of_Drinks_Per_Drinking_Day_Keywords,  4, CompareOperator.GREATER_EQUAL,24, patientHistoryBroadcastList)
                        )
                    )
                 )
             )
           || ( isMale(visit, m)
                && wasAssessmentPerformedValueWithInXMonths(visit, m, QPP431Elements.Audit_C_Grouping, 24, 4, CompareOperator.LESS, patientHistoryBroadcastList)
              )
           || ( isFemale(visit, m)
                && wasAssessmentPerformedValueWithInXMonths(visit, m, QPP431Elements.Audit_C_Grouping, 24, 3, CompareOperator.LESS, patientHistoryBroadcastList)
              )
        )
        )
        && !wasAssessmentPerformedBeforeEncounterWithinXMonths(visit, m, AdminElements.Encounter_Date, QPP431Elements.Alcohol_Reason_Not_Specified, 24, patientHistoryBroadcastList)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Documentation of medical reason(s) for not screening for unhealthy alcohol use (e.g., limited life expectancy, other medical reasons)
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      wasDiagnosedBeforeEncounter(visit, m, QPP431Elements.Limited_Life_Expectancy, patientHistoryBroadcastList)
        || wasInterventionPerformedBeforeEncounter(visit, m, QPP431Elements.Unhealthy_Alcohol_Medical_Reason, patientHistoryBroadcastList)
    )
  }
}