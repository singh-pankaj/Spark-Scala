package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS46
* Measure Title               :- Evidence of anatomic closure of macular hole within 90 days after surgery as documented by OCT
* Measure Description         :- Percentage of patients with a macular hole who have evidence of anatomic closure
*                                 documented by OCT within 90 days after surgical treatment.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- NA
* Measure Developer           :- Rishikesh Patil
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.6
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS46 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS46"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , IRIS46Elements.Macular_Hole
      , IRIS46Elements.Macular_Hole_Surgery
      , IRIS46Elements.Macular_Hole_Eye
      , IRIS46Elements.Associated_Retinal_Detachment
      , IRIS46Elements.Associated_Retinal_Detachment__Eye
      , IRIS46Elements.Macular_Hole_Surgery_Date
      , IRIS46Elements.Anatomic_Closure
      , IRIS46Elements.Anatomic_Closure_Eye

    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  //IPP criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
        isPatientAdult(visit, m)
        &&
        wasDiagnosedBeforeOrEqualEncounter(visit, m, IRIS46Elements.Macular_Hole, patientHistoryBroadcastList)
        &&
        isProcedurePerformedDuringEncounter(visit, m, IRIS46Elements.Macular_Hole_Surgery)
        &&
        wasProcedurePerformedBeforeEndInDays(visit, m, IRIS46Elements.Macular_Hole_Surgery, 90, patientHistoryBroadcastList )
        &&
        checkEyeElementsInRange(visit, m, IRIS46Elements.Macular_Hole_Eye, IRIS46Elements.Macular_Hole_Surgery)
    )
  }


  //Exclusion criteria
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      wasDiagnosedBeforeOrEqualEncounter(visit, m, IRIS46Elements.Associated_Retinal_Detachment, patientHistoryBroadcastList)
      &&
      checkEyeElementBeforeDiagnosisEyesElement(visit, m, IRIS46Elements.Associated_Retinal_Detachment__Eye, patientHistoryBroadcastList, IRIS46Elements.Associated_Retinal_Detachment)
    )
  }


  //Numerator criteria
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      wasDiagnosedBeforeEncounterWithinXDays(visit, m, IRIS46Elements.Macular_Hole_Surgery_Date, IRIS46Elements.Anatomic_Closure, 90, patientHistoryBroadcastList)
      &&
      checkEyeElementBeforeDiagnosisEyesElement(visit, m, IRIS46Elements.Anatomic_Closure_Eye, patientHistoryBroadcastList, IRIS46Elements.Anatomic_Closure)
    )
  }
}