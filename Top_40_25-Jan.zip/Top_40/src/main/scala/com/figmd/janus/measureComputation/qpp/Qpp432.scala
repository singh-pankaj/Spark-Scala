package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, QPP432Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 432
* Measure Title              :- Proportion of Patients Sustaining a Bladder Injury at the Time of any Pelvic Organ
                                Prolapse Repair
* Measure Description        :- Percentage of patients undergoing any surgery to repair pelvic organ prolapse
                                who sustains an injury to the bladder recognized either during or within 30 days after surgery
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp432 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp432"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP432Elements.Pelvic_Organ_Prolapse_Surgery
      , QPP432Elements.Bladder_Injury_2
      , QPP432Elements.Bladder_Injury_1
      , QPP432Elements.Bladder_Injury_Not_Met
      , QPP432Elements.Bladder_Injury_Medical_Reason
      , QPP432Elements.Bladder_Perforation_By_Midurethral_Sling_Trocar
      , QPP432Elements.Expired
      , QPP432Elements.Injury_Medical_Reason
      , QPP432Elements.Urinary_Incontinence_Procedure)
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate RDD
      val intermediateException = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
   All patients undergoing anterior or apical pelvic organ prolapse (POP) surgery
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isFemale(visit, m)
        && isProcedurePerformedDuringEncounter(visit, m, QPP432Elements.Pelvic_Organ_Prolapse_Surgery)
        && wasProcedurePerformedAfterStartWithInXMonths(visit, m, QPP432Elements.Pelvic_Organ_Prolapse_Surgery, 11, CalenderUnit.MONTH, patientHistoryBroadcastList)
    )
  }

  /*------------------------------------------------------------------------------------------------
    Total number of patient's receiving a bladder injury at the time of surgery to repair a pelvic
    organ prolapse with repair during the procedure or subsequently up to 30 days post-surgery.
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        isProcedureAdverseEvent(visit, m, QPP432Elements.Bladder_Injury_2, patientHistoryBroadcastList)
          || isProcedureAdverseEventDuringProcedure(visit, m, QPP432Elements.Bladder_Injury_1, QPP432Elements.Pelvic_Organ_Prolapse_Surgery)
          || isProcedureAdverseEventInXDaysAfterProcedure(visit, m, QPP432Elements.Pelvic_Organ_Prolapse_Surgery, QPP432Elements.Bladder_Injury_1, 30, patientHistoryBroadcastList)
        )
        && !isProcedureAdverseEvent(visit, m, QPP432Elements.Bladder_Injury_Not_Met, patientHistoryBroadcastList)
    )

  }

  /*-----------------------------------------------------------------------------------------------------------------
   Documented medical reasons for not reporting bladder injury (e.g. gynecologic or other pelvic malignancy documented,
   concurrent surgery involving bladder pathology, injury that occurs during a urinary incontinence procedure, patient
   death from non-medical causes not related to surgery, patient died during procedure without evidence of bladder
   injury)
   -----------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermediateException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateException.filter(visit =>
      isProcedureAdverseEventDuringProcedure(visit, m, QPP432Elements.Bladder_Injury_Medical_Reason, QPP432Elements.Pelvic_Organ_Prolapse_Surgery)
        || isProcedureAdverseEventInXDaysAfterProcedure(visit, m, QPP432Elements.Pelvic_Organ_Prolapse_Surgery_Date, QPP432Elements.Bladder_Injury_Medical_Reason, 30, patientHistoryBroadcastList)
        || isProcedureAdverseEventDuringProcedure(visit, m, QPP432Elements.Bladder_Perforation_By_Midurethral_Sling_Trocar, QPP432Elements.Pelvic_Organ_Prolapse_Surgery)
        || isProcedureAdverseEventInXDaysAfterProcedure(visit, m, QPP432Elements.Pelvic_Organ_Prolapse_Surgery_Date, QPP432Elements.Bladder_Perforation_By_Midurethral_Sling_Trocar, 30, patientHistoryBroadcastList)
        || isProcedurePerformedDuringOtherProcedure(visit, m, QPP432Elements.Surgery_Involving_Bladder_Pathology, QPP432Elements.Pelvic_Organ_Prolapse_Surgery)
        || isPatientDiedDuringProcedure(visit, m, QPP432Elements.Expired, QPP432Elements.Pelvic_Organ_Prolapse_Surgery)
        || isPatientExpiredInXDaysAfterProcedure(visit, m, QPP432Elements.Pelvic_Organ_Prolapse_Surgery, QPP432Elements.Expired, 30, patientHistoryBroadcastList)
        || isDiagnosedDuringProcedure(visit, m, QPP432Elements.Injury_Medical_Reason, QPP432Elements.Pelvic_Organ_Prolapse_Surgery)
        || isDiagnosedInXDaysAfterProcedure(visit, m, QPP432Elements.Pelvic_Organ_Prolapse_Surgery, QPP432Elements.Injury_Medical_Reason, 30, patientHistoryBroadcastList)
        || (
        isDiagnosedDuringProcedure(visit, m, QPP432Elements.Injury, QPP432Elements.Pelvic_Organ_Prolapse_Surgery)
          && isProcedureAdverseEventInXDaysAfterProcedure(visit, m, QPP432Elements.Pelvic_Organ_Prolapse_Surgery_Date, QPP432Elements.Urinary_Incontinence_Procedure, 30, patientHistoryBroadcastList)
        )
    )

  }

}
