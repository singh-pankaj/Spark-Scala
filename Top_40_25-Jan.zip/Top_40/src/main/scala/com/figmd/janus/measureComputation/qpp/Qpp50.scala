
package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP50Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 50
* Measure Title              :- Urinary Incontinence: Plan of Care for Urinary Incontinence in Women Aged 65 Years and Older
* Measure Description        :- Percentage of female patients aged 65 years and older with a diagnosis of urinary incontinence with a documented plan of care for urinary incontinence at least once within 12 months
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp50 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp50"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Backtracking List
      var patientHistoryRDD = getPatientHistory(sparkSession, ippRDD, QPP50Elements.Hospice, QPP50Elements.Hospice_Services_Snomedct,
        QPP50Elements.Hospice_Care, QPP50Elements.Documentation_Of_Urinary_Incontinence_Plan_Of_Care, QPP50Elements.Documentation_Of_Plan_Of_Care_For_Urinary_Incontinence)

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect.toList)
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList)

      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()

      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateB = getSubtractRDD(intermediateA, metRDD)

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow];


      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(
      visit =>
        //isFemale(visit, m)
          //&&
            isAgeBelow(visit, m, true, 65)
          && isDiagnosedDuringEncounter(visit, m, QPP50Elements.Urinary_Incontinence)
          && isVisitTypeIn(visit, m, QPP50Elements.Office_Visit, QPP50Elements.Care_Services_In_Long_Term_Residential_Facility,
          QPP50Elements.Home_Healthcare_Services, QPP50Elements.Initial_Preventive_Physical_Examination)
    )

  }

  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isInterventionPerformedInHistory(visit, m, QPP50Elements.Hospice, patientHistoryList)
        || (
        isInterventionBeforeEnd(visit, m, QPP50Elements.Hospice_Services_Snomedct, patientHistoryList)
          || isInterventionBeforeEnd(visit, m, QPP50Elements.Hospice_Care, patientHistoryList)
        )
    )
  }


  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      ((
        wasInterventionXBeforeEncounter(visit, m, QPP50Elements.Documentation_Of_Urinary_Incontinence_Plan_Of_Care, 12, patientHistoryList)
          || (
          wasInterventionXAfterEncounter(visit, m, QPP50Elements.Documentation_Of_Urinary_Incontinence_Plan_Of_Care, 12, patientHistoryList)
            && isInterventionPerformedInHistory(visit, m, QPP50Elements.Documentation_Of_Urinary_Incontinence_Plan_Of_Care, patientHistoryList)
          ) || (
            wasInterventionXBeforeEncounter(visit, m, QPP50Elements.Documentation_Of_Plan_Of_Care_For_Urinary_Incontinence, 12, patientHistoryList)
              || (
              wasInterventionXAfterEncounter(visit, m, QPP50Elements.Documentation_Of_Plan_Of_Care_For_Urinary_Incontinence, 12, patientHistoryList)
                && isInterventionPerformedInHistory(visit, m, QPP50Elements.Documentation_Of_Plan_Of_Care_For_Urinary_Incontinence, patientHistoryList)
              ))
        )
        &&
        !isInterventionPerformedInHistory(visit, m, QPP50Elements.Planurininc_Reason_Not_Specified, patientHistoryList)
        ))
  }

}