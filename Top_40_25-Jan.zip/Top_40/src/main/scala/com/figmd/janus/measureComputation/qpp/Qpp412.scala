package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp412
* Measure Title              :- Documentation of Signed Opioid Treatment Agreement
* Measure Description        :- All patients 18 and older prescribed opiates for longer than six weeks duration who
*                               signed an opioid treatment agreement at least once during Opioid Therapy documented
*                               in the medical record
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumant Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp412 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp412"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    val patientHistoryRDD = getPatientHistory(sparkSession,initialRDD
      ,QPP412Elements.Opioid_Medication_Start_Date
      ,QPP412Elements.Opioid_Medication_End_Date
      ,QPP412Elements.Office_Visit_Telehealth_Modifier
      ,QPP412Elements.Nursing_Facility_Visit_Telehealth_Modifier
      ,QPP412Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier
      ,QPP412Elements.Home_Healthcare_Services_Telehealth_Modifier
      ,QPP412Elements.Pos_02
      ,QPP412Elements.Hospice_Care
      ,QPP412Elements.Hospice_Services_Snomedct
      ,QPP412Elements.Opioid_Agreement
      ,QPP412Elements.Opioid_Medication
      ,QPP412Elements.Prescribed_Opiates
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val medicationList = List[(String, String)]((QPP412Elements.Opioid_Medication_Start_Date, QPP412Elements.Opioid_Medication_End_Date))
    val medicationDurationBroadcastList = sparkSession.sparkContext.broadcast(
      consecutive(patientHistoryRDD, m, medicationList, CalenderUnit.WEEK,
        CalenderUnit.WEEK, 0, CalenderUnit.DAY, 1, "DURING"))

    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList: Broadcast[List[CassandraRow]], medicationDurationBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Filter denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exceptions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateRDD = ippRDD.subtract(exclusionRDD)
      intermediateRDD.cache()

      // Filter Met
      val metRDD = getMet(intermediateRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]], medicationDurationBroadcastList)
      metRDD.cache()


      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      medicationDurationBroadcastList.destroy()
    }

  }


  /*-----------------------------------------------------------------------------------------------------------------------
  All patients 18 and older prescribed opiates for longer than six weeks duration
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], medicationDurationBroadcastList : Broadcast[List[(String,String, Double)]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        isVisitTypeIn(visit, m
          , QPP412Elements.Home_Healthcare_Services
          , QPP412Elements.Care_Services_In_Long_Term_Residential_Facility
          , QPP412Elements.Nursing_Facility_Visit
          , QPP412Elements.Office_Visit
        )
        &&
        (
          getConsecutiveResult(visit, m, QPP412Elements.Opioid_Medication, 6, CompareOperator.GREATER_EQUAL, medicationDurationBroadcastList)
            ||
            assessmentPerformed(visit, m, QPP412Elements.Prescribed_Opiates)
          )
        && !
        (
          isEncounterPerformed(visit, m, QPP412Elements.Office_Visit_Telehealth_Modifier, patientHistoryBroadcastList)
            ||
            isEncounterPerformed(visit, m, QPP412Elements.Nursing_Facility_Visit_Telehealth_Modifier, patientHistoryBroadcastList)
            ||
            isEncounterPerformed(visit, m, QPP412Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier, patientHistoryBroadcastList)
            ||
            isEncounterPerformed(visit, m, QPP412Elements.Home_Healthcare_Services_Telehealth_Modifier, patientHistoryBroadcastList)
          )
        && ! isEncounterPerformed(visit, m, QPP412Elements.Pos_02, patientHistoryBroadcastList)

    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
  Patients who were in hospice at any time during the performance period
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        assessmentPerformed(visit, m, QPP412Elements.Hospice_Services)
          ||
          isInterventionPerformed(visit, m, QPP412Elements.Hospice_Care, patientHistoryBroadcastList)
          ||
          isInterventionPerformed(visit, m, QPP412Elements.Hospice_Services_Snomedct, patientHistoryBroadcastList)
        )
    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
Patients who signed an opioid treatment agreement at least once during opioid therapy
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], medicationDurationBroadcastList : Broadcast[List[(String,String, Double)]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateRDD.filter(visit =>
      (
        assessmentPerformed(visit, m, QPP412Elements.Signed_Opioid_Treatment_Agreement)
          ||
          isCommunicationBeforeMedicationAndAssessment(visit, m, QPP412Elements.Opioid_Agreement,
            QPP412Elements.Opioid_Medication, QPP412Elements.Prescribed_Opiates, 6, CompareOperator.GREATER_EQUAL,
            medicationDurationBroadcastList, patientHistoryBroadcastList)
        )
        && ! assessmentPerformed(visit, m, QPP412Elements.Signed_Opioid_Treatment_Agreement_Not_Met)
    )
  }


}
