package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.MeasureProperty
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- TEST7
* Measure Title              :- Tonsillectomy: Secondary Post-Tonsillectomy Hemorrhage in Children
* Measure Description        :- The rate of secondary post-tonsillectomy hemorrhage that requires reevaluation or intervention in
*                               patients 1 to 18 years of age seen by the operating surgeon between 2 and 21 days after surgery.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Ganesh Warkhad
----------------------------------------------------------------------------------------------------------------------------*/

object Test7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Test7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      TEST7Elements.Tonsillectomy
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()


      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()


      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 1)
        &&
        isAgeBelow(visit, m, true, 18)
        &&
        isProcedurePerformedDuringEncounter(visit, m, TEST7Elements.Tonsillectomy)
        &&
        isVisitTypeIn(visit, m
          , TEST7Elements.Office_Or_Other_Outpatient_Visit
          , TEST7Elements.Discharge_Services__Observation_Care
          , TEST7Elements.Discharge_Services___Hospital_Inpatient_Same_Day_Discharge
          , TEST7Elements.Outpatient_Consultation
          , TEST7Elements.Hospital_Inpatient_Visit___Initial
          , TEST7Elements.Hospital_Observation_Care___Initial
          , TEST7Elements.Subsequent_Hospital_Care
          , TEST7Elements.Subsequent_Observation_Care
        )
        &&
        (wasElementPresentInFutureOfHistoryElementBetweenRange(visit, m, TEST7Elements.Office_Or_Other_Outpatient_Visit, TEST7Elements.Tonsillectomy, 2, 21, patientHistoryList)
          && wasElementPresentInFutureOfHistoryElementBetweenRange(visit, m, TEST7Elements.Discharge_Services__Observation_Care, TEST7Elements.Tonsillectomy, 2, 21, patientHistoryList)
          && wasElementPresentInFutureOfHistoryElementBetweenRange(visit, m, TEST7Elements.Discharge_Services___Hospital_Inpatient_Same_Day_Discharge, TEST7Elements.Tonsillectomy, 2, 21, patientHistoryList)
          && wasElementPresentInFutureOfHistoryElementBetweenRange(visit, m, TEST7Elements.Outpatient_Consultation, TEST7Elements.Tonsillectomy, 2, 21, patientHistoryList)
          && wasElementPresentInFutureOfHistoryElementBetweenRange(visit, m, TEST7Elements.Hospital_Inpatient_Visit___Initial, TEST7Elements.Tonsillectomy, 2, 21, patientHistoryList)
          && wasElementPresentInFutureOfHistoryElementBetweenRange(visit, m, TEST7Elements.Hospital_Observation_Care___Initial, TEST7Elements.Tonsillectomy, 2, 21, patientHistoryList)
          && wasElementPresentInFutureOfHistoryElementBetweenRange(visit, m, TEST7Elements.Subsequent_Hospital_Care, TEST7Elements.Tonsillectomy, 2, 21, patientHistoryList)
          && wasElementPresentInFutureOfHistoryElementBetweenRange(visit, m, TEST7Elements.Subsequent_Observation_Care, TEST7Elements.Tonsillectomy, 2, 21, patientHistoryList)
          )
    )
  }


  // Denominator Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      wasElementOverlapsElement(visit, m, TEST7Elements.Bleeding__Clotting_Disorders, TEST7Elements.Tonsillectomy, patientHistoryList)
    )
  }

  // Numerator criteria
  def getMet(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      (wasElementPresentInFutureOfHistoryElementBetweenRange(visit, m, TEST7Elements.Post__Tonsillectomy_Hemorrhage__Secondary_, TEST7Elements.Tonsillectomy, 2, 21, patientHistoryList)
        ||
        wasElementPresentInFutureOfHistoryElementBetweenRange(visit, m, TEST7Elements.Secondary_Hemorrhage, TEST7Elements.Tonsillectomy, 2, 21, patientHistoryList)
        )
        &&
        (wasElementPresentInFutureOfHistoryElementBetweenRange(visit, m, TEST7Elements.Patient_Experienced_Hemorrhage, TEST7Elements.Tonsillectomy, 2, 21, patientHistoryList)
          &&
          wasElementPresentInFutureOfHistoryElementBetweenRange(visit, m, TEST7Elements.Reevaluation_For_Post_Tonsillectomy_Hemorrhage, TEST7Elements.Tonsillectomy, 2, 21, patientHistoryList)
          )
    )
  }
}