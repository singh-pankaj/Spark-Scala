package com.figmd.janus.measureComputation.qpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 67
* Measure Title              :- Hematology: Myelodysplastic Syndrome (MDS) and Acute Leukemias: Baseline Cytogenetic Testing Performed on Bone Marrow
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of myelodysplastic syndrome (MDS) or an acute
                                leukemia who had baseline cytogenetic testing performed on bone marrow
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp67 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp67"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      , QPP67Elements.Myelodysplastic_Syndrome_Or_Acute_Leukemia
      , QPP67Elements.Cytogenetic_Test
      , QPP67Elements.Cytogenetic_Testing
      , QPP67Elements.Treatment_For_Bone_Marrow
      , QPP67Elements.Cytogenetic_Test_Reason_Not_Specified
      , QPP67Elements.Cytogenetic_Test_Medical_Reason
      , QPP67Elements.Cytogenetic_Test_Patient_Reason
      , QPP67Elements.Cytogenetic_Test_System_Reason
      , QPP67Elements.Palliative_Care)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      val intermediateRDD = getSubtractRDD(ippRDD, metRDD)
      intermediateRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateRDD, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  All patients aged 18 years and older with a diagnosis of myelodysplastic syndrome (MDS) or an acute leukemia
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD:RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
            isPatientAdult(visit,m)
        &&  isVisitTypeIn(visit,m
              ,QPP67Elements.Office_Visit
              ,QPP67Elements.Outpatient_Consultation)
        &&  wasDiagnosedWithInHistory(visit,m,QPP67Elements.Myelodysplastic_Syndrome_Or_Acute_Leukemia,patientHistoryBroadcastList)
        && ! isTeleHealthModifier(visit,m
               ,QPP67Elements.Office_Visit_Telehealth_Modifier
               ,QPP67Elements.Outpatient_Consultation_Telehealth_Modifier)
        &&  isPOSEncounterNotPerformed(visit,m,QPP67Elements.Pos_02)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Patients who had baseline cytogenetic testing performed on bone marrow
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateRDD.filter(visit =>
      (     isLaboratoryTestPerformed(visit,m,QPP67Elements.Cytogenetic_Test,patientHistoryBroadcastList)
        ||  (  isLaboratoryTestPerformedDuringDiagnosis(visit,m,QPP67Elements.Cytogenetic_Testing,QPP67Elements.Cytogenetic_Testing_Date,QPP67Elements.Myelodysplastic_Syndrome_Or_Acute_Leukemia,QPP67Elements.Myelodysplastic_Syndrome_Or_Acute_Leukemia_Date)
             || (   wasLaboratoryTestPerformedBeforeMedication(visit,m,QPP67Elements.Treatment_For_Bone_Marrow,patientHistoryBroadcastList,QPP67Elements.Cytogenetic_Testing)
                 && wasMedicationAdministeredAfterDiagnosis(visit,m,QPP67Elements.Myelodysplastic_Syndrome_Or_Acute_Leukemia_Date,patientHistoryBroadcastList,QPP67Elements.Treatment_For_Bone_Marrow)
                )
            )
      )
      && ! isLaboratoryTestPerformed(visit,m,QPP67Elements.Cytogenetic_Test_Reason_Not_Specified,patientHistoryBroadcastList)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Documentation of medical reason(s) for not performing baseline cytogenetic testing on bone marrow (eg, no liquid bone marrow or fibrotic marrow).
Documentation of patient reason(s) for not performing baseline cytogenetic testing on bone marrow (eg, at time of diagnosis receiving palliative care or not receiving treatment as defined above).
Documentation of system reason(s) for not performing baseline cytogenetic testing on bone marrow (eg, patient previously treated by another physician at the time cytogenetic testing performed).
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermediateRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)

    intermediateRDD.filter(visit =>
            isLaboratoryTestPerformedNotDone(visit,m,QPP67Elements.Cytogenetic_Test_Medical_Reason,patientHistoryBroadcastList)
         || isLaboratoryTestPerformedNotDone(visit,m,QPP67Elements.Cytogenetic_Test_Patient_Reason,patientHistoryBroadcastList)
         || wasInterVentionPerformedBeforeDiagnosis(visit,m,QPP67Elements.Myelodysplastic_Syndrome_Or_Acute_Leukemia,patientHistoryBroadcastList,QPP67Elements.Palliative_Care)
         || isLaboratoryTestPerformedNotDone(visit,m,QPP67Elements.Cytogenetic_Test_System_Reason,patientHistoryBroadcastList)
    )
  }
}

