package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master.{AAD28Elements, AdminElements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.nonqpp.Aad9.{MEASURE_NAME, checkEmptyIPPRDD}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD 28
* Measure Title              :- Biopsy: Squamous Cell Carcinoma Pathology Report - AJCC Reporting Criteria Listed
* Measure Description        :- Percentage of all skin specimens diagnosed histologically as primary invasive cutaneous
                                SCC with pathology report listing the differentiation (well, moderately, poorly or
                                undifferentiated) of the tumor, perineural invasion involving nerves >= 0.1mm, and depth
                                of invasion.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object AAD28 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAD28"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , AAD28Elements.Cutaneous_Squamous_Cell_Carcinoma_Grp
      , AAD28Elements.Cutaneous_Biopsy_External_Auditory_Canal_Grp
      , AAD28Elements.Cutaneous_Biopsy_Grp
      , AAD28Elements.Tumor_Differentiation_Grp
      , AAD28Elements.Perineural_Invasion_Grp
      , AAD28Elements.Nerves_Grp
      , AAD28Elements.Depth_Of_Invasion_Grp
      , AAD28Elements.Undetermined_Scc_Features_Grp
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Filter Eligable IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      /*exclusion RDD*/
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.unpersist()
    }
  }

  /*------------------------------------------------------------------------------
     	All skin specimens diagnosed histologically as primary invasive cutaneous squamous cell carcinoma within
     	the reporting period.
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow],patientHistoryRDD:RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)


    initialRDD.filter(visit =>
         wasDiagnosedBeforeOrEqualEncounter(visit,m,AAD28Elements.Cutaneous_Squamous_Cell_Carcinoma_Grp,patientHistoryList)
      && (
           wasDiagnosedBeforeOrEqualEncounter(visit,m,AAD28Elements.Cutaneous_Squamous_Cell_Carcinoma_Grp,patientHistoryList)
           &&
             (
                  isProcedurePerformedDuringEncounter(visit,m,AAD28Elements.Cutaneous_Biopsy_External_Auditory_Canal_Grp)
               || isProcedurePerformedDuringEncounter(visit,m,AAD28Elements.Cutaneous_Biopsy_Grp)
              )
         )
    )
  }

  /*------------------------------------------------------------------------------
    All cases where the SCC features cannot be accurately determined. For all exclusions, an explanation should be
    provided in the biopsy report (e.g., superficial tissue sampling or fragmentation of the skin specimen).
   ------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
      wasProcedurePerformedAfterOrEqualEncounter(visit,m,AAD28Elements.Undetermined_Scc_Features_Grp,patientHistoryList)
    )
  }

  /*------------------------------------------------------------------------------
    Number of skin specimens with a diagnosis of SCC for which the pathology report listed the differentiation
    (well, moderately, poorly or undifferentiated) of the tumor, perineural invasion involving nerves >= 0.1mm,
    and depth of invasion.
   ------------------------------------ ------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
         wasInterventionPerformedAfterOrEqualEncounter(visit,m,AAD28Elements.Tumor_Differentiation_Grp,patientHistoryList)
      && wasInterventionPerformedAfterOrEqualEncounter(visit,m,AAD28Elements.Perineural_Invasion_Grp,patientHistoryList)
      && wasDiagnosticStudyPerformedAfterOrEqualEncounter(visit,m,AAD28Elements.Nerves_Grp,patientHistoryList)
      && wasInterventionPerformedAfterOrEqualEncounter(visit,m,AAD28Elements.Depth_Of_Invasion_Grp,patientHistoryList)
    )
  }
}