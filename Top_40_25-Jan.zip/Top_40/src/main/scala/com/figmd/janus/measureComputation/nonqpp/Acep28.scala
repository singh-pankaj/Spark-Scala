package com.figmd.janus.measureComputation.nonqpp

import java.util.Date
import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{AdminElements, _}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACEP 28
* Measure Title              :- Sepsis Management: Septic Shock: Fluid Resuscitation
* Measure Description        :- Percentage of emergency department visits for patients aged 18 years and older
                                with septic shock who had an order for >= 1 L of crystalloids during
                                the emergency department visit
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/



object Acep28 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Acep28"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, rdd
                                                                   ,ACEP28Elements.Infection
                                                                   ,ACEP28Elements.Acute_Care_Or_Inpatient_Facility
                                                                   ,ACEP28Elements.Heart_Failure
                                                                   ,ACEP28Elements.Severe
                                                                   ,ACEP28Elements.Left_Ventricular_Assist_Device
                                                                   ,ACEP28Elements.Anuria
                                                                   ,ACEP28Elements.End_Stage_Renal_Disease).collect.toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(rdd,patientHistoryList)
    ippRDD.cache()

    // Filter Exclusion
    val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryList)
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA)
    metRDD.cache()

   // val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter Exceptions
    val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA, metRDD)
    notMetRDD.cache()

    saveToWebDM(rdd, ippRDD, ippRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)


  }

  /*--------------------------------------------------------------------------------------------------------------------
   All emergency department visits for patients aged 18 years and older with septic shock
   -------------------------------------------------------------------------------------------------------------------*/

  def getIpp(rdd: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
          isPatientAdult(visit,m)
      &&  isVisitTypeIn(visit,m
                               ,ACEP28Elements.Critical_Care_Evaluation_And_Management
                               ,ACEP28Elements.Emergency_Department_Visit)
      &&  (
                isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Septic_Shock, ACEP28Elements.Septic_Shock_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            ||  (
                      isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Sepsis, ACEP28Elements.Sepsis_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
                   && isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Acute_Hypotension, ACEP28Elements.Acute_Hypotension_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
                 )
            ||  (
                      wasDiagnosedBeforeEDOrCCEncounter(visit,m,ACEP28Elements.Infection,AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
                   && isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Acute_Hypotension, ACEP28Elements.Acute_Hypotension_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
                 )

          )
    )

  }

  /*--------------------------------------------------------------------------------------------------------------------
   Patients with any of the following:
     - Transferred into the emergency department from another acute care facility or other in-patient hospital setting
     - Left before treatment was complete
     - Died during the emergency department visit
     - Cardiac arrest within the emergency department visit
     - Patient or surrogate decision maker declined care
     - Advanced directives present in patient medical record for comfort care
     - Severe Heart Failure (LVEF < 20%)
     - Left Ventricular Assist Device (LVAD)
     - Acute pulmonary edema
     - Toxicological emergencies
     - Burn
     - Seizures
     - Anuria
     - End stage renal disease
     - Secondary diagnosis of
          - Gastrointestinal bleeding
          - Stroke
          - Acute myocardial infarction
          - Acute trauma
   -------------------------------------------------------------------------------------------------------------------*/



  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
           wasPatientTransferedFromAcuteCareWithinXHours(visit, m, ACEP28Elements.Acute_Care_Or_Inpatient_Facility, AdminElements.Emergency_Visit_Arrival_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management, 6, patientHistoryList)
        ||
           (
               isPatientLeftBeforeTreatmentCompletionOnEDOrCCEncounter(visit, m, ACEP28Elements.Left_Before_Treatment_Completion, ACEP28Elements.Left_Before_Treatment_Completion_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            || isPatientExpiredOnEDOrCCEncounter(visit, m, ACEP28Elements.Patient_Expired, ACEP28Elements.Patient_Expired_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
           )
        || (
               isInterventionOrderedDuringEDOrCCEncounter(visit, m, ACEP28Elements.Comfort_Measures, ACEP28Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            || isInterventionPerformedDuringEDOrCCEncounter(visit, m, ACEP28Elements.Comfort_Measures,ACEP28Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            || isCommunicationFromPatientToProviderDoneDuringEDOrCCEncounter(visit, m, ACEP28Elements.Declined_Sepsis_Care, ACEP28Elements.Declined_Sepsis_Care_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Cardiac_Arrest, ACEP28Elements.Cardiac_Arrest_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Second_And_Third_Degree_Burn, ACEP28Elements.Second_And_Third_Degree_Burn_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Seizure, ACEP28Elements.Seizure_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Gastrointestinal_Hemorrhage, ACEP28Elements.Gastrointestinal_Hemorrhage_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Hemorrhagic_Stroke, ACEP28Elements.Hemorrhagic_Stroke_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Ischemic_Stroke, ACEP28Elements.Ischemic_Stroke_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Myocardial_Infarction, ACEP28Elements.Myocardial_Infarction_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Toxicological_Emergency, ACEP28Elements.Toxicological_Emergency_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Trauma, ACEP28Elements.Trauma_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP28Elements.Acute_Pulmonary_Edema, ACEP28Elements.Acute_Pulmonary_Edema_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
           )
        || (
             (     wasDiagnosedBeforeEDOrCCEncounter(visit,m,ACEP28Elements.Heart_Failure,AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
                && wasDiagnosedBeforeEDOrCCEncounter(visit,m,ACEP28Elements.Severe,AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
             )
             || isDiagnosticStudyPerformedresultDuringEDorCCLessThanX(visit,m,ACEP28Elements.Ejection_Fraction,20,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
             || wasDeviceAppliedBeforeEDOrCCEncounter(visit,m,ACEP28Elements.Left_Ventricular_Assist_Device,AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
             || wasDiagnosedBeforeEDOrCCEncounter(visit,m,ACEP28Elements.Anuria,AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
             || wasDiagnosedBeforeEDOrCCEncounter(visit,m,ACEP28Elements.End_Stage_Renal_Disease,AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
           )
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Emergency department visits for patients who had an order for >= 1 L of crystalloids during the emergency department visit
   -------------------------------------------------------------------------------------------------------------------*/



  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      isMedicationOrderResultDuringEDorCCGreaterThanX(visit,m,ACEP28Elements.Crystalloids_For_Sepsis,1,AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP28Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }

}







