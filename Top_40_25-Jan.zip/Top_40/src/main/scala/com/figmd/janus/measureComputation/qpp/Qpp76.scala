package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP76Elements}
import com.figmd.janus.util.measure.{HistoryLookUpUtility, MeasureUtilityUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 76
* Measure Title              :- Prevention of Central Venous Catheter (CVC) - Related Bloodstream Infections
* Measure Description        :- Percentage of patients, regardless of age, who undergo central venous catheter
*                               (CVC) insertion for whom CVC was inserted with all elements of maximal sterile barrier technique,
*                                hand hygiene, skin preparation and, if ultrasound is used, sterile ultrasound techniques followed
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp76 extends MeasureUtilityUpdate with MeasureUpdate  {

  val MEASURE_NAME = "Qpp76"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


          // Filter Intermediate A
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA)
      metRDD.cache()

      // Filter Intermediate B
      val intermediateB = getSubtractRDD(intermediateA, metRDD)
      intermediateB.cache()

      // Filter Denominator Exception
      val exceptionRDD = getException(intermediateB)
      exceptionRDD.cache()

      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateB, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

    }
  }


  // IPP-Denominator criteria
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    rdd.filter(visit =>
      isProcedurePerformedDuringEncounter(visit,m,QPP76Elements.Central_Venous_Catheter_Insertion)
    )
  }




  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {
    var m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      (
        isProcedurePerformedDuringProcedure(visit, m, QPP76Elements.Maximal_Steril_Barrier_Technique_Cap,QPP76Elements.Maximal_Steril_Barrier_Technique_Cap_Date,QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
        ||
        /** $SterileTechniques **/
        (
          isInterventionPerformedDuringProcedure(visit, m, QPP76Elements.Maximal_Steril_Barrier_Technique_Cap,QPP76Elements.Maximal_Steril_Barrier_Technique_Cap_Date, QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
          &&
          isInterventionPerformedDuringProcedure(visit, m, QPP76Elements.Maximal_Sterile_Barrier_Technique_Mask,QPP76Elements.Maximal_Sterile_Barrier_Technique_Mask_Date, QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
          &&
          isInterventionPerformedDuringProcedure(visit, m, QPP76Elements.Maximal_Sterile_Barrier_Technique_Gloves,QPP76Elements.Maximal_Sterile_Barrier_Technique_Gloves_Date, QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
          &&
          isInterventionPerformedDuringProcedure(visit, m, QPP76Elements.Maximal_Sterile_Barrier_Technique_Gown,QPP76Elements.Maximal_Sterile_Barrier_Technique_Gown_Date, QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
          &&
          isInterventionPerformedDuringProcedure(visit, m, QPP76Elements.Maximal_Sterile_Barrier_Technique_Full_Body_Drape,QPP76Elements.Maximal_Sterile_Barrier_Technique_Full_Body_Drape_Date, QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
        )
        ||
        (
        isInterventionPerformedDuringProcedurePerformed(visit, m, QPP76Elements.Ultrasound_Guided_Cvc,QPP76Elements.Ultrasound_Guided_Cvc_Date,QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
        &&
        isInterventionOrderedDuringProcedurePerformed(visit, m, QPP76Elements.Sterile_Techniques_For_Usg_Guided_Cvc,QPP76Elements.Sterile_Techniques_For_Usg_Guided_Cvc_Date, QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
        &&
        /** $SterileTechniques **/
        (
        isInterventionPerformedDuringProcedure(visit, m, QPP76Elements.Maximal_Steril_Barrier_Technique_Cap,QPP76Elements.Maximal_Steril_Barrier_Technique_Cap_Date, QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
        &&
        isInterventionPerformedDuringProcedure(visit, m, QPP76Elements.Maximal_Sterile_Barrier_Technique_Mask,QPP76Elements.Maximal_Sterile_Barrier_Technique_Mask_Date, QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
        &&
        isInterventionPerformedDuringProcedure(visit, m, QPP76Elements.Maximal_Sterile_Barrier_Technique_Gloves,QPP76Elements.Maximal_Sterile_Barrier_Technique_Gloves_Date, QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
        &&
        isInterventionPerformedDuringProcedure(visit, m, QPP76Elements.Maximal_Sterile_Barrier_Technique_Gown,QPP76Elements.Maximal_Sterile_Barrier_Technique_Gown_Date, QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
        &&
        isInterventionPerformedDuringProcedure(visit, m, QPP76Elements.Maximal_Sterile_Barrier_Technique_Full_Body_Drape,QPP76Elements.Maximal_Sterile_Barrier_Technique_Full_Body_Drape_Date, QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
        )
      )
     )
        &&
        !isProcedurePerformedDuringProcedure(visit, m, QPP76Elements.Doc_Max_Sterile_Medical_Reason,QPP76Elements.Doc_Max_Sterile_Medical_Reason_Date,QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
      )
    }


  // Denominator Exception criteria
  def getException(intermediateB: RDD[CassandraRow]): RDD[CassandraRow] = {
    var m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateB.filter(visit =>
        isProcedurePerformedDuringProcedure(visit, m, QPP76Elements.Doc_Max_Sterile_Medical_Reason,QPP76Elements.Doc_Max_Sterile_Medical_Reason_Date,QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
        ||
        isInterventionPerformedDuringProcedure(visit, m, QPP76Elements.Doc_Max_Sterile_Medical_Reason_Keyword,QPP76Elements.Doc_Max_Sterile_Medical_Reason_Keyword_Date,QPP76Elements.Central_Venous_Catheter_Insertion,QPP76Elements.Central_Venous_Catheter_Insertion_Date)
     )


}
}