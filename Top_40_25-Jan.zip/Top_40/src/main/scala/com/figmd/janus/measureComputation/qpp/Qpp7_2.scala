package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ MeasureProperty, QPP7Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 7
* Measure Title              :- Coronary Artery Disease (CAD): Beta-Blocker Therapy-Prior Myocardial Infarction (MI) or
*                               Left Ventricular Systolic Dysfunction (LVEF <40%)
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of coronary artery
*                               disease seen within a 12 month period who also have a prior MI or a current or prior
*                               LVEF < 40% who were prescribed beta-blocker therapy.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 2
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp7_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp7_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patienthistoryRdd = getPatientHistory(sparkSession, initialRDD,
      QPP7Elements.Coronary_Artery_Disease_No_Mi,
      QPP7Elements.Ejection_Fraction,
      QPP7Elements.Left_Ventricular_Systolic_Dysfunction,
      QPP7Elements.Heart_Rate_2,
      QPP7Elements.Beta_Blocker_Therapy_For_Lvsd,
      QPP7Elements.Beta_Blocker_Therapy_Prescribed,
      QPP7Elements.Arrhythmia,
      QPP7Elements.Hypotension,
      QPP7Elements.Asthma,
      QPP7Elements.Allergy_To_Beta_Blocker_Therapy,
      QPP7Elements.Beta_Blocker_Therapy,
      QPP7Elements.Intolerance_To_Beta_Blocker_Therapy,
      QPP7Elements.Bradycardia,
      QPP7Elements.Beta_Blocker_Therapy_Ingredient,
      QPP7Elements.Atrioventricular_Block,
      QPP7Elements.Cardiac_Pacer_In_Situ,
      QPP7Elements.Cardiac_Pacer,
      QPP7Elements.Moderate_Or_Severe_Lvsd,
      QPP7Elements.Office_Visit,
      QPP7Elements.Outpatient_Consultation,
      QPP7Elements.Nursing_Facility_Visit,
      QPP7Elements.Care_Services_In_Long_Term_Residential_Facility,
      QPP7Elements.Home_Healthcare_Services,
      QPP7Elements.Patient_Provider_Interaction,
      QPP7Elements.Left_Ventricular_Ejection_Fraction)

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistoryRdd.collect().toList)

    val mostRecentpatienthistoryRdd = mostRecentPatientList(patienthistoryRdd, QPP7Elements.Heart_Rate_2)
    val mostRecentElementBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistoryRdd.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(sparkSession: SparkSession, initialRDD, patienthistoryRdd, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      // Filter Eligible
      val eligibleRDD = getEligibleRdd(ippRDD, patientHistoryList)
      eligibleRDD.cache()

      // Filter Not Eligible
      val noteligibleRDD = getSubtractRDD(ippRDD, eligibleRDD)
      noteligibleRDD.cache()

      // Filter Exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      val denominatorRDD  = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(eligibleRDD, patientHistoryList)
      metRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(eligibleRDD, metRDD)
      intermediateA.cache()

      // Filter Exceptions
      val exceptionRDD = getexceptionRDD(intermediateA, patientHistoryList, mostRecentElementBroadcastList)
      exceptionRDD.cache()

      // Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
      mostRecentElementBroadcastList.destroy()
    }
  }



  // IPP criteria
  def getIpp(sparkSession: SparkSession, rdd: RDD[CassandraRow], patienthistoryRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    val countElementList: List[(String,Int)] = countElement(patienthistoryRdd,m,
      QPP7Elements.Office_Visit,
      QPP7Elements.Outpatient_Consultation,
      QPP7Elements.Nursing_Facility_Visit,
      QPP7Elements.Care_Services_In_Long_Term_Residential_Facility,
      QPP7Elements.Home_Healthcare_Services,
      QPP7Elements.Patient_Provider_Interaction
    )
    rdd.filter(visit =>
      isPatientAdult(visit, m)
      &&
      getEncounterCountFromHistory(visit,m,2,true, countElementList)
      &&
      (
       wasDiagnosedBeforeOrEqualEncounter(visit, m,QPP7Elements.Coronary_Artery_Disease_No_Mi,patientHistoryList)
       ||
       isProcedurePerformedBeforeEnd(visit, m, QPP7Elements.Cardiac_Surgery,patientHistoryList)
      )
        &&
        !isTeleHealthEncounterPerformed(visit, m,
        QPP7Elements.Outpatient_Consultation_Telehealth_Modifier,
        QPP7Elements.Office_Visit_Telehealth_Modifier,
        QPP7Elements.Nursing_Facility_Visit_Telehealth_Modifier,
        QPP7Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier)
        &&
        isPOSEncounterNotPerformed(visit, m, QPP7Elements.Pos_02)
    )
  }


  // Denominator criteria
  def getEligibleRdd(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
    isDiagnosedWithEqualInMonths(visit,m,QPP7Elements.Moderate_Or_Severe_Lvsd,36,patientHistoryList)// element change to MyIn
    )
  }


  // Numerator criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      (
       isMedicationOrderedOnEncounter(visit, m, QPP7Elements.Beta_Blocker_Therapy_For_Lvsd)
       ||
       wasMedicationActiveInHistory(visit, m, QPP7Elements.Beta_Blocker_Therapy_For_Lvsd, patientHistoryList: Broadcast[List[CassandraRow]])
       ||
       isMedicationAdministeredOnEncounter(visit, m, QPP7Elements.Beta_Blocker_Therapy_Prescribed)
      )
      &&
      !isMedicationAdministeredNotDoneOnEncounter(visit,m,QPP7Elements.Beta_Blocker_Therapy_Prescribed_Reason_Not_Specified)
    )
  }


  // Exception criteria
  def getexceptionRDD(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]],mostRecentElementBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      (
        isMostRecentPhysicalExamPerformedBefore(visit, m, QPP7Elements.Heart_Rate_2, QPP7Elements.Heart_Rate,50,"lt" ,mostRecentElementBroadcastList)
        &&
        isPhysicalExamPerformedValueLessThanOnEncounter(visit, m, QPP7Elements.Heart_Rate, 50) //rebase or check
        &&
        isPhysicalExamPerformedDuringEncounter(visit, m, QPP7Elements.Heart_Rate)
        )
        ||
        (
          isMedicationOrderedOnEncounter(visit, m, QPP7Elements.Medical_Reason)
          ||
          isMedicationOrderedOnEncounter(visit, m, QPP7Elements.Patient_Reason)
          ||
          isMedicationOrderedOnEncounter(visit, m, QPP7Elements.System_Reason_2018)
          )
        ||
        (
          wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP7Elements.Arrhythmia, patientHistoryList)
          ||
          wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP7Elements.Hypotension, patientHistoryList)
          ||
          wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP7Elements.Asthma, patientHistoryList)
          ||
          wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP7Elements.Allergy_To_Beta_Blocker_Therapy, patientHistoryList)
  //      ||
    //    wasMedicationPerformedInHistory(visit, m, QPP7Elements.Beta_Blocker_Exception, patientHistoryList)
          ||
          wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP7Elements.Intolerance_To_Beta_Blocker_Therapy,  patientHistoryList)
          ||
          wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP7Elements.Bradycardia,  patientHistoryList)
          ||
          wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP7Elements.Beta_Blocker_Therapy_Ingredient,  patientHistoryList)
          )
        ||
        (
          wasDiagnosedBeforeOrEqualEncounter(visit, m, QPP7Elements.Atrioventricular_Block,  patientHistoryList)
          &&
          !isDeviceAppliedBeforeOrEqual(visit, m, QPP7Elements.Cardiac_Pacer_In_Situ, patientHistoryList)
          &&
          !isDeviceAppliedBeforeOrEqual(visit, m, QPP7Elements.Cardiac_Pacer, patientHistoryList)
          )
        ||
        (
          isMedicationAdministeredNotDoneOnEncounter(visit, m, QPP7Elements.Beta_Blocker_Therapy_Prescribed_Medical_Reason)
          ||
          isMedicationAdministeredNotDoneOnEncounter(visit, m, QPP7Elements.Beta_Blocker_Therapy_Prescribed_Patient_Reason)
          ||
          isMedicationAdministeredNotDoneOnEncounter(visit, m, QPP7Elements.Beta_Blocker_Therapy_Prescribed_System_Reason)
          )
    )
  }
}