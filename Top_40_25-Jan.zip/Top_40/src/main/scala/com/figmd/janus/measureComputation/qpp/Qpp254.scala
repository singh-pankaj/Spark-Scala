package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{QPP254Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 254
* Measure Title              :- Ultrasound Determination of Pregnancy Location for Pregnant Patients with Abdominal Pain
* Measure Description        :- Percentage of pregnant female patients aged 14 to 50 who present to the emergency department (ED) with a chief complaint of abdominal pain
*                               or vaginal bleeding who receive a trans-abdominal or trans-vaginal ultrasound to determine pregnancy location.
* Calculation Implementation :- Episode-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp254 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp254"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP254Elements.Emergency_Department_Visit,
      QPP254Elements.Critical_Care,
      QPP254Elements.Intrauterine_Pregnancy).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //All pregnant female patients aged 14 to 50 who present to the ED with a chief complaint of abdominal pain
  // or vaginal bleeding along with diagnosis of other current condition in the mother classifiable elsewhere but complicating Pregnancy, Childbirth, or the Puerperium.
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isFemale(visit, m)
        && isAgeBetween(visit, m, 14, 51)
        && isDiagnosisDuringEDOrCCEncounter(visit, m, QPP254Elements.Maternal_Conditions_Complicating_Pregnancy_Delivery, QPP254Elements.Maternal_Conditions_Complicating_Pregnancy_Delivery_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, QPP254Elements.Critical_Care_Date)
        && isVisitTypeIn(visit, m,
        QPP254Elements.Emergency_Department_Visit,
        QPP254Elements.Critical_Care,
        QPP254Elements.Pos_23,
        QPP254Elements.Emergency_Department_Visit

      )

        && (
        isDiagnosisDuringEDOrCCEncounter(visit, m, QPP254Elements.Vaginal_Bleeding, QPP254Elements.Vaginal_Bleeding_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, QPP254Elements.Critical_Care_Date)

          || isDiagnosisDuringEDOrCCEncounter(visit, m, QPP254Elements.Abdominal_Pain, QPP254Elements.Abdominal_Pain_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, QPP254Elements.Critical_Care_Date)
        )
    )
  }

  //Patients who receive a trans-abdominal or trans-vaginal ultrasound with documentation of pregnancy location in medical record.
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (isProcedureOrderDuringEDOrCCEncounter(visit, m, QPP254Elements.Vaginal_Bleeding, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date)
        || isProcedureOrderDuringEDOrCCEncounter(visit, m, QPP254Elements.Trans_Abdominal_Or_Trans_Vaginal_Ultrasound_Performed, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date)
        || isProcedureOrderDuringEDOrCCEncounter(visit, m, QPP254Elements.Trans_Vaginal_Ultrasound_Performed, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date)
        )

        && !isActionNotPerformedWithReasonDuringEncounter(visit, m, QPP254Elements.Trans_Abd_Vag_Ultra_Reason_Not_Specified)
    )
  }

  //Trans-abdominal or trans-vaginal ultrasound not performed for reasons documented by clinician
  // (e.g., patient has visited the ED multiple times within 72 hours, patient has a documented Intrauterine Pregnancy [IUP]).
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (
        isDiagnosisOnEncounter(visit, m, QPP254Elements.Intrauterine_Pregnancy)
          || isProcedurePerformedDuringEncounter(visit, m, QPP254Elements.Trans_Abd_Vag_Ultra_Medical_Reason)
        )
        ||
        (
          wasElementXhoursBeforeOfEDOrCCEncounter(visit, m, QPP254Elements.Critical_Care, 72, AdminElements.Emergency_Visit_Arrival_Date, QPP254Elements.Critical_Care_Date, patientHistoryBroadcastList)
            || wasElementXhoursBeforeOfEDOrCCEncounter(visit, m, QPP254Elements.Emergency_Department_Visit, 72, AdminElements.Emergency_Visit_Arrival_Date, QPP254Elements.Critical_Care_Date, patientHistoryBroadcastList)
          )
    )
  }


}

