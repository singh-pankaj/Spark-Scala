package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP437Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp 437
* Measure Title              :- Rate of Surgical Conversion from Lower Extremity Endovascular Revascularization Procedure
* Measure Description        :- Inpatients assigned to endovascular treatment for obstructive arterial disease, the percent
*                               of patients who undergo unplanned major amputation or surgical bypass within 48 hours of the index procedure.
* Calculation Implementation :- Procedure Specific
* Improvement Notation       :- Lower score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp437 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp437"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP437Elements.Endovascular_Lower_Extremity_Revascularization,
      QPP437Elements.Hybrid_Or_Staged_Procedure,
      QPP437Elements.Planned_Hybrid_Procedure,
      QPP437Elements.Planned_Staged_Procedure,
      QPP437Elements.Major_Amputation,
      QPP437Elements.Open_Surgical_Bypass,
      QPP437Elements.Amputation_Or_Surgical_Bypass_Not_Met
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter denominator Exclusions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()
      val intermediateARDD = getSubtractRDD(ippRDD, exclusionRDD)

      //Met initialRDD
      val metRDD = getMet(intermediateARDD, patientHistoryBroadcastList)
      metRDD.cache()
      //exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()
      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateARDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isProcedurePerformed(visit, m, QPP437Elements.Endovascular_Lower_Extremity_Revascularization, patientHistoryBroadcastList)
        && wasProcedurePerformedBeforeEndInXDays(visit, m, QPP437Elements.Endovascular_Lower_Extremity_Revascularization, 2, patientHistoryBroadcastList)
    )
  }


  // Denominator-Exclusion criteria
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      isProcedurePerformed(visit, m, QPP437Elements.Hybrid_Or_Staged_Procedure, patientHistoryBroadcastList)
        || (wasProcedurePerformedDuringProcedureInHistory(visit, m, QPP437Elements.Endovascular_Lower_Extremity_Revascularization, patientHistoryBroadcastList, QPP437Elements.Planned_Hybrid_Procedure)
        || wasProcedurePerformedDuringProcedureInHistory(visit, m, QPP437Elements.Endovascular_Lower_Extremity_Revascularization, patientHistoryBroadcastList, QPP437Elements.Planned_Staged_Procedure))
    )
  }


  // Numerator criteria
  def getMet(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      (isProcedurePerformed(visit, m, QPP437Elements.Major_Amputation_Or_Open_Surgical_Bypass, patientHistoryBroadcastList)
        || (wasProcedurePerformedAfterProcedureWithinXHours(visit, m, QPP437Elements.Endovascular_Lower_Extremity_Revascularization, 48, patientHistoryBroadcastList, QPP437Elements.Major_Amputation)
        || wasProcedurePerformedAfterProcedureWithinXHours(visit, m, QPP437Elements.Endovascular_Lower_Extremity_Revascularization, 48, patientHistoryBroadcastList, QPP437Elements.Open_Surgical_Bypass))
        )
        && !isProcedurePerformed(visit, m, QPP437Elements.Amputation_Or_Surgical_Bypass_Not_Met, patientHistoryBroadcastList)
    )
  }
}