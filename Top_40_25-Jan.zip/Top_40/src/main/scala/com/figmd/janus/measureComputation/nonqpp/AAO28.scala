package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AAO28Elements, MeasureProperty,CalenderUnit}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO28
* Measure Title               :- Tympanostomy Tubes: Resolution of Otitis Media with Effusion in Adults
* Measure Description         :- Percentage of patients >12 years of age with a diagnosis of otitis media with effusion who are seen 2 to 8 weeks after tympanostomy tube surgery and otitis media with effusion is resolved.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- KIRTI_RAUT_FIGMD_COM
* Initial GIT Version/Tag(CRA):-Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :-Measure_Development_2019-Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object AAO28 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO28"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      AAO28Elements.Tympanostomy_Tube_Insertion,
      AAO28Elements.Otitis_Media_With_Effusion,
      AAO28Elements.Office_Visit,
      AAO28Elements.Resolution_Of_Otitis_Media_With_Effusion,
      AAO28Elements.Patient_Refusal,
      AAO28Elements.Outpatient_Consultation,
      AAO28Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,
      AAO28Elements.Preventive_Care__Established_Office_Visit__0_To_17
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }



  /*-----------------------------------------------------------------------------------------------------------------------
Patients >12 years of age with a diagnosis of otitis media with effusion who undergo tympanostomy tube insertion.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit,m,true,12)
        &&    isProcedurePerformed(visit,m,AAO28Elements.Tympanostomy_Tube_Insertion,patientHistoryBroadcastList)
        &&    wasDiagnosisBeforeOrEqualProcedure(visit,m,AAO28Elements.Otitis_Media_With_Effusion,AAO28Elements.Tympanostomy_Tube_Insertion,patientHistoryBroadcastList)
        &&    isVisitTypeIn(visit,m,AAO28Elements.Office_Visit,AAO28Elements.Outpatient_Consultation,AAO28Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,AAO28Elements.Preventive_Care__Established_Office_Visit__0_To_17)
       // &&

        /*  (
                 isEncounterPerformedAfterEndOfProcedureInBetweenWeek(visit,m,AAO28Elements.Office_Visit,AAO28Elements.Tympanostomy_Tube_Insertion,CalenderUnit.WEEK,2,8,patientHistoryBroadcastList)
              || isEncounterPerformedAfterEndOfProcedureInBetweenWeek(visit,m,AAO28Elements.Outpatient_Consultation,AAO28Elements.Tympanostomy_Tube_Insertion,CalenderUnit.WEEK,2,8,patientHistoryBroadcastList)
              || isEncounterPerformedAfterEndOfProcedureInBetweenWeek(visit,m,AAO28Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,AAO28Elements.Tympanostomy_Tube_Insertion,CalenderUnit.WEEK,2,8,patientHistoryBroadcastList)
              || isEncounterPerformedAfterEndOfProcedureInBetweenWeek(visit,m,AAO28Elements.Preventive_Care__Established_Office_Visit__0_To_17,AAO28Elements.Tympanostomy_Tube_Insertion,CalenderUnit.WEEK,2,8,patientHistoryBroadcastList)
            )
   */ )

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients >12 years of age seen 2 to 8 weeks after surgery with resolution of otitis media with effusion.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)


    denominatorRDD.filter(visit =>
      true

      //isDiagnosticStudyPerformedAfterEndOfProcedureInBetweenWeek(visit,m,AAO28Elements.Preventive_Care__Established_Office_Visit__0_To_17,AAO28Elements.Tympanostomy_Tube_Insertion,CalenderUnit.WEEK,2,8,patientHistoryBroadcastList)



    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
Patient refusal for follow-up examination
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
      isCommunicationFromPatientToProvider(visit,m,AAO28Elements.Patient_Refusal,patientHistoryBroadcastList)

    )
  }
}