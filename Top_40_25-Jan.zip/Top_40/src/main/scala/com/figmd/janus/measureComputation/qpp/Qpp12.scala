package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{QPP12Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 12
* Measure Title              :- Primary Open-Angle Glaucoma (POAG): Optic Nerve Evaluation
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of primary open-angle glaucoma (POAG)
                                who have an optic nerve head evaluation during one or more office visits within 12 months.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp12 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp12"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patient_history_list = getPatientHistory(sparkSession, initialRDD
      , QPP12Elements.Primary_Open_Angle_Glaucoma
      , QPP12Elements.Optic_Nerve_Head_Evaluation
      , QPP12Elements.Cup_To_Disc_Ratio
      , QPP12Elements.Optic_Disc_Exam_For_Structural_Abnormalities
      , QPP12Elements.Optc_Nrvhdevalutn_Reason_Not_Specified
      , QPP12Elements.Medical_Reason_Not_Perform
      , QPP12Elements.Optc_Nrvhdevalutn_Medical_Reason
      , QPP12Elements.Medical_Reason).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //eligible RDD
      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryList)
      metRDD.cache()

      // Filter Intermediate RDD
      val intermediateException = getSubtractRDD(ippRDD, metRDD)
      intermediateException.cache()


      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateException, patientHistoryList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------
   All patients aged 18 years and older with a diagnosis of primary open-angle glaucoma
   -----------------------------------------------------------------------------------------*/

  def getIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
            isPatientAdult(visit, m)
        &&  isVisitTypeIn(visit,m
            ,QPP12Elements.Ophthalmological_Services
            ,QPP12Elements.Care_Services_In_Long_Term_Residential_Facility
            ,QPP12Elements.Nursing_Facility_Visit
            ,QPP12Elements.Office_Visit
            ,QPP12Elements.Outpatient_Consultation
            ,QPP12Elements.Face_To_Face_Interaction)
        &&  wasDiagnosedBeforeOrEqualEncounter(visit,m,QPP12Elements.Primary_Open_Angle_Glaucoma,patientHistoryList)
        && !isTeleHealthModifier(visit,m
            ,QPP12Elements.Office_Visit_Telehealth_Modifier
            ,QPP12Elements.Nursing_Facility_Visit_Telehealth_Modifier
            ,QPP12Elements.Ophthalmological_Services_Telehealth_Modifier
            ,QPP12Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier_Date
            ,QPP12Elements.Outpatient_Consultation_Telehealth_Modifier)
        &&  isPOSEncounterNotPerformed(visit, m, QPP12Elements.Pos_02)
    )
  }

  /*------------------------------------------------------------------------------------------------
   Patients who have an optic nerve head evaluation during one or more office visits within 12 months
   ------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
        (
               isDiagnosticStudyPerformed(visit,m,QPP12Elements.Optic_Nerve_Head_Evaluation,patientHistoryList)
          ||   (
                      isDiagnosticStudyPerformed(visit,m,QPP12Elements.Cup_To_Disc_Ratio,patientHistoryList)
                 &&   isDiagnosticStudyPerformed(visit,m,QPP12Elements.Optic_Disc_Exam_For_Structural_Abnormalities,patientHistoryList)
               )
        )
        &&  !isDiagnosticStudyPerformed(visit,m,QPP12Elements.Optc_Nrvhdevalutn_Reason_Not_Specified,patientHistoryList)
    )

  }

  /*------------------------------------------------------------------------------------------------
    Documentation of medical reason(s) for not performing an optic nerve head evaluation
   ------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermedaiateRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow]  = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermedaiateRdd.filter(visit =>

             isDiagnosticStudyPerformed(visit,m,QPP12Elements.Medical_Reason_Not_Perform,patientHistoryList)
        ||   isDiagnosticStudyPerformed(visit,m,QPP12Elements.Optc_Nrvhdevalutn_Medical_Reason,patientHistoryList)
        ||   isActionNotPerformedWithReason(visit,m,QPP12Elements.Medical_Reason,patientHistoryList)

    )

  }

}
