package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, MeasureProperty, QPP271Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp271
* Measure Title              :- Inflammatory Bowel Disease (IBD): Preventive Care: Corticosteroid Related Iatrogenic Injury – Bone Loss Assessment
Percentage of patients with an inflammatory bowel disease encounter who were prescribed prednisone equivalents greater than or equal to 10 mg/day for 60 or greater consecutive days or a single prescription equating to 600 mg prednisone or greater for all fills and were documented for risk of bone loss once during the reporting year or the previous calendar year. Individuals who received an assessment for bone loss during the prior or current year are considered adequately screened
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- 1
* Measure Developer          :- Vrushali Gholap
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp271 extends MeasureUtilityUpdate with MeasureUpdate{

  val MEASURE_NAME = "Qpp271"
  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      ,QPP271Elements.Prednisone
      ,QPP271Elements.Prednisone_Dose_Mg_Day
      ,QPP271Elements.Prednisolone
      ,QPP271Elements.Prednisolone_Dose_Mg_Day
      ,QPP271Elements.Dexamethasone
      ,QPP271Elements.Dexamethasone_Dose_Mg_Day
      ,QPP271Elements.Cortisone
      ,QPP271Elements.Cortisone_Dose_Mg_Day
      ,QPP271Elements.Hydrocortisone
      ,QPP271Elements.Hydrocortisone_Dose_Mg_Day
      ,QPP271Elements.Triamcinolone
      ,QPP271Elements.Triamcinolone_Dose_Mg_Day
      ,QPP271Elements.Methylprednisolone
      ,QPP271Elements.Methylprednisolone_Dose_Mg_Day
      ,QPP271Elements.Betamethasone
      ,QPP271Elements.Betamethasone_Dose_Mg_Day
      ,QPP271Elements.Dxa_Ordered_For_Osteoporosis_Prescribed
      ,QPP271Elements.Review_Of_System_And_Medication_History
      ,QPP271Elements.Pharmacologic_Therapy
      ,QPP271Elements.Dxa_Ordered_For_Osteoporosis_Prescribed_Not_Met
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIppRDD(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible initial population RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //exclusion
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMetRDD(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      //exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(denominatorRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  /*-------------------------------------------------------------------------------------------------------------------------
  All patients, regardless of age, with a diagnosis of inflammatory bowel disease who have received dose of corticosteroids
  greater than or equal to 10 mg/day of prednisone equivalents for 60 or greater consecutive days or a single prescription
  equating to 600 mg prednisone or greater for all fills.
----------------------------------------------------------------------------------------------------------------------------*/
  def getIppRDD(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    //need to add DB guideline
    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)
    initialRDD.filter(visit =>
      wasDiagnosedInHistory(visit,m,QPP271Elements.Inflammatory_Bowel_Disease,patientHistoryBroadcastList)
        && isVisitTypeIn(visit,m
        ,QPP271Elements.Office_Visit
        ,QPP271Elements.Home_Healthcare_Services
        ,QPP271Elements.Smoking_And_Tobacco_Use_Cessation_Counseling_Visit
        ,QPP271Elements.Office_Consultation)
        &&
        (    (   wasMedicationActiveBeforeEndWithinXMonths(visit,m,QPP271Elements.Prednisone,24,patientHistoryBroadcastList)
          && wasMedicationActiveOrderBeforeEndWithinXMonthswithDose(visit,m,QPP271Elements.Prednisone_Dose_Mg_Day,10,CalenderUnit.MONTH,24,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
          )
          ||(    wasMedicationActiveBeforeEndWithinXMonths(visit,m,QPP271Elements.Prednisolone,24,patientHistoryBroadcastList)
          && wasMedicationActiveOrderBeforeEndWithinXMonthswithDose(visit,m,QPP271Elements.Prednisolone_Dose_Mg_Day,10,CalenderUnit.MONTH,24,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
          )
          ||(    wasMedicationActiveBeforeEndWithinXMonths(visit,m,QPP271Elements.Dexamethasone,24,patientHistoryBroadcastList)
          && wasMedicationActiveOrderBeforeEndWithinXMonthswithDose(visit,m,QPP271Elements.Dexamethasone_Dose_Mg_Day,10,CalenderUnit.MONTH,24,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
          )
          ||(    wasMedicationActiveBeforeEndWithinXMonths(visit,m,QPP271Elements.Cortisone,24,patientHistoryBroadcastList)
          && wasMedicationActiveOrderBeforeEndWithinXMonthswithDose(visit,m,QPP271Elements.Cortisone_Dose_Mg_Day,10,CalenderUnit.MONTH,24,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
          )
          ||(    wasMedicationActiveBeforeEndWithinXMonths(visit,m,QPP271Elements.Hydrocortisone,24,patientHistoryBroadcastList)
          && wasMedicationActiveOrderBeforeEndWithinXMonthswithDose(visit,m,QPP271Elements.Hydrocortisone_Dose_Mg_Day,10,CalenderUnit.MONTH,24,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
          )
          ||(    wasMedicationActiveBeforeEndWithinXMonths(visit,m,QPP271Elements.Triamcinolone,24,patientHistoryBroadcastList)
          && wasMedicationActiveOrderBeforeEndWithinXMonthswithDose(visit,m,QPP271Elements.Triamcinolone_Dose_Mg_Day,10,CalenderUnit.MONTH,24,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
          )
          ||(    wasMedicationActiveBeforeEndWithinXMonths(visit,m,QPP271Elements.Methylprednisolone,24,patientHistoryBroadcastList)
          && wasMedicationActiveOrderBeforeEndWithinXMonthswithDose(visit,m,QPP271Elements.Methylprednisolone_Dose_Mg_Day,10,CalenderUnit.MONTH,24,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
          )
          ||(    wasMedicationActiveBeforeEndWithinXMonths(visit,m,QPP271Elements.Betamethasone,24,patientHistoryBroadcastList)
          && wasMedicationActiveOrderBeforeEndWithinXMonthswithDose(visit,m,QPP271Elements.Betamethasone_Dose_Mg_Day,10,CalenderUnit.MONTH,24,CompareOperator.LESS_EQUAL,patientHistoryBroadcastList)
          )
          )
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
   Patients who were documented for risk of bone loss during the reporting year or the previous calendar year.
   -------------------------------------------------------------------------------------------------------------------*/


  def getMetRDD(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (    wasProcedurePerformedBeforeEndInXMonths(visit,m,QPP271Elements.Dxa_Ordered_For_Osteoporosis_Prescribed,24,patientHistoryBroadcastList)
        || wasInterventionPerformedBeforeEndInXMonths(visit,m,QPP271Elements.Review_Of_System_And_Medication_History,24,patientHistoryBroadcastList)
        || wasMedicationOrderedBeforeEndInXMonths(visit,m,QPP271Elements.Pharmacologic_Therapy,24,patientHistoryBroadcastList)
        )
        && wasProcedurePerformedBeforeEndInXMonths(visit,m,QPP271Elements.Dxa_Ordered_For_Osteoporosis_Prescribed_Not_Met,24,patientHistoryBroadcastList)
    )
  }


}