package com.figmd.janus.measureComputation.qpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.ecqm.Ecqm160V7_6.{MEASURE_NAME, checkEmptyIPPRDD}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 438
* Measure Title              :- Statin Therapy for the Prevention and Treatment of Cardiovascular Disease
* Measure Description        :- "Percentage of the following patients - all considered at high risk of cardiovascular events - who were prescribed or were on statin therapy during the performance period:
                                • Adults aged ≥ 21 years who were previously diagnosed with or currently have an active diagnosis of
                                  clinical atherosclerotic cardiovascular disease (ASCVD); OR
                                • Adults aged ≥ 21 years who have ever had a fasting or direct low-density lipoprotein cholesterol (LDL-C)
                                  level ≥ 190 mg/dL or were previously diagnosed with or currently have an active diagnosis of familial or
                                  pure hypercholesterolemia; OR
                                • Adults aged 40-75 years with a diagnosis of diabetes with a fasting or direct LDL-C level of 70-189
                                  mg/dL"
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 3
* Measure Stratum No.        :- 2
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp438_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp438_2"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {
      //Backtracking List
      val patientHistoryList = getPatientHistory(sparkSession, ippRDD
        , QPP438Elements.Myocardial_Infarction
        , QPP438Elements.Cerebrovascular_Disease__Stroke__Tia
        , QPP438Elements.Atherosclerosis_And_Peripheral_Arterial_Disease
        , QPP438Elements.Ischemic_Heart_Disease_Or_Coronary_Occlusion__Rupture__Or_Thrombosis
        , QPP438Elements.Stable_And_Unstable_Angina
        , QPP438Elements.Atherosclerotic_Cardiovascular_Disease
        , QPP438Elements.Pci
        , QPP438Elements.Cabg_Surgeries
        , QPP438Elements.Carotid_Intervention
        , QPP438Elements.Breastfeeding_Patients
        , QPP438Elements.Rhabdomyolysis_Statin
        , QPP438Elements.Breastfeeding
        , QPP438Elements.Rhabdomyolysis
        , QPP438Elements.Statin_Therapy
        , QPP438Elements.Low_Intensity_Statin_Therapy
        , QPP438Elements.Moderate_Intensity_Statin_Therapy
        , QPP438Elements.High_Intensity_Statin_Therapy
        , QPP438Elements.Statin_Not_Met
        , QPP438Elements.Statin__Medical_Reason
        , QPP438Elements.Palliative_Care
        , QPP438Elements.End_Stage_Renal_Disease
        , QPP438Elements.Hepatitis_A
        , QPP438Elements.Hepatitis_B
        , QPP438Elements.Liver_Disease
        , QPP438Elements.Statin_Allergen
        , QPP438Elements.Ldl_Test
        , QPP438Elements.Hypercholesterolemia
        , QPP438Elements.Familial_Or_Pure_Hypercholesterolemia
        , QPP438Elements.Low_Density_Lipoprotein__Ldl_C_____190_Mg_Dl).collect.toList
      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

      // Eligible IPP
      val denominatorRDD = getEligibleIpp(ippRDD, patientHistoryBroadcastList)
      denominatorRDD.cache()

      /*// Filter notEligible
      val notEligibleRDD = getSubtractRDD(ippRDD, denominatorRDD)
      notEligibleRDD.cache()
*/
      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate for Met
      val intermediateMet = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateException = getSubtractRDD(intermediateMet, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }

  }

  /*-----------------------------------------------------------------------------------------
   All patients aged 21 years and older at the beginning of the measurement period with a
   patient encounter during the measurement period.
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
            isAgeAboveBeforeStart(visit, m ,true,21,CalenderUnit.YEAR)
        &&  isVisitTypeIn(visit,m
            ,QPP438Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
            ,QPP438Elements.Preventive_Care_Services_Individual_Counseling
            ,QPP438Elements.Preventive_Care_Services___Other
            ,QPP438Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
            ,QPP438Elements.Outpatient_Encounters_For_Preventive_Care
            ,QPP438Elements.Outpatient_Consultation
            ,QPP438Elements.Office_Visit
            ,QPP438Elements.Annual_Wellness_Visit)
    )
  }

  /*---------------------------------------------------------------------------------------------
   All patients who meet one or more of the following criteria (considered at "high risk"
   for cardiovascular events, under ACC/AHA guidelines):
   2)  Patients aged >= 21 years at the beginning of the measurement period who have ever had
       a fasting or direct laboratory result of LDL-C >=190 mg/dL or were previously diagnosed
       with or currently have an active diagnosis of familial or pure hypercholesterolemia
  ----------------------------------------------------------------------------------------------*/

  def getEligibleIpp(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME,ELIGIBLE,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
        (
         !(
                 wasProcedurePerformedInHistory(visit,m,QPP438Elements.Pci,patientHistoryBroadcastList)
            ||   wasProcedurePerformedInHistory(visit,m,QPP438Elements.Cabg_Surgeries,patientHistoryBroadcastList)
            ||   wasProcedurePerformedInHistory(visit,m,QPP438Elements.Carotid_Intervention,patientHistoryBroadcastList)
            ||   wasDiagnosedInHistory(visit,m,QPP438Elements.Myocardial_Infarction,patientHistoryBroadcastList)
            ||   wasDiagnosedInHistory(visit,m,QPP438Elements.Cerebrovascular_Disease__Stroke__Tia,patientHistoryBroadcastList)
            ||   wasDiagnosedInHistory(visit,m,QPP438Elements.Atherosclerosis_And_Peripheral_Arterial_Disease,patientHistoryBroadcastList)
            ||   wasDiagnosedInHistory(visit,m,QPP438Elements.Ischemic_Heart_Disease_Or_Coronary_Occlusion__Rupture__Or_Thrombosis,patientHistoryBroadcastList)
            ||   wasDiagnosedInHistory(visit,m,QPP438Elements.Stable_And_Unstable_Angina,patientHistoryBroadcastList)
          )
          &&   !isAssessmentPerformed(visit,m,QPP438Elements.Atherosclerotic_Cardiovascular_Disease,patientHistoryBroadcastList)
        )
        &&
        (
               isLaboratoryTestPerformedValueBeforeEnd(visit,m,QPP438Elements.Ldl_Test,190,CompareOperator.GREATER_EQUAL, patientHistoryBroadcastList)
          ||   wasDiagnosedInHistory(visit,m,QPP438Elements.Hypercholesterolemia,patientHistoryBroadcastList)
          ||   isAssessmentPerformed(visit,m,QPP438Elements.Familial_Or_Pure_Hypercholesterolemia,patientHistoryBroadcastList)
          ||   isAssessmentPerformed(visit,m,QPP438Elements.Low_Density_Lipoprotein__Ldl_C_____190_Mg_Dl,patientHistoryBroadcastList)
        )
        &&  !isTeleHealthEncounterPerformed(visit,m
             ,QPP438Elements.Preventive_Care_Services_Initial_Office_Visit_18_And_Up_Telehealth_Modifier
             ,QPP438Elements.Preventive_Care_Services_Individual_Counseling_Telehealth_Modifier
             ,QPP438Elements.Preventive_Care_Services___Established_Office_Visit_18_And_Up_Telehealth_Modifier
             ,QPP438Elements.Preventive_Care_Services___Other_Telehealth_Modifier
             ,QPP438Elements.Outpatient_Consultation_Telehealth_Modifier
             ,QPP438Elements.Office_Visit_Telehealth_Modifier
             ,QPP438Elements.Annual_Wellness_Visit_Telehealth_Modifier)
        &&   isPOSEncounterNotPerformed(visit,m,QPP438Elements.Pos_02)
    )
  }

  /*---------------------------------------------------------------------------------------------
    Patients who have a diagnosis of pregnancy
    Patients who are breastfeeding
    Patients who have a diagnosis of rhabdomyolysis
   ----------------------------------------------------------------------------------------------*/

  def getExclusionRdd(eligibleRdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCLUSION,globalStartDate,globalEndDate)

    eligibleRdd.filter(visit =>
        (
               isAssessmentPerformedOnEncounter(visit,m,QPP438Elements.Pregnancy_Ldl)
          ||   isDiagnosedDuringEncounter(visit,m,QPP438Elements.Pregnancy_Dx)
        )
        ||
        (
                isAssessmentPerformed(visit,m,QPP438Elements.Breastfeeding_Patients,patientHistoryBroadcastList)
            ||  isAssessmentPerformed(visit,m,QPP438Elements.Rhabdomyolysis_Statin,patientHistoryBroadcastList)
        )
        ||
        (
                wasDiagnosedInHistory(visit,m,QPP438Elements.Breastfeeding,patientHistoryBroadcastList)
            ||  wasDiagnosedInHistory(visit,m,QPP438Elements.Rhabdomyolysis,patientHistoryBroadcastList)
        )
    )
  }

  /*----------------------------------------------------------------------------------------
    Patients who are actively using or who receive an order (prescription) for statin therapy at any point during the measurement period.
   -----------------------------------------------------------------------------------------*/

  def getMet(intermediateMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateMet.filter(visit =>
      (

                isAssessmentPerformed(visit,m,QPP438Elements.Statin_Therapy,patientHistoryBroadcastList)

//          Commented below code, as "Overlaps measurement period" is inclusive of "During measurement period".
//          ||
//          (
//                  isMedicationOrdered(visit,m,QPP438Elements.Low_Intensity_Statin_Therapy,patientHistoryList)
//              ||  isMedicationOrdered(visit,m,QPP438Elements.Moderate_Intensity_Statin_Therapy,patientHistoryList)
//              ||  isMedicationOrdered(visit,m,QPP438Elements.High_Intensity_Statin_Therapy,patientHistoryList)
//          )
          ||
          (
                  wasMedicationActiveInHistory(visit,m,QPP438Elements.Low_Intensity_Statin_Therapy,patientHistoryBroadcastList)
              ||  wasMedicationActiveInHistory(visit,m,QPP438Elements.Moderate_Intensity_Statin_Therapy,patientHistoryBroadcastList)
              ||  wasMedicationActiveInHistory(visit,m,QPP438Elements.High_Intensity_Statin_Therapy,patientHistoryBroadcastList)
          )
        )
        &&  !isAssessmentPerformed(visit,m,QPP438Elements.Statin_Not_Met,patientHistoryBroadcastList)
    )
  }

  /*---------------------------------------------------------------------------------------------------------------------------------------------
  Patients with adverse effect, allergy, or intolerance to statin medication
  Patients who are receiving palliative care
  Patients with active liver disease or hepatic disease or insufficiency
  Patients with end-stage renal disease (ESRD)
  Patients with diabetes who have the most recent fasting or direct LDL-C laboratory test result < 70 mg/dL and are not taking statin therapy
   ---------------------------------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateException:RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCEPTION,globalStartDate,globalEndDate)

    intermediateException.filter(visit =>
            isAssessmentPerformed(visit,m,QPP438Elements.Statin__Medical_Reason,patientHistoryBroadcastList)
        ||  wasInterventionPerformedInHistory(visit,m,QPP438Elements.Palliative_Care,patientHistoryBroadcastList)
        ||  wasDiagnosedInHistory(visit,m,QPP438Elements.End_Stage_Renal_Disease,patientHistoryBroadcastList)
        ||  wasDiagnosedInHistory(visit,m,QPP438Elements.Hepatitis_A,patientHistoryBroadcastList)
        ||  wasDiagnosedInHistory(visit,m,QPP438Elements.Hepatitis_B,patientHistoryBroadcastList)
        ||  wasDiagnosedInHistory(visit,m,QPP438Elements.Liver_Disease,patientHistoryBroadcastList)
        ||  wasMedicationAdverseEffectInHistory(visit,m,QPP438Elements.Statin_Allergen,patientHistoryBroadcastList)
        ||  wasMedicationAllergyInHistory(visit,m,QPP438Elements.Statin_Allergen,patientHistoryBroadcastList)
        ||  wasMedicationIntoleranceInHistory (visit,m,QPP438Elements.Statin_Allergen,patientHistoryBroadcastList)
      /*  Only one element is crated for different medical categories, if source of data is different then different elements are required.

            •"Medication, Adverse Effects: Statin Allergen" using "Statin Allergen RXNORM Value Set (2.16.840.1.113883.3.117.1.7.1.423)"
            •"Medication, Allergy: Statin Allergen" using "Statin Allergen RXNORM Value Set (2.16.840.1.113883.3.117.1.7.1.423)"
            •"Medication, Intolerance: Statin Allergen" using "Statin Allergen RXNORM Value Set (2.16.840.1.113883.3.117.1.7.1.423)"

          This need discussion with CRA/ETL teams.
      */
    )
  }
}
