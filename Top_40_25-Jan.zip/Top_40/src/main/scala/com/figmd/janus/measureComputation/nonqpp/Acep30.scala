package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ACEP30Elements, AdminElements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Acep30
* Measure Title              :- Sepsis Management: Septic Shock: Lactate Clearance Rate >= 10%
* Measure Description        :- Percentage of emergency department visits for patients aged 18 years and older with septic shock who
*                                had an elevated serum lactate result (>2mmol/L) and a subsequent serum lactate level measurement performed
*                                following the elevated serum lactate result with a lactate clearance rate of >= 10% during the emergency department visit
* Calculation Implementation :- Visit Specific
* Improvement Notation       :- Higher score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Acep30 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Acep30"

  def refresh(sparkSession: SparkSession, rdd: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, rdd,
      AdminElements.Emergency_Visit_Arrival_Date,
      AdminElements.Emergency_Visit_Departure_Date,
      ACEP30Elements.Critical_Care_Evaluation_And_Management_Date,
      ACEP30Elements.Acute_Care_Or_Inpatient_Facility,
      ACEP30Elements.Serum_Lactate
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    // Filter IPP
    val ippRDD = getIpp(rdd, patientHistoryList)
    ippRDD.cache()

    val eligibleRDD = getEligible(ippRDD)

    val notEligibleRDD = getSubtractRDD(ippRDD, eligibleRDD)

    //Filter Denominator Exclusion
    val exclusionRDD = getExclusion(eligibleRDD, patientHistoryList)
    exclusionRDD.cache()

    // Filter Intermediate
    val intermediateA = getSubtractRDD(eligibleRDD, exclusionRDD)
    intermediateA.cache()

    // Filter Met
    val metRDD = getMet(intermediateA, patientHistoryList)
    metRDD.cache()


    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA, metRDD)
    notMetRDD.cache()


    saveToWebDM(rdd, ippRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], sparkSession.sparkContext.emptyRDD[CassandraRow], metRDD, sparkSession.sparkContext.emptyRDD[CassandraRow], notMetRDD, MEASURE_NAME)
  }

  def getIpp(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>
      isPatientAdult(visit, m)
        && isEDorCCEncounterPerformed(visit, m, patientHistoryList, AdminElements.Emergency_Visit_Arrival_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management)
        && (isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Septic_Shock, ACEP30Elements.Septic_Shock_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
        || (isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Sepsis, ACEP30Elements.Sepsis_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
        && isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Acute_Hypotension, ACEP30Elements.Acute_Hypotension_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
        )
        ||
        ( wasDiagnosedBeforeEDOrCCEncounter(visit, m, ACEP30Elements.Infection, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date, patientHistoryList)
          && isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Acute_Hypotension, ACEP30Elements.Acute_Hypotension_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
          )
        )
    )
  }

  def getEligible(ippRDD: RDD[CassandraRow]): RDD[CassandraRow] ={
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      checkElementValueOnEncounter(visit, m,ACEP30Elements.Serum_Lactate, 2, "ge")
    )

  }

  def getExclusion(rdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    rdd.filter(visit =>

      wasPatientTransferedFromAcuteCareWithinXHours(visit, m, ACEP30Elements.Acute_Care_Or_Inpatient_Facility, AdminElements.Emergency_Visit_Arrival_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management, 6, patientHistoryList)
        ||
        (isPatientLeftBeforeTreatmentCompletionOnEDOrCCEncounter(visit, m, ACEP30Elements.Left_Before_Treatment_Completion, ACEP30Elements.Left_Before_Treatment_Completion_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
          || isPatientExpiredOnEDOrCCEncounter(visit, m, ACEP30Elements.Patient_Expired, ACEP30Elements.Patient_Expired_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
          )
        || isDateTimeBetweenLessXHours(visit, m, AdminElements.Emergency_Visit_Arrival_Date, ACEP30Elements.Serum_Lactate, 2)
        || (
          isInterventionOrderedDuringEDOrCCEncounter(visit, m, ACEP30Elements.Comfort_Measures, ACEP30Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
            || isInterventionPerformedDuringEDOrCCEncounter(visit, m, ACEP30Elements.Comfort_Measures, ACEP30Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
            || isCommunicationFromPatientToProviderDoneDuringEDOrCCEncounter(visit, m, ACEP30Elements.Declined_Sepsis_Care, ACEP30Elements.Comfort_Measures_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Cardiac_Arrest, ACEP30Elements.Cardiac_Arrest_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Second_And_Third_Degree_Burn, ACEP30Elements.Second_And_Third_Degree_Burn_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Seizure, ACEP30Elements.Seizure_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Gastrointestinal_Hemorrhage, ACEP30Elements.Gastrointestinal_Hemorrhage_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Hemorrhagic_Stroke, ACEP30Elements.Hemorrhagic_Stroke_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Ischemic_Stroke, ACEP30Elements.Ischemic_Stroke_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Myocardial_Infarction, ACEP30Elements.Myocardial_Infarction_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Toxicological_Emergency, ACEP30Elements.Toxicological_Emergency_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
            || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Trauma, ACEP30Elements.Trauma_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)

          )
      ||(
        isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.End_Stage_Liver_Disease, ACEP30Elements.End_Stage_Liver_Disease_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
        || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP30Elements.Status_Epilepticus, ACEP30Elements.Status_Epilepticus_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
          || isMedicationDuringEDOrCCEncounter(visit, m, ACEP30Elements.Status_Epilepticus, ACEP30Elements.Status_Epilepticus_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
          || isMedicationDuringEDOrCCEncounter(visit, m, ACEP30Elements.Nucleoside_Reverse_Transcriptase_Inhibitors_Nrtis, ACEP30Elements.Nucleoside_Reverse_Transcriptase_Inhibitors_Nrtis_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)

        )
    )
  }


  def getMet(ippRdd: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRdd.filter(visit =>
      wasProcedurePerformedBeforeOrEqual(visit, m, ACEP30Elements.Repeat_Serum_Lactate, ACEP30Elements.Serum_Lactate, patientHistoryList ) &&
    isLaboratoryTestOrderDuringEDOrCCEncounter(visit, m, ACEP30Elements.Repeat_Serum_Lactate, ACEP30Elements.Repeat_Serum_Lactate_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date, ACEP30Elements.Critical_Care_Evaluation_And_Management_Date)
    )

  }

}
