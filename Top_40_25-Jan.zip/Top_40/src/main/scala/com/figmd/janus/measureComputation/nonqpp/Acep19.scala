package com.figmd.janus.measureComputation.nonqpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.{Measure, MeasureUpdate}
import com.figmd.janus.measureComputation.master.{ACEP19Elements, AdminElements, MeasureProperty}
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ACEP 19
* Measure Title              :- Emergency Medicine: Emergency Department Utilization of CT for Minor Blunt Head Trauma for Patients Aged 18 Years and Older
* Measure Description        :- Percentage of emergency department visits for patients aged 18 years and older who presented with a minor blunt head trauma
                                who had a head CT for trauma ordered by an emergency care provider who have an indication for a head CT
* Calculation Implementation :- Visit Specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Rasure
----------------------------------------------------------------------------------------------------------------------------*/


object Acep19 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Acep19"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    var getPatientHistoryList = getPatientHistory(sparkSession, initialRDD, ACEP19Elements.Non_Penetrating_Head_Trauma,
      ACEP19Elements.Ventricular_Shunt,
      ACEP19Elements.Brain_Tumor,
      ACEP19Elements.Antiplatelet_Therapy,
      ACEP19Elements.Coagulopathies,
      ACEP19Elements.Thrombocytopenia,
      ACEP19Elements.Anticoagulant,
      ACEP19Elements.Drug_Or_Alcohol_Intoxication).collect.toList
    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryList)
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      // Eligible IPP
      val denominatorRDD = getEligible(ippRDD)
      denominatorRDD.cache()

      //val noteligibleRDD = getSubtractRDD(ippRDD, eligibleRdd)

      // Filter Exclusion
      val exclusionRDD = getExclusionRdd(denominatorRDD, patientHistoryList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()


      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.unpersist()

    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Initial Population : All emergency department visits for patients aged 18 years and older who presented with a minor blunt head trauma
----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit,m)
      && isEDorCCEncounterPerformed(visit, m, patientHistoryList, AdminElements.Emergency_Visit_Arrival_Date, ACEP19Elements.Critical_Care_Evaluation_And_Management)
      && wasDiagnosedBeforeEDOrCCEncounter(visit, m, ACEP19Elements.Non_Penetrating_Head_Trauma, AdminElements.Emergency_Visit_Departure_Date, ACEP19Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
    )

  }

  /*-------------------------------------------------------------------------------------------------------------------------
Denominator : Equals Initial Population who had a head CT for trauma ordered by an emergency care provider
----------------------------------------------------------------------------------------------------------------------------*/

  def getEligible(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE,globalStartDate,globalEndDate)

    rdd.filter(visit =>
      isDiagnosticStudyDuringEDOrCCEncounter(visit,m,ACEP19Elements.Head_Ct,ACEP19Elements.Head_Ct_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
    )

  }

  /*-------------------------------------------------------------------------------------------------------------------------
Denominator Exclusions : Patients with any of the following:
   - Ventricular shunt
   - Brain tumor
   - Multisystem Trauma
   - Pregnancy
   - Currently taking any of the following antiplatelet medications*:
       - abciximab, cangrelor, cilostazol, clopidogrel, eptifibatide, prasugrel, ticlopidine, ticagrelor, tirofiban, vorapaxar

*The aforementioned list of medications/drug names is based on clinical guidelines and other evidence and may not be all-inclusive or current.
* Physicians and other health care professionals should refer to the FDA's web site page entitled "Drug Safety Communications" for up-to-date drug recall
* and alert information when prescribing medications. As part of the measure maintenance process, the measure and specifications will be updated routinely to account
* for newly released and FDA approved pharmacologic agents.
----------------------------------------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
      wasDiagnosedBeforeEDOrCCEncounter(visit, m, ACEP19Elements.Ventricular_Shunt, AdminElements.Emergency_Visit_Departure_Date, ACEP19Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        || wasDiagnosedBeforeEDOrCCEncounter(visit, m, ACEP19Elements.Brain_Tumor, AdminElements.Emergency_Visit_Departure_Date, ACEP19Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        || isDiagnosedWithOnEncounter(visit, m, ACEP19Elements.Pregnancy)
        || wasMedicationBeforeEDOrCCEncounter(visit, m, ACEP19Elements.Antiplatelet_Therapy, AdminElements.Emergency_Visit_Departure_Date, ACEP19Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        || isDiagnosisDuringEDOrCCEncounter(visit, m, ACEP19Elements.Trauma_Excluding_Head, ACEP19Elements.Trauma_Excluding_Head_Date, AdminElements.Emergency_Visit_Arrival_Date, AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
        || isDiagnosticStudyDuringEDOrCCEncounter(visit,m,ACEP19Elements.Ct_Of_Torso,ACEP19Elements.Ct_Of_Torso_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Numerator : Emergency department visits for patients who have an indication for a head CT
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      isAgeAbove(visit,m,true,65)
        || isGCSResultDuringEDorCCLessThanX(visit,m,ACEP19Elements.Glasgow_Coma_Scale,15,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
        || isSymptomDuringEDOrCCSeverity(visit,m,ACEP19Elements.Headache,ACEP19Elements.Headache_Date,ACEP19Elements.Severe,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
        || isSymptomDuringEDOrCCEncounter(visit,m,ACEP19Elements.Vomiting,ACEP19Elements.Vomiting_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
        || isSymptomDuringEDOrCCEncounter(visit,m,ACEP19Elements.Physical_Signs_Of_Basilar_Skull_Fracture,ACEP19Elements.Physical_Signs_Of_Basilar_Skull_Fracture_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
        || isSymptomDuringEDOrCCEncounter(visit,m,ACEP19Elements.Focal_Neurological_Deficit,ACEP19Elements.Focal_Neurological_Deficit_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
        || wasDiagnosedBeforeEDOrCCEncounter(visit, m, ACEP19Elements.Coagulopathies, AdminElements.Emergency_Visit_Departure_Date, ACEP19Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        || wasDiagnosedBeforeEDOrCCEncounter(visit, m, ACEP19Elements.Thrombocytopenia, AdminElements.Emergency_Visit_Departure_Date, ACEP19Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        || wasMedicationBeforeEDOrCCEncounter(visit, m, ACEP19Elements.Anticoagulant,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
        || (isVisitTypeIn(visit,m, ACEP19Elements.Emergency_Department_Visit, ACEP19Elements.Critical_Care_Evaluation_And_Management)
        && (isEncounterPerformedEDOrCCEncounter(visit,m,ACEP19Elements.Critical_Care_Evaluation_And_Management,ACEP19Elements.Dangerous_Mechanism_Of_Injury)
        || isEncounterPerformedEDOrCCEncounter(visit,m,ACEP19Elements.Emergency_Department_Visit,ACEP19Elements.Dangerous_Mechanism_Of_Injury)
        )
        )
        || (
        (isSymptomDuringEDOrCCEncounter(visit,m,ACEP19Elements.Loss_Of_Consciousness,ACEP19Elements.Loss_Of_Consciousness_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
          || isSymptomDuringEDOrCCEncounter(visit,m,ACEP19Elements.Post_Traumatic_Amnesia,ACEP19Elements.Post_Traumatic_Amnesia_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
          )
          &&
          (isAgeBetween(visit,m,60,66)
            || isGCSResultDuringEDorCCLessThanX(visit,m,ACEP19Elements.Glasgow_Coma_Scale,15,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
            || isSymptomDuringEDOrCCEncounter(visit,m,ACEP19Elements.Headache,ACEP19Elements.Headache_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
            || isSymptomDuringEDOrCCEncounter(visit,m,ACEP19Elements.Short_Term_Memory_Deficits,ACEP19Elements.Short_Term_Memory_Deficits_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
            || isSymptomDuringEDOrCCEncounter(visit,m,ACEP19Elements.Seizure_After_Head_Injury,ACEP19Elements.Seizure_After_Head_Injury_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
            || isSymptomDuringEDOrCCEncounter(visit,m,ACEP19Elements.Evidence_Of_Trauma_Of_Head_Or_Neck,ACEP19Elements.Evidence_Of_Trauma_Of_Head_Or_Neck_Date,AdminElements.Emergency_Visit_Arrival_Date,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date)
            || wasDiagnosedBeforeEDOrCCEncounter(visit,m,ACEP19Elements.Drug_Or_Alcohol_Intoxication,AdminElements.Emergency_Visit_Departure_Date,ACEP19Elements.Critical_Care_Evaluation_And_Management_Date,patientHistoryList)
            )
        )
    )
  }

}







