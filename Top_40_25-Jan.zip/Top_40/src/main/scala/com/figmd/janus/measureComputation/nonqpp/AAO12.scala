package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AAO12Elements, AdminElements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- AAO12
* Measure Title               :- Tympanostomy Tubes: Topical Ear Drop Monotherapy Acute Otorrhea
* Measure Description         :- Percentage of patients age 6 months to 12 years of age at the time of the visit with a current diagnosis
*                               of an uncomplicated acute tympanostomy tube otorrhea (TTO) who were prescribed or recommended to use topical
*                               antibiotic eardrops and NOT prescribed systemic (IV or PO) antibiotics for acute tympanostomy tube otorrhea.
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- VRUSHALI.GHOLAP
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.5
----------------------------------------------------------------------------------------------------------------------------*/

object AAO12 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "AAO12"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,AAO12Elements.Tympanostomy
      ,AAO12Elements.Otorrhea
      ,AAO12Elements.Ototopical_Antibiotics
      ,AAO12Elements.Antibiotics
      ,AAO12Elements.Failed_Topical_Antibiotic_Therapy
      ,AAO12Elements.Non_Ototoxic_Topical_Antibiotic_Drops
      ,AAO12Elements.Lack_Of_Tolerance
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
    All patients 6 months to 12 years of age at the time of the visit with a current diagnosis of an uncomplicated
    acute tympanostomy tube otorrhea.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
    isAgeAboveInMonth(visit,m,true,6)
      && isAgeBelow(visit,m,false,13)
      && isVisitTypeIn(visit,m
              ,AAO12Elements.Home_Visit
              ,AAO12Elements.Inpatient_Consultation
              ,AAO12Elements.Discharge_Services___Hospital_Inpatient
              ,AAO12Elements.Subsequent_Hospital_Care
              ,AAO12Elements.Hospital_Inpatient_Visit___Initial
              ,AAO12Elements.Discharge_Services__Observation_Care
              ,AAO12Elements.Subsequent_Observation_Care
              ,AAO12Elements.Hospital_Observation_Care___Initial
              ,AAO12Elements.Domiciliary_Or_Rest_Home_Visit
              ,AAO12Elements.Office_Visit
              ,AAO12Elements.Office_Or_Other_Outpatient_Visit
              ,AAO12Elements.Office_Consultation
              ,AAO12Elements.Nursing_Facility_Visit)
      && wasProcedurePerformedBeforeEncounter(visit,m,AAO12Elements.Tympanostomy,patientHistoryBroadcastList,AdminElements.Encounter_Date)
      && wasDiagnosisAfterProcedurePerformed(visit,m,AAO12Elements.Tympanostomy,patientHistoryBroadcastList,AAO12Elements.Otorrhea)
      && wasDiagnosedBeforeEncounter(visit,m,AAO12Elements.Otorrhea,patientHistoryBroadcastList)

    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Patients who were prescribed or recommended to use topical antibiotic eardrops and NOT prescribed systemic (IV or PO) antibiotics
  for acute tympanostomy tube otorrhea.
  -----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      (    wasMedicationAdministeredAfterDiagnosisInHistory(visit,m,AAO12Elements.Otorrhea,patientHistoryBroadcastList,AAO12Elements.Ototopical_Antibiotics)
        || wasMedicationAdministeredAfterProcedureInHistory(visit,m,AAO12Elements.Tympanostomy,patientHistoryBroadcastList,AAO12Elements.Ototopical_Antibiotics)
       )
      && !
      (    wasMedicationAdministeredAfterDiagnosisInHistory(visit,m,AAO12Elements.Otorrhea,patientHistoryBroadcastList,AAO12Elements.Antibiotics)
        || wasMedicationAdministeredAfterProcedureInHistory(visit,m,AAO12Elements.Tympanostomy,patientHistoryBroadcastList,AAO12Elements.Antibiotics)
       )
      )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Medical reason for not prescribing/recommending topical antibiotic monotherapy or for prescribing oral antibiotics include:
  • Patients with high fever;
  • Patients with cellulitis of the ear or adjacent skin,
  • Patients who are immunocompromised
  • Patients with oral antibiotic given for other concurrent condition including but not limited to streptococcal pharyngitis,
   bacterial sinusitis, pneumonia, pharyngitis, osteitis abscess, or other concurrent acute infection beyond the confines of the ear canal;
  • Patients who failed topical antibiotic therapy;
  • Patients with a cochlear implant;
  • Patients with concurrent diabetes;
  • Patients who were prescribed oral antibiotics by another clinician; concurrent diagnosis of acute suppurative otitis media effusion
  with intact eardrum; acute TTO persists, or worsens, despite topical antibiotic therapy.

  Patient reason for not prescribing/recommending topical antibiotics or prescribing oral antibiotics include:

  • Administration of eardrops is not possible because of local discomfort
  • Lack of tolerance
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
       isDiagnosedDuringEncounter(visit,m,AAO12Elements.Medical_Reason_For_Antibiotics_For_Tto)
    || isPatientCharacteristicDuringEncounter(visit,m,AAO12Elements.Patient_Refused)
    || wasInterventionPerformedAfterDiagnosisInHistory(visit,m,AAO12Elements.Otorrhea,patientHistoryBroadcastList,AAO12Elements.Failed_Topical_Antibiotic_Therapy)
    || wasInterventionPerformedfterProcedurePerformedInHistory(visit,m,AAO12Elements.Tympanostomy,patientHistoryBroadcastList,AAO12Elements.Failed_Topical_Antibiotic_Therapy)
    || wasInterventionPerformedAfterDiagnosisInHistory(visit,m,AAO12Elements.Otorrhea,patientHistoryBroadcastList,AAO12Elements.Non_Ototoxic_Topical_Antibiotic_Drops)
    || wasInterventionPerformedfterProcedurePerformedInHistory(visit,m,AAO12Elements.Tympanostomy,patientHistoryBroadcastList,AAO12Elements.Non_Ototoxic_Topical_Antibiotic_Drops)
    || wasMedicationIntoleranceAfterDiagnosisInHistory(visit,m,AAO12Elements.Otorrhea,patientHistoryBroadcastList,AAO12Elements.Lack_Of_Tolerance)
    || wasMedicationIntoleranceAfterProcedureInHistory(visit,m,AAO12Elements.Tympanostomy,patientHistoryBroadcastList,AAO12Elements.Lack_Of_Tolerance)

    )
  }
}