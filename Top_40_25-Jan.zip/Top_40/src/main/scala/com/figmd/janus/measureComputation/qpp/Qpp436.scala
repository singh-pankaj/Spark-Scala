package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty}
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 436
* Measure Title              :- Radiation Consideration for Adult CT: Utilization of Dose Lowering Techniques
* Measure Description        :- Percentage of final reports for patients aged 18 years and older undergoing CT with documentation
*                               that one or more of the following dose reduction techniques were used.
                                • Automated exposure control
                                • Adjustment of the mA and/or kV according to patient size
                                • Use of iterative reconstruction technique
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher score indicates better quality.
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp436 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp436"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {


      // Filter denominator Exclusions
      val denominatorExclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //eligible initial population RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val patient_history_list = getPatientHistory(sparkSession, ippRDD
        , QPP436Elements.Dose_Reduction_Techniques
        , QPP436Elements.Dose_Reduction_Not_Met
        , QPP436Elements.Dose_Optimization_Technique
      )

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list.collect().toList)

      //Met initialRDD
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)

      //exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(denominatorRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, denominatorExclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  // IPP-Denominator criteria
  /*--------------------------------------------------------------------------------------------------------------------
   All final reports for patients aged 18 years and older undergoing CT.
    --------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        isProcedurePerformedDuringEncounter(visit, m, QPP436Elements.Computed_Tomography)
    )
  }


  // Numerator criteria
  /*--------------------------------------------------------------------------------------------------------------------
   Final reports with documentation that indicate an individualized dose optimization technique was used for the performed
   procedure, Dose optimization techniques include the following:

  • Automated exposure control
  • Adjustment of the mA and/or kV according to patient size
  • Use of iterative reconstruction technique
   --------------------------------------------------------------------------------------------------------------------*/
  def getMet(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    rdd.filter(visit =>
      (
        isInterventionPerformed(visit, m, QPP436Elements.Dose_Reduction_Techniques, patientHistoryBroadcastList)
          ||
          wasInterventionPerformedAfterOrEqualEncounter(visit, m, QPP436Elements.Computed_Tomography, QPP436Elements.Dose_Optimization_Technique, patientHistoryBroadcastList)
        )
        &&
        !isInterventionPerformed(visit, m, QPP436Elements.Dose_Reduction_Not_Met, patientHistoryBroadcastList)
    )
  }
}