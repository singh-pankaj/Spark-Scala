package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{QPP261Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 261
* Measure Title              :- Referral for Otologic Evaluation for Patients with Acute or Chronic Dizziness
* Measure Description        :- Percentage of patients aged birth and older referred to a physician (preferably a
                                physician specially trained in disorders of the ear) for an otologic evaluation subsequent
                                to an audiologic evaluation after presenting with acute or chronic dizziness
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Priyanka Chavan
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp261 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp261"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP261Elements.Referral_To_A_Physician_For_Otologic_Evaluation
      , QPP261Elements.Patient_Referred_To_The_Physician_For_Otologic_Evaluation
      , QPP261Elements.Otologic_Evaluation_Reason_Not_Specified
      , QPP261Elements.Otologic_Evaluation__Patient_Ineligible
      , QPP261Elements.Otologic_Evaluation_Patient_Not_Eligible).collect().toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate RDD
      val intermediateException = getSubtractRDD(ippRDD, metRDD)
      intermediateException.cache()

      // Filter Exceptions
      val exceptionRDD = getExceptionRDD(intermediateException, patientHistoryBroadcastList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
  All patients aged birth and older presenting with acute or chronic dizziness
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isVisitTypeIn(visit, m
        , QPP261Elements.Audiology_Visit
        , QPP261Elements.Otologic_Test
        , QPP261Elements.Tympanometry)
        && isDiagnosedOnEncounter(visit, m, QPP261Elements.Dizziness_Acute_Or_Chronic)
    )
  }

  /*------------------------------------------------------------------------------------------------
   Patients referred to a physician for an otologic evaluation subsequent to
   an audiologic evaluation who present with acute or chronic dizziness
   ------------------------------------------------------------------------------------------------*/

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        wasInterventionPerformedAfterOrEqualEncounter(visit, m, QPP261Elements.Referral_To_A_Physician_For_Otologic_Evaluation, patientHistoryBroadcastList)
          || wasInterventionPerformedAfterOrEqualEncounter(visit, m, QPP261Elements.Patient_Referred_To_The_Physician_For_Otologic_Evaluation, patientHistoryBroadcastList)
        )
        && !wasInterventionPerformedAfterOrEqualEncounter(visit, m, QPP261Elements.Otologic_Evaluation_Reason_Not_Specified, patientHistoryBroadcastList)
    )

  }

  /*-----------------------------------------------------------------------------------------------------------------
   Patient is not eligible for the referral for otologic evaluation measure
   (e.g., patients who are already under the care of a physician for acute or chronic dizziness)
   -----------------------------------------------------------------------------------------------------------------*/

  def getExceptionRDD(intermediateException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)
    intermediateException.filter(visit =>
      wasInterventionPerformedNotDoneAfterOrEqualEncounter(visit, m, QPP261Elements.Otologic_Evaluation__Patient_Ineligible, patientHistoryBroadcastList)
        || wasInterventionPerformedNotDoneAfterOrEqualEncounter(visit, m, QPP261Elements.Otologic_Evaluation_Patient_Not_Eligible, patientHistoryBroadcastList)
    )

  }

}
