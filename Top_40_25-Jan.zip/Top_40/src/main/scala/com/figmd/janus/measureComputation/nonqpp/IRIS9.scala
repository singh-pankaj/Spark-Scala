package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, IRIS9Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS9
* Measure Title               :- Diabetic Retinopathy: Documentation of Presence or Absence of Macular Edema and Level of Severity of Retinopathy
* Measure Description         :- Percentage of patients aged 18 years and older with a diagnosis of diabetic retinopathy who had a dilated macular or fundus exam performed
                                 which included documentation of the level of severity of retinopathy and the presence or absence of macular edema during one or more office visits within 12 months
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.7
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.7
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS9 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "IRIS9"


  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
          ,IRIS9Elements.Diabetic_Retinopathy
          ,IRIS9Elements.Diabetic_Retinopathy__Eye
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Denominator
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate for Exception
      val intermediateForException = getSubtractRDD(denominatorRDD, metRDD)
      intermediateForException.cache()

      // Filter Exceptions
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients aged 18 years and older with a diagnosis of diabetic retinopathyAll patients aged
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
              isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
          &&  wasDiagnosedBeforeEncounter(visit,m,IRIS9Elements.Diabetic_Retinopathy,patientHistoryBroadcastList)
          &&  isVisitTypeIn(visit,m
                   ,IRIS9Elements.Ophthalmological_Services
                   ,IRIS9Elements.Care_Services_In_Long_Term_Residential_Facility
                   ,IRIS9Elements.Nursing_Facility_Visit
                   ,IRIS9Elements.Office_Visit
                   ,IRIS9Elements.Outpatient_Consultation
                   ,IRIS9Elements.Face_To_Face_Interaction)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients who had a dilated macular or fundus exam performed which included documentation of the level of severity of retinopathy
AND the presence or absence of macular edema during one or more office visits within 12 monthsPatients
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
        isDiagnosticStudyOnEncounter(visit,m,IRIS9Elements.Macular_Exam)
    &&  (   isDiagnosticStudyOnEncounter(visit,m,IRIS9Elements.Mild_Non_Proliferative_Diabetic_Retinopathy)
         || isDiagnosticStudyOnEncounter(visit,m,IRIS9Elements.Moderate_Diabetic_Retinopathy)
         || isDiagnosticStudyOnEncounter(visit,m,IRIS9Elements.Proliferative_Diabetic_Retinopathy)
         || isDiagnosticStudyOnEncounter(visit,m,IRIS9Elements.Severe_Non_Proliferative_Diabetic_Retinopathy)
         || isDiagnosticStudyOnEncounter(visit,m,IRIS9Elements.Very_Severe_Non_Proliferative_Diabetic_Retinopathy)
        )
    &&  (   isDiagnosticStudyOnEncounter(visit,m,IRIS9Elements.Macular_Edema_Findings_Present)
         || isDiagnosticStudyOnEncounter(visit,m,IRIS9Elements.Macular_Edema_Findings_Absent)
        )
    &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,true,IRIS9Elements.Macular_Exam__Eye,patientHistoryBroadcastList,Seq(IRIS9Elements.Diabetic_Retinopathy__Eye))
    &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,true,IRIS9Elements.Level_Of_Severity_Of_Retinopathy_Findings_Eye,patientHistoryBroadcastList,Seq(IRIS9Elements.Diabetic_Retinopathy__Eye))
    &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,true,IRIS9Elements.Macular_Edema_Findings__Eye,patientHistoryBroadcastList,Seq(IRIS9Elements.Diabetic_Retinopathy__Eye))
  )
 }

  /*-----------------------------------------------------------------------------------------------------------------------
Documentation of medical reason(s) for not performing a dilated macular or fundus examination.
Documentation of patient reason(s) for not performing a dilated macular or fundus examination.
-----------------------------------------------------------------------------------------------------------------------*/
  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateForException.filter(visit =>
           isDiagnosticStudyPerformedNotDoneDuringEncounter(visit,m,IRIS9Elements.Medical_Reason)
        || isDiagnosticStudyPerformedNotDoneDuringEncounter(visit,m,IRIS9Elements.Patient_Reason)
   )
  }
}