package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master
import com.figmd.janus.measureComputation.master.{MeasureProperty, QPP141Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 141
* Measure Title              :- Primary Open-Angle Glaucoma (POAG): Reduction of Intraocular Pressure (IOP) by 15% OR Documentation of a Plan of Care
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of primary open-angle glaucoma (POAG) whose glaucoma treatment
*                               has not failed (the most recent IOP was reduced by at least 15% from the pre-intervention level) OR if the most recent IOP was not
*                               reduced by at least 15% from the pre-intervention level, a plan of care was documented within 12 months.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp141 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp141"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    var patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP141Elements.Primary_Open_Angle_Glaucoma,
      QPP141Elements.Primary_Open_Angle_Glaucoma_Eye
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(sparkSession, intermediateA, patientHistoryRDD)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isVisitTypeIn(visit, m, QPP141Elements.Care_Services_In_Long_Term_Residential_Facility, QPP141Elements.Nursing_Facility_Visit,
        QPP141Elements.Office_Visit, QPP141Elements.Ophthalmological_Services)
        && (
          isDiagnosisWithBeforeEnd(visit, m, QPP141Elements.Primary_Open_Angle_Glaucoma, patientHistoryBroadcastList)
        && wasDiagnosedBeforeEndWithLaterality(visit, m, QPP141Elements.Primary_Open_Angle_Glaucoma, QPP141Elements.Primary_Open_Angle_Glaucoma_Eye, patientHistoryBroadcastList)
      )
      && !isVisitTypeIn(visit, m, QPP141Elements.Ophthalmological_Services_Telehealth_Modifier,
        QPP141Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier,
        QPP141Elements.Nursing_Facility_Visit_Telehealth_Modifier,
        QPP141Elements.Office_Visit_Telehealth_Modifier
      )
      && !isVisitTypeIn(visit, m, QPP141Elements.Pos_02)
    )
  }


  def getMet(spark: SparkSession,intermediateA: RDD[CassandraRow], patient_history_RDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    val firstIOPList =  spark.sparkContext.broadcast(getHistoryOnMinDateOfElement(patient_history_RDD, m, QPP141Elements.Iop_Reduction ))
    val latestIOPList =  spark.sparkContext.broadcast(getHistoryMostRecentDateOfElement(patient_history_RDD, m, QPP141Elements.Iop_Reduction ))

    intermediateA.filter(visit =>
      (
        (
          (wasPhysicalExamPerformedOnSameDay(visit, m, QPP141Elements.Intraocular_Pressure__Iop_, firstIOPList)
            && wasPhysicalExamPerformedOnSameDay(visit, m, QPP141Elements.Iop__Eye, firstIOPList))
          &&
            (wasPhysicalExamPerformedOnSameDay(visit, m, QPP141Elements.Intraocular_Pressure__Iop_, latestIOPList)
              && wasPhysicalExamPerformedOnSameDay(visit, m, QPP141Elements.Iop__Eye, latestIOPList))
          && isPhysicalExamPerformedValueGreaterOrEqualOnEncounter(visit, m, QPP141Elements.Difference_In_Iop, 15)
          && (isPhysicalExamPerformedValueLessThanOnEncounter(visit, m, QPP141Elements.Difference_In_Iop, 15)
              && isInterventionPerformedDuringEncounter(visit, m, QPP141Elements.Plan_Of_Care)
              && isInterventionPerformedDuringEncounter(visit, m, QPP141Elements.Plan_Of_Care_Eye)
          )
          )
        || isProcedurePerformedDuringEncounter(visit, m, QPP141Elements.Intraocular_Pressure)
        || (isProcedurePerformedDuringEncounter(visit, m, QPP141Elements.Iop_Reduction)
            && isProcedurePerformedDuringEncounter(visit, m, QPP141Elements.Iop__Eye)
            && isProcedurePerformedDuringEncounter(visit, m, QPP141Elements.Glaucoma_Plan_Of_Care)
            && isProcedurePerformedDuringEncounter(visit, m, QPP141Elements.Plan_Of_Care_Eye))
        )
      && !(
        isProcedurePerformedDuringEncounter(visit, m, QPP141Elements.Iop_Reduction)
        && isProcedurePerformedDuringEncounter(visit, m, QPP141Elements.Iop__Eye)
        && isInterventionNotDoneDuringEncounter(visit, m, QPP141Elements.Glaucoma_Plan_Of_Care_Reason_Not_Specified)
      )
      && ! isProcedurePerformedDuringEncounter(visit, m, QPP141Elements.Iop_Reason_Not_Specified)
  )
  }
}