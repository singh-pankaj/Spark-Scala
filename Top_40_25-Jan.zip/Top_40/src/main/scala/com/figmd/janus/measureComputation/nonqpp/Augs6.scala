package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty,AUGS6Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- Augs6
* Measure Title               :- Route of Hysterectomy
* Measure Description         :- Percentage of patients who underwent vaginal hysterectomy.
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.RASURE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.5.
* Latest GIT Version/Tag(CRA) :-
----------------------------------------------------------------------------------------------------------------------------*/

object Augs6 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Augs6"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {



    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,AUGS6Elements.Gynecologic_Or_Pelvic_Malignancy)
      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  // Note : This is Procedure-specific hence checking all the procedure on encounter instead of during measurement period.

  /*-----------------------------------------------------------------------------------------------------------------------
Initial Population : Total number of patients undergoing hysterectomy of any type.
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
           isFemale(visit,m)
        && (
                isProcedurePerformedDuringEncounter(visit,m,AUGS6Elements.Hysterectomy)
             || isProcedurePerformedDuringEncounter(visit,m,AUGS6Elements.Vaginal_Route_Of_Hysterectomy)
             || isProcedurePerformedDuringEncounter(visit,m,AUGS6Elements.Laparoscopic_Route_Of_Hysterectomy)
             || isProcedurePerformedDuringEncounter(visit,m,AUGS6Elements.Abdominal_Route_Of_Hysterectomy)
           )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Denominator Exclusions : Patients with a preoperative diagnosis of cancer.
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
          isDiagnosisOverlapsProcedure(visit,m,AUGS6Elements.Gynecologic_Or_Pelvic_Malignancy,AUGS6Elements.Hysterectomy,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Numerator : The number of patients undergoing vaginal hysterectomy.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
           isProcedurePerformedDuringEncounter(visit,m,AUGS6Elements.Vaginal_Route_Of_Hysterectomy)
        || isProcedurePerformedDuringEncounter(visit,m,AUGS6Elements.Vaginal_Hysterectomy)


    )
  }


}