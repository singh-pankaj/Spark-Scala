package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 258
* Measure Title              :- Rate of Open Repair of Small or Moderate Non-Ruptured Infrarenal Abdominal Aortic Aneurysms (
*                               AAA) without Major Complications (Discharged to Home by Post-Operative Day #7)
* Measure Description        :- Percent of patients undergoing open repair of small or moderate sized non-ruptured infrarenal
*                               abdominal aortic aneurysms who do not experience a major complication (discharge to home no
*                               later than post-operative day #7)
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp258 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp258"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP258Elements.Diameter_Of_Aortic_Aneurysm_Between_5_5_5_9_Cm
      , QPP258Elements.Diameter_Of_Aortic_Aneurysm_Of_At_Least_6_Cm
      , QPP258Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa
      , QPP258Elements.Diameter_Of_Aortic_Aneurysm
      , QPP258Elements.Discharge_Following_Open_Repairs
      , QPP258Elements.Skilled_Nursing_Facility
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  //IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        isProcedurePerformedDuringEncounter(visit, m, QPP258Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa)
    )
  }

  // Denominator Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (
        isFemale(visit, m)
          &&
          (
            wasInterventionPerformedBeforeEncounter(visit, m, QPP258Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa_Date, patientHistoryBroadcastList, QPP258Elements.Diameter_Of_Aortic_Aneurysm_Between_5_5_5_9_Cm)
              ||
              wasInterventionPerformedBeforeEncounter(visit, m, QPP258Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa_Date, patientHistoryBroadcastList, QPP258Elements.Diameter_Of_Aortic_Aneurysm_Of_At_Least_6_Cm)
            )
        )
        ||
        (
          isMale(visit, m)
            &&
            wasInterventionPerformedBeforeEncounter(visit, m, QPP258Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa_Date, patientHistoryBroadcastList, QPP258Elements.Diameter_Of_Aortic_Aneurysm_Of_At_Least_6_Cm)
          )
        ||
        (
          isFemale(visit, m)
            &&
            wasInterventionValueGreaterOrEqualBeforeProcedurePerformed(visit, m, QPP258Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, QPP258Elements.Diameter_Of_Aortic_Aneurysm, CompareOperator.GREATER_EQUAL, 5.5, patientHistoryBroadcastList)
            &&
            wasInterventionValueGreaterOrEqualBeforeProcedurePerformed(visit, m, QPP258Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, QPP258Elements.Diameter_Of_Aortic_Aneurysm, CompareOperator.LESS_EQUAL, 5.9, patientHistoryBroadcastList)
          )
        ||
        (
          isMale(visit, m)
            &&
            wasInterventionValueGreaterOrEqualBeforeProcedurePerformed(visit, m, QPP258Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, QPP258Elements.Diameter_Of_Aortic_Aneurysm, CompareOperator.GREATER_EQUAL, 6, patientHistoryBroadcastList)
          )
        ||
        (
          isFemale(visit, m)
            &&
            wasInterventionValueGreaterOrEqualBeforeProcedurePerformed(visit, m, QPP258Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, QPP258Elements.Diameter_Of_Aortic_Aneurysm, CompareOperator.GREATER_EQUAL, 6, patientHistoryBroadcastList)
          )
    )
  }


  // Numerator Criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        wasProcedureAfterXProcedureDays(visit, m, QPP258Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa, QPP258Elements.Open_Repairs_Of_Non_Ruptured_Infrarenal_Aaa_Date, 7, patientHistoryBroadcastList, QPP258Elements.Discharge_Following_Open_Repairs)
          ||
          isEncounterPerformedOnEncounter(visit, m, QPP258Elements.Discharged_Home)
          ||
          wasProcedureAfterXProcedureDays(visit, m, QPP258Elements.Skilled_Nursing_Facility, QPP258Elements.Skilled_Nursing_Facility_Date, 7, patientHistoryBroadcastList, QPP258Elements.Discharge_Following_Open_Repairs)
        )
        &&
        !isAssessmentPerformedOnEncounter(visit, m, QPP258Elements.Discharged_Not_Met)
    )
  }


}

