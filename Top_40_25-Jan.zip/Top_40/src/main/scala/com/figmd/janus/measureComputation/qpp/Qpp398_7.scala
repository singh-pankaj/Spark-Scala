package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, QPP398Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP398
* Measure Title              :- Optimal Asthma Control
* Measure Description        :- Composite measure of the percentage of pediatric and adult patients whose asthma is
*                               well-controlled as demonstrated by one of three age appropriate patient reported outcome
*                               tools and not at risk for exacerbation.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 7
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumant Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp398_7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp398_7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP398Elements.Asthma
      , QPP398Elements.Cystic_Fibrosis
      , QPP398Elements.Chronic_Obstructive_Pulmonary_Disease
      , QPP398Elements.Emphysema
      , QPP398Elements.Acute_Respiratory_Failure
      , QPP398Elements.Patient_Deceased
      , QPP398Elements.Nursing_Home_Resident
      , QPP398Elements.Hospice_Services
      , QPP398Elements.Palliative_Care
      , QPP398Elements.Only_Urgent_Care_Visits_During_The_Performance_Period
      , QPP398Elements.Patient_Not_At_Elevated_Risk_Of_Exacerbation
      , QPP398Elements.Patient_Not_At_Elevated_Risk_Of_Exacerbation_Reason_Not_Specified
      , QPP398Elements.Emergency_Department_Visit_Asthma
      , QPP398Elements.Hospital_Inpatient_Visit___Initial_Asthma
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exceptions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateRDD = ippRDD.subtract(exclusionRDD)
      intermediateRDD.cache()

      // Filter Met
      val metRDD = getMet(intermediateRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]], patientHistoryRDD)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  /*-----------------------------------------------------------------------------------------------------------------------
  Patient not at elevated risk of exacerbation for patients 18 to 50 with Asthma
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAbove(visit, m, true, 18)
        &&
        isAgeBelow(visit, m, false, 51)
        &&
        isDiagnosedWithInHistory(visit, m, QPP398Elements.Asthma, patientHistoryBroadcastList)
        &&
        (
          isDiagnosis(visit, m, QPP398Elements.Asthma, patientHistoryBroadcastList)
            ||
            wasDiagnosisBeforeStartInXMonths(visit, m, QPP398Elements.Asthma, CalenderUnit.MONTH, 12, patientHistoryBroadcastList)
          )
        &&
        isVisitTypeIn(visit, m
          , QPP398Elements.Office_Visit
          , QPP398Elements.Preventive_Care_Established_Office_Visit
        )
    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
Diagnosis for chronic obstructive pulmonary disease, emphysema, cystic fibrosis, or acute respiratory failure
OR
Patient died prior to the end of the performance period
OR
Patient was a permanent nursing home resident any time during the performance period
OR
Patient was in hospice or receiving palliative care services at any time during the performance period
OR
Patient had only urgent care visits during the performance period:
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (
        isDiagnosis(visit, m, QPP398Elements.Cystic_Fibrosis, patientHistoryBroadcastList)
          ||
          isDiagnosis(visit, m, QPP398Elements.Chronic_Obstructive_Pulmonary_Disease, patientHistoryBroadcastList)
          ||
          isDiagnosis(visit, m, QPP398Elements.Emphysema, patientHistoryBroadcastList)
          ||
          isDiagnosis(visit, m, QPP398Elements.Acute_Respiratory_Failure, patientHistoryBroadcastList)
          ||
          isPatientExpiredBeforeEnd(visit, m, QPP398Elements.Patient_Deceased, patientHistoryBroadcastList)
          ||
          isInterventionPerformed(visit, m, QPP398Elements.Nursing_Home_Resident, patientHistoryBroadcastList)
          ||
          isInterventionPerformed(visit, m, QPP398Elements.Hospice_Services, patientHistoryBroadcastList)
          ||
          isInterventionPerformed(visit, m, QPP398Elements.Palliative_Care, patientHistoryBroadcastList)
          ||
          isAssessmentPerformed(visit, m, QPP398Elements.Only_Urgent_Care_Visits_During_The_Performance_Period, patientHistoryBroadcastList)
        )
    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
Asthma well-controlled (submit the most recent asthma control tool result available during the measurement
period)
• Asthma Control Test TM (ACT) result of 20 or above - ages 12 and older
• Childhood Asthma Control Test TM (C-ACT) result of 20 or above - ages 11 and younger
• Asthma Control Questionnaire (ACQ) result of 0.75 or lower - ages 17 and older
• Asthma Therapy Assessment Questionnaire (ATAQ) result of 0 – Pediatric (ages 5 – 17) or Adult
(ages 18 and older)
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], patientHistoryRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    val patientVisitAsthmaList = countElement(patientHistoryRDD, m, QPP398Elements.Emergency_Department_Visit_Asthma)
    val patientVisitInitialAsthmaList = countElement(patientHistoryRDD, m, QPP398Elements.Hospital_Inpatient_Visit___Initial_Asthma)

    intermediateRDD.filter(visit =>
      (
        !getEncounterCountFromHistory(visit, m, 2, true, patientVisitAsthmaList)
          ||
          !getEncounterCountFromHistory(visit, m, 2, true, patientVisitInitialAsthmaList)
          ||
          isEncounterPerformed(visit, m, QPP398Elements.Patient_Not_At_Elevated_Risk_Of_Exacerbation, patientHistoryBroadcastList)
        )
        &&
        (
          !isEncounterPerformedNotdone(visit, m, QPP398Elements.Patient_Not_At_Elevated_Risk_Of_Exacerbation, patientHistoryBroadcastList)
            ||
            !isEncounterPerformedNotdone(visit, m, QPP398Elements.Patient_Not_At_Elevated_Risk_Of_Exacerbation_Reason_Not_Specified, patientHistoryBroadcastList)
          )
    )
  }

}
