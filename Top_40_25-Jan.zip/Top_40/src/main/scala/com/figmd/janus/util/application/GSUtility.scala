package com.figmd.janus.util.application

import java.io.File
import java.util.{Calendar, Properties}

import com.amazonaws.{AmazonClientException, AmazonServiceException}
import org.apache.hadoop.conf.Configuration
import com.figmd.janus.WebDataMartCreator.prop

object GSUtility {
  val hadoopConfiguration: Configuration = new Configuration()

  def readGSConfigFile(args: Array[String]): Unit = {

    val FILE_PATH = args(0)

    try {
      var fileData = GCSFileUtility.readFile(hadoopConfiguration, FILE_PATH)
      for (property <- fileData) {
        if (!property.startsWith("#")) {
          val sp = property.split("=")
          val key = sp(0)
          val value = sp(1)
          prop.setProperty(key, value)
          println(key + "=" + value)
        }
      }

    } catch {
      //TODO: Clean up
      case ase: AmazonServiceException => System.err.println("Exception: " + ase.toString)
      case ace: AmazonClientException => System.err.println("Exception: " + ace.toString)
    }
  }
}