package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{MeasureProperty,AAD30Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD 30
* Measure Title              :- Basal Cell Carcinoma/Squamous Cell Carcinoma: Documentation of Patient Input for Treatment Type
* Measure Description        :- Percentage of patients with documented input about treatment options  for superficial BCC or SCC in situ
*                                by scalpel-based excisional surgery (including standard excision and Mohs surgery).
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- 1
* Measure Developer          :- Vrushali Gholap
----------------------------------------------------------------------------------------------------------------------------*/
object AAD30 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "AAD30"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,AAD30Elements.Scalpel_Based_Excisional_Surgery_Grp
      ,AAD30Elements.Patient_s__Or_Legal_Caregiver__Input_Grp
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      /*exclusion RDD*/
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(denominatorRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)

      patientHistoryBroadcastList.destroy()
    }
  }

  /*------------------------------------------------------------------------------
    All patients treated for at least one superficial basal cell carcinoma
    or squamous cell carcinoma in situ by scalpel-based excisional surgery
    (including standard excision and Mohs surgery) within the reporting period.
   ------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isDiagnosedOnEncounter(visit,m,AAD30Elements.Cutaneous_Scc_Or_Bcc)
        && (  isDiagnosedOnEncounter(visit,m,AAD30Elements.Superficial_Basal_Cell_Carcinoma_Grp)
            ||isDiagnosedOnEncounter(visit,m,AAD30Elements.Squamous_Cell_Carcinoma_In_Situ_Grp)
            )
        && wasProcedurePerformedAfterOrEqualEncounter(visit,m,AAD30Elements.Scalpel_Based_Excisional_Surgery_Grp,patientHistoryBroadcastList)
        && isProcedurePerformed(visit,m,AAD30Elements.Scalpel_Based_Excisional_Surgery_Grp,patientHistoryBroadcastList)
      //Diagnosis checked on encounter. thus Procedure checked in context of Encounter.
    )
  }

  /*------------------------------------------------------------------------------
    Number of patients for whom there is documentation of patient (or legal caregiver) input regarding treatment options
    at least once per reporting period.
  ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      isCommunicationFromPatientToProvider(visit,m,AAD30Elements.Patient_s__Or_Legal_Caregiver__Input_Grp,patientHistoryBroadcastList)
    )
  }

}
