package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 259
* Measure Title              :- Rate of Endovascular Aneurysm Repair (EVAR) of Small or Moderate Non-Ruptured Infrarenal
*                               Abdominal Aortic Aneurysms (AAA) without Major Complications (Discharged to Home by Post Operative Day #2)
* Measure Description        :- Percent of patients undergoing endovascular repair of small or moderate non-ruptured
*                               infrarenal abdominal aortic aneurysms (AAA) that do not experience a major complication (discharged
*                               to home no later than post-operative day #2).
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp259 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp259"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD
      , QPP259Elements.Non_Rupture_Abdominal_Aortic_Aneurysms
      , QPP259Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
      , QPP259Elements.Diameter_Of_Aortic_Aneurysm_Between_5_5_5_9_Cm
      , QPP259Elements.Diameter_Of_Aortic_Aneurysm_Of_At_Least_6_Cm
      , QPP259Elements.Diameter_Of_Aortic_Aneurysm
      , QPP259Elements.Discharged_To_Home
      , QPP259Elements.Discharge_Following_Evar
      , QPP259Elements.Transfer_To_Nursing_Facility
      , QPP259Elements.Same_Facility
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //Filter Denominator Exclusion
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  //IPP-Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        &&
        isProcedurePerformedDuringEncounter(visit, m, QPP259Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa)
        &&
        wasDiagnosisBeforeOrEqualProcedure(visit, m
          , QPP259Elements.Non_Rupture_Abdominal_Aortic_Aneurysms
          , QPP259Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
          , patientHistoryBroadcastList)
    )
  }


  // Denominator Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (
        isFemale(visit, m)
          &&
          (
            wasDiagnositicStudyPerformedBeforeEncounter(visit, m
              , QPP259Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
              , patientHistoryBroadcastList
              , QPP259Elements.Diameter_Of_Aortic_Aneurysm_Between_5_5_5_9_Cm
            )
              ||
              wasDiagnositicStudyPerformedBeforeEncounter(visit, m
                , QPP259Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
                , patientHistoryBroadcastList
                , QPP259Elements.Diameter_Of_Aortic_Aneurysm_Of_At_Least_6_Cm)
            )
        )
        ||
        (
          isMale(visit, m)
            &&
            wasDiagnositicStudyPerformedBeforeEncounter(visit, m
              , QPP259Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
              , patientHistoryBroadcastList
              , QPP259Elements.Diameter_Of_Aortic_Aneurysm_Of_At_Least_6_Cm)
          )
        ||
        (
          isFemale(visit, m)
            &&
            wasDiagnosticStudyValueGreaterOrEqualBeforeProcedurePerformed(visit, m
              , QPP259Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
              , QPP259Elements.Diameter_Of_Aortic_Aneurysm
              , CompareOperator.GREATER_EQUAL
              , 5.5
              , patientHistoryBroadcastList)
            &&
            wasDiagnosticStudyValueGreaterOrEqualBeforeProcedurePerformed(visit, m
              , QPP259Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
              , QPP259Elements.Diameter_Of_Aortic_Aneurysm
              , CompareOperator.LESS_EQUAL
              , 5.9
              , patientHistoryBroadcastList)
          )
        ||
        (
          isMale(visit, m)
            &&
            wasDiagnosticStudyValueGreaterOrEqualBeforeProcedurePerformed(visit, m
              , QPP259Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
              , QPP259Elements.Diameter_Of_Aortic_Aneurysm
              , CompareOperator.GREATER_EQUAL
              , 6
              , patientHistoryBroadcastList)
          )
        ||
        (
          isFemale(visit, m)
            &&
            wasDiagnosticStudyValueGreaterOrEqualBeforeProcedurePerformed(visit, m
              , QPP259Elements.Evar_Of_Non_Ruptured_Infrarenal_Aaa
              , QPP259Elements.Diameter_Of_Aortic_Aneurysm
              , CompareOperator.GREATER_EQUAL
              , 6
              , patientHistoryBroadcastList)
          )
    )
  }


  // Numerator Criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        isEncounterPerformedOnEncounter(visit, m, QPP259Elements.Discharge_To_Home)
          ||
          (
            wasEncounterPerformedWithResultWithInXDays(visit, m
              , QPP259Elements.Discharged_To_Home
              , QPP259Elements.Same_Facility
              , CalenderUnit.DAY
              , 2
              , patientHistoryBroadcastList
            )
              ||
              wasEncounterPerformedWithResultWithInXDays(visit, m
                , QPP259Elements.Discharge_Following_Evar
                , QPP259Elements.Same_Facility
                , CalenderUnit.DAY
                , 2
                , patientHistoryBroadcastList
              )
              ||
              wasEncounterPerformedWithResultWithInXDays(visit, m
                , QPP259Elements.Transfer_To_Nursing_Facility
                , QPP259Elements.Same_Facility
                , CalenderUnit.DAY
                , 2
                , patientHistoryBroadcastList
              )
            )
        )
        &&
        !isEncounterPerformedOnEncounter(visit, m, QPP259Elements.Discharge_Not_Met)
    )
  }


}

