package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP454Elements}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp454
* Measure Title              :- Percentage of Patients who Died from Cancer with More than One Emergency Department Visit in the Last 30 Days of Life (lower score – better)
* Measure Description        :- Percentage of patients who died from cancer with more than one emergency department visit in the last 30 days of life
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sumit Kende
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp454 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "QPP454"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patinetHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP454Elements.Cancer,
      QPP454Elements.Office_Visit,
      QPP454Elements.Emergency_Department_Visit_Life,
      QPP454Elements.Emergency_Department_Visit_Life_Not_Met,
      QPP454Elements.Emergency_Department_Visit,
      QPP454Elements.Patient_Deceased_Cancer,
      QPP454Elements.Death_Due_To_Cancer
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patinetHistoryRDD.collect().toList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patinetHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {


      val denominatorRDD=ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      //      exclusionRDD.cache()

      // Filter Intermediate RDD
      //val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      //intermediateA.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patinetHistoryRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //Patients who died from cancer
  def getIpp(initialRDD: RDD[CassandraRow], patineHistoryRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    val countElementList: List[(String, Int)] = countElement(patineHistoryRDD, m, QPP454Elements.Office_Visit)
    initialRDD.filter(visit =>
      wasDiagnosedBeforeEncounter(visit, m, QPP454Elements.Cancer, patientHistoryList)
        && getEncounterCountFromHistory(visit, m, 2, true, countElementList)
        &&
        (
          isPatientCharacteristic(visit, m, QPP454Elements.Patient_Deceased_Cancer, patientHistoryList)
            || isPatientCharacteristic(visit, m, QPP454Elements.Death_Due_To_Cancer, patientHistoryList)
          )
    )
  }

  //Patients who died from cancer and had more than one emergency department visit in the last 30 days of life
  def getMet(ippRDD: RDD[CassandraRow], patineHistoryRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      (isEncounterPerformed(visit, m, QPP454Elements.Emergency_Department_Visit_Life, patientHistoryList)
        ||
        (
          wasCountGreaterThanXWithinXDays(visit, m, QPP454Elements.Death_Due_To_Cancer, QPP454Elements.Emergency_Department_Visit, 30, 1, patientHistoryList)
            || wasCountGreaterThanXWithinXDays(visit, m, QPP454Elements.Patient_Deceased_Cancer, QPP454Elements.Emergency_Department_Visit, 30, 1, patientHistoryList)
          ))
        && !isEncounterPerformed(visit, m, QPP454Elements.Emergency_Department_Visit_Life_Not_Met, patientHistoryList)
    )
  }

}
