package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP164Elements}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp164
* Measure Title              :- Coronary Artery Bypass Graft (CABG): Prolonged Intubation
* Measure Description        :- Percentage of patients aged 18 years and older undergoing isolated CABG surgery who require postoperative intubation > 24 hours
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp164 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp164"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryList = getPatientHistory(sparkSession, initialRDD,
      QPP164Elements.Coronary_Artery_Bypass_Graft,
      QPP164Elements.Cabg_Reoperation,
      QPP164Elements.Prolonged_Postoperative_Intubation,
      QPP164Elements.Prolonged_Intubation,
      QPP164Elements.Prolonged_Intubation_Not_Met
    ).collect().toList

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //All patients undergoing isolated CABG surgery
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isPatientAdult(visit, m)
        && isProcedurePerformedDuringEncounter(visit, m, QPP164Elements.Coronary_Artery_Bypass_Graft)
        ||
        (
          isProcedurePerformedDuringEncounter(visit, m, QPP164Elements.Coronary_Artery_Bypass_Graft)
            && isProcedurePerformedDuringEncounter(visit, m, QPP164Elements.Cabg_Reoperation)
          )
    )
  }

  //Patients undergoing isolated CABG who require intubation > 24 hours following exit from the operating room
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      isProcedurePerformedDuringEncounter(visit, m, QPP164Elements.Prolonged_Postoperative_Intubation)
        || wasProcedurePerformedAfterProcedureInXHours(visit, m, QPP164Elements.Prolonged_Intubation, QPP164Elements.Coronary_Artery_Bypass_Graft, 24, patientHistoryBroadcastList)
        && isProcedurePerformedDuringEncounter(visit, m, QPP164Elements.Prolonged_Intubation_Not_Met)
    )
  }

}
