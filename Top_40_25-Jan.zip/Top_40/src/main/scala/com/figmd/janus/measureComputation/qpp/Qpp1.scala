package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{QPP1Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalStartDate, globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 1
* Measure Title              :- Diabetes: Hemoglobin A1c (HbA1c) Poor Control (> 9%)
* Measure Description        :- Percentage of patients 18-75 years of age with diabetes who had hemoglobin A1c > 9.0% during the measurement period.
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Lower Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Ritesh Kolhe
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD, QPP1Elements.Diabetes, QPP1Elements.Hba1c_Laboratory_Test, QPP1Elements.Hba1c_Result, QPP1Elements.Hemoglobin_A1c_Level, QPP1Elements.Hemoglobin_Level, QPP1Elements.Hba1c_Level, QPP1Elements.Hemoglobin_A1c__Hba1c__Level, QPP1Elements.Hospice_Services, QPP1Elements.Hospice_Care, QPP1Elements.Hospice_Services_Snomedct)
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val mostRecentRDD = mostRecentPatientList(patientHistoryRDD: RDD[CassandraRow], QPP1Elements.Hba1c_Result, QPP1Elements.Hba1c_Level, QPP1Elements.Hemoglobin_A1c__Hba1c__Level)
    val mostRecentBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(mostRecentRDD)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediate = getSubtractRDD(ippRDD, exclusionRDD)
      intermediate.cache()

      val metRDD = getMet(intermediate, patientHistoryBroadcastList: Broadcast[List[CassandraRow]], mostRecentBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exceptionRDD.cache()

      val notMetRDD = getSubtractRDD(intermediate, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      mostRecentBroadcastList.destroy()
    }

  }


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
        isAgeBetween(visit, m, 18, 76)
          && isVisitTypeIn(visit, m
          , QPP1Elements.Medical_Nutrition_Therapy
          , QPP1Elements.Initial_Preventive_Physical_Examination
          , QPP1Elements.Critical_Care
          , QPP1Elements.Annual_Nursing_Facility_Assessment
          , QPP1Elements.Office_Visit
          , QPP1Elements.Home_Healthcare_Services
          , QPP1Elements.Face_To_Face_Interaction
          , QPP1Elements.Annual_Wellness_Visit
          , QPP1Elements.Preventive_Care_Services_Initial_Office_Visit__18_And_Up
          , QPP1Elements.Preventive_Care_Services___Established_Office_Visit__18_And_Up
          , QPP1Elements.Discharge_Services__Observation_Care
          , QPP1Elements.Care_Services_In_Long_Term_Residential_Facility
          , QPP1Elements.Discharge_Services___Nursing_Facility
          , QPP1Elements.Nursing_Facility_Visit
          , QPP1Elements.Hospital_Inpatient_Visit___Initial
          , QPP1Elements.Discharge_Services___Hospital_Inpatient
          , QPP1Elements.Hospital_Observation_Care___Initial
          , QPP1Elements.Subsequent_Hospital_Care
          , QPP1Elements.Emergency_Department_Visit
        )
          && wasDiagnosedInHistory(visit, m, QPP1Elements.Diabetes, patientHistoryList)
    )
  }

  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit => isInterventionPerformed(visit, m, QPP1Elements.Hospice_Services, patientHistoryList)
      || wasInterventionPerformedInHistory(visit, m, QPP1Elements.Hospice_Services_Snomedct, patientHistoryList)
      || wasInterventionPerformedInHistory(visit, m, QPP1Elements.Hospice_Care, patientHistoryList)
    )
  }

  def getMet(ippRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]], mostRecentRDD: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
      isRecentLaboratoryTestResultGreaterThanValue(visit, m, QPP1Elements.Hba1c_Result, 9, "ge", mostRecentRDD) // Most recent hemoglobin A1c level > 9.0% . This is value based element
        || isRecentLaboratoryTestResultMissing(visit, m, QPP1Elements.Hba1c_Result, mostRecentRDD) // Most recent HbA1c level is missing a result . This is value based element|| wasLaboratoryTestPerformedInHistory(visit,m,QPP1Elements.Hemoglobin_A1c_Level,mostRecentRDD)                      // Most recent hemoglobin A1c level was > 9.0%. This is code based element
        || wasLaboratoryTestPerformedInHistory(visit, m, QPP1Elements.Hemoglobin_Level, mostRecentRDD) // Indicates if hemoglobin A1c level was not performed during the measurement period. This is code based element
        &&
        (
          !(
            wasLaboratoryTestPerformedInHistory(visit, m, QPP1Elements.Hba1c_Level, mostRecentRDD) // Most recent hemoglobin A1c (HbA1c) level < 7.0% . This is code based element
              || wasLaboratoryTestPerformedInHistory(visit, m, QPP1Elements.Hemoglobin_A1c__Hba1c__Level, mostRecentRDD) // Most recent hemoglobin A1c (HbA1c) level 7.0 to 9.0% . This is code based element
            )
          )

    )
  }


}