
package com.figmd.janus.measureComputation.qpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP48Elements}
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 48
* Measure Title              :- Urinary Incontinence: Assessment of Presence or Absence of Urinary Incontinence in Women Aged 65 Years and Older
* Measure Description        :- Percentage of female patients aged 65 years and older who were assessed for the presence or absence of urinary incontinence within 12 months
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp48 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp48"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    //Backtracking List
    var patientHistoryRDD = getPatientHistory(sparkSession, ippRDD
      , QPP48Elements.Services_Hospice
      , QPP48Elements.Hospice_Services_Snomedct
      , QPP48Elements.Hospice_Care
      , QPP48Elements.Assessment_Of_Urinary_Incontinence
      , QPP48Elements.Urinary_Incontinence_Assessment
      , QPP48Elements.Presence_Or_Absence_Of_Urinary_Incontinence
      , QPP48Elements.Urinary_Incontinence
      , QPP48Elements.Urininc_Reason_Not_Specified).collect.toList
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
All female patients aged 65 years and older with a visit during the measurement period
----------------------------------------------------------------------------------------------------------------------------*/


  def getIpp(rdd:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
           isFemale(visit,m)
        && isAgeAbove(visit, m,true,65)
        && isVisitTypeIn(visit,m
            ,QPP48Elements.Office_Visit
            ,QPP48Elements.Home_Healthcare_Services
            ,QPP48Elements.Initial_Preventive_Physical_Examination
            ,QPP48Elements.Care_Services_In_Long_Term_Residential_Facility)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Patient use of hospice services any time during the measurement period
----------------------------------------------------------------------------------------------------------------------------*/

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,EXCLUSION,globalStartDate,globalEndDate)

    ippRDD.filter(visit =>
            isInterventionPerformed(visit,m,QPP48Elements.Services_Hospice,patientHistoryList)
        ||  wasInterventionPerformedInHistory(visit,m,QPP48Elements.Hospice_Services_Snomedct,patientHistoryList)
        ||  wasInterventionPerformedInHistory(visit,m,QPP48Elements.Hospice_Care,patientHistoryList)
    )
  }


  /*-------------------------------------------------------------------------------------------------------------------------
Patients who were assessed for the presence or absence of urinary incontinence within 12 months
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      (     wasAssessmentPerformedInXMonths(visit,m,AdminElements.Encounter_Date,QPP48Elements.Assessment_Of_Urinary_Incontinence,12,patientHistoryList)
        ||    (    wasAssessmentPerformedAfterEncounterWithInXMonths(visit,m,AdminElements.Encounter_Date,QPP48Elements.Assessment_Of_Urinary_Incontinence,12,patientHistoryList)
                && isAssessmentPerformed(visit,m,QPP48Elements.Assessment_Of_Urinary_Incontinence,patientHistoryList)
              )
        ||  wasAssessmentPerformedInXMonths(visit,m,AdminElements.Encounter_Date,QPP48Elements.Urinary_Incontinence_Assessment,12,patientHistoryList)
        ||    (    wasAssessmentPerformedAfterEncounterWithInXMonths(visit,m,AdminElements.Encounter_Date,QPP48Elements.Urinary_Incontinence_Assessment,12,patientHistoryList)
                && isAssessmentPerformed(visit,m,QPP48Elements.Urinary_Incontinence_Assessment,patientHistoryList)
              )
        ||  wasAssessmentPerformedInXMonths(visit,m,AdminElements.Encounter_Date,QPP48Elements.Presence_Or_Absence_Of_Urinary_Incontinence,12,patientHistoryList)
        ||    (    wasAssessmentPerformedAfterEncounterWithInXMonths(visit,m,AdminElements.Encounter_Date,QPP48Elements.Presence_Or_Absence_Of_Urinary_Incontinence,12,patientHistoryList)
                && isAssessmentPerformed(visit,m,QPP48Elements.Presence_Or_Absence_Of_Urinary_Incontinence,patientHistoryList)
              )
        ||  wasDiagnosedInXMonths(visit,m,AdminElements.Encounter_Date,QPP48Elements.Urinary_Incontinence,12,patientHistoryList)
        ||    (    wasDiagnosedAfterEncounterWithInXMonths(visit,m,AdminElements.Encounter_Date,QPP48Elements.Urinary_Incontinence,12,patientHistoryList)
                && isDiagnosis(visit,m,QPP48Elements.Urinary_Incontinence,patientHistoryList)
              )
      )
      && ! isAssessmentPerformed(visit,m,QPP48Elements.Urininc_Reason_Not_Specified,patientHistoryList)
    )
  }
}
