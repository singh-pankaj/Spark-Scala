
package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, QPP464Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 464
* Measure Title              :- Otitis Media with Effusion (OME): Systemic Antimicrobials – Avoidance of Inappropriate Use
* Measure Description        :- Percentage of patients aged 2 months through 12 years with a diagnosis of OME who were not prescribed systemic antimicrobials
* Calculation Implementation :- Episode-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp464 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp464"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP464Elements.Otitis_Media_With_Effusion,
      QPP464Elements.Preventive_Care__Initial_Office_Visit_0_To_17_Telehealth_Modifier,
      QPP464Elements.Outpatient_Consultation_Telehealth_Modifier,
      QPP464Elements.Preventive_Medicine_Reevaluation_Telehealth_Modifier,
      QPP464Elements.Office_Visit_Telehealth_Modifier,
      QPP464Elements.Systemic_Antimicrobial_Not_Met,
      QPP464Elements.Acute_Pharyngitis,
      QPP464Elements.Otitis_Media_With_Effusion
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Intermediate for Met
      val intermediateMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateMet.cache()
      // Filter Met
      val metRDD = getMet(intermediateMet, patientHistoryBroadcastList)
       metRDD.cache()
      // Filter Intermediate for Exception
      val intermediateException = getSubtractRDD(intermediateMet, metRDD)
      intermediateException.cache()
      // Filter Exceptions
      val exceptionRDD = getException(intermediateException, patientHistoryBroadcastList)
        exceptionRDD.cache()
      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
         notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  /*-----------------------------------------------------------------------------------------
   All patients aged 2 months through 12 years with a diagnosis of OME
   -----------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 2, CalenderUnit.MONTH)
        && isAgeBelowBeforeStart(visit, m, false, 13, CalenderUnit.YEAR)
        && isVisitTypeIn(visit, m, QPP464Elements.Office_Visit,
        QPP464Elements.Outpatient_Consultation,
        QPP464Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,
        QPP464Elements.Preventive_Care__Established_Office_Visit__0_To_17)
        && wasDiagnosedBeforeEncounter(visit, m, QPP464Elements.Otitis_Media_With_Effusion, patientHistoryList)
        && !(
        isEncounterPerformed(visit, m, QPP464Elements.Preventive_Care__Initial_Office_Visit_0_To_17_Telehealth_Modifier, patientHistoryList)
          || isEncounterPerformed(visit, m, QPP464Elements.Outpatient_Consultation_Telehealth_Modifier, patientHistoryList)
          || isEncounterPerformed(visit, m, QPP464Elements.Preventive_Medicine_Reevaluation_Telehealth_Modifier, patientHistoryList)
          || isEncounterPerformed(visit, m, QPP464Elements.Office_Visit_Telehealth_Modifier, patientHistoryList)
        )
        && isPOSEncounterNotPerformed(visit, m, QPP464Elements.Pos_02)
    )
  }


  /*----------------------------------------------------------------------------------------
   Patients who were not prescribed systemic antimicrobials
   -----------------------------------------------------------------------------------------*/

  def getMet(intermediateMet: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateMet.filter(visit =>
      (
        isMedicationOrderedDuringEncounter(visit, m, QPP464Elements.Systemic_Antimicrobials_Met)
          || !isMedicationOrderedDuringEncounter(visit, m, QPP464Elements.Systemic_Antimicrobial_Therapy)
        )
        && !wasMedicationDuringDiagnosisInHistory(visit, m, QPP464Elements.Systemic_Antimicrobial_Not_Met, patientHistoryList, QPP464Elements.Otitis_Media_With_Effusion)
    )
  }

  /*---------------------------------------------------------------------------------------------------------------------------------------------
    Documentation of medical reason(s) or acute pharyngitis for prescribing systemic antimicrobials
   ---------------------------------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateException: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      isMedicationOrderedDuringEncounter(visit, m, QPP464Elements.Systemic_Antimicrobial_Medical_Reason)
        || wasDiagnosisOverlapsDiagnosisInHistory(visit, m, QPP464Elements.Acute_Pharyngitis, QPP464Elements.Otitis_Media_With_Effusion, patientHistoryList)
    )
  }
}