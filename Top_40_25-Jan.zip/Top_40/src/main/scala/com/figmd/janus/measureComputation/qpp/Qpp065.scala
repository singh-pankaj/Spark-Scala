package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{QPP065Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 65
* Measure Title              :- Appropriate Treatment for Children with Upper Respiratory Infection (URI)
* Measure Description        :- Percentage of children 3 months-18 years of age who were diagnosed with upper respiratory infection (URI) and
*                               were not dispensed an antibiotic prescription on or three days after the episode
* Calculation Implementation :- Episode-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp065 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp065"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    var patientHistoryRDD = getPatientHistory(sparkSession, initialRDD,
      QPP065Elements.Hospice_Services_Snomedct,
      QPP065Elements.Hospice_Care,
      QPP065Elements.Competing_Conditions_For_Respiratory_Conditions,
      QPP065Elements.Antibiotic_Medication_For_Pharyngitis,
      QPP065Elements.Upper_Respiratory_Infection,
      QPP065Elements.Upper_Respiratory_Infection_Date,
      QPP065Elements.Antibiotic_Medication_For_Pharyngitis,
      QPP065Elements.Antibiotic_Prescribed_Or_Dispensed__Met,
      QPP065Elements.Antibiotic_Prescribed_Or_Dispensed__Not_Met

    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRdd(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }
  //Children age 3 months to 18 years who had an outpatient or emergency department (ED) visit with a diagnosis of upper respiratory infection (URI) during the measurement period
  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    rdd.filter(visit =>
                          isAgeBetween(visit,m,3,19)
                      && 	isVisitTypeIn(visit,m,
                                                QPP065Elements.Discharge_Services__Observation_Care,
                                                QPP065Elements.Initial_Preventive_Physical_Examination,
                                                QPP065Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17,
                                                QPP065Elements.Preventive_Care__Established_Office_Visit__0_To_17,
                                                QPP065Elements.Office_Visit,
                                                QPP065Elements.Hospital_Observation_Care___Initial,
                                                QPP065Elements.Face_To_Face_Interaction,
                                                QPP065Elements.Emergency_Department_Visit
                                        )
                      &&  isDiagnosisOnEncounter(visit,m,QPP065Elements.Upper_Respiratory_Infection)

    )
  }


  //Patient prescribed or dispensed antibiotic for documented medical reason(s) within three days after the initial diagnosis of URI (e.g., intestinal infection, pertussis, bacterial infection, Lyme disease, otitis media, acute sinusitis, acute pharyngitis, acute tonsillitis, chronic sinusitis, infection of the pharynx/larynx/tonsils/adenoids, prostatitis, cellulitis, mastoiditis, or bone infections, acute lymphadenitis, impetigo, skin staph infections, pneumonia/gonococcal infections, venereal disease (syphilis, chlamydia, inflammatory diseases [female reproductive organs]), infections of the kidney, cystitis or UTI, and acne.
  //OR
  //Children who are taking antibiotics in the 30 days prior to the date of the encounter during which the diagnosis was established.
  //
  //OR
  //Patients who use hospice services any time during the measurement period.

  def getExclusionRdd(ippRDD: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>
                              (
                                    isDiagnosisOnEncounter(visit,m,QPP065Elements.Antibiotic_Medical_Reason)
                                ||  isProcedurePerformedDuringEncounter(visit,m,QPP065Elements.Hospice_Services)
                                ||  isMedicationActiveDuringEncounter(visit, m,QPP065Elements.Antibiotics)
                              )
                           ||
                              (
                                    wasInterventionPerformedInHistory(visit,m,QPP065Elements.Hospice_Services_Snomedct,patientHistoryBroadcastList)
                                ||  wasInterventionPerformedInHistory(visit,m,QPP065Elements.Hospice_Care,patientHistoryBroadcastList)
                              )
                           ||  wasMedicationStartsAfterEncounterWithReasonBetweenPeriod(visit,m,AdminElements.Encounter_Date,QPP065Elements.Antibiotic_Medication_For_Pharyngitis,QPP065Elements.Competing_Conditions_For_Respiratory_Conditions,3,CalenderUnit.DAY,patientHistoryBroadcastList)
                              ||
                              (
                                    wasMedicationStartsBeforeEncounterWithReasonBetweenPeriod(visit,m,QPP065Elements.Upper_Respiratory_Infection_Date,QPP065Elements.Antibiotic_Medication_For_Pharyngitis,QPP065Elements.Competing_Conditions_For_Respiratory_Conditions,30,CalenderUnit.DAY,patientHistoryBroadcastList)
                                &&  wasMedicationActiveStartsBeforeInXDays(visit,m,QPP065Elements.Upper_Respiratory_Infection,1,CompareOperator.GREATER_EQUAL,patientHistoryBroadcastList,Seq(QPP065Elements.Antibiotic_Medication_For_Pharyngitis))

                              )



                 )
  }

//Children without a prescription for antibiotic medication on or 3 days after the outpatient or ED visit for an upper respiratory infection
  def getMet(intermediateA: RDD[CassandraRow],patientHistoryBroadcastList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
                              (
                                     wasAssessmentStartsAfterEncounterInXDays(visit,m,AdminElements.Encounter_Date,QPP065Elements.Antibiotic_Prescribed_Or_Dispensed__Met,3,patientHistoryBroadcastList)
                                ||  !wasMedicationStartsAfterEncounterInXDays(visit,m,AdminElements.Encounter_Date,QPP065Elements.Antibiotic_Medication_For_Pharyngitis,3,patientHistoryBroadcastList)
                              )
                              && ! wasAssessmentStartsAfterEncounterInXDays(visit,m,AdminElements.Encounter_Date,QPP065Elements.Antibiotic_Prescribed_Or_Dispensed__Not_Met,3,patientHistoryBroadcastList)
    )
  }



}

