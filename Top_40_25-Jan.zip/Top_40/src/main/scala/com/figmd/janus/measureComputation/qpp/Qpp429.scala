package com.figmd.janus.measureComputation.qpp


import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ MeasureProperty, ECQM137V7Elements, _}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp429
* Measure Title              :- Pelvic Organ Prolapse: Preoperative Screening for Uterine Malignancy
* Measure Description        :- Percentage of patients who are screened for uterine malignancy prior to vaginal closure or obliterative surgery for pelvic organ prolapse
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp429 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp429"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()


    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      val patientHistoryRDD = getPatientHistory(sparkSession, ippRDD,
        QPP429Elements.Obliterative_Procedure_Or_Vaginal_Closure,
        QPP429Elements.Prior_Hysterectomy_1,
        QPP429Elements.Prior_Hysterectomy_2,
        QPP429Elements.Uterine_Malignancy_Screening,
        QPP429Elements.Uterine_Malignancy_Or_Ultrasound_Or_Endometrial_Sampling
      ).collect().toList

      val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD)
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
          denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = getExclusionRDD(denominatorRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(denominatorRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }

  //All patients undergoing surgery for pelvic organ prolapse involving vaginal closure/ obliterative procedure
  def getIpp(rdd: RDD[CassandraRow]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)
    rdd.filter(visit =>
            isFemale(visit,m)
        && isProcedurePerformedDuringEncounter(visit,m,QPP429Elements.Obliterative_Procedure_Or_Vaginal_Closure)

    )
  }

  //Patients who have had a hysterectomy
  def getExclusionRDD(ippRDD: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
              wasProcedurePerformedInHistory(visit,m,QPP429Elements.Prior_Hysterectomy_1,patientHistoryList)
        ||    wasProcedurePerformedEndsBeforeStartOf(visit,m,QPP429Elements.Obliterative_Procedure_Or_Vaginal_Closure,patientHistoryList,QPP429Elements.Prior_Hysterectomy_2)



    )
  }

  //Number of patients screened for uterine malignancy or those that had an ultrasound and/or endometrial sampling of any kind
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
      (
        (
                isProcedurePerformed(visit,m,QPP429Elements.Uterine_Malignancy_Screening,patientHistoryList)
            &&  wasProcedurePerformedEndsBeforeStartOf(visit,m,QPP429Elements.Obliterative_Procedure_Or_Vaginal_Closure,patientHistoryList,QPP429Elements.Uterine_Malignancy_Screening)
          )
          ||
          (
                  isInterventionPerformed(visit,m,QPP429Elements.Uterine_Malignancy_Or_Ultrasound_Or_Endometrial_Sampling,patientHistoryList)
              && wasInterventionPerformedEndsBeforeStartOfProcedure(visit,m,QPP429Elements.Obliterative_Procedure_Or_Vaginal_Closure,patientHistoryList,QPP429Elements.Uterine_Malignancy_Or_Ultrasound_Or_Endometrial_Sampling)
            )
        )
        && !wasProcedurePerformedEndsBeforeStartOf(visit,m,QPP429Elements.Obliterative_Procedure_Or_Vaginal_Closure,patientHistoryList,QPP429Elements.Uterine_Malignancy_Screening_Reason_Not_Specified)


    )

  }


}