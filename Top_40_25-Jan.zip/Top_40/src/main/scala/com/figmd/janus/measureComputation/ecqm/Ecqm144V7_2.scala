package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- ECQM 144
* Measure Title              :- Heart Failure (HF): Beta-Blocker Therapy for Left Ventricular Systolic Dysfunction (LVSD)
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of heart failure (HF)
*                               with a current or prior left ventricular ejection fraction (LVEF) < 40% who were prescribed
*                               beta-blocker therapy either within a 12-month period when seen in the outpatient
*                               setting OR at each hospital discharge
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 2
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/


object Ecqm144V7_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm144V_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , ECQM144V7Elements.Patient_Provider_Interaction
      , ECQM144V7Elements.Ejection_Fraction
      , ECQM144V7Elements.Moderate_Or_Severe_Lvsd
      , ECQM144V7Elements.Left_Ventricular_Systolic_Dysfunction
      , ECQM144V7Elements.Moderate_Or_Severe
      , ECQM144V7Elements.Beta_Blocker_Therapy_For_Lvsd
      , ECQM144V7Elements.Heart_Rate
      , ECQM144V7Elements.Heart_Rate_2
      , ECQM144V7Elements.Medical_Reason
      , ECQM144V7Elements.Patient_Reason
      , ECQM144V7Elements.System_Reason_2018
      , ECQM144V7Elements.Arrhythmia
      , ECQM144V7Elements.Hypotension
      , ECQM144V7Elements.Asthma
      , ECQM144V7Elements.Allergy_To_Beta_Blocker_Therapy
      , ECQM144V7Elements.Intolerance_To_Beta_Blocker_Therapy
      , ECQM144V7Elements.Bradycardia
      , ECQM144V7Elements.Beta_Blocker_Therapy_Ingredient
      , ECQM144V7Elements.Atrioventricular_Block
      , ECQM144V7Elements.Cardiac_Pacer_In_Situ
      , ECQM144V7Elements.Cardiac_Pacer
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {


      // Eligible IPP
      val denominatorRDD = getEligibleIpp(ippRDD, patientHistoryBroadcastList)
      denominatorRDD.cache()

      // Filter Exclusions
      /*val notEligibleRDD = ippRDD.subtract(eligibleRdd)
      notEligibleRDD.cache()*/

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Exceptions
      val intermediate = getSubtractRDD(denominatorRDD, metRDD)
      intermediate.cache()

      val mostRecentHFBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getHistoryMostRecentDateOfElement(patientHistoryRDD, MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate), ECQM144V7Elements.Heart_Rate_2))

      val exceptionRDD = getExceptionRDD(intermediate, patientHistoryBroadcastList, mostRecentHFBroadcastList)
      exceptionRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediate, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      mostRecentHFBroadcastList.destroy()
    }
  }


  // IPP Criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 18, CalenderUnit.YEAR)
        &&
        isVisitTypeIn(visit, m, ECQM144V7Elements.Discharge_Services___Hospital_Inpatient)
        &&
        wasDiagnosedBeforeEncounter(visit, m, ECQM144V7Elements.Heart_Failure, patientHistoryBroadcastList)
    )
  }

  // Denominator Criteria
  def getEligibleIpp(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      wasDiagnosticStudyPerformedBeforeOrEqualEncounterWithResult(visit, m, ECQM144V7Elements.Ejection_Fraction, 40, CompareOperator.LESS, patientHistoryBroadcastList)
        ||
        wasDiagnosisBeforeOrEqualEncounter(visit, m, patientHistoryBroadcastList, ECQM144V7Elements.Moderate_Or_Severe_Lvsd)
        ||
        wasDiagnosisBeforeOrEqualEncounterWithResult(visit, m, ECQM144V7Elements.Left_Ventricular_Systolic_Dysfunction, ECQM144V7Elements.Moderate_Or_Severe, patientHistoryBroadcastList)
    )
  }


  // Numerator Criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      wasMedicationActiveBeforeOrEqualEncounter(visit, m, ECQM144V7Elements.Beta_Blocker_Therapy_For_Lvsd, patientHistoryBroadcastList)
    )
  }


  //Denominator Exception Criteria
  def getExceptionRDD(intermediate: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], mostRecentHFBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediate.filter(visit =>
      (
        wasMostRecentPhysicalExamBeforePhysicalExamPerformed(visit, m, ECQM144V7Elements.Heart_Rate, ECQM144V7Elements.Heart_Rate_2, patientHistoryBroadcastList, mostRecentHFBroadcastList)
          &&
          isPhysicalExamPerformedWithResultDuringEncounter(visit, m, ECQM144V7Elements.Heart_Rate, 50, CompareOperator.LESS)
          &&
          isPhysicalExamPerformedWithResultDuringEncounter(visit, m, ECQM144V7Elements.Heart_Rate_2, 50, CompareOperator.LESS)
        )
        ||
        (
          isMedicationOrderNotDone(visit, m, ECQM144V7Elements.Medical_Reason, patientHistoryBroadcastList)
            ||
            isMedicationOrderNotDone(visit, m, ECQM144V7Elements.Patient_Reason, patientHistoryBroadcastList)
            ||
            isMedicationOrderNotDone(visit, m, ECQM144V7Elements.System_Reason_2018, patientHistoryBroadcastList)
          )
        ||
        (
          wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Arrhythmia, patientHistoryBroadcastList)
            ||
            wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Hypotension, patientHistoryBroadcastList)
            ||
            wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Asthma, patientHistoryBroadcastList)
            ||
            wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Allergy_To_Beta_Blocker_Therapy, patientHistoryBroadcastList)
            ||
            wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Intolerance_To_Beta_Blocker_Therapy, patientHistoryBroadcastList)
            ||
            wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Bradycardia, patientHistoryBroadcastList)
            ||
            wasMedicationAllergyInHistory(visit, m, ECQM144V7Elements.Beta_Blocker_Therapy_Ingredient, patientHistoryBroadcastList)
          )
        ||
        wasDiagnosisInHistory(visit, m, ECQM144V7Elements.Atrioventricular_Block, patientHistoryBroadcastList)
        ||
        (
          !wasDiagnosisBeforeOrEqualEncounter(visit, m, patientHistoryBroadcastList, ECQM144V7Elements.Cardiac_Pacer_In_Situ)
            &&
            !wasDiagnosisBeforeOrEqualEncounter(visit, m, patientHistoryBroadcastList, ECQM144V7Elements.Cardiac_Pacer)
          )
    )

  }
}