package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, MeasureProperty, QPP461Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp461
* Measure Title              :- Average Change in Leg Pain Following Lumbar Discectomy and/or Laminotomy
* Measure Description        :- The average change (preoperative to three months postoperative) in leg pain for patients
*                               18 years of age or older who had a lumbar discectomy/laminotomy procedure
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher score indicates a better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- NA
* Measure Stratification     :- 2
* Measure Developer          :- Sumant Kulkarni
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp461_1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp461_1"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    var patientHistoryRDD = getPatientHistory(sparkSession,initialRDD
      , QPP461Elements.Herniated_Disc
      , QPP461Elements.Lumbar_Disectomy__Laminotomy
      , QPP461Elements.Leg_Pain_Vas
      , QPP461Elements.Lumbar_Disectomy__Laminotomy_Date
      , QPP461Elements.Leg_Pain_Measured
      , QPP461Elements.Pre_Operative_Vas_Score
      , QPP461Elements.Post_Operative_Vas_Score
      , QPP461Elements.Leg_Pain_Vas_Not_Met
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    val ippRDD = getIpp(initialRDD,patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      // Filter Exceptions
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()
      val intermediateRDD = getSubtractRDD(ippRDD,exclusionRDD)
          intermediateRDD.cache()
      val metRDD = getMet(intermediateRDD, patientHistoryBroadcastList)
          metRDD.cache()
      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateRDD, metRDD)
      notMetRDD.cache()
      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }



  /*-----------------------------------------------------------------------------------------------------------------------
Patients 18 years of age or older as of January 1 of the denominator identification period who had a lumbar
discectomy/laminotomy procedure for a diagnosis of disc herniation performed during the denominator identification
period
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(rdd: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)

    rdd.filter(visit =>
          isPatientAdult(visit, m)
        &&
          wasDiagnosedInHistory(visit, m, QPP461Elements.Herniated_Disc, patientHistoryBroadcastList)
        &&
          wasProcedurePerformedBeforeStartBetweenMonths(visit, m, QPP461Elements.Lumbar_Disectomy__Laminotomy,
            CalenderUnit.MONTH, 12, CalenderUnit.MONTH, 0, patientHistoryBroadcastList)
    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
Patient had any additional spine procedures performed on the same date as the lumbar
discectomy/laminotomy
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    ippRDD.filter(visit =>
        isProcedurePerformedDuringProcedure(visit, m,
                  QPP461Elements.Additional_Spinal_Procedure, QPP461Elements.Additional_Spinal_Procedure_Date,
                  QPP461Elements.Lumbar_Disectomy__Laminotomy, QPP461Elements.Lumbar_Disectomy__Laminotomy_Date)
      ||
        isProcedurePerformedDuringProcedure(visit, m,
                  QPP461Elements.Additional_Spine_Procedures, QPP461Elements.Additional_Spine_Procedures_Date,
                  QPP461Elements.Lumbar_Disectomy__Laminotomy, QPP461Elements.Lumbar_Disectomy__Laminotomy_Date)
    )
  }


  /*-----------------------------------------------------------------------------------------------------------------------
All eligible patients whose leg pain was measured by the Visual Analog Scale (VAS) within three months
preoperatively AND at three months (6 to 20 weeks) postoperatively
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateRDD.filter(visit =>
      (
          wasAssessmentPerformedStartAfterEndOfProcedurePerformed(visit, m, QPP461Elements.Leg_Pain_Vas,
                      patientHistoryBroadcastList, QPP461Elements.Lumbar_Disectomy__Laminotomy_Date)
        ||
          (
              wasAssessmentPerformedInXMonthsBeforeProcedure(visit, m, QPP461Elements.Lumbar_Disectomy__Laminotomy,
                          QPP461Elements.Leg_Pain_Measured, 3,
                          12, 0, patientHistoryBroadcastList)
            &&
              wasAssessmentPerformedInXMonthsBeforeProcedure(visit, m, QPP461Elements.Lumbar_Disectomy__Laminotomy,
                          QPP461Elements.Pre_Operative_Vas_Score, 3,
                          12, 0, patientHistoryBroadcastList)
            &&
               wasAssessmentPerformedInXWeeksAfterProcedureWithResult(visit, m,
                          QPP461Elements.Lumbar_Disectomy__Laminotomy, QPP461Elements.Leg_Pain_Measured,
                          QPP461Elements.Leg_Pain_Measured, CalenderUnit.WEEK, 6,
                 CalenderUnit.MONTH, 0,
                 CalenderUnit.MONTH, 12, patientHistoryBroadcastList)
            && !
              wasAssessmentPerformedInXWeeksAfterProcedureWithResult(visit, m,
                          QPP461Elements.Lumbar_Disectomy__Laminotomy, QPP461Elements.Leg_Pain_Measured,
                          QPP461Elements.Leg_Pain_Measured, CalenderUnit.WEEK, 20,
                CalenderUnit.MONTH, 0,
                CalenderUnit.MONTH, 12, patientHistoryBroadcastList)
            &&
              wasAssessmentPerformedInXWeeksAfterProcedure(visit, m,
                          QPP461Elements.Lumbar_Disectomy__Laminotomy, QPP461Elements.Post_Operative_Vas_Score,
                CalenderUnit.WEEK, 6,
                CalenderUnit.MONTH, 0,
                CalenderUnit.MONTH, 12, patientHistoryBroadcastList)
            && !
              wasAssessmentPerformedInXWeeksAfterProcedure(visit, m,
                          QPP461Elements.Lumbar_Disectomy__Laminotomy, QPP461Elements.Post_Operative_Vas_Score,
                CalenderUnit.WEEK, 20,
                CalenderUnit.MONTH, 0,
                CalenderUnit.MONTH, 12, patientHistoryBroadcastList)
          )
        )
        &&
          wasAssessmentPerformedInXWeeksAfterProcedure(visit, m,
                        QPP461Elements.Lumbar_Disectomy__Laminotomy, QPP461Elements.Leg_Pain_Vas_Not_Met,
            CalenderUnit.WEEK, 0,
            CalenderUnit.MONTH, 0,
            CalenderUnit.MONTH, 12, patientHistoryBroadcastList)
    )

  }

}

