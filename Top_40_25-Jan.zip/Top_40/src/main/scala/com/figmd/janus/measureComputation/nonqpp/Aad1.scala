
package com.figmd.janus.measureComputation.nonqpp

import java.util.Date

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master.{AAD1Elements, AdminElements, CalenderUnit, MeasureProperty}
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AAD 1
* Measure Title              :- Psoriasis: Assessment of Psoriasis Disease Activity
* Measure Description        :- Percentage of patients with plaque psoriasis who have disease activity assessed by using one of the listed measures or validated instruments/ tools* at least once during the measurement period.
                                Assessment and classification of disease activity using standardized descriptive measures or tools resulting in a numeric score or composite index:
                                Scales and instruments are examples and cut‐points can differ by scale. Standardized descriptive or numeric scales and/or composite indexes include: Psoriasis Area and Severity Index (PASI), Body Surface Area (BSA), Physician’s Global Assessment (PGA), Dermatology Life Quality Index (DLQI).
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Aad1 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Aad1"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD:RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Backtracking List
      var getPatientHistoryList = getPatientHistory(sparkSession, ippRDD
        , AAD1Elements.Psoriasis_Area_And_Severity_Index__Pasi__Grp
        , AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Pasi_Grp
        , AAD1Elements.Body_Surface_Area__Bsa__Value_Grp
        , AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Bsa_Value_Grp
        , AAD1Elements.Body_Surface_Area__Bsa__Range_Grp
        , AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Bsa_Range_Grp
        , AAD1Elements.Pga_5_Point_Scale_Grp
        , AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Pga_5_Point_Scale_Grp
        , AAD1Elements.Pga_6_Point_Scale_Grp
        , AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Pga_6_Point_Scale_Grp
        , AAD1Elements.Pga_7_Point_Scale_Grp
        , AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Pga_7_Point_Scale_Grp
        , AAD1Elements.Dermatology_Life_Quality_Index__Dlqi__Grp
        , AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Dlqi_Grp).collect.toList
      val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(getPatientHistoryList)

      // denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Met
      val metRDD = getMet(ippRDD, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
All patients with a diagnosis of plaque psoriasis
Patients who meet each of the following criteria are included in the population:
• Patient aged 18 years or older at the start of the measurement period.
• Patient had an outpatient face to face encounter
• Patient had diagnosis of psoriasis
----------------------------------------------------------------------------------------------------------------------------*/

  // Filter IPP
  def getIpp(initialRDD:RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    initialRDD.filter(visit =>
          isAgeAboveBeforeStart(visit,m,true,18,CalenderUnit.YEAR)
      &&  isVisitTypeIn(visit,m,AAD1Elements.Office_Visit)
      &&  isDiagnosedOnEncounter(visit,m,AAD1Elements.Plaque_Psoriasis__Psoriasis_Vulgaris_)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
A psoriasis patient’s disease activity is assessed and documented in the medical record using any of the listed measures or validated instruments/ tools at least once during the measurement period.
Tools for Assessing Psoriasis Disease Activity:
Any one of the following tools may be used to assess the patient’s disease activity
1. Psoriasis Area and Severity Index (PASI)
2. Body Surface Area (BSA) Value
3. Body Surface Area (BSA) Range
4. Physician’s Global Assessment (PGA) 5 point scale
5. Physician’s Global Assessment (PGA) 6 point scale
6. Physician’s Global Assessment (PGA) 7 point scale
7. Dermatology Life Quality Index (DLQI)
----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow],patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>
          isAssessmentPerformed(visit,m,AAD1Elements.Psoriasis_Area_And_Severity_Index__Pasi__Grp,patientHistoryList)
      ||  isAssessmentPerformed(visit,m,AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Pasi_Grp,patientHistoryList)
      ||  isAssessmentPerformed(visit,m,AAD1Elements.Body_Surface_Area__Bsa__Value_Grp,patientHistoryList)
      ||  isAssessmentPerformed(visit,m,AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Bsa_Value_Grp,patientHistoryList)
      ||  isAssessmentPerformed(visit,m,AAD1Elements.Body_Surface_Area__Bsa__Range_Grp,patientHistoryList)
      ||  isAssessmentPerformed(visit,m,AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Bsa_Range_Grp,patientHistoryList)
      ||  isAssessmentPerformed(visit,m,AAD1Elements.Pga_5_Point_Scale_Grp,patientHistoryList)
      ||  isAssessmentPerformed(visit,m,AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Pga_5_Point_Scale_Grp,patientHistoryList)
      ||  isAssessmentPerformed(visit,m,AAD1Elements.Pga_6_Point_Scale_Grp,patientHistoryList)
      ||  isAssessmentPerformed(visit,m,AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Pga_6_Point_Scale_Grp,patientHistoryList)
      ||  isAssessmentPerformed(visit,m,AAD1Elements.Pga_7_Point_Scale_Grp,patientHistoryList)
      ||  isAssessmentPerformed(visit,m,AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Pga_7_Point_Scale_Grp,patientHistoryList)
      ||  isAssessmentPerformed(visit,m,AAD1Elements.Dermatology_Life_Quality_Index__Dlqi__Grp,patientHistoryList)
      ||  isAssessmentPerformed(visit,m,AAD1Elements.Psoriasis_Disease_Activity_Assessment_Using_Dlqi_Grp,patientHistoryList)
    )
  }
}
