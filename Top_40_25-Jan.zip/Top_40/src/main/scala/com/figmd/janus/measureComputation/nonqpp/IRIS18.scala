package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, IRIS18Elements, MeasureProperty, QIM1Elements}
import com.figmd.janus.measureComputation.nonqpp.QIM1.wasCorrectedVisualAcuityValueGreaterXDays
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- IRIS18
* Measure Title               :- Chronic Anterior Uveitis - Post-treatment visual acuity
* Measure Description         :- Percentage of chronic anterior uveitis patients with a post-treatment best corrected visual acuity of 20/40 or better
                                 OR patients whose visual acuity had returned to their baseline value prior to onset of uveitis.Percentage
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- 1
* Measure Developer           :- RAHUL.GHONGATE
* Initial GIT Version/Tag(CRA):- Release_Notes_for_2019_Measures_SI_1.6
* Latest GIT Version/Tag(CRA) :- Release_Notes_for_2019_Measures_SI_1.6
----------------------------------------------------------------------------------------------------------------------------*/

object IRIS18 extends MeasureUtilityUpdate with MeasureUpdate {


  val MEASURE_NAME = "IRIS18"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryRDD
    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      ,IRIS18Elements.Chronic_Uveitis
      ,IRIS18Elements.Uveitis_Medications
      ,IRIS18Elements.Uveitis_Medications__Eye
      ,IRIS18Elements.Best_Corrected_Right_Eye_Va_Value
      ,IRIS18Elements.Best_Corrected_Left_Eye_Va_Value
      ,IRIS18Elements.Un_Corrected_Right_Eye_Va_Value
      ,IRIS18Elements.Un_Corrected_Left_Eye_Va_Value
      ,IRIS18Elements.Un_Specified_Right_Eye_Va_Value
      ,IRIS18Elements.Un_Specified_Left_Eye_Va_Value
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val correctVAValues: Array[String] = Array("20/10", "20/11", "20/12", "20/13", "20/14", "20/15", "20/16", "20/17", "20/18", "20/19", "20/2", "20/20", "20/21", "20/22", "20/23", "20/24", "20/25", "20/26", "20/28", "20/29", "20/3", "20/30", "20/31", "20/32", "20/33", "20/34", "20/35", "20/36", "20/37", "20/38", "20/39", "20/4", "20/5", "20/6", "20/7", "20/8", "20/9", "20/40")

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList,correctVAValues)
      metRDD.cache()

      //Filter Exception
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }

  /*-----------------------------------------------------------------------------------------------------------------------
All patients aged 18 years or greater who underwent treatment for chronic anterior uveitis.
-----------------------------------------------------------------------------------------------------------------------*/
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
              isPatientAdult(visit,m)
          &&  wasDiagnosedInHistory(visit,m,IRIS18Elements.Chronic_Uveitis,patientHistoryBroadcastList)
          &&  wasMedicationActiveBeforeEndWithinXDays(visit,m,IRIS18Elements.Uveitis_Medications_Date,92,patientHistoryBroadcastList)
          &&  checkEyeOnEncounterEqualsWithOtherEye(visit,m,true,IRIS18Elements.Uveitis_Medications__Eye,patientHistoryBroadcastList,Seq(IRIS18Elements.Chronic_Uveitis_Eye))
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with a best corrected visual acuity of 20/40 or better within 90 days of treatment initiation
OR
Patients whose visual acuity had returned to their baseline value prior to onset of acute uveitis within 90 days of treatment initiation
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],correctVAValues: Array[String]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>

            VisualAcuityReturnToBaseline(visit,m,IRIS18Elements.Uveitis_Medications,IRIS18Elements.Chronic_Uveitis,IRIS18Elements.Visual_Acuity,CalenderUnit.DAY,90,patientHistoryBroadcastList)
        &&
            (     wasCorrectedVisualAcuityValueGreaterXDays(visit, m, IRIS18Elements.Best_Corrected_Right_Eye_Va_Value,IRIS18Elements.Uveitis_Medications,90, correctVAValues, patientHistoryBroadcastList)
              ||  wasCorrectedVisualAcuityValueGreaterXDays(visit, m, IRIS18Elements.Best_Corrected_Left_Eye_Va_Value,IRIS18Elements.Uveitis_Medications,90, correctVAValues, patientHistoryBroadcastList)
              ||  wasCorrectedVisualAcuityValueGreaterXDays(visit, m, IRIS18Elements.Un_Corrected_Right_Eye_Va_Value,IRIS18Elements.Uveitis_Medications,90, correctVAValues, patientHistoryBroadcastList)
              ||  wasCorrectedVisualAcuityValueGreaterXDays(visit, m, IRIS18Elements.Un_Corrected_Left_Eye_Va_Value,IRIS18Elements.Uveitis_Medications,90, correctVAValues, patientHistoryBroadcastList)
              ||  wasCorrectedVisualAcuityValueGreaterXDays(visit, m, IRIS18Elements.Un_Specified_Right_Eye_Va_Value,IRIS18Elements.Uveitis_Medications,90, correctVAValues, patientHistoryBroadcastList)
              ||  wasCorrectedVisualAcuityValueGreaterXDays(visit, m, IRIS18Elements.Un_Specified_Left_Eye_Va_Value,IRIS18Elements.Uveitis_Medications,90, correctVAValues, patientHistoryBroadcastList)
            )
    )
  }

}
