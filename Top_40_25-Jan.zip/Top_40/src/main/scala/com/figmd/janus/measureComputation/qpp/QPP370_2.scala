package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{CalenderUnit, CompareOperator, MeasureProperty, QPP370Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- QPP370_2
* Measure Title               :- Depression Remission at Twelve Months
* Measure Description         :- The percentage of adolescent patients12 to 17 years of age and adult patients18 years of age or older
*                                with majordepression or dysthymia who reached remission 12 months (+/- 60 days) after an index event date
* Calculation Implementation  :- Patient-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 2
* Measure Stratum No.         :- NA
* Measure Stratification      :- 2
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.6
----------------------------------------------------------------------------------------------------------------------------*/

object QPP370_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "QPP370_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
          , QPP370Elements.Phq_9_Tool
          , QPP370Elements.Phq_9_Score
          , QPP370Elements.Phq_Score_Remission
          , QPP370Elements.Office_Visit
          , QPP370Elements.Medications_Encounter_Code_Set
          , QPP370Elements.Psych_Visit
          , QPP370Elements.Face_To_Face_Interaction___No_Ed
          , QPP370Elements.Telehealth_Services
          , QPP370Elements.Bipolar_Disorder
          , QPP370Elements.Personality_Disorder
          , QPP370Elements.Schizophrenia_Or_Psychotic_Disorder
          , QPP370Elements.Pervasive_Developmental_Disorder
          , QPP370Elements.Palliative_Care
          , QPP370Elements.Palliative_Care_Encounter
          , QPP370Elements.Hospice_Care
          , QPP370Elements.Hospice_Services
          , QPP370Elements.Care_Services_In_Long_Term_Residential_Facility
          , QPP370Elements.Permanent_Nursing_Home_Resident
          , QPP370Elements.Dysthymia
          , QPP370Elements.Major_Depression_Including_Remission
          , QPP370Elements.Phq__9_Score_Remission_Not_Met
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    val leastRecentAssessmentBroadcastList = sparkSession.sparkContext.broadcast(
                  leastRecentPatientList(patientHistoryRDD, QPP370Elements.Phq_9_Tool, QPP370Elements.Phq_9_Score))
    val mostRecentAssessmentBroadcastList = sparkSession.sparkContext.broadcast(
                  mostRecentPatientList(patientHistoryRDD, QPP370Elements.Phq_9_Tool, QPP370Elements.Phq_9_Score, QPP370Elements.Phq_Score_Remission))


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
      leastRecentAssessmentBroadcastList.destroy()
      mostRecentAssessmentBroadcastList.destroy()
    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
Adult patients aged 18 and older with a diagnosis of major depression or dysthymia and an initial PHQ-9 or PHQ-9M score greater than nine during the index event
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],
             leastRecentAssessmentBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(
      visit =>
        (
            isAgeAbove(visit, m, true, 18)
          &&
            (
                isAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, patientHistoryBroadcastList)
              ||
                wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Office_Visit, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Medications_Encounter_Code_Set, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Psych_Visit, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Face_To_Face_Interaction___No_Ed, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Telehealth_Services, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Office_Visit, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Medications_Encounter_Code_Set, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Psych_Visit, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Face_To_Face_Interaction___No_Ed, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Telehealth_Services, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            )
        )
        &&
        (
              isAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, patientHistoryBroadcastList)
            ||
              wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Office_Visit, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Medications_Encounter_Code_Set, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Psych_Visit, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Face_To_Face_Interaction___No_Ed, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Telehealth_Services, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Office_Visit, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Medications_Encounter_Code_Set, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Psych_Visit, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Face_To_Face_Interaction___No_Ed, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Telehealth_Services, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
        )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients with an active diagnosis of bipolar disorder any time prior to the end of the measure assessment period
OR
Patients with an active diagnosis of personality disorder any time prior to the end of the measure assessment period
OR
Patients with an active diagnosis of schizophrenia or psychotic disorder any time prior to the end of the measure assessment period
OR
Patients with an active diagnosis of pervasive developmental disorder any time prior to the end of the measure assessment period
OR
Patients who died any time prior to the end of the measure assessment period
OR
Patients who received hospice or palliative care service any time during denominator identification period or the measure assessment period
OR
Patients who were permanent nursing home residents any time during denominator identification period or the measure assessment period
-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],
                   leastRecentAssessmentBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
          wasDiagnosedInHistory(visit, m, QPP370Elements.Bipolar_Disorder, patientHistoryBroadcastList)
        ||
          wasDiagnosedInHistory(visit, m, QPP370Elements.Personality_Disorder, patientHistoryBroadcastList)
        ||
          wasDiagnosedInHistory(visit, m, QPP370Elements.Schizophrenia_Or_Psychotic_Disorder, patientHistoryBroadcastList)
        ||
          wasDiagnosedInHistory(visit, m, QPP370Elements.Pervasive_Developmental_Disorder, patientHistoryBroadcastList)
        ||
        (
            isAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, patientHistoryBroadcastList)
          ||
            wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Office_Visit, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
          ||
            wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Medications_Encounter_Code_Set, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
          ||
            wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Psych_Visit, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
          ||
            wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Face_To_Face_Interaction___No_Ed, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
          ||
            wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Telehealth_Services, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
          ||
            wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Office_Visit, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
          ||
            wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Medications_Encounter_Code_Set, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
          ||
            wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Psych_Visit, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
          ||
            wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Face_To_Face_Interaction___No_Ed, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
          ||
            wasDepressionAssessmentPerformed(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Telehealth_Services, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
        )
            //<TODO : Uncomment this block once the Patient_Expired element is available>
/*
        ||
        (
              wasPatientCharacteristicAfterXPeriodOfAssessment(visit, m, QPP370Elements.Patient_Expired, QPP370Elements.Phq_9_Score, 13, CalenderUnit.MONTH, patientHistoryBroadcastList)
            ||
              wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Office_Visit, QPP370Elements.Patient_Expired, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Medications_Encounter_Code_Set, QPP370Elements.Patient_Expired, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Psych_Visit, QPP370Elements.Patient_Expired, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Face_To_Face_Interaction___No_Ed, QPP370Elements.Patient_Expired, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Telehealth_Services, QPP370Elements.Patient_Expired, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Office_Visit, QPP370Elements.Patient_Expired, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Medications_Encounter_Code_Set, QPP370Elements.Patient_Expired, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Psych_Visit, QPP370Elements.Patient_Expired, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Face_To_Face_Interaction___No_Ed, QPP370Elements.Patient_Expired, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            ||
              wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Telehealth_Services, QPP370Elements.Patient_Expired, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
        )
*/
        ||
        (
            isInterventionOrdered(visit, m, QPP370Elements.Palliative_Care, patientHistoryBroadcastList)
          ||
            isEncounterPerformed(visit, m, QPP370Elements.Palliative_Care_Encounter, patientHistoryBroadcastList)
          ||
            isInterventionPerformed(visit, m, QPP370Elements.Hospice_Care, patientHistoryBroadcastList)
          ||
            isInterventionPerformed(visit, m, QPP370Elements.Hospice_Services, patientHistoryBroadcastList)
          ||
            isEncounterPerformed(visit, m, QPP370Elements.Care_Services_In_Long_Term_Residential_Facility, patientHistoryBroadcastList)
          ||
            (
                wasPatientCharacteristicAfterXPeriodOfAssessment(visit, m, QPP370Elements.Permanent_Nursing_Home_Resident, QPP370Elements.Phq_9_Score, 13, CalenderUnit.MONTH, patientHistoryBroadcastList)
              ||
                wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Office_Visit, QPP370Elements.Permanent_Nursing_Home_Resident, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Medications_Encounter_Code_Set, QPP370Elements.Permanent_Nursing_Home_Resident, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Psych_Visit, QPP370Elements.Permanent_Nursing_Home_Resident, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Face_To_Face_Interaction___No_Ed, QPP370Elements.Permanent_Nursing_Home_Resident, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Telehealth_Services, QPP370Elements.Permanent_Nursing_Home_Resident, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Office_Visit, QPP370Elements.Permanent_Nursing_Home_Resident, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Medications_Encounter_Code_Set, QPP370Elements.Permanent_Nursing_Home_Resident, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Psych_Visit, QPP370Elements.Permanent_Nursing_Home_Resident, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Face_To_Face_Interaction___No_Ed, QPP370Elements.Permanent_Nursing_Home_Resident, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
              ||
                wasPatientCharacteristicsInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Telehealth_Services, QPP370Elements.Permanent_Nursing_Home_Resident, patientHistoryBroadcastList, leastRecentAssessmentBroadcastList)
            )
        )
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Adult patients aged 18 and older who achieved remission at twelve months as demonstrated by a twelve month (+/- 60 days) PHQ-9 or PHQ-9M score of less than five
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]],
             leastRecentAssessmentBroadcastList: Broadcast[List[CassandraRow]],
             mostRecentAssessmentBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      (
        (
          (
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Office_Visit,
                  QPP370Elements.Phq_9_Tool, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Medications_Encounter_Code_Set,
                  QPP370Elements.Phq_9_Tool, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Psych_Visit,
                  QPP370Elements.Phq_9_Tool, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Face_To_Face_Interaction___No_Ed,
                  QPP370Elements.Phq_9_Tool, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Telehealth_Services,
                  QPP370Elements.Phq_9_Tool, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
          )
          &&
          (
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Office_Visit,
                  QPP370Elements.Phq_9_Tool, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Medications_Encounter_Code_Set,
                  QPP370Elements.Phq_9_Tool, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Psych_Visit,
                  QPP370Elements.Phq_9_Tool, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Face_To_Face_Interaction___No_Ed,
                  QPP370Elements.Phq_9_Tool, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Tool, QPP370Elements.Telehealth_Services,
                  QPP370Elements.Phq_9_Tool, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
          )
        )
        ||
          isAssessmentPerformed(visit, m, QPP370Elements.Phq_Score_Remission, patientHistoryBroadcastList)
        ||
        (
          (
              wasAssessmentInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Office_Visit,
                  QPP370Elements.Phq_Score_Remission, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Medications_Encounter_Code_Set,
                  QPP370Elements.Phq_Score_Remission, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Psych_Visit,
                  QPP370Elements.Phq_Score_Remission, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Face_To_Face_Interaction___No_Ed,
                  QPP370Elements.Phq_Score_Remission, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Telehealth_Services,
                  QPP370Elements.Phq_Score_Remission, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
          )
          &&
          (
              wasAssessmentInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Office_Visit,
                  QPP370Elements.Phq_Score_Remission, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Medications_Encounter_Code_Set,
                  QPP370Elements.Phq_Score_Remission, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Psych_Visit,
                  QPP370Elements.Phq_Score_Remission, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Face_To_Face_Interaction___No_Ed,
                  QPP370Elements.Phq_Score_Remission, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentInXPeriodsAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Telehealth_Services,
                  QPP370Elements.Phq_Score_Remission, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
          )
        )
        ||
        (
          (
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Office_Visit,
                  QPP370Elements.Phq_9_Score, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Medications_Encounter_Code_Set,
                  QPP370Elements.Phq_9_Score, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Psych_Visit,
                  QPP370Elements.Phq_9_Score, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Face_To_Face_Interaction___No_Ed,
                  QPP370Elements.Phq_9_Score, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
            ||
              wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Telehealth_Services,
                  QPP370Elements.Phq_9_Score, 11, CompareOperator.GREATER_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
          )
          &&
          (
               wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Office_Visit,
                  QPP370Elements.Phq_9_Score, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
             ||
               wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Medications_Encounter_Code_Set,
                  QPP370Elements.Phq_9_Score, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
             ||
               wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Psych_Visit,
                  QPP370Elements.Phq_9_Score, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
             ||
               wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Face_To_Face_Interaction___No_Ed,
                  QPP370Elements.Phq_9_Score, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
             ||
               wasAssessmentValueAfterDepressionAssessment(visit, m, QPP370Elements.Phq_9_Score, QPP370Elements.Telehealth_Services,
                  QPP370Elements.Phq_9_Score, 13, CompareOperator.LESS_EQUAL,
                  patientHistoryBroadcastList, leastRecentAssessmentBroadcastList, mostRecentAssessmentBroadcastList)
          )
        )
      )
      && ! isAssessmentPerformed(visit, m, QPP370Elements.Phq__9_Score_Remission_Not_Met, patientHistoryBroadcastList)
    )
  }



}