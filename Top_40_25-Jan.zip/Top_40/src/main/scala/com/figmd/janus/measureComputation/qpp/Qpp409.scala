package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{ MeasureProperty, QPP409Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- Qpp409
* Measure Title              :- Clinical Outcome Post Endovascular Stroke Treatment
* Measure Description        :- Percentage of patients with a mRs score of 0 to 2 at 90 days following endovascular stroke intervention.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- 1
* Measure Stratification     :- 1
* Measure Developer          :- Vrushali Gholap
----------------------------------------------------------------------------------------------------------------------------*/
object Qpp409 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp409"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    val patientHistoryRDD: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      , QPP409Elements.Endovascular_Stroke_Treatment
      , QPP409Elements.Ischemic_Stroke
      , QPP409Elements.Mrs_Score
      , QPP409Elements.Mrs_Score_Met
      , QPP409Elements.The_Modified_Rankin_Scale
      , QPP409Elements.Mrs_Score_Not_Met
      , QPP409Elements.No_Mrs_Score
      , QPP409Elements.Score_Mrs_Not_Obtained
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    // Filter IPP
    val ippRDD = getIppRDD(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Met
    val metRDD = getMetRDD(denominatorRDD, patientHistoryBroadcastList)
    metRDD.cache()

    // Filter Intermediate for Exception
    val intermediateException = getSubtractRDD(denominatorRDD, metRDD)
    intermediateException.cache()

    // Filter Exception
    val exceptionRDD = getExceptionRdd(intermediateException, patientHistoryBroadcastList)
    exceptionRDD.cache()


    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateException, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(initialRDD, ippRDD, denominatorRDD, sparkSession.sparkContext.emptyRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    patientHistoryBroadcastList.destroy()
  }
}
  /*-------------------------------------------------------------------------------------------------------------------------
  All patients with CVA undergoing endovascular stroke treatment.
  ----------------------------------------------------------------------------------------------------------------------------*/
  def getIppRDD(rdd: RDD[CassandraRow],patientHistoryList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME,IPP,globalStartDate,globalEndDate)


    rdd.filter(visit =>
      (    isDiagnosed(visit,m,QPP409Elements.Ischemic_Stroke,patientHistoryList)
        && wasDiagnosisBeforeOrEqualXDaysFromEnd(visit,m,QPP409Elements.Ischemic_Stroke,92,patientHistoryList)
        )
    &&(    isProcedurePerformed(visit,m,QPP409Elements.Endovascular_Stroke_Treatment,patientHistoryList)
        && wasProcedurePerformedAfterOrConcurrentDiagnosis(visit,m,QPP409Elements.Endovascular_Stroke_Treatment,QPP409Elements.Ischemic_Stroke,patientHistoryList)
        && wasProcedurePerformedBeforeOrEqualXDaysFromEnd(visit,m,QPP409Elements.Endovascular_Stroke_Treatment,92,patientHistoryList)
       )
    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
   Patients with a mRS of 0 to 2 at 90 days.
   -------------------------------------------------------------------------------------------------------------------*/


  def getMetRDD(RDD: RDD[CassandraRow], patientHistoryList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    RDD.filter(visit =>
      ((
            wasAssessmentPerformedInXDaysAfterProcedureWithResult(visit,m,QPP409Elements.Mrs_Score,QPP409Elements.Endovascular_Stroke_Treatment,0,"ge",90,patientHistoryList)
        &&  wasAssessmentPerformedInXDaysAfterProcedureWithResult(visit,m,QPP409Elements.Mrs_Score,QPP409Elements.Endovascular_Stroke_Treatment,2,"le",90,patientHistoryList)
        )
        || isAssessmentPerformed(visit,m,QPP409Elements.Mrs_Score_Met,patientHistoryList)
        || wasAssessmentPerformedAfterXDaysProcedure(visit,m,QPP409Elements.The_Modified_Rankin_Scale,QPP409Elements.Endovascular_Stroke_Treatment,90,patientHistoryList)
      )
      &&
    !(    isAssessmentPerformed(visit,m,QPP409Elements.Mrs_Score_Not_Met,patientHistoryList)
      ||  wasAssessmentPerformedInXDaysAfterProcedureWithResult(visit,m,QPP409Elements.Mrs_Score,QPP409Elements.Endovascular_Stroke_Treatment,2,"gt",90,patientHistoryList)
      )

    )
  }

  /*--------------------------------------------------------------------------------------------------------------------
  Patients in whom mRS score could not be obtained a 90 day follow-up.
  -------------------------------------------------------------------------------------------------------------------*/


  def getExceptionRdd(intermediateException: RDD[CassandraRow], patientHistoryList : Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateException.filter(visit =>
      isAssessmentPerformed(visit,m,QPP409Elements.No_Mrs_Score,patientHistoryList)
      || wasAssessmentPerformedAfterXDaysProcedure(visit,m,QPP409Elements.Score_Mrs_Not_Obtained,QPP409Elements.Endovascular_Stroke_Treatment,90,patientHistoryList)
    )
  }
}

