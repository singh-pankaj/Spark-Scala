package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- CMS 133
* Measure Title              :- Cataracts: 20/40 or Better Visual Acuity within 90 Days Following Cataract Surgery
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of uncomplicated cataract
*                               who had cataract surgery and no significant ocular conditions impacting the visual outcome
*                               of surgery and had best-corrected visual acuity of 20/40 or better (distance or near) achieved
*                               within 90 days following the cataract surgery
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rishikesh Patil
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm133V7 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm133V7"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , ECQM133V7Elements.Cataract_Surgery
      , ECQM133V7Elements.Cataract_Surgery_Eye
      , ECQM133V7Elements.Significant_Ocular_Conditions
      , ECQM133V7Elements.Significant_Ocular_Conditions__Eye
      , ECQM133V7Elements.Un_Corrected_Left_Eye_Va_Value
      , ECQM133V7Elements.Un_Corrected_Right_Eye_Va_Value
      , ECQM133V7Elements.Un_Specified_Left_Eye_Va_Value
      , ECQM133V7Elements.Un_Specified_Right_Eye_Va_Value
      , ECQM133V7Elements.Best_Corrected_Left_Eye_Va_Value
      , ECQM133V7Elements.Best_Corrected_Right_Eye_Va_Value
      , ECQM133V7Elements.Best_Corrected_Visual_Acuity
      , ECQM133V7Elements.Visual_Acuity_20_40_Or_Better
      , ECQM133V7Elements.Visual_Acuity_Eye
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)

    val correctVAValues: Array[String] = Array("20/10", "20/11", "20/12", "20/13", "20/14", "20/15", "20/16", "20/17", "20/18", "20/19", "20/2", "20/20", "20/21", "20/22", "20/23", "20/24", "20/25", "20/26", "20/28", "20/29", "20/3", "20/30", "20/31", "20/32", "20/33", "20/34", "20/35", "20/36", "20/37", "20/38", "20/39", "20/4", "20/5", "20/6", "20/7", "20/8", "20/9", "20/40")

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Filter Eligable IPP

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //val EligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      /*exclusion RDD*/
      val exclusionRDD = getExclusionRdd(ippRDD, patientHistoryBroadcastList)
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryBroadcastList, correctVAValues)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }
  }


  // IPP - Denominator criteria
  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    val filteredRDD = getPatientRDDBetweenPeriodsInMeasurementPeriod(initialRDD, m, CalenderUnit.DAY, 92, false)
    filteredRDD.filter(visit =>
      isAgeAboveBeforeStart(visit, m, true, 18, CalenderUnit.YEAR)
        //&& isProcedurePerformedXDaysBeforeEncounter(visit,m, ECQM133V7Elements.Cataract_Surgery, 92, patientHistoryList )
        && isProcedurePerformedDuringEncounter(visit, m, ECQM133V7Elements.Cataract_Surgery)
        && isProcedurePerformedWasConcurrentWith(visit, m, ECQM133V7Elements.Cataract_Surgery_Eye, ECQM133V7Elements.Cataract_Surgery, patientHistoryBroadcastList)
    )
  }

  // Exclusion criteria
  def getExclusionRdd(ippRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)
    ippRDD.filter(visit =>
      (
        wasDiagnosisPerformedBeforeProcedure(visit, m, ECQM133V7Elements.Significant_Ocular_Conditions, patientHistoryBroadcastList, ECQM133V7Elements.Cataract_Surgery)
          &&
          wasDiagnosisBeforeOrEqualProcedure(visit, m, ECQM133V7Elements.Significant_Ocular_Conditions_Date, ECQM133V7Elements.Cataract_Surgery, patientHistoryBroadcastList)
        )
        ||
        isDiagnosisPerformedWasConcurrentWith(visit, m, ECQM133V7Elements.Significant_Ocular_Conditions__Eye, ECQM133V7Elements.Significant_Ocular_Conditions, patientHistoryBroadcastList)
    )
  }


  // Numerator Criteria
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]], correctVAValues: Array[String]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateA.filter(visit =>
      (
        wasCorrectedVisualAcuityValueGreaterXDays(visit, m, ECQM133V7Elements.Un_Corrected_Left_Eye_Va_Value, ECQM133V7Elements.Cataract_Surgery, 90, correctVAValues, patientHistoryBroadcastList)
          ||
          wasCorrectedVisualAcuityValueGreaterXDays(visit, m, ECQM133V7Elements.Un_Corrected_Right_Eye_Va_Value, ECQM133V7Elements.Cataract_Surgery, 90, correctVAValues, patientHistoryBroadcastList)
          ||
          wasCorrectedVisualAcuityValueGreaterXDays(visit, m, ECQM133V7Elements.Un_Specified_Left_Eye_Va_Value, ECQM133V7Elements.Cataract_Surgery, 90, correctVAValues, patientHistoryBroadcastList)
          ||
          wasCorrectedVisualAcuityValueGreaterXDays(visit, m, ECQM133V7Elements.Un_Specified_Right_Eye_Va_Value, ECQM133V7Elements.Cataract_Surgery, 90, correctVAValues, patientHistoryBroadcastList)
          ||
          wasCorrectedVisualAcuityValueGreaterXDays(visit, m, ECQM133V7Elements.Best_Corrected_Left_Eye_Va_Value, ECQM133V7Elements.Cataract_Surgery, 90, correctVAValues, patientHistoryBroadcastList)
          ||
          wasCorrectedVisualAcuityValueGreaterXDays(visit, m, ECQM133V7Elements.Best_Corrected_Right_Eye_Va_Value, ECQM133V7Elements.Cataract_Surgery, 90, correctVAValues, patientHistoryBroadcastList)
        )
        ||
        (
          isPhysicalExamAndVAValueAfterXProcedureDays(visit, m, ECQM133V7Elements.Cataract_Surgery, ECQM133V7Elements.Visual_Acuity_20_40_Or_Better, ECQM133V7Elements.Best_Corrected_Visual_Acuity, 90, patientHistoryBroadcastList)
            &&
            isPhysicalExamPerformedDuringPhysicalExam(visit, m, ECQM133V7Elements.Visual_Acuity_Eye, ECQM133V7Elements.Visual_Acuity_Eye_Date, ECQM133V7Elements.Best_Corrected_Visual_Acuity, ECQM133V7Elements.Best_Corrected_Visual_Acuity_Date)
          )

    )
  }
}