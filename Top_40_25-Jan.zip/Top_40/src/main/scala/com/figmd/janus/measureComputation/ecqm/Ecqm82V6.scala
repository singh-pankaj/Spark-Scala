package com.figmd.janus.measureComputation.ecqm

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.ecqm.Ecqm144V7_2.{MEASURE_NAME, checkEmptyIPPRDD}
import com.figmd.janus.measureComputation.master.{AdminElements, ECQM82V6Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- eCQM 82v6
* Measure Title              :- Maternal Depression Screening
* Measure Description        :- The percentage of children who turned 6 months of age during the measurement year,
                                who had a face-to-face visit between the clinician and the child during child's first 6 months,
                                and who had a maternal depression screening for the mother at least once between 0 and 6 months of life
* Calculation Implementation :- Patient-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Ecqm82V6 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Ecqm82V6"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    // Filter IPP
    val ippRDD = getIpp(initialRDD)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD,ippRDD, MEASURE_NAME)) {



      // Eligible IPP

      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      //val eligibleRdd = sparkSession.sparkContext.emptyRDD[CassandraRow]

      //val noteligibleRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter Met
      val metRDD = getMet(ippRDD)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]

      // Filter not met
      val notMetRDD = getSubtractRDD(ippRDD, metRDD)
      notMetRDD.cache()

       saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
    }
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Children with a visit who turned 6 months of age in the measurement period
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
      (
        isDobWithinXMonthsBeforeMeasurementPeriod(visit, m, AdminElements.Date_of_Birth, 6, false)
          || isDobWithinXMonthsAfterMeasurementPeriod(visit: CassandraRow, m: MeasureProperty, AdminElements.Date_of_Birth, 6, true)
        )
        && (isEncounterPerformedAfterDOBWithinXMonths(visit, m, ECQM82V6Elements.Office_Visit, 6)
        || isEncounterPerformedAfterDOBWithinXMonths(visit, m, ECQM82V6Elements.Preventive_Care__Established_Office_Visit__0_To_17, 6)
        || isEncounterPerformedAfterDOBWithinXMonths(visit, m, ECQM82V6Elements.Preventive_Care_Services__Initial_Office_Visit__0_To_17, 6)
        )
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
Children with documentation of maternal screening or treatment for postpartum depression for the mother
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      isInterventionPerformedAfterDOBWithinXMonths(visit, m, ECQM82V6Elements.Maternal_Post_Partum_Depression_Care, 6)
        || isAssessmentPerformedAfterDOBWithinXMonths(visit, m, ECQM82V6Elements.Maternal_Post_Partum_Depression_Screening, 6)
    )
  }
}



