package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.measureComputation.master._
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 138
* Measure Title              :- Melanoma: Coordination of Care
* Measure Description        :- Percentage of patient visits, regardless of age, with a new occurrence of melanoma that have
                                a treatment plan documented in the chart that was communicated to the physician(s)
                                providing continuing care within one month of diagnosis
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- 2
* Measure Stratification     :- NA
* Measure Developer          :- Rahul Ghongate
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp138_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp138_2"

  // Logic for measure refresh
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //Backtracking List
    val patientHistory: RDD[CassandraRow] = getPatientHistory(sparkSession, initialRDD
      , QPP138Elements.New_Occurrence_Of_Melanoma_Other_Sites
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Unspecified_Site_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Unspecified_Site
      , QPP138Elements.New_Occurrence_Of_Melanoma_Overlapping_Sites_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Limb_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Limb_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Limb_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Limb_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Lower_Limb_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Lower_Limb
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Limb_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Limb_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Rt_Upper_Limb_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Rt_Upper_Limb_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Upper_Limb_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Upper_Limb
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Trunk_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Trunk
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Breast_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Breast_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Anal_Skin_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Anal_Skin_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Scalp_And_Neck
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Scalp___Neck_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Nose_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Face_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Face
      , QPP138Elements.New_Occurrence_Of_Melanoma_Left_Ear_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Ear_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Right_Ear_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Ear_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Ear
      , QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Eyelid_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Eyelid
      , QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Lip_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Eyelid_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Eyelid_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Eyelid_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Upper_Eyelid_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Eyelid_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Eyelid_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Eyelid_Grp
      , QPP138Elements.New_Occurrence_Of_Melanoma_Right_Upper_Eyelid_Grp
      , QPP138Elements.New_Occurrence_Of_Malignant_Melanoma_Of_Lip
      , QPP138Elements.New_Occurrence_Of_Melanoma_Insitu__Left_Ear_Grp
      , QPP138Elements.Malignant_Melanoma_Snomed_Grp
      , QPP138Elements.Malignant_Melanoma_Insitu_Snomed_Grp
      , QPP138Elements.Office_Visit
      , QPP138Elements.Outpatient_Consultation
      , QPP138Elements.Treatment_Plan_Grp
      , QPP138Elements.Tumor_Thickness_Of_Melanoma_Grp
      , QPP138Elements.Surgery_Or_Alternate_Care_Plan_Grp
      , QPP138Elements.Treatment_Plan_Communication
      , QPP138Elements.Diagnosis_Grp
      , QPP138Elements.Treatment_Plan_Reason_Not_Specified_Grp
      , QPP138Elements.Treatment_Plan_Patient_Reason_Grp
      , QPP138Elements.Treatment_Plan_System_Reason_Grp
      , QPP138Elements.Treatment_Plan_Medical_System_Reason_Grp)

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistory.collect().toList)

    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()


    // Filter Exclusions
    val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
    exclusionRDD.cache()

    // Filter Met
    val metRDD = getMet(ippRDD, patientHistoryBroadcastList)
    metRDD.cache()

    val intermediateA = getSubtractRDD(ippRDD, metRDD)
    intermediateA.cache()

    // Filter Exceptions
    val exceptionRDD = getException(intermediateA, patientHistoryBroadcastList)
    exceptionRDD.cache()

    // Filter not met
    val notMetRDD = getSubtractRDD(intermediateA, exceptionRDD)
    notMetRDD.cache()

    saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
  }
}

  /*-------------------------------------------------------------------------------------------------------------------------
  2) All visits for patients, regardless of age, diagnosed with a new occurrence of melanoma evaluated in an outpatient setting
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
      isDiagnosisList(visit,m,patientHistoryBroadcastList
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Other_Sites
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Unspecified_Site_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Unspecified_Site
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Overlapping_Sites_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Limb_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Limb_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Limb_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Limb_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Lower_Limb_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Lower_Limb
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Limb_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Limb_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Rt_Upper_Limb_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Rt_Upper_Limb_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Upper_Limb_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Upper_Limb
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Trunk_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Trunk
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Breast_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Breast_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Anal_Skin_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Anal_Skin_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Scalp_And_Neck
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Scalp___Neck_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Nose_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Face_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Face
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Ear_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Ear_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Ear_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Ear_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Ear
            ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Eyelid_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Eyelid
            ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Lip_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Eyelid_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Eyelid_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Eyelid_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Upper_Eyelid_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Eyelid_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Eyelid_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Eyelid_Grp
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Upper_Eyelid_Grp
            ,QPP138Elements.New_Occurrence_Of_Malignant_Melanoma_Of_Lip
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu__Left_Ear_Grp
            ,QPP138Elements.Malignant_Melanoma_Snomed_Grp
            ,QPP138Elements.Malignant_Melanoma_Insitu_Snomed_Grp)
  &&  (isDiagnosisListDuringEncounter(visit,m,QPP138Elements.Office_Visit_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Other_Sites_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Unspecified_Site_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Unspecified_Site_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Overlapping_Sites_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Lower_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Lower_Limb_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Rt_Upper_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Rt_Upper_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Upper_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Upper_Limb_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Trunk_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Trunk_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Breast_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Breast_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Anal_Skin_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Anal_Skin_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Scalp_And_Neck_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Scalp___Neck_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Nose_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Face_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Face_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Ear_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Ear_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Ear_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Ear_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Ear_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Eyelid_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Lip_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Upper_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Upper_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Malignant_Melanoma_Of_Lip_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu__Left_Ear_Grp_Date
            ,QPP138Elements.Malignant_Melanoma_Snomed_Grp_Date
            ,QPP138Elements.Malignant_Melanoma_Insitu_Snomed_Grp_Date)
    || isDiagnosisListDuringEncounter(visit,m,QPP138Elements.Outpatient_Consultation_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Other_Sites_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Unspecified_Site_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Unspecified_Site_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Overlapping_Sites_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Lower_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Lower_Limb_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Rt_Upper_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Rt_Upper_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Upper_Limb_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Upper_Limb_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Trunk_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Trunk_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Breast_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Breast_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Anal_Skin_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Anal_Skin_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Scalp_And_Neck_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Scalp___Neck_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Nose_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Face_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Face_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Ear_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Ear_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Ear_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Ear_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Ear_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Eyelid_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Lip_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Upper_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Upper_Eyelid_Grp_Date
            ,QPP138Elements.New_Occurrence_Of_Malignant_Melanoma_Of_Lip_Date
            ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu__Left_Ear_Grp_Date
            ,QPP138Elements.Malignant_Melanoma_Snomed_Grp_Date
            ,QPP138Elements.Malignant_Melanoma_Insitu_Snomed_Grp_Date)
     )
 && (  wasEncounterPerformedAfterStartWithInXMonths(visit,m,QPP138Elements.Office_Visit,11,patientHistoryBroadcastList)
    || wasEncounterPerformedAfterStartWithInXMonths(visit,m,QPP138Elements.Outpatient_Consultation,11,patientHistoryBroadcastList)
    )
 && ! isTeleHealthModifier(visit,m
        ,QPP138Elements.Office_Visit_Telehealth_Modifier
        ,QPP138Elements.Outpatient_Consultation_Telehealth_Modifier)
 && isPOSEncounterNotPerformed(visit,m,QPP138Elements.Pos_02)
)
}

  /*-------------------------------------------------------------------------------------------------------------------------
  Patient visits with a treatment plan documented in the chart that was communicated to the physician(s)
  providing continuing care within one month of diagnosis
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
      (  isCommunicationFromProvidertoProvider(visit,m,QPP138Elements.Treatment_Plan_Grp,patientHistoryBroadcastList)
       || ( wasCommunicationFromProviderToProviderAfterDiagnosisListWithInXMonths(visit,m,QPP138Elements.Tumor_Thickness_Of_Melanoma_Grp,1,patientHistoryBroadcastList
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Other_Sites
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Unspecified_Site_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Unspecified_Site
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Overlapping_Sites_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Lower_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Upper_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Trunk_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Trunk
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Scalp_And_Neck
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Scalp___Neck_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Nose_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Face
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Ear
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Eyelid
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Lip_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Malignant_Melanoma_Of_Lip
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu__Left_Ear_Grp
                ,QPP138Elements.Malignant_Melanoma_Snomed_Grp
                ,QPP138Elements.Malignant_Melanoma_Insitu_Snomed_Grp)
        && wasCommunicationFromProviderToProviderAfterDiagnosisListWithInXMonths(visit,m,QPP138Elements.Surgery_Or_Alternate_Care_Plan_Grp,1,patientHistoryBroadcastList
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Other_Sites
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Unspecified_Site_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Unspecified_Site
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Overlapping_Sites_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Lower_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Upper_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Trunk_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Trunk
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Scalp_And_Neck
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Scalp___Neck_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Nose_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Face
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Ear
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Eyelid
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Lip_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Malignant_Melanoma_Of_Lip
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu__Left_Ear_Grp
                ,QPP138Elements.Malignant_Melanoma_Snomed_Grp
                ,QPP138Elements.Malignant_Melanoma_Insitu_Snomed_Grp)
        && wasCommunicationFromProviderToProviderAfterDiagnosisListWithInXMonths(visit,m,QPP138Elements.Treatment_Plan_Communication,1,patientHistoryBroadcastList
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Other_Sites
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Unspecified_Site_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Unspecified_Site
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Overlapping_Sites_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Lower_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Upper_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Trunk_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Trunk
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Scalp_And_Neck
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Scalp___Neck_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Nose_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Face
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Ear
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Eyelid
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Lip_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Malignant_Melanoma_Of_Lip
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu__Left_Ear_Grp
                ,QPP138Elements.Malignant_Melanoma_Snomed_Grp
                ,QPP138Elements.Malignant_Melanoma_Insitu_Snomed_Grp)
        && wasCommunicationFromProviderToProviderAfterDiagnosisListWithInXMonths(visit,m,QPP138Elements.Diagnosis_Grp,1,patientHistoryBroadcastList
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Other_Sites
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Unspecified_Site_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Unspecified_Site
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Overlapping_Sites_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Lower_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Upper_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Trunk_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Trunk
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Scalp_And_Neck
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Scalp___Neck_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Nose_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Face
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Ear
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Eyelid
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Lip_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Malignant_Melanoma_Of_Lip
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu__Left_Ear_Grp
                ,QPP138Elements.Malignant_Melanoma_Snomed_Grp
                ,QPP138Elements.Malignant_Melanoma_Insitu_Snomed_Grp)
       )
    )
      && ! wasAssessmentPerformedAfterDiagnosisListWithInXMonths(visit,m,QPP138Elements.Treatment_Plan_Reason_Not_Specified_Grp,11,patientHistoryBroadcastList
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Other_Sites
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Unspecified_Site_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Unspecified_Site
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Overlapping_Sites_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Lower_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Upper_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Trunk_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Trunk
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Scalp_And_Neck
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Scalp___Neck_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Nose_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Face
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Ear
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Eyelid
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Lip_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Malignant_Melanoma_Of_Lip
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu__Left_Ear_Grp
                ,QPP138Elements.Malignant_Melanoma_Snomed_Grp
                ,QPP138Elements.Malignant_Melanoma_Insitu_Snomed_Grp)
    )
  }

  /*-------------------------------------------------------------------------------------------------------------------------
  Documentation of patient reason(s) for not communicating treatment plan to the Primary Care Physician(s) (PCP)(s)
  (eg, patient asks that treatment plan not be communicated to the physician(s) providing continuing care).
  ----------------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateA: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCEPTION, globalStartDate, globalEndDate)

    intermediateA.filter(visit =>
           wasAssessmentPerformedAfterDiagnosisListWithInXMonths(visit,m,QPP138Elements.Treatment_Plan_Patient_Reason_Grp,11,patientHistoryBroadcastList
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Other_Sites
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Unspecified_Site_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Unspecified_Site
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Overlapping_Sites_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Lower_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Upper_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Trunk_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Trunk
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Scalp_And_Neck
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Scalp___Neck_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Nose_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Face
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Ear
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Eyelid
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Lip_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Malignant_Melanoma_Of_Lip
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu__Left_Ear_Grp
                ,QPP138Elements.Malignant_Melanoma_Snomed_Grp
                ,QPP138Elements.Malignant_Melanoma_Insitu_Snomed_Grp)
        || wasAssessmentPerformedAfterDiagnosisListWithInXMonths(visit,m,QPP138Elements.Treatment_Plan_System_Reason_Grp,11,patientHistoryBroadcastList
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Other_Sites
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Unspecified_Site_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Unspecified_Site
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Overlapping_Sites_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Lower_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Upper_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Trunk_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Trunk
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Scalp_And_Neck
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Scalp___Neck_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Nose_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Face
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Ear
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Eyelid
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Lip_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Malignant_Melanoma_Of_Lip
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu__Left_Ear_Grp
                ,QPP138Elements.Malignant_Melanoma_Snomed_Grp
                ,QPP138Elements.Malignant_Melanoma_Insitu_Snomed_Grp)
     || wasCommunicationFromProviderToProviderAfterDiagnosisListWithInXMonths(visit,m,QPP138Elements.Treatment_Plan_Medical_System_Reason_Grp,11,patientHistoryBroadcastList
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Other_Sites
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Unspecified_Site_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Unspecified_Site
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Overlapping_Sites_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Lower_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Lower_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Rt_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Upper_Limb_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Upper_Limb
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Trunk_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Trunk
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Breast_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Anal_Skin_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Scalp_And_Neck
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Scalp___Neck_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Other_Parts_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Nose_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Face_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Face
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Ear_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Ear
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Eyelid
                ,QPP138Elements.New_Occurrence_Of_Melanoma_In_Situ_Lip_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Left_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Lower_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Right_Upper_Eyelid_Grp
                ,QPP138Elements.New_Occurrence_Of_Malignant_Melanoma_Of_Lip
                ,QPP138Elements.New_Occurrence_Of_Melanoma_Insitu__Left_Ear_Grp
                ,QPP138Elements.Malignant_Melanoma_Snomed_Grp
                ,QPP138Elements.Malignant_Melanoma_Insitu_Snomed_Grp)
    )
  }
}