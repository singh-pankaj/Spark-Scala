package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.measureComputation.master.{CAP24Elements, CalenderUnit, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                  :- CAP24_2
* Measure Title               :- Cancer Protocol and Turnaround Time for Carcinoma of the Intrahepatic Bile Ducts
* Measure Description         :- meet the maximum 4 business day turnaround time (TAT) requirement
*                                 (Report Date – Accession Date ≤ 4 business days).
* Calculation Implementation  :- Procedure-specific
* Improvement Notation        :- Higher Score indicates better quality
* Reporting Criteria          :- 1
* Measure Stratum No.         :- NA
* Measure Stratification      :- None
* Measure Developer           :- SUMANT KULKARNI
* Initial GIT Version/Tag(CRA):- 1.6
* Latest GIT Version/Tag(CRA) :- 1.6
----------------------------------------------------------------------------------------------------------------------------*/

object CAP24_2 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "CAP24_2"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , CAP24Elements.Confirm_Intrahepatic_Bile_Duct_Carcinoma_Resection
      , CAP24Elements.Surgical_Pathology_Accession_Number
      , CAP24Elements.Specimen_Accession_Date
      , CAP24Elements.Specimen_Verification_Date
    )
    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)


    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //Denominator is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      val exclusionRDD = getExclusion(denominatorRDD, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      exclusionRDD.cache()

      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList: Broadcast[List[CassandraRow]])
      metRDD.cache()

      val exceptionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]


      val notMetRDD = getSubtractRDD(intermediateForMet, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()

    }

  }

  /*-----------------------------------------------------------------------------------------------------------------------
  All final pathology reports for eligible hepatic resection cases that require the use of a CAP cancer protocol.
  CPT®: 88307 or 88309
  AND
  Any of the ICD 10 codes:
  C22.1: intrahepatic bile duct carcinoma
  C22.0: liver cell carcinoma
  C22.7: other specific carcinoma of liver
  C22.8: malignant neoplasm of liver, primary, unspecified as to type
  C22.9: malignant neoplasm of liver, not specified as primary or secondary
-----------------------------------------------------------------------------------------------------------------------*/

  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)

    initialRDD.filter(visit =>
          isDiagnosisOverlapsProcedure(visit, m, CAP24Elements.Confirm_Intrahepatic_Bile_Duct_Carcinoma_Resection,
                          CAP24Elements.Surgical_Pathology_Accession_Number, patientHistoryBroadcastList)
        &&
          isProcedurePerformed(visit, m, CAP24Elements.Surgical_Pathology_Accession_Number, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  1.Biopsy procedures
  2.Hepatocellular carcinoma
  3.Hepatoblastoma
  Carcinomas of the perihilar bile ducts

-----------------------------------------------------------------------------------------------------------------------*/
  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, EXCLUSION, globalStartDate, globalEndDate)

    denominatorRDD.filter(visit =>
      (
        isDiagnosisListDuringProcedure(visit, m, CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Liver_Cell_Carcinoma)
          &&
          isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Biopsy, CAP24Elements.Biopsy_Date,
            CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
        )
        ||
        isDiagnosisListDuringProcedure(visit, m, CAP24Elements.Surgical_Pathology_Accession_Number
          , CAP24Elements.Perihilar_Bile_Ducts_Tumor
          , CAP24Elements.Hepatocellular_Carcinoma
          , CAP24Elements.Hepatoblastoma
          , CAP24Elements.Cholangiocarcinoma
          , CAP24Elements.Angiosarcoma_Of_Liver
          , CAP24Elements.Other_Sarcomas_Of_Liver
          , CAP24Elements.Malignant_Neoplasm_Of_Extrahepatic_Bile_Duct_Gp
          , CAP24Elements.Secondary_Malignant_Neoplasm_Of_Liver_And_Intrahepatic_Bile_Duct
          , CAP24Elements.Hepatocellular_Carcinoma_Kw
        )
        ||
        isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Biopsy, CAP24Elements.Biopsy_Date,
          CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
        ||
        isLaboratoryTestPerformedDuringProcedure(visit, m, CAP24Elements.Biopsy_Or_Carcinoma__Hepatoblastoma_, CAP24Elements.Biopsy_Or_Carcinoma__Hepatoblastoma__Date,
          CAP24Elements.Surgical_Pathology_Accession_Number, CAP24Elements.Surgical_Pathology_Accession_Number_Date)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
  Final pathology report in the laboratory/hospital information system with result verified and reported by the laboratory,
  available to the requesting physician(s) within 4 business days.
-----------------------------------------------------------------------------------------------------------------------*/
  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)

    intermediateForMet.filter(visit =>
      isLaboratoryTestAfterLaboratoryTestWithinXDays(visit, m, CAP24Elements.Specimen_Accession_Date,
                  CAP24Elements.Specimen_Verification_Date, CalenderUnit.DAY, 4, patientHistoryBroadcastList)
    )
  }


}