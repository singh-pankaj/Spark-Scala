package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.measureComputation.master.{AdminElements, MeasureProperty, QPP421Elements}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import com.figmd.janus.{Measure, MeasureUpdate}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import com.figmd.janus.WebDataMartCreator.{globalStartDate,globalEndDate}

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 421
* Measure Title              :- Appropriate Assessment of Retrievable Inferior Vena Cava (IVC) Filters for Removal
* Measure Description        :- Percentage of patients in whom a retrievable IVC filter is placed who, within 3 months
                                post-placement, have a documented assessment for the appropriateness of continued
                                filtration, device removal or the inability to contact the patient with at least two attempts.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher score equals better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sanket Dhapte
----------------------------------------------------------------------------------------------------------------------------*/

object Qpp421 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Qpp421"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {


    val patientHistoryRDD = getPatientHistory(sparkSession, initialRDD
      , QPP421Elements.Placement_Of_Retrievable_Ivc_Filter
      , QPP421Elements.Patient_Alive_1
      , QPP421Elements.Potential_Removal_Intent
      , QPP421Elements.Ivc_Filter_Follow_Up
      , QPP421Elements.Placement_Of_Retrievable_Ivc_Filter
      , QPP421Elements.Appropriate_Ivc_Filter_Follow_Up
      , QPP421Elements.Appropriate_Ivc_Filter_Follow_Up_Not_Met
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patientHistoryRDD.collect().toList)
    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()
    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {
      //Denominator  is equal to IPP
      val denominatorRDD = ippRDD
      denominatorRDD.cache()
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      // Filter Met
      val metRDD = getMet(denominatorRDD, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter not met
      val notMetRDD = getSubtractRDD(denominatorRDD, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD,exclusionRDD , metRDD,sparkSession.sparkContext.emptyRDD[CassandraRow] , notMetRDD, MEASURE_NAME)
    }
  }

  /*------------------------------------------------------------------------------
    All patients who have a retrievable IVC filter placed with the intent for potential removal at time of placement.
   ------------------------------------------------------------------------------*/

  def getIpp(rdd: RDD[CassandraRow],patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)


    rdd.filter(visit =>
       wasProcedurePerformedWithinXMonths(visit,m,QPP421Elements.Placement_Of_Retrievable_Ivc_Filter,3,patientHistoryList)
    && isProcedurePerformedDuringEncounter(visit,m,QPP421Elements.Placement_Of_Retrievable_Ivc_Filter)
    && wasProcedurePerformedAfterXMonthsOfProcedure(visit,m,QPP421Elements.Placement_Of_Retrievable_Ivc_Filter,QPP421Elements.Patient_Alive_1,3,patientHistoryList)
    && isProcedurePerformedDuringEncounter(visit,m,QPP421Elements.Potential_Removal_Intent)
    )
  }

  /*------------------------------------------------------------------------------
    Number of patients that have appropriate IVC filter follow-up.
   ------------------------------------------------------------------------------*/

  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>
      (
            isInterventionPerformed(visit,m,QPP421Elements.Ivc_Filter_Follow_Up,patientHistoryList)
        || wasInterventionPerformedAfterXMonthsOfProcedure(visit,m,QPP421Elements.Placement_Of_Retrievable_Ivc_Filter,QPP421Elements.Appropriate_Ivc_Filter_Follow_Up,3,patientHistoryList)
        )
      && !isInterventionPerformed(visit,m,QPP421Elements.Appropriate_Ivc_Filter_Follow_Up_Not_Met,patientHistoryList)

    )
  }
}
