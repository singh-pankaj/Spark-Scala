package com.figmd.janus.measureComputation.nonqpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{AQUA17Elements, MeasureProperty}
import com.figmd.janus.util.measure.MeasureUtilityUpdate
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- AQUA 17
* Measure Title              :- Non Muscle Invasive Bladder Cancer: Initiation of BCG 3 months of diagnosis of high grade T1 bladder cancer and/or CIS
* Measure Description        :- Percentage of patients who initiate BCG treatment within 3 months of diagnosis of highâ€grade T1 bladder cancer and/or CIS.
* Calculation Implementation :- Procedure-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 1
* Measure Stratum No.        :- NA
* Measure Stratification     :- NA
* Measure Developer          :- Sahil Goyal
----------------------------------------------------------------------------------------------------------------------------*/
object Aqua17 extends MeasureUtilityUpdate with MeasureUpdate {

  val MEASURE_NAME = "Aqua17"

  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {

    //getPatientHistoryList
    val patienthistoryRdd = getPatientHistory(sparkSession, initialRDD,
      AQUA17Elements.Bladder_Cancer_T1,
      AQUA17Elements.Carcinoma_In_Situ,
      AQUA17Elements.Non_Urothelial_Histology,
      AQUA17Elements.Bcg_Treatment,
      AQUA17Elements.Chemotherapy_Onset,
      AQUA17Elements.Radical_Cystectomy,
      AQUA17Elements.Bcg_Treatment
    )

    val patientHistoryBroadcastList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patienthistoryRdd.collect().toList)


    // Filter IPP
    val ippRDD = getIpp(initialRDD, patientHistoryBroadcastList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //denominator RDD
      val denominatorRDD = ippRDD
      denominatorRDD.cache()

      // Filter Exclusion
      val exclusionRDD = getExclusion(ippRDD, patientHistoryBroadcastList)

      // Filter Intermediate A
      val intermediateForMet = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateForMet.cache()

      // Filter Met
      val metRDD = getMet(intermediateForMet, patientHistoryBroadcastList)
      metRDD.cache()

      // Filter Intermediate B
      val intermediateForException = getSubtractRDD(intermediateForMet, metRDD)
      intermediateForException.cache()

      // Filter Denominator Exception
      val exceptionRDD = getException(intermediateForException, patientHistoryBroadcastList)
      exceptionRDD.cache()

      //Filter Not Met
      val notMetRDD = getSubtractRDD(intermediateForException, exceptionRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryBroadcastList.destroy()
    }
  }


  /*-----------------------------------------------------------------------------------------------------------------------
Patients diagnosed with high‐grade T1 bladder cancer and/or CIS
-----------------------------------------------------------------------------------------------------------------------*/


  def getIpp(initialRDD: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    initialRDD.filter(visit =>
        (  wasDiagnosisAfterOrConcurentWithDiagnosis(visit, m, AQUA17Elements.Bladder_Cancer, patientHistoryBroadcastList, AQUA17Elements.Bladder_Cancer_T1)
        || wasDiagnosisAfterOrConcurentWithDiagnosis(visit, m, AQUA17Elements.Bladder_Cancer, patientHistoryBroadcastList, AQUA17Elements.Carcinoma_In_Situ)
        )
    && (   wasDiagnosisAfterOrConcurentWithProcedure(visit, m, AQUA17Elements.Transurethral_Resection_For_Bladder_Tumor, patientHistoryBroadcastList, AQUA17Elements.Bladder_Cancer_T1)
        || wasDiagnosisAfterOrConcurentWithProcedure(visit, m, AQUA17Elements.Transurethral_Resection_For_Bladder_Tumor, patientHistoryBroadcastList, AQUA17Elements.Carcinoma_In_Situ)
       )
      && isProcedurePerformed(visit, m, AQUA17Elements.Transurethral_Resection_For_Bladder_Tumor,patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Non‐urothelial histologyNon‐urothelial histolo
-----------------------------------------------------------------------------------------------------------------------*/


  def getExclusion(denominatorRDD: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP, globalStartDate, globalEndDate)
    denominatorRDD.filter(visit =>
          isLaboratoryTestPerformed(visit, m, AQUA17Elements.Non_Urothelial_Histology, patientHistoryList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Patients starting BCG within 3 months of TURBTPatients
-----------------------------------------------------------------------------------------------------------------------*/

  def getMet(intermediateForMet: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateForMet.filter(visit =>
          wasProcedurePerformedAfterXMonthsOfProcedure(visit, m,AQUA17Elements.Transurethral_Resection_For_Bladder_Tumor, AQUA17Elements.Bcg_Treatment, 3, patientHistoryBroadcastList)
    )
  }

  /*-----------------------------------------------------------------------------------------------------------------------
Onset of chemotherapy or radical cystectomy within 3 months of diagnosis; prior completion of at least 6 weeks BCGOnset of chemotherapy
-----------------------------------------------------------------------------------------------------------------------*/

  def getException(intermediateForException: RDD[CassandraRow], patientHistoryBroadcastList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    var m = MeasureProperty(MEASURE_NAME, MET, globalStartDate, globalEndDate)
    intermediateForException.filter(visit =>
          wasProcedurePerformedXMonthsAfterDiagnosis(visit, m, AQUA17Elements.Bladder_Cancer, AQUA17Elements.Chemotherapy_Onset, 3, patientHistoryBroadcastList)
       || wasProcedurePerformedXMonthsAfterDiagnosis(visit, m, AQUA17Elements.Bladder_Cancer, AQUA17Elements.Radical_Cystectomy, 3, patientHistoryBroadcastList)
       || wasProcedureEndsBeforeProcedureInXWeeks(visit, m, AQUA17Elements.Transurethral_Resection_For_Bladder_Tumor, AQUA17Elements.Bcg_Treatment, 6, patientHistoryBroadcastList)
      )
  }
}
