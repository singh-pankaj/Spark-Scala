
package com.figmd.janus.measureComputation.qpp

import com.datastax.spark.connector.CassandraRow
import com.figmd.janus.MeasureUpdate
import com.figmd.janus.WebDataMartCreator.{globalEndDate, globalStartDate}
import com.figmd.janus.measureComputation.master.{ MeasureProperty, QPP5Elements, _}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import com.figmd.janus.util.measure.MeasureUtilityUpdate

/*-------------------------------------------------------------------------------------------------------------------------
* Measure ID                 :- QPP 5
* Measure Title              :- Heart Failure (HF): Angiotensin-Converting Enzyme (ACE) Inhibitor or Angiotensin Receptor Blocker (ARB) Therapy for Left Ventricular Systolic Dysfunction (LVSD)
* Measure Description        :- Percentage of patients aged 18 years and older with a diagnosis of heart failure (HF) with a current or prior left ventricular ejection fraction (LVEF) < 40%
*                               who were prescribed ACE inhibitor or ARB therapy either within a 12 month period when seen in the outpatient setting OR at each hospital discharge
                                THERE ARE TWO SUBMISSION CRITERIA FOR THIS MEASURE:
                                1) All patients with a diagnosis of HF assessed during an outpatient encounter
                                OR
                                2) All patients with a diagnosis of HF and discharged from hospital
* Calculation Implementation :- Visit-specific
* Improvement Notation       :- Higher Score indicates better quality
* Reporting Criteria         :- 2
* Measure Stratum No.        :- A
* Measure Stratification     :- 1
* Measure Developer          :- Kiran Phalke
----------------------------------------------------------------------------------------------------------------------------*/


object Qpp5_1 extends MeasureUtilityUpdate with MeasureUpdate {
  val MEASURE_NAME = "Qpp5_1"
  def refresh(sparkSession: SparkSession, initialRDD: RDD[CassandraRow]): Unit = {
    var patient_history_list = getPatientHistory(sparkSession,initialRDD,
      QPP5Elements.Left_Ventricular_Ejection_Fraction,
      QPP5Elements.Ejection_Fraction,
      QPP5Elements.Moderate_Or_Severe_Lvsd,
      QPP5Elements.Left_Ventricular_Systolic_Dysfunction,
      QPP5Elements.Ace_Inhibitor_Or_Arb,
      QPP5Elements.Ace_Inhibitor_Or_Arb_Ingredient,
      QPP5Elements.Allergy_To_Ace_Inhibitor_Or_Arb,
      QPP5Elements.Ace_Inhibitor_Or_Arb_Medication,
      QPP5Elements.Intolerance_To_Ace_Inhibitor_Or_Arb,
      QPP5Elements.Pregnancy,
      QPP5Elements.Renal_Failure_Due_To_Ace_Inhibitor
    ).collect().toList

    val patientHistoryList: Broadcast[List[CassandraRow]] = sparkSession.sparkContext.broadcast(patient_history_list)

    val patineHistoryRDD=getPatientHistory(sparkSession,initialRDD,QPP5Elements.Office_Visit,
      QPP5Elements.Outpatient_Consultation,
      QPP5Elements.Nursing_Facility_Visit,
      QPP5Elements.Care_Services_In_Long_Term_Residential_Facility,
      QPP5Elements.Home_Healthcare_Services,
      QPP5Elements.Patient_Provider_Interaction)


    // Filter IPP
    val ippRDD = getIpp(initialRDD,patineHistoryRDD,patientHistoryList)
    ippRDD.cache()

    if (checkEmptyIPPRDD(sparkSession, initialRDD, ippRDD, MEASURE_NAME)) {

      //eligible RDD
      val denominatorRDD = getDenominator(ippRDD, patientHistoryList)


      // Filter Exclusions
      val exclusionRDD = sparkSession.sparkContext.emptyRDD[CassandraRow]
      exclusionRDD.cache()

      // Filter Intermediate RDD
      val intermediateA = getSubtractRDD(ippRDD, exclusionRDD)
      intermediateA.cache()

      // Filter Met
      val metRDD = getMet(intermediateA, patientHistoryList)
      metRDD.cache()

      // Filter Exceptions
      val exceptionRDD = getexceptionRDD(intermediateA, patientHistoryList)

      // Filter not met
      val notMetRDD = getSubtractRDD(intermediateA, metRDD)
      notMetRDD.cache()

      saveToWebDM(initialRDD, ippRDD, denominatorRDD, exclusionRDD, metRDD, exceptionRDD, notMetRDD, MEASURE_NAME)
      patientHistoryList.destroy()
    }
  }
  //SUBMISSION CRITERIA 1: All patients aged 18 years and older with a diagnosis of heart failure with a current or prior LVEF < 40%

  def getIpp(rdd: RDD[CassandraRow],patineHistoryRDD:RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, IPP,globalStartDate,globalEndDate)

    val countElementList: List[(String,Int)] = countElement(patineHistoryRDD,m,
      QPP5Elements.Office_Visit,
      QPP5Elements.Outpatient_Consultation,
      QPP5Elements.Nursing_Facility_Visit,
      QPP5Elements.Care_Services_In_Long_Term_Residential_Facility,
      QPP5Elements.Home_Healthcare_Services,
      QPP5Elements.Patient_Provider_Interaction
    )

    rdd.filter(visit =>
                           isPatientAdult (visit, m)
                        && isDiagnosedOnEncounter(visit,m,QPP5Elements.Heart_Failure)
                        &&  getEncounterCountFromHistory(visit,m,2, true,countElementList)
                        &&  ! isTeleHealthModifier(visit,m,
                                                          QPP5Elements.Care_Services_In_Long_Term_Residential_Facility_Telehealth_Modifier,
                                                          QPP5Elements.Home_Healthcare_Services_Telehealth_Modifier,
                                                          QPP5Elements.Nursing_Facility_Visit_Telehealth_Modifier,
                                                          QPP5Elements.Office_Visit_Telehealth_Modifier,
                                                          QPP5Elements.Outpatient_Consultation_Telehealth_Modifier
                                                  )

                        &&	isPOSEncounterNotPerformed(visit,m,QPP5Elements.Pos_02)

              )
  }

  //Equals Initial Population with a current or prior LVEF < 40%
  def getDenominator(ippRDD: RDD[CassandraRow], patientHistoryList:Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, ELIGIBLE,globalStartDate,globalEndDate)
    ippRDD.filter(visit =>

                      (

                        wasDiagnosticStudyPerformedBeforeOrEqualEncounter(visit,m,QPP5Elements.Left_Ventricular_Ejection_Fraction,patientHistoryList)
                      ||	(
                                  wasDiagnosticStudyPerformedBeforeOrEqualEncounterWithResult(visit,m,QPP5Elements.Ejection_Fraction,40,"lt",patientHistoryList)
                            ||	  wasDiagnosedBeforeEndOfEncounter(visit,m,QPP5Elements.Moderate_Or_Severe_Lvsd,patientHistoryList)
                            ||    wasDiagnosedBeforeEndOfEncounter(visit,m,QPP5Elements.Left_Ventricular_Systolic_Dysfunction,patientHistoryList)
                          )
                       )



              )
  }

  //SUBMISSION CRITERIA 1: Patients who were prescribed ACE inhibitor or ARB therapy within a 12-month period when seen in the outpatient setting
  def getMet(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {

    val m = MeasureProperty(MEASURE_NAME, MET,globalStartDate,globalEndDate)

    intermediateA.filter(visit =>

                            (
                                  isMedicationOrderedDuringEncounter(visit, m, QPP5Elements.Ace_Inhibitor_Or_Arb)
                              || wasMedicationActiveInHistory(visit, m, QPP5Elements.Ace_Inhibitor_Or_Arb, patientHistoryList)
                              || isMedicationAdministeredOnEncounter(visit, m, QPP5Elements.Arb_Or_Ace_Inhibitor_Therapy)
                            )
                            &&
                            (
                            !isMedicationAdministeredNotDoneOnEncounter(visit,m,QPP5Elements.Arb_Or_Ace_Inhibitor_Therapy_Reason_Not_Specified)

                             )
                        )

  }


//Documentation of medical reason(s) for not prescribing ACE inhibitor or ARB therapy (eg, hypotensive patients who are at immediate risk of cardiogenic shock, hospitalized patients who have experienced marked azotemia, allergy, intolerance, other medical reasons)
//
//Documentation of patient reason(s) for not prescribing ACE inhibitor or ARB therapy (eg, patient declined, other patient reasons)
//
//Documentation of system reason(s) for not prescribing ACE inhibitor or ARB therapy (eg, other system reasons)
  def getexceptionRDD(intermediateA: RDD[CassandraRow], patientHistoryList: Broadcast[List[CassandraRow]]): RDD[CassandraRow] = {
    val m = MeasureProperty(MEASURE_NAME, EXCEPTION,globalStartDate,globalEndDate)
    intermediateA.filter(visit =>

                                (
                                      isMedicationOrderedDuringEncounter(visit,m,QPP5Elements.Medical_Reason)
                                  ||  isMedicationOrderedDuringEncounter(visit,m,QPP5Elements.Patient_Reason)
                                  ||  isMedicationOrderedDuringEncounter(visit,m,QPP5Elements.System_Reason)
                                  ||  isCommunicationFromProviderToPatientOnEncounter(visit,m,QPP5Elements.Patient_Reason_For_Ace_Inhibitor_Or_Arb_Decline)
                                )
                            ||
                                (
                                      wasMedicationAllergyInHistory(visit,m,QPP5Elements.Ace_Inhibitor_Or_Arb_Ingredient,patientHistoryList)
                                  ||  isDiagnosisOverlapsEncounter(visit,m,patientHistoryList,QPP5Elements.Allergy_To_Ace_Inhibitor_Or_Arb)
                                  ||  wasMedicationInToleraneInHistory(visit,m,QPP5Elements.Ace_Inhibitor_Or_Arb_Medication,patientHistoryList)
                                  ||  isDiagnosisOverlapsEncounter(visit,m,patientHistoryList,QPP5Elements.Intolerance_To_Ace_Inhibitor_Or_Arb)
                                  ||  isDiagnosisOverlapsEncounter(visit,m,patientHistoryList,QPP5Elements.Pregnancy)
                                  ||  isDiagnosisOverlapsEncounter(visit,m,patientHistoryList,QPP5Elements.Renal_Failure_Due_To_Ace_Inhibitor)
                                )
                            ||
                                 (
                                       isMedicationAdministeredNotDoneOnEncounter(visit, m,QPP5Elements.Arb_Or_Ace_Inhibitor_Therapy_Medical_Reason)
                                   ||  isMedicationAdministeredNotDoneOnEncounter(visit, m,QPP5Elements.Arb_Or_Ace_Inhibitor_Therapy_Patient_Reason)
                                   ||  isMedicationAdministeredNotDoneOnEncounter(visit, m,QPP5Elements.Arb_Or_Ace_Inhibitor_Therapy_System_Reason)

                                 )
                            ||
                                  (
                                          isDiagnosedDuringEncounter(visit,m,QPP5Elements.Cardiogenic_Shock)

                                      &&  isDiagnosedDuringEncounter(visit,m,QPP5Elements.Hypotension)

                                  )


                        )
  }


}

